#==============================================================================
#   Hirion Engine - Item
#   Author: Nicke
#   Created: 07/11/2013
#   Edited: 10/11/2013
#   Version: 1.0a
#==============================================================================
# Instructions
# -----------------------------------------------------------------------------
# To install this script, open up your script editor and copy/paste this script
# to an open slot below ? Materials but above ? Main. Remember to save.
#==============================================================================
# Required scripts (Added above this script): 
# Hirion Engine - Core
# Hirion Engine - Settings
#==============================================================================
#
# This script changes the visual of the item scene. Optional to use.
#
# *** Only for RPG Maker VX Ace. ***
#==============================================================================
($imported ||= {})["HIRION-ENGINE-ITEM"] = true
# // Check if required scripts are imported properly.
ERROR.imported?("HIRION-ENGINE-CORE", "Hirion Engine - Item")
# *** Don't edit below unless you know what you are doing. ***
#==============================================================================#
# ** Window_Item_Help
#==============================================================================#
class Window_Item_Help < Window_Help
  
  def category_window=(category_window)
    # // Method to set category window.
    @category_window = category_window
    refresh
  end
  
  def draw_stats_icon(icon_index, x, y, alpha)
    # // Method to draw stats icon.
    bitmap = Cache.system("Iconset")
    rect = Rect.new(icon_index % 16 * 24, icon_index / 16 * 24, 24, 24)
    contents.blt(x, y, bitmap, rect, alpha)
  end
  
  def refresh
    # // Refresh help contents.
    contents.clear
    font_help = HIRION::SETTINGS::ITEM_HELP
    font_stats = HIRION::SETTINGS::ITEM_STATS
    font_param = HIRION::SETTINGS::ITEM_PARAM
    if @text.is_a?(String)
      # // Draw category icon.
      unless @category_window.nil?
        c_icon = HIRION::SETTINGS::ITEM_CATEGORIES[@category_window.current_symbol][2]
        draw_icon(c_icon, 0, 0)
      end
      # // Draw category help text.
      draw_str(@text, 26, 4, contents_width, 0, font_help[0], font_help[1], font_help[2], font_help[3], font_help[4], font_help[5], font_help[6])
      # // Draw category sort text.
      draw_str("Sort items by pressing CTRL.", 2, line_height, contents_width, 0, font_help[0], font_help[1], font_help[2], font_help[3], font_help[4], font_help[5], font_help[6])
    else
      # // Draw item details if valid item.
      return if @text.nil?
      # // Draw item icon.
      draw_icon(@text.icon_index, 0, 0)
      # // Draw item details.
      if @text.is_a?(RPG::Item)
        # // Draw item consumable type.
        type = @text.consumable ? "Consumable" : "Non-Consumable"
        # // Draw success rate, repeats, speed & tp gain.
        draw_str("Success: #{@text.success_rate}%.  �  Repeats: x#{@text.repeats}.  �  Speed: #{@text.speed}.   �  TP Gain: #{@text.tp_gain}.", 0, line_height * 2, contents_width, 1, font_help[0], font_help[1], font_help[2], font_help[3], font_help[4], font_help[5], font_help[6])
        # // Draw item scope & occasion.
        draw_scope(@text, "Usable by: ", 0, line_height * 1, font_help, 1)
        draw_occasion(@text, "Occasion: ", 0, line_height * 1, font_help, 2)
      end
      # // Draw weapon type if weapon.
      if @text.is_a?(RPG::Weapon)
        type = $data_system.weapon_types[@text.wtype_id]
      end
      # // Draw armor and equip types if armor.
      if @text.is_a?(RPG::Armor)
        atype = $data_system.armor_types[@text.atype_id]
        etype = $data_system.terms.etypes[@text.etype_id]
        type = "#{atype} [#{etype}]"
      end
      # // Draw stats with rect and icons if weapon or armor.
      if @text.is_a?(RPG::Weapon) || @text.is_a?(RPG::Armor)
        draw_str("Stats:", 0, line_height * 2, contents_width, 0, font_stats[0], font_stats[1], font_stats[2], font_stats[3], font_stats[4], font_stats[5], font_stats[6])
        8.times {|i| draw_rect((28 * i) + 48, line_height * 2, 24, 24, Color.new(255,255,255,96), Color.new(0,0,0,128))}
        param_icons = HIRION::SETTINGS::ITEM_PARAM_ICONS
        param_icons.each_with_index {|v, i|
          alpha = @text.params[i] == 0 ? 50 : 150
          draw_stats_icon(v, 48 + (28 * i), line_height * 2, alpha) 
        }
        # // Draw item category color.
        @text.params.each_with_index {|v, i|
          if v > 0
            font_param_color = Color.new(80,255,80) ; param_value = "+#{v}" 
          end
          if v == 0
            font_param_color = font_param[2] ; param_value = "#{v}" 
          end
          if v < 0
            font_param_color = Color.new(255,80,80) ; param_value = "#{v}" 
          end
          draw_str(param_value, 48 + (28 * i), line_height * 1.95, 24, 1, font_param[0], font_param[1], font_param_color, font_param[3], font_param[4], font_param[5], font_param[6])
        }
      end
      # // Draw item name with description.
      details = "#{@text.name} (#{type}): #{@text.description}"
      draw_str(details, 26, 4, contents_width, 0, font_help[0], font_help[1], font_help[2], font_help[3], font_help[4], font_help[5], font_help[6])
      # // Draw item value with gold icon.
      draw_icon(HIRION::SETTINGS::ITEM_GOLD_ICON, 0, line_height * 1) unless HIRION::SETTINGS::ITEM_GOLD_ICON.nil?
      value = "Value: #{@text.price}#{Vocab::currency_unit}."
      draw_str(value, 26, line_height * 1, contents_width, 0, font_help[0], font_help[1], font_help[2], font_help[3], font_help[4], font_help[5], font_help[6])
    end
    # // Draw lines.
    draw_shadow_line(0, line_height * 0.65, Color.new(255,255,255), Color.new(0,0,0,128), contents_width, 2)
  end
  
end
#==============================================================================
# ** Window_ItemCategory
#==============================================================================
class Window_ItemCategory < Window_HorzCommand
  
  def window_width
    # // Method to determine the width of the window.
    return Graphics.width * 0.975
  end
  
  def window_height
    # // Method to determine the height of the window.
    return 50
  end
  
  def col_max
    # // Method to determine col max.
    return @list.size / 2 + 1
  end
  
  def item_height
    # // Method to set item height.
    return 26
  end
  
  def spacing
    # // Method to determine spacing.
    return 1
  end
  
  def draw_item(index)
    # // Method to draw item.
    font = HIRION::SETTINGS::ITEM_CAT
    rect = item_rect(index)
    item = HIRION::SETTINGS::ITEM_CATEGORIES[@list[index][:symbol]]
    # // Draw rect for item.
    draw_rect(rect.x, rect.y, rect.width, 26, Color.new(75,75,75), Color.new(0,0,0,150))   
    # // Draw text.
    draw_str(command_name(index).upcase, rect.x, rect.y + 4, rect.width, 1, font[0], font[1], font[2], font[3], font[4], font[5], font[6])
    # // Draw icon.
    draw_icon(item[2], rect.x + 2, rect.y)
  end
  
  def make_command_list
    # // Method to add the commands.
    HIRION::SETTINGS::ITEM_CATEGORIES.each {|key, value|
      name = value[0] == "" ? key.id2name.capitalize : value[0]
      add_command(name, key)
    }
  end
  
end
#==============================================================================#
# ** Window_ItemList
#==============================================================================#
class Window_ItemList < Window_Selectable
  
  def col_max
    # // Method to determine col_max.
    return 4
  end
  
  def spacing
    # // Method to determine spacing.
    return 4
  end
  
  def category=(category)
    # // Method to set category.
    return if @category == category
    @category = category
    refresh
    self.oy = 0
    @help_window.set_text(HIRION::SETTINGS::ITEM_CATEGORIES[category][1])
  end
  
  def include?(item)
    # // Method to check if category is included.
    HIRION::SETTINGS.item_category(@category, item)
  end
  
  def item_category?(item)
    # // Method to scan the item notes for category color.
    item.note.scan(/<category[:] (\w*)>/i)
    return ($1.nil? ? :default : $1.to_sym)
  end
  
  def make_item_list(sort)
    # // Method to make item list.
    @data = $game_party.all_items.select {|item| include?(item) }
    case sort
    when :price_high ; @data.sort! { |a,b| a.price <=> b.price }
    when :price_low  ; @data.sort! { |a,b| b.price <=> a.price }
    when :a_z        ; @data.sort! { |a,b| a.name.downcase <=> b.name.downcase }
    when :z_a        ; @data.sort! { |a,b| b.name.downcase <=> a.name.downcase }
    when :none       ; nil
    end
    @data.push(nil) if include?(nil)
  end
  
  def draw_item(index)
    # // Method to draw item.    
    item = @data[index]
    if item
      # // Draw rect for item.
      rect = item_rect(index)
      color = HIRION::SETTINGS.item_color(item_category?(item))
      draw_rect(rect.x, rect.y, rect.width, item_height, Color.new(255,255,255,128), color) 
      # // Draw icon.
      draw_icon(item.icon_index, rect.x + 4, rect.y, enable?(item))
      # // Draw name.
      item_font_name = HIRION::SETTINGS::ITEM_NAME
      draw_str(item.name, rect.x + 30, rect.y + 4, rect.width, 0, item_font_name[0], item_font_name[1], item_font_name[2], item_font_name[3], item_font_name[4], item_font_name[5], item_font_name[6])
      # // Draw item amount.
      item_font_amount = HIRION::SETTINGS::ITEM_AMOUNT
      amt = $game_party.item_number(item) > 9 ? "x%2d" : "x%02d"
      draw_str(sprintf(amt, $game_party.item_number(item)), rect.x + 6, rect.y + 6, rect.width, 0, item_font_amount[0], item_font_amount[1], item_font_amount[2], item_font_amount[3], item_font_amount[4], item_font_amount[5], item_font_amount[6])    
    end
  end

  def update_help
    # // Method to update help window.
    return if item.nil?
    @help_window.set_text(item)
  end
  
  def refresh(sort = :none)
    # // Method to refresh window.
    make_item_list(sort)
    create_contents
    draw_all_items
    # // Draw no items text if no available items is found for selected category.
    if @data.empty?
      item_font_no_items = HIRION::SETTINGS::ITEM_NO_ITEMS
      draw_str("No available items for this category.", 0, contents_height / 2, contents_width, 1, item_font_no_items[0], item_font_no_items[1], item_font_no_items[2], item_font_no_items[3], item_font_no_items[4], item_font_no_items[5], item_font_no_items[6])
    end
  end
  
end
#==============================================================================
# ** Scene_ItemBase
#==============================================================================
class Scene_ItemBase < Scene_MenuBase
    
  alias hirion_item_scene_itembase_create_actor_win create_actor_window
  def create_actor_window(*args, &block)
    # // Method to create actor window.
    hirion_item_scene_itembase_create_actor_win(*args, &block)
    @actor_window.z = 200
    @actor_window.back_opacity = 255
  end
  
  def show_sub_window(window)
    # // Method override to show sub window.
    window.center
    window.show.activate
  end
  
end
#==============================================================================
# ** Window_ItemSort
#==============================================================================
class Window_ItemSort < Window_Command
  
  def window_width
    # // Method to determine the width of the window.
    return 200
  end

  def window_height
    # // Method to determine the height of the window.
    return fitting_height(@list.size)
  end

  def draw_item(index)
    # // Method to draw item.
    font = HIRION::SETTINGS::MENU_FONT_CHAR_OPTIONS
    rect = item_rect(index)
    enabled = command_enabled?(index)
    color = font[2]
    color.alpha = enabled ? 255 : 128
    draw_str(command_name(index), rect.x, rect.y, rect.width, 1, font[0], font[1], color, font[3], font[4], font[5], font[6])
  end
  
  def make_command_list
    # // Method to add the commands.
    add_command("Sort by highest price.", :price_high)
    add_command("Sort by lowest price.", :price_low)
    add_command("Sort by A-Z.", :a_z)
    add_command("Sort by Z-A.", :z_a)
  end

end
#==============================================================================
# ** Scene_Item
#==============================================================================
class Scene_Item < Scene_ItemBase
  
  def start
    # // Method to start the scene.
    super
    create_background
    create_help_window
    create_category_window
    create_item_window
  end

  def create_category_window
    # // Method to create the category window.
    @category_window = Window_ItemCategory.new
    @category_window.center(:x) 
    @category_window.viewport = @viewport
    @category_window.help_window = @help_window
    @category_window.y = @category_window.height
    @category_window.set_handler(:ok,     method(:on_category_ok))
    @category_window.set_handler(:cancel, method(:return_scene))
    @category_window.opacity = 0
    @help_window.category_window = @category_window
  end
  
  def create_help_window
    # // Method to create the help window.
    @help_window = Window_Item_Help.new(3)
    @help_window.viewport = @viewport
    @help_window.center(:x)
    @help_window.y = (Graphics.height - @help_window.height) + 8
    @help_window.opacity = 0
  end
  
  def create_item_window
    # // Method to create the item window.
    w = Graphics.width * 0.9
    h = Graphics.height * 0.65
    y = @category_window.height + @category_window.y - 16
    @item_window = Window_ItemList.new(0, y, w, h)
    @item_window.center(:x)
    @item_window.viewport = @viewport
    @item_window.help_window = @help_window
    @item_window.set_handler(:ok,     method(:on_item_ok))
    @item_window.set_handler(:cancel, method(:on_item_cancel))
    @category_window.item_window = @item_window
    @item_window.opacity = 0
  end
  
  def create_sort_window
    # // Method to create sort window.
    instance_variables.each do |varname|
      ivar = instance_variable_get(varname)
      if ivar.is_a?(Window)
        ivar.deactivate if ivar.active
      end
    end
    @sort_window = Window_ItemSort.new(0, 0)
    @sort_window.center
    @sort_window.z = 9999
    @sort_window.back_opacity = 255
    @sort_window.set_handler(:ok,     method(:on_sort_ok))
    @sort_window.set_handler(:cancel, method(:on_sort_cancel))
  end
  
  def update
    # // Method to update the scene.
    super
    create_sort_window if Input.trigger?(:CTRL) and @sort_window.nil?
  end
  
  def on_item_cancel
    # // Method to cancel item window.
    @item_window.unselect
    @category_window.activate
    @help_window.set_text(HIRION::SETTINGS::ITEM_CATEGORIES[@category_window.current_symbol][1])
  end
  
  def on_sort_ok
    # // Method to ok sort window.
    @item_window.refresh(@sort_window.current_symbol)
    on_sort_cancel
  end
  
  def on_sort_cancel
    # // Method to cancel sort window.
    @sort_window.dispose unless @sort_window.nil?
    @sort_window = nil
    @category_window.activate
    @help_window.set_text(HIRION::SETTINGS::ITEM_CATEGORIES[@category_window.current_symbol][1])
  end
  
end # END OF FILE

#=*==========================================================================*=#
# ** END OF FILE
#=*==========================================================================*=