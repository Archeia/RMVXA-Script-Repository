#==============================================================================
#   Hirion Engine - Error handler.
#   Author: Nicke
#   Created: 22/10/2013
#   Edited: 04/11/2013
#   Version: 1.0
#==============================================================================
# Instructions
# Script(s)
# Install the scripts in this order:
# Hirion Engine - Error Handler
# Hirion Engine - Settings
# Hirion Engine - Core
# Hirion Engine - Main Menu
# Hirion Engine - Status
# Hirion Engine - Item
# Hirion Engine - Equip
# -----------------------------------------------------------------------------
# To install this script, open up your script editor and copy/paste this script
# to an open slot below ? Materials but above ? Main. Remember to save.
#
# Error handler.
#
# *** Only for RPG Maker VX Ace. ***
# *** Don't edit below unless you know what you are doing. ***
#==============================================================================#
# ** Error handler.
#==============================================================================#
module ERROR
  
  def self.imported?(imported, script)
    unless $imported[imported]
      # // Error handler.
      raise("Error with the script: #{script}.\nPlease install Hirion Engine - Core & Settings.")
      exit
    end
  end
  
end # END OF FILE

#=*==========================================================================*=#
# ** END OF FILE
#=*==========================================================================*=#