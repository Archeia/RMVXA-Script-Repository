#==============================================================================
#   Hirion Engine - Core
#   Author: Nicke
#   Created: 22/10/2013
#   Edited: 10/11/2013
#   Version: 1.0b
#==============================================================================
# Instructions
# -----------------------------------------------------------------------------
# To install this script, open up your script editor and copy/paste this script
# to an open slot below ? Materials but above ? Main. Remember to save.
#==============================================================================
# Required scripts (Added above this script): 
# Hirion Engine - Settings
#==============================================================================
#
# Core script for Hirion Engine.
#
# *** Only for RPG Maker VX Ace. ***
#==============================================================================
($imported ||= {})["HIRION-ENGINE-CORE"] = true 
# // Check if required scripts are imported properly.
ERROR.imported?("HIRION-ENGINE-SETTINGS", "Hirion Engine - Core")
# // Set graphic resolution.
Graphics.resize_screen(HIRION::SETTINGS::RESOLUTION[0], HIRION::SETTINGS::RESOLUTION[1])
# *** Don't edit below unless you know what you are doing. ***
#==============================================================================#
# ** String
#==============================================================================#
class String
  
  def to_class(parent = Kernel)
    # // Method to convert string to class.
    chain = self.split "::"
    klass = parent.const_get chain.shift
    return chain.size < 1 ? (klass.is_a?(Class) ? klass : nil) : chain.join("::").to_class(klass)
    rescue
    nil
  end
  
  def slice_char(char)
    # // Method to slice char.
    self.split(char).map {|w| w.sub(char, " ") }.join(" ")
  end
  
end
#==============================================================================#
# ** Numeric
#==============================================================================#
class Numeric
  
  def round_to(places)
    power = 10.0 ** places
    (self * power).round / power
  end
  
  def percent_of(n)
    self.to_f / n.to_f * 100.0
  end
  
  def percents
    self * 100
  end
  
end
#==============================================================================
# ** Vocab
#==============================================================================
class << Vocab
  
  def create(name, value=nil, &block)
    # // Method to create a new vocab method.
    return if respond_to?(name)
    if block_given?
      define_method(name, &block)
    else
      define_method(name) { value }
    end
    module_function name
  end
  
end
#==============================================================================
# ** Sound
#==============================================================================
class << Sound
  
  def play(name, volume, pitch, type = :se)
    # // Method to play a sound. If specified name isn't valid throw an error.
    case type
    when :se  ; RPG::SE.new(name, volume, pitch).play rescue valid?(name)
    when :me  ; RPG::ME.new(name, volume, pitch).play rescue valid?(name)
    when :bgm ; RPG::BGM.new(name, volume, pitch).play rescue valid?(name)
    when :bgs ; RPG::BGS.new(name, volume, pitch).play rescue valid?(name)
    end
  end
  
  def valid?(name)
    # // Method to raise error if specified sound name is invalid.
    raise("Unable to find sound file: #{name}")
    exit 
  end
  
end
#==============================================================================#
# ** Game_BattlerBase
#==============================================================================#
class Game_BattlerBase
  
  def exp_rate
    # // Method to set exp rate.
    x, x2 = exp.to_f - current_level_exp.to_f, next_level_exp.to_f - current_level_exp.to_f
    return x / x2
  end
  
end
#==============================================================================#
# ** Sprite_Particle
#==============================================================================#
class Sprite_Particle < Sprite
  
  attr_reader :done
  
  def initialize(particle, x, y, z, opacity, angle, blend_type)
    # // Method to initialize sprite.
    super()
    self.bitmap = Cache.picture(particle)
    self.x = x
    self.y = y
    self.z = z
    self.ox = self.bitmap.width
    self.oy = self.bitmap.height
    self.blend_type = blend_type
    @angle = angle
    @opacity = opacity
    @done = false
  end
  
  def update
    # // Method to update sprite.
    self.opacity -= @opacity
    self.angle += rand(@angle)
    if self.opacity <= 0
      self.bitmap = nil
      dispose 
    end
  end
  
  def dispose
    # // Method to dispose sprite.
    super
    @done = true
  end
  
end
#==============================================================================#
# ** Window_Base
#==============================================================================#
class Window_Base < Window
  
  def center(type = :both)
    # // Method to center the window.
    case type
    when :both
      self.x = (Graphics.width - self.width) / 2
      self.y = (Graphics.height - self.height) / 2
    when :x 
      self.x = (Graphics.width - self.width) / 2
    when :y 
      self.y = (Graphics.height - self.height) / 2
    end
  end
  
  def draw_str(str, x, y, w, alg, f, sz, c, oc = Color.new(0,0,0,255), b = true, s = true, i = false)
    # // Method to draw text.
    contents.font.name = f
    contents.font.size = sz
    contents.font.color = c
    contents.font.bold = b
    contents.font.shadow = s
    contents.font.italic = i
    contents.font.out_color = oc
    draw_text(x, y, w, calc_line_height(str), str, alg)
    reset_font_settings
  end
  
  def draw_str_ex(str, x, y, f, sz, c, oc = Color.new(0,0,0,255), b = true, s = true, i = false)
    # // Method to draw text ex.
    contents.font.name = f
    contents.font.size = sz
    contents.font.color = c
    contents.font.bold = b
    contents.font.shadow = s
    contents.font.italic = i
    contents.font.out_color = oc
    str = convert_escape_characters(str)
    pos = {:x => x, :y => y, :new_x => x, :height => calc_line_height(str)}
    process_character(str.slice!(0, 1), str, pos) until str.empty?
    reset_font_settings
  end
  
  def draw_bar(x, y, width, height, rate, c1, c2, s1 = Color.new(255,255,255,128), s2 = Color.new(0,0,0,64))
    # // Method to draw a bar gauge.
    fill_w = ((width - 4) * rate).to_i
    gauge_y = y + line_height - 8
    contents.fill_rect(x, gauge_y, width, height, s1)
    contents.fill_rect(x + 1, gauge_y + 1, width - 2, height - 2, s2)
    contents.gradient_fill_rect(x + 2, gauge_y + 2, fill_w, height - 4, c1, c2)
  end
  
  def draw_bar_param(actor, x, y, width, param_id, font, bar_color1, bar_color2)
    # // Method to draw actor bar parameters.
    case param_id
    when 2 ; param_rate = actor.param(2) / actor.param_max(2).to_f
    when 3 ; param_rate = actor.param(3) / actor.param_max(3).to_f
    when 4 ; param_rate = actor.param(4) / actor.param_max(4).to_f
    when 5 ; param_rate = actor.param(5) / actor.param_max(5).to_f
    when 6 ; param_rate = actor.param(6) / actor.param_max(6).to_f
    when 7 ; param_rate = actor.param(7) / actor.param_max(7).to_f
    end
    draw_bar(x, y - 15, width, 20, param_rate, bar_color1, bar_color2)
    param = "#{sprintf("%03d", actor.param(param_id))}"
    draw_str(Vocab::param(param_id), x + 6, y, width, 0, font[0], font[1], font[2], font[3], font[4], font[5], font[6])
    draw_str(param, x - 6, y, width, 2, font[0], font[1], font[2], font[3], font[4], font[5], font[6])
  end
  
  def draw_shadow_line(x, y, color, shadow, width = 2, height = 2, type = :h)
    # // Method to draw line with a shadow.
    case type
    when :h
      line_y = y + line_height / 2 - 1
      contents.fill_rect(x, line_y, width, height, color)
      line_y += 1
      contents.fill_rect(x, line_y, width, height, shadow)
    when :v
      line_x = x + line_height / 2 - 1
      contents.fill_rect(line_x, y, width, height, color)
      line_x += 1
      contents.fill_rect(line_x, y, width, height, shadow)
    end
  end
  
  def draw_rect(x, y, width, height, color, shadow)
    # // Method to draw a rectangle with shadow.
    contents.fill_rect(x, y, width, height, color)
    contents.fill_rect(x + 1, y + 1, width - 2, height - 2, shadow)
  end
  
  def draw_actor_stats(actor, stat, x, y, stat_x, stat_y, color1, color2, width, height, vocab, vocab_x, vocab_y, font)
    # // Method to draw actor stats.
    case stat
    when :hp  ; rate = actor.hp_rate  ; values = [actor.hp,  actor.mhp]
    when :mp  ; rate = actor.mp_rate  ; values = [actor.mp,  actor.mmp]
    when :exp ; rate = actor.exp_rate ; values = [actor.exp, actor.next_level_exp]
    when :tp  ; rate = actor.tp_rate  ; values = [actor.tp,  actor.max_tp]
    end
    # // Draw guage.
    draw_bar(x, y - 8, width, height, rate, color1, color2)
    # // Draw stats and vocab.
    str = "#{values[0]} / #{values[1]}"
    draw_str(str, x + stat_x, y + stat_y, width, 1, font[0], font[1], font[2], font[3], font[4], font[5], font[6])
    draw_str(vocab, x + vocab_x, y + vocab_y, width, 0, font[0], font[1], font[2], font[3], font[4], font[5], font[6])
  end
  
  def draw_scope(item, text, x, y, font, alg)
    # // Method to draw scope for item.
    case @text.scope
    when 0  ; str = "None"
    when 1  ; str = "One Enemy"
    when 2  ; str = "All Enemies"
    when 3  ; str = "One Random Enemies"
    when 4  ; str = "Two Random Enemies"
    when 5  ; str = "Three Random Enemies"
    when 6  ; str = "Four Random Enemies"
    when 7  ; str = "One Ally"
    when 8  ; str = "All Allies"
    when 9  ; str = "Dead Ally"
    when 10 ; str = "Dead Allies"
    when 11 ; str = "User"
    end
    draw_str("#{text} #{str}.", x, y, contents_width, alg, font[0], font[1], font[2], font[3], font[4], font[5], font[6])
  end
  
  def draw_occasion(item, text, x, y, font, alg)
    # // Method to draw scope for item.
    case @text.occasion
    when 0  ; str = "Always"
    when 1  ; str = "Only in battle Enemy"
    when 2  ; str = "Only from the Menu"
    when 3  ; str = "Never"
    end
    draw_str("#{text} #{str}.", x, y, contents_width, alg, font[0], font[1], font[2], font[3], font[4], font[5], font[6])
  end
  
  def draw_icon_ex(icon_index, x, y, alpha)
    # // Method to draw icon.
    bitmap = Cache.system("Iconset")
    rect = Rect.new(icon_index % 16 * 24, icon_index / 16 * 24, 24, 24)
    contents.blt(x, y, bitmap, rect, alpha)
  end
  
end # END OF FILE

#=*==========================================================================*=#
# ** END OF FILE
#=*==========================================================================*=#