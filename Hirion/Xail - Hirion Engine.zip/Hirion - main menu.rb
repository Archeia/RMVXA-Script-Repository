#==============================================================================
#   Hirion Engine - Main Menu
#   Author: Nicke
#   Created: 22/10/2013
#   Edited: 10/11/2013
#   Version: 1.0b
#==============================================================================
# Instructions
# -----------------------------------------------------------------------------
# To install this script, open up your script editor and copy/paste this script
# to an open slot below ? Materials but above ? Main. Remember to save.
#==============================================================================
# Required scripts (Added above this script): 
# Hirion Engine - Core
# Hirion Engine - Settings
#==============================================================================
#
# This script changes the visual of menu scene as well as adding new features
# to it. Don't use this script with any XS - Menu versions.
#
# To setup use the instructions module which needs to be located above this
# script. Make sure you read through everything to understand each section.
#
# *** Only for RPG Maker VX Ace. ***
#==============================================================================
($imported ||= {})["HIRION-ENGINE-MAIN-MENU"] = true
# // Check if required scripts are imported properly.
ERROR.imported?("HIRION-ENGINE-CORE", "Hirion Engine - Main Menu")
# *** Don't edit below unless you know what you are doing. ***
#==============================================================================#
# ** Game_System
#==============================================================================#
class Game_System
  
  attr_accessor :menu_list
  
  alias hirion_main_menu_gm_sys_initialize initialize
  def initialize(*args, &block)
    # // Method to initialize game system.
    hirion_main_menu_gm_sys_initialize(*args, &block)
    @menu_list = {}
  end
  
  def get_menu
    # // Method to get the menu list.
    HIRION::SETTINGS::MENU_CUSTOM ? @menu_list : HIRION::SETTINGS::MENU_LIST
  end
  
end
#==============================================================================#
# ** Game_Interpreter
#==============================================================================#
class Game_Interpreter

  def menu_custom?
    # // Check if menu custom is enabled or else raise error.
    raise ("Menu custom is disabled! Don't use any menu scene methods.") unless HIRION::SETTINGS::MENU_CUSTOM
  end
  
  def menu_scene(key, type = :add)  
    # // Method to add/remove a menu item to the list.
    menu_custom?
    list = HIRION::SETTINGS::MENU_LIST
    valid = "The key: \"#{key}\" doesn't exists in the menu list! Please use a valid one.\nValid keys: #{list.keys}"
    included = "The key: \"#{key}\" already exists in the menu list!\nPlease add another one."
    case type
      when :add
      return raise(valid)    if list[key].nil?
      return raise(included) if $game_system.menu_list.has_key?(key)
      $game_system.menu_list[key] = list[key]
      when :del
      raise(valid) if list[key].nil?
      $game_system.menu_list.delete(key) 
    end
  end
  
  def menu_active(key, enabled)
    # // Method to enable id.
    menu_custom?
    $game_system.menu_list[key][3] = enabled
  end
  
  def menu_active?(key)
    # // Method to check if menu key is enabled.
    menu_custom?
    return $game_system.menu_list[key][3] rescue false
  end
  
  def menu_add_all
    # // Method to add all available menu items.
    HIRION::SETTINGS::MENU_LIST.each_key {|key| menu_scene(key) }
  end
  
  def menu_del_all
    # // Method to remove all available menu items.
    HIRION::SETTINGS::MENU_LIST.each_key {|key| menu_scene(key, :del) }
  end

end
#==============================================================================
# ** Window_MenuCommand
#==============================================================================
class Window_MenuCommand < Window_Command
  
  def window_width
    # // Method to determine the width of the window.
    return 200
  end

  def window_height
    # // Method to determine the height of the window.
    return @list.size * item_height + standard_padding * 2
  end
  
  def item_height
    # // Method to set item height.
    return 32
  end

  def draw_item(index)
    # // Method to draw item.
    font = HIRION::SETTINGS::MENU_FONT
    rect = item_rect(index)
    item = HIRION::SETTINGS::MENU_LIST[@list[index][:symbol]]
    enabled = command_enabled?(index)
    color = font[2]
    color.alpha = enabled ? 255 : 128
    # // Draw text.
    draw_str(command_name(index).upcase, rect.x + 26, rect.y + 6, rect.width, 0, font[0], font[1], color, font[3], font[4], font[5], font[6])
    # // Draw icons.
    draw_icon(item[2], rect.x + 2, rect.y + 4, true)
  end
  
  def make_command_list
    # // Method to add the commands.
    $game_system.get_menu.each {|key, value|
      name = value[0] == "" ? key.id2name.capitalize : value[0]
      HIRION::SETTINGS::MENU_LIST[:save][3] = save_enabled if HIRION::SETTINGS::MENU_SAVE
      add_command(name, key, value[3], value[5].nil? ? nil : value[5])
    }
  end

end
#==============================================================================
# ** Window_Menu_Details
#==============================================================================
class Window_Menu_Details < Window_Base
  
  def initialize(x, y)
    # // Method to initialize.
    super(x, y, Graphics.width, fitting_height(1))
    @playtime = $game_system.playtime_s
    refresh
  end
  
  def refresh
    # // Method to refresh the window.
    contents.clear
    # // Draw map.
    font = HIRION::SETTINGS::MENU_FONT_DETAILS
    icon = HIRION::SETTINGS::MENU_DETAIL_ICONS
    draw_icon(icon[0], 0, 0)
    draw_str($data_mapinfos[$game_map.map_id].name, 26, 2, contents_width, 0, font[0], font[1], font[2], font[3], font[4], font[5], font[6])
    # // Draw gold.
    gold = "#{sprintf("%07d", $game_party.gold)}#{Vocab::currency_unit}"
    draw_icon(icon[1], (contents_width / 2) + 36, 0)
    draw_str(gold, -148, 2, contents_width, 2, font[0], font[1], font[2], font[3], font[4], font[5], font[6])
    # // Draw playtime.
    draw_icon(icon[2], contents_width - 90, 0)
    draw_str(@playtime, 0, 2, contents_width, 2, font[0], font[1], font[2], font[3], font[4], font[5], font[6])
  end
  
  def update
    # // Method to update the window.
    super
    @playtime = $game_system.playtime_s
    refresh
  end
  
end
#==============================================================================
# ** Window_MenuStatus
#==============================================================================
class Window_MenuStatus < Window_Selectable
  
  def initialize(x, y)
    # // Method to initialize the window.
    super(x, y, window_width, window_height)
    self.arrows_visible = false
    @pending_index = -1
    refresh    
  end
  
  def window_width
    # // Method to determine window width.
    return (Graphics.width == 640 ? col_max : col_max) * item_width + standard_padding * 2
  end
  
  def window_height
    # // Method to determine window height.
    return 244
  end
  
  def col_max
    # // Method to determine col max.
    col = HIRION::SETTINGS::MENU_ACTORS
    return Graphics.width == 640 ? col[0] : col[1]
  end

  def spacing
    # // Method to determine spacing.
    return 0
  end
  
  def item_width
    # // Method to determine item width.
    return 100
  end

  def item_height
    # // Method to determine item height.
    return 220
  end

  def draw_item(index)
    # // Method to draw item.
    actor = $game_party.members[index]
    rect = item_rect(index)
    actor_font_name = HIRION::SETTINGS::MENU_ACTOR_NAME
    actor_font_lvl = HIRION::SETTINGS::MENU_ACTOR_LVL 
    actor_font_stats = HIRION::SETTINGS::MENU_ACTOR_STATS
    # // Draw rect.
    draw_rect(rect.x, rect.y, rect.width, 39, Color.new(0,0,0,64), Color.new(0,0,0,64))
    # // Draw side lines.
    draw_shadow_line(rect.x - 11, rect.y, Color.new(255,255,255), Color.new(0,0,0,64), 1, contents_height, :v)
    draw_shadow_line(contents_width - 12, 0, Color.new(255,255,255), Color.new(0,0,0,64), 1, contents_height, :v)
    # // Draw top line.
    draw_shadow_line(rect.x, rect.y - 11, Color.new(255,255,255), Color.new(0,0,0,64), contents_width, 1)
    # // Draw name.
    draw_str(actor.name, rect.x, rect.y, rect.width, 1, actor_font_name[0], actor_font_name[1], actor_font_name[2], actor_font_name[3], actor_font_name[4], actor_font_name[5], actor_font_name[6])
    # // Draw class.
    draw_str(actor.class.name, rect.x + 8, rect.y + 18, rect.width, 0, actor_font_name[0], actor_font_name[1], actor_font_name[2], actor_font_name[3], actor_font_name[4], actor_font_name[5], actor_font_name[6])
    # // Draw face.
    draw_actor_face(actor, rect.x + 2, rect.y + (rect.height - 98))
    # // Draw level.
    lvl = "#{Vocab::level_a} #{actor.level}"
    draw_str(lvl, rect.x + 4, rect.y + (rect.height - 22), rect.width, 0, actor_font_lvl[0], actor_font_lvl[1], actor_font_lvl[2], actor_font_lvl[3], actor_font_lvl[4], actor_font_lvl[5], actor_font_lvl[6])
    # // Draw bottom line.
    draw_shadow_line(rect.x, rect.y + (rect.height - 13), Color.new(255,255,255), Color.new(0,0,0,64), contents_width, 1)
    # // Draw stats.   
    Vocab.create(:exp_a, "EXP")
    stats_height = 30
    draw_actor_stats(actor, :hp, rect.x + 2, rect.y + stats_height, 0, 18, HIRION::SETTINGS::MENU_BAR_HP[0], HIRION::SETTINGS::MENU_BAR_HP[1], rect.width - 3, stats_height, Vocab.hp_a, 6, rect.y + 6, actor_font_stats)
    draw_actor_stats(actor, :mp, rect.x + 2, rect.y + stats_height * 2, 0, 18, HIRION::SETTINGS::MENU_BAR_MP[0], HIRION::SETTINGS::MENU_BAR_MP[1], rect.width - 3, stats_height, Vocab.mp_a, 6, rect.y + 6, actor_font_stats)
    draw_actor_stats(actor, :exp, rect.x + 2, rect.y + stats_height * 3, 0, 18, HIRION::SETTINGS::MENU_BAR_EXP[0], HIRION::SETTINGS::MENU_BAR_EXP[1], rect.width - 3, stats_height, Vocab.exp_a, 6, rect.y + 6, actor_font_stats)
  end

end
#==============================================================================#
# ** Window_Menu_Help
#==============================================================================#
class Window_Menu_Help < Window_Help
  
  def refresh
    # // Method to refresh the window.
    contents.clear
    font = HIRION::SETTINGS::MENU_HELP_FONT
    draw_str(@text, 0, 0, contents_width, 0, font[0], font[1], font[2], font[3], font[4], font[5], font[6])
  end
  
end
#==============================================================================#
# ** Window_Menu_Character_Options
#==============================================================================#
class Window_Menu_Character_Options < Window_HorzCommand
  
  def initialize(x, y, width)
    # // Method to initialize the window.
    @window_width = width
    super(x, y)
  end
  
  def window_width
    # // Method to determine the width of the window.
    return @window_width
  end
  
  def update_open
    # // Method override to update window opening.
    self.openness += 25
    self.opacity = self.openness unless self.opacity == 0
    self.back_opacity = self.openness unless self.opacity == 0
    @opening = false if open?
  end

  def update_close
    # // Method override to update window closing.
    self.openness -= 25
    self.opacity = self.openness unless self.opacity == 0
    self.back_opacity = self.openness unless self.opacity == 0
    @closing = false if close?
  end
  
  def col_max
  # // Method to determine col max.
    return 3
  end
  
  def alignment
    # // Method to return the alignment.
    return 1
  end

  def draw_item(index)
    # // Method to draw item.
    font = HIRION::SETTINGS::MENU_FONT_CHAR_OPTIONS
    rect = item_rect(index)
    enabled = command_enabled?(index)
    color = font[2]
    color.alpha = enabled ? 255 : 128
    draw_str(command_name(index), rect.x, rect.y, rect.width, 1, font[0], font[1], color, font[3], font[4], font[5], font[6])
  end
  
  def make_command_list
    # // Method to add the commands.
    add_command("Change Equipment", :equip)
    add_command("Check Status", :status)
    add_command("Manage Skills", :skill)
  end
  
end
#==============================================================================#
# ** Scene_MenuBase
#==============================================================================#
class Scene_MenuBase < Scene_Base
  
  @@last_scene = nil
  
  def start
    # // Method to start the scene.
    super
    @actor = $game_party.menu_actor
    # // Check if current scene is Scene_Menu and create backgrounds.
    if SceneManager.scene_is?(Scene_Menu)
      @backgrounds = []
      create_menu_backgrounds
    end
    # // Store last played music bgm & bgs.
    @bgm = HIRION::SETTINGS::MENU_MUSIC_BGM
    @bgs = HIRION::SETTINGS::MENU_MUSIC_BGS
    @last_bgm = RPG::BGM.last if @last_bgm.nil?
    @last_bgs = RPG::BGS.last if @last_bgs.nil?
    # // Play music if enabled.
    play_menu_music
  end
  
  def create_background
    # // Mehod to create background.
    @background_sprite = Sprite.new
    @background_sprite.bitmap = SceneManager.background_bitmap
    @background_sprite.color.set(0, 0, 0, 192)
  end
  
  def create_menu_backgrounds
    # // Method to create custom background(s).
    HIRION::SETTINGS::MENU_BACKGROUND.each {|key, value| @backgrounds << [Sprite.new, key] }
    @backgrounds.each {|i|
      i[0].bitmap = Cache.system(i[1])
      i[0].x = HIRION::SETTINGS::MENU_BACKGROUND[i[1]][0]
      i[0].y = HIRION::SETTINGS::MENU_BACKGROUND[i[1]][1]
      i[0].z = HIRION::SETTINGS::MENU_BACKGROUND[i[1]][2]
      i[0].opacity = HIRION::SETTINGS::MENU_BACKGROUND[i[1]][3]
    }
  end
  
  def play_menu_music
    # // Method to play menu music.   
    if @bgm != RPG::BGM.last.name
      Sound.play(@bgm[0], @bgm[1], @bgm[2], :bgm) unless @bgm.nil?
      Sound.play(@bgs[0], @bgs[1], @bgs[2], :bgs) unless @bgs.nil?
    end
  end
  
  alias hirion_menubase_transition perform_transition
  def perform_transition(*args, &block)
    # // Method to create the transition.
    return if $game_system.get_menu.empty?
    if HIRION::SETTINGS::MENU_TRANSITION.nil?
      hirion_menubase_transition(*args, &block)
    else
      Graphics.transition(HIRION::SETTINGS::MENU_TRANSITION[0],HIRION::SETTINGS::MENU_TRANSITION[1],HIRION::SETTINGS::MENU_TRANSITION[2])
    end
  end
  
  def dispose_sprites
    # // Method to dispose sprites.
    @backgrounds.each {|i| i[0].dispose unless i[0].nil? ; i[0] = nil } rescue nil
  end
  
  def pre_terminate
    # // Method to pre terminate scene menu.
    # // Play last bgm and bgs if menu music is enabled.
    if SceneManager.scene_is?(Scene_Map)
      @last_bgm.replay rescue nil
      @last_bgs.replay rescue nil
    end
  end
  
  def terminate
    # // Method to terminate.
    super
    dispose_sprites unless SceneManager.scene_is?(Scene_Menu)
  end
  
  def return_scene
    # // Method to return scene.
    @@last_scene = SceneManager.scene.class
    super
  end

end
#==============================================================================#
# ** Scene_Menu
#==============================================================================#
class Scene_Menu < Scene_MenuBase
  
  def start
    # // Method to start the scene.
    # // Raise error if menu list is empty.
    super
    if $game_system.get_menu.empty? and HIRION::SETTINGS::MENU_CUSTOM
      raise("Menu custom is set to true and the system couldn't find any commands added to the menu scene!\nPlease add one or use the menu_add_all code before calling the scene.")
      exit
    end
    # // Setup particles.
    @particles = []
    @particles_timer = 0
    @particles_x = 0.1 + rand(1.0)
    @particles_y = 0.5 + rand(1.0)
    @particles_ox = 0.1 + rand(1.0)
    @particles_oy = 0.5 + rand(1.0)
    # // Create windows.
    create_menu_command_window
    create_menu_details_window
    create_menu_actor_window
    create_menu_help_window
    create_menu_particles
    # // Remember the last scene called when using the character window.
    # // Needed for reactivating the status window when returning to the scene.
    scenes = [Scene_Status, Scene_Skill, Scene_Equip]
    if @@last_scene && scenes.include?(@@last_scene)
      @@last_scene = nil
      @command_window.deactivate
      command_personal
    end 
  end
  
  def create_menu_particles
    # // Method to create the command window.
    HIRION::SETTINGS::MENU_PARTICLES.each {|k, v| 
      x = v[0] == :random ? HIRION::SETTINGS.random_particle_movement(:width) : v[0]
      y = v[1] == :random ? HIRION::SETTINGS.random_particle_movement(:height) : v[1]
      @particles << Sprite_Particle.new(k, x, y, v[2], v[3], v[4], v[5])
    }
  end
  
  def create_menu_command_window
    # // Method to create the command window.
    @command_window = Window_MenuCommand.new
    @command_window.opacity = 0
    @command_window.center(:y)
    $game_system.get_menu.each {|key, value|
      unless value[5].nil?
        @command_window.set_handler(key, method(:command_custom))
      else
        personal = value[4] == true ? :command_personal : "command_#{key}".to_sym
        @command_window.set_handler(key, method(personal))
      end
    }    
    @command_window.set_handler(:cancel, method(:return_scene))
  end
  
  def create_menu_details_window
    # // Method to create the details window.
    @details_window = Window_Menu_Details.new(0, 0)
    @details_window.x = 0
    @details_window.y = (Graphics.height - @details_window.height) + 8
    @details_window.opacity = 0
  end
  
  def create_menu_actor_window
    # // Method to create the actor window.
    @status_window = Window_MenuStatus.new(0, 0)
    @status_window.x = (Graphics.width - @status_window.width) / 1.1
    @status_window.center(:y)
    @status_window.back_opacity = 200
  end
  
  def create_menu_help_window
    # // Method to create help window.
    @help_window = Window_Menu_Help.new(1)
    @help_window.viewport = @viewport
    @help_window.opacity = 0
    @help_window.set_text(create_menu_help_text)
  end
  
  def create_menu_help_text
    # // Method to create help inn text.
    str = HIRION::SETTINGS::MENU_LIST[@command_window.current_symbol]
    name = str[0] == "" ? @command_window.current_symbol.id2name.capitalize : str[0]
    return "#{name} - #{str[1]}"
  end
  
  def create_menu_character_window
    # // Method to create character window.
    width = Graphics.width == 640 ? @status_window.width : @status_window.width + 66
    x = @status_window.x - (Graphics.width == 640 ? 0 : 66 * 0.75)
    @character_window = Window_Menu_Character_Options.new(0, 0, width)
    @character_window.x = x
    @character_window.y = @status_window.height + @status_window.y
    @character_window.z = 200
    @character_window.back_opacity = 255
    @character_window.openness = 0
    @character_window.open
    @character_window.set_handler(:ok,       method(:on_character_ok))
    @character_window.set_handler(:cancel,   method(:on_character_cancel))   
  end
  
  def update
    # // Method for updating the scene.
    super
    # // Remeber last symbol and renew it if changed.
    if @last_symbol != @command_window.current_symbol
      # // Update help window.
      @help_window.set_text(create_menu_help_text)
      @last_symbol = @command_window.current_symbol
    end
    # // Create and animate the particles:
    unless HIRION::SETTINGS::MENU_PARTICLES_DELAY.nil?
      @particles_timer += 1
      if @particles_timer >= HIRION::SETTINGS::MENU_PARTICLES_DELAY
        create_menu_particles
        @particles_timer = 0
      end
    else
      create_menu_particles
    end
    @particles.each { |i|
      i.update
      unless i.done
        i.x += @particles_x
        i.y -= @particles_y
        i.ox += @particles_ox
        i.oy += @particles_oy
      else
        @particles.delete(i)
      end    
    }   
    if @status_window.active
      @status_window.arrows_visible = $game_party.all_members.size >= 5
    else
      @status_window.arrows_visible = false
    end
  end
  
  def call_scene(window)
    # // Method to call scene.
    scene = "Scene_#{window.current_symbol.to_s.capitalize}".to_class
    SceneManager.call(scene)
  end
  
  def on_character_ok
    # // Method when selecting ok on character window.
    call_scene(@character_window)
  end
  
  def on_character_cancel
    # // Method when selecting cancel on character window.
    @character_window.close
    command_personal
  end
  
  def on_personal_ok
    # // Method override on personal ok.
    return command_character if @command_window.current_symbol == :character
    call_scene(@command_window)
  end
  
  def command_character
    # // Method to call character window.
    create_menu_character_window
  end
  
  def command_custom
    # // Method to call a custom command. (Don't remove)
    if @command_window.current_ext.is_a?(Integer)
      $game_temp.reserve_common_event(@command_window.current_ext)
      return SceneManager.call(Scene_Map)
    end
    SceneManager.call(@command_window.current_ext)
  end

  def terminate
    # // Method to terminate the scene.
    SceneManager.snapshot_for_background
    super
    @character_window.dispose unless @character_window.nil?
    @character_window = nil
    @particles.each { |i|  i.dispose unless i.nil? ; i = nil }
    @particles.clear
    @particles = nil
  end
  
end # END OF FILE

#=*==========================================================================*=#
# ** END OF FILE
#=*==========================================================================*=#