#==============================================================================
#   Hirion Engine - Equip
#   Author: Nicke
#   Created: 07/11/2013
#   Edited: 11/02/2014
#   Version: 1.0
#==============================================================================
# Instructions
# -----------------------------------------------------------------------------
# To install this script, open up your script editor and copy/paste this script
# to an open slot below ? Materials but above ? Main. Remember to save.
#==============================================================================
# Required scripts (Added above this script): 
# Hirion Engine - Core
# Hirion Engine - Settings
#==============================================================================
#
# This script changes the visual of the Equip Scene. Optional to use.
#
# *** Only for RPG Maker VX Ace. ***
#==============================================================================
($imported ||= {})["HIRION-ENGINE-EQUIP"] = true
# // Check if required scripts are imported properly.
ERROR.imported?("HIRION-ENGINE-CORE", "Hirion Engine - Equip")
# *** Don't edit below unless you know what you are doing. ***
#==============================================================================#
# ** Window_Equip_Help
#==============================================================================#
class Window_Equip_Help < Window_Help
  
  def initialize(line_number = 2)
    # // Method to initialize the window.
    super(line_number)
    @actor = nil
    refresh
  end
    
  def actor=(actor)
    # // Method to set actor.
    return if @actor == actor
    @actor = actor
    refresh
  end
  
  def equip_window=(equip_window)
    # // Method to set equip window.
    @equip_window = equip_window
    refresh
  end
  
  def refresh
    # // Method to refresh the window.
    contents.clear
    font_help = HIRION::SETTINGS::FONT_EQUIP_HELP
    font_stats = HIRION::SETTINGS::FONT_EQUIP_STATS
    font_param = HIRION::SETTINGS::FONT_EQUIP_PARAM
    if @text.is_a?(String)
      # // Draw equip icon.
      unless @equip_window.nil?
        c_icon = HIRION::SETTINGS::EQUIP_LIST[@equip_window.current_symbol][2]
        draw_icon(c_icon, 0, 0)
      end
      # // Draw help text.
      draw_str(@text, 26, 4, contents_width, 0, font_help[0], font_help[1], font_help[2], font_help[3], font_help[4], font_help[5], font_help[6])     
    else
      # // Draw item details if valid item.
      return if @text.nil?
      # // Draw item icon.
      draw_icon(@text.icon_index, 0, 0)
      # // Draw item value with gold icon.
      draw_icon(HIRION::SETTINGS::ITEM_GOLD_ICON, 0, line_height * 1) unless HIRION::SETTINGS::ITEM_GOLD_ICON.nil?
      value = "Value: #{@text.price}#{Vocab::currency_unit}."
      draw_str(value, 26, line_height * 1, contents_width, 0, font_help[0], font_help[1], font_help[2], font_help[3], font_help[4], font_help[5], font_help[6])
      # // Draw lines.
      draw_shadow_line(0, line_height * 0.65, Color.new(255,255,255), Color.new(0,0,0,128), contents_width, 2)
      # // Draw weapon type if weapon.
      if @text.is_a?(RPG::Weapon)
        type = $data_system.weapon_types[@text.wtype_id]
      end
      # // Draw armor and equip types if armor.
      if @text.is_a?(RPG::Armor)
        atype = $data_system.armor_types[@text.atype_id]
        etype = $data_system.terms.etypes[@text.etype_id]
        type = "#{atype} [#{etype}]"
      end
      if @text.is_a?(RPG::Weapon) || @text.is_a?(RPG::Armor)
        # // Draw stats text.
        draw_str("Stats:", 0, line_height * 2, contents_width, 0, font_stats[0], font_stats[1], font_stats[2], font_stats[3], font_stats[4], font_stats[5], font_stats[6])
        # // Draw param.
        8.times {|i| draw_rect((28 * i) + 48, line_height * 2, 24, 24, Color.new(255,255,255,96), Color.new(0,0,0,128))}
        param_icons = HIRION::SETTINGS::EQUIP_PARAM_ICONS
        param_icons.each_with_index {|v, i|
          alpha = @text.params[i] == 0 ? 75 : 192
          draw_icon_ex(v, 48 + (28 * i), line_height * 2, alpha) 
        }
        @text.params.each_with_index {|v, i|
          if v > 0
            font_param_color = Color.new(80,255,80) ; param_value = "#{v}" 
          end
          if v == 0
            font_param_color = font_param[2] ; param_value = "#{v}" 
          end
          if v < 0
            font_param_color = Color.new(255,80,80) ; param_value = "#{v}".slice_char("-") 
          end
          draw_str(param_value, 48 + (28 * i), line_height * 1.95, 24, 1, font_param[0], font_param[1], font_param_color, font_param[3], font_param[4], font_param[5], font_param[6])
        }
        # // Draw xparam.
        10.times {|i| draw_rect((28 * i) + 272, line_height * 2, 24, 24, Color.new(255,255,255,96), Color.new(0,0,0,128))}
        xparam_icons = HIRION::SETTINGS::EQUIP_XPARAM_ICONS
        xparam_icons.each_with_index {|v, i|
          if !@text.features[i].nil?
            if @text.features[i].code == 22
              alpha = @text.features[i].value == 0 ? 75 : 192
            else
              alpha = 75
            end
          else
            alpha = 75
          end
          draw_icon_ex(v, 272 + (28 * i), line_height * 2, alpha) 
        }
        10.times {|i|
          if @text.features[i].code == 22
            val = "#{@text.features[i].value.percents.to_i}%".slice_char("-").slice_char(" ") 
            font_xparam_color = Color.new(80,255,80) if @text.features[i].value > 0
            font_xparam_color = font_param[2]        if @text.features[i].value == 0
            font_xparam_color = Color.new(255,80,80) if @text.features[i].value < 0
          end unless @text.features[i].nil?
          font_xparam_color = font_param[2] unless font_xparam_color.is_a?(Color)
          val = val.nil? ? "0%" : val
          draw_str(val, 272 + (28 * i), line_height * 1.95, 24, 1, font_param[0], font_param[1], font_xparam_color, font_param[3], font_param[4], font_param[5], font_param[6])
        }
      end
      # // Draw item name with description.
      if @actor
        name = @actor.equips.include?(@text) ? "[EQ] #{@text.name}" : @text.name
        details = "#{name} (#{type}): #{@text.description}"
        draw_str(details, 26, 4, contents_width, 0, font_help[0], font_help[1], font_help[2], font_help[3], font_help[4], font_help[5], font_help[6])
      end
    end
    # // Draw optimize/remove help text.
    draw_str("CTRL: Optimize equipment. - ALT: Remove all equipment.", 0, line_height * 4, contents_width, 0, font_help[0], font_help[1], font_help[2], font_help[3], font_help[4], font_help[5], font_help[6])
  end

end
#==============================================================================#
# ** Window_EquipStatus
#==============================================================================#
class Window_EquipStatus < Window_Base
  
  def window_width
    # // Method to determine window width.
    return 220
  end
  
  def draw_item(x, y, param_id)
    # // Method to draw item.
    font_param_name = HIRION::SETTINGS::FONT_EQUIP_PARAM_NAME
    font_param_details = HIRION::SETTINGS::FONT_EQUIP_PARAM_DETAILS
    # // Draw rect for item.
    draw_rect(x, y, contents_width, 24, Color.new(75,75,75), Color.new(0,0,0,150))    
    # // Draw param name.
    draw_str(Vocab::param(param_id), x + 6, y, contents_width, 0, font_param_name[0], font_param_name[1], font_param_name[2], font_param_name[3], font_param_name[4], font_param_name[5], font_param_name[6])
    if @temp_actor and @actor
      # // Draw current and new param.
      current_param = "#{sprintf("%03d", @actor.param(param_id))}"
      new_value = "#{sprintf("%03d", @temp_actor.param(param_id))}"
      color = param_change_color(new_value.to_i - @actor.param(param_id))
      draw_str(current_param, x - 48, y, contents_width, 2, font_param_details[0], font_param_details[1], color, font_param_details[3], font_param_details[4], font_param_details[5], font_param_details[6]) 
      draw_str("�", x - 34, y, contents_width, 2, font_param_details[0], font_param_details[1], color, font_param_details[3], font_param_details[4], font_param_details[5], font_param_details[6]) 
      draw_str(new_value, x - 8, y, contents_width, 2, font_param_details[0], font_param_details[1], color, font_param_details[3], font_param_details[4], font_param_details[5], font_param_details[6])
    end
  end
  
  def refresh
    # // Method to refresh the window.
    contents.clear
    6.times {|i| draw_item(0, line_height * (1 + i), 2 + i) }
  end
  
end
#==============================================================================#
# ** Window_EquipSlot
#==============================================================================#
class Window_EquipSlot < Window_Selectable
  
  def draw_item(index)
    # // Method to draw item.
    return unless @actor
    font_slot = HIRION::SETTINGS::FONT_EQUIP_SLOT_NAME
    font_item = HIRION::SETTINGS::FONT_EQUIP_SLOT_ITEM
    rect = item_rect(index)
    # // Draw rect for item.
    draw_rect(rect.x, rect.y, rect.width, 24, Color.new(75,75,75), Color.new(0,0,0,150))   
    # // Draw text.
    draw_str("#{slot_name(index)}:", rect.x + 6, rect.y + 2, rect.width, 0, font_slot[0], font_slot[1], font_slot[2], font_slot[3], font_slot[4], font_slot[5], font_slot[6])
    name = @actor.equips[index].nil? ? "-NO ITEM-" : @actor.equips[index].name
    draw_str(name, rect.x - 6, rect.y + 4, rect.width, 2, font_item[0], font_item[1], font_item[2], font_item[3], font_item[4], font_item[5], font_item[6])
  end
  
  alias hirion_equip_scene_equipslot_upd_help update_help
  def update_help(*args, &block)
    # // Method to update help.
    hirion_equip_scene_equipslot_upd_help(*args, &block)
    return if item.nil?
    @help_window.set_text(item)
  end
  
end
#==============================================================================#
# ** Window_EquipItem
#==============================================================================#
class Window_EquipItem < Window_ItemList
  
  def col_max
    # // Method to determine col max.
    return 2
  end
  
  def draw_item(index)
    # // Method to draw item.    
    item = @data[index]
    item_font_name = HIRION::SETTINGS::ITEM_NAME
    if item
      # // Draw rect for item.
      rect = item_rect(index)
      draw_rect(rect.x, rect.y, rect.width, item_height, Color.new(255,255,255,128), Color.new(0,0,0,128))
      # // Draw icon.
      draw_icon(item.icon_index, rect.x + 4, rect.y, enable?(item))
      # // Draw name.
      name = @actor.equips.include?(item) ? "#{item.name} (EQ)" : item.name
      draw_str(name, rect.x + 30, rect.y + 4, rect.width, 0, item_font_name[0], item_font_name[1], item_font_name[2], item_font_name[3], item_font_name[4], item_font_name[5], item_font_name[6])
      # // Draw item amount.
      item_font_amount = HIRION::SETTINGS::ITEM_AMOUNT
      amt = $game_party.item_number(item) > 9 ? "x%2d" : "x%02d"
      draw_str(sprintf(amt, $game_party.item_number(item)), rect.x + 6, rect.y + 6, rect.width, 0, item_font_amount[0], item_font_amount[1], item_font_amount[2], item_font_amount[3], item_font_amount[4], item_font_amount[5], item_font_amount[6])
    else
      rect = item_rect(index)
      draw_rect(rect.x, rect.y, rect.width, item_height, Color.new(255,255,255,128), Color.new(0,0,0,128)) 
      draw_str("-NO ITEM-", rect.x + 6, rect.y + 4, rect.width, 0, item_font_name[0], item_font_name[1], item_font_name[2], item_font_name[3], item_font_name[4], item_font_name[5], item_font_name[6])
    end
  end
  
  alias hirion_equip_scene_equipitem_upd_help update_help
  def update_help(*args, &block)
    # // Method to update help.
    hirion_equip_scene_equipitem_upd_help(*args, &block)
    return if item.nil?
    @help_window.set_text(item)
  end
  
end
#==============================================================================#
# ** Window_EquipActor
#==============================================================================#
class Window_EquipActor < Window_Base
  
  def initialize(x, y, width, height)
    # // Method to initialize the window.
    super(x, y, width, height)
    @actor = nil
    refresh
  end
  
  def actor=(actor)
    # // Method to set actor.
    return if @actor == actor
    @actor = actor
    refresh
  end
  
  def refresh
    # // Method to refresh the window.
    contents.clear
    font_actor_name = HIRION::SETTINGS::FONT_EQUIP_ACTOR_NAME
    font_actor_stats = HIRION::SETTINGS::FONT_EQUIP_ACTOR_STATS
    return if @actor.nil?
    # // Draw actor name.
    draw_str(@actor.name, 0, 0, contents_width, 0, font_actor_name[0], font_actor_name[1], font_actor_name[2], font_actor_name[3], font_actor_name[4], font_actor_name[5], font_actor_name[6])
    # // Draw actor stats.
    draw_actor_stats(@actor, :hp, 0, 20, 0, 6, HIRION::SETTINGS::EQUIP_BAR_HP[0], HIRION::SETTINGS::EQUIP_BAR_HP[1], contents_width / 2, 20, Vocab.hp, 6, 6, font_actor_stats)
    draw_actor_stats(@actor, :mp, contents_width / 2, 20, 0, 6, HIRION::SETTINGS::EQUIP_BAR_MP[0], HIRION::SETTINGS::EQUIP_BAR_MP[1], contents_width / 2, 20, Vocab.mp, 6, 6, font_actor_stats)
  end
  
end
#==============================================================================#
# ** Scene_Equip
#==============================================================================#
class Scene_Equip < Scene_MenuBase

  def start
    # // Method to start the scene.
    super
    create_background
    create_help_window
    create_status_window
    create_slot_window
    create_item_window
    create_actor_window
  end

   def create_help_window
    # // Method to create the help window.
    @help_window = Window_Equip_Help.new(5)
    @help_window.viewport = @viewport
    @help_window.actor = @actor
    @help_window.center(:x)
    @help_window.y = (Graphics.height - @help_window.height) + 8
    @help_window.opacity = 0
  end

   def create_status_window
   	# // Method to create the status window.
    @status_window = Window_EquipStatus.new(0, 0)
    @status_window.center(:y)
    @status_window.y += 24
    @status_window.viewport = @viewport
    @status_window.actor = @actor
    @status_window.opacity = 0
  end

   def create_slot_window
   	# // Method to create the slot window.
    @slot_window = Window_EquipSlot.new(0, 48, 220)
    @slot_window.viewport = @viewport
    @slot_window.help_window = @help_window
    @slot_window.status_window = @status_window
    @slot_window.actor = @actor
    @slot_window.set_handler(:ok,       method(:on_slot_ok))
    @slot_window.set_handler(:pagedown, method(:next_actor))
    @slot_window.set_handler(:pageup,   method(:prev_actor))
    @slot_window.set_handler(:cancel,   method(:return_scene))
    @slot_window.opacity = 0
    @slot_window.index = 0
    @slot_window.activate
  end

   def create_item_window
   	# // Method to create the item window.
    w = Graphics.width - @slot_window.width
    h = Graphics.height
    @item_window = Window_EquipItem.new(0, 0, w, h)
    @item_window.x = @slot_window.x + @slot_window.width
    @item_window.center(:y)
    @item_window.y += 24 * 5
    @item_window.viewport = @viewport
    @item_window.help_window = @help_window
    @item_window.status_window = @status_window
    @item_window.actor = @actor
    @item_window.set_handler(:ok,     method(:on_item_ok))
    @item_window.set_handler(:cancel, method(:on_item_cancel))
    @slot_window.item_window = @item_window
    @item_window.opacity = 0
  end
  
  def create_actor_window
    # // Method to create the actor window.
    w = Graphics.width - @slot_window.width
    h = 72
    @actor_window = Window_EquipActor.new(0, 0, w, h)
    @actor_window.x = @slot_window.x + @slot_window.width
    @actor_window.y = @item_window.y - @actor_window.height
    @actor_window.viewport = @viewport
    @actor_window.opacity = 0
    @actor_window.actor = @actor
  end
  
  def update
    # // Method to update the scene.
    super
    command_optimize if Input.trigger?(:CTRL)
    command_clear if Input.trigger?(:ALT)
  end
  
  def activate_window
    # // Method to reactivate the window.
    if @slot_window.active
      @slot_window.activate
      @item_window.deactivate
    else
      @item_window.activate
      @slot_window.deactivate
    end
  end

  def command_optimize
    # // Method command optimize equipment.
    Sound.play_equip
    @actor.optimize_equipments
    @status_window.refresh
    @slot_window.refresh
    activate_window
  end
  
  def command_clear
    # // Method command clear equipment.
    Sound.play_equip
    @actor.clear_equipments
    @status_window.refresh
    @slot_window.refresh
    activate_window
  end
  
  def on_actor_change
    # // Method when actor changes.
    @status_window.actor = @actor
    @slot_window.actor = @actor
    @item_window.actor = @actor
    @actor_window.actor = @actor
    @slot_window.activate
  end
  
end # END OF FILE

#=*==========================================================================*=#
# ** END OF FILE
#=*==========================================================================*=#