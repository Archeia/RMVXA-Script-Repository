#==============================================================================
#   Hirion Engine - Settings
#   Author: Nicke
#   Created: 22/10/2013
#   Edited: 09/02/2014
#   Version: 1.0d
#==============================================================================
# Instructions
# -----------------------------------------------------------------------------
# To install this script, open up your script editor and copy/paste this script
# to an open slot below ? Materials but above ? Main. Remember to save.
#
# Settings for Hirion Engine.
#
# *** Only for RPG Maker VX Ace. ***
#==============================================================================
($imported ||= {})["HIRION-ENGINE-SETTINGS"] = true

module HIRION
  module SETTINGS
  ############################################################################  
  #--------------------------------------------------------------------------#
  # * Graphic Settings
  #--------------------------------------------------------------------------#
  
    # RESOLUTION = [width, height]
    RESOLUTION = [640, 480]
    
  #--------------------------------------------------------------------------#
  # * End of Graphic Settings
  #--------------------------------------------------------------------------# 
  ############################################################################
  #--------------------------------------------------------------------------#
  # * Menu Scene Settings
  #--------------------------------------------------------------------------#
  
    # FONT = [name, size, color, out_color, bold, shadow, italic]
    MENU_FONT = ["Mongolian Baiti", 24, Color.new(255,255,255), Color.new(0,0,0,64), true, true, false]
    MENU_FONT_DETAILS = ["Mongolian Baiti", 16, Color.new(255,255,255), Color.new(0,0,0,64), true, true, false]
    MENU_FONT_CHAR_OPTIONS = ["Mongolian Baiti", 14, Color.new(255,255,255), Color.new(0,0,0,64), true, false, false]
    MENU_HELP_FONT = ["Mongolian Baiti", 22, Color.new(255,255,255), Color.new(0,0,0,128), false, true, false]
    MENU_ACTOR_NAME = ["Mongolian Baiti", 14, Color.new(255,255,255), Color.new(0,0,0,255), true, true, false]
    MENU_ACTOR_STATS = ["Coolvetica", 12, Color.new(255,255,255), Color.new(0,0,0,255), false, false, false]
    MENU_ACTOR_LVL = ["Coolvetica", 18, Color.new(0,0,0,255), Color.new(255,255,255,192), true, false, false]
    
    # MENU_LIST: 
    # name, icon_index and custom are optional.
    # If name is empty it will use the corresponding symbol as name instead.
    # To make a command a common event you need to set custom to the common event
    # id you want to run as seen below.
    # symbol => [name, description, icon_index, enabled, personal, custom]
    MENU_LIST = {
      :character => ["Character", "Manage your character.", 12, true, true],
      :item      => ["Inventory", "A collection of all of your items.", 270, true, false],
      :save      => ["", "Record your progress.", 338, true, false],
      :load      => ["", "Continue your saved progress.", 229, true, false, Scene_Load],
      :formation => ["", "Change your formation in the party.", 121, true, false],
      :title     => ["", "Return to title screen.", 117, true, false, Scene_Title],
      :game_end  => ["Quit", "Exit the program.", 1, true, false]
    } # Don't remove this line!
    
    # MENU_SAVE = true/false
    # Override enabled option for save (so you can change it ingame).
    MENU_SAVE = true
    
    # If MENU_CUSTOM is true you will have to add the commands yourself
    # ingame, which can be useful for certain quest related stuff or if you
    # want to enable/disable menu commands.
    # To add/remove a command ingame follow these instructions:
    # 
    # In a event script call do like this:
    # menu_scene(key, type)
    # menu_scene(:item,:add) # To add item to menu list.
    # menu_scene(:item,:del) # To remove item from menu list.
    #
    # In a conditional branch you can check if a menu command is 
    # enabled/disabled:
    # menu_active?(key)
    # menu_active?(:item) # Check if item is enabled.
    # !menu_active?(:item) # Check if item is disabled.
    #
    # To set a id to be enabled do like this:
    # menu_active(:skill, true) # Set menu skill to be enabled.
    #
    # To add/remove all available menu commands use one of the 
    # following methods in a script call:
    # menu_add_all
    # menu_del_all
    #
    # MENU_CUSTOM = true/false
    MENU_CUSTOM = false
    
    # MENU_MUSIC:
    # Set the music to be played at the menu scene.
    # This is optional.
    # Set to nil to disable.
    # MUSIC = [name, volume, pitch]
    MENU_MUSIC_BGM = ["Theme3", 70, 100]
    # MUSIC_BGS = [name, volume, pitch]
    MENU_MUSIC_BGS = nil
    
    # MENU_DETAIL_ICONS = [map, gold, playtime] 
    MENU_DETAIL_ICONS = [232, 262, 280]
    
    # MENU_BAR = rgba(255,255,255,255)
    # Set the color of the gauges.
    MENU_BAR_HP = [Color.new(65,7,5), Color.new(179,27,27)]
    MENU_BAR_MP = [Color.new(0,5,60), Color.new(0,51,152)]
    MENU_BAR_EXP = [Color.new(125,52,0), Color.new(255,102,0)]
    MENU_BAR_TP = [Color.new(0,125,0), Color.new(122,255,0)]
    
    # BACKGROUND:
    # name => [x, y, z, opacity]
    MENU_BACKGROUND = {
      "MenuBack" => [0, 0, 3, 255]
    } # Don't remove this line!
    
    # PARTICLES:
    # Advanced method for the particles, currently set to random.
    def self.random_particle_movement(type)
      case type
      when :width
        return rand(Graphics.width)
      when :height
        return rand(Graphics.height)
      end
    end
    
    # MENU_PARTICLES
    # The particles needs to be in Graphics/Picture folder.
    # x and y properties can be set to :random to have a random
    # movement effect.
    # name => [x, y, z, opacity, angle, blend_type] 
    MENU_PARTICLES = {
      "star_white"  => [
        :random, Graphics.height + 72, 40, 1 + rand(3), 2, 1
      ],
      "smash"  => [
        :random, Graphics.height + 72, 50, 1 + rand(3), 4, 1
      ],
      "particle_white"  => [
        :random, Graphics.height + 72, 60, 1 + rand(3), 6, 1
      ]
    } # Don't remove this line!

    # MENU_PARTICLES_DELAY = integer
    MENU_PARTICLES_DELAY = 20
    
    # Transition, nil to use default.
    # TRANSITION [speed, transition, opacity]
    MENU_TRANSITION = nil
    
    # Set how many visible actors you want to have for the character window.
    # This option depends on which resolution you have.
    # MENU_ACTORS = [640x480 resolution, 544x416 resolution]
    MENU_ACTORS = [4, 3]
    
  #--------------------------------------------------------------------------#
  # * End of Menu Scene Settings
  #--------------------------------------------------------------------------#
  ############################################################################
  #--------------------------------------------------------------------------#
  # * Status Scene Settings
  #--------------------------------------------------------------------------#
  
    # FONT = [name, size, color, out_color, bold, shadow, italic]
    STATUS_FONT = ["Mongolian Baiti", 20, Color.new(255,255,255), Color.new(0,0,0,64), true, true, false]
    STATUS_STATS = ["Coolvetica", 14, Color.new(255,255,255), Color.new(0,0,0,255), true, false, false]
    STATUS_STATES = ["Mongolian Baiti", 20, Color.new(255,255,255), Color.new(0,0,0,64), true, true, false]
    STATUS_EQUIP = ["Coolvetica", 14, Color.new(255,255,255), Color.new(0,0,0,255), true, false, false]
    STATUS_DESC = ["Mongolian Baiti", 18, Color.new(0,0,0,255), Color.new(255,255,255,192), true, false, false]
    STATUS_FAME = ["Mongolian Baiti", 16, Color.new(255,255,255), Color.new(0,0,0,64), false, true, false]
    
    # BAR_COLOR = rgba(red,blue,green,alpha)
    # Set the color of the bars.
    STATUS_BAR_PARAM = [Color.new(37,179,213), Color.new(137,192,213)]
    STATUS_BAR_HP = [Color.new(65,7,5), Color.new(179,27,27)]
    STATUS_BAR_MP = [Color.new(0,5,60), Color.new(0,51,152)]
    STATUS_BAR_EXP = [Color.new(125,52,0), Color.new(255,102,0)]
    STATUS_BAR_TP = [Color.new(0,125,0), Color.new(122,255,0)]
    
    # LINE_COLOR = rgba(255,255,255,255)
    # Set the color of the horizontal line.
    LINE_COLOR = [Color.new(255,255,255,200), Color.new(0,0,0,128)]
    
  #--------------------------------------------------------------------------#
  # * End of Status Settings
  #--------------------------------------------------------------------------#
  ############################################################################
  #--------------------------------------------------------------------------#
  # * Item Scene Settings
  #--------------------------------------------------------------------------#
  
    # FONT = [name, size, color, out_color, bold, shadow, italic]
    ITEM_HELP = ["Coolvetica", 15, Color.new(255,255,255), Color.new(0,0,0,64), true, true, false]
    ITEM_CAT = ["Coolvetica", 12, Color.new(240,220,180), Color.new(0,0,0,64), true, true, false]
    ITEM_NAME = ["Coolvetica", 14, Color.new(255,255,255), Color.new(0,0,0,255), true, false, false]
    ITEM_AMOUNT = ["Coolvetica", 12, Color.new(255,255,255), Color.new(0,0,0), true, true, false]
    ITEM_STATS = ["Coolvetica", 20, Color.new(255,255,255), Color.new(0,0,0,64), true, true, false]
    ITEM_PARAM = ["Coolvetica", 11, Color.new(150,150,150,255), Color.new(0,0,0,255), true, true, false]
    ITEM_NO_ITEMS = ["Coolvetica", 28, Color.new(255,125,125), Color.new(0,0,0,255), true, true, false]
    
    # Item gold icon. Set to nil to disable.
    # ITEM_GOLD_ICON = icon_id
    ITEM_GOLD_ICON = 361
    
    # ITEM_PARAM_ICONS = [hp, mp, atk, def, mat, mdf, agi, luk]
    ITEM_PARAM_ICONS = [528, 529, 530, 531, 532, 533, 534, 535]
    
    # ITEM_CATEGORIES:
    # category_symbol => [name, help text, icon]
    ITEM_CATEGORIES = {
      :item      => ["Misc", "Listing all miscellaneous items.", 270],
      :weapon    => ["Weapons", "Listing all weapons.", 115],
      :armor     => ["Armors", "Listing all armors.", 12],
      :shield    => ["Shields", "Listing all shields.", 13],      
      :helmet    => ["Helmets", "Listing all helmets.", 164],      
      :body      => ["Gears", "Listing all body gear.", 438],      
      :accessory => ["Accessories", "Listing all accessories.", 512],
      :key_item  => ["Quests", "Listing all quest related items.", 229],
      :all       => ["All", "Listing all available items.", 127]
    } # Don't remove this line!
    
    def self.item_category(category, item)
      # // Method to set custom categories.
      case category
      when :item      ; item.is_a?(RPG::Item) && !item.key_item?
      when :weapon    ; item.is_a?(RPG::Weapon)
      when :armor     ; item.is_a?(RPG::Armor)
      when :shield    ; item.is_a?(RPG::Armor) && item.etype_id == 1
      when :helmet    ; item.is_a?(RPG::Armor) && item.etype_id == 2
      when :body      ; item.is_a?(RPG::Armor) && item.etype_id == 3
      when :accessory ; item.is_a?(RPG::Armor) && item.etype_id == 4
      when :key_item  ; item.is_a?(RPG::Item) && item.key_item?
      when :all       ; item.is_a?(RPG::Item) || item.is_a?(RPG::Weapon) || item.is_a?(RPG::Armor)
      else            ; return false
      end
    end
    
    def self.item_color(category)
      # // Method to set custom category color for items.
      # // Use the notetag for items, weapons or armors to setup a category color.
      # // Formula for notetag: <category: category>
      # // Example: <category: health> will use the health color.
      case category
      when :health  ; Color.new(200,100,100,128)
      when :mana    ; Color.new(100,100,200,128)
      when :cure    ; Color.new(100,200,100,128)
      when :elixir  ; Color.new(200,200,100,128)
      when :casual  ; Color.new(200,200,200,64)
      when :default ; Color.new(0,0,0,128)
      end
    end
    
  #--------------------------------------------------------------------------#
  # * End of Item Scene Settings
  #--------------------------------------------------------------------------#
  ############################################################################
  #--------------------------------------------------------------------------#
  # * Equip Scene Settings
  #--------------------------------------------------------------------------#

    # FONT = [name, size, color, out_color, bold, shadow, italic]
    FONT_EQUIP_HELP = ["Coolvetica", 15, Color.new(255,255,255), Color.new(0,0,0,64), true, true, false]
    FONT_EQUIP_STATS = ["Coolvetica", 20, Color.new(255,255,255), Color.new(0,0,0,64), true, true, false]
    FONT_EQUIP_PARAM = ["Coolvetica", 11, Color.new(150,150,150,255), Color.new(0,0,0,255), true, true, false]
    FONT_EQUIP_PARAM_NAME = ["Coolvetica", 16, Color.new(240,220,180), Color.new(0,0,0,255), true, true, false]
    FONT_EQUIP_PARAM_DETAILS = ["Coolvetica", 13, Color.new(255,255,255), Color.new(0,0,0,64), true, true, false]
    FONT_EQUIP_SLOT_NAME = ["Coolvetica", 16, Color.new(240,220,180), Color.new(0,0,0,255), true, true, false]
    FONT_EQUIP_SLOT_ITEM = ["Coolvetica", 13, Color.new(255,255,255), Color.new(0,0,0,64), true, true, false]
    FONT_EQUIP_ACTOR_NAME = ["Coolvetica", 24, Color.new(255,255,255), Color.new(0,0,0,64), true, true, false]
    FONT_EQUIP_ACTOR_STATS = ["Coolvetica", 14, Color.new(255,255,255), Color.new(0,0,0,255), false, false, false]
    
    # BAR_COLOR = rgba(red,blue,green,alpha)
    # Set the color of the bars.
    EQUIP_BAR_HP = [Color.new(65,7,5), Color.new(179,27,27)]
    EQUIP_BAR_MP = [Color.new(0,5,60), Color.new(0,51,152)]
    
    # EQUIP_PARAM_ICONS = [hp, mp, atk, def, mat, mdf, agi, luk]
    EQUIP_PARAM_ICONS = [528, 529, 530, 531, 532, 533, 534, 535]
    
    # EQUIP_PARAM_ICONS = [hit, eva, cri, cev, mev, mrf, cnt, hrg, mrg, trg]
    EQUIP_XPARAM_ICONS = [536, 537, 538, 539, 540, 541, 542, 543, 544, 545]
    
  #--------------------------------------------------------------------------#
  # * End of Equip Scene Settings
  #--------------------------------------------------------------------------#
  end
end # END OF FILE

#=*==========================================================================*=#
# ** END OF FILE
#=*==========================================================================*=#