#==============================================================================
#   Hirion Engine - Status
#   Author: Nicke
#   Created: 24/10/2013
#   Edited: 05/11/2013
#   Version: 1.0a
#==============================================================================
# Instructions
# -----------------------------------------------------------------------------
# To install this script, open up your script editor and copy/paste this script
# to an open slot below ? Materials but above ? Main. Remember to save.
#==============================================================================
# Required scripts (Added above this script): 
# Hirion Engine - Core
# Hirion Engine - Settings
#==============================================================================
#
# This script changes the visual of the status scene. Optional to use.
#
# *** Only for RPG Maker VX Ace. ***
#==============================================================================
($imported ||= {})["HIRION-ENGINE-STATUS"] = true
# // Check if required scripts are imported properly.
ERROR.imported?("HIRION-ENGINE-CORE", "Hirion Engine - Status")
# *** Don't edit below unless you know what you are doing. ***
#==============================================================================#
# ** Window_Status
#==============================================================================#
class Window_Status < Window_Selectable
  
  def initialize(actor)
    # // Method to initialize the window.
    super(0, 0, window_width, window_height)
    self.openness = 0
    @actor = actor
    refresh
    activate
  end
  
  def update_open
    # // Method override to update window opening.
    self.openness += 10
    self.opacity = self.openness unless self.opacity == 0
    self.back_opacity = self.openness unless self.opacity == 0
    @opening = false if open?
  end
  
  def window_width
    # // Method to determine window width.
    w = Graphics.width
    return w == 640 ? w * 0.8 : w
  end
  
  def window_height
    # // Method to determine window height.
    h = Graphics.height
    return h == 480 ? h * 0.85 : h
  end
  
  def refresh
    # // Method to refresh.
    contents.clear
    # // Draw actor details.
    font_details = HIRION::SETTINGS::STATUS_FONT
    # // Draw level title if XS - Level Title installed.
    title = $imported["XAIL-LVL-TITLE"] == true ? "#{draw_title_level(@actor)}" : "#{@actor.level}"
    draw_str("#{@actor.name} \"#{@actor.nickname}\" (#{Vocab::level}: #{title})", 0, line_height * 0, contents_width, 0, font_details[0], font_details[1], font_details[2], font_details[3], font_details[4], font_details[5], font_details[6])
    draw_str(@actor.class.name, 0, line_height * 0, contents_width, 2, font_details[0], font_details[1], font_details[2], font_details[3], font_details[4], font_details[5], font_details[6])
    # // Draw fame if XS - Fame installed.
    if $imported["XAIL-FAME-SYSTEM"]
      font_fame = HIRION::SETTINGS::STATUS_FAME
      fame = "Fame: #{@actor.current_fame} (#{@actor.fame}/#{@actor.max_fame})"
      draw_str(fame, 0, line_height * 0.95, contents_width, 0, font_fame[0], font_fame[1], font_fame[2], font_fame[3], font_fame[4], font_fame[5], font_fame[6])
    end
    # // Draw line.
    draw_shadow_line(0, line_height * 0.5, Color.new(255,255,255), Color.new(0,0,0,128), contents_width, 1)
    # // Draw actor stats.
    font_stats = HIRION::SETTINGS::STATUS_STATS
    Vocab.create(:exp, "Experience")
    draw_actor_stats(@actor, :hp, 0, line_height * 1.5, 0, 6, HIRION::SETTINGS::STATUS_BAR_HP[0], HIRION::SETTINGS::STATUS_BAR_HP[1], contents_width - 1, 20, Vocab.hp, 6, 6, font_stats)
    draw_actor_stats(@actor, :mp, 0, line_height * 2.5, 0, 6, HIRION::SETTINGS::STATUS_BAR_MP[0], HIRION::SETTINGS::STATUS_BAR_MP[1], contents_width - 1, 20, Vocab.mp, 6, 6, font_stats)
    draw_actor_stats(@actor, :exp, 0, line_height * 3.5, 0, 6, HIRION::SETTINGS::STATUS_BAR_EXP[0], HIRION::SETTINGS::STATUS_BAR_EXP[1], contents_width - 1, 20, Vocab.exp, 6, 6, font_stats)
    draw_actor_stats(@actor, :tp, 0, line_height * 4.5, 0, 6, HIRION::SETTINGS::STATUS_BAR_TP[0], HIRION::SETTINGS::STATUS_BAR_TP[1], contents_width - 1, 20, Vocab.tp, 6, 6, font_stats)
    # // Draw states with a rect.
    font_states = HIRION::SETTINGS::STATUS_STATES
    10.times {|i| draw_rect((x + 124) + 24 * i, line_height * 6, 26, 25, Color.new(255,255,255,96), Color.new(0,0,0,128)) }
    draw_str("Conditions:", 0, line_height * 6, contents_width, 0, font_states[0], font_states[1], font_states[2], font_states[3], font_states[4], font_states[5], font_states[6])
    draw_actor_icons(@actor, x + 125, line_height * 6, 24 * 10)
    # // Draw actor parameters.
    draw_parameters(0, line_height * 7.5)
    # // Draw actor equipment.
    draw_equipments((contents_width / 2) + 2, line_height * 8)
     # // Draw line.
    draw_shadow_line(0, line_height * 13.25, Color.new(255,255,255), Color.new(0,0,0,128), contents_width, 1)
    # // Draw actor description.    
    draw_description(0, line_height * 14)
  end

  def draw_parameters(x, y)
    # // Method to draw actor parameters.
    font = HIRION::SETTINGS::STATUS_STATS
    c = HIRION::SETTINGS::STATUS_BAR_PARAM
    6.times {|i| draw_bar_param(@actor, x, y + line_height * i, contents_width / 2, i + 2, font, c[0], c[1]) }
  end
  
  def draw_status_item_name(item, x, y, enabled = true, width = 242)
    # // Method to draw status item name.
    return unless item
    font = HIRION::SETTINGS::STATUS_EQUIP
    draw_icon(item.icon_index, x, y, enabled)
    draw_str(item.name, x + 28, y + 2, width, 0, font[0], font[1], font[2], font[3], font[4], font[5], font[6])
  end
  
  def draw_equipments(x, y)
    # // Method override to draw equipments.
    @actor.equips.each_with_index do |item, i|
      draw_rect(x, y + line_height * i, 242, 25, Color.new(255,255,255,128), Color.new(0,0,0,64))
      draw_status_item_name(item, x + 4, y + line_height * i)
    end
  end

  def draw_description(x, y)
    # // Method override to draw the description.
    font = HIRION::SETTINGS::STATUS_DESC
    draw_str_ex(@actor.description, x, y, font[0], font[1], font[2], font[3], font[4], font[5], font[6])
  end
  
end 
#==============================================================================
# ** Scene_Status
#==============================================================================
class Scene_Status < Scene_MenuBase

  alias hirion_status_menu_start start
  def start(*args, &block)
    # // Method to start the scene.
    create_background
    hirion_status_menu_start(*args, &block)
    @status_window.open
    @status_window.center
  end
  
end # END OF FILE

#=*==========================================================================*=#
# ** END OF FILE
#=*==========================================================================*=#