#==============================================================================
#   XS - Variable Hud
#   Author: Nicke
#   Created: 02/04/2012
#   Edited: 09/04/2012
#   Version: 1.0a
#==============================================================================
# Instructions
# -----------------------------------------------------------------------------
# To install this script, open up your script editor and copy/paste this script
# to an open slot below ? Materials but above ? Main. Remember to save.
#
# A small hud to display variables on the map.
#
# *** Only for RPG Maker VX Ace. ***
#==============================================================================
($imported ||= {})["XAIL-VAR-WIN-HUD"] = true

module XAIL
  module VAR_HUD
  #--------------------------------------------------------------------------#
  # * Settings
  #--------------------------------------------------------------------------#
      # FONT = [name, size, color, bold, shadow]
      FONT = [["Verdana"], 14, Color.new(255,255,255), true, true]

      # HUD = [width, x, y, z, opacity, skin]
      HUD = [270, 295, -5,  200, 0, nil]

      # VAR_HUD_SWITCH = switch_id
      VAR_HUD_SWITCH = 1

      # VAR_LIST = [variable_id, vocab (nil), icon_index (nil), x, y]
      VAR_LIST = [] # Don't remove!
      VAR_LIST[0] = [1, nil, nil]
      VAR_LIST[1] = [2, nil, 358]
      VAR_LIST[2] = [3, nil, 359]
      VAR_LIST[3] = [4, nil, 366]
      
      # Set the symbol for the amount.
      # Can be set to "" to disable.
      # SYMBOL = string
      SYMBOL = ""

      # The space beetween the variables.
      # SPACING = number
      SPACING = 24

  end
end
# *** Don't edit below unless you know what you are doing. ***
#==============================================================================#
# ** Window_Var_Hud
#------------------------------------------------------------------------------
#  Class for drawing the variable hud.
#==============================================================================#
class Window_Var_Hud < Window_Base

  def initialize
    # // Method to initialize the var hud window.
    super(0, 0, window_width, fitting_height(XAIL::VAR_HUD::VAR_LIST.size))
    refresh
  end

  def window_width
    # // Method to return the width.
    return XAIL::VAR_HUD::HUD[0]
  end

  def draw_var(var, unit, x, y, width)
    # // Method to draw a variable with the content.
    value = "#{$game_variables[var]}#{XAIL::VAR_HUD::SYMBOL}"
    contents.font = Font.new(XAIL::VAR_HUD::FONT[0], XAIL::VAR_HUD::FONT[1])
    contents.font.color = XAIL::VAR_HUD::FONT[2]
    contents.font.bold = XAIL::VAR_HUD::FONT[3]
    contents.font.shadow = XAIL::VAR_HUD::FONT[4]
    draw_text(x, y, width - 60, line_height, value, 2)
    draw_text(x, y, width - 18, line_height, unit, 2) unless unit.nil?
    reset_font_settings
  end

  def refresh
    # // Method to refresh the variable hud.
    contents.clear
    draw_var_hud
  end

  def draw_var_hud
    # // Method to draw the var hud.
    y = 0
    @vars = {}
    for i in XAIL::VAR_HUD::VAR_LIST
      x = i[1].nil? ? 32 : -10
      draw_var(i[0], i[1], x, y, contents.width - 8)
      draw_icon(i[2], 210, y - 2) unless i[2].nil?
      y += XAIL::VAR_HUD::SPACING
      @vars[i[0]] = $game_variables[i[0]]
    end
  end

  def update
    # // Method to update the variable hud if a value has been changed.
    super
    for i in XAIL::VAR_HUD::VAR_LIST
      refresh if($game_variables[i[0]] != @vars[i[0]])
    end
  end

end
#==============================================================================
# ** Scene_Map
#------------------------------------------------------------------------------
#  Show variable hud on the map.
#==============================================================================
class Scene_Map < Scene_Base

  alias xail_var_hud_window_start start
  def start(*args, &block)
    # // Method to start the var hud window on the map.
    xail_var_hud_window_start(*args, &block)
    create_var_hud_window
    @var_hud_window.visible = $game_switches[XAIL::VAR_HUD::VAR_HUD_SWITCH]
  end

  alias xail_var_hud_window_terminate terminate
  def terminate(*args, &block)
    # // Method to terminate the var hud window on the map.
    xail_var_hud_window_terminate(*args, &block)
  end

  def create_var_hud_window
    # // Method to create the variable window.
    @var_hud_window = Window_Var_Hud.new
    @var_hud_window.x = XAIL::VAR_HUD::HUD[1]
    @var_hud_window.y = XAIL::VAR_HUD::HUD[2]
    @var_hud_window.z = XAIL::VAR_HUD::HUD[3]
    @var_hud_window.opacity = XAIL::VAR_HUD::HUD[4]
    @var_hud_window.windowskin = Cache.system(XAIL::VAR_HUD::HUD[5]) unless XAIL::VAR_HUD::HUD[5].nil?
  end

  alias xail_var_hud_window_update update
  def update(*args, &block)
    # // Method to update the var hud window on the map.
    xail_var_hud_window_update(*args, &block)
    @var_hud_window.visible = $game_switches[XAIL::VAR_HUD::VAR_HUD_SWITCH]
  end

end # END OF FILE

#=*==========================================================================*=#
# ** END OF FILE
#=*==========================================================================*=#