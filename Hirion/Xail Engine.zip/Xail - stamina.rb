#==============================================================================
#   XS - Stamina System
#   Author: Nicke
#   Created: 05/10/2013
#   Edited: 07/05/2014
#   Version: 1.0c
#==============================================================================
# Instructions
# -----------------------------------------------------------------------------
# To install this script, open up your script editor and copy/paste this script
# to an open slot below ? Materials but above ? Main. Remember to save.
#==============================================================================
# Requires: XS - Core Script.
# Requires: Numeric Class by IceDragon.
#==============================================================================
#
# This script will add a Stamina System which enables you to control
# the players dashing on the map.
#
# You can control the stamina by the following method:
# $game_player.set_stamina(value, stamina_type, operator = :add)
# 
# Examples:
# $game_player.set_stamina(50, :stamina)        # Increment stamina by 50.
# $game_player.set_stamina(50, :stamina, :lose) # Decrease stamina by 50.
#
# $game_player.set_stamina(100, :max_stamina)        # Increment max stamina by 50.
# $game_player.set_stamina(100, :max_stamina, :lose) # Decrease max stamina by 50.
#
# Items can also increase the stamina values and is done in the notetag for the
# specified item:
# <stamina: integer>
# <max_stamina: integer>
# 
# Examples:
# <stamina: 50>       # Item will instantly increment stamina by 50.
# <max_stamina: 150>  # Item will instantly increment nax stamina by 150.
#
# The stamina values are also binded to variables meaning you can also control
# the stamina by them. (Made for simplicity.)
#
# When the player is standing still they will regain stamina slowly. The recover
# time and how much stamina you will recover can be changed as needed.
# You can also setup a Region ID to enable faster recovery.
#
# Resting at a Inn will also restore stamina instantly.
#
# A HUD is enabled from default in this script that will show the stamina
# values to the player. This feature can be enabled/disabled by a switch ingame.
# The whole system can be also be enabled/disabled by a switch.
#
# In the HUD a gauge is created along with the stamina values. You can easily import
# your own custom pictures to change the gauge appearances.
#
# An animate feature is implemented and enabled by default.
# This will fade out the stamina hud after a short amount of time. (optional)
#
# Note!!! From default you need to enable the default switches to enable the 
# system ingame. Default switch IDs: 10 and 11.
#
# *** Only for RPG Maker VX Ace. ***
#==============================================================================
($imported ||= {})["XAIL-STAMINA-SYSTEM"] = true

module XAIL
  module STAMINA
  #--------------------------------------------------------------------------#
  # * Settings
  #--------------------------------------------------------------------------#
      # FONT = [name, size, color, out_color, bold, italic, shadow]
      FONT = [["Verdana"], 13, Color.new(0,0,0), Color.new(255,255,255,128),
                true, false, false]

      # Stamina hud settings.
      # HUD = [x, y, z]
      HUD = [4, 4, 200]
      
      # Use this to set the HUD at a predefined location.
      # Set to nil to use custom positioning.
      # 0 = Top left corner.
      # 1 = Top right corner.
      # 2 = Bottom left corner.
      # 3 = Bottom right corner.
      # 4 = Centered top.
      # 5 = Centered bottom.
      # HUD_PLACEMENT = integer
      HUD_PLACEMENT = 5
      
      # Switches to enable/disable the hud and script.
      # HUD_SWITCH = [script, hud]
      HUD_SWITCH = [10, 11]
      
      # Setup stamina hud pictures for back and front.
      # HUD_PICS = [back_pic, front_pic]
      HUD_PICS = ["Stamina_Back", "Stamina_Front"]
      
      # Setup default and max stamina value.
      # Use a integer.
      INIT_STAMINA = 255
      MAX_STAMINA = 255
      
      # Stamina recover. How long it should wait before the player regain stamina.
      # 60 frames (1 second).
      # RECOVER_TIME = integer
      RECOVER_TIME = 120
      
      # Set how much stamina you will recover when not dashing.
      # INIT_RECOVER = integer
      INIT_RECOVER = 5
      
      # Recover region.
      # The player will regain stamina much faster in this area.
      # RECOVER_REGION_ID = region_id
      RECOVER_REGION_ID = 20
      
      # Set how much stamina the player will recover in the region.
      # RECOVER_REGION = integer
      RECOVER_REGION_STAMINA = INIT_RECOVER * 2
      
      # Set how fast the recover time should be in the region.
      # RECOVER_REGION_TIME = integer
      RECOVER_REGION_TIME = 60
      
      # Set if you want stamina to be recovered while moving. (nil to disable)
      # This should obviously be less then INIT_RECOVER.
      # RECOVER_WHILE_MOVING = integer
      RECOVER_WHILE_MOVING = INIT_RECOVER / 4
      
      # Set the display name for HUD.
      # DISPLAY_NAME = string
      DISPLAY_NAME = "Stamina"
      
      # Set display value for the stamina hud.
      # Comment out the one you don't want or make a new yourself.
      # Might require some scripting knowledge.
      def self.display_value(stamina)
        "#{stamina.percent_of($game_player.max_stamina).to_i}%" # = Stamina: Stamina%
        #"#{stamina} / #{$game_player.max_stamina}" # = Stamina: Stamina / Max Stamina
      end
      
      # Animate the stamina hud. (Fade effect)
      # ANIMATE = true/false
      ANIMATE = true
      
      # Fade the stamina hud to this value.
      # ANIMATE_FADE = integer
      ANIMATE_FADE = 150
      
      # This will set how many frames it should wait before the animation occurs.
      # ANIMATE_TIME = integer
      ANIMATE_TIME = 400
      
      # Bind current and max stamina values to variables. (optional)
      # These variables can then easily be used to change stamina values
      # instead of using the built in methods.
      # A appropriate method for a non-scripter.
      # VARS = [current_stamina, max_stamina]
      VARS = [10,11]
      
  end
end
# *** Don't edit below unless you know what you are doing. ***
#==============================================================================#
# ** Error Handler
#==============================================================================#
  unless $imported["XAIL-XS-CORE"]
    # // Error handler when XS - Core is not installed.
    msg = "The script %s requires the latest version of XS - Core in order to function properly."
    name = "XS - Stamina System"
    msgbox(sprintf(msg, name))
    exit
  end
#==============================================================================#
# ** RPG::Item
#==============================================================================#
class RPG::Item < RPG::UsableItem
  
  def stamina
    # // Method to add stamina attribute for items.
    @note.scan(/<(?:STAMINA|stamina):\s(\d+)>/i)
    return ($1.to_i > 0 ? $1.to_i : 0)
  end
  
  def max_stamina
    # // Method to add max stamina attribute for items.
    @note.scan(/<(?:MAX_STAMINA|max_stamina):\s(\d+)>/i)
    return ($1.to_i > 0 ? $1.to_i : 0)
  end

end
#==============================================================================#
# ** Game_Interpreter
#==============================================================================#
class Game_Interpreter

  alias xail_stamina_sys_gm_interpreter_cmd_314 command_314
  def command_314(*args, &block)
    # // Method to regain stamina when recovering. (resting at an Inn etc)
    xail_stamina_sys_gm_interpreter_cmd_314(*args, &block)
    $game_player.set_stamina($game_player.max_stamina, :stamina)  
  end
  
end
#==============================================================================#
# ** Game_Battler
#==============================================================================#
class Game_Battler < Game_BattlerBase
  
  alias xail_stamina_sys_gm_battler_item_apply item_apply
  def item_apply(user, item)
    # // Method to apply item effect for stamina.
    xail_stamina_sys_gm_battler_item_apply(user, item)
    $game_player.set_stamina(item.stamina, :stamina)         if item.stamina.is_a?(Integer) and item.stamina > 0
    $game_player.set_stamina(item.max_stamina, :max_stamina) if item.max_stamina.is_a?(Integer) and item.max_stamina > 0
  end
  
  alias xail_stamina_sys_gm_battler_item_test item_test
  def item_test(user, item)
    # // Method to test a item.
    return true if $game_player.stamina < $game_player.max_stamina if item.stamina.is_a?(Integer) and item.stamina > 0
    xail_stamina_sys_gm_battler_item_test(user, item)
  end
  
end
#==============================================================================#
# ** Game_Player
#==============================================================================#
class Game_Player < Game_Character

  attr_reader :stamina, :max_stamina

  alias xail_stamina_sys_gm_player_init initialize
  def initialize(*args, &block)
    # // Method to initialize game player.
    @stamina = XAIL::STAMINA::INIT_STAMINA
    @max_stamina = XAIL::STAMINA::MAX_STAMINA
    @stamina_rate = 0
    @stamina_time = XAIL::STAMINA::RECOVER_TIME
    xail_stamina_sys_gm_player_init(*args, &block)
  end
  
  def set_stamina(value, stamina_type, operator = :add)
    # // Method to set stamina based on stamina type.
    case stamina_type
    when :stamina
      @stamina = (@stamina + value).clamp(0, @max_stamina) if operator == :add
      @stamina = (@stamina - value).clamp(0, @max_stamina) if operator == :lose
    when :max_stamina
      @max_stamina += value if operator == :add
      @max_stamina -= value if operator == :lose
    end
  end

  alias xail_stamina_sys_gm_player_move_by_input move_by_input
  def move_by_input(*args, &block)
  # // Method to control movement.
    if $game_switches[XAIL::STAMINA::HUD_SWITCH[0]]
      recover_stamina if @stamina < @max_stamina and !dash? or !moving?
      set_stamina(1, :stamina, :lose) if dash? and moving?
    end
    xail_stamina_sys_gm_player_move_by_input(*args, &block)
  end
  
  alias xail_stamina_sys_gm_player_dash? dash?
  def dash?(*args, &block)
    # // Method to check if player is dashing.
    return false if @stamina <= 0 if $game_switches[XAIL::STAMINA::HUD_SWITCH[0]]
    return xail_stamina_sys_gm_player_dash?(*args, &block)
  end
  
  def recover_stamina
    # // Method to recover stamina.
    @stamina_rate += 1
    if @stamina_rate >= @stamina_time
      if region_id == XAIL::STAMINA::RECOVER_REGION_ID
        @stamina_time = XAIL::STAMINA::RECOVER_REGION_TIME
        stamina = XAIL::STAMINA::RECOVER_REGION_STAMINA
      else
        @stamina_time = XAIL::STAMINA::RECOVER_TIME
        stamina = XAIL::STAMINA::INIT_RECOVER
      end
      unless XAIL::STAMINA::RECOVER_WHILE_MOVING.nil?
        set_stamina(XAIL::STAMINA::RECOVER_WHILE_MOVING, :stamina) unless dash? and !moving? 
      end
      set_stamina(stamina, :stamina) unless dash? or moving?
      @stamina_rate = 0
    end
  end
  
end
#==============================================================================
# ** Scene_Map
#==============================================================================
class Scene_Map < Scene_Base

  alias xail_stamina_sys_scene_map_start start
  def start(*args, &block)
    # // Method to start scene map.
    xail_stamina_sys_scene_map_start(*args, &block)
    @old_stamina = $game_player.stamina
    @old_max_stamina = $game_player.max_stamina
    @wait_stamina = 2
    @anim_stamina = 0
  end
  
  def create_stamina_hud
    # // Method to create stamina hud.
    # // Setup front and back pictures. Give error if can't locate them.
    begin
      stamina_back = Cache.picture(XAIL::STAMINA::HUD_PICS[0])
      stamina_front = Cache.picture(XAIL::STAMINA::HUD_PICS[1])
    rescue 
      msgbox("XS - Stamina: Error! Unable to find Stamina HUD pictures.")
      msgbox("Please put both pictures in \"Graphics/Picture\" folder.")
      exit 
    end
    # // Create sprite and define some variables.
    @stamina_spr ||= ::Sprite.new(@viewport1)
    @stamina_spr.bitmap = Bitmap.new(stamina_back.width, stamina_back.height)
    # // Check if hud placement is used else use custom positioning.
    if XAIL::STAMINA::HUD_PLACEMENT.nil?
      stamina_x = XAIL::STAMINA::HUD[0]
      stamina_y = XAIL::STAMINA::HUD[1]
    else
      case XAIL::STAMINA::HUD_PLACEMENT
      when 0 ; stamina_x, stamina_y = 4, 4
      when 1 
        stamina_x = Graphics.width - @stamina_spr.width - 4
        stamina_y = 4
      when 2 
        stamina_x = 4
        stamina_y = Graphics.height - @stamina_spr.height - 4
      when 3
        stamina_x = Graphics.width - @stamina_spr.width - 4
        stamina_y = Graphics.height - @stamina_spr.height - 2
      when 4
        stamina_x = (Graphics.width - @stamina_spr.width) / 2
        stamina_y = 4
      when 5
        stamina_x = (Graphics.width - @stamina_spr.width) / 2
        stamina_y = Graphics.height - @stamina_spr.height - 4
      end
    end
    begin
      @stamina_spr.x = stamina_x
      @stamina_spr.y = stamina_y
    rescue
      msgbox("XS - Stamina: Error! Please choose a valid HUD placement number (0-5).")
      exit
    end
    @stamina_spr.z = XAIL::STAMINA::HUD[2]
    # // Create new Rect objects.
    src_rect = Rect.new(0, 0, stamina_back.width, stamina_back.height)    
    @stamina_spr.bitmap.blt(0, 0, stamina_back, src_rect) 
    src_rect = Rect.new(0, 0, stamina_front.width * @old_stamina / $game_player.max_stamina, stamina_front.height)
    @stamina_spr.bitmap.blt(0, 0, stamina_front, src_rect)
  end
  
  def create_stamina_text
    # // Method to create stamina text.
    @stamina_spr.bitmap.font.name = XAIL::STAMINA::FONT[0]
    @stamina_spr.bitmap.font.size = XAIL::STAMINA::FONT[1]
    @stamina_spr.bitmap.font.color = XAIL::STAMINA::FONT[2]
    @stamina_spr.bitmap.font.out_color = XAIL::STAMINA::FONT[3]
    @stamina_spr.bitmap.font.bold = XAIL::STAMINA::FONT[4]
    @stamina_spr.bitmap.font.italic = XAIL::STAMINA::FONT[5]
    @stamina_spr.bitmap.font.shadow = XAIL::STAMINA::FONT[6]
    name = XAIL::STAMINA::DISPLAY_NAME
    value = XAIL::STAMINA.display_value(@old_stamina)
    @stamina_spr.bitmap.draw_text(8, -2, @stamina_spr.bitmap.width, 24, name, 0)
    @stamina_spr.bitmap.draw_text(-8, -2, @stamina_spr.bitmap.width, 24, value, 2)
  end  
  
  alias xail_stamina_sys_scene_map_upd update
  def update(*args, &block)
    # // Method to update scene map.
    xail_stamina_sys_scene_map_upd(*args, &block)
    return unless SceneManager.scene_is?(Scene_Map)
    if $game_switches[XAIL::STAMINA::HUD_SWITCH[1]]
      @wait_stamina -= 1 if @wait_stamina != 0
      if @old_stamina != $game_player.stamina and @wait_stamina == 0
        if @old_stamina < $game_player.stamina
          @old_stamina += 1
        else
          @old_stamina -= 1
        end
        @stamina_spr.bitmap.clear
        create_stamina_hud
        create_stamina_text
        @wait_stamina = 1
      end
      if @stamina_spr.nil?
        create_stamina_hud
        create_stamina_text
      end
      animate_stamina_hud if XAIL::STAMINA::ANIMATE
    else
      dispose_stamina_spr
    end
    save_stamina_variables
  end
  
  def save_stamina_variables
    # // Method to save the stamina values (current and max stamina) in variables.
    if @old_stamina != $game_player.stamina or @old_max_stamina != $game_player.max_stamina
      $game_variables[XAIL::STAMINA::VARS[0]] = @old_stamina
      $game_variables[XAIL::STAMINA::VARS[1]] = $game_player.max_stamina
      @old_max_stamina = $game_player.max_stamina
    end
  end
  
  def animate_stamina_hud
    # // Method to animate the stamina hud.
    if @anim_stamina >= XAIL::STAMINA::ANIMATE_TIME
      if $game_player.dash?
        @stamina_spr.opacity += 2
        @anim_stamina = 0 if @stamina_spr.opacity >= 255
      else
        @stamina_spr.opacity -= 2 unless @stamina_spr.opacity <= XAIL::STAMINA::ANIMATE_FADE
        @anim_stamina = 0 if @stamina_spr.opacity <= 0
      end
    else
      @anim_stamina += 1
    end
  end
  
  alias xail_stamina_sys_scene_map_terminate terminate
  def terminate(*args, &block)
    # // Method to terminate scene map.
    xail_stamina_sys_scene_map_terminate(*args, &block)
    dispose_stamina_spr
  end
  
  def dispose_stamina_spr
    # // Method to dipose stamina sprite.
    @stamina_spr.dispose unless @stamina_spr.nil? ; @stamina_spr = nil
  end

end # END OF FILE

#=*==========================================================================*=#
# ** END OF FILE
#=*==========================================================================*=#