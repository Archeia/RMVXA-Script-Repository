#==============================================================================
#   XaiL System - Teleport
#   Author: Nicke
#   Created: 10/01/2012
#   Edited: 03/04/2012
#   Version: 1.0a
#==============================================================================
# Instructions
# -----------------------------------------------------------------------------
# To install this script, open up your script editor and copy/paste this script
# to an open slot below ? Materials but above ? Main. Remember to save.
#
# To call this scene in a menu or on the map simply use the following code:
# SceneManager.call(Scene_Teleport)
#
# To add/del a teleport, do this in a script call:
# tp(id, type, enabled = true)
# Examples:
# tp(2, :add)  # This will add id 2.
# tp(2, :del)  # This will delete id 2.
#
# To check if id is added or enabled/disabled do the following, preferably in a
# conditional branch:
# tp_added?(id)
# tp_enable?(id)
# Examples:
# tp_added?(2)    # Is id 2 added?
# tp_enabled?(1)  # Is id 1 enabled?
# !tp_enabled?(3) # Same method used but returns true if it is disabled.
#
# To enable/disabling a id do like this:
# tp_enable(1, true)  # Enable id 1.
# tp_enable(2, false) # Disable id 2.
#
# If you want to add/delete all the id's in the list use this method:
# Note: This method uses the normal way of adding a tp. I created this method
# to save some space in the event page when adding a large amount of id's.
# tp_all(:add) # Add all id's.
# tp_all(:del) # Remove all id's.
#
# Read the settings carefully when setting up new teleport location as well as
# how to change certain settings. Make sure you change the settings as you
# want them and hopefully you will be pleased. Enjoy!
#
# *** Only for RPG Maker VX Ace. ***
#==============================================================================
($imported ||= {})["XAIL-XS-TELEPORT-SCENE"] = true

module XAIL
  module TELEPORT
    #--------------------------------------------------------------------------#
    # * Settings
    #--------------------------------------------------------------------------#
    # TP_FONT = [ name, size, color, bold, italic, shadow ]
    TP_CMD_FONT = [["Verdana"], 16, Color.new(255,255,255), true, false, false]
    TP_INFO_FONT = [["Verdana"], 14, Color.new(155,205,205), true, false, true]
    
    # The windowskin to use for the windows. Set to nil to disable.
    # SKIN = string
    SKIN = nil
    
    # Use this template when adding a long string to the map details.
    # Use \n to get to a new line.
    # TP_INFO_ID = long string
    TP_INFO_1 = "This is a very long string so that you can see how it may\nwork when using a super long string. :-)"
    TP_INFO_2 = "This is just a text explaining the map info."
    TP_INFO_3 = "Since this map is disabled i.e no teleporting allowed the\ncommand is disabled as well as the text."
    
    # How many lines the info window should display.
    # If you do have long strings in the info I suggest changing this.
    # TP_INFO_LINES = number
    TP_INFO_LINES = 3
    
    # Sets the padding of the text in the info window.
    TP_INFO_PADDING = 10 # Default: 12.
    
    # TELEPORT_LIST:
    # ID = ['Title', :symbol, map_id, x & y, map_image(nil), map_info(nil), 
    #       enabled, icon_index]
    TP_LIST = [] # Don't remove!
    TP_LIST[0] = ['Weird Lake', :weird_map,  1, [15,11], "map_test", TP_INFO_1, true, 321]
    TP_LIST[1] = ['World Map',  :world_map,  2, [12,3],"map_test2", TP_INFO_2, true, nil]
    TP_LIST[2] = ['Disabled Map', :disabled, 2, [1,1],"map_test2", TP_INFO_3, false, 327]
    
    # Empty icon index. Which icon should be in use if TP_LIST icon_index is nil.
    # EMPTY_ICON_INDEX = icon_index
    EMPTY_ICON_INDEX = 0
    
    # Display texts. Should be easy enough to understand what they are for.
    TEXT_NO_TELEPORTS = "You haven't found a location to teleport to."
    OK_NAME = "Teleport" # Dialog box ok.
    OK_CANCEL = "Cancel" # Dialog box cancel.
     
    # Transition, nil to use default.
    # TRANSITION [ SPEED, TRANSITION, OPACITY ]
    # TRANSITION = [40, "Graphics/Transitions/1", 50]
    TRANSITION = nil
    
    # Background image (System folder)
    # Note: You might want to decrease the opacity as well as arrange 
    # the windows so that you can properly see the background.
    # Set to nil to use default.
    BACK = nil
    
    # Should a animation be used when teleporting to a new map.
    # Set it to nil to disable it.
    ANIM_ID = 81
    
    # Fade out time when teleporting to a new map.
    # 1000 (1 second)
    # ANIM_SCENE_FADE/ANIM_AUDIO_FADE = number
    ANIM_SCENE_FADE = 500  # Fade out time for scene.
    ANIM_AUDIO_FADE = 500  # Fade out time for audio.
    
  end
end
# *** Don't edit below unless you know what you are doing. ***
#==============================================================================#
# ** Game_System
#------------------------------------------------------------------------------
#  Method for checking the teleport list.
#==============================================================================#
class Game_System
  
  attr_accessor :tp_list
  
  alias xail_teleport_sys_initialize initialize
  def initialize(*args, &block)
    xail_teleport_sys_initialize(*args, &block)
    @tp_list = []
  end
  
end
#==============================================================================#
# ** Game_Interpreter
#------------------------------------------------------------------------------
#  Method for adding and deleting a teleport.
#==============================================================================#
class Game_Interpreter
  
  def tp(id, type)  
    # // Method to add a item to the list.  
    case type
      when :add # // Add teleport id.
      unless $game_system.tp_list.include?(XAIL::TELEPORT::TP_LIST[id])
        $game_system.tp_list.push(XAIL::TELEPORT::TP_LIST[id])
      end unless XAIL::TELEPORT::TP_LIST[id].nil?
      when :del # // Remove teleport id.
      unless XAIL::TELEPORT::TP_LIST[id].nil?
        $game_system.tp_list.delete(XAIL::MENU::TP_LIST[id])
      end 
    end
  end
  
  def tp_enabled?(id)
    # // Method to check if id is enabled.
    # (Must be added in the list or else it returns nil).
    return if $game_system.tp_list[id].nil?
    return $game_system.tp_list[id][6]
  end
  
  def tp_added?(id)
    # // Method to check if id is added.
    return $game_system.tp_list[id]
  end
  
  def tp_enable(id, enabled)
    # // Method to enable id.
    $game_system.tp_list[id][6] = enabled
  end 
  
  def tp_all(type = :add)
    # // Method to add/delete all teleport id's.
    id = 0
    while id < XAIL::TELEPORT::TP_LIST.size
      case type
      when :add
        tp(id, :add)
      else
        tp(id, :del)
      end
      id += 1
    end
  end
  
end
#==============================================================================#
# ** Window_TeleportCommand
#------------------------------------------------------------------------------
#  New Window :: Window_TeleportCommand - A window for creating the commands.
#==============================================================================#
class Window_TeleportCommand < Window_Command
  
  def window_width
    # // Method to return the width.
    return 160
  end
  
  def window_height
    # // Method to return the height.
    return Graphics.height
  end
  
  def menu_color(color, enabled = true)
     # // Method to set the color and alpha if not enabled.
    contents.font.color.set(color)
    contents.font.color.alpha = 100 unless enabled
  end
  
  def draw_item(index)
    # // Method to draw the command item.
    contents.font.name = XAIL::TELEPORT::TP_CMD_FONT[0]
    contents.font.size = XAIL::TELEPORT::TP_CMD_FONT[1]
    menu_color(XAIL::TELEPORT::TP_CMD_FONT[2], menu_enabled?(index))
    contents.font.bold = XAIL::TELEPORT::TP_CMD_FONT[3]
    contents.font.italic = XAIL::TELEPORT::TP_CMD_FONT[4]
    contents.font.shadow = XAIL::TELEPORT::TP_CMD_FONT[5]
    draw_text(item_rect_for_icons(index), command_name(index), alignment)
    draw_tp_icons(index)
    reset_font_settings
  end
  
  def draw_tp_icons(index)
    # // Method to draw the icons. 
    # If there is no icon as in nil return a empty 
    # icon index
    y = 0
    for i in @tp_list
      icon = i[7].nil? ? XAIL::TELEPORT::EMPTY_ICON_INDEX : i[7]
      draw_icon(icon, 0, y, menu_enabled?(index))
      y += 24
    end
  end

  def item_rect_for_icons(index)
     # // Method to draw the text with icons.
    rect = item_rect(index)
    rect.x += 24
    rect.width -= 8
    rect
  end
  
  def menu_enabled?(index)
    # // Method to check if item is enabled.
    return @tp_list[index][6]
  end
  
  alias xail_mk_cmd_list_tp make_command_list
  def make_command_list(*args, &block)
    # // Method to add the commands.
    xail_mk_cmd_list_tp(*args, &block)
    @tp_list = $game_system.tp_list
    for i in @tp_list
      add_command(i[0], i[1], i[6])
    end
  end

end
#==============================================================================#
# ** Window_OK_Command
#==============================================================================#
class Window_OK_Command < Window_Command
  
  def window_width
    # // Method to return the width.
    return 120
  end
  
  def alignment
    # // Method to return the alignment.
    return 1
  end
  
  alias xail_mk_cmd_list_ok make_command_list
  def make_command_list(*args, &block)
    # // Method to add the commands.
    xail_mk_cmd_list_ok(*args, &block)
    add_command(XAIL::TELEPORT::OK_NAME, :ok)
    add_command(XAIL::TELEPORT::OK_CANCEL, :cancel)
  end
  
end
#==============================================================================#
# ** Window_tpInfo
#==============================================================================#
class Window_tpInfo < Window_Base
  
  def initialize(x, y, width, height)
    # // Method to initialize the window.
    super(0, 0, width, window_height)
    @tp_list = $game_system.tp_list
    refresh
  end
  
  def set_text(text, enabled)
    # // Method to set a new the tp text to the window.
    if text != @text
      @text = text
      menu_color(XAIL::TELEPORT::TP_INFO_FONT[2], enabled)
      refresh
    end
  end
  
  def window_height
    # // Method to return the height.
    return fitting_height(XAIL::TELEPORT::TP_INFO_LINES)
  end
  
  def standard_padding
    # // Method to set the padding for text.
    return XAIL::TELEPORT::TP_INFO_PADDING
  end

  def refresh
    # // Method to refresh the window.
    contents.clear
    draw_tp_text
  end
  
  def menu_color(color, enabled = true)
     # // Method to set the color and alpha if not enabled.
    contents.font.color.set(color)
    contents.font.color.alpha = 150 unless enabled
  end
  
  def draw_tp_ex(x, y, text)
    # // Special method to draw a text.
    text = convert_escape_characters(text)
    pos = {:x => x, :y => y, :new_x => x, :height => calc_line_height(text)}
    process_character(text.slice!(0, 1), text, pos) until text.empty?
  end
  
  def draw_tp_text
    # // Method to draw the tp text to the window.
    contents.font.name = XAIL::TELEPORT::TP_INFO_FONT[0]
    contents.font.size = XAIL::TELEPORT::TP_INFO_FONT[1]
    contents.font.bold = XAIL::TELEPORT::TP_INFO_FONT[3]
    contents.font.italic = XAIL::TELEPORT::TP_INFO_FONT[4]
    contents.font.shadow = XAIL::TELEPORT::TP_INFO_FONT[5]
    draw_tp_ex(0, 0, @text)
    reset_font_settings
  end
  
end
#==============================================================================#
# ** Window_tpImage
#==============================================================================#
class Window_tpImage < Window_Base
  
  def initialize(x, y, width, height)
    # // Method to initialize the window.
    super(0, 0, width, height)
    refresh
  end
  
  def refresh
    # // Method to refresh the window.
    contents.clear
  end
  
  def draw_tp_map(x, y, source, enabled = true)
    # // Method to draw the teleport map.
    rect = Rect.new(0, 0, Graphics.width, Graphics.height)
    return clear_tp_map(rect) if source.nil?
    clear_tp_map(rect)
    tp_map = Cache.picture(source)
    contents.blt(x, y, tp_map, rect, enabled ? 255 : 150)
  end
  
  def clear_tp_map(rect)
    # // Method to clear tp_map rect.
    contents.clear_rect(rect)
  end
  
end
#==============================================================================#
# ** Scene_TeleportBase
#------------------------------------------------------------------------------
#  New Scene :: Scene_TeleportBase - The teleport scene.
#==============================================================================#
class Scene_TeleportBase < Scene_Base
  
  alias xail_tpbase_start start
  def start(*args, &block)
    # // Method to start the scene
    xail_tpbase_start(*args, &block)
    @tp_list = $game_system.tp_list
    create_background
  end
  
  def post_start
    # // Method to post_start the scene.
    perform_transition unless @tp_list.empty?
  end
  
  alias xail_tpbase_terminate terminate
  def terminate(*args, &block)
    # // Method to terminate the scene.
    xail_tpbase_terminate(*args, &block)
  end
  
  def create_background
    # // Method to create the background.
    @background_sprite = Sprite.new
    if XAIL::TELEPORT::BACK.nil?
      @background_sprite.bitmap = SceneManager.background_bitmap
      @background_sprite.color.set(16, 16, 16, 128)
    else
      @background_sprite.bitmap = Cache.system(XAIL::TELEPORT::BACK)
    end
  end

  alias xail_tpbase_transition perform_transition
  def perform_transition(*args, &block)
    # // Method to create the transition.´
    if XAIL::TELEPORT::TRANSITION.nil?
      Graphics.transition(15)
    else
      Graphics.transition(XAIL::TELEPORT::TRANSITION[0],XAIL::TELEPORT::TRANSITION[1],XAIL::TELEPORT::TRANSITION[2])
    end
    xail_tpbase_transition(*args, &block)
  end
  
end 
#==============================================================================#
# ** Scene_Teleport
#------------------------------------------------------------------------------
#  New Scene :: Scene_Teleport - The teleport scene.
#==============================================================================#
class Scene_Teleport < Scene_TeleportBase
  
  alias xail_tpbase_init initialize
  def initialize(*args, &block)
    # // Method to initialize scene teleport.
    xail_tpbase_init(*args, &block)
    @tp_list = $game_system.tp_list
  end
  
  def start
    # // Method to start scene teleport.
    super
    return command_map if @tp_list.empty?
    create_tp_command_window
    create_tp_info
    create_tp_image
    on_index_change(0) # // Draw id 0 when scene is loaded.
  end
  
  def create_tp_command_window
    # // Method to create command list window.
    @command_window = Window_TeleportCommand.new(0, 0)
    @command_window.windowskin = Cache.system(XAIL::TELEPORT::SKIN) unless XAIL::TELEPORT::SKIN.nil?
    for i in @tp_list
      @command_window.set_handler(i[1], method(:command_ok_dialog))
    end
    @command_window.set_handler(:cancel, method(:return_scene))
  end
  
  def create_ok_window
    # // Method to create ok command window.
    @ok_window = Window_OK_Command.new(0, 0)
    @ok_window.windowskin = Cache.system(XAIL::TELEPORT::SKIN) unless XAIL::TELEPORT::SKIN.nil?
    @ok_window.x = (Graphics.width - @ok_window.width) / 2
    @ok_window.y = (Graphics.height - @ok_window.height) / 2
    @ok_window.set_handler(:ok, method(:command_teleport))
    @ok_window.set_handler(:cancel, method(:command_cancel_dialog))
  end
  
  def create_tp_info
    # // Method to create teleport info window.
    width = Graphics.width - @command_window.width
    height = 80
    @tp_info = Window_tpInfo.new(0, 0, width, height)
    @tp_info.windowskin = Cache.system(XAIL::TELEPORT::SKIN) unless XAIL::TELEPORT::SKIN.nil?
    @tp_info.x = @command_window.width
    @tp_info.y = 0
  end
  
  def create_tp_image
    # // Method to create teleport image window.
    width = Graphics.width - @command_window.width
    height = Graphics.height - @tp_info.height
    @tp_image_window = Window_tpImage.new(0, 0, width, height)
    @tp_image_window.windowskin = Cache.system(XAIL::TELEPORT::SKIN) unless XAIL::TELEPORT::SKIN.nil?
    @tp_image_window.x = @command_window.width
    @tp_image_window.y = @tp_info.height
  end
  
  def create_tp_message_window
    # // Method to create the message window.
    @message_window = Window_Message.new
  end
    
  def command_ok_dialog
    # // Method to open ok dialog.
    create_ok_window
  end
  
  def command_cancel_dialog
    # // Method to close ok dialog.
    @ok_window.close
    @command_window.active = true
  end
  
  def command_teleport
    # // Method to teleport the player.
    teleport_player(@command_window.index)
  end
  
  def command_map
    # // command_map (Don't remove)
    create_tp_message_window
    $game_message.texts << XAIL::TELEPORT::TEXT_NO_TELEPORTS
    SceneManager.call(Scene_Map)
  end
  
  def teleport_player(index)
    # // Method for teleporting the player to the spawn event. (if exists)
    $game_map.setup(@tp_list[index][2])
    $game_player.moveto(@tp_list[index][3][0], @tp_list[index][3][1])
    fadeout_scene
    $game_map.autoplay
    $game_map.refresh
    $game_player.animation_id = XAIL::TELEPORT::ANIM_ID unless XAIL::TELEPORT::ANIM_ID.nil?
    SceneManager.call(Scene_Map)
  end
  
  def fadeout_scene
    time = XAIL::TELEPORT::ANIM_AUDIO_FADE
    # // Method to fade out the scene.
    RPG::BGM.fade(time)
    RPG::BGS.fade(time)
    RPG::ME.fade(time)
    Graphics.fadeout(XAIL::TELEPORT::ANIM_SCENE_FADE * Graphics.frame_rate / 1000)
    RPG::BGM.stop
    RPG::BGS.stop
    RPG::ME.stop
  end
  
  def draw_tp_image(index)
    # // Draw teleport image.
    image = @tp_list[index][4]
    enabled = @tp_list[index][6]
    @tp_image_window.draw_tp_map(0, 0, image, enabled)
  end
  
  def draw_tp_info(index)
    # // Draw teleport details.
    title = @tp_list[index][0]
    info = @tp_list[index][5]
    enabled = @tp_list[index][6]
    text = "#{title}\n#{info}" unless @tp_list[index][5].nil?
    @tp_info.set_text(text, enabled)
  end
  
  alias xail_upd_tp_index_change update
  def update(*args, &block)
    # // Method for updating the scene.
    old_index = @command_window.index
    xail_upd_tp_index_change(*args, &block)
    on_index_change(@command_window.index) if old_index != @command_window.index
  end

  def on_index_change(index)
    # // If index changes redraw the image and info.
    draw_tp_image(index)
    draw_tp_info(index)
  end
  
end # END OF FILE

#=*==========================================================================*=#
# ** END OF FILE
#=*==========================================================================*=#