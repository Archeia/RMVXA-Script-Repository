#==============================================================================
#   XaiL System - Menu
#   Author: Nicke
#   Created: 29/12/2011
#   Edited: 17/01/2012
#   Version: 1.1c
#==============================================================================
# Instructions
# -----------------------------------------------------------------------------
# To install this script, open up your script editor and copy/paste this script
# to an open slot below ? Materials but above ? Main. Remember to save.
#
# A simple menu script featuring a few functions.
#
# *** Only for RPG Maker VX Ace. ***
#==============================================================================
($imported ||= {})["XAIL-XS-MENU"] = true

module XAIL
  module MENU
    #--------------------------------------------------------------------------#
    # * Settings
    #--------------------------------------------------------------------------#
    # MENU_FONT = [ name, size, color, bold, shadow ]
    MENU_FONT = [["Verdana"], 14, Colors::White, true, true]
    
    # MENU_WINDOW [ width, x, y, z, opacity]
    MENU_WINDOW = [160, 0, 0, 200, 255]
    
    # MENU_ALIGNMENT = 0 (left), 1 (center), 2 (right)
    MENU_ALIGNMENT = 0 # Default: 0.
    
    # The windowskin to use for the windows.
    # nil to disable.
    # MENU_SKIN = string
    MENU_SKIN = nil
    
    # Menu list - The icon_index (can be nil) and custom_scene is optional.
    # MENU_LIST: 
    # ID = ['Title', :symbol, :command, icon_index, active, custom ]
    MENU_LIST = []
    MENU_LIST[0] = ['Item',   :item,      :command_item,     264, true]
    MENU_LIST[1] = ['Skills', :skill,     :command_personal, 112, true]
    MENU_LIST[2] = ['Equip',  :equip,     :command_personal, 170, true]
    MENU_LIST[3] = ['Status', :status,    :command_personal, 122, true]
    MENU_LIST[4] = ['Party',  :formation, :command_formation,121, true]
    MENU_LIST[5] = ['Save',   :save,      :command_save,     233, true]
    MENU_LIST[6] = ['Quit',   :game_end,  :command_game_end, 1,   true]
    # Custom command:
    MENU_LIST[7] = ['Title',  :title,     :command_custom,   12, true, Scene_Title]
    
    # If MENU_CUSTOM is true you will have to add the commands yourself
    # ingame, which can be useful for certain quest related stuff or if you
    # want to disable commands temporarly.
    # To add/delete a command ingame follow these instructions:
    # 
    # In a Call Script do like this:
    # menu_scene(2,:add) # To add id 2 to menu list.
    # menu_scene(3,:del) # To remove id 3 from menu list.
    #
    # In a conditional branch do like this to check if a id is active:
    # menu_active?(5) # Returns true if id 5 is enabled.
    #
    # To set a id to be enabled do like this:
    # menu_set_active(1, true) # Set id 1 to be enabled.
    #
    # To add/delete every menu item to the list use this method:
    # menu_scene_all(type = :add/:del)
    #
    # MENU_CUSTOM = true/false
    MENU_CUSTOM = true
    
    # The text to be displayed if no menu items is available.
    # MENU_EMPTY = ""
    MENU_EMPTY = "Menu not available at this point."
    
    # Disable all of the icons if you don't need them.
    # ICON_ENABLE = true/false
    ICON_ENABLE = true
    
    # Gold window.
    # nil to disable the icon(s).
    # GOLD = [ x, y, z, opacity, icon_index, enabled ]
    GOLD = [0, 368, 101, 255, 361, false]
    
    # Status window.
    # If you disable status window you can't use formation (party) command.
    # So that command can be removed/commented in MENU_LIST if so.
    # STATUS = [ x, y, z, opacity, enabled ]
    STATUS = [160, 0, 100, 255, false]
     
    # Transition, nil to use default.
    # TRANSITION [ SPEED, TRANSITION, OPACITY ]
    # TRANSITION = [20, "Graphics/Transitions/1", 50]
    TRANSITION = nil
    
    # Menu background image (System folder)
    # Note: You might want to decrease the opacity as well as arrange 
    # the windows so that you can properly see the background.
    # Set to nil to use default.
    BACK = nil
    
    # Note: Not active if menu background is in use.
    # Background type: 
    # 0 = normal blur (default)
    # 1 = radial blur
    # 2 = hue change
    # 3 = custom color
    # 4 = custom gradient
    # BACK_TYPE = [ type, opacity, enabled ]
    BACK_TYPE = [1, 200, true]
    # BACK_RADIAL_BLUR = 0-360, 2-100
    BACK_RADIAL_BLUR = [10, 10]
    # BACK_HUE = 0-360
    BACK_HUE = 30 
    # BACK_COLOR = 0-255 (Red, Green, Blue, Alpha)
    BACK_COLOR = Color.new(255,0,255,128)
    # BACK_GRADIENT = [ Color1, Color2, Vertical ]
    BACK_GRADIENT = [Color.new(0,0,250,128), Color.new(255,0,0,128), true]
    
  end
end
# *** Don't edit below unless you know what you are doing. ***
#==============================================================================#
# ** Game_System
#==============================================================================#
class Game_System
  
  attr_accessor :menu_list
  
  alias XAIL_menu_sys_initialize initialize unless $@
  def initialize(*args, &block)
    XAIL_menu_sys_initialize(*args, &block)
    @menu_list = []
  end
  
end
#==============================================================================#
# ** Game_Interpreter
#==============================================================================#
class Game_Interpreter
  
  def menu_scene(id, type)  
    # // Method to add a item to the list.  
    case type
      when :add # // Add menu id.
      unless $game_system.menu_list.include?(XAIL::MENU::MENU_LIST[id])
        $game_system.menu_list.push(XAIL::MENU::MENU_LIST[id])
      end unless XAIL::MENU::MENU_LIST[id].nil?
      when :del # // Remove menu id.
      unless XAIL::MENU::MENU_LIST[id].nil?
        $game_system.menu_list.delete(XAIL::MENU::MENU_LIST[id])
      end 
    end
  end
  
  def menu_active?(id)
    # // Method to check if id is eanbled.
    return if $game_system.menu_list[id].nil?
    return $game_system.menu_list[id][4]
  end
  
  def menu_set_active(id, enabled)
    # // Method to enable id.
    $game_system.menu_list[id][4] = enabled
  end
  
  def menu_scene_all(type = :add)
    # // Method to add or delete all of the id's to the menu list.
    id = 0
    while id < XAIL::MENU::MENU_LIST.size
      case type
      when :add
        menu_scene(id, :add)
      else
        menu_scene(id, :del)
      end
      id += 1
    end
  end
  
end
#==============================================================================
# ** Window_MenuCommand
#==============================================================================
class Window_MenuCommand < Window_Command
  
  def window_width
    # // Method to return the width of MENU_WINDOW.
    return XAIL::MENU::MENU_WINDOW[0]
  end
  
  def alignment
    # // Method to return the alignment.
    return XAIL::MENU::MENU_ALIGNMENT
  end
  
  def get_menu(menu_list)
    # // Method to get the menu list.
    if XAIL::MENU::MENU_CUSTOM
      @menu_list = $game_system.menu_list
    else
      @menu_list = XAIL::MENU::MENU_LIST
    end
  end
  
  def menu_color(color, enabled = true)
     # // Method to set the color and alpha if not enabled.
    contents.font.color.set(color)
    contents.font.color.alpha = Colors::AlphaMenu unless enabled
  end
  
  def draw_item(index)
    # // Method to draw the command item.
    contents.font.name = XAIL::MENU::MENU_FONT[0]
    contents.font.size = XAIL::MENU::MENU_FONT[1]
    menu_color(XAIL::MENU::MENU_FONT[2], menu_enabled?(index))
    contents.font.bold = XAIL::MENU::MENU_FONT[3]
    contents.font.shadow = XAIL::MENU::MENU_FONT[4]
    draw_text(item_rect_for_text(index), command_name(index), alignment)
    reset_font_settings
  end
  
  def menu_enabled?(index)
    # // Method to check if menu item is enabled.
    return @menu_list[index][4]
  end
  
  def make_command_list
    # // Method to add the commands.
    for i in get_menu(@menu_list)
    case i[1]
    when :save
    if i[4].nil?
      add_command(i[0], i[1], save_enabled, i[5])
    else
      add_command(i[0], i[1], i[4], i[5])
    end
    when :formation
    if XAIL::MENU::STATUS[4]
      i[4] = true
      add_command(i[0], i[1], i[4], i[5])
    else
      i[4] = false
     add_command(i[0], i[1], i[4], i[5])
    end
    else
      i[4] = true if i[4].nil?
      add_command(i[0], i[1], i[4], i[5])
    end
  end
    
  end
end
#==============================================================================#
# ** Window_Gold
#==============================================================================#
class Window_Gold < Window_Base
  
  alias xail_wingold_refresh refresh
  def refresh(*args, &block)
    contents.clear
    # // Refresh method override, draw a icon and the value.
    if XAIL::MENU::ICON_ENABLE and !XAIL::MENU::GOLD[4].nil?
      draw_icon(XAIL::MENU::GOLD[4], 116, -2) 
      draw_currency_value(value, currency_unit, -10, 0, contents.width - 8)
    else
      xail_wingold_refresh(*args, &block)
    end
  end
  
end
#==============================================================================#
# ** Scene_MenuBase
#------------------------------------------------------------------------------
#  New Scene :: Scene_MenuBase
#==============================================================================#
class Scene_MenuBase < Scene_Base
  
  alias xail_menubase_start start
  def start(*args, &block)
    # // Method to start the scene
    xail_menubase_start(*args, &block)
    @menu_list = $game_system.menu_list
  end
  
  def post_start
    # // Method to post_start the scene.
    perform_transition unless @menu_list.empty?
  end
  
  alias xail_menubase_terminate terminate
  def terminate(*args, &block)
    # // Method to terminate the scene.
    xail_menubase_terminate(*args, &block)
  end
  
  def create_background
    # // Method to create custom background
    @background_sprite = Sprite.new
    if XAIL::MENU::BACK.nil?
      @background_sprite.bitmap = SceneManager.background_bitmap
      if XAIL::MENU::BACK_TYPE[2]
        source = SceneManager.background_bitmap
        bitmap = Bitmap.new(Graphics.width, Graphics.height)
        bitmap.stretch_blt(bitmap.rect, source, source.rect) unless SceneManager.scene_is?(Scene_Load)
        case XAIL::MENU::BACK_TYPE[0]
        when 0 ; bitmap.blur # // Default
        when 1 ; bitmap.radial_blur(XAIL::MENU::BACK_RADIAL_BLUR[0], XAIL::MENU::BACK_RADIAL_BLUR[0])
        when 2 ; bitmap.hue_change(XAIL::MENU::BACK_HUE)
        when 3 ; bitmap.fill_rect(bitmap.rect, XAIL::MENU::BACK_COLOR)
        when 4 ; bitmap.gradient_fill_rect(bitmap.rect, XAIL::MENU::BACK_GRADIENT[0],
                 XAIL::MENU::BACK_GRADIENT[1], XAIL::MENU::BACK_GRADIENT[2])
        end
        @background_sprite.opacity = XAIL::MENU::BACK_TYPE[1]
        @background_sprite.bitmap = bitmap
      end
    else
      @background_sprite.bitmap = Cache.system(XAIL::MENU::BACK)
    end
  end
  
  alias xail_menubase_transition perform_transition
  def perform_transition(*args, &block)
    # // Method to create the transition.
    xail_menubase_transition(*args, &block)
    if XAIL::MENU::TRANSITION.nil?
      Graphics.transition(15)
    else
      Graphics.transition(XAIL::MENU::TRANSITION[0],XAIL::MENU::TRANSITION[1],XAIL::MENU::TRANSITION[2])
    end
  end

end
#==============================================================================#
# ** Scene_Menu
#------------------------------------------------------------------------------
#  New Scene :: Scene_Menu
#==============================================================================#
class Scene_Menu < Scene_MenuBase
  
  def start
    # // Method to start the scene.
    super
    if XAIL::MENU::MENU_CUSTOM
      @menu_list = $game_system.menu_list
    else
      @menu_list = XAIL::MENU::MENU_LIST
    end
    return command_map if @menu_list.empty?
    create_menu_command_window
    create_menu_icon_window
    create_menu_gold_window if XAIL::MENU::GOLD[5]
    create_menu_status_window if XAIL::MENU::STATUS[4]
  end
  
  alias xail_menuscene_create_command_window create_command_window
  def create_menu_command_window(*args, &block)
    # // Method to create the command window.
    xail_menuscene_create_command_window(*args, &block)
    @command_window.windowskin = Cache.system(XAIL::MENU::MENU_SKIN) unless XAIL::MENU::MENU_SKIN.nil?
    @command_window.x = XAIL::MENU::MENU_WINDOW[1]
    @command_window.y = XAIL::MENU::MENU_WINDOW[2]
    @command_window.z = XAIL::MENU::MENU_WINDOW[3]
    @command_window.opacity = XAIL::MENU::MENU_WINDOW[4]
    for i in @menu_list
      case i[1]
      when :status
      if !XAIL::MENU::STATUS[4]
        @command_window.set_handler(i[1], method(:command_status))
      else
        @command_window.set_handler(i[1], method(i[2]))
      end
      when :skill
      if !XAIL::MENU::STATUS[4]
        @command_window.set_handler(i[1], method(:command_skill))
      else
        @command_window.set_handler(i[1], method(i[2]))
      end
      when :equip
      if !XAIL::MENU::STATUS[4]
        @command_window.set_handler(i[1], method(:command_equip))
      else
        @command_window.set_handler(i[1], method(i[2]))
      end
      else
      @command_window.set_handler(i[1], method(i[2]))
      end
    end
    @command_window.set_handler(:cancel, method(:return_scene))
  end
  
  def create_menu_icon_window
    # // Method to create the menu icon window.
    @command_icon = Window_Icon.new(0, 0, @command_window.width, XAIL::MENU::MENU_LIST.size)
    @command_icon.alignment = XAIL::MENU::MENU_ALIGNMENT
    @command_icon.enabled = XAIL::MENU::ICON_ENABLE
    @command_icon.draw_cmd_icons(@menu_list, 3)
    @command_icon.x = XAIL::MENU::MENU_WINDOW[1]
    @command_icon.y = XAIL::MENU::MENU_WINDOW[2]
    @command_icon.z = 201
    @command_icon.opacity = 0
  end
  
  def create_menu_message_window
    # // Method to create the message window.
    @message_window = Window_Message.new
  end
  
  def create_menu_gold_window
    # // Method to create the gold window.
    @gold_window = Window_Gold.new
    @gold_window.windowskin = Cache.system(XAIL::MENU::MENU_SKIN) unless XAIL::MENU::MENU_SKIN.nil?
    @gold_window.x = XAIL::MENU::GOLD[0]
    @gold_window.y = XAIL::MENU::GOLD[1]
    @gold_window.z = XAIL::MENU::GOLD[2]
    @gold_window.opacity = XAIL::MENU::GOLD[3]
  end

  def create_menu_status_window
    # // Method to create the status window.
    @status_window = Window_MenuStatus.new(XAIL::MENU::STATUS[0], XAIL::MENU::STATUS[1])
    @status_window.windowskin = Cache.system(XAIL::MENU::MENU_SKIN) unless XAIL::MENU::MENU_SKIN.nil?
    @status_window.z = XAIL::MENU::STATUS[2]
    @status_window.opacity = XAIL::MENU::STATUS[3]
  end
  
  def command_status
    # // command_status (Don't remove)
    SceneManager.call(Scene_Status)
  end
  
  def command_skill
    # // command_skill (Don't remove)
    SceneManager.call(Scene_Skill)
  end
  
  def command_equip
    # // command_equip (Don't remove)
    SceneManager.call(Scene_Equip)
  end
  
  def command_custom
    # // Method to call a custom command.
    SceneManager.goto(@command_window.current_ext)
  end
  
  def command_map
    # // command_map (Don't remove)
    create_menu_message_window
    $game_message.texts << XAIL::MENU::MENU_EMPTY
    SceneManager.call(Scene_Map)
  end
  
end # END OF FILE

#=*==========================================================================*=#
# ** END OF FILE
#=*==========================================================================*=#