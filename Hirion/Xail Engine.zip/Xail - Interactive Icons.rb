#==============================================================================
#   XaiL System - Interactive Icons
#   Author: Nicke
#   Created: 29/11/2012
#   Edited: 29/01/2013
#   Version: 1.0c
#==============================================================================
# Instructions
# -----------------------------------------------------------------------------
# To install this script, open up your script editor and copy/paste this script
# to an open slot below ? Materials but above ? Main. Remember to save.
#
# Interactive Icons. Setup a icon on a event by doing the following comment
# inside a event page:
# <CHARACTER_ICON: n>
#
# Example:
# <CHARACTER_ICON: 25> # Set the event to use icon 25. (25 is the icon_index).
#
# Script can be enabled/disabled using a switch and you can also change the
# animation below in the settings.
#
# *** Only for RPG Maker VX Ace. ***
#==============================================================================
($imported ||= {})["XAIL-INT-ICONS"] = true

module XAIL
  module INT_ICONS
  #--------------------------------------------------------------------------#
  # * Settings
  #--------------------------------------------------------------------------#
    # Set the initial default values for every icon sprite.
    # ICON_SPRITE = [ox, oy, z]
    ICON_SPRITE = [12, 34, 200]
    
    # Switch to enable/disable the script.
    # SWITCH = switch_id
    SWITCH = 1
    
    # Control the icon animation here.
    # ANIMATION = [enabled, speed, delay]
    ANIMATION = [true, 7, 60]

  end
end
# *** Don't edit below unless you know what you are doing. ***
#==============================================================================#
# ** Error Handler
#==============================================================================#
  unless $imported["XAIL-XS-CORE"]
    # // Error handler when XS - Core is not installed.
    msg = "The script %s requires the latest version of XS - Core in order to function properly."
    name = "XS - Interactive Icons"
    msgbox(sprintf(msg, name))
    exit
  end
#==============================================================================
# ** Sprite_Character
#==============================================================================
class Sprite_Character < Sprite_Base

  alias xail_int_icons_spr_char_init initialize
  def initialize(viewport, character = nil)
    # // Method to initialize sprite character.
    # // Define animation delay variable.
    @anim_speed = XAIL::INT_ICONS::ANIMATION[1]
    @anim_delay = XAIL::INT_ICONS::ANIMATION[2]
    @icon_index = 0
    xail_int_icons_spr_char_init(viewport, character)
  end
  
  def draw_character_icon(icon_index)
    # // Method to draw character icon.
    # // First dispose icon if it exists then create a new instance of it.
    dispose_icon
    @icon_sprite = ::Sprite.new(viewport)
    @icon_sprite.bitmap = Cache.system("Iconset")
    @icon_sprite.src_rect = rect = Rect.new(icon_index % 16 * 24, icon_index / 16 * 24, 24, 24)
    @icon_sprite.ox = XAIL::INT_ICONS::ICON_SPRITE[0]
    @icon_sprite.oy = XAIL::INT_ICONS::ICON_SPRITE[1]
    @icon_sprite.z = XAIL::INT_ICONS::ICON_SPRITE[2]
    @icon_sprite.bitmap.blt(@icon_sprite.x, @icon_sprite.y, @icon_sprite.bitmap, @icon_sprite.src_rect, 255)
    update_icon
  end
  
  def icon?
    # // Check if character icon is available and no transparency used.
    @character.icon and !@character.transparent
  end

  alias xail_int_icons_spr_char_upd update
  def update(*args, &block)
    # // Method to update sprite character.
    # // Update routine for the character icons and animation part.
    xail_int_icons_spr_char_upd(*args, &block)
    # // Check if icon should be displayed.
    if $game_switches[XAIL::INT_ICONS::SWITCH]
      # // Update icon sprite.
      update_icon
      # // Do animation based on speed and delay.
      update_icon_animation if XAIL::INT_ICONS::ANIMATION[0]
    else
      dispose_icon
    end
  end
  
  def update_icon
    # // Method to update character icon.
    return dispose_icon unless icon?
    if icon?
      # // Dispose and return if character opacity is equal to 0.
      return dispose_icon if @character.opacity == 0
      # // Draw the character icon based on the icon index.
      draw_character_icon(@character.icon_index) unless @icon_sprite
      # // Dispose icon and redraw it if icon index is changed.
      if @icon_index != @character.icon_index
        @icon_index = @character.icon_index
        dispose_icon
        draw_character_icon(@character.icon_index) unless @icon_sprite
      end
      # // Define icon sprite variables.
      @icon_sprite.x = x
      @icon_sprite.y = y - @icon_sprite.height
      @icon_sprite.z = z + 1
    end
  end
  
  def update_icon_animation
    # // Method to do icon animation. (fading)
    # // Do delay animation.
    if @anim_delay >= 0
      @anim_delay -= 1
    else
      # // Else do animation for icon and reset delay.
      if icon?
        @icon_sprite.opacity -= @anim_speed
        if @icon_sprite.opacity == 0 or @icon_sprite.opacity == 255
          @anim_speed *= -1
          @anim_delay = XAIL::INT_ICONS::ANIMATION[2]
        end
      end
    end
  end
  
  alias xail_int_icons_spr_chr_dispose dispose
  def dispose
    # // Method to dispose sprite chracter.
    # // Dispose the icon.
    dispose_icon
    xail_int_icons_spr_chr_dispose
  end

  def dispose_icon
    # // Method to dispose character icon.
    # // Dispose the icon unless it is nil, set the variable to nil afterwards.
    @icon_sprite.dispose unless @icon_sprite.nil?
    @icon_sprite = nil
  end
    
end
#==============================================================================
# ** Game_CharacterBase
#==============================================================================
class Game_CharacterBase
  
  attr_accessor :icon, :icon_index

  alias xail_int_icons_gm_char_init_public_members init_public_members
  def init_public_members(*args, &block)
    # // Method to init public members.
    xail_int_icons_gm_char_init_public_members(*args, &block)
    @icon = false
    @icon_index = 0
  end
  
end
#==============================================================================
# ** Game_Event
#==============================================================================
class Game_Event < Game_Character
  
  alias xail_int_icons_gm_evt_setup_page_settings setup_page_settings
  def setup_page_settings(*args, &block)
    # // Method to setup page settings for the event.
    xail_int_icons_gm_evt_setup_page_settings(*args, &block)
    # // Check comment if it includes character icon index.
    icon = comment_int?("CHARACTER_ICON")
    # // If results is a integer create icon.
    if icon.is_a?(Integer) and !icon.nil?
      @icon = true
      @icon_index = icon
    end
  end
  
  alias xail_int_icons_gm_evt_clear_page_settings clear_page_settings
  def clear_page_settings(*args, &block)
    # // Method to clear page settings for the event.
    xail_int_icons_gm_evt_clear_page_settings(*args, &block)
    @icon, @icon_index = false, 0
  end
    
end # END OF FILE

#=*==========================================================================*=#
# ** END OF FILE
#=*==========================================================================*=#