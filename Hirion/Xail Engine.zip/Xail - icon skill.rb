#==============================================================================
#   XaiL System - Icon Skill
#   Author: Nicke
#   Created: 11/04/2012
#   Edited: 11/04/2012
#   Version: 1.0
#==============================================================================
# Instructions
# -----------------------------------------------------------------------------
# To install this script, open up your script editor and copy/paste this script
# to an open slot below ? Materials but above ? Main. Remember to save.
#
# This script changes the skill list to display icons as skills instead.
# There is also a category feature which allows you to change the background
# color of each skill.
#
# Right now there is a setup of 3 categories one being the default one.
# You can easily edit the draw_skill_rect method to add new ones.
#
# To setup a category for a skill use the following code in the note field:
# <category fire> 
# or
# <category ice>
# The above will only work if you did not edit the category list.
#
# *** Only for RPG Maker VX Ace. ***
#==============================================================================
($imported ||= {})["XAIL-ICON-SKILL"] = true
module XAIL
  module ICON_SKILL
  #--------------------------------------------------------------------------#
  # * Settings
  #--------------------------------------------------------------------------#
    # FONT = [name, size, color, bold, shadow]
    FONT = [["Anklada�", "Verdana"], 16, Color.new(255,225,255), true, true]
    
    # Show/hide option for the item scene.
    # DISPLAY = [show_help_icon, show_name, show_description]
    DISPLAY = [false, true, true]
    
    # If this is false every item will have the same default black color.
    # NO_CATEGORIES = true/false
    NO_CATEGORIES = true
    
  end
end
# *** Don't edit below unless you know what you are doing. ***
#==============================================================================#
# ** Window_Help
#==============================================================================#
class Window_Help < Window_Base
  
  def set_skill_help(item)
    # // Method to set the item for window help.
    contents.font.name = XAIL::ICON_SKILL::FONT[0]
    contents.font.bold = XAIL::ICON_SKILL::FONT[3]
    contents.font.shadow = XAIL::ICON_SKILL::FONT[4]
    contents.font.out_color = Color.new(0,0,0,255)
    if item
      icon = XAIL::ICON_SKILL::DISPLAY[0] ? '\i[' + item.icon_index.to_s + ']' : ""
      name = XAIL::ICON_SKILL::DISPLAY[1] ? '\c[2] �� ' + item.name + '\c[0]' : ""
      desc = XAIL::ICON_SKILL::DISPLAY[2] ? item.description : ""
      new_line = "\n"
      item_text = icon + name + new_line + desc
    else
      item_text = ""
    end
    set_text(item_text)
  end
  
end
#==============================================================================#
# ** Window_SkillList_Icon
#==============================================================================#
class Window_SkillList_Icon < Window_SkillList

  def col_max
    # // Method to get col_max.
    return 14
  end

  def spacing
    # // Method to get spacing.
    return 14
  end
  
  def item_width
    # // Method to get item_width.
    return 24
  end
  
  def item_height
    # // Method to get item_height.
    return 24
  end 
  
  def row_max
    # // Method to get row_max.
    return item_max
  end

  def update_help
    # // Method to update help details.
    @help_window.set_skill_help(item)
  end
  
  def item_rect(index)
    # // Method to draw item rect.
    rect = Rect.new
    rect.width = item_width
    rect.height = item_height
    rect.x = index % col_max * (item_width + spacing)
    rect.y = index / col_max * (item_height + 3)
    rect
  end
  
  def page_row_max
    # // Method to define page row max.
    return 1
  end
  
  def scan_skills(skill)
    # // Method to scan the notes for the items.
    skill.note.scan(/<category[:]*\s*(.+)>/i)
    return $1 if !$1.nil?
  end

  def draw_item(index)
    # // Method override to draw item.
    skill = @data[index]
    if skill
      rect = item_rect(index) 
      draw_skill_rect(index, skill, rect, rect.x, rect.y)
      draw_skill_cost(rect, skill)
    end
  end

  def draw_skill_cost(rect, skill)
    # // Method to draw skill cost.
    rect.y += 8
    contents.font = Font.new(XAIL::ICON_SKILL::FONT[0], XAIL::ICON_SKILL::FONT[1])
    check_color(XAIL::ICON_SKILL::FONT[2], enable?(item))
    contents.font.bold = XAIL::ICON_SKILL::FONT[3]
    contents.font.shadow = XAIL::ICON_SKILL::FONT[4]
    contents.font.out_color = Color.new(0,0,0,255)
    if @actor.skill_tp_cost(skill) > 0
      change_color(tp_cost_color, enable?(skill))
      draw_text(rect, @actor.skill_tp_cost(skill), 1)
    elsif @actor.skill_mp_cost(skill) > 0
      change_color(mp_cost_color, enable?(skill))
      draw_text(rect, @actor.skill_mp_cost(skill), 1)
    end
    reset_font_settings
  end
  
  def draw_skill_icon(icon_index, x, y, enabled = true)
    # // Method to draw icon.
    bitmap = Cache.system("Iconset")
    rect = Rect.new(icon_index % 16 * 24, icon_index / 16 * 24, 24, 24)
    contents.blt(x, y, bitmap, rect, enabled ? 255 : 75)
  end
  
  def draw_skill_rect(index, skill, rect, x, y)
    # // Method to draw rect.
    outline = rect.clone
    outline.width = rect.width + 1
    outline.height = rect.height + 1
    contents.fill_rect(outline,Color.new(255,255,255,80))
    if XAIL::ICON_SKILL::NO_CATEGORIES
      case scan_skills(skill)
      when "fire"
        color = Color.new(150,0,0,65)
      when "ice"
        color = Color.new(0,0,150,65)
      when nil 
        color = Color.new(0,0,0,128)
      else
        color = Color.new(0,0,0,128)
      end
    else
      color = Color.new(0,0,0,128)
    end
    color = enable?(skill) ? color : Color.new(0,0,0,128)
    contents.fill_rect(rect, color)
    draw_skill_icon(skill.icon_index, x + 1, y, enable?(skill))
  end
  
  def check_color(color, enabled = true)
     # // Method to set the color and alpha.
    contents.font.color.set(color)
    contents.font.color.alpha = 95 unless enabled
  end
  
end
#==============================================================================#
# ** Scene_Skill
#==============================================================================#
class Scene_Skill < Scene_ItemBase
  
  def create_item_window
    # // Method override create the item list window.
    wx = 0
    wy = @status_window.y + @status_window.height
    ww = Graphics.width
    wh = Graphics.height - wy
    @item_window = Window_SkillList_Icon.new(wx, wy, ww, wh)
    @item_window.actor = @actor
    @item_window.viewport = @viewport
    @item_window.help_window = @help_window
    @item_window.set_handler(:ok,     method(:on_item_ok))
    @item_window.set_handler(:cancel, method(:on_item_cancel))
    @command_window.skill_window = @item_window
  end
  
end # END OF FILE

#=*==========================================================================*=#
# ** END OF FILE
#=*==========================================================================*=#