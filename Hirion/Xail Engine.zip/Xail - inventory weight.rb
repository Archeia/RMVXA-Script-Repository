#==============================================================================
#   XaiL System - Inventory Weight
#   Author: Nicke
#   Created: 02/05/2012
#   Edited: 12/05/2012
#   Version: 1.0b
#==============================================================================
# Instructions
# -----------------------------------------------------------------------------
# To install this script, open up your script editor and copy/paste this script
# to an open slot below ? Materials but above ? Main. Remember to save.
#
# This script enables you to have a inventory weight.
# The max weight will increase based on level from default. This can be altered
# as you like. See the settings for more details about customizing that.
#
# From default an item's weight is 0.0 unless you specify it in the notetag like
# this:
# <WEIGHT|weight: number>
#
# Examples:
# <weight: 20.0>
# <WEIGHT: 40.0>
#
# At default if an item exists already it won't increase the weight again 
# so you can stack up an item to the default max value (99). This can be changed
# in the settings.
#
# The max weight will be 0 from start. To refresh it do the following in a 
# script call:
# $game_party.refresh_weight
#
# The standard methods from the event page will add an item as default.
# To add/remove an item with weight you need to use the following method
# in a script call:
# $game_party.weight_item(item, amount = 1, type = :item, weight_type = :gain)
#
# Examples:
# $game_party.weight_item(1)                   # // Add one of item_id 1 with type item.
# $game_party.weight_item(1, 2, :weapon)       # // Add 2 of item_id 1 with type weapon.
# $game_party.weight_item(1, 1, :armor, :lose) # // Remove one of item_id 1 with type armor.
# Note: With this you can go beyond 99 which is the default max if you are 
# using a script that enables you to stack up more then 99 items.
# You can use my script called XS - Hero Control for that.
# However, my script uses a variable to change the stack for the items and it's
# not so intuitive if you are gonna change alot of items.
#
# You can use a quick method to add/remove items as well in a script call:
# w_item(25, 5)
# w_item(1, 2, :armor, :lose)
# Using this method is recommened because it's easier to read and it fits better.
#
# To check the current weight as well as the max weight do the following in a
# script call:
# $game_party.weight
# $game_party.max_weight
# Those can be used in a conditional branch etc for certain things.
# Warning: Don't try to use those methods to alter the max weight or weight
# because that will throw an error.
#
# *** Only for RPG Maker VX Ace. ***
#==============================================================================
($imported ||= {})["XAIL-INVENTORY-WEIGHT"] = true

module XAIL
  module INV_WEIGHT
  #--------------------------------------------------------------------------#
  # * Settings
  #--------------------------------------------------------------------------#     
      # Should weight be increased if you stack up items?
      # i.e if you have 2 or more of the same items.
      # STACK_WEIGHT = true/false
      STACK_WEIGHT = true
  
      # Max MAX_WEIGHT_TYPE = :symbol
      # :default = Increase max weight based on actor level.
      # :str     = Increase max_weight based on actor strength (atk).
      # :custom  = Increase max_weight based on custom parameters.
      MAX_WEIGHT_TYPE = :default
      
      # Formula for max weight based on level.
      def self.weight_level
        case $game_party.leader.level
        when 1..10  ; weight = 100.0
        when 11..19 ; weight = 200.0
        when 20..30 ; weight = 300.0
        when 31..40 ; weight = 400.0
        when 41..50 ; weight = 500.0
        end
        return weight
      end
      
      # Custom formula. Currently set to be based on actor's atk and agi 
      # divided by 2.
      # Choose what you like in here. 
      # Note: Don't use if you are not familiar with how parameters work.
      def self.weight_custom
        $game_party.leader.atk.to_f + $game_party.leader.agi.to_f / 2.0
      end
      
      # Enable this if you want the player to be able to get encumbered.
      # For example: At 50% of current weight the actor will run/walk at a 
      # decreased speed until an item is consumed or sold/dropped.
      # At 90% of total weight the dashing option is not enabled as well.
      # USE_ENCUMBER = true/false
      USE_ENCUMBER = true 
      
      # This decides the actor's move speed if USE_ENCUMBER is enabled.
      # Explaination:
      # At 50% the movement speed is decreased to 3.8.
      # At 75% the movement speed is decreased to 3.4.
      # At 90% the movement speed is decreased to 3.2.
      # At 95% the movement speed is decreased to 3.0.
      # Under 50% the movement speed is set to default.
      def self.encumber_speed(weight, max, default)
        $game_player.move_speed = 3.8 if weight >= max * 0.50
        $game_player.move_speed = 3.4 if weight >= max * 0.75
        $game_player.move_speed = 3.2 if weight >= max * 0.90
        $game_player.move_speed = 3.0 if weight >= max * 0.95
        $game_player.move_speed = default if weight <= max * 0.50
      end
  end
end
# *** Don't edit below unless you know what you are doing. ***
#==============================================================================#
# ** RPG::BaseItem
#==============================================================================#
class RPG::BaseItem
  
  def weight
    # // Method to set a item weight.
    @note.scan(/<(?:WEIGHT|weight):\s(\d+.\d+)>/i)
    return ($1.to_f > 0.0 ? $1.to_f : 0.0)
  end

end
#==============================================================================#
# ** Game_Party
#==============================================================================#
class Game_Party < Game_Unit
  
  attr_reader :weight
  attr_reader :max_weight
  
  alias xail_item_weight_sys_init initialize
  def initialize(*args, &block)
    # // Method to initialize.
    xail_item_weight_sys_init(*args, &block)
    @weight = 0.0
    @max_weight = 0.0
  end
  
  def refresh_weight
    # // Method to refresh the max weight.
    @max_weight = max_weight? unless leader.nil?
  end
  
  def max_weight?
    # // Method to check the max weight.
    case XAIL::INV_WEIGHT::MAX_WEIGHT_TYPE
    when :default ; return @max_weight = XAIL::INV_WEIGHT.weight_level
    when :str     ; return @max_weight = leader.atk.to_f
    when :custom  ; return @max_weight = XAIL::INV_WEIGHT.weight_custom
    end
  end
  
  def weight_item(item, amount = 1, type = :item, weight_type = :gain)
    # // Method to gain an item with weight.
    case type
    when :item   ; type = $data_items
    when :weapon ; type = $data_weapons
    when :armor  ; type = $data_armors
    end
    item = type[item]
    case weight_type
    when :gain
      # // Gain: Increase the current weight.
      unless item.nil?
        unless XAIL::INV_WEIGHT::STACK_WEIGHT
          unless has_item?(type[item.id])
            @weight += item.weight
          end
        else
          @weight += item.weight
        end
        if @weight > max_weight?
          return @weight -= item.weight
        end
        gain_item(item, amount, false)
      end
    when :lose
      # // Lose: Decrease the current weight.
      return unless has_item?(type[item.id])
      unless item.nil?
        unless XAIL::INV_WEIGHT::STACK_WEIGHT
          unless has_item?(type[item.id])
            @weight -= item.weight unless @weight <= 0.0
          end
          if item_number(item) < 2
            @weight -= item.weight unless @weight <= 0.0
          end
        else
          @weight -= item.weight unless @weight <= 0.0
        end
        gain_item(item, -amount, false)
      end
    end
  end
  
end
#==============================================================================#
# ** Game_Player
#==============================================================================#
class Game_Player < Game_Character
  
  attr_accessor :move_speed
  
  alias xail_item_weight_game_player_init initialize
  def initialize
    # // Method to initialize game player.
    @weight = $game_party.weight
    @max_weight = $game_party.max_weight
    xail_item_weight_game_player_init
    @default_move_speed = @move_speed.to_f
  end
  
  alias xail_item_weight_game_player_dash? dash?
  def dash?
    # // Method to check if player can dash.
    return false if $game_party.weight >= $game_party.max_weight * 0.90 if XAIL::INV_WEIGHT::USE_ENCUMBER
    xail_item_weight_game_player_dash?
  end
  
  alias xail_item_weight_game_player_update update
  def update
    # // Method to refresh game player.
    if XAIL::INV_WEIGHT::USE_ENCUMBER
      if @weight != $game_party.weight
        @weight = $game_party.weight
        @max_weight = $game_party.max_weight
        XAIL::INV_WEIGHT.encumber_speed(@weight, @max_weight, @default_move_speed)
      end
    end 
    xail_item_weight_game_player_update
  end

end
#==============================================================================#
# ** Game_Interpreter
#==============================================================================#
class Game_Interpreter

  def w_item(item, amount = 1, type = :item, weight_type = :gain)
    # // Quick method to add/remove an item with weight.
    $game_party.weight_item(item, amount, type, weight_type)
  end
  
end # END OF FILE

#=*==========================================================================*=#
# ** END OF FILE
#=*==========================================================================*=#