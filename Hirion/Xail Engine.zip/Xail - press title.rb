#==============================================================================
#   XS - Press Title
#   Author: Nicke
#   Created: 04/11/2012
#   Edited: 05/11/2012
#   Version: 1.0
#==============================================================================
# Instructions
# -----------------------------------------------------------------------------
# To install this script, open up your script editor and copy/paste this script
# to an open slot below ? Materials but above ? Main. Remember to save.
#
# Press start title script.
# This will enables a "Press Start" text before the actual title scene.
# Like oldschool RPGs had.
#
# *** Only for RPG Maker VX Ace. ***
#==============================================================================
($imported ||= {})["XAIL-PRESS-TITLE"] = true

module XAIL
  module PRESS_TITLE
  #--------------------------------------------------------------------------#
  # * Settings
  #--------------------------------------------------------------------------#
    # FONT = [name, size, color, bold, shadow]
    FONT = [["Verdana"], 32, Color.new(255,255,255), true, true]
    
    # Setup the text here.
    # TEXT = [name, x, y]
    TEXT = ["-PRESS START-", 154, 90]
    
    # The button to enter the title scene.
    # BUTTON = :symbol
    BUTTON = :C
    
    # Goto scene.
    SCENE = Scene_Title
    
    # Blink delay.
    # BLINK = [blink_in, blink_out]
    BLINK = [40, 40]
    
    # Skip this scene?
    # SKIP = true/false
    SKIP = false
    
  end
end
# *** Don't edit below unless you know what you are doing. ***
#==============================================================================#
# ** SceneManager
#==============================================================================#
class << SceneManager

  alias xail_press_title_scenemanager_first_scene_class first_scene_class
  def first_scene_class(*args, &block)
    # // Method for first scene class.
    return xail_press_title_scenemanager_first_scene_class(*args, &block) if XAIL::PRESS_TITLE::SKIP
    $BTEST ? Scene_Battle : Scene_Press_Title
  end
  
end 
#==============================================================================#
# ** Scene_Press_Title
#==============================================================================#
class Scene_Press_Title < Scene_Base
  
  def initialize
    # // Method to initialize the scene.
    play_title_music
    create_background
    display_text
  end
  
  def update
    # // Method to update the scene.
    super
    goto_scene
  end
  
  def delay?(amount)
    # // Method to delay.
    return if Input.trigger?(XAIL::PRESS_TITLE::BUTTON)
    if amount.nil?
      loop do
        update_basic        
        break if Input.trigger?(XAIL::PRESS_TITLE::BUTTON)
      end
    else
      amount.times do
        update_basic        
        break if Input.trigger?(XAIL::PRESS_TITLE::BUTTON)
      end
    end  
  end
  
  def center_sprite(sprite)
    # // Method to center a sprite.
    sprite.ox = sprite.bitmap.width / 2
    sprite.oy = sprite.bitmap.height / 2
    sprite.x = Graphics.width / 2
    sprite.y = Graphics.height / 2
  end
  
  def create_background
    # // Method to create the title background.
    @sprite1 = Sprite.new
    @sprite1.bitmap = Cache.title1($data_system.title1_name)
    @sprite2 = Sprite.new
    @sprite2.bitmap = Cache.title2($data_system.title2_name)
    center_sprite(@sprite1)
    center_sprite(@sprite2)
  end
  
  def display_text
    # // Method to display the "press enter" text.
    text = XAIL::PRESS_TITLE::TEXT
    t = Sprite.new 
    t.z = 5000
    t.bitmap = Bitmap.new(Graphics.width, Graphics.height)
    t.bitmap.font.name = XAIL::PRESS_TITLE::FONT[0]
    t.bitmap.font.size = XAIL::PRESS_TITLE::FONT[1]
    t.bitmap.font.color = XAIL::PRESS_TITLE::FONT[2]
    t.bitmap.font.bold = XAIL::PRESS_TITLE::FONT[3]
    t.bitmap.font.shadow = XAIL::PRESS_TITLE::FONT[4]
    t.bitmap.draw_text(text[1], text[2], Graphics.width, Graphics.height, text[0]) 
    loop do
      break if Input.trigger?(XAIL::PRESS_TITLE::BUTTON)
      update_basic
      t.opacity = 255
      delay?(XAIL::PRESS_TITLE::BLINK[0])
      t.opacity = 0
      delay?(XAIL::PRESS_TITLE::BLINK[1])
    end
    t = nil, t.dispose unless t.nil?
  end
  
  def goto_scene
    # // Method to go to specified scene.
    SceneManager.goto(XAIL::PRESS_TITLE::SCENE)
  end
  
  def play_title_music
    # // Method to play the title music.
    $data_system.title_bgm.play
    RPG::BGS.stop
    RPG::ME.stop
  end
  
end
#==============================================================================#
# ** Scene_Title
#==============================================================================#
class Scene_Title < Scene_Base

  def play_title_music
    # // Override title music for original scene.
  end
  
end # END OF FILE

#=*==========================================================================*=#
# ** END OF FILE
#=*==========================================================================*=#