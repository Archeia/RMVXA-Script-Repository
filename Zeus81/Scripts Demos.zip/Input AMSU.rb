﻿# Input AMSU v2.0
class Game_Player
  def update_inputs
    @analog_move = nil unless moving?
    unless moving? or $game_system.map_interpreter.running? or
      @move_route_forcing or $game_temp.message_window_showing
      analog_move(*Input.dirXY)
      unless new_jumping?
        @dash = (Input.press?(Dash_Input) and Input.dir8 != 0)
        new_jump if Input.trigger?(Jump_Input)
      end
    end
  end
  def update_move
    if @analog_move
      @trails.push([3]) if special_trail_activate
      distance = 2 ** (@real_move_speed * @analog_move.max)
      @y2 = Math.max(@y2-distance, @y*128) if @y2 > @y*128 and !passable?(@x, @y, 2)
      @x2 = Math.min(@x2+distance, @x*128) if @x2 < @x*128 and !passable?(@x, @y, 4)
      @x2 = Math.max(@x2-distance, @x*128) if @x2 > @x*128 and !passable?(@x, @y, 6)
      @y2 = Math.min(@y2+distance, @y*128) if @y2 < @y*128 and !passable?(@x, @y, 8)
      @real_y = Math.min(@real_y+distance, @y2) if @y2 > @real_y
      @real_x = Math.max(@real_x-distance, @x2) if @x2 < @real_x
      @real_x = Math.min(@real_x+distance, @x2) if @x2 > @real_x
      @real_y = Math.max(@real_y-distance, @y2) if @y2 < @real_y
      @dash &&= @analog_move.max > 0.8
      unless new_jumping? or @phase == 6
        @phase = @dash ? 3 : 2
        @anime_count += (@walk_anime ? 1.5 : @step_anime ? 1 : 0)
      end
    else super
    end
  end
  def analog_move(x, y)
    @analog_move = [x.abs**0.5, y.abs**0.5]
    move_right(false, @real_move_speed * @analog_move[0]) if x > 0
    move_left(false, @real_move_speed * @analog_move[0]) if x < 0
    move_down(false, @real_move_speed * @analog_move[1]) if y < 0
    move_up(false, @real_move_speed * @analog_move[1]) if y > 0
    case @direction_max == 4 ? Input.dir4 : Input.dir8
    when 1; turn_lower_left
    when 2; turn_down
    when 3; turn_lower_right
    when 4; turn_left
    when 6; turn_right
    when 7; turn_upper_left
    when 8; turn_up
    when 9; turn_upper_right
    end
  end
  def analog_speed
    return 0 unless @phase == 2 or @phase == 3
    (@analog_move ? @analog_move.max : 1) * @real_move_speed
  end
end