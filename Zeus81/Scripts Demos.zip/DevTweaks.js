﻿//=============================================================================
// DevTweaks.js v1.0.2 by Zeus81
// Free for commercial use
// License MIT
// Copyright (c) 2015 zeusex81@gmail.com
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.
//=============================================================================

/*:
 * @plugindesc Tweak stuff of the game engine.
 * Version: 1.0.2, License: MIT
 * @author Zeus81, Contact: zeusex81(a)gmail.com
 *
 * @param Start Fullscreen
 * @desc 0:no, 1:yes
 * Doesn't work on web browser.
 * @default 0
 *
 * @param Stretch Mode
 * @desc -1:default, 0:no, 1:yes
 * default = no on web browser, yes otherwise
 * @default -1
 *
 * @param Disable F3/F4
 * @desc 0:no, 1:yes
 * If you want to manage stretch/fullscreen yourself.
 * @default 0
 *
 * @param Disable F2/F5/F8
 * @desc 0:no, 1:yes
 * Maybe players don't need fps/reset/console ?
 * @default 0
 *
 * @param Test Mode
 * @desc -1:default, 0:no, 1:yes
 * default = yes when the game is launched from RMMV editor
 * @default -1
 *
 * @param Show FPS
 * @desc -1:default, 0:no, 1:yes
 * default = yes if we write '?showfps' in the url
 * @default -1
 *
 * @param Show Console
 * @desc 0:no, 1:yes
 * @default 0
 *
 * @param Show Plugins Errors
 * @desc 0:no, 1:yes
 * This plugin must be placed first to be effective.
 * @default 0
 *
 * @param Renderer Type
 * @desc -1:default, 0:auto, 1:canvas, 2:webgl
 * default = canvas on mobile device, auto otherwise
 * @default -1
 *
 * @param Mute On Hide
 * @desc -1:default, 0:no, 1:yes
 * default = yes on mobile device, no otherwise
 * @default -1
 *
 * @param Audio API
 * @desc -1:default, 0:WebAudio, 1:Html5Audio
 * default = Html5Audio on Android, WebAudio otherwise
 * @default -1
 *
 * @param Audio Extension
 * @desc -1:default, 0:m4a/ogg, 1:ogg/m4a, or write it (ex .m4a)
 * default = m4a on mobile device, ogg/m4a otherwise
 * @default -1
 *
 * @param Video Extension
 * @desc -1:default, 0:mp4/webm, 1:webm/mp4, or write it (ex .mp4)
 * default = mp4 on mobile device, webm/mp4 otherwise
 * @default -1
 *
 * @help If you play on web browser you must know that RMMV allows some settings
 * in the url. For example we can add '?test' to run in test mode.
 * That's why you should force Test Mode to 'no' before releasing.
 */

/*:fr
 * @plugindesc Sert à configurer des paramètres du moteur.
 * Version: 1.0.2, License: MIT
 * @author Zeus81, Contact: zeusex81(a)gmail.com
 *
 * @param Start Fullscreen
 * @desc 0:non, 1:oui
 * Ne marche pas sur navigateur.
 * @default 0
 *
 * @param Stretch Mode
 * @desc -1:défaut, 0:non, 1:oui
 * défaut = non sur navigateur, oui autrement
 * @default -1
 *
 * @param Disable F3/F4
 * @desc 0:non, 1:oui
 * Si vous voulez gérer les stretch/fullscreen manuellement.
 * @default 0
 *
 * @param Disable F2/F5/F8
 * @desc 0:non, 1:oui
 * Les joueurs n'ont pas besoin des fps/reset/console ?
 * @default 0
 *
 * @param Test Mode
 * @desc -1:défaut, 0:non, 1:oui
 * défaut = oui quand le jeu est lancé depuis RMMV
 * @default -1
 *
 * @param Show FPS
 * @desc -1:défaut, 0:non, 1:oui
 * défaut = oui si on écrit '?showfps' dans l'url
 * @default -1
 *
 * @param Show Console
 * @desc 0:non, 1:oui
 * @default 0
 *
 * @param Show Plugins Errors
 * @desc 0:non, 1:oui
 * Ce plugin doit être placé en premier pour que ça marche.
 * @default 0
 *
 * @param Renderer Type
 * @desc -1:défaut, 0:auto, 1:canvas, 2:webgl
 * défaut = canvas sur smartphone, auto autrement
 * @default -1
 *
 * @param Mute On Hide
 * @desc -1:défaut, 0:non, 1:oui
 * défaut = oui sur smartphone, non autrement
 * @default -1
 *
 * @param Audio API
 * @desc -1:défaut, 0:WebAudio, 1:Html5Audio
 * défaut = Html5Audio sur Android, WebAudio autrement
 * @default -1
 *
 * @param Audio Extension
 * @desc -1:défaut, 0:m4a/ogg, 1:ogg/m4a, ou l'écrire (ex .m4a)
 * défaut = m4a sur smartphone, ogg/m4a autrement
 * @default -1
 *
 * @param Video Extension
 * @desc -1:défaut, 0:mp4/webm, 1:webm/mp4, ou l'écrire (ex .mp4)
 * défaut = mp4 sur smartphone, webm/mp4 autrement
 * @default -1
 *
 * @help Si vous jouez sur navigateur vous devez savoir que RMMV permet de configurer
 * certains paramètres dans l'url.
 * Par exemple on peut ajouter '?test' pour démarrer en mode test.
 * C'est pourquoi il est préférable de forcer Test Mode sur 'non' avant de
 * distribuer le jeu.'
 */
 
function DevTweaks() {
    throw new Error('This is a static class');
}
DevTweaks.initialize = function () {
	var parameters			= PluginManager.parameters('DevTweaks');
	this.fullscreen			= !!Number(parameters['Start Fullscreen']);
	this.stretchMode		= Number(parameters['Stretch Mode']);
	this.disableF3F4		= !!Number(parameters['Disable F3/F4']);
	this.disableF2F5F8		= !!Number(parameters['Disable F2/F5/F8']);
	this.test				= Number(parameters['Test Mode']);
	this.showFPS			= Number(parameters['Show FPS']);
	this.showConsole		= !!Number(parameters['Show Console']);
	this.showPluginsErrors	= !!Number(parameters['Show Plugins Errors']);
	this.rendererType		= Number(parameters['Renderer Type']);
	this.muteOnHide			= Number(parameters['Mute On Hide']);
	this.useHtml5Audio		= Number(parameters['Audio API']);
	this.audioFileExt		= parameters['Audio Extension'];
	this.videoFileExt		= parameters['Video Extension'];
	if(this.audioFileExt.substr(0,1) != '.') this.audioFileExt = Number(this.audioFileExt);
	if(this.videoFileExt.substr(0,1) != '.') this.videoFileExt = Number(this.videoFileExt);
	if(this.fullscreen) Graphics._requestFullScreen();
	if(this.showConsole && Utils.isNwjs()) {
		var win = require('nw.gui').Window.get();
		var csl = win.showDevTools();
		csl.x = 0;
		csl.width = 500;
		win.focus();
	}
};
DevTweaks.initialize();

Utils.zeus_DevTweaks_isOptionValid = Utils.isOptionValid;
Utils.isOptionValid = function(name) {
	switch(name) {
	case 'canvas':
		if(DevTweaks.rendererType != -1) return DevTweaks.rendererType == 1;
		break;
	case 'webgl':
		if(DevTweaks.rendererType != -1) return DevTweaks.rendererType == 2;
		break;
	case 'showfps':
		if(DevTweaks.showFPS != -1) return !!DevTweaks.showFPS;
		break;
	case 'test':
		if(DevTweaks.test != -1) return !!DevTweaks.test;
		break;
	case 'btest':
	case 'etest':
		if(DevTweaks.test == 0) return false;
		break;
	}
	return this.zeus_DevTweaks_isOptionValid(name);
};

Graphics.zeus_DevTweaks_defaultStretchMode = Graphics._defaultStretchMode;
Graphics._defaultStretchMode = function() {
	if(DevTweaks.stretchMode != -1) return !!DevTweaks.stretchMode;
	return this.zeus_DevTweaks_defaultStretchMode();
};

Graphics.zeus_DevTweaks_onKeyDown = Graphics._onKeyDown;
Graphics._onKeyDown = function(event) {
    if (!event.ctrlKey && !event.altKey) {
        switch (event.keyCode) {
        case 113:   // F2
			if(DevTweaks.disableF2F5F8) return;
            break;
        case 114:   // F3
        case 115:   // F4
			if(DevTweaks.disableF3F4) return;
            break;
        }
    }
	this.zeus_DevTweaks_onKeyDown(event);
};

WebAudio.zeus_DevTweaks_shouldMuteOnHide = WebAudio._shouldMuteOnHide;
WebAudio._shouldMuteOnHide = function() {
	if(DevTweaks.muteOnHide != -1) return !!DevTweaks.muteOnHide;
	return this.zeus_DevTweaks_shouldMuteOnHide();
};

AudioManager.zeus_DevTweaks_shouldUseHtml5Audio = AudioManager.shouldUseHtml5Audio;
AudioManager.shouldUseHtml5Audio = function() {
	if(DevTweaks.useHtml5Audio != -1) return !!DevTweaks.useHtml5Audio;
    return this.zeus_DevTweaks_shouldUseHtml5Audio();
};

AudioManager.zeus_DevTweaks_audioFileExt = AudioManager.audioFileExt;
AudioManager.audioFileExt = function() {
	switch(DevTweaks.audioFileExt) {
	case -1: return this.zeus_DevTweaks_audioFileExt();
	case  0: return WebAudio.canPlayM4a() ? '.m4a' : '.ogg';
	case  1: return WebAudio.canPlayOgg() ? '.ogg' : '.m4a';
	default: return DevTweaks.audioFileExt;
	}
};

SceneManager.zeus_DevTweaks_shouldUseCanvasRenderer = SceneManager.shouldUseCanvasRenderer;	
SceneManager.shouldUseCanvasRenderer = function() {
	if(DevTweaks.rendererType == 0) return false;
	return this.zeus_DevTweaks_shouldUseCanvasRenderer();
};

SceneManager.zeus_DevTweaks_onKeyDown = SceneManager.onKeyDown;	
SceneManager.onKeyDown = function(event) {
    if (!event.ctrlKey && !event.altKey) {
        switch (event.keyCode) {
        case 116:   // F5
        case 119:   // F8
			if(DevTweaks.disableF2F5F8) return;
            break;
        }
    }
	this.zeus_DevTweaks_onKeyDown(event);
};

Game_Interpreter.prototype.zeus_DevTweaks_videoFileExt = Game_Interpreter.prototype.videoFileExt;
Game_Interpreter.prototype.videoFileExt = function() {
	switch(DevTweaks.videoFileExt) {
	case -1: return this.zeus_DevTweaks_videoFileExt();
	case  0: return Graphics.canPlayVideoType('video/mp4')  ? '.mp4' : '.webm';
	case  1: return Graphics.canPlayVideoType('video/webm') ? '.webm' : '.mp4';
	default: return DevTweaks.videoFileExt;
	}
};

if(DevTweaks.showPluginsErrors) {
	PluginManager._errors = [];
	PluginManager.zeus_DevTweaks_checkErrors = PluginManager.checkErrors;
	PluginManager.checkErrors = function() {
		this.zeus_DevTweaks_checkErrors();
		var e = this._errors.shift();
		if(e) throw e;
	};
	window.addEventListener('error', function(e) {PluginManager._errors.push(e.error)});
}