This library is used for Collision Maps and Collision Maps Overlay scripts.
You must place this in your project's System folder.

Hime
http://himeworks.wordpress.com/