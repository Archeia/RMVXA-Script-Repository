#==============================================================================
#   XS - Status Delux
#   Author: Nicke
#   Created: 05/08/2012
#   Edited: 30/12/2012
#   Version: 1.0c
#==============================================================================
# Instructions
# -----------------------------------------------------------------------------
# To install this script, open up your script editor and copy/paste this script
# to an open slot below ? Materials but above ? Main. Remember to save.

# This script changes the status scene to a more delux version.
# There are a few settings but bascially this is just a plug and play script.
#
# *** Only for RPG Maker VX Ace. ***
#==============================================================================
($imported ||= {})["XAIL-STATUS-DELUX"] = true

module XAIL
  module STATUS_DELUX
  #--------------------------------------------------------------------------#
  # * Settings
  #--------------------------------------------------------------------------#
    # FONT = [name, size, color, bold, shadow]
    FONT = [["Anklada�","Verdana"], 20, Color.new(255,255,255), true, true]
    
    # BAR_COLOR = rgba(255,255,255,255)
    # Set the color of the bars.
    BAR_COLOR = [Color.new(100,100,40,180), Color.new(200,200,200,180)]
    BAR_HP = [Color.new(225,50,50,64), Color.new(235,75,75,175)]
    BAR_MP = [Color.new(50,50,225,64), Color.new(75,75,235,175)]
    
    # LINE_COLOR = rgba(255,255,255,255)
    # Set the color of the horizontal line.
    LINE_COLOR = [Color.new(255,255,255,200), Color.new(0,0,0,128)]
    
    # LIST_ICONS[id] = icon_id
    # Set the param icon_id. (optional)
    ICONS = []
    ICONS[0] = 4149 # HP
    ICONS[1] = 4132 # MP
    ICONS[2] = 4138 # EXP
    ICONS[3] = 4145 # ATK
    ICONS[4] = 4150 # DEF
    ICONS[5] = 4147 # MAGIC
    ICONS[6] = 4148 # RES
    ICONS[7] = 4140 # AGL
    ICONS[8] = 4131 # LUK

  end
end
# *** Don't edit below unless you know what you are doing. ***
#==============================================================================#
# ** Error Handler
#==============================================================================#
  unless $imported["XAIL-XS-CORE"]
    # // Error handler when XS - Core is not installed.
    msg = "The script %s requires the latest version of XS - Core in order to function properly."
    name = "XS - Status Delux"
    msgbox(sprintf(msg, name))
    exit
  end
#==============================================================================#
# ** Window_Status
#==============================================================================#
class Window_Status < Window_Selectable

  def refresh
    # // Method to refresh.
    contents.clear
    # // Draw icons.
    draw_icons(XAIL::STATUS_DELUX::ICONS, :vertical, 0, line_height * 2, [4138,4145])
    # // Draw actor details.
    # // If XS - Fame System is imported.
    if $imported["XAIL-FAME-SYSTEM"]
      if XAIL::FAME_SYS::REPLACE_NICKNAME
         draw_fame(0, line_height * 0, contents_width, 1, XAIL::STATUS_DELUX::FONT[0], XAIL::STATUS_DELUX::FONT[1], true)
        draw_font_text(@actor.name, 0, line_height * 0, 200, 0, XAIL::STATUS_DELUX::FONT[0], 22, XAIL::STATUS_DELUX::FONT[2])
      else  
        draw_font_text(@actor.name + " " + @actor.nickname, 0, line_height * 0, 200, 0, XAIL::STATUS_DELUX::FONT[0], 22, XAIL::STATUS_DELUX::FONT[2])
      end
    end
    draw_font_text(@actor.class.name, 0, line_height * 0, contents.width, 2, XAIL::STATUS_DELUX::FONT[0], 22, XAIL::STATUS_DELUX::FONT[2])
    # // Draw line.
    draw_line_ex(48, line_height * 1, XAIL::STATUS_DELUX::LINE_COLOR[0], XAIL::STATUS_DELUX::LINE_COLOR[1])
    # // Draw actor face, level, stats and icons.
    draw_actor_face(@actor, 420, line_height * 2)
    if $imported["XAIL-LVL-TITLE"]
      lvl = "#{Vocab::level_a}: #{draw_title_level(@actor)}"
    else
      lvl = "#{Vocab::level_a}: #{@actor.level}  /  #{@actor.max_level}"
    end
    draw_font_text(lvl, 240, line_height * 2, 180, 0, XAIL::STATUS_DELUX::FONT[0], 20, XAIL::STATUS_DELUX::FONT[2])
    draw_actor_icons(@actor, 240, line_height * 3)
    draw_actor_stats(@actor, :hp, 20, line_height * 2, XAIL::STATUS_DELUX::BAR_HP[0], XAIL::STATUS_DELUX::BAR_HP[1])
    draw_actor_stats(@actor, :mp, 20, line_height * 3, XAIL::STATUS_DELUX::BAR_MP[0], XAIL::STATUS_DELUX::BAR_MP[1])
    draw_exp_info(20, line_height * 4)
    # // Draw line.
    draw_line_ex(-48, line_height * 6, XAIL::STATUS_DELUX::LINE_COLOR[0], XAIL::STATUS_DELUX::LINE_COLOR[1])
    # // Draw actor parameters.
    draw_parameters(20, line_height * 7)
    # // Draw actor equipment.
    draw_equipments(240, line_height * 7)
    # // Draw line.
    draw_line_ex(48, line_height * 13, XAIL::STATUS_DELUX::LINE_COLOR[0], XAIL::STATUS_DELUX::LINE_COLOR[1])
    # // Draw actor description.
    draw_description(4, line_height * 14)
  end
  
 def draw_actor_stats(actor, stat, x, y, color1, color2, width = 200)
    # // Method to draw actor hp & mp.
    case stat
    when :hp
      rate = actor.hp_rate
      vocab = Vocab::hp_a
      values = [actor.hp, actor.mhp]
    when :mp
      rate = actor.mp_rate
      vocab = Vocab::mp_a
      values = [actor.mp, actor.mmp]
    end
    contents.font.name = XAIL::STATUS_DELUX::FONT[0]
    contents.font.size = 16 # // Override font size.
    contents.font.color = XAIL::STATUS_DELUX::FONT[2]
    contents.font.bold = XAIL::STATUS_DELUX::FONT[3]
    contents.font.shadow = XAIL::STATUS_DELUX::FONT[4]
    draw_gauge_ex(x, y - 14, width, 20, rate, color1, color2)
    draw_text(x, y, width, line_height, vocab, 1)
    draw_current_and_max_values_ex(x - 8, y, width, values[0], values[1],
    XAIL::STATUS_DELUX::FONT[2], XAIL::STATUS_DELUX::FONT[2])
    reset_font_settings
  end
    
  def draw_current_and_max_values_ex(x, y, width, current, max, color1, color2)
    # // Method to draw current and max values.
    change_color(color1)
    xr = x + width
    if width < 96
      draw_text(xr - 40, y, 42, line_height, current, 0)
    else
      draw_text(32, y, 42, line_height, current, 0)
      change_color(color2)
      draw_text(xr - 36, y, 42, line_height, max, 2)
    end
  end

  def draw_parameters(x, y)
    # // Method to draw actor parameters.
    font = XAIL::STATUS_DELUX::FONT[0]
    size = 16 # // Override font size.
    c1 = XAIL::STATUS_DELUX::BAR_COLOR[0]
    c2 = XAIL::STATUS_DELUX::BAR_COLOR[1]
    c3 = XAIL::STATUS_DELUX::FONT[2]
    c4 = c3
    6.times {|i| draw_actor_param_gauge(@actor, x, y + line_height * i, 200, i + 2, font, size, c1, c2, c3, c4) }
  end

  def draw_exp_info(x, y)
    # // Method to draw exp info.
    s1 = @actor.max_level? ? "?" : @actor.exp
    s2 = @actor.max_level? ? "?" : @actor.next_level_exp - @actor.exp
    param_rate = @actor.exp / @actor.next_level_exp.to_f
    contents.font.name = XAIL::STATUS_DELUX::FONT[0]
    contents.font.size = 16
    contents.font.color = XAIL::STATUS_DELUX::FONT[2]
    contents.font.bold = XAIL::STATUS_DELUX::FONT[3]
    contents.font.shadow = XAIL::STATUS_DELUX::FONT[4]
    draw_gauge_ex(x, y + 8, 200, 20, param_rate, XAIL::STATUS_DELUX::BAR_COLOR[0], XAIL::STATUS_DELUX::BAR_COLOR[1])
    draw_text(x + 10, y + line_height, 200, line_height, s1, 0)
    draw_text(x, y + line_height, 200, line_height, "EXP", 1)
    draw_text(x - 1, y + line_height, 200, line_height, s2, 2)
    reset_font_settings
  end

  def draw_description(x, y)
    # // Method override to draw the description.
    contents.font.name = XAIL::STATUS_DELUX::FONT[0]
    contents.font.size = XAIL::STATUS_DELUX::FONT[1]
    contents.font.color = XAIL::STATUS_DELUX::FONT[2]
    contents.font.bold = XAIL::STATUS_DELUX::FONT[3]
    contents.font.shadow = XAIL::STATUS_DELUX::FONT[4]
    draw_text_ex(x, y, @actor.description)
    reset_font_settings
  end
  
end # END OF FILE

#=*==========================================================================*=#
# ** END OF FILE
#=*==========================================================================*=#