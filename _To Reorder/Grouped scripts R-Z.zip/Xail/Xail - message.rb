#==============================================================================
#   XS - Message
#   Author: Nicke
#   Created: 08/11/2012
#   Edited: 19/11/2012
#   Version: 1.0b
#==============================================================================
# Instructions
# -----------------------------------------------------------------------------
# To install this script, open up your script editor and copy/paste this script
# to an open slot below ? Materials but above ? Main. Remember to save.
#==============================================================================
# Requires: XS - Core Script.
#==============================================================================
# A message system based on using variables ingame.
# If the variable has the value 0 the default value will take place.
# To setup a simple message dialog do as you would normally do when adding
# text in events but before it set the variables you want to change.
#
# When changing width and height you should know that height is visible
# line numbers which means the numbers 1 to 4 is prefered to use. 
# 
# Example:
# You could set the width to 544 and height to 4 which is pretty much how
# the default message window looks like.
#
# This script also support sound effect to be played each time a character is
# processed. Can be tweaked in the settings.
#
# When setting variables for bold, shadow, namebox and skin etc. Remember to use
# the script area in the variable.
#
# If I wanted to enable bold and setting a custom skin I would do this:
# Set the value "true" in the script section for variable 41.
# Set the value "Window" in the script section for variable 44.
#
# Note: When changing the message window skin you must use this method after
# setting the variable in order to properly update to the new skin:
# SceneManager.scene.set_message_skin
#
# Example:
# So after setting variable 44 (default one) to "Window3" call that method.
#
# *** Only for RPG Maker VX Ace. ***
#==============================================================================
($imported ||= {})["XAIL-MESSAGE-SYSTEM"] = true

module XAIL
  module MSG
  #--------------------------------------------------------------------------#
  # * Settings
  #--------------------------------------------------------------------------#
    # Set the window variables.
    # WINDOW_VAR = [width, height, padding, x, y, delay, 
    # font_name, font_size, font_color, outline, bold, shadow, namebox, skin]
    WINDOW_VAR = [31,32,33,34,35,36,37,38,39,40,41,42,43,44]
    
    # Set the window open/close animation in frames.
    # WINDOW_ANIMATE = [openness, closeness]
    WINDOW_ANIMATE = [15, 15]
    
    # Name box options.
    # NAME = [font, size, color, bold, shadow]
    NAME = [["Verdana", "Anklada�"], 14, Color.new(255,225,235,225), true, true]
    
    # Set the sound for when the characters are processing.
    # The sound effect will be played each time the occurence is met.
    # From the default it will happen every odd processed character.
    # Can be set to nil to disable.
    # SE = [occurence, name, vol, pitch]
    SE = [2, "Decision1", 60, 150]
    
    # Set the animation options for face window.
    # For type only :fade exists at the moment.
    # ANIM_FACE = [enabled, type, animation_speed_in, animation_speed_out]
    ANIM_FACE = [true, :fade, 12, 8]
    
    # Set the animation options for name window.
    # For type only :fade exists at the moment.
    # ANIM_NAME = [animation_speed_in, animation_speed_out]
    ANIM_NAME = [true, :fade, 12, 8]
    
  end
end
# *** Don't edit below unless you know what you are doing. ***
#==============================================================================#
# ** Error Handler
#==============================================================================#
  unless $imported["XAIL-XS-CORE"]
    # // Error handler when XS - Core is not installed.
    msg = "The script %s requires the latest version of XS - Core in order to function properly."
    name = "XS - Message"
    msgbox(sprintf(msg, name))
    exit
  end
#==============================================================================#
# ** Window_Base
#==============================================================================#
class Window_Base < Window
  
  alias xail_msg_winbase_upd_open update_open
  def update_open(*args, &block)
    # // Method to update openness
    # This should only occur when $game_message is visible.
    if $game_message.visible
      self.openness += XAIL::MSG::WINDOW_ANIMATE[0]
      self.opacity = self.openness unless self.opacity == 0
      self.back_opacity = self.openness unless self.opacity == 0
      @opening = false if open?
    else
      xail_msg_winbase_upd_open(*args, &block)
    end
  end

  alias xail_msg_winbase_upd_close update_close
  def update_close(*args, &block)
    # // Method override to update closeness.
    # This should only occur when $game_message is visible.
    if $game_message.visible
      self.openness -= XAIL::MSG::WINDOW_ANIMATE[1]
      self.opacity = self.openness unless self.opacity == 0
      self.back_opacity = self.openness unless self.opacity == 0
      @closing = false if close?
    else
      xail_msg_winbase_upd_close(*args, &block)
    end
  end
  
end
#==============================================================================#
# ** Window_Message_Face
#==============================================================================#
class Window_Message_Face < Window_Base
  
  def initialize(x, y, width, height)
    # // Method to initialize.
    super(x, y, width, height)
    skin = $game_variables[XAIL::MSG::WINDOW_VAR[13]] == 0 ? "Window" : $game_variables[XAIL::MSG::WINDOW_VAR[13]]
    self.windowskin = Cache.system(skin)
    refresh
  end
  
  def refresh
    # // Method to refresh.
    contents.clear
    r = Rect.new(0, 0, width, height)
    r2 = Rect.new(2, 2, width-28, height-28)
    contents.fill_rect(r, Color.new(75,125,135,245))
    contents.gradient_fill_rect(r2, Color.new(125,125,125,255), Color.new(0,0,0,255), false)
    draw_face($game_message.face_name, $game_message.face_index, 4, 4)
  end
  
end
#==============================================================================#
# ** Window_Message_Name
#==============================================================================#
class Window_Message_Name < Window_Base
  
  def initialize(name, x, y, width, height)
    # // Method to initialize.
    super(x, y, width, height)
    skin = $game_variables[XAIL::MSG::WINDOW_VAR[13]] == 0 ? "Window" : $game_variables[XAIL::MSG::WINDOW_VAR[13]]
    self.windowskin = Cache.system(skin)
    @name = name
    refresh
  end
  
  def standard_padding
    # // Method to set standard padding
    return 4
  end
  
  def name=(name)
    # // Method to refresh and set name.
    return if @name == name
    @name = name
    refresh
  end
  
  def refresh
    # // Method to refresh.
    contents.clear
    draw_font_text(@name, 0, 0, contents_width, 1, XAIL::MSG::NAME[0], XAIL::MSG::NAME[1], XAIL::MSG::NAME[2])
  end
  
end
#==============================================================================#
# ** Window_Message
#==============================================================================#
class Window_Message < Window_Base
  
  def initialize
    # // Method override initialize for window message.
    super(0, 0, window_width, window_height)
    self.z = 200
    self.openness = 0
    create_all_windows
    create_back_bitmap
    create_back_sprite
    clear_instance_variables
    set_window_skins
  end
  
  def set_window_skins
    # // Method to set window skins.
    @gold_window.windowskin = Cache.system(get_var(XAIL::MSG::WINDOW_VAR[13], :skin))
    @choice_window.windowskin = Cache.system(get_var(XAIL::MSG::WINDOW_VAR[13], :skin))
    @number_window.windowskin = Cache.system(get_var(XAIL::MSG::WINDOW_VAR[13], :skin))
    @item_window.windowskin = Cache.system(get_var(XAIL::MSG::WINDOW_VAR[13], :skin))
  end
  
#~   alias xail_msg_winmsg_create_all_windows create_all_windows
#~   def create_all_windows(*args, &block)
#~     # // Method to create all windows.
#~     xail_msg_winmsg_create_all_windows(*args, &block)
#~     @choice_window = Window_ChoiceList.new(self)
#~     @number_window = Window_NumberInput.new(self)
#~     @item_window = Window_KeyItem.new(self)
#~     @choice_window.windowskin
#~   end
  
  def window_width
    # // Method override to return width.
    get_var(XAIL::MSG::WINDOW_VAR[0], :width)
  end

  def window_height
    # // Method override to return height.
    fitting_height(get_var(XAIL::MSG::WINDOW_VAR[1], :height))
  end
  
  def standard_padding
    # // Method to return the padding.
    get_var(XAIL::MSG::WINDOW_VAR[2], :padding)
  end
  
  def window_x
    # // Method to return x value of window.
    get_var(XAIL::MSG::WINDOW_VAR[3], :win_x)
  end
  
  def window_y
    # // Method to return y value of window.
    get_var(XAIL::MSG::WINDOW_VAR[4], :win_y)
  end
  
  def get_var(var, type)
    # // Method to return variable value if conditions met.
    unless var.nil? or $game_variables[var] == 0
      return $game_variables[var]
    else
      case type
      when :width           ; return Graphics.width
      when :height          ; return visible_line_number
      when :padding         ; return 12
      when :win_x           ; return 0
      when :win_y           ; return 0
      when :wait            ; return 0
      when :font_name       ; return Font.default_name
      when :font_size       ; return Font.default_size
      when :font_color      ; return Font.default_color
      when :font_out_color  ; return Font.default_out_color
      when :font_bold       ; return Font.default_bold
      when :font_shadow     ; return Font.default_shadow
      when :name            ; return ""
      when :skin            ; return "Window"
      end
    end
  end
  
  alias xail_msg_winmsg_upd_placement update_placement
  def update_placement(*args, &block)
    # // Method to update placement.
    xail_msg_winmsg_upd_placement(*args, &block)
    self.width = window_width
    self.height = window_height
    self.x = window_x
    self.y = window_y
    create_contents
  end
  
  def fiber_main
    # // Method override for fiber main.
    $game_message.visible = true
    update_background
    update_placement
    loop do
      process_all_text if $game_message.has_text?
      process_input
      $game_message.clear
      @gold_window.close
      dispose_face
      dispose_name
      Fiber.yield
      break unless text_continue?
    end
    close_and_wait
    $game_message.visible = false
    @fiber = nil
  end
  
  def draw_message_face
    # //  Method to draw face window.
    unless $game_message.face_name.empty?
      x = window_x - 44
      @face_window = Window_Message_Face.new(x, window_y, 128, 128)
      @face_window.z = 201
      @face_window.opacity = 0
      if XAIL::MSG::ANIM_FACE[0]
        case XAIL::MSG::ANIM_FACE[1]
        when :fade
          @face_window.contents_opacity = 0
          fade(XAIL::MSG::ANIM_FACE[2], @face_window, :in)
        end
      end
    end
  end
  
  def draw_message_name
    # // Method to draw name window.
    name = get_var(XAIL::MSG::WINDOW_VAR[12], :name)
    unless name == ""
      w = text_size(name).width + 24
      x = window_x + 16
      @name_window = Window_Message_Name.new(name, x, window_y - 31, w, 34)
      @name_window.z = 199
      if XAIL::MSG::ANIM_NAME[0]
        case XAIL::MSG::ANIM_NAME[1]
        when :fade
          @name_window.opacity = @name_window.contents_opacity = 0
          fade(XAIL::MSG::ANIM_NAME[2], @name_window, :in, true, true)
        end
      end
    end
  end
  
  alias xail_msg_winmsg_process_normal_character process_normal_character
  def process_normal_character(c, pos)
    # // Method to set a wait time for each processed character.
    # This will also play a SE based on if the pos is a odd number.
    xail_msg_winmsg_process_normal_character(c, pos)
    wait(get_var(XAIL::MSG::WINDOW_VAR[5], :wait))
    if (pos[:x] % XAIL::MSG::SE[0] > 0)
      Sound.play(XAIL::MSG::SE[1], XAIL::MSG::SE[2], XAIL::MSG::SE[3]) unless XAIL::MSG::SE.nil?
    end
  end
  
  alias xail_msg_winmsg_open_and_wait open_and_wait
  def open_and_wait(*args, &block)
    # // Method for open and wait.
    xail_msg_winmsg_open_and_wait(*args, &block)
    draw_message_face ; draw_message_name
  end
  
  def new_page(text, pos)
    # // Method override for new page.
    contents.clear
    contents.font.name = get_var(XAIL::MSG::WINDOW_VAR[6], :font_name)
    contents.font.size = get_var(XAIL::MSG::WINDOW_VAR[7], :font_size)
    contents.font.color = get_var(XAIL::MSG::WINDOW_VAR[8], :font_color)
    contents.font.out_color = get_var(XAIL::MSG::WINDOW_VAR[9], :font_out_color)
    contents.font.bold = eval(get_var(XAIL::MSG::WINDOW_VAR[10], :font_bold)) unless $game_variables[XAIL::MSG::WINDOW_VAR[10]] == 0
    contents.font.shadow = eval(get_var(XAIL::MSG::WINDOW_VAR[11], :font_shadow)) unless $game_variables[XAIL::MSG::WINDOW_VAR[11]] == 0
    pos[:x] = new_line_x
    pos[:y] = 0
    pos[:new_x] = new_line_x
    pos[:height] = calc_line_height(text)
    clear_flags
  end
  
  def new_line_x
    # // Method for new line x pos.
    $game_message.face_name.empty? ? 0 : @face_window.width / 2 + 4
  end
  
  def input_choice
    # // Method to start the input choice.
    @choice_window.start
    skin = $game_variables[XAIL::MSG::WINDOW_VAR[13]] == 0 ? "Window" : $game_variables[XAIL::MSG::WINDOW_VAR[13]]
    @choice_window.windowskin = Cache.system(skin)
    @choice_window.opacity = 255
    Fiber.yield while @choice_window.active
  end

  def input_number
    # // Method to start the input number.
    @number_window.start
    skin = $game_variables[XAIL::MSG::WINDOW_VAR[13]] == 0 ? "Window" : $game_variables[XAIL::MSG::WINDOW_VAR[13]]
    @number_window.windowskin = Cache.system(skin)
    @number_window.opacity = 255
    Fiber.yield while @number_window.active
  end
  
  def fade(max, window, type, con_op = true, op = false)
    # // Method to fade in/out the windows opacity and/or contents_opacity.
    return if window.is_a?(Array)
    case type
    when :in 
      for i in 1..max
        Graphics.update
        window.contents_opacity = i * (255 / max) if con_op
        window.opacity = i * (255 / max) if op
      end
    when :out
      for i in 1..max
        Graphics.update
        window.contents_opacity = 255 - i * (255 / max) if con_op
        window.opacity = 255 - i * (255 / max) if op
      end
    end
  end
  
  def dispose_face
    # // Method to dispose face window.
    unless @face_window.nil? or @face_window.is_a?(Array)
      if XAIL::MSG::ANIM_FACE[0]
        case XAIL::MSG::ANIM_FACE[1]
        when :fade
          fade(XAIL::MSG::ANIM_FACE[3], @face_window, :out)
        end
      end
      @face_window = nil, @face_window.dispose 
    end
  end
  
  def dispose_name
    # // Method to dispose name window.
    unless @name_window.nil? or @name_window.is_a?(Array)
      if XAIL::MSG::ANIM_NAME[0]
        case XAIL::MSG::ANIM_NAME[1]
        when :fade
          fade(XAIL::MSG::ANIM_NAME[3], @name_window, :out) 
        end
      end
      @name_window = nil, @name_window.dispose
    end
  end
  
end 
#==============================================================================#
# ** Scene_Map
#==============================================================================#
class Scene_Map < Scene_Base

  def set_message_skin
    # // Method to set message window skin.
    skin = $game_variables[XAIL::MSG::WINDOW_VAR[13]] == 0 ? "Window" : $game_variables[XAIL::MSG::WINDOW_VAR[13]]
    @message_window.windowskin = Cache.system(skin)
  end

end # END OF FILE

#=*==========================================================================*=#
# ** END OF FILE
#=*==========================================================================*=#