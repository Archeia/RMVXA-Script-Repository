#==============================================================================
#   XaiL System - Icon Item
#   Author: Nicke
#   Created: 09/04/2012
#   Edited: 01/11/2012
#   Version: 1.0f
#==============================================================================
# Instructions
# -----------------------------------------------------------------------------
# To install this script, open up your script editor and copy/paste this script
# to an open slot below ? Materials but above ? Main. Remember to save.
#
# This script changes the item list to display icons as items instead.
# There is also a category feature which allows you to change the background
# color of each items/weapons/armour etc.
#
# Right now there is a setup of 6 categories one being the default one.
# You can easily edit the draw_item_rect method to add new ones.
#
# To setup a category for a item use the following code in the note field of the
# item:
# <category health> 
# or
# <category mana>
# The above will only work if you did not edit the category list.
#
# *** Only for RPG Maker VX Ace. ***
#==============================================================================
($imported ||= {})["XAIL-ICON-SKILLS"] = true
module XAIL
  module ICON_ITEM
  #--------------------------------------------------------------------------#
  # * Settings
  #--------------------------------------------------------------------------#
    # FONT = [name, size, color, bold, shadow]
    FONT = [["Anklada�", "Verdana"], 16, Color.new(255,225,255), true, true]
    
    # Show/hide option for the item scene.
    # DISPLAY = [show_help_icon, show_name, show_description,
    # show_consumable, show_amount]
    DISPLAY = [true, true, true, true, true]
    
    # If this is false every item will have the same default black color.
    # NO_CATEGORIES = true/false
    NO_CATEGORIES = false
    
    # REQ_ICONS[id] = icon_id
    # Set the req icon_id. (0 to disable)
    # Only used if XS - Equip Requirements is installed.
    REQ_ICONS = []
    REQ_ICONS[0] = 4143 # LVL
    REQ_ICONS[1] = 4145 # ATK
    REQ_ICONS[2] = 4150 # DEF
    REQ_ICONS[3] = 4147 # MAGIC
    REQ_ICONS[4] = 4148 # RES
    REQ_ICONS[5] = 4140 # AGL
    REQ_ICONS[6] = 4131 # LUK
    REQ_ICONS[7] = 4149 # HP
    REQ_ICONS[8] = 4132 # MP
    
    # REQ_VOCABS = true/false
    # Enable or disable vocabs for requirement stats.
    REQ_VOCABS = false
    
  end
end
# *** Don't edit below unless you know what you are doing. ***
#==============================================================================#
# ** Window_Help
#==============================================================================#
class Window_Help < Window_Base
  
  alias xail_item_icon_win_help_init initialize
  def initialize(line_number = 2)
    # // Method to initialize window help.
    num = XAIL::ICON_ITEM::REQ_VOCABS ? 5 : 4
    line_number = $imported["XAIL-EQUIP-REQ"] ? num : 2 if SceneManager.scene_is?(Scene_Item)
    xail_item_icon_win_help_init(line_number)
  end
  
  def set_item_help(item)
    # // Method to set the item for window help.
    contents.font.name = XAIL::ICON_ITEM::FONT[0]
    contents.font.bold = XAIL::ICON_ITEM::FONT[3]
    contents.font.shadow = XAIL::ICON_ITEM::FONT[4]
    contents.font.out_color = Color.new(0,0,0,255)
    if item
      new_line = "\n"
      icon = XAIL::ICON_ITEM::DISPLAY[0] ? '\i[' + item.icon_index.to_s + ']' : ""
      name = XAIL::ICON_ITEM::DISPLAY[1] ? '\c[2] �� ' + item.name + '\c[0]' : ""
      weight = $imported["XAIL-INVENTORY-WEIGHT"] ? weight = " - Weight: #{item.weight}." : ""
      durability = $imported["XAIL-ITEM-DURABILITY"] ? durability = " - Durability: #{item.durability} / #{item.max_durability}." : ""
      if $imported["XAIL-EQUIP-REQ"]
        @req = '\c[4]�'
        req_skills = '\c[5]� Req Skills: '
        req_items = '    \c[6]� Req Items: '
        if XAIL::ICON_ITEM::REQ_VOCABS
          @req2 = '\c[4]�'
          4.times {|i| @req += get_icon_equip_req(item, i)}
          5.times {|i| @req2 += get_icon_equip_req(item, i+4)}
          @req2 += '\c[0]'
        else
          @req2 = ""
          9.times {|i| @req += get_icon_equip_req(item, i)}
        end
        @req += '\c[0]'
        unless item.req_equipment_skills == []
          item.req_equipment_skills.size.times {|i| 
            req_skills += get_icon_equip_req_items(item, i)
          }
        else
          req_skills += "None."
        end
        req_skills += '\c[0]'
        unless item.req_equipment_weapons == []
          item.req_equipment_weapons.size.times {|i| 
            req_items += get_icon_equip_req_items(item, i, :weapons)
          }
        end
        unless item.req_equipment_armors == []
          item.req_equipment_armors.size.times {|i| 
            req_items += get_icon_equip_req_items(item, i, :armors)
          }
        end
        req_items += '\c[0]'
      else
        @req, @req2, req_skills, req_items = ""
      end
      if item.is_a?(RPG::Item) && XAIL::ICON_ITEM::DISPLAY[2]
        consumable = item.consumable ? " (Consumable)" : " (Non-consumable)"
      else
        consumable = ""
      end
      desc = XAIL::ICON_ITEM::DISPLAY[3] ? item.description : ""
      if $imported["XAIL-EQUIP-REQ"]
        @req
      req = XAIL::ICON_ITEM::REQ_VOCABS ? @req + new_line + 
        @req2 + new_line : @req + new_line
      item_text = icon + name + weight + durability + new_line + 
        req + req_skills + req_items + new_line + desc
      else
        item_text = icon + name + weight + durability + new_line + desc
      end
    else
      item_text = ""
    end
    set_text(item_text)
  end
  
 def get_icon_item_req(item, id)
    # // Method to get requirements. 
    # // Only used if XS - Equip Requirements is installed.
    case id
    when 0 ; name = Vocab::level
    when 1 ; name = Vocab::param(2)
    when 2 ; name = Vocab::param(3)
    when 3 ; name = Vocab::param(4)
    when 4 ; name = Vocab::param(5)
    when 5 ; name = Vocab::param(6)
    when 6 ; name = Vocab::param(7)
    when 7 ; name = Vocab::param(0)
    when 8 ; name = Vocab::param(1)
    end  
    name = XAIL::ICON_ITEM::REQ_VOCABS ? name + " = " : "="
    return '\i[' + XAIL::ICON_ITEM::REQ_ICONS[id].to_s + ']' + name.to_s + item.req_equipment[id].to_s + "  "
  end
  
  def get_icon_equip_req_items(item, id, type = :skills)
    # // Method to get skill, weapon or armor requirements. 
    # // Only used if XS - Equip Requirements is installed.
    case type
    when :skills
    return '\i[' + $data_skills[item.req_equipment_skills[id]].icon_index.to_s + ']'
    when :weapons
    return '\i[' + $data_weapons[item.req_equipment_weapons[id]].icon_index.to_s + ']'
    when :armors
    return '\i[' + $data_armors[item.req_equipment_weapons[id]].icon_index.to_s + ']'  
    end
  end
  
  
end
#==============================================================================#
# ** Window_ItemList_Icon
#==============================================================================#
class Window_ItemList_Icon < Window_ItemList
  
  def col_max
    # // Method to get col_max.
    return 14
  end

  def spacing
    # // Method to get spacing.
    return 14
  end
  
  def item_width
    # // Method to get item_width.
    return 24
  end
  
  def item_height
    # // Method to get item_height.
    return 24
  end 
  
  def row_max
    # // Method to get row_max.
    return item_max
  end

  def update_help
    # // Method to update help details.
    @help_window.set_item_help(item)
  end
  
  def item_rect(index)
    # // Method to draw item rect.
    rect = Rect.new
    rect.width = item_width
    rect.height = item_height
    rect.x = index % col_max * (item_width + spacing)
    rect.y = index / col_max * (item_height + 3)
    rect
  end
  
  def page_row_max
    # // Method to define page row max.
    return 1
  end

  def scan_items(item)
    # // Method to scan the notes for the items.
    item.note.scan(/<category[:]*\s*(.+)>/i)
    return $1 if !$1.nil?
  end

  def draw_item(index)
    # // Method override to draw item.
    item = @data[index]
    if item
      rect = item_rect(index)
      draw_item_rect(index, item, rect, rect.x, rect.y)
      draw_item_number(rect, item) if $game_party.item_number(item) > 1 and XAIL::ICON_ITEM::DISPLAY[3]
    end
  end
  
  def draw_item_icon(icon_index, x, y, enabled = true)
    # // Method to draw icon.
    bitmap = Cache.system("Iconset")
    rect = Rect.new(icon_index % 16 * 24, icon_index / 16 * 24, 24, 24)
    contents.blt(x, y, bitmap, rect, enabled ? 255 : 75)
  end
  
  def draw_item_rect(index, item, rect, x, y)
    # // Method to draw rect.
    outline = rect.clone
    outline.width = rect.width + 1
    outline.height = rect.height + 1
    contents.fill_rect(outline,Color.new(255,255,255,80))
    unless XAIL::ICON_ITEM::NO_CATEGORIES
      case scan_items(item)
      when "health"
        color = Color.new(150,0,0,45)
      when "mana"
        color = Color.new(0,0,150,45)
      when "cure"
       color = Color.new(0,130,0,45)
      when "elixir"
        color = Color.new(250,250,0,45)
      when "herbs"
        color = Color.new(0,215,0,45)
      when nil 
        color = Color.new(0,0,0,128)
      else
       color = Color.new(0,0,0,128) 
      end
    else
      color = Color.new(0,0,0,128)
    end
    color = enable?(item) ? color : Color.new(0,0,0,128)
    contents.fill_rect(rect, color)
    draw_item_icon(item.icon_index, x + 1, y, enable?(item))
  end
  
  def check_color(color, enabled = true)
     # // Method to set the color and alpha.
    contents.font.color.set(color)
    contents.font.color.alpha = 95 unless enabled
  end

  def draw_item_number(rect, item)
    # // Method to draw the item number.
    rect.y += 8
    if $game_party.item_number(item) < 10
      rect.x -= 2
    end
    contents.font = Font.new(XAIL::ICON_ITEM::FONT[0], XAIL::ICON_ITEM::FONT[1])
    check_color(XAIL::ICON_ITEM::FONT[2], enable?(item))
    contents.font.bold = XAIL::ICON_ITEM::FONT[3]
    contents.font.shadow = XAIL::ICON_ITEM::FONT[4]
    contents.font.out_color = Color.new(0,0,0,255)
    draw_text(rect, sprintf("%2d", $game_party.item_number(item)), 1)
    reset_font_settings
  end

end
#==============================================================================#
# ** Scene_Item
#==============================================================================#
class Scene_Item < Scene_ItemBase
  
  def create_item_window
    # // Method override create the item list window.
    wy = @category_window.y + @category_window.height
    wh = Graphics.height - wy
    @item_window = Window_ItemList_Icon.new(0, wy, Graphics.width, wh)
    @item_window.viewport = @viewport
    @item_window.help_window = @help_window
    @item_window.set_handler(:ok,     method(:on_item_ok))
    @item_window.set_handler(:cancel, method(:on_item_cancel))
    @category_window.item_window = @item_window
  end

end # END OF FILE

#=*==========================================================================*=#
# ** END OF FILE
#=*==========================================================================*=#