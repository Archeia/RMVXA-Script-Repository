#==============================================================================
#   XaiL System - Journal
#   Author: Nicke
#   Created: 05/01/2013
#   Edited: 30/01/2013
#   Version: 1.0a
#==============================================================================
# Instructions
# -----------------------------------------------------------------------------
# To install this script, open up your script editor and copy/paste this script
# to an open slot below ? Materials but above ? Main. Remember to save.
#
# A journal system which can be as an actual journal or setup as an 
# quest system.
#
# There are 3 predefined journals (categories) which will act as the following:
# 
# Unfinished. Each entry added will automatically be added to this category.
# Completed. When a journal is completed or done it should be moved to this.
# Failed. Same as completed but the entry will be marked as failed instead.
#
# Use the following script to call the scene in an event:
# SceneManager.call(Scene_Journal)
# Scene_Journal is the name to add for any custom menu script.
# 
# To setup a journal entry do one of the following script call:
# journal(symbol)
#
# Examples:
# journal(:investigation)                 # Add investigation to the journal.
# set_journal(:investigation, :completed) # Set investigation entry to completed.
# set_journal(:investigation, :failed)    # Set investigation entry to failed.
#
# You can use the journal as you want and if you decide to use it as a quest
# system you can enable certain rewards. Those rewards won't be added
# automatically and it is only there to show the player what type of rewards
# that would be given if a quest is completed.
#
# See more below how you can customize that and how you add more journal
# entries.
#
# *** Only for RPG Maker VX Ace. ***
#==============================================================================
($imported ||= {})["XAIL-JOURNAL-SYSTEM"] = true

module XAIL
  module JOURNAL
  #--------------------------------------------------------------------------#
  # * Settings
  #--------------------------------------------------------------------------#
    # FONT = [name, size, color, bold, shadow ]
    FONT = [["Calibri", "Verdana"], 20, Color.new(255,255,255), true, true]
  
    # LIST:
    # LIST = { 
      # :journal_name => [icon_index, "entry 1", "entry 2"... etc,
      # item_id = The id you want as the item, set it to nil when using 
      # the :exp/:gold types. 
      # type = :exp, :gold, :items, :weapons, :armors or :fame.
      # The type fame should only be used if XS - Fame System is installed.
      # [[item_id (set to nil if gold or exp), item_amount, type]]
    # } 
    LIST = {
    :ruby_madness => 
      [358, "1. Get the Ruby.\n2. Return the Ruby.", 
      [[1, 5, :items],
      [2, 1, :weapons],
      [1, 1, :armors],
      [nil, 5000, :exp],
      [nil, 2500, :gold],
      [nil, 500,  :fame]
      ]],
        
    :fetching_of_doom => 
      [350, "1. Gather 1000 rocks. \n2. Return the rocks to Mr Negaul in the town Brafoul.\n3. Profit!!!"],
    
    :investigation =>
      [3, "I need to investigate the the murder in town.\nSome clues ought to be laying around. Hopefully!\n\n I probably need to use some stealth so the guards\n won't notice me. That should be a piece of cake.",
      [[nil, 25000, :exp],
      [nil, 25000, :gold],
      [nil, 50000, :fame]
      ]],
      
    } # Don't remove this line!
    
    # Default reward icons for gold and experience.
    # Not in used unless there is a reward.
    # Fame is only used if XS - Fame System is installed.
    # REWARD_ICONS = [gold, exp, fame]
    REWARD_ICONS = [262, 121, 125]
    
    # The windowskin to use for the windows.
    # nil to disable.
    # SKIN = string
    SKIN = nil
    
  end
end
# *** Don't edit below unless you know what you are doing. ***
#==============================================================================#
# ** Error Handler
#==============================================================================#
  unless $imported["XAIL-XS-CORE"]
    # // Error handler when XS - Core is not installed.
    msg = "The script %s requires the latest version of XS - Core in order to function properly."
    name = "XS - Journal"
    msgbox(sprintf(msg, name))
    exit
  end
#==============================================================================#
# ** Game_System
#==============================================================================#
class Game_System
  
  attr_accessor :journal_unfinished, :journal_completed, :journal_failed
  
  alias xail_journal_sys_gm_sys_initialize initialize
  def initialize(*args, &block)
    # // Method to initialize game system.
    xail_journal_sys_gm_sys_initialize(*args, &block)
    @journal_unfinished = {}
    @journal_completed = {}
    @journal_failed = {}
  end
  
  def get_journal(journal)
    # // Method to get journal.
    case journal
    when :unfinished  ; return $game_system.journal_unfinished
    when :completed   ; return $game_system.journal_completed   
    when :failed      ; return $game_system.journal_failed     
    end
  end
  
end
#==============================================================================#
# ** Game_Interpreter
#==============================================================================#
class Game_Interpreter
  
  def journal(key, type = :add)  
    # // Method to add/remove a menu item to the list.
    journal = $game_system.get_journal(:unfinished)
    case type
       # // Add menu id.
      when :add
      unless journal.include?(XAIL::JOURNAL::LIST[key])
        journal[key] = XAIL::JOURNAL::LIST[key]           
      end unless XAIL::JOURNAL::LIST[key].nil?
      # // Remove menu id.
      when :del 
      unless XAIL::JOURNAL::LIST[key].nil?
        journal.delete(key)
      end
    end
  end
  
  def set_journal(key, type)
    # // Method to set journal to unfinished, completed etc.
    journals = [:unfinished, :completed, :failed]
    journals.each {|i|
      next if $game_system.get_journal(i)[key].nil?
      $game_system.get_journal(type)[key] = $game_system.get_journal(i)[key]
      $game_system.get_journal(i).delete(key) unless i == type
    }
  end
  
end
#==============================================================================
# ** Window_JournalCommand
#==============================================================================
class Window_JournalCommand < Window_Command
  
  attr_accessor :journal
  
  def initialize(x, y)
    # // Method to initialize.
    @journal = :unfinished
    super(x, y)
  end
  
  def window_width
    # // Method to return the width.
    return 180
  end
  
  def window_height
    # // Method to return the height.
    return Graphics.height - 48
  end
  
  def draw_item(index)
    # // Method to draw the command item.
    rect = item_rect_for_text(index)
    # // Line.
    draw_line_ex(rect.x + 20, rect.y + 8, Color.new(255,255,255,128), Color.new(0,0,0,64))
    # // Item.
    draw_font_text(command_name(index), rect.x + 22, rect.y, contents_width, alignment, XAIL::JOURNAL::FONT[0], 18, XAIL::JOURNAL::FONT[2])
    # // Setup icons.
    icons = []
    $game_system.get_journal(@journal).each_value {|i| icons << i[0] unless icons.include?(i[0]) }
    # // Cancel icon.
    icons << 184 unless icons.include?(184)
    # // Draw icon(s).
    icon = icons[index].nil? ? nil : icons[index]
    draw_icon(icon, rect.x - 4, rect.y) unless icon.nil?
  end
  
  def make_command_list
    # // Method to add the commands.
    $game_system.get_journal(@journal).each {|i| add_command(i[0].to_s.slice_char("_").cap_words, i[0]) }
  end

end
#==============================================================================#
# ** Window_JournalHelp
#==============================================================================#
class Window_JournalHelp < Window_Help
  
  def refresh
    # // Refresh help contents.
    contents.clear
    draw_journal_help
  end
  
  def draw_journal_help
    # // Method to draw the help text.
    # // Line.
    draw_line_ex(0, 6, Color.new(255,255,255,128), Color.new(0,0,0,64))
    # // Current journal.
    draw_font_text(@text, 0, 0, contents_width, 2, XAIL::JOURNAL::FONT[0], 18, XAIL::JOURNAL::FONT[2])
    # // Category details.
    text = "Change journal with Left/Right buttons."
    draw_font_text(text, 0, 0, contents_width, 0, XAIL::JOURNAL::FONT[0], 18, XAIL::JOURNAL::FONT[2])
  end
  
end
#==============================================================================#
# ** Window_JournalDetails
#==============================================================================#
class Window_JournalDetails < Window_Base

  attr_accessor :journal
  attr_accessor :key
  
  def initialize(x, y, width, height)
    # // Method to initialize.
    super(x, y, width, height)
    @journal = :unfinished
    @key = :none
  end
  
  def refresh
    # // Method to refresh window.
    contents.clear
    return if $game_system.get_journal(@journal)[@key].nil?
    draw_details
  end
  
  def draw_details
    # // Method to draw details.
    h = 18
    # // Icon.
    icon_id = $game_system.get_journal(@journal)[@key][0]
    draw_icon(icon_id, 0, 0)
    # // Name.
    name = @key.to_s.slice_char("_").cap_words
    draw_font_text(name, 0, 0, contents_width, 1, XAIL::JOURNAL::FONT[0], 30, XAIL::JOURNAL::FONT[2])
    # // Line.
    draw_line_ex(0, 18, Color.new(255,255,255,128), Color.new(0,0,0,64))
    # // Journal text.
    journal = $game_system.get_journal(@journal)[@key][1]
    draw_font_text_ex(journal, 4, 40, XAIL::JOURNAL::FONT[0], 18, XAIL::JOURNAL::FONT[2])
    # // Reward Title.
    unless $game_system.get_journal(@journal)[@key][2].nil? 
    reward_title = "Rewards"
    draw_font_text(reward_title, 0, contents_height - h * 5, contents_width, 1, XAIL::JOURNAL::FONT[0], 30, XAIL::JOURNAL::FONT[2])
    # // Line.
    draw_line_ex(0, contents_height - h * 4, Color.new(255,255,255,128), Color.new(0,0,0,64))
    # // Rewards.
      items_x = 0
      $game_system.get_journal(@journal)[@key][2].each {|i|
        # // Reward icon.
        reward = $game_party.check_item?(i[0], i[2])
        amount = i[0].nil? ? "#{i[1]}"  : "#{i[1]}x"
        case i[2]
        when :gold
          h = 14
          draw_icon(XAIL::JOURNAL::REWARD_ICONS[0], contents_width - 24, contents_height - h * 2)
          draw_font_text(amount + Vocab::currency_unit, -26, (contents_height - h * 2) + 4, contents_width, 2, XAIL::JOURNAL::FONT[0], 16, XAIL::JOURNAL::FONT[2])
        when :exp
          h = 14
          draw_icon(XAIL::JOURNAL::REWARD_ICONS[1], 0, contents_height - h * 2)
          draw_font_text(amount + "XP", 26, (contents_height - h * 2) + 4, contents_width, 0, XAIL::JOURNAL::FONT[0], 16, XAIL::JOURNAL::FONT[2])
        when :fame
          h = 14
          draw_icon(XAIL::JOURNAL::REWARD_ICONS[2], (contents_width / 2) - (amount.length + 22), contents_height - h * 2)
          draw_font_text(amount + "Fame", 26, (contents_height - h * 2) + 4, contents_width, 1, XAIL::JOURNAL::FONT[0], 16, XAIL::JOURNAL::FONT[2])
        else 
          reward_icon = reward.icon_index
          draw_icon(reward_icon, items_x, contents_height - h * 3)
          # // Reward item amount.
          draw_font_text(amount, items_x + 6, (contents_height - h * 3) + 10, contents_width, 0, XAIL::JOURNAL::FONT[0], 16, XAIL::JOURNAL::FONT[2])
          items_x += line_height
        end
      }
    end
  end
  
end
#==============================================================================#
# ** Scene_Journal
#==============================================================================#
class Scene_Journal < Scene_Base
  
  def start
    # // Method to start the scene.
    super
    # // Define journals.
    @journals = [:unfinished, :completed, :failed]
    @journal_pos = 0
    # // Create windows.
    create_background
    create_journal_command
    create_journal_help
    create_journal_details
    # // Set default journal/details.
    set_journal(0)
    set_details(@journal_command_window.current_symbol)
  end
  
  def create_background
    # // Method to create a background.
    @background_sprite = Sprite.new
    @background_sprite.bitmap = SceneManager.background_bitmap
    @background_sprite.color.set(16, 16, 16, 128)
  end
  
  def create_journal_command
    # // Method to create journal command window.
    @journal_command_window = Window_JournalCommand.new(0, 0)
    @journal_command_window.windowskin = Cache.system(XAIL::JOURNAL::SKIN) unless XAIL::JOURNAL::SKIN.nil? 
    @journal_command_window.set_handler(:pageright, method(:next_journal))
    @journal_command_window.set_handler(:pageleft,  method(:prev_journal))
    @journal_command_window.set_handler(:cancel,    method(:return_scene))
    @journal_command_window.help_window = @journal_help_window
  end
  
  def create_journal_help
    # // Method to create journal help window.
    @journal_help_window = Window_JournalHelp.new(1)
    @journal_help_window.y = Graphics.height - @journal_help_window.height
    @journal_help_window.windowskin = Cache.system(XAIL::JOURNAL::SKIN) unless XAIL::JOURNAL::SKIN.nil?
  end
  
  def create_journal_details
    # // Method to create journal details window.
    x = @journal_command_window.width
    y = 0
    width = Graphics.width - @journal_command_window.width
    height = Graphics.height - @journal_help_window.height
    @journal_details_window = Window_JournalDetails.new(x, y, width, height)
  end
  
  alias xail_journal_sys_upd update
  def update(*args, &block)
    # // Method for updating the scene.
    old_symbol = @journal_command_window.current_symbol
    xail_journal_sys_upd(*args, &block)
    set_details(@journal_command_window.current_symbol) if old_symbol != @journal_command_window.current_symbol
  end
  
  def next_journal
    # // Method to determine next journal.
    unless @journal_pos == @journals.size - 1
      @journal_pos += 1
    else
      @journal_pos = 0
    end
    @journal_command_window.activate
    set_journal(@journal_pos)
  end
  
  def prev_journal
    # // Method to determine previous journal.
    unless @journal_pos == 0
      @journal_pos -= 1
    else
      @journal_pos = @journals.size - 1
    end
    @journal_command_window.activate
    set_journal(@journal_pos)
  end
  
  def set_journal(pos)
    # // Method to set journal based on position.
    j = @journals[pos].to_s.capitalize
    @journal_help_window.set_text("Current journal: " + j)
    @journal_command_window.journal = @journals[pos]
    @journal_command_window.refresh
    @journal_command_window.select(0)
  end
  
  def set_details(key)
    # // Method to set details based on key.
    @journal_details_window.journal = @journals[@journal_pos]
    @journal_details_window.key = key
    @journal_details_window.refresh
  end

end # END OF FILE

#=*==========================================================================*=#
# ** END OF FILE
#=*==========================================================================*=#