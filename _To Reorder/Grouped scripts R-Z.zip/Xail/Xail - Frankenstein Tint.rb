#==============================================================================
#   XaiL System - Frankenstein Tint
#   Author: Nicke
#   Created: 07/02/2013
#   Edited: 07/02/2013
#   Version: 1.0
#==============================================================================
# Instructions
# -----------------------------------------------------------------------------
# To install this script, open up your script editor and copy/paste this script
# to an open slot below ? Materials but above ? Main. Remember to save.
#
# Small snippet to enable a certain tint at every scene in the game instead
# of doing it with events.
#
# If tint command was used when fading in/out the screen a convient method
# exists so you can set the frankenstein tint back.
#
# In a event do the following script call to call that method:
# set_frankenstein_tint
#
# *** Only for RPG Maker VX Ace. ***
#==============================================================================
($imported ||= {})["XAIL-FRANK-TINT"] = true

module XAIL
  module FRANK_TINT
  #--------------------------------------------------------------------------#
  # * Settings
  #--------------------------------------------------------------------------#
    # TONE = [tone, duration]
    TONE = [Tone.new(0,0,0,255), 0]
    
  end
end
# *** Don't edit below unless you know what you are doing. ***
#==============================================================================#
# ** Game_Screen
#==============================================================================#
class Game_Screen
  
  alias xail_frankenstein_tint_gm_screen_init initialize
  def initialize(*args, &block)
    # // Method to initialize game screen.
    xail_frankenstein_tint_gm_screen_init(*args, &block)
    setup_frankenstein_tint
  end
  
  def setup_frankenstein_tint
    # // Method to setup frankenstein tint.
    start_tone_change(XAIL::FRANK_TINT::TONE[0], XAIL::FRANK_TINT::TONE[1])
  end 
  
end 
#==============================================================================#
# ** Game_Interpreter
#==============================================================================#
class Game_Interpreter 
  
  def set_frankenstein_tint
    # // Method to set the frankenstein tint if tone command was used for fading
    # the screen in/out.
    screen.start_tone_change(XAIL::FRANK_TINT::TONE[0], XAIL::FRANK_TINT::TONE[1])
  end
  
end # END OF FILE

#=*==========================================================================*=#
# ** END OF FILE
#=*==========================================================================*=#