#==============================================================================
#   XS - Pre Title
#   Author: Nicke
#   Created: 31/08/2012
#   Edited: 08/11/2012
#   Version: 1.0f
#==============================================================================
# Instructions
# -----------------------------------------------------------------------------
# To install this script, open up your script editor and copy/paste this script
# to an open slot below ? Materials but above ? Main. Remember to save.
#==============================================================================
# Requires: XS - Core Script.
#==============================================================================
# Pre title script.
# This will enables you to show pictures, texts and play movies before the title
# scene is presented.
#
# *** Only for RPG Maker VX Ace. ***
#==============================================================================
($imported ||= {})["XAIL-PRE-TITLE"] = true
module XAIL
  module PRE_TITLE
  #--------------------------------------------------------------------------#
  # * Settings
  #--------------------------------------------------------------------------#
    # FONT = [name, size, color, bold, shadow]
    FONT = [["Anklada™", "Verdana"], 32, Color.new(255,255,255), true, true]

    # Setup music to be played.
    # Can be set to nil to disable.
    # MUSIC = [name, pitch, volume]
    MUSIC = [nil]

    # Setup the pictures here.
    # PICTURES = [name, opacity, delay (can be nil), fade_in, fade_out]
    PICTURES = {
    0 => ["r2g", 255, 30, true, true],
    1 => [nil],
    2 => [nil]
    } # Don't remove this line.

    # Setup the text here.
    # TEXTS = [name, x, y, delay (can be nil), fade_in, fade_out]
    TEXTS = {
    0 => [nil],
    1 => [nil],
    2 => [nil]
    } # Don't remove this line.

    # Setup the movies here.
    # MOVIES = [filename, goto_title?]
    MOVIES = {
    0 => [nil],
    } # Don't remove this line.

    # Set the order. ID 0 begin the first one to be shown.
    # SHOW_ORDER[id] => symbol
    # symbol:
    # :m = movies
    #  = pictures
    # :t = texts
    SHOW_ORDER = {
    0 => :m,
    1 => :t,
    2 => :p,
    } # Don't remove this line.

    # Set the button to manually skip trough each texts and pictures.
    # BUTTON = symbol
    BUTTON = :C

    # Use this if you wish to skip the pre title scene.
    # Can be used when debugging your game.
    # SKIP_PRE_TITLE = true/false
    SKIP_PRE_TITLE = true

  end
end
# *** Don't edit below unless you know what you are doing. ***
#==============================================================================#
# ** Error Handler
#==============================================================================#
  unless $imported["XAIL-XS-CORE"]
    # // Error handler when XS - Core is not installed.
    msg = "The script %s requires the latest version of XS - Core in order to function properly."
    name = "XS - Pre Title"
    msgbox(sprintf(msg, name))
    exit
  end
#==============================================================================#
# ** SceneManager
#==============================================================================#
class << SceneManager
  alias xail_pre_title_scenemanager_first_scene_class first_scene_class
  def first_scene_class(*args, &block)
    # // Method for first scene class.
    return xail_pre_title_scenemanager_first_scene_class(*args, &block) if XAIL::PRE_TITLE::SKIP_PRE_TITLE
    $BTEST ? Scene_Battle : Scene_Pre_Title
  end

end
#==============================================================================#
# ** Scene_Base
# If YEA - Menu Cursor is installed change update_menu_cursors method to
# prevent bug.
#==============================================================================#
if $imported["YEA-MenuCursor"]
class Scene_Base

  alias xail_pre_title_yea_upd_menu_cur update_menu_cursors
  def update_menu_cursors(*args, &block)
    # // Method to update menu cursors.
    return if @menu_cursors.nil?
    xail_pre_title_yea_upd_menu_cur(*args, &block)
  end

end
end
#==============================================================================#
# ** Scene_Pre_Title
#==============================================================================#
class Scene_Pre_Title < Scene_Base

  def initialize
    # // Method to initialize the scene.
    Graphics.fadeout(0)
    setup_music unless XAIL::PRE_TITLE::MUSIC.nil?
    for i in XAIL::PRE_TITLE::SHOW_ORDER.values
	  case i
	  when :p ; setup_pictures
	  when :t ; setup_texts
	  when :m ; setup_movies
	  end
    end
  end

  def update
    # // Method to update the scene.
    super
    goto_title
  end

  def setup_music
    # // Method to play a bgm.
    bgm = XAIL::PRE_TITLE::MUSIC
    Sound.play(bgm[0], bgm[1], bgm[2], :bgm)
  end

  def setup_pictures
    # // Method to setup the picture(s).
    pics = XAIL::PRE_TITLE::PICTURES
    pics.keys.each {|i| display_picture(pics[i])}
  end

  def setup_texts
    # // Method to setup the text(s).
    texts = XAIL::PRE_TITLE::TEXTS
    texts.keys.each {|i| display_texts(texts[i])}
  end

  def setup_movies
    # // Method to setup the movie(s).
    movies = XAIL::PRE_TITLE::MOVIES
    movies.keys.each {|i| display_movie(movies[i])}
  end

  def delay?(amount)
    # // Method to delay.
    if amount.nil?
	  loop do
	    update_basic	   
	    break if Input.trigger?(XAIL::PRE_TITLE::BUTTON)
	  end
    else
	  amount.times do
	    update_basic	   
	    break if Input.trigger?(XAIL::PRE_TITLE::BUTTON)
	  end
    end 
  end

  def display_picture(picture)
    # // Method to display a picture.
    return if picture.nil?
    begin
	  pictures = Sprite.new
	  pictures.bitmap = Cache.picture(picture[0])
	  pictures.opacity = picture[1]
    rescue
	  msgbox("Error. Unable to locate picture: " + picture[0])
	  exit
    end
    Graphics.fadein(picture[3])
    delay?(picture[2])
    Graphics.fadeout(picture[4])
    delay?(60)
    pictures = nil, pictures.dispose unless pictures.nil?
  end

  def display_texts(text)
    # // Method to display a text.
    return if text.nil?
    Graphics.fadein(60)
    texts = Sprite.new
    texts.opacity = 0   
    texts.bitmap = Bitmap.new(Graphics.width, Graphics.height)
    texts.bitmap.font.name = XAIL::PRE_TITLE::FONT[0]
    texts.bitmap.font.size = XAIL::PRE_TITLE::FONT[1]
    texts.bitmap.font.color = XAIL::PRE_TITLE::FONT[2]
    texts.bitmap.font.bold = XAIL::PRE_TITLE::FONT[3]
    texts.bitmap.font.shadow = XAIL::PRE_TITLE::FONT[4]
    texts.bitmap.draw_text(text[1], text[2], Graphics.width, Graphics.height, text[0])
    for i in 1..text[4]
	  update_basic
	  texts.opacity = i * (255 / text[4])
    end
    delay?(text[3])
    for i in 1..text[5]
	  update_basic
	  texts.opacity = 255 - i * (255 / text[5])
    end
    delay?(60)
    texts = nil, texts.dispose unless texts.nil?
  end

  def display_movie(movie)
    # // Method to display a movie.
    return if movie.nil?
    begin
	  Graphics.play_movie("Movies/" + movie[0])
    rescue
	  msgbox("Error. Unable to locate movie: " + movie[0])
	  exit
    end
    delay?(60)
    goto_title if movie[1]
  end

  def goto_title
    # // Method to go to title scene.
    RPG::BGM.fade(1000)
    delay?(500)
    RPG::BGM.stop
    SceneManager.goto(Scene_Title)
  end

end # END OF FILE