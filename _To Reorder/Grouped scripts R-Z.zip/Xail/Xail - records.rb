#==============================================================================
#   XaiL System - Records
#   Author: Nicke
#   Created: 31/03/2012
#   Edited: 03/04/2012
#   Version: 1.0c
#==============================================================================
# Instructions
# -----------------------------------------------------------------------------
# To install this script, open up your script editor and copy/paste this script
# to an open slot below ? Materials but above ? Main. Remember to save.
#
# To call this scene in a menu or on the map simply use one the following codes:
# SceneManager.call(Scene_Records)
# SceneManager.goto(Scene_Records)

# To use this script simply use one of these methods to modify the records.
# Add/delete a record.
# record(id, type)
# Examples:
# record(1, :add)
# record(2, :add)
# record(2, :del)
#
# Use one of these methods in a conditional branch to check if they are added
# or enabled. Can be useful for certain quests or other things.
# record_enabled?(id)
# record_added?(id)
#
# record_enable(id, enabled)
# Examples:
# record_enabled(1, false) # // Will make id 1 disabled.
# record_enabled(2, true)  # // Will make id 2 enabled.
#
# To add all records in the list, use the following code:
# record_all       # // This will add all records in R_LIST.
# record_all(:del) # // To delete every added record.
#
## *** Only for RPG Maker VX Ace. ***
#==============================================================================
($imported ||= {})["XS-RECORD-SCENE"] = true

module XAIL
  module RECORDS
    #--------------------------------------------------------------------------#
    # * Settings
    #--------------------------------------------------------------------------#
    # FONT = [ name, size, color, bold, italic, shadow ]
    FONT = [["Verdana"], 20, Color.new(255,200,2), true, false, true]

    # The windowskin to use for the windows. Set to nil to disable.
    # SKIN = string
    SKIN = nil

    # Disable all of the icons if you don't need them.
    # ICON_ENABLE = true/false
    ICON_ENABLE = true

    # Records that you will be able to enable/disable/added/removed ingame.
    # Also make sure you don't use the same variable twice in a record.
    # The variable is there to change the value of a record.
    # R_LIST[ID] = [RECORD_TEXT, VARIABLE_ID, ICON_INDEX(can be nil), ENABLED]
    R_LIST = [] # Don't remove!
    R_LIST[0] = ["Acquired gold", 1, 361, true]
    R_LIST[1] = ["Save times", 2, 225, true]
    R_LIST[2] = ["Monsters slained", 3, nil, true]
    R_LIST[3] = ["Treasures found", 4, 261, true]
    R_LIST[4] = ["Locations discovered", 5, 231, true]
    R_LIST[5] = ["Letters received", 6, 234, true]
    R_LIST[6] = ["Artifacts found", 7, 245, true]
    R_LIST[7] = ["Gems", 8, 358, true]
    R_LIST[8] = ["Puzzle solved", 9, nil, true]
    R_LIST[9] = ["Steps walked", 10, 172, true]
    R_LIST[10] = ["Deaths", 11, 1, true]
    R_LIST[11] = ["Jail times", 12,280, true]
    R_LIST[12] = ["Sailed", 13, nil, true]
    R_LIST[13] = ["Shrines found", 14, 188, true]
    R_LIST[14] = ["Orbs obtained", 15, 359, true]
    R_LIST[15] = ["Test", 16, 362, true]
    R_LIST[16] = ["Test2", 17, 363, true]
    R_LIST[17] = ["Test3", 18, 364, true]
    
    # LINE_COLOR = Color.new(rgba)
    LINE_COLOR = Color.new(255,255,255)

    # Transition, nil to use default.
    # TRANSITION [ SPEED, TRANSITION, OPACITY ]
    TRANSITION = nil

    # Background image (System folder)
    # Note: You might want to decrease the opacity as well as arrange 
    # the windows so that you can properly see the background.
    # Set to nil to use default.
    BACK = nil

    # Return scene.
    # Can be anything you like. Default is return to the map.
    # RETURN_SCENE = Scene
    RETURN_SCENE = Scene_Map

  end
end
# *** Don't edit below unless you know what you are doing. ***
#==============================================================================#
# ** Game_System
#------------------------------------------------------------------------------
#  Class for checking the record list.
#==============================================================================#
class Game_System

  attr_accessor :records

  alias xail_record_sys_initialize initialize
  def initialize(*args, &block)
    xail_record_sys_initialize(*args, &block)
    @records = []
  end

end
#==============================================================================#
# ** Game_Interpreter
#------------------------------------------------------------------------------
#  Class to modify a record.
#==============================================================================#
class Game_Interpreter

  def record(id, type)  
    # // Method to add a record to the list.  
    case type
      when :add # // Add record id.
      unless $game_system.records.include?(XAIL::RECORDS::R_LIST[id])
        $game_system.records.push(XAIL::RECORDS::R_LIST[id])
      end unless XAIL::RECORDS::R_LIST[id].nil?
      when :del # // Remove record id.
      unless XAIL::RECORDS::R_LIST[id].nil?
        $game_system.records.delete(XAIL::RECORDS::R_LIST[id])
      end 
    end
  end

  def record_enabled?(id)
    # // Method to check if record is enabled.
    # (Must be added in the list or else it returns nil).
    return if $game_system.records[id].nil?
    return $game_system.records[id][3]
  end

  def record_added?(id)
    # // Method to check if record is added.
    return $game_system.records[id]
  end

  def record_enable(id, enabled)
    # // Method to enable/disable a record.
    $game_system.records[id][3] = enabled
  end 
  
  def record_all(type = :add)
    # // Method to add/delete all record id's.
    # This was made for convenient matters only.
    id = 0
    while id < XAIL::RECORDS::R_LIST.size
      case type
      when :add
        record(id, :add)
      when :del
        record(id, :del)
      end
      id += 1
    end
  end

end
#==============================================================================#
# ** Window_Record
#==============================================================================#
class Window_Record < Window_Selectable

  def initialize(x, y)
    # // Method to initialize the window.
    super(x, y, window_width, window_height)
    @records = $game_system.records
    @data = []
    refresh
  end

  def standard_padding
    # // Method to set the padding for text.
    return 16
  end
  
  def window_width
    # // Method to width the window.
    return Graphics.width
  end
  
  def window_height
    # // Method to height the window.
    return Graphics.height
  end
  
  def refresh
    # // Method to refresh the window.
    contents.clear
    make_item_list
    create_contents
    draw_all_items
  end
 
  def make_item_list
    for r in @records
      @data.push(r)
    end
  end

  def menu_color(color, enabled = true)
     # // Method to set the color and alpha if not enabled.
    contents.font.color.set(color)
    contents.font.color.alpha = 150 unless enabled
  end

  def draw_item(index)
    r = @data[index]
    # // Method to draw the record text to the window.
    contents.font = Font.new(XAIL::RECORDS::FONT[0], XAIL::RECORDS::FONT[1])
    menu_color(XAIL::RECORDS::FONT[2], r[3])
    contents.font.bold = XAIL::RECORDS::FONT[3]
    contents.font.italic = XAIL::RECORDS::FONT[4]
    contents.font.shadow = XAIL::RECORDS::FONT[5]
    y = index * 25
    y += 10 * index/17
    # // Draw Record.
    draw_text(26, y - 3, window_width, 32, r[0], 0)
    # // Draw Variable.
    draw_text(0, y - 3, window_width - 36, 32, $game_variables[r[1]], 2)
    # // Draw lines.
    draw_line(0, y + 24)
    # // Draw icons.
    draw_icon(r[2], 0, y, r[3]) unless r[2].nil? if XAIL::RECORDS::ICON_ENABLE
    reset_font_settings
  end

  def draw_line(x, y)
    # // Method to draw a line with a shadow.
    line = Rect.new
    line.height = 1
    line.width = Graphics.width
    line.x = x
    line.y = y
    contents.fill_rect(line,XAIL::RECORDS::LINE_COLOR)
    line.y += 1
    contents.fill_rect(line,Color.new(0,0,0,200))
  end
  
  def item_max
    # // Method to get item_max.
    @data ? @data.size : 1
  end
 
  def row_max
    # // Method to get row_max.
    item_max
  end
 
  def update_cursor
    # // Method to update cursor.
  end

end
#==============================================================================#
# ** Scene_RecordBase
#------------------------------------------------------------------------------
#  New Scene :: Scene_RecordBase - The Record scene.
#==============================================================================#
class Scene_RecordBase < Scene_Base

  alias xail_record_base_start start
  def start(*args, &block)
    # // Method to start the scene
    xail_record_base_start(*args, &block)
    @records = $game_system.records
    create_background
  end

  alias xail_record_base_terminate terminate
  def terminate(*args, &block)
    # // Method to terminate the scene.
    xail_record_base_terminate(*args, &block)
  end

  def create_background
    # // Method to create the background.
    @background_sprite = Sprite.new
    if XAIL::RECORDS::BACK.nil?
      @background_sprite.bitmap = SceneManager.background_bitmap
      @background_sprite.color.set(16, 16, 16, 128)
    else
      @background_sprite.bitmap = Cache.system(XAIL::RECORDS::BACK)
    end
  end

  alias xail_record_base_transition perform_transition
  def perform_transition(*args, &block)
    # // Method to create the transition.�
    if XAIL::RECORDS::TRANSITION.nil?
      Graphics.transition(15)
    else
      Graphics.transition(XAIL::RECORDS::TRANSITION[0],XAIL::RECORDS::TRANSITION[1],XAIL::RECORDS::TRANSITION[2])
    end
    xail_record_base_transition(*args, &block)
  end

  alias xail_record_base_re_scene return_scene
  def return_scene(*args, &block)
    # // Return to map.
    xail_record_base_re_scene(*args, &block)
    SceneManager.call(XAIL::RECORDS::RETURN_SCENE)
  end

end 
#==============================================================================#
# ** Scene_Records
#------------------------------------------------------------------------------
#  New Scene :: Scene_Records - The Record scene.
#==============================================================================#
class Scene_Records < Scene_RecordBase

  alias xail_record_init initialize
  def initialize(*args, &block)
    # // Method to initialize record scene.
    xail_record_init(*args, &block)
    @records = $game_system.records
  end

  alias xail_record_start start
  def start(*args, &block)
    # // Method to start record scene.
    xail_record_start(*args, &block)
    create_records
  end

  def create_records
    # // Method to create the record window.
    @record_window = Window_Record.new(0, 0)
    @record_window.windowskin = Cache.system(XAIL::RECORDS::SKIN) unless XAIL::RECORDS::SKIN.nil?
  end
  
  def update
    # // Method to update the record window.
    super
    if Input.trigger?(:B)
      return_scene
    end
    if Input.trigger?(:DOWN)
      @record_window.cursor_pagedown
    end
    if Input.trigger?(:UP)
      @record_window.cursor_pageup
    end
  end

end # END OF FILE

#=*==========================================================================*=#
# ** END OF FILE
#=*==========================================================================*=#