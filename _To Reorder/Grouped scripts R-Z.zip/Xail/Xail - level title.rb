#==============================================================================
#   XS - Level Title
#   Author: Nicke
#   Created: 28/12/2012
#   Edited: 28/12/2012
#   Version: 1.0
#==============================================================================
# Instructions
# -----------------------------------------------------------------------------
# To install this script, open up your script editor and copy/paste this script
# to an open slot below ? Materials but above ? Main. Remember to save.
#==============================================================================
# Requires: Numeric Class by IceDragon.
#==============================================================================
# Level Title script which changes how level are displayed.
# The actor is still level 1, 2, 3 etc but displayed differently in the status
# scene.
#
# Use the actor notetag field to setup which title to use for specified actor.
# <level_title: title>
# Where title need to be replaced by the actual titles found in the settings
# below.
#
# Examples:
# <level_title: magician> # Use the magician title.
# <level_title: rank>     # Use the rank title. 
# (Will automatically change the level to roman numerals.)
#
# *** Only for RPG Maker VX Ace. ***
#==============================================================================
($imported ||= {})["XAIL-LVL-TITLE"] = true

module XAIL
  module LVL_TITLES
  #--------------------------------------------------------------------------#
  # * Settings
  #--------------------------------------------------------------------------#
      # Change the titles based on the level of the actor.
      # Starting at level 1.
      # Note: Don't add any titles on rank!
      # TITLES = {symbol => [title, title, title...}
      TITLES = {
        :magician => ["Apprentice", "Novice", "Adept", "Mentalist", 
                      "Channeller", "Sorcerer", "Magister", "Lord Avatar",
                      "Grand Wizard"],
        :fighter  => ["Beginner", "Swordsman", "Warrior", "Berserker"],
        :rank     => ["Rank"] # << Don't edit this! Add more above or below.
      } # Don't remove this line!
  end
end
# *** Don't edit below unless you know what you are doing. ***
#==============================================================================#
# ** RPG::Actor
#==============================================================================#
class RPG::Actor < RPG::BaseItem
  
  def level_title
    # // Method to check level title.
    @note.scan(/<(?:LEVEL_TITLE|level_title):\s(\w+)>/i)
    return $1.to_s
  end
  
end
#==============================================================================#
# ** Game_Actor
#==============================================================================#
class Game_Actor < Game_Battler
  
  attr_reader :level_title
  
  alias xail_lvl_titles_sys_gm_actor_setup setup
  def setup(actor_id)
    # // Method to setup game actor.
    xail_lvl_titles_sys_gm_actor_setup(actor_id)
    @level_title = actor.level_title
  end
end

#==============================================================================#
# ** Window_Base
#==============================================================================#
class Window_Base < Window
  
  def draw_title_level(actor)
    # // New method to draw title level based on specified actor.
    title = actor.level_title
    titles = XAIL::LVL_TITLES::TITLES[title.to_sym]
    # // Check if title is empty or nil.
    unless title == "" and titles.nil?
      for i in 0..titles.size
        # // Rank title based on roman numerals.
        if title.downcase == "rank"
          return titles[0] + " " + actor.level.to_roman 
        # // Else use ordinary titles.
        else 
          if actor.level > titles.size
            return titles.last
          else
            return titles[i - 1] if actor.level == i
          end
        end
      end
    # // Return default level if title are empty or nil.
    else
      return actor.level
    end
  end
  
  def draw_actor_level(actor, x, y)
    # // Method override to draw actor level. 
    # (Used if XS - Status Delux isn't imported.
    lvl = draw_title_level(actor)
    change_color(system_color)
    draw_text(x, y, 32, line_height, Vocab::level_a)
    change_color(normal_color)
    draw_text(x + 32, y, text_size(lvl).width, line_height, lvl, 2)
  end
  
end # END OF FILE

#=*==========================================================================*=#
# ** END OF FILE
#=*==========================================================================*=#