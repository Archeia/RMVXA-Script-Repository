#==============================================================================
#   Simple Gold Hud
#   Author: Nicke
#   Created: 06/06/2012
#   Edited: 20/03/2013
#   Version: 1.0e
#==============================================================================
# Instructions
# -----------------------------------------------------------------------------
# To install this script, open up your script editor and copy/paste this script
# to an open slot below ? Materials but above ? Main. Remember to save.
#==============================================================================
# Requires: XS - Core Script.
#==============================================================================
# *** Only for RPG Maker VX Ace. ***
#==============================================================================
($imported ||= {})["XAIL-SIMPLE-GOLD-HUD"] = true

module XAIL
  module GOLD
  #--------------------------------------------------------------------------#
  # * Settings
  #--------------------------------------------------------------------------#
    # FONT = [name, size, color, bold, shadow]
    FONT = [["Anklada�","Verdana"], 20, Color.new(255,255,255), true, true]

    # GOLD_WINDOW = [width, x, y , opacity, skin]
    WINDOW =  [160, 405, 375,  200, 0, ""]

    # GOLD = [icon, switch_id, show_icon, show_vocab, count_switch]
    GOLD =   [361, 1, true, false, 1]

    # GOLD_COUNT = [sound, vol, pitch, play]
    GOLD_COUNT = ["", 60, 100, false]

    # Count timer for updating the gold.
    GOLD_COUNT_WAIT = 4
    # The time lapse between gold count changing.
    GOLD_CHANGING = 1
  end
end
# *** Don't edit below unless you know what you are doing. ***
#==============================================================================#
# ** Error Handler
#==============================================================================#
  unless $imported["XAIL-XS-CORE"]
    # // Error handler when XS - Core is not installed.
    msg = "The script %s requires the latest version of XS - Core in order to function properly."
    name = "XS - Gold HUD"
    msgbox(sprintf(msg, name))
    exit
  end
#==============================================================================#
# ** Window_Gold_Hud
#------------------------------------------------------------------------------
#  Class for drawing the gold.
#==============================================================================#
class Window_Gold_Hud < Window_Base

  def initialize
    # // Method to initialize the gold window.
    super(0, 0, window_width, fitting_height(1))
    @last_gold = $game_party.gold
    @wait_period = XAIL::GOLD::GOLD_COUNT_WAIT
    refresh
  end

  def window_width
    # // Method to return the width.
    return XAIL::GOLD::WINDOW[0]
  end

  def draw_gold(value, unit, x, y, width)
    # // Method to draw the gold.
    cx = text_size(unit).width
    contents.font = Font.new(XAIL::GOLD::FONT[0], XAIL::GOLD::FONT[1])
    contents.font.color = XAIL::GOLD::FONT[2]
    contents.font.bold = XAIL::GOLD::FONT[3]
    contents.font.shadow = XAIL::GOLD::FONT[4]
    # // Draw gold.
    draw_text(x, y, width - cx - 9, line_height, value, 2)
    # // Draw vocab.
    draw_text(x, y, width, line_height, unit, 2) if XAIL::GOLD::GOLD[3]
    reset_font_settings
  end

  def refresh
    # // Method to refresh the gold.
    contents.clear
    if $game_switches[XAIL::GOLD::GOLD[4]]
      draw_gold($game_party.gold, Vocab::currency_unit, -10, 0, contents.width - 8)
    else
      draw_gold(@last_gold, Vocab::currency_unit, -10, 0, contents.width - 8)
    end
    draw_icon(XAIL::GOLD::GOLD[0], 100, -2) if XAIL::GOLD::GOLD[2]
  end

  def update
    # // Method to update the gold.
    super
    @wait_period -= 1 if @wait_period != 0
    if @last_gold != $game_party.gold and @wait_period == 0
      if @last_gold < $game_party.gold
        @last_gold += 1
      else
        @last_gold -= 1
      end
      if self.visible
        Sound.play(XAIL::GOLD::GOLD_COUNT[0], XAIL::GOLD::GOLD_COUNT[1], XAIL::GOLD::GOLD_COUNT[2]) if XAIL::GOLD::GOLD_COUNT[3]
      end
      refresh
      @wait_period = XAIL::GOLD::GOLD_CHANGING
    end
  end

end
#==============================================================================
# ** Scene_Map
#------------------------------------------------------------------------------
#  Show gold window on the map.
#==============================================================================
class Scene_Map < Scene_Base

  alias xail_gold_hud_create_all_windows create_all_windows
  def create_all_windows(*args, &block)
    # // Method to create all windows.
    xail_gold_hud_create_all_windows(*args, &block)
    create_gold_window 
    check_gold_hud
  end
  
  def create_gold_window
    # // Method to create the gold window.
    @gold_window = Window_Gold_Hud.new
    @gold_window.x = XAIL::GOLD::WINDOW[1]
    @gold_window.y = XAIL::GOLD::WINDOW[2]
    @gold_window.z = XAIL::GOLD::WINDOW[3]
    @gold_window.opacity = XAIL::GOLD::WINDOW[4]
    @gold_window.windowskin = Cache.system(XAIL::GOLD::WINDOW[5]) unless XAIL::GOLD::WINDOW[5] == ""
  end

  alias xail_gold_window_update update
  def update(*args, &block)
    # // Method to update the gold window on the map.
    xail_gold_window_update(*args, &block)
    check_gold_hud
  end
  
  def check_gold_hud
    # // Method to check gold hud if it is enabled/disabled.
    if $game_switches[XAIL::GOLD::GOLD[1]]
      dispose_map_hud if @gold_window.nil?
    else
      dispose_map_hud
    end
  end
  
  def dispose_map_hud
    # // Method to dipose map hud.
    @gold_window.dispose unless @gold_window.nil?
    @gold_window = nil
  end

end # END OF FILE

#=*==========================================================================*=#
# ** END OF FILE
#=*==========================================================================*=#