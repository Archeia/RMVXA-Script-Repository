#==============================================================================
#   XaiL System - Footstep Sounds
#   Author: Nicke
#   Created: 24/01/2013
#   Edited: 06/02/2013
#   Version: 1.0a
#==============================================================================
# Instructions
# -----------------------------------------------------------------------------
# To install this script, open up your script editor and copy/paste this script
# to an open slot below ? Materials but above ? Main. Remember to save.
#
# Simple footstep sounds based on the terrain id tag.
#
# To setup simply choose one of the terrain tags in the tileset to the
# footstep you want.
#
# Default footstep sounds are:
# 1 = Grass
# 2 = Sand
# 
# Add more in the settings below.
#
# You can also tag an event to use a footstep sound by using a comment:
# <FOOTSTEP_SOUND: sound_name>
#
# Example:
# <FOOTSTEP_SOUND: Parry> # Will play the SE "Parry" as soon as the event moves.
#
# *** Only for RPG Maker VX Ace. ***
#==============================================================================
($imported ||= {})["XAIL-FOOTSTEP-SOUNDS"] = true

module XAIL
  module FOOTSTEP_SOUNDS
  #--------------------------------------------------------------------------#
  # * Settings
  #--------------------------------------------------------------------------#
    # LIST = { # TERRAIN_ID => [sound, volume, pitch] }
    LIST = {
      1 => ["Grass", 20, 100],
      2 => ["Sand", 20, 150],
    } # Don't remove this line!
    
    # EVENT = [volume, pitch]
    EVENT = [50, 100]
    
    # Switch to enable/disable the script.
    # If the switch is on/true it will disable the script.
    # SWITCH = id
    SWITCH = 1
    
  end
end
# *** Don't edit below unless you know what you are doing. ***
#==============================================================================#
# ** Error Handler
#==============================================================================#
  unless $imported["XAIL-XS-CORE"]
    # // Error handler when XS - Core is not installed.
    msg = "The script %s requires the latest version of XS - Core in order to function properly."
    name = "XS - Footstep Sounds"
    msgbox(sprintf(msg, name))
    exit
  end
#==============================================================================
# ** Game_Character
#==============================================================================
class Game_Character < Game_CharacterBase

  def play_footstep(sound)
    # // Method to play a footstep sound.
    return if $game_switches[XAIL::FOOTSTEP_SOUNDS::SWITCH] or sound.nil?
    return unless @move_succeed
    Sound.play(sound[0], sound[1], sound[2])
  end

end
#==============================================================================
# ** Game_Player
#==============================================================================
class Game_Player < Game_Character
  
  alias xail_footstep_sounds_gm_player_move_straight move_straight
  def move_straight(*args, &block)
    # // Method to move the player.
    xail_footstep_sounds_gm_player_move_straight(*args, &block)
    play_footstep(XAIL::FOOTSTEP_SOUNDS::LIST[terrain_tag])
  end
  
  alias xail_footstep_sounds_gm_player_move_diagonal move_diagonal
  def move_diagonal(*args, &block)
    # // Method to move the player diagonal.
    xail_footstep_sounds_gm_player_move_diagonal(*args, &block)
    play_footstep(XAIL::FOOTSTEP_SOUNDS::LIST[terrain_tag])
  end

end 
#==============================================================================
# ** Game_Event
#==============================================================================
class Game_Event < Game_Character
  
  alias xail_footstep_sounds_gm_evt_setup_page_settings setup_page_settings
  def setup_page_settings(*args, &block)
    # // Method to setup page settings for an event.
    xail_footstep_sounds_gm_evt_setup_page_settings(*args, &block)
    footstep_sound = comment_string?("FOOTSTEP_SOUND")
    @footstep_sound = footstep_sound if footstep_sound.is_a?(String)
    @footstep_vol = XAIL::FOOTSTEP_SOUNDS::EVENT[0]
    @footstep_pitch = XAIL::FOOTSTEP_SOUNDS::EVENT[1]
  end
  
  alias xail_footstep_sounds_gm_evt_move_type_random move_type_random
  def move_type_random(*args, &block)
    # // Method to move event random.
    xail_footstep_sounds_gm_evt_move_type_random(*args, &block)
    play_footstep([@footstep_sound, @footstep_vol, @footstep_pitch])
  end
  
  alias xail_footstep_sounds_gm_evt_move_type_custom move_type_custom
  def move_type_custom(*args, &block)
    # // Method to move event custom.
    xail_footstep_sounds_gm_evt_move_type_custom(*args, &block)
    play_footstep([@footstep_sound, @footstep_vol, @footstep_pitch])
  end
  
  alias xail_footstep_sounds_gm_evt_move_type_toward_player move_type_toward_player
  def move_type_toward_player(*args, &block)
    # // Method to move event toward player.
    xail_footstep_sounds_gm_evt_move_type_toward_player(*args, &block)
    play_footstep([@footstep_sound, @footstep_vol, @footstep_pitch])
  end

end # END OF FILE

#=*==========================================================================*=#
# ** END OF FILE
#=*==========================================================================*=#