#==============================================================================
#   XaiL System - Hero Control
#   Author: Nicke
#   Created: 22/04/2012
#   Edited: 24/04/2012
#   Version: 1.0
#==============================================================================
# Instructions
# -----------------------------------------------------------------------------
# To install this script, open up your script editor and copy/paste this script
# to an open slot below ? Materials but above ? Main. Remember to save.
#
# Control your hero!
#
# This snippet enables you to control your character as you wish. 
# For example, set the max stack number of a specific item (Default 99).
# Set a max level for your hero.
#
# In order to change a item max stack do the following:
# Set the item_id variable to the id you want to change then increase/decrease
# the item_value variable to the value you want to set.
#
# You can control the movement speed as well using the following script call:
# $game_player.speed(4.0) # // Default movement speed.
#
# *** Only for RPG Maker VX Ace. ***
#==============================================================================
($imported ||= {})["XAIL-HERO-CONTROL"] = true

module XAIL
  module HERO_CONTROL
  #--------------------------------------------------------------------------#
  # * Settings
  #--------------------------------------------------------------------------#
      # Item variables.
      # ITEM = [item_id, item_value]
      ITEM = [10, 11]
      
      # Control max gold with variable:
      # GOLD = number
      GOLD = 12
      
      # Control max level with variable:
      # LEVEL = number
      LEVEL = 13
      
      # Control vehicle speed with variable:
      # VEHICLE = [boat, ship, airship]
      VEHICLE = [14, 15, 16]
  end
end
# *** Don't edit below unless you know what you are doing. ***
#==============================================================================#
# ** RPG::BaseItem
#==============================================================================#
class RPG::BaseItem
  
  def item_max
    # // Method to set item max.
    case id
    when $game_variables[XAIL::HERO_CONTROL::ITEM[0]]
      return $game_variables[XAIL::HERO_CONTROL::ITEM[1]]
    else
      return 99
    end
  end
  
end
#==============================================================================#
# ** Game_Party
#==============================================================================#
class Game_Party < Game_Unit
  
  alias xail_hero_control_max_item_nr max_item_number
  def max_item_number(item)
    # // Method to return the item max number.
    xail_hero_control_max_item_nr(item)
    return item.item_max
  end
  
  alias xail_hero_control_max_gold max_gold
  def max_gold(*args, &block)
    #  // Method to return max_gold.
    if $game_variables[XAIL::HERO_CONTROL::GOLD] == 0
      xail_hero_control_max_gold(*args, &block)
    else
      max_gold = $game_variables[XAIL::HERO_CONTROL::GOLD]
    end
  end
  
end 
#==============================================================================#
# ** Game_Actor
#==============================================================================#
class Game_Actor < Game_Battler
  
  alias xail_hero_control_max_level max_level
  def max_level(*args, &block)
    # // Method to control the max level.
    xail_hero_control_max_level(*args, &block)
    lvl = $game_variables[XAIL::HERO_CONTROL::LEVEL]
    lvl = lvl == 0 ? actor.max_level : lvl
  end
  
  alias xail_hero_control_change_exp change_exp
  def change_exp(exp, show)
    # // Method to change exp.
    if @level == $game_variables[XAIL::HERO_CONTROL::LEVEL]
      return @exp[@class_id] = [0, 0].max
    end
    xail_hero_control_change_exp(exp, show)
  end

end 
#==============================================================================#
# ** Game_Player
#==============================================================================#
class Game_Player < Game_Character
    
  def speed(speed)
    # // Method to control the movement speed.
    @move_speed = speed
  end
  
end
#==============================================================================#
# ** Game_Vehicle
#==============================================================================#
class Game_Vehicle < Game_Character
  
  alias xail_hero_control_init_move_speed init_move_speed
  def init_move_speed(*args, &block)
    # // Method to control the vehicle speed.
    xail_hero_control_init_move_speed(*args, &block)
    @move_speed = $game_variables[XAIL::HERO_CONTROL::VEHICLE[0]] if @type == :boat
    @move_speed = $game_variables[XAIL::HERO_CONTROL::VEHICLE[1]] if @type == :ship
    @move_speed = $game_variables[XAIL::HERO_CONTROL::VEHICLE[2]] if @type == :airship
  end
  
end # END OF FILE

#=*==========================================================================*=#
# ** END OF FILE
#=*==========================================================================*=#