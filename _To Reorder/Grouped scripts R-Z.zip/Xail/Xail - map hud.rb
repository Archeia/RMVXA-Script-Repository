#==============================================================================
#   XS - Map Hud
#   Author: Nicke
#   Created: 03/04/2012
#   Edited: 03/11/2012
#   Version: 1.0c
#==============================================================================
# Instructions
# -----------------------------------------------------------------------------
# To install this script, open up your script editor and copy/paste this script
# to an open slot below ? Materials but above ? Main. Remember to save.
#==============================================================================
# Requires: XS - Core Script.
#==============================================================================
# A small hud that will animate in and display the map name.
# See settings to change everything regarding the hud.
# If the hud doesn't display properly try to change the font, x or y positions.
#
# *** Only for RPG Maker VX Ace. ***
#==============================================================================
($imported ||= {})["XAIL-MAP-HUD"] = true

module XAIL
  module MAP_HUD
  #--------------------------------------------------------------------------#
  # * Settings
  #--------------------------------------------------------------------------#
    # FONT = [name, size, color, bold, shadow]
    FONT = ["Anklada�", 20, Color.new(255,255,255), true, true]

    # HUD = [icon, show_icon, switch_id, x, y, opacity, skin]
    HUD =  [2379, true, 91, -6, -10, 0, nil]
    
    # Note: At the moment the animation depends on the position so you might 
    # need to do some tweaking if you want the animation to be consistent 
    # with your custom position.
    # The available types for animating the hud is the following:
    # :fade # // Fades in hud.
    # :move_x // Slides in on x pos.
    # :move_y // Slides in on y pos.
    # nil to disable.
    # ANIMATE_TYPE = :symbol
    ANIMATE_TYPE = :fade
    
    # Amount of frames for the animation. 60 frames = 1 second.
    # ANIMATE_TIMER = number
    ANIMATE_TIMER = 40
    
    # Show map hud only for these map_id(s).
    # SHOW_MAP_ID = [map_ids]
    # nil to disable.
    SHOW_MAP_ID = nil
    
    # Specific color for each maps.
    # Set to nil to disable.
    # MAP_COLOR[map_id] = [color]
    MAP_COLOR =  nil
    
    MAPNAME_REPLACE = {                    # Map ID => "Replaced Name"
      #1 => "Replacing the name with a super long string, seems to be working"
    } # Don't remove this line!

    # For advanced replacement:
    # If you don't use the replace method feel free to comment it out.
    #=========================================================================#
    TEMP = "Test name"
    TEMP2 = "Another name"
    
    # Method for replacing the map name.
    def self.replace_mapname(oldname, map_id)    
      case map_id
        when 998 ; return TEMP
        when 999 ; return TEMP2
      end
      return MAPNAME_REPLACE[map_id] if MAPNAME_REPLACE.has_key?(map_id)
      return oldname
    end
    #=========================================================================#
  end
end
# *** Don't edit below unless you know what you are doing. ***
#==============================================================================#
# ** Error Handler
#==============================================================================#
  unless $imported["XAIL-XS-CORE"]
    # // Error handler when XS - Core is not installed.
    msg = "The script %s requires the latest version of XS - Core in order to function properly."
    name = "XS - Map Hud"
    msgbox(sprintf(msg, name))
    exit
  end
#==============================================================================#
# ** Game_Map
#------------------------------------------------------------------------------
#  Class for reading the map id and name.
#==============================================================================#
class Game_Map
  
  attr_reader :name
  
  alias xail_map_hud_setup setup
  def setup(map_id)
    # // Method to setup the map id.
    xail_map_hud_setup(map_id)
    @map_infos = load_data("Data/MapInfos.rvdata2") if @map_infos.nil?
    @name = XAIL::MAP_HUD.replace_mapname(@map_infos[@map_id].name, @map_id)
  end
  
end
#==============================================================================#
# ** Window_MapHud
#------------------------------------------------------------------------------
#  Class for drawing the map hud.
#==============================================================================#
class Window_MapHud < Window_Base
  
  def initialize(width)
    # // Method to initialize the map hud window.
    super(0, 0, width, window_height)
    @map_id = $game_map.map_id
    refresh
  end
  
  def window_height
    # // Method to return the height.
    return 60
  end
  
  def refresh
    # // Method to refresh the map hud.
    contents.clear
    draw_map_hud # // Draw map.
    draw_icon(XAIL::MAP_HUD::HUD[0], 0, 0) if XAIL::MAP_HUD::HUD[1]
  end
  
  def draw_map_hud
    # // Method to draw the hud.
    # // Draw line.
    draw_line_ex(20, 8, Color.new(255,255,255,64), Color.new(0,0,0,255))
    map = $game_map.name.to_s
    cx = text_size($game_map.name).width
    cy = text_size($game_map.name).height
    contents.font = Font.new(XAIL::MAP_HUD::FONT[0], XAIL::MAP_HUD::FONT[1])
    contents.font.out_color = Color.new(0,0,0,255)
    contents.font.shadow = XAIL::MAP_HUD::FONT[3]
    if XAIL::MAP_HUD::HUD[1]
      contents.font.color = Color.new(0,0,0,255)
      draw_text(28, 2, cx + 24, cy, map, 0)
      unless XAIL::MAP_HUD::MAP_COLOR.nil?
        contents.font.color = XAIL::MAP_HUD::MAP_COLOR[@map_id][0]
      else
        contents.font.color = XAIL::MAP_HUD::FONT[2]
      end
      draw_text(28, 1, cx + 24, cy, map, 0)
    else
      contents.font.color = Color.new(0,0,0,255)
      draw_text(1, 2, cx + 24, cy, map, 0)
      unless XAIL::MAP_HUD::MAP_COLOR.nil?
        contents.font.color = XAIL::MAP_HUD::MAP_COLOR[@map_id][0]
      else
        contents.font.color = XAIL::MAP_HUD::FONT[2]
      end
      draw_text(0, 0, cx + 24, cy, map, 0)
    end
    reset_font_settings
  end

  def update
    # // Method to update the hud.
    super
    if @map_id != $game_map.map_id # // Only refresh if map changed.
      @map_id = $game_map.map_id
      refresh
    end  
  end

end
#==============================================================================
# ** Scene_Map
#------------------------------------------------------------------------------
#  Show map hud on Scene_Map.
#==============================================================================
class Scene_Map < Scene_Base
  
  alias xail_map_hud_window_start start
  def start(*args, &block)
    # // Method to start the map hud window on the map.
    xail_map_hud_window_start(*args, &block)
    dummy_bitmap
    create_map_hud_window 
    pre_animate_in
    map_vis
  end
  
  def dummy_bitmap
    # // Create a dummy bitmap to determine the size of the map name.
    @dummy = Bitmap.new(1,1)
    @width = @dummy.text_size($game_map.name).width + 46
    # // Offset width if map name is very long.
    if @width > 220
      @width -= 12
    end
  end
  
  def create_map_hud_window
    # // Method to create the map hud window.
    @map_hud_window = Window_MapHud.new(@width)
    @map_hud_window.x = XAIL::MAP_HUD::HUD[3]
    @map_hud_window.y = XAIL::MAP_HUD::HUD[4]
    @map_hud_window.z = 3
    @map_hud_window.opacity = XAIL::MAP_HUD::HUD[5]
    @map_hud_window.windowskin = Cache.system(XAIL::MAP_HUD::HUD[6]) unless XAIL::MAP_HUD::HUD[6].nil?
  end

  alias xail_map_hud_post_start post_start
  def post_start(*args, &block)
    # // Method post_start.
    xail_map_hud_post_start(*args, &block)
    animate_in unless XAIL::MAP_HUD::ANIMATE_TYPE.nil?
  end
  
  alias xail_map_hud_pre_terminate pre_terminate 
  def pre_terminate(*args, &block)
    # // Method post_start.
    xail_map_hud_pre_terminate(*args, &block)
    animate_out unless XAIL::MAP_HUD::ANIMATE_TYPE.nil?
  end
  
  def animate_in
    # // Method to animate in the map hud window.
    @timer = XAIL::MAP_HUD::ANIMATE_TIMER
    anim_type(XAIL::MAP_HUD::ANIMATE_TYPE)
  end
  
  def animate_out
    # // Method to animate out the map hud window.
    @timer = XAIL::MAP_HUD::ANIMATE_TIMER
    anim_type(XAIL::MAP_HUD::ANIMATE_TYPE, :out)
  end
  
  def anim_type(type, anim = :in)
    # // Method to choose animation type.
    t = XAIL::MAP_HUD::ANIMATE_TIMER
    case type
    when :fade
      if anim == :in
        return @map_hud_window.contents_opacity += 255 / t
      end
      if anim == :out
        return @map_hud_window.contents_opacity -= 255
      end
    when :move_x
      if anim == :in
        return @map_hud_window.x += 180 / t
      end
      if anim == :out
        return @map_hud_window.x -= 180
      end
    when :move_y
      if anim == :in
        return @map_hud_window.y += 170 / t
      end
      if anim == :out
        return @map_hud_window.y -= 170
      end
    end
  end

  def pre_animate_in
    # // Method to pre animate the map hud window.
    anim_type(XAIL::MAP_HUD::ANIMATE_TYPE, :out) unless XAIL::MAP_HUD::ANIMATE_TYPE.nil?
  end
  
  alias xail_map_hud_pref_transfer perform_transfer
  def perform_transfer(*args, &block)
    # // Method to perform a player transfer to another map.
    xail_map_hud_pref_transfer(*args, &block)
    dispose_map_hud_window
    dispose_dummy_bitmap
    dummy_bitmap
    create_map_hud_window
    pre_animate_in
    animate_in
  end
  
  def map_vis
    # // Method to check visibility.
    @map_hud_window.visible = $game_switches[XAIL::MAP_HUD::HUD[2]]
    unless XAIL::MAP_HUD::SHOW_MAP_ID.nil?
      if XAIL::MAP_HUD::SHOW_MAP_ID.include?($game_map.map_id)
         @map_hud_window.visible = true
      else
        @map_hud_window.visible = false
      end
    end
  end
  
  alias xail_map_hud_window_update update
  def update(*args, &block)
    # // Method to update the map hud window.
    xail_map_hud_window_update(*args, &block)
    unless XAIL::MAP_HUD::ANIMATE_TYPE.nil?
      if @timer > 0
        anim_type(XAIL::MAP_HUD::ANIMATE_TYPE)
        @timer -= 1
      end
    end
    map_vis
  end
  
  def dispose_map_hud_window
    # // Method to dispose the map hud window.
    @map_hud_window.dispose unless @map_hud_window.nil?
    @map_hud_window = nil
  end
  
  def dispose_dummy_bitmap
    # // Method to dispose dummy bitmap.
    @dummy.dispose unless @dummy.nil?
    @dummy = nil
  end
  
  alias xail_map_hud_window_terminate terminate
  def terminate(*args, &block)
    # // Method to terminate the map hud window on the map.
    xail_map_hud_window_terminate(*args, &block)
    dispose_map_hud_window
    dispose_dummy_bitmap
  end

end # END OF FILE

#=*==========================================================================*=#
# ** END OF FILE
#=*==========================================================================*=#