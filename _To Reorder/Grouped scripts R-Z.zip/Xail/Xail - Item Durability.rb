#==============================================================================
#  XaiL System - Item Durability
#  Author: Nicke
#  Created: 23/07/2012
#  Edited: 28/08/2012
#  Version: 1.0b
#==============================================================================
# Instructions
# -----------------------------------------------------------------------------
# To install this script, open up your script editor and copy/paste this script
# to an open slot below ? Materials but above ? Main. Remember to save.
#
# This script is pretty extensive which means you need to configure it to 
# get it as you want it.
#
# To setup a durability/max durability value for an item do the following in the 
# notetag:
# <durability: n>
# <max_durability: n>
# Where n is a floated value (2.3, 2.5 for example).
#
# You can also enable/disable repairing for an item:
# <repairable: bool>
# Where bool is true or false.
# This option will be true as default if you don't specify it.
#
# To check an item's current durability value, do the following in a script call:
# $game_party.durability?(item_id, item_type)
# $game_party.durability?(1, :weapon)
# $game_party.durability?(2, :armor)
# $game_party.durability?(3, :item)
#
# All of those calls above will return the current durability value for each item.
# You can also check the max durability value as well:
# $game_party.max_durability?(item_id, item_type)
# $game_party.max_durability?(3, :item)
#
# Althought the shop is intended for repairing you can force repair an item
# without it costing any gold by the following script call:
# $game_party.change_durability(nil, :repair, 2, :weapon)
# This will repair item_id 2 for weapons without it costing any gold.
#
# Using the same method but with a different option you can damage your item
# by doing the following instead:
# $game_party.change_durability(value, type, item, item_type)
# $game_party.change_durability(0.5, :damage, 2, :weapon)
# This will damage item_id 2 for weapons by a value of 0.5.
#
# You can also restore durability value for an item:
# $game_party.change_durability(2.0, :restore, 2, :weapon)
# This will restore 2.0 durability value to the current value.
#
# You can check if an item can be repaired:
# $game_party.repairable?(1, :item)
#
# You can alter the repair/damage formula in the settings.
# Default for repairing is half the item's price.
# Default for damaging an item is a randomized value by 0.1-0.5 with a 
# probability chance at 1/5.
#
# Current durability status for items will be displayed at the end of battle.
# This will only work for the default battle system at the moment.
# A few settings is located below to setup up this.
#
# *** Only for RPG Maker VX Ace. ***
#==============================================================================
($imported ||= {})["XAIL-ITEM-DURABILITY"] = true

module XAIL
  module ITEM_DURABILITY
  #--------------------------------------------------------------------------#
  # * Settings
  #--------------------------------------------------------------------------# 
    # FONT = [name, size, color, bold, shadow]
    FONT = [["Anklada™", "Verdana"], 16, Color.new(255,225,255), true, true]
    
    # Show/hide option for the ahop scene.
    # DISPLAY = [show_help_icon, show_name, show_description, 
    # show_type, show_amount]
    DISPLAY = [true, true, true, true, true]
    
    # Set the name of repair in the shop scene.
    # REPAIR_COMMAND = string
    REPAIR_COMMAND = "Repair"
    
    # Set the repair cost forumla.
    def self.repair_price(item)
      return item.price / 2
    end
    
    # Set the damage formula.
    def self.durability_damage
      return rand(5) == 0 ? rand(5).to_f/10 + 0.1 : 0
    end
    
    # USE_BROKEN = true/false
    # Should you be able to equip broken items.
    USE_BROKEN = false
    
    # TEXT_BROKEN = string
    # Set the text for a broken item. (Used in battle)
    TEXT_BROKEN = "Broken:"
    
    # DURABILITY_LOG = true/false
    # Display durability status at scene battle. (Default battle system)
    DURABILITY_LOG = true
    
    # LOG_WAIT = number
    # How many times should the durability log wait.
    LOG_WAIT = 3
    
  end
end
# *** Don't edit below unless you know what you are doing. ***
#==============================================================================#
# ** RPG::BaseItem
#==============================================================================#
class RPG::BaseItem
  
  attr_accessor :durability
  
  alias xail_item_durability_baseitem_init initialize
  def initialize(*args, &block)
    # // Method to initialize.
    xail_item_durability_baseitem_init(*args, &block)
    @durability = 0
  end
  
  def durability
    # // Method to check the item durability.
    @note.scan(/<(?:DURABILITY|durability):\s(\d+.\d+)>/i)
    return @durability unless @durability.nil?
    return ($1.to_f > 0.0 ? $1.to_f : 0.0)
  end
  
  def max_durability
    # // Method to check the item max durability.
    @note.scan(/<(?:MAX_DURABILITY|max_durability):\s(\d+.\d+)>/i)
    return ($1.to_f > 0.0 ? $1.to_f : 0.0)
  end
  
  def repairable
    # // Method to check if item is repairable.
    @note.scan(/<(?:REPAIRABLE|repairable):\s+(true|false)>/i)
    return false if durability == max_durability
    return true if $1.nil?
    return eval($1)
  end

end
#==============================================================================#
# ** Game_Party
#==============================================================================#
class Game_Party < Game_Unit
  
  def check_type(item_type)
    # // Method to check the item type.
    case item_type
    when :item  ; item_type = $data_items
    when :weapon ; item_type = $data_weapons
    when :armor  ; item_type = $data_armors
    end
    item_type
  end
  
  def durability?(item_id, item_type)
    # // Method to check the current durability of a specified id.
    item_type = check_type(item_type)
    item_type[item_id].durability unless item_type[item_id].nil?
  end
  
  def max_durability?(item_id, item_type)
    # // Method to check the maximum durability of a specified id.
    item_type = check_type(item_type)
    item_type[item_id].max_durability unless item_type[item_id].nil?
  end
  
  def change_durability(value, type, item_id, item_type)
    # // Method to change the durability value for an item.
    item_type = check_type(item_type)
    item = item_type[item_id]
    case type
    when :restore
      item.durability = (item.durability + value).clamp(0, item.max_durability)
    when :damage
      item.durability = (item.durability - value).clamp(0, item.max_durability)
    when :repair
      item.durability = item.max_durability
    end unless item.nil?
  end
  
  def repairable?(item_id, item_type)
    # // Method to check if an item can be repaired.
    item_type = check_type(item_type)
    item_type[item_id].repairable
  end
  
end
#==============================================================================#
# ** Game_Battler
#==============================================================================#
class Game_Battler < Game_BattlerBase
  
  alias xail_item_durability_gm_battler_execute_damage execute_damage
  def execute_damage(user)
    # // Method to execute damage.
    if user.is_a?(Game_Actor)
      r = Random.new
      r = r.rand(0..4)
      item = user.actor.equips[r]
      item_type = :armor ; item_type = :weapon if r == 0
      $game_party.change_durability(XAIL::ITEM_DURABILITY.durability_damage, :damage, item, item_type)
      if $game_party.durability?(item, item_type) == 0
        $game_actors[user.actor.id].change_equip(r, nil)
      end
    end
    xail_item_durability_gm_battler_execute_damage(user)
  end
  
end
#==============================================================================#
# ** Game_Actor
#==============================================================================#
class Game_Actor < Game_Battler
  
  def optimize_equipments
    # // Method override optimize equipments.
    clear_equipments
    equip_slots.size.times do |i|
      next if !equip_change_ok?(i)
      items = $game_party.equip_items.select do |item|
        item.etype_id == equip_slots[i] &&
        equippable?(item) && item.performance >= 0 && item.durability != 0.0
      end
      change_equip(i, items.max_by {|item| item.performance })
    end
  end
  
end
#==============================================================================#
# ** Window_Help
#==============================================================================#
class Window_Help < Window_Base
  
  def set_durability_help(item)
    # // Method to set the item for window help.
    contents.font.name = XAIL::ITEM_DURABILITY::FONT[0]
    contents.font.bold = XAIL::ITEM_DURABILITY::FONT[3]
    contents.font.shadow = XAIL::ITEM_DURABILITY::FONT[4]
    contents.font.out_color = Color.new(0,0,0,255)
    if item
      icon = XAIL::ITEM_DURABILITY::DISPLAY[0] ? '\i[' + item.icon_index.to_s + ']' : ""
      name = XAIL::ITEM_DURABILITY::DISPLAY[1] ? '\c[2] »» ' + item.name + '\c[0]' : ""
      desc = XAIL::ITEM_DURABILITY::DISPLAY[2] ? item.description : ""
      weight = $imported["XAIL-INVENTORY-WEIGHT"] ? weight = " - Weight: #{item.weight}." : ""
      durability = " - Durability: #{item.durability} / #{item.max_durability}."
      if XAIL::ITEM_DURABILITY::DISPLAY[3]
        if item.is_a?(RPG::Weapon) ; item_type = " (" + $data_system.weapon_types[item.wtype_id] + ")" end
        if item.is_a?(RPG::Armor) ; item_type = " (" + $data_system.armor_types[item.etype_id] + ")" end
      else
        item_type = ""
      end
      new_line = "\n"
      item_text = icon + name + item_type.to_s + weight + durability + new_line + desc
    else
      item_text = ""
    end
    set_text(item_text)
  end
  
end
#==============================================================================
# ** Window_ShopCommand
#==============================================================================
class Window_ShopCommand < Window_HorzCommand
  
  def col_max
    # // Method to set col max.
    return 4
  end

  alias xail_item_durability_winshop_make_cmd_list make_command_list
  def make_command_list(*args, &block)
    # // Method to make command list.
    xail_item_durability_winshop_make_cmd_list(*args, &block)
    add_command(XAIL::ITEM_DURABILITY::REPAIR_COMMAND, :repair)
  end
  
end
#==============================================================================
# ** Window_ShopRepair
#==============================================================================
class Window_ShopRepair < Window_ItemList

  def initialize(x, y, width, height)
    # // Method to initialize.
    super(x, y, width, height)
  end
  
  def enable?(item)
    # // Method to check if a item is valid to be repair. 
    item && XAIL::ITEM_DURABILITY.repair_price(item) <= $game_party.gold && 
    !$game_party.item_max?(item) && item.max_durability != item.durability
  end
  
  alias xail_item_durability_shop_update_help update_help
  def update_help(*args, &block)
    # // Method to check if a item is valid to be repair.
    xail_item_durability_shop_update_help(*args, &block)
    @help_window.set_durability_help(item) if @help_window
  end
  
end
#==============================================================================#
# ** Window_BattleLog
#==============================================================================#
class Window_BattleLog < Window_Selectable
  
  def display_durability(battler)
    # // Method to display durability status in battle.
    # i.e if a item has been broken.
    if battler.is_a?(Game_Actor)
      for i in 0..4
        item = battler.actor.equips[i]
        item_type = :armor ; item_type = :weapon if i == 0
        if $game_party.durability?(item, item_type) == 0
          item_type = $game_party.check_type(item_type)
          item = item_type[item]
          item = XAIL::ITEM_DURABILITY::TEXT_BROKEN + " " + item.name
          add_text(sprintf(item))
          XAIL::ITEM_DURABILITY::LOG_WAIT.times do
            wait
          end
        end
      end
    end
  end
  
end
#==============================================================================#
# ** Window_EquipItem
#==============================================================================#
class Window_EquipItem < Window_ItemList
  
  alias xail_item_durability_win_equip_enable? enable? 
  def enable?(item)
    # // Method to check if a item is enabled/disabled.
    return false if item.durability == 0 && !XAIL::ITEM_DURABILITY::USE_BROKEN unless item.nil?
    xail_item_durability_win_equip_enable?(item)
  end

end
#==============================================================================#
# ** Scene_Shop
#==============================================================================#
class Scene_Shop < Scene_MenuBase
  
  alias xail_item_durability_shop_start start
  def start(*args, &block)
    # // Method to start the scene.
    xail_item_durability_shop_start(*args, &block)
    create_repair_window
  end
  
  alias xail_item_durability_shop_create_cmd_win create_command_window
  def create_command_window(*args, &block)
    # // Method to create command window.
    xail_item_durability_shop_create_cmd_win(*args, &block)
    @command_window.set_handler(:repair, method(:command_repair))
  end
  
  def create_repair_window
    # // Method to create repair window.
    wy = @category_window.y + @category_window.height
    wh = Graphics.height - wy
    @repair_window = Window_ShopRepair.new(0, wy, Graphics.width, wh)
    @repair_window.viewport = @viewport
    @repair_window.help_window = @help_window
    @repair_window.hide
    @repair_window.set_handler(:ok,    method(:on_repair_ok))
    @repair_window.set_handler(:cancel, method(:on_repair_cancel))
    @category_window.item_window = @repair_window
  end
  
  def command_repair
    # // Method for command repair.
    @dummy_window.hide
    @category_window.show.activate
    @repair_window.show
    @repair_window.unselect
    @repair_window.refresh
  end
  
  def activate_repair
    # // Method to active command options.
    @repair_window.select(0)
    @category_window.show
    @repair_window.refresh
    @repair_window.show.activate
    @status_window.hide
  end
  
  alias xail_item_durability_shop_on_cat_ok on_category_ok
  def on_category_ok(*args, &block)
    # // Method for category ok.
    case @command_window.current_symbol
    when :repair
      activate_repair
    when :sell
      xail_item_durability_shop_on_cat_ok(*args, &block)
    end
  end
  
  alias xail_item_durability_shop_on_cat_cancel on_category_cancel
  def on_category_cancel(*args, &block)
    # // Method for category cancel.
    xail_item_durability_shop_on_cat_cancel(*args, &block)
    @repair_window.hide
  end
  
  def on_repair_ok
    # // Method to repair item.
    @item = @repair_window.item
    @status_window.item = @item
    @category_window.hide
    @repair_window.hide
    @number_window.set(@item, max_item, repair_price, currency_unit)
    @number_window.show.activate
    @status_window.show
  end
  
  def on_repair_cancel
    # // Method to cancel repair.
    @repair_window.unselect
    @category_window.activate
    @status_window.item = nil
    @help_window.clear
  end
  
  alias xail_item_durability_shop_on_number_ok on_number_ok
  def on_number_ok(*args, &block)
    # // Method on number ok.
    if @command_window.current_symbol == :repair
      do_repair(@number_window.number)
    end
    xail_item_durability_shop_on_number_ok(*args, &block)
  end
  
  alias xail_item_durability_shop_end_number_input end_number_input
  def end_number_input(*args, &block)
    # // Method to check input number.
    if @command_window.current_symbol == :repair
      activate_repair 
    end
    xail_item_durability_shop_end_number_input(*args, &block)
  end
  
  def do_repair(number)
    # // Method to do repair.
    if @item.is_a?(RPG::Item)  ; item_type = :item    end
    if @item.is_a?(RPG::Weapon) ; item_type = :weapon  end
    if @item.is_a?(RPG::Armor)  ; item_type = :armor    end
    $game_party.lose_gold(number * repair_price)
    $game_party.change_durability(nil, :repair, @item.id, item_type)
    @repair_window.refresh
    @gold_window.refresh
    @status_window.refresh
    @help_window.refresh
  end
  
  def max_item
    # // Method to determine max item.
    $game_party.item_number(@item)
  end
  
  def repair_price
    # // Method to set the repair price for the item.
    XAIL::ITEM_DURABILITY.repair_price(@item)
  end
  
end 
#==============================================================================#
# ** Scene_Battle
#==============================================================================#
class Scene_Battle < Scene_Base
  
  alias xail_item_durability_scene_battle_process_action_end process_action_end
  def process_action_end(*args, &block)
    # // Method when process end at scene battle.
    if XAIL::ITEM_DURABILITY::DURABILITY_LOG
      @log_window.display_durability(@subject)
      @log_window.wait_and_clear
    end
    xail_item_durability_scene_battle_process_action_end(*args, &block)
  end

end # END OF FILE

#=*==========================================================================*=#
# ** END OF FILE
#=*==========================================================================*=#