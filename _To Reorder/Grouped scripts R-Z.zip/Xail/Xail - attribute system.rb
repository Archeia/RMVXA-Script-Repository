#==============================================================================
#   XaiL System - Attribute System
#   Author: Nicke
#   Created: 01/08/2012
#   Edited: 28/12/2012
#   Version: 1.1b
#==============================================================================
# Instructions
# -----------------------------------------------------------------------------
# To install this script, open up your script editor and copy/paste this script
# to an open slot below ? Materials but above ? Main. Remember to save.
#==============================================================================
# Requires: XS - Core Script.
# Numeric Class by IceDragon.
#==============================================================================
# Attribute system. This script will allow you to gain attribute points each
# time an actor gains a level. Those points can then be spend as the user wish.
# For example, increase the health of the character or the magic resistance.
#
# To call this scene in the menu or any time during the game, use the following
# script call:
# SceneManager.call(Scene_Attribute)
#
# Use the following script calls to reward/remove points.
# $game_party.attribute(actor_id, value, type = :gain)
# $game_party.attribute(1, 5)
# $game_party.attribute(2, 5, :lose)
# This will return nil if the specified actor isn't in the party.
#
# Do this to check how many attribute points an actor have:
# $game_party.attribute?(actor_id)
# $game_party.attribute?(1)
# This will return nil if the specified actor isn't in the party.
#
# You can change the actor points, icons, cost, max stats etc in the settings.
# This script also support own background for the attribute windows.
#
# Note: At the scene you can change actor using Q or W like in the status scene.
#
# *** Only for RPG Maker VX Ace. ***
#==============================================================================
($imported ||= {})["XAIL-ATTRIBUTE-SYSTEM"] = true

module XAIL
  module ATTRIBUTE_SYSTEM
  #--------------------------------------------------------------------------#
  # * Settings
  #--------------------------------------------------------------------------#
    # FONT = name
    FONT = ["Anklada�", "Verdana"]
    
    # ATTRIBUTE LIST:
    # LIST[id] = [symbol, stats_increase, cost, enabled]
    LIST = [] # Don't remove!
    LIST[0]   = [:hp,       25,    1, true]
    LIST[1]   = [:mp,       25,    1, true]
    LIST[2]   = [:atk,      10,    1, true]
    LIST[3]   = [:def,      5,     2, true]
    LIST[4]   = [:magic,    10,    3, true]
    LIST[5]   = [:res,       3,    2, true]
    LIST[6]   = [:agl,      10,    1, true]
    LIST[7]   = [:luk,       2,    5, true]
    LIST[8]   = [:hit,    0.01,   15, true]
    LIST[9]   = [:eva,    0.01,   15, true]
    LIST[10]  = [:cri,    0.01,   15, true]
    LIST[11]  = [:cev,    0.01,   15, true]
    LIST[12]  = [:mev,    0.01,   15, true]
    LIST[13]  = [:mrf,    0.01,   15, true]

    # ACTOR_POINTS:
    # Distribute how many starting points each actor should have when the game
    # starts.
    # ACTOR_POINTS[id] => number
    ACTOR_POINTS = {
    1  => 5,
    2  => 5, 
    3  => 5,
    4  => 5,
    5  => 5,
    6  => 5,
    7  => 5,
    8  => 5,
    9  => 5,
    10 => 5
    } # Don't remove this line!
    
    # attr_points = formula
    # Attribute points formula.
    # Set how many attribute points an actor should gain per level.
    # Default: Based on actor's luck divided by 2.
    def self.attr_points(actor)
      case $game_actors[actor.id].id
      when 1 ; $game_actors[actor.id].luk / 2
      when 2 ; $game_actors[actor.id].luk / 2
      # // Add more actor_id's here.
      else ; 0 # // Prevent error if nil as in actor id isn't in party.
      end
    end
    
    # attr_max = formula
    # Set the max attribute points an actor can gain.
    # Default: Based on actor's luck times magic attack power.
    def self.attr_max(actor)
      case $game_actors[actor.id].id
      when 1 ; $game_actors[actor.id].luk * $game_actors[actor.id].mat
      when 2 ; $game_actors[actor.id].luk * $game_actors[actor.id].mat
      # // Add more actor_id's here.
      else   ; 0 # // Prevent error if nil as in actor id isn't in party.
      end
    end
    
    # LIST_ICONS[id] = icon_id
    # Set the list icon_id. (optional)
    LIST_ICONS = []
    LIST_ICONS[0] = 32 # HP
    LIST_ICONS[1] = 33 # MP
    LIST_ICONS[2] = 34 # ATK
    LIST_ICONS[3] = 35 # DEF
    LIST_ICONS[4] = 36 # MAGIC
    LIST_ICONS[5] = 37 # RES
    LIST_ICONS[6] = 38 # AGL
    LIST_ICONS[7] = 39 # LUK
    LIST_ICONS[8] = 4141 # HIT
    LIST_ICONS[9] = 4157 # EVA
    LIST_ICONS[10] = 4164 # CRI
    LIST_ICONS[11] = 4170 # CEV
    LIST_ICONS[12] = 4172 # MEV
    LIST_ICONS[13] = 4152 # MRF
    
    # PARAM_ICONS[id] = icon_id
    # Set the param icon_id. (optional)
    PARAM_ICONS = []
    PARAM_ICONS[0] = 4149 # HP
    PARAM_ICONS[1] = 4132 # MP
    PARAM_ICONS[2] = 4145 # ATK
    PARAM_ICONS[3] = 4150 # DEF
    PARAM_ICONS[4] = 4147 # MAGIC
    PARAM_ICONS[5] = 4148 # RES
    PARAM_ICONS[6] = 4140 # AGL
    PARAM_ICONS[7] = 4131 # LUK
    PARAM_ICONS[8] = 4138 # EXP
    
    # XPARAM_ICONS[id] = icon_id
    # Set the xparam icon_id. (optional)
    XPARAM_ICONS = []
    XPARAM_ICONS[0] = 4141 # HIT RATE
    XPARAM_ICONS[1] = 4157 # EVASION RATE
    XPARAM_ICONS[2] = 4164 # CRITICAL RATE
    XPARAM_ICONS[3] = 4170 # CRITICAL EVASION
    XPARAM_ICONS[4] = 4172 # MAGIC EVASION
    XPARAM_ICONS[5] = 4152 # MAGIC REFLECTION
    
    # PARAM_BAR_COLOR = rgba(255,255,255,255)
    # Set the color of the health, mana and parameter bars.
    PARAM_BAR_COLOR = [Color.new(60,60,120,150), Color.new(200,200,200,180)]
    PARAM_BAR_HP = [Color.new(225,50,50,64), Color.new(235,75,75,175)]
    PARAM_BAR_MP = [Color.new(50,50,225,64), Color.new(75,75,235,175)]
    
    # PARAM_TXT_COLOR = rgba(255,255,255,255)
    # Set the color of the parameter text.
    PARAM_TXT_COLOR = [Color.new(255,255,255), Color.new(235,215,0)]
    
    # PARAM_LINE_COLOR = rgba(255,255,255,255)
    # Set the color of the horizontal line.
    PARAM_LINE_COLOR = [Color.new(255,255,255,200), Color.new(0,0,0,128)]
    
    # STAT_GROWTH = true/false
    # Enable/disable the stat growth an actor normally have. i.e when levelling
    # up you gain attributes to each parameter automatically.
    # Note: Bare in mind that you cannot change this settings during the game
    # so make sure you decide if you want this option enabled or not.
    STAT_GROWTH = true
    
    # INITIAL_LEVEL = number
    # Set the initial starting level if stat growth is disabled.
    INITIAL_LEVEL = 1
    
    # ATTR_SWITCH = number
    # Switch to manually disable gaining attributes points on levelling up.
    ATTR_SWITCH = 10
    
    # MENU_CMD = true/false
    # Enable this to create a attribute command to the default menu. (optional)
    MENU_CMD = true
    
    # MENU_NAME = string
    # Set this to the name you want on the command for the default menu. (optional)
    MENU_NAME = "Attribute"
    
    # Transition, nil to use default.
    # TRANSITION [ SPEED, TRANSITION, OPACITY ]
    # TRANSITION = [40, "Graphics/Transitions/1", 50]
    TRANSITION = nil
    
    # Background image (System folder)
    # Note: You might want to decrease the opacity as well as arrange 
    # the windows so that you can properly see the background.
    # Set to nil to use default.
    BACK = nil
    
  end
end
# *** Don't edit below unless you know what you are doing. ***
#==============================================================================#
# ** Error Handler
#==============================================================================#
class XS_Error
  unless $imported["XAIL-XS-CORE"]
    # // Error handler when XS - Core is not installed.
    msg = "The script %s requires the latest version of XS - Core in order to function properly."
    name = "XS - Attribute System"
    msgbox(sprintf(msg, name))
    exit
  end
end
#==============================================================================#
# ** Game_BattlerBase
#==============================================================================#
class Game_BattlerBase
  
  alias xail_att_sys_gm_battlerbase_init initialize 
  def initialize(*args, &block)
    # // Method to initialize.
    clear_xparam_plus
    xail_att_sys_gm_battlerbase_init(*args, &block)
  end
  
  def xparam(xparam_id)
    # // Method to get xparam.
    (features_sum(FEATURE_XPARAM, xparam_id) + xparam_plus(xparam_id)).clamp(0,100).round_to(2)
  end
  
  def xparam_plus(xparam_id)
    # // Method to get xparam plus.
    @xparam_plus[xparam_id]
  end
  
  def clear_xparam_plus
    # // Method to clear xparam plus.
    @xparam_plus = [0] * 10
  end
  
  def add_xparam(xparam_id, value)
    # // Method to add xparam.
    @xparam_plus[xparam_id] += value
    refresh
  end
  
end
#==============================================================================#
# ** Game_Actor
#==============================================================================#
class Game_Actor < Game_Battler
  
  attr_accessor :attribute_spent
  
  # // Method to initialize the window.
  alias xail_att_sys_gm_actor_init initialize
  def initialize(actor_id)
    xail_att_sys_gm_actor_init(actor_id)
    @attribute_spent = 0
  end
  
  alias xail_att_sys_gm_actor_setup setup
  def setup(actor_id)
    # // Method to setup.
    xail_att_sys_gm_actor_setup(actor_id)
    clear_xparam_plus
  end
  
  alias xail_att_sys_gm_actor_lvl_up level_up
  def level_up(*args, &block)
    # // Method when a actor level up.
    xail_att_sys_gm_actor_lvl_up(*args, &block)
    gain_attribute(actor.id, XAIL::ATTRIBUTE_SYSTEM.attr_points(actor)) unless $game_switches[XAIL::ATTRIBUTE_SYSTEM::ATTR_SWITCH]
  end
  
  def param_base(param_id)
    # // Method override to set param base.
    if XAIL::ATTRIBUTE_SYSTEM::STAT_GROWTH
      self.class.params[param_id, @level]
    else
      self.class.params[param_id, XAIL::ATTRIBUTE_SYSTEM::INITIAL_LEVEL]
    end
  end
  
  def gain_attribute(actor_id, value, type = :gain)
    # // Method to gain attribute.
    points = XAIL::ATTRIBUTE_SYSTEM::ACTOR_POINTS
    case type
    when :gain
      points[actor_id] = (points[actor_id] + value).clamp(0, XAIL::ATTRIBUTE_SYSTEM.attr_max(actor))
    when :lose
      points[actor_id] = (points[actor_id] - value).clamp(0, XAIL::ATTRIBUTE_SYSTEM.attr_max(actor))
    end
  end
  
  def attribute?(actor_id)
    # // Method to check actor's attribute.
    XAIL::ATTRIBUTE_SYSTEM::ACTOR_POINTS[actor_id]
  end

end
#==============================================================================#
# ** Game_Party
#==============================================================================#
class Game_Party < Game_Unit
  
  def attribute(actor_id, value, type = :gain)
    # // Method to gain/lose attributes.
    # Will return nil if actor is not in the party.
    return unless members.include?($game_actors[actor_id])
    return $game_actors[actor_id].gain_attribute(actor_id, value, type)
  end
  
  def attribute?(actor_id)
    # // Method to check actor's attribute.
    # Will return nil if actor is not in the party.
    return unless members.include?($game_actors[actor_id])
    return $game_actors[actor_id].attribute?(actor_id)
  end
  
end
#==============================================================================#
# ** Window_Base
#==============================================================================#
class Window_Base < Window
  
  def draw_current_and_max_values_ex(x, y, width, current, max, color1, color2)
    # // New method to draw current and max values.
    change_color(color1)
    xr = x + width
    if width < 96
      draw_text(xr - 40, y, 42, line_height, current, 0)
    else
      draw_text(32, y, 42, line_height, current, 0)
      change_color(color2)
      draw_text(xr - 36, y, 42, line_height, max, 2)
    end
  end
  
  def draw_actor_stats(actor, stat, x, y, color1, color2, width = 339)
    # // New method to draw actor hp & mp.
    case stat
    when :hp
      rate = actor.hp_rate
      vocab = Vocab::hp_a
      values = [actor.hp, actor.mhp]
    when :mp
      rate = actor.mp_rate
      vocab = Vocab::mp_a
      values = [actor.mp, actor.mmp]
    end
    contents.font.name = XAIL::ATTRIBUTE_SYSTEM::FONT
    contents.font.size = 16 # // Override font size.
    contents.font.bold = true
    contents.font.shadow = false
    draw_gauge_ex(x, y - 14, width, 20, rate, color1, color2)
    contents.font.color = XAIL::ATTRIBUTE_SYSTEM::PARAM_TXT_COLOR[0]
    draw_text(x, y, contents.width, line_height, vocab, 1)
    draw_current_and_max_values_ex(x - 8, y, width, values[0], values[1],
    XAIL::ATTRIBUTE_SYSTEM::PARAM_TXT_COLOR[1], XAIL::ATTRIBUTE_SYSTEM::PARAM_TXT_COLOR[1])
    reset_font_settings
  end
  
end
#==============================================================================#
# ** Window_Attribute_List
#==============================================================================#
class Window_Attribute_List < Window_Command
  
  def standard_padding
    # // Method to set padding.
    return 8
  end
  
  def window_width
    # // Method to set the window width.
    return 160
  end
  
  def window_height
    # // Method to set the window height.
    return Graphics.height - 104
  end
  
  def menu_color(color, enabled = true)
    # // Method to set the color and alpha if not enabled.
    contents.font.color.set(color)
    contents.font.color.alpha = 100 unless enabled
  end
  
  def draw_item(index)
    # // Method to draw the command item.
    contents.font.name = XAIL::ATTRIBUTE_SYSTEM::FONT
    contents.font.size = 18 # // Override font size.
    menu_color(XAIL::ATTRIBUTE_SYSTEM::PARAM_TXT_COLOR[0], menu_enabled?(index))
    contents.font.bold = true
    draw_icons(XAIL::ATTRIBUTE_SYSTEM::LIST_ICONS, :vertical)
    draw_text(item_rect_for_icons(index), command_name(index), alignment)
    reset_font_settings
  end

  def item_rect_for_icons(index)
     # // Method to draw the text with icons.
    rect = item_rect(index)
    rect.x += 26
    rect.width -= 8
    rect
  end
  
  def menu_enabled?(index)
    # // Method to check if item is enabled.
    return XAIL::ATTRIBUTE_SYSTEM::LIST[index][3]
  end
  
  alias xail_att_sys_winatt_mk_cmd_list make_command_list
  def make_command_list(*args, &block)
    # // Method to add the commands.
    xail_att_sys_winatt_mk_cmd_list(*args, &block)
    id = 0
    for i in XAIL::ATTRIBUTE_SYSTEM::LIST
      case i[0]
      when :hit ; add_command(Vocab::xparam(0), i[0], i[3])
      when :eva ; add_command(Vocab::xparam(1), i[0], i[3])
      when :cri ; add_command(Vocab::xparam(2), i[0], i[3])
      when :cev ; add_command(Vocab::xparam(3), i[0], i[3])
      when :mev ; add_command(Vocab::xparam(4), i[0], i[3])
      when :mrf ; add_command(Vocab::xparam(5), i[0], i[3])
      else
        add_command(Vocab::param(id), i[0], i[3])
      end
      id += 1
    end
  end

end
#==============================================================================#
# ** Window_Attribute_Info
#==============================================================================#
class Window_Attribute_Info < Window_Base
  
  def initialize(x, y, width, height)
    # // Method to initialize the window.
    super(x, y, width, height)
    refresh
  end
  
  def standard_padding
    # // Method to set padding.
    return 16
  end
  
  def set_text(text, color = nil, alignment = 0)
    # // Method to set a text to the window.
    if text != @text
      @text = text
      @color = color
      @alignment = alignment
      refresh
    end
  end
  
  def refresh
    # // Method to refresh the window.
    contents.clear
    contents.font.name = XAIL::ATTRIBUTE_SYSTEM::FONT
    contents.font.size = 17 # // Override font size.
    contents.font.color = @color.nil? ? Color.new(255,255,255) : @color
    draw_text(0, 0, contents.width, line_height, @text, @alignment)
    reset_font_settings
  end
  
end
#==============================================================================#
# ** Window_Attribute_Points
#==============================================================================#
class Window_Attribute_Points < Window_Base
  
  def initialize(actor, x, y, width, height)
    # // Method to initialize the window.
    super(x, y, width, height)
    @actor = actor
    refresh
  end
  
  def standard_padding
    # // Method to set padding.
    return 16
  end
  
  def actor=(actor)
    # // Method to refresh and set actor.
    return if @actor == actor
    @actor = actor
    refresh
  end
  
  def refresh
    # // Method to refresh the window.
    contents.clear
    current = XAIL::ATTRIBUTE_SYSTEM::ACTOR_POINTS[@actor.id].to_s
    max = XAIL::ATTRIBUTE_SYSTEM.attr_max($game_actors[@actor.id]).to_s
    text = "Points: " + current + " / " + max
    contents.font.name = XAIL::ATTRIBUTE_SYSTEM::FONT
    contents.font.size = 20 # // Override font size.
    contents.font.color = Color.new(255,255,255)
    draw_text(0, 0, contents.width, line_height, text)
    reset_font_settings
  end
  
end
#==============================================================================#
# ** Window_Status
#==============================================================================#
class Window_Attribute_Status < Window_Selectable
  
  def initialize(actor)
    # // Method to initialize window.
    super(160, 52, Graphics.width - 160, Graphics.height - 52)
    @actor = actor
    refresh
    activate
  end

  def actor=(actor)
    # // Method to refresh and set actor.
    return if @actor == actor
    @actor = actor
    refresh
  end

  def refresh
    # // Method to refresh.
    contents.clear
    # Draw icons.
    draw_icons(XAIL::ATTRIBUTE_SYSTEM::PARAM_ICONS, :vertical, 0, line_height * 2, [4138])
    draw_icons(XAIL::ATTRIBUTE_SYSTEM::XPARAM_ICONS, :vertical, 179, line_height * 4)
    # Draw actor details.
    draw_font_text(@actor.name, 0, line_height * 0, 112, 0, XAIL::ATTRIBUTE_SYSTEM::FONT, 22, XAIL::ATTRIBUTE_SYSTEM::PARAM_TXT_COLOR[0])
    draw_font_text(@actor.class.name, 0, line_height * 0, contents_width, 1, XAIL::ATTRIBUTE_SYSTEM::FONT, 22, XAIL::ATTRIBUTE_SYSTEM::PARAM_TXT_COLOR[0])
    draw_font_text(@actor.nickname, 246, line_height * 0, 112, 2, XAIL::ATTRIBUTE_SYSTEM::FONT, 22, XAIL::ATTRIBUTE_SYSTEM::PARAM_TXT_COLOR[0])
    # Draw line.
    draw_line_ex(-48, line_height * 1, XAIL::ATTRIBUTE_SYSTEM::PARAM_LINE_COLOR[0], XAIL::ATTRIBUTE_SYSTEM::PARAM_LINE_COLOR[1])
    # Draw actor stats.
    draw_actor_stats(@actor, :hp, 20, line_height * 2, XAIL::ATTRIBUTE_SYSTEM::PARAM_BAR_HP[0], XAIL::ATTRIBUTE_SYSTEM::PARAM_BAR_HP[1])
    draw_actor_stats(@actor, :mp, 20, line_height * 3, XAIL::ATTRIBUTE_SYSTEM::PARAM_BAR_MP[0], XAIL::ATTRIBUTE_SYSTEM::PARAM_BAR_MP[1])
    # Draw actor parameters and xparameters.
    draw_parameters(20, line_height * 4)
    draw_xparameters(199, line_height * 4)
    # Draw line.
    draw_line_ex(48, line_height * 10, XAIL::ATTRIBUTE_SYSTEM::PARAM_LINE_COLOR[0], XAIL::ATTRIBUTE_SYSTEM::PARAM_LINE_COLOR[1])
    # Draw experience info.
    draw_exp_info(20, line_height * 10)
    # Draw line.
    draw_line_ex(-48, line_height * 12, XAIL::ATTRIBUTE_SYSTEM::PARAM_LINE_COLOR[0], XAIL::ATTRIBUTE_SYSTEM::PARAM_LINE_COLOR[1])
    # Draw points spent and actor level.
    draw_font_text("Points spent: " + @actor.attribute_spent.to_s, 0, line_height * 13, 140, 0, XAIL::ATTRIBUTE_SYSTEM::FONT, 22, XAIL::ATTRIBUTE_SYSTEM::PARAM_TXT_COLOR[0])
    if $imported["XAIL-LVL-TITLE"]
      lvl = "#{Vocab::level_a}: #{draw_title_level(@actor)}"
    else
      lvl = "#{Vocab::level_a}: #{@actor.level}  /  #{@actor.max_level}"
    end
    draw_font_text(lvl, 0, line_height * 13, contents_width, 2, XAIL::ATTRIBUTE_SYSTEM::FONT, 22, XAIL::ATTRIBUTE_SYSTEM::PARAM_TXT_COLOR[0])
  end

  def draw_parameters(x, y)
    # // Method to draw parameters.
    font = XAIL::ATTRIBUTE_SYSTEM::FONT
    size = 16 # // Override font size.
    c1 = XAIL::ATTRIBUTE_SYSTEM::PARAM_BAR_COLOR[0]
    c2 = XAIL::ATTRIBUTE_SYSTEM::PARAM_BAR_COLOR[1]
    c3 = XAIL::ATTRIBUTE_SYSTEM::PARAM_TXT_COLOR[0]
    c4 = XAIL::ATTRIBUTE_SYSTEM::PARAM_TXT_COLOR[1]
    6.times {|i| draw_actor_param_gauge(@actor, x, y + line_height * i, 160, i + 2, font, size, c1, c2, c3, c4) }
  end
  
  def draw_xparameters(x, y)
    # // Method to draw xparameters.
    font = XAIL::ATTRIBUTE_SYSTEM::FONT
    size = 16 # // Override font size.
    c1 = XAIL::ATTRIBUTE_SYSTEM::PARAM_BAR_COLOR[0]
    c2 = XAIL::ATTRIBUTE_SYSTEM::PARAM_BAR_COLOR[1]
    c3 = XAIL::ATTRIBUTE_SYSTEM::PARAM_TXT_COLOR[0]
    c4 = XAIL::ATTRIBUTE_SYSTEM::PARAM_TXT_COLOR[1]
    6.times {|i| draw_actor_xparam_gauge(@actor, x, y + line_height * i, 160, i, font, size, c1, c2, c3, c4) }
  end

  def draw_exp_info(x, y)
    # // Method to draw exp details.
    s1 = @actor.max_level? ? "?" : @actor.exp
    s2 = @actor.max_level? ? "?" : @actor.next_level_exp - @actor.exp
    param_rate = @actor.exp / @actor.next_level_exp.to_f
    contents.font.name = XAIL::ATTRIBUTE_SYSTEM::FONT
    contents.font.size = 16 # // Override font size.
    contents.font.color = XAIL::ATTRIBUTE_SYSTEM::PARAM_TXT_COLOR[1]
    contents.font.bold = true
    contents.font.shadow = false
    draw_gauge_ex(x, y + 9, 339, 20, param_rate, XAIL::ATTRIBUTE_SYSTEM::PARAM_BAR_COLOR[0], XAIL::ATTRIBUTE_SYSTEM::PARAM_BAR_COLOR[1])
    draw_text(x + 10, y + line_height, 339, line_height, s1, 0)
    draw_text(x + 339 / 2, y + line_height, 339, line_height, "EXP", 0)
    draw_text(x - 2, y + line_height, 339, line_height, s2, 2)    
  end
  
end
#==============================================================================#
# ** Scene_AttributeBase
#==============================================================================#
class Scene_AttributeBase < Scene_Base
  
  alias xail_att_sys_scenebase_start start
  def start(*args, &block)
    # // Method to start the scene
    xail_att_sys_scenebase_start(*args, &block)
    create_background
  end
  
  def create_background
    # // Method to create the background.
    @background_sprite = Sprite.new
    if XAIL::ATTRIBUTE_SYSTEM::BACK.nil?
      @background_sprite.bitmap = SceneManager.background_bitmap
      @background_sprite.color.set(16, 16, 16, 128)
    else
      @background_sprite.bitmap = Cache.system(XAIL::ATTRIBUTE_SYSTEM::BACK)
    end
  end
  
  alias xail_att_sys_scenebase_perf_trans perform_transition
  def perform_transition(*args, &block)
    # // Method to create the transition.�
    XAIL::ATTRIBUTE_SYSTEM::TRANSITION.nil? ? Graphics.transition(15) : Graphics.transition(XAIL::ATTRIBUTE_SYSTEM::TRANSITION[0],XAIL::ATTRIBUTE_SYSTEM::TRANSITION[1],XAIL::ATTRIBUTE_SYSTEM::TRANSITION[2])
    xail_att_sys_scenebase_perf_trans(*args, &block)
  end
  
  def next_actor
    # // Method to go to next actor.
    @actor = $game_party.menu_actor_next
    on_actor_change
  end
  
  def prev_actor
    # // Method to go to previous actor.
    @actor = $game_party.menu_actor_prev
    on_actor_change
  end
  
end 
#==============================================================================#
# ** Scene_Attribute
#==============================================================================#
class Scene_Attribute < Scene_AttributeBase
  
  def start
    # // Method to start scene teleport.
    super
    @actor = $game_party.menu_actor
    create_attribute_list
    create_attribute_info
    create_attribute_points
    create_attribute_param
    create_attribute_status
    on_index_change(0)
  end
  
  def create_attribute_list
    # // Method to create attribute window list.
    @attribute_list = Window_Attribute_List.new(0, 0)
    for i in XAIL::ATTRIBUTE_SYSTEM::LIST
      @attribute_list.set_handler(i[0], method(:command_attribute))
    end
    @attribute_list.set_handler(:pagedown, method(:next_actor))
    @attribute_list.set_handler(:pageup,   method(:prev_actor))
    @attribute_list.set_handler(:cancel, method(:return_scene))
  end
  
  def on_actor_change
    # // Method to change actor.
    @attribute_status.actor = @actor
    @attribute_points.actor = @actor
    @attribute_list.activate
    refresh_windows
  end
  
  def refresh_windows
    # // Method to refresh windows.
    @attribute_param.refresh
    @attribute_status.refresh
    @attribute_points.refresh
  end
  
  def create_attribute_info
    # // Method to create attribute info window.
    w = Graphics.width - @attribute_list.width
    x = @attribute_list.width
    @attribute_info = Window_Attribute_Info.new(x, 0, w, 52)
  end
  
  def create_attribute_points
    # // Method to create attribute points window.
    y = @attribute_list.height
    w = @attribute_list.width
    @attribute_points = Window_Attribute_Points.new(@actor, 0, y, w, 52)
  end
  
  def create_attribute_param
    # // Method to create attribute parameter window.
    y = @attribute_list.height + @attribute_points.height
    w = @attribute_list.width
    @attribute_param = Window_Attribute_Info.new(0, y, w, 52)
  end
  
  def create_attribute_status
    # // Method to create attribute status window.
    @attribute_status = Window_Attribute_Status.new(@actor)
  end
  
  alias xail_att_sys_scene_update update
  def update(*args, &block)
    # // Method for updating the scene.
    old_index = @attribute_list.index
    xail_att_sys_scene_update(*args, &block)
    on_index_change(@attribute_list.index) if old_index != @attribute_list.index
  end
  
  def on_index_change(index)
    # // Method when index changes.
    title = Vocab::param(index)
    case index
    when 8  ; title = Vocab::xparam(0)
    when 9  ; title = Vocab::xparam(1)
    when 10 ; title = Vocab::xparam(2)
    when 11 ; title = Vocab::xparam(3)
    when 12 ; title = Vocab::xparam(4)
    when 13 ; title = Vocab::xparam(5)
    end
    stats = XAIL::ATTRIBUTE_SYSTEM::LIST[index][1].to_s
    cost = XAIL::ATTRIBUTE_SYSTEM::LIST[index][2].to_s
    @attribute_param.set_text(title.to_s + " +" + stats, Color.new(150,205,150,225))
    @attribute_info.set_text("Distribute " + title + ". Cost � " + cost + " points", XAIL::ATTRIBUTE_SYSTEM::PARAM_TXT_COLOR[1])
    refresh_windows
  end
  
  def command_attribute
    # // Method to add attribute.
    case @attribute_list.current_symbol
    when :hp    ; change_param(0, :param)
    when :mp    ; change_param(1, :param)
    when :atk   ; change_param(2, :param)
    when :def   ; change_param(3, :param)
    when :magic ; change_param(4, :param)
    when :res   ; change_param(5, :param)
    when :agl   ; change_param(6, :param)
    when :luk   ; change_param(7, :param)
    when :hit   ; change_param(0, :xparam)
    when :eva   ; change_param(1, :xparam)
    when :cri   ; change_param(2, :xparam)
    when :cev   ; change_param(3, :xparam)
    when :mev   ; change_param(4, :xparam)
    when :mrf   ; change_param(5, :xparam)
    end
    @attribute_list.activate
    refresh_windows
  end
  
  def change_param(param_id, type)
    # // Method to change param.
    case type
    when :param
      id = XAIL::ATTRIBUTE_SYSTEM::LIST[param_id]
    when :xparam
      id = XAIL::ATTRIBUTE_SYSTEM::LIST[param_id + 8]
    end
    unless $game_party.attribute?(@actor.id) == 0
      return Sound.play_buzzer if $game_party.attribute?(@actor.id) < id[2]
      $game_party.attribute(@actor.id, id[2], :lose)
      @actor.attribute_spent += id[2]
      @actor.add_param(param_id, id[1]) if type == :param
      @actor.add_xparam(param_id, id[1]) if type == :xparam
    else
      Sound.play_buzzer
    end
  end
  
end
#==============================================================================#
# ** Window_MenuCommand
#==============================================================================#
class Window_MenuCommand < Window_Command
 
  alias xail_att_sys_win_menucmd_add_main_commands add_main_commands
  def add_main_commands(*args, &block)
    xail_att_sys_win_menucmd_add_main_commands(*args, &block)
    add_command(XAIL::ATTRIBUTE_SYSTEM::MENU_NAME, :attribute, true) if XAIL::ATTRIBUTE_SYSTEM::MENU_CMD
  end
    
end
#==============================================================================#
# ** Scene_Menu
#==============================================================================#
class Scene_Menu < Scene_MenuBase

  alias xail_att_sys_scenemenu_create_cmd_window create_command_window
  def create_command_window(*args, &block)
    # // Method to create command window.
    xail_att_sys_scenemenu_create_cmd_window(*args, &block)
    @command_window.set_handler(:attribute, method(:command_attribute)) if XAIL::ATTRIBUTE_SYSTEM::MENU_CMD
  end
  
  def command_attribute
    # // Method to call attribute scene.
    SceneManager.call(Scene_Attribute)
  end
  
end # END OF FILE

#=*==========================================================================*=#
# ** END OF FILE
#=*==========================================================================*=#