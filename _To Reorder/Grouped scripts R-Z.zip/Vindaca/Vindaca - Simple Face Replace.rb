#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
#                                                                              #
#                           V's Simple Face Replace                            #
#                                 Version  0.3                                 #
#                                                                              #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#                                Written By:  V                                #
#                         Last Edited: October 6, 2013                         #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#                                                                              #
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
 
  
#==============================================================================#
#------------------------------------------------------------------------------#
# ** Disclaimer                                                                #
#------------------------------------------------------------------------------#
#                                                                              #
# This script was intended for Non-commercial use only, if you wish to use     #
# this script in a commercial game please PM me at which ever site you found   #
# this script. Either way please give me credit in your game script as the     #
# writer of this script, and send me a PM abuot the release of the game/demo.  #
#                                                                              #
#------------------------------------------------------------------------------#
# ** How To Use                                                                #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#                                                                              #
# * This script is pretty much plug-and-play.                                  #
#                                                                              #
# * You can adjust the x and y's for the menu actors below.                    #
#                                                                              #
# * To add the graphic to the message window use this command in a script      #
#   call before the message is displayed.                                      #
#                                                                              #
#    set_message_graphic(graphic_page_name, graphic_index, x, y, zoom)         #
#                                                                              #
# * After the message use this in a script call to reset the graphic.          #
#                                                                              #
#    set_message_graphic                                                       #
#                                                                              #
#------------------------------------------------------------------------------#
# ** Description                                                               #
#------------------------------------------------------------------------------#
#                                                                              #
#  v0.1                                                                        #
# ~=~=~=~                                                                      #
#  * This script allows you to replace all of the faces in the game with the   #
# actors graphics instead.                                                     #
#                                                                              #
#  v0.2                                                                        #
# ~=~=~=~                                                                      #
#  * I added a feature to change the face in the message windows to a graphic  #
#  as well.                                                                    #
#                                                                              #
#  v0.3                                                                        #
# ~=~=~=~                                                                      #
#  * I added a zoom feature to change the graphic size in both the message     #
#  windows and the menus.                                                      #
#                                                                              #
#------------------------------------------------------------------------------#
#==============================================================================#
module V_Simple_Face_Replace
  module Specs
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
#                                                                              #
#                           Start Customizable Area.                           #
#                                                                              #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#                                                                              #
#                      ONLY EDIT AFTER THE EQUALS SYMBOL.                      #
#                                                                              #
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
   
    
  #============================================================================
  #  Menu Options
  #============================================================================
    
    Menu_Actor_Graphic_x = 50
    Menu_Actor_Graphic_y = 50
    Menu_Actor_Graphic_zoom = 1
    
    
    
    
    
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
#                                                                              #
#         DO NOT EDIT PAST THIS POINT UNLESS YOU KNOW WHAT YOUR DOING.         #
#                                                                              #
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#





























 
end
end
class Game_Message
  attr_accessor :message_actor
  attr_accessor :message_actor_index
  attr_accessor :message_actor_x
  attr_accessor :message_actor_y
  attr_accessor :message_actor_zoom
  alias :i0206165165132002 :initialize
  def initialize
    @message_actor = nil 
    @message_actor_index = nil 
    @message_actor_x = nil
    @message_actor_y = nil
    @message_actor_zoom = 1
    i0206165165132002()
  end
end
class Window_Base < Window
  include V_Simple_Face_Replace::Specs
  def draw_zoomed_character(character_name, character_index, x, y, zoom)
    return unless character_name
    bitmap = Cache.character(character_name)
    sign = character_name[/^[\!\$]./]
    if sign && sign.include?('$')
      cw = bitmap.width / 3
      ch = bitmap.height / 4
    else
      cw = bitmap.width / 12
      ch = bitmap.height / 8
    end
    n = character_index
    src_rect = Rect.new((n%4*3+1)*cw, (n/4*4)*ch, cw, ch)
    actor = Rect.new(x, y, cw * zoom, ch * zoom)
    contents.stretch_blt(actor, bitmap, src_rect)    
  end
  def draw_zoomed_actor_graphic(actor, x, y, zoom)
    draw_zoomed_character(actor.character_name, actor.character_index, x, y, zoom)
  end
  def draw_actor_face(actor, x, y, enabled = true, zoom = Menu_Actor_Graphic_zoom)
    if zoom == 1
      draw_actor_graphic(actor, x + Menu_Actor_Graphic_x, y + Menu_Actor_Graphic_y)
    else
      draw_zoomed_actor_graphic(actor, x + Menu_Actor_Graphic_x, y + Menu_Actor_Graphic_y, Menu_Actor_Graphic_zoom)
    end
  end
end
class Window_Message < Window_Base
  def new_page(text, pos)
    actor = $game_message.message_actor
    actor_index = $game_message.message_actor_index
    x = $game_message.message_actor_x
    y = $game_message.message_actor_y
    zoom = $game_message.message_actor_zoom
    contents.clear
    if zoom == 1
      draw_character(actor, actor_index, x, y) unless actor == nil || zoom > 1
    else
      draw_zoomed_character(actor, actor_index, x, y, zoom) unless actor == nil
    end
    reset_font_settings
    pos[:x] = new_line_x
    pos[:y] = 0
    pos[:new_x] = new_line_x
    pos[:height] = calc_line_height(text)
    clear_flags
  end
  def new_line_x
    $game_message.face_name.empty? ? check_for_message_graphic : 112
  end
  def check_for_message_graphic
    $game_message.message_actor == nil ? 0 : 112
  end
end
class Game_Interpreter
  def set_message_graphic(graphic_page_name = nil, graphic_index = nil, x = nil, y = nil, zoom = 1)
    $game_message.message_actor = graphic_page_name
    $game_message.message_actor_index = graphic_index
    $game_message.message_actor_x = x
    $game_message.message_actor_y = y
    $game_message.message_actor_zoom = zoom
  end
end