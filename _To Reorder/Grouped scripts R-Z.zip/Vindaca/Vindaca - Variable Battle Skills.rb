 
 
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
#                                                                              #
#                           V's Variable Battle Skills                         #
#                                 Version  0.1                                 #
#                                                                              #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#                                Written By:  V                                #
#                       Last Edited:  September 10, 2013                       #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#                                                                              #
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
 
  
#==============================================================================#
#------------------------------------------------------------------------------#
# ** Disclaimer                                                                #
#------------------------------------------------------------------------------#
#                                                                              #
# This script was intended for Non-commercial use only, if you wish to use     #
# this script in a commercial game please PM me at which ever site you found   #
# this script. Either way please give me credit in your game script as the     #
# writer of this script, and send me a PM abuot the release of the game/demo.  #
#                                                                              #
#------------------------------------------------------------------------------#
# ** How To Use                                                                #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#                                                                              #
# * This script is semi-plug-and-play.                                         #
#                                                                              #
# ============================================================================ #
# * ALL ACTORS MUST HAVE THIS TAG OR YOU WILL GET AN ERROR!                    #
# ============================================================================ #
#                                                                              #
#   Replace the words with the corresponding numbers                           #
#                                                                              #
#   <VBS: (Skill 1 Var), (Skill 1 Icon), (Skill 2 Var), (Skill 1 Icon)>        #
#                                                                              #
#   It should look something like this.                                        #
#                                                                              #
#   <VBS: 1, 22, 2, 23>                                                        #
#                                                                              #
#                                                                              #
# ============================================================================ #
# * ALL SKILLS MUST HAVE THIS TAG OR YOU WILL GET AN ERROR!                    #
# ============================================================================ #
#                                                                              #
#   Replace the words with the corresponding numbers                           #
#                                                                              #
#   <VBS: (Var to deduct skills cost from)>                                    #
#                                                                              #
#   It should look something like this.                                        #
#                                                                              #
#   <VBS: 1>                                                                   #
#                                                                              #
#   ** The skills cost is set up to be equal to the mp or tp cost.             #
#                                                                              #
#------------------------------------------------------------------------------#
# ** Description                                                               #
#------------------------------------------------------------------------------#
#                                                                              #
#  v0.1                                                                        #
# ~=~=~=~                                                                      #
#                                                                              #
# This script is an Add-On for The regular battle system to display variables  #
# and icons instead of Mp and Tp.                                              #
#                                                                              #
#------------------------------------------------------------------------------#
#==============================================================================#


class Game_BattlerBase
  def skill_mp_cost(skill)
    skill.mp_cost
  end
  def skill_tp_cost(skill)
    skill.tp_cost
  end
  def skill_cost_payable?(skill)
    bd = /<VBS:\s*(\d*)>/i
    note = $data_skills[skill.id].note.scan(bd) if $data_skills[skill.id].note.scan(bd) != nil
    bv = $1.to_i
    $game_variables[bv] >= skill_tp_cost(skill) && $game_variables[bv] >= skill_mp_cost(skill)
  end
  def pay_skill_cost(skill)
    bd = /<VBS:\s*(\d*)>/i
    note = $data_skills[skill.id].note.scan(bd) if $data_skills[skill.id].note.scan(bd) != nil
    bv = $1.to_i
    skill_mp_cost(skill) == 0 ? $game_variables[bv] -= skill_tp_cost(skill) : $game_variables[bv] -= skill_mp_cost(skill)
  end
end
class Window_BattleStatus < Window_Selectable
  def draw_gauge_area(rect, actor)
     dvas(rect, actor)
  end
  def dvas(rect, actor)
    bd = /<VBS:\s*(\d*)\S*\s*(\d*)\S*\s*(\d*)\S*\s*(\d*)>/i
    note = $data_actors[actor.id].note.scan(bd) if $data_actors[actor.id].note.scan(bd) != nil
    var = $1.to_i
    icon_id = $2.to_i
    vara = $3.to_i
    icon_ida = $4.to_i
    draw_actor_hp(actor, rect.x - 50, rect.y, 100)
    draw_icon(icon_id, rect.x + 70, rect.y)
    draw_text(rect.x - 275, rect.y - 45, self.width, self.height, $game_variables[var], 2)
    draw_icon(icon_ida, rect.x + 150, rect.y)
    draw_text(rect.x - 195, rect.y - 45, self.width, self.height, $game_variables[vara], 2)
  end
end