 
 
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
#                                                                              #
#                       V's Variable Voice Over System                         #
#                                  Version 0.1                                 #
#                                                                              #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#                                Written By:  V                                #
#                        Last Edited: February 7, 2013                         #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#                                                                              #
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
 
  
#==============================================================================#
#------------------------------------------------------------------------------#
# ** Disclaimer                                                                #
#------------------------------------------------------------------------------#
#                                                                              #
# This script was intended for Non-commercial use only, if you wish to use     #
# this script in a commercial game please PM me at which ever site you found   #
# this script. Either way please give me credit in your game script as the     #
# writer of this script, and send me a PM abuot the release of the game/demo.  #
#                                                                              #
#------------------------------------------------------------------------------#
# ** How To Use                                                                #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#                                                                              #
# * This script has a set-up area below and a script call.                     #
#                                                                              #
# * To call the voice method use this script call.                             #
#      voice(Voice_Type, [Voice_Id, Voice_Id, Voice_Id, Voice_Id])             #
#                                                                              #
# * Check out the demo for examples.                                           #
#                                                                              #
#------------------------------------------------------------------------------#
# ** Description                                                               #
#------------------------------------------------------------------------------#
#                                                                              #
#  v0.1                                                                        #
# ~=~=~=~                                                                      #
#                                                                              #
# * This sript basically acts as a voice over system(In short).                #
#                                                                              #
#------------------------------------------------------------------------------#
#==============================================================================#
#==============================================================================
# ** V's Variable Voice Over System
#------------------------------------------------------------------------------
#  This module manages customizable features and methods.
#==============================================================================
module Variable_Voice_Over_System
module Specs
Voice_Library = {}
  
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
#                                                                              #
#                           Start Customizable Area.                           #
#                                                                              #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#                                                                              #
#                      ONLY EDIT AFTER THE EQUALS SYMBOL.                      #
#                                                                              #
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
   
    
  #=============================================================================
  # * Folder directory for storing voices fx
  #=============================================================================
  
  Folder_Directory = 'Audio/SE/'
  
  #=============================================================================
  # * Voice Set-Up
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # ** The "Main" represents the voice type. For example, it could be a type of 
  # voice like raspy or sweet. It could also represent a person's name.
  #
  # ** The number index is for word id and randomization purposes. 
  # (IMPORTANT~ Make sure that no number in repeated with-in a voice type
  #
  # ** The ":duration" is a set in frames and controls the time in between words
  # or phrases. (60 frame / 1 second)
  #
  # ** The ":groupe_var_id" is a Variable that will control a group of word ids.
  # This could be used for gender, race, names or any other thing you can set
  # a variable to.
  #
  # ** The ":groupe_var_value" allows you to group words within the group_var_id.
  # This will allow you to mantain gender while maintianing randomization. For
  # example you could use, "Guy", "Man" or "Dude" what ever you like.
  #=============================================================================
  # ** REMEMBER You do not have to build your library word by word. You can also 
  # build it by the phrase. 
  #=============================================================================

  
  Voice_Library["Main"] = { 
                            1 => { :file_name => "Cow",
                                   :volume => 80,
                                   :pitch => 100,
                                   :duration => 200,
                                   :group_var_id => 1,
                                   :group_var_value => 0
                                  }, # <---End of Voice_ID
                                  
                            2 => { :file_name => "Cat",
                                   :volume => 80,
                                   :pitch => 100,
                                   :duration => 200,
                                   :group_var_id => 1,
                                   :group_var_value => 1
                                  }, # <---End of Voice_ID
                                  
                            3 => { :file_name => "Frog",
                                   :volume => 80,
                                   :pitch => 100,
                                   :duration => 200,
                                   :group_var_id => 1,
                                   :group_var_value => 1
                                  }, # <---End of Voice_ID
                                  
                            4 => { :file_name => "Crow",
                                   :volume => 80,
                                   :pitch => 100,
                                   :duration => 200,
                                   :group_var_id => 1,
                                   :group_var_value => 2
                                  }, # <---End of Voice_ID
                                  
                          } # <---End of Voice_Type
  
  end
end

#==============================================================================
# ** Game_Interpreter
#------------------------------------------------------------------------------
#  An interpreter for executing event commands. This class is used within the
# Game_Map, Game_Troop, and Game_Event classes.
#==============================================================================

class Game_Interpreter
  
  #--------------------------------------------------------------------------
  # * Includes Module's Variables With Class
  #--------------------------------------------------------------------------
  
  include Variable_Voice_Over_System::Specs
  
  #--------------------------------------------------------------------------
  # * Aliasing Method: Object Initialization
  #--------------------------------------------------------------------------
  def voice(voice_index, voices)
    new_voices = []
    voice_fxs = voices
    voice_fxs.size.times { |i| 
      var_value = $game_variables[Voice_Library[voice_index][voice_fxs[i]][:group_var_id]]
      value = Voice_Library[voice_index][voice_fxs[i]][:group_var_value]
      new_voices.push voice_fxs[i] if var_value == value
    }
    if new_voices.size < 1
      voice_fxs.size.times { |i| 
        var = Voice_Library[voice_index][voice_fxs[i]][:group_var_id]
        new_voices.push voice_fxs[i] if var != 0
      }
    end
    if new_voices.size == 1
      voice_id = new_voices[rand(new_voices.size) - 1]
    else
      voice_id = new_voices[0]
    end
    play_vfx(voice_index, voice_id)
  end
  
  #--------------------------------------------------------------------------
  # * Aliasing Method: Object Initialization
  #--------------------------------------------------------------------------
  def play_vfx(voice_index, voice_id)
    voice_fx = Voice_Library[voice_index][voice_id]
    Audio.se_play(Folder_Directory + voice_fx[:file_name], voice_fx[:volume], voice_fx[:pitch])
    wait(voice_fx[:duration])
  end

end