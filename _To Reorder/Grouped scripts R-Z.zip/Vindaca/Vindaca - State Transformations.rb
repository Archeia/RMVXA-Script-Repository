#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
#                                                                              #
#                          V's State Transformations                           #
#                                 Version  0.1                                 #
#                                                                              #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#                                Written By:  V                                #
#                        Last Edited: December 21, 2013                        #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#                                                                              #
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
 
  
#==============================================================================#
#------------------------------------------------------------------------------#
# ** Disclaimer                                                                #
#------------------------------------------------------------------------------#
#                                                                              #
# This script was intended for Non-commercial use only, if you wish to use     #
# this script in a commercial game please PM me at which ever site you found   #
# this script. Either way please give me credit in your game script as the     #
# writer of this script, and send me a PM abuot the release of the game/demo.  #
#                                                                              #
#------------------------------------------------------------------------------#
# ** How To Use                                                                #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#                                                                              #
# * This script is Plug & Play.                                                #
#                                                                              #
# * Add this tag to any state notebox that you want to transform.              #
#                                                                              #
#   <Transform State: character_name, character_index>                         #
#                                                                              #
#------------------------------------------------------------------------------#
# ** Description                                                               #
#------------------------------------------------------------------------------#
#                                                                              #
#  v0.1                                                                        #
# ~=~=~=~                                                                      #
#  * This script automatically transforms you into a new sprite when a state   #
#    is added and automatically changes you back when the state is removed.    #
#                                                                              #
#------------------------------------------------------------------------------#
#==============================================================================#
#==============================================================================
# ** V's State Transformations
#==============================================================================

#==============================================================================
# ** Game_Actor
#------------------------------------------------------------------------------
#  This class handles actors. It is used within the Game_Actors class
# ($game_actors) and is also referenced from the Game_Party class ($game_party).
#==============================================================================

class Game_Actor < Game_Battler

  #--------------------------------------------------------------------------
  # * Public Instance Variables
  #--------------------------------------------------------------------------
  attr_reader   :original_character_name           # original character graphic filename
  attr_reader   :original_character_index          # original character graphic index

  #--------------------------------------------------------------------------
  # * Aliasing Method: Object Initialization
  #--------------------------------------------------------------------------
  alias :gas542434100 :setup

  #--------------------------------------------------------------------------
  # * Setup
  #--------------------------------------------------------------------------
  def setup(actor_id)
    gas542434100(actor_id)
    @original_character_name = actor.character_name
    @original_character_index = actor.character_index
  end

  #--------------------------------------------------------------------------
  # * Tranform State Method
  #--------------------------------------------------------------------------
  def transform_state(state_id)
    note = /<Transform State:\s*(\w*)\S*\s*(\d*)\S*\s*(\w*)\S*\s*(\d*)\s*>/i
    data = $data_states[state_id].note.scan(note)
    if data != []
      new_character_name = $1
      new_character_index = $2.to_i 
      transform(new_character_name, new_character_index) 
      $game_player.refresh
    end
  end
  
  #--------------------------------------------------------------------------
  # * Remove State
  #--------------------------------------------------------------------------
  def remove_state(state_id)
    super(state_id)
    revert_actor
    $game_player.refresh
  end
  
  #--------------------------------------------------------------------------
  # * Add State
  #--------------------------------------------------------------------------
  def add_state(state_id)
    super(state_id)
    transform_state(state_id)
  end

  #--------------------------------------------------------------------------
  # * Revert Actor
  #--------------------------------------------------------------------------
  def revert_actor
    @character_name = @original_character_name
    @character_index = @original_character_index
  end
  
  #--------------------------------------------------------------------------
  # * Transform Actor
  #--------------------------------------------------------------------------
  def transform(character_name, character_index)
    @character_name = character_name
    @character_index = character_index
  end
  
end