#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
#                                                                              #
#                             V's Best Class Stats                             #
#                                 Version  1.0                                 #
#                                                                              #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#                                Written By:  V                                #
#                        Last Edited:  December 9, 2013                        #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#                                                                              #
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
 
  
#==============================================================================#
#------------------------------------------------------------------------------#
# ** Disclaimer                                                                #
#------------------------------------------------------------------------------#
#                                                                              #
# This script was intended for Non-commercial use only, if you wish to use     #
# this script in a commercial game please PM me at which ever site you found   #
# this script. Either way please give me credit in your game script as the     #
# writer of this script, and send me a PM abuot the release of the game/demo.  #
#                                                                              #
#------------------------------------------------------------------------------#
# ** How To Use                                                                #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#                                                                              #
# * This script is Plug & Play.                                                #
#                                                                              #
#------------------------------------------------------------------------------#
# ** Description                                                               #
#------------------------------------------------------------------------------#
#                                                                              #
#  v0.1                                                                        #
# ~=~=~=~                                                                      #
#  * This script automatically finds the highest stat for each of the actors   #
#    classes. This includes params, xparams, sparams, atk speed, atk times,    #
#    action times, equip weapon types and equip armor types.                   #
#                                                                              #
#------------------------------------------------------------------------------#
#==============================================================================#
#==============================================================================
# ** V's Best Class Stats
#==============================================================================
#==============================================================================
# ** Game_Actor
#------------------------------------------------------------------------------
#  This class handles actors. It is used within the Game_Actors class
# ($game_actors) and is also referenced from the Game_Party class ($game_party).
#==============================================================================

class Game_Actor < Game_Battler

  #--------------------------------------------------------------------------
  # * Object Initialization
  #--------------------------------------------------------------------------
  alias :i473453380004404400 :initialize
  
  #--------------------------------------------------------------------------
  # * Object Initialization
  #--------------------------------------------------------------------------
  def initialize(actor_id)
    i473453380004404400(actor_id)
    @atks = 0.0
    @atkt = 0.0
  end
  
  #--------------------------------------------------------------------------
  # * Returns All Of The Actor Classes
  #--------------------------------------------------------------------------
  def classes
    classes = []
    @exp.each { |i, v| classes.push i}
    return classes
  end
  
  #--------------------------------------------------------------------------
  # * Get Parameter
  #--------------------------------------------------------------------------
  def param(param_id)
    param = 0
    classes.each { |i|
      param = $data_classes[i].params[param_id, @level] if $data_classes[i].params[param_id, @level] > param
    }
    value = param + param_plus(param_id)
    value *= param_rate(param_id) * param_buff_rate(param_id)
    [[value, param_max(param_id)].min, param_min(param_id)].max.to_i
  end
  
  #--------------------------------------------------------------------------
  # * Get Ex-Parameter
  #--------------------------------------------------------------------------
  def xparam(xparam_id)
    xparam = 0.0
    classes.each { |i|
      $data_classes[i].features.each { |f| 
        if f.code == 22 && f.data_id == xparam_id
          xparam = f.value if f.value > xparam_id
        end
      }
    }
    return xparam
  end
  
  #--------------------------------------------------------------------------
  # * Get Sp-Parameter
  #--------------------------------------------------------------------------
  def sparam(sparam_id)
    sparam = 0.0
    classes.each { |i|
      $data_classes[i].features.each { |f| 
        if f.code == 23 && f.data_id == sparam_id
          sparam = f.value if f.value > sparam_id
        end
      }
    }
    return sparam
  end
  
  #--------------------------------------------------------------------------
  # * Determine Action Times
  #--------------------------------------------------------------------------
  def make_action_times
    actp = 1.0
    classes.each { |i|
      $data_classes[i].features.each { |f| 
        if f.code == 61
          actp = f.value if f.value > actp
        end
      }
    }
    return actp
  end
  
  #--------------------------------------------------------------------------
  # * Attack Speed
  #--------------------------------------------------------------------------
  def atk_speed
    atkt = 0.0
    classes.each { |i|
      $data_classes[i].features.each { |f| 
        if f.code == 34 
          atkt = f.value if f.value > atkt
        end
      }
    }
    return atkt
  end
  
  #--------------------------------------------------------------------------
  # * Change Additional Attack Times
  #--------------------------------------------------------------------------
  def atk_times_add
    atks = 0.0
    classes.each { |i|
      $data_classes[i].features.each { |f| 
        if f.code == 33 
          atks = f.value if f.value > atks
        end
      }
    }
    return atks
  end
  
  #--------------------------------------------------------------------------
  # * Determine if Weapon Can Be Equipped
  #--------------------------------------------------------------------------
  def equip_wtype_ok?(wtype_id)
    enabled = false
    classes.each { |i|
      $data_classes[i].features.each { |f| 
        if f.code == 51 && f.data_id == wtype_id
          enabled = true
          return enabled
        end
      }
    }
    return enabled
  end
  
  #--------------------------------------------------------------------------
  # * Determine if Armor Can Be Equipped
  #--------------------------------------------------------------------------
  def equip_atype_ok?(atype_id)
    enabled = false
    classes.each { |i|
      $data_classes[i].features.each { |f| 
        if f.code == 52 && f.data_id == atype_id
          enabled = true
          return enabled
        end
      }
    }
    return enabled
  end
   
end#<-- End Class===============================================================