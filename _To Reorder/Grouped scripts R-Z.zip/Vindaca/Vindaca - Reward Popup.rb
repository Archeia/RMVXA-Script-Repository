#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
#                                                                              #
#                              V's  Reward Pop Up                              #
#                                 Version  0.3                                 #
#                                                                              #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#                               Written By: Vindaca                            #
#                         Last Edited:  January 16, 2013                       #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
 
  
#==============================================================================#
#------------------------------------------------------------------------------#
# ** Disclaimer                                                                #
#------------------------------------------------------------------------------#
#                                                                              #
# This script was intended for Non-commercial use only, if you wish to use     #
# this script in a commercial game please PM me at which ever site you found   #
# this script. Either way please give me credit in your game script as the     #
# writer of this script, and send me a PM abuot the release of the game/demo.  #
#                                                                              #
#------------------------------------------------------------------------------#
# ** How To Use                                                                #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#                                                                              #
# * This script has two script calls:                                          #
#                                                                              #
#     This script call should be used at the beginning of the event before     #
#     any reward a given out to ensure no icon is repeated without reason.     #
#                                                                              #
#         * clear_reward                                                       #
#                                                                              #
#     This script call should be used after the last reward has been given.    #
#                                                                              #
#          * reward                                                            #
#                                                                              #
# * There is a customizable are below.                                         #
#                                                                              #
#------------------------------------------------------------------------------#
# ** Updates / Version Notes                                                   #
#------------------------------------------------------------------------------#
#                                                                              #
#  v0.1                                                                        #
# ~=~=~=~                                                                      #
#  * This script allows you to create a pop-up that displays rewards given on  #
#    the game map via events.                                                  #
#                                                                              #
#  v0.2                                                                        #
# ~=~=~=~                                                                      #
#  * I added a Font_Size & Font_Outline Options Below.                         #
#                                                                              #
#  v0.3                                                                        #
# ~=~=~=~                                                                      #
#  * This script is now compatible with V's Lucky Gold Find v0.2+.             #
#                                                                              #
#------------------------------------------------------------------------------#
#==============================================================================#
#==============================================================================
# ** V's Reward Pop Up 
#------------------------------------------------------------------------------
#  This module manages customizable features and methods.
#==============================================================================
module V_Reward_Pop_Up
  module Specs
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
#                                                                              #
#                           Start Customizable Area.                           #
#                                                                              #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#                                                                              #
#                        ONLY EDIT THE DESIGNATED AREAS.                       #
#                                                                              #
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#



  #=============================================================================
  # * Pop-up Options
  #=============================================================================

    #------------------------------------------------------------------------
    # * Font Options
    #------------------------------------------------------------------------
      Font_Size = 16
      Use_Outline = true
  
    #------------------------------------------------------------------------
    # * Reward Sound Effect
    #------------------------------------------------------------------------
      Reward_SE = ["Item1", 80, 100]
  
    #------------------------------------------------------------------------
    # * Gold Icon
    #------------------------------------------------------------------------
      Gold_Icon = 361
  
    #------------------------------------------------------------------------
    # * Amount of time (in frames) the reward should be displayed.
    #------------------------------------------------------------------------
      Display_Time = 90
  

    
    
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
#                                                                              #
#         DO NOT EDIT PAST THIS POINT UNLESS YOU KNOW WHAT YOUR DOING.         #
#                                                                              #
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#





















  end 
end #<--- End Module===========================================================


#==============================================================================
# ** Game_Party
#------------------------------------------------------------------------------
#  This class handles parties. Information such as gold and items is included.
# Instances of this class are referenced by $game_party.
#==============================================================================

class Game_Party < Game_Unit

  #--------------------------------------------------------------------------
  # * Public Instance Variables
  #--------------------------------------------------------------------------
  attr_accessor :rewards                                   # Rewards
  attr_accessor :give_rewards                              # Give Rewards?

  #--------------------------------------------------------------------------
  # * Aliasing Method: Object Initialization
  #--------------------------------------------------------------------------
  alias :i000040454245400400454 :initialize

  #--------------------------------------------------------------------------
  # * Object Initialization
  #--------------------------------------------------------------------------
  def initialize
    @rewards = []
    @give_rewards = false
    i000040454245400400454()
  end

  #--------------------------------------------------------------------------
  # * Add Reward
  #--------------------------------------------------------------------------
  def add_reward(type, value, id = nil)
    @rewards.push [type, value, id]
  end

  #--------------------------------------------------------------------------
  # * Current Reward
  #--------------------------------------------------------------------------
  def current_reward
    @rewards.last
  end

  #--------------------------------------------------------------------------
  # * Remove Rewards
  #--------------------------------------------------------------------------
  def remove_reward
    @rewards.delete_at @rewards.size - 1
  end

end


#==============================================================================
# ** Game_Interpreter
#------------------------------------------------------------------------------
#  An interpreter for executing event commands. This class is used within the
# Game_Map, Game_Troop, and Game_Event classes.
#==============================================================================

class Game_Interpreter

  #--------------------------------------------------------------------------
  # * Include Module
  #--------------------------------------------------------------------------
  if $imported["V_Lucky_Gold_Find"] == true
    include V_Lucky_Gold_Find::Specs
  end

  #--------------------------------------------------------------------------
  # * Aliasing Method: Change Gold
  #--------------------------------------------------------------------------
  alias :cmnd1254754534452453434 :command_125

  #--------------------------------------------------------------------------
  # * Change Gold
  #--------------------------------------------------------------------------
  def command_125
    value = operate_value(@params[0], @params[1], @params[2])
    if $imported["V_Lucky_Gold_Find"] == true
      s = $game_party.battle_members[0].param(7)
      sba = s*Bonus_Rate
      pb = 0
      t = $game_party.battle_members.size
      t.times { |i| pb += $game_party.battle_members[i - 1].param(7) }
      pba = pb*Bonus_Rate
      value = (value * sba).to_i if Solo_Bonus
      value = (value * pba).to_i if Solo_Bonus == false
    end
    $game_party.add_reward(0, value)
    cmnd1254754534452453434()
  end

  #--------------------------------------------------------------------------
  # * Aliasing Method: Change Items
  #--------------------------------------------------------------------------
  alias :cmnd126452434333453434 :command_126

  #--------------------------------------------------------------------------
  # * Change Items
  #--------------------------------------------------------------------------
  def command_126
    value = operate_value(@params[1], @params[2], @params[3])
    $game_party.add_reward(1, value, @params[0])
    cmnd126452434333453434()
  end

  #--------------------------------------------------------------------------
  # * Aliasing Method: Change Weapons
  #--------------------------------------------------------------------------
  alias :cmnd1274524744004053434 :command_127

  #--------------------------------------------------------------------------
  # * Change Weapons
  #--------------------------------------------------------------------------
  def command_127
    value = operate_value(@params[1], @params[2], @params[3])
    $game_party.add_reward(2, value, @params[0])
    cmnd1274524744004053434()
  end

  #--------------------------------------------------------------------------
  # * Aliasing Method: Change Armor
  #--------------------------------------------------------------------------
  alias :cmnd128452658646453464434 :command_128

  #--------------------------------------------------------------------------
  # * Change Armor
  #--------------------------------------------------------------------------
  def command_128
    value = operate_value(@params[1], @params[2], @params[3])
    $game_party.add_reward(3, value, @params[0])
    cmnd128452658646453464434()
  end

  #--------------------------------------------------------------------------
  # * Give Rewards
  #--------------------------------------------------------------------------
  def reward
    $game_party.give_rewards = true
  end

  #--------------------------------------------------------------------------
  # * Clear Last Reward
  #--------------------------------------------------------------------------
  def clear_reward
    $game_party.remove_reward if $game_party.rewards.size > 0
  end

end


#==============================================================================
# ** Scene_Map
#------------------------------------------------------------------------------
#  This class performs the map screen processing.
#==============================================================================

class Reward_Window < Window_Base
  
  #--------------------------------------------------------------------------
  # * Include Module
  #--------------------------------------------------------------------------
  include V_Reward_Pop_Up::Specs

  #--------------------------------------------------------------------------
  # * Refresh Processing
  #--------------------------------------------------------------------------
  def refresh(enabled = false)
    contents.clear
    draw_reward if enabled
  end
  
  #--------------------------------------------------------------------------
  # * Returns Character Graphic Dimensions
  #--------------------------------------------------------------------------
  def character_bitmap_width
    character_name = $game_party.members[0].character_name
    bitmap = Cache.character(character_name)
    sign = character_name[/^[\!\$]./]
    if sign && sign.include?('$')
      cw = bitmap.width / 3
    else
      cw = bitmap.width / 12
    end
    return cw
  end
  
  #--------------------------------------------------------------------------
  # * Draw Reward
  #--------------------------------------------------------------------------
  def draw_reward
    reward = $game_party.current_reward
    case reward[0]
    when 0
      string = ("+" + reward[1].to_s + " " + Vocab.currency_unit)
    when 1
      item_name =  $data_items[reward[2]].name
      string = ("+" + reward[1].to_s + " " + item_name)
    when 2
      item_name =  $data_weapons[reward[2]].name
      string = ("+" + reward[1].to_s + " " + item_name)
    when 3
      item_name =  $data_armors[reward[2]].name
      string = ("+" + reward[1].to_s + " " + item_name)
    end
    x = ($game_player.screen_x - (character_bitmap_width / 2)) - 5
    y = $game_player.screen_y - 96
    draw_icon(x, y, reward[0], reward[2])
    draw_sizable_text((x - (Graphics.width / 2)) + 10, y - 170, Graphics.width, Graphics.height, string, 1, Font_Size)
  end
  
  #--------------------------------------------------------------------------
  # * Draw Sizeable Text
  #--------------------------------------------------------------------------
  def draw_sizable_text(x, y, width, height, text, alignment, font_size)
    reset_font_settings
    contents.font.size = font_size
    contents.font.outline = Use_Outline
    contents.draw_text(x, y, width, height, text, alignment)
    reset_font_settings
  end
    
  #--------------------------------------------------------------------------
  # * Draw Icon
  #--------------------------------------------------------------------------
  def draw_icon(x, y, type, id)
    case type
    when 0
      icon_index = Gold_Icon
    when 1
      icon_index = $data_items[id].icon_index
    when 2
      icon_index = $data_weapons[id].icon_index
    when 3
      icon_index = $data_armors[id].icon_index
    end
    bitmap = Cache.system("Iconset")
    rect = Rect.new(icon_index % 16 * 24, icon_index / 16 * 24, 24, 24)
    contents.blt(x, y, bitmap, rect, 255)
  end
  

end

#==============================================================================
# ** Scene_Map
#------------------------------------------------------------------------------
#  This class performs the map screen processing.
#==============================================================================

class Scene_Map < Scene_Base

  #--------------------------------------------------------------------------
  # * Include Module
  #--------------------------------------------------------------------------
  include V_Reward_Pop_Up::Specs

  #--------------------------------------------------------------------------
  # * Aliasing Method: Object Initialization
  #--------------------------------------------------------------------------
  alias :i7777775552244155232511 :initialize

  #--------------------------------------------------------------------------
  # * Object Initialization
  #--------------------------------------------------------------------------
  def initialize
    @timer_completed = true
    @reward_frame = 0
    i7777775552244155232511()
  end

  #--------------------------------------------------------------------------
  # * Aliasing Method: Create All Windows
  #--------------------------------------------------------------------------
  alias :caw524042400 :create_all_windows

  #--------------------------------------------------------------------------
  # * Create All Windows
  #--------------------------------------------------------------------------
  def create_all_windows
    create_map_reward_window
    caw524042400()
  end

  #--------------------------------------------------------------------------
  # * Create Icon Window
  #--------------------------------------------------------------------------
  def create_map_reward_window
    @reward_window = Reward_Window.new(0,0,544,416)
    @reward_window.opacity = 0
  end

  #--------------------------------------------------------------------------
  # * Refresh Rewards
  #--------------------------------------------------------------------------
  def refresh_rewards(wait_time)
    show_icon = true
    if @reward_frame < wait_time
      @reward_frame += 1
    else
      $game_party.remove_reward
      show_icon = false
      @reward_frame = 0
      @timer_completed = true
    end
      @reward_window.refresh(show_icon)
  end

  #--------------------------------------------------------------------------
  # * Create Icon Window
  #--------------------------------------------------------------------------
  def update_rewards
    if $game_party.rewards.size > 0
      case
      when @timer_completed == true
        @reward_window.refresh(true)
        RPG::SE.new(Reward_SE[0], Reward_SE[1], Reward_SE[2]).play
        @timer_completed = false
      when @timer_completed == false
        refresh_rewards(Display_Time)
      end
    else 
      $game_party.give_rewards = false
    end
  end

  #--------------------------------------------------------------------------
  # * Aliasing Method: Process Updating
  #--------------------------------------------------------------------------
  alias :u45245045045204 :update

  #--------------------------------------------------------------------------
  # * Process Updating
  #--------------------------------------------------------------------------
  def update
    u45245045045204
    update_rewards if $game_party.give_rewards == true
  end

end