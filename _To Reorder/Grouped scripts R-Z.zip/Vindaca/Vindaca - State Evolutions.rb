#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
#                                                                              #
#                             V's State Evolutions                             #
#                                 Version  0.2                                 #
#                                                                              #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#                                Written By:  V                                #
#                         Last Edited:  January 6, 2013                        #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#                                                                              #
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
 
  
#==============================================================================#
#------------------------------------------------------------------------------#
# ** Disclaimer                                                                #
#------------------------------------------------------------------------------#
#                                                                              #
# This script was intended for Non-commercial use only, if you wish to use     #
# this script in a commercial game please PM me at which ever site you found   #
# this script. Either way please give me credit in your game script as the     #
# writer of this script, and send me a PM abuot the release of the game/demo.  #
#                                                                              #
#------------------------------------------------------------------------------#
# ** How To Use                                                                #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#                                                                              #
# * This script is Plug & Play.                                                #
#                                                                              #
# * Add this tag to any state notebox that you want to evolve.                 #
#                                                                              #
#   <Evolution State: state_id >                                               #
#                                                                              #
#------------------------------------------------------------------------------#
# ** Description                                                               #
#------------------------------------------------------------------------------#
#                                                                              #
#  v0.1                                                                        #
# ~=~=~=~                                                                      #
#  * This script automatically adds a state evolution feat. Let's say a zombie #
#    bit you well at first your just 'Scarred' then after one turn the state   #
#    is removed automatically, and a new one is added. Now your 'Feverish'     #
#    and so on until your 'One of Them'. Or lets say you have a transform      #
#    system based on states. Now when you are done with your 'Werewolf Form'   #
#    three turn killing spree, it is removed and now you are back to           #
#    'Human Form'. You can even use the 'Death' state.                         #
#                                                                              #
#  v0.2                                                                        #
# ~=~=~=~                                                                      #
#  * States now evolve with the "Steps Taken Removal Method."                  #
#                                                                              #
#------------------------------------------------------------------------------#
#==============================================================================#
#==============================================================================
# ** V's State Evolutions
#==============================================================================

#==============================================================================
# ** Game_Battler
#------------------------------------------------------------------------------
#  A battler class with methods for sprites and actions added. This class 
# is used as a super class of the Game_Actor class and Game_Enemy class.
#==============================================================================

class Game_Battler < Game_BattlerBase

  #--------------------------------------------------------------------------
  # * Aliasing Method: Object Initialization
  #--------------------------------------------------------------------------
  alias :bgrs4520453270060780 :remove_state

  #--------------------------------------------------------------------------
  # * Automatically Remove States
  #     timing:  Timing (1: End of action 2: End of turn)
  #--------------------------------------------------------------------------
  def remove_state(state_id)
    bgrs4520453270060780(state_id)
    evolve_current_state(state_id)
  end
  
  #--------------------------------------------------------------------------
  # * Evolve Current State
  #--------------------------------------------------------------------------
  def evolve_current_state(state_id)
    note = /<Evolution State:\s*(\d*)\s*>/i
    data = $data_states[state_id].note.scan(note)
    if data != []
      new_state = $1.to_i 
      add_state(new_state)
    end
  end
  
end