 
 
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
#                                                                              #
#                             V's Lucky Gold Find                              #
#                                 Version  0.4                                 #
#                                                                              #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#                                Written By:  V                                #
#                          Last Edited:  March 4, 2014                         #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#                                                                              #
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
 
  
#==============================================================================#
#------------------------------------------------------------------------------#
# ** Disclaimer                                                                #
#------------------------------------------------------------------------------#
#                                                                              #
# This script was intended for Non-commercial use only, if you wish to use     #
# this script in a commercial game please PM me at which ever site you found   #
# this script. Either way please give me credit in your game script as the     #
# writer of this script, and send me a PM abuot the release of the game/demo.  #
#                                                                              #
#------------------------------------------------------------------------------#
# ** How To Use                                                                #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#                                                                              #
# * This script is pretty much plug-and-play just two question below.          #
#                                                                              #
#------------------------------------------------------------------------------#
# ** Description                                                               #
#------------------------------------------------------------------------------#
#                                                                              #
#  v0.1                                                                        #
# ~=~=~=~                                                                      #
#                                                                              #
# This script basically give you a 0.5% bonus for every point the party leader #
# has in luck.                                                                 #
#                                                                              #
#  v0.2                                                                        #
# ~=~=~=~                                                                      #
#                                                                              #
# Script has been set-up for Add-Ons.                                          #
#                                                                              #
#  v0.3                                                                        #
# ~=~=~=~                                                                      #
#                                                                              #
# The script has been shortened for more compatibility.                        #
#                                                                              #
#  v0.4                                                                        #
# ~=~=~=~                                                                      #
#                                                                              #
# I've added an option to only effect the battle gold rewards.                 #
#                                                                              #
#------------------------------------------------------------------------------#
#==============================================================================#
   

$imported = {} if $imported.nil?
$imported["V_Lucky_Gold_Find"] = true

module V_Lucky_Gold_Find
  module Specs
    
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
#                                                                              #
#                           Start Customizable Area.                           #
#                                                                              #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#                                                                              #
#                      ONLY EDIT AFTER THE EQUALS SYMBOL.                      #
#                                                                              #
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
   

  #============================================================================
  # This controls if you only want to use the leader luck as a factor.
  #============================================================================
 
    Battle_Increase_Only = true
    Solo_Bonus = true
    Bonus_Rate = 1

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
#                                                                              #
#         DO NOT EDIT PAST THIS POINT UNLESS YOU KNOW WHAT YOUR DOING.         #
#                                                                              #
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
end
end


class Game_Party < Game_Unit
  include V_Lucky_Gold_Find::Specs
  unless Battle_Increase_Only == true
    alias :gain_gold16311 :gain_gold
    def gain_gold(amount)
      s = $game_party.battle_members[0].param(7)
      sba = s*Bonus_Rate
      pb = 0
      t = $game_party.battle_members.size
      t.times { |i| pb += $game_party.battle_members[i - 1].param(7) }
      pba = pb*Bonus_Rate
      amount = (amount * sba).to_i if Solo_Bonus
      amount = (amount * pba).to_i if Solo_Bonus == false
      gain_gold16311(amount)
    end
  end
end
module BattleManager
  include V_Lucky_Gold_Find::Specs
  def self.gain_gold
    s = $game_party.battle_members[0].param(7)
    sba = s*Bonus_Rate
    pb = 0
    t = $game_party.battle_members.size
    t.times { |i| pb += $game_party.battle_members[i - 1].param(7) }
    pba = pb*Bonus_Rate
    amount = ($game_troop.gold_total * sba).to_i if Solo_Bonus
    amount = ($game_troop.gold_total * pba).to_i if Solo_Bonus == false
    if amount > 0
      text = sprintf(Vocab::ObtainGold, amount)
      $game_message.add('\.' + text)
      $game_party.gain_gold(amount)
    end
    wait_for_message
  end
end