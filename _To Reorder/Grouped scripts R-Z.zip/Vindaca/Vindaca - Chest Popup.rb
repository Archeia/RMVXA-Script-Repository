 
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
#                                                                              #
#                               V's Chest Pop-Up                               #
#                                 Version  0.2                                 #
#                                                                              #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#                                Written By:  V                                #
#                          Last Edited: August 24, 2013                        #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#                                                                              #
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
 
  
#==============================================================================#
#------------------------------------------------------------------------------#
# ** Disclaimer                                                                #
#------------------------------------------------------------------------------#
#                                                                              #
# This script was intended for Non-commercial use only, if you wish to use     #
# this script in a commercial game please PM me at which ever site you found   #
# this script. Either way please give me credit in your game script as the     #
# writer of this script, and send me a PM abuot the release of the game/demo.  #
#                                                                              #
#------------------------------------------------------------------------------#
# ** How To Use                                                                #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#                                                                              #
# * This script is pretty much plug-and-play.                                  #
#                                                                              #
# * Just leave the word chest in a script call at the bottom of any event page #
#   that you want to use the window with.                                      #
#                                                                              #
#------------------------------------------------------------------------------#
# ** Description                                                               #
#------------------------------------------------------------------------------#
#                                                                              #
#  v0.1                                                                        #
# ~=~=~=~                                                                      #
#                                                                              #
# This script displays any gold that is found durring an event in pop-up.      #
#                                                                              #
#  v0.2                                                                        #
# ~=~=~=~                                                                      #
#                                                                              #
# Fixed a bug that was making the window pop up whenever any event was         #
# triggered                                                                    #
#                                                                              #
#------------------------------------------------------------------------------#
#==============================================================================#
   





#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
#                                                                              #
#         DO NOT EDIT PAST THIS POINT UNLESS YOU KNOW WHAT YOUR DOING.         #
#                                                                              #
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
   
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 


















 
$imported = {} if $imported.nil?
$imported["V's Chest Pop-Up"] = true
    
class VCPW < Window_Base
  def initialize(x, y, w, h)
    super(x, y, w, h)
    dpr
  end
  def lc
    color = normal_color
    color.alpha = 200
    color
  end
  def dhl
    contents.fill_rect(0, 30, 544, 2, lc)
  end
  def dpr
    draw_text(0, -60, 200, 150,  "You Got", 0)
    dhl
    dg if $game_system.gf != 0
  end
  def dg
    gv = $data_system.currency_unit
    ga = $game_system.gf.to_s
    draw_icon(361, 145, 41)
    draw_text(-55, -20,200, 150,  gv, 2)
    $imported["V_Lucky_Gold_Find"] ? draw_text(-70, -20, 200, 150, $game_system.gra, 2) : draw_text(-70, -20, 200, 150, ga, 2)
  end
end
class VCPS < Scene_Base
  def start
    super
    cpw
    cb
  end
  def cb
    @bs = Sprite.new
    @bs.bitmap = SceneManager.background_bitmap
    @bs.color.set(16, 16, 16, 128)
  end
  def dcb
    @bs.dispose
    @bs.bitmap.dispose
  end
  def cpw
    @pw = VCPW.new(172, 80, 200, 100)
  end
  def cs
    rv
    dcb
    return_scene
  end
  def rv
    $game_system.rc = 0
  end
  def update 
    super
    cs if Input.trigger?(:B)
  end
end
class Game_Interpreter
  def chest
    SceneManager.call(VCPS)
  end
  alias :command_1250645600 :command_125
  def command_125
    $game_system.rc += 1
    $game_system.gf = operate_value(@params[0], @params[1], @params[2])
    command_1250645600()
  end
end
class Game_System
  attr_accessor :gf
  attr_accessor :rc
  alias :old_init452527327532 :initialize
  def initialize
    @gf = 0 
    @rc = 0 
    old_init452527327532()
  end
end