#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
#                                                                              #
#                         V's  Auto Message Formatting                         #
#                                 Version  0.4                                 #
#                                                                              #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#                                Written By:  V                                #
#                         Last Edited:  March 20, 2014                         #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#                                                                              #
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
#==============================================================================#
#------------------------------------------------------------------------------#
# ** Disclaimer                                                                #
#------------------------------------------------------------------------------#
#                                                                              #
# This script was intended for Non-Commercial use only, if you wish to use     #
# this script in a commercial game please PM me at which ever site you found   #
# this script. Either way please give me credit in your game script as the     #
# writer of this script, and send me a PM abuot the release of the game/demo.  #
#                                                                              #
#------------------------------------------------------------------------------#
# ** How To Use                                                                #
#------------------------------------------------------------------------------#
#                                                                              #
#  * This script is Plug & Play.                                               #
#                                                                              #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#                                                                              #
#  * Additional Control/Escape Characters                                      #
#                                                                              #
#    \~                             ~ Quick Indent                             #
#    \M                             ~ Current Map Display Name                 #
#    \L                             ~ Current Group Leader                     #
#    \CG                            ~ Current Amount of Gold                   #
#    \K[x]                          ~ Party Member x Nickname                  #
#    \E[x]                          ~ Enemy x Name                             #
#    \ET[x]                         ~ Enemy Troop x Name                       #
#    \IT[x]                         ~ Item x Name                              #
#    \W[x]                          ~ Weapon Troop x Name                      #
#    \A[x]                          ~ Armor Troop x Name                       #
#    \Y[x]                          ~ Change Message Window Y to x             #
#                                                                              #
#------------------------------------------------------------------------------#
# ** Description                                                               #
#------------------------------------------------------------------------------#
#                                                                              #
#  v0.1                                                                        #
# ~=~=~=~                                                                      #
#                                                                              #
# In v0.1, this script automatically formats the games messages for you.       #
# This enables you to type everything on one line when writing out messages    #
# while also allowing you to still use the enter key and \n to start a new     #
# line if wanted.                                                              #
#                                                                              #
#  v0.2                                                                        #
# ~=~=~=~                                                                      #
#                                                                              #
# In v0.2, I added a few additional control/escape characters.                 #
#                                                                              #
#  v0.3                                                                        #
# ~=~=~=~                                                                      #
#                                                                              #
# In v0.3, I added a few more additional control/escape characters.            #
#                                                                              #
#  v0.4                                                                        #
# ~=~=~=~                                                                      #
#                                                                              #
# In v0.4, I added a control/escape character to change the windows y position.#
#                                                                              #
#------------------------------------------------------------------------------#
#==============================================================================#
#==============================================================================
# ** Window_Message
#------------------------------------------------------------------------------
#  This message window is used to display text.
#==============================================================================

class Window_Message < Window_Base

  #--------------------------------------------------------------------------
  # * Process All Text
  #--------------------------------------------------------------------------
  def process_all_text
    pos = {}
    text = format_text($game_message.all_text)
    open_and_wait
    new_page(text, pos)
    process_character(text.slice!(0, 1), text, pos) until text.empty?
  end
  
  #--------------------------------------------------------------------------
  # * Aliased Method: Control Character Processing
  #--------------------------------------------------------------------------
  alias :wmpec1002654654200456 :convert_escape_characters
 
  #--------------------------------------------------------------------------
  # * Preconvert Control Characters
  #    As a rule, replace only what will be changed into text strings before
  #    starting actual drawing. The character "\" is replaced with the escape
  #    character (\e).
  #--------------------------------------------------------------------------
  def convert_escape_characters(text)
    wmpec1002654654200456(text)
    result = text.to_s.clone
    result.gsub!(/\\/)             { "\e" }
    result.gsub!(/\e\e/)           { "\\" }
    result.gsub!(/\eV\[(\d+)\]/i)  { $game_variables[$1.to_i] }
    result.gsub!(/\eN\[(\d+)\]/i)  { actor_name($1.to_i) }
    result.gsub!(/\eP\[(\d+)\]/i)  { party_member_name($1.to_i) }
    result.gsub!(/\eG/i)           { Vocab::currency_unit }
    result.gsub!(/\eM/i)           { $game_map.display_name }
    result.gsub!(/\e~/i)           { "    " }
    result.gsub!(/\eL/i)           { $game_party.battle_members[0].name }
    result.gsub!(/\eCG/i)          { $game_party.gold.to_s }
    result.gsub!(/\eK\[(\d+)\]/i)  { $game_party.members[$1.to_i].nickname }
    result.gsub!(/\eE\[(\d+)\]/i)  { $data_enemies[$1.to_i].name }
    result.gsub!(/\eET\[(\d+)\]/i) { $data_troops[$1.to_i].name }
    result.gsub!(/\eIT\[(\d+)\]/i) { $data_items[$1.to_i].name }
    result.gsub!(/\eW\[(\d+)\]/i)  { $data_weapons[$1.to_i].name }
    result.gsub!(/\eA\[(\d+)\]/i)  { $data_armors[$1.to_i].name }
    self.y = $1.to_i if result.scan(/\eY\[(\d+)\]/i) != []
    result.gsub!(/\eY\[(\d+)\]/i)  { "" }
    result
  end
  
  #--------------------------------------------------------------------------
  # * Format(Text)
  #--------------------------------------------------------------------------
  def format_text(text)
    x_pos = 0
    temp_text = convert_escape_characters(text)
    temp_text.size.times { |i|
      element = i
      case 
      when temp_text[element] == "\e" && temp_text[element + 1] == "n"
        temp_text[element + 2] = "\n"
        x_pos = 0
        next
      end
      if x_pos >= (self.width - ($game_message.face_name.empty? ? 28 : 168 ))
        while(temp_text[element] != " ")
          break if element == 0
          element -= 1
        end
        temp_text[element] = "\n"
        i = element
        x_pos = 0
      else
        x_pos += text_size(temp_text[i]).width
      end
    }
    return temp_text
  end
  
end