#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
#                                                                              #
#                          V's Unlimited Parallax Maps                         #
#                                 Version  0.1                                 #
#                                                                              #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#                                Written By:  V                                #
#                       Last Edited:  September 23, 2013                       #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#                                                                              #
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
 
  
#==============================================================================#
#------------------------------------------------------------------------------#
# ** Disclaimer                                                                #
#------------------------------------------------------------------------------#
#                                                                              #
# This script was intended for Non-commercial use only, if you wish to use     #
# this script in a commercial game please PM me at which ever site you found   #
# this script. Either way please give me credit in your game script as the     #
# writer of this script, and send me a PM about the release of the game/demo.  #
#                                                                              #
#------------------------------------------------------------------------------#
# ** How To Use                                                                #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#                                                                              #
#  ==========================================================================  #
#  =                                                                        =  #
#  =                                 IMPORTANT                              =  #
#  =                                                                        =  #
#  ==========================================================================  #
#                                                                              #
# * Maps must be imported into the pictures folder.                            #
#                                                                              #
# * Each map MUST HAVE a base layer.                                           #
#                                                                              #
# * You must set the layers opacity that you want visable when you enter the   #
#   map. Base layers opacity is set to 255 by default.                         #
#                                                                              #
# * To veiw a layer above the player set the z_position's value above 101.     #
#                                                                              #
#  ==========================================================================  #
#  * Map Notetags                                                              #
#  ==========================================================================  #
#                                                                              #
#      For Base Layer.                                                         #
#      ~~~~~~~~~~~~~~~                                                         #
#        <Base: name, var_id>                                                  #
#                                                                              #
#      For Additional Layers.                                                  #
#      ~~~~~~~~~~~~~~~~~~~~~~                                                  #
#        <Layer: z_position, name, var_id, opacity_var_id>                     #
#                                                                              #
#  ==========================================================================  #
#  * Map Names                                                                 #
#  ==========================================================================  #
#                                                                              #
# * Maps must be named as such. (image_name + "_" + frame)                     #
#                                                                              #
#    Example of how to name the maps.                                          #
#    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                          #
#    mn1_1                                                                     #
#    woods_1                                                                   #
#    barbershop_1, barbershop_2, barbershop_3, barbershop_4                    #
#                                                                              #
#  ==========================================================================  #
#  * Animating Parallaxes                                                      #
#  ==========================================================================  #
#                                                                              #
# * Map frames are used for animating parallaxes.                              #
# ** To use animations set the layers var to whatever frame you want.          #
# ** To change the opacity set the layers opacity var to what you want.        #
#                                                                              #
#------------------------------------------------------------------------------#
# ** Description                                                               #
#------------------------------------------------------------------------------#
#                                                                              #
#  v0.1                                                                        #
# ~=~=~=~                                                                      #
#                                                                              #
# The script is set up to take a base layer and as many other layers as you    #
# can fit into the maps notebox, as well as animate them.                      #
#                                                                              #
#------------------------------------------------------------------------------#
#==============================================================================#


#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
#                                                                              #
#        DO NOT EDIT PASSED THIS POINT UNLESS YOU KNOW WHAT YOUR DOING.        #
#                                                                              #
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#







































class Game_Map
  def lnote
    t = /<Layer:\s*(\d*)\S*\s*(\w*)\S*\s*(\d*)\S*\s*(\d*)>/i
    n = @map.note
    pm = n.scan(t)
    return pm
  end
  def bnote
    t = /<Base:\s*(\w*)\S*\s*(\d*)\S*\s*(\d*)>/i
    n = @map.note
    pm = n.scan(t)
    return pm
  end
  alias :sp450404210 :setup_parallax
  def setup_parallax
    sp450404210()
  end
end
class Game_System
  attr_accessor :curz
  alias :i040404201 :initialize
  def initialize
    @curz = 0 
    i040404201()
  end
end
class Spriteset_Map
  alias :i05042042 :initialize
  def initialize
    @pml = []
    cbl
    i05042042()
    cpm
  end
  def cbl
    bl = $game_map.bnote
    z = -101 
    n = bl[0][0]
    v = bl[0][1].to_i
    $game_variables[v] = 0
    var = $game_variables[v]
    name = (n + "_") + var.to_s
    @pmbl = Sprite.new(@viewport1)
    @pmbl.bitmap = Cache.picture(name)
    @pmbl.z = z - $game_system.curz
    @curblvar = var
  end
  def ubl
    bl = $game_map.bnote
    n = bl[0][0]
    v = bl[0][1].to_i
    var = $game_variables[v]
    name = (n + "_") + var.to_s
    if @curblvar != var
      @pmbl.bitmap = Cache.picture(name)
      @curblvar = var
    end
    @pmbl.ox = $game_map.display_x * 32 if @pmbl.ox != $game_map.display_x * 32
    @pmbl.oy = $game_map.display_y * 32 if @pmbl.oy != $game_map.display_y * 32
  end
  def cpm
    @curpmopc = []
    @curpmvars = []
    pm = $game_map.lnote
    if pm != []
      pm.size.times {|i|
        z = pm[i][0] 
        n = pm[i][1]
        v = pm[i][2].to_i
        var = $game_variables[v]
        $game_variables[v] = 0
        name = (n + "_") + var.to_s
        o = $game_variables[pm[i][3].to_i]
        @pml[i] = Sprite.new(@viewport1)
        @pml[i].bitmap = Cache.picture(name)
        @pml[i].opacity = o
        @pml[i].z = z.to_i - $game_system.curz
        @curpmvars[i] = var
        @curpmopc[i] = o
      }
    end
  end
  def upm
    cx = []
    cy = []
    pm = $game_map.lnote
    if pm != []
      @pml.size.times {|i|
        n = pm[i][1]
        v = pm[i][2].to_i
        var = $game_variables[v]
        name = (n + "_") + var.to_s
        o = $game_variables[pm[i][3].to_i]
        if @curpmvars[i] != var
          @pml[i].bitmap = Cache.picture(name)
          @curpmvars[i] = var
        end
        if @curpmopc[i] != o
          @pml[i].opacity = o
          @curpmopc[i] = o
        end
      }
      @pml.size.times { |i| 
         cx[i] = @pml[i].ox 
         cy[i] = @pml[i].oy 
         @pml[i].ox = $game_map.display_x * 32 if @pml[i].ox != $game_map.display_x * 32
         @pml[i].oy = $game_map.display_y * 32 if @pml[i].oy != $game_map.display_y * 32
      }
    end
  end
  def dpm
    if @pml != []
      @pml.size.times { |i| 
        @pml[i].dispose
        @pml[i].bitmap.dispose
      }
    end
  end
  def dbl
    @pmbl.dispose
    @pmbl.bitmap.dispose
  end
  alias :u420542175045 :update
  def update
    ubl
    upm
    u420542175045()
  end
end
class Scene_Map < Scene_Base
  alias :pt054046404 :post_transfer
  def post_transfer
    @spriteset.dbl
    @spriteset.dpm
    @spriteset.cbl
    @spriteset.cpm
    @spriteset.update
    pt054046404()
  end
end