 
 
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
#                                                                              #
#                             V's Real Time Events                             #
#                                 Version  0.2                                 #
#                                                                              #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#                                Written By:  V                                #
#                        Last Edited:  January 30, 2013                        #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#                                                                              #
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
#                                                                              #
#==============================================================================#
#------------------------------------------------------------------------------#
# ** Disclaimer                                                                #
#------------------------------------------------------------------------------#
#                                                                              #
# This script was intended for Non-commercial use only, if you wish to use     #
# this script in a commercial game please PM me at which ever site you found   #
# this script. Either way please give me credit in your game script as the     #
# writer of this script, and send me a PM abuot the release of the game/demo.  #
#                                                                              #
#------------------------------------------------------------------------------#
# ** How To Use                                                                #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#                                                                              #
# * If you do not care to use a value you can replace it with a string         #
#         :time => [second, minute, hour, day, month, year]                    #
#                                                                              #
# * Variables and Switches may have as many assigned to a Time_Event           #
#   as you want.                                                               #
#         :variables => [[variable_id, value], [variable_id, value]]           #
#         :switches => [switch_id, switch_id]                                  #
#                                                                              #
#------------------------------------------------------------------------------#
# ** Description                                                               #
#------------------------------------------------------------------------------#
#                                                                              #
#  v0.1                                                                        #
# ~=~=~=~                                                                      #
#                                                                              #
# * This script is an extention of my conditional checks script. It was based  #
#   on Gump's Time Script. This script can be used to implement real time into #
#   your game via switches and variables.                                      # 
#                                                                              #
#  v0.2                                                                        #
# ~=~=~=~                                                                      #
#                                                                              #
# * Bug Fixed.                                                                 # 
#                                                                              #
#------------------------------------------------------------------------------#
#==============================================================================#

#==============================================================================
# ** V's Real Time Events
#------------------------------------------------------------------------------
#  This module manages customizable features and methods.
#==============================================================================
module V_Real_Time_Events
  Time_Events = {}
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
#                                                                              #
#                           Start Customizable Area.                           #
#                                                                              #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#                                                                              #
#                        ONLY EDIT THE DESIGNATED AREAS.                       #
#                                                                              #
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#


  #=============================================================================
  # * Time Event Set Up
  #=============================================================================

  Time_Events["Santa Gift Drop"] = {  :time => ["na", 31, 2, 16, 12, 13],
                                      :variables => [[1, 2], [2, 1]],
                                      :switches => [1, 2, 3, 4, 5],
                                    }
  
  Time_Events["Santa Goes Home"] = {  :time => ["na", 6, 6, 16, 12, 13],
                                      :variables => [[1, 0], [2, 2]],
                                      :switches => [1, 2],
                                    }
  
  
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
#                                                                              #
#         DO NOT EDIT PAST THIS POINT UNLESS YOU KNOW WHAT YOUR DOING.         #
#                                                                              #
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#






























  





  #=============================================================================
  # * Get System Time
  #=============================================================================

  def self.system_time
    systime = { :year => Time.now.strftime('%y').to_i,
                :month => Time.now.strftime('%m').to_i,
                :day => Time.now.strftime('%d').to_i,
                :hour => Time.now.strftime('%H').to_i,
                :minute => Time.now.strftime('%M').to_i,
                :second => Time.now.strftime('%S').to_i,
              } 
    return systime
   end
                  
  #=============================================================================
  # * Get Event Time by Index
  #=============================================================================

  def self.event_time(index)
      evtime = {  :year => Time_Events[index][:time][5],
                  :month => Time_Events[index][:time][4],
                  :day => Time_Events[index][:time][3],
                  :hour => Time_Events[index][:time][2],
                  :minute => Time_Events[index][:time][1],
                  :second => Time_Events[index][:time][0],
                }
    return evtime
  end
  
  #=============================================================================
  # * Initialize Queued Events by Index
  #=============================================================================

  def self.initialize_queued_event(index)
    $game_system.event_activation_states[index] = true
    if Time_Events[index].has_key?(:variables)
      Time_Events[index][:variables].size.times { |i|
        var = Time_Events[index][:variables][i][0]
        value = Time_Events[index][:variables][i][1]
        $game_variables[var] = value
      }
    end
    if Time_Events[index].has_key?(:switches)
      Time_Events[index][:switches].size.times { |i|
        switch = Time_Events[index][:switches][i]
        $game_switches[switch] == true ? $game_switches[switch] = false : $game_switches[switch] = true
      }
    end
  end
  
  #=============================================================================
  # * Events Update? by Index
  #=============================================================================

  def self.events_update?(index)
    return false if $game_system.event_activation_states[index] == true
    time = false, st = system_time, et = event_time(index)
    et.each_key { |i| 
      if et[i].is_a?(String)
        next
      else
        if st[i] > et[i]
          return true
        else
          if st[i] == et[i]
            time = true
          else
            return false
          end
        end
      end
    }
    return time
  end
  
end


#==============================================================================
# ** Game_System
#------------------------------------------------------------------------------
#  This class handles system data. It saves the disable state of saving and 
# menus. Instances of this class are referenced by $game_system.
#==============================================================================

class Game_System

  #--------------------------------------------------------------------------
  # * Public Instance Variables
  #--------------------------------------------------------------------------
  attr_accessor :event_activation_states        # Event_Times activation states

  #--------------------------------------------------------------------------
  # * Aliasing Method: Initialize Proccessing
  #--------------------------------------------------------------------------
  alias :gsi75214524000  :initialize

  #--------------------------------------------------------------------------
  # * Initialize Proccessing
  #--------------------------------------------------------------------------
  def initialize
    gsi75214524000()
    @event_activation_states = {}
    V_Real_Time_Events::Time_Events.each_key { |i|
      @event_activation_states[i] = false
    }
  end

end

#==============================================================================
# ** Scene_Map
#------------------------------------------------------------------------------
#  This class performs the map screen processing.
#==============================================================================

class Scene_Map < Scene_Base

  #--------------------------------------------------------------------------
  # * Aliasing Method: Update Proccessing
  #--------------------------------------------------------------------------
  alias :smu65465432  :update

  #--------------------------------------------------------------------------
  # * Update Proccessing
  #--------------------------------------------------------------------------
  def update(*args)
    smu65465432 
    V_Real_Time_Events::Time_Events.each_key { |i|
     V_Real_Time_Events.initialize_queued_event(i) if V_Real_Time_Events.events_update?(i)
    }
  end
  
end