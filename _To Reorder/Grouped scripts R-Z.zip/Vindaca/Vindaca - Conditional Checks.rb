#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
#                                                                              #
#                           V's Conditional Check's                            #
#                                 Version  1.2                                 #
#                                                                              #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#                                Written By:  V                                #
#                       Last Edited:  September 19, 2013                       #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#                                                                              #
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
 
  
#==============================================================================#
#------------------------------------------------------------------------------#
# ** Disclaimer                                                                #
#------------------------------------------------------------------------------#
#                                                                              #
# This script was intended for Non-commercial use only, if you wish to use     #
# this script in a commercial game please PM me at which ever site you found   #
# this script. Either way please give me credit in your game script as the     #
# writer of this script, and send me a PM abuot the release of the game/demo.  #
#                                                                              #
#------------------------------------------------------------------------------#
# ** How To Use                                                                #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#                                                                              #
# * This script is plug-and-play. Use any one of these checks in a conditional #
# branch                                                                       #
#                                                                              #
# * Checks are as follows:                                                     #
#                                                                              #
#  ==========================================================================  #
#    The following can be used with                                            #
#  $game_actors[i] || $game_party.members[i] || $game_party.battle_members[i]  #
#  ==========================================================================  #
#                                                                              #
#     For checking if weapons and armors are equiped.                          #
#     ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                          #
#     .has_armor_equiped?                                                      #
#     .has_weapon_equiped?                                                     #
#                                                                              #
#                                                                              #
#     For checking weapon and armor types.                                     #
#     ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                     #
#     .has_armor_type(armor_type_id)                                           #
#     .has_weapon_type(weapon_type_id)                                         #
#                                                                              #
#                                                                              #
#     For checking Hp.                                                         #
#     ~~~~~~~~~~~~~~~~                                                         #
#     .hp_is?(amount)                                                          #
#     .hp_is_less_then?(amount)                                                #
#     .hp_is_more_then?(amount)                                                #
#                                                                              #
#                                                                              #
#     For checking Mp.                                                         #
#     ~~~~~~~~~~~~~~~~                                                         #
#     .mp_is?(amount)                                                          #
#     .mp_is_less_then?(amount)                                                #
#     .mp_is_more_then?(amount)                                                #
#                                                                              #
#                                                                              #
#     For checking Tp.                                                         #
#     ~~~~~~~~~~~~~~~~                                                         #
#     .tp_is?(amount)                                                          #
#     .tp_is_less_then?(amount)                                                #
#     .tp_is_more_then?(amount)                                                #
#                                                                              #
#                                                                              #
#     For checking Hp by Percentage. (1% == 0.01)                              #
#     ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                           #
#     .hp_percentage_is?(amount)                                               #
#     .hp_percentage_is_less_then?(amount)                                     #
#     .hp_percentage_is_more_then?(amount)                                     #
#                                                                              #
#                                                                              #
#     For checking Mp by Percentage. (1% == 0.01)                              #
#     ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                           #
#     .mp_percentage_is?(amount)                                               #
#     .mp_percentage_is_less_then?(amount)                                     #
#     .mp_percentage_is_more_then?(amount)                                     #
#                                                                              #
#                                                                              #
#     For checking Tp by Percentage. (1% == 0.01)                              #
#     ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                           #
#     .tp_percentage_is?(amount)                                               #
#     .tp_percentage_is_less_then?(amount)                                     #
#     .tp_percentage_is_more_then?(amount)                                     #
#                                                                              #
#                                                                              #
#     For checking params                                                      #
#     ~~~~~~~~~~~~~~~~~~~                                                      #
#     .param_is?(param_id, amount)                                             #
#     .param_is_less_then?(param_id, amount)                                   #
#     .param_is_more_then?(param_id, amount)                                   #
#                                                                              #
#                                                                              #
#     For checking sparams                                                     #
#     ~~~~~~~~~~~~~~~~~~~~                                                     #
#     .sparam_is?(sparam_id, amount)                                           #
#     .sparam_is_less_then?(sparam_id, amount)                                 #
#     .sparam_is_more_then?(sparam_id, amount)                                 #
#                                                                              #
#                                                                              #
#     For checking xparams                                                     #
#     ~~~~~~~~~~~~~~~~~~~~                                                     #
#     .xparam_is?(xparam_id, amount)                                           #
#     .xparam_is_less_then?(xparam_id, amount)                                 #
#     .xparam_is_more_then?(xparam_id, amount)                                 #
#                                                                              #
#                                                                              #
#  ==========================================================================  #
#    The following can be used with $game_party                                #
#  ==========================================================================  #
#                                                                              #
#     For checking item quantities.                                            #
#     ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                            #
#     .less_then_amount_items?(item_id, amount)        item[x] < amount        #
#     .more_then_amount_items?(item_id, amount)        item[x] > amount        #
#     .fixed_amount_items?(item_id, amount)            item[x] == amount       #
#                                                                              #
#                                                                              #
#      For checking gold spent in stores.                                      #
#      ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                       #
#     .amount_spent_is?(amount)                        amount_spent == amount  #
#     .amount_spent_less_then?(amount)                 amount_spent < amount   #
#     .amount_spent_more_then?(amount)                 amount_spent > amount   #
#                                                                              #
#                                                                              #
#      Checks if any party member is of class x.                               #
#      ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                               #
#     .has_class?(class_id)                                                    #
#                                                                              #
#                                                                              #
#      Checks the total level of the party members.                            #
#      ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                            #
#     .total_plevel_is?(amount)                                                #
#     .total_plevel_less_then?(amount)                                         #
#     .total_plevel_more_then?(amount)                                         #
#                                                                              #
#                                                                              #
#      Checks the average level of the party members.                          #
#      ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                          #
#     .average_plevel_is?(amount)                                              #
#     .average_plevel_less_then?(amount)                                       #
#     .average_plevel_more_then?(amount)                                       #
#                                                                              #
#                                                                              #
#      Checks the total level of the battle members.                           #
#      ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                           #
#     .total_level_is?(amount)                                                 #
#     .total_level_less_then?(amount)                                          #
#     .total_level_more_then?(amount)                                          #
#                                                                              #
#                                                                              #
#      Checks the average level of the battle members.                         #
#      ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                         #
#     .average_level_is?(amount)                                               #
#     .average_level_less_then?(amount)                                        #
#     .average_level_more_then?(amount)                                        #
#                                                                              #
#                                                                              #
#      Checks the number of steps taken.                                       #
#      ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                       #
#     .steps_are?(amount)                                                      #
#     .steps_are_less_then?(amount)                                            #
#     .steps_are_more_then?(amount)                                            #
#                                                                              #
#                                                                              #
#      Checks the number of battle victories.                                  #
#      ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                  #
#     .battle_wins_are?(amount)                                                #
#     .battle_wins_less_then?(amount)                                          #
#     .battle_wins_more_then?(amount)                                          #
#                                                                              #
#                                                                              #
#      Checks the number of battle losses.                                     #
#      ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                     #
#     .battle_losses_are?(amount)                                              #
#     .battle_losses_less_then?(amount)                                        #
#     .battle_losses_more_then?(amount)                                        #
#                                                                              #
#                                                                              #
#      Checks the number of battle escapes.                                    #
#      ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                    #
#     .escape_count_is?(amount)                                                #
#     .escape_count_less_then?(amount)                                         #
#     .escape_count_more_then?(amount)                                         #
#                                                                              #
#                                                                              #
#      Checks the if the leader is $game_actors x.                             #
#      ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                             #
#     .leader_is?(actor_id)                                                    #
#                                                                              #
#                                                                              #
#      Checks the total gold found durring game.                               #
#      ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                               #
#     .total_gold_is?(amount)                                                  #
#     .total_gold_is_less_then?(amount)                                        #
#     .total_gold_is_more_then?(amount)                                        #
#                                                                              #
#                                                                              #
#  ==========================================================================  #
#    The following can be used with $game_system                               #
#  ==========================================================================  #
#                                                                              #
#      For checking game time in seconds.                                      #
#      ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                      #
#     .game_time_less_then?(amount_in_seconds)         time < amount           #
#     .game_time_more_then?(amount_in_seconds)         time > amount           #
#     .game_time_is?(amount_in_seconds)                time == amount          #
#                                                                              #
#                                                                              #
#      For checking battle count.                                              #
#      ~~~~~~~~~~~~~~~~~~~~~~~~~~                                              #
#     .battle_count_is?(amount)                                                #
#     .battle_count_is_less_then?(amount)                                      #
#     .battle_count_is_more_then?(amount)                                      #
#                                                                              #
#                                                                              #
#      For checking save count.                                                #
#      ~~~~~~~~~~~~~~~~~~~~~~~~                                                #
#     .save_count_is?(amount)                                                  #
#     .save_count_is_less_then?(amount)                                        #
#     .save_count_is_more_then?(amount)                                        #
#                                                                              #
#                                                                              #
#      For setting variables to PC time.                                       #
#      ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                       #
#    ----------------------------------------------------------------------    #
#    Note: Set these just before your check, if needed, but remember that      #
#    each check is a new time stamp. Meanning if you are working in minutes    #
#    there is a greater chance it will change while you are checking.          #
#    ----------------------------------------------------------------------    #
#     .pc_year                                         Actual Year             #
#     .pc_month                                        Actual Month            #
#     .pc_day                                          Actual Day              #
#     .pc_wday                                         Actual Day              #
#     .pc_hour                                         Actual Hour             #
#     .pc_min                                          Actual Minute           #
#                                                                              #
#                                                                              #
#      For checking PC time.                                                   #
#      ~~~~~~~~~~~~~~~~~~~~~                                                   #
#     .pc_year_is?(year)                               Year                    #
#     .pc_month_is?(month)                             Numeric Month           #
#     .pc_day_is?(day_of_the_month)                    Numeric Day             #
#     .pc_wday_is?(day_of_the_week)                    Numeric Day(Sunday => 0)#
#     .pc_hour_is?(hour)                               Hour                    #
#     .pc_hour_is_less_then?(hour)                                             #
#     .pc_hour_is_more_then?(hour)                                             #
#     .pc_min_is?(min)                                 Minute                  #
#     .pc_min_is_less_then?(min)                                               #
#     .pc_min_is_more_then?(min)                                               #
#                                                                              #
#                                                                              #
#  ==========================================================================  #
#    The following can be used with                                            #
#  $game_actors[i] || $game_party.members[i] || $game_party.battle_members[i]  #
#  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  #
#   **  They are ment to be used in common events activated by spells/skills   #
#  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  #
#  ==========================================================================  #
#                                                                              #
#      For checking the id of the selected enemy.                              #
#      ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                              #
#     .selected_enemy_id_is?(enemy_id)                                         #
#                                                                              #
#      Returns the id of the seleceted enemy.                                  #
#      ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                  #
#     .selected_enemy_id                                                       #
#                                                                              #
#------------------------------------------------------------------------------#
# ** Description                                                               #
#------------------------------------------------------------------------------#
#                                                                              #
#  v0.1                                                                        #
# ~=~=~=~                                                                      #
#                                                                              #
# Right now this script adds extra checks to be use in conditional barnches,   #
# add a variable to keep track of gold spent in shops.                         #
#                                                                              #
#  v0.2                                                                        #
# ~=~=~=~                                                                      #
#                                                                              #
# Added more checks.                                                           #
#                                                                              #
#  v0.3                                                                        #
# ~=~=~=~                                                                      #
#                                                                              #
# Fixed a few bugs.                                                            #
#                                                                              #
#  v0.4                                                                        #
# ~=~=~=~                                                                      #
#                                                                              #
# I added more checks for battle count, hp, hp%, and the same for mp and tp.   #
#                                                                              #
#  v0.5                                                                        #
# ~=~=~=~                                                                      #
#                                                                              #
# I added more checks for save count, params, xparams, sparams, total gold     #
# found durring the game.                                                      #
#                                                                              #
#  v1.0                                                                        #
# ~=~=~=~                                                                      #
#                                                                              #
# I just added several checks for pc year, month, days, hours, and minutes.    #
#                                                                              #
#  v1.1                                                                        #
# ~=~=~=~                                                                      #
#                                                                              #
# I fixed the average battle members level and pc_time checks. I also added    #
# checks for the entire party.                                                 #
#                                                                              #
#  v1.2                                                                        #
# ~=~=~=~                                                                      #
#                                                                              #
# I added checks for spells/skills to check the selected enemy id they are     #
# being used on.                                                               #
#                                                                              #
#------------------------------------------------------------------------------#
#==============================================================================#


#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
#                                                                              #
#        DO NOT EDIT PASSED THIS POINT UNLESS YOU KNOW WHAT YOUR DOING.        #
#                                                                              #
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#






























module BattleManager
  class<<self; alias pv465654321 process_victory; end
  def self.process_victory
    pv465654321()
    $game_party.bv += 1
  end
  class<<self; alias pd65163132154 process_defeat; end
  def self.process_defeat
    pd65163132154()
    $game_party.bl += 1
  end
  class<<self; alias pe654113201321 process_escape; end
  def self.process_escape
    pe654113201321()
    $game_party.excp += 1
  end
end  
class Game_System
  def save_count_is?(amount)
    @save_count == amount
  end
  def save_count_is_less_then?(amount)
    @save_count <= amount
  end
  def save_count_is_more_then?(amount)
    @save_count >= amount
  end
  def battle_count_is?(amount)
    @battle_count == amount
  end
  def battle_count_is_less_then?(amount)
    @battle_count <= amount
  end
  def battle_count_is_more_then?(amount)
    @battle_count >= amount
  end
  def pc_year
    t = Time.now
    t.year
  end
  def pc_month
    t = Time.now
    t.mon
  end
  def pc_day
    t = Time.now
    t.day
  end
  def pc_wday
    t = Time.now
    t.wday
  end
  def pc_hour
    t = Time.now
    t.hour
  end
  def pc_min
    t = Time.now
    t.min
  end
  def pc_year_is?(year)
    t = Time.now
    t.year == year
  end
  def pc_mon_is?(month)
    t = Time.now
    t.mon == month
  end
  def pc_day_is?(day_of_the_month)
    t = Time.now
    t.day == day_of_the_month
  end
  def pc_wday_is?(day_of_the_week)
    t = Time.now
    t.wday == day_of_the_week
  end
  def pc_hour_is?(hour)
    t = Time.now
    t.hour == hour
  end
  def pc_hour_is_less_then?(hour)
    t = Time.now
    t.hour <= hour
  end
  def pc_hour_is_more_then?(hour)
    t = Time.now
    t.hour >= hour
  end
  def pc_min_is?(min)
    t = Time.now
    t.min == min
  end
  def pc_min_is_less_then?(min)
    t = Time.now
    t.min <= min
  end
  def pc_min_is_more_then?(min)
    t = Time.now
    t.min >= min
  end
  def game_time_is?(amount_in_seconds)
    Graphics.frame_count / Graphics.frame_rate  == amount_in_seconds
  end
  def game_time_less_then?(amount_in_seconds)
    Graphics.frame_count / Graphics.frame_rate  <= amount_in_seconds
  end
  def game_time_more_then?(amount_in_seconds)
    Graphics.frame_count / Graphics.frame_rate  >= amount_in_seconds
  end
end
class Game_BattlerBase
  def hp_is?(amount)
    @hp == amount
  end
  def hp_is_less_then?(amount)
    @hp <= amount
  end
  def hp_is_more_then?(amount)
    @hp >= amount
  end
  def mp_is?(amount)
    @mp == amount
  end
  def mp_is_less_then?(amount)
    @mp <= amount
  end
  def mp_is_more_then?(amount)
    @mp >= amount
  end
  def tp_is?(amount)
    @tp == amount
  end
  def tp_is_less_then?(amount)
    @tp <= amount
  end
  def tp_is_more_then?(amount)
    @tp >= amount
  end
  def hp_percentage_is?(amount)
    @hp / mhp == amount
  end
  def hp_percentage_is_less_then?(amount)
    @hp / mhp <= amount
  end
  def hp_percentage_is_more_then?(amount)
    @hp / mhp >= amount
  end
  def mp_percentage_is?(amount)
    @mp / mmp == amount
  end
  def mp_percentage_is_less_then?(amount)
    @mp / mmp <= amount
  end
  def mp_percentage_is_more_then?(amount)
    @mp / mmp >= amount
  end
  def tp_percentage_is?(amount)
    @tp / 100 == amount
  end
  def tp_percentage_is_less_then?(amount)
    @tp / 100 <= amount
  end
  def tp_percentage_is_more_then?(amount)
    @tp / 100 >= amount
  end
end
class Game_Actor < Game_Battler
  attr_accessor :selected_enemy_id                   
  alias :su04214014027524524 :setup
  def setup(actor_id)
    su04214014027524524(actor_id)
    @selected_enemy_id = 0
  end
  def selected_enemy_id_is?(enemy_id)
    enemy_id == @selected_enemy_id
  end
  def selected_enemy_id
    return @selected_enemy_id
  end
  def selected_enemy(enemy_id)
    @selected_enemy_id = enemy_id
  end
  def param_is?(param_id, amount)
    param(param_id) == amount
  end
  def param_is_less_then?(param_id, amount)
    param(param_id) <= amount
  end
  def param_is_more_then?(param_id, amount)
    param(param_id) >= amount
  end
  def sparam_is?(sparam_id, amount)
    sparam(sparam_id) == amount
  end
  def sparam_is_less_then?(sparam_id, amount)
    sparam(sparam_id) <= amount
  end
  def sparam_is_more_then?(sparam_id, amount)
    sparam(sparam_id) >= amount
  end
  def xparam_is?(xparam_id, amount)
    xparam(xparam_id) == amount
  end
  def xparam_is_less_then?(xparam_id, amount)
    xparam(xparam_id) <= amount
  end
  def xparam_is_more_then?(xparam_id, amount)
    xparam(xparam_id) >= amount
  end
  def has_weapon_equiped?
    !weapons.compact.empty?
  end
  def has_armor_equiped?
    !armors.compact.empty?
  end
  def has_armor_type?(type_id)
    armors.compact.any? {|i| i.atype_id == type_id }
  end
  def has_weapon_type?(type_id)
    weapons.compact.any? {|i| i.wtype_id == type_id }
  end
end
class Game_Party < Game_Unit
  attr_accessor   :tgf
  attr_accessor   :gs
  attr_accessor   :bv
  attr_accessor   :bl
  attr_accessor   :excp
  alias :i72522752 :initialize
  def initialize
    i72522752()
    @tgf = 0
    @gs = 0
    @bv = 0
    @bl = 0
    @excp = 0
  end
  alias :gg7050504 :gain_gold
  def gain_gold(amount)
    gg7050504(amount)
    @tgf = (@tgf + amount)
  end
  def total_gold_is_more_then?(amount)
    @tgf >= amount
    p @tgf
  end
  def escape_count_is?(amount)
    @esc == amount
  end
  def escape_count_less_then?(amount)
    @esc <= amount
  end
  def escape_count_more_then?(amount)
    @esc >= amount
  end
  def battle_wins_are?(amount)
    @bv == amount
  end
  def battle_wins_less_then?(amount)
    @bv <= amount
  end
  def battle_wins_more_then?(amount)
    @bv >= amount
  end
  def battle_losses_are?(amount)
    @bl == amount
  end
  def battle_losses_less_then?(amount)
    @bl <= amount
  end
  def battle_losses_more_then?(amount)
    @bl >= amount
  end
  def leader_is?(actor_id)
    battle_members[0].id == $game_actors[id].id
  end
  def steps_are?(amount)
    @steps  == amount
  end
  def steps_are_less_then?(amount)
    @steps  <= amount
  end
  def steps_are_more_then?(amount)
    @steps  >= amount
  end
  def less_then_amount_items?(item_id, amount)
    @items[items[item_id].id] <= amount unless @items[item_id] == nil
  end
  def more_then_amount_items?(item_id, amount)
    @items[items[item_id].id] >= amount unless @items[item_id] == nil
  end
  def fixed_amount_items?(item_id, amount)
    @items[items[item_id].id] == amount unless @items[item_id] == nil
  end
  def amount_spent_is?(amount)
    @gs == amount
  end
  def amount_spent_less_then?(amount)
    @gs <= amount
  end
  def amount_spent_more_then?(amount)
    @gs >= amount
  end
  def has_class?(class_id)
    members.compact.any? { |i| i.class_id == class_id }
  end
  def total_plevel_is?(total)
    c = 0
    members.each { |i| c += i.level }
    c == total
  end
  def total_plevel_less_then?(total)
    c = 0
    members.each { |i| c += i.level }
    c <= total
  end
  def total_plevel_more_then?(total)
    c = 0
    members.each { |i| c += i.level }
    c >= total
  end
  def average_plevel_is?(amount)
    c = []
    members.each { |i| c.push i.level }
    (c.inject{ |sum, el| sum + el }.to_f / c.size)  == amount
  end
  def average_plevel_less_then?(amount)
    c = []
    members.each { |i| c.push i.level }
    (c.inject{ |sum, el| sum + el }.to_f / c.size) <= amount
  end
  def average_plevel_more_then?(amount)
    c = []
    members.each { |i| c.push i.level }
    (c.inject{ |sum, el| sum + el }.to_f / c.size)  >= amount
  end
  def total_level_is?(total)
    c = 0
    battle_members.each { |i| c += i.level }
    c == total
  end
  def total_level_less_then?(total)
    c = 0
    battle_members.each { |i| c += i.level }
    c <= total
  end
  def total_level_more_then?(total)
    c = 0
    battle_members.each { |i| c += i.level }
    c >= total
  end
  def average_level_is?(amount)
    c = []
    battle_members.each { |i| c.push i.level }
    (c.inject{ |sum, el| sum + el }.to_f / c.size)  == amount
  end
  def average_level_less_then?(amount)
    c = []
    battle_members.each { |i| c.push i.level }
    (c.inject{ |sum, el| sum + el }.to_f / c.size) <= amount
  end
  def average_level_more_then?(amount)
    c = []
    battle_members.each { |i| c.push i.level }
    (c.inject{ |sum, el| sum + el }.to_f / c.size)  >= amount
  end
end
class Scene_Shop < Scene_MenuBase
  alias :db70520504 :do_buy
  def do_buy(number)
    db70520504(number)
    $game_party.gs += (number * buying_price)
  end
end
class Scene_Battle < Scene_Base
  alias :oeo505204504 :on_enemy_ok
  def on_enemy_ok
    BattleManager.actor.selected_enemy(@enemy_window.enemy.enemy_id)
    oeo505204504()
  end
  alias :oec050404040 :on_enemy_cancel
  def on_enemy_cancel
    BattleManager.actor.selected_enemy(0)
    oec050404040()
  end
end