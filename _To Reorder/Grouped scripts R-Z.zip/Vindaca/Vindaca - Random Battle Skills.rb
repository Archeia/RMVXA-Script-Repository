#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
#                                                                              #
#                           V's Random Battle Skills                           #
#                                 Version  0.2                                 #
#                                                                              #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#                                Written By:  V                                #
#                        Last Edited: September 7, 2013                        #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#                                                                              #
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
 
  
#==============================================================================#
#------------------------------------------------------------------------------#
# ** Disclaimer                                                                #
#------------------------------------------------------------------------------#
#                                                                              #
# This script was intended for Non-commercial use only, if you wish to use     #
# this script in a commercial game please PM me at which ever site you found   #
# this script. Either way please give me credit in your game script as the     #
# writer of this script, and send me a PM abuot the release of the game/demo.  #
#                                                                              #
#------------------------------------------------------------------------------#
# ** How To Use                                                                #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#                                                                              #
# * This script is pretty much plug-and-play. Just set the                     #
# Number_Of_Random_Skills for each palyer, in the module and once the player   #
# has learned that many skills they will start to become randomized.           #
#                                                                              #
#------------------------------------------------------------------------------#
# ** Description                                                               #
#------------------------------------------------------------------------------#
#                                                                              #
#  v0.1                                                                        #
# ~=~=~=~                                                                      #
#  * This script allows you randomize the battle skills so that each battle    #
#  every actor will recieve a new set of skills.                               #
#                                                                              #
#  v0.2                                                                        #
# ~=~=~=~                                                                      #
#  * It is now set up to give every battle member a set number of random skills#
# at the start of every new battle.                                            #
#                                                                              #
#------------------------------------------------------------------------------#
#==============================================================================#
module V_Random_Battle_Skills
  module Specs
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
#                                                                              #
#                           Start Customizable Area.                           #
#                                                                              #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#                                                                              #
#                      ONLY EDIT AFTER THE EQUALS SYMBOL.                      #
#                                                                              #
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
   
    
  #============================================================================
  #  Menu Command Options
  #============================================================================
    
    Number_Of_Random_Skills = 7
    
    
    
    
    
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
#                                                                              #
#         DO NOT EDIT PAST THIS POINT UNLESS YOU KNOW WHAT YOUR DOING.         #
#                                                                              #
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
   
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 


















end
end
module BattleManager
  class<<self; alias bs546543213 battle_start; end
  def self.battle_start
    bs546543213()
    $game_party.battle_members.each do |i|
      i.tp = 100
    end
    $game_system.ib = true
  end
  class<<self; alias be321321654654321 battle_end; end
  def self.battle_end(result)
    be321321654654321(result)
    $game_system.rbs.clear
    $game_system.ib = false
    $game_party.members.each { |i| i.srs = true }
  end
end
class Game_Actor < Game_Battler
  include V_Random_Battle_Skills::Specs
  attr_accessor :trs
  attr_accessor :srs
  alias :old_init27201045070504 :initialize
  def initialize(actor_id)
    super()
    @trs = Number_Of_Random_Skills
    @srs = true
    old_init27201045070504(actor_id) 
  end
end
class Window_SkillList < Window_Selectable
  alias :mil050575041041041 :make_item_list
  def make_item_list
    if $game_system.ib == true
      if @actor.srs == false
        @data = $game_system.rbs[@actor]
      else
        temp = @actor.skills unless @actor.skills.size > @actor.trs
        temp = @actor.skills.shuffle[0, @actor.trs] if @actor.skills.size > @actor.trs
        $game_system.rbs[@actor] = temp
        @data = $game_system.rbs[@actor]
        @actor.srs = false
      end
    else
      mil050575041041041()
    end
  end
end
class Window_ActorCommand < Window_Command
  def make_command_list
    return unless @actor
    add_skill_commands
    add_item_command
  end
  def add_skill_commands
    if $game_system.ib == false
      @actor.added_skill_types.sort.each do |stype_id|
        name = $data_system.skill_types[stype_id]
        add_command(name, :skill, true, stype_id)
      end
    else
      add_command("Action", :skill, true)
    end
  end
end
  class Game_System
  attr_accessor :ib
  attr_accessor :rbs
  alias :old_init3213546461321 :initialize
  def initialize
    @ib = false
    @rbs = {}
    old_init3213546461321()
  end
end