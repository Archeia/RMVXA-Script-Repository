#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
#                                                                              #
#                           V's  Prefixes & Suffixes                           #
#                                 Version  0.3                                 #
#                                                                              #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#                                Written By:  V                                #
#                         Last Edited: January 30, 2014                        #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#                                                                              #
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
#==============================================================================#
#------------------------------------------------------------------------------#
# ** Disclaimer                                                                #
#------------------------------------------------------------------------------#
#                                                                              #
# This script was intended for Non-Commercial use only, if you wish to use     #
# this script in a commercial game please PM me at which ever site you found   #
# this script. Either way please give me credit in your game script as the     #
# writer of this script, and send me a PM abuot the release of the game/demo.  #
#                                                                              #
#------------------------------------------------------------------------------#
# ** How To Use                                                                #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#                                                                              #
#  * Check out weapons numbers 1, 64, 65, 67, 68 in the demo for examples of   #
#  how to set-up weapons, prefixes, and suffixes.                              #
#                                                                              #
#  * All prefixes, and suffixes are created the same way as weapons an must    #
#  ALL be created as a weapon.                                                 #
#                                                                              #
#  * Armor is set-up with the same tag as weapon 1.                            #
#                                                                              #
#  * Place these tags in your Weapon or Armor Noteboxes, the # should be       #
#  replaced by the weapon ids that you would like to use                       #
#                                                                              #
#       <Prefix: #, #, #>                                                      #
#       <Suffix: #, #, #>                                                      #
#                                                                              #
#  * Use these commands in a script call to create a specific weapon or armor. #
#                                                                              #
#       create_weapon(base_weapon_id, prefix_id, suffix_id)                    #
#       create_armor(base_armor_id, prefix_id, suffix_id)                      #
#                                                                              #
#  * The prefix_id and suffix_id are both false by default. A false id will    #
#  result in a random prefix and suffex set-up via weapon and armor notetags.  #
#  Here are a few more example script calls.                                   #
#                                                                              #
#       create_weapon(base_weapon_id, false, suffix_id)                        #
#       create_weapon(base_weapon_id, prefix_id, false)                        #
#       create_weapon(base_weapon_id, false, false)                            #
#       create_weapon(base_weapon_id)                                          #
#                                                                              #
#       create_armor(base_armor_id, false, suffix_id)                          #
#       create_armor(base_armor_id, prefix_id, false)                          #
#       create_armor(base_armor_id, false, false)                              #
#       create_armor(base_armor_id)                                            #
#                                                                              #
#  * You can also use 0 as an id to ensure no perfix or suffix is used. Here   #
#  are a few example of how to use 0.                                          #
#                                                                              #
#       create_weapon(base_weapon_id, 0, false)                                #
#       create_weapon(base_weapon_id, false, 0)                                #
#       create_weapon(base_weapon_id, prefix_id, 0)                            #
#       create_weapon(base_weapon_id, 0, suffix_id)                            #
#       create_weapon(base_weapon_id, 0, 0) This will result in a base weapon. #
#                                                                              #
#       create_armor(base_armor_id, false, 0)                                  #
#       create_armor(base_armor_id, 0, false)                                  #
#       create_armor(base_armor_id, prefix_id, 0)                              #
#       create_armor(base_armor_id, 0, suffix_id)                              #
#       create_armor(base_armor_id, 0, 0)                                      #
#                                                                              #
#                                                                              #
#                       See the demo for more examples                         #
#                                                                              #
#------------------------------------------------------------------------------#
# ** Description                                                               #
#------------------------------------------------------------------------------#
#                                                                              #
#  v0.1                                                                        #
# ~=~=~=~                                                                      #
#                                                                              #
# In v0.1, this script allows you to create instance item with prefixes and    #
# suffixes, completly random, or very specific.                                #
#                                                                              #  
#  v0.2                                                                        #
# ~=~=~=~                                                                      #
#                                                                              #
# A few bug fixes were added and now all prices will be merged as well as the  #
# parameters and features.                                                     #
#                                                                              #  
#  v0.3                                                                        #
# ~=~=~=~                                                                      #
#                                                                              #
# A bug was found and fixed by Selchar. All armors and weapon are now saved.   #
#                                                                              #  
#------------------------------------------------------------------------------#
#==============================================================================#

#==============================================================================
# ** DataManager
#------------------------------------------------------------------------------
#  This module manages the database and game objects. Almost all of the 
# global variables used by the game are initialized by this module.
#==============================================================================

module DataManager

  #--------------------------------------------------------------------------
  # * Aliasing Method: Extract Save Contents & Create Game Objects
  #--------------------------------------------------------------------------
  class << self
    alias :vindaca_affixes_esc :extract_save_contents
    alias :vindaca_affixes_cgo :create_game_objects
  end
  
  #--------------------------------------------------------------------------
  # * Extract Save Contents
  #--------------------------------------------------------------------------
  def self.extract_save_contents(contents)
    vindaca_affixes_esc(contents)
    $data_armors.concat($game_system.affixed_armors)
    $data_weapons.concat($game_system.affixed_weapons)
  end
  
  #--------------------------------------------------------------------------
  # * Create Game Objects
  #--------------------------------------------------------------------------
  def self.create_game_objects
    vindaca_affixes_cgo
    load_database
  end
end


#==============================================================================
# ** Game_System
#------------------------------------------------------------------------------
#  This class handles system data. It saves the disable state of saving and 
# menus. Instances of this class are referenced by $game_system.
#==============================================================================

class Game_System

  #--------------------------------------------------------------------------
  # * Public Instance Variables
  #--------------------------------------------------------------------------
  attr_accessor :affixed_armors, :affixed_weapons

  #--------------------------------------------------------------------------
  # * Aliasing Method: Make Command List
  #--------------------------------------------------------------------------
  alias :vindaca_affixes_gs_init :initialize

  #--------------------------------------------------------------------------
  # * Initializing Processing
  #--------------------------------------------------------------------------
  def initialize
    vindaca_affixes_gs_init
    @affixed_armors = @affixed_weapons = []
  end
  
end


#==============================================================================
# ** Game_Interpreter
#------------------------------------------------------------------------------
#  An interpreter for executing event commands. This class is used within the
# Game_Map, Game_Troop, and Game_Event classes.
#==============================================================================

class Game_Interpreter

  #-----------------------------------------------------------------------------
  # * Create Prefix
  #-----------------------------------------------------------------------------
  def create_prefix(base)
    p_note = /<Prefix\S*\s*(\d+(?:\S*\s*\d+)*)+>/im
    pre = base.note.match(p_note) {  $1.scan(/\d+/).collect { |i| i.to_i } }
    unless pre == nil
      prefix = pre[rand(pre.size)]
      return prefix
    else 
      return 0
    end
  end
  
  #-----------------------------------------------------------------------------
  # * Create Suffix
  #-----------------------------------------------------------------------------
  def create_suffix(base)
    s_note = /<Suffix\S*\s*(\d+(?:\S*\s*\d+)*)+>/im
    suf = base.note.match(s_note) {  $1.scan(/\d+/).collect { |i| i.to_i } }
    unless suf == nil
      suffix = suf[rand(suf.size)]
      return suffix
    else
      return 0
    end
  end
  
  #-----------------------------------------------------------------------------
  # * Create Name
  #-----------------------------------------------------------------------------
  def create_name(base, prefix, suffix)
    name = base.name
    pre = $data_weapons[prefix].dup unless prefix == 0
    suf = $data_weapons[suffix].dup unless suffix == 0
    unless prefix == 0
      name = pre.name + " " + name
    end
    unless suffix == 0 
      name = name + " " + suf.name
    end
    return name
  end
  
  #-----------------------------------------------------------------------------
  # * Create Params
  #-----------------------------------------------------------------------------
  def create_params(base, prefix, suffix)
    params = base.params
    8.times {  |i| params[i] += $data_weapons[prefix].params[i] } unless prefix == 0
    8.times {  |i| params[i] += $data_weapons[suffix].params[i] } unless suffix == 0
    return params
  end
  
  #-----------------------------------------------------------------------------
  # * Create Price
  #-----------------------------------------------------------------------------
  def create_price(base, prefix, suffix)
    price = base.price
    price += $data_weapons[prefix].price unless prefix == 0
    price += $data_weapons[suffix].price unless suffix == 0
    return price
  end
  
  #-----------------------------------------------------------------------------
  # * Create Features
  #-----------------------------------------------------------------------------
  def create_feats(base, prefix, suffix)
    feats = base.features
    pre = $data_weapons[prefix] unless prefix == 0
    suf = $data_weapons[suffix] unless suffix == 0
    pre.features.each { |pf| feats.push pf } unless prefix == 0
    suf.features.each { |sf| feats.push sf } unless suffix == 0
    return feats
  end
  
  #-----------------------------------------------------------------------------
  # * Create Weapon
  #-----------------------------------------------------------------------------
  def create_weapon(id, prefix = false, suffix = false)
    base = Marshal.load(Marshal.dump($data_weapons[id]))
    prefix = create_prefix(base) if prefix == false
    suffix = create_suffix(base) if suffix == false
    base.id = $data_weapons.size
    base.name = create_name(base, prefix, suffix)
    base.params = create_params(base, prefix, suffix)
    base.features = create_feats(base, prefix, suffix)
    base.price = create_price(base, prefix, suffix)
    $data_weapons.push base
    $game_system.affixed_weapons.push base
    $game_party.gain_item($data_weapons[$data_weapons.size - 1], 1, true)
  end
  
  #-----------------------------------------------------------------------------
  # * Create Weapon
  #-----------------------------------------------------------------------------
  def create_armor(id, prefix = false, suffix = false)
    base = Marshal.load(Marshal.dump($data_armors[id]))
    prefix = create_prefix(base) if prefix == false
    suffix = create_suffix(base) if suffix == false
    base.id = $data_armors.size
    base.name = create_name(base, prefix, suffix)
    base.params = create_params(base, prefix, suffix)
    base.features = create_feats(base, prefix, suffix)
    $data_armors.push base
    $game_system.affixed_armors.push base
    $game_party.gain_item($data_armors[$data_armors.size - 1], 1, true)
  end
  
end