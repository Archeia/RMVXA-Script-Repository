#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
#                                                                              #
#                              V's  Passive Items                              #
#                                 Version  0.3                                 #
#                                                                              #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#                                Written By:  V                                #
#                          Last Edited: August 24, 2013                        #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#                                                                              #
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
 
  
#==============================================================================#
#------------------------------------------------------------------------------#
# ** Disclaimer                                                                #
#------------------------------------------------------------------------------#
#                                                                              #
# This script was intended for Non-commercial use only, if you wish to use     #
# this script in a commercial game please PM me at which ever site you found   #
# this script. Either way please give me credit in your game script as the     #
# writer of this script, and send me a PM abuot the release of the game/demo.  #
#                                                                              #
#------------------------------------------------------------------------------#
# ** How To Use                                                                #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#                                                                              #
# * This script is pretty much plug-and-play.                                  #
#                                                                              #
# * Notetag all item you want to be passive with this tag:                     #
#                        <ItemParams: Hp, Mp, Atk, Def, Mat, Mdf, Agi, Luk>    #
#                                       (Replace the words with numbers)       #
#                                                                              #
#------------------------------------------------------------------------------#
# ** Description                                                               #
#------------------------------------------------------------------------------#
#                                                                              #
#  v0.1                                                                        #
# ~=~=~=~                                                                      #
#                                                                              #
# If you have ever played D2 or D2: LOD or any mods for those games then       #
# you'll know exsactly what I'm talking about. For everyone else this script   #
# basically gives passive stat bonuses to items as long as they're in your     #
# inventory. Nuff Said.                                                        #
#                                                                              #
#  v0.2                                                                        #
# ~=~=~=~                                                                      #
#                                                                              #
# I added a few spots for Add-Ons                                              #
#                                                                              #
#  v0.3                                                                        #
# ~=~=~=~                                                                      #
#                                                                              #
# Fixed a bug where the params were not staying with battle_member[0]          #
#                                                                              #
#------------------------------------------------------------------------------#
#==============================================================================#
   


#******************************************************************************#
#------------------------------------------------------------------------------#
#                              Available Add-Ons:                              #
#------------------------------------------------------------------------------#
#******************************************************************************#
#------------------------------------------------------------------------------#
#                                                                              #
#  ** X and S Parameter Bonuses                                                #
#                                                                              #
#------------------------------------------------------------------------------#
#******************************************************************************#


#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
#                                                                              #
#         DO NOT EDIT PAST THIS POINT UNLESS YOU KNOW WHAT YOUR DOING.         #
#                                                                              #
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
   
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 


















 
$imported = {} if $imported.nil?
$imported["V's  Passive Items "] = true
class Game_Actor < Game_Battler
  attr_accessor :item_param
  alias :old_init78373524214222 :initialize
  def initialize(actor_id)
    super()
    @item_param = [0, 0, 0, 0, 0, 0, 0, 0]
    old_init78373524214222(actor_id) 
  end
  alias :old_param_base5637386796435 :param_base
  def param_base(param_id)
    old_param_base5637386796435(param_id) + @item_param[param_id]
  end  
end
class Game_Party < Game_Unit
  alias :gain_item589831004 :gain_item
  def gain_item(item, amount, include_equip = false)
    gain_item589831004(item, amount, include_equip = false)
    note = /<ItemParams\S*\s*(\d*)\S*\s*(\d*)\S*\s*(\d*)\S*\s*(\d*)\S*\s*(\d*)\S*\s*(\d*)\S*\s*(\d*)\S*\s*(\d*)>/i
    ip = item.note[note] if item != nil
    gain_item_params(item, amount) if ip != nil
  end
  def gain_item_params(item, amount)
    note = /<ItemParams:\s*(\d*),\s*(\d*),\s*(\d*),\s*(\d*),\s*(\d*),\s*(\d*),\s*(\d*),\s*(\d*)>/i
    ip = item.note.scan(note) if item != nil
    8.times {|i| $game_party.members[0].item_param[i] += (ip[0][i].to_i * amount) }
    $game_party.members[0].hp += (ip[0][0].to_i * amount) if ip != nil
    $game_party.members[0].mp += (ip[0][1].to_i * amount) if ip != nil
  end
  alias :lose_item5637386796435 :lose_item
  def lose_item(item, amount, include_equip = false)
    lose_item5637386796435(item, amount, include_equip = false)
    note = /<ItemParams\S*\s*(\d*)\S*\s*(\d*)\S*\s*(\d*)\S*\s*(\d*)\S*\s*(\d*)\S*\s*(\d*)\S*\s*(\d*)\S*\s*(\d*)>/i
    ip = item.note[note] if item != nil
    lose_item_params(item, amount) if ip != nil && ip[0][0] != nil
  end
  def lose_item_params(item, amount)
    note = /<ItemParams\S*\s*(\d*)\S*\s*(\d*)\S*\s*(\d*)\S*\s*(\d*)\S*\s*(\d*)\S*\s*(\d*)\S*\s*(\d*)\S*\s*(\d*)>/i
    ip = item.note[note] if item != nil
    8.times {|i| $game_party.members[0].item_param[i] -= (ip[0][i].to_i * amount) }
  end

  alias :swap_order5637386796435 :swap_order
  def swap_order(index1, index2)
    tip = $game_party.battle_members[0].item_param
    $game_party.battle_members[0].item_param = [0, 0, 0, 0, 0, 0, 0, 0]
    if $game_party.battle_members[0].hp > $game_party.battle_members[0].mhp
      $game_party.battle_members[0].hp = $game_party.battle_members[0].mhp
    end
    if $game_party.battle_members[0].mp > $game_party.battle_members[0].mmp
      $game_party.battle_members[0].mp = $game_party.battle_members[0].mmp
    end
    swap_order5637386796435(index1, index2)
    $game_party.battle_members[0].item_param = tip
    $game_party.battle_members[0].hp += $game_party.battle_members[0].item_param[0]
    if $game_party.battle_members[0].hp > $game_party.battle_members[0].mhp
      $game_party.battle_members[0].hp = $game_party.battle_members[0].mhp
    end
    $game_party.battle_members[0].mp += $game_party.battle_members[0].item_param[1]
    if $game_party.battle_members[0].mp > $game_party.battle_members[0].mmp
      $game_party.battle_members[0].mp = $game_party.battle_members[0].mmp
    end
    $game_player.refresh
  end
end