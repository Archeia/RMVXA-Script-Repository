 
 
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
#                                                                              #
#                              V's Level Up Stats                              #
#                                 Version  1.5                                 #
#                                                                              #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#                                Written By:  V                                #
#                      Last Edited:  December 29, 2013                         #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#                                                                              #
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
 
  
#==============================================================================#
#------------------------------------------------------------------------------#
# ** Disclaimer                                                                #
#------------------------------------------------------------------------------#
#                                                                              #
# This script was commissioned by JJR for his doings, I release all copyrights #
# to him regarding this script. My only terms are that I am listed as writer   #
# of this script if a game is ever produced using this script.(Demo's Included)#
# I also ask that I am notified upon release of said game/demo.                #
#                                                                              #
#------------------------------------------------------------------------------#
# ** How To Use                                                                #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#                                                                              #
# * This script is semi-plug-and-play.                                         #
#                                                                              #
# * All images must be imported to the Graphics/Pictures resource folder       #
#                                                                              #
# * If you wish to use your own images the names must be filled in below,      #
#   the dimensions can vary within reason.                                     #
#                                                                              #
# * The dimensions for the graphics I used and their var names are as follows: #
#                                                                              #
#     Level_Up_Background = 544 x 544                                          #
#     Level_Up_Title = 454 x 76                                                #
#     All Buttons = 16 x 16                                                    #
#                                                                              #
# * ALL CLASSES MUST HAVE THIS TAG OR YOU WILL GET AN ERROR!                   #
#                                                                              #
#   Replace the stats with the amounts you want that classes bonuses.          #
#   If you do not want that classes to use a bonuses for a stat replace        #
#   it with a 1.                                                               #
#                                                                              #
#   <Bonuses: HP, MP, Str, Def, Mat, Mdf, Agi, Luk>                            #
#                                                                              #
#------------------------------------------------------------------------------#
# ** Description                                                               #
#------------------------------------------------------------------------------#
#                                                                              #
#  v0.1                                                                        #
# ~=~=~=~                                                                      #
#                                                                              #
# This script creates a stat distribution window when a player levels. The     #
# player will then be able to add a designated amount of points to the original#
# class base stats created in the database.                                    # 
#                                                                              #
#  v0.2                                                                        #
# ~=~=~=~                                                                      #
#                                                                              #
# I fix an issue where the level up screen displays just the class during the  #
# start of game and the name and class upon leveling.                          # 
#                                                                              #
#  v1.0                                                                        #
# ~=~=~=~                                                                      #
#                                                                              #
# I added a feature to add bonuses too the params dependent on classes.        # 
#                                                                              #
#  v1.1                                                                        #
# ~=~=~=~                                                                      #
#                                                                              #
# I made a few changes to make this script available and useable to the public.#
#                                                                              #
#  v1.2                                                                        #
# ~=~=~=~                                                                      #
#                                                                              #
# Fixed a bug that was not returning the right amount of points upon leveling. #
#                                                                              #
#  v1.3                                                                        #
# ~=~=~=~                                                                      #
#                                                                              #
# I added an option to stop the level up screen from popping up automatically. #
#                                                                              #
#  v1.4                                                                        #
# ~=~=~=~                                                                      #
#                                                                              #
# I removed a lot of unused methods and checks.                                # 
#                                                                              #
#  v1.5                                                                        #
# ~=~=~=~                                                                      #
#                                                                              #
# The window size should automatically change to fit the screen's resolution.  #                                # 
#                                                                              #
#------------------------------------------------------------------------------#
#==============================================================================#
 
 
 
#==============================================================================
# ** V's Level Up Stats Module
#------------------------------------------------------------------------------
#  This module manages customizable features and methods.
#==============================================================================
module V_Level_Up_Stats
  module Specs
    
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
#                                                                              #
#                           Start Customizable Area.                           #
#                                                                              #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#                                                                              #
#                      ONLY EDIT AFTER THE EQUALS SYMBOL.                      #
#                                                                              #
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
   
    
  #============================================================================
  #  Images
  #============================================================================
  
    #--------------------------------------------------------------------------
    #  Background
    #--------------------------------------------------------------------------
  
      Level_Up_Background = "StarlitSky"
    
    #--------------------------------------------------------------------------
    #  Title
    #--------------------------------------------------------------------------
  
      Level_Up_Title = "Level Up Title"
      Level_Up_Title_x = 30
      Level_Up_Title_y = 60
    
    #--------------------------------------------------------------------------
    #  Buttons
    #--------------------------------------------------------------------------
  
      Remove_Button = "Remove"
      Minus_Button = "Minus"
      Plus_Button = "Plus"
      Max_Button = "Max"

  #============================================================================
  #  Selector
  #============================================================================
  
    Icon = 338
    Icon_x = 0
    Icon_y = 0
    
  #============================================================================
  #  Additional Options
  #============================================================================
  
    #--------------------------------------------------------------------------
    #  Menu Command Window Options
    #--------------------------------------------------------------------------
  
      Use_Menu_Command = true
      Use_Menu_Command_Only = true
      Level_Up_Command_Title = "Spend Points"
    
    #--------------------------------------------------------------------------
    #  Point Set-Up
    #--------------------------------------------------------------------------
  
      Initial_Points = 0
      Points_Per_Level = 5
      Level_Up_Points_Vocab = "Level Up Points"
    
    
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
#                                                                              #
#                            End Customizable Area.                            #
#                                                                              #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#                                                                              #
#         DO NOT EDIT PAST THIS POINT UNLESS YOU KNOW WHAT YOUR DOING.         #
#                                                                              #
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
   
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 


















 
    
  end
end

#==============================================================================
# ** Scene Level Up Stats
#------------------------------------------------------------------------------
#  This class performs Path Selection scene processing.
#==============================================================================

class Window_Level_Up_Stats < Window_Base
  
  #--------------------------------------------------------------------------
  # * Includes Module's Variables With Class
  #--------------------------------------------------------------------------
  
  include V_Level_Up_Stats::Specs
  
  #--------------------------------------------------------------------------
  # * Start Processing
  #--------------------------------------------------------------------------
  
  def initialize(x, y, w, h)
    super(x, y, w, h)
    @remove_button = []
    @minus_button = []
    @plus_button = []
    @max_button = []
    refresh
  end
  
  #--------------------------------------------------------------------------
  # * Refresh
  #--------------------------------------------------------------------------
  
  def refresh
    contents.clear
    draw_current_actor_graphic
    draw_current_actor_name
    draw_current_actor_class
    draw_availabe_text
    draw_lvupp_vocab
    draw_available_lv_up_points
    draw_lv_up_stats
    draw_lv_up_stat_buttons
    draw_lv_up_accept_buttons
    create_lvup_icon
  end
  
  #--------------------------------------------------------------------------
  # * Draw Current Actor Graphic
  #--------------------------------------------------------------------------
  
  def draw_current_actor_graphic
    x = 90
    y = 220
    actor = $game_party.members[$game_system.leveling_actor]
    draw_actor_graphic(actor, x, y)
  end
  
  #--------------------------------------------------------------------------
  # * Draw Current Actor Name
  #--------------------------------------------------------------------------
  
  def draw_current_actor_name
    x = -180
    y = 30
    w = 544
    h = 416
    actor = $game_party.members[$game_system.leveling_actor]
    draw_text(x, y, w, h, actor.name, 1)
  end
  
  #--------------------------------------------------------------------------
  # * Draw Current Actor Name
  #--------------------------------------------------------------------------
  
  def draw_current_actor_class
    x = -180
    y = 30
    w = 544
    h = 416
    actor = $game_party.members[$game_system.leveling_actor]
    make_font_smaller
    draw_text(x, y + 15, w, h, actor.class.name, 1)
    make_font_bigger
  end
  
  #--------------------------------------------------------------------------
  # * Draw Available Text
  #--------------------------------------------------------------------------
  
  def draw_availabe_text
    x = -180
    y = 75
    w = 544
    h = 416
    actor = $game_party.members[$game_system.leveling_actor]
    make_font_smaller
    draw_text(x, y, w, h, "Available", 1)
    make_font_bigger
  end
  
  #--------------------------------------------------------------------------
  # * Draw Points Vocab
  #--------------------------------------------------------------------------
  
  def draw_lvupp_vocab
    x = -180
    y = 95
    w = 544
    h = 416
    actor = $game_party.members[$game_system.leveling_actor]
    make_font_smaller
    draw_text(x, y, w, h, Level_Up_Points_Vocab, 1)
    make_font_bigger
  end
  
  #--------------------------------------------------------------------------
  # * Draw Available Level Up Points
  #--------------------------------------------------------------------------
  
  def draw_available_lv_up_points
    x = -180
    y = 115
    w = 544
    h = 416
    temp_mhp = $game_party.members[$game_system.leveling_actor].temp_param[0]
    temp_mmp = $game_party.members[$game_system.leveling_actor].temp_param[1]
    temp_atk = $game_party.members[$game_system.leveling_actor].temp_param[2]
    temp_def = $game_party.members[$game_system.leveling_actor].temp_param[3]
    temp_mat = $game_party.members[$game_system.leveling_actor].temp_param[4]
    temp_mdf = $game_party.members[$game_system.leveling_actor].temp_param[5]
    temp_agi = $game_party.members[$game_system.leveling_actor].temp_param[6]
    temp_luk = $game_party.members[$game_system.leveling_actor].temp_param[7]
    
    temp_used_points = temp_mhp + temp_mmp + temp_atk + temp_def + temp_mat + temp_mdf + temp_agi + temp_luk
    actor = $game_party.members[$game_system.leveling_actor]
    points = actor.lvupp - temp_used_points
    draw_text(x, y, w, h, points, 1)
  end
  
  #--------------------------------------------------------------------------
  # * Creates the Accept Button
  #--------------------------------------------------------------------------
  
  def draw_lv_up_accept_buttons
    x = 330
    y = 350
    draw_text_ex(x, y, "Accept")
  end
  
  #--------------------------------------------------------------------------
  # * Draw Bonus Parameters
  #--------------------------------------------------------------------------
  
  def draw_actor_bonus_param(actor, x, y, param_id)
    bonuses = /<Bonuses:\s*(\d*)\S*\s*(\d*)\S*\s*(\d*)\S*\s*(\d*)\S*\s*(\d*)\S*\s*(\d*)\S*\s*(\d*)\S*\s*(\d*)\s*>/
    note = $data_classes[$game_party.members[$game_system.leveling_actor].class_id].note
    bonostats = note.scan(bonuses)
    bhp = bonostats[0][0]
    bmp = bonostats[0][1]
    batk = bonostats[0][2]
    bdef = bonostats[0][3]
    bmat = bonostats[0][4]
    bmdf = bonostats[0][5]
    bagi = bonostats[0][6]
    bluk = bonostats[0][7]
    bonus_param = [bhp, bmp, batk, bdef, bmat, bmdf, bagi, bluk]

    draw_text(x + 210, y, 36, line_height, "x", 2) if param_id == 0
    draw_text(x + 210, y, 36, line_height, "x", 2) if param_id == 1
    draw_text(x + 210, y, 36, line_height, "x", 2) if param_id == 2
    draw_text(x + 210, y, 36, line_height, "x", 2) if param_id == 3
    draw_text(x + 210, y, 36, line_height, "x", 2) if param_id == 4
    draw_text(x + 210, y, 36, line_height, "x", 2) if param_id == 5
    draw_text(x + 210, y, 36, line_height, "x", 2) if param_id == 6
    draw_text(x + 210, y, 36, line_height, "x", 2) if param_id == 7

    draw_text(x + 230, y, 36, line_height, bonus_param[0], 2) if param_id == 0
    draw_text(x + 230, y, 36, line_height, bonus_param[1], 2) if param_id == 1
    draw_text(x + 230, y, 36, line_height, bonus_param[2], 2) if param_id == 2
    draw_text(x + 230, y, 36, line_height, bonus_param[3], 2) if param_id == 3
    draw_text(x + 230, y, 36, line_height, bonus_param[4], 2) if param_id == 4
    draw_text(x + 230, y, 36, line_height, bonus_param[5], 2) if param_id == 5
    draw_text(x + 230, y, 36, line_height, bonus_param[6], 2) if param_id == 6
    draw_text(x + 230, y, 36, line_height, bonus_param[7], 2) if param_id == 7
  end
  
  #--------------------------------------------------------------------------
  # * Draw Parameters
  #--------------------------------------------------------------------------
  
  def draw_actor_param(actor, x, y, param_id)
    bonuses = /<Bonuses:\s*(\d*)\S*\s*(\d*)\S*\s*(\d*)\S*\s*(\d*)\S*\s*(\d*)\S*\s*(\d*)\S*\s*(\d*)\S*\s*(\d*)\s*>/
    note = $data_classes[$game_party.members[$game_system.leveling_actor].class_id].note
    bonostats = note.scan(bonuses)
    bhp = bonostats[0][0].to_i
    bmp = bonostats[0][1].to_i
    batk = bonostats[0][2].to_i
    bdef = bonostats[0][3].to_i
    bmat = bonostats[0][4].to_i
    bmdf = bonostats[0][5].to_i
    bagi = bonostats[0][6].to_i
    bluk = bonostats[0][7].to_i
    bonus_param = [bhp, bmp, batk, bdef, bmat, bmdf, bagi, bluk]

    change_color(system_color)
    draw_text(x, y, 120, line_height, Vocab::param(param_id))
    change_color(normal_color)
    draw_text(x + 120, y, 36, line_height, (actor.param(0) + (actor.temp_param[0] * bonus_param[0])), 2) if param_id == 0
    draw_text(x + 120, y, 36, line_height, (actor.param(1) + (actor.temp_param[1] * bonus_param[1])), 2) if param_id == 1
    draw_text(x + 120, y, 36, line_height, (actor.param(2) + (actor.temp_param[2] * bonus_param[2])), 2) if param_id == 2
    draw_text(x + 120, y, 36, line_height, (actor.param(3) + (actor.temp_param[3] * bonus_param[3])), 2) if param_id == 3
    draw_text(x + 120, y, 36, line_height, (actor.param(4) + (actor.temp_param[4] * bonus_param[4])), 2) if param_id == 4
    draw_text(x + 120, y, 36, line_height, (actor.param(5) + (actor.temp_param[5] * bonus_param[5])), 2) if param_id == 5
    draw_text(x + 120, y, 36, line_height, (actor.param(6) + (actor.temp_param[6] * bonus_param[6])), 2) if param_id == 6
    draw_text(x + 120, y, 36, line_height, (actor.param(7) + (actor.temp_param[7] * bonus_param[7])), 2) if param_id == 7
  end
  
  #--------------------------------------------------------------------------
  # * Draw Level Up Stats
  #--------------------------------------------------------------------------
  
  def draw_lv_up_stats
    line_height = 25
    x = 220
    y = 145
    actor = $game_party.members[$game_system.leveling_actor]
    8.times {|i| draw_actor_bonus_param(actor, x, y + line_height * i, i) }
    8.times {|i| draw_actor_param(actor, x, y + line_height * i, i) }
  end
  
  #--------------------------------------------------------------------------
  # * Draw Level Up Stat Buttons
  #--------------------------------------------------------------------------
  
  def draw_lv_up_stat_buttons
    i = 1
    x = 300
    y = 131
    pad = 5
    8.times {
    draw_remove_button(i, x, y + pad)
    draw_minus_button(i, x, y + pad)
    draw_plus_button(i, x, y + pad)
    draw_max_button(i, x, y + pad)
    i += 1
    }
  end
  
  #--------------------------------------------------------------------------
  # * Draws the Remove Button
  #--------------------------------------------------------------------------
  
  def draw_remove_button(i, x, y)
    line_height = 25
    @remove_button[i] = Sprite.new
    @remove_button[i].bitmap = Cache.picture(Remove_Button)
    @remove_button[i].x = x
    @remove_button[i].y = y + line_height * i
    @remove_button[i].z = 20
  end
  
  #--------------------------------------------------------------------------
  # * Draws the Minus Button
  #--------------------------------------------------------------------------
  
  def draw_minus_button(i, x, y)
    line_height = 25
    @minus_button[i] = Sprite.new
    @minus_button[i].bitmap = Cache.picture(Minus_Button)
    @minus_button[i].x = x + 25
    @minus_button[i].y = y + line_height * i
    @minus_button[i].z = 20
  end
  
  #--------------------------------------------------------------------------
  # * Draws the Plus Button
  #--------------------------------------------------------------------------
  
  def draw_plus_button(i, x, y)
    line_height = 25
    @plus_button[i] = Sprite.new
    @plus_button[i].bitmap = Cache.picture(Plus_Button)
    @plus_button[i].x = x + 100
    @plus_button[i].y = y + line_height * i
    @plus_button[i].z = 20
  end
  
  #--------------------------------------------------------------------------
  # * Draws the Max Button
  #--------------------------------------------------------------------------
  
  def draw_max_button(i, x, y)
    line_height = 25
    @max_button[i] = Sprite.new
    @max_button[i].bitmap = Cache.picture(Max_Button)
    @max_button[i].x = x + 125
    @max_button[i].y = y + line_height * i
    @max_button[i].z = 20
  end
  
  #--------------------------------------------------------------------------
  # * Creates the Selection Icon
  #--------------------------------------------------------------------------
  
  def create_lvup_icon
    
    ix = Icon_x
    iy = Icon_y
    
    if $game_system.icon_y == 8
      x = 310 + ix
      y = 362 + iy
    else
      x = 275 + ix if $game_system.icon_x == 0 && $game_system.icon_y != 8
      x = 300 + ix if $game_system.icon_x == 1 && $game_system.icon_y != 8
      x = 375 + ix if $game_system.icon_x == 2 && $game_system.icon_y != 8
      x = 400 + ix if $game_system.icon_x == 3 && $game_system.icon_y != 8
      y = 153 + iy if $game_system.icon_y == 0
      y = 178 + iy if $game_system.icon_y == 1
      y = 203 + iy if $game_system.icon_y == 2
      y = 228 + iy if $game_system.icon_y == 3
      y = 253 + iy if $game_system.icon_y == 4
      y = 278 + iy if $game_system.icon_y == 5
      y = 303 + iy if $game_system.icon_y == 6
      y = 328 + iy if $game_system.icon_y == 7
    end
    
    draw_icon(Icon, x, y)
  end
  
  #--------------------------------------------------------------------------
  # * Add the Temp Stats to Actors Added Stats
  #--------------------------------------------------------------------------
  
  def add_stats
    bonuses = /<Bonuses:\s*(\d*)\S*\s*(\d*)\S*\s*(\d*)\S*\s*(\d*)\S*\s*(\d*)\S*\s*(\d*)\S*\s*(\d*)\S*\s*(\d*)\s*>/
    note = $data_classes[$game_party.members[$game_system.leveling_actor].class_id].note
    bonostats = note.scan(bonuses)
    bhp = bonostats[0][0].to_i
    bmp = bonostats[0][1].to_i
    batk = bonostats[0][2].to_i
    bdef = bonostats[0][3].to_i
    bmat = bonostats[0][4].to_i
    bmdf = bonostats[0][5].to_i
    bagi = bonostats[0][6].to_i
    bluk = bonostats[0][7].to_i
    bonus_param = [bhp, bmp, batk, bdef, bmat, bmdf, bagi, bluk]

    temp_mhp = $game_party.members[$game_system.leveling_actor].temp_param[0]
    temp_mmp = $game_party.members[$game_system.leveling_actor].temp_param[1]
    temp_atk = $game_party.members[$game_system.leveling_actor].temp_param[2]
    temp_def = $game_party.members[$game_system.leveling_actor].temp_param[3]
    temp_mat = $game_party.members[$game_system.leveling_actor].temp_param[4]
    temp_mdf = $game_party.members[$game_system.leveling_actor].temp_param[5]
    temp_agi = $game_party.members[$game_system.leveling_actor].temp_param[6]
    temp_luk = $game_party.members[$game_system.leveling_actor].temp_param[7]
    
    temp_used_points = temp_mhp + temp_mmp + temp_atk + temp_def + temp_mat + temp_mdf + temp_agi + temp_luk
    actor = $game_party.members[$game_system.leveling_actor]
    points = actor.lvupp - temp_used_points

    8.times {|i| $game_party.members[$game_system.leveling_actor].added_param[i] += (actor.temp_param[i] * bonus_param[i])} unless actor == nil
    8.times {|i| $game_party.members[0].added_param[i] += (actor.temp_param[i] * bonus_param[i])} if actor == nil

    reset_temp_stats
  end
  
  #--------------------------------------------------------------------------
  # * Resets the Temp Stats to 0
  #--------------------------------------------------------------------------
  
  def reset_temp_stats
    temp_mhp = $game_party.members[$game_system.leveling_actor].temp_param[0]
    temp_mmp = $game_party.members[$game_system.leveling_actor].temp_param[1]
    temp_atk = $game_party.members[$game_system.leveling_actor].temp_param[2]
    temp_def = $game_party.members[$game_system.leveling_actor].temp_param[3]
    temp_mat = $game_party.members[$game_system.leveling_actor].temp_param[4]
    temp_mdf = $game_party.members[$game_system.leveling_actor].temp_param[5]
    temp_agi = $game_party.members[$game_system.leveling_actor].temp_param[6]
    temp_luk = $game_party.members[$game_system.leveling_actor].temp_param[7]
    
    temp_used_points = temp_mhp + temp_mmp + temp_atk + temp_def + temp_mat + temp_mdf + temp_agi + temp_luk
    8.times {|i| $game_party.members[$game_system.leveling_actor].temp_param[i] = 0 }
  end
  
  #--------------------------------------------------------------------------
  # * Dispose Level Up Stat Buttons
  #--------------------------------------------------------------------------
  
  def dispose_lv_up_stat_buttons
    i = 1
    8.times {
    @remove_button[i].dispose
    @remove_button[i].bitmap.dispose
    @minus_button[i].dispose
    @minus_button[i].bitmap.dispose
    @plus_button[i].dispose
    @plus_button[i].bitmap.dispose
    @max_button[i].dispose
    @max_button[i].bitmap.dispose
    i += 1
    }
  end

end




#==============================================================================
# ** Scene Level Up Stats
#------------------------------------------------------------------------------
#  This class performs Path Selection scene processing.
#==============================================================================

class Scene_Level_Up_Stats < Scene_Base
  
  #--------------------------------------------------------------------------
  # * Includes Module's Variables With Class
  #--------------------------------------------------------------------------
  
  include V_Level_Up_Stats::Specs
  
  #--------------------------------------------------------------------------
  # * Start Processing
  #--------------------------------------------------------------------------
  
  def start
    super
    $game_system.icon_y = 8
    actor = $game_party.members
    
    actor.each_index do |i|
      if actor[i].lvupp > 0
        $game_system.leveling_actor = i
        break
      else 
        $game_system.leveling_actor = 0
      end
    end
      
    create_lvup_bg
    create_lvup_title
    create_stat_window
  end
  
  #--------------------------------------------------------------------------
  # * Creates the Level Up Stats Background
  #--------------------------------------------------------------------------
  
  def create_lvup_bg
    @lvup_bg = Sprite.new
    @lvup_bg.bitmap = Cache.picture(Level_Up_Background)
    @lvup_bg.x = 0
    @lvup_bg.y = 0 
    @lvup_bg.z = 1 
    @lvup_bg.zoom_x = (Graphics.width / 544)
    @lvup_bg.zoom_y = (Graphics.height / 416)
  end
  
  #--------------------------------------------------------------------------
  # * Creates the Stat Window
  #--------------------------------------------------------------------------
  
  def create_stat_window
    @lvup_window = Window_Level_Up_Stats.new(0, 0, Graphics.width, Graphics.height) 
    @lvup_window.back_opacity = 0
  end
  
  #--------------------------------------------------------------------------
  # * Creates the Level Up Title Picture
  #--------------------------------------------------------------------------
  
  def create_lvup_title
    @lvup_title = Sprite.new 
    @lvup_title.bitmap = Cache.picture(Level_Up_Title)
    @lvup_title.x = Level_Up_Title_x 
    @lvup_title.y = Level_Up_Title_y 
    @lvup_title.z = 4 
  end
  
  #--------------------------------------------------------------------------
  # * Disposes the Level Up Background
  #--------------------------------------------------------------------------
  
  def dispose_lvup_graphics
    @lvup_bg.dispose
    @lvup_bg.bitmap.dispose
    @lvup_title.dispose
    @lvup_title.bitmap.dispose
  end
  
  #--------------------------------------------------------------------------
  # * Process the Inputs for the Stat selection 
  #--------------------------------------------------------------------------
  
  def process_stat_input
    leveling_actor = $game_system.leveling_actor
    
    if Input.trigger?(:LEFT) && $game_system.icon_x > 0
      $game_system.icon_x -= 1
      Sound.play_cursor
      @lvup_window.refresh
    elsif Input.trigger?(:LEFT) && $game_system.icon_x == 0
      $game_system.icon_x = 3
      Sound.play_cursor
      @lvup_window.refresh
    elsif Input.trigger?(:RIGHT) && $game_system.icon_x < 3
      $game_system.icon_x += 1
      Sound.play_cursor
      @lvup_window.refresh
    elsif Input.trigger?(:RIGHT) && $game_system.icon_x == 3
      $game_system.icon_x = 0
      Sound.play_cursor
      @lvup_window.refresh
    elsif Input.trigger?(:UP) && $game_system.icon_y > 0
      $game_system.icon_y -= 1
      Sound.play_cursor
      @lvup_window.refresh
    elsif Input.trigger?(:UP) && $game_system.icon_y == 0
      $game_system.icon_y = 8
      Sound.play_cursor
      @lvup_window.refresh
    elsif Input.trigger?(:DOWN) && $game_system.icon_y < 8
      $game_system.icon_y += 1
      Sound.play_cursor
      @lvup_window.refresh
    elsif Input.trigger?(:DOWN) && $game_system.icon_y == 8
      $game_system.icon_y = 0
      Sound.play_cursor
      @lvup_window.refresh
    elsif Input.trigger?(:A)
      @lvup_window.reset_temp_stats
      @lvup_window.refresh
      Sound.play_cursor
    elsif Input.trigger?(:L)
      $game_system.leveling_actor = ($game_party.members.size - 1) if leveling_actor == 0 
      $game_system.leveling_actor -= 1 unless leveling_actor == 0
      @lvup_window.reset_temp_stats
      @lvup_window.refresh
      Sound.play_cursor unless $game_party.members.size == 1
      Sound.play_buzzer if $game_party.members.size == 1
    elsif Input.trigger?(:R)
      $game_system.leveling_actor = 0 if leveling_actor == ($game_party.members.size - 1)
      $game_system.leveling_actor += 1 unless leveling_actor == ($game_party.members.size - 1)
      @lvup_window.reset_temp_stats
      @lvup_window.refresh
      Sound.play_cursor unless $game_party.members.size == 1
      Sound.play_buzzer if $game_party.members.size == 1
    elsif Input.trigger?(:B)
      Sound.play_cancel
      @lvup_window.dispose
      dispose_lvup_graphics
      @lvup_window.dispose_lv_up_stat_buttons
      @lvup_window.reset_temp_stats
      $game_system.leveling = false
      SceneManager.goto(Scene_Map) unless $game_system.menu_usage
      return_scene if $game_system.menu_usage
    elsif Input.trigger?(:C)
      process_ok unless $game_system.icon_y == 8
      process_accept if $game_system.icon_y == 8
    end
    
  end

  #--------------------------------------------------------------------------
  # * OK Accept
  #--------------------------------------------------------------------------
  
  def process_accept
    temp_mhp = $game_party.members[$game_system.leveling_actor].temp_param[0]
    temp_mmp = $game_party.members[$game_system.leveling_actor].temp_param[1]
    temp_atk = $game_party.members[$game_system.leveling_actor].temp_param[2]
    temp_def = $game_party.members[$game_system.leveling_actor].temp_param[3]
    temp_mat = $game_party.members[$game_system.leveling_actor].temp_param[4]
    temp_mdf = $game_party.members[$game_system.leveling_actor].temp_param[5]
    temp_agi = $game_party.members[$game_system.leveling_actor].temp_param[6]
    temp_luk = $game_party.members[$game_system.leveling_actor].temp_param[7]
    
    temp_used_points = temp_mhp + temp_mmp + temp_atk + temp_def + temp_mat + temp_mdf + temp_agi + temp_luk
    actor = $game_party.members[$game_system.leveling_actor]
    points = actor.lvupp - temp_used_points
    param_id = $game_system.icon_y
    $game_system.leveling = false
    SceneManager.goto(Scene_Map) unless $game_system.menu_usage
    return_scene if $game_system.menu_usage
    @lvup_window.add_stats
    $game_party.members[$game_system.leveling_actor].lvupp -= temp_used_points
    @lvup_window.reset_temp_stats
    @lvup_window.refresh
    $game_system.menu_usage = false
  end
    
  #--------------------------------------------------------------------------
  # * OK Processing
  #--------------------------------------------------------------------------
  
  def process_ok
    temp_mhp = $game_party.members[$game_system.leveling_actor].temp_param[0]
    temp_mmp = $game_party.members[$game_system.leveling_actor].temp_param[1]
    temp_atk = $game_party.members[$game_system.leveling_actor].temp_param[2]
    temp_def = $game_party.members[$game_system.leveling_actor].temp_param[3]
    temp_mat = $game_party.members[$game_system.leveling_actor].temp_param[4]
    temp_mdf = $game_party.members[$game_system.leveling_actor].temp_param[5]
    temp_agi = $game_party.members[$game_system.leveling_actor].temp_param[6]
    temp_luk = $game_party.members[$game_system.leveling_actor].temp_param[7]
    
    temp_used_points = temp_mhp + temp_mmp + temp_atk + temp_def + temp_mat + temp_mdf + temp_agi + temp_luk
    actor = $game_party.members[$game_system.leveling_actor]
    points = actor.lvupp - temp_used_points
    param_id = $game_system.icon_y
    
    case
    when $game_system.icon_x == 0
      
      if actor.temp_param[param_id] == 0
        Sound.play_buzzer
      else
        $game_party.members[$game_system.leveling_actor].temp_param[param_id] -= $game_party.members[$game_system.leveling_actor].temp_param[param_id]
        Sound.play_ok
      end
      
    when $game_system.icon_x == 1
      
      if actor.temp_param[param_id] == 0
        Sound.play_buzzer
      else
        $game_party.members[$game_system.leveling_actor].temp_param[param_id] -= 1 
        Sound.play_ok
      end
      
    when $game_system.icon_x == 2 
      
      if points == 0
        Sound.play_buzzer
      else
        $game_party.members[$game_system.leveling_actor].temp_param[param_id] += 1 
        Sound.play_ok
      end
      
    when $game_system.icon_x == 3
      
      if points == 0
        Sound.play_buzzer
      else
        $game_party.members[$game_system.leveling_actor].temp_param[param_id] += points 
        Sound.play_ok
      end
      
    end
    
    @lvup_window.refresh
  end
  
  #--------------------------------------------------------------------------
  # * Update Processing
  #--------------------------------------------------------------------------
  
  def update
    super
    process_stat_input
  end
  
end
  
  
     

#==============================================================================
# ** Window_MenuCommand
#------------------------------------------------------------------------------
#  This command window appears on the menu screen.
#==============================================================================

class Window_MenuCommand < Window_Command

  #--------------------------------------------------------------------------
  # * Includes Module's Variables With Class
  #--------------------------------------------------------------------------
  
  include V_Level_Up_Stats::Specs
  
  #--------------------------------------------------------------------------
  # * For Creating An Alias
  #--------------------------------------------------------------------------
 
  alias :aoc13215 :add_original_commands
 
  #--------------------------------------------------------------------------
  # * For Adding Original Commands
  #--------------------------------------------------------------------------
  
  def add_original_commands
    aoc13215()
    
    if Use_Menu_Command
      
      $game_party.members.each_index do |i|
        
        if $game_party.members[i].lvupp > 0 || $game_party.members[i].lvupp != nil
          add_command(Level_Up_Command_Title, :level_up_stats)
        end
        break
      end
      
    end
    
  end

end




#==============================================================================
# ** Scene_Menu
#------------------------------------------------------------------------------
#  This class performs the menu screen processing.
#==============================================================================

class Scene_Menu < Scene_MenuBase


  #--------------------------------------------------------------------------
  # * Includes Module's Variables With Class
  #--------------------------------------------------------------------------
  
  include V_Level_Up_Stats::Specs
  
  #--------------------------------------------------------------------------
  # * For Creating An Alias
  #--------------------------------------------------------------------------
 
  alias :ccw13215 :create_command_window
 
  #--------------------------------------------------------------------------
  # * Create Command Window
  #--------------------------------------------------------------------------
  
  def create_command_window
    ccw13215()
    
    if Use_Menu_Command
      @command_window.set_handler(:level_up_stats,    method(:command_level_up_stats)) 
      $game_system.menu_usage = true
    end
    
  end

  #--------------------------------------------------------------------------
  # * [Save] Command
  #--------------------------------------------------------------------------
  
  def command_level_up_stats
    SceneManager.call(Scene_Level_Up_Stats)
  end
  
end


#==============================================================================
# ** Game_Actor
#------------------------------------------------------------------------------
#  This class handles actors. It is used within the Game_Actors class
# ($game_actors) and is also referenced from the Game_Party class ($game_party).
#==============================================================================

class Game_Actor < Game_Battler

  #--------------------------------------------------------------------------
  # * Includes Module's Variables With Class
  #--------------------------------------------------------------------------
  
  include V_Level_Up_Stats::Specs
  
  #--------------------------------------------------------------------------
  # * Public Instance Variables
  #--------------------------------------------------------------------------
 
  attr_accessor :lvupp
  attr_accessor :added_param
  attr_accessor :temp_param
  
  #--------------------------------------------------------------------------
  # * For Creating An Alias
  #--------------------------------------------------------------------------
 
  alias :old_init787687322 :initialize
 
  #--------------------------------------------------------------------------
  # * Object Initialization
  #--------------------------------------------------------------------------
 
  def initialize(actor_id)
    super()
    @lvupp = Initial_Points
    @added_param = [0, 0, 0, 0, 0, 0, 0, 0]
    @temp_param = [0, 0, 0, 0, 0, 0, 0, 0]
    old_init787687322(actor_id) 
  end
  
  #--------------------------------------------------------------------------
  # * For Creating An Alias
  #--------------------------------------------------------------------------
 
  alias :old_param_base5547 :param_base
  
  #--------------------------------------------------------------------------
  # * Get Base Value of Parameter
  #--------------------------------------------------------------------------
  def param_base(param_id)
    old_param_base5547(param_id) + @added_param[param_id]
  end  
  
  #--------------------------------------------------------------------------
  # * For Creating An Alias
  #--------------------------------------------------------------------------
 
  alias :old_level_up546345 :level_up
  
  #--------------------------------------------------------------------------
  # * Level Up
  #--------------------------------------------------------------------------
  def level_up
    old_level_up546345()
    @lvupp += Points_Per_Level
    $game_system.leveling = true 
  end
  
end


#==============================================================================
# ** Game_Player
#------------------------------------------------------------------------------
#  This class handles the player. It includes event starting determinants and
# map scrolling functions. The instance of this class is referenced by
# $game_player.
#==============================================================================

class Game_Player < Game_Character
  
  #--------------------------------------------------------------------------
  # * Includes Module's Variables With Class
  #--------------------------------------------------------------------------
  
  include V_Level_Up_Stats::Specs
  
  #--------------------------------------------------------------------------
  # * For Creating An Alias
  #--------------------------------------------------------------------------
 
  alias :update417546345 :update
  
  #--------------------------------------------------------------------------
  # * Frame Update
  #--------------------------------------------------------------------------
  def update
    update417546345()
    check_leveling
  end
  
  def check_leveling
    SceneManager.call(Scene_Level_Up_Stats) if $game_system.leveling && Use_Menu_Command_Only == false
  end

end

  
  
  
#==============================================================================
# ** Game_System
#------------------------------------------------------------------------------
#  This class handles system data. It saves the disable state of saving and
# menus. Instances of this class are referenced by $game_system.
#==============================================================================
 
class Game_System
 
  #--------------------------------------------------------------------------
  # * Includes Module's Variables With Class
  #--------------------------------------------------------------------------
  
  include V_Level_Up_Stats::Specs
  
  #--------------------------------------------------------------------------
  # * Public Instance Variables
  #--------------------------------------------------------------------------
  attr_accessor :leveling
  attr_accessor :leveling_actor
  attr_accessor :icon_x
  attr_accessor :icon_y
  attr_accessor :menu_usage
  
  #--------------------------------------------------------------------------
  # * For Creating An Alias
  #--------------------------------------------------------------------------
 
  alias :old_init7527 :initialize
 
  #--------------------------------------------------------------------------
  # * Object Initialization
  #--------------------------------------------------------------------------
 
  def initialize
    
    @leveling = false 
    @leveling_actor = 0 
    @icon_x = 0
    @icon_y = 0
    @menu_usage = false
    old_init7527()
  end
 
end