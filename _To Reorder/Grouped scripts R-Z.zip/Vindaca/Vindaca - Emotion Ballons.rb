#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
#                                                                              #
#                            V's  Emotion Balloons                             #
#                                 Version  0.3                                 #
#                                                                              #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#                                Written By:  V                                #
#                        Last Edited: February 21, 2013                        #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#                             Extended Credit to:                              #
#                                                                              #
#                            SoulPour777 ~ Concept                             #
#                                                                              #
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
 
 
#==============================================================================#
#------------------------------------------------------------------------------#
# ** Disclaimer                                                                #
#------------------------------------------------------------------------------#
#                                                                              #
# This script was intended for Non-commercial use only, if you wish to use     #
# this script in a commercial game please PM me at which ever site you found   #
# this script. Either way please give me credit in your game script as the     #
# writer of this script, and send me a PM abuot the release of the game/demo.  #
#                                                                              #
#------------------------------------------------------------------------------#
# ** How To Use                                                                #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#                                                                              #
#  * This script is Plug & Play with a few options below.                      #
#                                                                              #
#------------------------------------------------------------------------------#
# ** Description                                                               #
#------------------------------------------------------------------------------#
#                                                                              #
#  v0.1                                                                        #
# ~=~=~=~                                                                      #
#                                                                              #
# In v0.1, this system will allow you to set up emotion balloons to be called  #
# by hitting F5, F6, F7, or F8.                                                #
#                                                                              #
#  v0.2                                                                        #
# ~=~=~=~                                                                      #
#                                                                              #
# In v0.2 I set-up an option for a menu to allow the player to change each of  #
# the balloon's emotions while in game. I also set-up an option to add as many #
# triggers as you want.                                                        #
#                                                                              #
#  v0.3                                                                        #
# ~=~=~=~                                                                      #
#                                                                              #
# Sound effects can now be assigned to emotions that play when it is displayed.#
#                                                                              #
#------------------------------------------------------------------------------#
#==============================================================================#
 
#==============================================================================
# ** V's Emotion Balloons
#------------------------------------------------------------------------------
#  This module manages customizable features and methods.
#==============================================================================

module Emotion_Balloons
  module Specs
  #=============================================================================
  # Balloon Table
  #-----------------------------------------------------------------------------
  # 1  - Exclamation
  # 2  - Question
  # 3  - Music Note
  # 4  - Heart
  # 5  - Anger
  # 6  - Sweat
  # 7  - Cob Web
  # 8  - Silence
  # 9  - Light Bulb
  # 10 - ZZZ
  #=============================================================================
  
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
#                                                                              #
#                           Start Customizable Area.                           #
#                                                                              #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#                                                                              #
#                      ONLY EDIT AFTER THE EQUALS SYMBOL.                      #
#                                                                              #
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
   

  #=============================================================================
  # * Menu Command:
  #=============================================================================

    #--------------------------------------------------------------------------
    # * Adds a command to the Main Menu for the Emotion Balloons Menu
    #--------------------------------------------------------------------------
    Use_Emo_Balloon_Menu_Command = true
    
    #--------------------------------------------------------------------------
    # * Menu Command Vocab
    #--------------------------------------------------------------------------
    Balloon_Menu_Vocab = "Emo Options"
  
    
  #=============================================================================
  # * Emotion Sound Effects:
  #=============================================================================
    Emotion_SFX = [
                    ["Cursor2", 80, 100],   # Exclamation
                    ["Confuse", 80, 100],   # Question
                    ["Saint5", 80, 100],    # Music Note
                    ["Load", 80, 100],      # Heart
                    ["Monster6", 80, 100],  # Anger
                    ["Sound3", 80, 100],    # Sweat
                    ["Sand", 80, 100],      # Cob Web
                    ["Silence", 80, 100],   # Silence
                    ["Thunder12", 80, 100], # Light Bulb
                    ["Sleep", 80, 100],     # ZZZ
                  ]
  
  
  #=============================================================================
  # * Balloon Information:
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # More triggers may be added if wanted. 
  #=============================================================================
    Balloon_Info = [   #Trigger          Vocab     Default Emotion
                     [ Input::F5,     "F5 Button",        1      ], 
                     [ Input::F6,     "F6 Button",        2      ], 
                     [ Input::F7,     "F7 Button",        3      ], 
                     [ Input::F8,     "F8 Button",        4      ],
                   ] 
  
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
  
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
#                                                                              #
#                            End Customizable Area.                            #
#                                                                              #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#                                                                              #
#         DO NOT EDIT PAST THIS POINT UNLESS YOU KNOW WHAT YOUR DOING.         #
#                                                                              #
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
   
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 


















 
end
end

#==============================================================================
# ** Game_System
#------------------------------------------------------------------------------
#  This class handles system data. It saves the disable state of saving and 
# menus. Instances of this class are referenced by $game_system.
#==============================================================================

class Game_System

  #--------------------------------------------------------------------------
  # * Includes Module's Variables With Class
  #--------------------------------------------------------------------------
  
  include Emotion_Balloons::Specs
  
  #--------------------------------------------------------------------------
  # * Public Instance Variables
  #--------------------------------------------------------------------------
  attr_accessor :emo_balloon
  
  #--------------------------------------------------------------------------
  # * Method for Aliasing: Object Initialization
  #--------------------------------------------------------------------------
  alias :gsi5404045000054548485 :initialize
    
  #--------------------------------------------------------------------------
  # * Object Initialization
  #--------------------------------------------------------------------------
  def initialize
    gsi5404045000054548485()
    @emo_balloon = []
    Balloon_Info.size.times { |i| @emo_balloon.push Balloon_Info[i][2] }
  end

end
  
  
#==============================================================================
# ** Window_Command
#------------------------------------------------------------------------------
#  This window deals with general command choices.
#==============================================================================

class Window_BalloonSelect < Window_Command

  #--------------------------------------------------------------------------
  # * Includes Module's Variables With Class
  #--------------------------------------------------------------------------
  
  include Emotion_Balloons::Specs
  
  #--------------------------------------------------------------------------
  # * Start Processing
  #--------------------------------------------------------------------------
  def initialize(x, y)
    super(x, y)
  end
  
  #--------------------------------------------------------------------------
  # * Window Height
  #--------------------------------------------------------------------------
  def window_height
    return Graphics.height
  end
  
  #--------------------------------------------------------------------------
  # * Window Width
  #--------------------------------------------------------------------------
  def window_width
    return Graphics.width / 2
  end
  
  #--------------------------------------------------------------------------
  # * Start Processing
  #--------------------------------------------------------------------------
  def make_command_list
    Balloon_Info.size.times { |i| add_command(Balloon_Info[i][1],  Balloon_Info[i][1].to_sym) }
  end
  
end

#==============================================================================
# ** Window_Command
#------------------------------------------------------------------------------
#  This window deals with general command choices.
#==============================================================================

class Window_EmotionSelect < Window_Command

  #--------------------------------------------------------------------------
  # * Includes Module's Variables With Class
  #--------------------------------------------------------------------------
  
  include Emotion_Balloons::Specs
  
  #--------------------------------------------------------------------------
  # * Start Processing
  #--------------------------------------------------------------------------
  def initialize(x, y)
    super(x, y)
  end
  
  #--------------------------------------------------------------------------
  # * Window Height
  #--------------------------------------------------------------------------
  def window_height
    return Graphics.height
  end
  
  #--------------------------------------------------------------------------
  # * Window Width
  #--------------------------------------------------------------------------
  def window_width
    return Graphics.width / 2
  end
  
  #--------------------------------------------------------------------------
  # * Start Processing
  #--------------------------------------------------------------------------
  def make_command_list
    add_command("Exclamation", :first_emotion)
    add_command("Question",    :second_emotion)
    add_command("Music Note",  :third_emotion)
    add_command("Heart",       :forth_emotion)
    add_command("Anger",       :fifth_emotion)
    add_command("Sweat",       :sixth_emotion)
    add_command("Cob Web",     :seventh_emotion)
    add_command("Silence",     :eighth_emotion)
    add_command("Light Bulb",  :ninth_emotion)
    add_command("ZZZ",         :tenth_emotion)
  end
  
end

#==============================================================================
# ** Window_MenuCommand
#------------------------------------------------------------------------------
#  This command window appears on the menu screen.
#==============================================================================

class Window_MenuCommand < Window_Command

  #--------------------------------------------------------------------------
  # * Includes Module's Variables With Class
  #--------------------------------------------------------------------------
  
  include Emotion_Balloons::Specs
  
  #--------------------------------------------------------------------------
  # * Method for Aliasing: Add Original Commands
  #--------------------------------------------------------------------------
  alias :wmaoc3216504040640 :add_original_commands
    
  #--------------------------------------------------------------------------
  # * Add Original Commands
  #--------------------------------------------------------------------------
  def add_original_commands
    wmaoc3216504040640()
    add_command(Balloon_Menu_Vocab, :emoballoonmenu) if Use_Emo_Balloon_Menu_Command == true
  end
  
end


#==============================================================================
# ** Scene_Base
#------------------------------------------------------------------------------
#  This is a super class of all scenes within the game.
#==============================================================================

class Scene_BalloonEmoMenu < Scene_Base

  #--------------------------------------------------------------------------
  # * Includes Module's Variables With Class
  #--------------------------------------------------------------------------
  
  include Emotion_Balloons::Specs
  
  #--------------------------------------------------------------------------
  # * Start Processing
  #--------------------------------------------------------------------------
  def initialize
    create_windows
  end
  
  #--------------------------------------------------------------------------
  # * Create Windows 
  #--------------------------------------------------------------------------
  def create_windows
    @balloon_select_window = Window_BalloonSelect.new(0, 0)
    Balloon_Info.size.times { |i| 
      @balloon_select_window.set_handler(Balloon_Info[i][1].to_sym,  method(:select_balloon))
    }
    @emo_select_window = Window_EmotionSelect.new(@balloon_select_window.width, 0)
    @emo_select_window.set_handler(:first_emotion,     method(:select_emo))
    @emo_select_window.set_handler(:second_emotion,    method(:select_emo))
    @emo_select_window.set_handler(:third_emotion,     method(:select_emo))
    @emo_select_window.set_handler(:forth_emotion,     method(:select_emo))
    @emo_select_window.set_handler(:fifth_emotion,     method(:select_emo))
    @emo_select_window.set_handler(:sixth_emotion,     method(:select_emo))
    @emo_select_window.set_handler(:seventh_emotion,   method(:select_emo))
    @emo_select_window.set_handler(:eighth_emotion,    method(:select_emo))
    @emo_select_window.set_handler(:ninth_emotion,     method(:select_emo))
    @emo_select_window.set_handler(:tenth_emotion,     method(:select_emo))
    @emo_select_window.unselect
    @emo_select_window.deactivate
  end

  #--------------------------------------------------------------------------
  # * Command Method: Select Balloon
  #--------------------------------------------------------------------------
  def select_balloon
    @balloon_select_window.deactivate
    @emo_select_window.select($game_system.emo_balloon[@balloon_select_window.index] - 1)
    @emo_select_window.activate
  end

  #--------------------------------------------------------------------------
  # * Command Method: Select Emotion
  #--------------------------------------------------------------------------
  def select_emo
    $game_system.emo_balloon[@balloon_select_window.index] = @emo_select_window.index + 1
    @emo_select_window.unselect
    @emo_select_window.deactivate
    @balloon_select_window.activate
  end

  #--------------------------------------------------------------------------
  # * Cancel Current Input
  #--------------------------------------------------------------------------
  def cancel
    Sound.play_cancel
    if @emo_select_window.index >= 0
      @emo_select_window.unselect
      @emo_select_window.deactivate
      @balloon_select_window.activate
    else
      return_scene
    end
  end

  #--------------------------------------------------------------------------
  # * Update Processing
  #--------------------------------------------------------------------------
  def update
    super
    cancel if Input.trigger?(:B)
  end

end


#==============================================================================
# ** Scene_Menu
#------------------------------------------------------------------------------
#  This class performs the menu screen processing.
#==============================================================================

class Scene_Menu < Scene_MenuBase

  #--------------------------------------------------------------------------
  # * Method for Aliasing: Create Command Window
  #--------------------------------------------------------------------------
  alias :smccw54065400000455 :create_command_window
    
  #--------------------------------------------------------------------------
  # * Create Command Window
  #--------------------------------------------------------------------------
  def create_command_window
    smccw54065400000455()
    @command_window.set_handler(:emoballoonmenu,  method(:command_emoballoons))
  end
  
  #--------------------------------------------------------------------------
  # * [Shut Down] Command
  #--------------------------------------------------------------------------
  def command_emoballoons
    SceneManager.call(Scene_BalloonEmoMenu)
  end
   
end


#==============================================================================
# ** Scene_Map
#------------------------------------------------------------------------------
#  This class performs the map screen processing.
#==============================================================================
class Scene_Map < Scene_Base
  
  #--------------------------------------------------------------------------
  # * Includes Module's Variables With Class
  #--------------------------------------------------------------------------
  
  include Emotion_Balloons::Specs
  
  #--------------------------------------------------------------------------
  # * Method for Aliasing: Update Processing
  #--------------------------------------------------------------------------
  alias :smu4560000 :update
  
  # -----------------------------------------------------
  # Update Processing
  # -----------------------------------------------------
  def update
    smu4560000()
    unless $game_message.visible
      Balloon_Info.size.times { |i| 
        show_emotion(i) if Input.trigger?(Balloon_Info[i][0])
      }
    end
  end
  
  # -----------------------------------------------------
  # Update Processing
  # -----------------------------------------------------
  def show_emotion(index)
    RPG::SE.new(Emotion_SFX[index][0], Emotion_SFX[index][1], Emotion_SFX[index][2]).play
    $game_player.balloon_id = $game_system.emo_balloon[index] if Input.trigger?(Balloon_Info[index][0])
  end
  
end