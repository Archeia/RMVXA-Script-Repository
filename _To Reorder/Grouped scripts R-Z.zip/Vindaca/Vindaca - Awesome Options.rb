
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
#                                                                              #
#                             V's  Awesome Options                             #
#                                  Version 1.4                                 #
#                                                                              #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#                                Written By:  V                                #
#                         Last Edited:   April 5, 2013                         #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#                                                                              #
#                            And A Special Thanks to                           #
#                           ~==~==~==~==~==~==~==~==~                          #
#                              Diamondandplatinum3                             #
#                                  ShinGamix                                   #
#                                                                              #
#                                                                              #
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#


#==============================================================================#
#------------------------------------------------------------------------------#
# ** Disclaimer                                                                #
#------------------------------------------------------------------------------#
#                                                                              #
# I do not mind sharing credit for this script if alterations to the script    #
# are made. I am not making this script for commercial uses. If anyone wants   #
# to use this script in one there games just give credit to any and everyone   #
# who took part in creating it.                                                #
#                                                                              #
#------------------------------------------------------------------------------#
# ** Description                                                               #
#------------------------------------------------------------------------------#
#                                                                              #
#  v0.1                                                                        #
# ~=~=~=~                                                                      #
# -This script is still in the working. For now, this script allows you to     #
#  change the backgrounds of the all the menus, the zoom and x/y placement     #
#  of the background and it's opacity. There is also an option to use and      #
#  change BGM while in the menu screen. It also allows you to display the      #
#  actors sprite instead of or on top of the actor faces.                      #
#                                                                              #
#  v0.2                                                                        #
# ~=~=~=~                                                                      #
# -This script is still in the working. In v0.2 new features have been added   #
#  to the Title Page and the Game over Screen. The Title Page Now has an option#
#  for a third layer. All the layers (Background, Mid-ground, and Foreground)  #
#  have the same functionality as the menu backgrounds. There is also an option#
#  to change the BGM, I added this because I believe you can raise the pitch   #
#  levels higher with this script then you can with the regular game options.  #
#  The Game over screen also has options for background and BGM.               #
#                                                                              #
#  v0.3                                                                        #
# ~=~=~=~                                                                      #
# -This script is still in the working. In v0.3 new features have been added   #
#  for all the game windows opacity and border opacity and options to change   #
#  default font settings. I have also fixed a bug with the draw title option   #
#  and added a style, size and font setting for the draw title.                #
#                                                                              #
#  v0.4                                                                        #
# ~=~=~=~                                                                      #
# -This script is still in the working. In v0.4 I fixed a few more bugs with   #
#  the title menu                                                              #
#                                                                              #
#  v1.0                                                                        #
# ~=~=~=~                                                                      #
# -This script is still in the working. In v1.0 I added an option for a        #
#  a vertical and horizontal command window for the title screen and options   #
#  to change the x and y positions of both. I've also added an option to       #
#  change the actors x and y position inside of the actors face windows.       #
#                                                                              #
#  v1.1                                                                        #
# ~=~=~=~                                                                      #
# -This script is still in the working. In v1.1 I fixed a few bugs with        #
#  the horizontal title menu.                                                  #
#                                                                              #
#  v1.2                                                                        #
# ~=~=~=~                                                                      #
# -This script is still in the working. In v1.2 I have added x and y position  #
#  options for the End Game scene command window. I have also add a center     #
#  command window text for the title and End Game Scene.                       #
#                                                                              #
#  v1.3                                                                        #
# ~=~=~=~                                                                      #
# -This script is still in the working. In v1.3 I have added an option to add  #
#  Draw Game Over Text and change the x and y value of it. I have also added   #
#  two additional layers to the Game Over Screen with the same funtions as the #
#  Title backgrounds. I've also worked out a few more bugs.                    #
#                                                                              #
#  v1.4                                                                        #
# ~=~=~=~                                                                      #
# -This script is basically done with a few more additions in my sights.       #
#  In v1.4 I have added an option to play an Intro Movie before the title      #
#  page. I have also added two features that I got from D&P3's youtube channel #
#  for Balloon SE's and Collision SE, I figured they were releavent.           #
#                                                                              #
#------------------------------------------------------------------------------#
#==============================================================================#





#==============================================================================
# ** V's Awesome Options Module
#------------------------------------------------------------------------------
#  This module manages customizable features and methods.
#==============================================================================

module V_OPTS
module Specs

  
  
  
  
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
#                                                                              #
#                           Start Customizable Area.                           #
#                                                                              #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#                                                                              #
#                      ONLY EDIT AFTER THE EQUALS SYMBOL.                      #
#                                                                              #
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#



  #============================================================================
  # Movie Intro Options
  #----------------------------------------------------------------------------
  # **The movie has to be .ogg format and imported into your movie folder. 
  # ** Keep in mind that you CAN NOT stop the movie still. So try not to bore 
  #    the player with an extremely long intro.
  #============================================================================

  Play_Movie_Intro = false

  Movie_Name = "Flow_Animation"

  #============================================================================
  # Title Background Options
  #============================================================================

  Use_Mid_Layer                      = true         # Set both options to false
                                                   # to use default background
                                                 
  Title_BG_File_Name                 = "Relic Title BG"           # Import the desired BG image  
  Title_MG_File_Name                 = ""           # into the Graphics/Pictures
  Title_FG_File_Name                 = ""           # folder in the Resource Manager
                                                   # If you just want to use one layer
                                                   # Leave the mid-ground and foreground
                                                   #blank

  Title_BG_Opacity                   = 255        
  Title_MG_Opacity                   = 200        
  Title_FG_Opacity                   = 120        

  Title_BG_x_position                = 0
  Title_MG_x_position                = 0
  Title_FG_x_position                = 0

  Title_BG_y_position                = 0
  Title_MG_y_position                = 0
  Title_FG_y_position                = 0

  Title_BG_Zoom                      = 100         # Scaled with %, meaning %100
                                                   # is full screen
  Title_MG_Zoom                      = 100      
                                             
  Title_FG_Zoom                      = 100        


  #============================================================================
  # Title Command Window Options
  #============================================================================

  Use_Horizontal_Command_Window      = true

  Center_Title_Cmmd_Window_Text      = true

  Command_Window_x_position          = 8
  Command_Window_y_position          = 378

  #============================================================================
  # Draw Title Options
  #============================================================================

  Use_Draw_Title                     = false        # If you want the system to draw
                                                    # the title set to true  
  Draw_Title_Font_Size               = 16  

  Draw_Title_Font                    = ["Times New Roman"]

  Draw_Title_x_position              = 217
  Draw_Title_y_position              = 350

  #============================================================================
  # Title BGM Options
  #============================================================================

  Use_Title_BGM                      = true
                                   #["BGM', Volume, Pitch]
  Title_BGM                          = ["Town1", 70, 100]
     
  #============================================================================
  # Menu Options
  #============================================================================

  Center_Menu_Cmmd_Window_Text       = true    

  Background_File_Name               = "Relic Title BG"         # Import the desired BG image  
                                                  # into the Graphics/Pictures
                                                  # folder in the Resource Manager
  Background_Opacity                 = 75        
  Background_x_position              = 0
  Background_y_position              = 0
  Background_Zoom                    = 110        # Scaled with %, meaning %100
                                                  # is full screen

  #============================================================================
  # Menu BGM Options
  #============================================================================

  Use_BGM                            = true
                                    #["BGM', Volume, Pitch]
  Background_BGM                     = ["Town4", 70, 100]
         
  #============================================================================
  # Menu Actor Face / Actor Graphic Options
  #============================================================================
                                                                                                 
  Display_Actor_Graphic_With_Face    = true       # If you do not want to display
                                                  # the face behind the character
                                                  # graphic set the actors face
                                                  # to "none" in the Database.
                                                 
   Actor_Graphic_x_position          = 48          # 0 is the center of the face
   Actor_Graphic_y_position          = 20
   
  #============================================================================
  # End Game Command Scene Options
  #============================================================================

  Center_EndGame_Cmmd_Window_Text    = false

  End_Game_Cmmd_Window_x_position    = 0
  End_Game_Cmmd_Window_y_position    = 330

  #============================================================================
  # Game Over Options
  #============================================================================

  Use_Game_Over_Foreground          = true
  Use_Game_Over_Midground           = true

  Game_Over_BG_File_Name            = "Relic Title BG"  # Import the desired BG image  
                                                    # into the Graphics/Pictures
                                                    # folder in the Resource Manager
  Game_Over_BG_Opacity              = 100        
  Game_Over_BG_x_position           = 0
  Game_Over_BG_y_position           = 0
  Game_Over_BG_Zoom                 = 100         # Scaled with %, meaning %100
                                                  # is full screen
                                                 
  #============================================================================
  # Game Over Mid-ground Options
  #============================================================================

  Game_Over_MG_File_Name            = ""  # Import the desired BG image  
                                                       # into the Graphics/Pictures
                                                       # folder in the Resource Manager
  Game_Over_MG_Opacity              = 200        
  Game_Over_MG_x_position           = 0
  Game_Over_MG_y_position           = 0
  Game_Over_MG_Zoom                 = 100          # Scaled with %, meaning %100
                                                      # is full screen

  #============================================================================
  # Game Over Foreground Options
  #============================================================================

  Game_Over_FG_File_Name            = ""  # Import the desired BG image  
                                                       # into the Graphics/Pictures
                                                       # folder in the Resource Manager
  Game_Over_FG_Opacity              = 255        
  Game_Over_FG_x_position           = 0
  Game_Over_FG_y_position           = 0
  Game_Over_FG_Zoom                 = 100           # Scaled with %, meaning %100
                                                      # is full screen

  #============================================================================
  # Draw Game Over Text Options
  #============================================================================

  Use_Draw_Game_Over                = true        # If you want the system to draw
                                                     # the title set to true  
  Draw_Game_Over_Vocab              = "You Died!"

  Draw_Game_Over_Font_Size          = 90  
                                  #red, green, blue
  Draw_Game_Over_Font_Color         = 100, 25, 25

  Draw_Game_Over_Font               = ["Times New Roman"]

  Draw_Game_Over_Bold               = true
  Draw_Game_Over_Italic             = true
  Draw_Game_Over_Shadow             = true

  Draw_Game_Over_x_position         = 0
  Draw_Game_Over_y_position         = -25

  #============================================================================
  # Game Over BGM Options
  #============================================================================

  Use_Game_Over_BGM                 = true
                                    #["BGM', Volume, Pitch]
  Game_Over_BGM                     = ["Dungeon5", 80, 70]
                                                 
  #============================================================================
  # Window Opacity And Boarder Options
  #============================================================================

  Affect_Window_Boarders            = true
  Window_Opacity                    = 0

  #============================================================================
  # Default Font Options
  #============================================================================

  Default_Font_Size                 = 20
  Default_Font_Name                 = ["Times New Roman"]
  Default_Font_Bold                 = false
  Default_Font_Italic               = true
  Use_Font_Shadow                   = true

  #--------------------------------------------------------------------------
  # * Collision SE
  #--------------------------------------------------------------------------
  
  Use_Collision_SE = true
  
  #Collision_SE         = ["SoundName", Volume, Pitch]
  Collision_SE         = ["Blow2", 100, 60]
  
  
  Collision_Wait_Timer = 45                     # Wait time is set in frames
  
  #============================================================================
  # Balloon SE
  #============================================================================

  #Used in game to turn on and off sounds
  Event_Switch = 21
  
  
  Exclamation_SE          = ["Cursor2",   80,  100]
  Question_SE             = ["Load",      80,  100]
  Music_Note_SE           = ["Starlight", 80,  100]
  Heart_SE                = ["Saint5",    80,  100]
  Anger_SE                = ["Monster1",  80,  100]
  Sweat_SE                = ["Heal5",     80,  100]
  Cobweb_SE               = ["Equip2",    80,  100]
  Silence_SE              = [nil,         80,  100]
  Lightbulb_SE            = ["Magic5",    80,  100]
  Zzz_SE                  = ["Saint1",    80,  100]

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
#                                                                              #
#                            End Customizable Area.                            #
#                                                                              #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#                                                                              #
#         DO NOT EDIT PAST THIS POINT UNLESS YOU KNOW WHAT YOUR DOING.         #
#                                                                              #
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#


















  end
end



#------------------------------------------------------------------------------
#  This class handles the player. It includes event starting determinants and
# map scrolling functions. The instance of this class is referenced by
# $game_player.
#==============================================================================

class Game_Player < Game_Character

  #--------------------------------------------------------------------------
  # * For Aliasing
  #--------------------------------------------------------------------------
  
  alias v_collisionsound_gameplayer_update_jh21     update

  #--------------------------------------------------------------------------
  # * Frame Update
  #--------------------------------------------------------------------------

  def update
    v_collisionsound_gameplayer_update_jh21()
    
    if V_OPTS::Specs::Use_Collision_SE
      @collision_sound_timer = 0 unless @collision_sound_timer
      @collision_sound_timer -= 1 unless @collision_sound_timer == 0
    end
    
  end

  #--------------------------------------------------------------------------
  # * For Aliasing
  #--------------------------------------------------------------------------
  
  alias v_collisionsound_gameplayer_passable_jh21     passable?
  
  #--------------------------------------------------------------------------
  # * Determine if Passable
  #--------------------------------------------------------------------------
  
  def passable?( *args )
    passable = v_collisionsound_gameplayer_passable_jh21( *args )
    
    unless passable || @collision_sound_timer > 0
      RPG::SE.new(*V_OPTS::Specs::Collision_SE).play
      @collision_sound_timer = V_OPTS::Specs::Collision_Wait_Timer
    end
    
    return passable
  end
  
end
#==============================================================================
# ** Window_Base
#------------------------------------------------------------------------------
#  This is a super class of all windows within the game.
#==============================================================================

class Window_Base < Window

  #--------------------------------------------------------------------------
  # * For Creating An Alias
  #--------------------------------------------------------------------------

  alias v_menuoptioss_winbase_initialize_34864                     initialize

  #--------------------------------------------------------------------------
  # * Object Initialization
  #--------------------------------------------------------------------------

  def initialize(x, y, width, height)
    super
    @usewinboarders = V_OPTS::Specs::Affect_Window_Boarders
    Font.default_size = V_OPTS::Specs::Default_Font_Size                      
    Font.default_name = V_OPTS::Specs::Default_Font_Name  
    Font.default_bold = V_OPTS::Specs::Default_Font_Bold                
    Font.default_italic = V_OPTS::Specs::Default_Font_Italic            
    Font.default_shadow = V_OPTS::Specs::Use_Font_Shadow    
    self.windowskin = Cache.system("Window")
   
    if @usewinboarders
      then self.opacity = V_OPTS::Specs::Window_Opacity
    else self.back_opacity = V_OPTS::Specs::Window_Opacity
    end
   
    update_padding
    update_tone
    create_contents
    @opening = @closing = false
  end

  #--------------------------------------------------------------------------
  # * For Creating An Alias
  #--------------------------------------------------------------------------

  alias v_menuoptioss_winbase_drawactorface_32541             draw_actor_face

  #--------------------------------------------------------------------------
  # * Draw Actor Face Or Graphic
  #--------------------------------------------------------------------------

  def draw_actor_face(actor, x, y, enabled = true)
    v_menuoptioss_winbase_drawactorface_32541(actor, x, y)
    @draw_actor_face_or_graphic = V_OPTS::Specs::Display_Actor_Graphic_With_Face
    @actorgraphicx = V_OPTS::Specs::Actor_Graphic_x_position
    @actorgraphicy = V_OPTS::Specs::Actor_Graphic_y_position
   
    if @draw_actor_face_or_graphic
      then draw_actor_graphic(actor, (x + 50 + @actorgraphicx), (y + 70 + @actorgraphicy))
    else draw_face(actor.face_name, actor.face_index, x, y, enabled)
    end
   
  end

end



#==============================================================================
# ** HorzCmmdWin
#------------------------------------------------------------------------------
#  This class is for the horizontal command window option.
#==============================================================================

class HorzCmmdWin < Window_Command

  #--------------------------------------------------------------------------
  # * Object Initialization
  #--------------------------------------------------------------------------

  def initialize
  super(((Graphics.width - window_width) / 1), Graphics.height - window_height)
  select_symbol :continue if continue_enabled
  end

  #--------------------------------------------------------------------------
  # * Get Window Width
  #--------------------------------------------------------------------------

  def window_width
  return (275- standard_padding) * 2
  end

  #--------------------------------------------------------------------------
  # * Create Command List
  #--------------------------------------------------------------------------

  def make_command_list
  add_command(Vocab::new_game, :new_game)
  add_command(Vocab::continue, :continue, continue_enabled)
  add_command(Vocab::shutdown, :shutdown)
  end

  #--------------------------------------------------------------------------
  # * Get Activation State of Continue
  #--------------------------------------------------------------------------

  def continue_enabled
  DataManager.save_file_exists?
  end

  #--------------------------------------------------------------------------
  # * Get Number of Items
  #--------------------------------------------------------------------------

  def item_max
    return 3
  end

  #--------------------------------------------------------------------------
  # * Get Digit Count
  #--------------------------------------------------------------------------

  def col_max
  return 3
  end

  #--------------------------------------------------------------------------
  # * Draw Item
  #--------------------------------------------------------------------------

  def draw_item(index)
    @center_text = V_OPTS::Specs::Center_Title_Cmmd_Window_Text
    change_color(normal_color, command_enabled?(index))
   
    if @center_text
      then draw_text(item_rect_for_text(index), command_name(index), alignment = 1)
    else draw_text(item_rect_for_text(index), command_name(index), alignment = 0)
    end
         
  end

end



#==============================================================================
# ** Window_MenuCommand
#------------------------------------------------------------------------------
#  This command window appears on the menu screen.
#==============================================================================

class Window_MenuCommand < Window_Command
 
  #--------------------------------------------------------------------------
  # * Draw Item
  #--------------------------------------------------------------------------

  def draw_item(index)
    @center_text = V_OPTS::Specs::Center_Menu_Cmmd_Window_Text
    change_color(normal_color, command_enabled?(index))
   
    if @center_text
      then draw_text(item_rect_for_text(index), command_name(index), alignment = 1)
    else draw_text(item_rect_for_text(index), command_name(index), alignment = 0)
    end
         
  end

end  



#==============================================================================
# ** Window_TitleCommand
#------------------------------------------------------------------------------
#  This window is for selecting New Game/Continue on the title screen.
#==============================================================================

class Window_TitleCommand < Window_Command

  #--------------------------------------------------------------------------
  # * Draw Item
  #--------------------------------------------------------------------------

  def draw_item(index)
    @center_text = V_OPTS::Specs::Center_Title_Cmmd_Window_Text
    change_color(normal_color, command_enabled?(index))
   
    if @center_text
      then draw_text(item_rect_for_text(index), command_name(index), alignment = 1)
    else draw_text(item_rect_for_text(index), command_name(index), alignment = 0)
    end
         
  end

end



#==============================================================================
# ** Window_GameEnd
#------------------------------------------------------------------------------
#  This window is for selecting Go to Title/Shut Down on the game over screen.
#==============================================================================

class Window_GameEnd < Window_Command

  #--------------------------------------------------------------------------
  # * Object Initialization
  #--------------------------------------------------------------------------

  def initialize
    super(0, 0)
    update_placement
    self.openness = 0
    open
  end

  #--------------------------------------------------------------------------
  # * Get Window Width
  #--------------------------------------------------------------------------

  def window_width
    return 160
  end

  #--------------------------------------------------------------------------
  # * Update Window Position
  #--------------------------------------------------------------------------

  def update_placement
    self.x = (Graphics.width - width) / 2
    self.y = (Graphics.height - height) / 2
  end

  #--------------------------------------------------------------------------
  # * Create Command List
  #--------------------------------------------------------------------------

  def make_command_list
    add_command(Vocab::to_title, :to_title)
    add_command(Vocab::shutdown, :shutdown)
    add_command(Vocab::cancel,   :cancel)
  end

  #--------------------------------------------------------------------------
  # * Draw Item
  #--------------------------------------------------------------------------

  def draw_item(index)
    @center_text = V_OPTS::Specs::Center_EndGame_Cmmd_Window_Text
    change_color(normal_color, command_enabled?(index))
   
    if @center_text
      then draw_text(item_rect_for_text(index), command_name(index), alignment = 1)
    else draw_text(item_rect_for_text(index), command_name(index), alignment = 0 )
    end
         
  end

end



#==============================================================================
# ** Scene_Title
#------------------------------------------------------------------------------
#  This class performs the title screen processing.
#==============================================================================

class Scene_Title < Scene_Base

  #--------------------------------------------------------------------------
  # * Start Processing
  #--------------------------------------------------------------------------

  def start
    super
    
    if  V_OPTS::Specs::Play_Movie_Intro
      movie_intro
    end
    
    @usehrzcmmdwin = V_OPTS::Specs::Use_Horizontal_Command_Window
    @usedrawtitle = V_OPTS::Specs::Use_Draw_Title
    SceneManager.clear
    Graphics.freeze
   
    if @usehrzcmmdwin
      then create_horizontal_command_window
    else create_command_window
    end
         
    create_background
    determine_use_MG
   
    if @usedrawtitle
      then create_foreground_with_title
      else create_foreground
    end
   
    play_title_music
     
  end
 
  #--------------------------------------------------------------------------
  # * Movie Intro
  #--------------------------------------------------------------------------
  
  def movie_intro
    name = V_OPTS::Specs::Movie_Name
    Graphics.play_movie('Movies/' + name) unless name.empty?
  end
  
  #--------------------------------------------------------------------------
  # * Determines If Midground Is True
  #--------------------------------------------------------------------------

  def determine_use_MG
    @usemidground = V_OPTS::Specs::Use_Mid_Layer

    if @usemidground
      then create_midground
    end
   
  end

  #--------------------------------------------------------------------------
  # * Termination Processing
  #--------------------------------------------------------------------------

  def hrz_terminate
  end

  #--------------------------------------------------------------------------
  # * Termination Processing
  #--------------------------------------------------------------------------

  def terminate
    super
    SceneManager.snapshot_for_background
    dispose_background
    usemidground = V_OPTS::Specs::Use_Mid_Layer

    if usemidground
      then dispose_midground
    end
   
    dispose_foreground
  end

  #--------------------------------------------------------------------------
  # * Create Background
  #--------------------------------------------------------------------------

  def create_background    
    @title_sprite1 = Sprite.new
    @title_sprite1.bitmap = Cache.picture(V_OPTS::Specs::Title_BG_File_Name)
    @title_sprite1.x = V_OPTS::Specs::Title_BG_x_position
    @title_sprite1.y = V_OPTS::Specs::Title_BG_y_position
    @title_sprite1.zoom_x= Graphics.width.to_f / @title_sprite1.width / 100 * V_OPTS::Specs::Title_BG_Zoom
    @title_sprite1.zoom_y = Graphics.height.to_f / @title_sprite1.height / 100 * V_OPTS::Specs::Title_BG_Zoom
    @title_sprite1.opacity = V_OPTS::Specs::Title_BG_Opacity
    @title_sprite1.visible = true
  end

  #--------------------------------------------------------------------------
  # * Create Midground
  #--------------------------------------------------------------------------

  def create_midground
    @title_sprite2 = Sprite.new
    @title_sprite2.bitmap = Cache.picture(V_OPTS::Specs::Title_MG_File_Name)
    @title_sprite2.x = V_OPTS::Specs::Title_MG_x_position
    @title_sprite2.y = V_OPTS::Specs::Title_MG_y_position
    @title_sprite2.zoom_x= Graphics.width.to_f / @title_sprite2.width / 100 * V_OPTS::Specs::Title_MG_Zoom
    @title_sprite2.zoom_y = Graphics.height.to_f / @title_sprite2.height / 100 * V_OPTS::Specs::Title_MG_Zoom
    @title_sprite2.opacity = V_OPTS::Specs::Title_MG_Opacity
    @title_sprite2.visible = true
  end

  #--------------------------------------------------------------------------
  # * Create Foreground With Title
  #--------------------------------------------------------------------------

  def create_foreground_with_title
    @title_sprite3 = Sprite.new
    @title_sprite3.bitmap = Cache.picture(V_OPTS::Specs::Title_FG_File_Name)
    @title_sprite3.x = V_OPTS::Specs::Title_FG_x_position
    @title_sprite3.y = V_OPTS::Specs::Title_FG_y_position
    @title_sprite3.zoom_x= Graphics.width.to_f / @title_sprite3.width / 100 * V_OPTS::Specs::Title_FG_Zoom
    @title_sprite3.zoom_y = Graphics.height.to_f / @title_sprite3.height / 100 * V_OPTS::Specs::Title_FG_Zoom
    @title_sprite3.opacity = V_OPTS::Specs::Title_FG_Opacity
    @title_sprite3.visible = true
    @title_sprite3.bitmap.font.size = V_OPTS::Specs::Draw_Title_Font_Size
    rect_x = V_OPTS::Specs::Draw_Title_x_position
    rect_y = V_OPTS::Specs::Draw_Title_y_position
    rect = Rect.new(*rect_x, *rect_y, Graphics.width, Graphics.height / 2)
    @title_sprite3.bitmap.draw_text(rect, $data_system.game_title, 1)
  end

  #--------------------------------------------------------------------------
  # * Create Foreground
  #--------------------------------------------------------------------------

  def create_foreground
    @title_sprite3 = Sprite.new
    @title_sprite3.bitmap = Cache.picture(V_OPTS::Specs::Title_FG_File_Name)
    @title_sprite3.x = V_OPTS::Specs::Title_FG_x_position
    @title_sprite3.y = V_OPTS::Specs::Title_FG_y_position
    @title_sprite3.zoom_x= Graphics.width.to_f / @title_sprite3.width / 100 * V_OPTS::Specs::Title_FG_Zoom
    @title_sprite3.zoom_y = Graphics.height.to_f / @title_sprite3.height / 100 * V_OPTS::Specs::Title_FG_Zoom
    @title_sprite3.opacity = V_OPTS::Specs::Title_FG_Opacity
    @title_sprite3.visible = true
  end

  #--------------------------------------------------------------------------
  # * Free Background
  #--------------------------------------------------------------------------

  def dispose_background
    @title_sprite1.bitmap.dispose
    @title_sprite1.dispose
  end

  #--------------------------------------------------------------------------
  # * Free Mid-ground
  #--------------------------------------------------------------------------

  def dispose_midground
    @title_sprite2.bitmap.dispose
    @title_sprite2.dispose
  end

  #--------------------------------------------------------------------------
  # * Free Foreground
  #--------------------------------------------------------------------------

  def dispose_foreground
    @title_sprite3.bitmap.dispose
    @title_sprite3.dispose
  end

  #--------------------------------------------------------------------------
  # * Create Horizontal Command List
  #--------------------------------------------------------------------------

  def create_horizontal_command_window
    @hrzcommand_window = HorzCmmdWin.new
    @hrzcommand_window.x = V_OPTS::Specs::Command_Window_x_position
    @hrzcommand_window.y = V_OPTS::Specs::Command_Window_y_position
    Font.default_size = 20
    @hrzcommand_window.set_handler(:new_game, method(:command_new_game))
    @hrzcommand_window.set_handler(:continue, method(:command_continue))
    @hrzcommand_window.set_handler(:shutdown, method(:command_shutdown))
  end

  #--------------------------------------------------------------------------
  # * Create Command List
  #--------------------------------------------------------------------------

  def create_command_window
    @command_window = Window_TitleCommand.new
    @command_window.x = V_OPTS::Specs::Command_Window_x_position
    @command_window.y = V_OPTS::Specs::Command_Window_y_position
    Font.default_size = 20
    @command_window.set_handler(:new_game, method(:command_new_game))
    @command_window.set_handler(:continue, method(:command_continue))
    @command_window.set_handler(:shutdown, method(:command_shutdown))
  end

  #--------------------------------------------------------------------------
  # * Close Command Window
  #--------------------------------------------------------------------------

  def close_command_window
    @usehrzcmmdwin = V_OPTS::Specs::Use_Horizontal_Command_Window
   
    if @usehrzcmmdwin
      then @hrzcommand_window.close && update until @hrzcommand_window.close?
    else
      @command_window.close && update until @command_window.close?
    end
   
    Font.default_size = V_OPTS::Specs::Default_Font_Size
  end

  #--------------------------------------------------------------------------
  # * [New Game] Command
  #--------------------------------------------------------------------------

  def command_new_game
    DataManager.setup_new_game
    close_command_window
    fadeout_all
    $game_map.autoplay
    SceneManager.goto(Scene_Map)
  end

  #--------------------------------------------------------------------------
  # * [Continue] Command
  #--------------------------------------------------------------------------

  def command_continue
    close_command_window
    SceneManager.call(Scene_Load)
  end

  #--------------------------------------------------------------------------
  # * [Shut Down] Command
  #--------------------------------------------------------------------------

  def command_shutdown
    close_command_window
    fadeout_all
    SceneManager.exit
  end

  #--------------------------------------------------------------------------
  # * Play Title Screen Music
  #--------------------------------------------------------------------------

  def play_title_music
    @usetbgm = V_OPTS::Specs::Use_Title_BGM
    tbgm = V_OPTS::Specs::Title_BGM
   
    if @usetbgm
      then RPG::BGM.new(*tbgm).play
    else $data_system.title_bgm.play
    end
   
    RPG::BGS.stop
    RPG::ME.stop
  end

end



#==============================================================================
# ** Scene_MenuBase
#------------------------------------------------------------------------------
#  This class performs basic processing related to the menu screen.
#==============================================================================

class Scene_MenuBase < Scene_Base

  #--------------------------------------------------------------------------
  # * For Creating An Alias
  #--------------------------------------------------------------------------

  alias v_menuoptions_scenemenubase_start_32541                            start

  #--------------------------------------------------------------------------
  # * Start Processing
  #--------------------------------------------------------------------------

  def start
    v_menuoptions_scenemenubase_start_32541()
    play_menu_music if V_OPTS::Specs::Use_BGM
  end

  #--------------------------------------------------------------------------
  # * Play BGM Processing
  #--------------------------------------------------------------------------

  def play_menu_music
    @last_bgm = RPG::BGM.last
    bgm = V_OPTS::Specs::Background_BGM
    RPG::BGM.fade(60)
    RPG::BGM.new(*bgm).play
  end

  #--------------------------------------------------------------------------
  # * For Creating An Alias
  #--------------------------------------------------------------------------

  alias v_menuoptions_scenebase_terminate_5465                     terminate

  #--------------------------------------------------------------------------
  # * Termination Processing
  #--------------------------------------------------------------------------

  def terminate
    v_menuoptions_scenebase_terminate_5465()
   
    if V_OPTS::Specs::Use_BGM
      RPG::BGM.fade(60)
      @last_bgm.replay rescue nil
    end
   
  end

  #--------------------------------------------------------------------------
  # * Free Background
  #--------------------------------------------------------------------------

  def dispose_background
    @background_sprite.dispose
  end

  #--------------------------------------------------------------------------
  # * Create Background
  #--------------------------------------------------------------------------

  def create_background
    @background_sprite = Sprite.new
    @background_sprite.bitmap = Cache.picture(V_OPTS::Specs::Background_File_Name)
    @background_sprite.x = V_OPTS::Specs::Background_x_position
    @background_sprite.y = V_OPTS::Specs::Background_y_position
    @background_sprite.zoom_x= Graphics.width.to_f / @background_sprite.width / 100 * V_OPTS::Specs::Background_Zoom
    @background_sprite.zoom_y = Graphics.height.to_f / @background_sprite.height / 100 * V_OPTS::Specs::Background_Zoom
    @background_sprite.opacity = V_OPTS::Specs::Background_Opacity
    @background_sprite.visible = true
  end

end



#==============================================================================
# ** Scene_Menu
#------------------------------------------------------------------------------
#  This class performs the menu screen processing.
#==============================================================================

class Scene_Menu < Scene_MenuBase

  #--------------------------------------------------------------------------
  # * [Exit Game] Command
  #--------------------------------------------------------------------------

  def command_game_end
    SceneManager.call(V_Scene_End)
  end

end



#==============================================================================
# ** V_Scene_End
#------------------------------------------------------------------------------
#  This class performs V Game End Scene processing.
#==============================================================================

class V_Scene_End < Scene_MenuBase

  #--------------------------------------------------------------------------
  # * Start Processing
  #--------------------------------------------------------------------------

  def start
    super
    create_command_window
  end

  #--------------------------------------------------------------------------
  # * Pre-Termination Processing
  #--------------------------------------------------------------------------

  def pre_terminate
    super
    close_command_window
  end

  #--------------------------------------------------------------------------
  # * Create Command Window
  #--------------------------------------------------------------------------

  def create_command_window
    @command_window = Window_GameEnd.new
    @command_window.x = V_OPTS::Specs::End_Game_Cmmd_Window_x_position
    @command_window.y = V_OPTS::Specs::End_Game_Cmmd_Window_y_position
    @command_window.set_handler(:to_title, method(:command_to_title))
    @command_window.set_handler(:shutdown, method(:command_shutdown))
    @command_window.set_handler(:cancel,   method(:return_scene))
  end

  #--------------------------------------------------------------------------
  # * Close Command Window
  #--------------------------------------------------------------------------

  def close_command_window
    @command_window.close
    update until @command_window.close?
  end

  #--------------------------------------------------------------------------
  # * [Go to Title] Command
  #--------------------------------------------------------------------------

  def command_to_title
    close_command_window
    fadeout_all
    SceneManager.goto(Scene_Title)
  end

  #--------------------------------------------------------------------------
  # * [Shut Down] Command
  #--------------------------------------------------------------------------

  def command_shutdown
    close_command_window
    fadeout_all
    SceneManager.exit
  end

end



#==============================================================================
# ** Scene_Gameover
#------------------------------------------------------------------------------
#  This class performs game over screen processing.
#==============================================================================

class Scene_Gameover < Scene_Base

  #--------------------------------------------------------------------------
  # * Start Processing
  #--------------------------------------------------------------------------
  def start
    super
    play_gameover_music
    fadeout_frozen_graphics
    @uselayer = V_OPTS::Specs::Use_Game_Over_Midground || V_OPTS::Specs::Use_Game_Over_Foreground
   
    if @uselayer
      then
      determine_layers
      create_base_background
    else
      create_background
    end
   
  end

  #--------------------------------------------------------------------------
  # * Play Music on Game Over Screen
  #--------------------------------------------------------------------------

  def play_gameover_music
    @usegobgm = V_OPTS::Specs::Use_Game_Over_BGM
    @usegofg = V_OPTS::Specs::Use_Game_Over_Foreground
    gobgm = V_OPTS::Specs::Game_Over_BGM
    RPG::BGM.stop
    RPG::BGS.stop
   
    if @usegobgm
      then RPG::BGM.new(*gobgm).play
    else
      $data_system.gameover_me.play
    end

  end

  #--------------------------------------------------------------------------
  # * Determine if mg is used
  #--------------------------------------------------------------------------

  def determine_layers
    @usegomg = V_OPTS::Specs::Use_Game_Over_Midground
   
    if @usegomg
      then
      determine_top_layer
    else
      create_foreground
    end
       
  end

  #--------------------------------------------------------------------------
  # * Determine top layer
  #--------------------------------------------------------------------------

  def determine_top_layer
    @usegofg = V_OPTS::Specs::Use_Game_Over_Foreground
   
    if @usegofg
      then
      create_base_midground
      create_foreground
    else
      create_midground
    end
   
  end

  #--------------------------------------------------------------------------
  # * Create Base Background
  #--------------------------------------------------------------------------

  def create_base_background
    @gobackground_sprite = Sprite.new
    @gobackground_sprite.bitmap = Cache.picture(V_OPTS::Specs::Game_Over_BG_File_Name)
    @gobackground_sprite.x = V_OPTS::Specs::Game_Over_BG_x_position
    @gobackground_sprite.y = V_OPTS::Specs::Game_Over_BG_y_position
    @gobackground_sprite.zoom_x= Graphics.width.to_f / @gobackground_sprite.width / 100 * V_OPTS::Specs::Game_Over_BG_Zoom
    @gobackground_sprite.zoom_y = Graphics.height.to_f / @gobackground_sprite.height / 100 * V_OPTS::Specs::Game_Over_BG_Zoom
    @gobackground_sprite.opacity = V_OPTS::Specs::Game_Over_BG_Opacity
    @gobackground_sprite.visible = true
  end
   
  #--------------------------------------------------------------------------
  # * Create Base Mid-Ground
  #--------------------------------------------------------------------------

  def create_base_midground
    @gomidground_sprite = Sprite.new
    @gomidground_sprite.bitmap = Cache.picture(V_OPTS::Specs::Game_Over_MG_File_Name)
    @gomidground_sprite.x = V_OPTS::Specs::Game_Over_MG_x_position
    @gomidground_sprite.y = V_OPTS::Specs::Game_Over_MG_y_position
    @gomidground_sprite.z = 50
    @gomidground_sprite.zoom_x= Graphics.width.to_f / @gomidground_sprite.width / 100 * V_OPTS::Specs::Game_Over_MG_Zoom
    @gomidground_sprite.zoom_y = Graphics.height.to_f / @gomidground_sprite.height / 100 * V_OPTS::Specs::Game_Over_MG_Zoom
    @gomidground_sprite.opacity = V_OPTS::Specs::Game_Over_MG_Opacity
    @gomidground_sprite.visible = true
  end
   
  #--------------------------------------------------------------------------
  # * Create Foreground
  #--------------------------------------------------------------------------

  def create_foreground
    @gotext = V_OPTS::Specs::Draw_Game_Over_Vocab
    @textcolor = V_OPTS::Specs::Draw_Game_Over_Font_Color
    @usevgoscreen = V_OPTS::Specs::Use_Draw_Game_Over
    gotext = V_OPTS::Specs::Draw_Game_Over_Vocab
    textcolor = @textcolor
   
  if @usevgoscreen
    then
      @goforeground_sprite = Sprite.new
      @goforeground_sprite.bitmap = Cache.picture(V_OPTS::Specs::Game_Over_FG_File_Name)
      @goforeground_sprite.x = V_OPTS::Specs::Game_Over_FG_x_position
      @goforeground_sprite.y = V_OPTS::Specs::Game_Over_FG_y_position
      @goforeground_sprite.z = 100
      @goforeground_sprite.zoom_x= Graphics.width.to_f / @goforeground_sprite.width / 100 * V_OPTS::Specs::Game_Over_FG_Zoom
      @goforeground_sprite.zoom_y = Graphics.height.to_f / @goforeground_sprite.height / 100 * V_OPTS::Specs::Game_Over_FG_Zoom
      @goforeground_sprite.opacity = V_OPTS::Specs::Game_Over_FG_Opacity
      @goforeground_sprite.visible = true
      @goforeground_sprite.bitmap.font.size = V_OPTS::Specs::Draw_Game_Over_Font_Size
      @goforeground_sprite.bitmap.font.color.set(*textcolor)
      rect_x = V_OPTS::Specs::Draw_Game_Over_x_position
      rect_y = V_OPTS::Specs::Draw_Game_Over_x_position
      rect = Rect.new(*rect_x, *rect_y, Graphics.width, Graphics.height / 2)
      @goforeground_sprite.bitmap.draw_text(rect, *gotext, 1)
    else
      @goforeground_sprite = Sprite.new
      @goforeground_sprite.bitmap = Cache.picture(V_OPTS::Specs::Game_Over_FG_File_Name)
      @goforeground_sprite.x = V_OPTS::Specs::Game_Over_FG_x_position
      @goforeground_sprite.y = V_OPTS::Specs::Game_Over_FG_y_position
      @goforeground_sprite.z = 100
      @goforeground_sprite.zoom_x= Graphics.width.to_f / @goforeground_sprite.width / 100 * V_OPTS::Specs::Game_Over_FG_Zoom
      @goforeground_sprite.zoom_y = Graphics.height.to_f / @goforeground_sprite.height / 100 * V_OPTS::Specs::Game_Over_FG_Zoom
      @goforeground_sprite.opacity = V_OPTS::Specs::Game_Over_FG_Opacity
      @goforeground_sprite.visible = true
    end
   
  end
   
  #--------------------------------------------------------------------------
  # * Create Mid-Ground
  #--------------------------------------------------------------------------

  def create_mid_ground
    @gotext = V_OPTS::Specs::Draw_Game_Over_Vocab
    @textcolor = V_OPTS::Specs::Draw_Game_Over_Font_Color
    @usevgoscreen = V_OPTS::Specs::Use_Draw_Game_Over
    gotext = V_OPTS::Specs::Draw_Game_Over_Vocab
    textcolor = @textcolor
   
  if @usevgoscreen
    then
      @gomidground_sprite = Sprite.new
      @gomidground_sprite.bitmap = Cache.picture(V_OPTS::Specs::Game_Over_MG_File_Name)
      @gomidground_sprite.x = V_OPTS::Specs::Game_Over_MG_x_position
      @gomidground_sprite.y = V_OPTS::Specs::Game_Over_MG_y_position
      @gomidground_sprite.z = 50
      @gomidground_sprite.zoom_x= Graphics.width.to_f / @gomidground_sprite.width / 100 * V_OPTS::Specs::Game_Over_MG_Zoom
      @gomidground_sprite.zoom_y = Graphics.height.to_f / @gomidground_sprite.height / 100 * V_OPTS::Specs::Game_Over_MG_Zoom
      @gomidground_sprite.opacity = V_OPTS::Specs::Game_Over_MG_Opacity
      @gomidground_sprite.visible = true
      @gomidground_sprite.bitmap.font.size = V_OPTS::Specs::Draw_Game_Over_Font_Size
      @gomidground_sprite.bitmap.font.color.set(*textcolor)
      rect_x = V_OPTS::Specs::Draw_Game_Over_x_position
      rect_y = V_OPTS::Specs::Draw_Game_Over_x_position
      rect = Rect.new(*rect_x, *rect_y, Graphics.width, Graphics.height / 2)
      @gomidground_sprite.bitmap.draw_text(rect, *gotext, 1)
    else
      @gomidground_sprite = Sprite.new
      @gomidground_sprite.bitmap = Cache.picture(V_OPTS::Specs::Game_Over_MG_File_Name)
      @gomidground_sprite.x = V_OPTS::Specs::Game_Over_MG_x_position
      @gomidground_sprite.y = V_OPTS::Specs::Game_Over_MG_y_position
      @gomidground_sprite.z = 50
      @gomidground_sprite.zoom_x= Graphics.width.to_f / @gomidground_sprite.width / 100 * V_OPTS::Specs::Game_Over_MG_Zoom
      @gomidground_sprite.zoom_y = Graphics.height.to_f / @gomidground_sprite.height / 100 * V_OPTS::Specs::Game_Over_MG_Zoom
      @gomidground_sprite.opacity = V_OPTS::Specs::Game_Over_MG_Opacity
      @gomidground_sprite.visible = true
    end
   
  end
   
  #--------------------------------------------------------------------------
  # * Create Background
  #--------------------------------------------------------------------------

  def create_background
    @gotext = V_OPTS::Specs::Draw_Game_Over_Vocab
    @textcolor = V_OPTS::Specs::Draw_Game_Over_Font_Color
    @usevgoscreen = V_OPTS::Specs::Use_Draw_Game_Over
    gotext = V_OPTS::Specs::Draw_Game_Over_Vocab
    textcolor = @textcolor
   
    if @usevgoscreen
    then
      @gobackground_sprite = Sprite.new
      @gobackground_sprite.bitmap = Cache.picture(V_OPTS::Specs::Game_Over_BG_File_Name)
      @gobackground_sprite.x = V_OPTS::Specs::Game_Over_BG_x_position
      @gobackground_sprite.y = V_OPTS::Specs::Game_Over_BG_y_position
      @gobackground_sprite.zoom_x= Graphics.width.to_f / @gobackground_sprite.width / 100 * V_OPTS::Specs::Game_Over_BG_Zoom
      @gobackground_sprite.zoom_y = Graphics.height.to_f / @gobackground_sprite.height / 100 * V_OPTS::Specs::Game_Over_BG_Zoom
      @gobackground_sprite.opacity = V_OPTS::Specs::Game_Over_BG_Opacity
      @gobackground_sprite.visible = true
      @gobackground_sprite.bitmap.font.size = V_OPTS::Specs::Draw_Game_Over_Font_Size
      @gobackground_sprite.bitmap.font.color.set(*textcolor)
      @gobackground_sprite.bitmap.font.bold = V_OPTS::Specs::Draw_Game_Over_Font_Bold
      @gobackground_sprite.bitmap.font.italic = V_OPTS::Specs::Draw_Game_Over_Font_Italic
      @gobackground_sprite.bitmap.font.shadow = V_OPTS::Specs::Draw_Game_Over_Font_Shadow
      rect_x = V_OPTS::Specs::Draw_Game_Over_x_position
      rect_y = V_OPTS::Specs::Draw_Game_Over_x_position
      rect = Rect.new(*rect_x, *rect_y, Graphics.width, Graphics.height / 2)
      @gobackground_sprite.bitmap.draw_text(rect, *gotext, 1)
    else
      @gobackground_sprite = Sprite.new
      @gobackground_sprite.bitmap = Cache.picture(V_OPTS::Specs::Game_Over_BG_File_Name)
      @gobackground_sprite.x = V_OPTS::Specs::Game_Over_BG_x_position
      @gobackground_sprite.y = V_OPTS::Specs::Game_Over_BG_y_position
      @gobackground_sprite.zoom_x= Graphics.width.to_f / @gobackground_sprite.width / 100 * V_OPTS::Specs::Game_Over_BG_Zoom
      @gobackground_sprite.zoom_y = Graphics.height.to_f / @gobackground_sprite.height / 100 * V_OPTS::Specs::Game_Over_BG_Zoom
      @gobackground_sprite.opacity = V_OPTS::Specs::Game_Over_BG_Opacity
      @gobackground_sprite.visible = true
    end

  end

  #--------------------------------------------------------------------------
  # * Free Background
  #--------------------------------------------------------------------------

  def dispose_background
    @usegomg = V_OPTS::Specs::Use_Game_Over_Midground
    @usegofg = V_OPTS::Specs::Use_Game_Over_Foreground
   
   
    if @usegomg
      then
      @gomidground_sprite.bitmap.dispose
      @gomidground_sprite.dispose
    end
   
    if @usegofg
      then
      @goforeground_sprite.bitmap.dispose
      @goforeground_sprite.dispose
    end
   
    @gobackground_sprite.bitmap.dispose
    @gobackground_sprite.dispose
  end

end





#==============================================================================
# ** Sprite_Character
#------------------------------------------------------------------------------
#  This sprite is used to display characters. It observes an instance of the
# Game_Character class and automatically changes sprite state.
#==============================================================================

class Sprite_Character < Sprite_Base
  #--------------------------------------------------------------------------
  # * For Aliasing
  #--------------------------------------------------------------------------

  alias v_seonballoon_sprite_chara_jh654                        start_balloon
  
  #--------------------------------------------------------------------------
  # * Start Balloon Icon Display
  #--------------------------------------------------------------------------
  def start_balloon
    unless $game_switches[V_OPTS::Specs::Event_Switch]
    case @balloon_id
    when 1
     RPG::SE.new(*V_OPTS::Specs::Exclamation_SE).play  if V_OPTS::Specs::Exclamation_SE[0]
    when 2
     RPG::SE.new(*V_OPTS::Specs::Question_SE).play     if V_OPTS::Specs::Question_SE[0]
    when 3
     RPG::SE.new(*V_OPTS::Specs::Music_Note_SE).play   if V_OPTS::Specs::Music_Note_SE[0]
    when 4
     RPG::SE.new(*V_OPTS::Specs::Heart_SE).play        if V_OPTS::Specs::Heart_SE[0]
    when 5
     RPG::SE.new(*V_OPTS::Specs::Anger_SE).play        if V_OPTS::Specs::Anger_SE[0]
    when 6
     RPG::SE.new(*V_OPTS::Specs::Sweat_SE).play        if V_OPTS::Specs::Sweat_SE[0]
    when 7
     RPG::SE.new(*V_OPTS::Specs::Cobweb_SE).play       if V_OPTS::Specs::Cobweb_SE[0]
    when 8
     RPG::SE.new(*V_OPTS::Specs::Silence_SE).play      if V_OPTS::Specs::Silence_SE[0]
    when 9
     RPG::SE.new(*V_OPTS::Specs::Lightbulb_SE).play    if V_OPTS::Specs::Lightbulb_SE[0]
    when 10
     RPG::SE.new(*V_OPTS::Specs::Zzz_SE).play          if V_OPTS::Specs::Zzz_SE[0]
    end
  end
  v_seonballoon_sprite_chara_jh654()
  end
end