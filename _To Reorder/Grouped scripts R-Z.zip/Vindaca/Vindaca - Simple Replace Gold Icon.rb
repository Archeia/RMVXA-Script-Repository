#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
#                                                                              #
#                             V's  Simple Replace:                             #
#                                  Gold  Icon                                  #
#                                 Version  0.2                                 #
#                                                                              #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#                                Written By:  V                                #
#                        Last Edited: February 21, 2013                        #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#                                                                              #
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
 
 
#==============================================================================#
#------------------------------------------------------------------------------#
# ** Disclaimer                                                                #
#------------------------------------------------------------------------------#
#                                                                              #
# This script was intended for Non-commercial use only, if you wish to use     #
# this script in a commercial game please PM me at which ever site you found   #
# this script. Either way please give me credit in your game script as the     #
# writer of this script, and send me a PM abuot the release of the game/demo.  #
#                                                                              #
#------------------------------------------------------------------------------#
# ** How To Use                                                                #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#                                                                              #
#  * This script is Plug & Play.                                               #
#                                                                              #
#------------------------------------------------------------------------------#
# ** Description                                                               #
#------------------------------------------------------------------------------#
#                                                                              #
#  v0.1                                                                        #
# ~=~=~=~                                                                      #
#                                                                              #
# * In v0.1, this script replaces gold vocab with an icon in the Gold window.  #
# It also replaces game message's \g with an icon, however the gold vocab is   #
# still available with \gv instead.                                            #
#                                                                              #
#  v0.2                                                                        #
# ~=~=~=~                                                                      #
#                                                                              #
# * I added an option to change the Gold Window vocab to an icon. I also added #
# the same escape characters to the Choices Window as the Message Window.      # 
#                                                                              #
#------------------------------------------------------------------------------#
#==============================================================================#
 
#==============================================================================
# ** V's Simple Replace: Gold Icon
#------------------------------------------------------------------------------
#  This module manages customizable features and methods.
#==============================================================================

module V_Simple_Replace_Gold_Icon
  module Specs
  
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
#                                                                              #
#                           Start Customizable Area.                           #
#                                                                              #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#                                                                              #
#                      ONLY EDIT AFTER THE EQUALS SYMBOL.                      #
#                                                                              #
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
   

  #=============================================================================
  # Gold Icon:
  #=============================================================================
  Gold_Icon = 361
  
  #=============================================================================
  # Change the Gold Window Vocab Into an Icon:
  #=============================================================================
  Change_Gold_Window = false
  
  
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
#                                                                              #
#                            End Customizable Area.                            #
#                                                                              #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#                                                                              #
#         DO NOT EDIT PAST THIS POINT UNLESS YOU KNOW WHAT YOUR DOING.         #
#                                                                              #
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
   
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 


















 
end
end


#==============================================================================
# ** Window_Base
#------------------------------------------------------------------------------
#  This is a super class of all windows within the game.
#==============================================================================

class Window_Base < Window
  
  #--------------------------------------------------------------------------
  # * Include Module
  #--------------------------------------------------------------------------
  include V_Simple_Replace_Gold_Icon::Specs
    
  #--------------------------------------------------------------------------
  # * Draw Number (Gold Etc.) with Currency Unit
  #--------------------------------------------------------------------------
  def draw_currency_value(value, unit, x, y, width)
    cx = text_size(unit).width
    change_color(normal_color)
    draw_text(x - 5, y, width - cx - 2, line_height, value, 2)
    change_color(system_color)
    if Change_Gold_Window != true
      draw_text(x, y, width, line_height, unit, 2)
    else
      draw_text(x, y, width, line_height, unit, 2) unless unit == Vocab::currency_unit
      draw_icon(Gold_Icon, width - 14, y) if unit == Vocab::currency_unit
    end
  end
  
  #--------------------------------------------------------------------------
  # * Preconvert Control Characters
  #    As a rule, replace only what will be changed into text strings before
  #    starting actual drawing. The character "\" is replaced with the escape
  #    character (\e).
  #--------------------------------------------------------------------------
  def convert_escape_characters(text)
    result = text.to_s.clone
    result.gsub!(/\\/)            { "\e" }
    result.gsub!(/\e\e/)          { "\\" }
    result.gsub!(/\eV\[(\d+)\]/i) { $game_variables[$1.to_i] }
    result.gsub!(/\eV\[(\d+)\]/i) { $game_variables[$1.to_i] }
    result.gsub!(/\eN\[(\d+)\]/i) { actor_name($1.to_i) }
    result.gsub!(/\eP\[(\d+)\]/i) { party_member_name($1.to_i) }
    result.gsub!(/\eGV/i)         { Vocab::currency_unit }
    result
  end

end


#==============================================================================
# ** Window_ChoiceList
#------------------------------------------------------------------------------
#  This window is used for the event command [Show Choices].
#==============================================================================

class Window_ChoiceList < Window_Command

  #--------------------------------------------------------------------------
  # * Method for Aliasing: Control Character Processing
  #--------------------------------------------------------------------------
  alias :wclpec24324321 :process_escape_character
    
  #--------------------------------------------------------------------------
  # * Control Character Processing
  #     code : the core of the control character
  #            e.g. "C" in the case of the control character \C[1].
  #     text : character string buffer in drawing processing (destructive)
  #     pos  : draw position {:x, :y, :new_x, :height}
  #--------------------------------------------------------------------------
  def process_escape_character(code, text, pos)
    case code.upcase
    when 'G'
      process_draw_icon(Gold_Icon, pos)
    end
    wclpec24324321(code, text, pos)
  end
  
end


#==============================================================================
# ** Window_Message
#------------------------------------------------------------------------------
#  This message window is used to display text.
#==============================================================================

class Window_Message < Window_Base

  #--------------------------------------------------------------------------
  # * Include Module
  #--------------------------------------------------------------------------
  include V_Simple_Replace_Gold_Icon::Specs
    
  #--------------------------------------------------------------------------
  # * Method for Aliasing: Control Character Processing
  #--------------------------------------------------------------------------
  alias :wmpec064506406 :process_escape_character
    
  #--------------------------------------------------------------------------
  # * Control Character Processing
  #     code : the core of the control character
  #            e.g. "C" in the case of the control character \C[1].
  #     text : character string buffer in drawing processing (destructive)
  #     pos  : draw position {:x, :y, :new_x, :height}
  #--------------------------------------------------------------------------
  def process_escape_character(code, text, pos)
    case code.upcase
    when 'G'
      process_draw_icon(Gold_Icon, pos)
    end
    wmpec064506406(code, text, pos)
  end
  
end