#==============================================================================
# ** Window_MenuCommand
#------------------------------------------------------------------------------
# This command window appears on the menu screen.
#==============================================================================

class Window_MenuCommand < Window_Command
#--------------------------------------------------------------------------
# * Alias Listing
#--------------------------------------------------------------------------
alias tds_status_distribution_window_menucommand_add_original_commands add_original_commands
#--------------------------------------------------------------------------
# * For Adding Original Commands
#--------------------------------------------------------------------------
def add_original_commands(*args, &block)
	# Run Original Method
	tds_status_distribution_window_menucommand_add_original_commands(*args, &block)
	# Add Stat Distribution Command
	add_command("Stat Change", :stat_change)
end
end


#==============================================================================
# ** Scene_Menu
#------------------------------------------------------------------------------
# This class performs the menu screen processing.
#==============================================================================

class Scene_Menu < Scene_MenuBase
#--------------------------------------------------------------------------
# * Alias Listing
#--------------------------------------------------------------------------
alias tds_status_distribution_scene_menu_create_command_window create_command_window
alias tds_status_distribution_scene_menu_on_personal_ok		on_personal_ok
#--------------------------------------------------------------------------
# * Create Command Window
#--------------------------------------------------------------------------
def create_command_window(*args, &block)
	# Run Original Method
	tds_status_distribution_scene_menu_create_command_window(*args, &block)
	# Set Command Window Handlers
	@command_window.set_handler(:stat_change, method(:command_personal))	
end
#--------------------------------------------------------------------------
# * [OK] Personal Command
#--------------------------------------------------------------------------
def on_personal_ok(*args, &block)
	# Run Original Method
	tds_status_distribution_scene_menu_on_personal_ok(*args, &block)
	# Command Window Current Symbol Case
	case @command_window.current_symbol
	when :stat_change ; SceneManager.call(Scene_Status_Distribution)
	end
end	
end