#==============================================================================
# ** TDS Change Message Window Z
#    Ver: 1.0
#------------------------------------------------------------------------------
#  * Description:
#  This script allows you to change the Z value of the message window.
#------------------------------------------------------------------------------
#  * Features: 
#  Changing the Z value of the Message Window.
#------------------------------------------------------------------------------
#  * Instructions:
#    To set the default message z variable ID (Message Z will be the same as
#    variable value) change this constant in the script:
#
#      DEFAULT_MESSAGE_Z_VARIABLE_ID = variable_ID
#
#      variable_ID = ID of the variable (If 0 it is ignored)
#
#      Example:
#
#      DEFAULT_MESSAGE_Z_VARIABLE_ID = 1
#      
#    To make the Default Message Z Variable update when the message window 
#    Z script calls are used, change this constant in the script:
#
#      UPDATE_DEFAULT_MESSAGE_Z_VARIABLE = True or False
#
#    To make the message window appear below pictures, use this in a script
#    call:
#
#      put_message_window_below_pictures
# 
#   To reset the message window Z back to it's default value (200), use
#   this in a script call:
#
#     reset_message_window_z 
#
#   To set an exact Z value for the message window, use this in a script 
#   call:
#     
#     change_message_window_z(Z)
#
#     Z = Z Value
#
#     Example: 
#
#     change_message_window_z(500)
#------------------------------------------------------------------------------
#  * Notes:
#------------------------------------------------------------------------------
# WARNING:
#
# Do not release, distribute or change my work without my expressed written 
# consent, doing so violates the terms of use of this work.
#
# If you really want to share my work please just post a link to the original
# site.
#
# * Not Knowing English or understanding these terms will not excuse you in any
#   way from the consequenses.
#==============================================================================
# * Import to Global Hash *
#==============================================================================
($imported ||= {})[:TDS_Change_Message_Window_Z] = true

#==============================================================================
# ** Game_Interpreter
#------------------------------------------------------------------------------
#  An interpreter for executing event commands. This class is used within the
# Game_Map, Game_Troop, and Game_Event classes.
#==============================================================================

class Game_Interpreter  
  #--------------------------------------------------------------------------
  # * Constants (Settings)
  #--------------------------------------------------------------------------
  # Default Message Z Variable ID (Set to 0 to not use)
  DEFAULT_MESSAGE_Z_VARIABLE_ID = 6
  # Update Default Message Z Variable when changing message window z flag
  UPDATE_DEFAULT_MESSAGE_Z_VARIABLE = true
  #--------------------------------------------------------------------------
  # * Alias Listings
  #--------------------------------------------------------------------------
  alias tds_change_window_message_z_game_interepeter_command_101 command_101
  #--------------------------------------------------------------------------
  # * Show Text
  #--------------------------------------------------------------------------
  def command_101(*args, &block)
    # If Message Z Variable ID is more than 0
    if DEFAULT_MESSAGE_Z_VARIABLE_ID > 0
      # Set Message Window Z Value to Default Message Z Variable
      change_message_window_z($game_variables[DEFAULT_MESSAGE_Z_VARIABLE_ID])
    end    
    # Run Original Method
    tds_change_window_message_z_game_interepeter_command_101(*args, &block)
  end
  #--------------------------------------------------------------------------
  # * Reset Message Window Z Value to original
  #--------------------------------------------------------------------------
  def reset_message_window_z 
    # Change Message Window Z and Update Default Message Z Variable
    change_message_window_z(200) ; update_default_message_z_variable(200) 
  end
  #--------------------------------------------------------------------------
  # * Put Message Window Below Pictures
  #--------------------------------------------------------------------------
  def put_message_window_below_pictures 
    # Change Message Window Z and Update Default Message Z Variable
    change_message_window_z(49) ; update_default_message_z_variable(49)     
  end    
  #--------------------------------------------------------------------------
  # * Get Target of Screen Command
  #     z : z value
  #--------------------------------------------------------------------------
  def change_message_window_z(z)
    # Update Default Messsage Z Variable
    update_default_message_z_variable(z)    
    # If on Scene Map or Scene Battle
    if SceneManager.scene_is?(Scene_Map) or SceneManager.scene_is?(Scene_Battle)   
      # Get Window
      window = SceneManager.scene.instance_variable_get(:@message_window)  
      # Set Window Z if window is not nil
      window.z = z if !window.nil?
    end    
  end
  #--------------------------------------------------------------------------
  # * Update the Default Message Z Variable Value
  #     z : z value
  #--------------------------------------------------------------------------
  def update_default_message_z_variable(z)
    # If Default Message Z Variable ID is more than 0 and it should update    
    if DEFAULT_MESSAGE_Z_VARIABLE_ID > 0 and UPDATE_DEFAULT_MESSAGE_Z_VARIABLE
      # Set Default Message Z Value
      $game_variables[DEFAULT_MESSAGE_Z_VARIABLE_ID] = z
    end    
  end
end


#==============================================================================
# ** Window_Message
#------------------------------------------------------------------------------
#  This message window is used to display text.
#==============================================================================

class Window_Message < Window_Base
  #--------------------------------------------------------------------------
  # * Alias Listings
  #--------------------------------------------------------------------------
  alias tds_change_window_message_z_window_message_update_back_sprite update_back_sprite
  #--------------------------------------------------------------------------
  # * Update Background Sprite
  #--------------------------------------------------------------------------
  def update_back_sprite(*args, &block)
    # Run Original Method
    tds_change_window_message_z_window_message_update_back_sprite(*args, &block)
    # Update Back Sprite Z Value
    @back_sprite.z = z
  end  
end
