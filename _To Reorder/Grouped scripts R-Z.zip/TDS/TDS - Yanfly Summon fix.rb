#==============================================================================
# ■ Window_PartyList
#==============================================================================
class Window_PartyList < Window_Selectable
#————————————————————————–
# make_item_list
#————————————————————————–
def make_item_list
@data = []
for member in $game_party.all_members
next if member.nil?
@data.push(member.id)
end
end
#————————————————————————–
# draw_actor
#————————————————————————–
def draw_actor(actor, rect)
buffer = YEA::PARTY::ACTOR_Y_BUFFER
draw_actor_graphic(actor, rect.x + 16, rect.y + rect.height + buffer)
text = actor.name
change_color(list_colour(actor), enabled?(actor))
draw_text(rect.x+32, rect.y, rect.width-32, line_height, text)
contents.clear_rect(rect.x, rect.y + 24, rect.width, 24)
end
end