#==============================================================================
# ■ Control Character Color Expansion
# By ：VIPArcher [email: VIPArcher@sina.com]
#  -- The script comes from http://rm.66rpg.com Please keep the information above.
#  Feel free to use/ reprint
#==============================================================================
$VIPArcherScript ||= {};$VIPArcherScript[:textcolor] = 20141012
#--------------------------------------------------------------------------------
module VIPArcher
  Text_Color = { #<-This line should not be deleted
   #color number  #color code(R  , G  , B [,A ]),
    32 => Color.new(0  , 0  , 255,255),
    33 => Color.new(0  , 255, 0      ),
    34 => Color.new(255, 0  , 0      ),
    35 => Color.new(233, 233, 233    )
    #to continue, add here
    };Text_Color.default = Color.new #<-This line should not be deleted
end
#--------------------------------------------------------------------------------
class Window_Base < Window
  #--------------------------------------------------------------------------
  # ● Get text color
  #     n : Text color number（0..31）
  #--------------------------------------------------------------------------
  alias vip_ex_text_color text_color
  def text_color(n)
    return VIPArcher::Text_Color[n] if n > 31
    vip_ex_text_color(n)
  end
end