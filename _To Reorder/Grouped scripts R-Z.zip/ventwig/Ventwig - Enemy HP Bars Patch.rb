# Enemy HP Bars and Wound Damage *Patch*
# Requires both scripts
# Both Scripts by Ventwig
 
class Window_Enemy_Hud < Window_Base
  if EHUD::NEO_ULTIMATE_ACE == false
   def draw_actor_hp(actor, x, y, width = 124)
    draw_hp_gauge(x, y, width, actor.hp_rate, actor.mhp_rate, hp_gauge_color1, hp_gauge_color2)
    change_color(system_color)
    draw_text(x, y, 30, line_height, Vocab::hp_a) if EHUD::DRAW_HP_VOCAB == true
    change_color(hp_color(actor))
    draw_text(x+width/4*3, y, 100, line_height, actor.hp) if EHUD::DRAW_HP_NUMBERS == true
    change_color(system_color)
    end
    
    def draw_hp_gauge(x, y, width, rate, rate2, color1, color2)
      fill_w2 = (width * rate2).to_i
      fill_w = (width * rate).to_i
      gauge_y = y + line_height - 8
      contents.fill_rect(x, gauge_y, width, 6, gauge_back_color)
      contents.gradient_fill_rect(x, gauge_y, fill_w2, 6, text_color(VTS_WOUNDS::WOUND_COLOR1), text_color(VTS_WOUNDS::WOUND_COLOR2))
      contents.gradient_fill_rect(x, gauge_y, fill_w, 6, color1, color2)
    end
  else
    def draw_actor_hp(actor, x, y, width = 124)
      gwidth = width * actor.hp_rate# / actor.omhp
      gwidth2 = width * actor.mhp_rate# / actor.omhp
      cg = neo_gauge_back_color
      c1, c2, c3 = cg[0], cg[1], cg[2]
      draw_neo_gauge(x + HPMP_GAUGE_X_PLUS, y + line_height - 8 +
        HPMP_GAUGE_Y_PLUS, width, HPMP_GAUGE_HEIGHT, c1, c2, c3)
        
      (1..3).each {|i| eval("c#{i} = WHP_GCOLOR_#{i}")}
      draw_neo_gauge(x + HPMP_GAUGE_X_PLUS, y + line_height - 8 +
        HPMP_GAUGE_Y_PLUS, gwidth2, HPMP_GAUGE_HEIGHT, c1, c2, c3, false, false,
        width, 30)
        
      (1..3).each {|i| eval("c#{i} = HP_GCOLOR_#{i}")}
      draw_neo_gauge(x + HPMP_GAUGE_X_PLUS, y + line_height - 8 +
        HPMP_GAUGE_Y_PLUS, gwidth, HPMP_GAUGE_HEIGHT, c1, c2, c3, false, false,
        width, 30)
      change_color(system_color)
    draw_text(x, y, 30, line_height, Vocab::hp_a) if EHUD::DRAW_HP_VOCAB == true
       change_color(hp_color(actor))
    draw_text(x+width/4*3, y, 100, line_height, actor.hp) if EHUD::DRAW_HP_NUMBERS == true
       change_color(system_color)
    end
  end
end