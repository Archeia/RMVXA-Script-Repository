#============================================================================
#Simple Face HUD
#By Ventwig
#Version 1.3 - April 07 2012
#For RPGMaker VX Ace
#============================================================================
# This is my first script :)
# Since I'm new, I know stuff in this script can be simplified, but oh well
# I decided to try scripting and learned through some videos and the help
# of amazing members on the forums :D
# Also, thanks to XAIL's Simple Gold HUD, I was able to learn off of
# it. For the stuff to show on the map.
#=============================================================================
# Description:
# This piece of code let's you show the player's party (Max 4, Min 1) on the
# top of the screen. It shows the faces of the current party members.
# Only the first four in the party, which is good because there's usually only
# 4 active at a time. You can choose to display names, and choose which
# gauges to be shown, or even draw the sprite graphic!
# Anyways, it centers the faces, too :)
#==============================================================================
# Compatability:
#  alias-es Scene_Map
#  Works with Neo Gauge Ultimate Ace
#===============================================================================
# Instructions: Put in materials, above main. Almost Plug and Play
# Put above Neo Gauge Ultimate Ace if used
#==============================================================================

class Window_Face_Hud < Window_Base
  #########################################################################
  #Configuration! Three of them!                                                                                  #
  #########################################################################
  #Draw the actors' names on the top of the face? true/false default = true
  DRAW_NAME = true
  #Choos which bars to draw. 1 = HP 2 = MP
  #0 = Both      Anything Higher means none
  #default = 0
  DRAW_BARS = 0
  #Selects whether or not to draw the actor's sprite over their face
  DRAW_SPRITE = true
  #Switch to show/hide HUD. Recommended to hide HUD during cut-scenes.
  #default = 100
  #Hide if it is off (default value of switches)
  HIDE_SWITCH = 100
  #########################################################################
  #End Of configuration. Touch anything below and it'll delete system32   #
  #########################################################################

  ###################################################################
  #Sets up what appears in the HUD
  #Questions names and HUD, then displays them
  #################################################################  
  #Set up the window's start-up
  def initialize
        #Draws window
        super(0,0,545,120)
        @x, @y = 5, 50
        @party_size = $game_party.all_members.size
        @switch_current = $game_switches[HIDE_SWITCH]
        face_hud
        check_visible
  end

  def face_hud
        #If branches for each party size to set the positioning of items
        if $game_party.all_members.size == 1
          @actor = $game_party.members[0]
          @actor_hp = @actor.hp
          @actor_mp = @actor.mp
          draw_actor_face(@actor, @x+189, @y-50, enabled = true)
          if DRAW_SPRITE == true
                draw_actor_graphic(@actor, @x+10+189, @y+20)
          end
          if DRAW_BARS == 0
                draw_actor_hp(@actor, @x-5+189, @y-50+75-17)
                draw_actor_mp(@actor, @x-5+189, @y-50+75)
          end
          if DRAW_BARS == 1
                draw_actor_hp(@actor, @x-5+189, @y-50+75)
          end
          if DRAW_BARS == 2
                draw_actor_mp(@actor, @x-5+189, @y-50+75)
          end
          if DRAW_NAME
                draw_actor_name(@actor, @x+190, @y-50)
          end
        end
        if $game_party.all_members.size == 2
          @actor = $game_party.members[0]
          @actor2 = $game_party.members[1]
          @actor_hp = @actor.hp
          @actor_mp = @actor.mp
          @actor2_hp = @actor2.hp
          @actor2_mp = @actor2.mp
          draw_actor_face(@actor, @x+126, @y-50, enabled = true)
          draw_actor_face(@actor2, @x+252, @y-50, enabled = true)
          if DRAW_SPRITE == true
                draw_actor_graphic(@actor, @x+10+126, @y+20)
                draw_actor_graphic(@actor2, @x+10+252, @y+20)
          end
          if DRAW_BARS == 0
                draw_actor_hp(@actor, @x-5+126, @y-50+75-17)
                draw_actor_hp(@actor2, @x-5+252, @y-50+75-17)
                draw_actor_mp(@actor, @x-5+126, @y-50+75)
                draw_actor_mp(@actor2, @x-5+252, @y-50+75)
          end
          if DRAW_BARS == 1
                draw_actor_hp(@actor, @x-5+126, @y-50+75)
                draw_actor_hp(@actor2, @x-5+252, @y-50+75)
          end
          if DRAW_BARS == 2
                draw_actor_mp(@actor, @x-5+126, @y-50+75)
                draw_actor_mp(@actor2, @x-5+252, @y-50+75)
          end
          if DRAW_NAME
                draw_actor_name(@actor, @x+126, @y-50)
                draw_actor_name(@actor2, @x+252, @y-50)
          end
        end
        if $game_party.all_members.size == 3
          @actor = $game_party.members[0]
          @actor2 = $game_party.members[1]
          @actor3 = $game_party.members[2]
          @actor_hp = @actor.hp
          @actor_mp = @actor.mp
          @actor2_hp = @actor2.hp
          @actor2_mp = @actor2.mp
          @actor3_hp = @actor3.hp
          @actor3_mp = @actor3.mp
          draw_actor_face(@actor, @x+63, @y-50, enabled = true)
          draw_actor_face(@actor2, @x+189, @y-50, enabled = true)
          draw_actor_face(@actor3, @x+315, @y-50, enabled = true)  
          if DRAW_SPRITE == true
                draw_actor_graphic(@actor, @x+10+63, @y+20)
                draw_actor_graphic(@actor2, @x+10+189, @y+20)
                draw_actor_graphic(@actor3, @x+10+315, @y+20)
          end
          if DRAW_BARS == 0
                draw_actor_hp(@actor, @x-5+63, @y-50+75-17)
                draw_actor_hp(@actor2, @x-5+189, @y-50+75-17)
                draw_actor_hp(@actor3, @x-5+315, @y-50+75-17)
                draw_actor_mp(@actor, @x-5+63, @y-50+75)
                draw_actor_mp(@actor2, @x-5+189, @y-50+75)
                draw_actor_mp(@actor3, @x-5+315, @y-50+75)
          end
          if DRAW_BARS == 1
                draw_actor_hp(@actor, @x-5+63, @y-50+75)
                draw_actor_hp(@actor2, @x-5+189, @y-50+75)
                draw_actor_hp(@actor3, @x-5+315, @y-50+75)
          end
          if DRAW_BARS == 2
                draw_actor_mp(@actor, @x-5+63, @y-50+75)
                draw_actor_mp(@actor2, @x-5+189, @y-50+75)
                draw_actor_mp(@actor3, @x-5+315, @y-50+75)
          end
          if DRAW_NAME
                draw_actor_name(@actor, @x+63, @y-50)
                draw_actor_name(@actor2, @x+189, @y-50)
                draw_actor_name(@actor3, @x+315, @y-50)
          end
  end
        if $game_party.all_members.size == 4
          @actor = $game_party.members[0]
          @actor2 = $game_party.members[1]
          @actor3 = $game_party.members[2]
          @actor4 = $game_party.members[3]
          @actor_hp = @actor.hp
          @actor_mp = @actor.mp
          @actor2_hp = @actor2.hp
          @actor2_mp = @actor2.mp
          @actor3_hp = @actor3.hp
          @actor3_mp = @actor3.mp
          @actor4_hp = @actor4.hp
          @actor4_mp = @actor4.mp
          draw_actor_face(@actor, @x, @y-50, enabled = true)
          draw_actor_face(@actor2, @x+126, @y-50, enabled = true)
          draw_actor_face(@actor3, @x+252, @y-50, enabled = true)                       
          draw_actor_face(@actor4, @x+378, @y-50, enabled = true)  
          if DRAW_SPRITE == true
                draw_actor_graphic(@actor, @x+10, @y+20)
                draw_actor_graphic(@actor2, @x+10+126, @y+20)
                draw_actor_graphic(@actor3, @x+10+252, @y+20)
                draw_actor_graphic(@actor4, @x+10+378, @y+20)
          end
          if DRAW_BARS == 0
                draw_actor_hp(@actor, @x-5, @y-50+75-17)
                draw_actor_hp(@actor2, @x-5+126, @y-50+75-17)
                draw_actor_hp(@actor3, @x-5+252, @y-50+75-17)
                draw_actor_hp(@actor4, @x-5+378, @y-50+75-17)
                draw_actor_mp(@actor, @x-5, @y-50+75)
                draw_actor_mp(@actor2, @x-5+126, @y-50+75)
                draw_actor_mp(@actor3, @x-5+252, @y-50+75)
                draw_actor_mp(@actor4, @x-5+378, @y-50+75)
          end
          if DRAW_BARS == 1
                draw_actor_hp(@actor, @x-5, @y-50+75)
                draw_actor_hp(@actor2, @x-5+126, @y-50+75)
                draw_actor_hp(@actor3, @x-5+252, @y-50+75)
                draw_actor_hp(@actor4, @x-5+378, @y-50+75)
          end
          if DRAW_BARS == 2
                draw_actor_mp(@actor, @x-5, @y-50+75)
                draw_actor_mp(@actor2, @x-5+126, @y-50+75)
                draw_actor_mp(@actor3, @x-5+252, @y-50+75)
                draw_actor_mp(@actor4, @x-5+378, @y-50+75)
          end
          if DRAW_NAME
                draw_actor_name(@actor, @x, @y-50)
                draw_actor_name(@actor2, @x+126, @y-50)
                draw_actor_name(@actor3, @x+252, @y-50)
                draw_actor_name(@actor4, @x+378, @y-50)
          end
        end
                  check_visible
  end

  def check_visible
        if $game_switches[HIDE_SWITCH] != @switches_current
          self.visible = $game_switches[HIDE_SWITCH]
          @switches_current = $game_switches[HIDE_SWITCH]
        end
  end


###################################################################
#Refresh the window to show all changes to the HUD
#It just copies the intizalize code.
#Also choose when to update
#################################################################

  def refresh
        contents.clear
        face_hud
        @party_size = $game_party.all_members.size
  end

  def update
        super
        check_visible
        if @party_size != $game_party.all_members.size
          refresh
        end
        if @party_size > 0
          if $game_party.members[0].hp != @actor_hp  or $game_party.members[0].mp != @actor_mp
                refresh
          end
        end
        if @party_size > 1
          if $game_party.members[1].hp != @actor2_hp or $game_party.members[1].mp != @actor2_mp
                refresh
          end
        end  
        if @party_size > 2
          if $game_party.members[2].hp != @actor3_hp or $game_party.members[2].mp != @actor3_mp
                refresh
          end
        end
        if @party_size > 3
          if $game_party.members[3].hp != @actor4_hp or $game_party.members[3].mp != @actor4_mp
                refresh
          end
        end
  end
end  

#Show the window on the map
class Scene_Map < Scene_Base
  alias original_create_all_windows create_all_windows
        def create_all_windows
          original_create_all_windows
          create_face_window
        end
        def create_face_window
          @face_window = Window_Face_Hud.new
        end
end
  #########################################################################
  #End Of Script                                                                                                                  #
  #########################################################################