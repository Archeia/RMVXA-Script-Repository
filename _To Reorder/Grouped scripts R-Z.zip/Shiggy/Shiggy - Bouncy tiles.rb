# https://www.rpgmakercentral.com/topic/40593-repulsion-geltrampoline-tilesbouncey-tiles/?tab=comments#comment-283063
# It works just like the slippery script, but the tags are bouncy and jumpy. 
# Bouncy makes you jump one case and jumpy makes you jump two.
# It doesn't check boundaries so this might get your character out of bounds 
# or in an unvalid spot

module YEA
  module REGEXP
  module TILESET
    BOUNCY = /<(?:BOUNCY|slippery tile):[ ]*(\d+(?:\s*,\s*\d+)*)>/i
    JUMPY = /<(?:JUMPY|slippery tile):[ ]*(\d+(?:\s*,\s*\d+)*)>/i
  end # TILESET
  end # REGEXP
end # YEA
 
class RPG::Tileset
  #--------------------------------------------------------------------------
  # public instance variables
  #--------------------------------------------------------------------------
  attr_accessor :bouncy
  attr_accessor :jumpy
   
  #--------------------------------------------------------------------------
  # common cache: load_notetags_st
  #--------------------------------------------------------------------------
  def load_notetags_st
    @slippery = []
    @bouncy = []
    @jumpy = []
    #---
    self.note.split(/[\r\n]+/).each { |line|
      case line
      #---
      when YEA::REGEXP::TILESET::SLIPPERY
        $1.scan(/\d+/).each { |num| 
        @slippery.push(num.to_i) if num.to_i > 0 }
      #---
      when YEA::REGEXP::TILESET::BOUNCY
        $1.scan(/\d+/).each { |num| 
        @bouncy.push(num.to_i) if num.to_i > 0 }
      #---
      when YEA::REGEXP::TILESET::JUMPY
        $1.scan(/\d+/).each { |num| 
        @jumpy.push(num.to_i) if num.to_i > 0 }
      #---
      end
    } # self.note.split
    #---
  end
   
end # RPG::Tileset
 
#==============================================================================
# ■ Game_Map
#==============================================================================
 
class Game_Map
   
  #--------------------------------------------------------------------------
  # new method: bouncy_floor?
  #--------------------------------------------------------------------------
  def bouncy_floor?(dx, dy)
    return (valid?(dx, dy) && bouncy_tag?(dx, dy))
  end
   
  #--------------------------------------------------------------------------
  # new method: bouncy_tag?
  #--------------------------------------------------------------------------
  def bouncy_tag?(dx, dy)
    return tileset.bouncy.include?(terrain_tag(dx, dy))
  end
   
    #--------------------------------------------------------------------------
  # new method: jumpy_floor?
  #--------------------------------------------------------------------------
  def jumpy_floor?(dx, dy)
    return (valid?(dx, dy) && jumpy_tag?(dx, dy))
  end
   
  #--------------------------------------------------------------------------
  # new method: jumpy_tag?
  #--------------------------------------------------------------------------
  def jumpy_tag?(dx, dy)
    return tileset.jumpy.include?(terrain_tag(dx, dy))
  end
   
end # Game_Map
 
class Game_CharacterBase
   
  #--------------------------------------------------------------------------
  # new method: on_bouncy_floor?
  #--------------------------------------------------------------------------
  def on_bouncy_floor?; $game_map.bouncy_floor?(@x, @y); end
   
  #--------------------------------------------------------------------------
  # new method: on_slippery_floor?
  #--------------------------------------------------------------------------
  def on_jumpy_floor?; $game_map.jumpy_floor?(@x, @y); end
   
 end
  
#==============================================================================
# ■ Game_Player
#==============================================================================
 
class Game_Player < Game_Character
 
 #--------------------------------------------------------------------------
  # alias method: update
  #--------------------------------------------------------------------------
  alias game_player_update_bt update
  def update
    game_player_update_bt
    update_bouncy
  end
   
  #--------------------------------------------------------------------------
  # new method: update_slippery
  #--------------------------------------------------------------------------
  def update_bouncy
    return if $game_map.interpreter.running?
    return if moving?
    jump_straight(1) if on_bouncy_floor?
    jump_straight(2) if on_jumpy_floor?
  end
   
  def jump_straight(power)
    case @direction
    when 2
        jump(0, power)
    when 4
        jump(-1 * power, 0)
    when 6
        jump(power, 0)
    when 8
        jump(0, -1 * power)
    end
  end
end