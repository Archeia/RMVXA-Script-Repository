module BattleManager
    class << self
        alias item_on_escape_process_abort process_abort
        def process_abort
            item = $data_items[1] #change 1 to the id of the item you want to give the party
            $game_party.gain_item(item, 1) #add item to player's inventory
            item_on_escape_process_abort #escape from battle
            $game_message.add('The party found X') #show a message to the player
        end
    end
end