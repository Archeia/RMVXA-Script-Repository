=begin
#===============================================================================
Title: Use equipped items
Author: Shiggy
Date: Jan 23, 2015
This script will be part of a Dragon Quest inventory system
--------------------------------------------------------------------------------
** Change log
Jan 23, 2015
- Initial release of the header to the script
--------------------------------------------------------------------------------
** Terms of Use
* Free to use in non-commercial projects
* Commercial uses
  * Ask permission
  * This is a small script so I won't charge for it
  * I may ask a free copy of your game 
  * I may ask for other stuff like the right to use some assets
* Will do bug fixes
* Compatibility patches may be requested but no guarantees 
* Please report any compatibility issues anyway
* Features may be requested but no guarantees, especially if it is non-trivial
* Credits to Shiggy in your project
* Preserve this header
* Be nice to other people ( I don't want mean people to use my scripts)

--------------------------------------------------------------------------------
** Description

This script let you activate skills by using something you have equipped

--------------------------------------------------------------------------------
** Usage

Put <equip_skill: skill_id > in the note of a weapon or an armor,you can now 
use that skill from the item menu.

--------------------------------------------------------------------------------
** Installation

Place this script below Materials and above Main

#===============================================================================
=end

class RPG::EquipItem < RPG::BaseItem 
  attr_reader :equip_skill
  
  alias equip_use_initialize initialize
  def initialize
    equip_use_initialize
    
  end
  
  def equip_skill
    matches =@note.scan(/<\s*equip[ -_]skill\s*:\s*(\d+)\s*>/)
    a=matches[0]
    if a
      return $data_skills[a[0].to_i ] 
    else 
      return nil
    end
    
  end
  
end

class Window_BattleItem < Window_ItemList
  
  alias equip_use_make_item_list make_item_list
  def make_item_list
    equip_use_make_item_list
    if BattleManager.actor
      equips = BattleManager.actor.equips.compact 
      @data = equips + @data
    end
    
  end
  #--------------------------------------------------------------------------
  # * Show Window
  #--------------------------------------------------------------------------
  def show
    refresh
    select_last
    @help_window.show
    super
  end
  #--------------------------------------------------------------------------
  # * Get Item
  #--------------------------------------------------------------------------
  def item
    if @data && index >= 0
       if @data[index].is_a?(RPG::Item) 
         a = @data[index]
       else         
         a = @data[index].equip_skill
        end
      else 
        a = nil
      end
      return a
  end
  #--------------------------------------------------------------------------
  # * Get Activation State of Selection Item
  #--------------------------------------------------------------------------
  alias equip_use_enable? enable?
  def enable?(item)
    a = false
    if item.is_a?(RPG::Item)
      a = equip_use_enable?(item)
    else
      a = true if item.equip_skill
    end
    return a
  end
  
  alias equip_use_draw_item draw_item
  def draw_item(index)
    if @data[index].is_a?(RPG::Item)
      equip_use_draw_item(index)
    else
      item = @data[index]
      if item
        rect = item_rect(index)
        rect.width -= 4
        draw_item_name(item, rect.x, rect.y, enable?(item))
      end
    end
  end
  
  def update_help
    @help_window.set_item(@data[index])
  end
  
end

class Scene_Battle < Scene_Base
  def on_item_ok
    @item = @item_window.item
    if @item.is_a?(RPG::Item) 
      BattleManager.actor.input.set_item(@item.id)
    else
      BattleManager.actor.input.set_skill(@item.id)
    end
    if !@item.need_selection?
      @item_window.hide
      next_command
    elsif @item.for_opponent?
      select_enemy_selection
    else
      select_actor_selection
    end
    $game_party.last_item.object 
  end
end