class Window_Message < Window_Base  
alias galv_gpanda_update_show_fast update_show_fast  
def update_show_fast    
return if $game_switches[21] galv_gpanda_update_show_fast  
end
end
