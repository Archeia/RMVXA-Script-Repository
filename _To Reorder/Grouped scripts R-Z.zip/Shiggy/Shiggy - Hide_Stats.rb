=begin
#===============================================================================
Title: Hide Stats from the player
Author: Shiggy
Date: Jan 29, 2015
--------------------------------------------------------------------------------
** Change log
Jan 29, 2015
- Initial release of the script
--------------------------------------------------------------------------------
** Terms of Use
* Free to use in non-commercial projects
* Commercial uses
  * Ask permission
  * This is a small script so I won't charge for it
  * I may ask a free copy of your game 
  * I may ask for other stuff like the right to use some assets
* Will do bug fixes
* Compatibility patches may be requested but no guarantees 
* Please report any compatibility issues anyway
* Features may be requested but no guarantees, especially if it is non-trivial
* Credits to Shiggy in your project
* Preserve this header
* Be nice to other people ( I don't want mean people to use my scripts)

--------------------------------------------------------------------------------
** Description

This script let you hide some stats from the player : they will exist and eventually be used 
if your game needs it but the player won't see them

--------------------------------------------------------------------------------
** Usage

Choose the parameters you want to hide and put them in RemovedParams array at beginning of the script
--------------------------------------------------------------------------------
** Installation

Place this script below Materials and above Main

#===============================================================================
=end

$imported = {} if $imported.nil?
$imported["Shiggy-Hide_Stats"] = true


module Shiggy
  
  #ATK = 2
  #DEF = 3
  #MAT = 4
  #MDF = 5
  #AGI = 6
  #LUK = 7
  RemovedParams=[3,6] # in this example def and agi are removed
  
  
end

class Window_Base < Window

  #--------------------------------------------------------------------------
  # * Draw Parameters
  #--------------------------------------------------------------------------
  def draw_actor_param(actor, x, y, param_id)
    unless Shiggy::RemovedParams.any? {|i| param_id==i }
    change_color(system_color)
    draw_text(x, y, 120, line_height, Vocab::param(param_id))
    change_color(normal_color)
    draw_text(x + 120, y, 36, line_height, actor.param(param_id), 2)
    end
  end
end  
  
class Window_Status < Window_Selectable  
  #--------------------------------------------------------------------------
  # * Draw Parameters
  #--------------------------------------------------------------------------
  def draw_parameters(x, y)
    j = 0
    for i in 0..5
      if Shiggy::RemovedParams.any? {|param_id| param_id==i+2 }
        j+=1
      else
       draw_actor_param(@actor, x, y + line_height * (i-j), i + 2) 
      end
    end
  end
end


class Window_EquipStatus < Window_Base
#--------------------------------------------------------------------------
# * Draw Item
#--------------------------------------------------------------------------
  def draw_item(x, y, param_id)
    unless Shiggy::RemovedParams.any? {|i| param_id==i }
      draw_param_name(x + 4, y, param_id)
      draw_current_param(x + 94, y, param_id) if @actor
      draw_right_arrow(x + 126, y)
      draw_new_param(x + 150, y, param_id) if @temp_actor
    end
  end

  def refresh
    contents.clear
    if @actor
      draw_actor_name(@actor, 4, 0) 
      j = 0
      for i in 0..5
        if Shiggy::RemovedParams.any? {|param_id| param_id==i+2 }
          j+=1
        else
           draw_item(0, line_height * (1 + i - j), 2 + i) 
        end
      end
    end
  end
  
end

if $imported["YEA-PartySystem"]

class Window_PartyStatus < Window_Base

	def draw_actor_parameters(actor, dx, dy)
		dw = contents.width/2 - 4
		rect = Rect.new(dx+1, dy+1, dw - 2, line_height - 2)
		contents.font.size = YEA::PARTY::STAT_FONT_SIZE
		colour = Color.new(0, 0, 0, translucent_alpha/2)
		array = [:atk, :def, :mat, :mdf, :agi, :luk]
		Shiggy::RemovedParams.each { |i| array.delete_at(i-2) }
		cx = 4
		for stat in array
			case stat
			when :atk
				param = Vocab::param(2)
				value = actor.atk.group
			when :def
				param = Vocab::param(3)
				value = actor.def.group
			when :mat
				param = Vocab::param(4)
				value = actor.mat.group
			when :mdf
				param = Vocab::param(5)
				value = actor.mdf.group
			when :agi
				param = Vocab::param(6)
				value = actor.agi.group
			when :luk
				param = Vocab::param(7)
				value = actor.luk.group
			else; next
			end
			contents.fill_rect(rect, colour)
			change_color(system_color)
			draw_text(rect.x + cx, rect.y, rect.width-cx*2, line_height, param, 0)
			change_color(normal_color)
			draw_text(rect.x + cx, rect.y, rect.width-cx*2, line_height, value, 2)
			rect.y += line_height
			end
		reset_font_settings
	end
end
end