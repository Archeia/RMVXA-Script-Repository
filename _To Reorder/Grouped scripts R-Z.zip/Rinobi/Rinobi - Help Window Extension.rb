#===============================================================================
# Rinobi: Help Window Extension
#-------------------------------------------------------------------------------
# This script allows for the adjusting of viable lines within help menus,
# effectively removing the imposed, two-line limit in the editor.
#-------------------------------------------------------------------------------
# Instructions:
#
# Use the notes section as additional lines to add to your help text. You may
# use both help text and notes text in conjunction, or separately.
#-------------------------------------------------------------------------------
# Version History:
#
# @ 1.0 Completed [11/23/2015]
#-------------------------------------------------------------------------------
# Compatibility:
#
# Modules:
# @ HelpMod < RINOBI
#
# Alias Methods:
# @ initialize  in Window_Help
# @ set_item    in Window_Help
#===============================================================================
module RINOBI module HelpMod # No Touchie!
#===============================================================================
# ** Settings Module
#===============================================================================
  Line_Number = 4   # Default help lines to display.
  #-----------------------------------------------------------------------------
  # Setting any of the constants below to 0 returns the default value set above.
  #-----------------------------------------------------------------------------
  Line_Status = 0   # Help lines within status menu.
  Line_Battle = 0   # Help lines in battle when viewing skills.
  Line_Skill  = 4   # Help lines within the skill menu.
  Line_Equip  = 0   # Help lines within the equip menu.
  Line_Item   = 0   # Help lines within the item menu.
  Line_LSkill = 4   # Compability with Yanfly's Learn Skill Engine
#===============================================================================
# ** End of Settings
#-------------------------------------------------------------------------------
# Editing beyond this area may result in unfathomable terror.
#===============================================================================
end end # No Touchie!
$imported = {} if $imported.nil?
$imported[:RIN_HelpExtenson] = true
#===============================================================================
# ** Class: Window_Help < Window_Base
#===============================================================================
class Window_Help < Window_Base
  #--------------------------------------------------------------------------
  # * Alias Method: Object Initialization
  #--------------------------------------------------------------------------
  alias :rinwin_init :initialize
  def initialize(line_number = RINOBI::HelpMod::Line_Number)
    if SceneManager.scene_is?(Scene_Status)
      return rinwin_init(line_number) unless RINOBI::HelpMod::Line_Status > 0
      return rinwin_init(RINOBI::HelpMod::Line_Status) end
    if SceneManager.scene_is?(Scene_Battle)
      return rinwin_init(line_number) unless RINOBI::HelpMod::Line_Battle > 0
      return rinwin_init(RINOBI::HelpMod::Line_Battle) end
    if SceneManager.scene_is?(Scene_Skill)
      return rinwin_init(line_number) unless RINOBI::HelpMod::Line_Skill  > 0
      return rinwin_init(RINOBI::HelpMod::Line_Skill)  end
    if SceneManager.scene_is?(Scene_Equip)
      return rinwin_init(line_number) unless RINOBI::HelpMod::Line_Equip  > 0
      return rinwin_init(RINOBI::HelpMod::Line_Equip)  end
    if SceneManager.scene_is?(Scene_Item)
      return rinwin_init(line_number) unless RINOBI::HelpMod::Line_Item   > 0
      return rinwin_init(RINOBI::HelpMod::Line_Item)   end
    if SceneManager.scene_is?(Scene_LearnSkill) && $imported["YEA-LearnSkillEngine"]
      return rinwin_init(line_number) unless RINOBI::HelpMod::Line_LSkill > 0
      return rinwin_init(RINOBI::HelpMod::Line_LSkill) end
    return rinwin_init(line_number)
  end # initialize
  #--------------------------------------------------------------------------
  # * Alias Method: set_item
  #--------------------------------------------------------------------------
  alias :rinwin_set_item :set_item
  def set_item(item)
    rinwin_set_item = set_text(item ? item.description + item.note : "")
  end # set_item
end # Window_Help < Window_Base