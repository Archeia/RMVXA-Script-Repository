#===============================================================================
# Rinobi: Apply Random States
#-------------------------------------------------------------------------------
# Allows states to be applied to targets randomly in battle.
#-------------------------------------------------------------------------------
# Version History:
#
# @ 1.0 [12/08/2015] Completed
#-------------------------------------------------------------------------------
# Instructions:
#
# Paste below Materials and above Main Process.
#-------------------------------------------------------------------------------
# Script Calls:
# 
# state_apply_sing # Uses the default settings for applying a single state.
# state_apply_sing(array) # Set own array, state turns set to default.
# state_apply_sing(array, min_turn, max_turn) # Set the array and turns.
#
# state_apply_rsing # Uses the default settings for applying a single state.
# state_apply_rsing(range) # Set own range, state turns set to default.
# state_apply_rsing(range, min_turn, max_turn) # Set the range and turns.
# 
# state_apply_mult # Uses the default settings for applying mutiple states.
# state_apply_mult(array) # Set own array, state turns set to default.
# state_apply_mult(array, min_turn, max_turn) # Set the array and turns.
# 
# state_apply_rmult # Uses the default settings for applying mutiple states.
# state_apply_rmult(range) # Set own range, state turns set to default.
# state_apply_rmult(range, min_turn, max_turn) # Set the range and turns.
#-------------------------------------------------------------------------------
# Examples:
# 
# b.state_apply_sing 
# (Adds a random state to the target based on the module settings below.)
#
# b.state_apply_sing([2, 5, 9])
# (Adds state 2, 5, or 9 to the target randomly.)
# 
# a.state_apply_rmult((2..5), 3, 3)
# (Randomly adds a number of states between 2 and 5 that last 3 turns to user.)
# 
# a.state_apply_rsing((1..25, 1, 10)
# (Randomly adds a 1 state between 1 and 25 that lasts betwen 1 and 10 turns.)
#-------------------------------------------------------------------------------
# Compatibility:
#
# Modules:
# @ StateRand < RINOBI
#
# New Methods:
# @ state_apply_sing in Game_Battler
# @ state_apply_mult in Game_Battler
# @ state_apply_rsing in Game_Battler
# @ state_apply_rmult in Game_Battler
#===============================================================================
module RINOBI module StateRand # No Touchie!
#===============================================================================
# ** Settings Module
#-------------------------------------------------------------------------------
# States default behavior.
#===============================================================================
#-----------------------------------------------------------------------------
# Number of turns the state lasts. Will return a number between the below
# values. Set both values as the same number to cancel randomization.
Turns_Default = {:Min => 1, :Max => 5}
#-----------------------------------------------------------------------------
# A selection of state IDs for applying a single random state. Add as many as
# you like in any order. States are selected randomly.
SArray_Default = [2, 3, 4, 5, 6, 7, 8]
#-----------------------------------------------------------------------------
# A selection of state IDs for applying a multiple random states. Add as many
# as you like in any order. States are selected randomly.
MArray_Default = [2, 3, 4, 5, 6, 7 ,8]
#-----------------------------------------------------------------------------
# A range of state IDs for applying a single random state. Set the beginning
# and ending state values below.
SRange_Default = (2..8)
#-----------------------------------------------------------------------------
# A range of state IDs for applying a mutiple random states. Set the beginning
# and ending state values below.
MRange_Default = (2..8)
#===============================================================================
# ** End of Settings
#-------------------------------------------------------------------------------
# Editing beyond this area may result in unfathomable terror.
#===============================================================================
end end # No Touchie! 
$imported = {} if $imported.nil?
$imported[:RIN_StateRand] = true
#===============================================================================
# ** Class: Game_Battler < Game_BattlerBase
#===============================================================================
class Game_Battler < Game_BattlerBase
#--------------------------------------------------------------------------
# * New Method: rand_apply_sing
#--------------------------------------------------------------------------
def state_apply_sing(array = RINOBI::StateRand::SArray_Default,
minturn = RINOBI::StateRand::Turns_Default[:Min], 
maxturn = RINOBI::StateRand::Turns_Default[:Max])
rstate = array.sample ; add_state(rstate)
@state_turns[rstate] = [(minturn..maxturn).to_a.sample, 0].max
end # rand_apply_sing
#--------------------------------------------------------------------------
# * New Method: rand_apply_mult
#--------------------------------------------------------------------------
def state_apply_mult(array = RINOBI::StateRand::MArray_Default,
minturn = RINOBI::StateRand::Turns_Default[:Min],
maxturn = RINOBI::StateRand::Turns_Default[:Max])
rstate = array.sample(1 + rand(array.count))
rstate.each {|s| add_state(s)}
rstate.each {|t| @state_turns[t] = [(minturn..maxturn).to_a.sample, 0].max}
end # rand_apply_mult
#--------------------------------------------------------------------------
# * New Method: rand_apply_rsing
#--------------------------------------------------------------------------
def state_apply_rsing(range = RINOBI::StateRand::SRange_Default,
minturn = RINOBI::StateRand::Turns_Default[:Min],
maxturn = RINOBI::StateRand::Turns_Default[:Max])
rstate = range.to_a.sample ; add_state(rstate)
@state_turns[rstate] = [(minturn..maxturn).to_a.sample, 0].max
end # rand_apply_rang
#--------------------------------------------------------------------------
# * New Method: rand_apply_rmult
#--------------------------------------------------------------------------
def state_apply_rmult(range = RINOBI::StateRand::MRange_Default,
minturn = RINOBI::StateRand::Turns_Default[:Min],
maxturn = RINOBI::StateRand::Turns_Default[:Max])
rstate = range.to_a.sample(1 + rand(range.count))
rstate.each {|s| add_state(s)}
rstate.each {|t| @state_turns[t] = [(minturn..maxturn).to_a.sample, 0].max}
end # rand_apply_rang
end # Game_Battler < Game_BattlerBase