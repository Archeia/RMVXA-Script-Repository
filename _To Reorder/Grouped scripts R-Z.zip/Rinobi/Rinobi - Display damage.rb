module RINOBI module WinEval # DO NOT MODIFY
#==============================================================================
#                               Window Eval
#::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
# By: Rinobi
# -----------------------------------------------------------------------------
# Allows formulas to be used within text events and help windows.
#==============================================================================
# # VERSION HISTORY
# -----------------------------------------------------------------------------
# 1.0 [07/26/2015] Completed
#-
# Details listed under 'Updates' section at the bottom of this page.
#==============================================================================
# # INSTRUCTIONS
# -----------------------------------------------------------------------------
# Use - \e< Code > - to display your formula within text and help windows.
# Where 'Code' is your custom forumla.
#-
#  a = actor  |  p = party  |  t = troop  |  v = variables  |  s = switches
#-
# \e<a.level * a.atk> - returns actor's attack value multiplied by level
#==============================================================================
# # COMPATIBILITY
# -----------------------------------------------------------------------------
# Created for use within RPG Maker VX Ace
#-
# Requirements
# 1. None
#-
# Overwrite Methods
# 1. None
#-
# Alias Methods
# 1. convert_escape_characters in Window_Base
#==============================================================================
# # TERMS OF USE
#------------------------------------------------------------------------------
# 1. Preserve this header.
# 2. Do not re-upload this script.
# 3. Do not claim this script as your own work.
# 4. Do not release modified versions of this script.
# 5. Free for use within non-commercial projects.
# 6. Free for use within commercial projects.
# 7. Credit Rinobi and/or his aliases if used.
#==============================================================================
# # END OF SETUP
# -----------------------------------------------------------------------------
# Editing beyond this line may result in undesirable side-effects.
#==============================================================================

  Note = /\eE<(.*?)>/i # Notetag Setting
 
end end # DO NOT MODIFY
#==============================================================================
# ** IMPORT SCRIPT
#------------------------------------------------------------------------------
$imported = {} if $imported.nil?    # Set imported to hash if empty.
$imported[:RIN_WinEval] = true  # Add script key to imported hash.
#==============================================================================
# ** Window_Base
#------------------------------------------------------------------------------
#  This is a super class of all windows within the game.
#==============================================================================
class Window_Base < Window
  #--------------------------------------------------------------------------
  # # Alias Method: Preconvert Control Characters
  #    As a rule, replace only what will be changed into text strings before
  #    starting actual drawing. The character "\" is replaced with the escape
  #    character (\e).
  #--------------------------------------------------------------------------
  alias :evaluate_formula :convert_escape_characters
  def convert_escape_characters(text)
    result = evaluate_formula(text)
    case SceneManager.scene
    when Scene_Battle
      result.gsub!(RINOBI::WinEval::Note) {window_eval_code1($1)}
    when Scene_Skill
      result.gsub!(RINOBI::WinEval::Note) {window_eval_code2($1)}
    else
      result.gsub!(RINOBI::WinEval::Note) {window_eval_code3($1)}
    end #-
    return result
  end # convert_escape_characters
  #-----------------------------------------------------------------------------
  # # New Method: window_eval_code1
  #-----------------------------------------------------------------------------
  def window_eval_code1(formula, a = BattleManager.actor,
    p = $game_party.members, t = $game_troop.members,
    v = $game_variables, s = $game_switches)
    eval(formula)
  end # window_eval_code1
  #-----------------------------------------------------------------------------
  # # New Method: window_eval_code2
  #-----------------------------------------------------------------------------
  def window_eval_code2(formula, a = $game_party.menu_actor,
    p = $game_party.members, t = $game_troop.members,
    v = $game_variables, s = $game_switches)
    eval(formula)
  end # window_eval_code2
  #-----------------------------------------------------------------------------
  # # New Method: window_eval_code3
  #-----------------------------------------------------------------------------
  def window_eval_code3(formula, a = $game_party.leader,
    p = $game_party.members, t = $game_troop.members,
    v = $game_variables, s = $game_switches)
    eval(formula)
  end # window_eval_code2
end # Window_Base < Window
#==============================================================================
# # UPDATES
# -----------------------------------------------------------------------------
# None yet.
#==============================================================================
# # AUTHOR'S NOTES
# -----------------------------------------------------------------------------
# Nothing yet.
#==============================================================================
# @@@@@  @   @  @@@@    @@@@@  @@@@@   @@@@@  @@@@@  @@@@   @@@@@  @@@@@  @@@@@
# @      @@  @  @   @   @   @  @       @      @      @   @    @    @   @    @  
# @@@@@  @ @ @  @   @   @   @  @@@@    @@@@@  @      @@@@     @    @@@@@    @  
# @      @  @@  @   @   @   @  @           @  @      @  @     @    @        @  
# @@@@@  @   @  @@@@    @@@@@  @       @@@@@  @@@@@  @   @  @@@@@  @        @  
#==============================================================================