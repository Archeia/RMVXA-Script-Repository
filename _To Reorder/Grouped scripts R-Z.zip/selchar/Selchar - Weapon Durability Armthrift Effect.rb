#===============================================================================
# Script: Weapon Durability Armthrift Effect
# Author: Selchar
# Requestor: SpellcraftQuill
#===============================================================================
=begin
This is an add-on to my Weapon Durability script, it adds an "Armthrift" rate
to anything with a notetag.  Armthrift is the effect of not reducing your
current weapon's durability when you attack/use a skill.

When you attack/use a skill, the the Armthrift rate on your actor, class, equips,
states, even your skills are all added together.  A total rate of 1.0 or higher
means you'll never use up your weapon's durability.
#-------------------------------------------------------------------------------
# Actor/Class/State/Armor/Weapon/Skill Notetag
#-------------------------------------------------------------------------------
<armthrift rate: x>
Where x is a float number such as 0.05, which translates to 5%.  

=end

$imported = {} if $imported.nil?
$imported[:Sel_Wep_Dura_Armthrift] = true
unless $imported[:Sel_Weapon_Durability]
  msgbox("Selchar's Weapon durability not detected, exiting.")
  exit
end

class Game_Battler < Game_BattlerBase
  alias :weapon_durability_cost_armthrift :weapon_durability_cost
  def weapon_durability_cost(weapon, skill)
    return 0 if armthrift_rate
    return weapon_durability_cost_armthrift(weapon, skill)
  end
  
  def armthrift_rate
    chance = 0.0
    feature_objects.each do |i|
      next unless i
      chance += i.armthrift_rate
    end
    skills.each do |i|
      next unless i
      chance += i.armthrift_rate
    end
    return rand <= chance
  end
end

class RPG::BaseItem
  def armthrift_rate
    @note =~ /<armthrift[-_ ]?rate:\s*(.*)\s*>/i ? @armthrift_rate = $1.to_f : @armthrift_rate = 0.0 if @armthrift_rate.nil?
    @armthrift_rate
  end
end