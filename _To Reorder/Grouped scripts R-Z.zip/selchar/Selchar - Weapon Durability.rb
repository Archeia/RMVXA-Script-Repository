#===============================================================================
# Script: Basic Instance Weapon Durability Ver. 1.07
# Author: Selchar
# Credit: Tsukihime
# Required: Tsukihime's Item Instance
#===============================================================================
=begin
This script implements durability for weapons.  With each use for an attack or
skill, a weapon's durability wil decrease by the amount you specify in the
customization area.  You can that by how much as well via a notetag for skills.
Only weapons with the <use durability> notetag will use this script's function.
#-------------------------------------------------------------------------------
# Weapon Notetag
#-------------------------------------------------------------------------------
<set durability>
Sets up the weapon to use durability.  See Default Setting down beow.

<max durability: x>
Where x is the starting durability of a weapon, defaults to the setting beow.

<broken weapon change: x>
Where x is the id of the new "weapon" you obtain when the one you are using
breaks.  Like say you wanted a "broken sword" instead of a "Sword 0/100".  This
only works if Destroy_Broken_Weapon down below is set to false.

<skill durability mod x: y>
Where x is the id of the skill who's durability cost you wish to modify and
y is by how much you wish to modify it by.  y can be either a positive or
a negative number.  Weapon Durability can not be "repaired" through this.
#-------------------------------------------------------------------------------
# Skill Notetag
#-------------------------------------------------------------------------------
<durability cost: x>
Where x is how much of a weapon's durability is used, defaults to the constant
Default_Durability_Cost that you set below, default value is 1

=end
module TH_Instance
  module Weapon
    #Set this for weapon durability designation for when the max durability
    #notetag is not present.
    Default_Durability = 100
    
    #Set this to what you want the default cost for successfully using skills
    #while equipped with a durability enabled equip to be.
    Default_Durability_Cost = 1
    
    #When a weapon is destroyed, this determines what will happen to it.  If
    #true, then it disappears from your inventory completely.  If it's false,
    #then either you keep the 0 durability version, or it changes to a new
    #"weapon" that you choose through the broken weapon notetag.
    Destroy_Broken_Weapon = false
    
    #This determines default Behavior of equips, and the behavior of the
    #<set durability> tag which is always the opposite.
    Durability_Setting = false
    
    #Format of durability suffix
    Dur_Suf = ' (%s/%s)'
  end
end
#===============================================================================
# Rest of the script
#===============================================================================
$imported = {} if $imported.nil?
$imported[:Sel_Weapon_Durability] = true
unless $imported["TH_InstanceItems"]
  msgbox("Tsukihime's Instance not detected, exiting")
  exit
end

class Game_Battler < Game_BattlerBase
#===============================================================================
# On Successful Damage
#===============================================================================
  alias :process_weapon_durability_mdv :make_damage_value
  def make_damage_value(user, item)
    process_weapon_durability_mdv(user, item)
    user.process_weapon_durability(item) if user.actor? && @result.hit?
  end
#===============================================================================
# Weapon Durability Methods in Game_Battler
#===============================================================================
  def process_weapon_durability(item)
    return unless item.is_a?(RPG::Skill)
    weapons.each do |i|
      next unless can_process_weapon_durability(i, item)
      process_individual_weapon_durability(i, item)
    end
  end
  
  def can_process_weapon_durability(weapon, skill)
    return false unless weapon
    return false unless weapon.use_durability
    return true
  end
  
  def process_individual_weapon_durability(weapon, skill)
    weapon.durability -= weapon_durability_cost(weapon, skill)
    weapon.durability = 0 if weapon.durability < 0
    weapon.refresh_name
    weapon.refresh_price
    weapon.break_by_durability(self) if weapon.durability.zero?
  end
  
  def weapon_durability_cost(weapon, skill)
    cost = skill.weapon_durability_cost
    cost += weapon.skill_durability_mod(skill.id)
    cost = 0 if cost < 0 #Make sure no negatives
    return cost
  end
end
#===============================================================================
# Can't equip if weapon uses durability and has none left.
#===============================================================================
class Game_Actor < Game_Battler
  alias :zero_durability_wep_equip :equippable?
  def equippable?(item)
    return zero_durability_wep_equip(item) if item.is_a?(RPG::EquipItem) && item.is_template?
    return false if item.is_a?(RPG::Weapon) && item.use_durability && item.durability.zero?
    return zero_durability_wep_equip(item)
  end
end
#===============================================================================
# Extend log_window
#===============================================================================
class Scene_Battle < Scene_Base
  attr_accessor :log_window
end
#===============================================================================
# Weapon Methods
#===============================================================================
class RPG::Weapon
  attr_accessor :durability
  attr_accessor :use_durability
  
  def repair
    @durability = max_durability
    refresh_name
    refresh_price
  end
  
  def can_repair?
    @durability < max_durability
  end
  
  def repair_price
    @durability.zero? ? @non_durability_price : (@non_durability_price - @price)
  end
  
  def broken_weapon_text(actor)
    message = "%s's %s broke!" % [actor.name, @non_durability_name]
    SceneManager.scene.log_window.add_text(message)
  end
  
  def break_by_durability(actor)
    actor.equips.each_index do |i|
      if actor.equips[i] == self
        actor.change_equip(i, nil)
        if TH_Instance::Weapon::Destroy_Broken_Weapon
          $game_party.gain_item(self, -1)
        else
          if broken_weapon_change
            $game_party.gain_item(self, -1)
            broke_version = InstanceManager.get_instance($data_weapons[broken_weapon_change])
            $game_party.gain_item(broke_version, 1) 
          end
        end
        broken_weapon_text(actor)
        break
      end
    end
  end
#===============================================================================
# Renaming/Price Adjusting
#===============================================================================
  def durability_suffix
    return TH_Instance::Weapon::Dur_Suf % [@durability, @max_durability]
  end
  def apply_durability_suffix(name)
    name += durability_suffix
  end
  
  alias :sel_durability_make_name :make_name
  def make_name(name)
    name = sel_durability_make_name(name)
    @non_durability_name = name
    name = apply_durability_suffix(name) if use_durability
    name
  end
  
  def apply_durability_price(price)
    if @durability.zero? && !@non_durability_price.zero?
      price = 2
    else
      price = (price * (@durability.to_f/max_durability)).to_i
    end
    price
  end
  
  alias :sel_durability_make_price :make_price
  def make_price(price)
    price = sel_durability_make_price(price)
    @non_durability_price = price
    price = apply_durability_price(price) if use_durability
    price
  end
#===============================================================================
# Weapon Notetag
#===============================================================================
  def use_durability
    if @use_durability.nil?
      default = TH_Instance::Weapon::Durability_Setting
      @note =~ /<set[-_ ]?durability>/i ? @use_durability = !default : @use_durability = default
    end
    @use_durability
  end
  
  def max_durability
    @note =~ /<max[-_ ]?durability:\s*(.*)\s*>/i ? @max_durability = $1.to_i : @max_durability = TH_Instance::Weapon::Default_Durability if @max_durability.nil?
    @max_durability
  end
  
  def broken_weapon_change
    @note =~ /<broken[-_ ]?weapon[-_ ]?change:\s*(.*)\s*>/i ? @broken_weapon_change = $1.to_i : @broken_weapon_change = false if @broken_weapon_change.nil?
    @broken_weapon_change
  end
  
  def skill_durability_mod(skill_id)
    if @skill_durability_mod.nil?
      @skill_durability_mod = []
      $data_skills.each do |i|
        next unless i
        if @note =~ /<skill[-_ ]?durability[-_ ]?mod[-_ ]?#{i.id.to_s}:\s*(.*)\s*>/i
          @skill_durability_mod[i.id] = $1.to_i
        else
          @skill_durability_mod[i.id] = 0
        end
      end
    end
    @skill_durability_mod[skill_id]
  end
end
#===============================================================================
# Skill Notetag
#===============================================================================
class RPG::Skill
  def weapon_durability_cost
    @note =~ /<durability[-_ ]?cost:\s*(.*)\s*>/i ? @durability_cost = $1.to_i : @durability_cost = TH_Instance::Weapon::Default_Durability_Cost if @durability_cost.nil?
    @durability_cost
  end
end
#===============================================================================
# Instance Manager: setup_instance
#===============================================================================
module InstanceManager
  class << self
    alias :instance_weapon_durability_setup :setup_weapon_instance
  end
  
  def self.setup_weapon_instance(obj)
    instance_weapon_durability_setup(obj)
    obj.repair if obj.use_durability
  end
end
#===============================================================================
# End of File
#===============================================================================