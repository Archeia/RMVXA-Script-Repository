#===============================================================================
# Script: Basic Instance Armor Durability Ver. 1.01
# Author: Selchar
# Credit: Tsukihime
# Required: Tsukihime's Item Instance
#===============================================================================
=begin
This script implements durability for armors.  With each time you are hit, there
will be a chance of reducing your equipment's durability.  You can change by how
much via a notetag for skills.  Only armor with the <use durability> notetag
will use this script's function.
#-------------------------------------------------------------------------------
# Armor Notetag
#-------------------------------------------------------------------------------
<set durability>
Sets up the weapon to use durability.  See Default Setting down beow.

<max durability: x>
Where x is the starting durability of a weapon, defaults to the setting beow.

<broken armor change: x>
Where x is the id of the new "weapon" you obtain when the one you are using
breaks.  Like say you wanted a "broken sword" instead of a "Sword 0/100".  This
only works if Destroy_Broken_Weapon down below is set to false.

<elem dura rate element_name: x>
Where element_name is the name of the element that you create in the database,
and x is a float number such as 0.5 or -0.5.  Negative numbers reduce the chance
of durability being reduced, while positive numbers increase the chance.

#-------------------------------------------------------------------------------
# Skill Notetag
#-------------------------------------------------------------------------------
<durability damage: x>
Where x is how much of an armor's durability is reduced by when an actor is hit
by this skill, defaults to the constant Default_Durability_Damage that you set
below, default value is 1
=end
module TH_Instance
  module Armor
    #Set this for weapon durability designation for when the max durability
    #notetag is not present.
    Default_Durability = 100
    
    #Set this to what you want the default cost for successfully using skills
    #while equipped with a durability enabled equip to be.
    Default_Durability_Damage = 1
    
    #The rate by which your armor's durability will be reduced without outside
    #modifications. 1.0 is all the time, 0.5 is 50% of the time.
    Durability_Reduce_Rate = 0.5
    
    #When a weapon is destroyed, this determines what will happen to it.  If
    #true, then it disappears from your inventory completely.  If it's false,
    #then either you keep the 0 durability version, or it changes to a new
    #"weapon" that you choose through the broken weapon notetag.
    Destroy_Broken_Armor = false
    
    #This determines default Behavior of equips, and the behavior of the
    #<set durability> tag which is always the opposite.
    Durability_Setting = false

    #Format of durability suffix
    Dur_Suf = ' (%s/%s)'
#===============================================================================
# Rest of the script
#===============================================================================
    def self.elem_dura_rate(element_id)
      /<elem[-_ ]?dura[-_ ]?rate[-_ ]?#{$data_system.elements[element_id]}:\s*(.*)\s*>/i
    end
  end
end

$imported = {} if $imported.nil?
$imported[:Sel_Armor_Durability] = true
unless $imported["TH_InstanceItems"]
  msgbox("Tsukihime's Instance not detected, exiting")
  exit
end

class Game_Battler < Game_BattlerBase
#===============================================================================
# On Successful Damage
#===============================================================================
  alias :process_armor_durability_mdv :make_damage_value
  def make_damage_value(user, item)
    process_armor_durability_mdv(user, item)
    self.process_armor_durability(item) if self.actor? && @result.hit?
  end
#===============================================================================
# Armor Durability Methods in Game_Battler
#===============================================================================
  def process_armor_durability(item)
    return unless item.is_a?(RPG::Skill)
    armors.each do |i|
      next unless can_process_armor_durability(i, item)
      process_individual_armor_durability(i, item)
    end
  end
  
  def can_process_armor_durability(armor, skill)
    return false unless armor
    return false unless armor.use_durability
    return false unless reduce_durability_rate(armor, skill)
    return true
  end
  
  def reduce_durability_rate(armor, skill)
    #Normal Attack is element -1, changed to 0 which is element none?
    ele = skill.damage.element_id == -1 ? 0 : skill.damage.element_id
    return true if rand <= (TH_Instance::Armor::Durability_Reduce_Rate + armor.elem_dura_rate(ele))
    return false
  end
  
  def process_individual_armor_durability(armor, skill)
    armor.durability -= armor_durability_damage(armor, skill)
    armor.durability = 0 if armor.durability < 0
    armor.refresh_name
    armor.refresh_price
    armor.break_by_durability(self) if armor.durability.zero?
  end
  
  def armor_durability_damage(armor, skill)
    damg = skill.armor_durability_damage
    damg = 0 if damg < 0 #Make sure no negatives
    return damg
  end
end
#===============================================================================
# Can't equip if armor uses durability and has none left.
#===============================================================================
class Game_Actor < Game_Battler
  alias :zero_durability_arm_equip :equippable?
  def equippable?(item)
    return zero_durability_arm_equip(item) if item.is_a?(RPG::EquipItem) && item.is_template?
    return false if item.is_a?(RPG::Armor) && item.use_durability && item.durability.zero?
    return zero_durability_arm_equip(item)
  end
end
#===============================================================================
# Extend log_window
#===============================================================================
class Scene_Battle < Scene_Base
  attr_accessor :log_window
end
#===============================================================================
# Armor Methods
#===============================================================================
class RPG::Armor
  attr_accessor :durability
  attr_accessor :use_durability
  
  def repair
    @durability = max_durability
    refresh_name
    refresh_price
  end
  
  def can_repair?
    @durability < max_durability
  end
  
  def repair_price
    @durability.zero? ? @non_durability_price : (@non_durability_price - @price)
  end
  
  def broken_armor_text(actor)
    message = "%s's %s broke!" % [actor.name, @non_durability_name]
    SceneManager.scene.log_window.add_text(message)
  end
  
  def break_by_durability(actor)
    actor.equips.each_index do |i|
      if actor.equips[i] == self
        actor.change_equip(i, nil)
        if TH_Instance::Armor::Destroy_Broken_Armor
          $game_party.gain_item(self, -1)
        else
          if broken_armor_change
            $game_party.gain_item(self, -1)
            broke_version = InstanceManager.get_instance($data_armors[broken_armor_change])
            $game_party.gain_item(broke_version, 1) 
          end
        end
        broken_armor_text(actor)
        break
      end
    end
  end
#===============================================================================
# Renaming/Price Adjusting
#===============================================================================
  def durability_suffix
    return TH_Instance::Armor::Dur_Suf % [@durability, @max_durability]
  end
  def apply_durability_suffix(name)
    name += durability_suffix
  end
  
  alias :sel_durability_make_name :make_name
  def make_name(name)
    name = sel_durability_make_name(name)
    @non_durability_name = name
    name = apply_durability_suffix(name) if use_durability
    name
  end
  
  def apply_durability_price(price)
    if @durability.zero? && !@non_durability_price.zero?
      price = 2
    else
      price = (price * (@durability.to_f/max_durability)).to_i
    end
    price
  end
  
  alias :sel_durability_make_price :make_price
  def make_price(price)
    price = sel_durability_make_price(price)
    @non_durability_price = price
    price = apply_durability_price(price) if use_durability
    price
  end
#===============================================================================
# Armor Notetag
#===============================================================================
  def use_durability
    if @use_durability.nil?
      default = TH_Instance::Armor::Durability_Setting
      @note =~ /<set[-_ ]?durability>/i ? @use_durability = !default : @use_durability = default
    end
    @use_durability
  end
  
  def max_durability
    @note =~ /<max[-_ ]?durability:\s*(.*)\s*>/i ? @max_durability = $1.to_i : @max_durability = TH_Instance::Armor::Default_Durability if @max_durability.nil?
    @max_durability
  end
  
  def broken_armor_change
    @note =~ /<broken[-_ ]?armor[-_ ]?change:\s*(.*)\s*>/i ? @broken_armor_change = $1.to_i : @broken_armor_change = false if @broken_armor_change.nil?
    @broken_armor_change
  end
  
  def elem_dura_rate(element_id)
    if @elem_dura_rate.nil?
      @elem_dura_rate = []
      (0...$data_system.elements.size).each do |i|
        @note =~ TH_Instance::Armor.elem_dura_rate(i) ? @elem_dura_rate[i] = $1.to_f : @elem_dura_rate[i] = 0.0
      end
    end
    @elem_dura_rate[element_id]
  end
end
#===============================================================================
# Skill Notetag
#===============================================================================
class RPG::Skill
  def armor_durability_damage
    @note =~ /<durability[-_ ]?damage:\s*(.*)\s*>/i ? @durability_damage = $1.to_i : @durability_damage = TH_Instance::Armor::Default_Durability_Damage if @durability_damage.nil?
    @durability_damage
  end
end
#===============================================================================
# Instance Manager: setup_instance
#===============================================================================
module InstanceManager
  class << self
    alias :instance_armor_durability_setup :setup_armor_instance
  end
  
  def self.setup_armor_instance(obj)
    instance_armor_durability_setup(obj)
    obj.repair if obj.use_durability
  end
end
#===============================================================================
# End of File
#===============================================================================