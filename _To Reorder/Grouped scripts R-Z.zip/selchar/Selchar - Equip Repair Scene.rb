#===============================================================================
# Script: Equip Repair Scene
# Author: Selchar
# Credit: Tsukihime
# Required: Tsukihime's Item Instance
#===============================================================================
=begin
This script script is an extention of my Equip Durability scripts.  It creates a
scene allowing you to repair select items for a cost.  Repairable items are
those that have less than their maximum durability.

To open the scene, use the following as a scriptcall SceneManager.call(Scene_RepairEquip)
=end
module TH_Instance
  module Scene_Repair
    #Message to display to select the item window, similar to buy/sell/etc...
    Vocab = "Repair"
    
    #Message to display when no item is selected, as in you enter the scene with
    #no equips at all.
    No_Selected_Item = "We can renew your items for you here!"
    
    #Help Message displayed on equips you can repair.  Followed by the repair
    #price and currency symbol.
    Selected_Item = "The cost to swing my hammer and mend this is "
    
    #Help Message displayed on items that have full durability already.
    Can_Not_Repair = "This item is in top condition already!"
    
    #Sound Effect played upon successful equipment repair.
    #     SE_Name, Volume, Pitch
    SE = ['Bell2',100,100]
    
    #Repair price = (current_durability/max_durability)*Purchase_Price
    #Price_Mod then multiplies what results from that.  Default 1.0
    Price_Mod = 1.0
  end
end
#===============================================================================
# Rest of the Script
#===============================================================================
$imported = {} if $imported.nil?
$imported[:Sel_Equip_Dura_Repair] = true
unless $imported["TH_InstanceItems"]
  msgbox("Tsukihime's Instance Items not detected,
exiting")
  exit
end
unless ($imported[:Sel_Weapon_Durability] || $imported[:Sel_Armor_Durability])
  msgbox("Neither of Selchar's Equip Durability
scripts were detected, Exiting")
  exit
end
#==============================================================================
# Repair Command Window
#==============================================================================
class Window_RepairCommand < Window_HorzCommand
  def initialize(window_width)
    @window_width = window_width
    super(0, 0)
  end
  
  def window_width
    @window_width
  end
  
  def col_max
    return 2
  end
  
  def make_command_list
    add_command(TH_Instance::Scene_Repair::Vocab,    :repair)
    add_command(Vocab::ShopCancel, :cancel)
  end
end
#===============================================================================
# Item Selection Window
#===============================================================================
class Window_EquipRepair < Window_ItemList
  def enable?(item)
    return true if item.is_a?(RPG::EquipItem) && item.can_repair? && $game_party.gold >=  item.repair_price
    return false
  end
  
  def update_help
    unless item
      @help_window.set_text(TH_Instance::Scene_Repair::No_Selected_Item)
    else
      if item.repair_price.zero?
        @help_window.set_text(TH_Instance::Scene_Repair::Can_Not_Repair)
      else
        @help_window.set_text(TH_Instance::Scene_Repair::Selected_Item + item.repair_price.to_s + Vocab.currency_unit)
      end
    end
  end
  
  def include?(item)
    !item.is_a?(RPG::Item) && !item.nil? && item.use_durability
  end
end
#===============================================================================
# Scene Repair Equip
#===============================================================================
class Scene_RepairEquip < Scene_ItemBase
  def start
    super
    create_help_window
    create_gold_window
    create_item_window
    create_command_window
  end
  
  def create_item_window
    wy = @help_window.y + @help_window.height + @gold_window.height
    wh = Graphics.height - wy
    @item_window = Window_EquipRepair.new(0, wy, Graphics.width, wh)
    @item_window.viewport = @viewport
    @item_window.help_window = @help_window
    @item_window.set_handler(:ok,     method(:on_item_ok))
    @item_window.set_handler(:cancel, method(:on_item_cancel))
    @item_window.category = :item
  end
  
  def create_gold_window
    @gold_window = Window_Gold.new
    @gold_window.x = Graphics.width - @gold_window.width
    @gold_window.y = @help_window.height
  end
  
  def create_command_window
    @command_window = Window_RepairCommand.new(@gold_window.x)
    @command_window.viewport = @viewport
    @command_window.y = @help_window.height
    @command_window.set_handler(:repair, method(:command_repair))
    @command_window.set_handler(:cancel, method(:return_scene))
  end
  
  def on_item_ok
    $game_party.lose_gold(item.repair_price)
    item.repair
    @gold_window.refresh
    on_item_sound
    activate_item_window
  end
  
  def on_item_cancel
    @item_window.unselect
    @item_window.deactivate
    @command_window.activate
    @help_window.set_text('')
  end
  
  def command_repair
    @command_window.deactivate
    @item_window.activate
    @item_window.select(0)
  end
  
  def on_item_sound
    RPG::SE.stop
    sound_effect = TH_Instance::Scene_Repair::SE
    RPG::SE.new(sound_effect[0], sound_effect[1], sound_effect[2]).play
  end
end
#===============================================================================
# Apply changes to the scripts you included.  Can combine if I make a
# Durability Core instead of 2 seperate scripts.
#===============================================================================
if $imported[:Sel_Weapon_Durability]
class RPG::Weapon
  alias :repair_price_mod :repair_price
  def repair_price
    return (repair_price_mod*TH_Instance::Scene_Repair::Price_Mod).to_i
  end
end
end
if $imported[:Sel_Armor_Durability]
class RPG::Armor
  alias :repair_price_mod :repair_price
  def repair_price
    return (repair_price_mod*TH_Instance::Scene_Repair::Price_Mod).to_i
  end
end
end
#===============================================================================
# End of File
#===============================================================================