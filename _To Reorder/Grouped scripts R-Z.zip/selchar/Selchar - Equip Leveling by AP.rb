#===============================================================================
# Script: Instance Equip Leveling by Ap
# Author: Selchar
# Credit: Tsukihime
# Required: Tsukihime's Item Instance
# Required: Selchar's Weapon Leveling Base
# Required: Selchar's Basic AP System
#===============================================================================
=begin
This script, when paired with the Weapon Leveing Base, allows select equipment to
gain ap and level up after battle.
#-------------------------------------------------------------------------------
# Weapon/Armor Notetag
#-------------------------------------------------------------------------------
<ap curve: x>
<ap curve>
x
</ap curve>

Where x in either notetag is a formula that'll be used to determine an equip's
ap curve.
=end
module TH_Instance
  module Equip
    #Set this to what you want the default ap curve to be.
    Default_Ap_Curve = '(level)*5'
    
    #Regex
    Ap_Curve_Regex = /<ap[-_ ]?curve:\s*(.*)\s*>/i
    Ext_Ap_Curve_Regex = /<ap[-_ ]?curve>(.*)<\/ap[-_ ]?curve>/im
  end
end
#===============================================================================
# Rest of the Script
#===============================================================================
$imported = {} if $imported.nil?
$imported[:Sel_Equip_AP_Leveling] = true
unless $imported["TH_InstanceItems"]
  msgbox("Tsukihime's Instance Items not detected,
exiting")
  exit
end
unless $imported[:Sel_Equip_Leveling_Base]
  msgbox("Selchar's Equip Leveling Base not detected,
Exiting")
  exit
end
unless $imported[:basic_ap]
  msgbox("Selchar's Basic AP System not detected,
Exiting")
  exit
end

class Game_Actor < Game_Battler
  def gain_equip_ap(amount)
    equips.each do |i|
      next unless i
      next unless i.can_level
      next if i.level == i.max_level
      i.ap += amount
      while i.ap >= i.ap_to_level
        i.ap = i.ap_to_level if i.level == (i.max_level-1)
        i.level_up
        i.equip_level_message(self.name, i)
      end
    end
  end
end

module BattleManager
  class << self
    alias :instance_equip_gain_ap :gain_ap
  end
  
  def self.gain_ap
    instance_equip_gain_ap
    $game_party.battle_members.each do |actor|
      actor.gain_equip_ap($game_troop.ap_total) unless actor.death_state?
    end
    wait_for_message
  end
end
#===============================================================================
# Note Tags Equip Info
#===============================================================================
class RPG::EquipItem
  attr_accessor :ap
  def ap_curve
    @note =~ TH_Instance::Equip::Ap_Curve_Regex ? @ap_curve = $1 : @ap_curve = nil if @ap_curve.nil?
    @note =~ TH_Instance::Equip::Ext_Ap_Curve_Regex ? @ap_curve = $1 : @ap_curve = TH_Instance::Equip::Default_Ap_Curve if @ap_curve.nil?
    @ap_curve
  end
  def ap_to_level
    eval(ap_curve)
  end
  def equip_level_message(actor_name, equip_item)
    message = "%s's %s leveled up!" % [actor_name, $game_party.get_template(equip_item).name]
    $game_message.add(message)
  end
end
#===============================================================================
# Instance Manager: setup_instance
#===============================================================================
module InstanceManager
  class << self
    alias :instance_equip_ap_level_setup :setup_equip_instance
  end
  
  def self.setup_equip_instance(obj)
    obj.ap = 0 if obj.can_level
    instance_equip_ap_level_setup(obj)
  end
end
#===============================================================================
# End of File
#===============================================================================