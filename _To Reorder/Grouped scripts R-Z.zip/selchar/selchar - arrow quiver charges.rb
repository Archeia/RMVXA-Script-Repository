*reads other thread as well* Under the assumption that the item(quiver) would simply be in your invenory the following should work.
=begin
Code:
<custom cost requirement>
$game_party.find_instance_item($data_items[X])
</custom cost requirement>

<custom cost perform>
$game_party.consume_item($game_party.find_instance_item($data_items[X]))
</custom cost perform>
The above of course doesn't work properly(negative charge o.o) if you use the <no charge keep> notetag but in the event that you do use it then add the following to the bottom of my script.
=end
Code:
class Game_Party < Game_Unit
def find_instance_item_wc(template_item)
container_list = item_container_list(template_item)
return container_list.find {|obj| obj.template_id == template_item.template_id && obj.current_charge > 0 }
end
end
=begin
Then use...
Code:
<custom cost requirement>
$game_party.find_instance_item($data_items[X])
</custom cost requirement>

<custom cost perform>
$game_party.consume_item($game_party.find_instance_item($data_items[X]))
</custom cost perform>
In both cases X would be the ID of your item who's charge you wish to consume.
=end