# I wanted to recharge for free when the player does a certain action. 
# For not-entirely-random example, imagine a DnD item with X uses a day. 
# Could I recharge all instances of that item without player intervention

# use the script call recharge_all_of(template_id) where template_id is the 
# id in the database of the item you wish to recharge.

class Game_Interpreter  
def recharge_all_of(template_id)    
$data_items.each do |item|      
next unless item      
next if item.is_template?      
item.recharge if item.template_id == template_id    
end  
end
end