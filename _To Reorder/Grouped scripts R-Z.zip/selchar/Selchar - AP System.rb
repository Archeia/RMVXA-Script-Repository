#===============================================================================
# Script: Basic AP System
# Author: Selchar, slightly modifed from Fomar
#-------------------------------------------------------------------------------
=begin
Simple AP(Ability Point) System, awarding ap in battle mimicking the awarding
of experience.  To utilize this script in another script, alias the method
gain_ap(ap) in the class Game_Actor and add your logic there.

#-------------------------------------------------------------------------------
# Enemy Notetag
#-------------------------------------------------------------------------------
<ap: x> Where x is the amount of Ap you want the enemy to give.
=end
#===============================================================================
# Script Begin
#===============================================================================
module Vocab
  ObtainAp = "%s AP was obtained!"
end

$imported = {} if $imported.nil?
$imported[:basic_ap] = true

class Game_Actor < Game_Battler
  #Alias This or similar method in BattleManager
  def gain_ap(ap)
  end
end

module BattleManager
  class <<self; alias :display_ap_with_exp :display_exp; end
  def self.display_exp
    display_ap_with_exp
    display_ap
  end
  def self.display_ap
    if $game_troop.ap_total > 0
      text = sprintf(Vocab::ObtainAp, $game_troop.ap_total)
      $game_message.add('\.' + text)
    end
  end
  
  class <<self; alias :gain_ap_with_exp :gain_exp; end
  def self.gain_exp
    gain_ap_with_exp
    gain_ap
  end
  #Aliasing this is also an option
  def self.gain_ap
    $game_party.all_members.each do |actor|
      actor.gain_ap($game_troop.ap_total)
    end
    wait_for_message
  end
end

class Game_Troop < Game_Unit
  def ap_total
    dead_members.inject(0) {|r, enemy| r += enemy.ap }
  end
end

class Game_Enemy < Game_Battler
  def ap
    enemy.note =~ /<ap:\s*(.*)>/i ? $1.to_i : 0
  end
end
#===============================================================================
# End of File
#===============================================================================