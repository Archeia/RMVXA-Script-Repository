#===============================================================================
# Script: Equip Evolve by Exp Ver. 1.01
# Author: Selchar
# Credit: Tsukihime
# Required: Tsukihime's Item Instance
#===============================================================================
=begin
This script allows equipment to change from one into another after gaining
certain amounts of exp.  It uses a combination of techniques from my Leveling/
Exp/Durability scripts to get the job done.  It can work on it's own, or with
the leveling script, preferably below.

Why would you want an equip to transform into a whole different?  Different
stats, features, notetags, icons, the works!
#-------------------------------------------------------------------------------
# Weapon/Armor Notetag
#-------------------------------------------------------------------------------
<exp to evolve: x>
Where x is how much exp is required before the equip can change.

<evolve to: x>
Where x is the id of the equip you wish to change into.  Armor will always give
armor, weapons will always give weapons.  No equip transformations will take
place without this notetag.
=end
module Selchar
  module TH_Instance
    module Equip
      #Default Exp required to evolve equipment
      Default_Evo_Exp = 200
      
      #Text to display at an equip's evolution
      Evolve_Text = ' transforms into '
    end
  end
end
#===============================================================================
# Rest of the Script
#===============================================================================
$imported = {} if $imported.nil?
$imported[:Sel_Evolving_Equip] = true
unless $imported["TH_InstanceItems"]
  msgbox("Tsukihime's Instance not detected, exiting")
  exit
end

class Game_Actor < Game_Battler
  def gain_equip_exp_for_evolve(amount)
    equips.each do |i|
      next unless i
      next unless i.evolve_to
      i.evolve_exp += amount
      i.evolve_equip(self) if i.evolve_exp >= i.exp_to_evolve
    end
  end
end

module BattleManager
  class << self
    alias :instance_equip_gain_evolve_exp :gain_exp
  end
  
  def self.gain_exp
    instance_equip_gain_evolve_exp
    $game_party.all_members.each do |actor|
      actor.gain_equip_exp_for_evolve($game_troop.exp_total)
    end
    wait_for_message
  end
end
#===============================================================================
# Note Tags Equips
#===============================================================================
class RPG::EquipItem
  attr_accessor :evolve_exp
  def evolve_to
    @note =~ /<evolve[-_ ]?to:\s*(.*)\s*>/i ? @evolve_to = $1.to_i : @evolve_to = false if @evolve_to.nil?
    @evolve_to
  end
  
  def exp_to_evolve
    @note =~ /<exp[-_ ]?to[-_ ]?evolve:\s*(.*)\s*>/i ? @exp_to_evolve = $1.to_i : @exp_to_evolve = Selchar::TH_Instance::Equip::Default_Evo_Exp if @exp_to_evolve.nil?
    @exp_to_evolve
  end
  
  def evolve_equip(actor)
    new_item = self.is_a?(RPG::Weapon) ? $data_weapons[evolve_to] : $data_armors[evolve_to]
    new_item = InstanceManager.get_instance(new_item)
    return unless new_item
    actor.equips.each_index do |i|
      if actor.equips[i] == self
        actor.change_equip(i, nil)
        $game_party.gain_item(self, -1)
        $game_party.gain_item(new_item, 1)
        actor.change_equip(i, new_item)
        equip_evolve_message(actor.name)
        break
      end
    end
  end
  
  def equip_evolve_message(actor_name)
    new_item = self.is_a?(RPG::Weapon) ? $data_weapons[evolve_to] : $data_armors[evolve_to]
    message = actor_name + "'s " + $game_party.get_template(self).name + Selchar::TH_Instance::Equip::Evolve_Text + new_item.name
    $game_message.add(message)
  end
end
#===============================================================================
# Instance Manager: setup_instance
#===============================================================================
module InstanceManager
  class << self
    alias :instance_equip_evolve_setup :setup_equip_instance
  end
  
  def self.setup_equip_instance(obj)
    instance_equip_evolve_setup(obj)
    obj.evolve_exp = 0
    obj.evolve_to
    obj.exp_to_evolve
  end
end
#===============================================================================
# End of File
#===============================================================================