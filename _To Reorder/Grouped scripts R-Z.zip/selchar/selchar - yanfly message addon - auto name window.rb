#===============================================================================
#Script: Yanfly Message Addon - Auto Name Window Names
#Author: Selchar
#Requestor: mylafter
#-------------------------------------------------------------------------------
=begin
This is a simple addon to Yanfly's Message System allowing for automatic name
window setup based on the name and index of the used faceset image.  Setup is
in the Selchar::Namebox module below.
Examples:

  Names["Actor1"] = [:All, "Ralph"]
 
  The above will set all indexes/faces of the Actor1 Faceset image to Ralph, so any
  and all faces from it will show Ralph in the Name Window.
 
  Names["Actor3"] = [
      $game_actors[1].name,
      "",
      "Yanfly",
      ]
     
  The above will set the first 3 indexes/faces of the Actor3 Faceset image.
  The first face is set to the name of Actor 1
  The second face is actually skipped since it's blank.
  The third face will be set to Yanfly.
 
  Names["Actor2"] = [
  "\\c[1]\\n[4]"
  ]
 
  Escape codes can also be used, just remember the extra \.  The above will
  set the first index/face of the Actor2 Faceset image to Actor 4's name, with
  colored text using color index 1(blue)
 
  If the escapecode \n<x> is already used in the textbox to designate a name, it
  will take priority over the image.
=end

module Selchar
  module NameBox
    Names = {}  #Do not remove
    def self.names_init
     #Names[Faceset name] = []
     
      Names["Actor1"] = [:All, "Hello World"]
      Names["Actor4"] = [
      $game_actors[1].name,
      "\\n[2]",
      "Terrence",
      "Top-Right Corner",
      "\\c[1]\\n[4]",
      "5",
      "Six",
      "Last",
      ]
      Names["Actor3"] = [:All, "Goodbye World"]
    end
  end
end
#===============================================================================
# Rest of the Script
#===============================================================================
$imported = {} if $imported.nil?
$imported[:Yanfly_Auto_Nameboxes] = true

unless $imported["YEA-MessageSystem"]
  msgbox("Yanfly's Message System not detected,
exiting")
  exit
end

module Selchar::NameBox
  @init = false
  def self.name(faceset, index)
    if @init == false
      self.names_init
      @init = true
    end
   
    return "" unless Names[faceset]
    return Names[faceset][1] if Names[faceset][0] == :All
    return Names[faceset][index] if Names[faceset][index]
    return ""
  end
end

class Window_Message < Window_Base
  alias :sel_start_name_window :start_name_window
  def start_name_window
    if @name_text == ""
      @name_text = Selchar::NameBox.name($game_message.face_name, $game_message.face_index)
    end
    sel_start_name_window
  end
end