#==============================================================================
# MOG VX - Event Sensor Range
#==============================================================================
# By Moghunter
# changed by thiago_d_d to work with events
# http://www.atelier-rgss.com/
# http://thiagodd.blogspot.com.br/
#
# ■ Activates one event page (SELF SWITCH D, for example) depending on other event # distance,
#   so it's like the first event senses the second event.
# ---------------------------------------------------------------------------
# To make an event sense other event, put his name like this:
#
# xxeventname
#
# xx - sensor distance. (Examples: 1, 10, 30)
# Example - 5Sign
# And there is more, the event that need to be "sensed" needs to have an comment
# in its page, with the same name you used above, in the event that "senses"
# For example, if the sensor event is called:
# 5Sign
# The events that will be senses needs to have this comment in its page:
# 5Sign
# ---------------------------------------------------------------------------
# NOTE - Don't forget to create the new page that will be activated when the event
# "senses".
#==============================================================================
module MOG
  # SELF SWITCH that will be activated. ( A, B , C ,D )
  SENSOR_KEY = "D"
end
class Game_Event < Game_Character
  attr_reader      :event
  #--------------------------------------------------------------------------
  # ● initialize
  #--------------------------------------------------------------------------
  alias mog_sensor_range initialize
  def initialize(map_id, event)
    @sensor_comment = event.name
    @sensor_range = event.name.to_i
    @key_act = false
    @key_act_old = @key_act
    mog_sensor_range(map_id, event)   
  end   
  #--------------------------------------------------------------------------
  # ● update
  #--------------------------------------------------------------------------
  alias mog_sensor_update update
  def update
      mog_sensor_update
      if @sensor_range > 0
        $game_map.events.each do |a, i|
          if i == self
            next
          end
           command_param = i.event.pages[0].list[0].parameters[0]
           if command_param == @sensor_comment
             sx = @x - i.x
             sy = @y - i.y
             range = (sx.abs + sy.abs)
             sensor = (range >= @sensor_range)     
             if sensor
                @key_act = false
              else
                @key_act = true
                break
             end
           end
         end
      end
     page_check if @key_act_old != @key_act
   end
  #--------------------------------------------------------------------------
  # ● page_check
  #--------------------------------------------------------------------------   
   def page_check
      @key_act_old = @key_act
      key = [@map_id, @id, MOG::SENSOR_KEY]
      $game_self_switches[key] = @key_act
      refresh
   end
end