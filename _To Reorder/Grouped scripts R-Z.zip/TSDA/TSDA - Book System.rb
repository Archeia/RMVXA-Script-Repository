=begin
#===============================================================================
# TSDA Book System
#===============================================================================
# by: thiago_d_d
# http://thiagodd.blogspot.com.br
# Versions: 1.0
#===============================================================================
# This scripts is a database/viewer of books:
#  - It breaks lines.
#  - Justify the text.You can use custom BG, fonts, sounds.
#  - You can change text color using the \\C tag
#===============================================================================
# Don't forget to configure the TSDA module!
#===============================================================================
 -----> To create new books
    To create a new book, you have to type the text in this format, in the TSDA module:

BookName = [
"paragraph1",
"paragraph2",
"paragraph3",
]

Don't put new lines in every paragraph, the script will break it.
You can use only letters and underlines in the book name. This isn't a problem, as the
book title will be shown as a image you have done in the Pictures folder.

After that, modify this line in the TSDA module:
BOOKS = [blablabla]
Put your book name in this list.


 -----> Calling the book viewer
 $book_name = "bookname"
 SceneManager.call(Scene_Book)
 
 -----> Changing text color
 Use this tag:
 \\C[color number]
 
 -----> About the BG
 Must be in the Pictures folder.
#===============================================================================
=end
module TSDA
  # This is the example book
  Exemplo = [
    "        No mundo de \\C[2]Stella Anima\\C[0], o planeta Terra é constituído por uma substância imperceptível porém tão abundante quanto o próprio ar que os seres humanos respiram. Alguns chamam essa tal substância de “mana”, outros a chamam de “pó dos deuses”, mas para regra geral, foi oficialmente adotado o nome de aura estelar.A partir da aura estelar o universo foi dividido em diversas “dimensões” ou como foram oficialmente chamadas: dobras astrais.Não se sabe muito sobre as dobras astrais, apenas que Chronus é a dobra onde os humanos vivem, e outra chamada Mitrandis, onde habitam os espíritos.",
    "        Na dimensão Chronus, cada ser humano tem sua aura estelar, catalizada num ponto específico do corpo chamado vortex polar, podendo ser lunar ou solar. Neste plano as pessoas estão acostumadas a utilizar sua aura estelar para alterar a realidade, o que alguns chamam de Astralogia. Porém, nem todos os humanos tem interesse e habilidade para dominar sua aura, preferindo pagar serviços de outras pessoas. Os seres humanos que usam sua aura estelar são chamados de Espiritualistas.",
  ]
  #Windowskin used to retrive the color used by the tag \\C
  WINDOWSKIN = "Window"
  #Books list
  BOOKS = ["Exemplo"]
  #Scene to transfer after reading the book
  SCENE_TO_GO = Scene_Map
  # Put here if the book will have a cover with the book title
  # Format:
  # {
  #     "Livro" => true or false,
  #     "Livro2" => true or false
  # }
  USE_TITLE = {
    "Exemplo" => false
  }
  #Put here the picture used as a cover in the book, if the book use the cover
  # Format:
  # {
  #     "Livro" => "IMg1",
  #     "Livro2" => "IMg2"
  # }
  TITLE_IMAGE = {
  }
  # Put here if the book uses a BG or the windowskin
  # Format:
  # {
  #     "Livro" => true or false,
  #     "Livro2" => true or false
  # }
  USE_WINDOWSKIN = {
    "Exemplo" => false
  }
  # Put there the BG name used by the book, in the Pictures folder.
  # Format:
  # {
  #     "Livro" => "BG1",
  #     "Livro2" => "GB2"
  # }
  BG_IMAGE = {
    "Exemplo" => "ExemploBG"
  }
  # Put here the sound used when changing pages
  # Format:
  # {
  #     "Livro" => "Sound1",
  #     "Livro2" => "Sound1"
  # }
  PAGE_SOUND = {
    "Exemplo" => "Book1"
  }
  # Put here the text font used by the book
  # Format:
  # {
  #     "Livro" => "Trebuchet MS",
  #     "Livro2" => "Arial"
  # }
  FONT_NAME = {
    "Exemplo" => "Comic Sans MS"
  }
end
#===============================================================================
class String
  def true_size
    copy = self.clone;size = 0
    while(copy.slice!(/./m)) != nil;size += 1;end;size
  end
  #=============================================================================
  def starts_with?(string2)
    if self[0,string2.size] == string2
      $ind = string2.size;return true;else;return false;end
  end
  #=============================================================================
  def substring(starting_index,final_index)
    self[starting_index,final_index - starting_index]
  end
  #=============================================================================
  def index_of(starting_index,st)
    return -1 if starting_index > size or starting_index < 0
    for i in starting_index...size
      return i if self[i,1] == st;end;return -1
  end
  #=============================================================================
  def last_index_of(st)
    pos = -1
    while (pos = index_of(pos + 1," ")) != -1
      tpos = pos;end;return tpos
  end
  #=============================================================================
  def contains_starting_space
    (self[0,1] == " ") ? (return true) : (return false)
  end
  #=============================================================================
  def rot13
    dup.unpack("C*").map{|i| (i + 13) % 256}.pack("C*")
  end
  #=============================================================================
  def unrot13
    dup.unpack("C*").map{|i| (i - 13) % 256}.pack("C*")
  end
end
#===============================================================================
module DataManager
  class << self
    alias book_system_datamanager_create_game_objects create_game_objects
    def create_game_objects
      book_system_datamanager_create_game_objects
      TSDA.make_books(TSDA::BOOKS)
    end
  end
end
#===============================================================================
module TSDA
  class Book
    attr_reader            :name
    attr_accessor            :contents
    #===========================================================================
    def initialize(name)
      @name = name
      @contents = []
    end
    #===========================================================================
    def obfuscate
      @name = @name.rot13
      for i in 0...@contents.size
        @contents[i] = @contents[i].rot13
      end
    end
    #===========================================================================
    def unobfuscate
      @name = @name.unrot13
      for i in 0...@contents.size
        @contents[i] = @contents[i].unrot13
      end
    end
  end
  #=============================================================================
  module_function
  #=============================================================================
  def make_books(list)
    books = {}
    for book_name in list
      book = Book.new(book_name)
      ary = eval("TSDA::" + book_name)
      book.contents = ary
      books[book_name] = book
    end
    $data_books = books
  end
end
#===============================================================================
class Scene_Book < Scene_Base
  attr_reader       :book
  include TSDA
  #=============================================================================
  def start
    book_name = $book_name
    @book = $data_books[book_name]
    @pages = []
    test_bitmap = Bitmap.new(512,384)
    test_bitmap.font.name = FONT_NAME[book_name]
    page = []
    temp_string = ""
    for l in @book.contents
      copy = l.clone
      copy.gsub!(/\\C\[([0-9]+)\]/i) { "\x01[#{$1}]" }
      x = 0
      while(letter = copy.slice!(/./m)) != nil
        if page.size == 16
          @pages.push(page)
          page = []
        end
        if letter == "\x01"
          temp_string.concat(letter)
          copy.sub!(/\[([0-9]+)\]/, "")
          temp_string.concat("[" + $1.to_i.to_s + "]")
          next
        end
        l_width = test_bitmap.text_size(letter).width
        temp_string.concat(letter)
        x += l_width
        if x >= 512
          pos = temp_string.last_index_of(" ")
          use_string = temp_string.substring(0,pos)
          temp_string = temp_string.substring(pos,temp_string.size)
          if temp_string.contains_starting_space
            temp_string = temp_string.substring(1,temp_string.size)
          end
          page.push(use_string)
          x = test_bitmap.text_size(temp_string).width
        end
      end
      page.push(temp_string)
      temp_string = ""
    end
    page.push(temp_string) 
    @pages.push(page)
    if USE_TITLE[@book.name]
      bg = Sprite.new
      bg.bitmap = Cache.picture(TITLE_IMAGE[@book.name])
      while true
        Graphics.update
        Input.update
        bg.update
        if Input.trigger?(:C)
          Sound.play_decision
          break
        end
      end
    end
    create_pages
    if USE_WINDOWSKIN[@book.name]
      @book_window = Window_Base.new(0,0,544,416)
      @book_window.contents = @bt_pages[0]
      @page_index = 0
    else
      @page_index = 0
      @bg = Sprite.new
      @bg.bitmap = Cache.picture(BG_IMAGE[@book.name])
      @page_sprite = Sprite.new
      @page_sprite.z = 10
      @page_sprite.x = 16
      @page_sprite.y = 16
      @page_sprite.bitmap = @bt_pages[@page_index]
    end
  end
  #=============================================================================
  def update
    super
    @bg.update unless @bg.nil?
    @page_sprite.update unless @page_sprite.nil?
    if Input.trigger?(:RIGHT)
      last_index = @page_index
      @page_index += 1
      if @page_index > @pages.size - 1
        @page_index = @pages.size - 1
      end
      Audio.se_play("Audio/SE/" + PAGE_SOUND[@book.name]) if last_index != @page_index
      wait(40)
      if last_index != @page_index
        if USE_WINDOWSKIN[@book.name]
          @book_window.contents = @bt_pages[@page_index]
        else
          @page_sprite.bitmap = @bt_pages[@page_index]
        end
      end
    elsif Input.trigger?(:LEFT)
      last_index = @page_index
      @page_index -= 1
      if @page_index < 0
        @page_index = 0
      end
      Audio.se_play("Audio/SE/" + PAGE_SOUND[@book.name]) if last_index != @page_index
      wait(40)
      if last_index != @page_index
        if USE_WINDOWSKIN[@book.name]
          @book_window.contents = @bt_pages[@page_index]
        else
          @page_sprite.bitmap = @bt_pages[@page_index]
        end
      end
    elsif Input.trigger?(:B)
      Sound.play_cancel
      SceneManager.call(SCENE_TO_GO)
    end
  end
  #=============================================================================
  def wait(value)
    value.times{|n| Graphics.update}
  end
  #=============================================================================
  def terminate
    if USE_WINDOWSKIN[@book.name]
      @book_window.dispose
    else
      @bg.dispose
      @page_sprite.dispose
    end
  end
  #=============================================================================
  def create_pages
    @bt_pages = []
    for page in @pages
      bt = Bitmap.new(512,384)
      for i in 0...page.size
        draw_item(i,page[i],bt)
      end
      @bt_pages.push(bt)
    end
  end
  #=============================================================================
  def draw_item(index,item,bt)
    width = bt.text_size(item).width
    if width > 380
      draw_justified_text(0,index * 24,512,24,item,bt)
    else
      draw_text2(0,index * 24,512,24,item,bt)
    end
  end
  #=============================================================================
  def draw_justified_text(x,y,width,height,text,bt)
    bt.font.name = FONT_NAME[@book.name]
    bt.font.color = @font unless @font.nil?
    use_x = x
    copy = text.clone
    tmp = ""
    copy2 = text.clone
    while ((letter = copy2.slice!(/./m)).nil? == false)
      if letter == "\x01"
        copy2.sub!(/\[([0-9]+)\]/, "")
        next
      end
      tmp.concat(letter)
    end
    total_width = bt.text_size(tmp).width
    plus = ((width.to_f - total_width.to_f - 5) / tmp.true_size)
    while ((letter = copy.slice!(/./m)).nil? == false)
      if letter == "\x01"
        copy.sub!(/\[([0-9]+)\]/, "")
        bt.font.color = text_color($1.to_i)
        @font = bt.font.color
        next
      end
      letter_width = bt.text_size(letter).width
      bt.draw_text(use_x.to_i,y,letter_width * 2,height,letter)
      use_x += (letter_width + plus)
    end
  end
  #=============================================================================
  def text_color(n)
    windowskin = Cache.system(WINDOWSKIN)
    windowskin.get_pixel(64 + (n % 8) * 8, 96 + (n / 8) * 8)
  end
  #=============================================================================
  def draw_text2(x,y,width,height,text,bt)
    use_x = x
    copy = text.clone
    while ((letter = copy.slice!(/./m)).nil? == false)
      if letter == "\x01"
        copy.sub!(/\[([0-9]+)\]/, "")
        bt.font.color = text_color($1.to_i)
        next
      end
      letter_width = bt.text_size(letter).width
      bt.draw_text(use_x.to_i,y,letter_width * 2,height,letter)
      use_x += letter_width
    end
  end
end