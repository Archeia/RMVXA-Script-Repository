=begin
  Script: Spellbook
  Author: Dr.Yami
  Version: 1.00
  Last Update: 2013.04.02
  ---
  This script allows users to create spellbook (can be used for both skill and
  item) which includes many magics and skills.
  ---
  Note: Spellbook doesn't allow party to use item spellbook outside battle 
  because we can't decide which actor will use magic/skill. Skill spellbook
  can still be used outside battle.
  ---
  Free for both non-commercial and commercial purposes. Author credit is not
  required.
=end

#==============================================================================
# �� Importing - Compatible purpose.
#==============================================================================

$imported = {} if $imported.nil?
$imported["Yami-Spellbook"] = true

#==============================================================================
# �� Regular Expression
#==============================================================================

module YAMI
  module SPELLBOOK
    module REGEXP
      SPELLBOOK = /<spellbook:[ ]*(.*)>/i
    end # REGEXP
  end # SPELLBOOK
end # YAMI

#==============================================================================
# �� DataManager
#==============================================================================

module DataManager
    
  #--------------------------------------------------------------------------
  # alias method: load_database
  #--------------------------------------------------------------------------
  class <<self; alias load_database_spellbook load_database; end
  def self.load_database
    load_database_spellbook
    initialize_spellbook
  end
  
  #--------------------------------------------------------------------------
  # new method: initialize_spellbook
  #--------------------------------------------------------------------------
  def self.initialize_spellbook
    groups = [$data_skills, $data_items]
    groups.each { |group|
      group.each { |obj|
        next if obj.nil?
        obj.initialize_spellbook
      }
    }
  end
  
end # DataManager

#==============================================================================
# �� RPG::BaseItem
#==============================================================================

class RPG::BaseItem
  
  #--------------------------------------------------------------------------
  # * Public Instance Variables
  #--------------------------------------------------------------------------
  attr_reader :spellbook

  #--------------------------------------------------------------------------
  # new method: initialize_spellbook
  #--------------------------------------------------------------------------
  def initialize_spellbook
    @spellbook = []
    self.note.split(/[\r\n]+/).each { |line|
      case line
      when YAMI::SPELLBOOK::REGEXP::SPELLBOOK
        @spellbook += $1.scan(/\d+/).collect{ |i| i.to_i }
      end
    }
  end
  
  #--------------------------------------------------------------------------
  # new method: is_spellbook?
  #--------------------------------------------------------------------------
  def is_spellbook?
    @spellbook.size > 0
  end
  
end # RPG::BaseItem

#==============================================================================
# �� Game_BattlerBase
#==============================================================================

class Game_BattlerBase
  
  #--------------------------------------------------------------------------
  # alias method: skill_conditions_met?
  #--------------------------------------------------------------------------
  alias spellbook_skill_conditions_met? skill_conditions_met?
  def skill_conditions_met?(skill)
    return true if skill.is_spellbook?
    return spellbook_skill_conditions_met?(skill)
  end
  
  #--------------------------------------------------------------------------
  # alias method: item_conditions_met?
  #--------------------------------------------------------------------------
  alias spellbook_item_conditions_met? item_conditions_met?
  def item_conditions_met?(item)
    if item.is_spellbook?
      return $game_party.in_battle ? true : false
    end
    return spellbook_item_conditions_met?(item)
  end
  
end # Game_BattlerBase

#==============================================================================
# �� Window_SkillList
#==============================================================================

class Window_SkillList < Window_Selectable
  
  #--------------------------------------------------------------------------
  # * Public Instance Variables
  #--------------------------------------------------------------------------
  attr_reader :spellbook
  
  #--------------------------------------------------------------------------
  # new method: spellbook=
  #--------------------------------------------------------------------------
  def spellbook=(spellbook)
    return if @spellbook == spellbook
    @last_spellbook = index if spellbook
    @spellbook = spellbook
    refresh
    self.oy = 0
    #---
    @spellbook ? select(0) : select(@last_spellbook)
    self.activate
  end
  
  #--------------------------------------------------------------------------
  # alias method: include?
  #--------------------------------------------------------------------------
  alias spellbook_include? include?
  def include?(item)
    return !item.nil? if @spellbook
    return spellbook_include?(item)
  end
  
  #--------------------------------------------------------------------------
  # alias method: make_item_list
  #--------------------------------------------------------------------------
  alias spellbook_make_item_list make_item_list
  def make_item_list
    return [] unless @actor
    if @spellbook
      make_spell_list
    else
      spellbook_make_item_list
    end    
  end
  
  #--------------------------------------------------------------------------
  # new method: make_spell_list
  #--------------------------------------------------------------------------
  def make_spell_list
    @data = @spellbook.spellbook.collect { |i| $data_skills[i] }
  end
  
end # Window_SkillList

#==============================================================================
# �� Scene_Skill
#==============================================================================

class Scene_Skill < Scene_ItemBase
  
  #--------------------------------------------------------------------------
  # alias method: on_item_ok
  #--------------------------------------------------------------------------
  alias spellbook_on_item_ok on_item_ok
  def on_item_ok
    if item.is_spellbook?
      open_spellbook
    else
      spellbook_on_item_ok
    end
  end
  
  #--------------------------------------------------------------------------
  # alias method: on_item_cancel
  #--------------------------------------------------------------------------
  alias spellbook_on_item_cancel on_item_cancel
  def on_item_cancel
    if @item_window.spellbook
      close_spellbook
    else
      spellbook_on_item_cancel
    end
  end
  
  #--------------------------------------------------------------------------
  # new method: open_spellbook
  #--------------------------------------------------------------------------
  def open_spellbook
    @item_window.spellbook = item
  end
  
  #--------------------------------------------------------------------------
  # new method: close_spellbook
  #--------------------------------------------------------------------------
  def close_spellbook
    @item_window.spellbook = nil
  end
  
  #--------------------------------------------------------------------------
  # alias method: on_actor_change
  #--------------------------------------------------------------------------
  alias spellbook_on_actor_change on_actor_change
  def on_actor_change
    cancel_spellbook
    spellbook_on_actor_change
  end
  
end # Scene_Skill

#==============================================================================
# �� Scene_Battle
#==============================================================================

class Scene_Battle < Scene_Base
  
  #--------------------------------------------------------------------------
  # alias method: on_skill_ok
  #--------------------------------------------------------------------------
  alias spellbook_on_skill_ok on_skill_ok
  def on_skill_ok
    if @skill_window.item.is_spellbook?
      open_spellbook
    else
      spellbook_on_skill_ok
    end
  end
  
  #--------------------------------------------------------------------------
  # alias method: on_skill_cancel
  #--------------------------------------------------------------------------
  alias spellbook_on_skill_cancel on_skill_cancel
  def on_skill_cancel
    if @skill_window.spellbook
      close_spellbook
    else
      spellbook_on_skill_cancel
    end
  end
  
  #--------------------------------------------------------------------------
  # alias method: on_item_ok
  #--------------------------------------------------------------------------
  alias spellbook_on_item_ok on_item_ok
  def on_item_ok
    if @item_window.item.is_spellbook?
      open_spellbook
    else
      spellbook_on_item_ok
    end
  end
  
  #--------------------------------------------------------------------------
  # new method: close_spellbook
  #--------------------------------------------------------------------------
  def close_spellbook
    @skill_window.spellbook = nil
    case @actor_command_window.current_symbol
    when :item
      @item_window.show.activate
      @item_window.select(@last_item_spellbook)
      @last_item_spellbook = nil
      @skill_window.hide
    end
  end
  
  #--------------------------------------------------------------------------
  # new method: open_spellbook
  #--------------------------------------------------------------------------
  def open_spellbook
    case @actor_command_window.current_symbol
    when :skill
      @skill_window.spellbook = @skill_window.item
    when :item
      @skill_window.actor = BattleManager.actor
      @skill_window.spellbook = @item_window.item
      @last_item_spellbook = @item_window.index
      @item_window.hide
      @skill_window.show.activate
    end
  end
  
  #--------------------------------------------------------------------------
  # alias method: command_skill
  #--------------------------------------------------------------------------
  alias spellbook_command_skill command_skill
  def command_skill
    spellbook_command_skill
    close_spellbook
  end
  
  #--------------------------------------------------------------------------
  # alias method: command_item
  #--------------------------------------------------------------------------
  alias spellbook_command_item command_item
  def command_item
    spellbook_command_item
    @item_window.select(@last_item_spellbook) if @last_item_spellbook
    @last_item_spellbook = nil
  end
  
end # Scene_Battle

#==============================================================================
#
# End of File
#
#==============================================================================