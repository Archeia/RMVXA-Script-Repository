class Spriteset_Map
  def dispose_parallax
    return if @parallax == nil
    @parallax.bitmap.dispose if @parallax.bitmap
    @parallax.dispose
    @parallax_image.dispose if @parallax_image != nil
    dispose_overlay_map
  end
 
  def update_parallax
    if $game_system.can_update_parallax_ex?
       refresh_parallax if can_refresh_parallax?
       update_parallax_transition_effect
       update_parallax_effects
       update_overlay
       return
    end
    mog_parallax_ex_update_parallax 
  end 
 
  def update_om_ground
    return unless @ground || @ground.disposed?
    @ground.visible = $game_switches[YSA::OVERLAY::GROUND_SWITCH] if @ground.visible != $game_switches[YSA::OVERLAY::GROUND_SWITCH]
    @ground.ox = $game_map.display_x * 32 if @ground.ox != $game_map.display_x * 32
    @ground.oy = $game_map.display_y * 32 if @ground.oy != $game_map.display_y * 32
    if @current_ground != $game_variables[YSA::OVERLAY::GROUND_VARIABLE]
      filename = YSA::OVERLAY::GROUND
      filename += $game_map.map_id.to_s
      filename += "-" + $game_variables[YSA::OVERLAY::GROUND_VARIABLE].to_s
      @ground.bitmap = Cache.overlay(filename)
      @current_ground = $game_variables[YSA::OVERLAY::GROUND_VARIABLE]
    end
  end
 
  def update_om_par
    return unless @par || @par.disposed?
    @par.visible = $game_switches[YSA::OVERLAY::PARALLAX_SWITCH] if @par.visible != $game_switches[YSA::OVERLAY::PARALLAX_SWITCH]
    @par.ox = $game_map.display_x * 32 if @par.ox != $game_map.display_x * 32
    @par.oy = $game_map.display_y * 32 if @par.oy != $game_map.display_y * 32
    if @current_par != $game_variables[YSA::OVERLAY::PARALLAX_VARIABLE]
      filename = YSA::OVERLAY::PARALLAX
      filename += $game_map.map_id.to_s
      filename += "-" + $game_variables[YSA::OVERLAY::PARALLAX_VARIABLE].to_s
      @par.bitmap = Cache.overlay(filename)
      @current_par = $game_variables[YSA::OVERLAY::PARALLAX_VARIABLE]
    end
  end
 
  def update_om_light
    return unless @light || @light.disposed?
    @light.visible = $game_switches[YSA::OVERLAY::LIGHT_SWITCH] if @light.visible != $game_switches[YSA::OVERLAY::LIGHT_SWITCH]
    @light.ox = $game_map.display_x * 32 if @light.ox != $game_map.display_x * 32
    @light.oy = $game_map.display_y * 32 if @light.oy != $game_map.display_y * 32
    if @current_light != $game_variables[YSA::OVERLAY::LIGHT_VARIABLE]
      filename = YSA::OVERLAY::LIGHT
      filename += $game_map.map_id.to_s
      filename += "-" + $game_variables[YSA::OVERLAY::LIGHT_VARIABLE].to_s
      @light.bitmap = Cache.overlay(filename)
      @current_light = $game_variables[YSA::OVERLAY::LIGHT_VARIABLE]
    end
  end
 
  def update_om_shadow
    return unless @shadow || @shadow.disposed?
    @shadow.visible = $game_switches[YSA::OVERLAY::SHADOW_SWITCH] if @shadow.visible != $game_switches[YSA::OVERLAY::SHADOW_SWITCH]
    @shadow.ox = $game_map.display_x * 32 if @shadow.ox != $game_map.display_x * 32
    @shadow.oy = $game_map.display_y * 32 if @shadow.oy != $game_map.display_y * 32
    if @current_shadow != $game_variables[YSA::OVERLAY::SHADOW_VARIABLE]
      filename = YSA::OVERLAY::SHADOW
      filename += $game_map.map_id.to_s
      filename += "-" + $game_variables[YSA::OVERLAY::SHADOW_VARIABLE].to_s
      @shadow.bitmap = Cache.overlay(filename)
      @current_shadow = $game_variables[YSA::OVERLAY::SHADOW_VARIABLE]
    end
  end
end