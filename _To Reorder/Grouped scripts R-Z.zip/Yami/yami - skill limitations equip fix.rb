class Game_Actor < Game_Battler#Thanks to Shiggy
    def equip_skill(index, id)
        return false unless skill_equippable?(index,id)
        if @equip_skills.include?(id) && id != 0
            @equip_skills[@equip_skills.index(id)] = @equip_skills[index]
        end
        @equip_skills[index] = id
    end
     
    def skill_equippable?(index,id)
     
        return true if id == 0
        skill = $data_skills[id]
        slot_numbers = tag_slots[skill.skill_tag]
        slot_fill = skill_tags(skill.skill_tag)
        if @equip_skills[index] > 0 && $data_skills[@equip_skills[index]].skill_tag == skill.skill_tag
            return false if slot_fill > slot_numbers
        else
            return false if slot_fill >= slot_numbers
        end
        return yes_seel_skill_equippable?(id)
  end
     
     
     
end