################################################################################
#  Message Windows 2.2.2                                                       #
#         by Tidloc                                  (May-27-17)               #
#==============================================================================#
#  Feel free to use it in your own RPG-Maker game.                             #
#  But please give me credits for this hell of work ^_^                        #
#------------------------------------------------------------------------------#
#  This script lets you have message-popups, for either small events(like      #
#  gaining an item/gold) or big popups(like accepting/resolving a quest)       #
#------------------------------------------------------------------------------#
#  This script starts itself as soon as anything is entered via the according  #
#  commands. And no information will be lost, one will be showed after the     #
#  other.                                                                      #
#  to set a message into the small window use the following syntax:            #
#      Tidloc.exe(*text*,:SmallText)                                           #
#  to set a message into the big popup use the following syntax:               #
#      Tidloc.exe(*text*,:BigText)                                             #
#  2.1 update: now you can show permamently a text (like quest) window with up #
#  to 3 entries with the following syntax:                                     #
#      Tidloc.exe([*identifier*,*text*],:QuestText_add)                        #
#  The ifentifier here is needed to erase these entries later again with the   #
#  following syntax:                                                           #
#      Tidloc.exe(*identifier*,:QuestText_clear)                               #
#------------------------------------------------------------------------------#
#  You can set music- and/or sound-effects to be played when the a big message #
#  pops up, for details see below.                                             #
#------------------------------------------------------------------------------#
#  Description of the constants:                                               #
#      Time ........... the time, the big popup shall be displayed             #
#      Max_History .... defines how many entries shall be saved in the history #
#      Big_size ....... the text-size in the big popup                         #
#      Big_Width ...... width of the text                                      #
#      Big_Height ..... height of the text                                     #
#      Big_X .......... the text's upper left corner x coordinate              #
#      Big_Y .......... the text's upper left corner y coordinate              #
#      Big_ME ......... ME to be played when a new big text pops up            #
#      Big_SE ......... SE to be played when a new big text pops up            #
#      Big_Color_1 .... outer color of the big popup's background(in hex code) #
#      Big_Color_2 .... inner color of the big popup's background(in hex code) #
#      Gold_Popup ..... text entries in the small window for receiving/losing  #
#                       gold?                                                  #
#      Item_Popup ..... text entries in the small window for receiving/losing  #
#                       item?                                                  #
#      Small_Lines .... number of maximum lines in the small window            #
#      Small_Width .... Width of the small window                              #
#      Small_Height ... maximum height of the small window                     #
#      Small_X ........ upper left corner's x coordinate of the small window   #
#      Small_Y ........ upper left corner's y coordinate of the small window   #
#      Sml_Color_1 .... outer color of the small windowbackground(in hex code) #
#      Sml_Color_2 .... inner color of the small windowbackground(in hex code) #
#      Quest_Entries .. Maximum Numer of Entries displayed                     #
#      Quest_Width .... width of the quest window                              #
#      Quest_Height ... height of the quest window                             #
#      Quest_X ........ upper left corner's x coordinate of the quest window   #
#      Quest_Y ........ upper left corner's y coordinate of the quest window   #
#      Quest_C1 ....... outer color of the quest window's background (in hex)  #
#      Quest_C2 ....... inner color of the quest window's background (in hex)  #
#------------------------------------------------------------------------------#
#  Now the history of the last entries can be checked. you may access this     #
#  scene by menu, key on the map or with the script command:                   #
#     Tidloc.exe("Message",:call)                                              #
#------------------------------------------------------------------------------#
# you can change the windowcolor, tone, opacity and background of this script, #
# by editing the following constants:                                          #
#    Windowskin = "Name of the windowskin in systemfolder"                     #
#    Windowtone = [a,b,c]                                                      #
#    Opacity    = 255                                                          #
#    Background = "Name of picture in the picturefolder"                       #
# where a,b and c are the RPG-values.                                          #
#==============================================================================#
#   If any questions appear feel free to contact me!                           #
#                                         tidloc@gmx.at                        #
#                                         149436915 (ICQ)                      #
################################################################################

$imported = {} if $imported.nil?
$imported["Tidloc-MessageWindow"] = [2,2,2]
$needed.push ["Tidloc-Header",[2,13,10],true,"Tidloc's Message Windows"]

module Tidloc
######### if you don't want to call the history via a Key on the map, simply
######### leave nil, or else put the desired Key here
  Keys = {} if Keys.nil?
  Keys["Message"] = nil
  Menu = {} if Menu.nil?
  Menu["Message"] = nil
  
  
  module Message
    Time        = 4
    Max_History = 50
    Scrollspeed = 8
    
    Big_size    = 48
    Big_Width   = (Graphics.width * 3 / 4.0).to_i
    Big_Height  = Big_size+48
    Big_X       = (Graphics.width - Big_Width) / 2
    Big_Y       = (Graphics.height/2)-(Big_size)
    Big_ME      = "Item"
    Big_SE      = nil
    Big_Color_1 = "8020FF"
    Big_Color_2 = "8040FF"
    
    Gold_Popup  = true
    Item_Popup  = true
    Small_Lines = 5
    Small_Width = Graphics.width* 3 /4.0
    Small_Height= Small_Lines*24+48
    Small_X     = -16
    Small_Y     = 32
    Sml_Color_1 = "20FF80"
    Sml_Color_2 = "2080FF"
    
    Quest_Entries = 3
    Quest_Width   = Graphics.width* 3 /4.0
    Quest_Height  = Quest_Entries*24+48
    Quest_X       = Graphics.width* 2 /3.0
    Quest_Y       = 32
    Quest_C1      = "FF0040"
    Quest_C2      = "FF0000"
    
    Windowskin    = nil
    Windowtone    = nil
    Background    = nil
    Opacity       = 255
    Back_BGS      = nil
  end
  module Vocabs;class<<self
    def Message(code,lang)
      if    lang == "ger"
        case code
        when "Name";    return "Nachrichten-Log"
        when "Prefix";  return ""
        when "Amount";  return "<color=black>*</color>"
        when "Receive"; return "<color=cyan>erhalten</color>"
        when "Loose";   return "<color=red>verloren</color>"
        end
      elsif lang == "eng"
        case code
        when "Name";    return "Message-Log"
        when "Prefix";  return ""
        when "Amount";  return "<color=black>×</color>"
        when "Receive"; return "<color=cyan>received</color>"
        when "Loose";   return "<color=red>lost</color>"
        end
      end
    end
  end;end
end

################################################################################
#                                                                              #
################################################################################

module Tidloc
  module Message
    class Window_Message_big < Window_Selectable
      def initialize
        super 0,Tidloc::Message::Big_Y,Graphics.width,Tidloc::Message::Big_Height
        self.opacity = 0
        self.contents_opacity = 0
        deactivate
      end
      def draw_all_items
        self.contents = Bitmap.new(self.width-32,self.height-32) 
        draw_item
        $game_temp._tidloc_message_big[0..1] = $game_temp._tidloc_message_big[1]
        if $game_temp._tidloc_message_big[0] == nil
          $game_temp._tidloc_message_big = [] 
        end
      end
      def draw_item
        return if $game_temp._tidloc_message_big[0].nil?
        RPG::ME.new(Tidloc::Message::Big_ME,66,100).play if Tidloc::Message::Big_ME
        RPG::SE.new(Tidloc::Message::Big_SE,66,100).play if Tidloc::Message::Big_SE
        rect = [Rect.new,Rect.new]
        rect[0].width = Graphics.width/2
        rect[1].width = Graphics.width/2
        rect[0].height = Tidloc::Message::Big_Height
        rect[1].height = Tidloc::Message::Big_Height
        rect[0].x = 0
        rect[1].x = self.width/2
        rect[0].y = 0
        rect[1].y = 0
        draw_background(rect)
        self.contents.font.size = Tidloc::Message::Big_size
        if $imported["HTML-tagging"]
          self.contents.draw_html(Tidloc::Message::Big_X,0,Tidloc::Message::Big_Width,Tidloc::Message::Big_size,
                  $game_temp._tidloc_message_big[0])
        else
          self.contents.draw_text(Tidloc::Message::Big_X,0,Tidloc::Message::Big_Width,Tidloc::Message::Big_size,
                  $game_temp._tidloc_message_big[0])
        end
      end
      def draw_background(rect)
        temp=Tidloc::Message::Big_Color_1
        temp=[temp[0..1].hex,temp[2..3].hex,temp[4..5].hex]
        color1 = Color.new(temp[0], temp[1], temp[2],  0)
        temp=Tidloc::Message::Big_Color_2
        temp=[temp[0..1].hex,temp[2..3].hex,temp[4..5].hex]
        color2 = Color.new(temp[0], temp[1], temp[2],160)
        contents.gradient_fill_rect(rect[0], color1, color2)
        contents.gradient_fill_rect(rect[1], color2, color1)
      end
    end
    
    
    class Window_Message_small < Window_Selectable
      def initialize
        super Tidloc::Message::Small_X,Tidloc::Message::Small_Y,Tidloc::Message::Small_Width,Tidloc::Message::Small_Height
        self.opacity = 0
        self.contents_opacity = 0
        deactivate
      end
      def draw_all_items
        self.contents = Bitmap.new(self.width-32,self.height-32) 
        for i in 0...Tidloc::Message::Small_Lines
          draw_item(i)
        end
        $game_temp._tidloc_message_small[0..1] = $game_temp._tidloc_message_small[1]
        if $game_temp._tidloc_message_small[0] == nil
          $game_temp._tidloc_message_small = []
          
        end
      end
      def draw_item(index)
        return if $game_temp._tidloc_message_small[index].nil?
        rect = Rect.new
        rect.x      = 0
        rect.y      = index*26
        rect.width  = Tidloc::Message::Small_Width
        rect.height = 32
        draw_background(rect)
        self.contents.font.size = 16
        if $imported["HTML-tagging"]
          self.contents.draw_html(0,index*24+8,Tidloc::Message::Small_Width,32,
                                  $game_temp._tidloc_message_small[index])
        else
          self.contents.draw_text(0,index*24+8,Tidloc::Message::Small_Width,32,
                                  $game_temp._tidloc_message_small[index])
        end
      end
      def draw_background(rect)
        temp=Tidloc::Message::Sml_Color_1
        temp=[temp[0..1].hex,temp[2..3].hex,temp[4..5].hex]
        color1 = Color.new(temp[0], temp[1], temp[2],  0)
        temp=Tidloc::Message::Sml_Color_2
        temp=[temp[0..1].hex,temp[2..3].hex,temp[4..5].hex]
        color2 = Color.new(temp[0], temp[1], temp[2],128)
        contents.gradient_fill_rect(rect, color2, color1)
      end
    end
    
    class Window_Message_quest < Window_Selectable
      def initialize
        super Tidloc::Message::Quest_X,Tidloc::Message::Quest_Y,Tidloc::Message::Quest_Width,Tidloc::Message::Quest_Height
        self.opacity = 0
        self.contents_opacity = 0
        deactivate
      end
      def draw_all_items
        self.contents = Bitmap.new(self.width-32,self.height-32) 
        for i in 0...Tidloc::Message::Quest_Entries
          draw_item(i)
        end
      end
      def draw_item(index)
        return if $game_temp._tidloc_message_quest[index].nil?
        rect = Rect.new
        rect.x      = 0
        rect.y      = index*26
        rect.width  = Tidloc::Message::Quest_Width
        rect.height = 32
        draw_background(rect)
        if $imported["HTML-tagging"]
          self.contents.draw_html(0,index*24+8,Tidloc::Message::Quest_Width,32,
                          "<size=16>#{$game_temp._tidloc_message_quest[index].text}")
        else
          self.contents.font.size = 16
          self.contents.draw_text(0,index*24+8,Tidloc::Message::Quest_Width,32,
                                  $game_temp._tidloc_message_quest[index].text)
        end
      end
      def draw_background(rect)
        temp=Tidloc::Message::Quest_C1
        temp=[temp[0..1].hex,temp[2..3].hex,temp[4..5].hex]
        color1 = Color.new(temp[0], temp[1], temp[2],128)
        temp=Tidloc::Message::Quest_C2
        temp=[temp[0..1].hex,temp[2..3].hex,temp[4..5].hex]
        color2 = Color.new(temp[0], temp[1], temp[2], 64)
        contents.gradient_fill_rect(rect, color2, color1)
      end
    end
    
    class Window_Selectable_2 < Window_Selectable
      def initialize(x, y, width, height)
        super(x, y, width, height)
        self.windowskin = Cache.system(Tidloc::Message::Windowskin) if Tidloc::Message::Windowskin
        t = Tidloc::Message::Windowtone
        self.tone.set(t[0],t[1],t[2],128) if t
        self.opacity = Tidloc::Message::Opacity
      end
      def update_tone
        if Tidloc::Message::Windowtone
          t = Tidloc::Message::Windowtone
          self.tone.set(t[0],t[1],t[2],128)
        else
          super
        end
      end
    end
  end  
  class << self
    def Clear_Messages(incl_quest=true)
      $game_temp._tidloc_message_big   = []
      $game_temp._tidloc_message_small = []
      $game_temp._tidloc_message_quest = [] if incl_quest == true
    end
  end
end


class Scene_Map < Scene_Base
  def create_Tidloc_message
    @Tidloc_Message_big = Tidloc::Message::Window_Message_big.new
    @Tidloc_Message_big.deactivate
    @Tidloc_Message_big.opacity = 0
    @Tidloc_Message_big.contents_opacity = 0
    @Tidloc_Message_small = Tidloc::Message::Window_Message_small.new 
    @Tidloc_Message_small.deactivate
    @Tidloc_Message_small.opacity = 0
    @Tidloc_Message_small.contents_opacity = 0
    @Tidloc_Message_quest = Tidloc::Message::Window_Message_quest.new 
    @Tidloc_Message_quest.deactivate
    @Tidloc_Message_quest.opacity = 0
    @Tidloc_Message_quest.contents_opacity = 0
  end
end



class Game_Interpreter
  alias wo_tidloc_command_125 command_125
  def command_125
    wo_tidloc_command_125
    return unless Tidloc::Message::Gold_Popup
    amount = operate_value(@params[0], @params[1], @params[2])
    text= (amount>=0)? Tidloc::Vocabs.Message("Receive",$tidloc_language) : Tidloc::Vocabs.Message("Loose",$tidloc_language)
    text += ": "
    text += amount.abs.to_s + " " + $data_system.currency_unit
    Tidloc.exe(text,:SmallText)
  end
  
  alias wo_tidloc_command_126 command_126
  def command_126
    wo_tidloc_command_126
    return unless Tidloc::Message::Item_Popup
    amount = operate_value(@params[1], @params[2], @params[3])
    item  = $data_items[@params[0]]
    text= (amount>=0)? Tidloc::Vocabs.Message("Receive",$tidloc_language) : Tidloc::Vocabs.Message("Loose",$tidloc_language)
    text += ": "
    text += (amount.abs > 1)? amount.abs.to_s + Tidloc::Vocabs.Message("Amount",$tidloc_language) : ""
    text += "<icon=#{item.icon_index.to_s}>"
    text += item.name
    Tidloc.exe(text,:SmallText)
  end
  
  alias wo_tidloc_command_127 command_127
  def command_127
    wo_tidloc_command_127
    return unless Tidloc::Message::Item_Popup
    amount = operate_value(@params[1], @params[2], @params[3])
    item  = $data_weapons[@params[0]]
    text= (amount>=0)? Tidloc::Vocabs.Message("Receive",$tidloc_language) : Tidloc::Vocabs.Message("Loose",$tidloc_language)
    text += ": "
    text += (amount.abs > 1)? amount.abs.to_s + Tidloc::Vocabs.Message("Amount",$tidloc_language) : ""
    text += "<icon=#{item.icon_index.to_s}>"
    text += item.name
    Tidloc.exe(text,:SmallText)
  end
  
  alias wo_tidloc_command_128 command_128
  def command_128
    wo_tidloc_command_128
    return unless Tidloc::Message::Item_Popup
    amount = operate_value(@params[1], @params[2], @params[3])
    item  = $data_armors[@params[0]]
    text= (amount>=0)? Tidloc::Vocabs.Message("Receive",$tidloc_language) : Tidloc::Vocabs.Message("Loose",$tidloc_language)
    text += ": "
    text += (amount.abs > 1)? amount.abs.to_s + Tidloc::Vocabs.Message("Amount",$tidloc_language) : ""
    text += "<icon=#{item.icon_index.to_s}>"
    text += item.name
    Tidloc.exe(text,:SmallText)
  end
end

module Tidloc;module Message;class Tidloc_Message < Scene_Base
  def start
    super
    create_info_window
    create_tid_help    if Tidloc::Keys["Help"]
    create_background
    autoplay
  end
  def autoplay
    return false if Tidloc::Message::Back_BGS.nil?
    RPG::BGS.new(Tidloc::Message::Back_BGS,50,100).play
  end
  def create_background
    return false if Tidloc::Message::Background.nil?
    @background_window   = Window_Base.new -12,-36,Graphics.width+32,Graphics.height+64
    @background_window.z = 0
    @background_window.opacity = 0
    @background_window.draw_html 0,0,Graphics.width,Graphics.height,
    "<img="+Tidloc::Message::Background+">"
  end
  def create_info_window
    @info_window = Tidloc::Message::Window_Selectable_2.new(0, 0, Graphics.width, Graphics.height)
    @info_window.oy       = 0
    @info_window.viewport = @viewport
    @info_window.visible  = true
    
    update_info
  end
  def create_tid_help
    @tidhelp_window = Tidloc::Window_Tid_Help.new
    text += "<space=50>Scrolling in the information window:\n"
    text += eval(Tidloc::Help["Scroll_U"])+": "+Tidloc::Vocabs.Header("Scroll+2",$tidloc_language)+"\n"
    text += eval(Tidloc::Help["Scroll_D"])+": "+Tidloc::Vocabs.Header("Scroll-2",$tidloc_language)+"\n"
    @tidhelp_window.text = text
  end
  def update_all_windows
    if    Tidloc::Keys["Help"] && Input.trigger?(Tidloc::Keys["Help"])
      @tidhelp_window.show.activate
    elsif Input.press?(Tidloc::Keys["Scroll-"])
      if @tidhelp_window.active
        @tidhelp_window.scroll_down
      else
        @info_window.oy = [@info_window.oy-Tidloc::Message::Scrollspeed,0].max 
      end
    elsif Input.press?(Tidloc::Keys["Scroll+"])
      if @tidhelp_window.active
        @tidhelp_window.scroll_up
      else
        @info_window.oy += Tidloc::Message::Scrollspeed if @info_window.height + @info_window.oy - 32 < $game_system._tidloc_message_history.size * 24
      end
    elsif Input.trigger?(:B) || Input.trigger?(:C)
      if @tidhelp_window.active
        @tidhelp_window.hide.deactivate
      else
        SceneManager.return
      end
    end
    update_info
  end
  def update_info
    @info_window.contents = Bitmap.new(@info_window.width-32,2000)
    for i in 0...$game_system._tidloc_message_history.size
      if $imported["HTML-tagging"]
        @info_window.contents.draw_html(0,24*i,@info_window.width-8,32,$game_system._tidloc_message_history[i])
      else
        @info_window.draw_text(0,24*i,@info_window.width-8,32,$game_system._tidloc_message_history[i])
      end
    end
  end
  def pre_terminate
    RPG::BGS.stop
  end
  def terminate
    super
    while SceneManager.scene.is_a?(Tidloc::Message::Tidloc_Message)
      SceneManager.return
    end
  end
  def Tidloc_Message.call
    if SceneManager.scene.is_a?(Scene_Map)
      SceneManager.call(Tidloc::Message::Tidloc_Message)
    else
      SceneManager.goto(Tidloc::Message::Tidloc_Message)
    end
  end
end;end;end