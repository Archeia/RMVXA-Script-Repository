=begin
  addition to my script diablo equipment.
  copy the commented template right above the first hash-line and paste it
  between the two hashlines. the tags can be adjusted as following:
  
  Name of the tag:
    temp.last.name     =  "Name"
    temp.last.descr    =  "additional description"
    temp.last.used     =  true  <- must stay true!
    temp.last.icon     =  0 <- icon-id, that shall be displayed in the socket
    temp.last.id       =  0 <- id of the corresponding item in the database
    temp.last.s_type   =  0 <- enter here if it can only be inserted into certain sockets (0=everywhere)
    temp.last.t_c      =  0 <- class this insertion can be applied to 0=all 1=only weapons 2=only armors
    temp.last.t_id     =  0 <- id of the item this insertion can be applied to (only when class is set too)
    

  Prerequesites of the tag: L  H  M  S  D  M  M  A  L  D  V
                            V  P  P  T  E  A  D  G  C  E  I
                            L        R  f  G  F  I  K  X  T
    temp.last.prere    =  [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
  
Bonus of the tag: (random bonus will be calculated for each item seperately)
                              H  M  S  D  M  M  A  L  D  V
                              P  P  T  E  A  D  G  C  E  I
                                    R  F  G  F  I  K  X  T
    temp.last.fix      =    [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] <- fixed bonus
    temp.last.random1  =    [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] <- lower bound of random bonus
    temp.last.random2  =    [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] <- upper bound of random bonus
  
                           H  E  C  C  M  M  C  H  M  T
                           I  V  R  E  E  R  N  P  P  P
                           T  A  I  V  V  F  T  R  R  R
    temp.last.b_xparam = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    
                           T  G  R  P  M  T  P  M  F  E
                           G  R  E  H  C  C  D  D  D  X
                           R  D  C  A  R  R  R  R  R  R
    temp.last.b_sparam = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    
  making an insert to gain lvl, set this true and define the needed exp per lvl
  right afterwards:
    temp._exp_enabled = *true*/*false*
    temp._exp_needed  = []
    
  adding skills, when equipping and releasing skills when unequipping item,
  enter the database ID of the skill in this array:
    temp.last.skills  = []
    
    temp.last.commands = [] <- section to add complex commands, see header for information
    
  price adjusting:
    temp.last.set_price(0)  <- set_price(*x*) ....... price of the enchated item will be offset by x
    
    
    
=end







$imported = {} if $imported.nil?
$imported["Tidloc-SocketInsert"] = [1,0,0]


module Tidloc;module CustomEquip;class Sockets
  
  def Sockets.template
    temp = Socket.new [0]
=begin
    temp.push template
    temp.last.name     =  ""
    temp.last.descr    =  ""
    temp.last.used     =  true
    temp.last.icon     =  0
    temp.last.id       =  0
    temp.last.s_type   =  0
    temp.last.t_c      =  0
    temp.last.t_id     =  0
    temp.last.prere    = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    temp.last.fix      =    [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    temp.last.random1  =    [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    temp.last.random2  =    [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    temp.last.b_xparam = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    temp.last.b_sparam = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    temp.last._exp_enabled  = false
    temp.last._exp_needed   = []
    temp.last.skills   = nil
    temp.last.commands = []
    temp.last.set_price(0)
=end
    return temp
  end
  def Sockets.database
    temp = []
    
################################################################################
    
    temp.push template    # red vial weak
    temp.last.name     =  ""
    temp.last.descr    =  ""
    temp.last.used     =  true
    temp.last.icon     =  187
    temp.last.id       =  1
    temp.last.s_type   =  0
    temp.last.t_c      =  2
    temp.last.t_id     =  0
    temp.last.prere    = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    temp.last.fix      =    [ 5, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    temp.last.random1  =    [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    temp.last.random2  =    [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    temp.last.b_xparam = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    temp.last.b_sparam = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    temp.last._exp_enabled  = false
    temp.last._exp_needed   = []
    temp.last.skills   = nil
    temp.last.commands = []
    temp.last.set_price(0)

    temp.push template    #
    temp.last.name     =  ""
    temp.last.descr    =  ""
    temp.last.used     =  true
    temp.last.icon     =  188
    temp.last.id       =  11
    temp.last.s_type   =  0
    temp.last.t_c      =  0
    temp.last.t_id     =  0
    temp.last.prere    = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    temp.last.fix      =    [ 0, 5, 0, 0, 0, 0, 0, 0, 0, 0]
    temp.last.random1  =    [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    temp.last.random2  =    [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    temp.last.b_xparam = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    temp.last.b_sparam = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    temp.last._exp_enabled  = false
    temp.last._exp_needed   = []
    temp.last.skills   = nil
    temp.last.commands = []
    temp.last.set_price(0)
    
    temp.push template    # fire-rune
    temp.last.name     =  ""
    temp.last.descr    =  ""
    temp.last.used     =  true
    temp.last.icon     =  8147
    temp.last.id       =  127
    temp.last.s_type   =  0
    temp.last.t_c      =  0
    temp.last.t_id     =  0
    temp.last.prere    = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    temp.last.fix      =    [ 0, 0, 2, 0, 0, 0, 0, 0, 0, 0]
    temp.last.random1  =    [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    temp.last.random2  =    [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    temp.last.b_xparam = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    temp.last.b_sparam = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    temp.last._exp_enabled  = false
    temp.last._exp_needed   = []
    temp.last.skills   = nil
    temp.last.commands = []
    temp.last.set_price(0)
    
    temp.push template    # 
    temp.last.name     =  ""
    temp.last.descr    =  ""
    temp.last.used     =  true
    temp.last.icon     =  184
    temp.last.id       =  13
    temp.last.s_type   =  0
    temp.last.t_c      =  0
    temp.last.t_id     =  0
    temp.last.prere    = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    temp.last.fix      =    [ 0, 0, 0, 0, 2, 0, 0, 0, 0, 0]
    temp.last.random1  =    [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    temp.last.random2  =    [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    temp.last.b_xparam = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    temp.last.b_sparam = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    temp.last._exp_enabled  = false
    temp.last._exp_needed   = []
    temp.last.skills   = nil
    temp.last.commands = []
    temp.last.set_price(0)

    
    temp.push template    # Luck-fragment
    temp.last.name     =  ""
    temp.last.descr    =  ""
    temp.last.used     =  true
    temp.last.icon     =  1683
    temp.last.id       =  164
    temp.last.s_type   =  0
    temp.last.t_c      =  0
    temp.last.t_id     =  0
    temp.last.prere    = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    temp.last.fix      =    [ 0, 0, 0, 0, 0, 0, 0, 1, 0, 0]
    temp.last.random1  =    [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    temp.last.random2  =    [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    temp.last.b_xparam = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    temp.last.b_sparam = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    temp.last._exp_enabled  = false
    temp.last._exp_needed   = []
    temp.last.skills   = nil
    temp.last.commands = []
    temp.last.set_price(0)
################################################################################

    return temp
  end
  def Sockets.item_ids
    $game_temp._tidloc_sockets_database.map{|i| i.id}.compact.sort_by{|x| x}
  end
  def Sockets.item_to_id(id)
    $game_temp._tidloc_sockets_database.find{|x| x.id==id}
  end
end;end;end