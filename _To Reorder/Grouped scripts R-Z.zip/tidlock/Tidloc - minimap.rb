################################################################################
#     Tidloc's Automatic Minimap v. 1.0.1                                      #
#                                             (Jul-13-16)                      #
################################################################################
# This script lets the game automatically collect mapdata when the player is   #
# travelling through the world. To adjust the maps on each map you have the    #
# following notetags:                                                          #
#------------------------------------------------------------------------------#
# map notetags:                                                                #
#   <nominimap>                                                                #
#     "no Minimap" will be shown for this map                                  #
#   <hideminimap>                                                              #
#     minimap window will be hidden on this map                                #
#   <fullminimap>                                                              #
#     full Minimap will be shown upon entering, no discovering needed          #
#   <mapitem *x*>                                                              #
#     with the item with ID *x* in the inventory, the whole map will be        #
#     discovered upon entering(like having a map for this area)                #
#   <maptiles *x*>                                                             #
#     the map has *x* tiles to be discovered. Needed to calculate the          #
#     fraction of discovery of this map                                        #
#   <mapcluster *x*>                                                           #
#     this map shares a discovery fraction with map *x*. multiple notetags of  #
#     this kind can be placed per map.                                         #
#   <mapradius *x*>                                                            #
#     mapradius is altered by +/- x on this map                                #
#------------------------------------------------------------------------------#
# Further you can use the following notetag on equipment to gain bonus upon    #
# them being equipped:                                                         #
#   <mapradius *x*>                                                            #
#     mapradius is altered by +/- x when this item is equipped                 #
#------------------------------------------------------------------------------#
# Also, events can have notetags:                                              #
#   <map-img *str*>                                                            #
#     the file *str*.png has to be placed in the folder of themap images       #
#   <map-info *str*>                                                           #
#     when in the minimap scene the info *str* will be shown when the cursor   #
#     is pointing at that tile                                                 #
#   <map-move *m*,*x*,*y*>                                                     #
#     when pressing ENTER on the minimap scene, the scene changes to the map   #
#     with ID *m* at position *x*,*y*                                          #
#------------------------------------------------------------------------------#
# This script has several script commands enabled:                             #
#   Tidloc.exe :show, :Minimap                                                 #
#     Hides Minimap in each map. This command is needed to show the minimap    #
#     in the first place. By default it's hidden!                              #
#   Tidloc.exe :hide, :Minimap                                                 #
#     Shows Minimap whenever it's allowed (depending on map notetags)          #
#   Tidloc.exe :toggle, :Minimap                                               #
#     Toggles showing the minimap (depending on map notetags)                  #
#   Tidloc.exe *map*, :Minimap_frac                                            #
#     Returns the fraction of discovery for the mapo with the ID *map*         #
#   Tidloc.exe [*x*,*y*], :Minimap_refresh                                     #
#     Triggers a refresh of the minimap on the actual map starting on the      #
#     coordinates *x*,*y*                                                      #
#   Tidloc.exe *map*, :Minimap_mark, *x*,*y*,*str*,*info*                      #
#     Sets a mark on the map with the ID *map* on postition *x*,*y* with the   #
#     image *str*.png overwriting the actual image (if discovered). This marks #
#     can be erased in the minimap scene by pressing ENTER on them. The info   #
#     string will be displayed on the minimap scene.                           #
#   Tidloc.exe *map*, :Minimap_mark_rem, *x*,*y*                               #
#     Removes a mark set by the command above.                                 #
#   Tidloc.exe "Minimap",:call                                                 #
#     calls the minimap scene with an interactive map showing the infos of     #
#     events and map transitions possible. scrolling with arrow keys, fast     #
#     scrollig when SHIFT is pressed too.                                      #
#------------------------------------------------------------------------------#
# All images need to be saved within the graphics\pictures folder and further  #
# in the folder specified in line 119 of this script.                          #
#------------------------------------------------------------------------------#
# When no other images are defined, this script looks at the region of the     #
# tiles that are passable by the player. Defining which graphics will be used  #
# for each region is defined in the lines 120pp. for each single region. When  #
# any region is about to be displayed on the minimap that's not defined the    #
# game will exit with the exact error description.                             #
#==============================================================================#
#     IMPORTANT NOTES                                                          #
# 1) You'll need the command in line 44 of this script to show the minimap at  #
#    all, by deafault it's hidden.                                             #
# 2) When the minimap is hidden, no data will be collected by walking in maps  #
#    to prevent garbage collection of map data that won't be used.             #
# 3) Using the DEBUG constant allows you to show the amount of free tiles      #
#    when you playtest on a map. This way you can easily calculate the max     #
#    number of tiles without having to count them all (for the <maxtile *x*>   #
#    command).                                                                 #
# 4) Players can set and erase their own marks in the minimap scene if the     #
#    constant Player_Marks is set true.                                        #
# 5) I recommend to have the constant Event_checking on true, unless you only  #
#    use stationary events with their own images.                              #
#==============================================================================#
#  Feel free to use this script, but please credit me for my work! ^__^        #
#      (C) Tidloc    (tidloc@gmx.at)                                           #
################################################################################
 
$imported = {} if $imported.nil?
$imported["Tidloc-MiniMap"] = [1,0,1]
$needed   = [] if $needed.nil?
$needed.push ["Tidloc-Header",[2,13,6],true,"Tidloc's Automatic Minimap"]
 
module Tidloc
  Keys = {} if Keys.nil?
  Keys["Minimap_scene"]  = nil
  Keys["Minimap_toggle"] = nil
  Menu = {} if Menu.nil?
  Menu["Minimap_scene"]  = true
   
  module Minimap
    Discover_Radius = 4
    Show_Frac       = true
    Event_checking  = true
    Player_Marks    = true
    Sprites = { :position_x => 10,
                :position_y => 10,
                :position_z => 1000,
                :width      => 200,
                :height     => 200
              }
    Image_size      = [12,12]
    Images =  { :folder  => "Mapimages",
                :player  => "player",
                :mark    => "mark",
                :center  => ["red_circle",16,16],
                :Regions => {  0 => "blank",
                               1 => "door",
                               2 => "poi",
                               3 => "exit_up",
                               4 => "exit_down",
                               5 => "exit_left",
                               6 => "exit_right",
                               7 => "null",
                               8 => "grass",
                               9 => "wood",
                              10 => ""},
                 
                :blank => "blank"
              }
    Notetags = [[ /<nominimap>/i,
                  /<hideminimap>/i,
                  /<fullminimap>/i,
                  /<mapitem ([0-9]+)>/i,
                  /<mapradius ([0-9_-]+)>/i
                ],
                [ /<maptiles ([0-9]+)>/i,
                  /<mapcluster ([0-9]+)>/i,
                  /<map-img (.*)>/i,
                  /<map-info (.*)>/i,
                  /<map-move ([0-9]+),([0-9]+),([0-9]+)>/i
                ]
               ]
    DEBUG = false
  end
   
  module Vocabs;class<<self
    def MiniMap(code,lang)
      if    lang == "ger"
        case code
        when "Name";   return "Minimap"
        when "nomap";  return "Keine Mappe verfügbar"
        when "pmark";  return "<color=gold>Mappen Markierung"
        when "error1"; return "FEHLER\n\n"+ 
          "Region \01 auf der Mappe \02 bei Position x=\03, y=\04 nicht "+
          "im Minimappen-Skript definiert!"
        end
      elsif lang =="eng"
        case code
        when "Name";   return "Minimap"
        when "nomap";  return "No map available"
        when "pmark";  return "<color=gold>Custom mark"
        when "error1"; return "ERROR\n\n"+ 
          "Region \01 occuring in map \02 at position x=\03, y=\04 not "+
          "defined in the Minimap definitions!"
        end
      elsif lang =="cze"
        case code
        when "Name";   return "Minimap"
        when "nomap";  return "Mapa není k dispozici"
        when "pmark";  return "<color=gold>Vlastní značka"
        when "error1"; return "ERROR\n\n"+ 
          "Region \01 označený na mapě \02 na pozici x=\03, y=\04"+
          "není definován ve scriptu Minimap!"
        end
      end
    end
  end;end
end
 
################################################################################
#                                                                              #
################################################################################
 
module Tidloc;module Minimap;class<<self
  def Update
    x  = Tidloc::Minimap::Sprites[:position_x]
    y  = Tidloc::Minimap::Sprites[:position_y]
    z  = Tidloc::Minimap::Sprites[:position_z]
    w  = Tidloc::Minimap::Sprites[:width]
    h  = Tidloc::Minimap::Sprites[:height]
    xp = $game_player.x
    yp = $game_player.y
    $game_system.tidloc_minimap_coord = [0,0] if $game_system.tidloc_minimap_coord.nil?
    $game_system.tidloc_minimap = []          if $game_system.tidloc_minimap.nil?
    $game_system.tidloc_minimap_marks = []    if $game_system.tidloc_minimap_marks.nil?
    if $game_system.tidloc_minimap[$game_map.map_id].nil?
      $game_system.tidloc_minimap[$game_map.map_id] = Array.new($game_map.width) { [] }
    end
    if $game_system.tidloc_minimap_marks[$game_map.map_id].nil?
      $game_system.tidloc_minimap_marks[$game_map.map_id] = Array.new($game_map.width) { [] }
    end
# map layer
    if $game_temp.tidloc_minimap_sprite.nil?
      $game_temp.tidloc_minimap_sprite        = Sprite.new
      $game_temp.tidloc_minimap_sprite.x      = x
      $game_temp.tidloc_minimap_sprite.y      = y
      $game_temp.tidloc_minimap_sprite.z      = z
    end
# event layer
    if $game_temp.tidloc_minimap_sprite2.nil?
      $game_temp.tidloc_minimap_sprite2        = Sprite.new
      $game_temp.tidloc_minimap_sprite2.x      = x
      $game_temp.tidloc_minimap_sprite2.y      = y
      $game_temp.tidloc_minimap_sprite2.z      = z+1
    end
# when <hideminimap>
    if $game_map.map.note =~ Tidloc::Minimap::Notetags[0][1] || !$game_system.tidloc_minimap_show
      if $game_temp.tidloc_minimap_sprite.bitmap
        $game_temp.tidloc_minimap_sprite.bitmap.dispose 
        $game_temp.tidloc_minimap_sprite.bitmap = nil
      end
      if $game_temp.tidloc_minimap_sprite2.bitmap
        $game_temp.tidloc_minimap_sprite2.bitmap.dispose 
        $game_temp.tidloc_minimap_sprite2.bitmap = nil
      end
      return
    elsif SceneManager.scene.is_a?(Scene_Map)
      if $game_temp.tidloc_minimap_sprite.bitmap.nil?
        $game_temp.tidloc_minimap_sprite.bitmap = Bitmap.new(w,h)
        $game_temp.tidloc_minimap_sprite.opacity = 160
      end
      if $game_temp.tidloc_minimap_sprite2.bitmap.nil?
        $game_temp.tidloc_minimap_sprite2.bitmap = Bitmap.new(w,h)
        $game_temp.tidloc_minimap_sprite2.opacity = 160
      end
      self.Force_Update
    end
#
    if $game_system.tidloc_minimap[$game_map.map_id].count_if(1) == 0
      refresh
    end
    if    $game_system.tidloc_minimap_coord[0] == -1 ||
          $game_system.tidloc_minimap_coord[0] != xp ||
          $game_system.tidloc_minimap_coord[1] != yp
      self.Force_Update
    else
      return
    end
  end
  def background
    w  = Tidloc::Minimap::Sprites[:width]
    h  = Tidloc::Minimap::Sprites[:height]
    $game_temp.tidloc_minimap_sprite.bitmap.fill_rect(0, 0, w, h, Color.new(0,0,0,160) )
  end
  def Force_Update
    return if $game_temp.tidloc_minimap_sprite.nil? || $game_temp.tidloc_minimap_sprite.bitmap.nil?
    w  = Tidloc::Minimap::Sprites[:width]
    h  = Tidloc::Minimap::Sprites[:height]
    xp = $game_player.x
    yp = $game_player.y
    $game_system.tidloc_minimap_coord[0] = xp
    $game_system.tidloc_minimap_coord[1] = yp
    xtemp = (w/2).to_i
    ytemp = (h/2).to_i
    $game_temp.tidloc_minimap_sprite.bitmap.clear
    $game_temp.tidloc_minimap_sprite2.bitmap.clear
    background
# handling <nominimap>
    if $game_map.map.note =~ Tidloc::Minimap::Notetags[0][0]
      xtemp -=  Tidloc::Vocabs.MiniMap("nomap",$tidloc_language).size * 
                                    $game_temp.tidloc_minimap_sprite.bitmap.text_size("T").width/2
      xtemp  = [0,xtemp.to_i].max
      ytemp -= 16
      $game_temp.tidloc_minimap_sprite.bitmap.draw_html(xtemp,ytemp,w,32,Tidloc::Vocabs.MiniMap("nomap",$tidloc_language))
      return
    end
    xtemp -= 12
    ytemp -= 12
 
#
#   Discovering of the map:
#
 
#~     $game_system.tidloc_minimap[$game_map.map_id][xp][yp] = 1
    $game_map.map.note =~ Tidloc::Minimap::Notetags[1][0]
    if    $game_party.steps > $game_system.tidloc_minimap_steps #&& ( $1.nil? ||
          #$game_system.tidloc_minimap[$game_map.map_id].count_if(1) < $1.to_i  )
      $game_system.tidloc_minimap_steps = $game_party.steps
      self.refresh
      self.refresh_all
    end
     
#
#   Displaying of maps:
#
    if $game_system.tidloc_minimap[$game_map.map_id]
      $game_system.tidloc_minimap[$game_map.map_id].count.times{ |x|
        xv = xtemp - (xp-x)*Tidloc::Minimap::Image_size[0]
        next if xv <= -Tidloc::Minimap::Image_size[0] || xv > w
        $game_system.tidloc_minimap[$game_map.map_id][x].count.times{ |y|
          yv = ytemp - (yp-y)*Tidloc::Minimap::Image_size[1]
          next if yv <= -Tidloc::Minimap::Image_size[1] || yv > h
# player position
          if x==xp && y==yp
            pic = Cache.picture( Tidloc::Minimap::Images[:folder]+"\\"+Tidloc::Minimap::Images[:player])
            $game_temp.tidloc_minimap_sprite2.bitmap.blt(xv,yv,pic,Rect.new(0,0,*Tidloc::Minimap::Image_size))
            next
          end
          i = $game_system.tidloc_minimap[$game_map.map_id][x][y]
          next if i.nil?
          if i.find{ |j| j.is_a?(Numeric)}
            l = i.find{ |j| j.is_a?(Numeric)}
            id = $game_map.region_id(x,y)
            case l
            when 0; next
            when 1; begin
                      pic = Cache.picture( Tidloc::Minimap::Images[:folder]+"\\"+Tidloc::Minimap::Images[:Regions][id])
                    rescue
                      text = Tidloc::Vocabs.MiniMap("error1",$tidloc_language).clone
                      text.sub!(/\01/,id.to_s)
                      text.sub!(/\02/,$game_map.map_id.to_s)
                      text.sub!(/\03/,x.to_s)
                      text.sub!(/\04/,y.to_s)
                      msgbox text
                      exit
                    end
                    $game_temp.tidloc_minimap_sprite.bitmap.blt(xv,yv,pic,Rect.new(0,0,*Tidloc::Minimap::Image_size))
            end
          end
          if i.find{ |j| j.is_a?(Array)&&j[0]==:img}
            l = i.find{ |j| j.is_a?(Array)&&j[0]==:img}[1]
            pic = Cache.picture( Tidloc::Minimap::Images[:folder]+"\\"+l)
            $game_temp.tidloc_minimap_sprite2.bitmap.blt(xv,yv,pic,Rect.new(0,0,*Tidloc::Minimap::Image_size))
          end
          l = $game_system.tidloc_minimap_marks[$game_map.map_id][x][y]
          if l
            pic = Cache.picture( Tidloc::Minimap::Images[:folder]+"\\"+l[0])
            $game_temp.tidloc_minimap_sprite2.bitmap.blt(xv,yv,pic,Rect.new(0,0,*Tidloc::Minimap::Image_size))
          end
        }
      }
    end
    if Tidloc::Minimap::Show_Frac && (Tidloc::Minimap::DEBUG || $game_map.map.note =~ Tidloc::Minimap::Notetags[1][0])
      if Tidloc::Minimap::DEBUG && $game_system.tidloc_minimap[$game_map.map_id]
        $game_temp.tidloc_minimap_sprite.bitmap.draw_html(w-55,h-24,55,24,
            $game_system.tidloc_minimap[$game_map.map_id].count_if(1).to_s )
      else
        maps = [$game_map.map_id]
        $game_map.map.note.split(/[\r\n]+/).each { |line|
          if line =~ Tidloc::Minimap::Notetags[1][1]
            maps.push $1.to_i
          end
        }
        frac = self.Fraction(*maps).round(1)
        frac = 100 if frac == 100
        $game_temp.tidloc_minimap_sprite.bitmap.draw_html(w-55,h-24,55,24,
            "<small>#{frac}%")
      end
    end
     
     
  end
  def Fraction(*map_ids)
    soll  = 0
    haben = 0
    map_ids.each{|m|
      if load_data(sprintf("Data/Map%03d.rvdata2", m)).note =~ Tidloc::Minimap::Notetags[1][0]
        soll  += $1.to_i
        haben += $game_system.tidloc_minimap[m].count_if(1) if $game_system.tidloc_minimap[m]
      end
    }
    return 0 if soll == 0
    return (100.0*haben)/soll
  end
  def event_check(x,y)
    if $game_map.events.find{|k,e| e.x==x && e.y==y}
      ev = $game_map.events.find{|k,e| e.x==x && e.y==y}[1]
      ev.refresh
      ev.update
      list = ev.list
      return if list.nil?
      list.each_with_index{|l,i|
        if l.code == 108
          text = l.parameters[0]
          j = i+1
          while list[j].code == 408
            begin
              text += list[j].parameters[0]
            rescue
              msgbox list[j].parameters
            end
            j += 1
          end
          if text =~ Tidloc::Minimap::Notetags[1][2]
            n = [:img,$1]
            if    $game_system.tidloc_minimap[$game_map.map_id][x] &&
                  (($game_system.tidloc_minimap[$game_map.map_id][x][y] && !$game_system.tidloc_minimap[$game_map.map_id][x][y].find{|k| k==n}) ||
                    !$game_system.tidloc_minimap[$game_map.map_id][x][y])
              $game_system.tidloc_minimap[$game_map.map_id][x][y] = [] if !$game_system.tidloc_minimap[$game_map.map_id][x][y]
              $game_system.tidloc_minimap[$game_map.map_id][x][y].push n
            end
          end
          if text =~ Tidloc::Minimap::Notetags[1][3]
            n = [:info,$1]
            if    $game_system.tidloc_minimap[$game_map.map_id][x] &&
                  (($game_system.tidloc_minimap[$game_map.map_id][x][y] && !$game_system.tidloc_minimap[$game_map.map_id][x][y].find{|k| k==n}) ||
                    !$game_system.tidloc_minimap[$game_map.map_id][x][y])
              $game_system.tidloc_minimap[$game_map.map_id][x][y] = [] if !$game_system.tidloc_minimap[$game_map.map_id][x][y]
              $game_system.tidloc_minimap[$game_map.map_id][x][y].unshift n
            end
          end
          if text =~ Tidloc::Minimap::Notetags[1][4]
            n = [:move,[$1.to_i,$2.to_i,$3.to_i]]
            if    $game_system.tidloc_minimap[$game_map.map_id][x] &&
                  (($game_system.tidloc_minimap[$game_map.map_id][x][y] && !$game_system.tidloc_minimap[$game_map.map_id][x][y].find{|k| k==n}) ||
                    !$game_system.tidloc_minimap[$game_map.map_id][x][y])
              $game_system.tidloc_minimap[$game_map.map_id][x][y] = [] if !$game_system.tidloc_minimap[$game_map.map_id][x][y]
              $game_system.tidloc_minimap[$game_map.map_id][x][y].unshift n
            end
          end
        end
      }
    end
  end
  def refresh(x=$game_player.x, y=$game_player.y, r=Tidloc::Minimap::Discover_Radius)
    return unless $game_system.tidloc_minimap[$game_map.map_id]
    disc  = [[x,y]]
    disc2 = [[x,y]]
    if $game_map.map.note =~ Tidloc::Minimap::Notetags[0][4]
      r += $1.to_i
    end
    $game_party.members.each{|m|
      m.equips.each{|e|
        if e && e.note =~ Tidloc::Minimap::Notetags[0][4]
          r += $1.to_i
        end
    } }
    if $game_map.map.note =~ Tidloc::Minimap::Notetags[0][3]
      r = 100000    if $game_party.item_number($data_items[$1.to_i]) > 0
    elsif $game_map.map.note =~ Tidloc::Minimap::Notetags[0][2]
      r = 100000
    end
    while disc.count > 0
      temp  = disc.shift
      if    $game_map.passable?(temp[0],temp[1],2) ||
            $game_map.passable?(temp[0],temp[1],4) ||
            $game_map.passable?(temp[0],temp[1],6) ||
            $game_map.passable?(temp[0],temp[1],8)
        $game_system.tidloc_minimap[$game_map.map_id][temp[0]][temp[1]] = [1]
        event_check(*temp)
        if    Math.sqrt((temp[0]-x)**2+((temp[1]+1)-y)**2) <= r
          if    $game_map.check_passage(temp[0],temp[1],1) # 2 - down
            n = [temp[0],temp[1]+1]
            if !disc2.find{|d| d==n}
              disc.push  n.clone
              disc2.push n.clone
            end
          end
          event_check(temp[0],temp[1]+1)
        end
        if    Math.sqrt(((temp[0]-1)-x)**2+(temp[1]-y)**2) <= r
          if    $game_map.check_passage(temp[0],temp[1],2) # 4 - left
            n = [temp[0]-1,temp[1]]
            if !disc2.find{|d| d==n}
              disc.push  n.clone
              disc2.push n.clone
            end
          end
          event_check(temp[0]-1,temp[1])
        end
        if    Math.sqrt(((temp[0]+1)-x)**2+(temp[1]-y)**2) <= r
          if    $game_map.check_passage(temp[0],temp[1],4) # 6 - right
            n = [temp[0]+1,temp[1]]
            if !disc2.find{|d| d==n}
              disc.push  n.clone
              disc2.push n.clone
            end
          end
          event_check(temp[0]+1,temp[1])
        end
        if    Math.sqrt((temp[0]-x)**2+((temp[1]-1)-y)**2) <= r
          if    $game_map.check_passage(temp[0],temp[1],8) # 8 - up
            n = [temp[0],temp[1]-1]
            if !disc2.find{|d| d==n}
              disc.push  n.clone
              disc2.push n.clone
            end
          end
          event_check(temp[0],temp[1]-1)
        end
        disc.compact!
      else
        event_check(*temp)
      end
    end
  end
  def refresh_all
    return unless SceneManager.scene.is_a?(Scene_Map)
    $game_map.update
    $game_map.refresh
    return unless $game_system.tidloc_minimap[$game_map.map_id]
    $game_system.tidloc_minimap[$game_map.map_id].count.times{ |x|
      $game_system.tidloc_minimap[$game_map.map_id][x].count.times{ |y|
        next unless $game_system.tidloc_minimap[$game_map.map_id][x][y]
        if    $game_map.check_passage(x,y,1) ||
              $game_map.check_passage(x,y,2) ||
              $game_map.check_passage(x,y,4) ||
              $game_map.check_passage(x,y,8)
          $game_system.tidloc_minimap[$game_map.map_id][x][y] = [1]
        end
        event_check(x,y)
      }
    }
    $game_map.events.each{|k,e| 
      e.refresh
      e.update
      next if e.list.nil?
      next unless $game_system.tidloc_minimap[$game_map.map_id][e.x][e.y]
      e.list.each_with_index{|l,i|
        if l.code == 108
          text = l.parameters[0]
          j = i+1
          while e.list[j].code == 408
            begin
              text += e.list[j].parameters[0]
            rescue
              msgbox e.list[j].parameters
            end
            j += 1
          end
          if text =~ Tidloc::Minimap::Notetags[1][2]
            n = [:img,$1]
            if    $game_system.tidloc_minimap[$game_map.map_id][e.x][e.y] &&
                  !$game_system.tidloc_minimap[$game_map.map_id][e.x][e.y].find{|k| k==n}
              $game_system.tidloc_minimap[$game_map.map_id][e.x][e.y].push n
            end
          end
          if text =~ Tidloc::Minimap::Notetags[1][3]
            n = [:info,$1]
            if    $game_system.tidloc_minimap[$game_map.map_id][e.x][e.y] &&
                  !$game_system.tidloc_minimap[$game_map.map_id][e.x][e.y].find{|k| k==n}
              $game_system.tidloc_minimap[$game_map.map_id][e.x][e.y].unshift n
            end
          end
          if text =~ Tidloc::Minimap::Notetags[1][4]
            n = [:move,[$1.to_i,$2.to_i,$3.to_i]]
            if    $game_system.tidloc_minimap[$game_map.map_id][e.x][e.y] &&
                  !$game_system.tidloc_minimap[$game_map.map_id][e.x][e.y].find{|k| k==n}
              $game_system.tidloc_minimap[$game_map.map_id][e.x][e.y].unshift n
            end
          end
        end
      }
    }
  end
end
  class Scene_Minimap < Scene_Base
    def start
      super
      create_background
      create_map
      @x = $game_player.x
      @y = $game_player.y
      @dx = @x
      @dy = @y
    end
    def create_background
      @background_sprite = Sprite.new
      @background_sprite.bitmap = SceneManager.background_bitmap
      @background_sprite.color.set(16, 16, 16, 128)
      @background_sprite.z = 0
    end
    def create_map
      @map_id     = $game_map.map_id
      @mapdata    = load_data(sprintf("Data/Map%03d.rvdata2", @map_id))
# creating the sprite for the floor images
      @map   = Sprite.new
      @map.x = 0
      @map.y = 0
      @map.z = 1
      @map.bitmap = Bitmap.new(Graphics.width,Graphics.height)
# creating the sprite for the event images
      @map2   = Sprite.new
      @map2.x = 0
      @map2.y = 0
      @map2.z = 1
      @map2.bitmap = Bitmap.new(Graphics.width,Graphics.height)
# creating the sprite for the center tile
      pic = Cache.picture( Tidloc::Minimap::Images[:folder]+"\\"+Tidloc::Minimap::Images[:center][0])
      rb = Tidloc::Minimap::Images[:center][1..2]
      @map3   = Sprite.new
      @map3.x = (Graphics.width  - rb[0]) / 2
      @map3.y = (Graphics.height - rb[1]) / 2
      @map3.z = 3
      @map3.bitmap = Bitmap.new(*rb)
      @map3.bitmap.blt(0,0,pic,Rect.new(0,0,*rb))
# creating the sprite for showed mapinfo
      @mapinfo = Sprite.new
      @mapinfo.x = 0
      @mapinfo.y = 0
      @mapinfo.z = 10
      @mapinfo.bitmap = Bitmap.new(Graphics.width,Graphics.height)
    end
    def update
      super
      update_control
      update_map
    end
    def update_control
      if Input.trigger?(:C)
# ENTER
        i = $game_system.tidloc_minimap[@map_id][@x][@y]
        s = i.find{ |j| j.is_a?(Array) && j[0] == :move}
        if !s.nil?
          if $game_system.tidloc_minimap[s[1][0]]
            @map_id  = s[1][0]
            @x       = s[1][1]
            @y       = s[1][2]
            @mapdata = load_data(sprintf("Data/Map%03d.rvdata2", @map_id))
            refresh_map
          else
            Sound.play_buzzer
            refresh_map
          end
        elsif $game_system.tidloc_minimap_marks[@map_id][@x][@y]
          $game_system.tidloc_minimap_marks[@map_id][@x][@y] = nil
          update_map
        else
          $game_system.tidloc_minimap_marks[@map_id][@x][@y] = [Tidloc::Minimap::Images[:mark],Tidloc::Vocabs.MiniMap("pmark",$tidloc_language)]
          update_map
        end
      end
      if Input.trigger?(:B) || Input.trigger?(Tidloc::Keys["Minimap"])
        SceneManager.return
      end
      @dx = @x
      @dy = @y
      if Input.press?(:SHIFT) && Input.press?(:LEFT) || Input.repeat?(:LEFT)
        @dx = [@x-1,0].max
      end
      if Input.press?(:SHIFT) && Input.press?(:RIGHT) || Input.repeat?(:RIGHT)
        @dx = [@x+1,$game_system.tidloc_minimap[@map_id].count-1].min
      end
      if Input.press?(:SHIFT) && Input.press?(:UP) || Input.repeat?(:UP)
        @dy = [@y-1,0].max
      end
      if Input.press?(:SHIFT) && Input.press?(:DOWN) || Input.repeat?(:DOWN)
        @dy = [@y+1,$game_system.tidloc_minimap[@map_id][@dx].count-1].min
      end
      if @dx != @x || @dy != @y
        if $game_system.tidloc_minimap[@map_id][@dx][@dy]
          @x = @dx
          @y = @dy
          refresh_map
        end
      end
    end
    def update_map
      xtemp = Graphics.width/2  - 6
      ytemp = Graphics.height/2 - 6
      $game_system.tidloc_minimap[@map_id].count.times{ |x|
        xv = xtemp - (@x-x)*Tidloc::Minimap::Image_size[0]
        next if xv <= -Tidloc::Minimap::Image_size[0] || xv > Graphics.width
        $game_system.tidloc_minimap[@map_id][x].count.times{ |y|
          yv = ytemp - (@y-y)*Tidloc::Minimap::Image_size[1]
          next if yv <= -Tidloc::Minimap::Image_size[1] || yv > Graphics.height
          i = $game_system.tidloc_minimap[@map_id][x][y]
          if @map_id==$game_map.map_id && x==$game_player.x && y==$game_player.y
            pic = Cache.picture( Tidloc::Minimap::Images[:folder]+"\\"+Tidloc::Minimap::Images[:player])
            @map.bitmap.blt(xv,yv,pic,Rect.new(0,0,*Tidloc::Minimap::Image_size))
            next
          end
          if x==@x && y==@y
            if i.is_a?(Array)
              if $game_system.tidloc_minimap_marks[@map_id][x][y]
                s = $game_system.tidloc_minimap_marks[@map_id][x][y][1]
                w = @mapinfo.bitmap.text_size(Bitmap.html_decode(s)).width
                dx = (Graphics.width-w)/2
                dy = (Graphics.height-Tidloc::Minimap::Images[:center][2])/2 - 24
                @mapinfo.bitmap.draw_html(dx,dy,w,24,s)
              else
                s = i.find{ |j| j.is_a?(Array) && j[0] == :info}
                unless s.nil?
                  s = s[1]
                  text = s.clone
                  if $imported["Tidloc-MultiLang"] && text =~ Tidloc::MultiLang::RegExp[:convo]
                    text.gsub!(Tidloc::MultiLang::RegExp[:convo]) {Tidloc::MultiLang::Load($1,$2)}
                  end
                  w = Bitmap.html_decode(text).lstrip.rstrip.size*@mapinfo.bitmap.text_size("T").width
                  dx = (Graphics.width-w)/2
                  dy = (Graphics.height-Tidloc::Minimap::Images[:center][2])/2 - 24
                  @mapinfo.bitmap.draw_html(dx,dy,w,24,s)
                end
              end
            end
          end
          next if i.nil?
          if i.find{ |j| j.is_a?(Numeric)}
            l = i.find{ |j| j.is_a?(Numeric)}
            id = region_id(x,y)
            case l
            when 0; next
            when 1; begin
                      pic = Cache.picture( Tidloc::Minimap::Images[:folder]+"\\"+Tidloc::Minimap::Images[:Regions][id])
                    rescue
                      text = Tidloc::Vocabs.MiniMap("error1",$tidloc_language).clone
                      text.sub!(/\01/,id.to_s)
                      text.sub!(/\02/,$game_map.map_id.to_s)
                      text.sub!(/\03/,x.to_s)
                      text.sub!(/\04/,y.to_s)
                      msgbox text
                      exit
                    end
                    @map.bitmap.blt(xv,yv,pic,Rect.new(0,0,*Tidloc::Minimap::Image_size))
            end
          end
          if i.find{ |j| j.is_a?(Array)&&j[0]==:img}
            l = i.find{ |j| j.is_a?(Array)&&j[0]==:img}[1]
            pic = Cache.picture( Tidloc::Minimap::Images[:folder]+"\\"+l)
            @map2.bitmap.blt(xv,yv,pic,Rect.new(0,0,*Tidloc::Minimap::Image_size))
          end
          l = $game_system.tidloc_minimap_marks[@map_id][x][y]
          if l
            pic = Cache.picture( Tidloc::Minimap::Images[:folder]+"\\"+l[0])
            @map2.bitmap.blt(xv,yv,pic,Rect.new(0,0,*Tidloc::Minimap::Image_size))
          end
        }
      }
    end
    def region_id(x, y)
      @mapdata.data[x, y, 3] >> 8
    end
    def refresh_map
      @map.bitmap.clear
      @map2.bitmap.clear
      @mapinfo.bitmap.clear
      update_map
    end
    def terminate
      super
      @map.bitmap.dispose
      @map.dispose
      @map2.bitmap.dispose
      @map2.dispose
      @map3.bitmap.dispose
      @map3.dispose
      @mapinfo.bitmap.dispose
      @mapinfo.dispose
    end
  end
end;end