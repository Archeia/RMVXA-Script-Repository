
$imported = {} if $imported.nil?
$imported["Tidloc-ActorData"] = [1,1,0]
$needed = [] if $needed.nil?
$needed.push ["Tidloc-Header",[2,11,2],true,"Tidloc-ActorData"]

class RPG::Actor
  alias wo_tidloc_name name
  def name
    temp = Tidloc::Header::ActorData(self.id)[:name][$tidloc_language]
    return temp if temp
    return wo_tidloc_name
  end
  def dataname
    wo_tidloc_name
  end
  def name_html
    text = "{eval= "
    Tidloc::Languages.each{|l|
      text += "if $tidloc_language==\"#{l}\";"
      temp = Tidloc::Header::ActorData(self.id)[:name][l]
      if temp
        text += "\"#{temp}\";els"
      else
        text += "\"#{wo_tidloc_name}\";els"
      end
    }
    text += "e;\"#{wo_tidloc_name}\";end}"
    return text
  end
  alias wo_tidloc_description description
  def description
    temp = Tidloc::Header::ActorData(self.id)[:desc][$tidloc_language]
    return temp if temp
    return wo_tidloc_description
  end
  def datadescription
    wo_tidloc_description
  end
  def commands
    Tidloc::Header::ItemData(self.id)[:commands]
  end
end

module Tidloc;module Header;class<<self;def ActorData(actor_id)
  name    = {"Def" => $data_actors[actor_id].dataname}
  desc    = {"Def" => $data_actors[actor_id].datadescription}
  command = []
  case actor_id
  when "actor react to recieving damage"
    command_name = "heal_1"
    command.push ["BattleGetHit","actor = $game_temp.tidloc[:target];
                               actor._tidvar[0] = 0 if actor._tidvar[0].nil?
                               actor._tidvar[0] += 1
                               actor.commands.push "+
                               "[\"TurnStart\",\"actor = $game_temp.tidloc[:enemy];
                                                create_popup(\\\"tot\\\",\\\"TP_DMG\\\");
                                                actor.commands.find{|c| c[2]==\\\"#{command_name}\\\"}.delete_if{|x| x}\",
                                  \"#{command_name}\"]\""]
  when 1 # Actor with ID 1
  end
  return {:name     => name,
          :commands => command,
          :desc     => desc
         }
end;end;end;end
end;end;end;end