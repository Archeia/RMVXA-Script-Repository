=begin
  addition to my script diablo equipment.
  copy the commented template right above the first hash-line and paste it
  between the two hashlines. the tags can be adjusted as following:
  
  Name of the tag:
    temp.last.name    =  "Name"
	temp.last.descr   =  "Description"

  Prerequesites of the tag: L  H  M  S  D  M  M  A  L  D  V
                            V  P  P  T  E  A  D  G  C  E  I
                            L        R  f  G  F  I  K  X  T
    temp.last.prere    =  [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
  
  Bonus of the tag: (random bonus will be calculated for each item seperately)
                              H  M  S  D  M  M  A  L  D  V
                              P  P  T  E  A  D  G  C  E  I
                                    R  F  G  F  I  K  X  T
    temp.last.fix      =    [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] <- fixed bonus
    temp.last.random1  =    [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] <- lower bound of random bonus
    temp.last.random2  =    [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] <- upper bound of random bonus
  
                           H  E  C  C  M  M  C  H  M  T
                           I  V  R  E  E  R  N  P  P  P
                           T  A  I  V  V  F  T  R  R  R
    temp.last.b_xparam = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    
                           T  G  R  P  M  T  P  M  F  E
                           G  R  E  H  C  C  D  D  D  X
                           R  D  C  A  R  R  R  R  R  R
    temp.last.b_sparam = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    
  Level difference needed between set item-level and enchantment level:
    temp.last.tag_lvl = 1
    
  class this tag is applied to 0=all 1=only weapons 2=only armors
    temp.last.tag_c   = 0
  id of the item (or array of item-ids) this tag is applied to (only when class 
  is set too)
    temp.last.tag_id  = 0
    
  adding skills, when equipping and releasing skills when unequipping item,
  enter the database ID of the skill in this array:
    temp.last.skills  = []
    
  price adjusting:
    temp.last.set_price(0).set_price_100(1.0)
             <- set_price(*x*) ....... price of the enchated item will be 
                                       offset by x
             <- set_price_100(*x*) ... price of the enchanted item will be
                                       multiplied with x
  
  Items are handled as if they have the special tag, with the difference of
  possible additional set boni. but hese have to set up seperatly here. Go to
  "Start of Set boni" 
=end

$imported = {} if $imported.nil?
$imported["Tidloc-DiabloSet"] = [1,0,0]

module Tidloc;module CustomEquip;class Set
  
  def Set.tag(ench_lvl,item)
    return [0,nil] unless item.note =~ Tidloc::DiabloEquip::Notetags[0]
    lvl = $1.to_i
    temp = ench_lvl - lvl #- $game_party.highest_level/2
    return [0,nil] if 0 > temp - Tidloc::DiabloEquip::Lvl_Corr_Set
    return [0,nil] unless rand(temp) > rand(lvl + Tidloc::DiabloEquip::Lvl_Corr_Set)
    return [0,nil] unless rand(100)  < Tidloc::DiabloEquip::Max_Prop_Set
    return [0,nil] unless $game_temp._tidloc_diablo_set && $game_temp._tidloc_diablo_setboni
    temp2 = []
    for i in $game_temp._tidloc_diablo_set
      temp2.push i if i[1].is_a?(Tidloc::CustomEquip::Tag) && i[1].tag_lvl < temp
    end
    while true
      return [0,nil] if temp2.size < 1
      temp = rand(temp2.size-1).to_i
      return [0,nil] if temp2[temp][1].nil?
      if (temp2[temp][1].tag_c == 0 || 
           (temp2[temp][1].tag_c == 1 && 
              item.is_a?(Tidloc::CustomEquip::Weapon) && 
             (temp2[temp][1].tag_id.is_a?(Integer) && 
               (temp2[temp][1].tag_id == 0 || temp2[temp][1].tag_id == item.id) ||
               (temp2[temp][1].tag_id.is_a?(Array) &&
                  temp2[temp][1].tag_id.find{|t| t== item.id}) ) ) || 
           (temp2[temp][1].tag_c == 2 && 
              item.is_a?(Tidloc::CustomEquip::Armor) && 
             (temp2[temp][1].tag_id.is_a?(Integer) && 
               (temp2[temp][1].tag_id == 0 || temp2[temp][1].tag_id == item.id) ||
               (temp2[temp][1].tag_id.is_a?(Array) &&
                  temp2[temp][1].tag_id.find{|t| t== item.id}) ) ) ) && 
           temp2[temp][1].tag_lvl < rand(ench_lvl - lvl)
        return temp2[temp].clone
      end
      temp2.delete_if{|t| t==temp2[temp]}
    end
  end
  
  def Set.template
    temp= Tag.new("")
    temp.name        =  ""
    temp.descr       = []
    temp.fix         = []
    temp.fix[0]      = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    temp.b_xparam    = []
    temp.b_xparam[0] = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    temp.b_sparam    = []
    temp.b_sparam[0] = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    temp.tag_lvl     = 0
    temp.skills      = []
    temp.skills[0]   = nil
    temp.commands    = []
    temp.commands[0] = []
    temp.set_note    = []
    temp.set_note[0] = ""
=begin
    temp.push template
    set_id =  1
    temp.last.name     =  ""
    temp.last.descr    =  ""
    temp.last.prere    = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    temp.last.fix      =    [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    temp.last.random1  =    [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    temp.last.random2  =    [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    temp.last.b_xparam = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    temp.last.b_sparam = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    temp.last.tag_lvl  = 1
    temp.last.tag_c    = 0
    temp.last.tag_id   = 0
    temp.last.skills   = nil
    temp.last.tag_exclude = []
    temp.last.commands = []
    temp.last.set_price(0).set_price_100(1.0)
=end
    return temp
  end
  
  
  def Set.ids
    temp = []
    
      temp.push template
      temp.last.id          = 1000000000
      
################################################################################
#
#   Start of Set boni
#
################################################################################
      
      temp.push template
      temp.last.name        = "Spellcaster's"
      temp.last.id          = 1
      temp.last.descr[2]    =  "2: +100 MP, +10 Int"
      temp.last.descr[3]    =  "3: heal 2 MP/round"
      
#                                  H  M  S  D  M  M  A  L  D  V
#                                  P  P  T  E  A  D  G  C  E  I
#                                        R  F  G  F  I  K  X  T
      temp.last.fix[1]      =    [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
      temp.last.fix[2]      =    [ 0,100,0, 0,10, 0, 0, 0, 0, 0]
      temp.last.fix[3]      =    [ 0,100,0, 0,10, 0, 0, 0, 0, 0]
#                               H  E  C  C  M  M  C  H  M  T
#                               I  V  R  E  E  R  N  P  P  P
#                               T  A  I  V  V  F  T  R  R  R
      temp.last.b_xparam[1] = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
      temp.last.b_xparam[2] = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
      temp.last.b_xparam[3] = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
#                               T  G  R  P  M  T  P  M  F  E
#                               G  R  E  H  C  C  D  D  D  X
#                               R  D  C  A  R  R  R  R  R  R
      temp.last.b_sparam[1] = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
      temp.last.b_sparam[2] = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
      temp.last.b_sparam[3] = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
      temp.last.commands[1] = []
      temp.last.commands[2] = []
      temp.last.commands[3] = []
	  temp.last.commands[3].push ["TurnStart","actor = $game_temp.tidloc[:actor];
                                               temp = [[actor.mmp*0.02,1].max,actor.mmp-actor.mp].min;
                                               if temp > 0;
                                                 actor.mp += temp;
                                               end;"]
      temp.last.set_note[1] = ""
      temp.last.set_note[2] = ""
      temp.last.set_note[3] = ""
      
      return temp
  end

################################################################################
#
#   End of Set boni
#
################################################################################

  def Set.tags
    temp=[]
    
    temp2 = template
    temp2.tag_lvl  = 1000000000
    temp.push [0,temp2]
################################################################################
#
#   Start of Set items
#
################################################################################
      
      temp2 = template 
      set_id         =  1
      temp2.name     =  "Hairband"
      temp2.descr    =  "Devine Hairband of an ancient Spellcaster<br>Boosts MP slightly"
#                         L  H  M  S  D  M  M  A  L  D  V
#                         V  P  P  T  E  A  D  G  C  E  I
#                         L        R  f  G  F  I  K  X  T
      temp2.prere    =  [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2]
#                           H  M  S  D  M  M  A  L  D  V
#                           P  P  T  E  A  D  G  C  E  I
#                                 R  F  G  F  I  K  X  T
      temp2.fix      =    [ 0, 0, 2, 0, 0, 0, 0, 0, 0, 4]
      temp2.random1  =    [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
      temp2.random2  =    [ 0,10, 0, 0, 3, 0, 0, 3, 0, 0]
#                        H  E  C  C  M  M  C  H  M  T
#                        I  V  R  E  E  R  N  P  P  P
#                        T  A  I  V  V  F  T  R  R  R
      temp2.b_xparam = [ 1, 0, 0, 0, 0, 0, 0, 0, 0, 0]
#                        T  G  R  P  M  T  P  M  F  E
#                        G  R  E  H  C  C  D  D  D  X
#                        R  D  C  A  R  R  R  R  R  R
      temp2.b_sparam = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
      temp2.tag_lvl  = 10
      temp2.tag_c    = 2
      temp2.tag_id   = 102
      temp2.commands = []
      temp2.skills   = nil
      temp2.set_price(61).set_price_100(1.0)
      temp.push [set_id,temp2.clone]
      
      temp2 = template 
      set_id         =  1
      temp2.name     =  "Pendant"
      temp2.descr    =  "Golden Pendant of an ancient Spellcaster<br>Boosts HP/MP slightly"
#                         L  H  M  S  D  M  M  A  L  D  V
#                         V  P  P  T  E  A  D  G  C  E  I
#                         L        R  f  G  F  I  K  X  T
      temp2.prere    =  [ 0, 0, 0, 0, 0, 0, 0, 3, 0, 0, 0]
#                           H  M  S  D  M  M  A  L  D  V
#                           P  P  T  E  A  D  G  C  E  I
#                                 R  F  G  F  I  K  X  T
      temp2.fix      =    [ 5,10, 0, 0, 0, 0, 0, 0, 2, 0]
      temp2.random1  =    [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
      temp2.random2  =    [ 0, 0, 0, 0, 0, 0, 5, 0, 0, 0]
#                        H  E  C  C  M  M  C  H  M  T
#                        I  V  R  E  E  R  N  P  P  P
#                        T  A  I  V  V  F  T  R  R  R
      temp2.b_xparam = [ 1, 0, 0, 0, 0, 0, 0, 0, 0, 0]
#                        T  G  R  P  M  T  P  M  F  E
#                        G  R  E  H  C  C  D  D  D  X
#                        R  D  C  A  R  R  R  R  R  R
      temp2.b_sparam = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
      temp2.tag_lvl  = 15
      temp2.tag_c    = 2
      temp2.tag_id   = 302
      temp2.commands = []
      temp2.skills   = nil
      temp2.set_price(76).set_price_100(1.0)
      temp.push [set_id,temp2.clone]
      
      
################################################################################
    return temp
  end
  
end;end;end
