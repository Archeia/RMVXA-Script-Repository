################################################################################
#    Custom Equipment Durability 1.0.1                                         #
#         by Tidloc                                  (Aug-29-15)               #
#==============================================================================#
#  Addition script for my custom equipment.                                    #
#  With this script you can have your equipment have durability and let it     #
#  with usage of them.                                                         #
#------------------------------------------------------------------------------#
#  To set this script up, you have the following notetags:                     #
#    <durability *x*> initiates the item with *x* max durability               #
#    <dura-uses *x*>  item drops a durability after *x* uses, like attacks for #
#                     weapons and getting hit for armor                        #
#    <dura-max-fix>   maximum durability can not decrease for this item        #
#------------------------------------------------------------------------------#
#  You got the following constants for adjusting this script:                  #
#    Def_Max_Uses ........... Default maximum durability, only used if none    #
#                             has been set via notetag.                        #
#    Duraloss_in_Menu ....... true = weapon also loses durability when casting #
#                             magic in the menu and armor loses dura if an     #
#                             item or skill becomes used in the menu on the    #
#                             character.                                       #
#    Destroy_at_no_Dura ..... true = destroys an item, if its dura drops to 0. #
#    Destroy_at_no_maxDura .. true = destroys an item, if its maximum dura     #
#                             drops to 0.                                      #
#    Color_Dura ............. color in hex coding for displaying durability    #
#    Color_Max_ ............. color the max dura is displayed when not max     #
#    Color_Max_4 ............ color the max dura is displayed when it drops    #
#                             below 1/4 of original max.                       #
#------------------------------------------------------------------------------#
#  To start the repair scene use the following script command:                 #
#    Tidloc.exe "DuraRepair",:call,*w*,*p*,*m*,*o*                             #
#      where *w* is the probability of loosing durability upon repair in %.    #
#      The remaining arguments may be left out:                                #
#      *p* is the repair cost per durability to be repaired, by default 0.     #
#      *m* is the maximum number of max dura that can be lost per repair, per  #
#      default set to all (1000). Set *o* to true, if the repair scene shall   #
#      not be canceled after one repair.                                       #
#-----------------------                                                       #
#  To start the scene to restore the maximum durability of an item, use the    #
#  following script command:                                                   #
#    Tidloc.exe "DuraMaxRep",:call,*d*,*p*,*o*                                 #
#      where all arguments after :call are optional:                           #
#      *d* is by default 1 and defines how many of max durability will be      #
#      restored, *p* is the cost to fix the item, by default 0. Set *o* to     #
#      true if the scene shall not be canceled after one restore.              #
#==============================================================================#
#  Feel free to use this script, but please credit me for my work! ^__^        #
################################################################################



$imported = {} if $imported.nil?
$imported["Tidloc-CustomDura"] = [1,0,1]
$needed   = [] if $needed.nil?
$needed.push ["Tidloc-Header",[2,11,2],true,"Tidloc-CustomDura"]
$needed.push ["HTML-tagging",[1,4,0],true,"Tidloc-CustomDura"]
$needed.push ["Tidloc-CustomEquip",[1,5,10],true,"Tidloc-CustomDura"]

module Tidloc
  module CustomDura
    
    Def_Max_Uses          = 10
    Duraloss_in_Menu      = false
    Destroy_at_no_Dura    = false
    Destroy_at_no_maxDura = false
    Color_Dura            = "#afaf00"
    Color_Max_            = "#00afaf"
    Color_Max_4           = "#af0000"
###############################################################################
    Notetags = {:duramax => /<durability ([0-9]+)>/,
                :uses    => /<dura-uses ([0-9]+)>/,
                :noloss  => /<dura-max-fix>/
               }
  end
  module Vocabs;class<<self
    def CustomDura(code,lang)
      if    lang == "eng"
        case code
        when "Durability"; return "Durability"
        when "Cost";       return "Cost: "
        end
      elsif lang == "ger"
        case code
        when "Durability"; return "Haltbarkeit"
        when "Cost";       return "Kosten: "
        end
      end
    end
  end;end

################################################################################
#                                                                              #
################################################################################

  module CustomEquip
    class Base
      attr_accessor :durability
      attr_accessor :durability_uses
      attr_accessor :durability_max
      attr_accessor :durability_max_temp
      
      def dura_init
        self.durability_max  = 0
        self.durability_uses = 0
        if self.item && note =~ Tidloc::CustomDura::Notetags[:duramax]
          self.durability          = $1.to_i
          self.durability_max      = $1.to_i
          self.durability_max_temp = $1.to_i
        end
      end
      def repair(probability, maxdrop)
        maxdrop.times{
          if rand(100.0) < probability/100.0
            self.durability_max_temp -= 1
          else
            break
          end
          break if self.durability_max_temp == 0
        }
        self.durability = self.durability_max_temp
        if self.durability_max_temp == 0 && Tidloc::CustomDura::Destroy_at_no_maxDura
          $game_party.lose_item_for_all_time(self)
        end
      end
      def repair_max(dura=self.durability_max)
        self.durability_max_temp = [self.durability_max,self.durability_max_temp+dura].min
        self.durability          = self.durability_max_temp
      end
      def dura_use
        return unless self.durability_max > 0
        self.durability_uses += 1 if self.durability > 0
        if note =~ Tidloc::CustomDura::Notetags[:uses] && self.durability_uses >= $1.to_i
          self.durability_uses = 0
          self.durability -= 1
        elsif self.durability_uses >= Tidloc::CustomDura::Def_Max_Uses
          self.durability_uses = 0
          self.durability -= 1
        end
        if self.durability == 0
          if Tidloc::CustomDura::Destroy_at_no_Dura
            $game_party.lose_item_for_all_time(self)
          else
            $game_party.battle_members.each{|a| a.release_unequippable_items}
          end
        end
      end
    end
  end
end

module Tidloc
  module CustomDura
    class Window_Repair < Window_ItemList
      attr_accessor :price
      def initialize(*args)
        super(*args)
        self.price = nil
      end
      def include?(item)
        item && item.is_a?(Tidloc::CustomEquip::Base) && item.inv && item.durability_max > 0
      end
      def enable?(item)
        return false if item.nil?
        return false if item.durability == item.durability_max_temp
        return false unless self.price
        return false if (item.durability_max_temp-item.durability)*self.price > $game_party.gold
        true
      end
      def col_max
        1
      end
    end
    class Window_Repair_Max < Window_ItemList
      attr_accessor :price
      def include?(item)
        item && item.is_a?(Tidloc::CustomEquip::Base) && item.inv && item.durability_max > 0
      end
      def enable?(item)
        return false if item.nil?
        return false if item.durability_max_temp == item.durability_max
        return false unless self.price
        return false if self.price > $game_party.gold
        true
      end
      def col_max
        1
      end
    end
    class Window_cost < Window_Base
      attr_accessor :price
      attr_accessor :item
      attr_reader   :cost
      def initialize
        x = Graphics.width/2
        y = 0
        w = x
        h = 96
        super x,y,w,h
      end
      def update
        super
        self.contents.clear
        x = 4
        y = 4
        draw_html x,y,100,24,"<size=24><color=#4169e1>#{Vocab::currency_unit}"
        return if cost.nil?
        x = 20
        y = 24
        draw_html x,y,100,20,"<size=20>"+Tidloc::Vocabs.CustomDura("Cost",$tidloc_language)
        x = 40 + (10-Math::log10(cost).to_i)*8 if cost >  0
        x = 40 + 80                            if cost < 10
        draw_html x,y,80,20,"<size=20>#{cost}"
        y = 44
        x = 20
        draw_html x,y,30,20,"<size=20>Have: "
        x = 40 + (10-Math::log10($game_party.gold).to_i)*8 if $game_party.gold >  0
        x = 40 + 80                                        if $game_party.gold < 10
        draw_html x,y,80,40,"<size=20>#{$game_party.gold}"
      end
      def cost
        return nil if self.price.nil? || self.item.nil?
        return (self.item.durability_max_temp-self.item.durability)*self.price
      end
    end
    class Window_cost_max < Window_cost
      def cost
        self.price
      end
    end
# repair scene
    class Scene_Repair < Scene_Base
      attr_accessor :prop
      attr_accessor :maxlose
      attr_accessor :price
      attr_accessor :multi
      def initialize(prop,price=0,maxlose=1000,multi=false)
        self.prop  = prop
        self.maxlose = maxlose
        self.price = price
        self.multi = multi
        super
      end
      def start
        super
        create_cost_window
        create_item_window
        create_info_window
      end
      def create_cost_window
        @cost_window = Tidloc::CustomDura::Window_cost.new
        @cost_window.price = self.price
      end
      def create_item_window
        x = Graphics.width/2
        y = 96
        w = x
        h = Graphics.height-96
        @item_window = Tidloc::CustomDura::Window_Repair.new x,y,w,h
        @item_window.set_handler(:ok,     method(:on_item_ok))
        @item_window.set_handler(:cancel, method(:return_scene))
        @item_window.set_handler(:change, method(:on_item_change))
        @item_window.price = self.price
        @item_window.refresh
        @item_window.index = 0 if @item_window.item_max > 0
        @item_window.activate
      end
      def create_info_window
        @help_window = Tidloc::CustomEquip::Window_ShopStatus2.new(0, 0, Graphics.width/2, Graphics.height)
        @help_window.z = 2000
        @help_window.scene = :repair
        @item_window.help_window = @help_window
      end
      def on_item_ok
        $game_party.gain_gold(-@cost_window.cost)
        @item_window.item.repair self.prop,self.maxlose
        if self.multi
          @item_window.activate
        else
          if $game_temp._tidloc_item_used.size > 0
            item  = $game_temp.tidloc[:item]
            actor = $game_temp.tidloc[:actor]
            $game_party.lose_item(item, 1) if item.is_a?(RPG::Item)
            actor.pay_skill_cost(item) if item.is_a?(RPG::Skill)
            actor.pay_skill_cost(item) if $imported["Tidloc-CustomSkills"] && item.is_a?(Tidloc::CustomSkills::Base)
            $game_temp._tidloc_item_used = []
            return_scene
          end
        end
      end
      def on_item_change
        @cost_window.item = @item_window.item
      end
      def update_all_windows
        super
        if Input.press?(:R)
          @help_window.oy = [@help_window.oy+5,@help_window.contents_height-Graphics.height].min
        elsif Input.press?(:L)
          @help_window.oy = [@help_window.oy-5,0].max
        end
      end
    end
# repair max dura scene
    class Scene_RepairMax < Scene_Base
      attr_accessor :max
      attr_accessor :price
      attr_accessor :multi
      def initialize(max=1,price=0,multi=false)
        self.max   = max
        self.price = price
        self.multi = multi
        super
      end
      def start
        super
        create_cost_window
        create_item_window
        create_info_window
      end
      def create_cost_window
        @cost_window = Tidloc::CustomDura::Window_cost_max.new
        @cost_window.price = self.price
      end
      def create_item_window
        x = Graphics.width/2
        y = 96
        w = x
        h = Graphics.height-96
        @item_window = Tidloc::CustomDura::Window_Repair_Max.new x,y,w,h
        @item_window.set_handler(:ok,     method(:on_item_ok))
        @item_window.set_handler(:cancel, method(:return_scene))
        @item_window.set_handler(:change, method(:on_item_change))
        @item_window.price = self.price
        @item_window.refresh
        @item_window.index = 0 if @item_window.item_max > 0
        @item_window.activate
      end
      def create_info_window
        @help_window = Tidloc::CustomEquip::Window_ShopStatus2.new(0, 0, Graphics.width/2, Graphics.height)
        @help_window.z = 2000
        @help_window.scene = :repair
        @item_window.help_window = @help_window
      end
      def on_item_ok
        $game_party.gain_gold(-@cost_window.cost)
        @item_window.item.repair_max self.max
        if self.multi
          @item_window.activate
          @cost_window.refresh
        else
          if $game_temp._tidloc_item_used.size > 0
            item  = $game_temp.tidloc[:item]
            actor = $game_temp.tidloc[:actor]
            $game_party.lose_item(item, 1) if item.is_a?(RPG::Item)
            actor.pay_skill_cost(item) if item.is_a?(RPG::Skill)
            actor.pay_skill_cost(item) if $imported["Tidloc-CustomSkills"] && item.is_a?(Tidloc::CustomSkills::Base)
            $game_temp._tidloc_item_used = []
            return_scene
          end
        end
      end
      def on_item_change
        @cost_window.item = @item_window.item
      end
      def update_all_windows
        super
        if Input.press?(:R)
          @help_window.oy = [@help_window.oy+5,@help_window.contents_height-Graphics.height].min
        elsif Input.press?(:L)
          @help_window.oy = [@help_window.oy-5,0].max
        end
      end
    end
  end
end