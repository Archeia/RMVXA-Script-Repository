#########################
#
#  For the cardconverter to function, cards need an additional
#  setting like below:
#       'Converter'   => [num,class,id,amount]
#    num ...... number of cards consumed for the conversion
#  The remaining are for the outcome of the conversion:
#    class .... 0=item, 1=weapon, 2=armor, 3=skill, 4=money, 5=other card
#    id ....... database-id of item/skill/card, not important if money
#    amount ... amount of item/card/money or database-id of actor to learn 
#               the skill(0 for all actors to learn)
#--------------
#  To call the Card Converter Scene, use one of the following script commands:
#       Tidloc.call_CC
#       SceneManager.call Scene_Card_Converter
#
########################

$imported = {} if $imported.nil?
$imported["Tidloc-TT_CardConverter"] = [1,0,5]

module Tidloc
  module Games
    module TripleTriad
    end
  end
  module Vocabs;class<<self
    def games_tripletriad(code,lang)
      if    lang == "eng"
        case code
        when "Card"   ; return "Card"
        when "Amount" ; return "Choose the amount:"
        when "for"    ; return "for"
        when "all"    ; return "all"
        end
      elsif lang == "ger"
        case code
        when "Card"   ; return "Karte"
        when "Amount" ; return "Anzahl:"
        when "for"    ; return "für"
        when "all"    ; return "alle"
        end
      end
    end
  end;end
end

module SceneManager
  unless $imported["Tidloc-Header"]
    def self.call(scene_class, *args)
      @stack.push(@scene)
      @scene = scene_class.new *args
    end
  end
end

module Tidloc
  class<<self
    def call_CC(multi = true)
      SceneManager.call Scene_Card_Converter,multi
      return false
    end
  end
  module Games
    module TripleTriad
      Notetags = [/<card: ([0-9]+)>/i,
                  /<card-prop: ([0-9]+)>/i]
      Card_NoItem = true
      class Card
        attr_accessor :name
        attr_accessor :icon_index
        attr_accessor :description
        attr_accessor :id
        def initialize(id)
          lang  = $imported["Tidloc-Header"]? $tidloc_language : "eng"
          self.id          = id
          self.name        = $imported["HTML-tagging"] ? "<color=#af80ff>" : ""
          self.name       += Tidloc::Vocabs.games_tripletriad("Card",lang)
          self.name       += ": "
          self.name       += Config_Triple_Triad::Card[id]['Name']
          self.icon_index  = Config_Triple_Triad::Rarity_Icons[Config_Triple_Triad::Card[id]['Rarity']][0]
          self.description = Config_Triple_Triad::Card[id]['Description'][0]
        end
  # for W/A randomizer:
        def color
          Color.new 255,255,255
        end
  # for Yanfly - Lunatic Parameters:
        def custom_parameters
          { 0 => [],
            1 => [], 
            2 => [], 
            3 => [], 
            4 => [], 
            5 => [], 
            6 => [], 
            7 => [] }
        end
      end
      class Window_Cards < Window_ItemList
        def initialize
          super Graphics.width/2,0,Graphics.width/2,Graphics.height
        end
        def make_item_list
          @data = []
          Config_Triple_Triad::Card.each_with_index{|c,i|
            if $game_timer.total_cards[i] > 0 && c['Converter']
              card = Tidloc::Games::TripleTriad::Card.new(i)
              @data.push(card)
            end
          }
        end
        def include?(item)
          true
        end
        def enable?(item)
          return false if item.nil?
          card = Config_Triple_Triad::Card[item.id]
          if $game_timer.total_cards[item.id] >= card['Converter'][0]
            return true
          end
          return false
        end
        def col_max
          1
        end
      end
      class Window_Num < Window_Selectable
        attr_accessor :source
        attr_accessor :target
        attr_accessor :text
        def initialize
          self.source = 0
          self.target = 0
          self.text   = ""
          x = Graphics.width/2 - 150
          y = Graphics.height/2 - 64
          w = 300
          h = 128
          super x,y,w,h
          self.hide.deactivate
        end
        def refresh
          self.contents.clear
          draw_text  4,  4, 290, 32, self.text
          draw_text 20, 50, 260, 32, "#{self.source} → #{self.target}"
        end
      end
      class Window_Card_Description < Window_Base
        def initialize
          super 0,0,Graphics.width/2,Graphics.height
        end
        def refresh(card)
          self.contents.clear
          return if card.nil?
          self.contents = Bitmap.new(self.width-16,self.height-16)
          img = Cache.triple_triad_card("#{card['Image']}2")
          x = (self.width-16)/2-45
          self.contents.blt(x,40,img,img.rect)
          draw_text(4,4,contents.width,32,Bitmap.html_decode(card['Name']),1)
          text = card['Converter'][0].to_s
          draw_text(4,165,40,32,text,2)
          draw_text(50,165,15,32,"→",1)
          if card['Converter'][1] == 5
            newcard = Config_Triple_Triad::Card[card['Converter'][3]]
          end
          lang  = $imported["Tidloc-Header"]? $tidloc_language : "eng"
          case card['Converter'][1]
          when 0
            text  = Bitmap.html_decode(Vocab::item)
            text += ": #{card['Converter'][3]}x #{ $data_items[card['Converter'][2]].name}"
          when 1
            text  = Bitmap.html_decode(Vocab::weapon)
            text += ": #{card['Converter'][3]}x #{$data_weapon[card['Converter'][2]].name}"
          when 2
            text  = Bitmap.html_decode(Vocab::armor)
            text += ": #{card['Converter'][3]}x #{$data_armors[card['Converter'][2]].name}"
          when 5
            text  = Tidloc::Vocabs.games_tripletriad("Card",lang)
            text +=": #{newcard['Name']}"
          when 4
            text  = "#{Bitmap.html_decode(Vocab::currency_unit)}"
            text += ": #{card['Converter'][3]}"
          when 3
            text  = Bitmap.html_decode(Vocab::skill)
            text += ": #{$data_skills[card['Converter'][2]].name} "
            text += Tidloc::Vocabs.games_tripletriad("for",lang)+" "
            if card['Converter'][3] == 0
              text += Tidloc::Vocabs.games_tripletriad("all",lang)
            else
              text += $game_actor[card['Converter'][3]].name
            end
            text += "."
          end
          draw_text 65,165,self.contents.width-65,32,text
        end
      end
    end
  end
end
##########
# Scene:
##########
class Scene_Card_Converter < Scene_Base
  def initialize(multi=true)
    super
    @multi = multi
  end
  def start
    super
    create_card_window
    create_desc_window
    create_num_window
  end
  def create_card_window
    @card_window = Tidloc::Games::TripleTriad::Window_Cards.new 
    @card_window.set_handler(:ok,     method(:on_item_ok))
    @card_window.set_handler(:cancel, method(:return_scene))
    @card_window.set_handler(:change, method(:update_desc))
    @card_window.show.activate.refresh
    @card_window.index = 0 if @card_window.item_max > 0
    @card_window.update
  end
  def create_desc_window
    @desc_window = Tidloc::Games::TripleTriad::Window_Card_Description.new 
    update_desc
  end
  def create_num_window
    @num_window = Tidloc::Games::TripleTriad::Window_Num.new
    @num_window.set_handler(:ok,     method(:on_num_ok))
    @num_window.set_handler(:cancel, method(:on_num_cancel))
  end
  def update_desc
    return unless @card_window.item
    card = Config_Triple_Triad::Card[@card_window.item.id]
    @desc_window.refresh card
  end
  def on_num_ok
    @card_window.activate
    @num_window.hide.text = ""
    dif = Config_Triple_Triad::Card[@card_window.item.id]['Converter'][0]
    (@num_window.source/dif).to_i.times{|i|
      sell
    }
  end
  def on_num_cancel
    @card_window.activate
    @num_window.hide.text = ""
  end
  def on_item_ok
    card = Config_Triple_Triad::Card[@card_window.item.id]
    if @multi && card['Converter'][1] != 3
      @num_window.show.activate
      @num_window.source = card['Converter'][0]
      @num_window.target = card['Converter'][3]
    else
      sell
    end
  end
  def sell
    card = Config_Triple_Triad::Card[@card_window.item.id]
    $game_timer.total_cards[@card_window.item.id] -= card['Converter'][0]
    case card['Converter'][1]
    when 0; $game_party.gain_item($data_items[card['Converter'][2]],card['Converter'][3])
    when 1; $game_party.gain_item($data_weapons[card['Converter'][2]],card['Converter'][3])
    when 2; $game_party.gain_item($data_armors[card['Converter'][2]],card['Converter'][3])
    when 4; $game_party.gain_gold(card['Converter'][3])
    when 5; $game_timer.total_cards[card['Converter'][2]] += card['Converter'][3]
    when 3 # skill
      if card['Converter'][3] == 0
        $game_actor.each{|a|
          a.learn_skill($data_skills[card['Converter'][2]])
        }
      else
        $game_actor[card['Converter'][3]].learn_skill($data_skills[card['Converter'][2]])
      end
    end
    if @multi
      @card_window.show.activate.refresh 
      @card_window.index = [@card_window.index,@card_window.item_max-1].min
    else
      if $imported["Tidloc-Header"]
        item  = $game_temp.tidloc[:item]  if $game_temp.tidloc[:item]
        actor = $game_temp.tidloc[:actor] if $game_temp.tidloc[:actor]
        $game_party.lose_item(item, 1)    if item.is_a?(RPG::Item)
        actor.pay_skill_cost(item)        if item.is_a?(RPG::Skill)
      end
      return_scene
    end
  end
  def update_all_windows
    super
    if @num_window.active
      lang  = $imported["Tidloc-Header"]? $tidloc_language : "eng"
      @num_window.text = Tidloc::Vocabs.games_tripletriad("Amount",lang)
      card = Config_Triple_Triad::Card[@card_window.item.id]
      dif = card['Converter'][0]
      if Input.trigger?(:LEFT) || Input.trigger?(:DOWN)
        Sound.play_cursor
        @num_window.source = [@num_window.source - dif, dif].max
        @num_window.target = (@num_window.source/dif).to_i * card['Converter'][3]
      elsif Input.trigger?(:RIGHT) || Input.trigger?(:UP)
        Sound.play_cursor
        @num_window.source = [@num_window.source + dif,
               ($game_timer.total_cards[@card_window.item.id]/dif.to_i*dif)].min
        @num_window.target = (@num_window.source/dif).to_i * card['Converter'][3]
      end
      @num_window.refresh
    end
  end
end



class Game_Party < Game_Unit
  alias wo_tidloc_TT_usable? usable?
  def usable?(item)
    if item.is_a?(Tidloc::Games::TripleTriad::Card)
      return false
    else
      wo_tidloc_TT_usable?(item)
    end
  end
  alias wo_tidloc_TT_item_number item_number
  def item_number(item)
    if item.is_a?(Tidloc::Games::TripleTriad::Card)
      $game_timer.total_cards[item.id]
    else
      wo_tidloc_TT_item_number(item)
    end
  end
end

class Game_Enemy
  attr_accessor :turned_to_card
  alias wo_tidloc_TT_initialize initialize
  def initialize(*args)
    wo_tidloc_TT_initialize *args
    self.turned_to_card = false
  end
  def turn_to_card
    if self.note =~ Tidloc::Games::TripleTriad::Notetags[0]
      id = $1.to_i
      if self.note =~ Tidloc::Games::TripleTriad::Notetags[1]
        if rand(100) < $1.to_i
          $game_timer.total_cards[id] += 1
          self.turned_to_card = Tidloc::Games::TripleTriad::Card_NoItem
          return true
        end
      else
        $game_timer.total_cards[id] += 1
        self.turned_to_card = Tidloc::Games::TripleTriad::Card_NoItem
        return true
      end
      return false
    else
      return false
    end
  end
  def card_name
    if self.note =~ Tidloc::Games::TripleTriad::Notetags[0]
      lang  = $imported["Tidloc-Header"]? $tidloc_language : "eng"
      text  = Config_Triple_Triad::Card[$1.to_i]['Name']
      text += " "+Tidloc::Vocabs.games_tripletriad("Card",lang)
      end
      return text
    return ""
  end
end

class Game_Enemy
  alias wo_tidloc_TT_make_drop_items make_drop_items
  def make_drop_items
    return if self.turned_to_card
    wo_tidloc_TT_make_drop_items
  end
end

class Bitmap
  if !$imported["HTML-tagging"]
    def Bitmap.html_decode(str)
      str
    end
  end
end

class Window_Selectable
  alias wo_ttcc_select select
  def select(index)
    wo_ttcc_select(index)
    call_handler(:change) unless $imported["Tidloc-Header"]
  end
  alias wo_ttcc_activate activate
  def activate
    wo_ttcc_activate
    call_handler(:change) unless $imported["Tidloc-Header"]
    self
  end
end