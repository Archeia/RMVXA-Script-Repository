$imported = {} if $imported.nil?


#######################
#
# if you set SwitchShowRules = -1 rules will always be displayed without
# wasting a game switch on this.
#
# also setting the WinVariable to -1 if the game gets canceled!
#-------------
# Switch_Skip_Card ......... game switch that, if set true, will let you skip
#                            the card selection upon beginning a duel. set it
#                            to nil to disable it.
# Show_only_collected ...... true = only displaying cards, that have already 
#                            been collected by the player.
# Change_direct_to_duel .... true = when equipping a fifth card during duel 
#                            preparation, the scene will automaticly change to
#                            the duel scene
#-------------
# Implemented new methods:
#   TT.booster ....... same as booster_triad_card in event script commands, but
#                      available everywhere
#   TT.booster_special *id*,*f*,*s*
#              request by Player One:
#              *id* is still the booster id
#              *f*  is the only allowed family, set to nil, if only special 
#                   shall be looked at
#              *s*  is the only allowed special (may be left out)
#
#######################

module Config_Triple_Triad
  Switch_Skip_Card      = nil
  Show_only_collected   = true
  Change_direct_to_duel = false
  Info_Message  = "Press X to continue!"
  Start_Message = "Press A to start the Game"
#~   only displaying names of rules:
  Rule_Texts[0] = "Same"
  Rule_Texts[1] = "Plus"
  Rule_Texts[2] = "Combo"
  Rule_Texts[3] = "Samewall"
  Rule_Texts[4] = "Pluswall"
  Rule_Texts[5] = "Open"
  Rule_Texts[6] = "Elemental"
  Rule_Texts[7] = "Trade Rule: "
end

class Window_Card_BuyList < Window_Command
  def make_command_list
    for i in 0...@card_number.length
      command = Card[@card_number[i]]['Name']
      if $imported["HTML-tagging"]
        command = "<color=cyan>#{command}</color>"   if $game_timer.total_cards[@card_number[i]] == -1
        command = "<color=yellow>#{command}</color>" if $game_timer.total_cards[@card_number[i]] == 0
      end
      add_command(command, nil) 
    end
  end
end

class Window_Card_List < Window_Command
  def make_command_list
    if SceneManager.scene_is?(Scene_Card_Overflow)
      for i in 0...@card_number.length
        if OIcon_Version == true
          if $game_timer.card_discovery[i] == false
            command = ""
            next if Config_Triple_Triad::Show_only_collected
          elsif $game_timer.card_discovery[i] == true && @card_number[i] <= 0 && !$game_timer.hand_deck.include?(i)
            command = ""
          else
            command = $game_timer.total_cards[i].to_s
          end
          add_command(command, nil, true, index) 
        else
          command = Card[i]['Name']
          command = "?????" if $game_timer.card_discovery[i] == false
          add_command(command, nil) 
        end
      end
    else
      for i in 0...@card_number.length
        if Icon_Version == true
          if $game_timer.card_discovery[i] == false
            command = ""
            next if Config_Triple_Triad::Show_only_collected
          elsif $game_timer.card_discovery[i] == true && @card_number[i] <= 0 && !$game_timer.hand_deck.include?(i)
            command = ""
          else
            command = $game_timer.total_cards[i].to_s
          end
          add_command(command, nil, true, index) 
        else
          command = Card[i]['Name']
#~           start alteration
          if Config_Triple_Triad::Show_only_collected && $game_timer.card_discovery[i] == false
            next
          end
          command = "?????" if $game_timer.card_discovery[i] == false
#~           end alteration
          add_command(command, nil) 
        end
      end
    end
  end
  def draw_item(index)
    if SceneManager.scene_is?(Scene_Card_Overflow) && OIcon_Version == true
      change_color(normal_color, command_enabled?(index))
      rect = item_rect_for_text(index)
      rect.width = 24
      rect.x -= 4
#~       start alteration
      if Config_Triple_Triad::Show_only_collected
        cards = []
        Card.each_with_index{|c,i| cards.push i if $game_timer.total_cards[i] > -1}
        iindex = cards[index]
        if @card_number[iindex] > 0 || $game_timer.hand_deck.include?(iindex)
          draw_icon(Rarity_Icons[Card[iindex]['Rarity']][0],rect.x,rect.y)
        elsif @card_number[iindex] <= 0 && $game_timer.card_discovery[iindex] == true
          draw_icon(Rarity_Icons[Card[iindex]['Rarity']][1],rect.x,rect.y)
        else
          draw_icon(Rarity_Icons[Card[iindex]['Rarity']][2],rect.x,rect.y)
        end
      else
        if @card_number[index] > 0 || $game_timer.hand_deck.include?(index)
          draw_icon(Rarity_Icons[Card[index]['Rarity']][0],rect.x,rect.y)
        elsif @card_number[index] <= 0 && $game_timer.card_discovery[index] == true
          draw_icon(Rarity_Icons[Card[index]['Rarity']][1],rect.x,rect.y)
        else
          draw_icon(Rarity_Icons[Card[index]['Rarity']][2],rect.x,rect.y)
        end
      end
#~       end alteration
      contents.font.size = 16
      rect.y += 1
      draw_text(rect, command_name(index), alignment)
    elsif SceneManager.scene_is?(Scene_Triad_Album) && Icon_Version == true
      change_color(normal_color, command_enabled?(index))
      rect = item_rect_for_text(index)
      rect.width = 24
      rect.x -= 4
#~       start alteration
      if Config_Triple_Triad::Show_only_collected
        cards = []
        Card.each_with_index{|c,i| cards.push i if $game_timer.total_cards[i] > -1}
        iindex = cards[index]
        if @card_number[iindex] > 0 || $game_timer.hand_deck.include?(iindex)
          draw_icon(Rarity_Icons[Card[iindex]['Rarity']][0],rect.x,rect.y)
        elsif @card_number[iindex] <= 0 && $game_timer.card_discovery[iindex] == true
          draw_icon(Rarity_Icons[Card[iindex]['Rarity']][1],rect.x,rect.y)
        else
          draw_icon(Rarity_Icons[Card[iindex]['Rarity']][2],rect.x,rect.y)
        end
      else
        if @card_number[index] > 0 || $game_timer.hand_deck.include?(index)
          draw_icon(Rarity_Icons[Card[index]['Rarity']][0],rect.x,rect.y)
        elsif @card_number[index] <= 0 && $game_timer.card_discovery[index] == true
          draw_icon(Rarity_Icons[Card[index]['Rarity']][1],rect.x,rect.y)
        else
          draw_icon(Rarity_Icons[Card[index]['Rarity']][2],rect.x,rect.y)
        end
      end
#~       end alteration
      contents.font.size = 16
      rect.y += 1
      draw_text(rect, command_name(index), alignment)
    else
      super
    end
  end
end

class Triple_Triad_Rules < Window_Base
  alias wo_tidloc_triad_update update
#~   additional update line if window has wrong height
  def update
    if self.height != fit_height
      refresh
    end
    wo_tidloc_triad_update
  end
  def refresh
#~     start alteration
    self.contents.dispose
    self.contents = Bitmap.new(width-32,fit_height-32)
    self.height = fit_height
#~     end alteration
    contents.font.size = Text_size
    contents.font.name = Text_font
    contents.font.size += 8
    change_color(Color.new(*Rule_Title_Color))
    colord1 = Color.new(*Rules_Divider_Color[0])
    colord2 = Color.new(*Rules_Divider_Color[1])
    contents.fill_rect(0,Rules_Divider_Y,contents.width,2,colord1)
    contents.fill_rect(0,Rules_Divider_Y+2,contents.width,1,colord2)
    if $imported["Tidloc-Runes"]
      draw_text(0, Rule_Title_Text_Y, contents.width, line_height, Config_Triple_Triad.Title_Rule, 1)
    else
      draw_text(0, Rule_Title_Text_Y, contents.width, line_height, Title_Rule, 1)
    end
    contents.font.size -= 8
    change_color(Color.new(*TT_System_Color))
    color = Color.new(*Rules_Text_Box_Color)
    y11 = Rule_Title_Text_Y + Rules_Text_Box_Y
    @yy = 0
#~     start alterations
    for n in 0..6
      next if !Rules_Included.include?(n)
      if @battle_info[n + 5] == true
      contents.fill_rect(0,@yy+y11+1,Rules_Text_Box_Width,line_height-2,color)
        if $imported["Tidloc-Runes"]
          draw_html(Rules_Text_Box_X+4, y11+@yy, Rules_Text_Box_Width-8, line_height, "<center>"+Config_Triple_Triad.Rule_Texts[n])
        else
          draw_text(Rules_Text_Box_X+4, y11+@yy, Rules_Text_Box_Width-8, line_height, Rule_Texts[n], 1)
        end
        @yy += line_height
      end
    end
    if $imported["Tidloc-Runes"]
      draw_text(Rules_Text_Box_X+4, y11+@yy, Rules_Text_Box_Width-8, line_height, Config_Triple_Triad.Rule_Texts[7])
    else
      draw_text(Rules_Text_Box_X+4, y11+@yy, Rules_Text_Box_Width-8, line_height, Rule_Texts[7])
    end
    draw_text(Rules_Text_Box_X+4, y11+@yy, Rules_Text_Box_Width-8, line_height, Win_Tex[@battle_info[3]-1]+" ", 2)
#~     end alterations
    reset_font_settings
  end
#~   new routine for fitting window:
  def fit_height
   104+(@battle_info[5..11].find_all{|x| x}).count*32
  end
end

class Window_Card_Description < Window_Base
  alias wo_tidloc_tt_refresh refresh
  def refresh(index)
#~     capturing if index is nil when album is empty:
    return if index.nil?
    wo_tidloc_tt_refresh(index)
  end
end

class Window_Card_Description_S < Window_Base
  def refresh(index, b=false)
    contents.clear
    contents.font.size = Text_size
    contents.font.name = Text_font
    return if index == nil || index == -1
    text1 = Card[index]['Name']
    bitmap = Cache.triple_triad_card(Card[index]['Image']+Config_Triple_Triad::Player1Marker)
    if SCard_X == :center
      album_x = (self.width - bitmap.width)/2 - standard_padding
    else
      album_x = SCard_X
    end
    text_x = SCard_Name_X 
    colorb1 = Color.new(*SInfo_Box_Color1)
    colorb2 = Color.new(*SInfo_Box_Color2)
    xb = 8
    yb = line_height - 16
    wb = contents.width - xb*2
    hb = SBox_Height
    xbw = SBoxVertDivLine
    #upper line
    contents.fill_rect(xb,yb,wb,2,colorb1)
    contents.fill_rect(xb,yb+2,wb,1,colorb2)
    #bottom line
    contents.fill_rect(xb,yb+hb,wb,1,colorb2)
    contents.fill_rect(xb,yb+1+hb,wb,2,colorb1)
    #left line
    contents.fill_rect(xb,yb,2,hb+1,colorb1)
    contents.fill_rect(xb+2,yb+2,1,hb-2,colorb2)
    #right line
    contents.fill_rect(xb+wb-3,yb+2,1,hb-2,colorb2)
    contents.fill_rect(xb+wb-2,yb,2,hb+1,colorb1)
    #middle horizontal line
    contents.fill_rect(xb+2,yb-1+30,wb-4,1,colorb2)
    contents.fill_rect(xb,yb+30,wb,2,colorb1)
    contents.fill_rect(xb+2,yb+2+30,wb-4,1,colorb2)
    #middle vertical line
    contents.fill_rect(xb+xbw-1,yb+2+30,1,hb-4-28,colorb2)
    contents.fill_rect(xb+xbw,yb+30,2,hb-29,colorb1)
    contents.fill_rect(xb+xbw+2,yb+2+30,1,hb-4-28,colorb2)
    contents.font.size = Text_size + 4
    if $imported["HTML-tagging"]
      draw_html(text_x, SCard_Name_Y, contents.width, fitting_height(1), "<center>\100\100"+text1)
    else
      draw_text(text_x, SCard_Name_Y, contents.width, fitting_height(1), text1, 1)
    end
    contents.font.size = Text_size
    x1 = SInfo_Txt_X 
    y1 = SInfo_Txt_Y 
    w1 = SInfo_Txt_W 
    h1 = line_height
    @yy = 0
    color = Color.new(*SText_Box_Color)
    4.times do
      contents.fill_rect(x1-4,y1+1+@yy,w1+8,h1-2,color)
      @yy += line_height
    end
    sum =  Card[index]['UP'] + Card[index]['RIGHT'] + Card[index]['LEFT'] + Card[index]['DOWN']
    colorpr = Color.new(*TT_System_Color)
    change_color(colorpr)
    draw_text(x1,y1,w1,h1,Config_Triple_Triad.Album_Text[0])
    draw_text(x1,y1+line_height,w1,h1,Config_Triple_Triad.Album_Text[1])
    draw_text(x1,y1+line_height*2,w1,h1,Config_Triple_Triad.Album_Text[10])
    draw_text(x1,y1+line_height*3,w1,h1,Config_Triple_Triad.Album_Text[11])
    if ($game_timer.total_cards[index] + $game_timer.hand_cards_check[index]) == Config_Triple_Triad::Max_Cards_Types && Config_Triple_Triad::Max_Cards_Types != 0
      colorfl = Color.new(*Cards_Full_Color)
      change_color(colorfl)
    else
      change_color(normal_color)
    end
#~     capture if card has never been hold:
    draw_text(x1,y1,w1,h1,[$game_timer.total_cards[index],0].max.to_s,2)
    rare_txt = Config_Triple_Triad::Rarity_Texts[Card[index]['Rarity']]
    colorr = Color.new(*Config_Triple_Triad::Rarity_Color[Card[index]['Rarity']])
    change_color(colorr)
    if $imported["HTML-tagging"]
      draw_html(x1,y1+line_height,w1,h1,"<right>"+rare_txt)
      change_color(normal_color)
      draw_html(x1,y1+line_height*2,w1,h1,"<right>"+sum.to_s)
    else
      draw_text(x1,y1+line_height,w1,h1,rare_txt,2)
      change_color(normal_color)
      draw_text(x1,y1+line_height*2,w1,h1,sum.to_s,2)
    end
    price = Card[index]['Price']
    price *= 2 if b == true
    draw_text(x1,y1+line_height*3,w1,h1,price.to_s,2)
    TT_Utils.paint_card(bitmap, index)
    rect = Rect.new(0, 0, bitmap.width, bitmap.height)
    contents.blt(album_x, SCard_Y, bitmap, rect, 255)
    pos1 = Config_Triple_Triad::Indicator_Pos
    case Status_Indicator
    when :not_dscvrd
      bitmap2 = Cache.triple_triad(Config_Triple_Triad::Undisc_Indicator_Img)
      contents.blt(album_x+pos1[0], SCard_Y+pos1[1], bitmap2, rect, 255) if $game_timer.card_discovery[index] == false
    when :not_owned
      bitmap2 = Cache.triple_triad(Config_Triple_Triad::New_Indicator_Img)
      contents.blt(album_x+pos1[0], SCard_Y+pos1[1], bitmap2, rect, 255) if $game_timer.total_cards[index] == 0 && !$game_timer.hand_deck.include?(index)
    when :both
      if $game_timer.card_discovery[index] == false
        bitmap2 = Cache.triple_triad(Config_Triple_Triad::Undisc_Indicator_Img)
        contents.blt(album_x+pos1[0], SCard_Y+pos1[1], bitmap2, rect, 255) 
      elsif $game_timer.total_cards[index] == 0 && !$game_timer.hand_deck.include?(index)
        bitmap2 = Cache.triple_triad(Config_Triple_Triad::New_Indicator_Img)
        contents.blt(album_x+pos1[0], SCard_Y+pos1[1], bitmap2, rect, 255) 
      end
    end
    h1 = SDescription_Y  #self.height - fitting_height(4) - 4
    color1 = Color.new(*SDivider_upper)
    color2 = Color.new(*SDivider_lower)
    contents.fill_rect(2, h1 + 13, contents.width - 4, 2, color1)
    contents.fill_rect(2, h1 + 15, contents.width - 4, 1, color2)
    change_color(colorpr)
    contents.font.bold = true
    contents.font.shadow = true
    contents.font.outline = true
    if $imported["HTML-tagging"]
      draw_html(12, h1 - 15, contents.width, fitting_height(1), Config_Triple_Triad.Album_Text[13])
    else
      draw_text(12, h1 - 15, contents.width, fitting_height(1), Album_Text[13])
    end
    contents.font.bold = false
    contents.font.shadow = false
    contents.font.outline = false
    change_color(normal_color)
    height = SDescription_Y + line_height #h1 + 24
    @yd = 0
    colord = Color.new(*SText_Box_Color)
    Max_Desc_Line.times do
      contents.fill_rect(4,height+@yd,contents.width-8,line_height,colord)
      @yd += line_height
    end
    @textd = [""]
    @textd = Config_Triple_Triad::Card[index]['Description'] if Config_Triple_Triad::Card[index]['Description'] != nil
    @yhd = 0
    @textd.each do |string|
      @yhd += 1
    end
    @thd = ((line_height*SMax_Desc_Line) - (@yhd*line_height))/2
    desc_y = 0
    contents.font.size = SDesc_Txt_Size
    @textd.each do |string|
      if $imported["HTML-tagging"]
        draw_html(0, height+desc_y+@thd, contents.width, line_height, "<center>\100"+string)
      else
        draw_text(0, height+desc_y+@thd, contents.width, line_height, string, 1)
      end
      desc_y += line_height
    end
    reset_font_settings
  end
end
  
class Shop_Triple_Triad < Scene_MenuBase
  def command_sell 
    @sell_window.dispose
    yl = SCard_List_Window[1]
    hl = SCard_List_Window[3]
    @sell_window = Window_Card_SellList.new($game_timer.total_cards.dup, hl)
    @sell_window.y = yl
    @sell_window.opacity = 0
    @sell_window.z = 200
    if $game_timer.total_cards.dup.card_sum == 0
      Sound.play_buzzer
      @command_window.active = true
      @sell_window.active = false
      return
    else
      @buy_window.contents_opacity = 0
      @sell_window.contents_opacity = 255
      @sell_window.select(0)
      @desc_window.refresh(@sell_window.array_cards[@sell_window.index])
      @sell_window.active = true
      @command_window.active = false
    end
  end
end

class Window_Triad_Condition < Window_Base
  def refresh(final = false)
    contents.clear
    contents.font.size = Text_size
    contents.font.name = Text_font
    if final
      if $imported["HTML-tagging"]
        contents.draw_text(0, 0, contents.width, contents.height, Bitmap.html_decoding(Info_Message),1)
      else
        contents.draw_text(0, 0, contents.width, contents.height, Info_Message, 1)
      end
    elsif $game_timer.game_triple_triad[3] == 1
      if $imported["Tidloc-Runes"]
        contents.draw_text(0, 0, contents.width, contents.height, Config_Triple_Triad.One, 1)
      else
        contents.draw_text(0, 0, contents.width, contents.height, One, 1)
      end
    elsif $game_timer.game_triple_triad[3] == 2
      if $imported["Tidloc-Runes"]
        contents.draw_text(0, 0, contents.width, contents.height, Config_Triple_Triad.Direct, 1)
      else
        contents.draw_text(0, 0, contents.width, contents.height, Direct, 1)
      end
    elsif $game_timer.game_triple_triad[3] == 3
      if $imported["Tidloc-Runes"]
        contents.draw_text(0, 0, contents.width, contents.height, Config_Triple_Triad.All, 1)
      else
        contents.draw_text(0, 0, contents.width, contents.height, All, 1)
      end
    else
      if $imported["Tidloc-Runes"]
        contents.draw_text(0, 0, contents.width, contents.height, Config_Triple_Triad.Random, 1)
      else
        contents.draw_text(0, 0, contents.width, contents.height, Random, 1)
      end
    end
    reset_font_settings
  end
end

class Window_Equip_Discard < Window_Command
  def can_equip
    if Config_Triple_Triad::Show_only_collected
      cards = []
      Card.each_with_index{|c,i| cards.push i if $game_timer.total_cards[i] > -1}
      iindex = cards[cardlist_index]
      return false unless iindex
      num = $game_timer.total_cards[iindex]
    else
      num = $game_timer.total_cards[cardlist_index]
    end
    if num <= 0 || $game_timer.hand_deck.size == 5
      return false
    else
      return true
    end
  end
  #--------------------------------------------------------------------------
  # Checking if the card can be discarded - !!NEW!!
  #--------------------------------------------------------------------------
  def can_discard
    if Config_Triple_Triad::Show_only_collected
      cards = []
      Card.each_with_index{|c,i| cards.push i if $game_timer.total_cards[i] > -1}
      iindex = cards[cardlist_index]
      return false unless iindex
      num = $game_timer.total_cards[iindex]
    else
      num = $game_timer.total_cards[cardlist_index]
    end
    return false if num == 0
    return true
  end
end
class Decision_Triple_Triad < Scene_Base
  alias wo_tidloc_TT_create_windows create_windows
  def create_windows
    wo_tidloc_TT_create_windows
    @name_window = Window_Base.new(0,0,120,64)
    @name_window.hide.deactivate.opacity = 0
  end
  alias wo_tidloc_TT_update update
  def update
    if @start_count
#~       additional info displaying when a card was chosen:
      @rule_window.refresh true if @rule_window
    end
    if @decided
      super
      if Input.trigger?(:B) || Input.trigger?(:C) || Input.trigger?(:X)
        $game_variables[WinVariable] = @win_old
        if $game_timer.card_overflow.max > 0
          Sound.play_ok
          SceneManager.goto(Scene_Card_Overflow)
        else
          Sound.play_ok
          SceneManager.return
        end
      end
      return
    end
    wo_tidloc_TT_update
  end
  def decision1
    if @decision_window1.status == :full
      Sound.play_ok
      @start_count = true
      $game_timer.card_overflow[@npc_hand[@index]]  = 0 if $game_timer.card_overflow[@npc_hand[@index]] < 0
      $game_timer.card_overflow[@npc_hand[@index]] += 1
      index = $game_timer.npc_triple_triad[@id].index(@npc_hand[@index])
      $game_timer.npc_triple_triad[@id][index] = nil
      $game_timer.npc_triple_triad[@id].compact!
      dispose_all
      SceneManager.goto(Scene_Card_Overflow)
      return
    else
      Sound.play_ok
      @flip_npc_commands.push(@index)
      $game_timer.total_cards[@npc_hand[@index]]  = 0 if $game_timer.total_cards[@npc_hand[@index]] < 0
      $game_timer.total_cards[@npc_hand[@index]] += 1
      $game_timer.card_discovery[@npc_hand[@index]] = true
      index = $game_timer.npc_triple_triad[@id].index(@npc_hand[@index])
      $game_timer.npc_triple_triad[@id][index] = nil
      $game_timer.npc_triple_triad[@id].compact!
    end
  end
  alias wo_tidloc_TT_dispose_all dispose_all
  def dispose_all
    wo_tidloc_TT_dispose_all
    @name_window.dispose
  end
  alias wo_tidloc_TT_player_won player_won
  def player_won
    wo_tidloc_TT_player_won
    if @old_index >= 0
      @name_window.x  = @npc_pics[@old_index].x-55
      @name_window.y  = @aux_window2.y-16
      @name_window.z  = 500
      @name_window.contents.clear
      num  = $game_timer.total_cards[@npc_hand[@old_index]]
      num += $game_timer.hand_cards_check[@npc_hand[@old_index]]
      if $imported["HTML-tagging"]
        color = ""
        color = "<color=cyan>"   if num == -1
        color = "<color=yellow>" if num == 0
        text  = "#{color}#{Card[@npc_hand[@old_index]]['Name']}"
        @name_window.draw_html(4,4,112,48,text)
      else
        @name_window.change_color(Color.new(255,255,255))
        @name_window.change_color(Color.new(  0,  0,255))     if num == -1
        @name_window.change_color(Color.new(255,255,  0,192)) if num ==  0
        @name_window.draw_text(4,4,112,48,Card[@npc_hand[@old_index]]['Name'])
      end
      @name_window.show
    end
  end
end

class Scene_Triad_Album < Scene_MenuBase
  alias wo_tidloc_tt_start start
  def start
    wo_tidloc_tt_start
    @continue   = Sprite.new
    @continue.x = Graphics.width/2  - 250
    @continue.y = Graphics.height/2 - 110
    @continue.z = 1000
    if $game_timer.hand_deck.size == 5 && $triple_force_5_cards
      @continue.bitmap = Bitmap.new(500,40)
      @continue.bitmap.font.name  = "Verdana"
      @continue.bitmap.font.size += 10
      @continue.bitmap.font.color = Color.new(0,0,255)
      if $imported["HTML-tagging"]
        @continue.bitmap.draw_html(0,0,500,40,"<center>"+Config_Triple_Triad::Start_Message)
      else
        @continue.bitmap.draw_text(0,0,500,40,Config_Triple_Triad::Start_Message,1)
      end
    end
  end
  def create_windows
    xu = Hand_Card_Window[0]
    yu = Hand_Card_Window[1]
    wu = Hand_Card_Window[2]
    hu = Hand_Card_Window[3]
    @upper_window = Window_Base.new(xu, yu, wu, hu)
    @upper_window.windowskin = Cache.system(Config_Triple_Triad::Windowskin)
    @right_window = Window_Card_Description.new(@album_cards)
    @card_list = Window_Card_List.new(@album_cards)
    @no_cards_window = Window_No_Cards.new
    @statistic_window = Window_Statistics_TT.new(@album_cards)
    @upper_window.opacity = Window_Opacity
    @right_window.opacity = Window_Opacity
    @card_list.opacity = Window_Opacity
    @statistic_window.opacity = Window_Opacity
    @no_cards_window.z = 200
    @no_cards_window.opacity = 0
    if $triple_force_5_cards && 
                 $game_timer.total_cards.card_sum+$game_timer.hand_deck.size < 5
      @return_to_map = true
    else
      @no_cards_window.contents_opacity = 0
    end
#~     start alteration
    if $game_timer.hand_deck.size < 5
      @upper_window.deactivate
      @card_list.activate.index = 0
      @right_window.refresh(0) if @card_list.item_max > 0
    else
      @card_list.deactivate
    end
#~     end alteration
  end
  alias wo_tidloc_triad_update update
  def update
    super
#~     start checking if album is empty and capture an error on moving then...
    if    Config_Triple_Triad::Switch_Skip_Card &&
          $game_switches[Config_Triple_Triad::Switch_Skip_Card] &&
          $triple_force_5_cards && $game_timer.hand_deck.size == 5
      dispose_card_album
      $triple_force_5_cards = false
      SceneManager.call(Triple_Triad)
      return
    end
    if @card_list.active && @card_list.item_max == 0
      if Input.trigger?(:B)
        super
        Sound.play_cancel
        return_scene
      end
      return
    end
    if (@card_list.active || (@card_list.active == false && 
          @deci_window.active == false && @warning_window.active == false)) &&
          Input.trigger?(:X)
      if $triple_force_5_cards
        if $game_timer.hand_deck.size == 5
          dispose_card_album
          $triple_force_5_cards = false
          SceneManager.call(Triple_Triad)
          return
        else
          Sound.play_buzzer
        end
      end
    end
#~     end checking
#~       start checking if cursor is in the highest line and player hits UP:
      if @old_index < @card_list.col_max && Input.trigger?(:UP) && $game_timer.hand_deck.size > 0
        Sound.play_ok
        @upper_window.activate
        @saved_index = @card_list.index
        @card_list.deactivate.index = -1
        @right_window.refresh($game_timer.hand_deck[@index])
        return
      end
#~       end checking
    if @hand_pics[4].x >= Ani_end_x
      for n in 0...5
        @hand_pics[n].x -= (n + 1)*2
      end
      return
    end
    if @return_to_map
#~       if Input.trigger?(:B)
        Sound.play_ok
        dispose_card_album
        $triple_force_5_cards = false
        #SceneManager.goto(Scene_Map)
#~       end
      return
    end
    if @card_list.active == false && 
       @deci_window.active == false && @warning_window.active == false
      if Input.repeat?(:LEFT)
        Sound.play_cursor
        if @index < $game_timer.hand_deck.size - 1
          @index += 1 
        else
          @index = 0
        end
        if $game_timer.hand_deck != []
          @right_window.refresh($game_timer.hand_deck[@index]) 
        else
          @right_window.refresh(-1) 
        end
      end
      if Input.repeat?(:RIGHT)
        Sound.play_cursor
        if @index > 0
          @index -= 1 
        else
          @index = $game_timer.hand_deck.size - 1
        end
        if $game_timer.hand_deck != []
          @right_window.refresh($game_timer.hand_deck[@index]) 
        else
          @right_window.refresh(-1) 
        end
      end
      if Input.trigger?(:DOWN) 
        Sound.play_ok
        @card_list.active = true
#~         setting the saved index if index is deactivated:
        @card_list.index = @saved_index  if @card_list.index == -1 && @saved_index
#~         additional setting the index if it was deactivated:
        @card_list.index = 0 if @card_list.index == -1 && @card_list.item_max > 0
        @right_window.refresh(@old_index)
      end
      if Input.trigger?(:C)
        if $game_timer.hand_lock.include?($game_timer.hand_deck[@index]) ||
          $game_timer.hand_deck.size <= 0 || $game_timer.hand_deck[@index].nil?
          Sound.play_buzzer
        else
          Sound.play_ok
          $game_timer.total_cards[$game_timer.hand_deck[@index]] += 1
          $game_timer.hand_cards_check[$game_timer.hand_deck[@index]] -= 1
          $game_timer.hand_deck[@index] = nil
          $game_timer.hand_deck.compact!
          @card_list.refresh
          @index -= 1 if @index == $game_timer.hand_deck.size
          if $game_timer.hand_deck != []
            @right_window.refresh($game_timer.hand_deck[@index]) 
          else
            @right_window.refresh(-1) 
          end
        end
      end
      if Input.trigger?(:B)
#~         updating the input, so that no ESC-command gets stuck:
        super
        if $triple_force_5_cards
          if $game_timer.hand_deck.size == 5
            dispose_card_album
            $triple_force_5_cards = false
            SceneManager.call(Triple_Triad)
            return
          else
            Sound.play_buzzer
          end
        else
          Sound.play_cancel
          dispose_card_album
          return
        end
      end
      for n in 0...$game_timer.hand_deck.size
        if n == @index 
          @hand_pics[n].y -= 1 if @hand_pics[n].y >= Album_y - 10
          @cursor.x += Card_Distance.abs/Album_Cursor_Speed if (@hand_pics[n].x + Cursor_album_x) > @cursor.x
          @cursor.x -= Card_Distance.abs/Album_Cursor_Speed if (@hand_pics[n].x + Cursor_album_x) < @cursor.x
  #~         @cursor.x += (@hand_pics[n].x + Cursor_album_x - @cursor.x).abs/10 if (@hand_pics[n].x + Cursor_album_x) > @cursor.x
  #~         @cursor.x -= (@hand_pics[n].x + Cursor_album_x - @cursor.x).abs/10 if (@hand_pics[n].x + Cursor_album_x) < @cursor.x
          @cursor.x = (@hand_pics[n].x + Cursor_album_x) if ((@cursor.x - Cursor_album_x) - @hand_pics[n].x).abs < (@hand_pics[n].x + Cursor_album_x - @cursor.x).abs/Album_Cursor_Speed
        else
          @hand_pics[n].y += 1 if @hand_pics[n].y < Album_y
        end
      end
    end
    if @hand_old_size != $game_timer.hand_deck.size
      @hand_old_size = $game_timer.hand_deck.size
      for n in 0...5
        if $game_timer.hand_deck[n].is_a?(Integer)
          @hand_pics[n].bitmap = Cache.triple_triad_card(Card[$game_timer.hand_deck[n]]['Image']+Config_Triple_Triad::Player1Marker)
          TT_Utils.paint_card(@hand_pics[n].bitmap, $game_timer.hand_deck[n])
        else
          @hand_pics[n].bitmap = Cache.triple_triad_card("")
        end
      end
    end
    if @card_list.active
      if @old_index != @card_list.index
        @old_index = @card_list.index
#~         start alteration
        if Config_Triple_Triad::Show_only_collected
          cards = []
          Card.each_with_index{|c,i| cards.push i if $game_timer.total_cards[i] > -1}
          @right_window.refresh(cards[@old_index])
        else
          @right_window.refresh(@old_index)
        end
#~         end alteration
      end
      @right_window.refresh(@old_index) if @old_index != @card_list.index
#~       start if hitting ESC on the itemlist, return scene:
      if Input.trigger?(:B)
        super
        $game_variables[WinVariable] = -1
        dispose_card_album
        Sound.play_cancel
      end
#~       end ESC
      if Input.trigger?(:C)
#~         start alteration
        if Config_Triple_Triad::Show_only_collected
          cards = []
          Card.each_with_index{|c,i| cards.push i if $game_timer.total_cards[i] > -1}
          iindex = cards[@old_index]
          num = $game_timer.total_cards[iindex]
        else
          num = $game_timer.total_cards[@old_index]
        end
#~         end alteration
#~         also checking if it's still initialized:
        if num <= 0
          Sound.play_buzzer
        else
          Sound.play_ok
          @deci_window.cardlist_index = @old_index
          @deci_window.refresh
          @card_list.active = false
          @deci_window.select(0)
          @deci_window.activate
        end
      end
    end
    if $game_timer.hand_deck.size < 5 && @continue.bitmap
      @continue.bitmap.dispose
    end
  end
  def equip_card
    Equip_SE.play
#~     start alteration
    if Config_Triple_Triad::Show_only_collected
      cards = []
      Card.each_with_index{|c,i| cards.push i if $game_timer.total_cards[i] > -1}
      iindex = cards[@old_index]
      if iindex.nil? || $game_timer.total_cards[iindex].nil?
        Sound.play_buzzer
        @deci_window.deactivate
        @card_list.activate
        return
      end
      $game_timer.total_cards[iindex] -= 1
      $game_timer.hand_cards_check[iindex] += 1
      $game_timer.hand_deck.push(iindex)
      @right_window.refresh(iindex)
    else      
      $game_timer.total_cards[@old_index] -= 1
      $game_timer.hand_cards_check[@old_index] += 1
      $game_timer.hand_deck.push(@old_index)
      @right_window.refresh(@old_index)
    end
#~     end alteration
#~     start changing to duel, if the fifth card gets chosen:
    if $game_timer.hand_deck.size == 5
      if $triple_force_5_cards && Config_Triple_Triad::Change_direct_to_duel
        $triple_force_5_cards = false
        SceneManager.call(Triple_Triad)
        return
      elsif $triple_force_5_cards
        @continue.bitmap = Bitmap.new(500,40)
        @continue.bitmap.font.name  = "Verdana"
        @continue.bitmap.font.size += 10
        @continue.bitmap.font.color = Color.new(0,0,255)
        if $imported["HTML-tagging"]
          @continue.bitmap.draw_html(0,0,500,40,"<center>"+Config_Triple_Triad::Start_Message)
        else
          @continue.bitmap.draw_text(0,0,500,40,Config_Triple_Triad::Start_Message,1)
        end
      end
    end
#~     end changing
    @card_list.refresh
    @statistic_window.refresh
    @deci_window.deactivate
    @card_list.activate
  end
  def terminate
    super
    @hand_pics.each{|p| p.dispose}
    @cursor.dispose
    @background_image.dispose
    @continue.dispose
  end
end

class Triple_Triad < Scene_Base
  def load_rules
#~     if switch is set to -1, showing rules:
    if Config_Triple_Triad::SwitchShowRules==-1 || $game_switches[Config_Triple_Triad::SwitchShowRules] == true || Config_Triple_Triad::SwitchShowRules == 0
      @rules = Triple_Triad_Rules.new
      @rules.x = Graphics.width/2 - @rules.width/2
      @rules.y = Graphics.height/2 - @rules.height/2
    end
  end
  def update
    super
    update_window
#~     if switch is set to -1, handling rules:
    if Config_Triple_Triad::SwitchShowRules == -1 || $game_switches[Config_Triple_Triad::SwitchShowRules] == true || Config_Triple_Triad::SwitchShowRules == 0
      return if @phase == 2 && @rules.opacity == 255
    end
    flip_npc_cards unless @flip_npc_commands
    update_texts unless @text_array.empty?
    update_turn_pics
    case @phase
    when 0
      update_opacity
    when 1
      update_draw
    when 2
      update_choose_player
    when 3
      update_cursor_hand
    when 4
      update_cursor_board
    when 5
      update_play
    when 6
      update_flip_play
    when 7
      update_results  
    when 8
      dispose_all_cards
    end
  end
  def update_window
    if @phase == 2
#~     if switch is set to -1, handling rules:
      if Config_Triple_Triad::SwitchShowRules == -1 || $game_switches[Config_Triple_Triad::SwitchShowRules] == true || Config_Triple_Triad::SwitchShowRules == 0
        if Input.trigger?(:B) || Input.trigger?(:C)
          RPG::BGM.new(@battle_info[0]).play unless @battle_info[0].nil?
          @rules.opacity = 0
          @rules.contents_opacity = 0
        end
      else
        RPG::BGM.new(@battle_info[0]).play unless @battle_info[0].nil?
      end
    end
    if @phase >= 3
#~     if switch is set to -1, handling rules:
      if Config_Triple_Triad::SwitchShowRules == -1 || $game_switches[Config_Triple_Triad::SwitchShowRules] == true || Config_Triple_Triad::SwitchShowRules == 0
        if Input.press?(Button)
          @rules.opacity = 255
          @rules.contents_opacity = 255
        else
          @rules.opacity = 0
          @rules.contents_opacity = 0
        end
      end
    end
  end
end

class Game_Timer
  alias :wo_tidloc_gt_initialize :initialize
  def initialize(*args, &block)
    wo_tidloc_gt_initialize(*args, &block)
#~     initializing at -1 instead of 0:
    @total_cards = Array.new(Config_Triple_Triad::Card.size, -1)
  end
  def total_cards_owned
    return hand_deck.size + total_cards.card_sum
  end
end

class Game_Interpreter
  def gain_triad_card(id, num)
    old_total = $game_timer.total_cards[id]
    old_disc = $game_timer.card_discovery[id]
#~     start checking if card is still initialized:
    $game_timer.total_cards[id]  = 0 if $game_timer.total_cards[id] < 0 && num > 0
    return if $game_timer.total_cards[id] < 0 && num <= 0
#~     end checking
    if Config_Triple_Triad::Max_Cards_Types != 0 && Config_Triple_Triad::Max_Cards != 0
      num.abs.times do
        if num > 0
          if $game_timer.total_cards_owned < Config_Triple_Triad::Max_Cards && 
            ($game_timer.total_cards[id] + $game_timer.hand_cards_check[id]) < Config_Triple_Triad::Max_Cards_Types
            $game_timer.total_cards[id] += 1
            $game_timer.card_discovery[id] = true if num > 0
          else
            $game_timer.card_overflow[id] += 1
          end
        else
          $game_timer.total_cards[id] -= 1
          $game_timer.total_cards[id] = 0 if $game_timer.total_cards[id] < 0
        end
      end
      if $game_timer.total_cards_owned < Config_Triple_Triad::Max_Cards && 
        ($game_timer.total_cards[id] + $game_timer.hand_cards_check[id]) < Config_Triple_Triad::Max_Cards_Types
        SceneManager.scene.card_triad_popup(id, num, old_total, old_disc) if num > 0 && SceneManager.scene_is?(Scene_Map)
      end
    else
      num.abs.times do
        if num > 0
          $game_timer.total_cards[id] += 1
        else
          $game_timer.total_cards[id] -= 1
        end
        $game_timer.total_cards[id] = 0 if $game_timer.total_cards[id] < 0
        $game_timer.card_discovery[id] = true if num > 0
      end
      SceneManager.scene.card_triad_popup(id, num, old_total, old_disc) if num > 0 && SceneManager.scene_is?(Scene_Map)
    end
    if $game_timer.card_overflow.max > 0 && $game_timer.overflow_flag == false
      Sound.play_buzzer
      $game_timer.overflow_flag = true
      $game_system.menu_disabled = true
      SceneManager.scene.card_overflow_popup 
    end
  end
  def total_triad_cards
    a = $game_timer.hand_deck.size
    a += $game_timer.total_cards.dup.card_sum
    return a
  end
  def booster_special(id,family=nil,special=nil)
    booster = Config_Triple_Triad::Booster[id]
    for n in 0...booster['Number']
      rarity = booster['Rarity']
      chance = booster['Chance'].sum
      chance = rand(chance)
      for n in 0...booster['Chance'].size
        if chance < booster['Chance'][n]
          rar = n
          break
        end
        chance -= booster['Chance'][n]
      end
      card_array = []
      for n in 0...Config_Triple_Triad::Card.size
        if booster['Element'] > 0
          card_array.push(n) if Config_Triple_Triad::Card[n]['Rarity'] == booster['Rarity'][rar] && Config_Triple_Triad::Card[n]['Element'] == booster['Element']
        else
          card_array.push(n) if Config_Triple_Triad::Card[n]['Rarity'] == booster['Rarity'][rar]
        end
      end
      booster['Rarity'][rar]
      if family || special
        card_array = card_array.find_all{|c| c['Family']==family} if family
        card_array = card_array.find_all{|c| c['Special']==special} if special
      end
      gain_triad_card(card_array.shuffle.first, 1)
    end
  end
end

class Array
  def card_sum
    a = 0
    for n in 0...size
      a += [self[n],0].max
    end
    a
  end
end

#~    new procedures:
module TT;class<<self
  def booster(id)
    cards = []
    booster = Config_Triple_Triad::Booster[id]
    for n in 0...booster['Number']
      rarity = booster['Rarity']
      chance = booster['Chance'].sum
      chance = rand(chance)
      for n in 0...booster['Chance'].size
        if chance < booster['Chance'][n]
          rar = n
          break
        end
        chance -= booster['Chance'][n]
      end
      card_array = []
      for n in 0...Config_Triple_Triad::Card.size
        card_array.push(n) if Config_Triple_Triad::Card[n]['Rarity'] == booster['Rarity'][rar]
      end
      booster['Rarity'][rar]
      cards.push card_array.shuffle.first
    end
    gain_triad_cards(cards, 1)
  end
  def booster_special(id,family=nil,special=nil)
    booster = Config_Triple_Triad::Booster[id]
    cards   = []
    for n in 0...booster['Number']
      rarity = booster['Rarity']
      chance = booster['Chance'].sum
      chance = rand(chance)
      for n in 0...booster['Chance'].size
        if chance < booster['Chance'][n]
          rar = n
          break
        end
        chance -= booster['Chance'][n]
      end
      card_array = []
      for n in 0...Config_Triple_Triad::Card.size
        if booster['Element'] > 0
          card_array.push(n) if Config_Triple_Triad::Card[n]['Rarity'] == booster['Rarity'][rar] && Config_Triple_Triad::Card[n]['Element'] == booster['Element']
        else
          card_array.push(n) if Config_Triple_Triad::Card[n]['Rarity'] == booster['Rarity'][rar]
        end
      end
      booster['Rarity'][rar]
      card_array = card_array.find_all{|c| Config_Triple_Triad::Card[c]['Family']==family}   if family
      card_array = card_array.find_all{|c| Config_Triple_Triad::Card[c]['Special']==special} if special && card_array
      unless card_array
        msgbox "booster cracked does not contain cards by the given family/special definition!"
        exit
      end
      cards.push card_array.shuffle.first if card_array
    end
    gain_triad_cards(cards, 1)
  end
  def gain_triad_cards(ids, num)
    if $imported["Tidloc-MessageWindow"]
      text = ""
      ids.compact.each_with_index{|id,i|
        text += ",\100" if i > 0
        if $game_timer.total_cards[id]==-1
          color = "<color=cyan>"
        elsif $game_timer.total_cards[id]==0
          color = "<color=yellow>"
        else
          color = ""
        end
        $game_timer.total_cards[id]  = 0 if $game_timer.total_cards[id] < 0
        $game_timer.total_cards[id] += num
        text += "#{color}#{Bitmap.html_decode(Config_Triple_Triad::Card[id]['Name'])}</color>"
        $game_timer.card_discovery[id] = true if num > 0
      }
      if $imported["Tidloc-Runes"]
        text  = Config_Triple_Triad.Pre_Name + text
        text += Config_Triple_Triad.Post_Name
      else
        text  = Config_Triple_Triad::Pre_Name + text
        text += Config_Triple_Triad::Pos_Name
      end
      Tidloc.exe(text,:SmallText) 
    else
      ids.compact.each{|c|
        gain_triad_card c,1
      }
    end
  end
  def gain_triad_card(id, num)
    old_total = $game_timer.total_cards[id]
    old_disc = $game_timer.card_discovery[id]
    if Config_Triple_Triad::Max_Cards_Types != 0 && Config_Triple_Triad::Max_Cards != 0
      num.abs.times do
        if num > 0
          $game_timer.total_cards[id]  = 0 if $game_timer.total_cards[id] < 0
          if $game_timer.total_cards_owned < Config_Triple_Triad::Max_Cards && 
            ($game_timer.total_cards[id] + $game_timer.hand_cards_check[id]) < Config_Triple_Triad::Max_Cards_Types
            $game_timer.total_cards[id] += 1
            $game_timer.card_discovery[id] = true if num > 0
          else
            $game_timer.card_overflow[id] += 1
          end
        else
          $game_timer.total_cards[id] -= 1
          $game_timer.total_cards[id] = 0 if $game_timer.total_cards[id] < 0
        end
      end
      if $game_timer.total_cards_owned < Config_Triple_Triad::Max_Cards && 
        ($game_timer.total_cards[id] + $game_timer.hand_cards_check[id]) < Config_Triple_Triad::Max_Cards_Types
        SceneManager.scene.card_triad_popup(id, num, old_total, old_disc) if num > 0 && SceneManager.scene_is?(Scene_Map)
      end
    else
      num.abs.times do
        if num > 0
          $game_timer.total_cards[id] += 1
        else
          $game_timer.total_cards[id] -= 1
        end
        $game_timer.total_cards[id] = 0 if $game_timer.total_cards[id] < 0
        $game_timer.card_discovery[id] = true if num > 0
      end
      SceneManager.scene.card_triad_popup(id, num, old_total, old_disc) if num > 0 && SceneManager.scene_is?(Scene_Map)
    end
    if $game_timer.card_overflow.max > 0 && $game_timer.overflow_flag == false
      Sound.play_buzzer
      $game_timer.overflow_flag = true
      $game_system.menu_disabled = true
      SceneManager.scene.card_overflow_popup 
    end
  end
  def cards_num
    a = $game_timer.hand_deck.size
    a += $game_timer.total_cards.dup.card_sum
    return a
  end
  def cards_uni
    a = $game_timer.total_cards.dup
    if $game_timer.hand_deck.size > 0
      for n in 0...$game_timer.hand_deck.size 
        a[$game_timer.hand_deck[n]] += 1
      end
    end
    a.delete(0)
    return a.size
  end
end;end