
$imported = {} if $imported.nil?
$imported["Tidloc-ArmorData"] = [1,1,0]
$needed = [] if $needed.nil?
$needed.push ["Tidloc-Header",[2,11,2],true,"Tidloc-ArmorData"]

class RPG::Armor
  alias wo_tidloc_name name
  def name
    temp = Tidloc::Header::ArmorData(self.id)[:name][$tidloc_language]
    return temp if temp
    return wo_tidloc_name
  end
  def dataname
    wo_tidloc_name
  end
  def name_html
    text = "{eval= "
    Tidloc::Languages.each{|l|
      text += "if $tidloc_language==\"#{l}\";"
      temp = Tidloc::Header::ArmorData(self.id)[:name][l]
      if temp
        text += "\"#{temp}\";els"
      else
        text += "\"#{wo_tidloc_name}\";els"
      end
    }
    text += "e;\"#{wo_tidloc_name}\";end}"
    return text
  end
  alias wo_tidloc_description description
  def description
    temp = Tidloc::Header::ArmorData(self.id)[:desc][$tidloc_language]
    return temp if temp
    return wo_tidloc_description
  end
  def datadescription
    wo_tidloc_description
  end
  def commands
    Tidloc::Header::ArmorData(self.id)[:commands]
  end
  def execute_commands(tag)
    self.commands.each {|x| x[0]==tag ? eval(Tidloc.exe(x[1],x[2])) : ""}
  end
end

module Tidloc;module Header;class<<self;def ArmorData(item_id)
  name    = {"Def" => $data_armors[item_id].dataname}
  desc    = {"Def" => $data_armors[item_id].datadescription}
  command = []
  case item_id
  when 1 # Necklace
    name["ger"] = "Halskette"
    name["eng"] = "Necklace"
    desc["ger"] = "einfache Halskette, erhöht LP"
    desc["eng"] = "simple Necklace, boosts HP"
  when 2 # Leather boots
    name["ger"] = "Lederstiefel"
    name["eng"] = "Leather Boots"
    command.push ["TurnStart","actor = $game_temp.tidloc[:actor];
                          temp = [[1,actor.hp-1].min,0].max;
                          actor.hp -= temp;
                          actor.create_popup(-temp,\"HP_DMG\") if temp > 0"]
    #desc["ger"] = "einfache Lederstiefel<br>sie schmerzen beim Gehen"
    #desc["eng"] = "Simple leather boots<br>they aren't exactly comfortable."
    command.push ["Use","item = $game_temp.tidloc[:item];
                         $game_temp.tidloc[:target].die;
                         item.commands.push [\"UnUse\",\"false\"];
                         ","Friend"]
  end
  return {:name     => name,
          :commands => command,
          :desc     => desc
         }
end;end;end;end