################################################################################
#  Dynamic Shop System   v. 2.5                                                #
#     by the request of Gnarizard                                              #
#          (http://rmrk.net/index.php/topic,32876.0.html)                      #
#         by Tidloc                                  (Jun-23-17)               #
#------------------------------------------------------------------------------#
#  This shop enables the following features:                                   #
#   -> Stocks items in Quantities                                              #
#   -> randomly gaining or loosing stock as time passes                        #
#   -> Occasionally stocking a bonus (substantially more rare) item for sale   #
#   -> Items you sell become their stock                                       #
#------------------------------------------------------------------------------#
#  simply use the normal shop command of the Events to use this custom shop.   #
#  before entering you should set the shop-number via the script command:      #
#     Tidloc.exe *shop-id*,:ShopNum                                            #
#  where *shop-id* should be replaced with the specific shop id you are about  #
#     Tidloc.exe *shop-lvl*,:ShopLVL                                           #
#  to set a shop lvl if you use my Custom Equipments.                          #
#     Tidloc.exe *x*,:ShopBoost                                                #
#  when the shop gets initialized, the items in stock get additional stock     #
#  between 0 and *x* for sale. (optional)                                      #
#------------------------------------------------------------------------------#
#  Epic Items can be granted to shops. These Items appear as special items,    #
#  but are only once in stock and won't stock again.                           #
#------------------------------------------------------------------------------#
#  Describing the defined constants:                                           #
#          MAXGAIN ... Maximum gain every timestep [item,weap,armor]           #
#          TIMESTEP .. Minutes that have to pass to gain/loose stock           #
#                      in ths shops                                            #
#          MINSTART .. Minimum start quantity of a single item                 #
#          MAXSTART .. Maximum start quantity of a single item                 #
#          ZERO ...... this boolean constant define wheter items with          #
#                      no cost shall be displayed.                             #
#          PROP ...... how high is the propability of getting a high           #
#                      value item (out of 10'000)                              #
#          CALCTIME .. bonus item calculation everytime the itemgain is        #
#                      calculatated                                            #
#          CALCCALL .. bonus item calculation everytime the specific           #
#                      shop is called                                          #
#          SPECIALS .. set in a set of 3 variables: [a,b,c}                    #
#                      a ... 1=item, 2=weapon, 3=armor                         #
#                      b ... ingame item-id                                    #
#                      c ... an array of in which shops it shall be            #
#                            available                                         #
#          EPIC ...... same as SPECIALS above, just that only one shop         #
#                      may be entered in c.                                    #
#------------------------------------------------------------------------------#
#  To recalculate the actual amount of items in stock you can use the constant #
#  TIMESTEP or set it to false and only do it on call with the script command: #
#    Scene_Shop.process                                                        #
################################################################################
# As requested by Mr_Wiggles this script now differs normal items, weapons and #
#  armors.                                                                     #
#  Simply with the MAXGAIN, MINSTART and MAXSTART use the following syntax:    #
#  ... = [item, weapon, armor]                                                 #
################################################################################
# You may us this script in any of your games,                                 #
#              but please credit me for this hell of work ^^                   #
################################################################################

$imported = {} if $imported.nil?
$imported["Tidloc-D-Shop"] = [2,5,0]

module Tidloc
 
  module D_Shop
    SHOPVAR  = 2
    MAXGAIN  = [5,2,2]
    TIMESTEP = 1
    MINSTART = [5,1,1]
    MAXSTART = [20,4,4]
    ZERO     = true
    PROP     = 1000
    CALCTIME = true
    CALCCALL = false
    SPECIALS = [ [ 0, 7,[2]],
                 [ 1, 2,[2]] ]
    EPIC     = [ [ 0, 6, 2] ]
  end
                   
  module Vocabs;class<<self
    def D_Shop(code,lang)
      if    lang == "ger"
        case code
        when "vocab"; return ["Kaufen",
                              "Verkaufen",
                              "Sonderangebote",
                              "Fertig"]
        end
      elsif lang == "eng"
        case code
        when "vocab"; return ["Regular Items",
                              "Sell Items",
                              "Special Offers",
                              "Leave"]
        end
      elsif lang == "ptbr"
        case code
        when "vocab"; return ["Comprar",
                              "Vender",
                              "Ofertas Especiais",
                              "Sair"]
        end
      end
    end
  end;end
################################################################################
#                                                                              #
################################################################################
module D_Shop
class Sell_Base < Game_BaseItem
  attr_accessor :amount
  attr_accessor :max_amount
  attr_accessor :can_raise
  attr_accessor :base_stock
  attr_accessor :item
  
  def initialize
    super
    self.amount     = 1
    self.max_amount = 0
    self.can_raise  = true
    self.base_stock = false
  end
  
      def id;          self.item.id;          end
      def class;       self.item.class;       end
      def icon_index;  self.item.icon_index;  end
      def note;        self.item.note;        end
      def etype_id;    self.item.etype_id;    end
      def features;    self.item.features;    end
      def wtype_id;    self.item.wtype_id;    end
      def atype_id;    self.item.atype_id;    end
      def damage;      self.item.damage;      end
      def performance; self.item.performance; end
      def key_item?;   self.item.key_item?;   end
      def price;       self.item.price;       end
      def name;        self.item.name;        end
      def params;      self.item.params;      end
      def description; self.item.description; end
      def max_limit;   self.item.max_limit;   end
      def elemental_rate(id); self.item.elemental_rate(id); end
      def is_weapon?;  false;                 end
      def is_armor?;   false;                 end
  
  
  def nid;
    if self.item.is_a?(Tidloc::CustomEquip::Weapon) || self.item.is_a?(Tidloc::CustomEquip::Armor)
      self.item.nid
    else
      -1
    end
  end
  def proceed_stock
    temp = 0
    if object.is_a?(RPG::Item) && !item.key_item?
      temp = (Tidloc::D_Shop::MAXGAIN[0]*(rand(2)-1)).round
    elsif $imported["Tidloc-CustomEquip"] && object.is_a?(Tidloc::CustomEquip::Base)
      if rand(10000) < (Tidloc::D_Shop::PROP+30*object.item_lvl)
        temp = -1
      end
    elsif object.is_a?(RPG::Weapon)
      temp = rand(Tidloc::D_Shop::MAXGAIN[1]*2)-Tidloc::D_Shop::MAXGAIN[1]
    elsif object.is_a?(RPG::Armor)
      temp = rand(Tidloc::D_Shop::MAXGAIN[2]*2)-Tidloc::D_Shop::MAXGAIN[2]
    end
    temp = 0 unless temp < 0 || can_raise
    self.amount = [[self.amount+temp,0].max,self.max_amount].min
    self.object = nil if self.amount == 0 && !self.base_stock
  end
end
          class Sell_Item < Sell_Base
            def initialize(item)
              super()
              if item.is_a?(Integer)
                self.item = $data_items[item] 
              else
                self.item = item
              end
              self.amount  = Tidloc::D_Shop::MINSTART[0]
              self.amount += rand(Tidloc::D_Shop::MAXSTART[0] - Tidloc::D_Shop::MINSTART[0])
              self.amount += rand($tidloc_shopnum[2]) if $tidloc_shopnum[2].is_a?(Integer)
            end
          end
          class Sell_Weapon < Sell_Base
            def initialize(item)
              super()
              if    item.is_a?(Integer)
                self.item = $data_weapons[item]
              elsif item.is_a?(RPG::Weapon) || 
                    ($imported["Tidloc-CustomEquip"] && item.is_a?(Tidloc::CustomEquip::Weapon))
                self.item = item
              end
              if self.item.is_a?(RPG::Weapon)
                self.amount  = Tidloc::D_Shop::MINSTART[1]
                self.amount += rand(Tidloc::D_Shop::MAXSTART[1] - Tidloc::D_Shop::MINSTART[1])
                self.amount += rand($tidloc_shopnum[2]) if $tidloc_shopnum[2].is_a?(Integer)
              else
                self.amount = 1
              end
            end
            def is_weapon?; true; end
          end
          class Sell_Armor < Sell_Base
            def initialize(item)
              super()
              if item.is_a?(Integer)
                self.item = $data_armors[item]
              elsif item.is_a?(RPG::Armor) || 
                    ($imported["Tidloc-CustomEquip"] && item.is_a?(Tidloc::CustomEquip::Armor))
                self.item = item
              end
              if self.item.is_a?(RPG::Armor)
                self.amount  = Tidloc::D_Shop::MINSTART[2]
                self.amount += rand(Tidloc::D_Shop::MAXSTART[2] - Tidloc::D_Shop::MINSTART[2])
                self.amount += rand($tidloc_shopnum[2]) if $tidloc_shopnum[2].is_a?(Integer)
              else
                self.amount = 1
              end
            end
            def is_armor?; true; end
          end
class Shop
  attr_accessor :_id
  attr_accessor :items
  attr_accessor :epic
  def initialize(id)
    self._id   = id
    self.items = []
    self.epic  = []
  end
  def clean_up
    self.items.delete_if{|x| x.item.nil?}
    self.epic.delete_if{|x|  x.item.nil?}
  end
end
end;end

#---------------Scene_Shop
class Scene_Shop < Scene_MenuBase
  def prepare(goods, purchase_only)
    @goods = goods
    @purchase_only = purchase_only
    if $tidloc_shopnum.nil? || $tidloc_shopnum[0].nil? || $tidloc_shopnum[1].nil?
      msgbox "The Dynamic shop was not setup for this shop\n"+
             "you tried to attend! Contact the developer."
      return_scene
      return
    end
    @shopnum = $tidloc_shopnum[0]
    @shoplvl = $tidloc_shopnum[1] ? $tidloc_shopnum[1] : 0
    Tidloc::Ench_lvl(@shoplvl)   if $imported["Tidloc-DiabloEquip"]
    Tidloc::Socket_lvl(@shoplvl) if $imported["Tidloc-SocketEquip"]
    @shop = false
    for i in 0...$game_system.tidloc_dshop.size
      @shop = true if $game_system.tidloc_dshop[i]._id == @shopnum
    end
    if !@shop
      $game_system.tidloc_dshop.push Tidloc::D_Shop::Shop.new @shopnum
      @shop = $game_system.tidloc_dshop.last
      @goods.each{|x|
        case x[0]
        when 0;  item = $data_items[x[1]]
          @shop.items.push Tidloc::D_Shop::Sell_Item.new item.id
        when 1;  item = $data_weapons[x[1]]
          if $imported["Tidloc-CustomEquip"] && @shoplvl > 0
            item = Tidloc::CustomEquip::Weapon.new item
            @shop.items.push Tidloc::D_Shop::Sell_Weapon.new item
          else
            @shop.items.push Tidloc::D_Shop::Sell_Weapon.new item.id
          end
        when 2;  item = $data_armors[x[1]]
          if $imported["Tidloc-CustomEquip"] && @shoplvl > 0
            item = Tidloc::CustomEquip::Armor.new item
            @shop.items.push Tidloc::D_Shop::Sell_Armor.new item
          else
            @shop.items.push Tidloc::D_Shop::Sell_Armor.new item.id
          end
        end
        @shop.items.last.base_stock = true
      }
      Tidloc::D_Shop::EPIC.each{|x|
        if x[2] == @shopnum
          case x[0]
          when 0;  item = $data_items[x[1]]
            @shop.epic.push Tidloc::D_Shop::Sell_Item.new item.id
          when 1;  item = $data_weapons[x[1]]
            if $imported["Tidloc-CustomEquip"] && @shoplvl > 0
              item = Tidloc::CustomEquip::Weapon.new item
              @shop.epic.push Tidloc::D_Shop::Sell_Weapon.new item
            else
              @shop.epic.push Tidloc::D_Shop::Sell_Weapon.new item.id
            end
          when 2;  item = $data_armors[x[1]]
            if $imported["Tidloc-CustomEquip"] && @shoplvl > 0
              item = Tidloc::CustomEquip::Armor.new item
              @shop.epic.push Tidloc::D_Shop::Sell_Armor.new item
            else
              @shop.epic.push Tidloc::D_Shop::Sell_Armor.new item.id
            end
          end
        end
      }
    else
      @shop = $game_system.tidloc_dshop.find{|x| x._id==@shopnum}
      @goods.each{|x|
        case x[0]
        when 0;  item = $data_items[x[1]];   
        when 1;  item = $data_weapons[x[1]];
        when 2;  item = $data_armors[x[1]];
        end
        unless @shop.items.find{|y| ((y.item == item) ||
          (item.is_a?(RPG::EquipItem) && y.item.item == item)) && y.base_stock}          
          case x[0]
          when 0;  item = $data_items[x[1]]
            @shop.items.push Tidloc::D_Shop::Sell_Item.new item.id
          when 1;  item = $data_weapons[x[1]]
            if $imported["Tidloc-CustomEquip"] && @shoplvl > 0
              item = Tidloc::CustomEquip::Weapon.new item
              @shop.items.push Tidloc::D_Shop::Sell_Weapon.new item
            else
              @shop.items.push Tidloc::D_Shop::Sell_Weapon.new item.id
            end
          when 2;  item = $data_armors[x[1]]
            if $imported["Tidloc-CustomEquip"] && @shoplvl > 0
              item = Tidloc::CustomEquip::Armor.new item
              @shop.items.push Tidloc::D_Shop::Sell_Armor.new item
            else
              @shop.items.push Tidloc::D_Shop::Sell_Armor.new item.id
            end
          end
          @shop.items.last.base_stock = true
        end
      }
    end
    if Tidloc::D_Shop::CALCCALL
      if rand(10000) < Tidloc::D_Shop::PROP
        temp = []
        a=0
        for x in Tidloc::D_Shop::SPECIALS
          for y in x[2]
            temp.push [x[0],x[1]]if y == @shop._id
          end
        end
        if temp.size > 0
          t = rand(temp.length)
          case temp[t][0]
          when 0;  item = $data_items[temp[t][1]];   
          when 1;  item = $data_weapons[temp[t][1]];
          when 2;  item = $data_armors[temp[t][1]];
          end
          unless @shop.items.find{|y| ((y.item == item) ||
            (item.is_a?(RPG::EquipItem) && y.item.item == item)) && y.base_stock}          
            case x[0]
            when 0;  item = $data_items[x[1]]
              @shop.items.push Tidloc::D_Shop::Sell_Item.new item.id
            when 1;  item = $data_weapons[x[1]]
              if $imported["Tidloc-CustomEquip"] && @shoplvl > 0
                item = Tidloc::CustomEquip::Weapon.new item
                @shop.items.push Tidloc::D_Shop::Sell_Weapon.new item
              else
                @shop.items.push Tidloc::D_Shop::Sell_Weapon.new item.id
              end
            when 2;  item = $data_armors[x[1]]
              if $imported["Tidloc-CustomEquip"] && @shoplvl > 0
                item = Tidloc::CustomEquip::Armor.new item
                @shop.items.push Tidloc::D_Shop::Sell_Armor.new item
              else
                @shop.items.push Tidloc::D_Shop::Sell_Armor.new item.id
              end
            end
          end
        end
      end
    end
  end
  
  alias wo_dshop_start start
  def start
    wo_dshop_start
    create_special_window
#~     @number_window.width = @buy_window.width
  end
  
  def create_buy_window
    @buy_window = Tidloc::D_Shop::Window_ShopBuy_2.new(@shopnum)
    @buy_window.viewport = @viewport
    @buy_window.help_window = @help_window
    @buy_window.status_window = @status_window
    @buy_window.hide
    @buy_window.set_handler(:ok,     method(:on_buy_ok))
    @buy_window.set_handler(:cancel, method(:on_buy_cancel))
  end
  def create_special_window
    @special_window = Tidloc::D_Shop::Window_ShopBuy_2.new(@shopnum, true)
    @special_window.viewport = @viewport
    @special_window.help_window = @help_window
    @special_window.status_window = @status_window
    @special_window.hide
    @special_window.set_handler(:ok,     method(:on_special_ok))
    @special_window.set_handler(:cancel, method(:on_special_cancel))
  end
  alias wo_dshop_status create_status_window
  def create_status_window
    if $imported["Tidloc-CustomEquip"] && Tidloc::CustomEquip::Use_New_Info_shop
      wx = Graphics.width/2+50
      wy = @dummy_window.y
      ww = Graphics.width/2 - 50
      wh = @dummy_window.height
      @status_window = Tidloc::CustomEquip::Window_ShopStatus2.new wx,wy,ww,wh
      @status_window.viewport = @viewport
      @status_window.hide
    else
      wo_dshop_status
    end
  end
  alias wo_tidloc_mun_win create_number_window
  def create_number_window
    if $imported["Tidloc-CustomEquip"] && Tidloc::CustomEquip::Use_New_Info_shop
      wy = @dummy_window.y
      wh = @dummy_window.height
      @number_window = Tidloc::D_Shop::Window_ShopNumber_2.new(0, wy, wh)
      @number_window.viewport = @viewport
      @number_window.hide
      @number_window.set_handler(:ok,     method(:on_number_ok))
      @number_window.set_handler(:cancel, method(:on_number_cancel))
    else
      wo_tidloc_mun_win
    end
  end
  def create_command_window
    @command_window = Tidloc::D_Shop::Window_ShopCommand_2.new(@gold_window.x, @purchase_only)
    @command_window.viewport = @viewport
    @command_window.y = @help_window.height
    @command_window.set_handler(:buy,    method(:command_buy))
    @command_window.set_handler(:sell,   method(:command_sell))
    @command_window.set_handler(:cancel, method(:return_scene))
    @command_window.set_handler(:special, method(:command_special))
  end
  
  def activate_special_window
    @special_window.money = money
    @special_window.show.activate
    @status_window.show
  end
  def command_special
    @dummy_window.hide
    activate_special_window
  end
  def on_special_ok
    @item = @special_window.item
    @special_window.hide
    @number_window.set(@item, max_buy, buying_price, currency_unit)
    @number_window.show.activate
  end
  def on_special_cancel
    @command_window.activate
    @dummy_window.show
    @special_window.hide
    @status_window.hide
    @status_window.item = nil
    @help_window.clear
  end
  def do_buy(number)
    $game_party.lose_gold(number * buying_price)
    $game_party.gain_item(@item.item, number)
    if    @command_window.current_symbol == :buy
      @shop.items.find{|x| x.id==@item.id && x.class==@item.class}.amount -= number
    elsif @command_window.current_symbol == :special
      @shop.epic.find{|x| x.id==@item.id && x.class==@item.class}.amount -= number
    end
    @shop.clean_up
  end
  def do_sell(number)
    $game_party.gain_gold(number * selling_price)
    $game_party.lose_item(@item, number)
    if @item.is_a?(Tidloc::CustomEquip::Weapon) || @item.is_a?(Tidloc::CustomEquip::Armor)
      item = @shop.items.find{|x| x.nid==@item.nid && x.class==@item.class} 
    else
      item = @shop.items.find{|x| x.id==@item.id && x.class==@item.class}
    end
    if item
      @shop.items.find{|x| x.id==@item.id && x.class==@item.class}.amount += number
    else
      if    @item.is_a?(RPG::Item)
        @shop.items.push Tidloc::D_Shop::Sell_Item.new @item.id
        @shop.items.last.amount = number
      elsif $imported["Tidloc-CustomEquip"] && @item.is_a?(Tidloc::CustomEquip::Weapon)
        @shop.items.push Tidloc::D_Shop::Sell_Weapon.new @item
        @shop.items.last.amount = 1
      elsif $imported["Tidloc-CustomEquip"] && @item.is_a?(Tidloc::CustomEquip::Armor)
        @shop.items.push Tidloc::D_Shop::Sell_Armor.new @item
        @shop.items.last.amount = 1
      elsif @item.is_a?(RPG::Weapon)
        @shop.items.push Tidloc::D_Shop::Sell_Weapon.new @item.id
        @shop.items.last.amount = number
      elsif @item.is_a?(RPG::Armor)
        @shop.items.push Tidloc::D_Shop::Sell_Armor.new @item.id
        @shop.items.last.amount = number
      end
    end
  end
  def max_buy
    max = $game_party.max_item_number(@item) - $game_party.item_number(@item)
    if    @command_window.current_symbol == :buy
      max2 = @shop.items.find{|x| x.id==@item.id && x.class==@item.class}.amount
    elsif @command_window.current_symbol == :special
      max2 = @shop.epic.find{|x| x.id==@item.id && x.class==@item.class}.amount
    end
    max = [max,max2].min
    buying_price == 0 ? max : [max, money / buying_price].min
  end
  def on_number_ok
    Sound.play_shop
    case @command_window.current_symbol
    when :buy
      do_buy(@number_window.number)
    when :special
      do_buy(@number_window.number)
    when :sell
      do_sell(@number_window.number)
    end
    end_number_input
    @gold_window.refresh
    @status_window.refresh
  end
  def buying_price
    case @command_window.current_symbol
    when :buy
      @buy_window.price(@item)
    when :special
      @special_window.price(@item)
    end
  end
  def end_number_input
    @number_window.hide
    case @command_window.current_symbol
    when :buy
      activate_buy_window
    when :special
      activate_special_window
    when :sell
      activate_sell_window
    end
  end
  
  def Scene_Shop.bonus
    $game_system.tidloc_dshop.each{|x|
      if rand(10000) < Tidloc::D_Shop::PROP
        temp = []
        a=0
        for x in Tidloc::D_Shop::SPECIALS
          for y in x[2]
            temp.push [x[0],x[1]] if y == x._id
          end
        end
        if temp.size > 0
          t = rand(temp.length)
          case temp[t][0]
          when 0;  item = $data_items[temp[t][1]];   
          when 1;  item = $data_weapons[temp[t][1]];
          when 2;  item = $data_armors[temp[t][1]];
          end
          unless @shop.items.find{|y| ((y.object == item) ||
            (item.is_a?(RPG::EquipItem) && y.object.item == item)) && y.base_stock}
            if $imported["Tidloc-CustomEquip"] && @shoplvl > 0
              if item.is_a?(RPG::Weapon)
                item = Tidloc::CustomEquip::Weapon.new item
              elsif item.is_a?(RPG::Armor)
                item = Tidloc::CustomEquip::Armor.new item
              end
            end
            @shop.items.push Tidloc::D_Shop::Sell_Item.new item
          end
        end
      end
    }
  end
  def Scene_Shop.process
    $game_system.tidloc_dshop.each{|x|
      x.items.each{|y|
        y.proceed_stock
      }
      if Tidloc::D_Shop::CALCTIME
        if rand(10000) < Tidloc::D_Shop::PROP
          temp = []
          a=0
          for z in Tidloc::D_Shop::SPECIALS
            for y in z[2]
              temp.push [z[0],z[1]] if y == x._id
            end
          end
          if temp.size > 0
            t = rand(temp.length)
            case temp[t][0]
            when 0;  item = $data_items[temp[t][1]];   
            when 1;  item = $data_weapons[temp[t][1]];
            when 2;  item = $data_armors[temp[t][1]];
            end
            unless x.items.find{|y| ((y.object == item) ||
              (item.is_a?(RPG::EquipItem) && y.object.item == item)) && y.base_stock}
              if $imported["Tidloc-CustomEquip"]
                if item.is_a?(RPG::Weapon)
                  item = Tidloc::CustomEquip::Weapon.new item
                elsif item.is_a?(RPG::Armor)
                  item = Tidloc::CustomEquip::Armor.new item
                end
              end
              x.items.push Tidloc::D_Shop::Sell_Item.new item
            end
          end
        end
      end
    }
  end      
end


module Tidloc;module D_Shop
class Window_ShopBuy_2 < Window_ShopBuy
  def initialize(shopnum,bonus=false)
    super(0, 120, Graphics.height-120,[])
    self.width = Graphics.width/2 + 50
    @shop  = $game_system.tidloc_dshop.find{|x| x._id == $tidloc_shopnum[0]}
    @bonus = bonus
    refresh
    self.index = 0
  end
  def price(item)
    item.price
  end
  def refresh
    self.contents.clear
    return unless @shop && @shop.items && @shop.epic
    self.contents = Bitmap.new(width - 32, row_max * 32)
    if @bonus
      @data = @shop.epic
    else
      @data = @shop.items
      @data = @data.map{|x| x if x.amount>0}.compact.sort_by{|x| [x.id]}
    end
    for i in 0...@data.size
      draw_item i
    end
  end
  def draw_item(index)
    item = @data[index]
    case item
    when RPG::Item
      number = $game_party.item_number(item)
    when Tidloc::CustomEquip::Weapon
      number = 1
    when Tidloc::CustomEquip::Weapon
      number = 1
    when RPG::Weapon
      number = $game_party.item_number(item)
    when RPG::Armor
      number = $game_party.item_number(item)
    else
      number = 1
    end
    if item.price <= $game_party.gold and number < 99
      self.contents.font.color = normal_color
    else
      self.contents.font.color = Color.new(255, 255, 255, 128)
    end
    x = 4
    y = index * 24
    rect = Rect.new(x, y, self.width - 32, 32)
    self.contents.fill_rect(rect, Color.new(0, 0, 0, 0))
    draw_icon(item.icon_index, x, y)
    if Graphics.width == 640
      self.contents.draw_html(x + 28,  y, 200, 24, item.name, 0) if $imported["HTML-tagging"]
      self.contents.draw_text(x + 28,  y, 200, 24, item.name, 0) unless $imported["HTML-tagging"]
      self.contents.font.color = system_color
      self.contents.draw_text(x + 230, y,  30, 24, "x"+item.amount.to_s, 2) if item.amount > 1
      self.contents.font.color = normal_color
      self.contents.draw_text(x + 260, y,  70, 24, item.price.to_s, 2)
    else
      self.contents.draw_html(x + 28,  y, 150, 24, item.name, 0) if $imported["HTML-tagging"]
      self.contents.draw_text(x + 28,  y, 150, 24, item.name, 0) unless $imported["HTML-tagging"]
      self.contents.font.color = system_color
      self.contents.draw_text(x + 180, y,  30, 24, "x"+item.amount.to_s, 2) if item.amount > 1
      self.contents.font.color = normal_color
      self.contents.draw_text(x + 210, y,  55, 24, item.price.to_s, 2)
    end
  end
  def update_help
    @help_window.set_text(self.item == nil ? "" : self.item.description)
    @status_window.item = item if @status_window
  end
end

class Window_ShopCommand_2 < Window_ShopCommand
  def make_command_list
    add_command(Tidloc::Vocabs.D_Shop("vocab",$tidloc_language)[0], :buy)
    add_command(Tidloc::Vocabs.D_Shop("vocab",$tidloc_language)[1], :sell,   !@purchase_only)
    add_command(Tidloc::Vocabs.D_Shop("vocab",$tidloc_language)[2], :special)
    add_command(Tidloc::Vocabs.D_Shop("vocab",$tidloc_language)[3], :cancel)
  end
end

class Window_ShopNumber_2 < Window_ShopNumber
  def window_width
    Graphics.width/2 + 50
  end
end
end;end