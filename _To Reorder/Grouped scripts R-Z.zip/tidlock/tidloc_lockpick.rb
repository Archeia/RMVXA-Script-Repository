################################################################################
#  Tidloc's Lockpicking v. 1.1.3                                               #
#                                             (Mar-11-16)                      #
#==============================================================================#
# This script allows you to have a little minigame for opening doors. Original #
# idea comes from Skyrim.                                                      #
#==============================================================================#
# You start the minigame with a scriptcommand as in the next line:             #
#    Tidloc.exe "LockPick",:game,*d*,*r*,*p*                                   #
# Where *d* is the difficulty of the door. by this diffuculty the speed of the #
# pins is determined more details in the list of constants below. Upon a       #
# successfull lockpick, a defined switch will be set true, but between this    #
# script command and the conditional branch is any other command needed (RMVXA #
# hardcoded) needed, like "wait 1 frame" or it won't accept the door to be     #
# opened.                                                                      #
# *r* is an optionan argument wheter upon breaking a lockpick the arrested     #
# pins shall be remembered. default is set to false. If used, set it to the    #
# saved ID of the lock.                                                        #
# *p* is an optional argument for fixing pins upon entering the game (so less  #
# have to be arrested in the minigame). Use an array like [true,true] to have  #
# the first two pins fixed upon entering. By default this is an empty array.   #
# This minigame needs my header to work.                                       #
#------------------------------------------------------------------------------#
# There are notetags you have to use on items for this script to work:         #
#    <lockpick>                                                                #
#      the tagged item is a lockpick and will be used, when an attempt fails.  #
#      at least one has to be in the inventory to start the minigame, or one   #
#      of the following notetag:                                               #
#    <lockpick-unbreak>                                                        #
#      the tagged item is an unbreakable lockpick and as long as it's in the   #
#      inventory, no lockpicks are being used by a failed attempt.             #
#------------------------------------------------------------------------------#
# constants to adjust the minigame:                                            #
#   Result_Switch ... the ID of the global switch where the outcome of the     #
#                     minigame gets save to.                                   #
#   Count_Var ....... the ID of the global variable where it's stored how many #
#                     locks have been picked so far. set to 0 to deactivate.   #
#   Arrest_Perc ..... the percentage of the pin position that's accepted as a  #
#                     successfull arresting of one pin.                        #
#   Pin_Max ......... defines how many pins are used for each lock.            #
#   Speeds .......... defines the speed of each pin for each difficulty in an  #
#                     array of arrays. Example is given below.                 #
#   Screen_Tone ..... tones the surrounding of the map ba the given tone       #
# following some graphical adjustments:                                        #
#   Start_Pick ...... x-coordinate of the pick, when at the first pin.         #
#   Diff_Pick ....... x-difference of the pins.                                #
#   Pick_height ..... y-coordinate of the pick.                                #
#   Pin_Limit ....... y-coordinate of the lowest and highest point of the pins #
#                     movement, considered from the middle of the screen,      #
#                     facing upwards.
#   Automatic_Pro ... if true, the pick progresses automaticly after a success #
#                     in arresting a pin to next one. if false, the player can #
#                     freely choose between the pins.                          #
# following some sound adjustments:                                            #
#   Open_SE ......... sound effect to be played when all pins were arrested.   #
#   Arrest_SE ....... sound effect to be played when one pin was arrested.     #
#   Fail_SE ......... sound effect to be played when the lockpicking failed.   #
#   Images .......... a hash for the graphics used for the folder name, the    #
#                     background image (lock) the pick and the single pins.    #
#   Multiplier ...... a hast consisting of a stat, that shall be considered    #
#                     and the formula used, to make lockpicking more easy at   #
#                     higher stats and more challenging for lower stats.       #
#------------------------------------------------------------------------------#
# Speeds constant:                                                             #
#  For example if Pin_Max=2 and we use 4 difficulties, you can define the      #
#  speeds like:                                                                #
#    Speeds = [[1  , 1.1],                                                     #
#              [1.4, 1.6],                                                     #
#              [1.9, 2.1],                                                     #
#              [2.4, 2.8]]                                                     #
#  where the first line is difficulty 0 and the first pin will move with a     #
#  speed of 1 and the second with a speed of 1.1 (the Multiplier constant will #
#  be considered in the next step in the script) and so on.                    #
# Multiplier constant:                                                         #
#  the Multiplier constant will be evaluated by the game upon starting the     #
#  minigame. if you don't want to use it, write "1" for the formula.           #
#  stat is the calculated variable via the string :stat. With this :stat you   #
#  are free to consider whichever attribute you want and/or the attribute of   #
#  the whole party like in the following line:                                 #
#    :stat    => "a=0;$game_party.battle_members.each{|m| a += m.agi};a",      #
#  takes the accumulated value of all party members agility into consideration.#
#==============================================================================#
# Credits for this script:                                                     #
#   - Tidloc, for creating it                                                  #
################################################################################

$imported = {} if $imported.nil?
$imported["Tidloc-GameLockPick"] = [1,1,3]
$needed   = [] if $needed.nil?
$needed.push ["Tidloc-Header",[2,11,3],true,"Tidloc-GameLockPick"]

module Tidloc
  module Games
    module LockPick
      Result_Switch = 1
      Count_Var     = 0
      Arrest_Perc   = 10
      Pin_Max       = 5
      Speeds        = [[1  ,1  ,1  ,1  ,1.2],
                       [1.6,1.6,1.6,1.6,2  ],
                       [2  ,2  ,2.1,2.2,2.3]]
      Screen_Tone   = [ -68, -68, 0, 68]
      
      Sprite_Z      = 2000
      Start_Pick    = 83
      Diff_Pick     = 28
      Pick_height   = Graphics.height/2 + 30
      Pin_Limit     = [35, 78]
      Automatic_Pro = true
      Open_SE       = ["Open2",  75, 100]
      Arrest_SE     = ["Key",    75, 100]
      Fail_SE       = ["Sword2", 65, 125]
      Images = {  :folder => "Graphics/Pictures/Games/LockPick/",
                  :back   => "back",
                  :pick   => "pick",
                  :pin    => "pin"
                }
                
      Multiplier = { :stat    => "$game_party.leader.agi",
                     :formula => "0.8+1.1**(-stat/10.0 - 1)"
                   }
      
      Notetags = {  :pick    => /<lockpick>/i,
                    :picklvl => /<lockpick ([0-9]+)>/i,
                    :unbreak => /<lockpick-unbreak>/
                  }
    end
  end
  module Vocabs;class<<self
    def games_lockpick(code,lang)
      if    lang == "eng"
        case code
        when "name" ; return "Lock picking"
        when "pick" ; return "Lockpicks:"
        when "lvl"  ; return "Lock level:"
        when "lvls" ; return ["easy","average","hard"]
        end
      elsif lang == "ger"
        case code
        when "name" ; return "Schloss knacken"
        when "pick" ; return "Dietriche:"
        when "lvl"  ; return "Komplexitä"
        when "lvls" ; return ["einfach","mittel","schwer"]
        end
      elsif lang == "cze"
        case code
        when "name" ; return "Páčení zámků"
        when "pick" ; return "Paklíče:"
        when "lvl"  ; return "Úroveň zabezpečení:"
        when "lvls" ; return ["nízká","běžná","vysoká"]
        end
      end
    end
  end;end
################################################################################
  module Games
    module LockPick
      class Game
        attr_accessor :progress
        attr_accessor :stage
        attr_accessor :pins
        attr_accessor :pinh
        attr_accessor :lvl
        attr_accessor :remember
        attr_accessor :prefix
        def initialize(lvl=0,remember = false,prefix = Array.new(Tidloc::Games::LockPick::Pin_Max) {nil} )
          
#~           if tone
#~             @ori_tone = tone
#~           else
            @ori_tone = $game_map.screen.tone.clone
#~           end
          $game_map.screen.start_tone_change(
                             Tone.new(*Tidloc::Games::LockPick::Screen_Tone), 0)
          $game_map.update false
          
          stat  = eval Tidloc::Games::LockPick::Multiplier[:stat]
          @mult = eval Tidloc::Games::LockPick::Multiplier[:formula]
          self.lvl      = lvl
          self.progress = :start
          self.remember = remember
          self.stage    = 0
          self.pins     = Array.new(Tidloc::Games::LockPick::Pin_Max) { false   }
          self.pinh     = Array.new(Tidloc::Games::LockPick::Pin_Max) { [0,nil] }
          self.prefix   = prefix
          prefix.each_with_index{|p,i|
            self.pins[i] = p unless p.nil?
          }
#~           if self.remember && $game_system.tidloc_lockpick_rem && $game_system.tidloc_lockpick_rem[self.remember]
#~             self.pins = $game_system.tidloc_lockpick_rem[self.remember]
#~           end
        end
        def update_map
          "@spriteset.update;
           update_game_sprite_picklock;
           update_game_input_picklock"
        end
        def update_pin(index)
          dif = Tidloc::Games::LockPick::Pin_Limit[1]-Tidloc::Games::LockPick::Pin_Limit[0]
          self.pinh[index][1] = :down if index != self.stage
          if    self.pinh[index][1] == :up   && self.pinh[index][0] < dif
            self.pinh[index][0] += Tidloc::Games::LockPick::Speeds[self.lvl][index] * @mult
            self.pinh[index][1] = :down if self.pinh[index][0] >= dif
          elsif self.pinh[index][1] == :down && self.pinh[index][0] > 0
            self.pinh[index][0] -= Tidloc::Games::LockPick::Speeds[self.lvl][index] * @mult
            if    self.pinh[index][0] <= 0 && index == self.stage
              self.pinh[index][1] = :up   
            elsif self.pinh[index][0] == 0
              self.pinh[index][1] = nil
            end
          end
        end
        def arrest
          dif  = Tidloc::Games::LockPick::Pin_Limit[1]-Tidloc::Games::LockPick::Pin_Limit[0]
          dif *= (100-Tidloc::Games::LockPick::Arrest_Perc)/100.0
          self.pinh[self.stage][0] > dif
        end
        def end(tonechange=true)
          if self.remember
            unless $game_system.tidloc_lockpick_rem
              $game_system.tidloc_lockpick_rem = []
            end
            $game_system.tidloc_lockpick_rem[self.remember] = self.pins
          end
          SceneManager.scene.t_game_sprite.each{|b| b.bitmap.dispose;b.dispose}
          SceneManager.scene.t_game_sprite = []
          $tidloc_game = nil
          if tonechange
            $game_map.screen.start_tone_change(Tone.new(0,0,0,0),0) 
          else
            return @ori_tone
          end
        end
      end
    end
  end
end

class Game_System
  attr_accessor :tidloc_lockpick_rem
end
class Game_Party
  def num_lockpicks
    it  = self.items.find_all{|i| i.note =~ Tidloc::Games::LockPick::Notetags[:pick]}
    it += self.items.find_all{|i| i.note =~ Tidloc::Games::LockPick::Notetags[:unbreak]}
    num = 0
    it.each{|i| num += item_number i }
    return num
  end
  def lose_lockpick
    return if self.items.find_all{|i| i.note =~ Tidloc::Games::LockPick::Notetags[:unbreak]}.size > 0
    it = self.items.find{|i| i.note =~ Tidloc::Games::LockPick::Notetags[:pick]}
    self.lose_item it,1
  end
end

class Scene_Map < Scene_Base
  def update_game_sprite_picklock
    f  = Tidloc::Games::LockPick::Images[:folder]
    i1 = Tidloc::Games::LockPick::Images[:back]
    i2 = Tidloc::Games::LockPick::Images[:pick]
    i3 = Tidloc::Games::LockPick::Images[:pin]
    back = Cache.normal_bitmap(f+i1)
    pick = Cache.normal_bitmap(f+i2)
    pin  = Cache.normal_bitmap(f+i3)
    @t_game_sprite.each{|b| b.bitmap.clear if b && b.bitmap}
    if $tidloc_game.progress == :start
      @t_game_sprite = Array.new(7) {Sprite.new}
      @t_game_sprite[0].bitmap = Bitmap.new back.width , back.height
      @t_game_sprite[1].bitmap = Bitmap.new pick.width , pick.height
      @t_game_sprite[1].x = Tidloc::Games::LockPick::Start_Pick-50
      @t_game_sprite[2].bitmap = Bitmap.new pin.width  , pin.height
      @t_game_sprite[3].bitmap = Bitmap.new pin.width  , pin.height
      @t_game_sprite[4].bitmap = Bitmap.new pin.width  , pin.height
      @t_game_sprite[5].bitmap = Bitmap.new pin.width  , pin.height
      @t_game_sprite[6].bitmap = Bitmap.new pin.width  , pin.height
      @t_game_sprite.each{|s|
        s.z = Tidloc::Games::LockPick::Sprite_Z
      }
      $tidloc_game.progress = :move_right
    elsif $tidloc_game.progress == :move_right
      @t_game_sprite[1].x += 2
      if    @t_game_sprite[1].x >= Tidloc::Games::LockPick::Start_Pick &&
           (@t_game_sprite[1].x-Tidloc::Games::LockPick::Start_Pick)%Tidloc::Games::LockPick::Diff_Pick == 0
        $tidloc_game.stage = ((@t_game_sprite[1].x-Tidloc::Games::LockPick::Start_Pick)/Tidloc::Games::LockPick::Diff_Pick).to_i
        if    !Tidloc::Games::LockPick::Automatic_Pro  ||
              (Tidloc::Games::LockPick::Automatic_Pro && !$tidloc_game.pins[$tidloc_game.stage])
          $tidloc_game.progress = :game
          $tidloc_game.pinh[$tidloc_game.stage][1] = :up
        end
      end
    elsif $tidloc_game.progress == :move_left
      @t_game_sprite[1].x -= 2
      if    @t_game_sprite[1].x >= Tidloc::Games::LockPick::Start_Pick &&
           (@t_game_sprite[1].x-Tidloc::Games::LockPick::Start_Pick)%Tidloc::Games::LockPick::Diff_Pick == 0
        $tidloc_game.progress = :game
        $tidloc_game.stage = ((@t_game_sprite[1].x-Tidloc::Games::LockPick::Start_Pick)/Tidloc::Games::LockPick::Diff_Pick).to_i
        $tidloc_game.pinh[$tidloc_game.stage][1] = :up
      end
    else
      @t_game_sprite[1].x = Tidloc::Games::LockPick::Start_Pick + $tidloc_game.stage*Tidloc::Games::LockPick::Diff_Pick
    end
    @t_game_sprite[0].x = (Graphics.width  - back.width )/2
    @t_game_sprite[0].y = (Graphics.height - back.height)/2
    @t_game_sprite[0].z = Tidloc::Games::LockPick::Sprite_Z
    @t_game_sprite[0].bitmap.blt(0, 0, back, back.rect, 255)
    @t_game_sprite[0].bitmap.draw_text 20,150,150,30,Tidloc::Vocabs.games_lockpick("pick",$tidloc_language)+" #{$game_party.num_lockpicks.to_s.rjust(2)}",2
    @t_game_sprite[1].y  = Tidloc::Games::LockPick::Pick_height
    @t_game_sprite[1].z  = Tidloc::Games::LockPick::Sprite_Z+1
    @t_game_sprite[1].bitmap.blt(0, 0, pick, pick.rect, 255)
    @t_game_sprite[2..6].each_with_index{|s,i|
      s.x  = Tidloc::Games::LockPick::Start_Pick + i*Tidloc::Games::LockPick::Diff_Pick
      s.x += pick.width - pin.width/2 - 1
      if $tidloc_game.pins[i]
        s.y  = Graphics.height/2 - Tidloc::Games::LockPick::Pin_Limit[1]
      else
        s.y  = Graphics.height/2 - Tidloc::Games::LockPick::Pin_Limit[0]
        $tidloc_game.update_pin(i)
        s.y -= $tidloc_game.pinh[i][0]
      end
      s.z  = Tidloc::Games::LockPick::Sprite_Z+1
      s.bitmap.blt(0, 0, pin, pin.rect, 255)
    }
  end
  def update_game_input_picklock
    return unless $tidloc_game.progress == :game
    if    Input.trigger?(:B)
      $tidloc_game.end
      $game_switches[Tidloc::Games::LockPick::Result_Switch] = false
    elsif Input.trigger?(:LEFT)  && $tidloc_game.stage > 0
      return if Tidloc::Games::LockPick::Automatic_Pro
      $tidloc_game.progress = :move_left
    elsif Input.trigger?(:RIGHT) && $tidloc_game.stage < Tidloc::Games::LockPick::Pin_Max-1
      return if Tidloc::Games::LockPick::Automatic_Pro
      $tidloc_game.progress = :move_right
    elsif Input.trigger?(:C) && !$tidloc_game.pins[$tidloc_game.stage]
      if $tidloc_game.arrest
        $tidloc_game.pins[$tidloc_game.stage] = true
        if $tidloc_game.pins[0] && $tidloc_game.pins[1] && $tidloc_game.pins[2] && $tidloc_game.pins[3] && $tidloc_game.pins[4]
          $tidloc_game.end
          $game_switches[Tidloc::Games::LockPick::Result_Switch] = true
          RPG::SE.new(*Tidloc::Games::LockPick::Open_SE).play
          if Tidloc::Games::LockPick::Count_Var && Tidloc::Games::LockPick::Count_Var > 0
            $game_variables[Tidloc::Games::LockPick::Count_Var] += 1 
          end
        else
          RPG::SE.new(*Tidloc::Games::LockPick::Arrest_SE).play
          if Tidloc::Games::LockPick::Automatic_Pro
            $tidloc_game.progress = :move_right
          end
        end
      else
        RPG::SE.new(*Tidloc::Games::LockPick::Fail_SE).play
        if $game_party.num_lockpicks > 1
          lvl = $tidloc_game.lvl
          rem = $tidloc_game.remember
          pre = $tidloc_game.prefix
          $tidloc_game.end(false)
          $tidloc_game = Tidloc::Games::LockPick::Game.new lvl,rem,pre
        else
          $tidloc_game.end
          $game_switches[Tidloc::Games::LockPick::Result_Switch] = false
        end
        $game_party.lose_lockpick
      end
    end
  end
end