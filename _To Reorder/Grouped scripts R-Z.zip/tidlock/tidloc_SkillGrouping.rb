########################################
#
# to group skills, simply put a notetag for them:
#    <group: *x*>
# where *x* is any string under which group you want that skill listed.
#---------------
# there is also a constant called Group_Icon. if you set an icon index there
# bigger then 0, it will be used instead of any skill icon
#---------------
# alternatively you can use my Skill-Data script for unique entries for
# each group!
#
########################################

module Tidloc
  module SkillGrouping
    Group_Icon = 224
    Notetags   = [/<group: (.*)>/]
    
########################################
    class Group
      attr_accessor :name
      attr_accessor :icon_index
      attr_accessor :description
      def initialize(name, skill)
        self.name = name
				if $imported["Tidloc-SkillData"]
					temp = Tidloc::Header.SkillData(name)[0]
					self.name        = temp[:name]
					self.icon_index  = temp[:icon]
					self.description = temp[:desc]
			  end
			  if !$imported["Tidloc-SkillData"] || !self.name
          self.icon_index  = Tidloc::SkillGrouping::Group_Icon
          self.icon_index  = skill.icon_index if self.icon_index < 1
          self.description = skill.description
				end
      end
    end
  end
end

class RPG::Skill
  def grouping_class
    if self.note =~ Tidloc::SkillGrouping::Notetags[0]
      return $1
    else
      return "\10"
    end
  end
end

class Window_BattleSkill2 < Window_BattleSkill
  def make_item_list
    @data = @actor ? @actor.skills.select {|skill| include?(skill) } : []
    return if @data.size == 0
    @skills_grouped = []
    data2 = @data.map{|d| d.grouping_class}.uniq.sort.delete_if{|d| d == "\10"}
    @skills_grouped[data2.size] = @data.find_all{|da| da.grouping_class == "\10"}
    data2.each_with_index{|d,i|
      @skills_grouped[i] = @data.find_all{|da| da.grouping_class == d}
    }
    @data = []
    data2.each_with_index{|d,i|
      @data.push Tidloc::SkillGrouping::Group.new d,@skills_grouped[i][0]
    }
    @data += @skills_grouped.last
  end
  def skills
    @skills_grouped[index]
  end
  def enable?(item)
    true
  end
  alias wo_tidloc_skillgrouping_draw_skill_cost draw_skill_cost
  def draw_skill_cost(rect, skill)
    if skill.is_a?(Tidloc::SkillGrouping::Group)
      return
    end
    wo_tidloc_skillgrouping_draw_skill_cost(rect, skill)
  end
end


class Window_BattleSkill3 < Window_BattleSkill
  def refresh(skills)
    super()
    @data = skills
    self.height = 24 + @data.size*24
    self.width  = Graphics.width/2
    draw_all_items
  end
  def actor=(actor)
    return if @actor == actor
    @actor = actor
    self.oy = 0
  end
  def stype_id=(stype_id)
    return if @stype_id == stype_id
    @stype_id = stype_id
    self.oy = 0
  end
  def col_max
    1
  end
end

class Scene_Battle < Scene_Base
  alias wo_tidloc_skillgrouping_create_all_windows create_all_windows
  def create_all_windows
    wo_tidloc_skillgrouping_create_all_windows
    create_skill_2
  end
  def create_skill_window
    @skill_window = Window_BattleSkill2.new(@help_window, @info_viewport)
    @skill_window.set_handler(:ok,     method(:on_skill_ok))
    @skill_window.set_handler(:cancel, method(:on_skill_cancel))
  end
  def create_skill_2
    @skill_window_2 = Window_BattleSkill3.new(@help_window, @info_viewport)
    @skill_window_2.x = @skill_window.x
    @skill_window_2.hide.deactivate
    @skill_window_2.set_handler(:ok,     method(:on_skill_ok_2))
    @skill_window_2.set_handler(:cancel, method(:on_skill_cancel_2))
  end
  alias wo_tidloc_skillgrouping_command_skill command_skill
  def command_skill
    wo_tidloc_skillgrouping_command_skill
    @skill_window_2.actor = BattleManager.actor
    @skill_window_2.stype_id = @actor_command_window.current_ext
  end
  def on_skill_ok
    if @skill_window.item.is_a?(Tidloc::SkillGrouping::Group)
      @skill_window_2.refresh @skill_window.skills
      @skill_window_2.x = @skill_window.x + @skill_window.index%2*Graphics.width/2
      @skill_window_2.y = @skill_window.y + @skill_window.index/2*24
      @skill_window_2.y = [@skill_window_2.y,Graphics.width-@skill_window_2.height].min
      @skill_window_2.z = 500
      @skill_window_2.show.activate
    else
      @skill = @skill_window.item
      BattleManager.actor.input.set_skill(@skill.id)
      BattleManager.actor.last_skill.object = @skill
      if !@skill.need_selection?
        @skill_window.hide
        next_command
      elsif @skill.for_opponent?
        select_enemy_selection
      else
        select_actor_selection
      end
    end
  end
  def on_skill_cancel_2
    @skill_window_2.hide.deactivate
    @skill_window.show.activate
  end
  def on_skill_ok_2
    @skill = @skill_window_2.item
    BattleManager.actor.input.set_skill(@skill.id)
    BattleManager.actor.last_skill.object = @skill
    if !@skill.need_selection?
      @skill_window.hide
      @skill_window_2.hide
      next_command
    elsif @skill.for_opponent?
      select_enemy_selection
    else
      select_actor_selection
    end
  end
  alias wo_tidloc_skillgrouping_on_actor_ok on_actor_ok
  def on_actor_ok
    @skill_window_2.hide
    wo_tidloc_skillgrouping_on_actor_ok
  end
  alias wo_tidloc_skillgrouping_on_enemy_ok on_enemy_ok
  def on_enemy_ok
    @skill_window_2.hide
    wo_tidloc_skillgrouping_on_enemy_ok
  end
end