
$imported = {} if $imported.nil?
$imported["Tidloc-EnemyData"] = [1,1,0]
$needed = [] if $needed.nil?
$needed.push ["Tidloc-Header",[2,11,2],true,"Tidloc-EnemyData"]

class RPG::Enemy
  alias wo_tidloc_name name
  def name
    temp = Tidloc::Header::EnemyData(self.id)[:name][$tidloc_language]
    return temp if temp
    return wo_tidloc_name
  end
  def dataname
    wo_tidloc_name
  end
  def name_html
    text = "{eval= "
    Tidloc::Languages.each{|l|
      text += "if $tidloc_language==\"#{l}\";"
      temp = Tidloc::Header::EnemyData(self.id)[:name][l]
      if temp
        text += "\"#{temp}\";els"
      else
        text += "\"#{wo_tidloc_name}\";els"
      end
    }
    text += "e;\"#{wo_tidloc_name}\";end}"
    return text
  end
  def commands
    Tidloc::Header::ItemData(self.id)[:commands]
  end
end

module Tidloc;module Header;class<<self;def EnemyData(enemy_id)
  name    = {"Def" => $data_enemies[enemy_id].dataname}
  desc    = {"Def" => ""}
  command = []
  case enemy_id
  when "enemy react to recieving damage"
    command_name = "heal_1"
    command.push ["BattleGetHit","actor = $game_temp.tidloc[:target];
                               actor._tidvar[0] = 0 if actor._tidvar[0].nil?
                               actor._tidvar[0] += 1
                               actor.commands.push "+
                               "[\"TurnStart\",\"actor = $game_temp.tidloc[:enemy];
                                                create_popup(\\\"tot\\\",\\\"TP_DMG\\\");
                                                actor.commands.find{|c| c[2]==\\\"#{command_name}\\\"}.delete_if{|x| x}\",
                                  \"#{command_name}\"]\""]
  when 1 # Pixie
    name["ger"] = "Pixie"
    name["eng"] = "Pixie"
  when 2 # Cavesnake
    name["ger"] = "Höhlenschlange"
    name["eng"] = "Cavesnake"
  when 3 # Hunterdemon
    name["ger"] = "Jagddämon"
    name["eng"] = "Hunterdemon"
  when 4 # brown rabbit
    name["ger"] = "brauner Hase"
    name["eng"] = "brown rabbit"
  when 5 # forestrat
    name["ger"] = "Waldratte"
    name["eng"] = "Forestrat"
  end
  return {:name     => name,
          :commands => command,
          :desc     => desc
         }
end;end;end;end