=begin
  addition to my script diablo equipment.
  This script completely relies on the Pretag and Postag additions and you can
  choose how many pre/postags are allowed per multi-tag item (initially just as 
  in Path of Exile 3 of each are possible.)

=end

$imported["Tidloc-DiabloMulti"] = [1,0,0]
$needed.push ["Tidloc-DiabloPretag",[1,0,0],true,"Tidloc's Custom Equipment"]
$needed.push ["Tidloc-DiabloPosttag",[1,0,0],true,"Tidloc's Custom Equipment"]


module Tidloc;module CustomEquip
  Pretag_max  = 3
  Postag_max  = 3
end;end

module Tidloc;module Vocabs;class<<self
  def MultiEquip(code,lang)
    if lang == "eng"
      case code
      when "Prefix"; return "Rare"
      end
    elsif lang == "ger"
      case code
      when "Prefix"; return "Seltenes"
      end
    end
  end
end;end;end

################################################################################

module Tidloc;module CustomEquip;class Multi
  def Multi.tag(ench_lvl,item)
    return [] unless item.note =~ Tidloc::DiabloEquip::Notetags[0]
    lvl = $1.to_i
    temp = ench_lvl - lvl
    return [] if 0 > temp - Tidloc::DiabloEquip::Lvl_Corr_Mul
    return [] unless rand(temp) > rand(lvl + Tidloc::DiabloEquip::Lvl_Corr_Mul)
    return [] unless rand(100)  < Tidloc::DiabloEquip::Max_Prop_Multi
    return [] unless $game_temp._tidloc_diablo_postags && $game_temp._tidloc_diablo_pretags
    temp = []
    Pretag_max.times{
      neu = 0
      while neu==0 || temp[0..(Pretag_max-1)].compact.find{|t| t.tag_exclude.find{|n| n== neu}}
        new = Pretag.tag(ench_lvl,item)
        neu = new.nil? ? nil : new.clone
      end
      temp.push neu
    }
    Postag_max.times{
      neu = 0
      while neu==0 || temp[(Pretag_max)..(Pretag_max+Postag_max-1)].compact.find{|t| t.tag_exclude.find{|n| n== neu}}
        new = Postag.tag(ench_lvl,item)
        neu = new.nil? ? nil : new.clone
      end
      temp.push neu
    }
    return [] if temp.compact.count < 3
    temp
  end
end;end;end