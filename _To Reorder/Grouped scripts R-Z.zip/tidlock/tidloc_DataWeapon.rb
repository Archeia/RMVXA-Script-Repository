
$imported = {} if $imported.nil?
$imported["Tidloc-WeaponData"] = [1,1,0]
$needed = [] if $needed.nil?
$needed.push ["Tidloc-Header",[2,11,2],true,"Tidloc-WeaponData"]

class RPG::Weapon
  alias wo_tidloc_name name
  def name
    temp = Tidloc::Header::WeaponData(self.id)[:name][$tidloc_language]
    return temp if temp
    return wo_tidloc_name
  end
  def dataname
    wo_tidloc_name
  end
  def name_html
    text = "{eval= "
    Tidloc::Languages.each{|l|
      text += "if $tidloc_language==\"#{l}\";"
      temp = Tidloc::Header::WeaponData(self.id)[:name][l]
      if temp
        text += "\"#{temp}\";els"
      else
        text += "\"#{wo_tidloc_name}\";els"
      end
    }
    text += "e;\"#{wo_tidloc_name}\";end}"
    return text
  end
  alias wo_tidloc_description description
  def description
    temp = Tidloc::Header::WeaponData(self.id)[:desc][$tidloc_language]
    return temp if temp
    return wo_tidloc_description
  end
  def datadescription
    wo_tidloc_description
  end
  def commands
    Tidloc::Header::ItemData(self.id)[:commands]
  end
  def execute_commands(tag)
    self.commands.each {|x| x[0]==tag ? eval(Tidloc.exe(x[1],x[2])) : ""}
  end
end

module Tidloc;module Header;class<<self;def WeaponData(item_id)
  name    = {"Def" => $data_weapons[item_id].dataname}
  desc    = {"Def" => $data_weapons[item_id].datadescription}
  command = []
  case item_id
  when "catching item"
    com_name = "Kartenwandler"
    command.push ["BattleHit","enemy=$game_temp.tidloc[:target];
                               enemy.commands.push [\"Die\",\"char=$game_temp.tidloc[:target]
                                                              if char.turn_to_card
                                                                create_popup(Bitmap.html_decode(char.card_name),\\\"TP_DMG\\\")
                                                              end\",\"#{com_name}\"]
                               enemy.commands.push [\"TurnNext\", \"char=self
                                                                    char.commands.delete_if{|c| c[2]==\\\"#{com_name}\\\"}\",
                                                               \"#{com_name}\"]"]
  when 1
    name["ger"] = "Taschenmesser"
    name["eng"] = "Pocket Knife"
    desc["ger"] = "Schaden: 1-3\n<space=30>Krit: 5%"
    desc["eng"] = "\100Damage: 1-3\n<space=30>Crit: 5%"
  when 2
    name["ger"] = "Dolch"
    name["eng"] = "Dagger"
    desc["ger"] = "Schaden: 2-4\n<space=30>Krit: 6%"
    desc["eng"] = "\100Damage: 2-4\n<space=30>Crit: 6%"
  when 3
    name["ger"] = "Langschwert"
    name["eng"] = "Longsword"
    desc["ger"] = "Schaden: 7-10\n<space=30>Krit: 5%"
    desc["eng"] = "\100Damage: 7-10\n<space=30>Crit: 5%"
  end
  return {:name     => name,
          :commands => command,
          :desc     => desc
         }
end;end;end;end