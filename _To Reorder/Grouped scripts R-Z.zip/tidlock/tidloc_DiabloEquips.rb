################################################################################
#    Diablo Equipment 1.7.0                                                    #
#         by Tidloc                                  (Jun-23-17)               #
#==============================================================================#
#  Script, that allows items to gain pretags and posttags like the items in    #
#  the Diablo(C) merchandise.                                                  #
#------------------------------------------------------------------------------#
#  To be able to enchant items you need to setup three things:                 #
#  1. Each enchantable item needs to be assigned an item-level, you do this    #
#     via the notetag:                                                         #
#          <elevel=*x*>                                                        #
#  2. You need to define the pretags/postags/specials in their respective      #
#     sections in the script.                                                  #
#  3. before getting items (or before fight ends) you need to set up the item  #
#     level of the items you gain. the higher this enchant-level is, the more  #
#     likely your item will be enchanted and the more likely it may be a       #
#     special item. This item level is set via the script command:             #
#          Tidloc::Ench_lvl(*x*)                                               #
#------------------------------------------------------------------------------#
#  If the item-level is lower then the set level of the item you obtain, it    #
#  will not be enchted and stay vanilla.                                       #
#------------------------------------------------------------------------------#
#  description on the adjustable constants:                                    #
#   Color_ench ...... when using my HTML tagging, you can enter here a tag to  #
#                     change the color the item name is written in when        #
#                     enchanted.                                               #
#   Color_special ... same as Color_ench, just applied when the item is a      #
#                     special item.                                            #
#   Max_Prop_Pre .... maximum propability of an item getting a pretag          #
#   Max_Prop_Post ... maximum propability of an item getting a posttag         #
#   Max_Prop_Spe .... maximum propability of an item being special             #
#   Lvl_Corr_Pre .... higher values lower the propability of applying pretags  #
#                     (only important for lower-level-gears)                   #
#   Lvl_Corr_Post ... higher values lower the propability of applying posttags #
#                     (only important for lower-level-gears)                   #
#   Lvl_Corr_Spe .... higher values lower the propability of being special     #
#                     (only important for lower-level-gears)                   #
#   Use_Identify .... defines wheter you get unidentified items, as used from  #
#                     the Diablo series(false = get as already identified)     #
#                     This feature is described below.                         #
#==============================================================================#
#  When choosing to use identifying, items will always come unidentified. To   #
#  identify them, you can use two options, either via items/skills or by       #
#  calling a scene to identify. To call the Scene type the following script    #
#  command within an event:                                                    #
#     Tidloc.exe("Identify".:call,true)                                        #
#  if you want the identifier to charge for his service, write the amount      #
#  charged instead of true. To have an item or skill identify the enchanted    #                                                     
#  equipment, use the following notetag:                                       #
#     <exe-use: Tidloc.exe("Identify".:call)>                                  #
#  You can add true or an amount to make the item usable indefinitely and/or   #
#  charge money, like in the normal script command. for further customization, #
#  pls refer to my header.                                                     #
#------------------------------------------------------------------------------#
#  Equipment without enchantments can also be enchanted via a new scene that   #
#  can be called with the script command:                                      #
#     Tidloc.exe("Enchant",:call,*enchant-lvl*,*multi?*,*price*)               #
#  And you can also assign items/equipment/skills with this command again.     #
#  enchant-lvl is here the same as when you receive an item, so the higher it  #
#  is chosen, the more likely you can get a good enchantment and the more      #
#  likely it will be enchanted. multi is true/false if more then one item can  #
#  be enchanted per scene call. and price is the charged price for each time   #
#  an equipment gets enchanted. multi and price may be left out.               #
#------------------------------------------------------------------------------#
#  Enchanted equipment maybe unenchanted with a new scene that can be called   #
#  with the script command:                                                    #
#     Tidloc.exe("UnEnchant",:call,*multi?*,*price*)                           #
#  or inserting it again in a notetag of a item/equipment/skill.               #
#  as above, multi is true/false wheter it can be used more often then only    #
#  once and price is the money charged per use. Both can be left out again.    #
#==============================================================================#
#  Feel free to use this script, but please credit me for my work! ^__^        #
################################################################################

$imported = {} if $imported.nil?
$imported["Tidloc-DiabloEquip"] = [1,7,0]
$needed   = [] if $needed.nil?
$needed.push ["Tidloc-Header",[2,11,1],true,"Tidloc's Diablo Equipment"]
$needed.push ["Tidloc-CustomEquip",[1,5,9],true,"Tidloc's Diablo Equipment"]


module Tidloc
  
  Keys = {} if Keys.nil?
  Keys["Identify"]   = false
  Keys["Enchanting"] = false
  Keys["UnEnch"]     = false
  Menu = {} if Menu.nil?
  Menu["Identify"]   = false
  Menu["Enchanting"] = false
  Menu["UnEnch"]     = false
  
  module DiabloEquip
    
    Color_ench     = "<color=cyan>"
    Color_multi    = "<color=orange>"
    Color_special  = "<color=gold>"
    Color_set      = "<color=#007a2a>"
    Max_Prop_Pre   = 50
    Max_Prop_Post  = 50
    Max_Prop_Multi = 20
    Max_Prop_Spe   = 10
    Max_Prop_Set   = 10
    Lvl_Corr_Pre   = 10
    Lvl_Corr_Post  = 10
    Lvl_Corr_Mul   = 15
    Lvl_Corr_Spe   = 25
    Lvl_Corr_Set   = 30
    Use_Identify   = true
    
    DiabloBackground  = nil
    Diablo_BGS        = nil
    EnchantBackground = nil
    Enchant_BGS       = nil
    UnEnchBackground  = nil
    UnEnch_BGS        = nil
  end
  module DiabloEquip
    Notetags = [/<elevel=([0-9]+)>/i]
  end
  
  module Vocabs;class<<self
    def DiabloEquip(code,lang)
      if    lang == "ger"
        case code
        when "Name";    return "Identifizieren"
        when "Enchant"; return "Verzaubern"
        when "UnEnch";  return "Entzaubern"
          
        when "Help1";    return ""+ # Identifying
             "Hier können nicht identifizierte Gegenstände identifiziert werden "+
             "Dafür einfach den zu identifizierenden Gegenstand mit "+
             eval(Help["Enter"])+" auswählen. Wenn das Identifizieren etwas "+
             "kostet und zu wenig Geld zur verfügung steht, wid abgebrochen"
        when "Help2";    return ""+ # Enchanting
             "Hier können nicht verzauberte Gegenstände verzaubert werden "+
             "Dafür einfach den zu verzaubernden Gegenstand mit "+
             eval(Help["Enter"])+" auswählen. Wenn das Verzaubern etwas "+
             "kostet und zu wenig Geld zur verfügung steht, wid abgebrochen"
        when "Help3";    return ""+ # UnEnchanting
             "Hier können verzauberte Gegenstände von ihrer Verzauberung "+
             "glöst werden. Dafür einfach den zu entzaubernden Gegenstand mit "+
             eval(Help["Enter"])+" auswählen. Wenn das Entzaubern etwas "+
             "kostet und zu wenig Geld zur verfügung steht, wid abgebrochen"
        end
      elsif lang == "eng"
        case code
        when "Name";    return "Identify"
        when "Enchant"; return "enchant"
        when "UnEnch";  return "Disenchant"
          
        when "Help1";    return ""+ # Identifying
             "In this scene you can identify unidentified equipment. To do so "+
             "simply press "+eval(Help["Enter"])+" on the item. If the "+
             "identifying costs money and you don't have enough on you, "+
             "it will fail."
        when "Help2";    return ""+ # Enhanting
             "In this scene you can enchant unenchanted equipment. To do so "+
             "simply press "+eval(Help["Enter"])+" on the item. If the "+
             "enchanting costs money and you don't have enough on you, "+
             "it will fail."
        when "Help3";    return ""+ # UnEnchanting
             "In this scene you can unenchant enchanted equipment. To do so "+
             "simply press "+eval(Help["Enter"])+" on the item. If the "+
             "unenchanting costs money and you don't have enough on you, "+
             "it will fail."
        end
      elsif lang == "cze"
        case code
        when "Name";    return "Identifikovat"
        when "Enchant"; return "Oèarovat"
        when "UnEnch";  return "Odèarovat"
          
        when "Help1";    return ""+ # Identifying
             "V této scénì je možné identifikovat neidentifikované vybavení."+
             "K tomu staèí nad pøedmìtem zmáèknout "+eval(Help["Enter"])+". Pokud"+
             "identifikace stojí peníze a ty jich nemáš dost,"+
             "selže."
        when "Help2";    return ""+ # Enhanting
             "V této scénì je možné oèarovat neoèarované vybavení."+
             "K tomu staèí nad pøedmìtem zmáèknout "+eval(Help["Enter"])+" Pokud"+
             "oèarovávání stojí peníze a ty jich nemáš dost,"+
             "selže."
        when "Help3";    return ""+ # UnEnchanting
             "V této scénì je možné odèarovat již oèarované vybavení."+
             "K tomu staèí nad pøedmìtem zmáèknout "+eval(Help["Enter"])+" Pokud"+
             "odèarovávání stojí peníze a ty jich nemáš dost,"+
             "selže."
        end
      end
    end
  end;end
  
################################################################################
#                                                                              #
################################################################################
  module CustomEquip
    class Tag
      attr_accessor :name
      attr_accessor :id
      attr_accessor :descr
      attr_accessor :prere
      
      attr_accessor :fix
      attr_accessor :random
      attr_accessor :random1
      attr_accessor :random2
      attr_accessor :value
      attr_accessor :b_xparam
      attr_accessor :b_sparam
      
      attr_accessor :tag_lvl
      attr_accessor :tag_c     # 0=all items, 1=only weapons, 2=only armors
      attr_accessor :tag_id    # only applies if class is chosen, id of special
                               #    item to only get this tag
      attr_accessor :tag_exclude
      attr_accessor :skills
      attr_accessor :commands
      attr_accessor :set_note
      
      def initialize(temp, id=0)
        self.name        = temp
        self.id          = id
        self.descr       = ""
        self.prere     = [0,0,0,0,0,0,0,0,0]
        self.fix         = [0,0,0,0,0,0,0,0]
        self.random1     = [0,0,0,0,0,0,0,0]
        self.random2     = [0,0,0,0,0,0,0,0]
        self.value       = [0, 1.0]
        self.b_xparam    = [0,0,0,0,0,0,0,0,0,0]
        self.b_sparam    = [0,0,0,0,0,0,0,0,0,0]
        self.tag_lvl     = 1
        self.tag_c       = 0
        self.tag_id      = 0
        self.tag_exclude = []
        self.skills      = nil
        self.commands    = []
      end
      def bonus
        temp = []
        Tidloc::Vocabs.Header("Params",$tidloc_language).count.times{|i|
          temp.push self.fix[i] + ((self.random) ? self.random[i] : 0)
        }
        return temp
      end
      def set_attr(v)
        self.fix = [0,0,v,0,v,0,v,v]
        return self
      end
      def set_rand
        temp = []
        Tidloc::Vocabs.Header("Params",$tidloc_language).count.times{|i|
          temp.push (self.random1[i] + rand(self.random2[i] - self.random1[i])).to_i
        }
        self.random = temp.clone
        return self
      end
      def set_price(v)
        self.value[0] = v
        return self
      end
      def set_price_100(v)
        self.value[1] = v
        return self
      end
      def price
        return self.value[0] ? self.value[0] : 0
      end
      def price_100
        return self.value[1] ? self.value[1] : 1.0
      end
      def xparam(id)
        b_xparam[id]
      end
      def sparam(id)
        b_sparam[id]
      end
    end
  end

  class<<self
    def Ench_lvl(lvl)
      $game_temp._tidloc_new_ench_lvl=lvl if $game_temp
    end
  end
  module CustomEquip
    class Base < Game_BaseItem
      attr_accessor :pretag
      attr_accessor :postag
      attr_accessor :multitags
      attr_accessor :special
      attr_accessor :set_id
      attr_accessor :identified
      
      def diablo_init
        self.pretag     = nil
        self.postag     = nil
        self.multitags  = []
        self.special    = nil
        self.set_id     = 0
        self.identified = !Tidloc::DiabloEquip::Use_Identify
        set_tags($game_temp._tidloc_new_ench_lvl)
        set_diablo_skills
        execute_commands("Identify") if !Tidloc::DiabloEquip::Use_Identify
      end
      
      def set_tags(item_lvl)
        return unless self.note =~ Tidloc::DiabloEquip::Notetags[0] && item_lvl > 0
        temp = Set.tag(item_lvl,self)        if $imported["Tidloc-DiabloSet"]
        self.set_id  = temp[0]               if $imported["Tidloc-DiabloSet"] && temp[1]
        self.special = temp[1].set_rand      if $imported["Tidloc-DiabloSet"] && temp[1]
        return                             if self.special
        temp = Special.tag(item_lvl,self)    if $imported["Tidloc-DiabloSpecial"]
        self.special = temp.clone.set_rand   if temp
        return                             if self.special
        temp = Multi.tag(item_lvl,self)      if $imported["Tidloc-DiabloMulti"]
        self.multitags = temp.clone          if temp.count>2
        self.multitags.compact.each{|m| m.set_rand} if temp.count>2
        return                             if self.multitags.count > 0
        temp = Pretag.tag(item_lvl,self)     if $imported["Tidloc-DiabloPretag"]
        self.pretag  = temp.clone.set_rand   if temp
        temp = Postag.tag(item_lvl,self)     if $imported["Tidloc-DiabloPosttag"]
        self.postag  = temp.clone.set_rand   if temp
      end
      def set_diablo_skills
        return unless $imported["Tidloc-CustomSkills"]
        if self.pretag && self.pretag.skills
          $game_system.tidloc_skills_count += 1
          temp = self.pretag.skills
          self.pretag.skills = Tidloc::CustomSkills::Base.new $game_system.tidloc_skills_count
          self.pretag.skills.object = $data_skills[temp]
          self.pretag.skills.commands = Tidloc::Header::SkillData(temp)[:comamnds]
        end
        if self.postag && self.postag.skills
          $game_system.tidloc_skills_count += 1
          temp = self.postag.skills
          self.postag.skills = Tidloc::CustomSkills::Base.new $game_system.tidloc_skills_count
          self.postag.skills.object = $data_skills[temp]
          self.postag.skills.commands = Tidloc::Header::SkillData(temp)[:commands]
        end
        if self.multitags.count > 0
          self.multitags.compact.each{|t|
            if t.skills
              $game_system.tidloc_skills_count += 1
              temp = s
              t.skills = Tidloc::CustomSkills::Base.new $game_system.tidloc_skills_count
              t.skills.object = $data_skills[temp]
              t.skills.commands = Tidloc::Header::SkillData(temp)[:commands]
            end
          }
        end
        if self.special && self.special.skills
          $game_system.tidloc_skills_count += 1
          temp = self.special.skills
          self.special.skills = Tidloc::CustomSkills::Base.new $game_system.tidloc_skills_count
          self.special.skills.object = $data_skills[temp]
          self.special.skills.commands = Tidloc::Header::SkillData(temp)[:commands]
        end
      end
      def identify
        return if self.identified
        self.identified = true
        $game_temp.tidloc[:item] = self
        execute_commands("Identify")
        self
      end
      def force_enchant(lvl)
        self.identified = true
        for i in 0...100
          set_tags(lvl,self)
          return true if self.special || self.multitags || self.pretag || self.postag
        end
        self.pretag = $game_temp._tidloc_diablo_pretags[rand($game_temp._tidloc_diablo_pretags.size)]
      end
      def unenchant
        $game_temp.tidloc[:item] = self
        execute_commands("UnEnchant")
        self.pretag     = nil
        self.postag     = nil
        self.multitags  = []
        self.special    = nil
        self.set_id     = 0
        self.identified = !Tidloc::DiabloEquip::Use_Identify
      end
    end
    class<<self
      def load_Tags(i)
        return Tidloc::CustomEquip::Pretag.tags  if i==0 && $imported["Tidloc-DiabloPretag"]
        return Tidloc::CustomEquip::Postag.tags  if i==1 && $imported["Tidloc-DiabloPosttag"]
        return Tidloc::CustomEquip::Special.tags if i==2 && $imported["Tidloc-DiabloSpecial"]
        return Tidloc::CustomEquip::Set.tags     if i==3 && $imported["Tidloc-DiabloSet"]
        return Tidloc::CustomEquip::Set.ids      if i==4 && $imported["Tidloc-DiabloSet"]
        return nil
      end
    end
  end
end




module Tidloc;module CustomEquip;
class Diablo_Gold_Window < Window_Gold
  def initialize(value)
    @cost      = value
    super()
    self.x     = Graphics.width/2
    refresh
  end
  def window_width
    return Graphics.width/2
  end
  def draw_currency_value(value, unit, x, y, width)
    cx = text_size(unit).width
    if Tidloc::Money_Icon
      draw_icon(Tidloc::Money_Icon,x,y)
    elsif Tidloc::Money_Img
      image=Cache.picture(Tidloc::Money_Img)
      contents.blt(x,y,image,image.rect)
    else
      change_color(system_color)
      draw_text(x, y, Graphics.width/3, line_height, unit, 2)
      change_color(normal_color)
    end
    draw_text(x, y, Graphics.width/3 - cx - 2, line_height, value, 2)
    draw_text(Graphics.width/3+10,y,Graphics.width/6,line_height," / #{@cost}") if @cost > 0
  end
end

class Identify_Window < Window_ItemList
  def include?(item)
    return false unless item.is_a?(Tidloc::CustomEquip::Base)
    return false if item.identified
    return true  if item.inv && (item.pretag || item.postag || item.special)
    return false
  end
  def current_item_enabled?
    true
  end
  def enable?(item)
    true
  end
  def col_max
    1
  end
  def process_cursor_move
    return unless cursor_movable?
    last_index = @index
    cursor_down (Input.trigger?(:DOWN))  if Input.repeat?(:DOWN)
    cursor_up   (Input.trigger?(:UP))    if Input.repeat?(:UP)
    Sound.play_cursor if @index != last_index
  end
end
class Enchant_Window < Window_ItemList
  def include?(item)
    return false unless item.is_a?(Tidloc::CustomEquip::Base)
    return false if item.pretag || item.postag || item.special || !item.inv
    return true
  end
  def current_item_enabled?
    true
  end
  def enable?(item)
    true
  end
  def col_max
    1
  end
  def process_cursor_move
    return unless cursor_movable?
    last_index = @index
    cursor_down (Input.trigger?(:DOWN))  if Input.repeat?(:DOWN)
    cursor_up   (Input.trigger?(:UP))    if Input.repeat?(:UP)
    Sound.play_cursor if @index != last_index
  end
end
class UnEnchant_Window < Window_ItemList
  def include?(item)
    return false unless item.is_a?(Tidloc::CustomEquip::Base)
    return true if item.inv && (item.pretag || item.postag || item.special)
    return false
  end
  def current_item_enabled?
    true
  end
  def enable?(item)
    true
  end
  def col_max
    1
  end
  def process_cursor_move
    return unless cursor_movable?
    last_index = @index
    cursor_down (Input.trigger?(:DOWN))  if Input.repeat?(:DOWN)
    cursor_up   (Input.trigger?(:UP))    if Input.repeat?(:UP)
    Sound.play_cursor if @index != last_index
  end
end

class Scene_Identify < Scene_Base
  def initialize(multiple = false)
    @multiple = multiple.is_a?(Integer) ? true     : multiple
    @cost =     multiple.is_a?(Integer) ? multiple : false
  end
  def start
    super
    create_item_window
    create_gold_window    if @cost
    create_info_window
    create_tidhelp_window if Tidloc::Keys["Help"]
    create_background     if Tidloc::DiabloEquip::DiabloBackground
    autoplay              if Tidloc::DiabloEquip::Diablo_BGS
  end
  def create_item_window
    @item_window = Tidloc::CustomEquip::Identify_Window.new 0,0,Graphics.width/2,Graphics.height
    @item_window.set_handler(:ok,     method(:on_item_ok))
    @item_window.set_handler(:cancel, method(:return_scene))
    @item_window.refresh
    @item_window.show.activate.index = 0 if @item_window.item_max > 0
  end
  def create_info_window
    @info_window = Tidloc::CustomEquip::Window_ShopStatus2.new(Graphics.width/2, (@cost ? @gold_window.height : 0), Graphics.width/2, Graphics.height- (@cost ? @gold_window.height : 0))
    @info_window.scene = :identify
  end
  def create_gold_window
    @gold_window   = Tidloc::CustomEquip::Diablo_Gold_Window.new @cost
  end
  def create_tidhelp_window
    @tidhelp_window = Tidloc::Window_Tid_Help.new
    text = Tidloc::Vocabs.DiabloEquip("Help1",$tidloc_language)
    @tidhelp_window.text = text
  end
  def autoplay
    RPG::BGS.new(Tidloc::DiabloEquip::Diablo_BGS,50,100).play
  end
  def create_background
    @background_window   = Window_Base.new -12,-36,Graphics.width+32,Graphics.height+64
    @background_window.z = 0
    @background_window.opacity = 0
    @background_window.draw_html 0,0,Graphics.width,Graphics.height,
    "<img=#{Tidloc::DiabloEquip::DiabloBackground}>"
  end
  def on_item_ok
    if @item_window.item
      if @cost && $game_party.gold < @cost
        Sound.play_buzzer
        @item_window.refresh
        @item_window.show.activate
        return
      end
      @item_window.item.identify
      @info_window.item = @item_window.item.clone
      @info_window.refresh
      if @multiple==true
        @item_window.refresh
        @item_window.show.activate
        @item_window.index = [@item_window.item_max-1,@item_window.index].min
        $game_party.lose_gold @cost
        @gold_window.refresh
      else
        item  = $game_temp.tidloc[:item]  if $game_temp.tidloc[:item]
        actor = $game_temp.tidloc[:actor] if $game_temp.tidloc[:actor]
        $game_party.lose_item(item, 1) if item.is_a?(RPG::Item)
        actor.pay_skill_cost(item) if item.is_a?(RPG::Skill)
        actor.pay_skill_cost(item) if $imported["Tidloc-CustomSkills"] && item.is_a?(Tidloc::CustomSkills::Base)
        @item_window.deactivate
        @info_window.activate
      end
    else
      return_scene
    end
  end
  def update_all_windows
    if @tidhelp_window.active
      if Input.trigger?(:C) || Input.trigger?(:B)
        @tidhelp_window.hide.deactivate
      elsif Input.press?(Tidloc::Keys["Scroll+"])
        @tidhelp_window.scroll_up
        @tidhelp_window.update
      elsif Input.press?(Tidloc::Keys["Scroll-"])
        @tidhelp_window.scroll_down
        @tidhelp_window.update
      end
      return
    end
    if Tidloc::Keys["Help"] && Input.trigger?(Tidloc::Keys["Help"])
      @tidhelp_window.show.activate
    end
    super
    if    Input.press?(Tidloc::Keys["Scroll-"])
      @info_window.oy = [[@info_window.oy+5,@info_window.contents_height-Graphics.height].min,0].max unless @info_window.item.is_a?(RPG::Item)
    elsif Input.press?(Tidloc::Keys["Scroll+"])
      @info_window.oy = [@info_window.oy-5,0].max unless @info_window.item.is_a?(RPG::Item)
    end
    if @info_window.active
      if Input.trigger?(:C) || Input.trigger?(:B)
        item  = $game_temp.tidloc[:item]  if $game_temp.tidloc[:item]
        actor = $game_temp.tidloc[:actor] if $game_temp.tidloc[:actor]
        if (item.is_a?(RPG::Skill) || ($imported["Tidloc-CustomSkills"] && item.is_a?(Tidloc::CustomSkills::Base))) && actor.skill_cost_payable(item)
          return_scene
          return
        elsif item.is_a?(RPG::Item) && $game_party.item_number(item) < 1
          return_scene
          return
        end
        @info_window.deactivate
        @item_window.activate
        Input.update
      return
      end
    end
  end
  def pre_terminate
    RPG::BGS.stop
  end
end

class Scene_Enchant < Scene_Base
  def initialize(ench_lvl,multiple=false,price=0)
    @lvl      = ench_lvl
    @multiple = multiple
    @price    = price
  end
  def start
    super
    create_item_window
    create_gold_window    if @price
    create_info_window
    create_tidhelp_window if Tidloc::Keys["Help"]
    create_background     if Tidloc::CustomEquip::EnchantBackground
    autoplay              if Tidloc::CustomEquip::Enchant_BGS
  end
  def create_item_window
    @item_window = Tidloc::CustomEquip::Enchant_Window.new 0,0,Graphics.width/2,Graphics.height
    @item_window.set_handler(:ok,     method(:on_enchant_ok))
    @item_window.set_handler(:cancel, method(:return_scene))
    @item_window.refresh
    @item_window.show.activate.index = 0 if @item_window.item_max > 0
  end
  def create_info_window
    @info_window = Tidloc::CustomEquip::Window_ShopStatus2.new(Graphics.width/2, (@price ? @gold_window.height : 0), Graphics.width/2, Graphics.height- (@price ? @gold_window.height : 0))
    @info_window.scene = :enchant
  end
  def create_gold_window
    @gold_window   = Tidloc::CustomEquip::Diablo_Gold_Window.new @price
  end
  def create_tidhelp_window
    @tidhelp_window = Tidloc::Window_Tid_Help.new
    text = Tidloc::Vocabs.DiabloEquip("Help2",$tidloc_language)
    @tidhelp_window.text = text
  end
  def autoplay
    RPG::BGS.new(Tidloc::DiabloEquip::Enchant_BGS,50,100).play
  end
  def create_background
    @background_window   = Window_Base.new -12,-36,Graphics.width+32,Graphics.height+64
    @background_window.z = 0
    @background_window.opacity = 0
    @background_window.draw_html 0,0,Graphics.width,Graphics.height,
    "<img=#{Tidloc::DiabloEquip::EnchantBackground}>"
  end
  def on_enchant_ok
    if @item_window.item
      if @price && $game_party.gold < @price
        Sound.play_buzzer
        @item_window.refresh
        @item_window.show.activate
        return
      end
      @item_window.item.force_enchant @lvl
      @item_window.item.execute_commands("Generate Item")
      @item_window.item.execute_commands("Identify")
      @info_window.item = @item_window.item.clone
      @info_window.refresh
      if @multiple
        @item_window.refresh
        @item_window.show.activate
        @item_window.index = [@item_window.item_max-1,@item_window.index].min
        $game_party.lose_gold @price if @price > 0
        @gold_window.refresh         if @price > 0
      else
        if $game_temp._tidloc_item_used.size > 0
          item  = $game_temp.tidloc[:item]
          actor = $game_temp.tidloc[:actor]
          $game_party.lose_item(item, 1) if item.is_a?(RPG::Item)
          actor.pay_skill_cost(item) if item.is_a?(RPG::Skill)
          actor.pay_skill_cost(item) if $imported["Tidloc-CustomSkills"] && item.is_a?(Tidloc::CustomSkills::Base)
          $game_temp._tidloc_item_used = []
        end
        @item_window.deactivate
        @info_window.activate
      end
    else
      return_scene
    end
  end
  def update_all_windows
    if @tidhelp_window.active
      if Input.trigger?(:C) || Input.trigger?(:B)
        @tidhelp_window.hide.deactivate
      elsif Input.press?(Tidloc::Keys["Scroll+"])
        @tidhelp_window.scroll_up
        @tidhelp_window.update
      elsif Input.press?(Tidloc::Keys["Scroll-"])
        @tidhelp_window.scroll_down
        @tidhelp_window.update
      end
      return
    end
    if Tidloc::Keys["Help"] && Input.trigger?(Tidloc::Keys["Help"])
      @tidhelp_window.show.activate
    end
    super
    if @info_window.active
      if Input.trigger?(:C) || Input.trigger?(:B)
        item  = $game_temp.tidloc[:item]  if $game_temp.tidloc[:item]
        actor = $game_temp.tidloc[:actor] if $game_temp.tidloc[:actor]
        if (item.is_a?(RPG::Skill) || ($imported["Tidloc-CustomSkills"] && item.is_a?(Tidloc::CustomSkills::Base))) && actor.skill_cost_payable(item)
          return_scene
          return
        elsif item.is_a?(RPG::Item) && $game_party.item_number(item) < 1
          return_scene
          return
        end
        @info_window.deactivate
        @item_window.activate
        Input.update
        return
      end
      if    Input.press?(:R)
        @info_window.oy = [[@info_window.oy+5,@info_window.contents_height-Graphics.height].min,0].max unless @info_window.item.is_a?(RPG::Item)
      elsif Input.press?(:L)
        @info_window.oy = [@info_window.oy-5,0].max unless @info_window.item.is_a?(RPG::Item)
      end
    end
  end
  def pre_terminate
    RPG::BGS.stop
  end
  def terminate
    super
    while SceneManager.scene.is_a?(Tidloc::CustomEquip::Scene_Enchant)
      SceneManager.return
    end
  end
end

class Scene_UnEnchant < Scene_Base
  def initialize(multiple=false,price=0)
    @multiple = multiple
    @price    = price
  end
  def start
    super
    create_item_window
    create_gold_window    if @price
    create_info_window
    create_tidhelp_window if Tidloc::Keys["Help"]
    create_background     if Tidloc::CustomEquip::UnEnchBackground
    autoplay              if Tidloc::CustomEquip::UnEnch_BGS
  end
  def create_item_window
    @item_window = Tidloc::CustomEquip::UnEnchant_Window.new 0,0,Graphics.width/2,Graphics.height
    @item_window.set_handler(:ok,     method(:on_unenchant_ok))
    @item_window.set_handler(:cancel, method(:return_scene))
    @item_window.refresh
    @item_window.show.activate.index = 0 if @item_window.item_max > 0
  end
  def create_info_window
    @info_window = Tidloc::CustomEquip::Window_ShopStatus2.new(Graphics.width/2, (@price ? @gold_window.height : 0), Graphics.width/2, Graphics.height- (@price ? @gold_window.height : 0))
    @info_window.scene = :unench
    @item_window.help_window = @info_window
  end
  def create_gold_window
    @gold_window   = Tidloc::CustomEquip::Diablo_Gold_Window.new @price
  end
  def create_tidhelp_window
    @tidhelp_window = Tidloc::Window_Tid_Help.new
    text = Tidloc::Vocabs.DiabloEquip("Help3",$tidloc_language)
    @tidhelp_window.text = text
  end
  def autoplay
    RPG::BGS.new(Tidloc::DiabloEquip::UnEnch_BGS,50,100).play
  end
  def create_background
    @background_window   = Window_Base.new -12,-36,Graphics.width+32,Graphics.height+64
    @background_window.z = 0
    @background_window.opacity = 0
    @background_window.draw_html 0,0,Graphics.width,Graphics.height,
    "<img=#{Tidloc::DiabloEquip::UnEnchBackground}>"
  end
  def on_unenchant_ok
    if @item_window.item
      if @price && $game_party.gold < @price
        Sound.play_buzzer
        @item_window.refresh
        @item_window.show.activate
        return
      end
      @item_window.item.unenchant
      if @multiple
        @item_window.refresh
        @item_window.show.activate
        @item_window.index = [@item_window.item_max-1,@item_window.index].min
        $game_party.lose_gold @price if @price > 0
        @gold_window.refresh         if @price > 0
      else
        if $game_temp._tidloc_item_used.size > 0
          item  = $game_temp.tidloc[:item]
          actor = $game_temp.tidloc[:actor]
          $game_party.lose_item(item, 1) if item.is_a?(RPG::Item)
          actor.pay_skill_cost(item) if item.is_a?(RPG::Skill)
          actor.pay_skill_cost(item) if $imported["Tidloc-CustomSkills"] && item.is_a?(Tidloc::CustomSkills::Base)
          $game_temp._tidloc_item_used = []
        end
        @item_window.deactivate
        @info_window.activate
      end
    else
      return_scene
    end
  end
  def update_all_windows
    if @tidhelp_window.active
      if Input.trigger?(:C) || Input.trigger?(:B)
        @tidhelp_window.hide.deactivate
      elsif Input.press?(Tidloc::Keys["Scroll+"])
        @tidhelp_window.scroll_up
        @tidhelp_window.update
      elsif Input.press?(Tidloc::Keys["Scroll-"])
        @tidhelp_window.scroll_down
        @tidhelp_window.update
      end
      return
    end
    if Tidloc::Keys["Help"] && Input.trigger?(Tidloc::Keys["Help"])
      @tidhelp_window.show.actovate
    end
    super
    if @info_window.active
      if Input.trigger?(:C) || Input.trigger?(:B)
        item  = $game_temp.tidloc[:item]
        actor = $game_temp.tidloc[:actor]
        if item.is_a?(RPG::Item) && $game_party.item_number(item) < 1
          return_scene
          return
        elsif item.is_a?(RPG::Skill) && !actor.skill_cost_payable?(item)
          return_scene
          return
        elsif $imported["Tidloc-CustomSkills"] && item.is_a?(Tidloc::CustomSkills::Base) && !actor.skill_cost_payable?(item)
          return_scene
          return
        end
        @info_window.deactivate
        @item_window.show.activate
        Input.update
        return
      end
      if    Input.press?(:R)
        @info_window.oy = [[@info_window.oy+5,@info_window.contents_height-Graphics.height].min,0].max unless @info_window.item.is_a?(RPG::Item)
      elsif Input.press?(:L)
        @info_window.oy = [@info_window.oy-5,0].max unless @info_window.item.is_a?(RPG::Item)
      end
    end
  end
  def pre_terminate
    RPG::BGS.stop
  end
  def terminate
    super
    while SceneManager.scene.is_a?(Tidloc::CustomEquip::Scene_UnEnchant)
      SceneManager.return
    end
  end
end
class<<self
  def create_tag(item,spe_id,pre_id,pos_id)
    item.special = $game_temp._tidloc_diablo_special[spe_id] if spe_id && spe_id >= 0
    item.special.set_rand if item.special
    item.pretag  = $game_temp._tidloc_diablo_pretags[pre_id] if pre_id && pre_id >= 0 && !item.special
    item.pretag.set_rand  if item.pretag
    item.postag  = $game_temp._tidloc_diablo_postags[pos_id] if pos_id && pos_id >= 0 && !item.special
    item.postag.set_rand  if item.postag
    item.identify
  end
end
end;end