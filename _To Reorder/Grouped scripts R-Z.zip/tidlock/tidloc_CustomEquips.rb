################################################################################
#    Custom Equipment 1.8                                                      #
#         by Tidloc                                  (Jun-24-17)               #
#==============================================================================#
#  Small script as start for my upcoming item scripts. This script seperates   #
#  all equippable items into 1-stacks and enables to give them requirements    #
#  to be equipped as stated below: (use notetags)                              #
#------------------------------------------------------------------------------#
#    <p-lvl *x*> need to have lvl x                                            #
#    <p-hp *x*>  need to have x Max HP                                         #
#    <p-mp *x*>  need to have x Max MP                                         #
#    <p-str *x*> need to have x Str                                            #
#    <p-mag *x*> need to have x Int                                            #
#    <p-def *x*> need to have x Def                                            #
#    <p-mdf *x*> need to have x Mag Def                                        #
#    <p-agi *x*> need to have x Agi                                            #
#    <p-luc *x*> need to have x Luck                                           #
#    <p-dex *x*> need to have x Dex                                            #
#    <p-vit *x*> need to have x Vit                                            #
#------------------------------------------------------------------------------#
#  Also this script allows to give stat boosts or penalties on your item, to   #
#  be adjusted the following way: (also in the notetag, may be negative)       #
#------------------------------------------------------------------------------#
#    <b-hp *x*>  gives x Max HP                                                #
#    <b-mp *x*>  gives x Max MP                                                #
#    <b-str *x*> gives x Str                                                   #
#    <b-mag *x*> gives x Int                                                   #
#    <b-def *x*> gives x Def                                                   #
#    <b-mdf *x*> gives x Mag Def                                               #
#    <b-agi *x*> gives x Agi                                                   #
#    <b-luc *x*> gives x Luck                                                  #
#    <b-dex *x*> gives x Dex                                                   #
#    <b-vit *x*> gives x Vit                                                   #
#    <b%-hp *x*>  gives x% Max HP                                              #
#    <b%-mp *x*>  gives x% Max MP                                              #
#    <b%-str *x*> gives x% Str                                                 #
#    <b%-mag *x*> gives x% Int                                                 #
#    <b%-def *x*> gives x% Def                                                 #
#    <b%-mdf *x*> gives x% Mag Def                                             #
#    <b%-agi *x*> gives x% Agi                                                 #
#    <b%-luc *x*> gives x% Luck                                                #
#    <b%-dex *x*> gives x% Dex                                                 #
#    <b%-vit *x*> gives x% Vit                                                 #
#    <br-hp *x*,*y*>  gives random Max HP  (between x and y)                   #
#    <br-mp *x*,*y*>  gives random Max MP  (between x and y)                   #
#    <br-str *x*,*y*> gives random Str     (between x and y)                   #
#    <br-mag *x*,*y*> gives random Int     (between x and y)                   #
#    <br-def *x*,*y*> gives random Def     (between x and y)                   #
#    <br-mdf *x*,*y*> gives random Mag Def (between x and y)                   #
#    <br-agi *x*,*y*> gives random Agi     (between x and y)                   #
#    <br-luc *x*,*y*> gives random Luck    (between x and y)                   #
#    <br-dex *x*,*y*> gives random Dex     (between x and y)                   #
#    <br-vit *x*,*y*> gives random Vit     (between x and y)                   #
#    <br%-hp *x*,*y*>  gives random % to Max HP  (between x and y)             #
#    <br%-mp *x*,*y*>  gives random % to Max MP  (between x and y)             #
#    <br%-str *x*,*y*> gives random % to Str     (between x and y)             #
#    <br%-mag *x*,*y*> gives random % to Int     (between x and y)             #
#    <br%-def *x*,*y*> gives random % to Def     (between x and y)             #
#    <br%-mdf *x*,*y*> gives random % to Mag Def (between x and y)             #
#    <br%-agi *x*,*y*> gives random % to Agi     (between x and y)             #
#    <br%-luc *x*,*y*> gives random % to Luck    (between x and y)             #
#    <br%-dex *x*,*y*> gives random % to Dex     (between x and y)             #
#    <br%-vit *x*,*y*> gives random % to Vit     (between x and y)             #
#  Here now the xparam and sparam, you can adjust for each item. be aware you  #
#  should know what you do on these ;)                                         #
#    <b-hit *x*> gives x % hit rate                                            #
#    <b-eva *x*> gives x % evasion rate                                        #
#    <b-cri *x*> gives x % critical rate                                       #
#    <b-cev *x*> gives x % critical evasion rate                               #
#    <b-mev *x*> gives x % magical evasion rate                                #
#    <b-mrf *x*> gives x % magical reflection rate                             #
#    <b-cnt *x*> gives x % counter attack rate                                 #
#    <b-hrg *x*> gives x % HP regeneration rate                                #
#    <b-mrg *x*> gives x % MP regeneration rate                                #
#    <b-trg *x*> gives x % TP regeneration rate                                #
#    <b-tgr *x*> gives x % target rate                                         #
#    <b-grd *x*> gives x % guard effect rate                                   #
#    <b-rec *x*> gives x % recovery effect rate                                #
#    <b-pha *x*> gives x % Pharmacology                                        #
#    <b-mcr *x*> gives x % MP cost rate                                        #
#    <b-tcr *x*> gives x % TP charge rate                                      #
#    <b-pdr *x*> gives x % Physical damage rate                                #
#    <b-mdr *x*> gives x % Magical damage rate                                 #
#    <b-fdr *x*> gives x % floor damage rate                                   #
#    <b-exr *x*> gives x % experience rate                                     #
#------------------------------------------------------------------------------#
#  Since Version 1.31 you can add skills to be bound to equipment via the      #
#  notetag:                                                                    #
#     <b-skill *x*> gives the skill with the database ID *x* to the player and #
#                   will only remove that skill again, if the last item was    #
#                   unequipped, that granted that skill.                       #
#------------------------------------------------------------------------------#
#  explanation of constants used:                                              #
#    Use_New_Info ... adjusts the Item-,Equipment- and Shop scene so all       #
#                     information is shown in the new windows.                 #
#    Attr_Color ..... defines in which solor the attributes shall be written   #
#    System_Color ... defines in which color titles are written                #
#    Pos_Color ...... defines in which color positive changes are written      #
#    Neg_Color ...... defines in which color negative changes are written      #
#    Deactivate_PG .. true/false defines if you deactivate the PAGE UP and     #
#                     PAGE DOWN Keys in the item windows. (to only scroll with #
#                     these buttons then)                                      #
#    Use_Item_Group . true/false if you want the possibility in item menus     #
#                     to group equips of the same database item.               #
#    Use_Require .... an array in which you can dafine which attributes will   #
#                     be displayed in the Prerequisite section of the item     #
#                     description. allowed attributes:                         #
#                       "" "HP" "MP" "STR" "MAG" "DEF" "MDF" "AGI" "LUC" "LVL" #
#    Use_Bonus ...... an array in which you can dafine which attributes will   #
#                     be displayed in the bonus section of the item            #
#                     description. allowed attributes:                         #
#                       "" "HP" "MP" "STR" "MAG" "DEF" "MDF" "AGI" "LUC"       #
#    Attr_Icons ..... an array for the attributes you want to display, where   #
#                     the attribute will be used one after the other (even if  #
#                     you haven't defined it in the database)                  #
#------------------------------------------------------------------------------#
#  you don't have to use all attributes in the prerequisite or bonus display.  #
#  just insert whichever you need in whichever allignment you want to display  #
#  them. listing non-allowed attributes or empty strings will lead to nothing  #
#  being display at that place.                                                #
#==============================================================================#
#  now to something more complex in some enhancements: COMMANDS                #
#  command can have an impact on everythin the item can do. for example:       #
#     command.push ["equip","$game_party.members.each(|x| x.add_state(1))"]    #
#     command.push ["equip","self.pretag.nil"]                                 #
#  with htese two commands, as soon as you equip the item all party members    #
#  become the state with the id 1 and then the pretag will be erased from the  #
#  object. So, Ruby knowledge is needed to programm something deep here.       #
#  implemented tags so far:                                                    #
#     "start" ..... command for when the item is generated                     #
#     "equip" ..... command for when the item will be equipped                 #
#     "attach" .... command for when the corresponding gets attached (e.g.     #
#                   socket insertionts)                                        #
#==============================================================================#
#  Feel free to use this script, but please credit me for my work! ^__^        #
################################################################################

$imported = {} if $imported.nil?
$imported["Tidloc-CustomEquip"] = [1,8,0]
$needed   = [] if $needed.nil?
$needed.push ["Tidloc-Header",[2,14,1],true,"Tidloc's Custom Equipment"]
$needed.push ["HTML-tagging",[1,5,2],true,"Tidloc's Custom Equipment"]

module Tidloc
  module CustomEquip
    
    Use_New_Info_shop  = true
    Use_New_Info_item  = true
    Use_New_Info_equip = true
    
    Attr_Color         = "#ff4500"
    System_Color       = "#4169e1"
    Pos_Color          = "#32cd32"
    Neg_Color          = "#dc143c"
    Deactivate_PG      = true
    Use_Item_Group     = true
    Exp_Rate           = 1

    Disp_Attr    = ["HP",
                    "MP",
                    "STR",
                    "MAG",
                    "AGI",
                    "DEX",
                    "VIT",
                    "LUC"]
    
    Use_Require  = ["STR","MAG",
                    "AGI","DEX",
                    "VIT","LUC"]
                    
    Use_Bonus    = [ "HP",nil,
                     "MP",nil,
                    "STR","MAG",
                    "AGI","DEX",
                    "VIT","LUC"]
                    
                    
    Attrib_Icons =[115, # e.g. physical
                   117, # e.g. magic
                   8560, # e.g. fire
                   8563, # e.g. water
                   8564, # e.g. earth
                   8565, # e.g. air
                   8561,
                   8562,
                   8566,
                   8567]
  end
  module Vocabs;class<<self
    def CustomEquip(code,lang)
      if    lang == "ger"
        case code
        when "Name"; return ""
        when "Desc"; return ["Name","Beschreibung","Änderungen","Erfahrung",
                             "Voraussetzung","Bonus","Elementare Verteidigung"]
        when "Set";  return "<color=cyan>Set Gegenstand!</color>"
          
        when "HP";  return " LP"
        when "MP";  return " GP"
        when "TP";  return " TP"
        when "STR"; return "Str"
        when "MAG"; return "Int"
        when "DEF"; return "Vrt"
        when "MDF"; return "MVt"
        when "AGI"; return "Agi"
        when "LUC"; return "Glk"
        when "DEX"; return "Ges"
        when "VIT"; return "Vit"
        when "LVL"; return "LVL"
        when "HIT"; return "Hit"
        when "EVA"; return "Eva"
        when "CRI"; return "Cti"
        when "CEV"; return "C-Ev"
        when "MEV"; return "M-Ev"
        when "MRF"; return "M-Rf"
        when "CNT"; return "Coun"
        when "HRG"; return "HP-R"
        when "MRG"; return "MP-R"
        when "TPR"; return "TP-T"
        when "TGR"; return "Targ"
        when "GRD"; return "Guar"
        when "REC"; return "Rec"
        when "PHA"; return "Phar"
        when "MCR"; return "MP-C"
        when "TCR"; return "TP-C"
        when "PDR"; return "P-DR"
        when "MDR"; return "M-DR"
        when "FDR"; return "F-DR"
        when "EXR"; return "ExpR"
          
        when "All"; return "Alle"
        end
      elsif lang == "eng"
        case code
        when "Name";return ""
        when "Desc"; return ["Name","Description","Changes","Experience",
                             "Prerequisite","Bonus","Element Defense"]
        when "Set";  return "<color=cyan>Set item!</color>"
        
        when "HP";  return " HP"
        when "MP";  return " SP"
        when "TP";  return " TP"
        when "STR"; return "Str"
        when "MAG"; return "Int"
        when "DEF"; return "Def"
        when "MDF"; return "MDf"
        when "AGI"; return "Agi"
        when "LUC"; return "Luc"
        when "DEX"; return "Dex"
        when "VIT"; return "Vit"
        when "LVL"; return "LVL"
        when "HIT"; return "Hit"
        when "EVA"; return "Eva"
        when "CRI"; return "Cti"
        when "CEV"; return "C-Ev"
        when "MEV"; return "M-Ev"
        when "MRF"; return "M-Rf"
        when "CNT"; return "Coun"
        when "HRG"; return "HP-R"
        when "MRG"; return "MP-R"
        when "TPR"; return "TP-T"
        when "TGR"; return "Targ"
        when "GRD"; return "Guar"
        when "REC"; return "Rec"
        when "PHA"; return "Phar"
        when "MCR"; return "MP-C"
        when "TCR"; return "TP-C"
        when "PDR"; return "P-DR"
        when "MDR"; return "M-DR"
        when "FDR"; return "F-DR"
        when "EXR"; return "ExpR"
          
        when "All"; return "All"
        end
      end
    end
  end;end
################################################################################
#                                                                              #
################################################################################
  module CustomEquip
    class Dummy_Damage
      attr_accessor :to_hp
      attr_accessor :to_mp
      attr_accessor :drain
      attr_accessor :recover
      attr_accessor :variance
      attr_accessor :element_id
      attr_accessor :critical
      attr_accessor :none
      def initialize
        self.to_hp      = false
        self.to_mp      = false
        self.drain      = false
        self.recover    = false
        self.variance   = 0
        self.element_id = 0
        self.critical   = false
        self.none       = true
      end
      def to_hp?;   to_hp;   end
      def to_mp?;   to_mp;   end
      def drain?;   drain;   end
      def recover?; recover; end
      def none?;    none;    end
      def eval(user,target,var)
      end
    end
    
    class Base < Game_BaseItem
      attr_accessor :item
      attr_accessor :nid
      attr_accessor :inv
      attr_accessor :br_param
      attr_accessor :b2r_param
      attr_accessor :b_xparam
      attr_accessor :b_sparam
      attr_accessor :commands
      attr_accessor :uses
      attr_accessor :item_lvl
      attr_accessor :lvl_param
      attr_accessor :add_note
      attr_accessor :add_descr
      attr_accessor :add_descr2
      attr_accessor :CustomSkill
      
      def initialize(item_lvl = 0)
        self.inv = true
        self.lvl_param  = [0] *10   if self.lvl_param.nil?
        self.br_param   = [0] *10   if self.br_param.nil?
        self.b2r_param  = [100] *10 if self.b2r_param.nil?
        self.b_xparam   = [0] *10   if self.b_xparam.nil?
        self.b_sparam   = [0] *10   if self.b_sparam.nil?
        self.commands   = []        if self.commands.nil?
        self.uses       = 0         if self.uses.nil?
        self.add_note   = []        if self.add_note.nil?
        self.add_descr  = []        if self.add_descr.nil?
        self.add_descr2 = []        if self.add_descr2.nil?
        self.CustomSkill = nil      if self.CustomSkill.nil?
        refining_init if $imported["Tidloc-CustomRefining"]
        exp_init      if $imported["Tidloc-ExpEquip"]
        diablo_init   if $imported["Tidloc-DiabloEquip"]
        socket_init   if $imported["Tidloc-SocketEquip"]
        skill_init    if $imported["Tidloc-CustomSkills"]
        dura_init     if $imported["Tidloc-CustomDura"]
        megaten_init  if $imported["Tidloc-CustomMegaten"]
        shopban_init  if $imported["Tidloc-CustomShopId"]
        $game_temp.tidloc[:item] = self
        execute_commands("Generate Item")
        calculate_item_lvl
      end
      
      
      def extra_phys_def
        dmg=0
        tag = "Defense"
        self.commands.each{|c| dmg += eval(c[1]) if c[0]==tag}
        self.pretag.commands.each{|c| dmg += eval(c[1]) if c[0]==tag}  if $imported["Tidloc-DiabloEquip"] && self.pretag
        self.postag.commands.each{|c| dmg += eval(c[1]) if c[0]==tag}  if $imported["Tidloc-DiabloEquip"] && self.postag
        self.special.commands.each{|c| dmg += eval(c[1]) if c[0]==tag} if $imported["Tidloc-DiabloEquip"] && self.special
        if $imported["Tidloc-SocketEquip"]
          self.sockets.compact.each{|s|
            if s
              s.commands.each{|c| dmg += eval(c[1]) if c[0]==tag}
            end
          } 
        end
        if $imported["Tidloc-ExpEquip"] && self._exp_enabled && self._exp_lvl > 0
          for i in 1..self._exp_lvl
            if self.note =~ /#{Tidloc::Exp_Equip::Notetags[:exp_lvl_def].gsub("|",i.to_s)}/i
              dmg += eval($1)
            end
          end
        end
        return dmg
      end
      def extra_mag_def
        dmg=0
        tag = "MDefense"
        self.commands.each{|c| dmg += eval(c[1]) if c[0]==tag}
        self.pretag.commands.each{|c| dmg += eval(c[1]) if c[0]==tag}  if $imported["Tidloc-DiabloEquip"] && self.pretag
        self.postag.commands.each{|c| dmg += eval(c[1]) if c[0]==tag}  if $imported["Tidloc-DiabloEquip"] && self.postag
        self.special.commands.each{|c| dmg += eval(c[1]) if c[0]==tag} if $imported["Tidloc-DiabloEquip"] && self.special
        if $imported["Tidloc-SocketEquip"]
          self.sockets.compact.each{|s|
            if s
              s.commands.each{|c| dmg += eval(c[1]) if c[0]==tag}
            end
          } 
        end
        if $imported["Tidloc-ExpEquip"] && self._exp_enabled && self._exp_lvl > 0
          for i in 1..self._exp_lvl
            if self.note =~ /#{Tidloc::Exp_Equip::Notetags[:exp_lvl_mdef].gsub("|",i.to_s)}/i
              dmg += eval($1)
            end
          end
        end
        return dmg
      end
      def extra_phys_damage
        dmg=0
        tag = "Damage"
        self.commands.each{|c| dmg += eval(c[1]) if c[0]==tag}
        self.pretag.commands.each{|c| dmg += eval(c[1]) if c[0]==tag}  if $imported["Tidloc-DiabloEquip"] && self.pretag
        self.postag.commands.each{|c| dmg += eval(c[1]) if c[0]==tag}  if $imported["Tidloc-DiabloEquip"] && self.postag
        self.special.commands.each{|c| dmg += eval(c[1]) if c[0]==tag} if $imported["Tidloc-DiabloEquip"] && self.special
        if $imported["Tidloc-SocketEquip"]
          self.sockets.compact.each{|s|
            if s
              s.commands.each{|c| dmg += eval(c[1]) if c[0]==tag}
            end
          } 
        end
        if $imported["Tidloc-ExpEquip"] && self._exp_enabled && self._exp_lvl > 0
          for i in 1..self._exp_lvl
            if self.note =~ /#{Tidloc::Exp_Equip::Notetags[:exp_lvl_dmg].gsub("|",i.to_s)}/i
              dmg += eval($1)
            end
          end
        end
        return dmg
      end
      def extra_mag_damage
        dmg=0
        tag = "MDamage"
        self.commands.each{|c| dmg += eval(c[1]) if c[0]==tag}
        self.pretag.commands.each{|c| dmg += eval(c[1]) if c[0]==tag}  if $imported["Tidloc-DiabloEquip"] && self.pretag
        self.postag.commands.each{|c| dmg += eval(c[1]) if c[0]==tag}  if $imported["Tidloc-DiabloEquip"] && self.postag
        self.special.commands.each{|c| dmg += eval(c[1]) if c[0]==tag} if $imported["Tidloc-DiabloEquip"] && self.special
        if $imported["Tidloc-SocketEquip"]
          self.sockets.compact.each{|s|
            if s
              s.commands.each{|c| dmg += eval(c[1]) if c[0]==tag}
            end
          } 
        end
        if $imported["Tidloc-ExpEquip"] && self._exp_enabled && self._exp_lvl > 0
          for i in 1..self._exp_lvl
            if self.note =~ /#{Tidloc::Exp_Equip::Notetags[:exp_lvl_mdmg].gsub("|",i.to_s)}/i
              dmg += eval($1)
            end
          end
        end
        return dmg
      end
      def skill_init
        if note =~ /<b-skill ([0-9]+)>/i
          $game_system.tidloc_skills_count += 1
          self.CustomSkill = Tidloc::CustomSkills::Base.new $game_system.tidloc_skills_count
          self.CustomSkill.object   = $data_skills[$1.to_i]
          self.CustomSkill.commands = Tidloc::Header::SkillData($1.to_i)[:commands]
        end
      end
      
      def calculate_item_lvl
        lvl  = -1
        lvl  = self._exp_lvl-1      if $imported["Tidloc-ExpEquip"]    && self._exp_enabled
        lvl += self.pretag.tag_lvl  if $imported["Tidloc-DiabloEquip"] && self.pretag
        lvl += self.postag.tag_lvl  if $imported["Tidloc-DiabloEquip"] && self.postag
        lvl += self.special.tag_lvl if $imported["Tidloc-DiabloEquip"] && self.special
        lvl += 2**self.sockets.size if $imported["Tidloc-SocketEquip"] && self.sockets && !self.special
        
        self.item_lvl = [lvl,1].max
      end
      
      def is_vanilla?
        if    $imported["Tidloc-DiabloEquip"] && (self.pretag || self.postag || self.special)
          false
        elsif $imported["Tidloc-SocketEquip"] && self.sockets[0]
          false
        elsif $imported["Tidloc-ExpEquip"]    && self._exp_enabled
          false
        else
          true
        end
      end
      
      alias original_object object
      def object
        if self.item
          if self.item.is_a?(Game_BaseItem)
            return self.item.object
          else
            self.item
          end
        else
          return nil
        end
      end
      
      def id;                     self.item ? self.item.id:                    0; end
      def icon_index;             self.item ? self.item.icon_index:            0; end
      def key_item?;              self.item ? self.item.key_item?:         false; end
      def etype_id;               self.item.etype_id;               end
      def features;               self.item.features;               end
      def wtype_id;               self.item.wtype_id;               end
      def atype_id;               self.item.atype_id;               end
      def performance;            self.item.performance;            end
      def damage;                 self.item.damage;                 end
      def skill;                  self.item.skill;                  end
      def is_weapon?;             false;                            end
      def is_armor?;              false;                            end
      def max_limit;              1;                                end
      def animation_id;           self.item.animation_id;           end
# "Use"-modifications, starting with header 1.12.2:
      def for_friend?;            self.item.for_friend?;            end
      def for_opponent?;          self.item.for_opponent?;          end
      def for_user?;              self.item.for_user?;              end
      def for_one?;               self.item.for_one?;               end
      def for_all?;               self.item.for_all?;               end
      def for_dead_friend?;       self.item.for_dead_friend?;       end
      def repeats;                1;                                end
      def success_rate;           100;                              end
      def physical?;              false;                            end
      def magical?;               false;                            end
      def tp_gain;                0;                                end
# Tusikhimes modifications:
      def load_notetag_atk_element_modifiers
        if self.item; self.item.load_notetag_atk_element_modifiers
        else; end
      end
      def atk_element_modifiers
        if self.item; self.item.atk_element_modifiers
        else; end
      end 
# Yanfly's Steal:
      def steal_type;             self.item.steal_type;             end
      def steal_rate;             self.item.steal_rate;             end
      def steal_kind;             self.item.steal_kind;             end
# Ao no Kiseki procedures:
      def operate_time(bat);      self.item.operate_time(bat);      end
      def operate_formula;        self.item.operate_formula;        end
      def stiff_time(bat);        self.item.stiff_time(bat);        end
      def stiff_formula;          self.item.stiff_formula;          end
      def delay_attack?;          self.item.delay_attack?;          end
      def delay_count(bat);       self.item.delay_count(bat);       end
      def delay_formula;          self.item.delay_formula;          end
      def delay_percent(bat);     self.item.delay_percent(bat);     end
      def delay_percent_formula;  self.item.delay_percent_formula;  end
      def cancel_attack?;         self.item.cancel_attack?;         end
      def cancel?;                self.item.cancel?;                end
      def cancel_percent;         self.item.cancel_percent;         end
      def cancel_percent_formula; self.item.cancel_percent_formula; end
      def anti_delay?;            self.item.anti_delay?;            end
      def anti_cancel?;           self.item.anti_cancel?;           end
      def operate_states;         self.item.operate_states;         end
      def prepare_msg;            self.item.prepare_msg;            end
      def operate_states_for_friends_all?
        self.item.operate_states_for_friends_all?
      end
      def operate_states_for_opponents_all?
        self.operate_states_for_opponents_all?
      end
        
      
      def note
        text = ""
        self.add_note.each{|n|
          text += "#{n[1]}\n"
        }
        text += self.item.note if self.item
        text
      end
      def all_notes
        text = note
#~         text += self.pretag.note  if self.pretag
#~         text += self.postag.note  if self.postag
#~         text += self.special.note if self.special
#~         self.multitags.compact.each{|t|
#~           text += t.note
#~         }
        self.sockets.compact.each{|s|
          text += s.add_notes
        }
        
        text
      end
      
      def gain_exp(exp)
        $game_temp.tidloc[:item] = self
        if $imported["Tidloc-ExpEquip"]
          item_gain_exp(exp)
        end
        if Tidloc.Version("Tidloc-SocketEquip",[1,4,0])
          self.sockets.each{|s|
            s.gain_exp(exp)
          }
        end
      end
      
      if $imported["YEA-ElementReflect"]
        def element_reflect;    self.item.element_reflect;    end
      end
      if $imported["YEA-AceEquipEngine"]
        def sealed_equip_type; self.item.sealed_equip_type; end
        def fixed_equip_type;  self.item.fixed_equip_type;  end
      end
      if $imported["YEA-WeaponAttackReplace"]
        def attack_skill
          if self.item.note =~ YEA::REGEXP::BASEITEM::ATTACK_SKILL
            return $1.to_i
          else 
            return 1
          end
        end
      end
      
      def effects
        return self.item.effects if self.item.is_a?(RPG::Item)
        return []
      end
      def price
        return 0 unless self.item
        temp  = self.item.price
        temp *= $1.to_f**self._exp_lvl if $imported["Tidloc-ExpEquip"] && self._exp_enabled && self.note =~ /<exp-price (.*)>/i
        if $imported["Tidloc-DiabloEquip"]
          if self.special
            temp = self.special.price
            temp *= $1.to_f**self._exp_lvl if $imported["Tidloc-ExpEquip"] && self._exp_enabled && self.note =~ /<exp-price (.*)>/i
            return temp
          end
          temp += self.pretag.price     if self.pretag
          temp += self.postag.price     if self.postag
        end
        if $imported["Tidloc-SocketEquip"]          
          for i in self.sockets
            temp += i.price
          end
        end
        if $imported["Tidloc-DiabloEquip"]
          temp *= self.pretag.price_100 if self.pretag
          temp *= self.postag.price_100 if self.postag
        end
        return temp.to_i
      end
      def name
        return "" unless self.item
        temp = ""
        if $imported["HTML-tagging"]
          temp  = Tidloc::SocketEquip::Color_Socket     if $imported["Tidloc-SocketEquip"]    && self.sockets.size > 0
          temp  = Tidloc::DiabloEquip::Color_ench       if (($imported["Tidloc-DiabloPretag"] && self.pretag) || ($imported["Tidloc-DiabloPosttag"] && self.postag))
          temp  = Tidloc::DiabloEquip::Color_multi      if $imported["Tidloc-DiabloMulti"]    && self.multitags.compact.count > 2
          temp  = Tidloc::DiabloEquip::Color_special    if $imported["Tidloc-DiabloSpecial"]  && self.special
          temp  = Tidloc::DiabloEquip::Color_set        if $imported["Tidloc-DiabloSet"]      && self.set_id > 0
        end
        if self.identified
          temp += Tidloc::Vocabs.MultiEquip("Prefix",$tidloc_language) if self.multitags.compact.count > 2
          temp += Tidloc::CustomEquip::Set.ids[self.set_id].name+" "   if self.set_id > 0
          temp += Bitmap.html_decode(self.special.name)                if self.special
          temp += Bitmap.html_decode(self.pretag.name)                 if self.pretag
        end
        if temp.length > 0 && Bitmap.html_decode(temp[-2]) != "-" && (self.pretag || self.multitags.compact.count > 2)
          temp += Tidloc::Vocabs.Header("Genders",$tidloc_language)[self.item.gender] + " "
        end
        if !$imported["Tidloc-DiabloSpecial"] || (self.special && !self.identified) || !self.special
          if (self.item.is_a?(RPG::Weapon) && $imported["Tidloc-WeaponData"]) ||
             (self.item.is_a?(RPG::Armor)  && $imported["Tidloc-ArmorData"])
            temp += Bitmap.html_decode(self.item.name_html)
          else
            temp += self.item.name
          end
        end
        temp += " "+Bitmap.html_decode(self.postag.name) if $imported["Tidloc-DiabloPosttag"] && self.postag && self.identified
        temp += self.socket_name       if $imported["Tidloc-SocketEquip"] && self.sockets.size > 0
        temp += "</color>"             if $imported["HTML-tagging"] && ($imported["Tidloc-DiabloPretag"] || $imported["Tidloc-DiabloPosttag"] || $imported["Tidloc-DiabloSpecial"]) && (self.pretag || self.postag || self.special)
        return temp 
      end
      
      
      def elemental_rate(id)     
        if self.item 
          temp = self.item.elemental_rate(id)
        else
          temp = 1
        end
        element_name = $data_system.elements.map {|name| name.downcase}[id]
        temp *= eval($1)/100.0 if note =~ /<ele-def #{element_name} ([0-9]+)>/i
        temp
      end
      
      def socket_name
        temp = ""
        return temp unless $imported["Tidloc-SocketEquip"] && self.sockets.size > 0
        self.sockets.compact.map{|x| x.name if x.is_a?(Tidloc::CustomEquip::Socket) && x.used}.compact.each{|x| temp+=x}
        return temp
      end
      
      def p_level
        temp  = 0
        temp += $1.to_i if self.item.note =~ /<p-lvl (.*)>/i
        if $imported["Tidloc-DiabloEquip"]          
          return  self.special.prere[0] if self.special && self.identified
          temp += self.pretag.prere[0] if self.pretag && self.identified
          temp += self.postag.prere[0] if self.postag && self.identified
        end
        if $imported["Tidloc-SocketEquip"]
          for i in 0...self.sockets.size
            if i == self.temp_id
              temp += self.temp_socket.prere[0]
            else
              temp += self.sockets[i].prere[0] if self.sockets[i].used
            end
          end
        end
        return temp
      end
      def p_hp
        temp  = 0
        temp += $1.to_i if self.item.note =~ /<p-hp (.*)>/i
        if $imported["Tidloc-DiabloEquip"]          
          return  self.special.prere[1] if self.special && self.identified
          temp += self.pretag.prere[1] if self.pretag && self.identified
          temp += self.postag.prere[1] if self.postag && self.identified
        end
        if $imported["Tidloc-SocketEquip"]
          for i in 0...self.sockets.size
            if i == self.temp_id
              temp += self.temp_socket.prere[1]
            else
              temp += self.sockets[i].prere[1] if self.sockets[i].used
            end
          end
        end
        return temp
      end
      def p_mp
        temp  = 0
        temp += $1.to_i if self.item.note =~ /<p-mp (.*)>/i
        if $imported["Tidloc-DiabloEquip"]          
          return  self.special.prere[2] if self.special && self.identified
          temp += self.pretag.prere[2] if self.pretag && self.identified
          temp += self.postag.prere[2] if self.postag && self.identified
        end
        if $imported["Tidloc-SocketEquip"]
          for i in 0...self.sockets.size
            if i == self.temp_id
              temp += self.temp_socket.prere[2]
            else
              temp += self.sockets[i].prere[2] if self.sockets[i].used
            end
          end
        end
        return temp
      end
      def p_str
        temp  = 0
        temp += $1.to_i if self.item.note =~ /<p-str (.*)>/i
        if $imported["Tidloc-DiabloEquip"]          
          return  self.special.prere[3] if self.special && self.identified
          temp += self.pretag.prere[3] if self.pretag && self.identified
          temp += self.postag.prere[3] if self.postag && self.identified
        end
        if $imported["Tidloc-SocketEquip"]
          for i in 0...self.sockets.size
            if i == self.temp_id
              temp += self.temp_socket.prere[3]
            else
              temp += self.sockets[i].prere[3] if self.sockets[i].used
            end
          end
        end
        return temp
      end
      def p_def
        temp  = 0
        temp += $1.to_i if self.item.note =~ /<p-def (.*)>/i
        if $imported["Tidloc-DiabloEquip"]          
          return  self.special.prere[4] if self.special && self.identified
          temp += self.pretag.prere[4] if self.pretag && self.identified
          temp += self.postag.prere[4] if self.postag && self.identified
        end
        if $imported["Tidloc-SocketEquip"]
          for i in 0...self.sockets.size
            if i == self.temp_id
              temp += self.temp_socket.prere[4]
            else
              temp += self.sockets[i].prere[4] if self.sockets[i].used
            end
          end
        end
        return temp
      end
      def p_int
        temp  = 0
        temp += $1.to_i if self.item.note =~ /<p-mag (.*)>/i
        if $imported["Tidloc-DiabloEquip"]          
          return  self.special.prere[5] if self.special && self.identified
          temp += self.pretag.prere[5] if self.pretag && self.identified
          temp += self.postag.prere[5] if self.postag && self.identified
        end
        if $imported["Tidloc-SocketEquip"]
          for i in 0...self.sockets.size
            if i == self.temp_id
              temp += self.temp_socket.prere[5]
            else
              temp += self.sockets[i].prere[5] if self.sockets[i].used
            end
          end
        end
        return temp
      end
      def p_mdf
        temp  = 0
        temp += $1.to_i if self.item.note =~ /<p-mdf (.*)>/i
        if $imported["Tidloc-DiabloEquip"]          
          return  self.special.prere[6] if self.special && self.identified
          temp += self.pretag.prere[6] if self.pretag && self.identified
          temp += self.postag.prere[6] if self.postag && self.identified
        end
        if $imported["Tidloc-SocketEquip"]
          for i in 0...self.sockets.size
            if i == self.temp_id
              temp += self.temp_socket.prere[6]
            else
              temp += self.sockets[i].prere[6] if self.sockets[i].used
            end
          end
        end
        return temp
      end
      def p_agi
        temp  = 0
        temp += $1.to_i if self.item.note =~ /<p-agi (.*)>/i
        if $imported["Tidloc-DiabloEquip"]          
          return  self.special.prere[7] if self.special && self.identified
          temp += self.pretag.prere[7] if self.pretag && self.identified
          temp += self.postag.prere[7] if self.postag && self.identified
        end
        if $imported["Tidloc-SocketEquip"] 
          for i in 0...self.sockets.size
            if i == self.temp_id
              temp += self.temp_socket.prere[7]
            else
              temp += self.sockets[i].prere[7] if self.sockets[i].used
            end
          end
        end
        return temp
      end
      def p_luc
        temp  = 0
        temp += $1.to_i if self.item.note =~ /<p-luc (.*)>/i
        if $imported["Tidloc-DiabloEquip"]          
          return  self.special.prere[8] if self.special && self.identified
          temp += self.pretag.prere[8] if self.pretag && self.identified
          temp += self.postag.prere[8] if self.postag && self.identified
        end
        if $imported["Tidloc-SocketEquip"]
          for i in 0...self.sockets.size
            if i == self.temp_id
              temp += self.temp_socket.prere[8]
            else
              temp += self.sockets[i].prere[8] if self.sockets[i].used
            end
          end
        end
        return temp
      end
      def p_dex
        temp  = 0
        temp += $1.to_i if self.item.note =~ /<p-dex (.*)>/i
        if $imported["Tidloc-DiabloEquip"]          
          return  self.special.prere[9] if self.special && self.identified
          temp += self.pretag.prere[9] if self.pretag && self.identified
          temp += self.postag.prere[9] if self.postag && self.identified
        end
        if $imported["Tidloc-SocketEquip"]
          for i in 0...self.sockets.size
            if i == self.temp_id
              temp += self.temp_socket.prere[9]
            else
              temp += self.sockets[i].prere[9] if self.sockets[i].used
            end
          end
        end
        return temp
      end
      def p_vit
        temp  = 0
        temp += $1.to_i if self.item.note =~ /<p-vit (.*)>/i
        if $imported["Tidloc-DiabloEquip"]          
          return  self.special.prere[10] if self.special && self.identified
          temp += self.pretag.prere[10] if self.pretag && self.identified
          temp += self.postag.prere[10] if self.postag && self.identified
        end
        if $imported["Tidloc-SocketEquip"]
          for i in 0...self.sockets.size
            if i == self.temp_id
              temp += self.temp_socket.prere[10]
            else
              temp += self.sockets[i].prere[10] if self.sockets[i].used
            end
          end
        end
        return temp
      end
      def params
        temp = [0] *Tidloc::Vocabs.Header("Params",$tidloc_language).count
        8.times{|i|
          temp[i] = self.item.params[i] + b_param[i] + br_param[i]
        }
        for i in 8...Tidloc::Vocabs.Header("Params",$tidloc_language).count
          temp[i] = b_param[i] + br_param[i]
        end
        return temp
      end
      def description
        return "" unless self.item
        item = $data_weapons[self.item.id] if self.item.is_a?(RPG::Weapon)
        item = $data_armors[self.item.id] if self.item.is_a?(RPG::Armor)
        temp = ""
        self.add_descr.each{|d|
          temp += d[1]
        }
        temp += item.description
        self.add_descr2.each{|d|
          temp += d[1]
        }
        if $imported["Tidloc-DiabloEquip"]
          if self.multitags.compact.count > 2
            text = ""
            self.multitags.compact.each{|t|
              text += Bitmap.html_decode(t.descr.clone.gsub("<br>"){""})+"\n" if t.descr && t.descr.length>0
            }
            return text
          end
          return Bitmap.html_decode(self.special.descr) if self.special && self.identified
          temp += Bitmap.html_decode(self.pretag.descr) if self.pretag && self.identified
          temp += Bitmap.html_decode(self.postag.descr) if self.postag && self.identified
        end
        if $imported["Tidloc-SocketEquip"]
          self.sockets.compact.map{|x| x.descr if x.used}.compact.each{|x| temp += Bitmap.html_decode(x)}
        end
        return temp
      end
      def b_param
        temp = []
        temp.push self.note =~ /<b-hp (.*)>/i ?  $1.to_i : 0
        temp.push self.note =~ /<b-mp (.*)>/i ?  $1.to_i : 0
        temp.push self.note =~ /<b-str (.*)>/i ? $1.to_i : 0
        temp.push self.note =~ /<b-def (.*)>/i ? $1.to_i : 0
        temp.push self.note =~ /<b-mag (.*)>/i ? $1.to_i : 0
        temp.push self.note =~ /<b-mdf (.*)>/i ? $1.to_i : 0
        temp.push self.note =~ /<p-agi (.*)>/i ? $1.to_i : 0
        temp.push self.note =~ /<b-luc (.*)>/i ? $1.to_i : 0
        temp.push self.note =~ /<b-dex (.*)>/i ? $1.to_i : 0
        temp.push self.note =~ /<b-vit (.*)>/i ? $1.to_i : 0
        return temp if self.item.nil?
        if $imported["Tidloc-ExpEquip"] && self._exp_enabled
          Tidloc::Vocabs.Header("Params",$tidloc_language).count.times{|i|
            temp[i] += self.lvl_param[i]
          }
        end
        if $imported["Tidloc-DiabloEquip"] && self.identified
          return self.special.bonus if self.special
          if self.pretag
            Tidloc::Vocabs.Header("Params",$tidloc_language).count.times{|i|
              temp[i] += self.pretag.bonus[i]
            }
          end
          if self.postag
            Tidloc::Vocabs.Header("Params",$tidloc_language).count.times{|i|
              temp[i] += self.postag.bonus[i]
            }
          end
        end
        if $imported["Tidloc-SocketEquip"]         
          self.sockets.size.times{|i|
            if i == self.temp_id
              Tidloc::Vocabs.Header("Params",$tidloc_language).count.times{|j|
                temp[j] += self.temp_socket.bonus[j]
              }
            else
              Tidloc::Vocabs.Header("Params",$tidloc_language).count.times{|j|
                temp[j] += self.sockets[i].bonus[j] if self.sockets[i].used
              }
            end
          }
        end
        if $imported["Tidloc-DiabloMulti"]
          self.multitags.compact.each{|m|
            Tidloc::Vocabs.Header("Params",$tidloc_language).count.times{|j|
              temp[j] += m.bonus[j]
            }
          }
        end
        if $imported["Tidloc-CustomRefining"]
          Tidloc::Vocabs.Header("Params",$tidloc_language).count.times{|i|
            temp[i] += (self.item.params[i] + temp[i] + br_param[i])*self.refining_param3[i]/100.0 if i<8
            temp[i] += (temp[i] + br_param[i])*self.refining_param3[i]/100.0 if i>7
            temp[i] += self.refining_param[i]
          }
        end
        Tidloc::Vocabs.Header("Params",$tidloc_language).count.times{|i|
          temp[i] = temp[i].to_i
        }
        return temp
      end
      def param2
        temp=[]
        temp.push self.note =~ /<b%-hp (.*)>/i ?  ($1.to_i + self.b2r_param[0])/100.0 : self.b2r_param[0]/100.0
        temp.push self.note =~ /<b%-mp (.*)>/i ?  ($1.to_i + self.b2r_param[1])/100.0 : self.b2r_param[1]/100.0
        temp.push self.note =~ /<b%-str (.*)>/i ? ($1.to_i + self.b2r_param[2])/100.0 : self.b2r_param[2]/100.0
        temp.push self.note =~ /<b%-def (.*)>/i ? ($1.to_i + self.b2r_param[3])/100.0 : self.b2r_param[3]/100.0
        temp.push self.note =~ /<b%-mag (.*)>/i ? ($1.to_i + self.b2r_param[4])/100.0 : self.b2r_param[4]/100.0
        temp.push self.note =~ /<b%-mdf (.*)>/i ? ($1.to_i + self.b2r_param[5])/100.0 : self.b2r_param[5]/100.0
        temp.push self.note =~ /<p%-agi (.*)>/i ? ($1.to_i + self.b2r_param[6])/100.0 : self.b2r_param[6]/100.0
        temp.push self.note =~ /<b%-luc (.*)>/i ? ($1.to_i + self.b2r_param[7])/100.0 : self.b2r_param[7]/100.0
        temp.push self.note =~ /<b%-dex (.*)>/i ? ($1.to_i + self.b2r_param[8])/100.0 : self.b2r_param[8]/100.0
        temp.push self.note =~ /<b%-vit (.*)>/i ? ($1.to_i + self.b2r_param[9])/100.0 : self.b2r_param[9]/100.0
        if $imported["Tidloc-CustomRefining"]
          temp.size.times{|i|
            temp[i] += self.refining_param2[i]/100.0
          }
        end
        return temp
      end
      def xparam(xparam_id)
        temp  = 0.0
        case xparam_id
        when 0; temp = $1/100.0 if self.note =~ /<b-hit (.*)>/;
        when 1; temp = $1/100.0 if self.note =~ /<b-eva (.*)>/;
        when 2; temp = $1/100.0 if self.note =~ /<b-cri (.*)>/;
        when 3; temp = $1/100.0 if self.note =~ /<b-cev (.*)>/;
        when 4; temp = $1/100.0 if self.note =~ /<b-mev (.*)>/;
        when 5; temp = $1/100.0 if self.note =~ /<b-mrf (.*)>/;
        when 6; temp = $1/100.0 if self.note =~ /<b-cnt (.*)>/;
        when 7; temp = $1/100.0 if self.note =~ /<b-hrg (.*)>/;
        when 8; temp = $1/100.0 if self.note =~ /<b-mrg (.*)>/;
        when 9; temp = $1/100.0 if self.note =~ /<b-trg (.*)>/;
        end
        temp += self.item.features.select{|ft| ft.code == 22 && ft.data_id == xparam_id}.inject(0.0){|r, ft| r += ft.value}
        temp += self.b_xparam[xparam_id]/100.0
        temp += self.pretag.xparam(xparam_id)/100.0   if $imported["Tidloc-DiabloEquip"] && self.pretag
        temp += self.postag.xparam(xparam_id)/100.0   if $imported["Tidloc-DiabloEquip"] && self.postag
        temp += self.special.xparam(xparam_id)/100.0  if $imported["Tidloc-DiabloEquip"] && self.special
        temp += self.refining_xparam[xparam_id]/100.0 if $imported["Tidloc-CustomRefining"]
        self.sockets.each{|x|
          temp += x.xparam(xparam_id)
        } if $imported["Tidloc-SocketEquip"]
        if $imported["Tidloc-DiabloMulti"]
          self.multitags.compact.each{|m|
            Tidloc::Vocabs.Header("Params",$tidloc_language).count.times{|j|
              temp[j] += m.xparam[j]
            }
          }
        end
        return temp
      end
      def sparam(sparam_id)
        temp  = 0.0
        case sparam_id
        when 0; temp = $1/100.0 if self.note =~ /<b-hit (.*)>/
        when 1; temp = $1/100.0 if self.note =~ /<b-eva (.*)>/
        when 2; temp = $1/100.0 if self.note =~ /<b-cri (.*)>/
        when 3; temp = $1/100.0 if self.note =~ /<b-cev (.*)>/
        when 4; temp = $1/100.0 if self.note =~ /<b-mev (.*)>/
        when 5; temp = $1/100.0 if self.note =~ /<b-mrf (.*)>/
        when 6; temp = $1/100.0 if self.note =~ /<b-cnt (.*)>/
        when 7; temp = $1/100.0 if self.note =~ /<b-hrg (.*)>/
        when 8; temp = $1/100.0 if self.note =~ /<b-mrg (.*)>/
        when 9; temp = $1/100.0 if self.note =~ /<b-trg (.*)>/
        end
        temp += self.item.features.select{|ft| ft.code == 23 && ft.data_id == sparam_id}.inject(0.0){|r, ft| r += ft.value}
        temp += self.b_sparam[sparam_id]/100.0
        temp += self.pretag.sparam(sparam_id)/100.0  if $imported["Tidloc-DiabloEquip"] && self.pretag
        temp += self.postag.sparam(sparam_id)/100.0  if $imported["Tidloc-DiabloEquip"] && self.postag
        temp += self.special.sparam(sparam_id)/100.0 if $imported["Tidloc-DiabloEquip"] && self.special
        self.sockets.each{|x|
          temp += x.sparam(sparam_id)
        } if $imported["Tidloc-DiabloEquip"]
        if $imported["Tidloc-DiabloMulti"]
          self.multitags.compact.each{|m|
            Tidloc::Vocabs.Header("Params",$tidloc_language).count.times{|j|
              temp[j] += m.sparam[j]
            }
          }
        end
        return temp
      end
      def check_random_bonus
        temp = [0] *Tidloc::Vocabs.Header("Params",$tidloc_language).count
        return temp if self.item.nil?
        temp[0] = $1.to_i + rand($2.to_i - $1.to_i) if self.note =~ /<br-hp ([0-9]+),([0-9]+)>/i
        temp[1] = $1.to_i + rand($2.to_i - $1.to_i) if self.note =~ /<br-mp ([0-9]+),([0-9]+)>/i
        temp[2] = $1.to_i + rand($2.to_i - $1.to_i) if self.note =~ /<br-str ([0-9]+),([0-9]+)>/i
        temp[3] = $1.to_i + rand($2.to_i - $1.to_i) if self.note =~ /<br-def ([0-9]+),([0-9]+)>/i
        temp[4] = $1.to_i + rand($2.to_i - $1.to_i) if self.note =~ /<br-mag ([0-9]+),([0-9]+)>/i
        temp[5] = $1.to_i + rand($2.to_i - $1.to_i) if self.note =~ /<br-mdf ([0-9]+),([0-9]+)>/i
        temp[6] = $1.to_i + rand($2.to_i - $1.to_i) if self.note =~ /<br-agi ([0-9]+),([0-9]+)>/i
        temp[7] = $1.to_i + rand($2.to_i - $1.to_i) if self.note =~ /<br-luc ([0-9]+),([0-9]+)>/i
        temp[8] = $1.to_i + rand($2.to_i - $1.to_i) if self.note =~ /<br-dex ([0-9]+),([0-9]+)>/i
        temp[9] = $1.to_i + rand($2.to_i - $1.to_i) if self.note =~ /<br-vit ([0-9]+),([0-9]+)>/i
        self.br_param = temp.clone
        temp = [100] *Tidloc::Vocabs.Header("Params",$tidloc_language).count
        temp[0] = $1.to_i + rand($2.to_i - $1.to_i) if self.note =~ /<br%-hp ([0-9]+),([0-9]+)>/i
        temp[1] = $1.to_i + rand($2.to_i - $1.to_i) if self.note =~ /<br%-mp ([0-9]+),([0-9]+)>/i
        temp[2] = $1.to_i + rand($2.to_i - $1.to_i) if self.note =~ /<br%-str ([0-9]+),([0-9]+)>/i
        temp[3] = $1.to_i + rand($2.to_i - $1.to_i) if self.note =~ /<br%-def ([0-9]+),([0-9]+)>/i
        temp[4] = $1.to_i + rand($2.to_i - $1.to_i) if self.note =~ /<br%-mag ([0-9]+),([0-9]+)>/i
        temp[5] = $1.to_i + rand($2.to_i - $1.to_i) if self.note =~ /<br%-mdf ([0-9]+),([0-9]+)>/i
        temp[6] = $1.to_i + rand($2.to_i - $1.to_i) if self.note =~ /<br%-agi ([0-9]+),([0-9]+)>/i
        temp[7] = $1.to_i + rand($2.to_i - $1.to_i) if self.note =~ /<br%-luc ([0-9]+),([0-9]+)>/i
        temp[8] = $1.to_i + rand($2.to_i - $1.to_i) if self.note =~ /<br%-dex ([0-9]+),([0-9]+)>/i
        temp[9] = $1.to_i + rand($2.to_i - $1.to_i) if self.note =~ /<br%-vit ([0-9]+),([0-9]+)>/i
        self.b2r_param = temp.clone
      end
      def execute_commands(tag)
        $game_temp.tidloc[:item] = self
        self.commands.each                             {|x| x[0]==tag ? eval(Tidloc.exe(x[1],x[2])) : ""}
        self.pretag.commands.each                      {|x| x[0]==tag ? eval(Tidloc.exe(x[1],x[2])) : ""}            if $imported["Tidloc-DiabloEquip"] && self.pretag
        self.postag.commands.each                      {|x| x[0]==tag ? eval(Tidloc.exe(x[1],x[2])) : ""}            if $imported["Tidloc-DiabloEquip"] && self.postag
        self.special.commands.each                     {|x| x[0]==tag ? eval(Tidloc.exe(x[1],x[2])) : ""}            if $imported["Tidloc-DiabloEquip"] && self.special
        self.multitags.compact.each{|t| t.commands.each{|x| x[0]==tag ? eval(Tidloc.exe(x[1],x[2])) : ""}}           if $imported["Tidloc-DiabloMulti"] && self.multitags.compact.count > 0
        self.sockets.each{|y| y.commands.each          {|x| x[0]==tag ? eval(Tidloc.exe(x[1],x[2])) : ""} if y.used} if $imported["Tidloc-SocketEquip"] && self.sockets
      end      
      def skills
        if $imported["Tidloc-CustomSkills"]
          return custom_skills
        end
        temp = [0]*1000
        if self.item.note =~ /<b-skill (.*)>/i
          temp[$1.to_i] = 1
        end
        if Tidloc.Version("Tidloc-DiabloEquip",[1,2,1]) && self.identified
          if self.pretag
            self.pretag.skills.each{|x|
              temp[x] += 1
            }
          end
          if self.postag
            self.postag.skills.each{|x|
              temp[x] += 1
            }
          end
          if self.special
            self.special.skills.each{|x|
              temp[x] += 1
            }
          end
        end
        if Tidloc.Version("Tidloc-SocketEquip",[1,3,1])
          self.sockets.each{|y|
            y.skills.each{|x|
              temp[x] += 1
            } if y.used
          }
        end
        return temp
      end
      def custom_skills
        temp = []
        if $imported["Tidloc-CustomSkills"]
          temp.push self.CustomSkill
          if Tidloc.Version("Tidloc-DiabloEquip",[1,6,0]) && self.identified
            temp.push self.pretag.skills  if self.pretag
            temp.push self.postag.skills  if self.postag
            temp.push self.special.skills if self.special
          end
          if Tidloc.Version("Tidloc-SocketEquip",[1,6,0])
            self.sockets.each{|y|
              temp.push y.skills if y.used
            }
          end
        end
        return temp.compact
      end
      def skills?
        if $imported["Tidloc-CustomSkills"]
          if skills.size > 0
            return true
          else
            return false
          end
        end
        temp = skills
        temp.each{|y|
          return true if y > 0
        }
        return false
      end
    end
    
    
    class Weapon < Base
      def initialize(item)
        if item.is_a?(RPG::Weapon)
          self.item = item
        else
          self.item = $data_weapons[item]
        end
        self.nid = $game_system._tidloc_singleequip_w
        $game_system._tidloc_singleequip_w += 1
        super 0
        self.commands = Tidloc::Header::WeaponData(id)[:commands] if $imported["Tidloc-WeaponData"]
        check_random_bonus
      end
      def is_weapon?; true; end
    end
    class Armor < Base
      def initialize(item)
        if item.is_a?(RPG::Armor)
          self.item = item
        else
          self.item = $data_armors[item] 
        end
        self.nid = $game_system._tidloc_singleequip_a
        $game_system._tidloc_singleequip_a += 1
        super 0
        self.commands = Tidloc::Header::ArmorData(id)[:commands] if $imported["Tidloc-ArmorData"]
        check_random_bonus
      end
      def is_armor?; true; end
      def damage;    Dummy_Damage.new;  end
    end
    
    class<<self
      def gain_equip(item)
        return Tidloc::CustomEquip::Weapon.new(item) if item.is_a?(RPG::Weapon)
        return Tidloc::CustomEquip::Armor.new(item)  if item.is_a?(RPG::Armor)
        return nil unless item.is_a?(RPG::EquipItem)
        if    item.is_a?(Tidloc::CustomEquip::Weapon)
          $game_party.weapons.find{|x| x.nid==item.nid}.inv = true
          return item
        elsif item.is_a?(Tidloc::CustomEquip::Armor)
          $game_party.armors.find{|x| x.nid==item.nid}.inv  = true
          return item
        end
        return nil
      end
      def item_prere(item,param)
        case param
        when "HP";  return item.p_hp
        when "MP";  return item.p_mp
        when "STR"; return item.p_str
        when "MAG"; return item.p_int
        when "DEF"; return item.p_def
        when "MDF"; return item.p_mdf
        when "AGI"; return item.p_agi
        when "LUC"; return item.p_luc
        when "DEX"; return item.p_dex
        when "VIT"; return item.p_vit
        when "LVL"; return item.p_level
        end
        return 0
      end
      def item_bonus(item,param)
        case param
        when "HP";  return item.params[0]
        when "MP";  return item.params[1]
        when "STR"; return item.params[2]
        when "MAG"; return item.params[4]
        when "DEF"; return item.params[3]
        when "MDF"; return item.params[5]
        when "AGI"; return item.params[6]
        when "LUC"; return item.params[7]
        when "DEX"; return item.params[8]
        when "VIT"; return item.params[9]
        when "HIT"; return item.xparam(0)
        when "EVA"; return item.xparam(1)
        when "CRI"; return item.xparam(2)
        when "CEV"; return item.xparam(3)
        when "MEV"; return item.xparam(4)
        when "MRF"; return item.xparam(5)
        when "CNT"; return item.xparam(6)
        when "HRG"; return item.xparam(7)
        when "MRG"; return item.xparam(8)
        when "TPR"; return item.xparam(9)
        when "TGR"; return item.sparam(0)
        when "GRD"; return item.sparam(1)
        when "REC"; return item.sparam(2)
        when "PHA"; return item.sparam(3)
        when "MCR"; return item.sparam(4)
        when "TCR"; return item.sparam(5)
        when "PDR"; return item.sparam(6)
        when "MDR"; return item.sparam(7)
        when "FDR"; return item.sparam(8)
        when "EXR"; return item.sparam(9)
        end
        return 0
      end
      def item_bonus2(item,param)
        case param
        when "HP";  return item.param2[0]
        when "MP";  return item.param2[1]
        when "STR"; return item.param2[2]
        when "MAG"; return item.param2[4]
        when "DEF"; return item.param2[3]
        when "MDF"; return item.param2[5]
        when "AGI"; return item.param2[6]
        when "LUC"; return item.param2[7]
        when "DEX"; return item.param2[8]
        when "VIT"; return item.param2[9]
        end
        return 0
      end
    end
    
    
    
    
    
    class Window_ItemList_22 < Window_ItemList_2
      def col_max
        return 1
      end
      def cursor_pagedown
      end
      def cursor_pageup
      end
    end
    
    class Window_ItemList_2 < Window_ItemList
      attr_accessor :help_window
      alias wo_tidloc_update_help update_help
      def update_help
        if SceneManager.scene_is?(Scene_Item)
          @help_window.item= item
          return
        end
        wo_tidloc_update_help
      end
      def col_max
        return 1
      end
    end
    
    class Window_ShopStatus2 < Window_ShopStatus
      attr_accessor :scene
      attr_accessor :actor
      attr_reader   :item
      attr_accessor :tempitem
      attr_accessor :sockets
      attr_accessor :socket_pics
      alias wo_tidloc_init initialize
      def initialize(x, y, width, height)
        self.scene = nil
        self.actor = nil
        self.sockets = []
        self.socket_pics = []
        Tidloc::SocketEquip::Empty_Socket_BMP.each{|x|
          self.socket_pics.push Game_Picture.new(1)
        } if $imported["Tidloc-SocketEquip"]
        wo_tidloc_init(x, y, width, height)
      end
      def set_item(item)
        @item = item
        @tempitem = item.clone if item
        self.oy = 0 if item.nil? || item.is_a?(RPG::Item)
        refresh
      end
      def reset_tempitem
        item.apply_temp(nil,-1)
      end
      def contents_height
        return 2000 if self.scene.nil?
        temp2 = height-line_height
        return temp2 if self.item.nil? || self.item.is_a?(RPG::Item)
        temp = 5.5
        if $imported["Tidloc-DiabloEquip"] && self.item.set_id > 0 && self.actor
          temp += 1.5
          if self.actor.equips.compact.find_all{|e| e.set_id == self.item.set_id}.count > 1
            temp += self.actor.equips.compact.find_all{|e| e.set_id == self.item.set_id}.count-1
          end
        end
        temp += 2   if $imported["Tidloc-DiabloEquip"] && item.multitags.compact.count > 2
        temp += 2.5 if $imported["Tidloc-Element-Separation"] && (item.is_a?(RPG::Weapon) || item.is_a?(Tidloc::CustomEquip::Weapon))
        temp += 4.5 if $imported["Tidloc-ExpEquip"] && self.item && self.item._exp_enabled
        temp += -0.5 + Tidloc::CustomEquip::Disp_Attr.size if self.scene == :equip
        temp += 4.5 if self.scene == :refine
        temp += 2.5 if $imported["Tidloc-SocketEquip"] && self.item
        temp += 0.5 if Tidloc::CustomEquip::Use_Require.size > 0
        temp += (Tidloc::CustomEquip::Use_Require.size+1)/2 if Tidloc::CustomEquip::Use_Require.size > 0
        temp += 0.5 if Tidloc::CustomEquip::Use_Bonus.size > 0
        temp += (Tidloc::CustomEquip::Use_Bonus.size+1)/2
        temp += 3.5 if Tidloc::CustomEquip::Attrib_Icons.size > 0
        temp += (Tidloc::CustomEquip::Attrib_Icons.size+1)/2
        return [temp*line_height,temp2].max
      end
      def clear
        self.item = nil
      end
      def set_temp_actor(temp_actor)
        return if @temp_actor == temp_actor
        @temp_actor = temp_actor
        refresh
      end
      def height
        if self.scene == :equip
          return 0
        else
          return super
        end
      end
      def refresh
        return if self.disposed?
        if self.scene.nil?
          contents.clear
          draw_possession(4, 0)
          draw_equip_info(4, line_height * 2) if @item.is_a?(RPG::EquipItem)
        else
          contents.clear
          draw_possession(4, 0) if self.scene == :shop
          draw_item_info(4, (self.scene == :shop) ? line_height * 2 : 0)
          if self.scene == :shop && @item.is_a?(RPG::EquipItem)
            change_color(system_color)
            draw_html(4,line_height*19,300,32,($tidloc_language == "ger")?"Aktive Ausrüstung:":"Active equipment:")
            change_color(normal_color)
            draw_equip_info(4, line_height*20)
          end
        end
      end
      def draw_item_info(x,y)
        color2 = Color.new(255,192,128,128)
        color1 = Color.new(255,192,128)
        w = contents.width-5
        
        item = self.item
        y_offset =  line_height*6
        y_offset += line_height*2 if item.is_a?(Tidloc::CustomEquip::Base) && item.multitags.compact.count>2
        
# when set item:
        if item && item.is_a?(Tidloc::CustomEquip::Base) && item.set_id > 0 && @temp_actor
          draw_html x+15,y+y_offset,self.width,32,"#{Tidloc::Vocabs.CustomEquip("Set",$tidloc_language)}"
          y_offset += line_height*1
          num = @temp_actor.equips.compact.find_all{|e| e.set_id == item.set_id}.map{|e| Bitmap.html_decode(e.name)}.uniq.count
          if num > 1
            for i in 2..num
              text = Tidloc::CustomEquip::Set.ids[item.set_id].descr[i].clone
              draw_html x+35,y+y_offset,self.width,32,"#{i}: #{text}"
              y_offset += line_height*1
            end
          end
          y_offset += line_height*0.5
        elsif item && item.is_a?(Tidloc::CustomEquip::Base) && item.set_id > 0 && self.actor
          draw_html x+15,y+y_offset,self.width,32,"#{Tidloc::Vocabs.CustomEquip("Set",$tidloc_language)}"
          y_offset += line_height*1
          num = self.actor.equips.compact.find_all{|e| e.set_id == item.set_id}.count
          if num > 1
            for i in 2..num
              text = Tidloc::CustomEquip::Set.ids[item.set_id].descr[i].clone
              draw_html x+35,y+y_offset,self.width,32,"#{i}: #{text}"
              y_offset += line_height*1
            end
          end
          y_offset += line_height*0.5
        end
        
# show changes:
        if    self.scene == :refine
          draw_html(x+10,y+y_offset,self.width,32,"<color=#{Tidloc::CustomRefining::Refine_Color}>#{Tidloc::Vocabs.CustomRefining("Merge",$tidloc_language)}")
          if    item.ehc_stone?
            newitem = $data_items.find{|i| i && i.ehc_lvl == item.ehc_lvl+1}
            draw_html(x+10,y+y_offset+line_height,self.width,32,"<space=25>#{Tidloc::CustomRefining::EHC_Merge}x #{item.name}")
          elsif item.safety_stone?
            newitem = $data_items.find{|i| i && i.safety_lvl == item.safety_lvl+1}
            draw_html x+10,y+y_offset+line_height*1,self.width,32,"<space=25>#{Tidloc::CustomRefining::Safety_Merge}x #{item.name}"
          elsif item.blessed_stone?
            newitem = $data_items.find{|i| i && i.blessed_stone_lvl == item.blessed_stone_lvl+1}
            draw_html x+10,y+y_offset+line_height*1,self.width,32,"<space=25>#{Tidloc::CustomRefining::Safety_Merge}x #{item.name}"
          end
          draw_html x+10,y+y_offset+line_height*2,self.width,32,"<space=60><color=#{Tidloc::CustomRefining::Refine_Color}>↓"
          draw_html x+10,y+y_offset+line_height*3,self.width,32,"<space=40>#{newitem.name}"
          y_offset += line_height*4.5
        elsif self.scene == :equip
          draw_html(x+10,y+y_offset,self.width,32,"<color=orange>#{self.actor.name}")
          if Tidloc.Version("Tidloc-Header",[2,7,0])
            t=1
            Tidloc::Param_Names[0].count.times{|i|
              if Tidloc::CustomEquip::Disp_Attr.find{|x| x==Tidloc::Param_Names[0][i]}
                draw_item_change(x+10,y+y_offset+line_height*t,i)
                t += 1
              end
            }
            if item
              contents.fill_rect(x+2,y+y_offset,w/2, 1,color1)
              draw_html x+20,y+y_offset-9,w-2,20,"<size=16><font=Comic Sans MS><color=cyan><i>#{Tidloc::Vocabs.CustomEquip("Desc",$tidloc_language)[2]}:"
            end
            y_offset += line_height*(t+0.5)
          else
            draw_item_change(x+10,y+y_offset+line_height*1,0)
            draw_item_change(x+10,y+y_offset+line_height*2,1)
            draw_item_change(x+10,y+y_offset+line_height*2,1)
            draw_item_change(x+10,y+y_offset+line_height*2,1)
            draw_item_change(x+10,y+y_offset+line_height*3,2)
            draw_item_change(x+10,y+y_offset+line_height*4,4)
            draw_item_change(x+10,y+y_offset+line_height*5,6)
            draw_item_change(x+10,y+y_offset+line_height*6,7)
            y_offset += line_height*7.5
          end
        end
        
        return if item.nil?
        
        contents.fill_rect(x+2,y+line_height*0.3,w/2, 1,color1)
          draw_html x+15,y-2,w-2,20,"<size=16><font=Comic Sans MS><color=cyan><i>#{Tidloc::Vocabs.CustomEquip("Desc",$tidloc_language)[0]}:"
          draw_item_name(item,x+4,y+2+line_height*0.5)
        contents.fill_rect(x+2,y+6+line_height*1.6,w/2, 1,color1)
          draw_html x+15,y+line_height*1.6-3,w-2,20,"<size=16><font=Comic Sans MS><color=cyan><i>#{Tidloc::Vocabs.CustomEquip("Desc",$tidloc_language)[1]}:"
          draw_html(x, y+line_height*1.75,self.width,line_height*6, item.description, true)
        return if item.is_a?(RPG::Item) || item.is_a?(RPG::Skill) || ($imported["Tidloc-TT_CardConverter"] && item.is_a?(Tidloc::Games::TripleTriad::Card))
        
        
        
#~ # TODO
#~         if $imported["Tidloc-Element-Separation"] && (item.is_a?(RPG::Weapon) || item.is_a?(Tidloc::CustomEquip::Weapon))
#~           if    item.note =~ Tidloc::Element_Separation::Notetags[:ele_dmg]   ||
#~                (item.note =~ Tidloc::Element_Separation::Notetags[:ele_for1]  &&
#~                 item.note =~ Tidloc::Element_Separation::Notetags[:ele_for2]) ||
#~                (item.note =~ Tidloc::Element_Separation::Notetags[:ele_for3]  &&
#~                 item.note =~ Tidloc::Element_Separation::Notetags[:ele_for2])
#~             t = Array.new(1000) {item.tid_damage_eval.sum}
#~           elsif $imported["YEA-WeaponAttackReplace"]
#~             t = Array.new(1000) {$data_skills[item.attack_skill].damage.eval($game_temp.tidloc[:user], Tidloc::Dummy_actor.new, $game_variables)}
#~           else
#~             t = Array.new(1000) {$data_skills[$game_temp.tidloc[:user].attack_skill_id].damage.eval($game_temp.tidloc[:user], Tidloc::Dummy_actor.new, $game_variables)}
#~           end
#~           dmg1=t.min
#~           dmg2=t.max
#~           t = nil
#~           draw_html x+15,y+y_offset,self.width,32,"<size=16><font=Comic Sans MS><color=cyan><i>#{Tidloc::Vocabs.ElementSeparation("Damage",$tidloc_language)}:"
#~           s=24
#~ #          s=22 if dmg2 >= 100
#~ #          s=16 if dmg2 >= 1000
#~           draw_html(x+15,y+y_offset+line_height,self.width,32,"<size=#{s}>    #{dmg1.to_s.rjust(6)}-#{dmg2.to_s}")
#~           y_offset += line_height*2.5
#~         end
        
        if $imported["Tidloc-CustomDura"] && item.durability_max > 0
          contents.fill_rect(w*3/4,y+8,w/3, 1,color1)
          contents.fill_rect(w*3/4,y+8+line_height,w/3, 1,color1)
          contents.fill_rect(w*3/4,y+8,1,line_height,color1)
            draw_html w*3/4+1,y-2,w/4,20,"<size=16><font=Comic Sans MS><color=cyan><i>#{Tidloc::Vocabs.CustomDura("Durability",$tidloc_language)}:"
          if item.durability_max_temp < item.durability_max/4;  color = "<color=#{Tidloc::CustomDura::Color_Max_}>"
          elsif item.durability_max_temp < item.durability_max; color = "<color=#{Tidloc::CustomDura::Color_Max_4}>"
          else;                                                 color = ""
          end
          s=24
          s=22 if item.durability_max_temp >= 100
          s=16 if item.durability_max_temp >= 1000
          draw_html(w*3/4,y+18-s/2,w/4,32,"<size=#{s}>#{item.durability}/#{color}#{item.durability_max_temp}")
        end


        if $imported["Tidloc-ExpEquip"] && item.is_a?(Tidloc::CustomEquip::Base) && item._exp_enabled
          contents.fill_rect(x+2,y+y_offset,w/2, 1,color1)
            draw_html x+15,y+y_offset-9,w-2,20,"<size=16><font=Comic Sans MS><color=cyan><i>#{Tidloc::Vocabs.CustomEquip("Desc",$tidloc_language)[3]}:"
          draw_html(x+5, y+y_offset,self.width,32,"<color=yellow>#{Tidloc::Vocabs.ExpEquip("LVLI",$tidloc_language)}</color>")
          draw_html(x+15,y+y_offset+line_height*1,self.width,32,"<color=orange>#{Tidloc::Vocabs.ExpEquip("ILVL",$tidloc_language)}:</color> #{item._exp_lvl.to_i}")
          draw_html(x+15,y+y_offset+line_height*2,self.width,32,"<color=orange>#{Tidloc::Vocabs.ExpEquip("IEXP",$tidloc_language)}:</color> #{item._exp_exp.to_i}")
          if item._exp_lvl_max
            draw_html(x+15,y+y_offset+line_height*3,self.width,32,"<color=orange>#{Tidloc::Vocabs.ExpEquip("INED",$tidloc_language)}:</color> <color=#af80ff>MAX</color>")
          else
            draw_html(x+15,y+y_offset+line_height*3,self.width,32,"<color=orange>#{Tidloc::Vocabs.ExpEquip("INED",$tidloc_language)}:</color> #{item._exp_next.to_i}")
          end
          y_offset += line_height * 4.5
        end
        if $imported["Tidloc-SocketEquip"]
          contents.fill_rect(x+2,y+y_offset,w/2, 1,color1)
            draw_html x+15,y+y_offset-9,w-2,20,"<size=16><font=Comic Sans MS><color=cyan><i>#{Tidloc::Vocabs.SocketEquip("Desc",$tidloc_language)}:"
          self.sockets = self.item.sockets if self.scene != :socket
          temp = self.sockets
          if temp.size > 0
            for i in 0...temp.size
              image = Cache.picture(Tidloc::SocketEquip::Empty_Socket_BMP[temp[i].s_type])
              contents.blt(x+30+28*(i%6),y+6+y_offset+line_height*(i/6).to_i, image, image.rect)
              image2 = (i == item.temp_id && item.temp_socket) ? item.temp_socket.icon : (temp[i]) ? temp[i].icon : ""
              draw_icon(image2,x+30+28*(i%6),y+y_offset+line_height*(i/6).to_i) if temp[i] && (temp[i].used || i == item.temp_id)
            end
          end
          y_offset += line_height * 2.5
        end
        
        if Tidloc::CustomEquip::Use_Require.size > 0
          contents.fill_rect(x+2,y+y_offset-4,w/2, 1,color1)
            draw_html x+15,y+y_offset-13,w-2,20,"<size=16><font=Comic Sans MS><color=cyan><i>#{Tidloc::Vocabs.CustomEquip("Desc",$tidloc_language)[4]}:"
          for i in 0...Tidloc::CustomEquip::Use_Require.size
            text  = "<color=#{Tidloc::CustomEquip::Attr_Color}>"
            text += Tidloc::Vocabs.CustomEquip(Tidloc::CustomEquip::Use_Require[i],$tidloc_language)
            draw_html(x+ 5+(i%2)*Graphics.width/4, y+y_offset+line_height*((i/2).to_i),35,line_height,text)
            temp = Tidloc::CustomEquip::item_prere(item,Tidloc::CustomEquip::Use_Require[i])
            draw_text_ex(x+40+(i%2)*Graphics.width/4, y+y_offset+line_height*((i/2).to_i), temp) if temp > 0
          end
          y_offset += line_height*(0.5+(Tidloc::CustomEquip::Use_Require.size+1)/2)
        end
        
        if Tidloc::CustomEquip::Use_Bonus.size > 0
          contents.fill_rect(x+2,y+y_offset-4,w/2, 1,color1)
            draw_html x+15,y+y_offset-13,w-2,20,"<size=16><font=Comic Sans MS><color=cyan><i>#{Tidloc::Vocabs.CustomEquip("Desc",$tidloc_language)[5]}:"
          Tidloc::CustomEquip::Use_Bonus.size.times{|i|
            next unless Tidloc::CustomEquip::Use_Bonus[i]
            text = "<color=#{Tidloc::CustomEquip::Attr_Color}>"
            text += Tidloc::Vocabs.CustomEquip(Tidloc::CustomEquip::Use_Bonus[i],$tidloc_language)
            draw_html(x+ 5+(i%2)*Graphics.width/4, y+y_offset+line_height*((i/2).to_i),35,line_height,text)
            temp = Tidloc::CustomEquip::item_bonus(item,Tidloc::CustomEquip::Use_Bonus[i])
            if temp>0;text = "<color=#{Tidloc::CustomEquip::Pos_Color}>"
                 else;text = "<color=#{Tidloc::CustomEquip::Neg_Color}>";end
            text += temp.to_s
            draw_html(x+40+(i%2)*Graphics.width/4, y+y_offset+line_height*((i/2).to_i), 100, line_height, text) if temp!=0
            temp = Tidloc::CustomEquip::item_bonus2(item,Tidloc::CustomEquip::Use_Bonus[i])
            if temp>1.0;text = "<color=#{Tidloc::CustomEquip::Pos_Color}>"
                   else;text = "<color=#{Tidloc::CustomEquip::Neg_Color}>";end
            text += "#{(temp*100).to_i}%"
            draw_html(x+90+(i%2)*Graphics.width/4, y+y_offset+line_height*((i/2).to_i), 100, line_height, text) if temp!=1.0
          }
          y_offset += line_height*(0.5+(Tidloc::CustomEquip::Use_Bonus.size+1)/2)
        end
        
        for i in 0...Tidloc::CustomEquip::Attrib_Icons.size
          contents.fill_rect(x+2,y+y_offset-4,w/2, 1,color1)
            draw_html x+15,y+y_offset-13,w-2,20,"<size=16><font=Comic Sans MS><color=cyan><i>#{Tidloc::Vocabs.CustomEquip("Desc",$tidloc_language)[6]}:"
          j = i%2
          draw_icon(Tidloc::CustomEquip::Attrib_Icons[i], x+ 5+j*Graphics.width/4, y+y_offset+line_height*((i/2).to_i))
          draw_elemental_rate(item, i+1,                  x+25+j*Graphics.width/4, y+y_offset+line_height*((i/2).to_i))
        end
        
        contents.fill_rect(x+1,y,w,2,color2)
        contents.fill_rect(x+1,y+contents_height-26,w,2,color2)
        contents.fill_rect(x+1,y,2,contents_height-25,color2)
        contents.fill_rect(x+w-1,y,2,contents_height-25,color2)
        
      end
      def draw_elemental_rate(item,id,x,y)
        if item.elemental_rate(id) > 1
          change_color(power_down_color)
          draw_text(x,y,50,line_height,(item.elemental_rate(id)*100).to_i.to_s+"%")
        elsif item.elemental_rate(id) < 1
          change_color(power_up_color)
          draw_text(x,y,50,line_height,(item.elemental_rate(id)*100).to_i.to_s+"%")
        elsif item.elemental_rate(id) == 1.0
          change_color(normal_color)
          draw_text(x,y,50,line_height,(item.elemental_rate(id)*100).to_i.to_s+"%")
        end
#~         if @item.element_reflect[id]
#~           change_color(mp_cost_color)
#~           draw_text(x+50,y,50,line_height,"("+(@item.element_reflect[id]*100).to_i.to_s+"%)")
#~         end
      end
      def draw_item_change(dx, dy, param_id)
        draw_param_name(dx + 4, dy, param_id)
        draw_current_param(dx + 104, dy, param_id) if @actor
        draw_right_arrow(dx + 150, dy)
        draw_new_param(dx + 170, dy, param_id) if @temp_actor
        reset_font_settings
      end
      def draw_param_name(dx, dy, param_id)
        text = "<color=#{Tidloc::CustomEquip::Attr_Color}>"
        text += (param_id>=0 && param_id< Tidloc::Vocabs.Header("Params",$tidloc_language).count) ? 
                 Tidloc::Vocabs.CustomEquip(Tidloc::Param_Names[0][param_id],$tidloc_language) : ""
        draw_html(dx, dy, contents.width, line_height, text)
      end
      def draw_current_param(dx, dy, param_id)
        change_color(normal_color)
        temp = 0
        temp += @actor.hp_reserved if $imported["Tidloc-CustomSkills"] && param_id==0
        temp += @actor.mp_reserved if $imported["Tidloc-CustomSkills"] && param_id==1
        change_color(crisis_color) if temp > 0
        draw_text(0, dy, dx+48, line_height, @actor.param(param_id)-temp, 2)
        reset_font_settings
      end
      def draw_right_arrow(x, y)
        text  = "<color=#{Tidloc::CustomEquip::System_Color}>→</color>"
        draw_html(x, y, 22, line_height, text, false, 1)
      end
      def draw_new_param(dx, dy, param_id)
        new_value = @temp_actor.param(param_id)
        temp = 0
        temp += @temp_actor.hp_reserved if $imported["Tidloc-CustomSkills"] && param_id==0
        temp += @temp_actor.mp_reserved if $imported["Tidloc-CustomSkills"] && param_id==1
        change_color(param_change_color(new_value - @actor.param(param_id)))
        draw_text(dx, dy, contents.width-170, line_height, new_value-temp)
        reset_font_settings
      end
    end
    class Group_Window < Window_Selectable
      attr_accessor :group
      attr_accessor :type
      attr_accessor :item_window
      attr_accessor :actor
      def initialize
        super 0,0,Graphics.width,line_height*2
        self.deactivate.hide.type = nil
        self.group = []
        self.actor = nil
        make_groups
      end
      def make_groups(type = nil)
        self.type = type if type
        temp = []
        if    self.type == :weapon || (self.type.is_a?(Integer) && self.type == 0)
          temp = $game_party.weapons
        elsif self.type == :armor || (self.type.is_a?(Integer) && self.type > 0)
          temp = $game_party.armors
        else
          self.type = nil
        end
        temp = temp.find_all{|x| self.actor.equippable?(x) && x.inv} if self.actor
        if    temp.size > 0 && (self.type == :armor || self.type == :weapon)
          temp.each{|x|
            self.group.push x.item.name unless self.group.find{|y| y == x.item.name}
          } 
        elsif temp.size > 0 && self.type.is_a?(Integer) && self.type >= 0
          temp.each{|x|
            self.group.push x.item.name unless self.group.find{|y| y == x.item.name} || x.item.etype_id != self.type
          }
        end
        if self.item_window
          self.group.delete_if{|y| !self.item_window.data.find{|x| x.is_a?(Tidloc::CustomEquip::Base) &&  x.item.name == y}}   
        end
        self.group.unshift Tidloc::Vocabs.CustomEquip("All",$tidloc_language)
        refresh
        self.index = 0 if self.index >= 0
      end
      def refresh
        self.contents.clear
        if self.group.size == 0
          self.index = -1
          return
        end
        for i in 0...self.group.size
          draw_text(i*item_width+5,0,item_width-10,line_height,self.group[i])
        end
      end
      def update
        super
      end
      def item_max
        col_max
      end
      def col_max
        return 1 unless self.group
        return self.group.size
      end
      def item_width
        Graphics.width/3
      end
      def spacing
        0
      end
      def contents_width
        10000
      end
    end
    
    class Group_Window_Small < Group_Window
      def initialize(x,y,w,h)
        super()
        self.x      = x
        self.y      = y
        self.width  = w
        self.height = h
      end
      def item_width
        self.width
      end
      def update
        super
        return unless active
      end
      def refresh
        self.contents.clear
        return if self.index < 0
        if self.group.size == 0
          self.index = -1
          return
        end
        draw_text(5,0,item_width-10,line_height,(self.group[self.index].center(30,"-")))
      end
    end
  end
end

class Window_Selectable
  alias wo_equip_pgu cursor_pageup
  def cursor_pageup
    wo_equip_pgu unless Tidloc::CustomEquip::Deactivate_PG
  end
  alias wo_equip_pgp cursor_pagedown
  def cursor_pagedown
    wo_equip_pgd unless Tidloc::CustomEquip::Deactivate_PG
  end
end


class Game_Party < Game_Unit
  def init_all_items
    @items = {}
    @weapons = []
    @armors = []
  end
  alias wo_tid_cusequ_number item_number
  def item_number(item)
    return 0 unless item
    t=0
    if item.class == Tidloc::CustomEquip::Weapon
      return @weapons.find{|x| x.nid==item.nid} ? 1 : nil
    elsif item.class == Tidloc::CustomEquip::Armor
      return  @armors.find{|x| x.nid==item.nid} ? 1 : nil
    elsif item.class == RPG::Item
      return wo_tid_cusequ_number item
    elsif item.class == RPG::Weapon
      @weapons.compact.each{|weap|
        t += 1 if weap.inv && weap.id == item.id
      }
    elsif item.class == RPG::Armor
      @armors.compact.each{|arm|
        t += 1 if arm.inv  && arm.id  == item.id
      }
    end
    return t
  end
  def lose_item_for_all_time(item)
    return if item.nil?
    $game_map.need_refresh = true
    if item.is_a?(Tidloc::CustomEquip::Weapon)
      for i in 0...@weapons.count
        if @weapons[i].nid == item.nid
          eval($1) if item.note =~ /<exe-lose: (.*)>/
          @weapons[i] = nil
        end
      end
      @weapons = @weapons.compact
    elsif item.is_a?(Tidloc::CustomEquip::Armor)
      for i in 0...@armors.count
        if @armors[i].nid == item.nid
          eval($1) if item.note =~ /<exe-lose: (.*)>/
          @armors[i] = nil
        end
      end
      @armors = @armors.compact
    end
  end
  alias wo_tid_cusequ_gain gain_item
  def gain_item(item, amount, include_equip = false)
    return if item.nil?
    $game_map.need_refresh = true
    if item.is_a?(Tidloc::CustomEquip::Weapon)
      if amount>0
        @weapons.find{|x| x.nid==item.nid}.inv = true
        eval($1) if item.note =~ /<exe-get: (.*)>/
      else
        @weapons.find{|x| x.nid==item.nid}.inv = false
        eval($1) if item.note =~ /<exe-lose: (.*)>/
      end
    elsif item.is_a?(Tidloc::CustomEquip::Armor)
      if amount>0
        @armors.find{|x| x.nid==item.nid}.inv = true
        eval($1) if item.note =~ /<exe-get: (.*)>/
      else
        @armors.find{|x| x.nid==item.nid}.inv = false
        eval($1) if item.note =~ /<exe-lose: (.*)>/
      end
    elsif item.is_a?(RPG::Weapon)
      container = @weapons
      if amount>0
        amount.times {|x| eval($1)} if item.note =~ /<exe-get: (.*)>/
        amount.times{|x|
          new_item = Tidloc::CustomEquip::gain_equip item
          container.push new_item
        }
      else
        amount.times {|x| eval($1)} if item.note =~ /<exe-lose: (.*)>/
        container.count.times{|i|
          next if amount >= 0
          if container[i].id == item.id
            container[i].item = nil
            amount += 1
          end
        }
        container.delete_if{|x| x.item.nil?}
      end
    elsif item.is_a?(RPG::Armor)
      container = @armors
      if amount>0
        amount.times {|x| eval($1)} if item.note =~ /<exe-get: (.*)>/
        for i in 0...amount
          new_item = Tidloc::CustomEquip::gain_equip item
          container.push new_item
        end
      else
        amount.times {|x| eval($1)} if item.note =~ /<exe-lose: (.*)>/
        container.count.times{|i|
          next if amount >= 0
          if container[i].id == item.id
            container[i].item = nil
            amount += 1
          end
        }
        container.delete_if{|x| x.item.nil?}
      end
    else
      wo_tid_cusequ_gain(item, amount, include_equip)
    end
  end
  def item_container(item_class)
    return @items   if item_class == RPG::Item
    return @weapons if item_class == RPG::Weapon || item_class == Tidloc::CustomEquip::Weapon
    return @armors  if item_class == RPG::Armor  || item_class == Tidloc::CustomEquip::Armor
    return nil
  end
  def weapons
    @weapons
  end
  def armors
    @armors
  end
  def has_item?(item, include_equip = false)
    return true if item_number(item) > 0
    return true if item.is_a?(Tidloc::CustomEquip::Base) && item.inv
    return include_equip ? members_equip_include?(item) : false
  end
end

class Game_Actor
  
  def release_unequippable_items(item_gain = true)
    @equips.each_with_index do |item, i|
      if !equippable?(item.object) || item.object.etype_id != equip_slots[i]
        trade_item_with_party(nil, item.object) if item_gain
        item.object = nil
      end
    end
  end
  
  def change_equip(slot_id, item)
    return if item && !$game_party.has_item?(item)
    return if item && equip_slots[slot_id] != item.etype_id
    itemtemp = @equips[slot_id].object
    if itemtemp.is_a?(Tidloc::CustomEquip::Base)
      itemtemp.execute_commands("Unequip")
      if itemtemp.skills?
        temp = itemtemp.skills
        for i in 0...temp.size
          if $imported["Tidloc-CustomSkills"]
            self.forget_skill temp[i]
          elsif temp[i] > 0
            can_unlearn = true
            for j in 0..6
              if j != slot_id && @equips[j] && @equips[j].object && @equips[j].object.skills?
                can_unlearn = false if @equips[j].object.skills[i] > 0
              end
            end
            self.forget_skill(i) if can_unlearn
          end
        end
      end
    end
    $game_party.gain_item(@equips[slot_id].object, 1)
    if item.nil?
      @equips[slot_id].object = nil
    elsif item.is_weapon?
      @equips[slot_id].object = $game_party.weapons.find{|x| x.nid == item.nid}
    else
      @equips[slot_id].object = $game_party.armors.find{|x| x.nid == item.nid}
    end
    $game_party.lose_item(item, 1)
    if item.is_a?(Tidloc::CustomEquip::Base)
      item.execute_commands("Equip")
      if item.skills?
        temp = item.skills
        if $imported["Tidloc-CustomSkills"]
          temp.each{|s|
            self.learn_skill s
          }
        else
          for i in 0...temp.size
            self.learn_skill(i) if temp[i] > 0
          end
        end
      end
    end
    refresh
  end
  def equippable?(item)
    return false unless item.is_a?(Tidloc::CustomEquip::Base)
    return false if equip_type_sealed?(item.etype_id)
    return false if   @level < item.p_level
    return false if param(0) < item.p_hp
    return false if param(1) < item.p_mp
    return false if param(2) < item.p_str
    return false if param(3) < item.p_def
    return false if param(4) < item.p_int
    return false if param(5) < item.p_mdf
    return false if param(6) < item.p_agi
    return false if param(7) < item.p_luc
    return false if $imported["Tidloc-CustomDura"] && item.durability && item.durability <= 0
    return equip_wtype_ok?(item.wtype_id) if item.is_a?(Tidloc::CustomEquip::Weapon)
    return equip_atype_ok?(item.atype_id) if item.is_a?(Tidloc::CustomEquip::Armor)
    return false
  end

  alias wo_tidloc_xparam xparam
  def xparam(xparam_id)
    temp = wo_tidloc_xparam(xparam_id)
    self.equips.compact.each{|i|
      temp += i.xparam(xparam_id) if i.object && i.object.is_a?(Tidloc::CustomEquip::Base)
    }
    temp += set_bonus[:xparam][xparam_id] if $imported["Tidloc-DiabloSet"] && set_bonus && set_bonus[:xparam][xparam_id]
    return temp
  end
  alias wo_tidloc_sparam sparam
  def sparam(sparam_id)
    temp = wo_tidloc_sparam(sparam_id)
    self.equips.compact.each{|i|
      temp += i.sparam(sparam_id) if i.object.is_a?(Tidloc::CustomEquip::Base)
    }
    temp += set_bonus[:sparam][sparam_id] if $imported["Tidloc-DiabloSet"] && set_bonus && set_bonus[:sparam][sparam_id]
    return temp
  end
  def init_equips(equips)
    @equips = Array.new(equip_slots.size) { Game_BaseItem.new }
    equips.each_with_index do |item_id, i|
      etype_id = index_to_etype_id(i)
      slot_id = empty_slot(etype_id)
      @equips[slot_id].set_equip(etype_id == 0, item_id) if slot_id
    end
    refresh
  end
  def set_bonus
    bonus = { :param  => [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
             :xparam  => [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
             :sparam  => [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], 
             :command => [],
             :setnote => "", }
    sets = []
    self.equips.compact.each{|e|
      if e.set_id > 0
        sets.push e.set_id
      end
    }
    return bonus if sets.compact.count<2
    while sets.compact.count>1
      num = self.equips.compact.find_all{|s| s.set_id == sets[0]}.map{|e| Bitmap.html_decode(e.name)}.uniq.count
      if num > 1
        temp = Tidloc::CustomEquip::Set.ids[sets[0]]
        bonus[:param].count.times{|i|
          bonus[:param][i] += temp.fix[num][i]
        }
        bonus[:xparam].count.times{|i|
          bonus[:xparam][i] += temp.b_xparam[num][i]
        }
        bonus[:sparam].count.times{|i|
          bonus[:sparam][i] += temp.b_sparam[num][i]
        }
        bonus[:command] = temp.commands[num]
        bonus[:setnote] = temp.set_note[num]
      end
      sets.delete_if{|s| s == sets[0]}
    end
    bonus
  end
end


class Window_ShopSell < Window_ItemList
  alias wo_tidloc_ce_include include?
  def include?(item)
    if self.cat_window && item.is_a?(Tidloc::CustomEquip::Base) && self.cat_window.index > 0
      return false if Bitmap.html_decode(item.item.name) != self.cat_window.group[self.cat_window.index]
    end
    return wo_tidloc_ce_include item
  end
end
  
class Window_EquipItem < Window_ItemList
  def include?(item)
    if self.cat_window && item.is_a?(Tidloc::CustomEquip::Base) && self.cat_window.index > 0
      return false if Bitmap.html_decode(item.item.name) != self.cat_window.group[self.cat_window.index]
    end
    return true if item == nil
    return false unless item.is_a?(Tidloc::CustomEquip::Base)
    return false if item.is_a?(Tidloc::CustomEquip::Weapon) && !item.inv
    return false if item.is_a?(Tidloc::CustomEquip::Armor)  && !item.inv
    return false if @slot_id < 0
    return false if item.etype_id != @actor.equip_slots[@slot_id]
    if Tidloc::Use_mod[:accessoires] && item.note =~ Tidloc::Notetags[7][3]
      ids = eval($1)
      if ids.is_a?(Integer)
        return false if @slot_id-3 != ids
      elsif ids.is_a?(Array)
        return false unless ids.find{|i| i==@slot_id-3 }
      end
    end
    return @actor.equippable?(item)
  end
  def col_max
    return 1  if Tidloc::CustomEquip::Use_New_Info_item
    return super
  end
  def cursor_pagedown
    super unless Tidloc::CustomEquip::Use_New_Info_item
  end
  def cursor_pageup
    super unless Tidloc::CustomEquip::Use_New_Info_item
  end
  alias wo_group_rect item_rect
  def item_rect(index)
    rect = wo_group_rect index
    rect.y += item_height if Tidloc::CustomEquip::Use_Item_Group
    rect
  end
  def slot_item
    if @slot_id == 0
      return :weapon
    else 
      return @slot_id 
    end
  end
end

class Game_BaseItem
  def attack_skill
    object.attack_skill
  end
  def is_weapon?
    return (@class == RPG::Weapon || @class == Tidloc::CustomEquip::Weapon)
  end
  def is_armor?
    return (@class == RPG::Armor  || @class == Tidloc::CustomEquip::Armor)
  end
  alias wo_tidloc_object object
  def object
    if @class == Tidloc::CustomEquip::Weapon
      return $game_party.weapons.find{|x| x.nid == @item_id}
    elsif @class == Tidloc::CustomEquip::Armor
      return $game_party.armors.find{|x| x.nid == @item_id}
    end
    return wo_tidloc_object
  end
  def object=(item)
    @class   = nil
    @item_id = 0
    if item
      @class = item.class
      if item.is_a?(Tidloc::CustomEquip::Base)
        @item_id = item.nid
      else
        @item_id = item.id
      end
    end
  end
  def set_equip(is_weapon, item_id)
    if is_weapon
      item = $data_weapons[item_id]
      item = Tidloc::CustomEquip::gain_equip item
      return unless item
      item.inv = false
      $game_party.item_container(Tidloc::CustomEquip::Weapon).push item
    else
      item = $data_armors[item_id]
      item = Tidloc::CustomEquip::gain_equip item
      return unless item
      item.inv = false
      $game_party.item_container(Tidloc::CustomEquip::Armor).push item
    end
    self.object = item
  end
end




class Window_EquipSlot < Window_Selectable
  def cursor_pagedown
    super unless Tidloc::CustomEquip::Use_New_Info_equip
  end
  def cursor_pageup
    super unless Tidloc::CustomEquip::Use_New_Info_equip
  end
end