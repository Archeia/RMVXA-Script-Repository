
$imported = {} if $imported.nil?
$imported["Tidloc-ItemData"] = [1,2,0]
$needed = [] if $needed.nil?
$needed.push ["Tidloc-Header",[2,11,2],true,"Tidloc-ItemData"]

class RPG::Item
  alias wo_tidloc_name name
  def name
    temp = Tidloc::Header::ItemData(self.id)[:name][$tidloc_language]
    return temp if temp
    return wo_tidloc_name
  end
  def dataname
    wo_tidloc_name
  end
  def name_html
    text = "{eval= "
    Tidloc::Languages.each{|l|
      text += "if $tidloc_language==\"#{l}\";"
      temp = Tidloc::Header::ItemData(self.id)[:name][l]
      if temp
        text += "\"#{temp}\";els"
      else
        text += "\"#{wo_tidloc_name}\";els"
      end
    }
    text += "e;\"#{wo_tidloc_name}\";end}"
    return text
  end
  alias wo_tidloc_description description
  def description
    temp = Tidloc::Header::ItemData(self.id)[:desc][$tidloc_language]
    return temp if temp
    return wo_tidloc_description
  end
  def datadescription
    wo_tidloc_description
  end
  def voucher_data
    Tidloc::Header::ItemData(self.id)[:voucher]
  end
  def voucher_quality
    Tidloc::Header::ItemData(self.id)[:voucher_quality]
  end
  def commands
    Tidloc::Header::ItemData(self.id)[:commands]
  end
  def execute_commands(tag)
    self.commands.each {|x| x[0]==tag ? eval(Tidloc.exe(x[1],x[2])) : ""}
  end
end

module Tidloc;module Header;class<<self;def ItemData(item_id)
  name      = {"Def" => $data_items[item_id].dataname}
  desc      = {"Def" => $data_items[item_id].datadescription}
  command   = []
  tarot     = nil
  soulstone = nil
  voucherq  = 0
  voucher   = nil
  case item_id
  when 1 
    name["ger"] = "rote Phiole (schwach)"
    name["eng"] = "Red Vial (weak)"
    desc["ger"] = "heilt 25 LP bei einem Charakter"
    desc["eng"] = "Restores 25 HP on one ally"
  when 2
    name["ger"] = "rote Phiole (mittel)"
    name["eng"] = "Red Vial (medium)"
    desc["ger"] = "heilt 35 LP bei einem Charakter"
    desc["eng"] = "Restores 35 HP on one ally"
  when 3
    name["ger"] = "rote Phiole (stark)"
    name["eng"] = "Red Vial (strong)"
    desc["ger"] = "heilt 50 LP bei einem Charakter"
    desc["eng"] = "Restores 50 HP on one ally"
  end
  return {:name     => name,
          :commands => command,
          :desc     => desc,
          :tarot    => tarot,
          :SS       => soulstone,
          :voucher  => voucher,
          :voucher_quality => voucherq
         }
end;end;end;end