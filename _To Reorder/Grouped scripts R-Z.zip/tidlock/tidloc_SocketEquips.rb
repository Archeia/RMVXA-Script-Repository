################################################################################
#    Socketed Equipment 1.6.3                                                  #
#         by Tidloc                                  (Jun-06-17)               #
#==============================================================================#
#  Script, that allows items to have sockets, like used to from Diablo 2 e.g.  #
#------------------------------------------------------------------------------#
#  To be able to socket items you need to setup four things:                   #
#  1. Each socketable item needs to be assigned an socket-level, you do this   #
#     via the notetag:                                                         #
#          <slevel=*x*>                                                        #
#  2. Each socketable item also need to be assigned how many sockets it may    #
#     have. You do this via the notetag:                                       #
#          <socket *x*,*y*>                                                    #
#     Meaning: if the item is socketed, it can have between x and y sockets    #
#  3. You need to define the items for socketing in Socket Inserts (example    #
#     optainable from where you got this script)                               #
#  4. before getting items (or before fight ends) you need to set up the socket#
#     level of the items you gain. the higher this socket-level is, the more   #
#     likely your item will be socketed and the more likely it may have more   #
#     slots (up to the defined maximum). set vie the script command:           #
#          Tidloc::Socket_lvl(*x*)                                             #
# (5).You can also define fixed socketing propabilites for each item. then     #
#     only WHETER the item is socketed will be calculated via the socketing-   #
#     lvl for this item. to use this make a notetag:                           #
#          <spropfix *x*>                                                      #
#     where x needs to be between 0 and 100                                    #
# (6).Sockets may have a specified type. to specify types available in your    #
#     sockets, edit Empty_Socket_BMP, as described below. the first socket type#
#     will be for items to be able to insert into all socket types. the last   #
#     will be for sockets to accept all types of insertion (if Multi_Socket    #
#     is defined as true) if you want an item to have sockets with special     #
#     types, use the following notetag:                                        #
#          <sspecial *x*,*y*)                                                  #
#     where x is the id and y is the maximum allowed number of these socket    #
#     type on the item.                                                        #
#------------------------------------------------------------------------------#
#  If the socket-level is lower then the set level of the item you obtain, it  #
#  will not be socketed and stay vanilla.                                      #
#------------------------------------------------------------------------------#
#  To insert items into sockets, a own scene has been made. To call it use the #
#  script command:                                                             #
#     Tidloc.exe "Socket",:call,*x*                                            #
#  where x is the amount of Money charged per insertion. if you want it to be  #
#  free, you can leave x out and end the command with :call                    #
#------------------------------------------------------------------------------#
#  description on the adjustable constants:                                    #
#   Max_Socket_Prop .... Maximum propability for a socket to be applied. may   #
#                        be overwritten vie the notetag <spropfix *x*> for     #
#                        single itema                                          #
#   Color_Socket ....... when using my HTML tagging, you can enter here a tag  #
#                        to change the color the item name is written in when  #
#                        socketed.                                             #
#   Empty_Socket_BMP ... array of Names of the image in your \Graphics\Pictures# 
#                        folder to be displayed for the sockets. the first is  #
#                        the typeless socket, the last the all-type-socket if  #
#                        Multi_Socket is true.                                 #
#   Multi_Socket ....... true/false if you use different sockettypes and want  #
#                        to have a socket, that accepts all types. (the last   #
#                        in the array then)                                    #
#==============================================================================#
#  Feel free to use this script, but please credit me for my work! ^__^        #
################################################################################


$imported = {} if $imported.nil?
$imported["Tidloc-SocketEquip"] = [1,6,3]
$needed   = [] if $needed.nil?
$needed.push ["Tidloc-Header",[2,11,1],true,"Tidloc's Socketed Equipment"]
$needed.push ["Tidloc-CustomEquip",[1,5,9],true,"Tidloc's Socketed Equipment"]



module Tidloc
  
  Keys = {} if Keys.nil?
  Keys["Socket"] = nil
  Menu = {} if Menu.nil?
  Menu["Socket"] = false
  
  module SocketEquip
     
    Max_Socket_Prop    = 70
    Color_Socket       = "<color=#ffafaf>"
    Empty_Socket_BMP   = ["Socket","Socket_1","Socket_2","Socket_3","Socket_4","Socket_5","Socket_all"]
    Multi_Socket       = true
    Show_Lvl_Up        = false
    Refund_On_Unsocket = false
    
    Opacity            = 255
    SocketBackground   = nil
    Socket_BGS         = nil
    
    Notetags = [/<slevel=([0-9]+)>/i,
                /<socket ([0-9]+),([0-9]+)>/i,
                /<spropfix ([0-9]+)>/i,
                ["<sspecial ",",([0-9]+)>"],
                ]
  end
    
  module Vocabs;class<<self
    def SocketEquip(code,lang)
      if    lang == "ger"
        case code
        when "Name"; return "Sockeln"
        when "Desc"; return "Sockel"
        
        when "Help"; return "Hier kann man ungesockelte Ausrüstungsgegenstände"+
            "Sockeln. Hierfür einfach den zu sockelnden Gegenstand auswählen"+
            "und "+eval(Tidloc::Help["Enter"])+" drücken."
        when "in";   return "in"
        end
      elsif lang == "eng"
        case code
        when "Name"; return "Socket"
        when "Desc"; return "Socket"
          
        when "Help"; return "In this scene you can socket unsocketed equipment."+
             " To do so, simply choose the item to socket and press "+
             eval(Tidloc::Help["Enter"])+"."
        when "in";   return "in"
        end
      end
    end
  end;end
    
################################################################################
#                                                                              #
################################################################################
  module CustomEquip
    class Socket
      attr_accessor :name
      attr_accessor :descr
      attr_accessor :prere
      attr_accessor :used
      attr_accessor :icon
      attr_accessor :id
      attr_accessor :s_type
      attr_accessor :t_c
      attr_accessor :t_id
      
      attr_accessor :iitem
      
      attr_accessor :fix
      attr_accessor :random
      attr_accessor :random1
      attr_accessor :random2
      attr_accessor :b_xparam
      attr_accessor :b_sparam
      
      attr_accessor :skills
      
      attr_accessor :commands
      
      attr_accessor :_exp_enabled
      attr_accessor :_exp_needed
      attr_accessor :_exp_lvl
      attr_accessor :_exp_exp
      attr_accessor :_exp_next
      
      def initialize(insert_types)
        self.name     = ""
        self.descr    = ""
        self.used     = false
        self.icon     = 1
        self.id       = 0
        self.s_type   = insert_types[rand(insert_types.size)]
        self.t_c      = 0
        self.t_id     = 0
        self.item     = nil
        self.prere  = [0,0,0,0,0,0,0,0,0,0,0]
        self.fix      = [0,0,0,0,0,0,0,0,0,0]
        self.random   = [0,0,0,0,0,0,0,0,0,0]
        self.random1  = [0,0,0,0,0,0,0,0,0,0]
        self.random2  = [0,0,0,0,0,0,0,0,0,0]
        self.b_xparam = [0,0,0,0,0,0,0,0,0,0]
        self.b_sparam = [0,0,0,0,0,0,0,0,0,0]
        self.skills   = nil
        self.commands = []
        self._exp_enabled = false
      end
      def bonus
        temp = []
        Tidloc::Vocabs.Header("Params",$tidloc_language).count.times{|i|
          temp.push self.fix[i] + self.random[i]
        }
        return temp
      end
      def item=(item)
        self.iitem   = item
        if self.skills && $game_system
          $game_system.tidloc_skills_count += 1
          temp = self.skills
          self.skills = Tidloc::CustomSkills::Base.new $game_system.tidloc_skills_count
          self.skills.object = $data_skills[temp]
          self.skills.commands = Tidloc::Header::SkillData(temp)[:commands]
        end
      end
      def item
        self.iitem
      end
      def set_attr(v)
        self.fix = [0,0,v,0,v,0,v,v,v,v,0,1.0]
        return self
      end
      def set_rand
        temp = []
        Tidloc::Vocabs.Header("Params",$tidloc_language).count.times{|i|
          temp.push (self.random1[i] + rand(self.random2[i] - self.random1[i])).to_i
        }
        self.random = temp.clone
        return self
      end
      def set_price(v)
        self.fix[10] = v
        return self
      end
      def price
        return self.fix[10] ? self.fix[10] : 0
      end
      def xparam(id)
        b_xparam[id]
      end
      def sparam(id)
        b_sparam[id]
      end
      def gain_exp(exp)
        $game_temp.tidloc[:socket] = self
        return unless self._exp_enabled
        self._exp_exp += exp * _exp_rate
        if self._exp_exp >= self._exp_next
          self._exp_lvl += 1
          self._exp_exp -= self._exp_next
          self._exp_next = 0
          if Tidloc::SocketEquip::Show_Lvl_Up && $imported["Tidloc-MessageWindow"]
            text  = $game_temp.tidloc[:socket].name + " " +
                    Tidloc::Vocabs.SocketEquip("in",$tidloc_language) + " " +
                    $game_temp.tidloc[:actor].name + "'s " +
                    $game_temp.tidloc[:item].name + " " +
                    Tidloc::Vocabs.CustomEquip("LVLUP",$tidloc_language) + " " +
                    $game_temp.tidloc[:item]._exp_lvl.to_s
            Tidloc.exe(text,:SmallText)
          end
          exp_check_for_next_lvl
        end
      end
      def exp_check_for_next_lvl
        return unless self._exp_enabled
        self._exp_next = self._exp_needed[self._exp_lvl]
      end
    end
    
    class Base
      attr_accessor :sockets
      attr_accessor :temp_socket
      attr_accessor :temp_id
      
      attr_accessor :attach_info
      attr_accessor :attach_info_added
      
      def socket_init
        self.sockets     = []
        self.temp_socket = nil
        self.temp_id     = -1
        self.attach_info = Tidloc::CustomEquip::Socket.new [0]
        self.attach_info_added = false
        set_sockets($game_temp._tidloc_new_socket_lvl, self) if $game_temp._tidloc_new_socket_lvl > 0
      end
      def set_sockets(item_lvl,item)
        self.sockets     = []
        return unless item.note =~ Tidloc::SocketEquip::Notetags[0]
        return if item_lvl < $1.to_i
        prop = [item_lvl - $1.to_i,Tidloc::SocketEquip::Max_Socket_Prop].min
        prop = $1.to_i if item.note =~ Tidloc::SocketEquip::Notetags[2]
        if item.note =~ Tidloc::SocketEquip::Notetags[1]
          num = [$1.to_i,$2.to_i]
          for i in 0...num[1]
            if i < num[0] || rand(100) < prop
              sockets_insert = [0]
              if Tidloc::SocketEquip::Empty_Socket_BMP.size > 1
                for i in 1...(Tidloc::SocketEquip::Empty_Socket_BMP.size-2)
                  temp = 0
                  if self.note =~ /#{Tidloc::SocketEquip::Notetags[3][0]}#{i}#{Tidloc::SocketEquip::Notetags[3][1]}/i
                    self.sockets.each{|x| temp += 1 if x.s_type == i}
                    sockets_insert.push i if temp < $1.to_i 
                  end
                end
                sockets_insert.push Tidloc::SocketEquip::Empty_Socket_BMP.size-1 if Tidloc::SocketEquip::Multi_Socket
              end
              self.sockets.push Tidloc::CustomEquip::Socket.new(sockets_insert)
            end
          end
        end
      end
      def apply_temp(item,socketid)
        if (item.is_a?(Tidloc::CustomEquip::Base) && item.attach_info_added)
          self.temp_socket = item.attach_info.clone
          self.temp_socket.set_rand
          self.temp_socket.item = item.nid
          self.temp_id = socketid
          return true
        elsif !item.nil? && Tidloc::CustomEquip::Sockets.item_ids.find{|x| x == item.id}
          self.temp_socket = Tidloc::CustomEquip::Sockets.item_to_id(item.id).clone
          self.temp_socket.set_rand
          self.temp_socket.item = item.id
          self.temp_id = socketid
          return true
        end
        self.temp_id     = -1
        self.temp_socket = nil
        return false
      end
      def attach_temp
        self.sockets[self.temp_id] = self.temp_socket if self.temp_socket
        self.temp_id     = -1
        self.temp_socket = nil
      end
      def apply_socket(socket,item)
        if (item.is_a?(Tidloc::CustomEquip::Base) && item.attach_info_added)
          self.sockets[socket].commands.each{|x|
            eval(Tidloc.exe(x[1], x[2])) if x[0]=="Socket Clear"
          }
          $game_party.gain_item(self.sockets[socket].item,1) if Tidloc::SocketEquip::Refund_On_Unsocket
          self.sockets[socket] = item.attach_info.clone
          self.sockets[socket].set_rand
          self.sockets[socket].item = item
          $game_party.lose_item(item,1)
          self.sockets[socket].commands.each{|x|
            eval(Tidloc.exe(x[1], x[2])) if x[0]=="Socket Attach"
          }
          return true
        elsif Tidloc::CustomEquip::Sockets.item_ids.find{|x| x == item.id} 
          self.sockets[socket].commands.each{|x|
            eval(Tidloc.exe(x[1], x[2])) if x[0]=="Socket Clear"
          }
          $game_party.gain_item(self.sockets[socket].item,1) if Tidloc::SocketEquip::Refund_On_Unsocket
          self.sockets[socket] = Tidloc::CustomEquip::Sockets.item_to_id(item.id).clone
          self.sockets[socket].set_rand
          self.sockets[socket].item = item
          $game_party.lose_item(item,1)
          self.sockets[socket].commands.each{|x|
            eval(Tidloc.exe(x[1], x[2])) if x[0]=="Socket Attach"
          }
          return true
        end
        return false
      end
    end
    class<<self
      def load_Sockets
        return Tidloc::CustomEquip::Sockets.database if $imported["Tidloc-SocketInsert"]
        return nil
      end
    end
  end
  class<<self
    def Socket_lvl(lvl)
      $game_temp._tidloc_new_socket_lvl=lvl if $game_temp
    end
  end
end
   



module Tidloc;module CustomEquip
class Socket_Gold_Window < Window_Gold
  def initialize(value)
    @cost      = value
    super()
    self.x     = Graphics.width/2
    refresh
  end
  def window_width
    return Graphics.width/2
  end
  def draw_currency_value(value, unit, x, y, width)
    cx = text_size(unit).width
    if Tidloc::Money_Icon
      draw_icon(Tidloc::Money_Icon,x,y)
    elsif Tidloc::Money_Img
      image=Cache.picture(Tidloc::Money_Img)
      contents.blt(x,y,image,image.rect)
    else
      change_color(system_color)
      draw_text(x, y, Graphics.width/3, line_height, unit, 2)
      change_color(normal_color)
    end
    draw_text(x, y, Graphics.width/3 - cx - 2, line_height, value, 2)
    draw_text(Graphics.width/3+10,y,Graphics.width/6,line_height," / #{@cost}") if @cost > 0
  end
end
class Socket_Item_Window < Window_ItemList
  attr_accessor :item_window
  attr_accessor :socket
  attr_accessor :target_item
  def initialize(x, y, width, height)
    super(x, y, width, height)
    self.item_window = nil
    self.socket = 0
  end
  def include?(item)
    return false unless target_item
    if item.is_a?(Tidloc::CustomEquip::Base) && item.attach_info_added && item.inv
      temp = item.attach_info
      if temp.t_c == 0 || (temp.t_c == 1 && target_item.is_a?(Tidloc::CustomEquip::Weapon)) || (temp.t_c == 2 && target_item.is_a?(Tidloc::CustomEquip::Armor))
        if temp.t_id == 0 || temp.t_id == target_item.id
          return true if temp.s_type == 0
          return true if Tidloc::SocketEquip::Multi_Socket && target_item.sockets[socket].s_type == Tidloc::SocketEquip::Empty_Socket_BMP.size-1
          return true if target_item.sockets[socket].s_type == temp.s_type
        end
      end
    end
    if item.is_a?(RPG::Item) && Tidloc::CustomEquip::Sockets.item_ids.find{|x| x==item.id}
      temp = Tidloc::CustomEquip::Sockets.item_to_id(item.id)
      if temp.t_c == 0 || (temp.t_c == 1 && target_item.is_a?(Tidloc::CustomEquip::Weapon)) || (temp.t_c == 2 && target_item.is_a?(Tidloc::CustomEquip::Armor))
        if temp.t_id == 0 || temp.t_id == target_item.id
          return true if temp.s_type == 0
          return true if Tidloc::SocketEquip::Multi_Socket && target_item.sockets[socket].s_type == Tidloc::SocketEquip::Empty_Socket_BMP.size-1
          return true if target_item.sockets[socket].s_type == temp.s_type
        end
      end
    end
    return false
  end
  def current_item_enabled?
    true
  end
  def enable?(item)
    true
  end
  def col_max
    1
  end
  def process_cursor_move
    return unless cursor_movable?
    last_index = @index
    cursor_down (Input.trigger?(:DOWN))  if Input.repeat?(:DOWN)
    cursor_up   (Input.trigger?(:UP))    if Input.repeat?(:UP)
    Sound.play_cursor if @index != last_index
  end
  def call_update_help
    return unless self.item_window && active && get_socket_info
    self.item_window.reset_tempitem
    self.item_window.item.temp_socket = get_socket_info if get_socket_info
    self.item_window.item.temp_id = self.socket
    self.item_window.refresh
  end
  def get_socket_info
    if    item.is_a?(RPG::Item)
      return Tidloc::CustomEquip::Sockets.item_to_id(item.id)
    elsif item.is_a?(Tidloc::CustomEquip::Base)
      return item.attach_info.clone if item.attach_info_added
      return nil
    end
  end
  def process_cursor_move
    return unless cursor_movable?
    last_index = @index
    cursor_down (Input.trigger?(:DOWN))  if Input.repeat?(:DOWN)
    cursor_up   (Input.trigger?(:UP))    if Input.repeat?(:UP)
    Sound.play_cursor if @index != last_index
  end
end
class Socket_Source_Window < Window_ItemList
  def initialize(*args)
    super(*args)
    self.opacity = Tidloc::SocketEquip::Opacity
  end
  def include?(item)
    return false unless item.is_a?(Tidloc::CustomEquip::Base)
    return true  if item.inv && item.sockets.size > 0
    return false
  end
  def current_item_enabled?
    true
  end
  def enable?(item)
    true
  end
  def col_max
    1
  end
  def process_cursor_move
    return unless cursor_movable?
    last_index = @index
    cursor_down (Input.trigger?(:DOWN))  if Input.repeat?(:DOWN)
    cursor_up   (Input.trigger?(:UP))    if Input.repeat?(:UP)
    Sound.play_cursor if @index != last_index
  end
end
class Socket_Window < Window_Selectable
  attr_accessor :max_sockets
  def initialize(x, y, width, height)
    super(x, y, width, height)
    self.max_sockets = 1
  end
  def col_max
    return 6
  end
  def item_max
    self.max_sockets ? self.max_sockets : 1
  end
  def item_rect(index)
    rect = Rect.new
    rect.width = 24
    rect.height = 24
    rect.x = (index % col_max * 28) + 34
    rect.y = (index / col_max * line_height) + line_height*3.5 - oy
    rect
  end
  def ensure_cursor_visible
  end
  def process_cursor_move
    return unless cursor_movable?
    last_index = @index
    cursor_down (Input.trigger?(:DOWN))  if Input.repeat?(:DOWN)
    cursor_up   (Input.trigger?(:UP))    if Input.repeat?(:UP)
    cursor_right(Input.trigger?(:RIGHT)) if Input.repeat?(:RIGHT)
    cursor_left (Input.trigger?(:LEFT))  if Input.repeat?(:LEFT)
    Sound.play_cursor if @index != last_index
  end
end
    
    
class Scene_Socket < Scene_Base
  def initialize(price=0)
    @price = price
  end
  def start
    super
    create_item_window
    create_source_window
    create_gold_window if @price > 0
    create_socket_window
    create_info_window
    create_tid_help    if Tidloc::Keys["Help"]
    create_background  if Tidloc::SocketEquip::SocketBackground
    autoplay           if Tidloc::SocketEquip::Socket_BGS
  end
  def create_item_window
    @item_window = Tidloc::CustomEquip::Socket_Item_Window.new 0,0,Graphics.width/2,Graphics.height
    @item_window.set_handler(:ok,     method(:on_item_ok))
    @item_window.set_handler(:cancel, method(:on_item_cancel))
    @item_window.refresh
    @item_window.hide.deactivate.index = -1
  end
  def create_socket_window
    @socket_window = Tidloc::CustomEquip::Socket_Window.new Graphics.width/2, (@price>0 ? @gold_window.height : 0), Graphics.width/2, Graphics.height- (@price>0 ? @gold_window.height : 0)
    @socket_window.set_handler(:ok,     method(:on_socket_ok))
    @socket_window.set_handler(:cancel, method(:on_socket_cancel))
    @socket_window.refresh
    @socket_window.z = 2000
    @socket_window.opacity = 0
    @socket_window.show.deactivate.index = -1
  end
  def create_source_window
    @source_window = Tidloc::CustomEquip::Socket_Source_Window.new 0,0,Graphics.width/2,Graphics.height
    @source_window.set_handler(:ok,     method(:on_source_ok))
    @source_window.set_handler(:cancel, method(:return_scene))
    @source_window.refresh
    @source_window.show.activate
    @source_window.index = 0 if @source_window.item_max > 0
  end
  def create_gold_window
    @gold_window   = Tidloc::CustomEquip::Socket_Gold_Window.new @price
  end
  def create_info_window
    @info_window = Tidloc::CustomEquip::Window_ShopStatus2.new Graphics.width/2, (@price>0 ? @gold_window.height : 0), Graphics.width/2, Graphics.height- (@price>0 ? @gold_window.height : 0)
    @info_window.scene = :item
    @info_window.opacity = Tidloc::SocketEquip::Opacity
    @source_window.help_window = @info_window
    @item_window.item_window = @info_window
  end
  def create_tid_help
    @tidhelp_window = Tidloc::Window_Tid_Help.new
    text = Tidloc::Vocabs.SocketEquip("Help",$tidloc_language)
    @tidhelp_window.text = text
  end
  def autoplay
    RPG::BGS.new(Tidloc::SocketEquip::Socket_BGS,50,100).play
  end
  def create_background
    @background_window   = Window_Base.new -12,-36,Graphics.width+32,Graphics.height+64
    @background_window.z = 0
    @background_window.opacity = 0
    @background_window.draw_html 0,0,Graphics.width,Graphics.height,
    "<img=#{Tidloc::SocketEquip::SocketBackground}>"
  end
  
  def on_source_ok
    if @source_window.item.nil? || @source_window.item.sockets.nil? ||
            @source_window.item_max <= 0 || @info_window.item.nil?
      return_scene
      return
    end
    @socket_window.activate
    @socket_window.max_sockets = @source_window.item.sockets.size
    @socket_window.opacity = 0
    @socket_window.index   = 0
    @info_window.item = @source_window.item
    @info_window.scene = :socket
  end
  def on_socket_ok
    @source_window.hide.deactivate
    @item_window.target_item = @source_window.item
    @item_window.socket = @socket_window.index
    @item_window.refresh
    @item_window.show.activate.index = 0
    @info_window.reset_tempitem
  end
  def on_socket_cancel
    @socket_window.index = -1
    @source_window.show.activate
    @info_window.scene = :item
  end
  def on_item_ok
    if @item_window.item.nil?
      on_item_cancel
      return
    end
    if $game_party.gold < @price
      Sound.play_buzzer
      @item_window.show.activate.index = 0
      return
    end
    $game_party.lose_gold @price
    temp = @info_window.item.sockets[@socket_window.index].s_type
    $game_party.gain_item(@info_window.item.sockets[@socket_window.index].item,1) if Tidloc::SocketEquip::Refund_On_Unsocket
    @info_window.item.sockets[@socket_window.index] = @item_window.get_socket_info
    @info_window.item.sockets[@socket_window.index].s_type = temp
    @info_window.item.sockets[@socket_window.index].exp_check_for_next_lvl
    @info_window.item.sockets[@socket_window.index].item = @item_window.item
    $game_party.lose_item(@item_window.item,1)
    @item_window.deactivate.hide.refresh
    @item_window.target_item = nil
    @gold_window.refresh if @gold_window
    @info_window.refresh
    @source_window.show.refresh
    @socket_window.activate
  end
  def on_item_cancel
    @item_window.hide.deactivate.index = -1
    @item_window.target_item = nil
    @info_window.reset_tempitem
    @info_window.refresh
    @source_window.show
    @socket_window.activate
  end
  def update_all_windows
    if @tidhelp_window.active
      if Input.trigger?(:C) || Input.trigger?(:B)
        @tidhelp_window.hide.deactivate
      end
      return
    end
    if Tidloc::Keys["Help"] && Input.trigger?(Tidloc::Keys["Help"])
      @tidhelp_window.show.activate
    end
    super
    if    Input.press?(:R)
      @info_window.oy = [[@info_window.oy+5,@info_window.contents_height-Graphics.height].min,0].max unless @info_window.item.is_a?(RPG::Item)
      @socket_window.oy = @info_window.oy
    elsif Input.press?(:L)
      @info_window.oy = [@info_window.oy-5,0].max unless @info_window.item.is_a?(RPG::Item)
      @socket_window.oy = @info_window.oy
    end
  end
  def pre_terminate
    RPG::BGS.stop
  end
end
end;end