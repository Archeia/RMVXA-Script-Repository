################################################################################
#    Exp Equipment 1.2.0                                                       #
#         by Tidloc                                  (Jun-21-17)               #
#==============================================================================#
#  Enhancement for my Custom Equipment script.                                 #
#  At first I implemented this enhancement directly into the main script, but  #
#  it felt more natural for that script to only be the basic and extracting    #
#  the exp handling into this new script.                                      #
#------------------------------------------------------------------------------#
#  Notetags for EXP-items:                                                     #
#    <exp-item>  item can gain exp and therefore level up. levels have to be   #
#         specified via one of the next commands, if both specified, the first #
#         will be used as long as lvls are specified:                          #
#    <exp-lvl *x*,*y*> item needs y Exp to raise from level x-1 to level x     #
#    <exp-rec *x*,*y*> recursive calculation. item needs x Exp to raise from   #
#         level 1 to 2. for each level after, the Exp needed are multiplied    #
#         with y. therefor for level 3 it needs x*y Exp, for level 4 it needs  #
#         x*y*y Exp and so on...                                               #
#    <exp-lvlm *x*>  defines the maximum level an item can achieve             #
#    <exp-price *x*> defines the price maniulation per level achieved. x has   #
#         to be a floating value between 0 and 1 for lowering the price, over  #
#         1 for raising the price. If it shall stay at normal, no need for     #
#         this notetag.                                                        #
#    <exp-bonus *x*> an array of bonus attributes per lvl, looking like:       #
#           [hp, mp, str, def, mag, mdf, agi, luc, dex, vit]                   #
#        in each space write the value you want the lvl to boost that atribute #
#    <exp-lvlbon *x*,*y*> defines a specific bonus for a specific level. x is  #
#        the level, this bonus gets specified for, y is like above an array of #
#        bonus values for the achieved level                                   #
#    <exp-lvlcom *x*,*c*> upon reaching the level *x* the script command *c*   #
#        will be executed                                                      #
#==============================================================================#
#  COMMANDs for Exp items (enhanced coding stuff)                              #
#     "Level Up" ...... command for when the item gains a level.               #
#     "Level Max" ..... command for when the item reaches the maximum possible #
#                       level.                                                 #
#==============================================================================#
#  Feel free to use this script, but please credit me for my work! ^__^        #
################################################################################

$imported = {} if $imported.nil?
$imported["Tidloc-ExpEquip"] = [1,2,0]
$needed   = [] if $needed.nil?
$needed.push ["Tidloc-Header",[2,13,11],true,"Tidloc's Exp Equipment"]
$needed.push ["Tidloc-CustomEquip",[1,7,2],true,"Tidloc's Exp Equipment"]

module Tidloc
  module Exp_Equip
    Show_Lvl_Up = true
    Notetags =  { :exp_item   =>              /<exp-item>/i,
                  :exp_rate   =>              /<exp-rate (.*)>/i,
                  :exp_level_exp_direct    => "<exp-lvl |,([0-9]+)>",
                  :exp_level_exp_recursive => /<exp-rec ([0-9]+),(.*)>/i,
                  :exp_level_max   =>         /<exp-lvlm ([0-9]+)>/i,
                  
                  :exp_bonus       =>         /<exp-bonus \[([0-9]+),([0-9]+),([0-9]+),([0-9]+),([0-9]+),([0-9]+),([0-9]+),([0-9]+)\]>/i,
                  :exp_lvl_bonus   =>         "<exp-lvlbon |,\[([0-9]+),([0-9]+),([0-9]+),([0-9]+),([0-9]+),([0-9]+),([0-9]+),([0-9]+)\]>",
                  :exp_lvl_command =>         "<exp-lvlcom |,(.*)>",
                  
                  :exp_lvl_dmg     =>         "<exp-lvl-dmg |,(.*)>",
                  :exp_lvl_mdmg    =>         "<exp-lvl-mdmg |,(.*)>",
                  :exp_lvl_def     =>         "<exp-lvl-def |,(.*)>",
                  :exp_lvl_mdef    =>         "<exp-lvl-mdef |,(.*)>",
                }
    Commands =  { :lvl_up => "Level Up",
                  :lvl_max => "Level Max"
                }
  end
  module Vocabs;class<<self
    def ExpEquip(code,lang)
      if    lang == "ger"
        case code
        when "LVLI"; return "Level-Item"
        when "IEXP"; return " Erfahrung"
        when "ILVL"; return "Item-Stufe"
        when "INED"; return "  benötigt"
        when "LVLUP";return "erreicht Stufe"
        end
      elsif lang == "eng"
        case code
        when "LVLI"; return "Level-Item"
        when "IEXP"; return "Experience"
        when "ILVL"; return "Item-Level"
        when "INED"; return "    needed"
        when "LVLUP";return "reaches level"
        end
      end
    end
  end;end

################################################################################
#                                                                              #
################################################################################
  module CustomEquip
    class Base < Game_BaseItem
      attr_accessor :_exp_enabled
      attr_accessor :_exp_lvl
      attr_accessor :_exp_exp
      attr_accessor :_exp_next
      attr_accessor :_exp_lvl_max
      
      def exp_init
        if self.note =~ Tidloc::Exp_Equip::Notetags[:exp_item]
          self._exp_enabled = true
          self._exp_lvl     = 0
          self._exp_exp     = 0
          self._exp_lvl_max = false
          exp_check_for_next_lvl
        else
          self._exp_enabled = false
        end
      end
      def _exp_rate
        if self.note =~ Tidloc::Exp_Equip::Notetags[:exp_rate]
          return $1.to_f*Tidloc::CustomEquips::Exp_Rate
        end
        return Tidloc::CustomEquip::Exp_Rate
      end
      def exp_check_for_next_lvl
        if note =~ Tidloc::Exp_Equip::Notetags[:exp_level_max]
          if $1.to_i <= self._exp_lvl
            self._exp_exp     = 0
            self._exp_lvl_max = true
            execute_commands(Tidloc::Exp_Equip::Commands[:lvl_max])
            return
          end
        end
        if note =~ /#{Tidloc::Exp_Equip::Notetags[:exp_level_exp_direct].gsub("|",(self._exp_lvl+1).to_s)}/i
          self._exp_next = $1.to_i
          return
        end
        if note =~ Tidloc::Exp_Equip::Notetags[:exp_level_exp_recursive]
          self._exp_next = $1.to_i * ($2.to_f)**(self._exp_lvl)
        else
          self._exp_exp = 0
        end
      end
      def exp_check_for_bonus
        if    self.note =~ /#{Tidloc::Exp_Equip::Notetags[:exp_lvl_bonus].gsub("|",self._exp_lvl.to_s)}/i
          self.lvl_param[0] += $1.to_i
          self.lvl_param[1] += $2.to_i
          self.lvl_param[2] += $3.to_i
          self.lvl_param[3] += $4.to_i
          self.lvl_param[4] += $5.to_i
          self.lvl_param[5] += $6.to_i
          self.lvl_param[6] += $7.to_i
          self.lvl_param[7] += $8.to_i
        elsif self.note =~ Tidloc::Exp_Equip::Notetags[:exp_bonus]
          self.lvl_param[0] += $1.to_i
          self.lvl_param[1] += $2.to_i
          self.lvl_param[2] += $3.to_i
          self.lvl_param[3] += $4.to_i
          self.lvl_param[4] += $5.to_i
          self.lvl_param[5] += $6.to_i
          self.lvl_param[6] += $7.to_i
          self.lvl_param[7] += $8.to_i
        end
        if    self.note =~ /#{Tidloc::Exp_Equip::Notetags[:exp_lvl_command].gsub("|",self._exp_lvl.to_s)}/i
          eval $1
        end
      end
      def exp_check_lvl_up
        while !(self._exp_lvl_max) && (self._exp_exp.to_i >= self._exp_next.to_i)
          self._exp_lvl += 1
          self._exp_exp -= self._exp_next
          self._exp_next = 0
          exp_check_for_bonus
          exp_check_for_next_lvl
          execute_commands(Tidloc::Exp_Equip::Commands[:lvl_up])
        end
      end
      def item_gain_exp
        if self._exp_enabled && !(self._exp_lvl_max)
          self._exp_exp += exp*_exp_rate
          temp = self._exp_lvl.to_i
          exp_check_lvl_up
          if temp < self._exp_lvl.to_i
            if Tidloc::Exp_Equip::Show_Lvl_Up && $imported["Tidloc-MessageWindow"]
              text  = $game_temp.tidloc[:actor].name + "'s\100" +
                      $game_temp.tidloc[:item].name + " " +
                      Tidloc::Vocabs.ExpEquip("LVLUP",$tidloc_language) + " " +
                      $game_temp.tidloc[:item]._exp_lvl.to_s
              Tidloc.exe(text,:SmallText)
            end
          end
        end
      end
      
    end
  end
end