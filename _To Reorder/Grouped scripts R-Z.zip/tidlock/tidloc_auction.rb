################################################################################
#  Item Auction system 2.0.5                                                   #
#                    by Tidloc                                                 #
#==============================================================================#
#  Feel free to use it in your own RPG-Maker game.                             #
#  But please give me credits for this hell of work ^_^                        #
#------------------------------------------------------------------------------#
#  This script has been made as requested by Rook Stonetower                   #
#------------------------------------------------------------------------------#
#  This script simulates an Auction system, similar to well known internet     #
#  auction houses.                                                             #
#------------------------------------------------------------------------------#
#  To start this script you can access it via a defined Key on the map, over   #
#  a command in the main menu, or by direct call with the command:             #
#      Tidloc_Auction.call                                                     #
#  This script operates over time segments simply enter the the time steps in  #
#  minutes to the constant Auction_time. if set to 0, the time does not pass   #
#  in the auction system on it's own, only by calling the following script     #
#  command (also possible if time steps are active):                           #
#      Tidloc_Auction.process                                                  #
#  Description of the constants:                                               #
#      Use_category ... Defines if items will be categorised or all shall be   #
#                       listed in one window.                                  #
#      Time ........... Defines the minutes, that have to pass to let an hour  #
#                       go in this script. If set to 0, no progress will be on #
#                       it's own.                                              #
#      Fee_1 .......... The starting Fee in percent of the original selling    #
#                       price of the item.                                     #
#      Fee_2 .......... The fee, due for each hour of bidding in percent of    #
#                       the original selling price of the item.                #
#      Bigtime ........ limit to differ long-running auctions from short       #
#                       running.                                               #
#      Maxtime ........ maximum hours, an auction may be running.              #
#      FloodLimit ..... Maximum of same Items Listed at the same time without  #
#                       having the probability of bids reduced                 #
#      Raise .......... Sets lower and upper limit of raises a bid may have    #
#      Default_Auctionable ... Defines if items are usually free to be sold    #
#                       via auction or not. to change this, item by item put   #
#                       the <Auction> tag in the notes of that item            #
#      Default_Rarity . Sets teh default Rarity of an item. Should be 0. The   #
#                       more rare an item is, the more likely a new bid will   #
#                       be coming for that item. maximum is always 50%(except  #
#                       for rarities over 100. altered item-by-item by notetag.#
#      Super_Prop ..... Probability for having a super event (out of 10000)    #
#------------------------------------------------------------------------------#
#  Possible Tags in Notes of Items:                                            #
#      <Auction> ...... enables/disables an item to be sold in auction         #
#      <Rarity: xxx> .. sets the rarity of an item, the rarer it is, the more  #
#                       likely it will be bidden on. (over 100 increases the   #
#                       chances over the normal 50%, so be cautious to use that#
#------------------------------------------------------------------------------#
# you can change the windowcolor, tone, opacity and background of this script, #
# by editing the following constants:                                          #
#    Windowskin = "Name of the windowskin in systemfolder"                     #
#    Windowtone = [a,b,c]                                                      #
#    Opacity    = 255                                                          #
#    Background = "Name of picture in the picturefolder"                       #
# where a,b and c are the RPG-values.                                          #
#==============================================================================#
#   If any questions appear feel free to contact me!                           #
#                                         tidloc@gmx.at                        #
#                                         149436915 (ICQ)                      #
################################################################################

$imported = {} if $imported.nil?
$imported["Tidloc-Auction"] = [2,0,5]

module Tidloc
######### if you don't want to call this script via a Key on the map, simply
######### leave nil, or else put the desired Key here
  Keys = {} if Keys.nil?
  Keys["Auction"] = nil
  Menu = {} if Menu.nil?
  Menu["Auction"] = nil
  
  module Auction
    Use_category = true
    Time    = 0
    Fee_1   = 10
    Fee_2   = 0.2
    Bigtime = 500
    Maxtime = 999
    FloodLimit = 3
    Raise   = [5,15]
    
    Default_Auctionable = true
    Default_Rarity      = 0
    
    Super_Prop = 10
    
    Windowskin     = nil
    Windowtone     = nil
    Background     = nil
    Opacity        = 255
    Back_BGS       = nil
  end
  
  module Vocabs;class<<self
    def Auction(code,lang)
      if    lang == "ger"
        case code
        when "Name";     return "Auktion"
        when "Commands"; return ["Etwas Verkaufen",
                                 "Status überprüfen",
                                 "Geld abheben",
                                 "Beenden"]
        when "Hours";    return "Dauer der Auktion, maximal: "
        when "Costs";    return "Kosten:"
        when "NoAuction";return "Momentan läuft keine Auktion."
        when "Time";     return "Verbleibende Zeit"
        when "Bids";     return "Anzahl der Gebote"
        when "Bid";      return "Aktuelles Gebot"
        when "Timevocab";return "Tage"
        when "Value";    return "Verkaufswert des Gegenstandes"
        when "Money";    return "Geld erhalten"
        when "HTML_pre"; return "<color=cyan>Auktion:</color>"
        when "Items";    return "Nicht verkaufte Gegenstände"
        when "NoItem";   return "Keine Gegenstände zum Abholen bereit"
        when "Sold";     return ["Gegenstand","verkauft für"]
        when "NotSold";  return ["Gegenstand","wurde nicht verkauft."]
        when "Super_1";  return ["Ein rießen Gebot auf Gegenstand","!"]
        when "Super_2";  return ["Gegenstand","wurde aus dem Auktionshaus gestohlen..."]
        end
      elsif lang == "eng"
        case code
        when "Name";     return "Auction"
        when "Commands"; return ["List a Sale",
                                 "Check Status",
                                 "Redeem Money",
                                 "Cancel"]
        when "Hours";    return "Duration of Auction, maximum: "
        when "Costs";    return "Costs:"
        when "NoAuction";return "There are no auctions running at the moment."
        when "Time";     return "Remaining time"
        when "Bids";     return "Number of bids"
        when "Bid";      return "Best bid"
        when "Timevocab";return "days"
        when "Value";    return "Market value of the item"
        when "Money";    return "Money received"
        when "HTML_pre"; return "<color=cyan>Auction:</color>"
        when "Items";    return "Not sold items"
        when "NoItem";   return "No items to withdraw"
        when "Sold";     return ["Item","sold for"]
        when "NotSold";  return ["Item","was not sold."]
        when "Super_1";  return ["A gigantic bid happened on item","!"]
        when "Super_2";  return ["Bad news, item","has been stolen..."]
        end
      end
    end
  end;end
end

################################################################################
#                                                                              #
################################################################################

module Tidloc
  module Auction
    class Auction
      attr_accessor :item
      attr_accessor :time
      attr_accessor :price
      attr_accessor :longtime
      attr_accessor :bids
      attr_accessor :rare
      
      def initialize(item, time)
        self.item  = [(item.is_a?(RPG::Item))? 0 : (item.is_a?(RPG::Weapon))? 1 : 2,item.id]
        temp = self.item[0]*1000+self.item[1]
        $game_temp._tidloc_auction_flood[temp]  = 0 if $game_temp._tidloc_auction_flood[temp].nil?
        $game_temp._tidloc_auction_flood[temp] += 1
        $game_temp._tidloc_auction_itemcount[temp]  = 0 if $game_temp._tidloc_auction_itemcount[temp].nil?
        $game_temp._tidloc_auction_itemcount[temp] += 1
        self.time  = time
        self.price = 0
        self.bids  = 0
        self.rare  = $game_temp._tidloc_auction_rarity[temp]
        self.rare  = 1 if self.rare.nil?
        self.longtime  = (time > Tidloc::Auction::Bigtime)? true : false
        @originalprice = item.price/2
        @name          = item.name
      end
      def bid
        self.bids += 1
        self.price += 0
      end
      def process
        if rand(10000) < (10000 * calculate_probability)
          self.bids  += 1
          self.price += [(@originalprice * (rand(Tidloc::Auction::Raise[1]-Tidloc::Auction::Raise[0])+Tidloc::Auction::Raise[0])/100.0).to_i,1].max
        end
        self.time -= 1
        if self.time == 0
          cash_out
          return true
        end
        return false
      end
      def calculate_probability
        temp = 1.0/(self.bids+2.0)
        temp += (self.rare/100.0)*(0.5-temp)
        if self.price > @originalprice*(0.3+0.7*(1-($game_temp._tidloc_auction_itemcount[(self.item[0]*1000+self.item[1])]/100.0)))
          temp /= 1.0+($game_temp._tidloc_auction_itemcount[(self.item[0]*1000+self.item[1])]/100.0)
        end
        temp += 0.5 if self.longtime && self.time < 3
        if self.price > @originalprice/2 && $game_temp._tidloc_auction_flood[(self.item[0]*1000+self.item[1])] > Tidloc::Auction::FloodLimit
          if temp < 0.1
            temp /= 3
          else
            temp = 0.05
          end
        end
        return temp
      end
      def cash_out
        if self.bids > 0
          $game_temp._tidloc_auction_redeem[0] += self.price
          text = ($imported["HTML-tagging"])? Tidloc::Vocabs.Auction("HTML_pre",$tidloc_language)+" " : Tidloc::Vocabs.Auction("Name",$tidloc_language)+": "
          text += Tidloc::Vocabs.Auction("Sold",$tidloc_language)[0]+" "+@name+" "+Tidloc::Vocabs.Auction("Sold",$tidloc_language)[1]+" "+self.price.to_s
          Tidloc.exe(text,:SmallText) if $imported["Tidloc-MessageWindow"]
        else
          $game_temp._tidloc_auction_redeem[1].push self.item
          text = ($imported["HTML-tagging"])? Tidloc::Vocabs.Auction("HTML_pre",$tidloc_language)+" " : Tidloc::Vocabs.Auction("Name",$tidloc_language)+": "
          text += Tidloc::Vocabs.Auction("NotSold",$tidloc_language)[0]+" "+@name+" "+Tidloc::Vocabs.Auction("NotSold",$tidloc_language)[1]
          Tidloc.exe(text,:SmallText) if $imported["Tidloc-MessageWindow"]
        end
        temp = self.item[0]*1000+self.item[1]
        $game_temp._tidloc_auction_flood[temp] -= 1
      end
      def Super_1
        text = ($imported["HTML-tagging"])? Tidloc::Vocabs.Auction("HTML_pre",$tidloc_language)+" " : Tidloc::Vocabs.Auction("Name",$tidloc_language)+": "
        text += Tidloc::Vocabs.Auction("Super_1",$tidloc_language)[0]+" "+@name+" "+Tidloc::Vocabs.Auction("Super_1",$tidloc_language)[1]
        Tidloc.exe(text,:SmallText)
        self.bids += 1
        self.price += @originalprice/2
      end
      def Super_2
        text = ($imported["HTML-tagging"])? Tidloc::Vocabs.Auction("HTML_pre",$tidloc_language)+" " : Tidloc::Vocabs.Auction("Name",$tidloc_language)+": "
        text += Tidloc::Vocabs.Auction("Super_2",$tidloc_language)[0]+" "+@name+" "+Tidloc::Vocabs.Auction("Super_2",$tidloc_language)[1]
        Tidloc.exe(text,:SmallText)
      end
    end
    class Window_Auction_Command < Window_Command
      def initialize(x, y)
        super(x, y)
        self.windowskin = Cache.system(Tidloc::Auction::Windowskin) if Tidloc::Auction::Windowskin
        t = Tidloc::Auction::Windowtone
        self.tone.set(t[0],t[1],t[2],128) if t
        self.opacity = Tidloc::Auction::Opacity
      end
      def make_command_list
        add_command(Tidloc::Vocabs.Auction("Commands",$tidloc_language)[0], :sell)
        add_command(Tidloc::Vocabs.Auction("Commands",$tidloc_language)[1], :check)
        add_command(Tidloc::Vocabs.Auction("Commands",$tidloc_language)[2], :redeem)
        add_command(Tidloc::Vocabs.Auction("Commands",$tidloc_language)[3], :cancel)
      end
      def update_tone
        if Tidloc::Auction::Windowtone
          t = Tidloc::Auction::Windowtone
          self.tone.set(t[0],t[1],t[2],128)
        else
          super
        end
      end
    end
    class Window_ItemList2 < Window_ItemList
      def initialize(x, y, width, height)
        super(x, y, width, height)
        self.windowskin = Cache.system(Tidloc::Auction::Windowskin) if Tidloc::Auction::Windowskin
        t = Tidloc::Auction::Windowtone
        self.tone.set(t[0],t[1],t[2],128) if t
        self.opacity = Tidloc::Auction::Opacity
      end
      def include?(item)
        return true
      end
      def enable?(item)
        t  = (item.is_a?(RPG::Item))?0 : (item.is_a?(RPG::Weapon))?1000 : 2000
        t += item.id
        affordable   = ((item.price/2 * Tidloc::Auction::Fee_1/100 + $Tidloc_Auction * Tidloc::Auction::Fee_2/100 * item.price/2) <= $game_party.gold)
        buy_possible = $game_temp._tidloc_auction_possible[t]
        return false unless affordable && buy_possible && item.price > 0
        return true
      end
      def update_tone
        if Tidloc::Auction::Windowtone
          t = Tidloc::Auction::Windowtone
          self.tone.set(t[0],t[1],t[2],128)
        else
          super
        end
      end
    end
    class Window_ItemList3 < Window_ItemList_2
      def initialize(x, y, width, height)
        super(x, y, width, height)
        self.windowskin = Cache.system(Tidloc::Auction::Windowskin) if Tidloc::Auction::Windowskin
        t = Tidloc::Auction::Windowtone
        self.tone.set(t[0],t[1],t[2],128) if t
        self.opacity = Tidloc::Auction::Opacity
      end
      def enable?(item)
        return false if item.nil?
        t  = (item.is_a?(RPG::Item))?0 : (item.is_a?(RPG::Weapon))?1000 : 2000
        t += item.id
        affordable   = ((item.price/2 * Tidloc::Auction::Fee_1/100 + $Tidloc_Auction * Tidloc::Auction::Fee_2/100 * item.price/2) <= $game_party.gold)
        buy_possible = $game_temp._tidloc_auction_possible[t]
        return false unless affordable && buy_possible && item.price > 0
        return true
      end
      def update_tone
        if Tidloc::Auction::Windowtone
          t = Tidloc::Auction::Windowtone
          self.tone.set(t[0],t[1],t[2],128)
        else
          super
        end
      end
    end
    class Window_Selectable_2 < Window_Selectable
      def initialize(x, y, width, height)
        super(x, y, width, height)
        self.windowskin = Cache.system(Tidloc::Auction::Windowskin) if Tidloc::Auction::Windowskin
        t = Tidloc::Auction::Windowtone
        self.tone.set(t[0],t[1],t[2],128) if t
        self.opacity = Tidloc::Auction::Opacity
      end
      def update_tone
        if Tidloc::Auction::Windowtone
          t = Tidloc::Auction::Windowtone
          self.tone.set(t[0],t[1],t[2],128)
        else
          super
        end
      end
    end
    class Window_Help_2 < Window_Help
      def initialize
        super
        self.windowskin = Cache.system(Tidloc::Auction::Windowskin) if Tidloc::Auction::Windowskin
        t = Tidloc::Auction::Windowtone
        self.tone.set(t[0],t[1],t[2],128) if t
        self.opacity = Tidloc::Auction::Opacity
      end
      def update_tone
        if Tidloc::Auction::Windowtone
          t = Tidloc::Auction::Windowtone
          self.tone.set(t[0],t[1],t[2],128)
        else
          super
        end
      end
    end
    class Window_ItemCategory_3 < Window_ItemCategory_2
      def initialize
        super
        self.windowskin = Cache.system(Tidloc::Auction::Windowskin) if Tidloc::Auction::Windowskin
        t = Tidloc::Auction::Windowtone
        self.tone.set(t[0],t[1],t[2],128) if t
        self.opacity = Tidloc::Auction::Opacity
      end
      def update_tone
        if Tidloc::Auction::Windowtone
          t = Tidloc::Auction::Windowtone
          self.tone.set(t[0],t[1],t[2],128)
        else
          super
        end
      end
    end
    class Window_ItemCategory_4 < Window_ItemCategory
      def initialize
        super
        self.windowskin = Cache.system(Tidloc::Auction::Windowskin) if Tidloc::Auction::Windowskin
        t = Tidloc::Auction::Windowtone
        self.tone.set(t[0],t[1],t[2],128) if t
        self.opacity = Tidloc::Auction::Opacity
      end
      def update_tone
        if Tidloc::Auction::Windowtone
          t = Tidloc::Auction::Windowtone
          self.tone.set(t[0],t[1],t[2],128)
        else
          super
        end
      end
    end
  end
end






class Tidloc_Auction < Scene_Base
  def start
    $Tidloc_Auction = 1
    super
    create_help_window
    create_option_window
    create_category_window
    create_item_window
    create_info_window
    create_background if Tidloc::Auction::Background
    autoplay
  end
  def autoplay
    return false if Tidloc::Auction::Back_BGS.nil?
    RPG::BGS.new(Tidloc::Auction::Back_BGS,50,100).play
  end
  def create_help_window
    @help_window = Tidloc::Auction::Window_Help_2.new
    @help_window.viewport = @viewport
  end
  def create_info_window
    @info_window = Tidloc::Auction::Window_Selectable_2.new(0, 72, Graphics.width, Graphics.height - 72)
    @info_window.viewport = @viewport
    @info_window.visible = false
  end
  def create_option_window
    @option_window = Tidloc::Auction::Window_Auction_Command.new(0,72)
    @option_window.height = 120
    @option_window.active = true
    @option_window.set_handler(:sell,   method(:command_sell))
    @option_window.set_handler(:check,  method(:command_check))
    @option_window.set_handler(:redeem, method(:command_redeem))
    @option_window.set_handler(:cancel, method(:return_scene))
    @option_window.update
  end
  def create_category_window
    if Tidloc::Use_mod[:item_categories]
      @category_window = Tidloc::Auction::Window_ItemCategory_3.new
    else
      @category_window = Tidloc::Auction::Window_ItemCategory_4.new
    end
    @category_window.viewport = @viewport
    @category_window.help_window = @help_window
    @category_window.y = @help_window.height
    @category_window.set_handler(:ok,     method(:on_category_ok))
    @category_window.set_handler(:cancel, method(:on_category_cancel))
    @category_window.active = false
    @category_window.visible = false
  end
  def create_item_window
    if Tidloc::Use_mod[:item_categories]
      @item_window = Tidloc::Auction::Window_ItemList3.new 0,118,Graphics.width,Graphics.height-118
    else
      @item_window = Tidloc::Auction::Window_ItemList2.new 0,@help_window.height,Graphics.width,Graphics.height-@help_window.height
    end
    @item_window.viewport = @viewport
    @item_window.help_window = @help_window
    @item_window.set_handler(:ok,     method(:on_item_ok))
    @item_window.set_handler(:cancel, method(:on_item_cancel))
    @item_window.active  = false
    @item_window.visible = false
    @category_window.item_window = @item_window
  end
  def create_background
    @background_window   = Window_Base.new -12,-36,Graphics.width+32,Graphics.height+64
    @background_window.z = 0
    @background_window.opacity = 0
    @background_window.draw_html 0,0,Graphics.width,Graphics.height,
    "<img="+Tidloc::Auction::Background+">"
  end
  def command_sell
    @item_window.visible     = true
    @option_window.visible   = false
    if Tidloc::Auction::Use_category
      @category_window.visible = true
      @category_window.activate
    else
      @item_window.activate
      @item_window.select_last
    end
  end
  def command_check
    @bidid = 0
    draw_bid_status
    @option_window.visible   = false
    @info_window.visible = true
    @info_window.activate
  end
  def command_redeem
    draw_redeem_status
    @option_window.visible   = false
    @info_window.visible = true
    @info_window.activate
  end
  def on_check_cancel
    @info_window.active  = false
    @info_window.visible = false
    @option_window.visible   = true
    @option_window.activate
  end
  def on_start_ok
    $game_party.gain_gold(-((@item_window.item.price/2 * Tidloc::Auction::Fee_1/100 + $Tidloc_Auction * Tidloc::Auction::Fee_2/100 * @item_window.item.price/2)).to_i)
    $game_party.gain_item(@item_window.item,-1)
    $game_temp._tidloc_auctions[$game_temp._tidloc_auctions.size] = Tidloc::Auction::Auction.new @item_window.item, $Tidloc_Auction
    @item_window.refresh
    on_start_cancel
  end
  def on_start_cancel
    @info_window.active  = false
    @info_window.visible = false
    @item_window.visible   = true
    @item_window.activate
    if Tidloc::Auction::Use_category
      @category_window.visible = true
    end
  end
  def on_category_ok
    @category_window.active = false
    @item_window.activate
    @item_window.update
    @item_window.select_last
  end
  def on_category_cancel
    @category_window.active  = false
    @category_window.visible = false
    @item_window.visible     = false
    @option_window.visible   = true
    @option_window.activate
  end
  def on_item_ok
    if @item_window.item.nil? || @item_window.item.price <= 0
      Sound.play_buzzer
      @item_window.active = true
      return
    end
    $Tidloc_Auction = 1
    draw_astart
    @item_window.active = false
    if Tidloc::Auction::Use_category
      @category_window.visible = false
    end
    @item_window.visible       = false
    @info_window.visible       = true
    @info_window.activate
  end
  def on_item_cancel
    @item_window.active = false
    if Tidloc::Auction::Use_category
      @category_window.activate
    else
      @item_window.visible     = false
      @option_window.visible   = true
      @option_window.activate
    end
  end
  def update_all_windows
    if @info_window.active && @option_window.current_symbol == :sell
      if    Input.trigger?(:UP)
        Sound.play_cursor
        $Tidloc_Auction += 1
        $Tidloc_Auction = Tidloc::Auction::Maxtime if Input.press?(:SHIFT)
        $Tidloc_Auction = [$Tidloc_Auction, Tidloc::Auction::Maxtime, (($game_party.gold - @item_window.item.price/2 * Tidloc::Auction::Fee_1/100)/(Tidloc::Auction::Fee_2/100 * @item_window.item.price/2)).to_i].min
        $Tidloc_Auction = [$Tidloc_Auction,1].max
        draw_astart
      elsif Input.trigger?(:DOWN)
        Sound.play_cursor
        $Tidloc_Auction -= 1
        $Tidloc_Auction = 1  if Input.press?(:SHIFT)
        $Tidloc_Auction = [$Tidloc_Auction,1].max
        draw_astart
      elsif Input.trigger?(:RIGHT)
        Sound.play_cursor
        $Tidloc_Auction += 10
        $Tidloc_Auction += 90 if Input.press?(:SHIFT)
        $Tidloc_Auction = [$Tidloc_Auction, Tidloc::Auction::Maxtime, (($game_party.gold - @item_window.item.price/2 * Tidloc::Auction::Fee_1/100)/(Tidloc::Auction::Fee_2/100 * @item_window.item.price/2)).to_i].min
        $Tidloc_Auction = [$Tidloc_Auction,1].max
        draw_astart
      elsif Input.trigger?(:LEFT)
        Sound.play_cursor
        $Tidloc_Auction -= 10
        $Tidloc_Auction -= 90 if Input.press?(:SHIFT)
        $Tidloc_Auction = [$Tidloc_Auction,1].max
        draw_astart
      elsif Input.trigger?(:C)
        t = @item_window.item.id + (@item_window.item.is_a?(RPG::Weapon)?1000 : @item_window.item.is_a?(RPG::Armor)?2000 : 0)
        if (((@item_window.item.price/2 * Tidloc::Auction::Fee_1/100 + $Tidloc_Auction * Tidloc::Auction::Fee_2/100 * @item_window.item.price/2)).to_i > $game_party.gold) || !($game_temp._tidloc_auction_possible[t])
          Sound.play_buzzer
        else
          Sound.play_ok
          on_start_ok
        end
        return
      elsif Input.trigger?(:B)
        Sound.play_cancel
        on_start_cancel
        return
      end
    elsif @info_window.active && @option_window.current_symbol == :check
      if    Input.trigger?(:UP)
        Sound.play_cursor
        unless $game_temp._tidloc_auctions[0].nil?
          @bidid = [@bidid+1,$game_temp._tidloc_auctions.size-1].min
          @bidid = $game_temp._tidloc_auctions.size-1 if Input.press?(:SHIFT)
        end
        draw_bid_status
        return
      elsif Input.trigger?(:DOWN)
        Sound.play_cursor
        unless $game_temp._tidloc_auctions[0].nil?
          @bidid = [@bidid-1,0].max 
          @bidid = 0 if Input.press?(:SHIFT)
        end
        draw_bid_status        
        return
      elsif Input.trigger?(:LEFT)
        Sound.play_cursor
        unless $game_temp._tidloc_auctions[0].nil?
          @bidid = [@bidid-10,0].max 
          @bidid = [@bidid-90,0].max if Input.press?(:SHIFT)
        end
        draw_bid_status        
        return
      elsif Input.trigger?(:RIGHT)
        Sound.play_cursor
        unless $game_temp._tidloc_auctions[0].nil?
          @bidid = [@bidid+10,$game_temp._tidloc_auctions.size-1].min
          @bidid = [@bidid+90,$game_temp._tidloc_auctions.size-1].min if Input.press?(:SHIFT)
        end
        draw_bid_status
        return
      elsif Input.trigger?(:C) || Input.trigger?(:B)
        Sound.play_cancel
        on_check_cancel
        return
      end
    elsif @info_window.active && @option_window.current_symbol == :redeem
      if Input.trigger?(:C) || Input.trigger?(:B)
        Sound.play_cancel
        on_check_cancel
        return
      end
    end
    super
  end
  def draw_redeem_status
    @info_window.refresh
    @info_window.draw_text(10, 40, 600, 30,Tidloc::Vocabs.Auction("Money",$tidloc_language)+":")
    @info_window.draw_text(20, 72, 600, 30,$game_temp._tidloc_auction_redeem[0].to_s)
    $game_party.gain_gold($game_temp._tidloc_auction_redeem[0])
    @info_window.draw_text(10,110, 600, 30,Tidloc::Vocabs.Auction("Items",$tidloc_language))
    temp = $game_temp._tidloc_auction_redeem[1].size 
    if temp == 0
      @info_window.draw_text(20,142, 600, 30,Tidloc::Vocabs.Auction("NoItem",$tidloc_language))
    else
      for i in 0...temp-1
        if $game_temp._tidloc_auction_redeem[1][i][0] == 0
          item = $data_items[$game_temp._tidloc_auction_redeem[1][i][1]]
        elsif $game_temp._tidloc_auction_redeem[1][i][0] == 1
          item = $data_weapons[$game_temp._tidloc_auction_redeem[1][i][1]]
        else
          item = $data_armors[$game_temp._tidloc_auction_redeem[1][i][1]]
        end
        @info_window.draw_text(20,142+i*24, 600, 30,item.name)
        $game_party.gain_item(item,1)
      end
    end
    $game_temp._tidloc_auction_redeem = [0,[]]
  end
  def draw_astart
    @info_window.refresh
    @info_window.draw_text(10, 10, 600, 30,Tidloc::Vocabs.Auction("Hours",$tidloc_language) + Tidloc::Auction::Maxtime.to_s)
    @info_window.draw_text(20, 42, 600, 30,$Tidloc_Auction.to_s)
    @info_window.draw_text(10, 80, 600, 30,Tidloc::Vocabs.Auction("Costs",$tidloc_language))
    return if @item_window.item.nil?
    @info_window.draw_text_ex(20,112,(((@item_window.item.price/2 * Tidloc::Auction::Fee_1/100 + $Tidloc_Auction * Tidloc::Auction::Fee_2/100 * @item_window.item.price/2)).to_i).to_s+"   ("+$data_system.currency_unit+":"+$game_party.gold.to_s+")")
  end
  def draw_bid_status
    @info_window.refresh
    if $game_temp._tidloc_auctions[0].nil?
      @info_window.draw_text(25,35,550,30,Tidloc::Vocabs.Auction("NoAuction",$tidloc_language))
      return
    end
    @info_window.draw_text(10, 10,600,30,Tidloc::Vocabs.Auction("Name",$tidloc_language) + " # " + (@bidid+1).to_s)
    item = $game_temp._tidloc_auctions[@bidid].item
    item = (item[0]==0) ? $data_items[item[1]] : (item[0]==1) ? $data_weapons[item[1]] : $data_armors[item[1]]
    @help_window.set_text(item.description)
    @info_window.draw_item_name(item,15,42)
    @info_window.draw_text(20, 80,600,30,Tidloc::Vocabs.Auction("Bids",$tidloc_language) + ":   " + $game_temp._tidloc_auctions[@bidid].bids.to_s)
    @info_window.draw_text(20,112,600,30,Tidloc::Vocabs.Auction("Bid",$tidloc_language)  + ":   " + $game_temp._tidloc_auctions[@bidid].price.to_s)
    @info_window.draw_text(20,144,600,30,Tidloc::Vocabs.Auction("Value",$tidloc_language)+ ":   " + (item.price/2).to_s + " " + $data_system.currency_unit)
    @info_window.draw_text(20,176,600,30,Tidloc::Vocabs.Auction("Time",$tidloc_language) + ":   " + $game_temp._tidloc_auctions[@bidid].time.to_s + " " + Tidloc::Vocabs.Auction("Timevocab",$tidloc_language))
  end
  def Tidloc_Auction.call
    SceneManager.call(Tidloc_Auction)
  end
  def return_scene
    while !SceneManager.scene.is_a?(Scene_Map)
      SceneManager.return
    end
  end
  def Tidloc_Auction.process
    resolved = 0
    temp = $game_temp._tidloc_auctions.size
    for i in 0...temp
      if $game_temp._tidloc_auctions[i-resolved] && $game_temp._tidloc_auctions[i-resolved].process
        $game_temp._tidloc_auctions[(i-resolved)..(i-resolved+1)] = $game_temp._tidloc_auctions[i-resolved+1]
        i-=1
        resolved += 1
      end
    end
    if temp != resolved + $game_temp._tidloc_auctions.size
      temp = [temp-$game_temp._tidloc_auctions.size,$game_temp._tidloc_auctions.size]
      $game_temp._tidloc_auctions[temp[0]..temp[1]] = $game_temp._tidloc_auctions[temp[1]]
    end
    if rand(10000) < Tidloc::Auction::Super_Prop
      temp = rand($game_temp._tidloc_auctions.size)
      if rand(2)%2 == 0
        $game_temp._tidloc_auctions[temp].Super_1
      else
        $game_temp._tidloc_auctions[temp].Super_2
        $game_temp._tidloc_auctions[temp..(temp+1)] = $game_temp._tidloc_auctions[temp+1]
      end
    end
  end
  def pre_terminate
    RPG::BGS.stop
  end
  def terminate
    super
    while SceneManager.scene.is_a?(Tidloc_Auction)
      SceneManager.return
    end
  end
end