################################################################################
#  Tidloc's Header  v.2.12.2                                                   #
#                                             (Dec-22-15)                      #
#==============================================================================#
#  Feel free to use it in your own RPG-Maker game.                             #
#  But please give me credits for this hell of work ^_^                        #
#               contact:   tidloc@gmx.at                                       #
#                                  ICQ: 149436915                              #
#------------------------------------------------------------------------------#
#  the Versions may differ from script to script you use of me, but be assured #
#  to always use the highest version available, so that no incompatibility may #
#  occur.                                                                      #
#  I've decided to use this header instead of implementing everything inside   #
#  my scripts as I first encountered the error of the stack going to deep by   #
#  aliasing...                                                                 #
#------------------------------------------------------------------------------#
#  This script has now two additional functions on it's own:                   #
#   - you can adjust, how many accessoires each actor can equip                #
#   - you can add additional Categories to your items. by defining using them, #
#     each item is defined being a normal item. changing it to another         #
#     category with one of the following notetags:                             #
#       \c<*x*>                                                                #
#       \class<*x*>                                                            #
#       <c=*x*>                                                                #
#     categories can be gone through with LEFT/RIGHT and only                  #
#     catogies with entries are displayed.                                     #
#   - skills can have hp costs, set by notetag                                 #
#==============================================================================#
#  These scripts support commands. With these you can make complex             #
#  structures within my scripts! Caution, Ruby knowledge is strongly suggested #
#  to use these. Usable via the the following scriptcommand (whereever you     #
#  have a variable called 'command' within my scripts):                        #
#     command.push ["tag", "command"]                                          #
#  The command has to be written in Ruby programming language and within the   #
#  speech marks. The used tag also has to be written within speech marks and   #
#  the following tags are available at the moment:                             #
#    with self. <- the actual item                                             #
#     "Use" ............. command for when a item or skill is used, if used on #
#                         equipment, the third entry has to be either "Friend",#
#                         "All Friends", "Enemy", "All Enemies", "All",        #
#                         "Dead Friend" or "Self" to
#                         define the target range.                             #
#     "Generate Item" ... command for when the item is generated (generating   #
#                         of my custom equipment)                              #
#     "Identify" ........ command for when the item gets identified (diablo    #
#                         equipment)                                           #
#     "UnEnchant" ....... command for when the item gets unenchanted (diablo   #
#                         equipment)                                           #
#     "Rune Attach" ..... command for when the corresponding gets attached     #
#                         (e.g. socket insertionts)                            #
#     "Rune Clear" ...... command for when the corresponding gets erased       #
#                         from a slot (socket insertion of other item e.g.)    #
#     "Equip" ........... command for when the item/skill will be equipped     #
#                         (custom equipment/skill)                             #
#     "Unequip" ......... comamnd for when the item/skill will be unequipped   #
#                         (custom equipment/skill)                             #
#     "Level Up" ........ command for when the item/skill/rune levels up       #
#     "Level Max" ....... command for when the item/skill/rune reache Max level#
#     "Random" .......... command to be used at radom when walking on the map  #
#                         with a probability of 1% per step                    #
#     "Die" ............. command for when the actor/enemy dies                #
#     "Target" .......... command to alter the target of a skill/item          #
#    Battle specific commands:                                                 #
#     "TurnStart" ....... command for start of a turn during a turn based BS   #
#     "TurnEnd" ......... command for end of turn during a turn based BS       #
#     "TurnNext" ........ command for the next turn. recommended only for      #
#                         commands, that erase itself afterwards               #
#     "BattleEnd" ....... command for after a fight                            #
#     "BattleWin" ....... command for when a fight is won                      #
#     "BattleFlee" ...... command for when you flee from a battle              #
#     "BattleNotFlee" ... command for when an attemp to flee fails             #
#     "BattleHit" ....... command for when the skill/item hits                 #
#     "BattleMiss" ...... command for when the skill/item misses               #
#     "BattleCrit" ...... command for when the skill/item deals critical       #
#                         damage                                               #
#     "BattleLB" ........ command for when the skill/item deals a limitbreak   #
#     "BattleGetHit" .... command for when the actor gets hit                  #
#     "BattleGetCrit" ... command for when the actor get a critical damage     #
#     "BattleGetLB" ..... command for when the actor get a limitbreak          #
#     "BattleDefeat" .... command for when either all enemies or all actors    #
#                         are defeted                                          #
#    Questlog specific commands:                                               #
#     "Start" ........... command for when the quest is started                #
#     "Resolve" ......... command for when the quest is resolved               #
#    Customskills specific commands:                                           #
#     "Evolve" .......... command for when a skill evolves                     #
#  Whenever available $game_temp.tidloc[:user], $game_temp.tidloc[:target],    #
#  $game_temp.tidloc[:targets], $game_temp.tidloc[:actor],                     #
#  $game_temp.tidloc[:enemy], $game_temp.tidloc[:item],                        #
#  $game_temp.tidloc[:skill] can be used to refer to the according.            #
#  In these commands you can always use $game_temp.tidloc.actor to aim at      #
#  the actor having the item/skill equipped (not available for quest, though). #
#  Also you can add commands within these commands or execute them on your own #
#  with scriptcalls via the script command:                                    #
#     Tidloc.exe("command", "tag")                                             #
#  where you need to specify the tag used for your command. if none is written #
#  the call will return the command. tags implemented so far:                  #
#     :BigText                                                                 #
#     :SmallText                                                               #
#     :QuestText_add                                                           #
#     :QuestText_clear                                                         #
#     :TimeAdd                                                                 #
#     :TimeCut                                                                 #
#     :TimeSet                                                                 #
#     :TimeVar                                                                 #
#     :TimeGet                                                                 #
#     :ShopNum                                                                 #
#     :ShopLVL                                                                 #
#     :ShopAdd                                                                 #
#     :call                                                                    #
#------------------------------------------------------------------------------#
#  it's possible to create additional on-use-commands on items and skills now  #
#  via the notetags:                                                           #
#     <exe-use: *command*>                                                     #
#             <- the *command* will be executed as soon as the item is used    #
#     <exe-get: *command*>                                                     #
#             <- the *command* will be executed as soon as the player gets     #
#                the item                                                      #
#  Equipitems can be used indefinitely except if you use one of  the following #
#  command:                                                                    #
#     <exe-use-count *x*>                                                      #
#     <exe-use-break *y*>                                                      #
#  As the name suggests, you can use the skill of that item up to y times then #
#  before the item breaks or x times before it gets non-usable from there on.  #
#  If you want to use consumable items indefinitely, add the following note:   #
#     <exe-use-indef>                                                          #
#------------------------------------------------------------------------------#
#  HP cost on skills is set with the following notetag:                        #
#     <hp-cost *x*>                                                            #
#  or % HP cost of Max HP:                                                     #
#     <hp%-cost *x*>                                                           #
#------------------------------------------------------------------------------#
#  skills/items/equipment and characters can now have a chance to limitbreak   #
#  on an attack. to activate this feature, set this constant to true:          #
#     Use_Limit_Break                                                          #
#  then to activate it, you need to set thw following notetags:                #
#     <lb-chance *x*> ... by default 0, defines the percentual chance of a     #
#                         critical to be a limit break.                        #
#     <lb-def *x*> ...... by default 0, defines the percentual chance of       #
#                         preventing a limitbreak.                             #
#  also players and enemies can now have notetags, that define the damage      #
#  multiplier for criticals and limit breaks:                                  #
#     <c-dam *x*> .... critical multiplier for actor/enemy is x                #
#     <c-var *x*> .... critical multiplier is equal the game variable x        #
#     <lb-dam *x*> ... limitbreak multiplier for actor/enemy is x              #
#     <lb-var *x*> ... limitbreak multiplier is equal the game variable x      #
#  skills can have a fixed chance for crititals, defined with this notetag:    #
#     <crit: *x*> ..... critical chance of this skill is x%                    #
#     <crit-no-cev> ... critical chance ignores enemy's critical evasion       #
#==============================================================================#
#  Now supported scripts by this header:                                       #
#                 HTML Rendering *                                             #
#                 Questlog *                                                   #
#                 Runes script *                                               #
#                 Alchemy script *                                             #
#                 Blacksmitch script *                                         #
#                 Dismantle script *                                           #
#                 Dynamic Shop script *                                        #
#                 Itemvalue script *                                           #
#                 Self Variable scipt *                                        #
#                 Message Windows *                                            #
#                 Compass script                                               #
#                 Auction script *                                             #
#                 Equipment Alteration *                                       #
#                 Scene_Language *                                             #
#                 CustomEquips * (and all enhancements of it)                  #
#                 CustomSkills *                                               #
#                 Independet ingame time *                                     #
#------------------------------------------------------------------------------#
#  scripts with a '*' behind their names need this header to work correctly    #
#------------------------------------------------------------------------------#
#  Most of my Scripts use vocabulary, I entered the standard phrases in german #
#  and english. to change this write "ger" or "eng" into the constant Language #
#  Now some scripts also support spanish by using "spa" and Brazilian          #
#  Portuguese by using "ptbr".                                                 #
#------------------------------------------------------------------------------#
#  In update 2.70 there came the constant DEBUG, which defines through some of #
#  my scripts to show debugging, not sure how constant I work with it, maybe   #
#  using it only for my own scripting, anyway when testing the game, it will   #
#  always send you to the initial map position instead of title screen!        #
################################################################################

$imported = {} if $imported.nil?
$imported["Tidloc-Header"] = [2,12,1]
$needed   = [] if $needed.nil?

module Tidloc
             DEBUG = false
          Language = "eng"
         Languages = ["eng","ger","cze"]
       Line_Height = 24
              Keys = {}
              Menu = {}
              Help = {}
           Use_mod = {     :crit => true,  # change the standard critical multiplier to another value, defined below
                      :crit_note => true,  # change the critical multiplier via notetags (overrules :crit)
                     :limitbreak => true,  # activate the possibility for limitbreaks
                 :language_scene => true,  # activate the language scene before the title scene
                    :param_names => true,  # activate to use parameter names defined below in the Vocabs module
                :item_categories => true,  # activate item categorizing
                       :vit_rate => true,  # activate vitality to boost HP
                       :int_rate => true,  # activate intelligence to boost MP
                    :accessoires => false, # activate for an actor to have more then 1 accessoire
                       :Menu_mod => true,  # activate Menu alteration through this script
				   :Show_all_cat => false, # when item window is modified, it's show all items, if they are categorized as long the window isn't active
# activating commands for all parts of the game:
                 :battle_command => true,  # battle commands for actors/enemies/equipment
                 :random_command => true,  # random command for when on the map
                  :actor_command => true,  # complete deactivation of actor commands
                  :enemy_command => true,  # complete deactivation of enemy commands
                 
# these are only for scripters, as they make my scripts appear smoother and have
# no big impact on the game, to switch off different alterations:
                   :base_win_mod => true,  # window_base
                   :item_win_mod => true,  # window_itemlist
                  :bitem_win_mod => true,  # window_battleitem
                  :skill_win_mod => true,  # window_skilllist
                      }
              
   
         Crit_Mult = 3     # default by RPG Maker is 3
           LB_Mult = 10    # multiplication factor for limit breaks
  Accessoire_Count = 1     # number of maximum accessoires per actor
      Item_Columns = 1     # if item list gets modified, it will show the here
                           # defined number of columns of items
          Vit_Rate = 0     # set to 0 to deactivate, otherwise the vit-attribute
                           # will have this weighted contribution to HP
          Int_Rate = 0     # set to 0 to deactivate, otherwise the mat-attribute
                           # will have this weighted contribution to MP
                           
      Money_Icon   = nil   # displaying this icon additional whenever money is shown
      Money_Img    = nil   # displaying this image additionally whenever money
                           # is shown. only works, if icon is set nil.
   Crit_Ignore_Def = false
 Crit_Ignore_Guard = false
   Crit_Ignore_PDR = false
      
      Notetags = [[/<hp:([0-9]+)>/i,   # 
                 /<mp:([0-9]+)>/i,   # raise the given stat
                 /<str:([0-9]+)>/i,  # 
                 /<def:([0-9]+)>/i,  # by a fixed value
                 /<mag:([0-9]+)>/i,  # 
                 /<mdf:([0-9]+)>/i,  # 
                 /<agi:([0-9]+)>/i,  # 
                 /<luc:([0-9]+)>/i,  # 
                 /<dex:([0-9]+)>/i,  # 
                 /<vit:([0-9]+)>/i], #--------------
                [/<%hp:(.*)>/i,   # 
                 /<%mp:(.*)>/i,   # raise a given stat
                 /<%str:(.*)>/i,  # 
                 /<%def:(.*)>/i,  # by pertentage of
                 /<%mag:(.*)>/i,  # 
                 /<%mdf:(.*)>/i,  # the actual value
                 /<%agi:(.*)>/i,  # 
                 /<%luc:(.*)>/i,  # 
                 /<%dex:(.*)>/i,  # 
                 /<%vit:(.*)>/i], #-------------
                [/<res-stat:([0-9]+)>/i,      # resists a status change to the given state-id
                 /<res-ele:([0-9]+),(.*)>/i,  # resists an element (1) by (2)%
                 /<atk-ele:([0-9]+),(.*)>/i], # boosts an element (1) by (2)%
                [/<%mhp:(.*)>/i,   # x% of max-HP is reserved by passive
                 /<%mmp:(.*)>/i],  # x% of max-MP is reserved by passive
                [/<lb-chance ([0-9]+)>/i,# lb chance when dealing a crit is x%
                 /<lb-eva ([0-9]+)>/i,   # lb evasion is x%
                 /<crit: ([0-9]+)>/i,    # crit chance for this skill is x%
                 /<crit-no-cev>/i,       # crit ignores crit eva for this skill
                 /<crit-ign-pl>/],       # crit irnores the users crit chance(has then a fixed value)
                [/<c-dam (.*)>/i,      # critical damage multiplier is x
                 /<c-var ([0-9]+)>/i,  # critical damage multiplier is game variable with id x
                 /<lb-dam (.*)>/i,     # LB damage multiplier is x
                 /<lb-var ([0-9]+)>/i],# LB damage multiplier is game variable with id x
                []]
      
      Param_Names = [["HP","MP","STR","DEF","MAG","MDF","AGI","LUC","DEX","VIT"],
                     ["HP_res","MP_res"]]
      
      Menu["Save"] = true 
      Menu["Load"] = true
      
      Keys["DEBUG"]= nil
      Keys["Help"] = :F8
      
      Keys["CatChange"] = :SHIFT 
      Keys["Cat+"]      = :RIGHT 
      Keys["Cat-"]      = :LEFT  
      Keys["Alternate"] = :CTRL  
      Keys["Scroll+"]   = :L     # scorlling up
      Keys["Scroll-"]   = :R     # scrolling down
      
      Help["CatChange"] = "\"<color=orange>\"+Tidloc::Vocabs.Header(\"CatChange\",$tidloc_language)+\"</color>\""
      Help["Cat+"]      = "\"<color=orange>\"+Tidloc::Vocabs.Header(\"Cat+\",$tidloc_language)+\"</color>\""
      Help["Cat-"]      = "\"<color=orange>\"+Tidloc::Vocabs.Header(\"Cat-\",$tidloc_language)+\"</color>\""
      Help["Scroll_U"]  = "\"<color=orange>\"+Tidloc::Vocabs.Header(\"Scroll+\",$tidloc_language)+\"</color>\""
      Help["Scroll_D"]  = "\"<color=orange>\"+Tidloc::Vocabs.Header(\"Scroll-\",$tidloc_language)+\"</color>\""
      Help["Enter"]     = "\"<color=orange>\"+Tidloc::Vocabs.Header(\"Enter\",$tidloc_language)+\"</color>\""
      Help["Esc"]       = "\"<color=orange>\"+Tidloc::Vocabs.Header(\"Esc\",$tidloc_language)+\"</color>\""
      Help["Alternate"] = "\"<color=orange>\"+Tidloc::Vocabs.Header(\"Alternate\",$tidloc_language)+\"</color>\""
      
  module Vocabs;class<<self
    def Header(code, lang)
      if    lang == "ger"
        case code
        when "Categories"; return ["Anleitungen","Rohstoffe","Runen","Karten","Gegnerbeute"]
        when "Load";       return "Laden"
        when "Save";       return "Speichern"
        when "Weak";       return "Schwachstelle"
        when "Strong";     return "Resistenzen"
        when "Params";     return ["LP","MP","Str","Abw","Mag","MDf","Ges","Glk","Aus","Vit"]
        when "Param_long"; return ["maximale Lebenspunkte",
                                   "maximale Manapunkte",
                                   "Physische St�rke",
                                   "Physische Verteidigung",
                                   "Magische Macht",
                                   "Magische Verteidigung",
                                   "Geschick",
                                   "Gl�ck",
                                   "Ausdauer",
                                   "Vitalit�t"]
          
        when "CatChange";  return "Umschalt"
        when "Cat+";       return "Pfeil-rechts"
        when "Cat+2";      return "zur n�chsten Kategorie wechseln"
        when "Cat-";       return "Pfeil-links"
        when "Cat-2";      return "zur vorigen Kategorie wechseln"
        when "Scroll+";    return "Bild hoch"
        when "Scroll+2";   return "Im Informationsfenster hinauf scrollen"
        when "Scroll-";    return "Bild runter"
        when "Scroll-2";   return "Im Informationsfenster hinunter scrollen"
        when "Enter";      return "ENTER"
        when "Esc";        return "ESC"
        when "Alternate";  return "STRG"
        end
      elsif lang == "eng"
        case code
        when "Categories"; return ["Manuals","Ressources","Runes","Card-items","Monster items"]
        when "Load";       return "Load"
        when "Save";       return "Save"
        when "Weak";       return "Weakness"
        when "Strong";     return "Resistances"
        when "Params";     return ["HP","MP","STR","DEF","MAG","MDF","AGI","LUC","DEX","VIT"]
        when "Param_long"; return ["maximum Hitpoints",
                                   "maximum Manapoints",
                                   "physical strength",
                                   "physical defense ",
                                   "magical power",
                                   "magical defense",
                                   "Agility",
                                   "Luck",
                                   "Dexterity",
                                   "Vitality"]
          
        when "CatChange";  return "Shift"
        when "Cat+";       return "right arrow"
        when "Cat+2";      return "switching to the next category"
        when "Cat-";       return "left arrow"
        when "Cat-2";      return "switching to the previous category"
        when "Scroll+";    return "Page Up"
        when "Scroll+2";   return "scrolling the information window up"
        when "Scroll-";    return "Page Down"
        when "Scroll-2";   return "scrolling the information window down"
        when "Enter";      return "ENTER"
        when "Esc";        return "ESC"
        when "Alternate";  return "CTRL"
        end
      elsif lang == "esp"
        case code
        when "Categories"; return ["Instrucci�n","Materias primas","Runa"]
        when "Load";       return "Continuar"
        when "Save";       return "Memorizar"
        when "Weak";       return "punto flaco"
        when "Strong";     return "resistencia"
        end
      elsif lang == "ptbr"
        case code
        when "Categories"; return ["Instru��es","Recursos","Runas"]
        when "Load";       return "Carregar"
        when "Save";       return "Salvar"
        when "Weak";       return "vulnerabilidade"
        when "Strong";     return "resist�ncia"
        end
      end
    end
  end;end
  class<<self;
    def Debug_start
      DataManager.setup_new_game
      return Scene_Map
    end
    def Version(name,ver,quit=false,needed="")
      temp=false 
      if $imported[name]
        if $imported[name].is_a?(Array)
          if $imported[name][0] > ver[0]
            temp = true
          elsif $imported[name][0] == ver[0]
            if  $imported[name][1] >  ver[1]
              temp = true
            elsif $imported[name][1] == ver[1]
              if  $imported[name][2] >= ver[2]
                temp = true
              end
            end
          end
        elsif !quit
          msgbox "script #{name} is not up to date,\nfunctions are restricted!"
        end
      end
      if quit && !temp
        msgbox "script \"#{needed}\" needs the script \"#{name}\" in \nversion #{ver[0]}.#{ver[1]}.#{ver[2]} or higher to run!"
        exit
      end
      return temp
    end
    def try
    end
  end
end

################################################################################
#                                                                              #
################################################################################

$tidloc_language = Tidloc::Language if $tidloc_language.nil?

module SceneManager
  class<<self;alias wo_tidloc_run run;end
  def self.run
    $needed.each{|n|
      Tidloc.Version(*n)
    }
    wo_tidloc_run
  end
end

module Vocab
  LBToEnemy       = "Limit Break!!"
  LBToActor       = "Limit Break!!"
  class<<self;alias wo_tidloc_param param;end
  def self.param(param_id)
    if param_id < 8 && !Tidloc::Use_mod[:param_names]
      wo_tidloc_param param_id
    else
      Tidloc::Vocabs.Header("Params",$tidloc_language)[param_id]
    end
  end
end

module Math;class<<self
  alias wo_tidloc_log log
  def log(num, power=Math::E)
    if power.is_a?(Complex)
      Math.log(num)/Math.log(power)
    else
      if num.is_a?(Complex)
        Complex(Math.log(num.abs),num.arg)
      else
        wo_tidloc_log(num, power)
      end
    end
  end
  alias wo_tidloc_exp exp
  def exp(power)
    if power.is_a?(Complex)
      x  = Math.cos(power.imag)
      y  = Math.sin(power.imag)
      x *= Math.exp(power.real)
      y *= Math.exp(power.real)
      Complex(x,y)
    else
      wo_tidloc_exp(power)
    end
  end
  def transpose(mat,fill=nil)
    newmat = []
    xmax = mat.size
    ymax = 0
    mat.each{|l| ymax = l.size if l && ymax < l.size}
    xmax.times{|i|
      ymax.times{|j|
        if    mat[i].nil?
          newmat[j] = [] if newmat[j].nil?
          newmat[j][i] = fill
        elsif mat[i][j].nil?
          newmat[j] = [] if newmat[j].nil?
          newmat[j][i] = fill
        else
          newmat[j] = [] if newmat[j].nil?
          newmat[j][i] = mat[i][j]
        end
      }
    }
    return newmat
  end
  def prime_gen(x=0)
    x=rand(1000) if x==0
    y=0;i=1
    while true
      i += 1
      if i.is_prime?
        y += 1
        return i if y == x
      end
    end
  end
  def relativistic_add(*args)
    if    args.size < 2
      return args[0]
    elsif args.size == 2
      return (args[0]+args[1])/(1+args[0]*args[1])
    elsif args.size == 3
      if args[2] > 1
        return (args[0]+args[1])/(1+args[0]*args[1]/args[2]^2)
      else
        temp = relativistic_add(*args[1..-1])
        return (args[0]+temp)/(1+args[0]*temp)
      end
    else
      temp = relativistic_add(*args[1..-1])
      return (args[0]+temp)/(1+args[0]*temp)
    end
  end
end;end

class Integer
  def is_prime?
    ((2..(Math.sqrt(self)))).each{|i|
      return false if self % i == 0
    }
    return true
  end
end

class Array
  def sum
    a = 0
    for n in 0...size
      a += self[n]     if self[n].is_a?(Numeric)
      a += self[n].sum if self[n].is_a?(Array)
    end
    return a
  end
end

module Tidloc;class<<self
  def exe(command,tag=nil,*args)
    if    tag.nil?
      return command
    elsif tag == :BigText
      return command unless $imported["Tidloc-MessageWindow"]
      $game_temp._tidloc_message_big.push     command
      $game_temp._tidloc_message_history.push "B: "+command
    elsif tag == :SmallText
      return command unless $imported["Tidloc-MessageWindow"]
      $game_temp._tidloc_message_small.push   command
      $game_temp._tidloc_message_history.push "S: "+command
    elsif tag == :QuestText_add
      return command unless Tidloc.Version("Tidloc-MessageWindow",[2,1,0])
      temp = Tidloc::Message_class.new(command[1],command[0])
      $game_temp._tidloc_message_quest.push   temp
      $game_temp._tidloc_message_history.push "T: "+command[1]
    elsif tag == :QuestText_clear
      return command unless Tidloc.Version("Tidloc-MessageWindow",[2,1,0])
      $game_temp._tidloc_message_quest.delete_if{|x| x.identifier == command}
    elsif tag == :TimeAdd
      return command unless $imported["Tidloc-Clock"]
      $game_temp._tidloc_clock_step += command
      $game_temp._tidloc_clock_step -= Tidloc::Clock::Max_Steps if $game_temp._tidloc_clock_step >= Tidloc::Clock::Max_Steps
    elsif tag == :TimeCut
      return command unless $imported["Tidloc-Clock"]
      $game_temp._tidloc_clock_step -= command
      $game_temp._tidloc_clock_step += Tidloc::Clock::Max_Steps if $game_temp._tidloc_clock_step < 0
    elsif tag == :TimeSet
      return command unless $imported["Tidloc-Clock"]
      $game_temp._tidloc_clock_step = command
    elsif tag == :TimeVar
      return command unless $imported["Tidloc-Clock"]
      $game_variables[command] = $game_temp._tidloc_clock_step
    elsif tag == :TimeGet
      return command unless $imported["Tidloc-Clock"]
      return $game_temp._tidloc_clock_step
    elsif tag == :ShopNum
      return command unless $imported["Tidloc-D-Shop"]
      $tidloc_shopnum = [] unless $tidloc_shopnum
      $tidloc_shopnum[0] = command
    elsif tag == :ShopLVL
      return command unless $imported["Tidloc-D-Shop"]
      $tidloc_shopnum = [] unless $tidloc_shopnum
      $tidloc_shopnum[1] = command
    elsif tag == :ShopAdd
      return command unless $imported["Tidloc-D-Shop"]
      return command unless Tidloc::D_Shop::add_item command,*args
    elsif tag == :SkillMax
      return command unless $imported["Tidloc-CustomSkills"]
      return command unless Tidloc::CustomSkills::change_max_skills command,*args[0]
    elsif tag == :call
      if    command == "Message"  && $imported["Tidloc-MessageWindow"]
        if SceneManager.scene.is_a?(Scene_Map)
          SceneManager.call(Tidloc::Message::Tidloc_Message)
        else
          SceneManager.goto(Tidloc::Message::Tidloc_Message)
        end
      elsif command == "Questlog" && $imported["Tidloc-Questlog"]
        SceneManager.call(Tidloc::Questlog::Scene_Questlog, *args)
      elsif command == "Auction"  && $imported["Tidloc-Auction"]
        SceneManager.call(Tidloc_Auction)
      elsif command == "Smith"    && $imported["Tidloc-Smith"]
        SceneManager.call(Tidloc_Smith, *args)
      elsif command == "Alchemy"  && $imported["Tidloc-Alchemy"]
        SceneManager.call(Tidloc_Alch, *args)
      elsif command =="Dismantle" && $imported["Tidloc-Dismantle"]
        SceneManager.call(Tidloc_Dismantle)
      elsif command == "Identify" && $imported["Tidloc-DiabloEquip"]
        SceneManager.call(Tidloc::CustomEquip::Scene_Identify, *args)
        return false
      elsif command == "Enchant"  && $imported["Tidloc-DiabloEquip"]
        SceneManager.call(Tidloc::CustomEquip::Scene_Enchant, *args)
      elsif command == "UnEnch"   && $imported["Tidloc-DiabloEquip"]
        SceneManager.call(Tidloc::CustomEquip::Scene_UnEnchant, *args)
      elsif command == "Socket"   && $imported["Tidloc-SocketEquip"]
        SceneManager.call(Tidloc::CustomEquip::Scene_Socket, *args)
      elsif command == "Rune"     && $imported["Tidloc-Runes"]
        SceneManager.call(Tidloc::Rune::Tidloc_Rune, *args)
      elsif command == "RuneShop" && $imported["Tidloc-RuneShop"]
        SceneManager.call(Tidloc::Rune::Rune_Magic_Shop, *args)
      elsif command == "Skills" && $imported["Tidloc-CustomSkills"]
        SceneManager.call(Tidloc::CustomSkills::SkillEquip, *args)
      elsif command == "Refine_Merge" && $imported["Tidloc-CustomRefining"]
        SceneManager.call(Tidloc::CustomRefining::Scene_Merge,*args)
      elsif command == "Refine_Scene" && $imported["Tidloc-CustomRefining"]
        SceneManager.call(Tidloc::CustomRefining::Scene_Refine,*args)
      elsif command == "DuraRepair" && $imported["Tidloc-CustomDura"]
        SceneManager.call(Tidloc::CustomDura::Scene_Repair,*args)
      elsif command == "DuraMaxRep" && $imported["Tidloc-CustomDura"]
        SceneManager.call(Tidloc::CustomDura::Scene_RepairMax,*args)
      elsif command == "Banking" && $imported["Tidloc-Banking"]
        SceneManager.call(Tidloc::Banking::Scene_Bank,*args)
      end
    elsif tag == :game
      if    command == "Jump" && $imported["Tidloc-GameJumping"]
        $tidloc_game = Tidloc::Games::Jump::Game.new *args
      elsif command == "Digging" && $imported["Tidloc-GameDigging"]
        $tidloc_game = Tidloc::Games::Digging::Game.new *args
      elsif command == "LockPick" && $imported["Tidloc-GameLockPick"]
        $tidloc_game = Tidloc::Games::LockPick::Game.new *args
      elsif command == "DicePoker" && $imported["Tidloc-GameDicePoker"]
        $tidloc_game = Tidloc::Games::DicePoker::Game.new *args
      elsif command == "Yahtzee" && $imported["Tidloc-GameYahtzee"]
        $tidloc_game = Tidloc::Games::Yahtzee::Game.new *args
      end
    else
      return command
    end
    return true
  end
end
  class Dummy_actor
    def def; 0; end
    def mdf; 0; end
  end
  class Message_class
    attr_accessor :text
    attr_accessor :identifier
    def initialize(text="",identifier=nil)
      self.text = text
      self.identifier = identifier
    end
  end
  class << self
    def Message(text)
      $game_temp._tidloc_message.push text
    end
  end
################################################################################
#                                                                              #
################################################################################
  
  module Header
    class Category_Window < Window_Selectable
      attr_accessor :category
      attr_accessor :item_window
      def initialize
        super 0,0,Graphics.width,line_height*2
        self.deactivate.hide
        self.category = []
        make_category
      end
      def make_category
        temp = $game_party.items.map{|x| x.tidloc_class}.delete_if{|y| y==0}.uniq.sort
        self.category = [0]
        temp.each{|x|
          self.category.push x
        }
        refresh
        self.index = 0
      end
      def refresh
        self.contents.clear
        if self.category.size == 0
          self.index = -1
          return
        end
        self.category.size.times{|i|
          text = self.category[i] == 0 ? Bitmap.html_decode(Vocab::Possession) : Tidloc::Vocabs.Header("Categories",$tidloc_language)[self.category[i]-1]
          draw_text(i%4*item_width+5,i/4*line_height,item_width-10,line_height,text)
        }
      end
      def update
        super
      end
      def item_max
        Tidloc::Vocabs.Header("Categories",$tidloc_language).size
      end
      def col_max
        return 4
      end
      def row_max
        1 + Tidloc::Vocabs.Header("Categories",$tidloc_language).size/4
      end
      def item_width
        width/3.2
      end
      def spacing
        0
      end
      def contents_width
        10000
      end
    end
    class Category_Window_Small < Category_Window
      def initialize(x,y,w,h)
        super()
        self.x      = x
        self.y      = y
        self.width  = w
        self.height = h
      end
      def item_width
        self.width
      end
      def update
        super
        return unless active
      end
      def row_max
        1
      end
      def refresh
        self.contents.clear
        return if self.index < 0
        if self.category.size == 0
          self.index = -1
          return
        end
        i = self.index
        text = self.category[i] == 0 ? Bitmap.html_decode(Vocab::Possession) : Tidloc::Vocabs.Header("Categories",$tidloc_language)[self.category[i]-1]
        draw_text(5,0,item_width-10,line_height,text)
      end
    end
  end
  class Window_Tid_Help < Window_Base
    attr_accessor :text
    attr_accessor :inited
    def initialize
      x = 50
      y = 50
      w = Graphics.width  - 100
      h = Graphics.height - 100
      super x,y,w,h
      self.hide.z=1000
      self.back_opacity=255
      self.open.hide.deactivate.inited = false
    end
    def scroll_up
      self.oy = [self.oy-5,0].max
    end
    def scroll_down
      self.oy += 5 if self.height + self.oy - 32 < self.contents.height
    end
    def activate
      refresh
      Sound.play_ok if self.inited
      super
    end
    def deactivate
      Sound.play_ok if self.inited
      self.oy = 0
      super
    end
    def contents_height
      if self.text.nil?
        super 
      else
        Bitmap.new(width-32, 2000).draw_html(0, 0, width-32, 2000, self.text,true)
      end
    end
    def update
      super
      return if !self.active || self.inited
      refresh
    end
    def refresh
      create_contents
      return unless self.text
      self.contents.draw_html(Rect.new(0, 0, self.width-32, contents_height),self.text,true)
      self.inited = true
      self
    end
  end
end
################################################################################
#                                                                              #
################################################################################

class Game_Temp
  def scan_items
    itemvalue = self._tidloc_itemvalues.nil? && $imported["Tidloc-Itemvalue"]
    self._tidloc_itemvalues = [[],[],[]] if itemvalue
    if $data_items
      for i in 1...$data_items.size
        j = $data_items[i]
        self._tidloc_itemvalues[0][j.id] = j.wo_tidloc_price if itemvalue
        self._tidloc_auction_possible[i] = Tidloc::Auction::Default_Auctionable if $imported["Tidloc-Auction"]
        self._tidloc_auction_rarity[i] = 0 if $imported["Tidloc-Auction"]
        text = j.note.clone
        text.split(/[\r\n]+/).each { |line|
          case line
          when /<(?:auction|Auction)>/
            self._tidloc_auction_possible[i] = !self._tidloc_auction_possible if $imported["Tidloc-Auction"]
          when/<(?:rarity|Rarity):[ ](\d+)>/i
            self._tidloc_auction_rarity[i] = $1.to_i if $imported["Tidloc-Auction"]
          end
        }
      end
    end
    if $data_weapons
      for i in 1...$data_weapons.size
        j = $data_weapons[i]
        self._tidloc_itemvalues[1][j.id] = j.wo_tidloc_price if itemvalue
        self._tidloc_auction_possible[i+1000] = Tidloc::Auction::Default_Auctionable if $imported["Tidloc-Auction"]
        self._tidloc_auction_rarity[i+1000] = 0 if $imported["Tidloc-Auction"]
        text = j.note.clone
        text.split(/[\r\n]+/).each { |line|
          case line
          when  /<(?:auction|Auction)>/
            self._tidloc_auction_possible[i+1000] = !self._tidloc_auction_possible if $imported["Tidloc-Auction"]
          when /<(?:rarity|Rarity):[ ](\d+)>/i
            self._tidloc_auction_rarity[i+1000] = $1.to_i if $imported["Tidloc-Auction"]
          when /<t-e-art:[ ]([0-9]+),([A-Za-z0-9_-]+),([0-9]+)>/
            next unless $imported["Tidloc-AddStats"]
            self._tidloc_equipalt[i+1000] = [] if self._tidloc_equipalt[i+1000].nil?
            self._tidloc_equipalt[i+1000][$1.to_i] = [$2,$3.to_i]
          when /<(?:stat|Stat):[ ]([0-9]+),([0-9-]+)>/
            next unless $imported["Tidloc-AddStats"]
            self._tidloc_addstats[i+1000] = [] if self._tidloc_addstats[i+1000].nil?
            self._tidloc_addstats[i+1000][$1.to_i] = $2.to_i
          end
        }
      end
    end
    if $data_armors
      for i in 1...$data_armors.size
        j = $data_armors[i]
        self._tidloc_itemvalues[2][j.id] = j.wo_tidloc_price if itemvalue
        self._tidloc_auction_possible[i+2000] = Tidloc::Auction::Default_Auctionable if $imported["Tidloc-Auction"]
        self._tidloc_auction_rarity[i+2000] = 0 if $imported["Tidloc-Auction"]
        text = j.note.clone
        text.split(/[\r\n]+/).each { |line|
          case line
          when  /<(?:auction|Auction)>/
            self._tidloc_auction_possible[i+2000] = !self._tidloc_auction_possible if $imported["Tidloc-Auction"]
          when /<(?:rarity|Rarity):[ ](\d+)>/i
            self._tidloc_auction_rarity[i+2000] = $1.to_i if $imported["Tidloc-Auction"]
          when /<t-e-art:[ ]([0-9]+),([A-Za-z0-9_-]+),([0-9]+)>/
            next unless $imported["Tidloc-AddStats"]
            self._tidloc_equipalt[i+2000] = [] if self._tidloc_equipalt[i+2000].nil?
            self._tidloc_equipalt[i+2000][$1.to_i] = [$2,$3.to_i]
          when /<(?:stat|Stat):[ ]([0-9]+),([0-9-]+)>/
            next unless $imported["Tidloc-AddStats"]
            self._tidloc_addstats[i+2000] = [] if self._tidloc_addstats[i+2000].nil?
            self._tidloc_addstats[i+2000][$1.to_i] = $2.to_i
          end
        }
      end
    end
  end
end
################################################################################
#                                                                              #
################################################################################

#~ module DataManager
#~   class<<self; alias wo_tidloc_make_save_contents make_save_contents; end
#~   def self.make_save_contents
#~     contents = wo_tidloc_make_save_contents
#~     contents[:self_variables] = $game_self_variables   if $imported["Tidloc-SelfVariables"]
#~     contents
#~   end
#~   class<<self; alias wo_tidloc_extract_save_contents extract_save_contents; end
#~   def self.extract_save_contents(contents)
#~     wo_tidloc_extract_save_contents(contents)
#~     $game_self_variables   = contents[:self_variables] if $imported["Tidloc-SelfVariables"]
#~     
#~     if $imported["Tidloc-Questlog"] && $game_system.questlog.nil?
#~       $game_system.questlog           = Questlog.new 
#~     end
#~     if $imported["Tidloc-D-Shop"]
#~       $game_system.tidloc_dshop       = [] if $game_system.tidloc_dshop.nil?
#~     end
#~   end
#~   class <<self; alias wo_tidloc_create_game_objects create_game_objects; end
#~   def self.create_game_objects
#~     wo_tidloc_create_game_objects
#~     $game_self_variables = []            if $imported["Tidloc-SelfVariables"]
#~   end
#~ end
################################################################################
#                                                                              #
################################################################################

#~ module SceneManager
#~   class<<self;alias wo_tidloc_call call;end
#~   def self.call(scene_class, *args)
#~     if @scene.is_a?(Scene_Map) && $imported["Tidloc-MessageWindow"]
#~       $game_system.tidloc_message_time_1 = -1
#~       $game_system.tidloc_message_time_2 = -1
#~       $game_system.tidloc_message_time_3 = -1
#~     end
#~     if args
#~       @stack.push(@scene)
#~       @scene = scene_class.new *args
#~     else
#~       wo_tidloc_call(scene_class)
#~     end
#~   end
#~   class<<self;alias wo_tidloc_goto goto;end
#~   def self.goto(scene_class,*args)
#~     if args
#~       @scene = scene_class.new *args
#~     else
#~       wo_tidloc_goto(scene_class)
#~     end
#~   end
#~   class<<self;alias wo_tidloc_fc first_scene_class;end
#~   def self.first_scene_class
#~     if    $BTEST
#~       return Scene_Battle
#~     elsif Tidloc::DEBUG
#~       return Tidloc::Debug_start()
#~     elsif Tidloc::Use_mod[:language_scene] && $imported["Tidloc-SceneLanguage"]
#~       if @scene.nil? 
#~         return Tidloc::Lang::Scene_Language
#~       else
#~         return Scene_Title
#~       end
#~     else
#~       return self.wo_tidloc_fc
#~     end
#~   end
#~ end
################################################################################
#                                                                              #
################################################################################

#~ class Game_Character < Game_CharacterBase
#~   def set_speed(new_speed)
#~     @move_speed = new_speed
#~   end
#~ end
################################################################################
#                                                                              #
################################################################################

#~ class Window_MenuCommand < Window_Command
#~   alias old_add_save_command add_save_command
#~   def add_save_command
#~     if Tidloc::Use_mod[:Menu_mod]
#~       add_command(Tidloc::Vocabs.CustomSkills("Img",$tidloc_language),    :tidloc_customskill) if Tidloc::Menu["CustomSkills"]
#~       add_command(Tidloc::Vocabs.Rune("Name",$tidloc_language),           :tidloc_runes)       if Tidloc::Menu["Runes"]
#~       add_command(Tidloc::Vocabs.Questlog("Name",$tidloc_language),       :tidloc_questlog)    if Tidloc::Menu["Questlog"]
#~       add_command(Tidloc::Vocabs.Alch("Name",$tidloc_language),           :tidloc_alchemy)     if Tidloc::Menu["Alchemy"]
#~       add_command(Tidloc::Vocabs.Smith("Name",$tidloc_language),          :tidloc_smith)       if Tidloc::Menu["Smith"]
#~       add_command(Tidloc::Vocabs.Dismantle("Name",$tidloc_language),      :tidloc_dismantle)   if Tidloc::Menu["Dismantle"]
#~       add_command(Tidloc::Vocabs.Auction("Name",$tidloc_language),        :tidloc_auction)     if Tidloc::Menu["Auction"]
#~       add_command(Tidloc::Vocabs.Message("Name",$tidloc_language),        :tidloc_message)     if Tidloc::Menu["Message"]
#~       add_command(Tidloc::Vocabs.DiabloEquip("Name",$tidloc_language),    :tidloc_identify)    if Tidloc::Menu["Identify"]
#~       add_command(Tidloc::Vocabs.DiabloEquip("Enchant",$tidloc_language), :tidloc_enchant)     if Tidloc::Menu["Enchant"]
#~       add_command(Tidloc::Vocabs.DiabloEquip("UnEnch",$tidloc_language),  :tidloc_unench)      if Tidloc::Menu["UnEnch"]
#~       add_command(Tidloc::Vocabs.SocketEquip("Name",$tidloc_language),    :tidloc_socket)      if Tidloc::Menu["Socket"]
#~       add_command(Tidloc::Vocabs.MenuImage("Name",$tidloc_language),      :tidloc_image)       if Tidloc::Menu["Image"]
#~       add_command(Tidloc::Vocabs.Header("Save",$tidloc_language),         :save,save_enabled)  if Tidloc::Menu["Save"]
#~       add_command(Tidloc::Vocabs.Header("Load",$tidloc_language),         :load)               if Tidloc::Menu["Load"]
#~     else
#~       old_add_save_command
#~     end
#~   end
#~ end
################################################################################
#                                                                              #
################################################################################

#~ class Scene_Menu < Scene_MenuBase
#~   alias wo_tidloc_create_command_window create_command_window
#~   def create_command_window
#~     wo_tidloc_create_command_window
#~     return unless Tidloc::Use_mod[:Menu_mod]
#~     @command_window.set_handler(:tidloc_questlog,   
#~                     method(:command_tidloc_questlog))
#~     @command_window.set_handler(:tidloc_alchemy,    
#~                     method(:command_tidloc_alchemy))
#~     @command_window.set_handler(:tidloc_smith,      
#~                     method(:command_tidloc_smith))
#~     @command_window.set_handler(:tidloc_dismantle,  
#~                     method(:command_tidloc_dismantle))
#~     @command_window.set_handler(:tidloc_runes,      
#~                     method(:command_personal))
#~     @command_window.set_handler(:tidloc_auction,    
#~                     method(:command_tidloc_auction))
#~     @command_window.set_handler(:tidloc_message,    
#~                     method(:command_tidloc_message))
#~     @command_window.set_handler(:tidloc_customskill,    
#~                     method(:command_personal))
#~     @command_window.set_handler(:tidloc_identify,            
#~                     method(:command_tidloc_identify))
#~     @command_window.set_handler(:tidloc_enchant,            
#~                     method(:command_tidloc_enchant))
#~     @command_window.set_handler(:tidloc_unench,            
#~                     method(:command_tidloc_unench))
#~     @command_window.set_handler(:tidloc_socket,            
#~                     method(:command_tidloc_socket))
#~     @command_window.set_handler(:tidloc_image,            
#~                     method(:command_tidloc_menuimage))
#~     @command_window.set_handler(:load,            
#~                     method(:command_load))
#~   end
#~   alias wo_tidloc_pers_ok on_personal_ok
#~   def on_personal_ok
#~     wo_tidloc_pers_ok
#~     case @command_window.current_symbol
#~     when :tidloc_customskill
#~       Tidloc.exe "Skills",:call
#~     when :tidloc_runes
#~       Tidloc.exe "Rune",:call
#~     end
#~     @command_window.update
#~   end
#~   def command_tidloc_questlog
#~     Tidloc.exe "Questlog",:call
#~   end 
#~   def command_tidloc_alchemy
#~     Tidloc.exe "Alchemy",:call,0
#~   end 
#~   def command_tidloc_smith
#~     Tidloc.exe "Smith",:call,0
#~   end 
#~   def command_tidloc_dismantle
#~     Tidloc.exe "Dismantle",:call
#~   end
#~   def command_tidloc_auction
#~     Tidloc.exe "Auction",:call
#~   end
#~   def command_tidloc_message
#~     Tidloc.exe "Message",:call
#~   end     
#~   def command_tidloc_identify
#~     Tidloc.exe "Identify",:call
#~   end
#~   def command_tidloc_enchant
#~     pro = (Tidloc::DiabloEquip::Max_Prop_Pre + Tidloc::DiabloEquip::Max_Prop_Post)/2
#~     Tidloc.exe "Enchant",:call,pro,true,0
#~   end
#~   def command_tidloc_unench
#~     Tidloc.exe "UnEnchant",:call,true,0
#~   end
#~   def command_tidloc_socket
#~     Tidloc.exe "Socket",:call,0
#~   end
#~   def command_tidloc_menuimage
#~     
#~   end
#~   def command_load
#~     SceneManager.call(Scene_Load)
#~   end
#~ end

#~ class Scene_Title
#~   alias wo_tidloc_command_new_game command_new_game
#~   def command_new_game
#~     $game_temp_tidloc_town      = Game_Temp_Tidloc_Town.new  if $imported["Tidloc-Town"]
#~     wo_tidloc_command_new_game
#~   end
#~ end
################################################################################
#                                                                              #
################################################################################

#~ class Scene_Base
#~   alias wo_tidloc_base_start start
#~   def start
#~     wo_tidloc_base_start
#~     return unless $imported["Tidloc-Clock"]
#~     Tidloc::Clock::Clock_Visible.each{|x|
#~       if self.is_a?(x[0])
#~         create_tidloc_clock_window x[1],x[2] 
#~         return
#~       end
#~     }
#~   end
#~   alias wo_tidloc_base_update update
#~   def update
#~     wo_tidloc_base_update
#~     if $imported["Tidloc-Clock"] && $game_temp
#~       if Tidloc::Clock::Time_Passing.find{|x| x==self.class}
#~         unless self.is_a?(Scene_Map) && $game_map.note =~ /<no-time>/
#~           if ((Graphics.frame_count / (Graphics.frame_rate*1.0)) - $game_system.tidloc_clock_time_2 > 0.1)
#~             $game_system.tidloc_clock_time_2  = (Graphics.frame_count / (Graphics.frame_rate*1.0))
#~             $game_system.tidloc_clock_time   += 0.1
#~             if $game_system.tidloc_clock_time >= Tidloc::Clock::Step_Time
#~               $game_system.tidloc_clock_time   = 0
#~               $game_system._tidloc_clock_step += 1
#~               $game_system._tidloc_clock_step  = 0 if $game_temp._tidloc_clock_step >= Tidloc::Clock::Max_Steps
#~             end
#~           end
#~         end
#~       end
#~       @tid_clock_window.step = $game_temp._tidloc_clock_step if @tid_clock_window
#~     end
#~   end
#~ end

################################################################################
#                                                                              #
################################################################################

class Scene_Map < Scene_Base
  attr_accessor :tidloc_night
  attr_accessor :t_game_sprite
  alias wo_tidloc_start start
  def start
    @t_game_sprite = []
    tidloc_init_daytime if $imported["Tidloc-Clock"]
    $game_system.tidloc_dshop_time  = Graphics.frame_count / Graphics.frame_rate if $imported["Tidloc-D-Shop"] && ($game_system.tidloc_dshop_time.nil? || $game_system.tidloc_dshop_time > Graphics.frame_count / Graphics.frame_rate)
    $game_temp.tidloc_auction_time = Graphics.frame_count / Graphics.frame_rate if $imported["Tidloc-Auction"] && ($game_temp.tidloc_auction_time.nil? || $game_temp.tidloc_auction_time > Graphics.frame_count / Graphics.frame_rate)
    wo_tidloc_start
  end

  alias wo_tidloc_create_all_windows create_all_windows
  def create_all_windows
    wo_tidloc_create_all_windows
    create_Tidloc_message if $imported["Tidloc-MessageWindow"]
  end
  
  def tidloc_init_daytime
    tidloc_change_night 0 if $game_temp._tidloc_clock_step >= Tidloc::Clock::Nightstart
    tidloc_change_day 0   if $game_temp._tidloc_clock_step <  Tidloc::Clock::Nightstart
  end
  def tidloc_change_night(time=0)
    if $game_map.note =~ /<nightmap>/
      self.tidloc_night = true
      c    = Tidloc::Clock::Nighttone
      tone = Tone.new(c[0], c[1], c[2], c[3])
      $game_map.screen.start_tone_change(tone, time)
    else
      tidloc_change_day 0
    end
  end
  def tidloc_change_day(time=0)
    self.tidloc_night = false
    c     = Tidloc::Clock::Daytone
    tone = Tone.new(c[0], c[1], c[2], c[3])
    $game_map.screen.start_tone_change(tone, time)
  end
  def update_tidloc_games
    eval $tidloc_game.update_map
  end
  alias wo_tidloc_update update
  def update
    if $tidloc_game
      super
      update_tidloc_games
      return
    end
    if $imported["Tidloc-Clock"]
      if $game_map.note =~ /<nightmap>/
        if Tidloc::Clock::Nightstart[0] && $game_temp._tidloc_clock_step == Tidloc::Clock::Nightstart
          tidloc_change_night 60 unless self.tidloc_night
        elsif Tidloc::Clock::Nightstart[0] && $game_temp._tidloc_clock_step > Tidloc::Clock::Nightstart
          tidloc_change_night 0 unless self.tidloc_night
        elsif Tidloc::Clock::Nightstart[0] && $game_temp._tidloc_clock_step < Tidloc::Clock::Nightstart
          tidloc_change_day 60 if self.tidloc_night
        end
      else
        tidloc_change_day
      end
    end
    if $imported["Tidloc-Compass"]
      compass_update
    end
    if $imported["Tidloc-D-Shop"]
      if Tidloc::D_Shop::TIMESTEP && ((($game_system.tidloc_dshop_time/60)+Tidloc::D_Shop::TIMESTEP) < ((Graphics.frame_count / Graphics.frame_rate) / 60))
        $game_system.tidloc_dshop_time  = Graphics.frame_count / Graphics.frame_rate
        Scene_Shop.process
      end
    end
    if $imported["Tidloc-Auction"]
      if Tidloc::Auction::Time > 0
        if (($game_temp.tidloc_auction_time/60)+Tidloc::Auction::Time) < ((Graphics.frame_count / Graphics.frame_rate) / 60)
          $game_temp.tidloc_auction_time = Graphics.frame_count / Graphics.frame_rate
          Tidloc_Auction.process
        end
      end
    end
    if $imported["Tidloc-MessageWindow"]
      if $game_system.tidloc_message_time_1 > -1
        if ($game_system.tidloc_message_time_1) + Tidloc::Message::Time-1 < ((Graphics.frame_count / Graphics.frame_rate))
          if $game_temp._tidloc_message_big.size > 0
            $game_system.tidloc_message_time_1 = Graphics.frame_count / Graphics.frame_rate
          else
            @Tidloc_Message_big.contents_opacity = 0
            $game_system.tidloc_message_time_1 = -1
          end
          @Tidloc_Message_big.refresh
        end
      end
      if $game_system.tidloc_message_time_2 > -1
        if ($game_system.tidloc_message_time_2) + Tidloc::Message::Time-1 < ((Graphics.frame_count / Graphics.frame_rate))
          if $game_temp._tidloc_message_small.size > 0
            $game_system.tidloc_message_time_2 = Graphics.frame_count / Graphics.frame_rate
          else
            @Tidloc_Message_small.contents_opacity = 0
            $game_system.tidloc_message_time_2 = -1
          end
          @Tidloc_Message_small.refresh
        end
      end
      if $game_system.tidloc_message_time_3 > -1
          if $game_temp._tidloc_message_quest.size > 0
            $game_system.tidloc_message_time_3 = Graphics.frame_count / Graphics.frame_rate
          else
            @Tidloc_Message_quest.contents_opacity = 0
            $game_system.tidloc_message_time_3 = -1
          end
          @Tidloc_Message_quest.refresh
      end
      if $game_temp._tidloc_message_big.size > 0 && $game_system.tidloc_message_time_1 == -1
        @Tidloc_Message_big.refresh
        @Tidloc_Message_big.contents_opacity = 255
        $game_system.tidloc_message_time_1 = Graphics.frame_count / Graphics.frame_rate
      end
      if $game_temp._tidloc_message_small.size > 0 && $game_system.tidloc_message_time_2 == -1
        @Tidloc_Message_small.refresh
        @Tidloc_Message_small.contents_opacity = 255
        $game_system.tidloc_message_time_2 = Graphics.frame_count / Graphics.frame_rate
      end
      if $game_temp._tidloc_message_history.size > Tidloc::Message::Max_History
        temp = $game_temp._tidloc_message_history.size-Tidloc::Message::Max_History
        $game_temp._tidloc_message_history[0...temp] = $game_temp._tidloc_message_history[temp-1]
      end
      if $game_temp._tidloc_message_quest.size > 0 && $game_system.tidloc_message_time_3 == -1
        @Tidloc_Message_quest.refresh
        @Tidloc_Message_quest.contents_opacity = 255
        $game_system.tidloc_message_time_3 = Graphics.frame_count / Graphics.frame_rate
      end
    end
    wo_tidloc_update
    if (Graphics.frame_count * 3 / Graphics.frame_rate) != @total_seconds
      @total_seconds = Graphics.frame_count * 3 / Graphics.frame_rate
      if $imported["Tidloc-Smith"]
        for i in 0...$game_system.tidloc_smith.busy.length
          if $game_system.tidloc_smith.busy[i] && $game_system.tidloc_smith.time[i] > 0
                $game_system.tidloc_smith.time[i] -= 1
          end
        end
      end
      if $imported["Tidloc-Alchemy"]
        for i in 0...$game_system.tidloc_alch.busy.length
          if $game_system.tidloc_alch.busy[i] && $game_system.tidloc_alch.time[i] > 0
                $game_system.tidloc_alch.time[i] -= 1
          end
        end
      end
    end
    if $imported["Tidloc-CustomSkills"]
      $game_party.battle_members.each{|p|
        if p.tidloc_skill_forget? && 
                p.tidloc_skills.find_all{|s| s.sid!=0}.size !=
                p.tidloc_active_skills.find_all{|s| s.sid!=0}.size
          $game_party.menu_actor = p
          Tidloc.exe("Skills",:call)
        end
      }
    end
  end
  
  alias wo_tidloc_update_scene update_scene
  def update_scene
    wo_tidloc_update_scene
    update_call_debug_tidloc unless scene_changing?
    return unless Tidloc::Use_mod[:Menu_mod]
    update_call_questlog     unless scene_changing? || !Tidloc::Keys["Questlog"]
    update_call_alchemy      unless scene_changing? || !Tidloc::Keys["Alchemy"]
    update_call_smith        unless scene_changing? || !Tidloc::Keys["Smith"]
    update_call_dismantle    unless scene_changing? || !Tidloc::Keys["Dismantle"]
    update_call_runes        unless scene_changing? || !Tidloc::Keys["Runes"]
    update_call_auction      unless scene_changing? || !Tidloc::Keys["Auction"]
    update_call_message      unless scene_changing? || !Tidloc::Keys["Message"]
    update_call_identify     unless scene_changing? || !Tidloc::Keys["Identify"]
    update_call_enchant      unless scene_changing? || !Tidloc::Keys["Enchant"]
    update_call_unench       unless scene_changing? || !Tidloc::Keys["UnEnch"]
    update_call_socket       unless scene_changing? || !Tidloc::Keys["Socket"]
    update_call_customskills unless scene_changing? || !Tidloc::Keys["CustomSkills"]
    update_call_help         unless scene_changing? || !Tidloc::Keys["Help"]
  end
  def update_call_debug_tidloc
    unless $game_map.interpreter.running?
      @debug_calling ||= Input.trigger?(Tidloc::Keys["DEBUG"])
      if @debug_calling && !$game_player.moving? && Tidloc::DEBUG
        Tidloc.try
      end
      @debug_calling = false
    end
  end
  def update_call_questlog
    unless $game_map.interpreter.running?
      @questlog_calling ||= Input.trigger?(Tidloc::Keys["Questlog"])
      if @questlog_calling && !$game_player.moving?
        Tidloc.exe "Questlog",:call
      end
      @questlog_calling = false
    end
  end
  def update_call_alchemy
    unless $game_map.interpreter.running?
      @alchemy_calling ||= Input.trigger?(Tidloc::Keys["Alchemy"])
      if @alchemy_calling && !$game_player.moving?
        Tidloc.exe "Alchemy",:call,0
      end
      @alchemy_calling = false
    end
  end
  def update_call_smith
    unless $game_map.interpreter.running?
      @smith_calling ||= Input.trigger?(Tidloc::Keys["Smith"])
      if @smith_calling && !$game_player.moving?
        Tidloc.exe "Smith",:call,0
      end
      @smith_calling = false
    end
  end
  def update_call_dismantle
    unless $game_map.interpreter.running?
      @dismantle_calling ||= Input.trigger?(Tidloc::Keys["Dismantle"])
      if @dismantle_calling && !$game_player.moving?
        Tidloc.exe "Dismantle",:call
      end
      @dismantle_calling = false
    end
  end
  def update_call_runes
    unless $game_map.interpreter.running?
      @runes_calling ||= Input.trigger?(Tidloc::Keys["Runes"])
      if @runes_calling && !$game_player.moving?
        Tidloc.exe "Rune",:call
      end
      @runes_calling = false
    end
  end
  def update_call_auction
    unless $game_map.interpreter.running?
      @auctions_calling ||= Input.trigger?(Tidloc::Keys["Auction"])
      if @auctions_calling && !$game_player.moving?
        Tidloc.exe "Auction",:call
      end
      @auctions_calling = false
    end
  end
  def update_call_message
    unless $game_map.interpreter.running?
      @message_calling ||= Input.trigger?(Tidloc::Keys["Message"])
      if @message_calling && !$game_player.moving?
        Tidloc.exe "Message",:call
      end
      @message_calling = false
    end
  end
  def update_call_identify
    unless $game_map.interpreter.running?
      @identify_calling ||= Input.trigger?(Tidloc::Keys["Identify"])
      if @identify_calling && !$game_player.moving?
        Tidloc.exe "Identify",:call,1
      end
      @identify_calling = false
    end
  end
  def update_call_enchant
    unless $game_map.interpreter.running?
      @enchant_calling ||= Input.trigger?(Tidloc::Keys["Enchant"])
      if @enchant_calling && !$game_player.moving?
        Tidloc.exe "Enchant",:call
      end
      @enchant_calling = false
    end
  end
  def update_call_unench
    unless $game_map.interpreter.running?
      @unench_calling ||= Input.trigger?(Tidloc::Keys["UnEnch"])
      if @unench_calling && !$game_player.moving?
        Tidloc.exe "UnEnch",:call 
      end
      @unench_calling = false
    end
  end
  def update_call_socket
    unless $game_map.interpreter.running?
      @socket_calling ||= Input.trigger?(Tidloc::Keys["Socket"])
      if @socket_calling && !$game_player.moving?
        Tidloc.exe "Socket",:call
      end
      @socket_calling = false
    end
  end
  def update_call_customskills
    unless $game_map.interpreter.running?
      @customskills_calling ||= Input.trigger?(Tidloc::Keys["CustomSkills"])
      if @customskills_calling && !$game_player.moving?
        Tidloc.exe "Skills",:call
      end
      @customskills_calling = false
    end
  end
  def update_call_help
    unless $game_map.interpreter.running?
      @customskills_calling ||= Input.trigger?(Tidloc::Keys["CustomSkills"])
      if @customskills_calling && !$game_player.moving?
        if false
        elsif $imported["Tidloc-Alchemy"] &&
              SceneManager.scene.is_a?(Tidloc_Alch)
        elsif $imported["Tidloc-Smith"] &&
              SceneManager.scene.is_a?(Tidloc_Smith)
        elsif $imported["Tidloc-Dismantle"] &&
              SceneManager.scene.is_a?(Tidloc_Dismantle)
        elsif $imported["Tidloc-RuneShop"] &&
              SceneManager.scene.is_a?(Tidloc::Rune::Rune_Magic_Shop)
        end
      end
      @customskills_calling = false
    end
  end
end

################################################################################
#                                                                              #
################################################################################

#~ class Window_ItemList < Window_Selectable
#~   attr_accessor :cat_window
#~   attr_accessor :tid_category
#~   alias wo_tidloc_include include?
#~   def include?(item)
#~     return wo_tidloc_include(item) unless Tidloc::Use_mod[:item_win_mod]
#~     if Tidloc::Use_mod[:Show_all_cat] && !self.active && @category==:item
#~       return item.is_a?(RPG::Item) && !item.key_item?
#~     end
#~     if self.cat_window && $imported["Tidloc-CustomEquip"] && item.is_a?(Tidloc::CustomEquip::Base) && self.cat_window.index > 0
#~       return false if item.item.name != self.cat_window.group[self.cat_window.index]
#~     end
#~     if self.tid_category && item.is_a?(RPG::Item) && self.tid_category.index >= 0
#~       return false if item.tidloc_class != self.tid_category.category[self.tid_category.index]
#~     end
#~     case @category
#~     when :item
#~       item.is_a?(RPG::Item) && !item.key_item?
#~     when :weapon
#~       if  $imported["Tidloc-CustomEquip"]
#~         item.is_a?(Tidloc::CustomEquip::Weapon) &&
#~                    $game_party.weapons.find{|x| x.nid==item.nid}.inv
#~       else
#~         item.is_a?(RPG::Weapon)
#~       end
#~     when :armor
#~       if $imported["Tidloc-CustomEquip"]
#~         item.is_a?(Tidloc::CustomEquip::Armor)  && 
#~                    $game_party.armors.find{|x| x.nid == item.nid}.inv
#~       else
#~         item.is_a?(RPG::Armor)
#~       end
#~     when :key_item
#~       item.is_a?(RPG::Item) && item.key_item?
#~     else
#~       false
#~     end
#~   end
#~   alias wo_tidloc_draw_number draw_item_number
#~   def draw_item_number(rect, item)
#~     return if !Tidloc::Use_mod[:item_win_mod] && $imported["Tidloc-CustomEquip"] && item.is_a?(Tidloc::CustomEquip::Base)
#~     wo_tidloc_draw_number(rect, item)
#~   end
#~   alias wo_tidloc_draw_item draw_item
#~   def draw_item(index)
#~     return wo_tidloc_draw_item(index) if Tidloc::Use_mod[:item_win_mod]
#~     item = @data[index]
#~     if item
#~       rect = item_rect(index)
#~       rect.width -= 4
#~       draw_item_name(item, rect.x, rect.y, enable?(item))
#~       draw_item_number(rect, item)
#~     end
#~   end
#~   alias wo_tidloc_item_cursor_pagedown cursor_pagedown
#~   def cursor_pagedown
#~     wo_tidloc_item_cursor_pagedown if !Tidloc::Use_mod[:item_win_mod]
#~   end
#~   alias wo_tidloc_item_cursor_pageup cursor_pageup
#~   def cursor_pageup
#~     wo_tidloc_item_cursor_pageup if !Tidloc::Use_mod[:item_win_mod]
#~   end
#~   alias wo_tidloc_col_max col_max
#~   def col_max
#~     if Tidloc::Use_mod[:item_win_mod]
#~       Tidloc::Item_Columns
#~     else
#~       wo_tidloc_col_max
#~     end
#~   end
#~ end
################################################################################
#                                                                              #
################################################################################

#~ class Window_BattleItem < Window_ItemList
#~   alias wo_tidloc_bitem_col_max col_max
#~   def col_max
#~     return wo_tidloc_bitem_col_max if !Tidloc::Use_mod[:bitem_win_mod]
#~     1
#~   end
#~   alias wo_tidloc_bitem_cursor_pagedown cursor_pagedown
#~   def cursor_pagedown
#~     return wo_tidloc_bitem_cursor_pagedown if !Tidloc::Use_mod[:bitem_win_mod]
#~     self.index = [self.index+9,item_max-1].min
#~   end
#~   alias wo_tidloc_bitem_cursor_pageup cursor_pageup
#~   def cursor_pageup
#~     return wo_tidloc_bitem_cursor_pageup if !Tidloc::Use_mod[:bitem_win_mod]
#~     self.index = [self.index-9,0].max
#~   end
#~ end

#~ class Window_Base < Window
#~   def dispose
#~     contents.dispose unless disposed? || contents.nil?
#~     super
#~   end
#~   def tidloc_opacity(o)
#~     self.opacity = o
#~   end
#~   alias wo_tidloc_draw_currency_value draw_currency_value
#~   def draw_currency_value(value, unit, x, y, width,with_name=false)
#~     unless Tidloc::Use_mod[:base_win_mod]
#~       wo_tidloc_draw_currency_value(value, unit, x, y, width)
#~       return
#~     end
#~     drawn = false
#~     cx = text_size(unit).width
#~     if Tidloc::Money_Icon
#~       draw_icon(Tidloc::Money_Icon,x,y)
#~       x += 28 if with_name
#~       drawn = true
#~     elsif Tidloc::Money_Img
#~       image=Cache.picture(Tidloc::Money_Img)
#~       contents.blt(x,y,image,image.rect)
#~       x += image.rect.width+4 if with_name
#~       drawn = true
#~     end
#~     if !drawn || with_name
#~       change_color(system_color)
#~       draw_text(x, y, Graphics.width/3, line_height, unit, 0)
#~       change_color(normal_color)
#~     end
#~     draw_text(x, y, width - cx - 2, line_height, value, 2)
#~   end
#~ end
################################################################################
#                                                                              #
################################################################################

#~ class Window_Selectable
#~   alias wo_tidloc_select select
#~   def select(index)
#~     wo_tidloc_select(index)
#~     call_handler(:change)
#~   end
#~   alias wo_tidloc_activate activate
#~   def activate
#~     wo_tidloc_activate
#~     call_handler(:change)
#~     self
#~   end
#~ end
################################################################################
#                                                                              #
################################################################################

#~ class Game_Player
#~   alias wo_tidloc_move_straight move_straight
#~   def move_straight(d, turn_ok = true)
#~     wo_tidloc_move_straight(d, turn_ok)
#~     $game_party.battle_members.each{|p| p.tidloc_exe_command("Random")} if Tidloc::Use_mod[:random_command] && rand(100)<1
#~   end
#~ end

#~ class Game_Actor < Game_Battler
#~   attr_accessor :rune_visible
#~   attr_accessor :rune_lvls
#~   attr_accessor :rune_lvlu
#~   attr_accessor :level_sum
#~   attr_accessor :tidloc_runes
#~   attr_accessor :tidloc_skills
#~   attr_accessor :tidloc_skills_count
#~   attr_accessor :tidloc_active_skills
#~   attr_accessor :tidloc_max_skills
#~   attr_accessor :commands
#~   alias wo_tid_init initialize
#~   def initialize(actor_id)
#~     if Tidloc::Use_mod[:actor_command]
#~       self.commands    = []
#~       self.commands    = Tidloc::Header::ActorData(actor_id)[:commands] if $imported["Tidloc-ActorData"]
#~     end
#~     wo_tid_init(actor_id)
#~     if $imported["Tidloc-Runes"]
#~       self.rune_visible = false
#~       self.level_sum   = 0
#~       self.rune_lvls   = []
#~       self.rune_lvlu   = []
#~       self.tidloc_runes = [Tidloc::Rune::Runedata.new,Tidloc::Rune::Runedata.new,Tidloc::Rune::Runedata.new,Tidloc::Rune::Runedata.new]
#~     end
#~     if $imported["Tidloc-CustomSkills"]
#~       self.tidloc_skills        = [] if self.tidloc_skills.nil?
#~       self.tidloc_active_skills = [] if self.tidloc_active_skills.nil?
#~       if self.actor.note =~ Tidloc::CustomSkills::Notetags[0]
#~         self.tidloc_max_skills    = $1.to_i
#~       else
#~         self.tidloc_max_skills    = Tidloc::CustomSkills::Init_Skills
#~       end
#~       for i in 0...self.tidloc_max_skills
#~         if self.tidloc_active_skills[i].nil?
#~           self.tidloc_active_skills[i] = Tidloc::CustomSkills::Base.new 0
#~         end
#~       end
#~     end
#~   end
#~   alias wo_tidloc_equips_slots equip_slots
#~   def equip_slots
#~     if !Tidloc::Use_mod[:accessoires]
#~       return wo_tidloc_equips_slots
#~     end
#~     temp = [0,1,2,3]
#~     temp[1] = 0 if dual_wield?
#~     for i in 1..Tidloc::Accessoire_Count
#~       temp.push 4
#~     end
#~     return temp
#~   end
#~   
#~   alias wo_tid_gain_exp gain_exp
#~   def gain_exp(exp)
#~     $game_temp.tidloc[:actor] = self
#~     if Tidloc.Version("Tidloc-CustomEquip",[1,4,0])
#~       self.equips.compact.each{|item|
#~         item.object.gain_exp(exp) if item.object.is_a?(Tidloc::CustomEquip::Base)
#~       }
#~     end
#~     if Tidloc.Version("Tidloc-Runes",[1,0,0])
#~       for i in 0...self.tidloc_runes.count
#~         rune = self.tidloc_runes[i]
#~         rune.exp_now += (exp * final_exp_rate).to_i if rune.id && rune.lvl < rune.maxlvl
#~         if rune.id && rune.exp_now >= rune.exp_next
#~           rune.execute_commands("Level Up")
#~           id = rune.id
#~           self.rune_lvlu[id]  = 0 if self.rune_lvlu[id].nil?
#~           self.rune_lvls[id]  = 0 if self.rune_lvls[id].nil?
#~           self.rune_lvls[id] += 1
#~           rune.execute_commands("Level Max") if self.rune_lvls[id] == rune.maxlvl
#~           self.add_param(2, 1) if rune.attr[0] == 1
#~           self.add_param(4, 1) if rune.attr[1] == 1
#~           self.add_param(6, 1) if rune.attr[2] == 1
#~           self.add_param(7, 1) if rune.attr[3] == 1
#~           self.add_param(8, 1) if rune.attr[4] == 1
#~           self.add_param(9, 1) if rune.attr[5] == 1
#~           self.tidloc_runes[i] = Tidloc::Rune::Runedata.new
#~           self.level_sum += 1
#~         end
#~       end
#~     end
#~     if $imported["Tidloc-ExpSkills"]
#~       self.tidloc_active_skills.each{|skill|
#~         skill.gain_exp(exp)
#~       }
#~     end
#~     wo_tid_gain_exp(exp) if !($imported["Tidloc-Runes"]) || Tidloc::Rune::Actor_gain_exp
#~   end
#~   alias wo_tidloc_level_up level_up
#~   def level_up
#~     wo_tidloc_level_up
#~     if $imported["Tidloc-CustomSkills"]
#~       if    self.note =~ /#{Tidloc::CustomSkills::Notetags[1][0]}#{@level}#{Tidloc::CustomSkills::Notetags[1][1]}/i
#~         self.tidloc_max_skills += $1.to_i
#~       elsif self.note =~ /#{Tidloc::CustomSkills::Notetags[2][0]}#{@level}#{Tidloc::CustomSkills::Notetags[2][1]}/i
#~         self.tidloc_max_skills -= $1.to_i
#~       elsif self.note =~ /#{Tidloc::CustomSkills::Notetags[3][0]}#{@level}#{Tidloc::CustomSkills::Notetags[3][1]}/i
#~         self.tidloc_max_skills  = $1.to_i
#~       end
#~       self.tidloc_max_skills = [[self.tidloc_max_skills,0].max,Tidloc::CustomSkills::Max_skills].min if $imported["Tidloc-CustomSkills"]
#~     end
#~   end
#~   alias wo_tidloc_param param
#~   def param(param_id)
#~     if param_id > 99 && $imported["Tidloc-AddStats"] && $imported["Tidloc-CustomEquip"]
#~       return 0 if (param_id-100 >= Tidloc::Additional_Stats::Stats.size) || @equips.nil?
#~       self.equips.each{|i|
#~         temp = (i.object.is_a?(RPG::Weapon) || i.object.is_a?(Tidloc::CustomEquip::Weapon))?1000 : 2000
#~         if i.object
#~           if $game_temp._tidloc_addstats[temp+i.object.id]
#~             if $game_temp._tidloc_addstats[temp+i.object.id][param_id-100]
#~               value += $game_temp._tidloc_addstats[temp+i.object.id][param_id-100] 
#~             end
#~           end
#~         end
#~         i.pretag.commands.each{|x|
#~           value += x[2] if x[0] == "AddStat" && x[1] == param_id-100
#~         }if i.pretag
#~         i.postag.commands.each{|x|
#~           value += x[2] if x[0] == "AddStat" && x[1] == param_id-100
#~         }if i.postag
#~         i.sockets.each{|y|
#~           y.commands.each{|x|
#~             value += x[2] if x[0] == "AddStat" && x[1] == param_id-100
#~           } if y.commands
#~         } if i.sockets
#~       }
#~       return value
#~     else
#~ ###############################################
#~ #
#~ #  influence of vit on HP and int on mp
#~ #
#~ ###############################################
#~       value = wo_tidloc_param(param_id)
#~       value += param(9)*Tidloc::Vit_Rate if Tidloc::Use_mod[:vit_rate] && param_id==0
#~       value += param(4)*Tidloc::Int_Rate if Tidloc::Use_mod[:int_rate] && param_id==1
#~       return [[value, param_max(param_id)].min, param_min(param_id)].max.to_i
#~     end
#~   end
#~   alias wo_tidloc_param_base param_base
#~   def param_base(param_id)
#~     if param_id < 8
#~       return wo_tidloc_param_base(param_id)
#~     elsif self.actor.note =~ Tidloc::Notetags[0][param_id]
#~       value += $1.to_i
#~     elsif self.class.note =~Tidloc::Notetags[0][param_id]
#~       value += $1.to_i
#~     else
#~       return 1
#~     end
#~   end
#~   def per_param(param_id)
#~     value = 1.0
#~     if $imported["Tidloc-CustomEquip"]
#~       equips.compact.each{|i|
#~         value *= i.param2[param_id] }
#~     end
#~     if $imported["Tidloc-CustomSkills"] && self.tidloc_active_skills && $imported["Tidloc-PassiveSkills"]
#~       for i in self.tidloc_active_skills
#~         if i.is_passive?
#~           value *= i.note =~ Tidloc::Notetags[1][param_id] ? 1+($1.to_f/100) : 1
#~           value *= i.exp_bonus2[param_id] if $imported["Tidloc-ExpSkills"] && i.exp_skill && i.exp_bonus2[param_id]
#~         end
#~       end
#~     end
#~     return value
#~   end
#~   alias wo_tidloc_param_plus param_plus
#~   def param_plus(param_id)
#~     value = 0
#~     if param_id < 8
#~       value = wo_tidloc_param_plus(param_id)
#~     elsif $imported["Tidloc-CustomEquip"]
#~       self.equips.compact.each{|item|
#~         value += item.params[param_id]
#~       }
#~     end
#~     if $imported["Tidloc-CustomSkills"] && self.tidloc_active_skills && $imported["Tidloc-PassiveSkills"]
#~       for i in self.tidloc_active_skills
#~         if i.is_passive?
#~           value += (i.note =~ Tidloc::Notetags[0][param_id]) ? $1.to_i : 0
#~           value += i.exp_bonus[param_id] if $imported["Tidloc-ExpSkills"] && i.exp_skill && i.exp_bonus[param_id]
#~         end
#~       end
#~     end
#~     return value
#~   end
#~   alias wo_tidloc_param_rate param_rate
#~   def param_rate(param_id)
#~     temp  = (param_id<8) ? wo_tidloc_param_rate(param_id) : 1.0
#~     temp *= per_param(param_id)
#~     temp
#~   end
#~   alias wo_tidloc_param_buff_rate param_buff_rate
#~   def param_buff_rate(param_id)
#~     return (param_id<8) ? wo_tidloc_param_buff_rate(param_id) : 1.0
#~   end
#~   alias wo_tidloc_resist? state_resist?
#~   def state_resist?(state_id)
#~     if $imported["Tidloc-PassiveSkills"] && self.tidloc_active_skills
#~       for i in self.tidloc_active_skills
#~         i.note =~ Tidloc::Notetags[2][1]
#~         if state_id == $1.to_i
#~           return true
#~         end
#~       end
#~     end
#~     return wo_tidloc_resist?(state_id)
#~   end
#~   alias wo_tidloc_element_rate item_element_rate
#~   def item_element_rate(user, item)
#~     rate = wo_tidloc_element_rate(user, item)
#~     if item.damage.element_id < 0
#~       if user.atk_elements.empty?
#~         return 1.0
#~       elsif $imported["Elemental_Modifiers"]
#~         element_id = weakest_element(user.atk_elements)
#~       else
#~         return rate
#~       end
#~     else
#~       if $imported[:TH_AttackElementModifiers]
#~         unless item.atk_element_modifiers.empty?
#~           rate = item_multi_element_rate(user, item)
#~         end
#~  #     else
#~  #       return wo_tidloc_element_rate(user, item)
#~       end
#~     end
#~     if $imported["Tidloc-CustomSkills"] && $imported["Tidloc-PassiveSkills"]
#~       if user == self
#~         for i in self.tidloc_active_skills
#~           unless i.object.nil? 
#~             while(i.note =~ Tidloc::Notetags[2][2])
#~               if $1 == element_id && i.is_passive?
#~                 rate *= 1+($2.to_f/100)
#~               end
#~             end
#~           end
#~         end
#~       else
#~         for i in self.tidloc_active_skills
#~           while(i.note =~ Tidloc::Notetags[2][3])
#~             if $1 == element_id
#~               rate *= 1+($2.to_f/100)
#~             end
#~           end
#~         end
#~       end
#~     end
#~     return rate
#~   end
#~   def tidloc_exe_command(cmd)
#~     return if self.dead? || self.commands.nil?
#~     $game_temp.tidloc[:actor] = self
#~     if Tidloc::Use_mod[:actor_command]
#~       self.commands.each{|x| x[0]==cmd ? eval(Tidloc.exe(x[1],x[2])) : ""}
#~     end
#~     if $imported["Tidloc-CustomEquip"]
#~       @equips.each{|item|
#~         item.object.execute_commands(cmd) if item.object.is_a?(Tidloc::CustomEquip::Base)
#~       }
#~     end
#~     if $imported["Tidloc-CustomSkills"] && self.tidloc_active_skills
#~       self.tidloc_active_skills.each{|skill|
#~         skill.execute_commands(cmd)
#~       }
#~     end
#~     if $imported["Tidloc-Runes"] && self.tidloc_runes
#~       self.tidloc_runes.each{|rune|
#~         rune.execute_commands(cmd)
#~       }
#~     end
#~   end
#~ end
################################################################################
#                                                                              #
################################################################################

#~ class Game_Enemy
#~   attr_accessor :commands
#~   attr_accessor :_tidvar
#~   alias wo_tidloc_initialize initialize
#~   def initialize(*args)
#~     wo_tidloc_initialize(*args)
#~     if Tidloc::Use_mod[:enemy_command]
#~       self.commands = []
#~       self.commands = Tidloc::Header.EnemyData(self.enemy_id)[:commands] if $imported["Tidloc-EnemyData"]
#~     end
#~     self._tidvar  = []
#~   end
#~   alias wo_tidloc_param_base param_base
#~   def param_base(param_id)
#~     if param_id < 8
#~       temp = wo_tidloc_param_base(param_id)
#~     else
#~       temp = 1
#~     end
#~     if self.enemy.note =~ Tidloc::Notetags[0][param_id]
#~       temp += $1.to_i
#~     end
#~     temp
#~   end
#~   def tidloc_exe_command(tag)
#~     return if self.dead? || self.hidden?
#~     if Tidloc::Use_mod[:enemy_command] && $imported["Tidloc-EnemyData"]
#~       $game_temp.tidloc[:enemy] = self
#~       self.commands.each{|x| x[0]==tag ? eval(Tidloc.exe(x[1],x[2])) : ""}
#~     end
#~   end
#~ end
################################################################################
#                                                                              #
################################################################################

#~ class Window_BattleLog < Window_Selectable
#~   alias wo_tidloc_display_critical display_critical
#~   def display_critical(target, item)
#~     if Tidloc::Use_mod[:limitbreak] && target.result.limitbreak
#~       text = target.actor? ? Bitmap.html_decode(Vocab::LBToActor) : Bitmap.html_decode(Vocab::LBToEnemy)
#~       add_text(text)
#~       wait
#~     else
#~       wo_tidloc_display_critical(target, item)
#~     end
#~   end
#~ end
################################################################################
#                                                                              #
################################################################################

#~ class Game_ActionResult
#~   attr_accessor :limitbreak
#~   alias wo_tidloc_clear_hit_flags clear_hit_flags
#~   def clear_hit_flags
#~     wo_tidloc_clear_hit_flags
#~     @limitbreak = false if Tidloc::Use_mod[:limitbreak]
#~   end
#~   alias wo_tidloc_make_damage make_damage
#~   def make_damage(value, item)
#~     @limitbreak = false if value == 0 || !Tidloc::Use_mod[:limitbreak]
#~     wo_tidloc_make_damage(value, item)
#~   end
#~ end
################################################################################
#                                                                              #
################################################################################

#~ module BattleManager
#~   class<<self;alias wo_tidloc_turn_start turn_start;end
#~   def self.turn_start
#~     wo_tidloc_turn_start
#~     unless $imported["Ao no Kiseki"]
#~       $game_party.battle_members.each{|m|
#~         m.tidloc_exe_command("TurnStart") 
#~       }
#~     end
#~   end
#~   class<<self;alias wo_tidloc_turn_end turn_end;end
#~   def self.turn_end
#~     wo_tidloc_turn_end
#~     unless $imported["Ao no Kiseki"]
#~       $game_party.battle_members.each{|m|
#~         m.tidloc_exe_command("TurnEnd")}
#~     end
#~     $game_party.battle_members.each{|m|
#~       $game_temp.tidloc[:actor] = m
#~       m.tidloc_exe_command("TurnNext")}
#~     $game_troop.members.each{|t|
#~       $game_temp.tidloc[:enemy] = t
#~       t.tidloc_exe_command("TurnNext")}
#~   end
#~ end

################################################################################
#                                                                              #
################################################################################

#~ class Window_EquipSlot < Window_Selectable
#~   alias wo_tidloc_initialize initialize
#~   def initialize(x, y, width)
#~     if !Tidloc::Use_mod[:accessoires]
#~       wo_tidloc_initialize x, y, width
#~       return
#~     end
#~     super(x, y, width, 144)
#~     @actor = nil
#~     refresh
#~   end
#~   def contents_height
#~     visible_line_number * line_height + standard_padding * 2
#~   end
#~   alias wo_tidloc_visible_line_number visible_line_number
#~   def visible_line_number
#~     return wo_tidloc_visible_line_number unless Tidloc::Use_mod[:accessoires]
#~     return 4 + Tidloc::Accessoire_Count
#~   end
#~ end
################################################################################
#                                                                              #
################################################################################

#~ class Window_Help < Window_Base
#~   def text
#~     return @text
#~   end
#~ end
################################################################################
#                                                                              #
################################################################################

#~ class Scene_ItemBase < Scene_MenuBase
#~   def use_item
#~     play_se_for_item
#~     user.use_item(item)
#~     use_item_to_actors
#~     check_common_event
#~     check_gameover
#~     @item_window.enable? @item_window.item
#~     @actor_window.refresh
#~     @item_window.refresh
#~     unless @item_window.enable? @item_window.item
#~       on_actor_cancel
#~     end
#~   end
#~ end
################################################################################
#                                                                              #
#~ ################################################################################

#~ class Scene_Item < Scene_ItemBase
#~   alias wo_tid_header_start start
#~   def start
#~     super
#~     if $imported["Tidloc-CustomEquip"] && $imported["HTML-tagging"] && Tidloc::CustomEquip::Use_New_Info_item
#~       @last_group = -1
#~       create_category_window if $imported["Tidloc-CustomEquip"] && Tidloc::CustomEquip::Use_New_Info_item
#~       create_help_window
#~       create_category_window unless $imported["Tidloc-CustomEquip"] && Tidloc::CustomEquip::Use_New_Info_item
#~       create_item_window
#~     else
#~       wo_tid_header_start
#~     end
#~     create_cat_window  if $imported["Tidloc-CustomEquip"] && Tidloc::CustomEquip::Use_Item_Group
#~     create_tid_category if Tidloc::Use_mod[:item_categories]
#~     @last_group_2 = -1
#~     create_tidhelp_window if Tidloc::Keys["Help"]
#~   end
#~   
#~   def create_tidhelp_window
#~     @tidhelp_window = Tidloc::Window_Tid_Help.new
#~     text  = "<space=50>Changing Categories:\n"
#~     text += eval(Tidloc::Help["Cat+"])+": "+Tidloc::Vocabs.Header("Cat+2",$tidloc_language)+"\n"
#~     text += eval(Tidloc::Help["Cat-"])+": "+Tidloc::Vocabs.Header("Cat-2",$tidloc_language)+"\n"
#~     @tidhelp_window.text = text
#~     @tidhelp_window.viewport = @viewport
#~   end
#~   def create_cat_window
#~     @cat_window = Tidloc::CustomEquip::Group_Window.new
#~     @cat_window.y = @category_window.y
#~     @cat_window.viewport = @viewport
#~     @item_window.cat_window = @cat_window
#~     @item_window.viewport = @viewport
#~   end
#~   alias wo_tid_header_create_category create_category_window
#~   def create_category_window
#~     if $imported["Tidloc-CustomEquip"] && Tidloc::CustomEquip::Use_New_Info_item
#~       @category_window = (Tidloc::Use_mod[:item_categories])?Window_ItemCategory_2.new : Window_ItemCategory.new
#~       @category_window.viewport = @viewport
#~       @category_window.help_window = @help_window
#~       @category_window.y = 0
#~       @category_window.set_handler(:ok,     method(:on_category_ok))
#~       @category_window.set_handler(:cancel, method(:return_scene))
#~       @category_window.viewport = @viewport
#~     else
#~       wo_tid_header_create_category
#~     end
#~     @category_window.z=0
#~   end
#~   alias wo_tid_header_item_window create_item_window
#~   def create_item_window
#~     if $imported["Tidloc-CustomEquip"] && Tidloc::CustomEquip::Use_New_Info_item
#~       wy = @category_window.y + @category_window.height
#~       wh = Graphics.height - wy
#~       @item_window = Tidloc::CustomEquip::Window_ItemList_22.new(0, wy, Graphics.width/2, wh)# : Window_ItemList_2.new(0, wy, Graphics.width/2, wh)
#~       @item_window.viewport = @viewport
#~       @item_window.help_window = @help_window
#~       @item_window.set_handler(:ok,     method(:on_item_ok))
#~       @item_window.set_handler(:cancel, method(:on_item_cancel))
#~       @category_window.item_window = @item_window
#~     else
#~       wo_tid_header_item_window
#~     end
#~   end
#~   def create_tid_category
#~     @tid_category = Tidloc::Header::Category_Window.new
#~     @tid_category.y = @category_window.y
#~     @tid_category.viewport = @viewport
#~     @item_window.tid_category = @tid_category
#~     @item_window.refresh
#~   end
#~   def create_help_window
#~     if $imported["Tidloc-CustomEquip"] && $imported["HTML-tagging"] && Tidloc::CustomEquip::Use_New_Info_item
#~       wy = @category_window.height
#~       wh = Graphics.height - wy
#~       @help_window = Tidloc::CustomEquip::Window_ShopStatus2.new(Graphics.width/2, wy, Graphics.width/2, wh)
#~       @help_window.z = 900
#~       @help_window.scene = :item
#~       @help_window.viewport = @viewport
#~     else
#~       super 
#~     end
#~   end
#~   
#~   def update_all_windows
#~     if @tidhelp_window && @tidhelp_window.active
#~       if Input.trigger?(:C) || Input.trigger?(:B)
#~         @tidhelp_window.hide.deactivate
#~       elsif Input.press?(Tidloc::Keys["Scroll+"])
#~         @tidhelp_window.scroll_up
#~         @tidhelp_window.update
#~       elsif Input.press?(Tidloc::Keys["Scroll-"])
#~         @tidhelp_window.scroll_down
#~         @tidhelp_window.update
#~       end
#~       return
#~     end
#~     if Tidloc::Keys["Help"] && Input.trigger?(Tidloc::Keys["Help"])
#~       @tidhelp_window.show.activate
#~     end  
#~     if $imported["Tidloc-CustomEquip"] && Tidloc::CustomEquip::Use_Item_Group && @item_window.active && (@category_window.index == 1 || @category_window.index == 2)
#~       if    Input.trigger?(Tidloc::Keys["Cat-"])
#~         @cat_window.index -= 1
#~         @cat_window.index  = @cat_window.group.size - 1 if @cat_window.index < 0
#~         Sound.play_cursor
#~       elsif Input.trigger?(Tidloc::Keys["Cat+"])
#~         @cat_window.index += 1
#~         @cat_window.index  = 0 if @cat_window.index >= @cat_window.group.size
#~         Sound.play_cursor
#~       end
#~       while @cat_window.index*@cat_window.item_width >= 3*@cat_window.item_width+@cat_window.ox
#~         @cat_window.ox += @cat_window.item_width
#~       end
#~       while @cat_window.index*@cat_window.item_width < @cat_window.ox
#~         @cat_window.ox -= @cat_window.item_width
#~       end
#~     end
#~     if $imported["Tidloc-CustomEquip"] && Tidloc::CustomEquip::Use_Item_Group && @last_group != @cat_window.group[@cat_window.index]
#~       @item_window.refresh
#~       @last_group = @cat_window.group[@cat_window.index]
#~       @item_window.index = [@item_window.index,@item_window.item_max-1].min
#~       return
#~     end
#~     if Tidloc::Use_mod[:item_categories] && @item_window.active && @category_window.index == 0
#~       if    Input.trigger?(Tidloc::Keys["Cat-"])
#~         @tid_category.index -= 1
#~         @tid_category.index  = @tid_category.category.size - 1 if @tid_category.index < 0
#~         Sound.play_cursor
#~         @item_window.refresh
#~         @item_window.index=0 if @item_window.index < 0 && @item_window.item_max>0
#~       elsif Input.trigger?(Tidloc::Keys["Cat+"])
#~         @tid_category.index += 1
#~         @tid_category.index  = 0 if @tid_category.index >= @tid_category.category.size
#~         Sound.play_cursor
#~         @item_window.refresh
#~         @item_window.index=0 if @item_window.index < 0 && @item_window.item_max>0
#~       end
#~       while @tid_category.index*@tid_category.item_width >= 3*@tid_category.item_width+@tid_category.ox
#~         @tid_category.ox += @tid_category.item_width
#~       end
#~       while @tid_category.index*@tid_category.item_width < @tid_category.ox
#~         @tid_category.ox -= @tid_category.item_width
#~       end
#~     end
#~     if Tidloc::Use_mod[:item_categories] && @last_group_2 != @tid_category.category[@tid_category.index]
#~       @item_window.refresh
#~       @last_group_2 = @tid_category.category[@tid_category.index]
#~       @item_window.index = [@item_window.index,@item_window.item_max-1].min
#~       return
#~     end
#~     super
#~     return unless $imported["Tidloc-CustomEquip"] && Tidloc::CustomEquip::Use_New_Info_item
#~     if    Input.trigger?(:B)
#~       @status_window.oy = 0
#~     elsif Input.press?(Tidloc::Keys["Scroll-"])
#~       @help_window.oy = [[@help_window.oy+5,@help_window.contents_height-Graphics.height].min,0].max unless @help_window.item.is_a?(RPG::Item)
#~     elsif Input.press?(Tidloc::Keys["Scroll+"])
#~       @help_window.oy = [@help_window.oy-5,0].max unless @help_window.item.is_a?(RPG::Item)
#~     end
#~     @help_window.oy = 0 if @help_window.item.is_a?(RPG::Item)
#~   end
#~   
#~   
#~   def on_category_ok
#~     if Tidloc::Use_mod[:item_categories] && @category_window.index == 0
#~       @category_window.hide.deactivate
#~       @tid_category.show.make_category
#~       @tid_category.index = 0
#~     elsif $imported["Tidloc-CustomEquip"] && Tidloc::CustomEquip::Use_Item_Group && (@category_window.index == 1 || @category_window.index == 2)
#~       @category_window.hide.deactivate
#~       @cat_window.show.make_groups @category_window.current_symbol
#~       @cat_window.index = 0
#~     end
#~     @item_window.refresh
#~     @item_window.activate.index = 0
#~   end
#~   def on_item_cancel
#~     @item_window.deactivate.index = -1
#~     if Tidloc::Use_mod[:item_categories] && @category_window.index == 0
#~       @tid_category.hide.index = 0
#~     elsif $imported["Tidloc-CustomEquip"] && Tidloc::CustomEquip::Use_Item_Group && (@category_window.index == 1 || @category_window.index == 2)
#~       @cat_window.hide.index = 0
#~       @cat_window.ox         = 0
#~       @cat_window.update
#~     end
#~     @category_window.show.activate
#~     @item_window.refresh
#~   end
#~ end
################################################################################
#                                                                              #
################################################################################

#~ class Scene_Equip < Scene_MenuBase
#~   attr_accessor :last_group
#~   alias wo_tidloc_start start
#~   def start
#~     wo_tidloc_start
#~     create_cat_window  if $imported["Tidloc-CustomEquip"] && Tidloc::CustomEquip::Use_Item_Group
#~     create_tid_help    if Tidloc::Keys["Help"]
#~   end
#~   def create_cat_window
#~     @cat_window = Tidloc::CustomEquip::Group_Window_Small.new(@item_window.x,@item_window.y,@item_window.width,64)
#~     @cat_window.show.deactivate.opacity = 0
#~     @cat_window.actor = @actor
#~     @cat_window.index = 0
#~     @cat_window.z     = 2000
#~     @item_window.cat_window = @cat_window
#~   end
#~   def create_tid_help
#~     @tidhelp_window = Tidloc::Window_Tid_Help.new
#~     text  = eval(Tidloc::Help["Cat+"])+": "+Tidloc::Vocabs.Header("Cat+2",$tidloc_language)+"\n"
#~     text += eval(Tidloc::Help["Cat-"])+": "+Tidloc::Vocabs.Header("Cat-2",$tidloc_language)+"\n"
#~     text += "<line>"
#~     text += eval(Tidloc::Help["Scroll_U"])+": "+Tidloc::Vocabs.Header("Scroll+2",$tidloc_language)+"\n"
#~     text += eval(Tidloc::Help["Scroll_D"])+": "+Tidloc::Vocabs.Header("Scroll-2",$tidloc_language)+"\n"
#~     @tidhelp_window.text = text
#~   end
#~   alias wo_tidloc_create_status_window create_status_window
#~   def create_status_window
#~     if $imported["Tidloc-CustomEquip"] && Tidloc::CustomEquip::Use_New_Info_equip
#~       @status_window = @help_window
#~       @status_window.actor = @actor
#~     else
#~       wo_tidloc_create_status_window
#~     end
#~   end
#~   def create_help_window
#~     if $imported["Tidloc-CustomEquip"] && Tidloc::CustomEquip::Use_New_Info_equip
#~       @help_window = Tidloc::CustomEquip::Window_ShopStatus2.new(0, 0, Graphics.width/2, Graphics.height)
#~       @help_window.scene = :equip
#~       @help_window.z = 2000
#~       @help_window.viewport = @viewport
#~     else
#~       super
#~     end
#~   end
#~   alias wo_tidloc_create_item_window create_item_window
#~   def create_item_window
#~     if $imported["Tidloc-CustomEquip"] && Tidloc::CustomEquip::Use_New_Info_equip
#~       wx = @help_window.width
#~       wy = @slot_window.y + @slot_window.height
#~       ww = Graphics.width - wx
#~       wh = Graphics.height - wy
#~       @item_window = Window_EquipItem.new(wx, wy, ww, wh)
#~       @item_window.viewport = @viewport
#~       @item_window.help_window = @help_window
#~       @item_window.status_window = @status_window
#~       @item_window.actor = @actor
#~       @item_window.set_handler(:ok,     method(:on_item_ok))
#~       @item_window.set_handler(:cancel, method(:on_item_cancel))
#~       @slot_window.item_window = @item_window
#~     else
#~       wo_tidloc_create_item_window
#~     end
#~   end
#~   alias wo_group_slot_ok on_slot_ok
#~   def on_slot_ok
#~     wo_group_slot_ok
#~     return unless $imported["Tidloc-CustomEquip"] && Tidloc::CustomEquip::Use_Item_Group
#~     @cat_window.index = 0
#~     @cat_window.make_groups @item_window.slot_item
#~   end
#~   alias wo_group_item_cancel on_item_cancel
#~   def on_item_cancel
#~     wo_group_item_cancel
#~     @cat_window.index = 0 if $imported["Tidloc-CustomEquip"] && Tidloc::CustomEquip::Use_Item_Group
#~   end
#~   alias wo_group_item_ok on_item_ok
#~   def on_item_ok
#~     wo_group_item_ok
#~     @cat_window.index = 0 if $imported["Tidloc-CustomEquip"] && Tidloc::CustomEquip::Use_Item_Group
#~   end
#~   def update_all_windows
#~     if @tidhelp_window && @tidhelp_window.active
#~       if Input.trigger?(:C) || Input.trigger?(:B)
#~         @tidhelp_window.hide.deactivate
#~       elsif Input.press?(Tidloc::Keys["Scroll+"])
#~         @tidhelp_window.scroll_up
#~         @tidhelp_window.update
#~       elsif Input.press?(Tidloc::Keys["Scroll-"])
#~         @tidhelp_window.scroll_down
#~         @tidhelp_window.update
#~       end
#~       return
#~     end
#~     if Tidloc::Keys["Help"] && Input.trigger?(Tidloc::Keys["Help"])
#~       @tidhelp_window.show.activate
#~     end
#~     if $imported["Tidloc-CustomEquip"] && Tidloc::CustomEquip::Use_Item_Group && @item_window.active
#~       if    Input.trigger?(Tidloc::Keys["Cat-"])
#~         @cat_window.index -= 1
#~         @cat_window.index  = @cat_window.group.size - 1 if @cat_window.index < 0
#~         Sound.play_cursor
#~       elsif Input.trigger?(Tidloc::Keys["Cat+"])
#~         @cat_window.index += 1
#~         @cat_window.index  = 0 if @cat_window.index >= @cat_window.group.size
#~         Sound.play_cursor
#~       end
#~     end
#~     if $imported["Tidloc-CustomEquip"] && Tidloc::CustomEquip::Use_Item_Group && @last_group != @cat_window.group[@cat_window.index]
#~       @item_window.refresh
#~       @cat_window.refresh
#~       @last_group = @cat_window.group[@cat_window.index]
#~       @item_window.index = [@item_window.index,@item_window.item_max-1].min
#~       return
#~     end
#~     super
#~     return unless $imported["Tidloc-CustomEquip"] && Tidloc::CustomEquip::Use_New_Info_equip
#~     if Input.press?(:R) && (@slot_window.active || @item_window.active)
#~       @help_window.oy = [@help_window.oy+5,@status_window.contents_height-Graphics.height].min unless @help_window.item.is_a?(RPG::Item)
#~     elsif Input.press?(:L) && (@slot_window.active || @item_window.active)
#~       @help_window.oy = [@help_window.oy-5,0].max unless @help_window.item.is_a?(RPG::Item)
#~     end
#~     @help_window.oy = 0 if @help_window.item.is_a?(RPG::Item)
#~   end
#~ end
################################################################################
#                                                                              #
################################################################################

#~ class Scene_Shop < Scene_MenuBase
#~   alias wo_group_start start
#~   def start
#~     wo_group_start
#~     create_cat_window   if $imported["Tidloc-CustomEquip"] && Tidloc::CustomEquip::Use_Item_Group
#~     create_tid_category if Tidloc::Use_mod[:item_categories]
#~     create_tid_help     if Tidloc::Keys["Help"]
#~     @last_group = -1
#~     @last_group_2 = -1
#~   end
#~   
#~   def create_tid_help
#~     @tidhelp_window = Tidloc::Window_Tid_Help.new
#~     text  = "<space=50>Changing Categories:\n"
#~     text += eval(Tidloc::Help["Cat+"])+": "+Tidloc::Vocabs.Header("Cat+2",$tidloc_language)+"\n"
#~     text += eval(Tidloc::Help["Cat-"])+": "+Tidloc::Vocabs.Header("Cat-2",$tidloc_language)+"\n"
#~     @tidhelp_window.text = text
#~   end
#~   def create_tid_category
#~     @tid_category = Tidloc::Header::Category_Window.new
#~     @tid_category.y = @category_window.y
#~     @sell_window.tid_category = @tid_category
#~   end
#~   def create_cat_window
#~     @cat_window = Tidloc::CustomEquip::Group_Window.new
#~     @cat_window.y = @category_window.y
#~     @cat_window.hide.deactivate.index = 0
#~     @sell_window.cat_window = @cat_window
#~   end
#~   def update_all_windows
#~     if @tidhelp_window && @tidhelp_window.active
#~       if Input.trigger?(:C) || Input.trigger?(:B)
#~         @tidhelp_window.hide.deactivate
#~       elsif Input.press?(Tidloc::Keys["Scroll+"])
#~         @tidhelp_window.scroll_up
#~         @tidhelp_window.update
#~       elsif Input.press?(Tidloc::Keys["Scroll-"])
#~         @tidhelp_window.scroll_down
#~         @tidhelp_window.update
#~       end
#~       return
#~     end
#~     if Input.trigger?(Tidloc::Keys["Help"])
#~       @tidhelp_window.show.activate
#~     end
#~     if $imported["Tidloc-CustomEquip"] && Tidloc::CustomEquip::Use_Item_Group && @sell_window.active && (@category_window.index == 1 || @category_window.index == 2)
#~       if    Input.trigger?(Tidloc::Keys["Cat-"])
#~         @cat_window.index -= 1
#~         @cat_window.index  = @cat_window.group.size - 1 if @cat_window.index < 0
#~         Sound.play_cursor
#~         @sell_window.refresh
#~         @sell_window.index = 0 if @sell_window.index < 0 && @sell_window.item_max > 0
#~       elsif Input.trigger?(Tidloc::Keys["Cat+"])
#~         @cat_window.index += 1
#~         @cat_window.index  = 0 if @cat_window.index >= @cat_window.group.size
#~         Sound.play_cursor
#~         @sell_window.refresh
#~         @sell_window.index = 0 if @sell_window.index < 0 && @sell_window.item_max > 0
#~       end
#~     end
#~     if $imported["Tidloc-CustomEquip"] && Tidloc::CustomEquip::Use_Item_Group && @last_group != @cat_window.group[@cat_window.index]
#~       @last_group = @cat_window.group[@cat_window.index]
#~       @sell_window.refresh
#~       @cat_window.refresh
#~       @sell_window.index = [@sell_window.index,@sell_window.item_max-1].min
#~       return
#~     end
#~     if Tidloc::Use_mod[:item_categories] && @sell_window.active && @category_window.index == 0
#~       if    Input.trigger?(Tidloc::Keys["Cat-"])
#~         @tid_category.index -= 1
#~         @tid_category.index  = @tid_category.category.size - 1 if @tid_category.index < 0
#~         Sound.play_cursor
#~         @sell_window.refresh
#~         @sell_window.index=0 if @sell_window.index < 0 && @item_window.item_max>0
#~       elsif Input.trigger?(Tidloc::Keys["Cat+"])
#~         @tid_category.index += 1
#~         @tid_category.index  = 0 if @tid_category.index >= @tid_category.category.size
#~         Sound.play_cursor
#~         @sell_window.refresh
#~         @sell_window.index=0 if @sell_window.index < 0 && @item_window.item_max>0
#~       end
#~     end
#~     if Tidloc::Use_mod[:item_categories] && @last_group_2 != @tid_category.category[@tid_category.index] && @category_window.index == 0
#~       @sell_window.refresh
#~       @last_group_2 = @tid_category.category[@tid_category.index]
#~       @sell_window.index = [@sell_window.index,@sell_window.item_max-1].min
#~       return
#~     end
#~     super
#~     if $imported["Tidloc-CustomEquip"] && Tidloc::CustomEquip::Use_New_Info_shop && $imported["Tidloc-D-Shop"] && (@buy_window.active || @special_window.active)
#~       if    Input.trigger?(:C) || Input.trigger?(:B)
#~         @status_window.oy = 0
#~       elsif Input.press?(:R)
#~         @status_window.oy = [@status_window.oy+5,@status_window.contents_height-Graphics.height].min unless @status_window.item.is_a?(RPG::Item)
#~       elsif Input.press?(:L)
#~         @status_window.oy = [@status_window.oy-5,0].max unless @status_window.item.is_a?(RPG::Item)
#~       end
#~       @status_window.oy = 0 if @status_window.item.nil? || @status_window.item.is_a?(RPG::Item)
#~     end
#~   end
#~   alias wo_group_cat_ok on_category_ok
#~   def on_category_ok
#~     wo_group_cat_ok
#~     if Tidloc::Use_mod[:item_categories] && @category_window.index == 0
#~       @category_window.deactivate.hide
#~       @tid_category.show.index = 0
#~       @tid_category.make_category
#~     elsif $imported["Tidloc-CustomEquip"] && (@category_window.index == 1 || @category_window.index == 2)
#~       @category_window.deactivate.hide
#~       @cat_window.show.index = 0
#~       @cat_window.make_groups @category_window.current_symbol
#~     end
#~   end
#~   alias wo_group_sell_cancel on_sell_cancel
#~   def on_sell_cancel
#~     wo_group_sell_cancel
#~     if Tidloc::Use_mod[:item_categories] && @category_window.index == 0
#~       @tid_category.hide.index = 0
#~     elsif $imported["Tidloc-CustomEquip"] && (@category_window.index == 1 || @category_window.index == 2)
#~       @cat_window.hide.index = 0
#~     end
#~     @category_window.activate.show
#~   end
#~ end


################################################################################
#                                                                              #
################################################################################

#~ class Game_System
#~   attr_accessor :questlog
#~   attr_accessor :tidloc_talk
#~   attr_accessor :tidloc_dshop
#~   attr_accessor :tidloc_dshop_time
#~   attr_accessor :_tidloc_singleequip_w
#~   attr_accessor :_tidloc_singleequip_a
#~   attr_accessor :_tidloc_alchemy
#~   attr_accessor :_tidloc_smith
#~   attr_accessor :tidloc_alch
#~   attr_accessor :tidloc_smith
#~   attr_accessor :tidloc_message_time_1
#~   attr_accessor :tidloc_message_time_2
#~   attr_accessor :tidloc_message_time_3
#~   attr_accessor :tidloc_clock_time
#~   attr_accessor :tidloc_clock_time_2
#~   attr_accessor :tidloc_skills_count
#~   alias wo_questlog_init initialize
#~   def initialize
#~     wo_questlog_init
#~     self.tidloc_talk = {}
#~     self.questlog = Questlog.new    if $imported["Tidloc-Questlog"]
#~     self.tidloc_dshop          = [] if $imported["Tidloc-D-Shop"]
#~     self._tidloc_singleequip_w = 0  if self._tidloc_singleequip_w.nil?
#~     self._tidloc_singleequip_a = 0  if self._tidloc_singleequip_a.nil?
#~     if $imported["Tidloc-Smith"]
#~       self.tidloc_smith = Tidloc::Smith::Blacksmith.new
#~       self._tidloc_smith = Tidloc_Smith.load_smith_data
#~     end
#~     if $imported["Tidloc-Alchemy"]
#~       self.tidloc_alch  = Tidloc::Alchemy::Alchemist.new
#~       self._tidloc_alchemy = Tidloc_Alch.load_alch_data
#~     end
#~     self.tidloc_message_time_1 = -1
#~     self.tidloc_message_time_2 = -1
#~     self.tidloc_message_time_3 = -1
#~     self.tidloc_clock_time     = -1
#~     self.tidloc_clock_time_2   = -1
#~     self.tidloc_skills_count   =  0 if $imported["Tidloc-CustomSkills"]
#~   end
#~ end
################################################################################
#                                                                              #
################################################################################

class Game_Temp
  attr_accessor :tidloc
  attr_accessor :_tidloc_itemclass
  attr_accessor :_tidloc_runes
  attr_accessor :_tidloc_runes_maxlvl
  attr_accessor :_tidloc_itemvalues
  attr_accessor :_tidloc_auctions
  attr_accessor :_tidloc_message_big
  attr_accessor :_tidloc_message_small
  attr_accessor :_tidloc_message_quest
  attr_accessor :_tidloc_message_history
  attr_accessor :_tidloc_auction_redeem
  attr_accessor :_tidloc_auction_possible
  attr_accessor :_tidloc_auction_rarity
  attr_accessor :_tidloc_auction_flood
  attr_accessor :_tidloc_auction_itemcount
  attr_accessor :_tidloc_equipalt
  attr_accessor :_tidloc_addstats
  attr_accessor :_tidloc_new_ench_lvl
  attr_accessor :_tidloc_new_socket_lvl
  attr_accessor :_tidloc_diablo_pretags
  attr_accessor :_tidloc_diablo_postags
  attr_accessor :_tidloc_diablo_special
  attr_accessor :_tidloc_item_used
  attr_accessor :_tidloc_sockets_database
  attr_accessor :_tidloc_clock_step
  attr_accessor :tidloc_auction_time

  alias wo_tidloc_initialize initialize
  def initialize
    wo_tidloc_initialize
    self.tidloc = {}
    if self._tidloc_runes.nil? && $imported["Tidloc-Runes"]
      self._tidloc_runes = Tidloc::Rune::Scan()
      self._tidloc_runes_maxlvl= Tidloc::Rune::Maxlvlstart
    end
    if $imported["Tidloc-DiabloEquip"]
      self._tidloc_diablo_pretags = Tidloc::CustomEquip.load_Tags(0) if self._tidloc_diablo_pretags.nil?
      self._tidloc_diablo_postags = Tidloc::CustomEquip.load_Tags(1) if self._tidloc_diablo_postags.nil?
      self._tidloc_diablo_special = Tidloc::CustomEquip.load_Tags(2) if self._tidloc_diablo_special.nil?
    end
    if $imported["Tidloc-SocketInsert"]
      self._tidloc_sockets_database = Tidloc::CustomEquip::Sockets.database
    end
    self._tidloc_auctions = []           if self._tidloc_auctions.nil? && $imported["Tidloc-Auction"]
    self._tidloc_auction_redeem = [0,[]] if self._tidloc_auction_redeem.nil? && $imported["Tidloc-Auction"]
    self._tidloc_auction_possible = []   if self._tidloc_auction_possible.nil? && $imported["Tidloc-Auction"]
    self._tidloc_auction_rarity = []     if self._tidloc_auction_rarity.nil? && $imported["Tidloc-Auction"]
    self._tidloc_auction_flood = []      if self._tidloc_auction_flood.nil? && $imported["Tidloc-Auction"]
    self._tidloc_auction_itemcount = []  if self._tidloc_auction_itemcount.nil? && $imported["Tidloc-Auction"]
    self._tidloc_equipalt = []           if self._tidloc_equipalt.nil? && $imported["Tidloc-AddStats"]
    self._tidloc_addstats = []           if self._tidloc_addstats.nil? && $imported["Tidloc-AddStats"]
    self._tidloc_message_big = []        if self._tidloc_message_big.nil?
    self._tidloc_message_small = []      if self._tidloc_message_small.nil?
    self._tidloc_message_quest = []      if self._tidloc_message_quest.nil?
    self._tidloc_message_history = []    if self._tidloc_message_history.nil?
    self._tidloc_new_ench_lvl = 0        if self._tidloc_new_ench_lvl.nil?
    self._tidloc_new_socket_lvl = 0      if self._tidloc_new_socket_lvl.nil?
    self._tidloc_diablo_pretags = []     if self._tidloc_diablo_pretags.nil?
    self._tidloc_diablo_postags = []     if self._tidloc_diablo_postags.nil?
    self._tidloc_diablo_special = []     if self._tidloc_diablo_special.nil?
    self._tidloc_sockets_database = []   if self._tidloc_sockets_database.nil?
    self._tidloc_item_used = []          if self._tidloc_item_used.nil?
    self._tidloc_clock_step = 0          if self._tidloc_clock_step.nil?
    scan_items
  end
end

################################################################################
#                                                                              #
################################################################################

#~ class Window_Selectable_old < Window_Base

#~   attr_reader   :index
#~   attr_reader   :help_window

#~   def initialize(x, y, width, height, klein = 0)
#~     super(x, y, width, height)
#~     @item_max = 1
#~     @column_max = 1
#~     @index = -1
#~     @counter = 5
#~     @klein = klein
#~   end

#~   def index=(index)
#~     @index = index
#~     if self.active and @help_window != nil
#~       update_help
#~     end
#~     update_cursor_rect
#~   end
#~   
#~   
#~   def row_max
#~     return (@item_max + @column_max - 1) / @column_max
#~   end

#~   def top_row
#~     return self.oy / 32
#~   end
#~         
#~   def top_row=(row)
#~     if row < 0
#~       row = 0
#~     end
#~     if row > row_max
#~       row = row_max
#~     end
#~     if @klein == 0
#~       self.oy = row * 32
#~     else
#~       self.oy = row * 24
#~     end
#~   end

#~   def page_row_max
#~     if @klein == 0
#~       return (self.height - 32) / 32
#~     else
#~       return (self.height - 32) / 24
#~     end
#~   end

#~   def page_item_max
#~     return page_row_max * @column_max
#~   end

#~   def help_window=(help_window)
#~     @help_window = help_window
#~     if self.active and @help_window != nil
#~       update_help
#~     end
#~   end

#~   def update_cursor_rect
#~     if @index < 0
#~       self.cursor_rect.empty
#~       return
#~     end
#~     row = @index / @column_max
#~     if row < self.top_row
#~       self.top_row = row
#~     end
#~     if row > self.top_row + (self.page_row_max - 1)
#~       self.top_row = row - (self.page_row_max - 1)
#~     end
#~     cursor_width = self.width / @column_max - 32
#~     x = @index % @column_max * (cursor_width + 32)
#~     if @klein == 0
#~       y = @index / @column_max * 32
#~       if SceneManager.scene.is_a?(Scene_Title)
#~         cursor_width = 32
#~         x = @index % @column_max * (cursor_width + 32)
#~         if (@counter % 80) < 40
#~           y = y + 5 + (((@counter % 40) - 20) * 0.5)
#~         else
#~           y = y + 5 - (((@counter % 40) - 20) * 0.5)
#~         end
#~         if ((@counter ) % 80) < 10
#~           x = x - 5 + ((((@counter ) % 80)) * 0.5)
#~         elsif ((@counter ) % 80) < 20
#~           x = x - ((((@counter ) % 80) - 10) * 0.5)
#~         elsif ((@counter ) % 80) < 30
#~           x = x - 5 + ((((@counter ) % 80) - 20) * 0.5)
#~         elsif ((@counter ) % 80) < 60
#~           x = x - ((((@counter ) % 80) - 30) * 0.5)
#~         else #((@counter ) % 80) < 10
#~           x = x - 15 + ((((@counter ) % 80) - 60) * 0.5)
#~         end
#~         @counter = @counter + 1
#~       elsif @finger != 0
#~         cursor_width = 32
#~         if (@counter % 80) < 40
#~           x = x #- (((@counter/4) % 20) - 10)
#~           y = y - ((@counter % 40) / 4) + 5
#~         else
#~           x = x #+ (((@counter/4) % 20) - 10)
#~           y = y + ((@counter % 40) / 4) - 5
#~         end
#~         @counter += 1
#~       else
#~         if (@counter % 80) < 40
#~           y = y - 10 - (((@counter % 20) - 20) * 0.5)
#~         else
#~           y = y - 10 + (((@counter % 20) - 20) * 0.5)
#~         end
#~         @counter = @counter + 1
#~       end
#~       self.cursor_rect.set(x, y, self.width-32, 24)
#~     else
#~       y = @index / @column_max * 24 - self.oy
#~       if (@counter % 80) < 40
#~         y = y - 10 - (((@counter % 40) - 20) * 0.5)
#~       else
#~         y = y - 10 + (((@counter % 40) - 20) * 0.5)
#~       end
#~       @counter = @counter + 1
#~       self.cursor_rect.set(x, y, cursor_width, 24)
#~     end
#~   end

#~   def update
#~     super
#~     if self.active and @item_max > 0 and @index >= 0
#~       if Input.repeat?(Input::DOWN)
#~         if SceneManager.scene.is_a?(Scene_Title) && @title_dis == 1
#~           @index = @index % 2 + 1
#~         elsif (@column_max == 1 and Input.trigger?(Input::DOWN)) or
#~            @index < @item_max - @column_max
#~           Sound.play_cursor
#~           @index = (@index + @column_max) % @item_max
#~         end
#~         if SceneManager.scene.is_a?(Scene_Title) && @con == 1 && @index == 0
#~           @index = 1
#~         end
#~         if (SceneManager.scene.is_a?(Scene_Menu) && !$game_switches.[](33) && @index == 4) || (SceneManager.scene.is_a?(Scene_Menu) && !$game_switches.[](34) && @index == 5)
#~           @index = 6
#~         end
#~       end
#~       if Input.repeat?(Input::UP)
#~         if SceneManager.scene.is_a?(Scene_Title) && @title_dis == 1
#~           @index = @index % 2 + 1
#~         elsif (@column_max == 1 and Input.trigger?(Input::UP)) or
#~            @index >= @column_max
#~           Sound.play_cursor
#~           @index = (@index - @column_max + @item_max) % @item_max
#~         end
#~         if SceneManager.scene.is_a?(Scene_Title) && @con == 1 && @index == 0
#~           @index = 2
#~         end
#~         if SceneManager.scene.is_a?(Scene_Title) && @con == 1 && @index == 1 && @title_dis == 1
#~           @index = 2
#~         end
#~       end
#~       if Input.repeat?(Input::RIGHT)
#~         if @column_max >= 2 and @index < @item_max - 1
#~           Sound.play_cursor
#~           @index += 1
#~         end
#~       end
#~       if Input.repeat?(Input::LEFT)
#~         if @column_max >= 2 and @index > 0
#~           Sound.play_cursor
#~           @index -= 1
#~         end
#~       end
#~       if Input.repeat?(Input::R)
#~         if self.top_row + (self.page_row_max - 1) < (self.row_max - 1)
#~           Sound.play_cursor
#~           @index = [@index + self.page_item_max, @item_max - 1].min
#~           self.top_row += self.page_row_max
#~         end
#~       end
#~       if Input.repeat?(Input::L)
#~         if self.top_row > 0
#~           Sound.play_cursor
#~           @index = [@index - self.page_item_max, 0].max
#~           self.top_row -= self.page_row_max
#~         end
#~       end
#~     end
#~     if self.active and @help_window != nil
#~       update_help
#~     end
#~     update_cursor_rect
#~   end
#~ end
################################################################################
#                                                                              #
################################################################################

#~ class Window_Item_old < Window_Selectable_old

#~   attr_reader   :klein
#~   attr_accessor :_active_class

#~   def initialize(klein = 0, finger = 0, _class = 0)
#~     self._active_class = _class
#~     @klein=klein
#~     @finger = finger
#~     super(0, 64, Graphics.width, Graphics.height-64)
#~     @column_max = 1
#~     refresh
#~     self.index = 0
#~     @title = 1
#~   end
#~   def item
#~     return @data[self.index]
#~   end
#~   def refresh
#~     if self.contents != nil
#~       self.contents.dispose
#~       self.contents = nil
#~     end
#~     @data = []
#~     for i in 1...$data_items.size
#~       if $game_party.item_number($data_items[i]) > 0
#~         @data.push($data_items[i])
#~       end
#~     end
#~     if $imported["Tidloc-CustomEquip"]
#~       @data += $game_party.equip_items
#~     else      
#~       for i in 1...$data_weapons.size
#~         if $game_party.item_number($data_weapons[i]) > 0
#~           @data.push($data_weapons[i])
#~         end
#~       end
#~       for i in 1...$data_armors.size
#~         if $game_party.item_number($data_armors[i]) > 0
#~           @data.push($data_armors[i])
#~         end
#~       end
#~     end
#~     
#~     @item_max = @data.size
#~     if @item_max > 0
#~       self.contents = Bitmap.new(width - 32, row_max * 32)
#~       for i in 0...@item_max
#~         draw_item(i)
#~       end
#~     end
#~   end
#~   def draw_item(index)
#~     item = @data[index]
#~     number = $game_party.item_number(item)
#~     if item.is_a?(RPG::Item) and $game_party.usable?(item)
#~       self.contents.font.color = normal_color
#~     else
#~       self.contents.font.color = Color.new(128, 128, 128, 255)
#~     end
#~     x = 4
#~     y = index * 32
#~     rect = Rect.new(x, y, self.width / @column_max - 32, 32)
#~     self.contents.fill_rect(rect, Color.new(0, 0, 0, 0))
#~     bitmap = Cache.system("Iconset")
#~     opacity = self.contents.font.color == normal_color ? 255 : 128
#~     self.contents.blt(x+32, y + 4, bitmap, Rect.new(0, 0, 24, 24), opacity)
#~     self.contents.draw_text(x + 60, y, 180, 32, item.name, 0)
#~     self.contents.draw_text(x + 400, y, 16, 32, ":", 1)
#~     self.contents.draw_text(x + 416, y, 24, 32, number.to_s, 2)
#~   end
#~   def update_help
#~     @help_window.set_text(self.item == nil ? "" : self.item.description)
#~   end
#~ end
################################################################################
#                                                                              #
################################################################################

#~ class Window_Command2 < Window_Selectable_old

#~   attr_reader :title

#~   def initialize(width, commands, klein = 0, finger = 0, title = 0, items = 0)
#~     @klein = klein
#~     @finger = finger
#~     @title = title
#~     @items = items
#~     @title_dis = 0
#~     width-=2
#~     if @klein == 0
#~       super(0, 0, width, commands.size * 32 + 32)
#~     elsif @klein == 2
#~       super(0, 0, width, commands.size * 25 + 26, 1)
#~     elsif @klein == 3
#~       super(0, 0, width, commands.size * 25 + 32)
#~     elsif @items == 1
#~       super(0, 0, width, 210, 1)
#~     else
#~       super(0, 0, width, commands.size * 25 + 25)
#~     end
#~     @item_max = commands.size
#~     @commands = commands
#~     if @klein == 0 || @klein == 3
#~       self.contents = Bitmap.new(width - 32, @item_max * 32)
#~     else
#~       self.contents = Bitmap.new(width - 32, @item_max * 25)
#~     end
#~     if klein == 0
#~       self.contents.font.size = 22
#~     else
#~       self.contents.font.size = 20
#~     end
#~     refresh
#~     self.index = 0
#~   end

#~   def refresh
#~     self.contents.clear
#~     if @items == 1
#~       @commands = []
#~       @command = []
#~       @item_max = 0
#~       for i in 0...17
#~         if $game_party.item_number(i+45) > 0
#~           @command.push($data_items[i+45])
#~           @item_max = @item_max + 1
#~         end
#~       end
#~       for i in 0...@item_max
#~         item = @command[i]
#~         number = $game_party.item_number(item.id)
#~         if number < 10
#~           @commands[i] = "0" + number.to_s + "* " + item.name
#~         else
#~           @commands[i] = number.to_s + "* " + item.name
#~         end
#~       end
#~       #@item_max = @item_max - 1
#~     elsif @items == 2
#~       @commands = []
#~       @command = []
#~       @item_max = 0
#~       for i in 0...25
#~         if $game_party.item_number(i+81) > 0
#~           @command.push($data_items[i+81])
#~           @item_max = @item_max + 1
#~         end
#~       end
#~       for i in 0...@item_max
#~         item = @command[i]
#~         number = $game_party.item_number(item.id)
#~         if number < 10
#~           @commands[i] = "0" + number.to_s + "* " + item.name
#~         else
#~           @commands[i] = number.to_s + "* " + item.name
#~         end
#~       end
#~       #@item_max = @item_max - 1
#~     end
#~     for i in 0...@item_max
#~       if title == 0
#~         draw_item(i, normal_color)
#~       else
#~         draw_item(i, knockout_color)
#~       end
#~     end
#~   end

#~   def draw_item(index, color)
#~     self.contents.font.color = color
#~     if @klein != 0 || width == 180 || @items != 0
#~       rect = Rect.new(4, 24 * index, self.contents.width - 8, 24)
#~     else
#~       rect = Rect.new(4, 32 * index, self.contents.width - 8, 32)
#~     end
#~     self.contents.fill_rect(rect, Color.new(0, 0, 0, 0))
#~     self.contents.draw_text(rect, @commands[index])
#~   end

#~   def returnid(index)
#~     return @command[index]
#~   end

#~   def disable_item(index)
#~     @title_dis = 1
#~     draw_item(index, Color.new(255, 255, 255, 128))
#~   end
#~ end
################################################################################
#                                                                              #
################################################################################

#~ class Window_Command3 < Window_Selectable_old

#~   attr_reader :title
#~   attr_reader :item_max
#~   attr_accessor :_usable

#~   def initialize(width, commands, klein = 1, finger = 1, title = 0, items = 1)
#~     @klein = klein
#~     @finger = finger
#~     @title = title
#~     @items = items
#~     @title_dis = 0
#~     @_usable=[]
#~     width-=2
#~     super(0, 0, width, Graphics.height-200, 1)
#~     @item_max = commands.size
#~     @commands = commands
#~     if @item_max!=0
#~       self.contents = Bitmap.new(width - 32, @item_max * 25)
#~     else
#~       self.contents = Bitmap.new(width - 32, 25)
#~     end
#~     self.contents.font.size = 20
#~     refresh
#~     self.index = 0
#~   end

#~   def refresh
#~     self.contents.clear
#~     if @_usable.size < @commands.size
#~       for i in @_usable.size...@commands.size
#~         @_usable.push true
#~       end
#~     end
#~     for i in 0...@item_max
#~       if title == 0
#~         if @_usable[i]
#~           draw_item(i, normal_color)
#~         else
#~           draw_item(i, Color.new(128, 128, 128, 255))
#~         end
#~       else
#~         draw_item(i, knockout_color)
#~       end
#~     end
#~   end
#~   def draw_item(index, color)
#~     self.contents.font.color = color
#~     if @klein != 0 || width == 180 || @items != 0
#~       rect = Rect.new(4, 24 * index, self.contents.width - 8, 24)
#~     else
#~       rect = Rect.new(4, 32 * index, self.contents.width - 8, 32)
#~     end
#~     self.contents.fill_rect(rect, Color.new(0, 0, 0, 0))
#~     self.contents.draw_text(rect, @commands[index]) if @commands[index]
#~   end

#~   def returnid(index)
#~     return @command[index]
#~   end

#~   def disable_item(index)
#~     @title_dis = 1
#~     draw_item(index, Color.new(255, 255, 255, 128))
#~   end
#~ end
################################################################################
#                                                                              #
################################################################################

#~ class Window_ItemCategory_2 < Window_ItemCategory
#~   def make_command_list
#~     add_command(Bitmap.html_decode(Vocab::item),         :item)
#~     add_command(Bitmap.html_decode(Vocab::weapon),     :weapon)
#~     add_command(Bitmap.html_decode(Vocab::armor),       :armor)
#~     add_command(Bitmap.html_decode(Vocab::key_item), :key_item)
#~   end
#~ end

################################################################################
#                                                                              #
################################################################################

#~ class Window_ItemList_2 < Window_ItemList
#~   def include?(item)
#~     return false if item.nil?
#~     if self.cat_window && item.is_a?(Tidloc::CustomEquip::Base) && self.cat_window.index > 0
#~       return false if item.item.name != self.cat_window.group[self.cat_window.index]
#~     end
#~     if self.tid_category && item.is_a?(RPG::Item) && self.tid_category.index >= 0
#~       return false if item.tidloc_class != self.tid_category.category[self.tid_category.index]
#~     end
#~     case @category
#~     when :item
#~       item.is_a?(RPG::Item) && !item.key_item?
#~     when :weapon
#~       if $imported["Tidloc-CustomEquip"]
#~         item.is_a?(Tidloc::CustomEquip::Weapon) && item.inv
#~       else
#~         item.is_a?(RPG::Weapon)
#~       end
#~     when :armor
#~       if $imported["Tidloc-CustomEquip"]
#~         item.is_a?(Tidloc::CustomEquip::Armor) && item.inv
#~       else
#~         item.is_a?(RPG::Armor)
#~       end
#~     when :key_item
#~       item.is_a?(RPG::Item) && item.key_item?
#~     else
#~       false
#~     end
#~   end
#~ end
################################################################################
#                                                                              #
################################################################################

#~ module RPG
#~   class EquipItem
#~     attr_accessor :tidloc_uses
#~     alias wo_tidloc_init initialize
#~     def initialize
#~       self.tidloc_uses = 0
#~       wo_tidloc_init
#~     end
#~     def elemental_rate(id)
#~       return 1 if self.features.nil?
#~       temp = self.features.select {|ele| ele.code == 11 && ele.data_id == id}
#~       return temp[0].value if temp.size > 0
#~       return 1
#~     end
#~     def lb_chance
#~       if self.note =~ Tidloc::Notetags[4][0]
#~         return $1.to_i/100.0
#~       else
#~         return 0
#~       end
#~     end
#~     def lb_def
#~       if self.note =~ Tidloc::Notetags[4][1]
#~         return $1.to_i/100.0
#~       else
#~         return 0
#~       end
#~     end
#~     
#~     def key_item?;   return false; end
#~     def effects;     return [];    end
#~   end
#~   class Skill
#~     def hp_cost
#~       if self.note =~ /<hp-cost (.*)>/i
#~         return $1.to_i
#~       end
#~       return 0
#~     end
#~     def lb_chance
#~       if self.note =~ Tidloc::Notetags[4][0]
#~         return $1.to_i/100.0
#~       else
#~         return 0
#~       end
#~     end
#~     def lb_def
#~       0
#~     end
#~   end
#~   class Item
#~     alias wo_tidloc_for_user? for_user?
#~     def for_user?
#~       return true if $imported["Tidloc-ItemData"] &&
#~                      self.commands.find_all{|c| c[0]=="Use"}.size > 0 &&
#~                      self.commands.find_all{|c| c[0]=="Use"}.find_all{|c|
#~                         c[2]=="Self"}.size > 0
#~       return wo_tidloc_for_user?
#~     end
#~     alias wo_tidloc_for_friend? for_friend?
#~     def for_friend?
#~       return false if self.note =~ /<exe-use: (.*)>/i
#~       return true if $imported["Tidloc-ItemData"] &&
#~                      self.commands.find_all{|c| c[0]=="Use"}.size > 0 &&
#~                      self.commands.find_all{|c| c[0]=="Use"}.find_all{|c|
#~                         c[2]=="Friend"        || c[2]=="All Friends" ||
#~                         c[2]=="Dead Friend"   || c[2]=="All Dead Friends" ||
#~                         c[2]=="Random Friend" || c[2]=="Self"}.size > 0
#~       return wo_tidloc_for_friend?
#~     end
#~     alias wo_tidloc_for_opponent? for_opponent?
#~     def for_opponent?
#~       return true if $imported["Tidloc-ItemData"] &&
#~                      self.commands.find_all{|c| c[0]=="Use"}.size > 0 &&
#~                      self.commands.find_all{|c| c[0]=="Use"}.find_all{|c|
#~                         c[2]=="Enemy" || c[2]=="All Enemies" ||
#~                         c[2]=="Random Enemy"}.size > 0
#~       return wo_tidloc_for_opponent?
#~     end
#~     
#~     alias wo_tidloc_for_dead_friend? for_dead_friend?
#~     def for_dead_friend?
#~       return true if $imported["Tidloc-ItemData"] &&
#~                      self.commands.find_all{|c| c[0]=="Use"}.size > 0 &&
#~                      self.commands.find_all{|c| c[0]=="Use"}.find_all{|c|
#~                         c[2]=="Dead Friend" || c[2]=="All Dead Friends"}.size > 0
#~       return wo_tidloc_for_dead_friend?
#~     end
#~     alias wo_tidloc_for_random? for_random?
#~     def for_random?
#~       return true if $imported["Tidloc-ItemData"] &&
#~                      self.commands.find_all{|c| c[0]=="Use"}.size > 0 &&
#~                      self.commands.find_all{|c| c[0]=="Use"}.find_all{|c|
#~                         c[2]=="Random Friend" || c[2]=="Random Enemy"}.size > 0
#~       return wo_tidloc_for_random?
#~     end
#~     alias wo_tidloc_for_one? for_one?
#~     def for_one?
#~       return true if $imported["Tidloc-ItemData"] &&
#~                      self.commands.find_all{|c| c[0]=="Use"}.size > 0 &&
#~                      self.commands.find_all{|c| c[0]=="Use"}.find_all{|c|
#~                         c[2]=="Friend" || c[2]=="Enemy" ||
#~                         c[2]=="Dead Friend"}.size > 0
#~       return wo_tidloc_for_one?
#~     end
#~     alias wo_tidloc_for_all? for_all?
#~     def for_all?
#~       return true if $imported["Tidloc-ItemData"] &&
#~                      self.commands.find_all{|c| c[0]=="Use"}.size > 0 &&
#~                      self.commands.find_all{|c| c[0]=="Use"}.find_all{|c|
#~                         c[2]=="All Friends" || c[2]=="All Enemies" ||
#~                         c[2]=="All Dead Friends"}.size > 0
#~       return wo_tidloc_for_all?
#~     end
#~     
#~     def lb_chance
#~       if self.note =~ Tidloc::Notetags[4][0]
#~         return $1.to_i/100.0
#~       else
#~         return 0
#~       end
#~     end
#~     def lb_def
#~       0
#~     end
#~   end
#~   
#~   class Weapon
#~     def for_friend?
#~       return false if self.note =~ /<exe-use: (.*)>/i
#~       return true if $imported["Tidloc-WeaponData"] &&
#~                      self.commands.find{|c| c[0]=="Use"} &&
#~                      self.commands.find_all{|c| c[0]=="Use"}.find{|c|
#~                         c[2]=="Friend"        || c[2]=="All Friends" ||
#~                         c[2]=="Dead Friend"   || c[2]=="All Dead Friends" ||
#~                         c[2]=="Random Friend" || c[2]=="Self"}
#~       return false
#~     end
#~     def for_opponent?
#~       return true if $imported["Tidloc-WeaponData"] &&
#~                      self.commands.find{|c| c[0]=="Use"} &&
#~                      self.commands.find_all{|c| c[0]=="Use"}.find{|c|
#~                         c[2]=="Enemy" || c[2]=="All Enemies" ||
#~                         c[2]=="Random Enemy"}
#~       return false
#~     end
#~     
#~     def for_user?
#~       return true if $imported["Tidloc-WeaponData"] &&
#~                      self.commands.find{|c| c[0]=="Use"} &&
#~                      self.commands.find_all{|c| c[0]=="Use"}.find{|c|
#~                         c[2]=="Self"}
#~       return false
#~     end
#~     def for_dead_friend?
#~       return true if $imported["Tidloc-WeaponData"] &&
#~                      self.commands.find{|c| c[0]=="Use"} &&
#~                      self.commands.find_all{|c| c[0]=="Use"}.find{|c|
#~                         c[2]=="Dead Friend" || c[2]=="All Dead Friends"}
#~       return false
#~     end
#~     def for_random?
#~       return true if $imported["Tidloc-WeaponData"] &&
#~                      self.commands.find{|c| c[0]=="Use"} &&
#~                      self.commands.find_all{|c| c[0]=="Use"}.find{|c|
#~                         c[2]=="Random Friend" || c[2]=="Random Enemy"}
#~       return false
#~     end
#~     def for_one?
#~       return true if $imported["Tidloc-WeaponData"] &&
#~                      self.commands.find{|c| c[0]=="Use"} &&
#~                      self.commands.find_all{|c| c[0]=="Use"}.find{|c|
#~                         c[2]=="Friend" || c[2]=="Enemy" ||
#~                         c[2]=="Dead Friend"}
#~       return false
#~     end
#~     def for_all?
#~       return true if $imported["Tidloc-WeaponData"] &&
#~                      self.commands.find{|c| c[0]=="Use"} &&
#~                      self.commands.find_all{|c| c[0]=="Use"}.find{|c|
#~                         c[2]=="All Friends" || c[2]=="All Enemies" ||
#~                         c[2]=="All Dead Friends"}
#~       return false
#~     end
#~   end
#~   
#~   class Armor
#~     def for_user?
#~       return true if $imported["Tidloc-ArmorData"] &&
#~                      self.commands.find{|c| c[0]=="Use"} &&
#~                      self.commands.find_all{|c| c[0]=="Use"}.find{|c|
#~                         c[2]=="Self"}
#~       return false
#~     end
#~     def for_friend?
#~       return false if self.note =~ /<exe-use: (.*)>/i
#~       return true if $imported["Tidloc-ArmorData"] &&
#~                      self.commands.find{|c| c[0]=="Use"} &&
#~                      self.commands.find_all{|c| c[0]=="Use"}.find{|c|
#~                         c[2]=="Friend"        || c[2]=="All Friends" ||
#~                         c[2]=="Dead Friend"   || c[2]=="All Dead Friends" ||
#~                         c[2]=="Random Friend" || c[2]=="Self"}
#~       return false
#~     end
#~     def for_opponent?
#~       return true if $imported["Tidloc-ArmorData"] &&
#~                      self.commands.find{|c| c[0]=="Use"} &&
#~                      self.commands.find_all{|c| c[0]=="Use"}.find{|c|
#~                         c[2]=="Enemy" || c[2]=="All Enemies" ||
#~                         c[2]=="Random Enemy"}
#~       return false
#~     end
#~     
#~     def for_dead_friend?
#~       return true if $imported["Tidloc-ArmorData"] &&
#~                      self.commands.find{|c| c[0]=="Use"} &&
#~                      self.commands.find_all{|c| c[0]=="Use"}.find{|c|
#~                         c[2]=="Dead Friend" || c[2]=="All Dead Friends"}
#~       return false
#~     end
#~     def for_random?
#~       return true if $imported["Tidloc-ArmorData"] &&
#~                      self.commands.find{|c| c[0]=="Use"} &&
#~                      self.commands.find_all{|c| c[0]=="Use"}.find{|c|
#~                         c[2]=="Random Friend" || c[2]=="Random Enemy"}
#~       return false
#~     end
#~     def for_one?
#~       return true if $imported["Tidloc-ArmorData"] &&
#~                      self.commands.find{|c| c[0]=="Use"} &&
#~                      self.commands.find_all{|c| c[0]=="Use"}.find{|c|
#~                         c[2]=="Friend" || c[2]=="Enemy" ||
#~                         c[2]=="Dead Friend"}
#~       return false
#~     end
#~     def for_all?
#~       return true if $imported["Tidloc-ArmorData"] &&
#~                      self.commands.find{|c| c[0]=="Use"} &&
#~                      self.commands.find_all{|c| c[0]=="Use"}.find{|c|
#~                         c[2]=="All Friends" || c[2]=="All Enemies" ||
#~                         c[2]=="All Dead Friends"}
#~       return false
#~     end
#~   end
#~ end
################################################################################
#                                                                              #
################################################################################

#~ class Scene_Battle
#~   alias wo_tidloc_use_item use_item
#~   def use_item
#~     wo_tidloc_use_item
#~     item = @subject.current_action.item if @subject.current_action
#~     item.uses += 1 if $imported["Tidloc-CustomSkills"] && item.is_a?(Tidloc::CustomSkills::Base)
#~   end
#~ end
################################################################################
#                                                                              #
################################################################################

#~ class Game_Battler < Game_BattlerBase
#~   alias wo_tidloc_battler_die die
#~   def die
#~     wo_tidloc_battler_die
#~     $game_temp.tidloc[:target] = self
#~     tidloc_exe_command("Die")
#~   end
#~   alias wo_tidloc_use_item use_item
#~   def use_item(item)
#~     if item.note =~ /<exe-use: (.*)>/i
#~       $game_temp.tidloc[:item]  = item
#~       $game_temp.tidloc[:user]  = self
#~       $game_temp.tidloc[:actor] = self
#~       consume_item(item)
#~     else
#~       if $imported["Tidloc-CustomSkills"] && item.is_a?(Tidloc::CustomSkills::Base)
#~         pay_skill_cost(item) 
#~         item.uses += 1
#~       end
#~       wo_tidloc_use_item(item)
#~     end
#~   end
#~   alias wo_tidloc_consume consume_item
#~   def consume_item(item)
#~     $game_temp.tidloc[:user]  = self
#~     $game_temp.tidloc[:actor] = self
#~     wo_tidloc_consume(item)
#~   end
#~ #  alias wo_tidloc_item_test item_test
#~   def item_test(user, item)
#~     return false if item.for_dead_friend? != dead?
#~     return true if $game_party.in_battle
#~     return true if item.for_opponent?
#~     if $imported["Tidloc-PassiveSkills"] && item.damage
#~       return true if item.damage.recover? && item.damage.to_hp? && hp < mhp-hp_reserved
#~       return true if item.damage.recover? && item.damage.to_mp? && mp < mmp-mp_reserved
#~     elsif item.damage
#~       return true if item.damage.recover? && item.damage.to_hp? && hp < mhp
#~       return true if item.damage.recover? && item.damage.to_mp? && mp < mmp
#~     end
#~     return true #if item_has_any_valid_effects?(user, item)
#~     return false
#~   end
#~   def make_damage_value(user, item)
#~     value  = item.damage.eval(user, self, $game_variables)
#~     value  = item.damage.eval(user, Tidloc::Dummy_actor.new, $game_variables) if Tidloc::Crit_Ignore_Def && @result.critical
#~     value += item.extra_damage if $imported["Tidloc-CustomSkills"] && item.is_a?(Tidloc::CustomSkills::Base)
#~     value += item.extra_damage if $imported["Tidloc-CustomEquip"]  && item.is_a?(Tidloc::CustomEquip::Base)
#~     value *= item_element_rate(user, item)
#~     value *= pdr if item.physical? if !Tidloc::Crit_Ignore_PDR || !@result.critical
#~     value *= mdr if item.magical?
#~     value *= rec if item.damage.recover?
#~     value = apply_critical(value,user)   if @result.critical && (!Tidloc::Use_mod[:limitbreak] || !@result.limitbreak)
#~     value = apply_limitbreak(value) if Tidloc::Use_mod[:limitbreak] && @result.limitbreak
#~     value = apply_variance(value, item.damage.variance)
#~     value = apply_guard(value)  unless (Tidloc::Use_mod[:limitbreak] && @result.limitbreak) || (Tidloc::Crit_Ignore_Guard && @result.critical)
#~     @result.make_damage(value.to_i, item)
#~   end
#~   alias wo_tidloc_apply_critical apply_critical
#~   def apply_critical(damage, user=self)
#~     mul = 1
#~     if    !Tidloc::Use_mod[:crit] && !Tidloc::Use_mod[:crit_note]
#~       return wo_tidloc_apply_critical(damage)
#~     elsif !Tidloc::Use_mod[:crit_note]
#~       mul = Tidloc::Crit_Mult
#~     elsif user.is_a?(Game_Enemy)
#~       mul += $1.to_f                  if user.enemy.note =~ Tidloc::Notetags[5][0]
#~       mul += $game_variables[$1.to_i] if user.enemy.note =~ Tidloc::Notetags[5][1]
#~     elsif user.is_a?(Game_Actor)
#~       mul += $1.to_f                  if user.actor.note =~ Tidloc::Notetags[5][0]
#~       mul += $game_variables[$1.to_i] if user.actor.note =~ Tidloc::Notetags[5][1]
#~       if $imported["Tidloc-CustomEquip"] && $imported["Tidloc-CustomRefining"]
#~         user.weapons.each{|w|
#~           mul += w.refining_crit_boost/100.0
#~         }
#~       end
#~     end
#~     damage * mul
#~   end
#~   def apply_limitbreak(damage)
#~     if    self.is_a?(Game_Enemy) && $data_enemies[self.enemy_id].note =~ Tidloc::Notetags[5][2]
#~       damage * $1.to_f
#~     elsif self.is_a?(Game_Enemy) && $data_enemies[self.enemy_id].note =~ Tidloc::Notetags[5][3]
#~       damage * $game_variables[$1.to_i]
#~     elsif self.is_a?(Game_Actor) && $data_actors[self.actor_id].note =~ Tidloc::Notetags[5][2]
#~       damage * $1.to_f
#~     elsif self.is_a?(Game_Actor) && $data_actors[self.actor_id].note =~ Tidloc::Notetags[5][3]
#~       damage * $game_variables[$1.to_i]
#~     else
#~       damage * Tidloc::LB_Mult
#~     end
#~   end
#~   alias wo_tidloc_item_apply item_apply
#~   def item_apply(user, item)
#~     unless Tidloc::Use_mod[:limitbreak] || Tidloc::Use_mod[:battle_command]
#~       wo_tidloc_item_apply(user, item)
#~       return
#~     end
#~     @result.clear
#~     @result.used = item_test(user, item)
#~     @result.missed = (@result.used && rand >= item_hit(user, item))
#~     @result.evaded = (!@result.missed && rand < item_eva(user, item))
#~     if @result.hit?
#~       if item.damage.none?
#~         $game_temp.tidloc[:target] = self
#~         $game_temp.tidloc[:user]   = user
#~         begin
#~           item.execute_commands("Use")
#~         rescue;end
#~       else
#~         if    $imported["Tidloc-CustomEquip"] && $imported["Tidloc-CustomDura"] && 
#~               (Tidloc::CustomDura::Duraloss_in_Menu ||
#~               (!SceneManager.scene.is_a?(Scene_Item) && !SceneManager.scene.is_a?(Scene_Skill)))
#~           if user.is_a?(Game_Actor)
#~             user.weapons.each{|w|
#~               w.dura_use }
#~           end
#~           if self.is_a?(Game_Actor)
#~             self.armors.each{|w|
#~               w.dura_use }
#~           end
#~         end
#~         @result.critical = (rand < item_cri(user, item))
#~         if Tidloc::Use_mod[:limitbreak] && @result.critical
#~           @result.limitbreak = rand < item_LB(user, item)
#~         end
#~         if Tidloc::Use_mod[:battle_command] && SceneManager.scene_is?(Scene_Battle)
#~           $game_temp.tidloc[:skill]  = item
#~           $game_temp.tidloc[:user]   = user
#~           $game_temp.tidloc[:target] = self
#~           user.tidloc_exe_command("BattleHit")
#~           self.tidloc_exe_command("BattleGetHit")
#~           if @result.limitbreak
#~             user.tidloc_exe_command("BattleLB")
#~             self.tidloc_exe_command("BattleGetLB")
#~           elsif @result.critical
#~             user.tidloc_exe_command("BattleCrit")
#~             self.tidloc_exe_command("BattleGetCrit")
#~           end
#~         end
#~         make_damage_value(user, item)
#~         execute_damage(user)
#~         $game_temp.tidloc[:target] = self
#~         $game_temp.tidloc[:user]   = user
#~         if    item.is_a?(RPG::Item) && $imported["Tidloc-ItemData"]
#~           $game_temp.tidloc[:item]  = item
#~         elsif item.is_a?(RPG::Skill) && $imported["Tidloc-SkillData"]
#~           $game_temp.tidloc[:skill] = item
#~         elsif $imported["Tidloc-CustomSkills"] && item.is_a?(Tidloc::CustomSkills::Base)
#~           $game_temp.tidloc[:skill] = item
#~         end
#~         begin
#~           item.execute_commands("Use")
#~         rescue;end
#~       end
#~       item.effects.each {|effect| item_effect_apply(user, item, effect) }
#~       item_user_effect(user, item)
#~     elsif Tidloc::Use_mod[:battle_command] && (@result.missed || @result.evaded)
#~       $game_temp.tidloc[:skill]  = item
#~       $game_temp.tidloc[:actor]  = user
#~       $game_temp.tidloc[:target] = self
#~       user.tidloc_exe_command("BattleMiss")
#~     end
#~   end
#~   alias wo_tidloc_attack_apply attack_apply
#~   def attack_apply(attacker)
#~     if attacker.is_a?(Game_Actor)
#~       $game_temp.tidloc[:weapon] = attacker.equips[0] 
#~     else
#~       $game_temp.tidloc[:weapon] = RPG::Weapon.new
#~     end
#~     wo_tidloc_attack_apply(attacker)
#~   end
#~   def item_cri(user, item)
#~     if item.damage.critical
#~       if item.is_a?(RPG::Skill) && item.note =~ Tidloc::Notetags[4][2]
#~         prop  = $1.to_i/100.0
#~         prop += user.cri  unless item.nope =~ Tidloc::Notetags[4][4]
#~         prop *= (1 - cev) unless item.note =~ Tidloc::Notetags[4][3]
#~         prop
#~       else
#~         user.cri * (1 - cev)
#~       end
#~     else
#~       0
#~     end
#~   end
#~   def item_LB(user, item)
#~     (user.lb_chance+item.lb_chance) * (1 - lb_def)
#~   end
#~ end
################################################################################
#                                                                              #
################################################################################

#~ class Game_BattlerBase
#~   def dex; param(8);end
#~   def vit; param(9); end
#~   def skill_hp_cost(skill)
#~     temp  = skill.hp_cost 
#~     temp += ($1.to_f*mhp/100.0).to_i if skill.note =~ /<hp%-cost (.*)>/i
#~     (temp* hcr).to_i
#~   end
#~   alias wo_tidloc_pay pay_skill_cost
#~   def pay_skill_cost(skill)
#~     self.hp -= skill_hp_cost(skill)
#~     $game_temp.tidloc[:actor] = self
#~     wo_tidloc_pay(skill)
#~   end
#~   def skill_cost_payable?(skill)
#~     hp >= skill_hp_cost(skill) && tp >= skill_tp_cost(skill) && mp >= skill_mp_cost(skill)
#~   end
#~   def hcr
#~     return $1.to_f if self.is_a?(Game_Actor) && self.actor.note =~ /<hp-cost-rate (.*)>/i
#~     return $1.to_f if self.is_a?(Game_Enemy) && self.enemy.note =~ /<hp-cost-rate (.*)>/i
#~     return 1
#~   end
#~   def lb_chance
#~     return 0 unless Tidloc::Use_mod[:limitbreak]
#~     temp = 0.0
#~     if    self.is_a?(Game_Actor)
#~       temp += $1.to_i/100.0 if self.actor.note =~ Tidloc::Notetags[4][0]
#~       self.equips.compact.each{|i|
#~         if i.note =~ Tidloc::Notetags[4][0]
#~           temp += $1.to_i/100.0
#~         end
#~       }
#~       if $imported["Tidloc-CustomSkills"] && $imported["Tidloc-PassiveSkills"]
#~         self.tidloc_active_skills.compact.each{|s|
#~           temp += s.lb_chance
#~         }
#~       end
#~     elsif self.is_a?(Game_Enemy)
#~       temp += $1.to_i/100.0 if self.enemy.note =~ Tidloc::Notetags[4][0]
#~     end
#~     return temp
#~   end
#~   def lb_def
#~     return 1 unless Tidloc::Use_mod[:limitbreak]
#~     temp = 0.0
#~     if    self.is_a?(Game_Actor)
#~       temp += $1.to_i/100.0 if self.actor.note =~ Tidloc::Notetags[4][1]
#~       self.equips.compact.each{|i|
#~         if i.note =~ Tidloc::Notetags[4][1]
#~           temp += $1.to_i/100.0
#~         end
#~       }
#~       if $imported["Tidloc-CustomSkills"] && $imported["Tidloc-PassiveSkills"]
#~         self.tidloc_active_skills.compact.each{|s|
#~           temp += s.lb_chance
#~         }
#~       end
#~     elsif self.is_a?(Game_Enemy)
#~       temp += $1.to_i/100.0 if self.enemy.note =~ Tidloc::Notetags[4][1]
#~     end
#~     return temp
#~   end
#~   alias wo_tidloc_usable? usable?
#~   def usable?(item)
#~     begin
#~       if item.commands.find{|c| c[0]=="Use"}
#~         if item.commands.find{|c| c[0]=="UnUse"}
#~           item.commands.each_with_index{|c,i|
#~             if c[0]=="UnUse" && eval(c[1])
#~               item.commands[i] = nil
#~             end
#~           }
#~         else
#~           return true
#~         end
#~       end
#~     rescue;end
#~     item.commands.compact!
#~     wo_tidloc_usable?(item)
#~   end
#~ end
################################################################################
#                                                                              #
################################################################################

#~ class Window_SkillList
#~   alias wo_tidloc_draw_skill_cost draw_skill_cost
#~   def draw_skill_cost(rect, skill)
#~     if    !Tidloc::Use_mod[:skill_win_mod]
#~       wo_tidloc_draw_skill_cost(rect, skill)
#~     elsif @actor.skill_tp_cost(skill) > 0
#~       change_color(tp_cost_color, enable?(skill))
#~       draw_text(rect, @actor.skill_tp_cost(skill), 2)
#~     elsif @actor.skill_mp_cost(skill) > 0
#~       change_color(mp_cost_color, enable?(skill))
#~       draw_text(rect, @actor.skill_mp_cost(skill), 2)
#~     elsif @actor.skill_hp_cost(skill) > 0
#~       change_color(hp_gauge_color1, enable?(skill))
#~       draw_text(rect, @actor.skill_hp_cost(skill), 2)
#~     end
#~   end
#~   alias wo_tidloc_skill_col_max col_max
#~   def col_max
#~     return wo_tidloc_skill_col_max unless Tidloc::Use_mod[:skill_win_mod]
#~     1
#~   end
#~ end
################################################################################
#                                                                              #
################################################################################

#~ class Game_Party < Game_Unit
#~   alias wo_tidloc_gain gain_item
#~   def gain_item(item, amount, include_equip = false)
#~     return unless item
#~     if amount > 0 && item.note =~ /<exe-get: (.*)>/
#~       amount.times {|x| eval($1)}
#~     end
#~     if amount < 0 && item.note =~ /<exe-lose: (.*)>/
#~       (-amount).times {|x| eval($1)}
#~     end
#~     wo_tidloc_gain(item, amount, include_equip)
#~   end
#~   alias wo_tidloc_usable usable?
#~   def usable?(item)
#~     return false unless item
#~     if item.note =~ /<exe-use: (.*)>/i
#~       if item.note =~ /<exe-use-count: (.*)>/i
#~         return true if item.is_a?(RPG::EquipItem)     && item.tidloc_uses < $1.to_i
#~         return true if $imported["Tidloc-CustomEquip"] && item.is_a?(Tidloc::CustomEquip::Base) && item.uses < $1.to_i
#~       else
#~         return true
#~       end
#~       return false
#~     end
#~     begin
#~       if item.commands.find{|c| c[0]=="Use"}
#~         if item.commands.find{|c| c[0]=="UnUse"}
#~           item.commands.find_all{|c| c[0]=="UnUse"}.each{|c|
#~             c = nil if eval(c[1])
#~           }
#~           
#~         else
#~           return true
#~         end
#~       end
#~     rescue;end
#~     return wo_tidloc_usable(item)
#~   end
#~   alias wo_tidloc_consume consume_item
#~   def consume_item(item)
#~     if item.is_a?(RPG::EquipItem) || ($imported["Tidloc-CustomEquip"] && item.is_a?(Tidloc::CustomEquip::Base))
#~       if item.note =~ /<exe-use: (.*)>/i
#~         begin
#~           eval($1)
#~         rescue
#~           msgbox "Command \"#{$1}\" on item #{item.name} was faulty!"
#~           exit
#~         end
#~         if item.is_a?(RPG::EquipItem)
#~           item.tidloc_uses += 1 
#~           if item.note =~ /<exe-use-break: (.*)>/i
#~             if item.tidloc_uses >= $1.to_i 
#~               item.tidloc_uses = 0
#~               lose_item(item, 1) 
#~             end
#~           end
#~         else
#~           item.uses        += 1       if $imported["Tidloc-CustomEquip"] && item.is_a?(Tidloc::CustomEquip::Base)
#~           item.execute_command("Use") if $imported["Tidloc-CustomEquip"] && item.is_a?(Tidloc::CustomEquip::Base)
#~           if item.note =~ /<exe-use-break: (.*)>/i
#~             if item.uses >= $1.to_i 
#~               item.uses = 0
#~               lose_item(item, 1)
#~             end
#~           end
#~         end
#~       elsif $imported["Tidloc-CustomEquip"] && item.is_a?(Tidloc::CustomEquip::Base) &&
#~             item.commands.find_all{|c| c[0]=="Use"}.size > 0
#~         item.execute_command("Use")
#~       end
#~     else
#~       if item.note =~ /<exe-use: (.*)>/i
#~         $game_temp.tidloc[:item] = item
#~         eval($1)
#~         $game_party.lose_item(item, 1) unless item.note =~ /<exe-use-indef>/i
#~       else
#~         wo_tidloc_consume(item)
#~       end
#~     end
#~   end
#~   def need_healing?
#~     $game_party.battle_members.each{|a|
#~       return true if !$imported["Tidloc-PassiveSkills"] && a.hp < a.mhp
#~       return true if !$imported["Tidloc-PassiveSkills"] && a.mp < a.mmp
#~       return true if  $imported["Tidloc-PassiveSkills"] && a.hp < a.mhp-a.hp_reserved
#~       return true if  $imported["Tidloc-PassiveSkills"] && a.mp < a.mmp-a.mp_reserved
#~     }
#~     false
#~   end
#~ end
################################################################################
#                                                                              #
################################################################################

#~ class Game_Troop < Game_Unit
#~   attr_accessor :commands
#~   alias wo_tidloc_initialize initialize
#~   def initialize
#~     wo_tidloc_initialize
#~     self.commands = []
#~   end
#~   def execute_commands(tag)
#~     self.commands.each {|x| x[0]==tag ? eval(Tidloc.exe(x[1],x[2])) : ""}
#~   end
#~ end

#~ class Sprite_Picture < Sprite
#~   def picture
#~     @picture
#~   end
#~ end

#~ class Game_Interpreter
#~   def command_315
#~     value = operate_value(@params[2], @params[3], @params[4])
#~     iterate_actor_var(@params[0], @params[1]) do |actor|
#~       actor.gain_exp(value)
#~     end
#~   end
#~ end
################################################################################
#                                                                              #
################################################################################

#~ module BattleManager
#~   class<<self;alias wo_tidloc_process_victory process_victory;end
#~   def self.process_victory
#~     self.wo_tidloc_process_victory
#~     if Tidloc::Use_mod[:actor_command]
#~       $game_party.battle_members.each{|character|
#~         $game_temp.tidloc[:actor] = character
#~         character.tidloc_exe_command("BattleEnd")
#~         character.tidloc_exe_command("BattleWin")}
#~     end
#~     $game_troop.execute_commands("BattleDefeat")
#~   end
#~   class<<self;alias wo_tidloc_process_escape process_escape;end
#~   def self.process_escape
#~     temp = wo_tidloc_process_escape
#~     if temp
#~       if Tidloc::Use_mod[:actor_command]
#~         $game_party.battle_members.each{|character|
#~           $game_temp.tidloc[:actor] = character
#~           character.tidloc_exe_command("BattleEnd")
#~           character.tidloc_exe_command("BattleFlee")}
#~       end
#~       $game_troop.execute_commands("BattleFlee")
#~     else
#~       if Tidloc::Use_mod[:actor_command]
#~         $game_party.battle_members.each{|character|
#~           $game_temp.tidloc[:actor] = character
#~           character.tidloc_exe_command("BattleNotFlee")}
#~       end
#~       if Tidloc::Use_mod[:enemy_command]
#~         $game_troop.members.each{|enemy|
#~           $game_temp.tidloc[:enemy] = enemy
#~           enemy.tidloc_exe_command("BattleNotFlee")}
#~       end
#~       $game_troop.execute_commands("BattleNotFlee")
#~     end
#~     temp
#~   end
#~   class<<self;alias wo_tidloc_process_defeat process_defeat;end
#~   def self.process_defeat
#~     wo_tidloc_process_defeat
#~     if Tidloc::Use_mod[:battle_command]
#~       if Tidloc::Use_mod[:actor_command]
#~         $game_party.battle_members.each{|character|
#~           $game_temp.tidloc[:actor] = character
#~           character.tidloc_exe_command("BattleDefeat")}
#~       end
#~       if Tidloc::Use_mod[:enemy_command]
#~         $game_troop.members.each{|enemy|
#~           $game_temp.tidloc[:enemy] = enemy
#~           enemy.tidloc_exe_command("BattleWin")}
#~       end
#~       $game_troop.execute_commands("BattleWin")
#~     end
#~   end
#~ end

################################################################################
#                                                                              #
################################################################################

#~ class Bitmap
#~   if !$imported["HTML-tagging"]
#~     def Bitmap.html_decode(str)
#~       str
#~     end
#~   end
#~ end
################################################################################
#                                                                              #
################################################################################

#~ class RPG::BaseItem
#~   
#~   def elemental_rate(id)
#~     return 1 if self.features.nil?
#~     temp = self.features.select {|ele| ele.code == 11 && ele.data_id == id}
#~     return temp[0].value if temp.size > 0
#~     return 1
#~   end
#~   def tidloc_class
#~     return 0 unless Tidloc::Use_mod[:item_categories]
#~     classes = 0
#~     if    self.note =~ /<c=(.*)>/i
#~       classes = $1.to_i
#~     elsif self.note =~ /\\c<(.*)>/i
#~       classes = $1.to_i
#~     elsif self.note =~ /\\class<(.*)>/i
#~       classes = $1.to_i
#~     end
#~     return classes
#~   end
#~ end



#~ def arr_add(a1,a2)
#~   temp = []
#~   max = [a1.size,a2.size].max
#~   for i in 0...max
#~     temp[i] = a1[i] + a2[i]
#~   end
#~   return temp
#~ end
#~ def arr_sub(a1,a2)
#~   return arr_add(a1,-a2)
#~ end