=begin ========================================================================
# ** String Input Scene
#------------------------------------------------------------------------------
#      Author: Rikifive
#  Contact me: https://www.rpgmakercentral.com/profile/57081-rikifive/
#     Discord: Rikifive#2820
#
#  v 1.0 // 26.05.2018 (dd.mm.yyyy)
#
#---[ DESCRIPTION ]------------------------------------------------------------
#  In this scene you can input a string into a variable, similar to name input.
#
#---[ FEATURES ]---------------------------------------------------------------
#  Allow players to input a string and store it in a variable.
#  Can be used to say something 'custom' in the message box,
#  can be used to change names etc.,
#  can be used to ask for password, codes and so on...
#
#---[ TERMS OF USE ]-----------------------------------------------------------
#  - Can be used in commercial projects
#  - Can be modified to your needs
#  - Cannot be reposted without permission
#  - Credit me, { Rikifive } in your project
#
#---[ INSTRUCTIONS ]-----------------------------------------------------------
#  Paste below materials; above main.
#
#  Assign [ 5 ] variables to settings in the configuration section below.
#
#  To call a scene, use the [ script call ] from 3rd page.
#
#---[ EXAMPLE ]----------------------------------------------------------------
> Event Commands / 3rd Page / Advanced / Script...
- - - - - - - - - - - - - - - - - - - - - - - - - -

$game_variables[21] = "What's your name?" # desc
$game_variables[22] = Color.new(255,125,60) # desc color
$game_variables[23] = "Eric" # string suggested by default
$game_variables[24] = 30 # length (max 30)
SceneManager.call(Scene_Input);

- - - - - - - - - - - - - - - - - - - - - - - - - -
Color is in [ RGB ] format; from [ 0 ] to [ 255 ] for each color.
Maximum supported length is [ 30 ] characters. Putting more won't have effect.


You can modify each settings as you wish, you DON'T have to include all
of them each time you want to bring the input menu; for example:

$game_variables[21] = "What's your name?" # desc
SceneManager.call(Scene_Input);

Will call a scene with the description specified above.
The rest of settings will remain the same as they were set last time OR
                             reset to defaults; see configuration below.
                             
/!\ WARNING
HOWEVER, you HAVE TO to configure ALL settings when calling the input menu
for the FIRST TIME. Otherwise it will crash, due to lack of values, or rather,
them not being formatted correctly.

=end #=========================================================================
module RK5_VAREDIT
  
  #----------------------------------------------------------------------------
  # QUICK CONFIGURATION
  #----------------------------------------------------------------------------
  # In which variable would you like to store...
  # - Please assign variable ID's for each setting. -
  #----------------------------------------------------------------------------
  
  # This is a variable, where the input is stored, which can be used afterwards.
  STRING  = 20 # USER INPUT (STRING)
  
  
  DESC    = 21 # DESCRIPTION / QUESTION
  COLOR   = 22 # DESCRIPTION COLOR
  
  DEFAULT = 23 # STRING SUGGESTED BY DEFAULT
  LENGTH  = 24 # MAXIMUM ALLOWED CHARACTERS
  
  #----------------------------------------------------------------------------
  # Should settings be reset after use?
  # - Enabling that will restore defaults to specific settings after use -
  #----------------------------------------------------------------------------
  
  CLEAN_DEFAULT = true # if true, it will leave default input blank after use.
  CLEAN_DESC    = true # if true, it will leave description blank after use.
  RESET_COLOR   = true # if true, it will reset font color to white after use.
  RESET_LENGTH  = 12 # this is the default length that will be set after use.
                    # put [ 0 ] to disable this and keep the last used value.
  
  #----------------------------------------------------------------------------                  
  # For example, if all above would be enabled, after putting:
  #
  # SceneManager.call(Scene_Input);
  #
  # ~in the script call, would successfully call the input scene with default
  #  settings.
  #  The defaults being:
  #  - no default string
  #  - no description
  #  - color set to white
  #  - length set to specified default
  #
  #  ... just input window.
  #
  # REMINDER: You can modify each settings as you wish,
  # you don't have to include all of them each time.
  # Skipping settings will either use defaults or last used values.
  #----------------------------------------------------------------------------
  
end
#==============================================================================
# ::: END OF CONFIGURATION :::
#==============================================================================
# ** DONUT EDIT THINGS BELOW ** - Do it at your own risk. -
#==============================================================================

class Scene_Input < Scene_MenuBase
  #--------------------------------------------------------------------------
  # * Start Processing
  #--------------------------------------------------------------------------
  def start
    super
    $game_variables[RK5_VAREDIT::STRING] = $game_variables[RK5_VAREDIT::DEFAULT]
    @edit_window = Window_StringEdit.new
    @input_window = Window_NameInput.new(@edit_window)
    @input_window.set_handler(:ok, method(:on_input_ok))
  end
  #--------------------------------------------------------------------------
  # * Input [OK]
  #--------------------------------------------------------------------------
  def on_input_ok
    $game_variables[RK5_VAREDIT::STRING] = @edit_window.string
    reset_settings
    return_scene
  end
  #--------------------------------------------------------------------------
  # * Reset to Defaults
  #--------------------------------------------------------------------------
  def reset_settings
    $game_variables[RK5_VAREDIT::DEFAULT] = "" if RK5_VAREDIT::CLEAN_DEFAULT
    $game_variables[RK5_VAREDIT::DESC] = "" if RK5_VAREDIT::CLEAN_DESC
    $game_variables[RK5_VAREDIT::COLOR] = Color.new(255,255,255) if RK5_VAREDIT::RESET_COLOR
    if RK5_VAREDIT::RESET_LENGTH != 0
      $game_variables[RK5_VAREDIT::LENGTH] = RK5_VAREDIT::RESET_LENGTH
    end
  end
  
end


#==============================================================================
# ** Window_StringEdit
#------------------------------------------------------------------------------
#  This window is used to edit the string on the input screen.
#  Based on NameEdit, duh!
#==============================================================================

class Window_StringEdit < Window_Base
  #--------------------------------------------------------------------------
  # * Public Instance Variables
  #--------------------------------------------------------------------------
  attr_reader   :string                   # input string
  attr_reader   :index                    # cursor position
  attr_reader   :max_char                 # maximum number of characters
  attr_reader   :name                     # COMPATIBILITY PURPOSES
  
  #--------------------------------------------------------------------------
  # * Object Initialization
  #--------------------------------------------------------------------------
  def initialize
    x = (Graphics.width - 360) / 2
    y = (Graphics.height - (fitting_height(4) + fitting_height(9) + 8)) / 2
    super(x, y, 360, fitting_height(4))
    @name = "compatibility"
    @max_char = [$game_variables[RK5_VAREDIT::LENGTH], 30].min
    @string = $game_variables[RK5_VAREDIT::DEFAULT][0, @max_char]
    @index = @string.size
    deactivate
    refresh
  end
  #--------------------------------------------------------------------------
  # * Add Text Character
  #     ch : character to add
  #--------------------------------------------------------------------------
  def add(ch)
    return false if @index >= @max_char
    @string += ch
    @index += 1
    refresh
    return true
  end
  #--------------------------------------------------------------------------
  # * Go Back One Character
  #--------------------------------------------------------------------------
  def back
    return false if @index == 0
    @index -= 1
    @string = @string[0, @index]
    refresh
    return true
  end
  #--------------------------------------------------------------------------
  # * Get Character Width
  #--------------------------------------------------------------------------
  def char_width
    text_size($game_system.japanese? ? "あ" : "A").width 
  end
  #--------------------------------------------------------------------------
  # * Get Coordinates of Left Side for Drawing Name
  #--------------------------------------------------------------------------
  def left
    input_center = contents_width / 2
    input_width = (@max_char + 1) * char_width
    return [input_center - input_width / 2, contents_width - input_width].min
  end
  #--------------------------------------------------------------------------
  # * Get Rectangle for Displaying Item
  #--------------------------------------------------------------------------
  def item_rect(index)
    Rect.new(left + index * char_width, 36+10, char_width, line_height)
  end
  #--------------------------------------------------------------------------
  # * Get Underline Rectangle
  #--------------------------------------------------------------------------
  def underline_rect(index)
    rect = item_rect(index)
    rect.x += 1
    rect.y += rect.height - 4
    rect.width -= 2
    rect.height = 2
    rect
  end
  #--------------------------------------------------------------------------
  # * Get Underline Color
  #--------------------------------------------------------------------------
  def underline_color
    color = normal_color
    color.alpha = 48
    color
  end
  #--------------------------------------------------------------------------
  # * Draw Underline
  #--------------------------------------------------------------------------
  def draw_underline(index)
    contents.fill_rect(underline_rect(index), underline_color)
  end
  #--------------------------------------------------------------------------
  # * Draw Text
  #--------------------------------------------------------------------------
  def draw_char(index)
    rect = item_rect(index)
    rect.x -= 1
    rect.width += 4
    change_color(normal_color)
    draw_text(rect, @string[index] || "")
  end
  #--------------------------------------------------------------------------
  # * Draw Description
  #--------------------------------------------------------------------------
  def draw_desc
    desc = $game_variables[RK5_VAREDIT::DESC]
    change_color($game_variables[RK5_VAREDIT::COLOR])
    draw_text(0,line_height/2,contents_width,line_height,desc,1)
  end
  #--------------------------------------------------------------------------
  # * Refresh
  #--------------------------------------------------------------------------
  def refresh
    contents.clear
    @max_char.times {|i| draw_underline(i) }
    @string.size.times {|i| draw_char(i) }
    draw_desc
    cursor_rect.set(item_rect(@index))
  end
end