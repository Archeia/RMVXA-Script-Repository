# Multiple Choices
# Autor: Raizen
# Edit by: Tsukihime
# Compatible with RMVXAce
# Instructions:

# To use is very simple
# Script Call: @get_choices = [a,b,c,d,e,f,g]
#
# where in the letter you put the choices,
# always between quotes
# Example
# Script Call: @get_choices = ["legs", "ball", "house", "car", "demon head", "glasses"]

# To have a cancel condition, the last choices without quotes needs
# to be the number of the choice that cancels.
# Script Call: @get_choices = ["legs", "ball", "house", "car", "demon head", "glasses", 5]
#
# To decide what each decision does, you only need to put
# a condition after the choices call on the events with the
# variable that represents it
# For Example:
# If I want the secondo choice to make the character Jump, I'll put
# after the choices,
# Condition
# Variable X equals to 2
# Jump.

# normal usage
#@get_choices = [
#"one",
#"two"
#]

# with a condition
#@get_choices = [
#"one",
#["two", "$game_actors[1].level > 4"] # an array is used
#]

# After Call Script,

# Do as you normally would to create choices, it doesn't
# matter what choices you choose, after the call script it will
# put the choices on the call script.

# After that put the conditions with the variable chosen from below,
# when the player chooses the first choice, the variable will change
# its value to 1, when he chooses the seventh, it will make the variables
# value to 7, so you can create conditions based on the variable




module Raizen_choices
#variable to control the conditions of each choice
Variable = 70
end

#======================================================================
#=========================Here starts the script============================
#======================================================================

class Game_Interpreter
alias :raizen_choices :setup_choices

def show_choices(choices)
n = 0
choices.each {|choice| #
break if choice.is_a?(Integer)
$game_message.choices.push(choice)
n += 1
}
$game_message.choice_cancel_type = choices[n] if choices[n].is_a?(Integer)
@get_choices = nil
$game_message.choice_proc = Proc.new {|n| @branch[@indent] = n
$game_variables[Raizen_choices::Variable] = n + 1 }
Fiber.yield while $game_message.choice?
end

def setup_choices(params)
@get_choices.nil? ? raizen_choices(params) : show_choices(@get_choices)
end
end

# add-on: color commands

class Window_ChoiceList

def make_command_list
$game_message.choices.each do |choice|
if choice.is_a?(Array)
add_command(choice[0], :choice, eval(choice[1]))
elsif choice.is_a?(String)
add_command(choice, :choice)
end
end
end

alias :th_multiple_choice_draw_item :draw_item
def draw_item(index)
change_color(normal_color, command_enabled?(index))
th_multiple_choice_draw_item(index)

end

# not important
def reset_font_settings
end
end