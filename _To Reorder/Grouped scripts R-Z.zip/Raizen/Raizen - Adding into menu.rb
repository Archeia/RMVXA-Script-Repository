#==============================================================================
# ** Scene_Menu
#------------------------------------------------------------------------------
#  Esta classe executa o processamento da tela de menu.
#==============================================================================

class Scene_Menu < Scene_MenuBase
  def create_command_window
    @command_window = Window_MenuCommand.new
    @command_window.set_handler(:item,      method(:command_item))
    @command_window.set_handler(:skill,     method(:command_personal))
    @command_window.set_handler(:equip,     method(:command_personal))
    @command_window.set_handler(:status,    method(:command_personal))
    @command_window.set_handler(:skill_tree,  method(:command_skill_tree))
    @command_window.set_handler(:formation, method(:command_formation))
    @command_window.set_handler(:save,      method(:command_save))
    @command_window.set_handler(:game_end,  method(:command_game_end))
    @command_window.set_handler(:cancel,    method(:return_scene))
  end
  def command_skill_tree
      SceneManager.call(Scene_Skill_Change)
  end
end

#==============================================================================
# ** Window_MenuCommand
#------------------------------------------------------------------------------
#  Esta janela exibe os comandos do menu.
#==============================================================================

class Window_MenuCommand < Window_Command
alias raizen_add_main_commands add_main_commands
  def add_main_commands
    raizen_add_main_commands
    add_command(Skill_Tree::Menu, :skill_tree, main_commands_enabled)
  end
end
