module StartGame
	$game_mouse = true
end