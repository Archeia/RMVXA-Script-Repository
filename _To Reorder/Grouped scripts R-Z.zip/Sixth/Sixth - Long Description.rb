class Scene_Item < Scene_ItemBase
  
  alias description_extension_start start
  def start
    description_extension_start
    
    create_description_window
  end
  
  def create_description_window
    @description_window = Window_Item_Description.new
    @description_window.z = 300
    @description_window.back_opacity = 255
   
    @description_window.hide
    
  end
  
  def unexpand
    @description_window.hide
    @item_window.activate
  end
  
  alias description_extension_create_item_window create_item_window
  def create_item_window
    description_extension_create_item_window
    @item_window.set_handler(:expand,     method(:on_item_expand))
  end
  
  def on_item_cancel
    if @description_window.visible
        @description_window.hide
        @item_window.activate
    else
      @item_window.unselect
      @category_window.activate
    end
  end
  
  def on_item_expand
     if @description_window.visible
        @description_window.hide
        @item_window.activate
    else
      @description_window.show
      @description_window.get_description(@item_window.item)
    end
  end

end

class Window_Item_Description < Window_Base
  
  def initialize
    super(0,0,Graphics.width,200) # <==== change window position and size
  end
  
  def get_description(item)
    contents.clear
    text = item.note.scan(/<\s*description\s*:\s*([^>]+)>/)
    if text[0] 
      draw_text_ex( 0 , 0 , text[0][0])
    else
      draw_text_ex( 0 , 0 ,item.description)
    end
  end
  
end

class Window_ItemList < Window_Selectable
  
def process_handling
  return unless open? && active
    return process_ok       if ok_enabled?        && Input.trigger?(:C)
    return process_cancel   if cancel_enabled?    && Input.trigger?(:B)
    return process_pagedown if handle?(:pagedown) && Input.trigger?(:R)
    return process_pageup   if handle?(:pageup)   && Input.trigger?(:L)
  return process_description if Input.trigger?(:SHIFT)  #<===== change which button to press to show window
end

def process_description
  call_handler(:expand)
end
end