#===============================================================================
# * [ACE] Map HUD EX
#===============================================================================
# * Made by: Sixth (www.rpgmakervxace.net, www.forums.rpgmakerweb.com)
# * Version: 1.3
# * Updated: 06/10/2015
# * Requires: -------
#-------------------------------------------------------------------------------
# * < Change Log >
#-------------------------------------------------------------------------------
# * Version 1.0 (13/06/2015)
#   - Initial release.
# * Version 1.1 (01/07/2015)
#   - Added compatibility with my Menu Engine script.
#   - You can now set the numeric display type for every gauge shown separately.
#   - Fixed an update method which updated constantly instead of only when
#     necessary.
# * Version 1.2 (10/07/2015)
#   - Made it impossible to toggle the visibility of the HUD during events.
# * Version 1.3 (06/10/2015)
#   - Added state/buff display.
#-------------------------------------------------------------------------------
# * < Description >
#-------------------------------------------------------------------------------
# * This script is aimed for games where the player can control only one actor
#   at a time, such as a game with an action battle system and the likes.
# * This script adds a map HUD which can display the following information:
#   - HP, MP, TP, XP, state/buff icons
# * All information displayed will be the party leader's data!
# * You can set what to show, where to show, how to show, and more!
# * The HUD is purely image based. You can use any images you want!
# * Two kinds of image bar filling is possible, can be horizontal or vertical.
# * Image based number drawing is possible too, with my Picture Drawing script!
# * Toggle the HUD with a single press of a button or by toggling a switch
#   anytime during the game!
# * A little bonus: play an animation on the player upon a level up!
# * Tons of settings for you to configure!
# * Say goodbye to the old and boring default bars and make your own!
#-------------------------------------------------------------------------------
# * < Usage Information >
#-------------------------------------------------------------------------------
# * This script uses a custom made folder setup to get the location of the
#   pictures used. All images used must be in that folder!
#   You can set the folder location with the 'ImgFolder' setting!
#-------------------------------------------------------------------------------
# * < Installation >
#-------------------------------------------------------------------------------
# * Place this script below Materials but above Main!
#-------------------------------------------------------------------------------
# * < Compatibility Info >
#-------------------------------------------------------------------------------
# * No known incompatibilities.
#-------------------------------------------------------------------------------
# * < Known Issues >
#-------------------------------------------------------------------------------
# * No known issues.
#-------------------------------------------------------------------------------
# * < Terms of Use >
#-------------------------------------------------------------------------------
# * Free to use for whatever purposes you want.
# * Credit me (Sixth) in your game, pretty please! :P
# * Posting modified versions of this script is allowed as long as you notice me
#   about it with a link to it!
#===============================================================================
$imported = {} if $imported.nil?
$imported["SixthMapHUD"] = true
#===============================================================================
# Settings:
#===============================================================================
module SixthMapHUD # <-- No touchy-touchy!
  #-----------------------------------------------------------------------------
  # Image Folder Settings:
  #-----------------------------------------------------------------------------
  # Set up a custom folder where your map HUD pictures will be read from.
  # All pictures used must be in this folder!
  #-----------------------------------------------------------------------------
  ImgFolder = "Graphics/MapHUD/"
 
  #-----------------------------------------------------------------------------
  # Switch Settings:
  #-----------------------------------------------------------------------------
  # Set up a switch used to toggle the HUD at will during the game.
  # Useful for eventing, I guess.
  # Enter the ID of the switch you want to use for this.
  # Don't forget that you MUST turn this switch ON to show the HUD!
  #-----------------------------------------------------------------------------
  HUDSwitch = 100
 
  #-----------------------------------------------------------------------------
  # Button Settings:
  #-----------------------------------------------------------------------------
  # Set up a button for toggling the HUD at will during the game.
  # In case you want to give the option of hiding the HUD for the player, this
  # is just the thing you need. And why wouldn't you give that option, right?
  # Enter the symbol of the button you want to use.
  # Enter nil to disable this feature (not really recommended by me, thou).
  #-----------------------------------------------------------------------------
  ToggleHUD = :R
 
  #-----------------------------------------------------------------------------
  # Animation Settings:
  #-----------------------------------------------------------------------------
  # In case you want to show an animation on the player when he/she levels up,
  # you can enter an animation ID here.
  # Set it to 0 to disable this feature.
  #-----------------------------------------------------------------------------
  LvlAnim = 149
 
  #-----------------------------------------------------------------------------
  # Horizontal Fill Rate Settings:
  #-----------------------------------------------------------------------------
  # You have two options to draw the current rate of a stat with the horizontal
  # filling type of the bars:
  #
  #   :rect = This is the same as how every vertical gauge will operate.
  #           You have a fill rate image, and depending on the current rate of
  #           the stat, only a certain portion of that image will be drawn from
  #           the left side of the image. So, if the player got 50% from MP, the
  #           bar will only draw half of the image from the left side as is.
  #           This is good for unusual shaped bars without a foreground image,
  #           for example.
  # :stretch = The second mode instead will pack the whole image into a box, and
  #            the width and height of the box will depend on the current rate
  #            of the stat. Generally takes more processing time, but should
  #            not be noticeable.
  #-----------------------------------------------------------------------------
  HorzMode = :rect
 
  #-----------------------------------------------------------------------------
  # Data Display Settings:
  #-----------------------------------------------------------------------------
  # You can define what data to show on the map HUD here.
  # You can also set the bar's filling type up here.
  #
  # Available keys are:
  #   :hp, :mp, :tp, :xp
  # All of these can have a bar/gauge shown.
  #
  # Available filling type symbols:
  #   :vert, :horz
  # It should be obvious which one does what, right?
  # The vertical fill type will fill from down to up.
  # The horizontal fill type will fill from left to right.
  #
  # Any key missing from this hash setting will not be shown on the HUD at all!
  # So, if you want to hide, let's say, the TP bar, just comment out the :tp
  # settings, and it won't show up ever on the HUD.
  #-----------------------------------------------------------------------------
  HUDs = { # <-- No touchy-touchy!
    :hp => :horz,
    :mp => :horz,
    :tp => :vert,
    :xp => :horz,
  } # <-- No touchy-touchy!
   
  #-----------------------------------------------------------------------------
  # Dynamic Text Color Settings:
  #-----------------------------------------------------------------------------
  # In the case of HP, MP and TP value displays, it is possible to set up
  # different colors for the text depending on the percentage of current HP, MP
  # and TP respectively.
  # You can set up infinite amount of color changes here for each data.
  # If you are using my Picture Number Drawing script to display the values,
  # you can seet up style changes too here.
  #
  # Format:
  #
  # 1. Regular text based format:
  #  
  #     percentage => [Red,Blue,Green,Alpha],
  #
  #   So, 4 integer numbers in an array.
  #   Valid values are from 0 to 255 for all of them!
  #   Replace the percentage with an integer value from 0 to 100.
  #   0 = 0%, 25 = 25%, 100 = 100%, and so on.
  #
  # 2. Picture number drawing format:
  #
  #     percentage => ["image_file",row_index],
  #
  #   Replace the image_file with the name of the image you want to use.
  #   Replace the row_index with the index of the style you want to use from the
  #   image.
  #   The percentage means the same thing like at the regular text based format.
  #   Remember that the images used here must be in the folder you set in my
  #   Picture Number Drawing script!
  #
  # The settings must be from lowest to highest percentage values!
  #-----------------------------------------------------------------------------
  TxtColors = { # <-- No touchy-touchy!
    :hp => { # Settings for the HP display.
      10 => ["hpnums1va",2],
      33 => ["hpnums1va",0],
      100 => ["hpnums1va",1],
    },
    :mp => { # Settings for the MP display.
      10 => ["mpnums1va",2],
      33 => ["mpnums1va",0],
      100 => ["mpnums1va",1],
    },
    :tp => { # Settings for the TP display.
      99 => ["mpnums1va",0],
      100 => ["mpnums1va",2],
    }
  } # <-- No touchy-touchy!
   
  #-----------------------------------------------------------------------------
  # Advanced Data Display Settings:
  #-----------------------------------------------------------------------------
  # From here on, you can configure the details of your HP, MP, TP and XP bars.
  # Every data uses the same format!
  #
  # You can set up 3 static picture for each bar, but all of them are optional!
  # These are the :pic1, :pic2, and :pic3 settings.
  # You can simply omit any of them in case you don't wanna use all 3 for all
  # types of data.
  #
  # And you can set up a fill rate picture, that is the :fill setting.
  # The fill pictures got one simple rule to follow:
  # If you use the image for a vertical bar, the image used must not contain
  # any empty pixels on the top or on the bottom of the image, and if you use
  # it for a horizontal bar, it should not contain any empty pixels on the left
  # or right side of the picture!
  #
  # The settings for the :pic1, :pic2, :pic3 and :fill use the same format!
  # The available options are:
  #
  #   :img => "file name",
  # The name of the image file to use.
  # You don't have to use a boring, old and simple linear gauge image!
  # Spheres, swords, irregular shapes, all of them will work!
  #
  #   :pos => [x,y],
  # The X and Y position of the image.
  #
  #   :opa => value,
  # The opacity value for the image. Valid values: 0 - 255.
  #
  #   :z => value,
  # The Z value of the image, so you can set backgrounds and foregrounds too
  # for your fancy bars!
  #
  # The last setting is named :txt, and will let you set up the visuals of the
  # numeric displays for your HUD.
  # If you comment out or delete the :txt settings for a data, it will not have
  # a numeric display at all, only the bar itself!
  # The available options here are:
  #
  #   :style => type,
  # Two options here: :text or :picture.
  # :text will use the default text drawing method, while :picture will use my
  # picture number drawing method (requires my Picture Number Drawing script!).
  #
  #   :type => type,
  # This will determine how the numeric info will be shown.
  # You get 3 options (2 for the XP data!):
  #   :current = This will only display the current HP/MP/TP.
  #              Can NOT select this for the XP text!
  #   :direct = Will display the data like this: current / max .
  #   :percentage = Will display the data like this: percentage_value% .
  # In case you have set your :type to percentage, you will need to set up
  # another setting named :decimals for it.
  # Remember that you need a % and a . extra character set up in the Picture
  # Number Drawing script to show those characters for the :percentage type, and
  # you will need a / extra character set up for the :direct type!
  #
  #   :decimals => value,
  # The amount of decimals to display for the numeric data if the text's :type
  # is set to :percentage. Must be an integer number from 0 to infinity!
  # You don't need to set this up if the text's :type is not :percentage!
  #
  #   :img => ["image_file",row_index],
  # The style setup for the picture drawing method.
  # Replace the image_file with the name of the image you want to use.
  # Replace the row_index with the index of the style you want to use from the
  # image.
  #
  #   :pos1 => [x,y],
  # The X and Y position of the sprite which will contain the text display.
  #
  #   :pos2 => [x,y],
  # The text's X and Y position INSIDE the sprite used.
  # Since some text types got some unusual letters, it is wise to set the text's
  # position a few pixels from the edges, so it will be displayed correctly
  # without leftover pixels from the previous value display.
  #
  #   :size1 => [width,height],
  # The width and height of the bitmap created for the text.
  #
  #   :size2 => [width,height],
  # The width and height reserved for the text itself INSIDE the bitmap.
  # Do NOT use higher values than for the :size1 setup, or some text might get
  # cut down from the display!
  # The same reason as for :pos2, this ssetting has been made. If you see some
  # pixels left from a previous drawing, you might need to lower the size of
  # this setting and/or increase the size of the :size1 setting!
  # This should only matter for the regular drawing method, not for the image
  # based number drawing method!
  #
  #   :align => value,
  # The alignment used for the text. 0 = left, 1 = middle, 2 = right.
  #
  #   :font => [["type1","type2", ...],size],
  # The font settings for the text.
  # An array which contains another array and a single integer number.
  # Replace the "types" with the name of the font types you want to use.
  # Font types on the left in the font type array gets priority over the right
  # ones, so as soon as a valid type is detected on the system, that one will
  # be selected, the rest will be ignored.
  # Replace the size with the font size you want to use for the text.
  #
  #   :opa => value,
  # The opacity value for the text display. Valid values: 0 - 255.
  #
  #   :z => value,
  # The Z value of the sprite containing the text.
  #
  # And this is it! Have fun with designing cool gauges!
  #-----------------------------------------------------------------------------  
  HPBar = { # Settings for the HP display.
#~     :pic1 => {
#~       :img => "HPBackP2v2",
#~       :pos => [5,Graphics.height-59],
#~       :opa => 200,
#~       :z => 270,
#~     },
    :pic2 => {
      :img => "xpback2a",
      :pos => [35,38],
      :opa => 150,
      :z => 240,
    },
    :pic3 => {
      :img => "hpfore2a",
      :pos => [35,18],
      :opa => 240,
      :z => 260,
    },
    :fill => {
      :img => "hpfill2a",
      :pos => [40,40],
      :opa => 240,
      :z => 255,
    },
    :txt => {
      :style => :picture, :type => :direct,
      :img => ["hpnums1va",1],
      :pos1 => [-39,31],
      :pos2 => [190,0],
      :size1 => [200,60],
      :size2 => [200,60],
      :font => [["Parry Hotter","Old English Text MT"],36],
      :align => 2,
      :opa => 240,
      :z => 272,
    }
  } # <-- No touchy-touchy!
 
  MPBar = { # Settings for the MP display.
#~     :pic1 => {
#~       :img => "MPBackP2v2",
#~       :pos => [Graphics.width-197,Graphics.height-59],
#~       :opa => 200,
#~       :z => 270,
#~     },
    :pic2 => {
      :img => "xpback2a",
      :pos => [28,70],
      :opa => 150,
      :z => 240,
    },
    :pic3 => {
      :img => "mpfore2a",
      :pos => [28,50],
      :opa => 240,
      :z => 260,
    },
    :fill => {
      :img => "mpfill2a",
      :pos => [33,72],
      :opa => 240,
      :z => 255,
    },
    :txt => {
      :style => :picture, :type => :direct,
      :img => ["mpnums1va",1],
      :pos1 => [-46,63],
      :pos2 => [190,0],
      :size1 => [200,60],
      :size2 => [200,60],
      :font => [["Parry Hotter","Old English Text MT"],36],
      :align => 2,
      :opa => 240,
      :z => 272,
    }
  } # <-- No touchy-touchy!
 
  TPBar = { # Settings for the TP display.
    :pic1 => {
      :img => "tpback1a",
      :pos => [194,28],
      :opa => 150,
      :z => 220,
    },
    :pic3 => {
      :img => "tpfore2a",
      :pos => [216,104],
      :opa => 240,
      :z => 260,
    },
    :fill => {
      :img => "tpfill1a",
      :pos => [199,33],
      :opa => 240,
      :z => 255,
    },
  } # <-- No touchy-touchy!
 
  XPBar = { # Settings for the XP display.
    :pic1 => {
      :img => "xpback2a",
      :pos => [23,102],
      :opa => 150,
      :z => 200,
    },
    :pic3 => {
      :img => "xpfore2a",
      :pos => [23,82],
      :opa => 240,
      :z => 260,
    },
    :fill => {
      :img => "xpfill2a",
      :pos => [28,104],
      :opa => 240,
      :z => 220,
    },
    :txt => {
      :style => :picture, :type => :direct, :decimals => 2,
      :img => ["hpnums1va",0],
      :pos1 => [-51,95],
      :pos2 => [190,0],
      :size1 => [200,60],
      :size2 => [200,60],
      :font => [["Parry Hotter","Old English Text MT"],36],
      :align => 2,
      :opa => 240,
      :z => 272,
    }
  } # <-- No touchy-touchy!
 
  #-----------------------------------------------------------------------------
  # State/Buff Display Settings:
  #-----------------------------------------------------------------------------
  # Settings for the state/buff display.
  # All the state and buff icons will be displayed in an invisible window.
  # If there are more icons than what fits into the window, the icons will start
  # to scroll either horizontally or vertically.
  #
  #   :pos => [x,y],
  # The position of the state/buff display window.
  #
  #   :size => [width,height],
  # The size of the state/buff display window.
  #
  #   :opa => value,
  # The opacity of the state/buff display window. (0 - 255)
  #
  #   :z => value,
  # The Z value of the state/buff display window.
  #
  #   :anim => {:type => :horz/:vert, :speed => value, :wait => value},
  # The scrolling settings for the state/buff icons inside the window.
  # :type = The scroll type of the window.
  #         Can be :horz (horizontal) or :vert (vertical).
  # :speed = The speed of the scrolling. Measured in pixels.
  #          This many pixel will be scrolled in each frames when needed.
  #          Higher values mean quicker scrolling.
  # :wait = The wait time between changing scrolling directions.
  #         This many frames will the scrolling stop once it reached the
  #         last/first icon in the window. 60 = 1 second.
  #-----------------------------------------------------------------------------
  Icons = { # <-- No touchy-touchy!
    :pos => [78,104],
    :size => [4*24,24],
    :opa => 255,
    :z => 110,
    :anim => {:type => :horz, :speed => 2, :wait => 180},
  } # <-- No touchy-touchy!
 
end # <-- No touchy-touchy!
#===============================================================================
# End of settings! O.o
# Don't look below, someone may find out!
#===============================================================================
 
module Cache
 
  def self.maphud(filename)
    load_bitmap(SixthMapHUD::ImgFolder, filename)
  end
 
end
 
class Game_Actor < Game_Battler
 
  def get_xp_info
    s1 = exp - current_level_exp
    s2 = exp_for_level(level + 1) - current_level_exp
    if max_level?
      exp_rate = 1.0
    else
      exp_rate = s1.to_f / s2
    end
    return [s1,s2,exp_rate]
  end
 
  def xp_text(type,dec=0)
    inf = get_xp_info
    if max_level?
      txt = "-------"
    else
      case type
      when :direct
        t1 = inf[0]; t2 = inf[1]
        txt = t1.to_s + "/" + t2.to_s
      when :percentage
        txt = sprintf("%1.#{dec}f%",inf[2]*100)
      end
    end
    return txt
  end
   
  alias sixth_HUD7754 gain_exp
  def gain_exp(exp)
    if SceneManager.scene_is?(Scene_Map)
      change_exp(self.exp + (exp * final_exp_rate).to_i, false)
    else
      sixth_HUD7754(exp)
    end
  end
 
  alias sixth_HUD9908 level_up
  def level_up
    sixth_HUD9908
    if SceneManager.scene_is?(Scene_Map) && SixthMapHUD::LvlAnim != 0
      $game_player.animation_id = SixthMapHUD::LvlAnim
    end
  end
 
end
 
class Scene_Map < Scene_Base
 
  alias sixth_hpHUD7766 start
  def start
    @leadmp = [$game_party.members[0].mp,$game_party.members[0].mmp]
    @leadhp = [$game_party.members[0].hp,$game_party.members[0].mhp]
    @leadtp = [$game_party.members[0].tp,$game_party.members[0].max_tp]
    @leadxp = $game_party.members[0].get_xp_info
    @togglesw = $game_switches[SixthMapHUD::HUDSwitch]
    sixth_hpHUD7766
    init_HUD
    toggle_HUD($game_switches[SixthMapHUD::HUDSwitch])
  end
 
  def init_HUD
    @thehud = {}
    SixthMapHUD::HUDs.each do |sym,info|
      make_emHUD(sym,info)
    end
    update_fill_rates(true)
    init_icon_display
  end
 
  def init_icon_display
    pos = SixthMapHUD::Icons[:pos]
    sz = SixthMapHUD::Icons[:size]
    anim = SixthMapHUD::Icons[:anim]
    rect = Rect.new(pos[0],pos[1],sz[0],sz[1])
    @aicons = ScrollIcons.new(rect,$game_party.members[0],anim)
    @aicons.z = SixthMapHUD::Icons[:z]
  end
 
  def make_emHUD(sym,type)
    @thehud[sym] = {} if @thehud[sym].nil?
    case sym
    when :hp
      rate = $game_party.members[0].hp_rate
      inf = SixthMapHUD::HPBar
    when :mp
      rate = $game_party.members[0].mp_rate
      inf = SixthMapHUD::MPBar
    when :tp
      rate = $game_party.members[0].tp_rate
      inf = SixthMapHUD::TPBar
    when :xp
      rate = $game_party.members[0].get_xp_info[2]
      inf = SixthMapHUD::XPBar
    end
    [:pic1,:pic2,:pic3,:txt].each do |pic|
      next if inf[pic].nil?
      @thehud[sym][pic] = Sprite.new
      unless pic == :txt
      @thehud[sym][pic].bitmap = Cache.maphud(inf[pic][:img]) if !inf[pic][:img].nil?
        @thehud[sym][pic].x = inf[pic][:pos][0]
        @thehud[sym][pic].y = inf[pic][:pos][1]
      end
      @thehud[sym][pic].opacity = inf[pic][:opa]
      @thehud[sym][pic].z = inf[pic][:z]
    end
    if !inf[:txt].nil?
      @thehud[sym][:txt].bitmap = Bitmap.new(inf[:txt][:size1][0],inf[:txt][:size1][1])
      @thehud[sym][:txt].x = inf[:txt][:pos1][0]
      @thehud[sym][:txt].y = inf[:txt][:pos1][1]
      if inf[:txt][:style] == :picture
        @thehud[sym][:txt].bitmap.num_style = inf[:txt][:img]  
      else
        @thehud[sym][:txt].bitmap.font.name = inf[:txt][:font][0]
        @thehud[sym][:txt].bitmap.font.size = inf[:txt][:font][1]
      end
    end
    fillpic = Cache.maphud(inf[:fill][:img])
    yy = inf[:fill][:pos][1]; xx = inf[:fill][:pos][0]
    @thehud[sym][:fill] = SpritedBar1.new(xx,yy,fillpic,rate,sym) if type == :vert
    @thehud[sym][:fill] = SpritedBar2.new(xx,yy,fillpic,rate,sym) if type == :horz
    @thehud[sym][:fill].opacity = inf[:fill][:opa]
    @thehud[sym][:fill].z = inf[:fill][:z]
    @thehud[sym][:fill].update_fill_rate
  end
   
  alias sixth_hpHUD8888 update
  def update
    sixth_hpHUD8888
    update_HUD_fill
    update_fill_rates
    toggle_HUDinit if Input.trigger?(SixthMapHUD::ToggleHUD) && !$game_map.interpreter.running?
    if @togglesw != $game_switches[SixthMapHUD::HUDSwitch]
      toggle_HUD($game_switches[SixthMapHUD::HUDSwitch])
      @togglesw = $game_switches[SixthMapHUD::HUDSwitch]
    end
  end
 
  def update_HUD_fill
    @thehud.each do |sym,sprite|
      sprite[:fill].update
    end
  end
 
  def update_fill_rates(force=false)
    if ((@leadhp[0] != $game_party.members[0].hp || @leadhp[1] != $game_party.members[0].mhp) || force) && !@thehud[:hp][:txt].nil?
      change_txt_color(:hp,$game_party.members[0].hp_rate)
      case SixthMapHUD::HPBar[:txt][:type]
      when :direct
        txt = $game_party.members[0].hp.to_s + "/" + $game_party.members[0].mhp.to_s
      when :percentage
        txt = sprintf("%1.#{SixthMapHUD::HPBar[:txt][:decimals]}f%",$game_party.members[0].hp_rate*100)
      when :current
        txt = $game_party.members[0].hp
      end
      update_bar_txt(@thehud[:hp][:txt],SixthMapHUD::HPBar[:txt],txt)
      @leadhp = [$game_party.members[0].hp,$game_party.members[0].mhp]
    end
    if ((@leadmp[0] != $game_party.members[0].mp || @leadmp[1] != $game_party.members[0].mmp) || force) && !@thehud[:mp][:txt].nil?
      change_txt_color(:mp,$game_party.members[0].mp_rate)
      case SixthMapHUD::MPBar[:txt][:type]
      when :direct
        txt = $game_party.members[0].mp.to_s + "/" + $game_party.members[0].mmp.to_s
      when :percentage
        txt = sprintf("%1.#{SixthMapHUD::MPBar[:txt][:decimals]}f%",$game_party.members[0].mp_rate*100)
      when :current
        txt = $game_party.members[0].mp
      end
      update_bar_txt(@thehud[:mp][:txt],SixthMapHUD::MPBar[:txt],txt)
      @leadmp = [$game_party.members[0].mp,$game_party.members[0].mmp]
    end
    if ((@leadtp[0] != $game_party.members[0].tp || @leadtp[1] != $game_party.members[0].max_tp) || force) && !@thehud[:tp][:txt].nil?
      change_txt_color(:tp,$game_party.members[0].tp_rate)
      case SixthMapHUD::TPBar[:txt][:type]
      when :direct
        txt = $game_party.members[0].tp.to_i.to_s + "/" + $game_party.members[0].max_tp.to_s
      when :percentage
        txt = sprintf("%1.#{SixthMapHUD::TPBar[:txt][:decimals]}f%",$game_party.members[0].tp_rate*100)
      when :current
        txt = $game_party.members[0].tp.to_i
      end
      update_bar_txt(@thehud[:tp][:txt],SixthMapHUD::TPBar[:txt],txt)
      @leadtp = [$game_party.members[0].tp,$game_party.members[0].max_tp]
    end
    if (@leadxp != $game_party.members[0].get_xp_info || force) && !@thehud[:xp][:txt].nil?
      txt = $game_party.members[0].xp_text(SixthMapHUD::XPBar[:txt][:type],SixthMapHUD::XPBar[:txt][:decimals])
      update_bar_txt(@thehud[:xp][:txt],SixthMapHUD::XPBar[:txt],txt)
      @leadxp = $game_party.members[0].get_xp_info
    end    
  end
 
  def change_txt_color(sym,data)
    SixthMapHUD::TxtColors[sym].each do |key,val|
      if (data*100) <= key
        if val.size == 2
          @thehud[sym][:txt].bitmap.num_style = val
        else
          @thehud[sym][:txt].bitmap.font.color = Color.new(*val)
        end
        break
      end
    end
  end
   
  def update_bar_txt(bar,info,data)
    rect = Rect.new(0,0,info[:size1][0],info[:size1][1])
    bar.bitmap.clear_rect(rect)
    if info[:style] == :picture
      bar.bitmap.draw_numbers(info[:pos2][0],info[:pos2][1],data,255,info[:align])
    else
      rectt = Rect.new(info[:pos2][0],info[:pos2][1],info[:size2][0],info[:size2][1])
      bar.bitmap.draw_text(rectt,data,info[:align])
    end
  end
   
  def toggle_HUDinit
    $game_switches[SixthMapHUD::HUDSwitch] = !$game_switches[SixthMapHUD::HUDSwitch]
  end
 
  def toggle_HUD(opa)
    @thehud.each do |sym,sprites|
      if opa == true
        case sym
        when :hp
          inf = SixthMapHUD::HPBar
        when :mp
          inf = SixthMapHUD::MPBar
        when :tp
          inf = SixthMapHUD::TPBar
        when :xp
          inf = SixthMapHUD::XPBar
        end
      end
      sprites.each do |sym2,sprite|
        opac = opa == true ? inf[sym2][:opa] : 0
        sprite.opacity = opac
      end
    end
    opac = opa == true ? SixthMapHUD::Icons[:opa] : 0
    @aicons.contents_opacity = opac
  end
 
  def dispose_the_HUD
    @thehud.each do |sym,sprites|
      sprites.each do |sym2,sprite|
        sprite.bitmap.dispose
        sprite.dispose
      end
    end
  end
 
  alias sixth_hpHUD9986 dispose_spriteset
  def dispose_spriteset
    dispose_the_HUD
    sixth_hpHUD9986
  end
 
end
 
class SpritedBar1 < Sprite_Base
 
  def initialize(x,y,pic,rate,sym)
    super(nil)
    self.x = x; self.y = y
    @ori_y = self.y
    @rate = rate; @sym = sym
    self.bitmap = pic
    src_rect.height = self.bitmap.height * @rate
    src_rect.y = self.bitmap.height - src_rect.height
    self.y = @ori_y + src_rect.y
  end
 
  def update
    super
    update_rate
  end
 
  def update_rate
    case @sym
    when :hp
      if @rate != $game_party.members[0].hp_rate
        @rate = $game_party.members[0].hp_rate
        update_fill_rate
      end
    when :mp
      if @rate != $game_party.members[0].mp_rate
        @rate = $game_party.members[0].mp_rate
        update_fill_rate
      end
    when :tp
      if @rate != $game_party.members[0].tp_rate
        @rate = $game_party.members[0].tp_rate
        update_fill_rate
      end
    when :xp
      if @rate != $game_party.members[0].get_xp_info[2]
        @rate = $game_party.members[0].get_xp_info[2]
        update_fill_rate
      end
    when :timer
      if @rate != $game_timer.fill_rate
        @rate = $game_timer.fill_rate
        update_fill_rate
      end
    end
  end
 
  def update_fill_rate
    src_rect.height = self.bitmap.height * @rate
    src_rect.y = self.bitmap.height - src_rect.height
    self.y = @ori_y + src_rect.y
  end
 
end
 
class SpritedBar2 < Sprite_Base
 
  def initialize(x,y,pic,rate,sym)
    super(nil)
    self.x = x; self.y = y
    @rate = rate; @sym = sym; @pic = pic
    if SixthMapHUD::HorzMode == :rect
      self.bitmap = pic
    else
      self.bitmap = Bitmap.new(pic.width,pic.height)
    end
    update_fill_rate
  end
 
  def update
    super
    update_rate
  end
 
  def update_rate
    case @sym
    when :hp
      if @rate != $game_party.members[0].hp_rate
        @rate = $game_party.members[0].hp_rate
        update_fill_rate
      end
    when :mp
      if @rate != $game_party.members[0].mp_rate
        @rate = $game_party.members[0].mp_rate
        update_fill_rate
      end
    when :tp
      if @rate != $game_party.members[0].tp_rate
        @rate = $game_party.members[0].tp_rate
        update_fill_rate
      end
    when :xp
      if @rate != $game_party.members[0].get_xp_info[2]
        @rate = $game_party.members[0].get_xp_info[2]
        update_fill_rate
      end
    when :timer
      if @rate != $game_timer.fill_rate
        @rate = $game_timer.fill_rate
        update_fill_rate
      end
    end
  end
 
  def update_fill_rate
    if SixthMapHUD::HorzMode == :rect
      src_rect.width = self.bitmap.width * @rate
    else
      full_rect = Rect.new(0,0,@pic.width,@pic.height)
      new_rect = Rect.new(0,0,@pic.width*@rate,@pic.height)
      self.bitmap.clear_rect(full_rect)
      self.bitmap.stretch_blt(new_rect,@pic,full_rect,SixthMapHUD::XPBar[:fill][:opa])
    end
  end
 
end
 
unless $imported && $imported["SixthMenuEngine"]
class ScrollIcons < Window_Base
   
  def initialize(rect,actor,anim)
    @rect = rect
    @actor = actor; @icons = actor.state_icons; @anim = anim
    case @anim[:type]
    when :horz
      @w = @actor.state_icons.size*24; @h = rect.height
      @w = 1 if @w == 0
      @count = actor.state_icons.size > rect.width/24 ? @anim[:wait] : 0
    when :vert
      @w = rect.width; @h = @actor.state_icons.size*24
      @h = 1 if @h == 0
      @count = actor.state_icons.size > rect.height/24 ? @anim[:wait] : 0
    end
    @dir = :down
    super(rect.x,rect.y,rect.width,rect.height)
    self.opacity = 0
    self.arrows_visible = false
    draw_them_icons
  end
 
  def standard_padding
    0
  end
 
  def set_actor(actor)
    @actor = actor
    case @anim[:type]
    when :horz
      @count = @actor.state_icons.size > @rect.width/24 ? @anim[:wait] : 0
    when :vert
      @count = @actor.state_icons.size > @rect.height/24 ? @anim[:wait] : 0
    end
    self.ox = 0; self.oy = 0
    update_icons(true)
  end
 
  def contents_width
    @w
  end
 
  def contents_height
    @h
  end
 
  def draw_them_icons
    create_contents
    draw_actor_icons(@actor, 0, 0)
  end
   
  def draw_actor_icons(actor, x, y)
    icons = (actor.state_icons + actor.buff_icons)
    case @anim[:type]
    when :horz
      icons.each_with_index {|n, i| draw_icon(n, x + 24 * i, y) }
    when :vert
      icons.each_with_index {|n, i| draw_icon(n, x, y + 24 * i) }
    end
  end
   
  def update_scrolling_horz
    if @actor.state_icons.size > @rect.width/24
      if @count <= 0
        if @dir == :down
          if self.ox < (@actor.state_icons.size - @rect.width/24) * 24
            self.ox += @anim[:speed]
            self.ox = [self.ox,(@actor.state_icons.size - @rect.width/24) * 24].min
          end
          if self.ox == (@actor.state_icons.size - @rect.width/24) * 24
            @dir = :up
            @count = @anim[:wait]
          end
        elsif @dir == :up
          if self.ox > 0
            self.ox -= @anim[:speed]
            self.ox = [self.ox,0].max
          end
          if self.ox == 0
            @dir = :down
            @count = @anim[:wait]
          end
        end
      end
    elsif @actor.state_icons.size <= @rect.width/24
      self.ox = 0 if self.ox != 0
    end
    @count -= 1 if @count > 0
  end
 
  def update_scrolling_vert
    if @actor.state_icons.size > @rect.height/24
      if @count <= 0
        if @dir == :down
          if self.oy < (@actor.state_icons.size - @rect.height/24) * 24
            self.oy += @anim[:speed]
            self.oy = [self.oy,(@actor.state_icons.size - @rect.height/24) * 24].min
          end
          if self.oy == (@actor.state_icons.size - @rect.height/24) * 24
            @dir = :up
            @count = @anim[:wait]
          end
        elsif @dir == :up
          if self.oy > 0
            self.oy -= @anim[:speed]
            self.oy = [self.oy,0].max
          end
          if self.oy == 0
            @dir = :down
            @count = @anim[:wait]
          end
        end
      end
    elsif @actor.state_icons.size <= @rect.height/24
      self.oy = 0 if self.oy != 0
    end
    @count -= 1 if @count > 0
  end
 
  def update_icons(force=false)
    if @icons != @actor.state_icons || force
      case @anim[:type]
      when :horz
        @w = @actor.state_icons.size*24 if @w != @actor.state_icons.size*24
        @w = 1 if @w == 0
      when :vert
        @h = @actor.state_icons.size*24 if @h != @actor.state_icons.size*24
        @h = 1 if @h == 0
      end
      draw_them_icons
      @icons = @actor.state_icons
    end
  end
 
  def update
    super
    update_icons
    case @anim[:type]
    when :horz
      update_scrolling_horz
    when :vert
      update_scrolling_vert
    end
  end
 
end
end
#==============================================================================
# !!END OF SCRIPT - OHH, NOES!!
#==============================================================================