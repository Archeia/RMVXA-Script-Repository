class Game_Character < Game_CharacterBase
 
  unless method_defined?('actor')
    attr_accessor :actor
  end

end

class Game_Actor < Game_Battler
 
  attr_accessor :force_refresh
 
  alias fix_eqvis4311 change_equip
  def change_equip(*args)
    fix_eqvis4311(*args)
    @firce_refresh = true
  end
 
  alias fix_eqvis8881 release_unequippable_items
  def release_unequippable_items(*args)
    fix_eqvis8881(*args)
    @force_refresh = true
  end
 
end

class Sprite_Character
 
  alias fix_eqvis9927 graphic_changed?
  def graphic_changed?
    if @character.actor && @character.actor.force_refresh
      @character.actor.force_refresh = false
      return true
    end
    return fix_eqvis9927
  end
 
end