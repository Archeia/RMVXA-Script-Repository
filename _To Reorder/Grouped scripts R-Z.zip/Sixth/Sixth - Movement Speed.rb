#===============================================================================
# * [ACE] Movement Speed Altering Features
#===============================================================================
# * Made by: Sixth (www.rpgmakervxace.net, www.forums.rpgmakerweb.com)
# * Version: 1.1
# * Updated: 17/02/2018
# * Requires: -------
#-------------------------------------------------------------------------------
# * < Change Log >
#-------------------------------------------------------------------------------
# * Version 1.0 (04/10/2015)
#   - Initial release.
# * Version 1.1 (17/02/2018)
#   - Fixed the movement speed change for followers.
#-------------------------------------------------------------------------------
# * < Description >
#-------------------------------------------------------------------------------
# * This script will let you make features which can manipulate the player's
#   movement speed on the map.
# * These features can be assigned to:
#   - Actors
#   - Classes
#   - Enemies (requires Falcao's ABS)
#   - Equipment
#   - States
# * Settings for maximum/minimum bonuses gained from equipment.
# * Settings for absolute minimum and maximum movement speed.
# * The effect can be set to be dash-only.
# * The bonus can be gotten from the party leader's equipment only, or from
#   all active member's equipment (battle members).
# * If you use Falcao's ABS, you can manipulate the enemy event's movement
#   speed on the map too.
# * Disable switch for eventing purposes.
#------------------------------------------------------------------------------- 
# * < Note-Tags >
#-------------------------------------------------------------------------------
# Just note-tag your actors/classes/enemies/equipment/states with this note:
#
#   <speed bonus: +val>
#   <speed bonus: -val>
#
# Replace 'val' with the bonus percentage added/removed to/from the speed.
# Always use + for positive bonuses and - for negative ones!
# 
# Examples:
#
#   <speed bonus: +50>
# This makes the equip gain a "Movement Speed +50%" effect. If the player equips
# it, the movement speed will be raised significantly (by 50%).
#
#   <speed bonus: -20>
# This makes the equip gain a "Movement Speed -20%" effect. If the player equips
# it, the movement speed will be decreased by 20%.
#
# NOTE:
# These bonuses are stackable! Meaning all of your equipment's bonus will be 
# added together and the final value is used to determine the real bonus.
# For example, if the player got an equipment with +20% speed, another with +10%,
# and yet another with -15% speed effect, the final bonus will be:
# 20 + 10 - 15 = 15%
#
# You can choose which party members will affect the movement speed, the party 
# leader only, or the whole active party (battle members).
#------------------------------------------------------------------------------- 
# * < Installation >
#-------------------------------------------------------------------------------
# * Place this script below Materials but above Main!
#-------------------------------------------------------------------------------
# * < Compatibility Info >
#-------------------------------------------------------------------------------
# * No known incompatibilities.
#-------------------------------------------------------------------------------
# * < Known Issues >
#-------------------------------------------------------------------------------
# * No known issues.
#-------------------------------------------------------------------------------
# * < Terms of Use >
#-------------------------------------------------------------------------------
# * Free to use for whatever purposes you want.
# * Credit me (Sixth) in your game, pretty please! :P
# * Posting modified versions of this script is allowed as long as you notice me
#   about it with a link to it!
#===============================================================================
$imported = {} if $imported.nil?
$imported["SixthSpeedBonus"] = true
#===============================================================================
# Settings:
#===============================================================================
module SpeedBonus
  #-----------------------------------------------------------------------------
  # Player Bonus Source Settings:
  #-----------------------------------------------------------------------------
  # true = Only the leader's equips will be checked for speed bonuses.
  # false = All battle members' equips will be checked for speed bonuses.
  #-----------------------------------------------------------------------------
  LeaderOnly = true
  
  #-----------------------------------------------------------------------------
  # Player Bonus Type Settings:
  #-----------------------------------------------------------------------------
  # true = The bonus will only be applied when the player is running.
  # false = The bonus will be applied on walking and running alike.
  #-----------------------------------------------------------------------------
  DashOnly = false
  
  #-----------------------------------------------------------------------------
  # Disable Switch Settings:
  #-----------------------------------------------------------------------------
  # Set this setting to a switch ID. 
  # Whenever this switch is ON, the bonus speed effects will be ignored.
  # Useful for evented scenes, I guess.
  #-----------------------------------------------------------------------------
  DisableSwitch = 50
  
  #-----------------------------------------------------------------------------
  # Bonus Limit Settings:
  #-----------------------------------------------------------------------------
  # With these settings, you can limit the maximum and minimum amount of speed
  # bonus a character can get. These limits will be applied BEFORE the real
  # speed calculation, meaning they will limit the total bonus itself only.
  # The settings are in float values (0.2 means 20%, -0.42 means -42%, etc).
  # So, if the player got a total of +53% speed bonus, but the maximum cap is
  # set to be 0.4, the final bonus value will be +40% instead of +53%.
  #-----------------------------------------------------------------------------
  MaxBonus = 0.4
  MinBonus = -0.4
  
  #-----------------------------------------------------------------------------
  # Absolute Speed Limit Settings:
  #-----------------------------------------------------------------------------
  # In case you need to limit the movement speed AFTER the bonus addition, you
  # can set a limit here for both maximum and minimum cap.
  # This means that if the character's final speed value reached 10, but the 
  # maximum cap here is set to 8, it will be reduced to the value of the cap,
  # so, instead of being 10, it will be 8 at the end.
  # The minimum cap can NOT be lower than 1!
  #-----------------------------------------------------------------------------
  AbsMaxCap = 8
  AbsMinCap = 1
  
end
#===============================================================================
# End of Settings! Do not edit below this line unless pink pigs are flying!
#===============================================================================

class Game_CharacterBase

  alias add_equip_effs7643 real_move_speed
  def real_move_speed
    if self.is_a?(Game_Player) &&
       ((SpeedBonus::DashOnly == true && dash?) || SpeedBonus::DashOnly == false)
      base = add_equip_effs7643
      return base if $game_switches[SpeedBonus::DisableSwitch]
      base += base * $game_party.speed_bonus
      return [[base,SpeedBonus::AbsMinCap].max,SpeedBonus::AbsMaxCap].min
    elsif self.is_a?(Game_Event) && @enemy
      base = add_equip_effs7643
      return base if $game_switches[SpeedBonus::DisableSwitch]
      base += base * @enemy.speed_bonus
      return [[base,SpeedBonus::AbsMinCap].max,SpeedBonus::AbsMaxCap].min
    else
      return add_equip_effs7643
    end
  end

end

class Game_Party < Game_Unit

  def speed_bonus
    bonus = 0
    if SpeedBonus::LeaderOnly == true
      leader.feature_objects.each {|eq| bonus += eq.speed_bonus if !eq.nil? }
    else
      battle_members.each do |mem|
        mem.feature_objects.each {|eq| bonus += eq.speed_bonus if !eq.nil? }
      end
    end
    return [[bonus,SpeedBonus::MinBonus].max,SpeedBonus::MaxBonus].min
  end
  
end

class Game_Enemy < Game_Battler

  def speed_bonus
    bonus = 0
    feature_objects.each {|eq| bonus += eq.speed_bonus if !eq.nil? }
    return [[bonus,SpeedBonus::MinBonus].max,SpeedBonus::MaxBonus].min
  end
    
end

class RPG::BaseItem

  attr_accessor :speed_bonus
  
  def speed_bonus
    get_speed_bonus if @speed_bonus.nil?
    return @speed_bonus  
  end
  
  def get_speed_bonus
    @speed_bonus = @note =~ /<speed bonus: ([+\-]\d+)>/i ? $1.to_i * 0.01 : 0
    return @speed_bonus
  end
  
end
#==============================================================================
# !!END OF SCRIPT - OHH, NOES!!
#==============================================================================