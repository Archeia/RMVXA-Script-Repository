# Yeah, 3x3 grid is solid enough, if someone got only 4 active party member. 
# Well, I got 6, and 6 out of 9 slots didn't give me much choice of creating different formations,
# so I decided to modify the script for a 4x4 grid for more places and more possibilities.
# It is not a very hard edit, but I'm not sure that I remember every thing I changed in the script, 
# so I will just paste the whole script here, saving you the time of editing many little things,
# and also saving your time of reporting errors and my time of replying with corrections for them.
# NOTE: The following edited script is optimized for a game resolution of 800x600!
#    Many things are edited, and some things (like text and other info) will not show at all on lower resolution (out of screen).
#    You can, of course, edit any placement of texts/windows shown, or comment out anything that you don't want to show up, if you wish. 
# The following edited version of Vlue's Formation Bonus Script features:
# - All the related fixes/edits made by me mentioned above.
# - 4x4 grid (16 slots total) to place your actors on, gives much more possibilities of combinations.
# - Extra stats shown: Hit Rate, Critical Rate, Evasion.
# - Extra information shown: The selected actor's: Name, Title (requires Blackmourning's Title System Script)
# - Changed the actor's graphic shown in the Status Window of the Formation Bonus Scene.
#  Instead of the actor's sprite, it will now show the actor's face graphic.
# - The default help window is disabled. Instead of that, a new window is created which will display different text,
#  depending on where the active cursor is (in the character selection window or in the position selection window).
# - Text and information placement changed, some windows are resized and moved to suit 800x600 resolution. 
# Extra note: 
# While I actually implemented showing the Title of the actor's on this scene, I don't recommend using that Title script yet,
# because it got some compatibility issues with Yanfly's Class System Script. 
# The issue happens when you change your primary (main/default) class while having a title which gives stat increase equipped.
# I will try to fix this too, as a matter of fact, already tried it, but so far nothing I tried fixed it.
# But if you don't use Yanfly's Class System, you might as well ignore this note. 
# Things yet to be implemented:
# - While the position selection window is active (aka selecting the position of the selected actor), 
#     showing the movement of the actual selected actor's sprite graphic on the screen in real time.
#  If the cancel button is pressed, the actor would jump back to it's original placement.
# - Giving the bonus only to the actors present in the active formation. 
#  This would enable lesser formations with fewer battle members, like at the start of the game, 
#  without actually breaking the bigger formations designed for later stages of your game.
#  It would also enable the next thing on the list.
# - Multiple active formations at the same time (I thought about 2 at max, to not complicate it too much).
#  This one won't really be helpful unless you got 6 active battle members like me.
#  I want to be able to set my actors in lesser formations, like 3 in one formation, and 3 in another one.
#  Why? I will leave that to your imagination, the possibilities are almost endless!
# - Locked formations. 
#  That's right, I want to be able to lock every single formation until my lead character actually learns them in the game.
#  I think it should be obvious why, but for a simple example: to prevent OP formations on earlier stages of my game.
# This is all I can think of now, but my braincells are always thinking, so this list might expand,
# or get smaller when I (or anyone else) actually implement them. This is if Vlue allows it, of course. 
# Okay, time to actually post the script, right? Here it is: #Formation Bonus v1.2a - Edited by Sixth
#----------#
#Features: Rearrange actors by rows and make formations, granting bonuses
#           based on what row and formation the actors are in.
##Usage:    Plug and play, customize as needed.
##----------#
#-- Script by: V.M of D.T
##- Questions or comments can be:
#    posted on the thread for the script
#    given by email: sumptuaryspade@live.ca
#    provided on facebook: http://www.facebook.com/DaimoniousTailsGames##--- 
# Free to use in any project, commercial or non-commercial, with credit given
# - - Though a donation's always a nice way to say thank you~ (I also accept actual thank you's)
$imported = {} if $imported.nil?$imported["Formation-Bonus"] = true
#Location for actor sprites in battle (3x3 grid only right now):
#(Or not, made it 4x4 now! Yay!)
FORMATION_LOCATIONS = [  
  [375,200],[425,200],[475,200],[525,200],
  [395,230],[445,230],[495,230],[545,230],  
  [415,260],[465,260],[515,260],[565,260],  
  [435,290],[485,290],[535,290],[585,290]] 
  #Icon to be displayed as formation slot in the Formation Changing Scene.
  FORMATION_ICON = 430
  #Change in damage given/recieved based on row position:
  #Front row, middle left row, middle right row, back row
  FORMATION_ROW_ATK = [1.0, 0.8, 0.7, 0.5]
  FORMATION_ROW_DEF = [1.0, 0.8, 0.7, 0.5]
  FORMATION_ROW_MAT = [1.0, 1.0, 1.0, 1.0]
  FORMATION_ROW_MDF = [1.0, 1.0, 1.0, 1.0]
  FORMATION_ROW_TGR = [1.5, 1.0, 0.8, 0.6] 
  #The special Formations actors can be placed in:
  # id => { :name => "name of formation", :slots = [slots to be filled], ... }
  #   Slot ids are:#                   0, 1, 2, 3
  #                    4, 5, 6, 7
  #                     8, 9,10,11
  #                      12,13,14,15
  ##  Stat options are: :hp, :mp, :atk, :def, :mat, :mdf, :agi, :luk
  #  Formation bonuses apply to all actors.
  # Example:
  #  1 => { :name => "Back Row", :slots => [2,5,8], :hp => 20, :mp => 5,}
  FORMATION_BONUS = { 0 => {},  
  1 => { :name => "Caution!",  :slots => [2,5,6,9,10,14], :hp => 10, :mdf => 10,},  
  2 => { :name => "Retreat!",  :slots => [3,6,7,10,11,15], :mat => 10, :def => 10,},  
  3 => { :name => "Charge!",   :slots => [0,4,5,8,9,12], :atk => 10,},  
  4 => { :name => "Surround!", :slots => [1,4,7,8,11,13], :mdf => 10, :agi => 10,},  
  5 => { :name => "Pierce!",   :slots => [1,4,5,6,7,9], :atk => 10, :mat => 10, :luk => 10,},  
  6 => { :name => "Pierce!",   :slots => [5,8,9,10,11,13], :atk => 10, :mat => 10, :luk => 10,},  
  7 => { :name => "'X' Marks the Way!", :slots => [0,2,5,9,12,14], :hp => 5, :mp => 5, :atk => 5, :mat => 5,},  
  8 => { :name => "Tactical!", :slots => [3,4,6,8,10,15], :hp => 5, :mp => 5, :atk => 5, :def => 5, :mat => 5, :mdf => 5, :agi => 5, :luk => 5,}}
  class Game_Actor < Game_Battler  
  attr_accessor :formation_slot  
  alias formation_init initialize  
  alias formation_param param  
  def initialize(actor_id)    
  formation_init(actor_id)    
  @formation_slot = -1  
  end 
  #uncomment def screen_x and def screen_y if you don't use Yami's Battle Symphony  
  #def screen_x   
  # FORMATION_LOCATIONS[@formation_slot][0]  
  #end  
  #def screen_y  
  #  FORMATION_LOCATIONS[@formation_slot][1]  
  #end   
  def front_row?    
  [0,4,8,12].include?(@formation_slot)  
  end  def middle_left_row?    
  [1,5,9,13].include?(@formation_slot)  
  end  
  def middle_right_row?    
  [2,6,10,14].include?(@formation_slot)  
  end  
  def back_row?    
  [3,7,11,15].include?(@formation_slot)  
  end  
  def param(param_id)    
  sym = [:hp,:mp,:atk,:def,:mat,:mdf,:agi,:luk]    
  value = formation_param(param_id)    
  if $game_party.short_form[sym[param_id]]      
  value *= ($game_party.short_form[sym[param_id]] * 0.01 + 1)    
  end    
  [[value, param_max(param_id)].min, param_min(param_id)].max.to_i  
  end
  end 
 class Game_Enemy < Game_Battler  
  def front_row?    
  true  
  end  
  def middle_left_row?    
  false  
  end  
  def middle_right_row?    
  false  
  end  
  def back_row?    
  false  
  end
  end 
  class Game_Battler  
  def tgr    
  return sparam(0) * FORMATION_ROW_TGR[3]  if back_row?      
  return sparam(0) * FORMATION_ROW_TGR[2]  if middle_right_row?      
  return sparam(0) * FORMATION_ROW_TGR[1]  if middle_left_row?    
  return sparam(0) * FORMATION_ROW_TGR[0]  
  end  
  def make_damage_value(user, item)    
  value = item.damage.eval(user, self, $game_variables)    
  value *= item_element_rate(user, item)    
  value *= pdr if item.physical?    
  value *= mdr if item.magical?    
  value *= rec if item.damage.recover?    
  value *= row_defense if item.physical? && !item.damage.recover?    
  value *= row_attack(user) if item.physical? && !item.damage.recover?    
  value *= row_magic_attack(user) if item.magical? && !item.damage.recover?    
  value *= row_magic_defense if item.magical? && !item.damage.recover?    
  value = apply_critical(value) if @result.critical    
  value = apply_variance(value, item.damage.variance)    
  value = apply_guard(value)    
  @result.make_damage(value.to_i, item)  
  end  
  def row_defense    
  return FORMATION_ROW_DEF[1] if middle_left_row?    
  return FORMATION_ROW_DEF[2] if middle_right_row?    
  return FORMATION_ROW_DEF[3] if back_row?    
  return FORMATION_ROW_DEF[0]  
  end  
  def row_attack(user)    
  return FORMATION_ROW_ATK[3] if user.back_row?    
  return FORMATION_ROW_ATK[1] if user.middle_left_row?    
  return FORMATION_ROW_ATK[2] if user.middle_right_row?    
  return FORMATION_ROW_ATK[0]  
  end  
  def row_magic_defense    
  return FORMATION_ROW_MDF[1] if middle_left_row?    
  return FORMATION_ROW_MDF[2] if middle_right_row?    
  return FORMATION_ROW_MDF[3] if back_row?    
  return FORMATION_ROW_MDF[0]  
  end  
  def row_magic_attack(user)    
  return FORMATION_ROW_MAT[3] if user.back_row?    
  return FORMATION_ROW_MAT[2] if user.middle_right_row?    
  return FORMATION_ROW_MAT[1] if user.middle_left_row?    
  return FORMATION_ROW_MAT[0]  
  end
  end 
  class Game_Party  
  attr_accessor  :formation_id  
  def first_available_slot  
  end  
  def formation_slot(id)    
  battle_members.each do |actor|      
  return actor if actor.formation_slot == id    
  end    
  return nil  
  end  
  def formation_name    
  return current_formation[:name] if current_formation    
  return "-----"  
  end  
  def setup_starting_members    
  @actors = $data_system.party_members.clone    
  iter = 0    
  battle_members.each do |actor|      
  actor.formation_slot = iter      
  
  iter += 1   
  end    
  current_formation  
  end  
  def current_formation    
  FORMATION_BONUS.each do |sym, form|      
  next if sym == 0      
  valid = true      
  form[:slots].each do |val|        
  valid = false unless formation_slot(val)      
  end      
  next unless valid      
  @formation_id = sym      
  return FORMATION_BONUS[sym]    
  end    
  @formation_id = 0    
  return nil  
  end  
  def short_form    
  @formation_id = 0 unless @formation_id    
  FORMATION_BONUS[@formation_id]  
  end  
  def add_actor(actor_id)    
  return if @actors.include?(actor_id)    
  @actors.push(actor_id)    
  16.times do |i|      
  if formation_slot(i).nil?        
  $game_actors[actor_id].formation_slot = i        
  break      
  end    
  end    
  $game_player.refresh    
  $game_map.need_refresh = true  
  end  
  def remove_actor(actor_id)    
  return unless @actors.include?(actor_id)    
  @actors.delete(actor_id)    
  $game_actors[actor_id].formation_slot = -1    
  $game_player.refresh    
  $game_map.need_refresh = true  
  end
  end 
  class Scene_Formation < Scene_Base  
  def start    
  super       
  @list_window = Window_FormList.new    
  @list_window.y = 0    
  @list_window.set_handler:)ok, method:)list_ok))    
  @list_window.set_handler:)cancel, method:)list_cancel))     
  @bonus_window = Window_FormBonus.new    
  @form_window = Window_Formation.new    
  @form_window.set_handler:)ok, method:)form_ok))    
  @form_window.set_handler:)cancel, method:)form_cancel))    
  @stat_window = Window_FormStat.new    
  @stat_window.y = @list_window.height        
  @helpy_window = Window_Helpy.new
  #(@bonus_window.x, 0, @bonus_window.width, 48)    
  @helpy_window.x = @list_window.width    
  @helpy_window.width = @bonus_window.width        
  @list_window.select(0)    
  @list_window.activate  
  end  
  def update    
  super    
  if @list_window.active      
  @stat_window.set_actor(@list_window.current_item)   
  @helpy_window.contents.draw_text(0, 0, 300, 24, "Select a party member.", 0)    
  elsif @form_window.active      
  if @form_window.current_item  
  @stat_window.set_actor(@form_window.current_item)      
  else        
  @stat_window.set_actor(@list_window.current_item)              
  end      
  @helpy_window.contents.draw_text(0, 0, 300, 24, "Select a position.", 0)    
  end  
  end  
  def list_ok    
  @form_window.select(@list_window.current_item.formation_slot)  
  @form_window.activate    
  @helpy_window.refresh  
  end  
  def list_cancel    
  SceneManager.return  
  end  
  def form_ok    
  index = @form_window.current_index    
  actor = @list_window.current_item    
  if $game_party.formation_slot(index)
  $game_party.formation_slot(index).formation_slot = actor.formation_slot   
  end    
  actor.formation_slot = index    
  @form_window.refresh    
  @bonus_window.refresh   
  @stat_window.refresh    
  @helpy_window.refresh    
  form_cancel  
  end  
  def form_cancel    
  @form_window.select(-1)    
  @list_window.activate    
  @helpy_window.refresh  
  end
  end 
  class Window_Helpy < Window_Selectable   
  def initialize    
  super(Graphics.width/5*2, 0, Graphics.width/5*3, 48)    
  refresh  
  end    
  def refresh    
  contents.clear  
  end    
  def open    
  refresh    
  super  
  end  
  end 
  class Window_FormList < Window_Selectable  
  def initialize    
  super(0,48,Graphics.width/5*2, 24 * 7)    
  refresh  
  end  
  def item_max    
  $game_party.battle_members.size  
  end  
  def draw_item(index)    
  actor = $game_party.battle_members[index]    
  rect = item_rect(index)    
  draw_text(rect, actor.name)    
  draw_text(rect, "Lvl        ",2)    
  draw_text(rect, actor.level,2)  
  end  
  def current_item    
  return $game_party.battle_members[@index] if @index >= 0    
  return nil  
  end
  end 
  class Window_FormBonus < Window_Base  
  def initialize
  super(Graphics.width/5*2,48+(Graphics.height-48)/3*2,Graphics.width/5*3,(Graphics.height-48)/3)    
  refresh  
  end  
  def refresh    
  contents.clear    
  change_color(system_color)    
  draw_text(0,0,contents.width,line_height,"Bonuses:")    
  return unless $game_party.current_formation    
  change_color(normal_color)    
  form = $game_party.current_formation    
  xx = 6;yy = line_height;iter = 1    
  form.each do |key, val|      
  next unless [:hp,:mp,:atk,:def,:mat,:mdf,:agi,:luk].include?(key)      
  case key      
  when :hp        
  text = sprintf("%s %+d%", Vocab::hp, val.to_s)      
  when :mp        
  text = sprintf("%s %+d%", Vocab::mp, val.to_s)      
  when :atk        
  text = sprintf("%s %+d%", Vocab::param(2), val.to_s)      
  when :def        
  text = sprintf("%s %+d%", Vocab::param(3), val.to_s)      
  when :mat        
  text = sprintf("%s %+d%", Vocab::param(4), val.to_s)      
  when :mdf       
  text = sprintf("%s %+d%", Vocab::param(5), val.to_s)      
  when :agi        
  text = sprintf("%s %+d%", Vocab::param(6), val.to_s)      
  when :luk        
  text = sprintf("%s %+d%", Vocab::param(7), val.to_s)      
  end      
  draw_text(xx,yy,contents.width/3,line_height,text)      
  xx += contents.width/3      
  if iter % 3 == 0        
  xx = 5; yy += line_height      
  end      
  iter += 1    
  end  
  end
  end 
  class Window_Formation < Window_Selectable  
  def initialize   
  super(Graphics.width/5*2,48,Graphics.width/5*3,(Graphics.height-48)/3*2)    
  refresh  
  end  
  def refresh    
  contents.clear    
  xx = contents.width/4;yy = contents.height/3;iter = 0    
  4.times do      
  4.times do        draw_icon(FORMATION_ICON,xx,yy,$game_party.formation_slot(iter))        
  if $game_party.formation_slot(iter)   
  draw_actor_graphic($game_party.formation_slot(iter),xx-4,yy-16)        
  end        
  xx += 50       
  iter += 1      
  end     
  xx -= 200      
  yy += 30;xx += 20    
  end    
  change_color(system_color)    
  draw_text(0,0,contents.width,line_height,"Formation: ")
  change_color(normal_color)  
  draw_text(106,0,contents.width,line_height,$game_party.formation_name)  
  end  
  def item_rect(index)    
  xx = contents.width/4;yy = contents.height/3    
  xx += index % 4 * 50    
  xx += 20 * (index / 4).to_i    
  yy += 30 * (index / 4).to_i    
  Rect.new(xx,yy,24,24)  
  end  
  def col_max; 4; 
  end  
  def row_max; 4; 
  end  
  def item_max; 16; 
  end  
  def current_item    
  $game_party.formation_slot(@index)? 
  $game_party.formation_slot(@index):nil  
  end  
  def current_index    
  @index  
  end  
  def draw_actor_graphic(actor,x,y)    
  new_bitmap = Cache.character(actor.character_name)    
  next_bitmap = new_bitmap.clone    
  xx = actor.character_index % 4 * new_bitmap.width/4    
  yy = actor.character_index / 4 * new_bitmap.height/2 
  next_bitmap.blt(0,0,next_bitmap,Rect.new(xx,yy,next_bitmap.width/4,next_bitmap.height/2))    
  contents.blt(x,y,next_bitmap,Rect.new(0,next_bitmap.height/8,next_bitmap.width/12,next_bitmap.height/8))  
  end
  end 
  class Window_FormStat < Window_Base  
  def initialize    
  super(0,48+(24*7),Graphics.width/5*2,line_height*18)    
  refresh  
  end  
  def refresh    
  contents.clear    
  change_color(system_color)
  draw_text(standard_padding*2+88,0+12,contents.width,line_height,"Name:")    
  draw_text(standard_padding*2+88,line_height+12,contents.width,line_height,"Class:")    
  draw_text(standard_padding*2+88,line_height*2+12,contents.width,line_height,"Title:") 
  if $imported["Title-System"]    
  draw_text(75,line_height*4+8,contents.width/2,line_height,"Status:",1)    
  draw_text(75,line_height*5+10,contents.width/2,line_height,Vocab::param(0))    
  draw_text(75,line_height*6+10,contents.width/2,line_height,Vocab::param(1))    
  draw_text(75,line_height*7+10,contents.width/2,line_height,Vocab::param(2))    
  draw_text(75,line_height*8+10,contents.width/2,line_height,Vocab::param(3))    
  draw_text(75,line_height*9+10,contents.width/2,line_height,Vocab::param(4))    
  draw_text(75,line_height*10+10,contents.width/2,line_height,Vocab::param(5))    
  draw_text(75,line_height*11+10,contents.width/2,line_height,Vocab::param(6))    
  draw_text(75,line_height*12+10,contents.width/2,line_height,Vocab::param(7))    
  draw_text(75,line_height*13+10,contents.width/2,line_height,Vocab::x_param(0))    
  draw_text(75,line_height*14+10,contents.width/2,line_height,Vocab::x_param(2))    
  draw_text(75,line_height*15+10,contents.width/2,line_height,Vocab::x_param(1))    
  return unless @actor    
  change_color(normal_color)    
  draw_actor_face(@actor,0,0)    
  draw_text(-4,0+12,contents.width,line_height,@actor.name,2)    
  draw_text(-4,line_height*2+12,contents.width,line_height,Vocab.titles_name(@actor.title_id),2) 
  if $imported["Title-System"]    
  draw_text(75,line_height*5+10,contents.width/2,line_height,@actor.mhp,2)    
  draw_text(75,line_height*6+10,contents.width/2,line_height,@actor.mmp,2)    
  draw_text(75,line_height*7+10,contents.width/2,line_height,@actor.atk,2)    
  draw_text(75,line_height*8+10,contents.width/2,line_height,@actor.def,2)    
  draw_text(75,line_height*9+10,contents.width/2,line_height,@actor.mat,2)    
  draw_text(75,line_height*10+10,contents.width/2,line_height,@actor.mdf,2)    
  draw_text(75,line_height*11+10,contents.width/2,line_height,@actor.agi,2)    
  draw_text(75,line_height*12+10,contents.width/2,line_height,@actor.luk,2)    
  value1 = eval("@actor.#{:hit}") 
  text1 = sprintf("%d%", value1 * 100)    
  value2 = eval("@actor.#{:cri}") 
  text2 = sprintf("%d%", value2 * 100)    
  value3 = eval("@actor.#{:eva}") 
  text3 = sprintf("%d%", value3 * 100)
  draw_text(75,line_height*13+10,contents.width/2,line_height,text1,2)    
  draw_text(75,line_height*14+10,contents.width/2,line_height,text2,2)    
  draw_text(75,line_height*15+10,contents.width/2,line_height,text3,2)        
  if $imported["CXJ-ClassExtensions"]         
  if @actor.subclass.nil?        
  text = @actor.class.name      
  elsif !@actor.class.combined_name[@actor.subclass_id].nil?        
  text = @actor.class.combined_name[@actor.subclass_id]      
  else        
  fmt = YEA::CLASS_SYSTEM::SUBCLASS_TEXT        
  text = sprintf(fmt, @actor.class.name, @actor.subclass.name)      
  end        
  draw_text(-4,line_height+12,contents.width,line_height,text,2)              
  else    
  draw_text(-4,line_height+12,contents.width,line_height,@actor.class.name,2)      
  end    
  end   
  def set_actor(actor)    
  return if @actor == actor    
  @actor = actor    
  refresh  
  end
  end 
  #class Scene_Menu
  #  def command_formation
  #    SceneManager.call(Scene_Formation)
  #  end
  #end 
  #################################################################################
  # Uncomment this if you don't use (or don't know how to use) Yanfly's Menu Engine
  # to show the new command button in the main menu for this scene.
  #################################################################################
  =begin
  class Window_MenuCommand < Window_Command  
  alias formation1_command 
  add_original_commands  
  def add_original_commands    
  formation1_command    
  add_command("Formation1", :formation1)  end
  end
  =end
  #################################################################################
  # Uncomment this if you don't use (or don't know how to use) Yanfly's Menu Engine
  # to show the new command button in the main menu for this scene.
  ################################################################################# 
  if $imported["YEA-AceMenuEngine"] 
  #optional line 
  class Scene_Menu < Scene_MenuBase   #--------------------------------------------------------------------------  
  # * For Creating An Alias  
  #--------------------------------------------------------------------------   
  alias formation1_menu13211            
  create_command_window   #--------------------------------------------------------------------------  
  # * Create Command Window  #--------------------------------------------------------------------------   
  def create_command_window    
  formation1_menu13211()    
  @command_window.set_handler:)formation1,    method:)command_formation1))  
  end   
  #--------------------------------------------------------------------------  
  # * [Save] Command  #--------------------------------------------------------------------------  
  def command_formation1    
  SceneManager.call(Scene_Formation)  
  end 
  end
  end 
  #optional line 
  class Window_MenuCommand  
  def formation_enabled    
  true  
  end
  end 
  # This is it! Enjoy!