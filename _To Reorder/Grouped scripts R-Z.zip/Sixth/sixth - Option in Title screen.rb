class Window_TitleCommand < Window_Command
 
  alias add_opt_cmd7725 make_command_list
  def make_command_list
    add_opt_cmd7725
    cmd = {
      :name => "Options", # Change name here if needed.
      :symbol => :opts, # Do NOT change this line!
      :enabled => true, # Do NOT change this line!
    }
    @list.insert(2,cmd) # Change position here if needed. 0 = 1st command, 1 = 2nd, and so on...
  end
 
end
 
class Scene_Title < Scene_Base
 
  alias add_opt_cmd8654 create_command_window
  def create_command_window
    add_opt_cmd8654
    @command_window.set_handler(:opts,   method(:cmd_opts))
  end
 
  def cmd_opts
    SceneManager.call(Scene_Options)
  end
 
end