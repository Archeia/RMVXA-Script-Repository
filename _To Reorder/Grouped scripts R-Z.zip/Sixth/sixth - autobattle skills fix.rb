# In my project I'm using Yanfly's Autobattle script,
# It seems that when autobattle is on, characters can use skills
# even if they don't have the proper skill type for that skill

# Put it below the default scripts.
# It will filter out any skills belonging to a skill type which the 
# actor doesn't have currently in the skill type feature list

class Game_Actor < Game_Battler

  alias strip_list6414 make_action_list
  def make_action_list
    list = strip_list6414
    list.reject! {|act| ![*added_skill_types,0].include?(act.item.stype_id) }
    return list
  end

end