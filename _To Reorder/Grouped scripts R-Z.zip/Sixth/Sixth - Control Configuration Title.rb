#===============================================================================
# * [ACE] Control Configuration System - Title Command Addon
#===============================================================================
# * Made by: Sixth (www.rpgmakervxace.net, www.forums.rpgmakerweb.com)
# * Version: 1.0
# * Updated: 05/07/2017
# * Requires: -------
#-------------------------------------------------------------------------------
# * < Change Log >
#-------------------------------------------------------------------------------
# * Version 1.0 (05/07/2017)
#   - Initial release.
#-------------------------------------------------------------------------------
# * < Description >
#-------------------------------------------------------------------------------
# * Just a small script to add the control configuration menu to the title
#   commands.
#===============================================================================
#===============================================================================
# Settings:
#===============================================================================
module System
  #-----------------------------------------------------------------------------
  # Title Command Settings:
  #-----------------------------------------------------------------------------
  # These settings will adjust how the command button for the control
  # configuration menu will show up on the title screen.
  #
  # The settings are self-explanatory.
  #
  # As an extra info, you might wanna know that the :index can be set to
  # positive or negative numbers alike. If positive (including 0), the position
  # will be counted from the top of the command list, if negative, it will be
  # counted from the bottom of the list.
  # So, 0 means that it will be the first command, 1 means that it will be the
  # second command, and so on, but -1 means that it will be the last command on
  # the list, -2 means that it will be the second to last, and so on.
  #-----------------------------------------------------------------------------
  Title = {
    :show => true,       # Show or not? true = show, false = don't show.
    :name => "Controls", # Name of the command button.
    :index => -2,        # Placement of the command button.
  }
 
end
#===============================================================================
# End of Settings! Editing anything below may lead to... you know it, right?
#===============================================================================
 
class Window_TitleCommand < Window_Command
 
  alias add_control_cmd1232 make_command_list
  def make_command_list
    add_control_cmd1232
    return unless System::Title[:show]
    cmd = {
      :name => System::Title[:name], :symbol=> :controls,
      :enabled => true, :ext => nil
    }
    @list.insert(System::Title[:index],cmd)
  end
 
end
 
class Scene_Title < Scene_Base
 
  alias add_control_cmd9826 create_command_window
  def create_command_window
    add_control_cmd9826
    @command_window.set_handler(:controls, method(:controls_menu))
  end
 
  def controls_menu
    SceneManager.call(ConfScene)
  end
 
end
#==============================================================================
# !!END OF SCRIPT - OHH, NOES!!
#==============================================================================