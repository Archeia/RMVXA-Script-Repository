#===============================================================================
# * [ACE] Biography Scene + Morality System
#===============================================================================
# * Made by: Sixth (www.rpgmakervxace.net, www.forums.rpgmakerweb.com)
# * Version: 1.3
# * Updated: 22/01/2015
# * Requires: -------
#-------------------------------------------------------------------------------
# * < Change Log >
#-------------------------------------------------------------------------------
# * Version 0.1 (16/01/2015)
#   - Initial release (Alpha version).
# * Version 1.0 (18/01/2015)
#   - Full version release.
# * Version 1.1 (20/01/2015)
#   - Added multiple pages for the biography data.
#     Pages can be toggled on the Biography scene. Infinite pages available!
#     New script calls for adding or deleting any page from the biography data.
# * Version 1.2 (20/01/2015)
#   - Prevented every crash issue which could happen with the biography pages.
#   - A page will only be added to the biography if there is no page in the
#     current biography like the page entered into the script call!
#     This means that there is no chance to get duplicates!
#   - A page will only be deleted if there is at least 1 page left in the
#     biography after the deletion of the page! This means that there will
#     always be at least 1 page in the biography!
# * Version 1.3 (22/01/2015)
#   - Added a new option to set the starting page of the biography.
#-------------------------------------------------------------------------------
# * < Description >
#-------------------------------------------------------------------------------
# * This script makes a Biography scene for your game.
#   The Biography shows various information about the selected actors.
# * This script will also add a morality status for your actors.
#   I say morality, but it can be used for anything you want for.
# * The following data is available to be shown on the Biography scene:
#   - The actor's name, nickname, class, level, XP, HP, MP, TP and state info.
#   - Aside from the above default data, you can setup 5 custom text to be shown
#     for each actor. In the sample settings, I named them age, gender, weight,
#     height and the last one I used to show the actor's full name.
#   - Of course, you can write a fully customizable biography text for each
#     actor too. And from v1.1, you can even have multiple pages for your
#     biography data! Yayy!
#   - Two custom pictures can be shown for each actors.
#   - And the last one: the morality data. This comes with a unique gauge which
#     goes in two directions (left and right). The middle of the bar represents
#     neutrality, the left side of the gauge represents evil alignment, and the
#     right side of the bar represents good alignment. These are just examples,
#     it can be setup to be a faction alignment, a Love/Hate meter, etc.
#     Use your imagination!
# * All of the data shown is optional! Any of them can be turned off easily in
#   the script's settings.
# * Ability to use images for the scene!
#   You can build up the visuals of the scene with images too.
#   Infinite amount of images can be set up for the scene!
# * Script calls to change the actor's portrait, custom picture, biography text
#   and morality points during the game!
# * Script call to check for the actor's morality points!
#   Script call to check for the party's total morality level!
# * Tons of settings to configure!
#   Make your own unique scene however you want to!
#-------------------------------------------------------------------------------
# * < Script Calls >
#-------------------------------------------------------------------------------
# * To call the Biography scene in an event, you can use the following script
#   call:
#
#     SceneManager.call(Scene_SBio)
#
#   This will open the Biography scene.
#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
# * To change the biography text for an actor during the game, you can use the
#   following script call:
#
#     bio_change(id,[text],page)
#
#   id = The ID of the actor.
#   [text] = An array of strings. The strings are separated by commas!
#            Follows the same rules like the initial bio_text setup!
#   page = The specific biography page to be changed.
#          If you omit this setting, the new text will be added as a new page
#          and won't change any other pages in the biography.
#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
# * To delete a biography page for an actor during the game, you can use the
#   following script call:
#
#     bio_delete(id,page)
#
#   id = The ID of the actor.
#   page = The specific biography page to be deleted.
#          If you omit this setting, the last page will be deleted from the
#          biography.
#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
# * To change the portrait for an actor during the game, you can use the
#   following script call:
#
#     port_change(id,pic)
#
#   id = The ID of the actor.
#   pic = The name of the image file used for the new portrait.
#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
# * To change the custom picture for an actor during the game, you can use the
#   following script call:
#
#     pic_change(id,pic,index)
#
#   id = The ID of the actor.
#   pic = The name of the image file used for the new actor pic.
#   index = The index for the new actor pic used.
#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
# * To add/subtract morality points for an actor, you can use the following
#   script call:
#
#     moral_add(id,val)
#
#   id = The ID of the actor.
#   val = The amount of morality points to be added or subtracted.
#         Use negative values to subtract points!
#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
# * To set morality points to a specific value for an actor, you can use the
#   following script call:
#
#     moral_set(id,val)
#
#   id = The ID of the actor.
#   val = The value you want to set the morality of the actor to.
#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
# * To check for an actor's current morality level, you can use the following
#   script call:
#
#     check_moral(id,val,type)
#
#   id = The ID of the actor.
#   val = The value of the morality level you want to check for.
#   type = The type of the check. Valid options available: :pos, :neg, :equ.
#          :pos = The check will return true if the actor has equal or more
#                 morality points than the value you check for.
#          :neg = The check will return true if the actor has equal or less
#                 morality points than the value you check for.
#          :equ = The check will return true if the actor's morality points are
#                 equal with the value you check for.
#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
# * To check for the party's total morality level, you can use the following
#   script call:
#
#     check_party_moral(val,type,type2)
#
#   val = The value of the morality level you want to check for.
#   type = The type of check. Valid options available: :pos, :neg, :equ.
#          This means the same as for the above script call.
#   type2 = You can set 2 values here: :all or :battle.
#           :all = This check will include all party members in the calculation.
#        :battle = Only the battle members will be counted in the calculation.
#           If you omit this setting, :all will be selected by default.
#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
# * Examples:
#
#     bio_change(2,["text1 - 1st line.",
#                   "text2 - 2nd line.",
#                   "text3 - 3rd line."])
#
#   This would change the biography text used for the actor with the ID of 2.
#   The new biography text would look like this on the scene:
#   text1 - 1st line.
#   text2 - 2nd line.
#   text3 - 3rd line.
#   This text would go into a new page in the biography data.
#
#     bio_change(2,["text1 - 1st line.",
#                   "text2 - 2nd line.",
#                   "text3 - 3rd line."],3)
#
#   This would do the same as the above, but instead of creating a new page, it
#   would replace the 3rd page with the new text for the actor with the ID of 2.
#
#     bio_delete(1,2)
#
#   This would delete the second page from the biography for the actor with the
#   ID of 2.
#
#     bio_delete(3)
#
#   This would delete the last page from the biography for the actor with the
#   ID of 3.
#
#     port_change(3,"actor3port1")
#
#   This would change the portrait used for the actor with the ID of 3.
#   The new portrait's file name is: actor3port1.
#   The file name must be enclosed between quotation marks!
#
#     pic_change(1,"actor2",6)
#
#   This would change the pic picture used for the actor with the ID of 1.
#   The new pic picture's file name is: actor2.
#   The file name must be enclosed between quotation marks!
#   The index will determine which picture will be used from the sheet.
#   The index of 6 will take the 3rd picture from the bottom row.
#   More info about the sheet can be found below at the scripts settings!
#
#     moral_add(2,12)     moral_add(3,-32)
#
#   The 1st call would add 12 morality points to the actor with the ID of 2.
#   The 2nd call would subtract 32 morality points from the actor with the ID of 3.
#
#     moral_set(4,100)
#
#   This would set the morality points for the actor with the ID of 4 to 100.
#
#     check_moral(1,50,:pos)
#
#   This conditional check would return true if the actor with the ID of 1 has
#   equal or more morality points than 50.
#
#     check_moral(1,-40,:neg)
#
#   This conditional check would return true if the actor with the ID of 1 has
#   equal or less morality points than -40.
#
#     check_moral(1,-100,:equ)
#
#   This conditional check would return true if the actor with the ID of 1 has
#   exactly -100 morality points.
#
#     check_party_moral(50,:pos,:all)
#
#   This checks if the party's total morality points added up is higher than 50.
#   If it is, it returns true.
#-------------------------------------------------------------------------------
# * < Installation >
#-------------------------------------------------------------------------------
# * Place this script below Materials but above Main!
#-------------------------------------------------------------------------------
# * < Compatibility Info >
#-------------------------------------------------------------------------------
# * No known incompatibilities.
#-------------------------------------------------------------------------------
# * < Known Issues >
#-------------------------------------------------------------------------------
# * No known issues.
#-------------------------------------------------------------------------------
# * < Terms of Use >
#-------------------------------------------------------------------------------
# * Free to use for whatever purposes you want.
# * Credit me (Sixth) in your game, pretty please! :P
# * Posting modified versions of this script is allowed as long as you notice me
#   about it with a link to it!
#===============================================================================
$imported = {} if $imported.nil?
$imported["SixthBiography"] = true
#===============================================================================
# Settings:
#===============================================================================
# Basic notes:
#
# The color settings:
#
# You have two ways to setup every color options used for any settings:
#   1. If you enter a single number for them, the color will be taken from your
#      windowskin directly from the color palette.
#   2. If you enter an array, the direct RGB values will be used to determine
#      the color. The array must contain 4 numbers separated by commas, and they
#      represent RGBA values with 'A' being the opacity level!
#      Valid values for this range from 0 to 255 for each numbers!
#      A simple example: [255,255,255,255] <-- This is fully white!
#
# The font type settings:
#
# In any font type setup in the script, you must use an array with font type
# names in it. The font types must be separated by commas! These will be the
# font types for the setting you have configured. If the system can't find the
# 1st font type installed on the player's PC, it will look for the 2nd one. If
# the system can't find the 2nd one, it will look for the 3rd one on the list,
# and so on... You can setup as many font types for a setting as you want!
# It is recommended to setup at least 2 text types for these settings!
#===============================================================================
module Sixth_Actor_Bio
#===============================================================================
# System Settings:
#===============================================================================
# Set various system options up for your Biography scene here.
#===============================================================================
 
  # System folders for images used in the scene.
  # The first one is for the backgrounds.
  # The second one is for every other pictures for the actors (pics, portraits).
  # You can use the same folders for them if you wish.
  BioImg_Folder = "Graphics/Biography/System/"
  ActorImgFolder = "Graphics/Biography/Actors/"
 
  # Buttons used to trigger various events on the Biography scene.
  Button_Setup = { # <-- No touchy-touchy!
    :exit => :B,      # Button for exiting the menu.
    :prev => :LEFT,   # Button to switch to the previous actor.
    :next => :RIGHT,  # Button to switch to the next actor.
    :bio_prev => :L,  # Button to switch to the previous biography page.
    :bio_next => :R,  # Button to switch to the next biography page.
  } # <-- No touchy-touchy!
 
  # Sound settings.
  # Format:
  # :name => RPG::SE.new("file name",volume,pitch),
  Sound_Setup = { # <-- No touchy-touchy!
    :change => RPG::SE.new("Cursor2",  80, 100), # When switching actors.
    :exit =>   RPG::SE.new("Cancel2",  80, 100), # Upon exiting the scene.
    :change_bio => RPG::SE.new("Book2",  80, 100), # When switching bio pages.
  } # <-- No touchy-touchy!
 
  # You can set on which page will your biography start when you open the scene.
  # Two options are available:
  # 1. :newest = The biography will always start on the last page added.
  # 2. :first = The biography will always start on the first page.
  Bio_StartPage = :newest
 
#===============================================================================
# Page Indicator Settings:
#===============================================================================
# Setup the page indicator's properties here.
#
# Use 0 for the icon ID settings to disable icons.
# Use "" for the text settings to disable the texts.
#
# Page_Indicator is the previous/next actor indicator in the :title window.
# Page_Indicator2 is the biography page indicator in the :bio window.
#
# The prev/next actor indicator will show 2 configurable icons and
# configurable 2 texts.
# The biography page indicator will always show the currently selected page's
# number as well as 2 configurable icons.
#===============================================================================
  Page_Indicator = { # <-- No touchy-touchy!
    :icon1 => 588,  # Icon ID for the left icon.
    :icon2 => 589,  # Icon ID for the right icon.
    :ipos1 => [5,2],                 # Position for the left icon (x,y).
    :ipos2 => [Graphics.width-53,2], # Position for the right icon (x,y).
    :txt1 => "Prev Actor",  # Text for the left icon.
    :txt2 => "Next Actor",  # Text for the right icon.
    :tpos1 => [0,24],                 # Text position for the left side (x,y).
    :tpos2 => [Graphics.width-87,24], # Text position for the right side (x,y).
    :size => [120,24],           # Size reserved for the texts (width,height).
    :font => [["Arial"],16,17],  # Font type, size and color for the texts.
  } # <-- No touchy-touchy!
 
  Page_Indicator2 = { # <-- No touchy-touchy!
    :icon1 => 630,  # Icon ID for the left icon.
    :icon2 => 631,  # Icon ID for the right icon.
    :ipos1 => [100,291], # Position for the left icon (x,y).
    :ipos2 => [180,291], # Position for the right icon (x,y).
    :tpos => [124,291], # Text position for the left side (x,y).
    :size => [56,24],           # Size reserved for the texts (width,height).
    :font => [["Arial"],18,17],  # Font type, size and color for the texts.
  } # <-- No touchy-touchy!
 
#===============================================================================
# Menu Command Settings:
#===============================================================================
# Set the properties of the command button in the main menu here.
#
# Extra note:
#
# For people using Yanfly's Menu Engine, you can simply disable the Menu_Enable
# option here and do the following in Yanfly's script:
#
# Insert the following into the COMMANDS array setup anywhere you want the menu
# to show up:
#
#   :biography
#
# Insert the following into the CUSTOM_COMMANDS array setup anywhere you want:
#
#   :biography => ["Biography", 0, 0, :command_biography],
#
# Configure the line above to your liking. Refer to the instructions in
# Yanfly's script for the configuration options of that line. The command must
# remain :biography and the handler must remain :command_biography !
#===============================================================================
  # Enable/disable the menu button for the Biography here.
  Menu_Enable = true
 
  # Name of the Biography command in the main menu.
  Menu_Name = "Profile"
 
  # Hide/show the Biography command with the switch setup here.
  # Set it to 0 to always show the command.
  Menu_Hide_Switch = 0
 
  # Enable/disable the access of the Biography with the switch setup here.
  # Set it to 0 to always enable the access.
  Menu_Enable_Switch = 0
 
#===============================================================================
# Background Settings:
#===============================================================================
# You can setup unlimited amount of backgrounds for your Biography scene.
#
# Format:
#
#   :name => {
#     :graphic: => "image name",
#     :pos => [x,y],
#     :opacity => value, # 0 = transparent, 255 = no transparency at all.
#     :z => value,
#   },
#
# If you give the same z value to all of your backgrounds, than the backgrounds
# will be drawn on top of each other starting from the first one in the setup.
# You can name them however you want, but the name must be a symbol and they
# must use unique names, meaning no duplicates!
# Symbols start with a ":" sign.
#
# If you don't want any backgrounds, remove every setup from the hash, but make
# sure to leave the lines marked untouched!
#===============================================================================
  Background_Setup = { # <-- No touchy-touchy!
#~     :back1 => {
#~       :graphic => "actors background full1",
#~       :pos => [0,0],
#~       :opacity => 255,
#~       :z => 50,
#~     },
    # Add more backround setups here if you want!
  } # <-- No touchy-touchy!
 
#===============================================================================
# Window Settings:
#===============================================================================
# This is where you will setup the properties of each windows on the scene.
# You can shift and shape them however you want.
#
# Format:
#
#   :name => {
#     :pos => [x,y],
#     :size => [width,height],
#     :skin => "windowskin name",
#     :opacity => value, # 0 = transparent, 255 = no transparency at all.
#   },
#
# :title = The settings for the title window.
#          Used to display a single text and page indicators.
# :info  = The settings for the actor info window.
#          Used to display the actor's name, nickname, class, level, picture,
#          HP, MP, TP, XP, state info and a custom text.
# :bio   = The settings for the biography window.
#          Used to display the actor's age, gender, weight, height, morality,
#          biography text, portrait and a custom text.
#===============================================================================
  Window_Setup = { # <-- No touchy-touchy!
    :title => {
      :pos => [0,0],
      :size => [Graphics.width,70],
      :skin => "Window",
      :opacity => 255,
    },
    :info => {
      :pos => [0,70],
      :size => [Graphics.width,74],
      :skin => "Window",
      :opacity => 255,
    },
    :bio => {
      :pos => [0,144],
      :size => [Graphics.width,Graphics.height-144],
      :skin => "Window",
      :opacity => 255,
    },
  } # <-- No touchy-touchy!
 
#===============================================================================
# Text Settings:
#===============================================================================
# You can set various texts up here.
# Each of the settings got obvious names, so I guess, it is not needed to explain
# what each of them does and where will they show up.
# Use "" if you don't want to show any descriptive text for an information.
#===============================================================================
  Text_Setup = { # <-- No touchy-touchy!
    :title => "Profile",
    :progress => "",
    :name => "",
    :class => "Class",
    :level => "Lvl",
    :state => "",
    :hp_bar => "HP",
    :mp_bar => "MP",
    :tp_bar => "TP",
    :xp_bar => "Exp",
    :nickname => "Title",
    :age => "Age",
    :gender => "Gender",
    :weight => "Weight",
    :height => "Height",
    :bio_text => "Biography",
    :morality => "Morality",
    :custom1 => "",
  } # <-- No touchy-touchy!
 
#===============================================================================
# Data Display Settings:
#===============================================================================
# Select what data you want to show on the Biography scene.
# The following symbols are available:
#
#   :title    - Descriptive text, shown in the :title window. *
#   :progress - Custom text, shown in the :info window. *
#   :name     - Actor's name, shown in the :info window.
#   :class    - Actor's class, shown in the :info window.
#   :level    - Actor's level, shown in the :info window.
#   :state    - Actor's state icons and text, shown in the :info window.
#   :hp_bar   - Actor's HP with a gauge, shown in the :info window.
#   :mp_bar   - Actor's MP with a gauge, shown in the :info window.
#   :tp_bar   - Actor's TP with a gauge, shown in the :info window.
#   :xp_bar   - Actor's XP with a gauge, shown in the :info window.
#   :nickname - Actor's nickname, shown in the :info window.
#   :age      - Actor's age, shown in the :bio window. *
#   :gender   - Actor's gender, shown in the :bio window. *
#   :weight   - Actor's weight, shown in the :bio window. *
#   :height   - Actor's height, shown in the :bio window. *
#   :bio_text - Actor's biography text, shown in the :bio window. *
#   :morality - Actor's morality with a gauge, shown in the :bio window. *
#   :custom1  - Actor's custom text, shown in the :bio window. *
#   :pic     - Actor's picture, shown in the :info window.
#   :portrait - Actor's portrait, shown in the :bio window.
#
# Any data with it's symbol not present in the 'Show_Data' array will not be
# displayed.
# While the descriptions I gave for some of the symbols are pretty exact, a lot
# of them can be used however you want. These are marked with a * and are fully
# customizable and can be used to display whatever you want.
#===============================================================================
  Show_Data = [
    :title, :class, :level, :hp_bar, :mp_bar, :tp_bar, :xp_bar, :nickname,
    :age, :gender, :weight, :height, :bio_text, :morality, :custom1, :pic,
    :portrait,
  ]
 
#===============================================================================
# Font Settings:
#===============================================================================
# You can set up the fonts used for each type of information shown on the scene.
#
# Format:
#
#   :name => {
#     :type => ["font name","font name","font name", ... ],
#     :size => value,
#     :color => [color1,color2]
#   },
#
# color1 = The color of the descriptive texts you have setup above.
# color2 = The color of the actual data texts.
#
# Note that some color setups will be useless due to the data setup not having
# an actual second text. These will be marked, but just in case, I will write
# the info about them here too:
# All settings marked with this will use the 1st number in the array.
# The 2nd number (if present) can be either deleted or ignored.
# Make sure to keep the array brackets "[]" around them whatever you choose to do!
#
# The font setup for the :bio_text and :morality settings will use a different
# format! Those are explained right besides the settings!
# The :xp_bar setting will have an extra color option for the gauge color!
#===============================================================================
  Font_Setup = { # <-- No touchy-touchy!
    :title => {
      :type => ["Monotype Corsiva","Arial"],
      :size => 30,
      :color => [[185,100,255,255]], # Only 1 text available!
    },
    :progress => {
      :type => ["Monotype Corsiva","Arial"],
      :size => 26,
      :color => [[100,180,220,255]], # Only 1 text available!
    },
    :name => {
      :type => ["Monotype Corsiva","Arial"],
      :size => 24,
      :color => [[100,180,220,255],[255,255,255,255]],
    },
    :class => {
      :type => ["Monotype Corsiva","Arial"],
      :size => 24,
      :color => [[100,180,220,255],[255,255,255,255]],
    },
    :level => {
      :type => ["Monotype Corsiva","Arial"],
      :size => 24,
      :color => [[100,180,220,255],[255,255,255,255]],
    },
    :state => {
      :type => ["Monotype Corsiva","Arial"],
      :size => 24,
      :color => [[100,180,220,255]], # Only 1 text available!
    },
    :hp_bar => {
      :type => ["Monotype Corsiva","Arial"],
      :size => 24,
      :color => [[100,180,220,255]], # Only 1 text available!
    },
    :mp_bar => {
      :type => ["Monotype Corsiva","Arial"],
      :size => 24,
      :color => [[100,180,220,255]], # Only 1 text available!
    },
    :tp_bar => {
      :type => ["Monotype Corsiva","Arial"],
      :size => 24,
      :color => [[100,180,220,255]], # Only 1 text available!
    },
    :xp_bar => {
      :type => ["Monotype Corsiva","Arial"],
      :size => 24,
      :color => [[100,180,220,255]], # Only 1 text available!
      :gcolor => [30,31], # Colors for the XP gauge (left,right)!
    },
    :nickname => {
      :type => ["Monotype Corsiva","Arial"],
      :size => 24,
      :color => [[100,180,220,255],[255,255,255,255]],
    },
    :custom1 => {
      :type => ["Monotype Corsiva","Arial"],
      :size => 30,
      :color => [[100,180,220,255],[255,225,100,255]],
    },
    :age => {
      :type => ["Monotype Corsiva","Arial"],
      :size => 22,
      :color => [[100,180,220,255],[255,255,255,255]],
    },
    :gender => {
      :type => ["Monotype Corsiva","Arial"],
      :size => 22,
      :color => [[100,180,220,255],[255,255,255,255]],
    },
    :weight => {
      :type => ["Monotype Corsiva","Arial"],
      :size => 22,
      :color => [[100,180,220,255],[255,255,255,255]],
    },
    :height => {
      :type => ["Monotype Corsiva","Arial"],
      :size => 22,
      :color => [[100,180,220,255],[255,255,255,255]],
    },
    :bio_text => {
      :type1 => ["Monotype Corsiva","Arial"], # Descriptive text font type
      :size1 => 26,                           # Descriptive text font size
      :type2 => ["Comic Sans MS","Arial"],    # Biography data text font type
      :size2 => 18,                           # Biography data text font size
      :color => [[100,180,220,255],[255,255,255,255]], # Color setups.
    },
    :morality => {
      :type1 => ["Monotype Corsiva","Arial"], # Negative text font type
      :type2 => ["Monotype Corsiva","Arial"], # Positive text font type
      :type3 => ["Monotype Corsiva","Arial"], # Zero text font type
      :type4 => ["Monotype Corsiva","Arial"], # Descriptive text font type
      :size => [20,20,20,24], # Font size array, in order of the above type setup
      :color => [100,180,220,255], # Color setup for the descriptive text
    },
  } # <-- No touchy-touchy!
 
#===============================================================================
# Placement Settings:
#===============================================================================
# Set up the placement properties of each texts shown on the scene here.
#
# Format:
#
#   :name => {
#     :pos => [x,y],
#     :size => [width,height],
#     :align => [align1,align2], # 0 = left, 1 = middle, 2 = right.
#
#   # For the :pic setting only:
#     :opacity => value, # 0 = transparent, 255 = no transparency at all.
#    
#   # For the settings with gauges only:
#     :offset => [x,y], # Offsets for the descriptive texts on the gauges.
#
#   # For the :bio_text setting only:
#     :line_h => value, # Vertical distance between each texts for the bio info.
#   },
#
# align1 = The alignment for the descriptive text shown.
# align2 = The alignment for the actual data text shown.
#
# Note that some align setups will be useless due to the data setup not having
# an actual second text. These will be marked, but just in case, I will write
# the info about them here too:
# All settings marked with this will use the 1st number in the array.
# The 2nd number (if present) can be either deleted or ignored.
# Make sure to keep the array brackets "[]" around them whatever you choose to do!
#
# Some options will be missing from certain settings.
# Those are set automatically, so you don't have to set them up.
#
# The setup for the :bio_text and :morality settings will use a different
# format! Those are explained right besides the settings!
# Use odd numbers for the width of the morality bar to prevent display errors!
# The display errors are minor, barely noticeable, but still!
#===============================================================================
  InfoPos_Setup = { # <-- No touchy-touchy!
    :title => {
      :pos => [-1,0],
      :size => [Graphics.width-24,46],
      :align => [1], # Only 1 text available!
    },
    :progress => {
      :pos => [6,0],
      :size => [120,50],
      :align => [1], # Only 1 text available!
    },
    :pic => {
      :pos => [-8,0],
      :size => [50,50],
      :opacity => 255,
    },
    :name => {
      :pos => [200,0],
      :size => [140,24],
      :align => [0,0],
    },
    :class => {
      :pos => [85,0],
      :size => [170,24],
      :align => [0,2],
    },
    :level => {
      :pos => [34,4],
      :pos2 => [34,22],
      :size => [40,24],
      :align => [1,1],
    },
    :state => {
      :pos => [200,28],
      :size => [50,24],
      :align => [0], # Only 1 text available!
    },
    :hp_bar => {
      :pos => [85,26],
      :offset => [2,0],
      :size => [170,24],
      :align => [0], # Only 1 text available!
    },              
    :mp_bar => {
      :pos => [265,26],
      :offset => [2,0],
      :size => [170,24],
      :align => [0], # Only 1 text available!
    },                
    :tp_bar => {
      :pos => [445,26],
      :offset => [2,0],
      :size => [170,24],
      :align => [0], # Only 1 text available!
    },                
    :xp_bar => {
      :pos => [445,0],
      :offset => [2,0],
      :size => [170,24],
      :align => [0], # Only 1 text available!
    },                
    :nickname => {
      :pos => [265,0],
      :size => [170,24],
      :align => [0,2],
    },
    :custom1 => {
      :pos => [-4,4],
      :size => [360,32],
      :align => [1,1],
    },
    :age => {
      :pos => [6,50],
      :size => [135,24],
      :align => [0,2],
    },
    :gender => {
      :pos => [6,74],
      :size => [135,24],
      :align => [0,2],
    },
    :weight => {
      :pos => [151,50],
      :size => [135,24],
      :align => [0,2],
    },
    :height => {
      :pos => [151,74],
      :size => [135,24],
      :align => [0,2],
    },
    :bio_text => {
      :pos1 => [2,110],  # For the 'Text_Setup' descriptive text (x,y).
      :pos2 => [6,150],  # For the real actor biography data (x,y).
      :size => [340,28], # For the 'Text_Setup' descriptive text (width,height).
      :align => 1,       # For the 'Text_Setup' descriptive text.
      :line_h => 24,     # For the real actor biography data. Vertical spacing.
    },
    :morality => {
      :pos => [320,264],   # Gauge position (x,y).
      :tpos1 => [320,254], # Position for the negative moral texts (x,y).
      :tpos2 => [320,254], # Position for the positive moral texts (x,y).
      :tpos3 => [320,288], # Position for the zero (neutral) moral texts (x,y).
      :tpos4 => [320,244], # Descriptive text position (x,y).
      :t_height => 24,     # Descriptive text height.
      :size => [281,8],    # Gauge size (width,height) - odd values for width!
      :align => [0,2,1,1], # Text alignments in the order of the position setups!
    },
  } # <-- No touchy-touchy!
 
#===============================================================================
# Morality Info Settings:
#===============================================================================
# Setup the properties used for the morality display.
# Although I refer to this setting as "morality", it can be used to show any
# data you want, just use your imagination.
#
# The morality bar is an offset gauge, meaning the center of it is a neutral
# point, the left side means the evil side, while the right side is the good one.
# It uses 3 colors for the setup (left, middle and right colors).
#
# The morality setup looks like this:
#
#   :max => value,   # Maximum morality. Must use a positive number!
#   :min => -value,  # Minimum morality. Must use a negative number!
#   :limit => true/false, # Use limit for morality points?
#   :default => 0,   # Default starting morality for actors.
#   :max_color => color,  # Right side color for the gauge (positive moral).
#   :min_color => color,  # Left side color for the gauge (negative moral).
#   :zero_color => color, # Middle color for the gauge (zero moral).
#   :back_color => color, # Back color for the gauge.
#   :out_color => color,  # Outline color for the gauge.
#   :def_out => true/false, # Use outline for min-/max+ text?
#   :max_text => ["text",t.color,o.color], # Text setup for the max+ morale status.
#   :min_text => ["text",t.color,o.color], # Text setup for the min- morale status.
#   :text_setup => [  # Moral text setup.
#     ["text" ,req.points,t.color,use outline?,o.color]
#     ["text1", [min,max],  color,  true/false,  color],
#     ["text2", [min,max],  color,  true/false,  color],
#     ["text3", [min,max],  color,  true/false,  color],
#     ["text4", [min,max],  color,  true/false,  color],
#     ["text5", [min,max],  color,  true/false,  color],
#       .....
#   ],
#
# The min and max morality value must use the same integer numbers with min being
# a negative and max being a positive number!
#
# If you enable the limit function, the maximum and minimum points for the
# morality will be limited. It will never go above the value you have set up
# for the :max setting plus 1, and it will never go below the value you have
# set up for the :min setting minus 1!
# Plus and minus one, because I wanted to keep the ability of displaying the
# final texts in all circumstances.
#
# The actors will start with the default starting morality you have setup here
# unless you change it below at the 'Actor_Info_Setup' settings!
#
# The :max_text will be displayed when the actor have more morality points than
# the maximum value you have setup for the morality. The gauge color will also
# change and will be filled with the :max_color completely on the right side!
# The :min_text will be displayed when the actor have less morality points than
# the minimum value you have setup for the morality. The gauge color will also
# change and will be filled with the :min_color completely on the left side!
# The settings for both of them uses this format:
#
#     ["text",text color,outline color]
#
# The texts used for them will be outlined with the outline color you have setup
# for them if you have set the :def_out option to true.
#
# The text showing up on the morality gauge depends on your :text_setup settings.
# You can use as many text setup arrays as you want, but you must follow the
# same format for them as presented above and they must be separated with commas!
# The required points must cover all possible morality levels, meaning if you
# have setup 100 for max moral points and -100 for min moral points, than the
# required points from all the array setups must contain all numbers between
# -100 and +100! If some of them are missing, your text display won't be correct!
#===============================================================================
  Morality_Setup = { # <-- No touchy-touchy!
    :max => 100,   # Max morality.
    :min => -100,  # Min morality.
    :limit => false, # Use limit for morality points?
    :default => 0, # Default starting morality for actors.
    :max_color => 11,  # Gauge right side color (positive moral).
    :min_color => 10,  # Gauge left side color (negative moral).
    :zero_color => 17, # Gauge middle color (zero moral).
    :back_color => [30,30,30,180],    # Gauge back color.
    :out_color => [160,160,160,200],  # Gauge outline color.
    :def_out => true, # Use outline for min-/max+ text?
    :max_text => ["Angel", 29, 30], # ["text",t.color,o.color]
    :min_text => ["Devil", 10, 20], # ["text",t.color,o.color]
    :text_setup => [  # Moral text settings.
    # ["text",  req.points, t.color,outline,o.color]
      ["Evil",   [-100,-51],     10,  false,     20],
      ["Bad",      [-50,-1],      2,  false,      0],
      ["Neutral",     [0,0],     17,  false,      0],
      ["Good",       [1,50],     28,  false,      0],
      ["Saint",    [51,100],     29,  false,     29],
    ],
  } # <-- No touchy-touchy!
 
#===============================================================================
# Actor Info Settings:
#===============================================================================
# Set up information used on the scene for each actors here.
#
# Format:
#
#   ID => {
#     :portrait => ["img name",[x pos,y pos],opacity],
#     :pic => ["img name",index],
#     :age => "text",
#     :gender => "text",
#     :weight => "text",
#     :height => "text",
#     :morality => value,
#     :custom1 => "text",
#     :bio_text => [ # <-- Starting the biography text here!
#
#       ["text1 - 1st line","text2 - 2nd line",  <--|
#        "text3 - 3rd line","text4 - 4th line",     |-- 1st page of the biography!
#               ...        ,"textn - nth line"], <--|
#
#       ["text1 - 1st line","text2 - 2nd line",  <--|
#        "text3 - 3rd line","text4 - 4th line",     |-- 2nd page of the biography!
#               ...        ,"textn - nth line"], <--|
#
#       # More pages like the above goes here if desired.
#
#     ], # <-- Ending the biography text here!
#   },
#
# The ID represents the ID of the actors. You need to make a setup for each of
# your actors here.
# As you can see, the age, gender, weight, height and the custom1 data uses
# simple texts. While I named them how I named them, you can use these to display
# any data you want, so you are not restricted to age, weight, etc data only!
#
# The bio_text data uses an array with multiple small arrays.
# Each small array will define a page for the biography data.
# Each small array must be separated with a comma!
# The small arrays will have texts set up in them.
# Each text will be drawn on a new line. Separate each text with a comma!
# You can use any valid message codes in the texts!
# You can setup as many lines as you want!
# You can setup as many pages as you want!
#
# The :morality will be the starting morality for the actor. If you don't set
# this up for an actor, than the actor will take the default starting morality!
#
# The images for the portraits and pictures must be in the folder you have set
# up at the 'ActorImgFolder' settings!
#
# The images for the portraits are simple images without any extra setup needed.
# I haven't put them into any sheet, because depending on the size of them
# (width and height), the sheet could reach some pretty big sizes both in width
# and height and in bytes.
#
# The images for the pictures in the info window, however, use the same format
# as the face picture images, meaning it must be a 4x2 sheet which looks like
# this:
#
#   -----------------
#   | 0 | 1 | 2 | 3 |   # The numbers mean the corresponding indexes for the
#   |----------------   # pictures. You must assign an index for each picture
#   | 4 | 5 | 6 | 7 |   # settings!
#   -----------------
#
# I made it like that to reduce the amount of files for the custom pictures.
# The width and height of each picture on the image must be the same width and
# height you have set up for the :pic info at the 'InfoPos_Setup' settings!
#===============================================================================
  Actor_Info_Setup = { # <-- No touchy-touchy!
    1 => {
      :portrait => ["bust1-A",[325,0],255],
      :pic => ["Actor2test",2],
      :age => "44",
      :gender => "Male",
      :weight => "81 Kg",
      :height => "179 Cm",
      :morality => 0,
      :custom1 => "Danny Salrock",
      :bio_text => [
            # 1st page.
             ["Marveck Academy 1st class protic scientist.",
              "He was the one who invented the protic stones.",
              "Despite his invaluable product, the world forgot him.",
              "Currently searching for the legendary Polarities.",
              "Very stubborn person with high level of arrogance.",
              "Food is the only thing that can melt his heart."],
            # 2nd page.
             ["Let's test the second page, alright?",
              "So, apparently, this is the second page.",
              "Third line, etc, etc yadda yadda..."],
        ],
    },
    2 => {
      :portrait => ["bust3-A",[325,0],255],
      :pic => ["Actor2test",0],
      :age => "28",
      :gender => "Male",
      :weight => "85 Kg",
      :height => "189 Cm",
      :morality => -70,
      :custom1 => "Raiden Lenorich",
      :bio_text => [
            # 1st page.
             ["A soldier from the Solitude Mercenary Center.",
              "He left the mercenary center, reasons unknown.",
              "Officially the best sniper in the year of 243 AC.",
              "Often gets violent without any provocation.",
              "Usually, the leading member of bar-fights.",
              "Friend or enemy? Can't say for sure yet."],
        ],
    },
    3 => {
      :portrait => ["bust2-A",[325,0],255],
      :pic => ["Actor2test",1],
      :age => "26",
      :gender => "Female",
      :weight => "56 Kg",
      :height => "164 Cm",
      :morality => 70,
      :custom1 => "Sophie Taramis",
      :bio_text => [
            # 1st page.
             ["A hunter from the Hordal Tribes living in the woods.",
              "A kind and selfless woman, helping those in need.",
              "It seems like she can talk with the animals.",
              "Knows a bit about curative herbs and poisons.",
              "She values life and peace over everything else.",
              "Never resorts to violence unless it's necessary."],
            # 2nd page.
             ["Let's test the second page, alright?",
              "So, apparently, this is the second page.",
              "Third line, etc, etc yadda yadda..."],
            # 3rd page.
             ["And this is the 3rd page?",
              "So, apparently, this is the 3rd page.",
              "Third line, etc, etc yadda yadda..."],
        ],
    },
  } # <-- No touchy-touchy!
   
end # <-- No touchy-touchy!
#===============================================================================
# End of Settings! Editing anything below may lead to... You know what, right?
#===============================================================================
 
module Cache
 
  def self.bio(filename)
    load_bitmap(Sixth_Actor_Bio::BioImg_Folder, filename)
  end
 
  def self.bio_pic(filename)
    load_bitmap(Sixth_Actor_Bio::ActorImgFolder, filename)
  end
 
end
 
module DataManager
 
  class << self
    alias sixth_bio_create_objects        create_game_objects
    alias sixth_bio_save_contents         make_save_contents
    alias sixth_bio_extract_contents      extract_save_contents
  end
 
  def self.create_game_objects
    sixth_bio_create_objects
    $bio = Game_Bio.new
  end
 
  def self.make_save_contents
    contents = sixth_bio_save_contents
    contents[:biography] = $bio
    contents
  end
 
  def self.extract_save_contents(contents)
    sixth_bio_extract_contents(contents)
    $bio = contents[:biography]
  end
 
end
 
class Game_Bio_Info
 
  attr_accessor  :text, :port, :pic, :morality, :tmax
 
  def initialize(bio_id)
    @bio_id = bio_id
    @bio_info = Sixth_Actor_Bio::Actor_Info_Setup[@bio_id]
    @text = @bio_info[:bio_text]
    @tmax = @bio_info[:bio_text].size
    @port = @bio_info[:portrait][0]
    @pic = @bio_info[:pic]
    @morality = !@bio_info[:morality].nil? ? @bio_info[:morality] : Sixth_Actor_Bio::Morality_Setup[:default]
  end
   
end
 
class Game_Bio
 
  def initialize
    @bio = {}
  end
   
  def [](bio_id)
    return nil unless Sixth_Actor_Bio::Actor_Info_Setup[bio_id]
    @bio[bio_id] ||= Game_Bio_Info.new(bio_id)
  end
 
end
 
class Game_Actor < Game_Battler
 
  def get_xp_info
    s1 = exp - current_level_exp
    s2 = exp_for_level(level + 1) - current_level_exp
    if max_level?
      exp_rate = 1.0
    else
      exp_rate = s1.to_f / s2
    end
    return [s1,s2,exp_rate]
  end
 
end
 
class Scene_SBio < Scene_Base
  include Sixth_Actor_Bio
 
  def start
    super
    create_variables
    create_backgrounds if Background_Setup != {}
    create_all_windows
  end
 
  def create_backgrounds
    Background_Setup.each_key do |sym|
      draw_the_background(sym)
    end
  end
 
  def draw_the_background(sym)
    @backs[sym] = Sprite.new
    @backs[sym].bitmap = Cache.bio(Background_Setup[sym][:graphic])
    @backs[sym].x = Background_Setup[sym][:pos][0]
    @backs[sym].y = Background_Setup[sym][:pos][1]
    @backs[sym].opacity = Background_Setup[sym][:opacity]
    @backs[sym].z = Background_Setup[sym][:z]
  end
 
  def create_all_windows
    create_title_window
    create_actor_info_window
    create_bio_window
  end
 
  def create_variables
    @current = 0
    @old = 0
    @max = $game_party.members.size - 1
    @backs = {}
    @bio_max = $bio[$game_party.members[@current].id].tmax - 1
    @start_bio = Bio_StartPage == :newest ? @bio_max : 0
    @old_bio = @start_bio
    @current_bio = @start_bio
  end
 
  def create_title_window
    @title = Bio_Title.new
  end
 
  def create_actor_info_window
    @info = Bio_Info.new
  end
 
  def create_bio_window
    @bio = Bio_Bio.new
  end
 
  def update
    super
    process_system_buttons
    process_change_actors if @max > 0
    process_change_bio_text if @bio_max > 0
  end
 
  def process_system_buttons
    if Input.trigger?(Button_Setup[:exit])
      Sound_Setup[:exit].play
      return_scene
    end
  end
 
  def process_change_actors
    if Input.trigger?(Button_Setup[:prev])
      Sound_Setup[:change].play
      @current -= 1
      if @current < 0
        @current = @max
      end
    elsif Input.trigger?(Button_Setup[:next])
      Sound_Setup[:change].play
      @current += 1
      if @current > @max
        @current = 0
      end
    end
    if @old != @current
      @bio_max = $bio[$game_party.members[@current].id].tmax - 1
      @start_bio = Bio_StartPage == :newest ? @bio_max : 0
      @title.refresh(@current)
      @info.refresh($game_party.members[@current])
      @bio.refresh($game_party.members[@current],@start_bio)
      @current_bio = @start_bio
      @old = @current
    end
  end
 
  def process_change_bio_text
    if Input.trigger?(Button_Setup[:bio_prev])
      Sound_Setup[:change_bio].play
      @current_bio -= 1
      if @current_bio < 0
        @current_bio = @bio_max
      end
      while $bio[$game_party.members[@current].id].text[@current_bio].nil?
        @current_bio -= 1
      end
    elsif Input.trigger?(Button_Setup[:bio_next])
      Sound_Setup[:change_bio].play
      @current_bio += 1
      if @current_bio > @bio_max
        @current_bio = 0
      end
      while $bio[$game_party.members[@current].id].text[@current_bio].nil?
        @current_bio += 1
      end
    end
    if @old_bio != @current_bio
      @bio.refresh($game_party.members[@current],@current_bio)
      @old_bio = @current_bio
    end
  end
 
  def dispose_backgrounds
    @backs.each_key do |sym|
      @backs[sym].bitmap.dispose
      @backs[sym].dispose
    end
  end
 
  def return_scene
    dispose_backgrounds
    super
  end
 
end
 
class Window_Base < Window
  include Sixth_Actor_Bio
 
  def get_color_sixth(color)
    if color.is_a?(Integer)
      return text_color(color)
    else
      return Color.new(*color)
    end
  end
 
  def change_the_font(type,size)
    contents.font.name = type
    contents.font.size = size
  end
 
  def draw_text_ex_s(x, y, text)
    text = convert_escape_characters(text)
    pos = {:x => x, :y => y, :new_x => x, :height => calc_line_height(text)}
    process_character(text.slice!(0, 1), text, pos) until text.empty?
  end
 
  def draw_bio_info(sym,data=nil,pos2=nil)
    return unless Show_Data.include?(sym)
    change_the_font(Font_Setup[sym][:type],Font_Setup[sym][:size])
    change_color(get_color_sixth(Font_Setup[sym][:color][0]))
    i = InfoPos_Setup[sym]
    draw_text(i[:pos][0],i[:pos][1],i[:size][0],i[:size][1],Text_Setup[sym],i[:align][0])
    if !data.nil?
      change_color(get_color_sixth(Font_Setup[sym][:color][1]))
      if !pos2.nil?
        draw_text(pos2[0],pos2[1],i[:size][0],i[:size][1],data,i[:align][1])
      else
        draw_text(i[:pos][0],i[:pos][1],i[:size][0],i[:size][1],data,i[:align][1])
      end
    end
  end
 
end
 
class Bio_Title < Window_Base
  include Sixth_Actor_Bio
 
  def initialize
    pos = Window_Setup[:title][:pos]
    size = Window_Setup[:title][:size]
    super(pos[0],pos[1],size[0],size[1])
    self.windowskin = Cache.system(Window_Setup[:title][:skin])
    self.opacity = Window_Setup[:title][:opacity]
    refresh(0)
  end
   
  def refresh(index)
    contents.clear
    draw_bio_info(:title)
    draw_page_indicator(index)
  end
 
  def draw_page_indicator(index)
    i = Page_Indicator
    change_the_font(i[:font][0],i[:font][1])
    change_color(get_color_sixth(i[:font][2]))
    if $game_party.members.size == 1
      a1 = a2 = translucent_alpha
      draw_icon(i[:icon1],i[:ipos1][0],i[:ipos1][1],false)
      draw_icon(i[:icon2],i[:ipos2][0],i[:ipos2][1],false)
    elsif index == $game_party.members.size - 1
      a1 = 255; a2 = translucent_alpha
      draw_icon(i[:icon1],i[:ipos1][0],i[:ipos1][1])
      draw_icon(i[:icon2],i[:ipos2][0],i[:ipos2][1],false)
    elsif index == 0
      a2 = 255; a1 = translucent_alpha
      draw_icon(i[:icon1],i[:ipos1][0],i[:ipos1][1],false)
      draw_icon(i[:icon2],i[:ipos2][0],i[:ipos2][1])
    else
      a1 = 255; a2 = 255
      draw_icon(i[:icon1],i[:ipos1][0],i[:ipos1][1])
      draw_icon(i[:icon2],i[:ipos2][0],i[:ipos2][1])
    end
    contents.font.color.alpha = a1
    draw_text(i[:tpos1][0],i[:tpos1][1],i[:size][0],i[:size][1],i[:txt1])
    contents.font.color.alpha = a2
    draw_text(i[:tpos2][0],i[:tpos2][1],i[:size][0],i[:size][1],i[:txt2])
  end
 
end
 
class Bio_Info < Window_Base
  include Sixth_Actor_Bio
 
  def initialize
    pos = Window_Setup[:info][:pos]
    size = Window_Setup[:info][:size]
    super(pos[0],pos[1],size[0],size[1])
    self.windowskin = Cache.system(Window_Setup[:info][:skin])
    self.opacity = Window_Setup[:info][:opacity]
    refresh($game_party.members[0])
  end
 
  def refresh(actor)
    contents.clear
    xp = actor.get_xp_info
    xc1 = get_color_sixth(Font_Setup[:xp_bar][:gcolor][0])
    xc2 = get_color_sixth(Font_Setup[:xp_bar][:gcolor][1])
    draw_bio_pic(actor) if Show_Data.include?(:pic)
    draw_bio_info_i(actor,:state)
    draw_bio_info_g(:hp_bar,actor.hp,actor.mhp,actor.hp_rate,
                    hp_gauge_color1,hp_gauge_color2,hp_color(actor),normal_color)
    draw_bio_info_g(:mp_bar,actor.mp,actor.mmp,actor.mp_rate,
                    mp_gauge_color1,mp_gauge_color2,mp_color(actor),normal_color)
    draw_bio_info_g(:tp_bar,actor.tp.to_i,actor.max_tp,actor.tp_rate,
                    tp_gauge_color1,tp_gauge_color2,tp_color(actor),normal_color)
    draw_bio_info_g(:xp_bar,xp[0],xp[1],xp[2],xc1,xc2,normal_color,normal_color)
    draw_bio_info(:progress)
    draw_bio_info(:state)
    draw_bio_info(:name,actor.name)
    draw_bio_info(:class,actor.class.name)
    draw_bio_info(:level,actor.level,InfoPos_Setup[:level][:pos2])
    draw_bio_info(:nickname,actor.nickname)
  end
 
  def draw_bio_pic(actor)
    return if $bio[actor.id].pic[0].nil? || $bio[actor.id].pic[0] == ""
    pic = Cache.bio_pic($bio[actor.id].pic[0])
    index = $bio[actor.id].pic[1]
    opa = InfoPos_Setup[:pic][:opacity]
    pos = InfoPos_Setup[:pic][:pos]
    size = InfoPos_Setup[:pic][:size]
    rect = Rect.new(index%4*size[0],index/4*size[1],size[0],size[1])
    contents.blt(pos[0],pos[1],pic,rect,opa)
    pic.dispose
  end
   
  def draw_bio_info_i(actor,sym)
    return unless Show_Data.include?(sym)
    i = InfoPos_Setup[sym]
    draw_actor_icons(actor,i[:pos][0],i[:pos][1],i[:size][0])
  end
 
  def draw_bio_info_g(sym,d1,d2,rate,c1,c2,c3,c4)
    return unless Show_Data.include?(sym)
    i = InfoPos_Setup[sym]
    draw_gauge(i[:pos][0],i[:pos][1],i[:size][0],rate,c1,c2)
    xi1 = i[:pos][0]+i[:offset][0]
    xi2 = i[:pos][0]
    yi = i[:pos][1]+i[:offset][1]
    change_the_font(Font_Setup[sym][:type],Font_Setup[sym][:size])
    change_color(get_color_sixth(Font_Setup[sym][:color][0]))
    draw_text(xi1,yi,i[:size][0],i[:size][1],Text_Setup[sym],i[:align][0])
    draw_current_and_max_values(xi2,yi,i[:size][0],d1,d2,c3,c4)  
  end
 
end
 
class Bio_Bio < Window_Base
  include Sixth_Actor_Bio
 
  def initialize
    pos = Window_Setup[:bio][:pos]
    size = Window_Setup[:bio][:size]
    super(pos[0],pos[1],size[0],size[1])
    self.windowskin = Cache.system(Window_Setup[:bio][:skin])
    self.opacity = Window_Setup[:bio][:opacity]
    s_bio = Bio_StartPage == :newest ? $bio[$game_party.members[0].id].tmax-1 : 0
    refresh($game_party.members[0],s_bio)
  end
 
  def refresh(actor,page)
    contents.clear
    if Show_Data.include?(:portrait) && !$bio[actor.id].port.nil?
      draw_actor_portrait(actor) if $bio[actor.id].port != ""
    end
    draw_bio_info(:custom1,Actor_Info_Setup[actor.id][:custom1])
    draw_bio_info(:age,Actor_Info_Setup[actor.id][:age])
    draw_bio_info(:gender,Actor_Info_Setup[actor.id][:gender])
    draw_bio_info(:weight,Actor_Info_Setup[actor.id][:weight])
    draw_bio_info(:height,Actor_Info_Setup[actor.id][:height])
    draw_bio_txt_page(actor,page) if Show_Data.include?(:bio_text)
    draw_full_bio_txt(actor,:bio_text,page) if Show_Data.include?(:bio_text)
    draw_morality_bar(actor) if Show_Data.include?(:morality)
    draw_moral_text(actor) if Show_Data.include?(:morality)
  end
 
  def draw_actor_portrait(actor)
    pic = Cache.bio_pic($bio[actor.id].port)
    x = Actor_Info_Setup[actor.id][:portrait][1][0]
    y = Actor_Info_Setup[actor.id][:portrait][1][1]
    opa = Actor_Info_Setup[actor.id][:portrait][2]
    rect = Rect.new(0,0,pic.width,pic.height)
    contents.blt(x,y,pic,rect,opa)
  end
 
  def draw_moral_text(actor)
    i = InfoPos_Setup[:morality]; f = Font_Setup[:morality]
    m = Morality_Setup
    # getting the morale info!
    if $bio[actor.id].morality < m[:min]
      @out = [m[:def_out],m[:min_text][2]]
      @text = m[:min_text][0]
      @col = m[:min_text][1]
    elsif $bio[actor.id].morality > m[:max]
      @out = [m[:def_out],m[:max_text][2]]
      @text = m[:max_text][0]
      @col = m[:max_text][1]
    else
      m[:text_setup].each_with_index do |mor,id|
        if $bio[actor.id].morality.between?(mor[1][0],mor[1][1])
          @text = mor[0]
          @col = mor[2]
          @out = [mor[3],mor[4]]
          break
        end
      end
    end
    tw = i[:size][0]; th = i[:t_height]
    # drawing the descriptive text!
    change_the_font(f[:type4],f[:size][3])
    change_color(get_color_sixth(f[:color]))
    draw_text(i[:tpos4][0],i[:tpos4][1],tw,th,Text_Setup[:morality],i[:align][3])
    # getting the morale text pos and properties
    if $bio[actor.id].morality < 0
      tx = i[:tpos1][0]; ty = i[:tpos1][1]
      tp = f[:type1]; al = i[:align][0]; fs = f[:size][0]
    elsif $bio[actor.id].morality > 0
      tx = i[:tpos2][0]; ty = i[:tpos2][1]
      tp = f[:type2]; al = i[:align][1]; fs = f[:size][1]
    else
      tx = i[:tpos3][0]; ty = i[:tpos3][1]
      tp = f[:type3]; al = i[:align][2]; fs = f[:size][2]
    end
    if @out[0] == true
      contents.font.outline = true
      contents.font.out_color = get_color_sixth(@out[1])
    end
    # drawing the morale text
    change_the_font(tp,fs)
    change_color(get_color_sixth(@col))
    draw_text(tx,ty,tw,th,@text,al)
    reset_font_settings
  end
 
  def draw_morality_bar(actor)
    i = InfoPos_Setup[:morality]
    m = Morality_Setup
    x = i[:pos][0]; y = i[:pos][1]
    w = i[:size][0]; h = i[:size][1]; rw = w/2
    c = (m[:max].abs+m[:min].abs)/2
    val = $bio[actor.id].morality
    cb = get_color_sixth(m[:back_color]); co = get_color_sixth(m[:out_color])
    cmin = get_color_sixth(m[:min_color]); cmax = get_color_sixth(m[:max_color])
    czero = get_color_sixth(m[:zero_color])
    rate = val.abs.to_f / c
    draw_gauge_back(x,y,w,h,cb,co)
    if val == 0 # zero fill
      draw_gauge_middle(x+rw-1,y,3,h,czero)
    elsif val < 0 && val < m[:min] # left fill, minimum
      rate = 1; czero = cmin
      draw_gauge_left(x,y,rw,h,rate,cmin,czero,true)
    elsif val > 0 && val > m[:max] # right fill, maximum
      rate = 1; czero = cmax
      draw_gauge_right(x+rw,y,rw,h,rate,czero,cmax,true)
    elsif val < 0 # left fill, normal
      draw_gauge_left(x,y,rw,h,rate,cmin,czero)
    else val > 0 # right fill, normal
      draw_gauge_right(x+rw,y,rw,h,rate,czero,cmax)
    end
  end
 
  def draw_gauge_back(x,y,w,h,color1,color2)
    w = w - 2
    y = y - 3
    gauge_y = y + line_height - 2 - h
    contents.fill_rect(x,gauge_y-1,w+2,h+2,color2)
    contents.fill_rect(x+1,gauge_y,w,h,color1)
  end
 
  def draw_gauge_middle(x,y,w,h,color)
    y = y - 3
    gauge_y = y + line_height - 2 - h
    contents.fill_rect(x,gauge_y,w,h,color)
  end
 
  def draw_gauge_left(x,y,w,h,rate,color1,color2,max=false)
    w = w - 1
    y = y - 3
    fill_w = [[(w * rate).to_i, w].min,3].max
    fill_2 = [w - fill_w, 0].max
    gauge_y = y + line_height - 2 - h
    new_x = x + fill_2
    contents.gradient_fill_rect(new_x+1,gauge_y,fill_w,h,color1,color2)
  end
 
  def draw_gauge_right(x,y,w,h,rate,color1,color2,max=false)
    w = w - 1
    y = y - 3
    fill_w = [[(w * rate).to_i, w].min,3].max
    gauge_y = y + line_height - 2 - h
    contents.gradient_fill_rect(x+1,gauge_y,fill_w,h,color1,color2)
  end
 
  def draw_full_bio_txt(actor,sym,page)
    change_the_font(Font_Setup[sym][:type1],Font_Setup[sym][:size1])
    change_color(get_color_sixth(Font_Setup[sym][:color][0]))
    bio = $bio[actor.id].text[page]
    pos1 = InfoPos_Setup[sym][:pos1]
    pos2 = InfoPos_Setup[sym][:pos2]
    size = InfoPos_Setup[sym][:size]
    align = InfoPos_Setup[sym][:align]
    draw_text(pos1[0],pos1[1],size[0],size[1],Text_Setup[sym],align)
    change_the_font(Font_Setup[sym][:type2],Font_Setup[sym][:size2])
    change_color(get_color_sixth(Font_Setup[sym][:color][1]))
    @h = InfoPos_Setup[sym][:line_h]
    bio.each_with_index do |txt,i|
      draw_text_ex_s(pos2[0],pos2[1]+i*@h,txt)
    end
  end
 
  def draw_bio_txt_page(actor,page)
    i = Page_Indicator2
    change_the_font(i[:font][0],i[:font][1])
    change_color(get_color_sixth(i[:font][2]))
    if $bio[actor.id].tmax == 1
      draw_icon(i[:icon1],i[:ipos1][0],i[:ipos1][1],false)
      draw_icon(i[:icon2],i[:ipos2][0],i[:ipos2][1],false)
    elsif page == $bio[actor.id].tmax - 1
      draw_icon(i[:icon1],i[:ipos1][0],i[:ipos1][1])
      draw_icon(i[:icon2],i[:ipos2][0],i[:ipos2][1],false)
    elsif page == 0
      draw_icon(i[:icon1],i[:ipos1][0],i[:ipos1][1],false)
      draw_icon(i[:icon2],i[:ipos2][0],i[:ipos2][1])
    else
      draw_icon(i[:icon1],i[:ipos1][0],i[:ipos1][1])
      draw_icon(i[:icon2],i[:ipos2][0],i[:ipos2][1])
    end
    draw_text(i[:tpos][0],i[:tpos][1],i[:size][0],i[:size][1],page+1,1)
  end
 
end
 
class Game_Interpreter
 
  def bio_change(id,text,page=nil)
    if page.nil?
      $bio[id].text.push(text) unless $bio[id].text.include?(text)
    else
      $bio[id].text[page-1] = text unless $bio[id].text.include?(text)
    end
    $bio[id].text.compact!
    $bio[id].tmax = $bio[id].text.size
  end  
 
  def bio_delete(id,page=nil)
    return if $bio[id].text[page-1].nil?
    if page.nil?
      $bio[id].text.delete_at(-1) unless $bio[id].tmax <= 1
    else
      $bio[id].text.delete_at(page-1) unless $bio[id].tmax <= 1
    end
    $bio[id].text.compact!
    $bio[id].tmax = $bio[id].text.size
  end
 
  def port_change(id,pic)
    $bio[id].port = pic
  end
 
  def pic_change(id,pic,index)
    $bio[id].pic = [pic,index]
  end
 
  def moral_add(id,val)
    $bio[id].morality += val
    if Sixth_Actor_Bio::Morality_Setup[:limit] == true
      if $bio[id].morality > Sixth_Actor_Bio::Morality_Setup[:max]+1
        $bio[id].morality = Sixth_Actor_Bio::Morality_Setup[:max]+1
      elsif $bio[id].morality < Sixth_Actor_Bio::Morality_Setup[:min]-1
        $bio[id].morality = Sixth_Actor_Bio::Morality_Setup[:min]-1
      end
    end
  end
 
  def moral_set(id,val)
    $bio[id].morality = val
  end
 
  def check_moral(id,val,type)
    if type == :pos
      return true if $bio[id].morality >= val
    elsif type == :neg
      return true if $bio[id].morality <= val
    else
      return true if $bio[id].morality == val
    end
    return false
  end
 
  def check_party_moral(val,type,type2=:all)
    if type2 == :all
      party = $game_party.members
    else
      party = $game_party.battle_members
    end
    total = 0
    party.each do |actor|
      total += $bio[actor.id].morality
    end
    if type == :pos
      return true if total >= val
    elsif type == :neg
      return true if total <= val
    else
      return true if total == val
    end
    return false
  end
 
end
 
if Sixth_Actor_Bio::Menu_Enable == true
  class Window_MenuCommand < Window_Command
 
    alias sixth_biography122 add_original_commands
    def add_original_commands
      sixth_biography122
      if Sixth_Actor_Bio::Menu_Hide_Switch == 0 ||
         $game_switches[Sixth_Actor_Bio::Menu_Hide_Switch] == true
        add_command(Sixth_Actor_Bio::Menu_Name, :biography, enable_biography)
      end
    end
   
    def enable_biography
      if Sixth_Actor_Bio::Menu_Enable_Switch == 0 ||
         $game_switches[Sixth_Actor_Bio::Menu_Enable_Switch] == true
        return true
      end
      return false
    end
   
  end
end
 
class Scene_Menu < Scene_MenuBase
 
  alias sixth_biography13211 create_command_window
  def create_command_window
    sixth_biography13211()
    @command_window.set_handler(:biography, method(:command_biography))
  end
 
  def command_biography
    dispose_selectors if defined?(dispose_selectors)
    SceneManager.call(Scene_SBio)
  end
 
end
#==============================================================================
# !!END OF SCRIPT - OHH, NOES!!
#==============================================================================