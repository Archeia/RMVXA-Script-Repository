class Window_ActorCommand < Window_Command

  def visible_line_number
    return super
  end
 
  alias set_h0071 make_command_list
  def make_command_list
    set_h0071
    self.height = window_height unless self.disposed?
  end
 
  def refresh
    super
    self.y = Graphics.height - self.height
  end
     
end

class Window_BattleEnemy < Window_Selectable

  alias set_w8827 show
  def show
    set_w8827
    SceneManager.scene.set_iwp_w(@info_viewport.rect.width)
    self
  end

  alias set_w8817 hide
  def hide
    set_w8817
    SceneManager.scene.set_iwp_w(@info_viewport.rect.width)
    self
  end

end

class Scene_Battle < Scene_Base
 
  alias make_new_wp8861 create_info_viewport
  def create_info_viewport
    make_new_wp8861
    @iwp = Viewport.new
    @iwp.z = @info_viewport.z
  end
 
  alias set_wp9927 create_actor_command_window
  def create_actor_command_window
    set_wp9927
    @actor_command_window.viewport = @iwp
  end
 
  alias move_iwp9927 move_info_viewport
  def move_info_viewport(ox)
    move_iwp9927(ox)
    @iwp.ox = @info_viewport.ox
  end
 
  def set_iwp_w(w)
    @iwp.rect.width = w
  end
 
  def dispose_all_windows
    super
    @iwp.dispose
  end
 
end