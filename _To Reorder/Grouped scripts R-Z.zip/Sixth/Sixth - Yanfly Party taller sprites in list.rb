=begin
 
Yanfly's Party System has a little issue with displaying taller sprites in the
actor list window. This little snippet aims to provide a fix for that.
 
Made by: Sixth
 
Install this script below Yanfly's Party System script!
 
Note that this script renders the ACTOR_Y_BUFFER setting in Yanfly's script
unusable! Instead of that static setting, this script provides more dynamic
ways of setting your character sprite up for the actor list window.
 
=end
 
module PSys_Fix
  #-----------------------------------------------------------------------------
  # This many pixels will be added to the drawn portion of the character sprite.
  # Use this to move the drawn area up/down.
  # Negative values will move the drawing area up, while positive values will
  # move it down.
  # Add any custom settings here if needed.
  #
  # Format 1 -> ["filename",character_index] => value,
  # Format 2 -> "filename" => value,
  #
  # Format 1 will apply the settings only to the specified character index,
  # while Format 2 will apply the setting to the whole sprite-sheet.
  #
  # Any images missing a setting here will load the :default setting instead!
  #-----------------------------------------------------------------------------
  AddY = {
    :default => 0, # Default setting, do NOT remove!
    ["Riding",4] => 16,
    ["People3",4] => 2,
    # <-- Add more settings here if needed!
  }
 
  #-----------------------------------------------------------------------------
  # This will be the height of the drawn portion of the character sprite.
  # Can not exceed the item_height of the window (which is usually 24 by
  # default)! Even if you set it to higher here, it will be reset to the maximum
  # amount (which is the item_height of the window).
  # Add any custom settings here if needed.
  #
  # Format 1 -> ["filename",character_index] => value,
  # Format 2 -> "filename" => value,
  #
  # Format 1 will apply the setting only to the specified character index,
  # while Format 2 will apply the setting to the whole sprite-sheet.
  #
  # Any images missing a setting here will load the :default setting instead!
  #-----------------------------------------------------------------------------
  Heights = {
    :default => 22, # Default setting, do NOT remove!
    # <-- Add more settings here if needed!
  }
 
end
 
# End of settings! O_O
 
class Game_Actor < Game_Battler
 
  def psys_addy
    if PSys_Fix::AddY[character_name]
      return PSys_Fix::AddY[character_name]
    elsif PSys_Fix::AddY[[character_name,character_index]]
      return PSys_Fix::AddY[[character_name,character_index]]
    else
      return PSys_Fix::AddY[:default]
    end
  end
 
  def psys_height
    if PSys_Fix::Heights[character_name]
      return PSys_Fix::Heights[character_name]
    elsif PSys_Fix::Heights[[character_name,character_index]]
      return PSys_Fix::Heights[[character_name,character_index]]
    else
      return PSys_Fix::Heights[:default]
    end
  end
 
end
 
class Window_PartyList < Window_Selectable
 
  def draw_actor(actor, rect)
    bitmap = Cache.character(actor.character_name)
    sign = actor.character_name[/^[\!\$]./]
    if sign && sign.include?('$')
      cw = bitmap.width / 3
      ch = bitmap.height / 4
    else
      cw = bitmap.width / 12
      ch = bitmap.height / 8
    end
    n = actor.character_index
    hh = [ch,actor.psys_height].min
    cx = (n%4*3+1)*cw
    cy = (n/4*4)*ch + actor.psys_addy
    src_rect = Rect.new(cx, cy, cw, hh)
    xx = rect.x + 16 - cw / 2
    yy = rect.y + ((rect.height - hh) / 2)
    contents.blt(xx, yy, bitmap, src_rect)
    change_color(list_colour(actor), enabled?(actor))
    draw_text(rect.x+32, rect.y, rect.width-32, line_height, actor.name)
  end
 
end
# End of script! O_O