#===============================================================================
# * [ACE] Animated Commands
#===============================================================================
# * Made by: Sixth (www.rpgmakervxace.net, www.forums.rpgmakerweb.com)
# * Version: 1.1
# * Updated: 17/06/2015
# * Requires: ------
#-------------------------------------------------------------------------------
# * < Change Log >
#-------------------------------------------------------------------------------
# * Version 1.0 (17/06/2015)
#   - Initial release.
# * Version 1.1 (17/06/2015)
#   - Made it possible to move the cursor even before the entering animation
#     is finished (optional).
#-------------------------------------------------------------------------------
# * < Description >
#-------------------------------------------------------------------------------
# * This script is part of my unreleased menu engine!
# * This script is mainly a scripters tool, keep that in mind!
# * This script changes the way how command windows are displayed entirely.
# * The sole purpose of this script is to add better visuals and animations for
#   your command windows using pictures and "built-in" animation methods.
#   This script only changes the main menu commands, but it can be used for
#   any command window you want, if you know your way in scripting, that is!
# * You can set up an entering, an exiting and a selection animation too!
# * You can set up animations on a per command button basis, so you can create
#   non-linear and complex animations "easily"!
#   Two commands flying in from the left, two from above, two fading in, and
#   three zooming in at their place in the meanwhile, sounds fun, right? :P
# * You can create the following types of animations and effects and combine
#   them freely:
#   - Moving animation
#   - Fade in/fade out animation
#   - Zoom in/zoom out animation
#   - Tone changing animation (changes during command selection)
#   - Blending mode changes (changes during command selection)
#   - Picture based animation (only active while the command is selected)
#   - Flashing animation (only active while the command is selected)
# * Each animation and effect got separate speed settings (if applicable), so
#   you can synchronize your animations the way you want!
# * In addition to the above cool things, you can place your command buttons
#   wherever you want on your screen! 2 in each of the corners? No problem! :)
# * As a bonus, this script can act as a menu command organizer too, since you
#   get complete control over your commands and what they do! This means you can:
#   - Add/remove default/custom command buttons easily!
#   - Order your commands how you want!
#   - Change their enable and show conditions how you want!
#     Tie them to switches, add a script requirement or call already coded in
#     methods to define their enable/show states!
#     Or simply turn them ON or OFF forever, but where is the fun in that, right?
#   - Make your own command buttons for common events or even for script calls!
#   - And more! ... No actually there are no more... Ohh, well... :P
#-------------------------------------------------------------------------------
# * < Instructions for Scripters >
#-------------------------------------------------------------------------------
# * The new class created is named 'SpriteCommands'.
#   This class takes two arguments for it's initialization method:
#     1. The module data for your command setup.
#     2. The folder path to the images used for the command sprites.
#     3. The selection settings (important for cursor behavior).
#   Knowing this, you can easily create your own command window settings:
#     1. Replace the old command window with this class in your scene.
#     2. Paste your command settings as the first argument.
#     3. Paste your image folder settings as the second argument.
#     4. Paste your selection settings as the second argument.
#     5. Set up the handlers for the window in the scene just like I did here
#        (should not be hard, basically it is just copy/paste and change the
#        module/setting names).
#     6. Copy the 'init_exiting' and 'exit_now' methods to your own scene.
#     7. If you want common event or script command buttons, copy and paste the
#        related methods from this script into your own scene class!
#        The method names for these are kinda hard to miss... :D
#     8. Copy any missing or new methods from your old window class into the
#        new class.
#   Note that the layout of your command and selection settings must follow the
#   same layout found in this script!
#   If you have any questions, you can ask me anytime in the topic you found
#   this script!
#-------------------------------------------------------------------------------
# * < Installation >
#-------------------------------------------------------------------------------
# * In the script editor, place this script below Materials but above Main!
# * If you are using any custom menu scripts, place this script below them!
#-------------------------------------------------------------------------------
# * < Compatibility Info >
#-------------------------------------------------------------------------------
# * No known incompatibilities, but since I have overwritten some methods for
#   the visuals, there might be problems with other menu scripts.
# * Overwritten methods:
#   - In the Scene_Menu class:
#     ~ create_command_window,
#     ~ create_status_window (thanks to Enterbrain's way of positioning windows) -.-
# * I replaced Window_MenuCommand with my new class called SpriteCommands in
#   Scene_Menu.
#   The good news is that I inherit from Window_MenuCommand, so any method
#   defined there (such as custom enable checks, for example) will be there!
# * I disabled the 'update_cursor' method in the new class, since it is not
#   needed anymore.
# * Also the new class got it's own method of 'make_command_list' and the only
#   way your custom buttons will show up is to add them through the command
#   settings in the module!
#-------------------------------------------------------------------------------
# * < Known Issues >
#-------------------------------------------------------------------------------
# * No known issues.
#-------------------------------------------------------------------------------
# * < Terms of Use >
#-------------------------------------------------------------------------------
# * Free to use for whatever purposes you want.
# * Credit me (Sixth) in your game, pretty please! :P
# * Posting modified versions of this script is allowed as long as you notice me
#   about it with a link to it!
#===============================================================================
module MCommands
  #--------------------------------------------------------------------------  
  # Image Folder Settings:
  #--------------------------------------------------------------------------
  # Setup the folders used for your images here.
  # This demo uses the :main folder settings!
  # All images used must be in the folder you set up here!
  #--------------------------------------------------------------------------
  ImgFolder = { # <-- No touchy-touchy!
    :main => "Graphics/MenuHUD/Main/",
  } # <-- No touchy-touchy!
 
  #--------------------------------------------------------------------------  
  # Status WIndow Settings:
  #--------------------------------------------------------------------------
  # In case you need to change these settings for your status window to
  # account for the changes in your command window, you can do it here.
  # What each of them does should be obvious.
  #--------------------------------------------------------------------------
  StatusWindow = { # <-- No touchy-touchy!
    :pos => [200,0],
    :size => [400,400],
    :opa => 0,
  } # <-- No touchy-touchy!
 
  #--------------------------------------------------------------------------  
  # Selection Settings:
  #--------------------------------------------------------------------------
  # These settings are important for the cursor's behaviour during command
  # selection.
  # For example, having two command pictures on the left and two on the right
  # with the :max_col setting set to 1 will only let you select the commands
  # with the up and down arrows. But if you set that to 2, you can use the left
  # and right buttons too for selection.
  # If your commands are lined up horizontally, set the :max_col settings to the
  # number of commands you can have at max, and set the :horizontal setting
  # to true. That will ensure that only the left and right buttons are available
  # for selection, and the cursor will be able to wrap around if you set the
  # :horizontal setting to true.
  #--------------------------------------------------------------------------
  Selection = { # <-- No touchy-touchy!
    :max_col => 1,
    :horizontal => false,
    :eselect => true,
  } # <-- No touchy-touchy!
 
  #--------------------------------------------------------------------------  
  # Command Settings:
  #--------------------------------------------------------------------------    
  # Well, you set up your commands here.
  # The entire purpose of this script is to let you animate your command
  # buttons the way you want to, and to make that possible to do on a per
  # command button basis, so if you want, you can design a different animation
  # for each of your command buttons separately!
  #
  # There are a lot to set up, so if you are not willing to read the descriptions
  # of these settings, than you might as well delete this script, because without
  # knowing what these settings do, you won't be able to make your own animations,
  # you might even screw up the whole game! So, please, read the stuffs below!
  #
  # Let's start with the easier settings first...
  # I ordered the settings this way:
  # Non-animation settings first, animation settings later.
  # Most of the animation settings can be omitted (but NOT ALL of them!), so
  # it is best to place them lower on the list.
  #
  # So, the settings start with a unique identifier for the command button.
  # I will refer to that by "command ID" from now on!
  # These command IDs must be unique (so no duplicates), but aside from that,
  # they can be just about everything (integers, strings, symbols). I used
  # simple integers, those are easy to follow.
  #
  # The order how you set your command buttons up in the main setting's hash
  # will decide in which order they will appear on the scene. This is important
  # for the animation settings (in case you want to design delayed animations),
  # and this will also decide which command will be selected upon a button press.
  # So, it is important, in short, and should not be neglected!
  #
  # Okay, now for the details:
  #
  #   :name => "text",
  # The name of the command button. This is not used yet, you can even omit it,
  # if you want, I just put it in for possible later usage.
  #
  #   :symbol => :command_symbol,
  # This is the symbol of the command button. Needed for processing the correct
  # code when the command is selected (pressing the confirm button on it).
  # If you want to add your own custom buttons, but don't know what symbol some
  # scripts use, you will have to ask the author of the script about it!
  # In case you want to make your own common event or script command buttons,
  # you can enter your own symbols, doesn't matter how you name your symbols,
  # but there can be NO duplicates! If one command button got :event for it's
  # :symbol setting, no other command button can have it's :symbol setting set
  # to :event!
  # If you want to set up a common event or script command button, you will need
  # to set up a new setting called :extra for the command button too!
  #
  #   :extra => event_id, # <-- For common event command buttons.
  #   :extra => "code to evaluate", # <-- For script command buttons.
  # This is the extra settings needed for common event or script command buttons.
  # If you need this for a common event, enter the ID of the common event from
  # the database. If you need this for a script command button, enter the ruby
  # code to evaluate as a string.
  # In the case of a script command button, the command window will NOT get
  # activated automatically, so if you want that to happen after your code, you
  # must enter this at the end of your script string: "@command_window.activate".
  # If the command button is neither a common event, nor a script command button,
  # you can omit this setting!
  #
  #   :method => :method_symbol,
  # The method to run upon selecting this command. You must know the correct
  # method symbol for the command here. Again, if you have a custom scrript and
  # you have trouble finding out what symbol to enter here, you will need to ask
  # the author of that custom script about it!
  # If the command is a common event or script command button, you must set this
  # to :do_the_event or :do_the_script repectively!
  #
  #   :enable => condition,
  # The condition that must be true for the command to be enabled.
  # You have several options here:
  # 1. Enter an integer number and it will check for the switch with that ID.
  #    If the switch is turned ON, it will be enabled, if not, it will be disabled.
  # 2. Enter a symbol, and a method with that name will be run to determine the
  #    state of the command button. The method must be defined in any of these
  #    classes: Window_Base, Window_Selectable, Window_Command,
  #             Window_MenuCommand, SpriteCommands (the new class of this script).
  # 3. Enter a string, and it will be treated as a ruby code, and the evaluation
  #    of that code will decide if the command will be enabled or not. The code
  #    entered must return either true or false!
  # 4. Simply enter true, and it will always be enabled.
  #
  #   :show => condition,
  # This is the same as the :enable setting, but this one will decide if the
  # command button will show up or not. You have the same options available here
  # like at the :enable settings.
  #
  #   :z => value,
  # The Z value of the image used for the command button. No idea if this is
  # useful or not, but I added it just in case.
  #
  #   :pic => {
  #     :e => "file name", :d => "file name", :h => "file name",
  #     :anim => {:frames => [frame list], :wait => value, :rows => number},
  #   },
  # This is the image setup for the command button. The images you set up here
  # will be shown on the scene. You can set up 3 kinds of images, one will show
  # up when the command is enabled (:e, as 'enabled'), one will show up if the
  # command is disabled (:d, as 'disabled'), and the last one will be shown if
  # the command is hidden (:h, as 'hidden'), aka "not shown".
  # The command is hidden if it's show condition is not true!
  # If the command is hidden, it can not be selected, but you can still show an
  # image for it if you want! If you don't want to show an image for hidden
  # commands, you can make a transparent image and use that!
  # Now, the :anim settings are there for you to make even more complex
  # animations using a series of pictures from a sheet.
  # You will need an image sheet to do this. Each picture on the sheet must be
  # below the other, so the final sheet will be a series of pictures ordered
  # vertically! These pictures than will get an index from the top to bottom.
  # The index numbers start with 0 and goes to infinity!
  # The :frames setting is an array of integer numbers. These numbers will decide
  # the order of the animation pictures shown from the command image sheet.
  # You can enter as many numbers into the array as you wish, making it possible
  # to design really detailed animations! The numbers represent picture indexes
  # from the image sheet used! Once the last picture is shown from the sheet,
  # it starts over from the first picture index!
  # The :wait setting decides how quickly the images will cycle from the sheet.
  # Lower values mean slower change, higher values mean quicker change (which
  # usually makes smoother animations). It is measured in frames!
  # The :rows setting is the number of pictures you use on your image sheet.
  # So, you can have less rows than your actual :frames size, and you can re-use
  # the pictures from your sheet as many times as you want without forcing you
  # to add duplicate pictures on the sheet.
  # Note that if you decide to use this kind of animation, the top picture must
  # be the initial picture which you want to show up when the command pictures
  # are created and the entering animation plays!
  #
  #   :tone => {:a => [r,g,b,gr], :i => [r,g,b,gr], :speed => value},
  # The tone of the pictures used. As before, :a stands for 'active' and :i
  # stands for 'inactive'. Enter the red, green, blue and gray values of the
  # tone you want in the array settings. The tone change between the active and
  # inactive state will change smoothly, depending on the :speed settings.
  # The lower your :speed setting is, the smoother and slower will the change be,
  # and if you set it a higher value, the change will happeen more quickly.
  #
  #   :blend => {:a => type, :i => type, :da => type, :di => type},
  # The blend mode of the pictures. There are several settings, these are:
  #   :a = enabled active command
  #   :i = enabled inactive command
  #   :da = disabled active command
  #   :di = disabled inactive command
  # You can set a separate blending mode for each of the states from above.
  # 3 types of modes are available:
  # 0 = normal, 1 = addition, 2 = subtraction.
  # I don't think I can explain what each type does exactly, so you will have to
  # experiment on your own with these, sorry!
  #
  #   :flash => {:color => [r,g,b,a], :dur => value, :wait => value},
  # Settings for the flashing animation. You can set up a color for it with
  # RGBA values. Each color value goes from 0 to 255!
  # The :dur option decides how long will the flashing last.
  # The :wait option decides how long it should wait for the next flash effect
  # after a flashing. This value must be higher than the :dur value!
  # The image will be flashing once when it's activation animation (if any) is
  # completed automatically. After that, it will flash periodically, once after
  # each :wait frames.
  #
  # This ends the easier part of the configuration.
  # The following configurations are all related to the animations of the
  # command buttons!
  #
  # You got 3 separate settings for your animation needs:
  #   :enter = This will be played upon opening the scene, and only once!
  #   :exit = This plays upon exiting the scene.
  #   :anim = This plays when the command button is selected. If the button is
  #           selected, the animation settings set up here will be performed
  #           on the selected button image, and if the button is no longer
  #           selected, the animation set up here will be performed again, but
  #           this time, it will reverse any effect.
  #           The player does not have to wait for the full animation to finish
  #           to select another command, so don't worry about that!
  #
  # Some settingss can and some settings can NOT be omitted. Here are the ones
  # which needs to be set up:
  # The whole :enter animation setting! This will determine the initial values
  # for your command button, so this must be set up!
  # The rest is optional, but if you want some cool animations during command
  # selection, and upon exiting the scene, you will need to set them up!
  #  
  # Let's see the animation options in detail now:
  #
  # For the :enter and :exit animation settings:
  #   :pos => {:start => [x,y], :end => [x,y], :speed => [xspeed,yspeed]},
  # For the :anim settings:
  #   :pos => {:move => [x,y], :speed => [xspeed,yspeed]},
  # Like the name suggests, this will give you a move animation.
  # In the case of :enter and :exit animations, the X and Y values in the :start
  # and :end settings are direct positions on the screen. The image will move
  # from the :start position to the :end position. When it reaches the :end
  # position, the :enter/:exit animation phase is finished.
  # In the case of :anim settings, the X and Y values are the offset values for
  # the animation. The image will move that many pixels on the X/Y axis when
  # selected from it's original position. The command images' original position
  # is the X and Y position of the :enter animation's :end settings!
  # The speed at which the image will move is controlled by the :speed settings.
  # The first is the move speed on the X axis, and the second is the move speed
  # on the Y axis. 1 means that the image will be moved by 1 pixel at a frame!
  # Entering higher numbers yields quicker move speed!
  # You don't have to worry about the image ending up in wrong positions, the
  # final position of the image can never be more than what you enter in the
  # relative settings, regardless if it is a negative or positive value!
  #
  #   :opa => {:start => value, :end => value, :speed => value},
  # This will give a fade in/fade out animation.
  # All three animation settings use the same format!
  # The image's opacity will start on the opacity value entered for the :start
  # setting, and will gradually increase/decrease depending on the :speed
  # setting. Like above, the :speed determines how much will get added/subtracted
  # to/from the image's opacity at each frame.
  # Remember that the minimum opacity is 0 and the maximum is 255, with 0 being
  # fully transparent!
  #
  #   :zoom => {
  #     :x => {:start => value, :end => value, :speed => value},
  #     :y => {:start => value, :end => value, :speed => value},
  #   },
  # This will give a zoom in/zoom out animation.
  # You can set the zoom level on the X and Y axis separately.
  # If you have been reading the above two setting decriptions, you should
  # already know what each of these settings do.
  # Remember that the normal zoom level is 1.0! Lower values will zoom out the
  # image, while higher values will zoom in! Setting the zoom level to 0.0 will
  # effectively make the image disappear completely!
  #
  # And these were the currently available animation settings!
  # Final notes:
  # - The initial position, opacity and zoom levels of the command images will
  #   be the same what you have set up for the :enter animation setting's :end
  #   values! You should design your :exit and :anim animations with this in mind!
  # - The :enter and :exit animations will only be set as "finished" if ALL of
  #   the set up animations are finished executing! You will not be able to
  #   select any command before the :enter animation is finished, and the scene
  #   will not exit until the :exit animation is finished (if any)!
  # - The :symbol setting MUST be a unique symbol! You can NOT have duplicates!
  #   The button images will get the :symbol as their identifiers, so if there
  #   are duplicates, some images will be missing!
  # - Do not forget the commas in the settings! Seriously, DON'T FORGET THEM! :P
  #--------------------------------------------------------------------------    
  Commands = { # <-- No touchy-touchy!
    0 => { # 1st command - Settings start!
      :name => "Items",
      :symbol => :item,
      :method => :command_item,
      :enable => :main_commands_enabled,
      :show => true,
      :z => 100,
      :pic => {
        :e => "Items1", :d => "Items1", :h => "Hidden1",
        :anim => {:frames => [0,1,2,1,0,3,4,3], :wait => 6, :rows => 5},
      },
      :tone => {:a => [0,0,0,0], :i => [0,0,0,255],:speed => 10},
      :blend => {:a => 0, :i => 1, :da => 2, :di => 2},
      :flash => {:color => [255,255,0,200], :dur => 60, :wait => 180},
      :enter => { # Enter animation settings start!
        :pos => {:start => [-100,-30], :end => [80,30], :speed => [5,1]},
        :opa => {:start => 100, :end => 255, :speed => 2},
        :zoom => {
          :x => {:start => 0.1, :end => 0.6, :speed => 0.1},
          :y => {:start => 0.1, :end => 0.6, :speed => 0.1},
        },
      }, # Enter animation settings end!
      :anim => { # Selection animation settings start!
        :pos => {:move => [40,0], :speed => [2,1]},
        :opa => {:start => 255, :end => 255, :speed => 1},
        :zoom => {
          :x => {:start => 0.6, :end => 1.0, :speed => 0.02},
          :y => {:start => 0.6, :end => 1.0, :speed => 0.02},
        },
      }, # Selection animation settings end!
      :exit => { # Exit animation settings start!
        :pos => {:start => [80,30], :end => [80,30], :speed => [5,1]},
        :opa => {:start => 255, :end => 0, :speed => 15},
        :zoom => {
          :x => {:start => 1.0, :end => 0.0, :speed => 0.05},
          :y => {:start => 1.0, :end => 0.0, :speed => 0.05},
        },
      }, # Exit animation settings end!
    }, # 1st command - Settings end!
    1 => { # 2nd command - Settings start!
      :name => "Skills",
      :symbol => :skill,
      :method => :command_personal,
      :enable => :main_commands_enabled,
      :show => true,
      :z => 100,
      :pic => {
        :e => "Skills1", :d => "Skills1", :h => "Hidden1",
        :anim => {:frames => [0,1,2,1,0,3,4,3], :wait => 6, :rows => 5},
      },
      :tone => {:a => [0,0,0,0], :i => [0,0,0,255], :speed => 10},
      :blend => {:a => 0, :i => 1, :da => 2, :di => 2},
      :flash => {:color => [255,255,0,200], :dur => 60, :wait => 180},
      :enter => {
        :pos => {:start => [-130,-60], :end => [80,60], :speed => [5,2]},
        :opa => {:start => 100, :end => 255, :speed => 2},
        :zoom => {
          :x => {:start => 0.1, :end => 0.6, :speed => 0.1},
          :y => {:start => 0.1, :end => 0.6, :speed => 0.1},
        },
      },
      :anim => {
        :pos => {:move => [40,0], :speed => [2,1]},
        :opa => {:start => 255, :end => 255, :speed => 1},
        :zoom => {
          :x => {:start => 0.6, :end => 1.0, :speed => 0.02},
          :y => {:start => 0.6, :end => 1.0, :speed => 0.02},
        },
      },
      :exit => {
        :pos => {:start => [80,60], :end => [80,60], :speed => [5,1]},
        :opa => {:start => 255, :end => 0, :speed => 15},
        :zoom => {
          :x => {:start => 1.0, :end => 0.0, :speed => 0.05},
          :y => {:start => 1.0, :end => 0.0, :speed => 0.05},
        },
      },
    }, # 2nd command - Settings end!
    2 => { # 3rd command - Settings start!
      :name => "Equipment",
      :symbol => :equip,
      :method => :command_personal,
      :enable => :main_commands_enabled,
      :show => true,
      :z => 100,
      :pic => {
        :e => "Equipment1", :d => "Equipment1", :h => "Hidden1",
        :anim => {:frames => [0,1,2,1,0,3,4,3], :wait => 6, :rows => 5},
      },
      :tone => {:a => [0,0,0,0], :i => [0,0,0,255], :speed => 10},
      :blend => {:a => 0, :i => 1, :da => 2, :di => 2},
      :flash => {:color => [255,255,0,200], :dur => 60, :wait => 180},
      :enter => {
        :pos => {:start => [-160,-90], :end => [80,90], :speed => [5,3]},
        :opa => {:start => 100, :end => 255, :speed => 2},
        :zoom => {
          :x => {:start => 0.1, :end => 0.6, :speed => 0.1},
          :y => {:start => 0.1, :end => 0.6, :speed => 0.1},
        },
      },
      :anim => {
        :pos => {:move => [40,0], :speed => [2,1]},
        :opa => {:start => 255, :end => 255, :speed => 1},
        :zoom => {
          :x => {:start => 0.6, :end => 1.0, :speed => 0.02},
          :y => {:start => 0.6, :end => 1.0, :speed => 0.02},
        },
      },
      :exit => {
        :pos => {:start => [80,90], :end => [80,90], :speed => [5,1]},
        :opa => {:start => 255, :end => 0, :speed => 15},
        :zoom => {
          :x => {:start => 1.0, :end => 0.0, :speed => 0.05},
          :y => {:start => 1.0, :end => 0.0, :speed => 0.05},
        },
      },
    }, # 3rd command - Settings end!
    3 => { # 4th command - Settings start!
      :name => "Gems",
      :symbol => :gems,
      :method => :command_personal,
      :enable => true,
      :show => true,
      :z => 100,
      :pic => {
        :e => "Gems1", :d => "Gems1", :h => "Hidden1",
        :anim => {:frames => [0,1,2,1,0,3,4,3], :wait => 6, :rows => 5},
      },
      :tone => {:a => [0,0,0,0], :i => [0,0,0,255], :speed => 10},
      :blend => {:a => 0, :i => 1, :da => 2, :di => 2},
      :flash => {:color => [255,255,0,200], :dur => 60, :wait => 180},
      :enter => {
        :pos => {:start => [-190,-120], :end => [80,120], :speed => [5,4]},
        :opa => {:start => 100, :end => 255, :speed => 2},
        :zoom => {
          :x => {:start => 0.1, :end => 0.6, :speed => 0.1},
          :y => {:start => 0.1, :end => 0.6, :speed => 0.1},
        },
      },
      :anim => {
        :pos => {:move => [40,0], :speed => [2,1]},
        :opa => {:start => 255, :end => 255, :speed => 1},
        :zoom => {
          :x => {:start => 0.6, :end => 1.0, :speed => 0.02},
          :y => {:start => 0.6, :end => 1.0, :speed => 0.02},
        },
      },
      :exit => {
        :pos => {:start => [80,120], :end => [80,120], :speed => [5,1]},
        :opa => {:start => 255, :end => 0, :speed => 15},
        :zoom => {
          :x => {:start => 1.0, :end => 0.0, :speed => 0.05},
          :y => {:start => 1.0, :end => 0.0, :speed => 0.05},
        },
      },
    }, # 4th command - Settings end!
    4 => { # 5th command - Settings start!
      :name => "Status",
      :symbol => :status,
      :method => :command_personal,
      :enable => :main_commands_enabled,
      :show => true,
      :z => 100,
      :pic => {
        :e => "Status1", :d => "Status1", :h => "Hidden1",
        :anim => {:frames => [0,1,2,1,0,3,4,3], :wait => 6, :rows => 5},
      },
      :tone => {:a => [0,0,0,0], :i => [0,0,0,255], :speed => 10},
      :blend => {:a => 0, :i => 1, :da => 2, :di => 2},
      :flash => {:color => [255,255,0,200], :dur => 60, :wait => 180},
      :enter => {
        :pos => {:start => [-220,-150], :end => [80,150], :speed => [5,5]},
        :opa => {:start => 100, :end => 255, :speed => 2},
        :zoom => {
          :x => {:start => 0.1, :end => 0.6, :speed => 0.1},
          :y => {:start => 0.1, :end => 0.6, :speed => 0.1},
        },
      },
      :anim => {
        :pos => {:move => [40,0], :speed => [2,1]},
        :opa => {:start => 255, :end => 255, :speed => 1},
        :zoom => {
          :x => {:start => 0.6, :end => 1.0, :speed => 0.02},
          :y => {:start => 0.6, :end => 1.0, :speed => 0.02},
        },
      },
      :exit => {
        :pos => {:start => [80,150], :end => [80,150], :speed => [5,1]},
        :opa => {:start => 255, :end => 0, :speed => 15},
        :zoom => {
          :x => {:start => 1.0, :end => 0.0, :speed => 0.05},
          :y => {:start => 1.0, :end => 0.0, :speed => 0.05},
        },
      },
    }, # 5th command - Settings end!
    5 => { # 6th command - Settings start!
      :name => "Formation",
      :symbol => :formation,
      :method => :command_formation,
      :enable => :formation_enabled,
      :show => true,
      :z => 100,
      :pic => {
        :e => "Formation1", :d => "Formation1", :h => "Hidden1",
        :anim => {:frames => [0,1,2,1,0,3,4,3], :wait => 6, :rows => 5},
      },
      :tone => {:a => [0,0,0,0], :i => [0,0,0,255], :speed => 10},
      :blend => {:a => 0, :i => 1, :da => 2, :di => 2},
      :flash => {:color => [255,255,0,200], :dur => 60, :wait => 180},
      :enter => {
        :pos => {:start => [-250,-180], :end => [80,180], :speed => [5,6]},
        :opa => {:start => 100, :end => 255, :speed => 2},
        :zoom => {
          :x => {:start => 0.1, :end => 0.6, :speed => 0.1},
          :y => {:start => 0.1, :end => 0.6, :speed => 0.1},
        },
      },
      :anim => {
        :pos => {:move => [40,0], :speed => [2,1]},
        :opa => {:start => 255, :end => 255, :speed => 1},
        :zoom => {
          :x => {:start => 0.6, :end => 1.0, :speed => 0.02},
          :y => {:start => 0.6, :end => 1.0, :speed => 0.02},
        },
      },
      :exit => {
        :pos => {:start => [80,180], :end => [80,180], :speed => [5,1]},
        :opa => {:start => 255, :end => 0, :speed => 15},
        :zoom => {
          :x => {:start => 1.0, :end => 0.0, :speed => 0.05},
          :y => {:start => 1.0, :end => 0.0, :speed => 0.05},
        },
      },
    }, # 6th command - Settings end!
    6 => { # 7th command - Settings start!
      :name => "Save",
      :symbol => :save,
      :method => :command_save,
      :enable => :save_enabled,
      :show => true,
      :z => 100,
      :pic => {
        :e => "Save1", :d => "Save1", :h => "Hidden1",
        :anim => {:frames => [0,1,2,1,0,3,4,3], :wait => 6, :rows => 5},
      },
      :tone => {:a => [0,0,0,0], :i => [0,0,0,255], :speed => 10},
      :blend => {:a => 0, :i => 1, :da => 2, :di => 2},
      :flash => {:color => [255,255,0,200], :dur => 60, :wait => 180},
      :enter => {
        :pos => {:start => [-280,-210], :end => [80,210], :speed => [5,7]},
        :opa => {:start => 100, :end => 255, :speed => 2},
        :zoom => {
          :x => {:start => 0.1, :end => 0.6, :speed => 0.1},
          :y => {:start => 0.1, :end => 0.6, :speed => 0.1},
        },
      },
      :anim => {
        :pos => {:move => [40,0], :speed => [2,1]},
        :opa => {:start => 255, :end => 255, :speed => 1},
        :zoom => {
          :x => {:start => 0.6, :end => 1.0, :speed => 0.02},
          :y => {:start => 0.6, :end => 1.0, :speed => 0.02},
        },
      },
      :exit => {
        :pos => {:start => [80,210], :end => [80,210], :speed => [5,1]},
        :opa => {:start => 255, :end => 0, :speed => 15},
        :zoom => {
          :x => {:start => 1.0, :end => 0.0, :speed => 0.05},
          :y => {:start => 1.0, :end => 0.0, :speed => 0.05},
        },
      },
    }, # 7th command - Settings end!
    7 => { # 8th command - Settings start!
      :name => "Game End",
      :symbol => :game_end,
      :method => :command_game_end,
      :enable => true,
      :show => true,
      :z => 100,
      :pic => {
        :e => "Game End1", :d => "Game End1", :h => "Hidden1",
        :anim => {:frames => [0,1,2,1,0,3,4,3], :wait => 6, :rows => 5},
      },
      :tone => {:a => [0,0,0,0], :i => [0,0,0,255], :speed => 10},
      :blend => {:a => 0, :i => 1, :da => 2, :di => 2},
      :flash => {:color => [255,255,0,200], :dur => 60, :wait => 180},
      :enter => {
        :pos => {:start => [-310,-240], :end => [80,240], :speed => [5,8]},
        :opa => {:start => 100, :end => 255, :speed => 2},
        :zoom => {
          :x => {:start => 0.1, :end => 0.6, :speed => 0.1},
          :y => {:start => 0.1, :end => 0.6, :speed => 0.1},
        },
      },
      :anim => {
        :pos => {:move => [40,0], :speed => [2,1]},
        :opa => {:start => 255, :end => 255, :speed => 1},
        :zoom => {
          :x => {:start => 0.6, :end => 1.0, :speed => 0.02},
          :y => {:start => 0.6, :end => 1.0, :speed => 0.02},
        },
      },
      :exit => {
        :pos => {:start => [80,240], :end => [80,240], :speed => [5,1]},
        :opa => {:start => 255, :end => 0, :speed => 15},
        :zoom => {
          :x => {:start => 1.0, :end => 0.0, :speed => 0.05},
          :y => {:start => 1.0, :end => 0.0, :speed => 0.05},
        },
      },
    }, # 8th command - Settings end!
    8 => { # 9th command - Settings start!
      :name => "Common Event 1",
      :symbol => :common_event1,
      :method => :do_the_event,
      :extra => 9,
      :enable => true,
      :show => true,
      :z => 100,
      :pic => {
        :e => "Event 1", :d => "Event 1", :h => "Hidden1",
        :anim => {:frames => [0,1,2,1,0,3,4,3], :wait => 6, :rows => 5},
      },
      :tone => {:a => [0,0,0,0], :i => [0,0,0,255], :speed => 10},
      :blend => {:a => 0, :i => 1, :da => 2, :di => 2},
      :flash => {:color => [255,255,0,200], :dur => 60, :wait => 180},
      :enter => {
        :pos => {:start => [-340,-270], :end => [80,270], :speed => [5,9]},
        :opa => {:start => 100, :end => 255, :speed => 2},
        :zoom => {
          :x => {:start => 0.1, :end => 0.6, :speed => 0.1},
          :y => {:start => 0.1, :end => 0.6, :speed => 0.1},
        },
      },
      :anim => {
        :pos => {:move => [40,0], :speed => [2,1]},
        :opa => {:start => 255, :end => 255, :speed => 1},
        :zoom => {
          :x => {:start => 0.6, :end => 1.0, :speed => 0.02},
          :y => {:start => 0.6, :end => 1.0, :speed => 0.02},
        },
      },
      :exit => {
        :pos => {:start => [80,270], :end => [80,270], :speed => [5,1]},
        :opa => {:start => 255, :end => 0, :speed => 15},
        :zoom => {
          :x => {:start => 1.0, :end => 0.0, :speed => 0.05},
          :y => {:start => 1.0, :end => 0.0, :speed => 0.05},
        },
      },
    }, # 9th command - Settings end!
    9 => { # 10th command - Settings start!
      :name => "Scrip 1",
      :symbol => :script1,
      :method => :do_the_script,
      :extra => "$game_party.gain_gold(rand(3333));
                @gold_window.refresh;
                @command_window.activate",
      :enable => true,
      :show => true,
      :z => 100,
      :pic => {
        :e => "Script 1", :d => "Script 1", :h => "Hidden1",
        :anim => {:frames => [0,1,2,1,0,3,4,3], :wait => 6, :rows => 5},
      },
      :tone => {:a => [0,0,0,0], :i => [0,0,0,255], :speed => 10},
      :blend => {:a => 0, :i => 1, :da => 2, :di => 2},
      :flash => {:color => [255,255,0,200], :dur => 60, :wait => 180},
      :enter => {
        :pos => {:start => [-370,-300], :end => [80,300], :speed => [5,10]},
        :opa => {:start => 100, :end => 255, :speed => 2},
        :zoom => {
          :x => {:start => 0.1, :end => 0.6, :speed => 0.1},
          :y => {:start => 0.1, :end => 0.6, :speed => 0.1},
        },
      },
      :anim => {
        :pos => {:move => [40,0], :speed => [2,1]},
        :opa => {:start => 255, :end => 255, :speed => 1},
        :zoom => {
          :x => {:start => 0.6, :end => 1.0, :speed => 0.02},
          :y => {:start => 0.6, :end => 1.0, :speed => 0.02},
        },
      },
      :exit => {
        :pos => {:start => [80,300], :end => [80,300], :speed => [5,1]},
        :opa => {:start => 255, :end => 0, :speed => 15},
        :zoom => {
          :x => {:start => 1.0, :end => 0.0, :speed => 0.05},
          :y => {:start => 1.0, :end => 0.0, :speed => 0.05},
        },
      },
    }, # 10th command - Settings end!
   
    # <-- Add more command setups here!
   
  } # <-- No touchy-touchy!
 
end
#===============================================================================
# End of Settings Part!
# Editing below may lead to malfunctioning brain-cells! You have been warned!
#===============================================================================
 
$imported = {} if $imported.nil?
$imported["SixthAnimCommands"] = true
 
module Cache
 
  def self.menuhud(filename,folder)
    load_bitmap(folder, filename)
  end
 
end
 
class Scene_Base
 
  # This is needed for the exit animation, do not remove!
  def exit_now
    # Anti-crasher!
  end
 
end
 
class SpriteCommands < Window_MenuCommand
 
  # The 'data' is the command button setup.
  # The 'folder' is the image folder used for the sprites.
  # This way you can add your own data and folder settings from your own
  # custom scripts too, if needed!
  def initialize(data,folder,selection)
    @data = data; @folder = folder; @esel = selection[:eselect]
    @cols = selection[:max_col]; @horz = selection[:horizontal]
    @entered = false; @flasher = 0
    @animater = 0; @picid = 0; @prate = -1
    super()
    deactivate unless @esel
    self.hide # No need for windows!
  end
 
  def window_width
    1 # The smaller, the better!
  end
 
  def window_height
    1 # The smaller, the better!
  end
   
  def col_max
    return @cols ? @cols : super
  end
 
  def horizontal?
    return @horz ? @horz : super
  end
 
  # Setting correct animation phases for the sprites here!
  # Also ensuring that the flashing of the command sprite will happen after
  # it's activation animation, and that the picture animation resets.
  def select(index)
    if index
      if current_symbol && @entered
        @cpics_state[current_symbol] = :inactive
        @cpics[current_symbol].src_rect.y = 0
      end
      super
      if current_symbol && @entered
        info = @data.find {|key,item| item[:symbol] == current_symbol }
        info = info[1]
        if !info[:pic][:anim].nil?
          @prate = info[:pic][:anim][:wait]
          @pframes = info[:pic][:anim][:frames]
          @cpics[current_symbol].src_rect.y = 0
          @animater = 0; @picid = 0
        else
          @prate = -1
          @pframes = -1
        end
        @flasher = 999999
        @cpics_state[current_symbol] = :active
      end
    end
  end
   
  def cursor_pagedown
    # Since the width and height is 1, this must be rewritten to avoid weird
    # behaviors. I have set it so it always selects the last command.
    select(item_max-1) if index != item_max-1
  end
 
  def cursor_pageup
    # Since the width and height is 1, this must be rewritten to avoid weird
    # behaviors. I have set it so it always selects th first command.
    select(0) if index != 0
  end
 
  def update
    super
    do_sprite_anim
    check_enter_exit_state
  end
   
  def update_cursor
    # No need for this so I might as well disable it, right?
  end
 
  def start_exit_anim
    select(-1) # Unselect any active command!
    # Wait until all commands are at their initial position!
    until @cpics_state.all? {|sym,dt| dt == :idle }
      Graphics.update
      do_sprite_anim
    end
    @cpics_state.each do |sym,state| # Start the exit animation!
      @cpics_state[sym] = :exit
    end
  end
 
  def check_enter_exit_state
    # Activate the window IF the entering animation is finished!
    if @cpics_state.all? {|sym,dt| dt != :enter } && !@entered
      @entered = true
      if @esel
        info = @data.find {|key,item| item[:symbol] == current_symbol }
        if !info.nil?
          info = info[1]
          if !info[:pic][:anim].nil?
            @prate = info[:pic][:anim][:wait]
            @pframes = info[:pic][:anim][:frames]
            @cpics[current_symbol].src_rect.y = 0
            @animater = 0; @picid = 0
          else
            @prate = -1
            @pframes = -1
          end
          @flasher = 999999
          @cpics_state[current_symbol] = :active
        end
      else
        activate; select_last
      end
    end
    # Exit the scene IF the exit animation is finished!
    if @cpics_state.all? {|sym,dt| dt == :exit_now }
      SceneManager.scene.exit_now
    end
  end
 
  # Update picture animation if applicable!
  def do_pic_anim
    if current_symbol && @cpics_state[current_symbol] == :idle && @entered
      return if @prate == -1
      @animater += 1
      if @animater % @prate == 0
        @picid += 1
        patt = @pframes[@picid % @pframes.size]
        @cpics[current_symbol].src_rect.y = patt*@cpics[current_symbol].src_rect.height
      end
    end
  end
 
  # Update periodical flashing if applicable!
  def do_flash_anim
    if current_symbol && @cpics_state[current_symbol] == :idle && @entered
      info = @data.find {|key,item| item[:symbol] == current_symbol }
      info = info[1]
      return if info[:flash].nil?
      if @flasher > info[:flash][:wait]
        @flasher = 0
        @cpics[current_symbol].flash(Color.new(*info[:flash][:color]),info[:flash][:dur])
      end
      @flasher += 1
    end
  end
 
  # Update any animation and command button sprites!
  def do_sprite_anim
    @cpics.each do |sym,sprite|
      case @cpics_state[sym]
      when :enter
        do_inout_anim(sym,sprite,:enter)
      when :active
        do_activation_anim(sym,sprite) if @cpics_state[sym] != :exit
      when :inactive
        do_deactivation_anim(sym,sprite) if @cpics_state[sym] != :exit
      when :exit
        do_inout_anim(sym,sprite,:exit)
      end
      sprite.update
    end
    do_pic_anim
    do_flash_anim
  end
 
  # The entering and exiting animation logic!
  def do_inout_anim(sym,sprite,type)
    info = @data.find {|key,item| item[:symbol] == sym }
    info = info[1]
    info[type] = {} if info[type].nil?
    return @cpics_state[sym] = :exit_now if info[type].nil? && type == :exit
    # Moving on X axis:
    if info[type][:pos] && sprite.x != info[type][:pos][:end][0]
      if info[type][:pos][:start][0] < info[type][:pos][:end][0]
        sprite.x += info[type][:pos][:speed][0]
        sprite.x = [sprite.x,info[type][:pos][:end][0]].min
      elsif info[type][:pos][:start][0] > info[type][:pos][:end][0]
        sprite.x -= info[type][:pos][:speed][0]
        sprite.x = [sprite.x,info[type][:pos][:end][0]].max
      end
    else
      x_move_end = true
    end
    # Moving on Y axis:
    if info[type][:pos] && sprite.y != info[type][:pos][:end][1]
      if info[type][:pos][:start][1] < info[type][:pos][:end][1]
        sprite.y += info[type][:pos][:speed][1]
        sprite.y = [sprite.y,info[type][:pos][:end][1]].min
      elsif info[type][:pos][:start][1] > info[type][:pos][:end][1]
        sprite.y -= info[type][:pos][:speed][1]
        sprite.y = [sprite.y,info[type][:pos][:end][1]].max
      end
    else
      y_move_end = true
    end
    # Setting opacity :
    if info[type][:opa] && sprite.opacity != info[type][:opa][:end]
      if info[type][:opa][:start] < info[type][:opa][:end]
        sprite.opacity += info[type][:opa][:speed]
        sprite.opacity = [sprite.opacity,info[type][:opa][:end]].min
      elsif info[type][:opa][:start] > info[type][:opa][:end]
        sprite.opacity -= info[type][:opa][:speed]
        sprite.opacity = [sprite.opacity,info[type][:opa][:end]].max
      end
    else
      opa_end = true
    end
    # Setting zoom_x :
    if info[type][:zoom] && info[type][:zoom][:x] && sprite.zoom_x != info[type][:zoom][:x][:end]
      if info[type][:zoom][:x][:start] < info[type][:zoom][:x][:end]
        sprite.zoom_x += info[type][:zoom][:x][:speed]
        sprite.zoom_x = [sprite.zoom_x,info[type][:zoom][:x][:end]].min
      elsif info[type][:zoom][:x][:start] > info[type][:zoom][:x][:end]
        sprite.zoom_x -= info[type][:zoom][:x][:speed]
        sprite.zoom_x = [sprite.zoom_x,info[type][:zoom][:x][:end]].max
      end
    else
      zoom_x_end = true
    end
    # Setting zoom_y :
    if info[type][:zoom] && info[type][:zoom][:y] && sprite.zoom_y != info[type][:zoom][:y][:end]
      if info[type][:zoom][:y][:start] < info[type][:zoom][:y][:end]
        sprite.zoom_y += info[type][:zoom][:y][:speed]
        sprite.zoom_y = [sprite.zoom_y,info[type][:zoom][:y][:end]].min
      elsif info[type][:zoom][:y][:start] > info[type][:zoom][:y][:end]
        sprite.zoom_y -= info[type][:zoom][:y][:speed]
        sprite.zoom_y = [sprite.zoom_y,info[type][:zoom][:y][:end]].max
      end
    else
      zoom_y_end = true
    end
    # Checking if entering/exiting animation is finished:
    if [x_move_end,y_move_end,opa_end,zoom_x_end,zoom_y_end].all? {|dt| !dt.nil? && dt == true}
      case type
      when :enter
        @cpics_state[sym] = :idle
      when :exit
        SceneManager.scene.exit_now
      end
    end
  end
   
  # The activation animation logic!
  def do_activation_anim(sym,sprite) # activation animation
    info = @data.find {|key,item| item[:symbol] == sym }
    info = info[1]
    info[:anim] = {} if info[:anim].nil?
    # Setting correct blending mode:
    ss = check_cmd?(info[:enable]) ? :a : :da
    if info[:blend] && sprite.blend_type != info[:blend][ss]
      sprite.blend_type = info[:blend][ss]
    end
    # Adjusting X pos:
    if info[:anim][:pos] && sprite.x != info[:enter][:pos][:end][0] + info[:anim][:pos][:move][0]
      if info[:anim][:pos][:move][0] > 0
        sprite.x += info[:anim][:pos][:speed][0]
        sprite.x = [sprite.x,info[:enter][:pos][:end][0] + info[:anim][:pos][:move][0]].min
      elsif info[:anim][:pos][:move][0] < 0
        sprite.x -= info[:anim][:pos][:speed][0]
        sprite.x = [sprite.x,info[:enter][:pos][:end][0] + info[:anim][:pos][:move][0]].max
      end
    else
      x_move_end = true
    end
    # Adjusting Y pos:
    if info[:anim][:pos] && sprite.y != info[:enter][:pos][:end][1] + info[:anim][:pos][:move][1]
      if info[:anim][:pos][:move][1] > 0
        sprite.y += info[:anim][:pos][:speed][1]
        sprite.y = [sprite.y,info[:enter][:pos][:end][1] + info[:anim][:pos][:move][1]].min
      elsif info[:anim][:pos][:move][1] < 0
        sprite.y -= info[:anim][:pos][:speed][1]
        sprite.y = [sprite.y,info[:enter][:pos][:end][1] + info[:anim][:pos][:move][1]].max
      end
    else
      y_move_end = true
    end
    # Adjusting opacity:
    if info[:anim][:opa] && sprite.opacity != info[:anim][:opa][:end]
      if info[:anim][:opa][:start] < info[:anim][:opa][:end]
        sprite.opacity += info[:anim][:opa][:speed]
        sprite.opacity = [sprite.opacity,info[:anim][:opa][:end]].min
      elsif info[:anim][:opa][:start] > info[:anim][:opa][:end]
        sprite.opacity -= info[:anim][:opa][:speed]
        sprite.opacity = [sprite.opacity,info[:anim][:opa][:end]].max
      end
    else
      opa_end = true
    end
    # Setting zoom_x :
    if info[:anim][:zoom] && info[:anim][:zoom][:x] && sprite.zoom_x != info[:anim][:zoom][:x][:end]
      if info[:anim][:zoom][:x][:start] < info[:anim][:zoom][:x][:end]
        sprite.zoom_x += info[:anim][:zoom][:x][:speed]
        sprite.zoom_x = [sprite.zoom_x,info[:anim][:zoom][:x][:end]].min
      elsif info[:anim][:zoom][:x][:start] > info[:anim][:zoom][:x][:end]
        sprite.zoom_x -= info[:anim][:zoom][:x][:speed]
        sprite.zoom_x = [sprite.zoom_x,info[:anim][:zoom][:x][:end]].max
      end
    else
      zoom_x_end = true
    end
    # Setting zoom_y :
    if info[:anim][:zoom] && info[:anim][:zoom][:y] && sprite.zoom_y != info[:anim][:zoom][:y][:end]
      if info[:anim][:zoom][:y][:start] < info[:anim][:zoom][:y][:end]
        sprite.zoom_y += info[:anim][:zoom][:y][:speed]
        sprite.zoom_y = [sprite.zoom_y,info[:anim][:zoom][:y][:end]].min
      elsif info[:anim][:zoom][:y][:start] > info[:anim][:zoom][:y][:end]
        sprite.zoom_y -= info[:anim][:zoom][:y][:speed]
        sprite.zoom_y = [sprite.zoom_y,info[:anim][:zoom][:y][:end]].max
      end
    else
      zoom_y_end = true
    end
    # Setting red tone:
    if info[:tone] && sprite.tone.red != info[:tone][:a][0]
      if info[:tone][:a][0] > info[:tone][:i][0]
        sprite.tone.red += info[:tone][:speed]
        sprite.tone.red = [sprite.tone.red,info[:tone][:a][0]].min
      elsif info[:tone][:a][0] < info[:tone][:i][0]
        sprite.tone.red -= info[:tone][:speed]
        sprite.tone.red = [sprite.tone.red,info[:tone][:a][0]].max
      end
    else
      r_done = true
    end
    # Setting green tone:
    if info[:tone] && sprite.tone.green != info[:tone][:a][1]
      if info[:tone][:a][1] > info[:tone][:i][1]
        sprite.tone.green += info[:tone][:speed]
        sprite.tone.green = [sprite.tone.green,info[:tone][:a][1]].min
      elsif info[:tone][:a][1] < info[:tone][:i][1]
        sprite.tone.green -= info[:tone][:speed]
        sprite.tone.green = [sprite.tone.green,info[:tone][:a][1]].max
      end
    else
      g_done = true
    end
    # Setting blue tone:
    if info[:tone] && sprite.tone.blue != info[:tone][:a][2]
      if info[:tone][:a][2] > info[:tone][:i][2]
        sprite.tone.blue += info[:tone][:speed]
        sprite.tone.blue = [sprite.tone.blue,info[:tone][:a][2]].min
      elsif info[:tone][:a][2] < info[:tone][:i][2]
        sprite.tone.blue -= info[:tone][:speed]
        sprite.tone.blue = [sprite.tone.blue,info[:tone][:a][2]].max
      end
    else
      b_done = true
    end
    # Setting gray tone:
    if info[:tone] && sprite.tone.gray != info[:tone][:a][3]
      if info[:tone][:a][3] > info[:tone][:i][3]
        sprite.tone.gray += info[:tone][:speed]
        sprite.tone.gray = [sprite.tone.gray,info[:tone][:a][3]].min
      elsif info[:tone][:a][3] < info[:tone][:i][3]
        sprite.tone.gray -= info[:tone][:speed]
        sprite.tone.gray = [sprite.tone.gray,info[:tone][:a][3]].max
      end
    else
      gr_done = true
    end
    # Checking if activation animation is finished:
    if [x_move_end,y_move_end,opa_end,zoom_x_end,zoom_y_end,r_done,g_done,b_done,gr_done].all? {|dt| !dt.nil? && dt == true}
      @cpics_state[sym] = :idle
    end
  end
 
  # The deactivation animation logic!
  def do_deactivation_anim(sym,sprite) # deactivation animation
    info = @data.find {|key,item| item[:symbol] == sym }
    info = info[1]
    info[:anim] = {} if info[:anim].nil?
    # Setting correct blending mode:
    ss = check_cmd?(info[:enable]) ? :i : :di
    if info[:blend] && sprite.blend_type != info[:blend][ss]
      sprite.blend_type = info[:blend][ss]
    end
    # Adjusting X pos:
    if info[:anim][:pos] && sprite.x != info[:enter][:pos][:end][0]
      if info[:anim][:pos][:move][0] > 0
        sprite.x -= info[:anim][:pos][:speed][0]
        sprite.x = [sprite.x,info[:enter][:pos][:end][0]].max
      elsif info[:anim][:pos][:move][0] < 0
        sprite.x += info[:anim][:pos][:speed][0]
        sprite.x = [sprite.x,info[:enter][:pos][:end][0]].min
      end
    else
      x_move_end = true
    end
    # Adjusting Y pos:
    if info[:anim][:pos] && sprite.y != info[:enter][:pos][:end][1]
      if info[:anim][:pos][:move][1] > 0
        sprite.y -= info[:anim][:pos][:speed][1]
        sprite.y = [sprite.y,info[:enter][:pos][:end][1]].max
      elsif info[:anim][:pos][:move][1] < 0
        sprite.y += info[:anim][:pos][:speed][1]
        sprite.y = [sprite.y,info[:enter][:pos][:end][1]].min
      end
    else
      y_move_end = true
    end
    # Adjusting opacity:
    if info[:anim][:opa] && sprite.opacity != info[:anim][:opa][:start]
      if info[:anim][:opa][:start] < info[:anim][:opa][:end]
        sprite.opacity -= info[:anim][:opa][:speed]
        sprite.opacity = [sprite.opacity,info[:anim][:opa][:start]].max
      elsif info[:anim][:opa][:start] > info[:anim][:opa][:end]
        sprite.opacity += info[:anim][:opa][:speed]
        sprite.opacity = [sprite.opacity,info[:anim][:opa][:start]].min
      end
    else
      opa_end = true
    end
    # Setting zoom_x :
    if info[:anim][:zoom] && info[:anim][:zoom][:x] && sprite.zoom_x != info[:anim][:zoom][:x][:start]
      if info[:anim][:zoom][:x][:start] < info[:anim][:zoom][:x][:end]
        sprite.zoom_x -= info[:anim][:zoom][:x][:speed]
        sprite.zoom_x = [sprite.zoom_x,info[:anim][:zoom][:x][:start]].max
      elsif info[:anim][:zoom][:x][:start] > info[:anim][:zoom][:x][:end]
        sprite.zoom_x += info[:anim][:zoom][:x][:speed]
        sprite.zoom_x = [sprite.zoom_x,info[:anim][:zoom][:x][:start]].min
      end
    else
      zoom_x_end = true
    end
    # Setting zoom_y :
    if info[:anim][:zoom] && info[:anim][:zoom][:y] && sprite.zoom_y != info[:anim][:zoom][:y][:start]
      if info[:anim][:zoom][:y][:start] < info[:anim][:zoom][:y][:end]
        sprite.zoom_y -= info[:anim][:zoom][:y][:speed]
        sprite.zoom_y = [sprite.zoom_y,info[:anim][:zoom][:y][:start]].max
      elsif info[:anim][:zoom][:y][:start] > info[:anim][:zoom][:y][:end]
        sprite.zoom_y += info[:anim][:zoom][:y][:speed]
        sprite.zoom_y = [sprite.zoom_y,info[:anim][:zoom][:y][:start]].min
      end
    else
      zoom_y_end = true
    end
    # Setting red tone:
    if info[:tone] && sprite.tone.red != info[:tone][:i][0]
      if info[:tone][:i][0] > info[:tone][:a][0]
        sprite.tone.red += info[:tone][:speed]
        sprite.tone.red = [sprite.tone.red,info[:tone][:i][0]].min
      elsif info[:tone][:i][0] < info[:tone][:a][0]
        sprite.tone.red -= info[:tone][:speed]
        sprite.tone.red = [sprite.tone.red,info[:tone][:i][0]].max
      end
    else
      r_done = true
    end
    # Setting green tone:
    if info[:tone] && sprite.tone.green != info[:tone][:i][1]
      if info[:tone][:i][1] > info[:tone][:a][1]
        sprite.tone.green += info[:tone][:speed]
        sprite.tone.green = [sprite.tone.green,info[:tone][:i][1]].min
      elsif info[:tone][:i][1] < info[:tone][:a][1]
        sprite.tone.green -= info[:tone][:speed]
        sprite.tone.green = [sprite.tone.green,info[:tone][:i][1]].max
      end
    else
      g_done = true
    end
    # Setting blue tone:
    if info[:tone] && sprite.tone.blue != info[:tone][:i][2]
      if info[:tone][:i][2] > info[:tone][:a][2]
        sprite.tone.blue += info[:tone][:speed]
        sprite.tone.blue = [sprite.tone.blue,info[:tone][:i][2]].min
      elsif info[:tone][:i][2] < info[:tone][:a][2]
        sprite.tone.blue -= info[:tone][:speed]
        sprite.tone.blue = [sprite.tone.blue,info[:tone][:i][2]].max
      end
    else
      b_done = true
    end
    # Setting gray tone:
    if info[:tone] && sprite.tone.gray != info[:tone][:i][3]
      if info[:tone][:i][3] > info[:tone][:a][3]
        sprite.tone.gray += info[:tone][:speed]
        sprite.tone.gray = [sprite.tone.gray,info[:tone][:i][3]].min
      elsif info[:tone][:i][3] < info[:tone][:a][3]
        sprite.tone.gray -= info[:tone][:speed]
        sprite.tone.gray = [sprite.tone.gray,info[:tone][:i][3]].max
      end
    else
      gr_done = true
    end
    # Checking if deactivation animation is finished:
    if [x_move_end,y_move_end,opa_end,zoom_x_end,zoom_y_end,r_done,g_done,b_done,gr_done].all? {|dt| !dt.nil? && dt == true}
      @cpics_state[sym] = :idle
    end
  end
   
  # Making 'em commands and command sprites!
  def make_command_list
    @cpics = {} if @cpics.nil?; @cpics_state = {} if @cpics_state.nil?
    @data.each do |id,data|
      # Making the sprite if there is no sprite with the :symbol yet!
      if @cpics[data[:symbol]].nil?
        @cpics_state[data[:symbol]] = :enter
        if check_cmd?(data[:show]) && check_cmd?(data[:enable])
          pic = Cache.menuhud(data[:pic][:e],@folder)
        elsif check_cmd?(data[:show]) && !check_cmd?(data[:enable])
          pic = Cache.menuhud(data[:pic][:d],@folder)
        else
          pic = Cache.menuhud(data[:pic][:h],@folder)
        end
        @cpics[data[:symbol]] = Sprite.new
        @cpics[data[:symbol]].x = data[:enter][:pos][:start][0]
        @cpics[data[:symbol]].y = data[:enter][:pos][:start][1]
        @cpics[data[:symbol]].z = data[:z]
        @cpics[data[:symbol]].opacity = data[:enter][:opa][:start]
        @cpics[data[:symbol]].zoom_x = data[:enter][:zoom][:x][:start]
        @cpics[data[:symbol]].zoom_y = data[:enter][:zoom][:y][:start]
        @cpics[data[:symbol]].tone = Tone.new(*data[:tone][:i])
        @cpics[data[:symbol]].bitmap = pic
        row = data[:pic][:anim] ? data[:pic][:anim][:rows] : 1
        height = @cpics[data[:symbol]].bitmap.height/row
        @cpics[data[:symbol]].src_rect.height = height
        @cpics[data[:symbol]].ox = @cpics[data[:symbol]].bitmap.width/2
        @cpics[data[:symbol]].oy = height/2
        bl = check_cmd?(data[:enable]) ? data[:blend][:i] : data[:blend][:di]
        @cpics[data[:symbol]].blend_type = bl
      end
      next unless check_cmd?(data[:show])
      # Adding the commands:
      add_command(data[:name],data[:symbol],check_cmd?(data[:enable]),data[:extra])
    end
  end
 
  # Checking method for enable and show states!
  def check_cmd?(data)
    case data
    when Integer
      return $game_switches[data]
    when Symbol
      return method(data).call
    when String
      return eval(data)
    else
      return data
    end
  end
 
  # Disposing the command sprites!
  def dispose_cmd_pics
    @cpics.each_value do |sprite|
      sprite.bitmap.dispose
      sprite.dispose
    end
  end
 
  def dispose
    dispose_cmd_pics
    super
  end
 
  # Correcting this method now!
  def select_last
    select_symbol(@@last_command_symbol) if !@@last_command_symbol.nil?
    select(0) if @@last_command_symbol.nil?
  end
 
end
 
class Window_MenuStatus < Window_Selectable
 
  def window_width
    MCommands::StatusWindow[:size][0]
  end
 
  def window_height
    MCommands::StatusWindow[:size][1]
  end
 
end
 
class Scene_Menu < Scene_MenuBase
 
  # Remaking the command window and setting correct handlers!
  # NOTE: The cancel handler has been changed!
  def create_command_window
    @command_window = SpriteCommands.new(MCommands::Commands,
                              MCommands::ImgFolder[:main],MCommands::Selection)
    MCommands::Commands.each do |id,data|
      @command_window.set_handler(data[:symbol],method(data[:method]))
    end
    @command_window.set_handler(:cancel,method(:init_exiting))
  end
 
  # Duhh...
  def create_status_window
    pos = MCommands::StatusWindow[:pos]
    @status_window = Window_MenuStatus.new(pos[0],pos[1])
    @status_window.opacity = MCommands::StatusWindow[:opa]
  end
 
  # Executing the script command if any!
  def do_the_script
    data = @command_window.current_ext
    if !data.nil? && data.is_a?(String)
      eval(data)
    else
      @command_window.activate
    end
  end
 
  # Executing the common event command if any!
  def do_the_event
    data = @command_window.current_ext
    if !data.nil? && data.is_a?(Integer)
      $game_temp.reserve_common_event(data)
      init_exiting
    else
      @command_window.activate
    end
  end
 
  # The new :cancel handler!
  # This initiates the exiting animation for the command window.
  def init_exiting
    @command_window.start_exit_anim
  end
 
  # This gets executed after the exiting animation is finished to exit the
  # scene for real.
  def exit_now
    if $game_temp.common_event_reserved?
      SceneManager.goto(Scene_Map)
    else
      return_scene
    end
  end
 
end
#==============================================================================
# !!END OF SCRIPT!!
#==============================================================================