# Here's the thing:
# Vlue's Formation Bonus script will break the moving animation 
# (any kind of it) in Yami's Battle Symphony.
# We will fix that one too with the edits below! 
# First, head over to Vlue's script and at the top of the script, insert these lines:
 $imported = {} if $imported.nil?$imported["Formation-Bonus"] = true 
# Second, find the following(s): def screen_xdef screen_y 
# Comment out these (the whole definition, not only the single lines!). 
# There, you are done here, move over to the Symphony script.
# Find the following lines: 
def set_default_position 
# Here you need to replace the following lines:       
@origin_x = @screen_x = @destination_x = SYMPHONY::View::ACTORS_POSITION[index][0]
@origin_y = @screen_y = @destination_y = SYMPHONY::View::ACTORS_POSITION[index][1] 
# With these lines:     
if $imported["Formation-Bonus"]      
@origin_x = @screen_x = @destination_x = FORMATION_LOCATIONS[@formation_slot][0] + 180 
@origin_y = @screen_y = @destination_y = FORMATION_LOCATIONS[@formation_slot][1] + 180 
else      
@origin_x = @screen_x = @destination_x = SYMPHONY::View::ACTORS_POSITION[index][0]
@origin_y = @screen_y = @destination_y = SYMPHONY::View::ACTORS_POSITION[index][1]
end 
# Notice the numbers '180' at the end of those 2 lines there? 
# That will be the offset of your actors horizontally and vertically.
# That one is necessary, because 'FORMATION_LOCATIONS[@formation_slot]' will return the direct co-ordinates on the screen 
# of your actors from the Formation Bonus scene, so it is very likely that your actors will be in some rather "unusual" places
# on the battle screen without these offsets. Edit those numbers freely to change
# your actors' position in the battle, and yet
# maintain the original formation of your actors. 
# Moving on, we are not done here just yet...
# Scroll a bit down and you should see the following line:   
def correct_origin_position 
# Here we need to replace these lines:     
@origin_x = @screen_x = SYMPHONY::View::ACTORS_POSITION[index][0]    
@origin_y = @screen_y = SYMPHONY::View::ACTORS_POSITION[index][1] 
# With these:     
if $imported["Formation-Bonus"]      
@origin_x = @screen_x = FORMATION_LOCATIONS[@formation_slot][0] + 180      
@origin_y = @screen_y = FORMATION_LOCATIONS[@formation_slot][1] + 180    
else    @origin_x = @screen_x = SYMPHONY::View::ACTORS_POSITION[index][0]    
@origin_y = @screen_y = SYMPHONY::View::ACTORS_POSITION[index][1]    
end 
# The numbers at the end ('180') are for the same reason like before, 
# and they should be the same numbers as above.
# Do NOT insert different numbers here than those you set above or "strange" 
# things will happen! 
# And this should be it! We managed to mix the 2 scripts with 100% working 
# functions from both scripts. Enjoy!