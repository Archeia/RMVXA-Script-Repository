# To ensure that at least 1HP damage occurs

class RPG::BaseItem

attr_accessor :no_min_dmg

def no_min_dmg
init_no_min_dmg if @no_min_dmg.nil?
return @no_min_dmg
end

def init_no_min_dmg
@no_min_dmg = @note =~ /<no min dmg>/i ? true : false
end

end

class Game_ActionResult

alias add_min_dmg6681 make_damage
def make_damage(value, item)
if value == 0 && !item.no_min_dmg
value = item.damage.recover? ? -1 : 1
end
add_min_dmg6681(value, item)
end

end