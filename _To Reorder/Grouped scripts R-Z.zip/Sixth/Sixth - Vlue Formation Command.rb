# These 2 scripts use the same button from the menu by default. 
# Obviously, anyone who uses both scripts would not want it like this.
# So, let's fix this little issue!
# Let's start with commenting out these lines in the Formation Bonus script:
class Scene_Menu  
def command_formation    
SceneManager.call(Scene_Formation)  
end
end
# This will eliminate the button for this script, 
# so we will need to make a new one to use.
# To do that insert these lines below the commented lines from before
class Window_MenuCommand < Window_Command  
alias formation1_command 
 add_original_commands  
def add_original_commands    
 formation1_command    
 add_command("Formation1", :formation1)  
end
end
# Now the only thing we need to do is to insert these lines below the above lines
if $imported["YEA-AceMenuEngine"] 
#This line is optional only for Yanfly's Menu Engine scriptclass 
 Scene_Menu < Scene_MenuBase  
alias formation1_menu13211             
 create_command_window  #--------------------------------------------------------------------------  
 # * Create Command Window  #--------------------------------------------------------------------------  
def create_command_window    
 formation1_menu13211()    
 @command_window.set_handler:)formation1, method:)command_formation1))  
end  
 #--------------------------------------------------------------------------  
 # * New Formation Command  #--------------------------------------------------------------------------  
def command_formation1    
 SceneManager.call(Scene_Formation)  
end 
end
end  
#This line is optional only for Yanfly's Menu Engine script
# With this, there should be a new button for calling the Formation Bonus Scene.
# Note that this actually names your command button as 'Formation1' 
# which is not a very decorative name for it...
# For renaming it to whatever you want, just change the "Formation1" 
# to anything you like at 'Window_MenuCommand'.
# There, now you can call Vlue's Formation Bonus Scene and 
# Yanfly's Party System Scene without any of them conflicting 
# with each other. Nice!
# Extra note:
# If you are inserting the new command button with Yanfly's Menu Engine script, 
# you do NOT need to add 'Window_MenuCommand' 
# or else you will get a duplicate command button.
# Use either the normal way or Yanly's Menu Engine way, but not both!
# By default, all of your actors will appear in the Formation Bonus Scene, 
# but only in the actual position window.
# There is no way to select them, but still, they will be there if your 
# active party member's size is lower than the 
# whole party size, aka you got more characters than you can take into battle. 
# This is annoying for two reasons:
# 1. Not very decorative, which is the least of our problem now.
# 2. They will count to the actual formation. Just an example:
# We got a 3-man battle party system, so 3 characters can participate 
# in the battle at max.
# During the game, we recruited 3 other characters to the party. 
# Now we got 6 party members total.
# But we can still take only 3 into the battle. So, logically, 
# the other 3 should not appear at all in the Formation Bonus Scene,
# because they are not in the battle, which also means they should not 
# be in the formation at all.
# Yet, by default, they are. They will count toward the needed positions also, 
# which actually breaks the whole system. 
# But with my really little edit below, this can be fixed.
# However, by doing these edits, you will not be able to change your 
# active party members from the menu
# without Yanfly's Party System script. What? Ohh, right, 
# you were not able to do that from the moment you 
# inserted the Formation Bonus script. Which is another side effect which 
# will need to be fixed for those who are not using
# Yanfly's Party System. But, as I don't really need it, 
# I am not planning to do anything about this one for now.
# The thing that needs to be edited for this is 'def item_max' as 
# that one is actually bound 
# by your maximum battle members' number. You would also need to change 
# which number from the items (items are your actors now)
# are counted towards the formation bonus, and which one will actually 
# appear in the position window. This number should be
# equal to your maximum battle members' size. And that should be the basics of it, 
# but it is always easier in theory than 
# in practice, so I will just leave it in theory for now. 
# If you don't want to bother with this, just use Yanfly's Party System, easy "fix". 
# So, after all these words, let's get started! 
# Search for the first two lines like this in the script:     
# 	members.each do |actor| 
# And replace both of them with this:     
# 	battle_members.each do |actor| 
# This will hide any actor that is currently not in your active battle party 
# from the Formation Bonus Scene. 
# And that's all, folks! This was a really quick one, right?