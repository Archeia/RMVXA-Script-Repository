=begin
 
- Status Display Change
- Requires: Sixth's Custom Parameters script
- Made by: Sixth
 
This script will change the parameter and equipment display in the status menu.
It will let you display the parameters from my Custom Parameters script too.
 
This is made for the default status menu, so it will most probably not work
with custom status menu scripts.
 
=end
module CPrmDisp
 
  # Enter the parameters you want to show on the status screen into the :show
  # setting array.
  # You can display default parameters by entering their ID.
  # To display your custom parameters made by my script, enter their setting
  # key.
  # Order them however you want, add as many as you want.
  # Adjust the other visual settings as you see fit.
  Stats = {
    :show => [
      2,3,4,5,6,7,
      'str','dex','vit','res','spi','sta','blk','skl','pro','rge','cha','mor',
    ],
    :pos => [4,163], # Position of the first parameter drawn.
    :size => [100,24], # Size reserved for 1 parameter.
    :rows => 6, # Maximum rows shown.
    :spacing => [8,2], # Horizontal and vertical spacing between each parameter.
    :padding => [4,1], # Padding of the text in the display box.
    :box => Color.new(100,100,100,128), # Display box color.
  }
 
  # Setup how the equipment display will look like here.
  Equips = {
    :empty => ["Empty", 185], # The word and icon displayed for empty equip slots.
    :pos => [330, 163], # Position of the first equipment drawn.
    :size => [186,24], # Size reserved for 1 equipment.
    :rows => 6, # Maximum rows shown.
    :spacing => [8,2], # Horizontal and vertical spacing between each equipment.
    :padding => [4,1], # Padding of the text in the display box.
    :box => Color.new(100,100,100,128), # Display box color.
  }
 
end
# End of settings! No touchy-touchy below! o.o
 
class Window_Base < Window
 
  def draw_actor_cparam(actor, x, y, w, h, stat)
    change_color(system_color)
    draw_text(x, y, w, h, CustomParams::Params[stat][:short])
    change_color(normal_color)
    draw_text(x, y, w, h, actor.send(stat), 2)
  end
 
end
 
class Window_Status < Window_Selectable
   
  def draw_block3(y)
    dt = CPrmDisp::Stats; edt = CPrmDisp::Equips
    draw_stats_ex(*dt[:pos],*dt[:size],dt[:rows],dt[:spacing],dt[:padding],dt[:box])
    draw_equipments(*edt[:pos],*edt[:size],edt[:rows],edt[:spacing],edt[:padding],edt[:box])
  end
 
  def draw_stats_ex(x,y,w,h,rows,sp,pad,color)
    CPrmDisp::Stats[:show].each_with_index do |prm,i|
      yy = i % rows * (h + sp[1]) + y
      xx = (i / rows * (w + sp[0])) + x
      contents.fill_rect(xx,yy,w,h,color)
      if CustomParams::Params.include?(prm) # Custom parameter
        draw_actor_cparam(@actor, xx+pad[0], yy+pad[1], w-pad[0]*2, h-pad[1]*2, prm)
      else # Default parameter
        draw_actor_param_ex(@actor, xx+pad[0], yy+pad[1], w-pad[0]*2, h-pad[1]*2, prm)
      end
    end
  end
 
  def draw_equipments(x,y,w,h,rows,sp,pad,color)
    @actor.equips.each_with_index do |item, i|
      yy = i % rows * (h + sp[1]) + y
      xx = (i / rows * (w + sp[0])) + x
      contents.fill_rect(xx,yy,w,h,color)
      if item.nil? # No equip on slot
        draw_empty_slot(xx+pad[0], yy+pad[1], w-pad[0]*2, h-pad[1]*2)
      else # Equipped item
        draw_item_name(item, xx+pad[0], yy+pad[1], true, w-pad[0]*2, h-pad[1]*2)
      end
    end
  end
 
  def draw_empty_slot(x, y, w, h)
    draw_icon(CPrmDisp::Equips[:empty][1], x, y + (h-24)/2)
    change_color(normal_color,false)
    draw_text(x + 26, y, w, h, CPrmDisp::Equips[:empty][0])
  end
   
  def draw_item_name(item, x, y, enabled = true, w = 172, h = 24)
    return unless item
    draw_icon(item.icon_index, x, y + (h-24)/2, enabled)
    change_color(normal_color, enabled)
    draw_text(x + 26, y, w, h, item.name)
  end
 
  def draw_actor_param_ex(actor, x, y, w, h, param_id)
    change_color(system_color)
    draw_text(x, y, w, h, Vocab::param(param_id))
    change_color(normal_color)
    draw_text(x, y, w, h, actor.param(param_id), 2)
  end
 
end
# End of script! O_O