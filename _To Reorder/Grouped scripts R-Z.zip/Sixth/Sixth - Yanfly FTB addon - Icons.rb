=begin
 
Actor Based Action Icons for YEA FTB
Made by: Sixth
Requires: Yanfly's Free Turn Battle script
 
This little snippet will let you change the action amount display in Yanfly's
Free Turn Battle script.
By default, all of the actions use the same icon, but with this script, the
action icons can indicate which actors have some actions left and which of them
used up their action points already.
 
You can setup a custom action icon set for your actors by using this note-tag
on them:
 
  <ftb icon: normal_icon, used_icon>
 
Replace the normal_icon part with the index of the icon for unused action
points.
Replace the used_icon part with the index of the icon for used action points.
 
If an actor got no such note-tag, it will use the default icons setup in
Yanfly's FTB script.
 
Place this script below Yanfly's Free Turn Battle script!
 
=end
 
class RPG::Actor < RPG::BaseItem
 
  attr_accessor :ftb_icon
 
  def ftb_icon
    init_ftb_icon if @ftb_icon.nil?
    return @ftb_icon
  end
 
  def init_ftb_icon
    if @note =~ /<ftb icon:(?:\s*)(\d+),(?:\s*)(\d+)>/i
      @ftb_icon = [$1.to_i,$2.to_i]
    else
      @ftb_icon = [YEA::FTB::ICON_ACTION,YEA::FTB::ICON_EMPTY]
    end
  end
 
end
 
class Game_Actor < Game_Battler
 
  def ftb_icon
    return actor.ftb_icon
  end
 
end
 
class Window_FTB_Gauge < Window_Base
 
  def refresh
    contents.clear
    collect_icons
    draw_icons
  end
 
  def collect_icons
    @icons = {:used => [], :rem => []}
    $game_party.members.reverse.each do |mem|
      next unless mem.game_battlerbase_inputable_ftb
      rem = mem.max_ftb_actions - mem.ftb_actions
      @icons[:rem] << [mem.ftb_icon[0],rem]
      @icons[:used] << [mem.ftb_icon[1],mem.ftb_actions]
    end
  end
 
  def draw_icons
    dx = contents.width
    @icons[:rem].values.each do |dt|
      dt[1].times do
        dx -= 24
        draw_icon(dt[0], dx, 0)
      end
    end
    @icons[:used].each do |dt|
      dt[1].times do
        dx -= 24
        draw_icon(dt[0], dx, 0)
      end
    end
  end
   
end
# End of script! O_O