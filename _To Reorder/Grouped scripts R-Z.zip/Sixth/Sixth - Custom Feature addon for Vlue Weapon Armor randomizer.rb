#===============================================================================
# * [ACE] Custom Feature Extension for Vlue's Randomizer
#===============================================================================
# * Made by: Sixth (www.rpgmakervxace.net, www.forums.rpgmakerweb.com)
# * Version: 1.3
# * Updated: 22/05/2015
# * Requires: Vlue's W/A Randomizer script
#-------------------------------------------------------------------------------
# * < Change Log >
#-------------------------------------------------------------------------------
# * Version 1.0 (04/01/2015)
#   - Initial release.
# * Version 1.1 (05/01/2015)
#   - Fixed a crash issue. Opss! >.>
# * Version 1.2 (22/03/2015)
#   - Added several new options to change the item's properties, any of them!
#     This includes things like damage formula, scope, element type, etc.
#     Well, everything is included, literally.
#   - Added an option to add new notes into the notefield of the new item.
#     This makes it possible to add any custom effects from any custom scripts
#     easily for your randomized items! That is if they use note-tags to get the
#     new custom effects onto the item, of course.
#     There is also an option to completely replace the current note-field with
#     a new text, if you want.
# * Version 1.3 (26/05/2015)
#   - Fixed the issue of note-field settings not working.
#-------------------------------------------------------------------------------
# * < Description >
#-------------------------------------------------------------------------------
# * This script will rewrite some methods from Vlue's Randomizer script for 
#   my Enchant System, therefore this is required for my Enchant System script.
# * This script will also add additional options for you to use for setting up 
#   your affixes in Vlue's W/A Randomizer script.
#   These new options are:
#   - Possibility of setting up random items too, not just equips!
#   - Currently includes new affix setup options for the following scripts:
#     ~ Convert Damage (Yanfly)
#     ~ Critical Hit Effects (Victor)
#     ~ Element Strengthen (Victor)
# * From version 1.2, you can change your randomized items even further!
#   Changing damage formulas, hit types, scopes, occasions, element types, and
#   all other properties is possible now!
# * Adding new notes to the note-field is also possible now!
#------------------------------------------------------------------------------- 
# * < Instructions >
#-------------------------------------------------------------------------------
# * New affix options for making randomized items:
#
# ~ For adding random effects onto your items:
# 
#   :effects => [[e.code,data_id,val1,val2]],
#   #Examples: :effects => [[11,0,0,120],[12,0,0.1,0]], :effects => [[43,63,0,0]],
#
#   Replace 'e.code' with the effect's effect code. See the list below!
#   Replace 'data_id' with the data ID of the effect. See list below!
#   Replace 'val1' and 'val2' with the power of the effect.
#   Some effects use 2 values, that is why there are two of them in the setup.
#   See the list below for possible and valid value setups!
#               
#   You can define multiple effects for the affixes as shown in the examples!
#
#   Here is the list of item effect codes and valid setups for them:
#
#      effect       code         data_id              value1          value2
#   HP Heal      ->  11 -> data_id is always 0 -> val1 is float -> val2 is integ
#   MP Heal      ->  12 -> data_id is always 0 -> val1 is float -> val2 is integ 
#   TP Gain      ->  13 -> data_id is always 0 -> val1 is integ -> val2 is alw 0
#   Add State    ->  21 -> data_id = state IDs -> val1 is float -> val2 is alw 0 
#   Rem State    ->  22 -> data_id = state IDs -> val1 is float -> val2 is alw 0
#   Add Buff     ->  31 -> data_id = param IDs -> val1 is integ -> val2 is alw 0 
#   Add Debuff   ->  32 -> data_id = param IDs -> val1 is integ -> val2 is alw 0 
#   Rem Buff     ->  33 -> data_id = param IDs -> val1 is alw 0 -> val2 is alw 0 
#   Rem Debuff   ->  34 -> data_id = param IDs -> val1 is alw 0 -> val2 is alw 0 
#   Spec Effect  ->  41 -> data_id is always 0 -> val1 is alw 0 -> val2 is alw 0 
#   Grow         ->  42 -> data_id = param IDs -> val1 is alw 0 -> val2 is alw 0 
#   Learn Skill  ->  43 -> data_id = skill IDs -> val1 is alw 0 -> val2 is alw 0 
#   Common Event ->  44 -> data_id = event IDs -> val1 is alw 0 -> val2 is alw 0
#
#   float = -0.1, 0.03, -2.4, 1.34, etc. - Usually represents percentages.
#   integ = 1, -3, -345, 460, 5600, etc. - Usually represents direct values.
#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
# * New affix options for changing the item's properties (items only!):
#
#     :scope => value,
#   This changes the scope of the item. Valid values are:
#   0 = None, 1 = One Enemy, 2 = All Enemy, 3 = 1 Random Enemy,
#   4 = 2 Random Enemies, 5 = 3 Random Enemies, 6 = 4 Random Enemies,
#   7 = 1 Ally, 8 = All Allies, 9 = One Ally (Dead), 10 = All Allies (Dead),
#   11 = The User
#
#     :occasion => value,
#   This changes the occasion of the item. Valid values are:
#   0 = Always, 1 = Only In Battle, 2 = Only From the Menu, 3 = Never
#
#     :speed => value,
#   Changes the speed of the item. Uses integer values.
#
#     :success_rate => value,
#   Changes the success rate of the item. Uses integer values, 100 = 100%.
# 
#     :repeats => value,
#   Changes the repeat times of the item. Uses integer values from 1 to 9.
#
#     :tp_gain => value,
#   Changes the TP gain for using the item. Uses integer values.
#
#     :hit_type => value,
#   Changes the hit type of the item. Valid values are:
#   0 = Certain Hit, 1 = Physical Attack, 2 = Magical Attack
#
#     :damage_type => value,
#   Changes the damage type of the item. Valid values are:
#   0 = None, 1 = HP Damage, 2 = MP Damage, 3 = HP Recovery, 4 = MP Recovery,
#   5 = HP Drain, 6 = MP Drain
#
#     :element_id => value,
#   Changes the element type of the damage. Uses element IDs for the value.
#   0 means it is a normal, non-elemental damage, the rest takes the elements
#   from the database.
#
#     :dmg_formula => "formula",
#   Changes the damage formula of the item. It is a string, and got the same 
#   properties like the damage formula in the database, meaning you can use
#   the same stuffs in it like there (a = attacker, b = user, v = variables, etc).
#
#     :dmg_variance => value,
#   Changes the damage variance of the item. Uses integer values.
#
#     :critical => true/false,
#   Changes the critical flag for the item. If true, the item can hit criticals,
#   if false, criticals will be disabled for the item.
#
#     :consumable => true/false,
#   Changes the consumable flag for the item. If true, the item will be consumed
#   upon usage, if false, it will not be consumed even after usage.
#
#     :itype => value,
#   Changes the item's type. Valid values:
#   1 = Regular Item, 2 = Key Item
#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
# * New affix options for changing the note field of the items or adding extra 
#   notes for the items (any item, meaning items, weapons or armors):
#
#     :addnote => "text"
#   Adds the specified text to the note field of the item. 
#   This way, people can add any extra effects from custom scripts which 
#   operate with note-tags on items. Handy tool!
#
#     :replacenote => "text"
#   Replaces the original note field with the text defined for the items entirely.
#   The replace happens before anything else is added to the notes with the above
#   option, make sure to keep this in mind!
#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
# * New affix options for Yanfly's Convert Damage script:
#
# ~ For adding a convert damage feature, you can use this new option:
#
#     :convert_damage => [[effect,value]],
#     #Examples: :convert_damage => [[:hp_physical,0.05],[:mp_physical,0.01]], 
#                :convert_damage => [[:mp_magical,0.1]],
#
#   Replace 'effect' with a valid effect symbol.
#   Valid symbols: :hp_physical, :hp_magical, :mp_physical, :mp_magical.
#   Replace 'value' with the power of the effect.
#   The 'value' uses float values, so 0.1 means 10%, 0.5 means 50%, 1.0 means 100%.
#   You can define as many convert damage features as you want for an affix
#   with a single ':convert_damage' setup as shown in the examples!
#
# ~ For adding an anti-convert feature, you can use this new option:
#
#     :anticonvert => [effect],
#     #Examples: :anticonvert => [:hp_magical,:mp_physical], 
#                :anticonvert => [:mp_magical],
#
#   Replace 'effect' with a valid effect symbol.
#   Valid symbols: :hp_physical, :hp_magical, :mp_physical, :mp_magical.
#   You can define as many anti-convert features as you want for an affix
#   with a single ':anticonvert' setup as shown in the examples!
#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
# * New affix options for Victor's Critical Hit Effects script:
#
# ~ For adding a critical damage feature, you can use this new option:
#   
#     :cri_dmg => value,  #Examples: :cri_dmg => 60, :cri_dmg => -20,
#   
#   Replace the 'value' with the percentage bonus you want to add for the item.
#   The 'value' represents percentages, so 1 = 1%, -20 = -20%, 100 = 100%, etc.
#
# ~ For adding a critical defense feature, you can use this new option:
#
#     :cri_def => value,  #Examples: :cri_def => 40, :cri_def => -50,
#   
#   Replace the 'value' with the percentage bonus you want to add for the item.
#   The 'value' represents percentages, so 1 = 1%, -20 = -20%, 100 = 100%, etc.
#
# ~ For adding a critical state add feature, you can use this new option:
#
#     :cri_state_add => [[state_id,chance],[state_id,chance]],
#     #Examples: :cri_state_add => [[2,20],[3,30]], :cri_state_add => [[4,14]],
#
#   Replace 'state_id' with the ID of the state you want to use for the feature.
#   Replace 'chance' with the chance of occurence of the effect.
#   The 'chance' value represents percentages, so 10 = 10%, 50 = 50%, etc.
#   You can define as many crit state add features as you want for an affix
#   with a single ':cri_state_add' setup as shown in the examples!
#
# ~ For adding a critical state remove feature, you can use this new option:
#
#     :cri_state_rem => [[state_id,chance],[state_id,chance]],
#     #Examples: :cri_state_rem => [[1,8],[4,52]], :cri_state_rem => [[6,34]],
#
#   Replace 'state_id' with the ID of the state you want to use for the feature.
#   Replace 'chance' with the chance of occurence of the effect.
#   The 'chance' value represents percentages, so 10 = 10%, 50 = 50%, etc.
#   You can define as many crit state remove features as you want for an affix
#   with a single ':cri_state_rem' setup as shown in the examples!
#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
# * New affix options for Victor's Element Strengthen script:
#
# ~ For adding an element strengthen feature, you can use this new option:
#
#     :ele_str => [[element_id,value],[element_id,value]],
#     #Examples: :ele_str => [[3,20],[4,-28]], :ele_str => [[6,36]],
#
#   Replace 'element_id' with the ID of the element you want to use for the feature.
#   Replace 'value' with the strenght of the effect.
#   The 'value' represents percentages, so 10 = 10%, 50 = 50%, etc.
#   You can define as many element strengthen features as you want for an affix
#   with a single ':ele_str' setup as shown in the examples!
#------------------------------------------------------------------------------- 
# * < Installation >
#-------------------------------------------------------------------------------
# * Put this scipt below Vlue's W/A Randomizer but above Main!
#-------------------------------------------------------------------------------
# * < Compatibility Info >
#-------------------------------------------------------------------------------
# * No known incompatibilities.
#-------------------------------------------------------------------------------
# * < Known Issues >
#-------------------------------------------------------------------------------
# * No known issues.
#-------------------------------------------------------------------------------
# * < Terms of Use >
#-------------------------------------------------------------------------------
# * Free to use for whatever purposes you want.
# * Credit me (Sixth) in your game, pretty please! :P
# * Posting modified versions of this script is allowed as long as you notice me
#   about it with a link to it!
#===============================================================================
$imported = {} if $imported.nil?
$imported["SixthRandomizerEX"] = true
#===============================================================================
# Settings:
#===============================================================================

#Stack random item, when false all items are unique
STACK_SAME_ITEM = true

#===============================================================================
# End of Settings Part!
# Editing below may lead to malfunctioning brain-cells! You have been warned!
#===============================================================================

class Game_Party

  attr_accessor :saved_items

  alias sixth_ini_ritems1222 initialize
  def initialize
    sixth_ini_ritems1222
    @saved_items = $data_items
  end

  def add_weapon(id, amount, false_add = false, subnote=nil)
    item = Marshal.load(Marshal.dump($data_weapons[id]))
    edit_item(item)
    edit_affixes(item, subnote)
    if STACK_SAME_EQUIP
      $data_weapons.each do |base_item|
        next if base_item.nil?
        if ( item.params == base_item.params && 
            item.features.size == base_item.features.size &&
            item.price == base_item.price &&
            item.name == base_item.name &&
            item.color == base_item.color)
          $game_party.gain_item(base_item, amount) unless false_add
          return base_item
        end
      end
    end
    item.note += @extra_note if !@extra_note.nil?
    item.note += @extra_note2 if !@extra_note2.nil?
    item.set_original(item.id)
    item.id = $data_weapons.size
    $data_weapons.push(item)
    $game_party.gain_item(item, amount) unless false_add
    return item
  end
  
  def add_armor(id, amount, false_add = false, subnote=nil)
    item = Marshal.load(Marshal.dump($data_armors[id]))
    edit_item(item)
    edit_affixes(item, subnote)
    if STACK_SAME_EQUIP
      $data_armors.each do |base_item|
        next if base_item.nil?
        if ( item.params == base_item.params && 
            item.features.size == base_item.features.size &&
            item.price == base_item.price &&
            item.name == base_item.name &&
            item.color == base_item.color)
          $game_party.gain_item(base_item, amount) unless false_add
          return base_item
        end
      end
    end
    item.note += @extra_note if !@extra_note.nil?
    item.note += @extra_note2 if !@extra_note2.nil?
    item.set_original(item.id)
    item.id = $data_armors.size
    $data_armors.push(item)
    $game_party.gain_item(item, amount) unless false_add
    return item
  end
 
  def add_item(id, amount, false_add = false, subnote=nil)
    item = Marshal.load(Marshal.dump($data_items[id]))
    edit_item(item)
    edit_affixes(item, subnote)
    if STACK_SAME_ITEM
      $data_items.each do |base_item|
        next if base_item.nil?
        if (item.price == base_item.price && 
            item.effects.size == base_item.effects.size &&
            item.name == base_item.name &&
            item.color == base_item.color)
          $game_party.gain_item(base_item, amount) unless false_add
          return base_item
        end
      end
    end
    item.note += @extra_note if !@extra_note.nil?
    item.note += @extra_note2 if !@extra_note2.nil?
    item.set_original(item.id)
    item.id = $data_items.size
    $data_items.push(item)
    $game_party.gain_item(item, amount) unless false_add
    return item
  end
  
  alias sixth_enchant_affix1223 add_affix
  def add_affix(item, id, prefix)
    affix = AFFIXES[id.to_i]
    if prefix
      @extra_note = ""
    else
      @extra_note2 = ""
    end
    # For adding/changing the note field of the items.
    item.note = affix[:replacenote] if !affix[:replacenote].nil?
    item.note = item.note + affix[:addnote] if !affix[:addnote].nil?
    # For Victor's Critical Hit Effects
    if prefix && !affix[:cri_dmg].nil?
      @extra_note += "\r\n<critical damage: #{affix[:cri_dmg]}%>"
    elsif !affix[:cri_dmg].nil?
      @extra_note2 += "\r\n<critical damage: #{affix[:cri_dmg]}%>"
    end
    if prefix && !affix[:cri_def].nil?
      @extra_note += "\r\n<critical defense: #{affix[:cri_def]}%>"
    elsif !affix[:cri_def].nil?
      @extra_note2 += "\r\n<critical defense: #{affix[:cri_def]}%>"
    end
    if prefix && !affix[:cri_state_add].nil?
      for state in affix[:cri_state_add]
        @extra_note += "\r\n<critical state add: #{state[0]}, #{state[1]}%>"
      end
    elsif !affix[:cri_state_add].nil?
      for state in affix[:cri_state_add]
        @extra_note2 += "\r\n<critical state add: #{state[0]}, #{state[1]}%>"
      end
    end
    if prefix && !affix[:cri_state_rem].nil?
      for state in affix[:cri_state_rem]
        @extra_note += "\r\n<critical state remove: #{state[0]}, #{state[1]}%>"
      end
    elsif !affix[:cri_state_rem].nil?
      for state in affix[:cri_state_rem]
        @extra_note2 += "\r\n<critical state remove: #{state[0]}, #{state[1]}%>"
      end
    end
    # For Victor's Element Strengthen
    if prefix && !affix[:ele_str].nil?
      for element in affix[:ele_str]
        @extra_note += "\r\n<element strenghten #{element[0]}: #{element[1]}%>"
      end
    elsif !affix[:ele_str].nil?
      for element in affix[:ele_str]
        @extra_note2 += "\r\n<element strenghten #{element[0]}: #{element[1]}%>"
      end
    end
    # For Yanfly's Convert Damage effects
    if !affix[:convert_damage].nil? && !item.is_a?(RPG::Item)
      for conv_dmg in affix[:convert_damage]
        item.convert_dmg[conv_dmg[0]] = conv_dmg[1]
      end
    end
    if !affix[:anticonvert].nil? && !item.is_a?(RPG::Item)
      for anti_conv in affix[:anticonvert]
        item.anticonvert.push(anti_conv)
      end
    end
    # For item effects
    if item.is_a?(RPG::Item) 
      # Item effects
      if !affix[:effects].nil?
        for effect in affix[:effects]
          new_effect = RPG::UsableItem::Effect.new(effect[0], effect[1], effect[2], effect[3])
          item.effects.push(new_effect)
        end
      end
      # Item properties
      item.scope = affix[:scope] if !affix[:scope].nil?
      item.occasion = affix[:occasion] if !affix[:occasion].nil?
      item.speed = affix[:speed] if !affix[:speed].nil?
      item.success_rate = affix[:success_rate] if !affix[:success_rate].nil?
      item.repeats = affix[:repeats] if !affix[:repeats].nil?
      item.tp_gain = affix[:tp_gain] if !affix[:tp_gain].nil?
      item.hit_type = affix[:hit_type] if !affix[:hit_type].nil?
      item.damage.type = affix[:damage_type] if !affix[:damage_type].nil?
      item.damage.element_id = affix[:element_id] if !affix[:element_id].nil?
      item.damage.formula = affix[:dmg_formula] if !affix[:dmg_formula].nil?
      item.damage.variance = affix[:dmg_variance] if !affix[:dmg_variance].nil?
      item.damage.critical = affix[:critical] if !affix[:critical].nil?
      item.consumable = affix[:consumable] if !affix[:consumable].nil?
      item.itype_id = affix[:itype] if !affix[:itype].nil?
    end
    sixth_enchant_affix1223(item, id, prefix)
  end
  
end

class Scene_Load
  
  alias sixth_load_ritems1222 on_load_success
  def on_load_success
    sixth_load_ritems1222
    $data_items = $game_party.saved_items
  end
  
end
#==============================================================================
# !!END OF SCRIPT!!
#==============================================================================