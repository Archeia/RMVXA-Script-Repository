=begin

Negative Bonus Fix for Vlue's W/A Randomizer v1.1
Made by: Sixth

This snippet fixes the negative random stat gains from affixes in 
Vlue's W/A Randomizer script.
Without this fix, you would gain positive stats even if you specified a 
negative stat gain for your affixes. 
This bug only affected the random parameter bonuses, the static ones are fine.

Also, with this snippet installed, the note-tags for the basic parameter
randomization for your equipment has been sligthly altered to allow negative
stat "bonuses" as well.
Nothing changed in it's format, you just have to enter a + or - before the
value, the rest is the same.
Examples:

 - Old:         - New:           - Negative versions:
  <ATK 15>       <ATK +15>        <ATK -15>
  <LUK% 50>      <LUK% +50>       <LUK% -50>
  <PRICE 10>     <PRICE +10>      <PRICE -10>
  
So, use the new versions from now on!

And finally, this snippet will fix some issues with my 
Equipment Parameter Description script, so if you are planning to use that,
you will have to use this one too to avoid display errors!

Put this script right below Vlue's W/A Randomizer script!

=end

class Game_Party < Game_Unit

  def rrand(value)
    base = rand(value)
    base *= -1 if value < 0
    return base
  end
  
  def add_affix(item, id, prefix)
    affix = AFFIXES[id.to_i]
    if prefix && !affix[:name].nil?
      item.name = affix[:name] + item.name
    elsif !affix[:name].nil?
      item.name = item.name + affix[:name]  
    end
    if !affix[:rarity].nil?
      if item.rarity.nil? || item.rarity < affix[:rarity]
        item.set_color(affix[:color]) if !affix[:color].nil?
        item.rarity = affix[:rarity]
      end
    else
      item.set_color(affix[:color]) if !affix[:color].nil?
    end
    item.change_desc(:desc,affix[:desc]) if affix[:desc]
    item.change_desc(:pdesc,affix[:pdesc]) if affix[:pdesc]
    item.change_desc(:sdesc,affix[:sdesc]) if affix[:sdesc]
    if !item.is_a?(RPG::Armor) && !affix[:animation].nil?
      item.animation_id = affix[:animation]
    end
    item.icon_index = affix[:icon] if !affix[:icon].nil?
    if !item.is_a?(RPG::Item)
      [:hp,:mp,:atk,:def,:mat,:mdf,:agi,:luk].each_with_index do |prm,i|
        next unless affix[prm]
        item.params[i] += rrand(affix[prm])
      end
      [:Shp,:Smp,:Satk,:Sdef,:Smat,:Smdf,:Sagi,:Sluk].each_with_index do |prm,i|
        next unless affix[prm]
        item.params[i] += affix[prm]
      end
      [:hpP,:mpP,:atkP,:defP,:matP,:mdfP,:agiP,:lukP].each_with_index do |prm,i|
        next unless affix[prm]
        add = item.params[i] * (rrand(affix[prm])) * 0.01
        item.params[i] += add.to_i
      end
      [:ShpP,:SmpP,:SatkP,:SdefP,:SmatP,:SmdfP,:SagiP,:SlukP].each_with_index do |prm,i|
        next unless affix[prm]
        add = item.params[i] * affix[prm] * 0.01
        item.params[i] += add.to_i
      end
    end
    item.price += rrand(affix[:price]) if affix[:price]
    item.price += affix[:Sprice] if affix[:Sprice]
    if affix[:priceP]
      add = item.price * (rrand(affix[:priceP])) * 0.01
      item.price += add.to_i
    end
    if affix[:SpriceP]
      add = item.price * affix[:SpriceP] * 0.01
      item.price += add.to_i
    end
    if !affix[:features].nil? && !item.is_a?(RPG::Item)
      for feature in affix[:features]
        new_feature = RPG::BaseItem::Feature.new(*feature)
        item.features.push(new_feature)
      end
    end
    return true
  end
  
  def set_static_bonus(item,param,i)
    if item.note =~ /<#{param} ([+\-]\d+)>/i
      item.params[i] += rrand($1.to_i)
    end
  end
  
  def set_percent_bonus(item,param,i)
    if item.note =~ /<#{param}% ([+\-]\d+)>/i
      add = item.params[i] * rrand($1.to_i) * 0.01
      item.params[i] += add.to_i
    end
  end
  
  def edit_item(item)
    if !item.is_a?(RPG::Item)
      ["HP","MP","ATK","DEF","MAT","MDF","AGI","LUK"].each_with_index do |param,i|
        set_static_bonus(item,param,i)
        set_percent_bonus(item,param,i)
      end
    end
    item.price += rrand($1.to_i) if item.note =~ /<PRICE ([+\-]\d+)>/
    if item.note =~ /<PRICE% ([+\-]\d+)>/
      add = item.price * rrand($1.to_i) * 0.01
      item.price += add.to_i
    end    
  end

end

class RPG::BaseItem

  def change_desc(type,atxt)
    case type
    when :dessc
      @description = atxt
    when :pdesc
      @description = atxt + @description
    when :sdesc
      @description = @description + atxt
    end
  end
  
end
#==============================================================================
# !!END OF SCRIPT!!
#==============================================================================