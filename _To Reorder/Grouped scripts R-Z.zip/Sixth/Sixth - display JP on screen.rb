#Jp Display Version 1.0

#Fix to Yanfly's JP Manager to display the JP on screen in the ACE Menu Engine
#To use, install below the JP manager and below the ACE Menu Engine
#Script should work without Ace Menu Engine installed, but the draw_actor_jp
#line may need to be modified.

#Terms of Use: Free for commercial and non-commercial games
#Credit: Credit should be given to Yanfly as it is their system. No credit
#required to me (bgillisp) for the edit. 


class Window_Base < Window
  @bg_display_string
  
  #--------------------------------------------------------------------------
  # alias method: draw_actor_simple_status
  #--------------------------------------------------------------------------
  alias bg_jpdisplay_draw_actor_simple_status draw_actor_simple_status
  def draw_actor_simple_status(actor, dx, dy)
    #Call Original Method
    bg_jpdisplay_draw_actor_simple_status(actor, dx, dy)
    
    #Set the dy value to be the same as in Ace Menu Engine
    #May need to comment this line out if not using Ace Menu Engine
    dy -= line_height / 2
    
    #Draw the jp on screen. Jp will appear below the MP bar, and to the 
    #far right. If you wish to have jp displayed closer to the left, reduce 
    #the number being added to dx
    draw_actor_jp(actor, dx + 230, dy + line_height * 3)
    
  end
  
end # Window_Base