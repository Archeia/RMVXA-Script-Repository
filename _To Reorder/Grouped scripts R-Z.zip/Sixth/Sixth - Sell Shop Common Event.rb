=begin
Shop Sell Common Events
Made by: Sixth
 
Just a very short snippet for allowing sold items to trigger common events.
 
Use this note-tag:
 
  <ce trigger: comon_event_id>
 
Replace the common_event_id with the ID of the... common event you want to
trigger when the item is sold.
You can use this note-tag on items, weapons and armors.
 
Note that the common event will run only after the event that triggered the shop
actually ends.
 
=end
 
class RPG::BaseItem
 
  attr_accessor :ce_trigger
 
  def ce_trigger
    init_ce_trigger if @ce_trigger.nil?
    return @ce_trigger
  end
 
  def init_ce_trigger
    @ce_trigger = @note =~ /<ce trigger:(?:\s*)(\d+)>/i ? $1.to_i : 0
  end
 
end
 
class Scene_Shop < Scene_MenuBase
 
  alias add_ce_trigger6614 do_sell
  def do_sell(num)
    add_ce_trigger6614(num)
    if @item.ce_trigger > 0
      $game_temp.reserve_common_event(@item.ce_trigger)
      SceneManager.goto(Scene_Map)
    end
  end
 
end
# End of script! o.o