#===============================================================================
# * [ACE] Toolbar Addon for Falcao's Pearl ABS Liquid v3
#===============================================================================
# * Made by: Sixth (www.rpgmakervxace.net, www.forums.rpgmakerweb.com)
# * Version: 1.8
# * Updated: 28/11/2016
# * Requires: Falcao's Pearl ABS Liquid v3
#             Cidiomar's Perfect Pixel Collision System
#             Cidiomar's Collision Helper
#-------------------------------------------------------------------------------
# * < Change Log >
#-------------------------------------------------------------------------------
# * Version 1.0 (26/09/2015)
#   - Initial release.
# * Version 1.1 (29/09/2015)
#   - Fixed a weird crash issue.
# * Version 1.2 (05/10/2015)
#   - Added an option to use images for your cooldown masks.
#     Now you can use other shapes for them, not just squares or rectangles.
#   - Added a switch setting to hide/show the toolbar without turning off the
#     entire ABS script.
# * Version 1.3 (26/02/2016)
#   - Fixed an ammo coloring issue.
#   - Skills can now properly show item cost as well.
#     TP display takes priority over MP display, and MP display takes priority
#     over item cost display. This applies to the color of cost display as well.
# * Version 1.4 (09/08/2016)
#   - Now properly shows the cooldown for dual wield characters (2 weapons).
#     This was fixed before, but forgot to include it in the change log. o.o
#   - Fixed an incorrect update method. Minor performance increase.
# * Version 1.5 (30/09/2016)
#   - Major update! From now on, this script requires Cidiomar's
#     Perfect Pixel Collision System! This one works better and quicker.
#   - Added settings to adjust the Z level of the toolbar images.
#   - Fixed a bug with the ammo display.
#   - Fixed a bug with the cooldown display.
# * Version 1.6 (30/10/2016)
#   - Added compatibility with my Control Configuration System.
#     Now you can show the correct key-binds on your toolbars regardless of how
#     the player changed them in my control configuration menu.
# * Version 1.7 (18/11/2016)
#   - Fixed a bug with the item cost display.
# * Version 1.8 (28/11/2016)
#   - Fixed a bug with the item cost display... Again. >.>
#-------------------------------------------------------------------------------
# * < Description >
#-------------------------------------------------------------------------------
# * This script will add complete control over the toolbar of the ABS.
# * Set up the position of each icon, letter and tool cost data.
# * Font setting for the cost and letter displays.
# * Disable any icon from the toolbar if you want.
#   Just be aware that it won't actually disable the tool trigger, only hide
#   the graphical display of it!
# * Separate settings for the 3 scenes where the toolbar can appear.
# * Changed the display method of the cooldown data. It will not the use simple
#   number countdown anymore. Instead, it will use a gradient/image mask which
#   fills up depending on the cooldown time. Many RPGs use this kind of cooldown
#   display, and it looks way better this way, in my opinion.
# * Option to toggle the visibility of the on-map toolbar anytime with a switch.
#-------------------------------------------------------------------------------
# * < Installation >
#-------------------------------------------------------------------------------
# * Place this script below the last script from Falcao's Pearl ABS Liquid v3
#   script series but above Main!
# * Place this script below Cidiomar's Collision Helper script!
# * If you are using my Stat Bonus Addon script, you must place this script
#   below that one too!
# * In case you can't find Cidiomar's Perfect Pixel Collision System:
#   http://himeworks.com/redirect.php?type=demo&name=image_collision_detection
#   That is a link to the script's demo. Thanks Tsukihime for the backup!
# * Don't forget to put Cidiomar's CollisionDetection.dll into the System folder
#   of your project!
#-------------------------------------------------------------------------------
# * < Compatibility Info >
#-------------------------------------------------------------------------------
# * No known incompatibilities.
#-------------------------------------------------------------------------------
# * < Known Issues >
#-------------------------------------------------------------------------------
# * Mouse functionality is broken at the moment, so you can't use the toolbar
#   by clicking on the icons. This will only affect your game if you use
#   Falcao's mouse addon.
#   Will try to fix this in the next update.
#-------------------------------------------------------------------------------
# * < Terms of Use >
#-------------------------------------------------------------------------------
# * Free to use for whatever purposes you want.
# * Credit me (Sixth) in your game, pretty please! :P
# * Posting modified versions of this script is allowed as long as you notice me
#   about it with a link to it!
#===============================================================================
$imported = {} if $imported.nil?
$imported["SixthABSToolBarAddon"] = true
#===============================================================================
# Settings:
#===============================================================================
module PearlSkillBar
  #-----------------------------------------------------------------------------
  # Toolbar Switch Settings:
  #-----------------------------------------------------------------------------
  # You can set up a switch to toggle the visibility of the toolbar on the map.
  # When this switch is ON, the toolbar is shown, when it is OFF, the toolbar
  # is hidden. This will only affect the toolbar on the map!
  # You can set it to 0 if you don't want to use this feature.
  #-----------------------------------------------------------------------------  
  ToolBarSwitch = 0
 
  #-----------------------------------------------------------------------------
  # Background Position Settings:
  #-----------------------------------------------------------------------------
  # You can set up the position of the background used for the toolbar here.
  # This will move the whole toolbar!
  # You can set up a setting for the 3 scenes separately.
  # Format: :scene => [x,y],
  # The position settings are measured in pixels, NOT in tiles!
  #-----------------------------------------------------------------------------
  Position = {
    :map => [14,110],       # For the map toolbar.
    :toolmenu => [14,110],  # For the quick tool menu.
    :charmenu => [14,110],  # For the character selection menu.
  }
 
  #-----------------------------------------------------------------------------
  # Background Image Settings:
  #-----------------------------------------------------------------------------
  # You can set up the background image used for the toolbar here.
  # You can set up different images for the 3 scenes separately.
  # The images must be placed in the "Graphics\Pictures" folder of your game!
  #-----------------------------------------------------------------------------
  LayoutImg = {
    :map => "SkillBarFinal",       # For the map toolbar.
    :toolmenu => "SkillBarFinal",  # For the quick tool menu.
    :charmenu => "SkillBarFinal",  # For the character selection menu.
  }
 
  #-----------------------------------------------------------------------------
  # Priority Settings:
  #-----------------------------------------------------------------------------
  # You can setup the Z level of each images on the toolbar here.
  # In case you want to show the icons below the background image or the ammo
  # below the cooldown mask, you can set them up however you want to.
  # Images with higher values set here will show up above the ones with lower
  # values!
  # Also, if some images from another custom script would appear above the
  # toolbar and you don't want that, try to increase the values here, that might
  # solve that issue.
  # ----------
  # :back = Background image.
  # :icons = Icon display.
  # :cool = Cooldown display.
  # :ammo = Ammo display.
  # :letters = Button letter display.
  #-----------------------------------------------------------------------------
  Priority = {
    :map => { # Map toolbar settings:
      :back => 0, :icons => 1, :cool => 2, :ammo => 3, :letters => 4,
    },
    :toolmenu => { # Quick tool selection menu toolbar settings:
      :back => 0, :icons => 1, :cool => 2, :ammo => 3, :letters => 4,
    },
    :charmenu => { # Character selection menu toolbar settings:
      :back => 0, :icons => 1, :cool => 2, :ammo => 3, :letters => 4,
    },
  }
 
  #-----------------------------------------------------------------------------
  # Enable Settings:
  #-----------------------------------------------------------------------------
  # You can enable/disable some features here.
  # Currently only one feature can be disabled.
  # true = enabled, false = disabled.
  #-----------------------------------------------------------------------------
  EnableSettings = {
    :letters => false, # Button letters.
  }
 
  #-----------------------------------------------------------------------------
  # Button Display Mode Settings:
  #-----------------------------------------------------------------------------
  # Can't really call these "letter settings" anymore, because with my control
  # configuration system, you can choose how do you want to display the required
  # button for triggering your tools.
  # You can choose from 3 types:
  # :name - This will diplay the name of the button with text.
  # :icon - This will diplay the icon of the button.
  # :img  - This will diplay the custom image of the button.
  # In all cases, only the first key-bind will be displayed for each tool type!
  #
  # If you don't have my control configuration system installed, this setting
  # will not do anything! In that case, the default drawing method will be used.
  #-----------------------------------------------------------------------------
  LetterTypes = {
    :map => :name,
    :toolmenu => :name,
    :charmenu => :name,
    :sixthmenu => :name,
  }
 
  #-----------------------------------------------------------------------------
  # Font Settings:
  #-----------------------------------------------------------------------------
  # Set up the font properties used for the letter and ammo display.
  # :type = The name of the font type used. (array of strings)
  # :size = The size of the font. (integer)
  # :bold = Bold the font or not? (true/false)
  # :color = The color of the font. Uses RGBA codes!
  #          Format: Color.new(R,G,B,A),
  # ----------
  # NOTE:
  # A skill tool will only display it's MP or TP cost, and only one of them!
  # The TP cost is prioritized, so if a skill got both TP and MP cost,
  # only the TP cost will be displayed!
  # For this reason, if you want to display item cost for your tools, make them
  # as items, instead of skills. Items will always display the current number
  # of ammo in the party's inventory, but only if the tool actually requires
  # ammo!
  #-----------------------------------------------------------------------------
  Fonts = {
    :letters => { # Button letters.
      :type => ["Gabriola"], :size => 36, :bold => true,
      :color => Color.new(250,180,50,255),
    },
    :ammo => { # Ammo display.
      :type => ["Tw Cen MT Condensed"], :size => 16, :bold => true,
      :color => {
        :item => Color.new(255,255,255,255), # Color for the item cost.
        :mp => Color.new(110,160,255,255),   # Color for the MP cost.
        :tp => Color.new(255,80,80,255),     # Color for the TP cost.
      },
    },
  }
 
  #-----------------------------------------------------------------------------
  # Cooldown Display Settings:
  #-----------------------------------------------------------------------------
  # You can set up various settings used for the mask in the cooldown display
  # here. You can choose to use an image for your masks, or use the default
  # gradient drawing.
  # The image used must be in the "Graphics/Pictures" folder of your game!
  # The color settings for the default gradient type masks use RGBA codes!
  # The cooldown mask will be drawn above the tool icons. Once a tool with
  # cooldown is used, the mask will appear above the used tool's icon, and will
  # start to shrink vertically, from the bottom to the top.
  # When the mask disappears, the tool can be used again.
  # Remember that you need to set the cooldown display to true for your tools,
  # or else it will not be displayed!
  #-----------------------------------------------------------------------------
  CoolDisplay = {
    :useimg => true,             # Enable image type masks? (true/false)
    :coolimg => "coolfill1",     # Image used for the masks. (string)
    :coolopa => 250,             # Opacity of the image type masks. (0 - 255)
    :f1 => Color.new(0,0,0,160), # Fill color 1 for gradient type masks. (RGBA)
    :f2 => Color.new(0,0,0,160), # Fill color 2 for gradient type masks. (RGBA)
  }
 
  #-----------------------------------------------------------------------------
  # Cooldown Refresh Settings:
  #-----------------------------------------------------------------------------
  # You can set up the refresh rate of the cooldown display here.
  # There should be no performance issues with the new cooldown display, even if
  # it is refreshed in every frame, but in case you notice an FPS drop, you can
  # try to set this to higher values.
  # 1 means that the cooldown masks will be refreshed in every frame.
  # 2 means that it will be refreshed after every 2nd frame, and so on.
  # Note that if you set this to any value other than 1, your cooldown mask
  # display might not be accurate!
  #-----------------------------------------------------------------------------
  CoolRefreshRate = 1
 
  #-----------------------------------------------------------------------------
  # Map Toolbar Settings:
  #-----------------------------------------------------------------------------
  # This is the placce to set up the position of everything in the toolbar.
  # This setting affects the map toolbar only!
  # ----------
  # :icon = Position settings for the tool icons.
  # :cool = Position settings for the cooldown masks.
  # :ammo = Position settings for the ammo/cost display.
  # :letter = Position settings for the button letters.
  # ----------
  # :weapon = Settings for the weapon tool.
  # :armor = Settings for the armor tool.
  # :item1 = Settings for the 1st item tool.
  # :item2 = Settings for the 2nd item tool.
  # :skill1 = Settings for the 1st skill tool.
  # :skill2 = Settings for the 2nd skill tool.
  # :skill3 = Settings for the 3rd skill tool.
  # :skill4 = Settings for the 4th skill tool.
  # :toggle = Settings for the follower toggle icon.
  # ----------
  # :pos = Position settings. Format: :pos => [x,y],
  # :size = Size settings. Format: :size => [width,height],
  # :align = Alignment settings. 0 = Left, 1 = Middle, 2 = Right.
  # ----------
  # If you don't want to show a tool, simply comment out it's line, just like
  # I did with the 3rd and 4th tool, and with the follower toggle icon.
  #-----------------------------------------------------------------------------
  MapSettings = {
    :icon => {
      :weapon => {:pos => [1,15]},
      :armor =>  {:pos => [1,56]},
      :item1 =>  {:pos => [1,97]},
      :item2 =>  {:pos => [1,126]},
      :skill1 => {:pos => [1,167]},
      :skill2 => {:pos => [1,196]},
     # :skill3 => {:pos => [1,196]},
     # :skill4 => {:pos => [1,196]},
     # :toggle => {:pos => [1,196]},
    },
    :cool => {
      :weapon => {:pos => [17,27], :size => [24,24]},
      :armor =>  {:pos => [17,68], :size => [24,24]},
      :item1 =>  {:pos => [17,109], :size => [24,24]},
      :item2 =>  {:pos => [17,138], :size => [24,24]},
      :skill1 => {:pos => [17,179], :size => [24,24]},
      :skill2 => {:pos => [17,208], :size => [24,24]},
     # :skill3 => {:pos => [17,208], :size => [24,24]},
     # :skill4 => {:pos => [17,208], :size => [24,24]},
     # :toggle => {:pos => [17,208], :size => [24,24]},
    },
    :ammo => {
      :weapon => {:pos => [37,17], :size => [32,32], :align => 1},
      :armor =>  {:pos => [37,58], :size => [32,32], :align => 1},
      :item1 =>  {:pos => [37,99], :size => [32,32], :align => 1},
      :item2 =>  {:pos => [37,128], :size => [32,32], :align => 1},
      :skill1 => {:pos => [37,169], :size => [32,32], :align => 1},
      :skill2 => {:pos => [37,198], :size => [32,32], :align => 1},
     # :skill3 => {:pos => [37,198], :size => [32,32], :align => 1},
     # :skill4 => {:pos => [37,198], :size => [32,32], :align => 1},
     # :toggle => {:pos => [37,198], :size => [32,32], :align => 1},
    },
    :letter => {
      :weapon => {:pos => [17,27], :size => [24,24], :align => 1},
      :armor =>  {:pos => [17,68], :size => [24,24], :align => 1},
      :item1 =>  {:pos => [17,109], :size => [24,24], :align => 1},
      :item2 =>  {:pos => [17,138], :size => [24,24], :align => 1},
      :skill1 => {:pos => [17,179], :size => [24,24], :align => 1},
      :skill2 => {:pos => [17,208], :size => [24,24], :align => 1},
     # :skill3 => {:pos => [17,208], :size => [24,24], :align => 1},
     # :skill4 => {:pos => [17,208], :size => [24,24], :align => 1},
     # :toggle => {:pos => [17,208], :size => [24,24], :align => 1},
    },
  }
 
  #-----------------------------------------------------------------------------
  # Quick Tool Selection Menu Toolbar Settings:
  #-----------------------------------------------------------------------------
  # Same as the map toolbar settings above, but this will only affect the
  # quick tool selection menu made by Falcao!
  # Uses the same format too, so I won't write down the details here again. :P
  #-----------------------------------------------------------------------------
  ToolMenuSettings = {
    :icon => {
      :weapon => {:pos => [1,15]},
      :armor =>  {:pos => [1,56]},
      :item1 =>  {:pos => [1,97]},
      :item2 =>  {:pos => [1,126]},
      :skill1 => {:pos => [1,167]},
      :skill2 => {:pos => [1,196]},
     # :skill3 => {:pos => [1,196]},
     # :skill4 => {:pos => [1,196]},
     # :toggle => {:pos => [1,196]},
    },
    :cool => {
      :weapon => {:pos => [17,27], :size => [24,24]},
      :armor =>  {:pos => [17,68], :size => [24,24]},
      :item1 =>  {:pos => [17,109], :size => [24,24]},
      :item2 =>  {:pos => [17,138], :size => [24,24]},
      :skill1 => {:pos => [17,179], :size => [24,24]},
      :skill2 => {:pos => [17,208], :size => [24,24]},
     # :skill3 => {:pos => [17,208], :size => [24,24]},
     # :skill4 => {:pos => [17,208], :size => [24,24]},
     # :toggle => {:pos => [17,208], :size => [24,24]},
    },
    :ammo => {
      :weapon => {:pos => [37,17], :size => [32,32], :align => 1},
      :armor =>  {:pos => [37,58], :size => [32,32], :align => 1},
      :item1 =>  {:pos => [37,99], :size => [32,32], :align => 1},
      :item2 =>  {:pos => [37,128], :size => [32,32], :align => 1},
      :skill1 => {:pos => [37,169], :size => [32,32], :align => 1},
      :skill2 => {:pos => [37,198], :size => [32,32], :align => 1},
     # :skill3 => {:pos => [37,198], :size => [32,32], :align => 1},
     # :skill4 => {:pos => [37,198], :size => [32,32], :align => 1},
     # :toggle => {:pos => [37,198], :size => [32,32], :align => 1},
    },
    :letter => {
      :weapon => {:pos => [17,27], :size => [24,24], :align => 1},
      :armor =>  {:pos => [17,68], :size => [24,24], :align => 1},
      :item1 =>  {:pos => [17,109], :size => [24,24], :align => 1},
      :item2 =>  {:pos => [17,138], :size => [24,24], :align => 1},
      :skill1 => {:pos => [17,179], :size => [24,24], :align => 1},
      :skill2 => {:pos => [17,208], :size => [24,24], :align => 1},
     # :skill3 => {:pos => [17,208], :size => [24,24], :align => 1},
     # :skill4 => {:pos => [17,208], :size => [24,24], :align => 1},
     # :toggle => {:pos => [17,208], :size => [24,24], :align => 1},
    },
  }
 
  #-----------------------------------------------------------------------------
  # Character Selection Menu Toolbar Settings:
  #-----------------------------------------------------------------------------
  # Same as the map toolbar settings above, but this will only affect the
  # character selection menu made by Falcao!
  # Uses the same format too, so I won't write down the details here again. :P
  #-----------------------------------------------------------------------------
  CharMenuSettings = {
    :icon => {
      :weapon => {:pos => [1,15]},
      :armor =>  {:pos => [1,56]},
      :item1 =>  {:pos => [1,97]},
      :item2 =>  {:pos => [1,126]},
      :skill1 => {:pos => [1,167]},
      :skill2 => {:pos => [1,196]},
     # :skill3 => {:pos => [1,196]},
     # :skill4 => {:pos => [1,196]},
     # :toggle => {:pos => [1,196]},
    },
    :cool => {
      :weapon => {:pos => [17,27], :size => [24,24]},
      :armor =>  {:pos => [17,68], :size => [24,24]},
      :item1 =>  {:pos => [17,109], :size => [24,24]},
      :item2 =>  {:pos => [17,138], :size => [24,24]},
      :skill1 => {:pos => [17,179], :size => [24,24]},
      :skill2 => {:pos => [17,208], :size => [24,24]},
     # :skill3 => {:pos => [17,208], :size => [24,24]},
     # :skill4 => {:pos => [17,208], :size => [24,24]},
     # :toggle => {:pos => [17,208], :size => [24,24]},
    },
    :ammo => {
      :weapon => {:pos => [37,17], :size => [32,32], :align => 1},
      :armor =>  {:pos => [37,58], :size => [32,32], :align => 1},
      :item1 =>  {:pos => [37,99], :size => [32,32], :align => 1},
      :item2 =>  {:pos => [37,128], :size => [32,32], :align => 1},
      :skill1 => {:pos => [37,169], :size => [32,32], :align => 1},
      :skill2 => {:pos => [37,198], :size => [32,32], :align => 1},
     # :skill3 => {:pos => [37,198], :size => [32,32], :align => 1},
     # :skill4 => {:pos => [37,198], :size => [32,32], :align => 1},
     # :toggle => {:pos => [37,198], :size => [32,32], :align => 1},
    },
    :letter => {
      :weapon => {:pos => [17,27], :size => [24,24], :align => 1},
      :armor =>  {:pos => [17,68], :size => [24,24], :align => 1},
      :item1 =>  {:pos => [17,109], :size => [24,24], :align => 1},
      :item2 =>  {:pos => [17,138], :size => [24,24], :align => 1},
      :skill1 => {:pos => [17,179], :size => [24,24], :align => 1},
      :skill2 => {:pos => [17,208], :size => [24,24], :align => 1},
     # :skill3 => {:pos => [17,208], :size => [24,24], :align => 1},
     # :skill4 => {:pos => [17,208], :size => [24,24], :align => 1},
     # :toggle => {:pos => [17,208], :size => [24,24], :align => 1},
    },
  }
     
end
#===============================================================================
# End of settings! O.o
#===============================================================================
 
module PxColl
 
  def self.check_coll(sp1,sp2)
    if !sp1.nil? && !sp1.disposed? && !sp2.nil? && !sp2.disposed? &&
       sp2.pixel_collide?(sp1)
      return true
    end
    return false
  end
 
end
 
class Game_Battler < Game_BattlerBase
   
  attr_accessor :msc, :mic, :mac, :mwc
 
  alias add_maxi_vals2221 initialize
  def initialize
    @msc = {}; @mic = {}; @mwc = {}; @mac = {}
    add_maxi_vals2221
  end
 
  unless $imported["SixthABSStatAddon"]
    alias add_max_cools8874 apply_cooldown
    def apply_cooldown(item, value)    
      @msc[item.id] = value if item.is_a?(RPG::Skill)
      @mic[item.id] = value if item.is_a?(RPG::Item)
      @mwc[item.id] = value if item.is_a?(RPG::Weapon)
      @mac[item.id] = value if item.is_a?(RPG::Armor)
      add_max_cools8874(item, value)
    end
  end
 
end
 
class Game_Actor < Game_Battler
 
  alias change_usability6642 setup
  def setup(actor_id)
    change_usability6642(actor_id)
    @usability = { # Rewritten variable.
      :weapon => nil, :armor => nil, :item1 => nil, :item2 => nil,
      :skill1 => nil, :skill2 => nil, :skill3 => nil, :skill4 => nil,
    }
  end
   
  # Rewritten.
  def apply_usability
    apply_usabilityto_melee(:weapon)
    apply_usabilityto_melee(:armor)
    @usability[:item1] = usable?(@assigned_item) if !@assigned_item.nil?
    @usability[:item2] = usable?(@assigned_item2) if !@assigned_item2.nil?
    @usability[:skill1] = usable?(@assigned_skill) if !@assigned_skill.nil?
    @usability[:skill2] = usable?(@assigned_skill2) if !@assigned_skill2.nil?
    @usability[:skill3] = usable?(@assigned_skill3) if !@assigned_skill3.nil?
    @usability[:skill4] = usable?(@assigned_skill4) if !@assigned_skill4.nil?
  end
 
  # Rewritten.
  def apply_usabilityto_melee(type)
    index = type == :weapon ? 0 : 1
    if !equips[index].nil?
      invoke = equips[index].tool_data("Tool Invoke Skill = ")
      if invoke != nil and invoke != 0 and index == 0
        @usability[type] = usable?($data_skills[invoke])
      elsif index == 0
        @usability[type] = usable?($data_skills[1])
      end
      if invoke != nil and invoke != 0 and index == 1
        @usability[type] = usable?($data_skills[invoke])
      elsif index == 1
        @usability[type] = usable?($data_skills[2])
      end
    end
  end
 
end
 
class Scene_Map < Scene_Base
   
  alias fix_crash8861 get_event_spriteset
  def get_event_spriteset(evt_id)
    return nil if @spriteset.nil?
    fix_crash8861(evt_id)
  end
 
  alias fix_crash8864 get_picture_spriteset
  def get_picture_spriteset(pic_id)    
    return nil if @spriteset.nil?
    fix_crash8864(pic_id)
  end
 
end
 
class Sprite_PearlTool < Sprite
     
  # Rewritten.
  def initialize(view, custom_pos=nil)
    super(view)
    @actor = $game_player.actor
    @actor.apply_usability
    @old_usability = {}
    @layout = ::Sprite.new(view)
    if SceneManager.scene_is?(Scene_Map)
      @bartype = :map
      @info = MapSettings
    elsif SceneManager.scene_is?(Scene_QuickTool)
      @bartype = :toolmenu
      @info = ToolMenuSettings
    elsif SceneManager.scene_is?(Scene_CharacterSet)
      @bartype = :charmenu
      @info = CharMenuSettings
    elsif SceneManager.scene_is?(ABSScene)
      @bartype = :sixthmenu
      @info = SixthMenuSettings
    end
    @layout.bitmap = Cache.picture(LayoutImg[@bartype])
    @layout.x = Position[@bartype][0]
    @layout.y = Position[@bartype][1]
    @priority = Priority[@bartype]
    @info[:icon].each_key do |key|
      next if key == :toggle
      @old_usability[key] = @actor.usability[key]
    end
    @icons = ::Sprite.new(view)
    @icons.bitmap = Bitmap.new(@layout.bitmap.width, @layout.bitmap.height)
    self.bitmap = Bitmap.new(@layout.bitmap.width+32, @layout.bitmap.height+32)
    self.bitmap.font.size = Fonts[:ammo][:size]
    self.bitmap.font.name = Fonts[:ammo][:type]
    self.bitmap.font.bold = Fonts[:ammo][:bold]
    @icons.x = @layout.x
    @icons.y = @layout.y
    self.x = @layout.x - 16
    self.y = @layout.y - 12
    @framer = 0
    @cool_img = Sprite.new(view)
    @cool_img.bitmap = Bitmap.new(@layout.bitmap.width+32, @layout.bitmap.height+32)
    @cool_img.x = @layout.x - 16
    @cool_img.y = @layout.y - 12
    if EnableSettings[:letters] == true
      @info_keys = ::Sprite.new(view)
      @info_keys.bitmap = Bitmap.new(self.bitmap.width, self.bitmap.height)
      @info_keys.x = self.x; @info_keys.y = self.y; @info_keys.z = self.z
      @info_keys.bitmap.font.name = Fonts[:letters][:type]
      @info_keys.bitmap.font.size = Fonts[:letters][:size]
      @info_keys.bitmap.font.bold = Fonts[:letters][:bold]
      draw_key_info
    end
    set_z_priority
    @cools = {}
    [:weapop,:armor,:item1,:item2,:skill1,:skill2,:skill3,:skill4].each {|type|
      @cools[type] = -1
    }
    refresh_icons
    refresh_texts(true)
    @view = view
    @on_map = SceneManager.scene_is?(Scene_Map)
    @mouse_exist = defined?(Map_Buttons).is_a?(String)
    @mouse_exist = false if @mouse_exist && !SceneManager.scene_is?(Scene_Map)
    update
  end
 
  def set_z_priority
    @layout.z = @priority[:back]
    self.z = @priority[:ammo]
    @icons.z = @priority[:icons]
    @info_keys.z = @priority[:letters] if @info_keys
    @cool_img.z = @priority[:cool]
  end
     
  def get_letter(*path)
    buttons = System.nest($system,*path)
    return "" if buttons.nil?
    key = buttons.find {|ky| !ky.nil? }
    return key ? ConfigScene::Keys[key][:name] : ConfigScene::Keys[:empty][:name]
  end
 
  def get_icon(*path)
    buttons = System.nest($system,*path)
    return 0 if buttons.nil?
    key = buttons.find {|ky| !ky.nil? }
    return key ? ConfigScene::Keys[key][:icon] : ConfigScene::Keys[:empty][:icon]
  end
 
  def get_img(*path)
    buttons = System.nest($system,*path)
    return "" if buttons.nil?
    key = buttons.find {|ky| !ky.nil? }
    return key ? ConfigScene::Keys[key][:img] : ConfigScene::Keys[:empty][:img]
  end
 
  def draw_key_letters
    letters = {
      :weapon => get_letter(:p1,:l_hand), :armor => get_letter(:p1,:r_hand),
      :item1 => get_letter(:p1,:item_1), :item2 => get_letter(:p1,:item_2),
      :skill1 => get_letter(:p1,:skill_1), :skill2 => get_letter(:p1,:skill_2),
      :skill3 => get_letter(:p1,:skill_3), :skill4 => get_letter(:p1,:skill_4),
      :toggle => get_letter(:p1,:follower),
    }
    @info[:letter].each do |key,info|
      next if letters[key].nil?
      xx = info[:pos][0]; yy = info[:pos][1]; w = info[:size][0]; h = info[:size][1]
      @info_keys.bitmap.draw_text(xx,yy,w,h,letters[key],info[:align])
    end
  end
 
  def draw_key_icons
    letters = {
      :weapon => get_icon(:p1,:l_hand), :armor => get_icon(:p1,:r_hand),
      :item1 => get_icon(:p1,:item_1), :item2 => get_icon(:p1,:item_2),
      :skill1 => get_icon(:p1,:skill_1), :skill2 => get_icon(:p1,:skill_2),
      :skill3 => get_icon(:p1,:skill_3), :skill4 => get_icon(:p1,:skill_4),
      :toggle => get_icon(:p1,:follower),
    }
    @info[:letter].each do |key,info|
      next if letters[key].nil?
      xx = info[:pos][0]; yy = info[:pos][1]; w = info[:size][0]; h = info[:size][1]
      draw_icon(letters[key], xx, yy, true, @info_keys.bitmap)
    end
  end
 
  def draw_key_imgs
    letters = {
      :weapon => get_img(:p1,:l_hand), :armor => get_img(:p1,:r_hand),
      :item1 => get_img(:p1,:item_1), :item2 => get_img(:p1,:item_2),
      :skill1 => get_img(:p1,:skill_1), :skill2 => get_img(:p1,:skill_2),
      :skill3 => get_img(:p1,:skill_3), :skill4 => get_img(:p1,:skill_4),
      :toggle => get_img(:p1,:follower),
    }
    @info[:letter].each do |key,info|
      next if letters[key].nil?
      xx = info[:pos][0]; yy = info[:pos][1]; w = info[:size][0]; h = info[:size][1]
      draw_img(letters[key],xx,yy,@info_keys.bitmap)
    end
  end
 
  def draw_original_info
    letters = {
      :weapon => Key::Weapon[1], :armor => Key::Armor[1],
      :item1 => Key::Item[1], :item2 => Key::Item2[1],
      :skill1 => Key::Skill[1], :skill2 => Key::Skill2[1],
      :skill3 => Key::Skill3[1], :skill4 => Key::Skill4[1],
      :toggle => Key::Follower[1],
    }
    @info[:letter].each do |key,info|
      next if letters[key].nil?
      xx = info[:pos][0]; yy = info[:pos][1]; w = info[:size][0]; h = info[:size][1]
      @info_keys.bitmap.draw_text(xx,yy,w,h,letters[key],info[:align])
    end
  end
 
  # Rewritten.
  def draw_key_info
    if $imported["SixthControlConfigMenu"]
      case LetterTypes[@bartype]
      when :name; draw_key_letters
      when :icon; draw_key_icons
      when :img;  draw_key_imgs
      end
    else
      draw_original_info
    end
  end
 
  # Rewritten.
  def draw_icon(icon_index, x, y, enabled = true, bmp = nil)
    bmp = @icons.bitmap if bmp.nil?
    bit = Cache.system("Iconset")
    rect = Rect.new(icon_index % 16 * 24, icon_index / 16 * 24, 24, 24)
    bmp.blt(x, y, bit, rect, enabled ? 255 : 150)
  end
 
  def draw_img(iname,x,y,bmp)
    img = Cache.custom_imgs(iname,System::ImgFolder)
    rect = Rect.new(0,0,img.width,img.height)
    bmp.blt(x,y,img,rect,255)
  end
 
  # Rewritten.
  def refresh_texts(force=false)
    refresh_cooldown if @on_map || force
    refresh_ammo
  end
   
  # Refresh toolbar icons - rewritten.
  def refresh_icons
    @icons.bitmap.clear    
    icon = {
      :weapon => @actor.equips[0], :armor => @actor.equips[1],
      :item1 => @actor.assigned_item, :item2 => @actor.assigned_item2,
      :skill1 => @actor.assigned_skill, :skill2 => @actor.assigned_skill2,
      :skill3 => @actor.assigned_skill3, :skill4 => @actor.assigned_skill4,
      :toggle => ToggleIcon,
    }
    @info[:icon].each do |key,info|
      next if icon[key].nil?
      xx = info[:pos][0]; yy = info[:pos][1]
      case icon[key]
      when RPG::Item, RPG::Skill
        draw_icon(icon[key].icon_index, xx, yy, true)
      when RPG::Weapon
        enable = @actor.usability[0] ; enable = true if enable.nil?
        draw_icon(icon[key].icon_index, xx, yy, true)
      when RPG::Armor
        enable = @actor.usability[1] ; enable = true if enable.nil?
        draw_icon(icon[key].icon_index, xx, yy, true)
      when Fixnum
        draw_icon(icon[key], xx, yy)
      end
    end    
    @now_equip = [@actor.equips[0], @actor.equips[1], @actor.assigned_item,
    @actor.assigned_item2, @actor.assigned_skill, @actor.assigned_skill2,
    @actor.assigned_skill3, @actor.assigned_skill4]
  end
   
  # fade effect when player is behind the toolbar - rewritten.
  # Added tool bar hide switch.
  def update_fade_effect
    if SceneManager.scene_is?(Scene_Map)
      if ToolBarSwitch == 0 || $game_switches[ToolBarSwitch]
        if self.visible == false
          @layout.visible = @icons.visible = self.visible = true
          @info_keys.visible = true if EnableSettings[:letters] == true
        end
      else
        if self.visible == true
          @layout.visible = @icons.visible = self.visible = false
          @info_keys.visible = false if EnableSettings[:letters] == true
        end
      end
    end
    if behind_toolbar?
      if self.opacity >= 60
        self.opacity -= 10
        @layout.opacity = @icons.opacity = self.opacity
        @info_keys.opacity = self.opacity if EnableSettings[:letters] == true
      end
    elsif self.opacity != 255
      self.opacity += 10
      @layout.opacity = @icons.opacity = self.opacity
      @info_keys.opacity = self.opacity if EnableSettings[:letters] == true
    end
  end
   
  # Rewritten check, it's pixel collison based now.
  # Uses Cidiomar's Perfect Pixel Collision System.
  def behind_toolbar?
    return false unless @on_map
    if SceneManager.scene_is?(Scene_Map)
      pl_sprite = SceneManager.scene.get_event_spriteset(0)
      return true if PxColl.check_coll(pl_sprite,@layout)
    end
    return false
  end
 
  # refresh the icons when the usability change - rewritten.
  def update_usability_enable
    @info[:icon].each_key do |key|
      next if key == :toggle
      refresh_icons if @old_usability[key] != @actor.usability[key]
    end
  end
 
  # ammunition engine - rewritten.
  def ammo_ready?(item)
    return false if item.nil?
    return true if item.has_data.nil? && item.is_a?(RPG::Item) &&
    item.consumable
    return true if item.is_a?(RPG::Skill)
    return false if flagged(item, 2).nil?
    return true  if flagged(item, 2) != 0
    return false
  end
 
  # get item cost - rewritten
  def itemcost(item)
    return 0 if item.nil?
    if item.is_a?(RPG::Item) && item.consumable && item.itemcost == 0
      return $game_party.item_number(item)
    end
    if item.is_a?(RPG::Skill)
      if @actor.skill_tp_cost(item) > 0
        return @actor.skill_tp_cost(item)
      elsif @actor.skill_mp_cost(item) > 0
        return @actor.skill_mp_cost(item)
      end
    end
    return $game_party.item_number($data_items[item.itemcost]) if item.itemcost != 0
    return 0
  end
 
  # Ammo refresher - rewritten.
  def refresh_ammo
    if @wnumber != itemcost(@actor.equips[0])
      @wnumber = itemcost(@actor.equips[0])
      draw_em_ammo(:weapon,@wnumber,@actor.equips[0])
    end
    if @anumber != itemcost(@actor.equips[1])
      @anumber = itemcost(@actor.equips[1])
      draw_em_ammo(:armor,@anumber,@actor.equips[1])
    end
    if @inumber != itemcost(@actor.assigned_item)
      @inumber = itemcost(@actor.assigned_item)
      draw_em_ammo(:item1,@inumber,@actor.assigned_item)
    end
    if @inumber2 != itemcost(@actor.assigned_item2)
      @inumber2 = itemcost(@actor.assigned_item2)
      draw_em_ammo(:item2,@inumber2,@actor.assigned_item2)
    end
    if @snumber != itemcost(@actor.assigned_skill)
      @snumber = itemcost(@actor.assigned_skill)
      draw_em_ammo(:skill1,@snumber,@actor.assigned_skill)
    end
    if @snumber2 != itemcost(@actor.assigned_skill2)
      @snumber2 = itemcost(@actor.assigned_skill2)
      draw_em_ammo(:skill2,@snumber2,@actor.assigned_skill2)
    end
    if @snumber3 != itemcost(@actor.assigned_skill3)
      @snumber3 = itemcost(@actor.assigned_skill3)
      draw_em_ammo(:skill3,@snumber3,@actor.assigned_skill3)
    end
    if @snumber4 != itemcost(@actor.assigned_skill4)
      @snumber4 = itemcost(@actor.assigned_skill4)
      draw_em_ammo(:skill4,@snumber4,@actor.assigned_skill4)
    end
  end
 
  def draw_em_ammo(key,number,item)
    return if @info[:ammo][key].nil?
    case item
    when RPG::Weapon, RPG::Armor, RPG::Item
      self.bitmap.font.color = Fonts[:ammo][:color][:item]
    when RPG::Skill
      return if item.tp_cost == 0 && item.mp_cost == 0 && item.itemcost == 0
      if item.tp_cost > 0
        self.bitmap.font.color = Fonts[:ammo][:color][:tp]
      elsif item.mp_cost > 0
        self.bitmap.font.color = Fonts[:ammo][:color][:mp]
      else
        self.bitmap.font.color = Fonts[:ammo][:color][:item]
      end
    end
    info = @info[:ammo][key]
    xx = info[:pos][0]; yy = info[:pos][1]; w = info[:size][0]; h = info[:size][1]
    self.bitmap.clear_rect(xx,yy,w,h)
    self.bitmap.draw_text(xx, yy, w, h, number.to_s, info[:align]) if number > 0
  end
   
  def get_max_cool(slot1,slot2=nil)
    return nil if @actor.equips[slot1].nil?
    if @actor.equips[slot1].is_a?(RPG::Weapon)
      return @actor.mwc[@actor.equips[slot1].id]
    elsif @actor.equips[slot1].is_a?(RPG::Armor)
      return @actor.mac[@actor.equips[slot1].id]
    end
  end
 
  # Cooldown refresher - completely rewritten.
  def refresh_cooldown
    if !get_max_cool(0,1).nil?
      wr = weapon_cooldown.to_f/get_max_cool(0,1)
    else
      wr = 0.0
    end
    if !get_max_cool(1,0).nil?
      ar = armor_cooldown.to_f/get_max_cool(1,0)
    else
      ar = 0.0
    end
    if !@actor.assigned_item.nil? && !@actor.mic[@actor.assigned_item.id].nil?
      ir = item_cooldown.to_f/@actor.mic[@actor.assigned_item.id]
    else
      ir = 0.0
    end
    if !@actor.assigned_item2.nil? && !@actor.mic[@actor.assigned_item2.id].nil?
      ir2 = item_cooldown2.to_f/@actor.mic[@actor.assigned_item2.id]
    else
      ir2 = 0.0
    end
    if !@actor.assigned_skill.nil? && !@actor.msc[@actor.assigned_skill.id].nil?
      sr = skill_cooldown.to_f/@actor.msc[@actor.assigned_skill.id]
    else
      sr = 0.0
    end
    if !@actor.assigned_skill2.nil? && !@actor.msc[@actor.assigned_skill2.id].nil?
      sr2 = skill_cooldown2.to_f/@actor.msc[@actor.assigned_skill2.id]
    else
      sr2 = 0.0
    end
    if !@actor.assigned_skill3.nil? && !@actor.msc[@actor.assigned_skill3.id].nil?
      sr3 = skill_cooldown3.to_f/@actor.msc[@actor.assigned_skill3.id]
    else
      sr3 = 0.0
    end
    if !@actor.assigned_skill4.nil? && !@actor.msc[@actor.assigned_skill4.id].nil?
      sr4 = skill_cooldown4.to_f/@actor.msc[@actor.assigned_skill4.id]
    else
      sr4 = 0.0
    end
    c1 = CoolDisplay[:f1]; c2 = CoolDisplay[:f2]
    if CoolDisplay[:useimg] == true
      draw_em_gauge_pic(:weapon,wr) if @cools[:weapon] != wr
      draw_em_gauge_pic(:armor,ar) if @cools[:armor] != ar
      draw_em_gauge_pic(:item1,ir) if @cools[:item1] != ir
      draw_em_gauge_pic(:item2,ir2) if @cools[:item2] != ir2
      draw_em_gauge_pic(:skill1,sr) if @cools[:skill1] != sr
      draw_em_gauge_pic(:skill2,sr2) if @cools[:skill2] != sr2
      draw_em_gauge_pic(:skill3,sr3) if @cools[:skill3] != sr3
      draw_em_gauge_pic(:skill4,sr4) if @cools[:skill4] != sr4
    else
      draw_em_gauge(:weapon,wr,c1,c2) if @cools[:weapon] != wr
      draw_em_gauge(:armor,ar,c1,c2) if @cools[:armor] != ar
      draw_em_gauge(:item1,ir,c1,c2) if @cools[:item1] != ir
      draw_em_gauge(:item2,ir2,c1,c2) if @cools[:item2] != ir2
      draw_em_gauge(:skill1,sr,c1,c2) if @cools[:skill1] != sr
      draw_em_gauge(:skill2,sr2,c1,c2) if @cools[:skill2] != sr2
      draw_em_gauge(:skill3,sr3,c1,c2) if @cools[:skill3] != sr3
      draw_em_gauge(:skill4,sr4,c1,c2) if @cools[:skill4] != sr4
    end
  end
 
  def draw_em_gauge(key,rate,c1,c2)
    @cools[key] = rate
    return if @info[:cool][key].nil?
    xx = @info[:cool][key][:pos][0]
    yy = @info[:cool][key][:pos][1]
    w = @info[:cool][key][:size][0]
    h = @info[:cool][key][:size][1]
    fill_h = (h * rate).to_i
    @cool_img.bitmap.clear_rect(xx,yy,w,h)
    @cool_img.bitmap.gradient_fill_rect(xx, yy, w, fill_h, c2, c1, true)
  end
 
  def draw_em_gauge_pic(key,rate)
    @cools[key] = rate
    return if @info[:cool][key].nil?
    xx = @info[:cool][key][:pos][0]
    yy = @info[:cool][key][:pos][1]
    pic = Cache.picture(CoolDisplay[:coolimg])
    fill_h = (pic.height * rate).to_i
    grect = Rect.new(0,0,pic.width,fill_h)
    @cool_img.bitmap.clear_rect(xx,yy,pic.width,pic.height)
    @cool_img.bitmap.blt(xx,yy,pic,grect,CoolDisplay[:coolopa])
  end
 
  def update_cooldown
    if @on_map and @actor != $game_player.actor
      @actor = $game_player.actor
      refresh_icons
      refresh_texts
    end
    if $game_player.refresh_skillbar > 0
      $game_player.refresh_skillbar -= 1
      if $game_player.refresh_skillbar == 0
        @actor.apply_usability
        refresh_icons
      end
    end
    # Rewrote cooldown update here.
    refresh_texts if Graphics.frame_count % CoolRefreshRate == 0
  end
 
  def dispose
    self.bitmap.dispose
    @cool_img.bitmap.dispose
    @cool_img.dispose
    @layout.bitmap.dispose
    @layout.dispose
    @icons.bitmap.dispose
    @icons.dispose
    # Dispose the letters only if they are enabled.
    if EnableSettings[:letters] == true
      @info_keys.bitmap.dispose
      @info_keys.dispose
    end
    super
  end
   
end
#==============================================================================
# !!END OF SCRIPT - OHH, NOES!!
#==============================================================================