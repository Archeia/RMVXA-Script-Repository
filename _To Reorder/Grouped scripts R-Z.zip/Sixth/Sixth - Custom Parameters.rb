#===============================================================================
# * [ACE] Custom Parameters
#===============================================================================
# * Made by: Sixth (www.rpgmakervxace.net, www.forums.rpgmakerweb.com)
# * Version: 1.5
# * Updated: 22/04/2018
# * Requires: -----------
#-------------------------------------------------------------------------------
# * < Change Log >
#-------------------------------------------------------------------------------
# * Version 1.0 (21/04/2016)
#   - Initial release.
# * Version 1.1 (22/04/2016)
#   - Changed the manually added bonus (with script calls) for multiplier
#     parameters. Instead of them being an additive bonus, they are now
#     multiplier bonuses as well.
#   - Added the ability to get the value of a parameter from a custom method
#     with or without arguments.
# * Version 1.2 (22/04/2016)
#   - Added shortened methods for getting the custom parameter values.
#     For example: actor.vit, enemy.sta, and so on.
#   - Added shortened methods for getting the custom parameter names.
#     For example: Vocab.cdr, Vocab.cdr_a, Vocab.cparam("spi"), and so on.
#   - Changed the name of the default (non-shortened) methods, so make sure
#     to check the description of the script calls again if you use those!
#     Basically, "custom_prm" is changed to "cparam" in all old script calls!
# * Version 1.3 (24/04/2016)
#   - The minimum and maximum values can be manipulated with note-tags and
#     script calls as well from now on, so you can make "Limit Break" equipment,
#     for example, to increase the maximum possible value for a parameter, or
#     make items/events which change the maximum/minimum possible values.
#   - Relocated the place where you need to place your own methods for using the
#     method call note-tags/settings. They are now in the 'CustomParamMethods'
#     module.
#   - Added an optional argument for the 'add_cparam' method. It will let you
#     decide if the value added should be added to the bonus parameter value
#     even if the player reached the minimum/maximum values for that parameter
#     (including actor, equipment, state and class bonuses) or not.
#   - Changed the update settings to be more specific. You can now choose to
#     only update the parameter's actual value, minimum value or maximum value.
#     You can also use new note-tags to specify the update setting for an object
#     specifically, instead of always using a global update setting.
#     Depending on how you use your custom parameters, this might increase
#     performance slightly.
# * Version 1.4 (08/05/2016)
#   - Optimized the update check. Now it reads the note-tag of your database
#     objects only once for that.
# * Version 1.5 (22/04/2018)
#   - Slight optimization.
#-------------------------------------------------------------------------------
# * < Description >
#-------------------------------------------------------------------------------
# * This script will let you make your own custom parameters.
#   These parameters can be whatever you want them to be.
#   You can access the new parameters with the provided script calls.
# * Create simple and static parameters or more complex and dynamic ones!
#   You can use eval formulas and your own custom methods for setting up
#   the values of your new parameters too!
# * Make additive or multiplier parameters!
# * Actors, Classes, Enemies, Equipment and States can all get these custom
#   parameters with simple note-tagging.
# * Increase/decrease your custom parameters with script calls! Permanently!
# * These new parameters won't do anything at all until you make them do
#   something! Use them in your damage formulas, use them in eventing or use
#   them in your own custom scripts!
#-------------------------------------------------------------------------------
# * < Note-Tags >
#-------------------------------------------------------------------------------
# * These note-tags can be used on Actors, Classes, Enemies, Equipment and
#   States! All note-tags are optional!
# * The custom parameter for an Actor or Enemy will start on the default value
#   you have set up in the script's settings. But if you want an actor or enemy
#   to have a different starting value, you can use the provided note-tags to
#   set up a custom starting value for them!
# * If a Class, Equipment or State doesn't have a note-tag for a custom
#   parameter, that parameter will be set to either 0 (in the case of additive
#   parameters) or 1 (in the case of multiplier parameters) for them.
#   If an Actor or Enemy got no note-tag for a custom parameter, that parameter
#   will be set to the default parameter value you have set up in the script.
# * To be very short and simple:
#   - Actor and Enemy note-tags control the starting value of these parameters.
#   - Class, Equipment and State note-tags will be bonuses for these parameters.
#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
# * To set up a static (non-eval) custom parameter, use this note-tag:
#
#     <cparam: value>
#
#   Hahh! How simple, right? :P
#
#   So, the 'cparam' you see is a key used in the settings of this script. That
#   is the custom parameter's key, and it can be any valid key from the settings
#   of this script.
#
#   The 'value' can be any numeric value including integers and float numbers,
#   and positive or negative values.
#
#   In the case of additive bonuses, these values will be added together for the
#   same custom parameter, and the result will be added to the actor's or
#   enemy's default (starting) parameter value.
#   This is the same behavior like the one that the default parameters
#   (HP, ATK, etc) use.
#
#   In the case of multiplier bonuses, these values will be multiplied with
#   each other for the same custom parameter, and the result will be used to
#   multiply the default (starting) parameter value. In other words, any and all
#   multiplier bonus of the same custom parameter will get multiplied with each
#   other.
#   This is the same behavior like the one that the default s-parameters
#   (GRD, MCR, etc) and the elemental damage rate features use.
#
#   Some examples using the parameters from the sample settings:
#
#     <cdr: 0.25>
#   If this is placed on an Actor or Enemy, this will be the starting value for
#   their CDR (Critical Damage Rate) custom parameter.
#   If this is placed on a Class, Equipment or State, this will be a bonus
#   value, which will be either added to the starting value (in the case of
#   additive parameters) or will multiply the total value of the current custom
#   parameter (in the case of multiplier parameters).
#
#     <cha: -15>
#   Well, same as above, but this will control the CHA (Charisma) custom
#   parameter instead.
#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
# * To set up a dynamic (eval) custom parameter, use this note-tag:
#  
#     <cparam formula: string>
#
#   This basically works the same way as the static note-tags, but instead of
#   taking a static value, this will evaluate a valid ruby code to determine
#   the real value of the custom parameter.
#
#   The 'string' will be the code which will be evaluated to get the value.
#  
#   NOTE:
#   Unless you set the custom parameter to be updated every time it's value is
#   requested, the formula will be evaluated only once and never again!
#   So, if you want to base a parameter on the value of a variable, for example,
#   you should set up the update feature for that custom parameter in the
#   script's settings or use the update note-tags for your database objects!
#   This is purely for optimization, because most people really don't need
#   formulas for their custom parameters, I guess. It would be a waste of
#   performance to always read the note-tags of all feature objects AND
#   re-evaluate the formula when a custom parameter's value is requested, so
#   I made this extra (and fully optional) setting to avoid the re-readings
#   and re-calculating of note-tag formulas.
#
#   Some examples using the parameters from the sample settings:
#
#     <sta formula: user.agi * 10>
#   This specific note-tag would modify the STA (Stamina) custom parameter.
#   As you can see, it references the user, and that is used to get the owner
#   of the parameter (actor or enemy).
#   So, to get to the point, this will read the owner's current AGI, and would
#   base the owner's STA on that parameter. In short, the owner's base STA would
#   always be 10 times higher than it's AGI, so it would be a dynamic value.
#
#   Like the above example shows, using this function needs at least a minimum
#   amount of coding knowledge in Ruby.
#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
# * To set up a dynamic or static (based on your custom methods) custom
#   parameter using your own methods, use this note-tag:
#  
#     <cparam method: method_name, arg1, arg2, ...>
#
#   Well, this works similarly as the eval note-tag above, but instead of
#   evaluating a string, this will call the specified method with the specified
#   arguments (if any) you used in the note-tag.
#   This lets you make your own custom methods for your custom parameters as
#   long as you know how to code them in Ruby.
#   NOTE:
#   Mind the spaces used after the commas in the note-tag! They are required!
#  
#   You custom methods must be defined in the 'CustomParamMethods' module!
#   The first argument of any custom method must be the 'user', which will
#   get the actor/enemy the parameter belongs to.
#   The rest of the arguments will be your own arguments if you specify them
#   in your note-tags.
#   If you just use the method name without any arguments in the note-tag, than
#   no additional arguments will be used for the method. In other words, the
#   arguments are optional!
#   Note that all arguments will be passed as strings, so you must convert them
#   to the object type you want to work with inside your own methods!
#
#   Examples using my sample custom methods found in the script:
#
#     <spi method: mp_left, 10, 0.75>
#   This will control the SPI custom parameter.
#   Will call the method named 'mp_left' in the CustomParamMethods module with
#   the mandatory 'user' argument (which gets you the actor/enemy of the
#   parameter), and with the optional arguments specified in the note-tag. The
#   optional arguments are "10" and "0.75".
#   If you check out the sample method named 'mp_left' in the script, you will
#   see that the value returned will be calculated based on the remaining MP
#   of the actor/enemy.
#   The argument "10" will be the minimum value added to the parameter,
#   regardless of the current remaining MP, and the argument "0.75" will be the
#   multiplier used in the MP based calculation, so whatever amount of MP the
#   actor/enemy lost will get multiplied by 0.75, and the result of that plus
#   10 (from the first argument) will be the total parameter value gained.
#   The arguments here let you re-use this note-tag type on many different
#   database items, and it will let you specify different values based on the
#   arguments you use in your note-tags.
#   Conclusion: You can create your own methods AND your own note-tags as well!
#
#     <rge method: hp_left>
#   This modifies the RGE (Rage, fitting name for the stat based on it's value
#   calculation - see below) custom parameter.
#   Similar to the above note-tag, but this one got no optional arguments.
#   If you check out the method named 'hp_left' in the script below, you will
#   see that the parameter value gained will depend on the remaining HP of the
#   actor/enemy. The remaining HP will get multiplied by 2, and that will be the
#   actual value gained. Pretty simple method, yet perfect for this stat, right?
#
#   NOTE:
#   Just like with the formula (eval) note-tags, if you want the parameter to
#   be updated every time it is requested, set up it's update settings!
#   If you don't do it, it will only be calculated once and never more!
#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
# * To set up custom maximum or minimum value limits or bonuses for your
#   parameters, use these note-tags:
#
#   - Static note-tags:
#
#     <cparam max: value>  # For modifying the maximum parameter values.
#     <cparam min: value>  # For modifying the minimum parameter values.
#
#   - Eval formula note-tags:
#
#     <cparam max formula: string>
#     <cparam min formula: string>
#
#   - Custom method call note-tags:
#
#     <cparam max method: method_name, arg1, arg2, ...>
#     <cparam min method: method_name, arg1, arg2, ...>
#
#   The static note-tags only accept integers or float numbers as values!
#   The formula note-tags will read the entered string, evaluate it as a Ruby
#   code and will use the returned value.
#   The custom method call note-tags will get the method name from the note-tag,
#   run that method (which must be in the 'CustomParamMethods' module!), and
#   will use the returned value.
#  
#   If these note-tags are set on an Actor or Enemy, these will decide the base
#   minimum/maximum values the parameter can get.
#   If these note-tags are on a Class, Equipment or State, the value will be
#   added to the base minimum/maximum values, effectively raising or lowering
#   them. Can be used to make "Limit Break" equipment and such things.
#
#   NOTE:
#   Remember to set up your update settings for the parameters/objects which use
#   a formula or a custom method for their values!
#
#   Examples:
#
#     <cdr max: 0.5>
#   If this is on an Actor or Enemy, it will set the maximum possible value for
#   the CDR parameter to be 0.5 for the actor/enemy.
#   If this is on a Class, Equipment or State, this will be a bonus value which
#   will be added to the base maximum value for the parameter, so, in this case,
#   the maximum possible value for the parameter will be raised by 0.5.
#
#     <mor min: -75>
#   If this is on an Actor or Enemy, it will set the minimum possible value for
#   the MOR parameter to be -75 for the actor/enemy.
#   If this is on a Class, Equipment or State, this will be a bonus value which
#   will be added to the base minimum value for the parameter, so, in this case,
#   the minimum possible value for the parameter will be lowered by 75.
#
#     <vit max formula: user.hp/10 + user.def/2>
#   Changes the maximum possible value for the VIT parameter.
#   Uses an eval formula for getting the value. This formula will set the
#   maximum limit for VIT to be equal with the user's current HP / 10 plus the
#   user's DEF stat.
#
#     <dex min method: lvl_formula, 0.009, 3, 5, 31>
#   This will change the minimum possible value limit for the DEX parameter.
#   The value will be whatever the method named 'lvl_formula' in the
#   'CustomParamMethods' returns. The note-tag passes the arguments "0.009",
#   "3", "5" and "31" to the method. Based on these numbers and on the user's
#   level, the value will be calculated according to the method.
#   Because this uses the user's level in the method, this can only be used on
#   database objects that can only appear on actors (enemies got no levels)!
#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
# * To set up the update method for an object specifically, use this note-tag:
#
#     <cparam type update>
#
#   The 'cparam', as always, is a valid key from the parameter settings from the
#   script.
#  
#   Depending on the 'type' you use, different values will be updated:
#   value = Updates the parameter's current value on the database object.
#   max = Updates the parameter's maximum limit on the database object.
#   min = Updates the parameter's minimum limit on the database object.
#
#   Kinda hard to explain this feature, but here is what this actually does:
#
#   If the :update setting for a parameter is omitted for a specific type
#   (value, max or min), you can still update these on your database objects
#   separately if needed. This is, of course, only needed if the database object
#   uses a note-tag for a cparam, cparam max or cparam min value with an eval
#   formula or custom method. If the database object uses a simple static
#   note-tag for these, it got no reason for being updated after it's
#   initialization.
#
#   So, here is a full example for an armor with the following note-tags:
#
#     <cha formula: user.level * 5>
#     <dex: 12>
#     <sta max method: hp_left>
#     <cha value update>
#
#   Lets assume that none of the parameters got any :update settings set up
#   for them in the script...
#
#   Okay, so what happens here?
#   This specific armor gives a lot of stats, namely:
#   The CHA parameter will be raised based on the user's level multiplied by 5.
#   If the user is level 1, it would give +5 CHA, if the user is level 2, it
#   would give +10 CHA, and so on.
#   Because the object got the <cha value update> note-tag, the added bonus will
#   be recalculated every time the CHA parameter is requested in any way, so
#   it can update itself with the user's level.
#   If that note-tag would not be used, whatever level the user was when the
#   CHA parameter was first requested on this armor will be used in all of the
#   calculations after. So, if the user was level 1, it will give +5 CHA always,
#   regardless if the player level up or not. If the user was level 4 when the
#   CHA parameter is requested on the armor, it will always give +20 CHA for any
#   actor who equips it, no matter if the other actors got different levels or
#   not.
#   So, if you want a dynamically calculated value which updates itself when
#   needed, you will need to use the update note-tag on the used object with the
#   specific parameter and parameter value type.
#   Lets move on to the next stat bonus on this armor...
#   DEX will be raised by 12. Just like that, a plain old static bonus. This
#   will never need to be updated, because it will always give +12, no matter
#   who equips it and when.
#   Next, the maximum limit for the STA parameter will change depending on the
#   value that the method named 'hp_left' returns. That method will base it's
#   value on the user's remaining HP, so the less HP the user has, the higher
#   their STA parameter can get. Note that it CAN get higher, but unless the
#   user got enough STA, it will NOT automatically add that much STA, it just
#   raises the limit for that parameter. Kinda like the "Limit Break" feature
#   in the FF series, which raised the damage cap to 99999 instead of 9999.
#   Now, because the armor got no <sta max update> note-tag, the calculation
#   for the maximum STA value bonus will only be run once in your entire game!
#   So, depending on when the player equips the armor, and on how much HP the
#   actor get at that time, the bonus will be based on that actor's HP, and
#   will stay on that value forever, no matter if someone else equips it or if
#   the HP of the user changes or not.
#
#   As a last note, the update note-tags on this armor will only update the
#   specified parameter values on this armor!
#
#   I hope this wall of text cleared up what this note-tag does exactly.
#   If not, though luck, because I don't think that I can explain it any better.
#
#   Here are a few more examples:
#
#     <cdr value update>
#     <spi max update>
#     <mor min update>
#-------------------------------------------------------------------------------
# * < Script Calls >
#-------------------------------------------------------------------------------
# * The following script calls can be used anywhere you want, from an evented
#   script call, or from a custom script, doesn't matter!
#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
# * To get the current value of the actor's or enemy's custom parameter, you
#   can use this script call:
#
#     actor_object.cparam("cparam")  # For actors.
#     enemy_object.cparam("cparam")  # For enemies.
#
#   From v1.2:
#    
#     actor_object.cparam   # For actors.
#     enemy_object.cparam   # For enemies.
#
#   The 'actor_object' can be any method or variable which returns a valid
#   actor object. The most commonly used are:
#     $game_actors[ID] - To get the actor based on it's database ID.
#     $game_party.members[index] - To get the actor based on it's party index.
#
#   The 'enemy_object' can be any method or variable which returns a valid
#   enemy object. There aren't many ways of getting an enemy object, because
#   they only exist in battles by default, but here is the one which is usable
#   in case you need it:
#     $game_troop.members[index] - To get the enemy based on it's troop index.
#
#   The "cparam" can be any valid custom parameter key from the settings of this
#   script. Obviously, this is used to get the value of the selected parameter.
#
#   Examples:
#
#     $game_actors[2].cparam("vit") # Old method, still usable.
#     $game_actors[2].vit           # New method from v1.2.
#   This would return the VIT (Vitality) custom parameter of Actor 2.
#
#     $game_troop.members[1].cparam("cdr")  # Old method, still usable.
#     $game_troop.members[1].cdr            # New method from v1.2.
#   This would return the CDR (Critical Damage Rate) parameter of the 1st enemy
#   from the current opponents in battle.
#   Note that this is only usable in battles and it's not really useful, I just
#   wanted to make an example for an enemy. :P
#
#   - In the damage formula:
#
#     a.cparam("sta") # Old method, still usable.
#     a.sta           # New method from v1.2.
#   Gets the STA (Stamina) parameter of the user of the skill/item.
#
#     b.cparam("mor") # Old method, still usable.
#     b.mor           # New method from v1.2.
#   Gets the MOR (Morality) parameter of the target of the skill/item.
#
#   - In conditional branches:
#
#   Well, basically the same as the regular script calls, but here you can (and
#   should) compare their values with a specific value.
#   Some examples:
#
#     $game_actors[2].cparam("vit") >= 300  # Old method, still usable.
#     $game_actors[2].vit >= 300            # New method from v1.2.
#   This check returns true if the VIT of Actor 2 is higher than 300.
#
#     $game_actors[2].cparam("mor") > $game_actors[3].cparam("mor")
#     $game_actors[2].mor > $game_actors[3].mor
#   This returns true if the MOR of Actor 2 is higher than the MOR of Actor 3.
#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
# * To increase/decrease a custom parameter, use this script call:
#
#     actor_object.add_cparam("cparam",value,limit) # Old method, still usable.
#     actor_object.add_cparam(value,limit)          # New method from v1.2.
#  
#   The 'actor_object' is the same as above, so refer to the explanation there.
#  
#   The "cparam" can be any valid custom parameter key from the settings of this
#   script. Obviously, this is used to get the value of the selected parameter.
#
#   And the 'value' will be the value added to the selected parameter.
#   It can be positive and negative, and integer or float number as well!
#
#   The 'limit' argument is an optional one. This decides if the script call
#   will add the value to the parameter even if it reached the minimum/maximum
#   limits or not. If this is set to true, it will NOT add anymore parameter
#   value if it has already reached the minimum/maximum values (including all
#   bonuses from class, equipment and state note-tags)! If this is false, it
#   will keep adding the values regardless if the parameter reached it's
#   minimum/maximum value or not.
#   The default value of this argument is false, if you omit it in your script
#   calls, that value will be used!
#   Another hard thing to explain without examples, so here we go!
#   Suppose the actor has 960 total DEX with all the bonuses. Than the actor
#   equips an armor which increases DEX by 100. The max limit for DEX is 999.
#   So, after equipping the armor, the value of DEX would be capped on 999.
#   Now, the player drinks a weird potion which would increase it's DEX by 5
#   permanently. But DEX is already at it's max value, so what will happen now?
#   If this optional argument is set to true, and the player drinks the potion,
#   the stat gain from that potion will not happen, because the actor's DEX
#   is already at it's max value. Now the actor un-equips this armor, and his
#   DEX would drop back to 960. So, no increase can be seen even after taking
#   off the armor!
#   But if the actor drinks another of these potions, now without the armor,
#   the actor's DEX will indeed be increased by 5, because the total value
#   of DEX is not capped without the armor.
#   Lets see what happens when this optional argument is set to false now...
#   Now the actor has 965 DEX without the armor, and again, 999 with it
#   equipped. So, the actor equips the armor again. He drinks another weird
#   potion, which is seemingly the same, but the script call used for this
#   one is using false for this optional argument. After drinking it, the
#   DEX stays the same, 999 with the armor equipped. Ohh, well, what a bummer,
#   right? But when the armor is unequipped, the player can notice that the
#   value of DEX increased from 965 to 970! So, when this arguments is false,
#   it WILL add the bonus from the script call, even if the parameter's value
#   is capped already. This doesn't mean that the parameter will exceed the
#   maximum allowed values! But if the player unequips some stuffs giving
#   bonuses for the parameter, the increase from the script call will be
#   visible.
#   I hope this clears this up... Phew!
#
#   Examples:
#
#     $game_party.members[0].add_cparam("cha",5) # Old method, still usable.
#     $game_party.members[0].add_cha(5)          # New method from v1.2.
#   Increases CHA by 5 for the party leader.
#
#     $game_actors[4].add_cparam("mor",-12) # Old method, still usable.
#     $game_actors[4].add_mor(-12)          # New method from v1.2.
#   Decreases MOR by 12 for Actor 4.
#
#   NOTE:
#   In the case of additive parameters, these extra bonuses will be simply added
#   to the value of the parameters. Permanently!
#   The starting value of these bonuses is always 0!
#
#   In the case of multiplier parameters, the values you add this way will
#   multiply the existing value of the custom parameter. Again, permanently!
#   The starting value of these bonuses is always 1!
#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
# * To get the total amount of bonus value of a custom parameter (which you add
#   with the above script call), use this script call:
#
#     actor_object.cparam_bonus("cparam") # Old method, still usable.
#     actor_object.cparam_bonus           # New method from v1.2.
#
#   This will return the total value of bonus custom parameter which you added
#   with the above 'add_cparam' script call.
#  
#   It should be clear what the above script call means by now, so I will
#   jump to the examples right away:
#
#     $game_actors[7].cparam_bonus("cdr") # Old method, still usable.
#     $game_actors[7].cdr_bonus           # New method from v1.2.
#   Gets the total value of bonus CDR Actor 7 has.
#
#     $game_party.members[2].cparam_bonus("vit") # Old method, still usable.
#     $game_party.members[2].vit_bonus           # New method from v1.2.
#   Gets the total value of bonus VIT the 2nd actor in the party has.
#
#   In theory, you can add bonus custom parameters for enemies too, but only in
#   the battle, and once the battle is over, these bonuses will be reset.
#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
# * To get the maximum/minimum value limits for a parameter, use this script
#   call:
#
#   - For actors:
#
#     actor_object.cparam_max("cparam")
#     actor_object.cparam_max
#     actor_object.cparam_min("cparam")
#     actor_object.cparam_min
#
#   - For enemies (although you most probably won't use this on enemies):
#
#     enemy_object.cparam_max("cparam")
#     enemy_object.cparam_max
#     enemy_object.cparam_min("cparam")
#     enemy_object.cparam_min
#
#   From v1.3, you can manipulate these limits with note-tags and script calls
#   as well, so it might be useful to know the limits of your parameters.
#   Well, it is mostly useful for coding purposes, but who knows, someone might
#   just use it for some eventing and what not...
#
#   Anyway, these will return the total amount of maximum/minimum limits of the
#   parameters.
#
#   Examples:
#
#     $game_actors[1].cparam_max("sta")
#     $game_actors[1].sta_max
#   Both of these will return the maximum limit for the STA parameter for
#   actor 1.
#
#     $game_party.members[3].cparam_min("dex")
#     $game_party.members[3].dex_min
#   Both of these will return the minimum limit for the DEX parameter for
#   the 3rd party member.
#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
# * To raise or lower the maximum/minimum limits of your parameters, you can
#   use these script calls:
#
#     actor_object.add_cparam_max("cparam",value)
#     actor_object.add_cparam_max(value)
#     actor_object.add_cparam_min("cparam",value)
#     actor_object.add_cparam_min(value)
#
#   These script calls will raise or lower the maximum/minimum limits of your
#   parameters permanently.
#  
#   Examples:
#
#     $game_actors[2].add_cparam_max("rge",35)
#     $game_actors[2].add_rge_max(35)
#   Both of these will raise the maximum limit for the RGE parameter by 35 for
#   actor 2.
#
#     $game_actors[5].add_cparam_min("mor",-50)
#     $game_actors[5].add_mor_min(-50)
#   Both of these will lower the minimum limit for the MOR parameter by 50 for
#   actor 5.
#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
# * To check the values added for your maximum/minimum limits with the above
#   script call for your parameters, use this script call:
#
#     actor_object.cparam_max_bonus("cparam")
#     actor_object.cparam_max_bonus
#     actor_object.cparam_min_bonus("cparam")
#     actor_object.cparam_min_bonus
#
#   These will get the values added with the 'add_cparam_max' and
#   'add_cparam_min' script calls explained above.
#   Might be good in some eventing or in your own scripts.
#
#   Examples:
#
#     $game_actors[2].cparam_max("cdr")
#     $game_actors[2].cdr_max
#   Both of these will return the total added value for the maximum limit of
#   the CDR parameter for actor 2.
#
#     $game_actors[5].cparam_min_bonus("mor")
#     $game_actors[5].mor_min_bonus
#   Both of these will return the total added value for the minimum limit of
#   the MOR parameter for actor 5.
#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
# * To get the names and short names of your custom parameters, you can use any
#   of the following script calls (if you set these settings up in the script):
#
#   - For the full names:
#
#     Vocab.cparam("cparam")
#     Vocab.cparam
#     CustomParams::Params["cparam"][:name]
#
#   - For the shortened names:
#
#     Vocab.cparam_a("cparam")
#     Vocab.cparam_a
#     CustomParams::Params["cparam"][:short]  
#  
#   Examples using the sample settings:
#
#     Vocab.cparam("spi")
#     Vocab.spi
#     CustomParams::Params["spi"][:name]
#   All of these would return the full name of the custom parameter, and that
#   is "Spirit" in this case.
#
#     Vocab.cparam_a("sta")
#     Vocab.sta_a
#     CustomParams::Params["sta"][:short]
#   All of these would return the shortened name of the custom parameter, and
#   that is "STA" in this case.
#
#   You can use these script calls anywhere you want!
#-------------------------------------------------------------------------------
# * < Installation >
#-------------------------------------------------------------------------------
# * Place this script between Materials and Main!
#-------------------------------------------------------------------------------
# * < Compatibility Info >
#-------------------------------------------------------------------------------
# * No known incompatibilities.
#-------------------------------------------------------------------------------
# * < Known Issues >
#-------------------------------------------------------------------------------
# * No known issues.
#-------------------------------------------------------------------------------
# * < Terms of Use >
#-------------------------------------------------------------------------------
# * Free to use for whatever purposes you want.
# * Credit me (Sixth) in your game, pretty please! :P
# * Posting modified versions of this script is allowed as long as you notice me
#   about it with a link to it!
#===============================================================================
$imported = {} if $imported.nil?
$imported["SixthCustomParams"] = true
#===============================================================================
# Settings:
#===============================================================================
module CustomParams
  #-----------------------------------------------------------------------------
  # Custom Parameter Settings:
  #-----------------------------------------------------------------------------
  # This is where you set up all your custom parameters.
  # You can make as many as you want!
  #
  # Format:
  #
  #   "cparam_key" => {
  #     :name => "Param Name",
  #     :short => "Param Name - Short Version",
  #     :default => value,
  #     :min => min_value,
  #     :max => max_value,
  #     :type => :add/:mul,
  #     :update => [:value,:min,:max],
  #   },
  #
  # Details:
  #
  #   "cparam_key" => {
  # This will be the key of the custom parameter. You can name it however you
  # want, but make sure to use a string for it, and make sure that there are
  # no duplicates!
  # This will be used in your note-tags and script calls, so I advise you to
  # use shorter keys!
  # NOTE:
  # You don't use the quotation marks in your note-tags, but you must use it
  # in any script calls which deal with custom parameters!
  # You can NOT use any key names here which are already defined method names
  # in the Game_Battler class! For example, the default params like ATK, DEF,
  # and such are defined as 'atk' and 'def', so those method names are already
  # taken. If you use a method name which is already taken by the default
  # engine, you will overwrite those methods, and as such, you will most
  # probably brake your game, because those methods are needed for the engine
  # to function correctly!
  # If, by any chance, overwriting these methods is exactly what you are
  # looking for, by all means, you can do it, just make sure to return the
  # correct object/value type in your methods, for example, ATK, DEF, and such
  # basic parameters expect positive integer numbers only, and CRI, EXR, and
  # other x-params/s-params expect a float number!  
  #
  #   :name => "Param Name",
  # This would be the full name of the parameter.
  # It is a setting which can be used to set up a name for your parameters.
  # Not used at all in the script! It is meant to be a helper setting for other
  # scripters, so that they can reference the name of the parameters from this
  # setting area in case they want to display it somewhere.
  # I might make use of this setting myself if someone request a menu edit to
  # show these new parameters somewhere, but until that happens, you don't have
  # to set these up at all, unless you want to use them somewhere in your own
  # codes.
  #
  #   :short => "Param Name - Short Version",
  # Same as above, just a helper setting for other scripters.
  # Feel free to ignore this setting if you want!
  #
  #   :default => value,
  # This will be the default value (starting value) of the parameter.
  # If an Actor or Enemy got no note-tags specifying a custom starting value
  # for a parameter, these values will be loaded.
  # The value can be an integer or float number, and it can be positive or
  # negative as well.
  # Advanced users can set this to be a string, in which case the string will
  # be evaluated as a Ruby code, and the returned value will be the value of
  # the parameter. Needless to say, this requires some Ruby coding knowledge!
  # You have a unique local variable which you can use to determine the owner of
  # the parameter in your formulas, you can reference it with 'user'
  # (without the apostrophes!). This will let you make formulas which can change
  # the value of the custom parameter depending on who is using that specific
  # armor piece or depending on how high the actor's/enemy's DEF is,
  # for example.
  # From v1.1, you can also set the value to a symbol, which will run the method
  # named like the symbol you used, and the result of that method will be the
  # value of the parameter. This method will be run in the 'CustomParamMethods'
  # module, so make sure that you add your own custom methods there! Your
  # methods must contain one argument, and that will be the owner of the
  # parameter! You must add this argument to your methods!
  # And additionally, you can also use an array for the value, where the first
  # element will be the symbol of the method name you want to use, and the
  # second element will be another array containing all the arguments you want
  # to send to that method. The arguments themselves will be evaluated in the
  # settings module, so you can't use any dynamic values or any in-game data
  # for those! Keep this in mind when you add your arguments!
  # Just like in the case of method using note-tags, the first argument will
  # always be the actor/enemy the parameter belongs to, and your own arguments
  # will come after that!
  # NOTE:
  # If you want to use the eval and/or custom method features, make sure to read
  # the setting explanation of the :update setting, and the note-tags made for
  # the parameter updates!
  #
  #   :min => min_value,
  # This is the minimum allowed value for the parameter.
  # The value of the parameter can never go below this!
  # You can set this up the same way like the :default setting explained above.
  # If you want this to be updated whenever the parameter is requested, you
  # must include :min in the :update setting for the parameter!
  #
  #   :max => max_value,
  # This is the maximum allowed value for the parameter.
  # The value of the parameter can never go above this!
  # You can set this up the same way like the :default setting explained above.
  # If you want this to be updated whenever the parameter is requested, you
  # must include :max in the :update setting for the parameter!
  #
  #   :type => :add/:mul,
  # This is the type of the parameter.
  # It can be either additive (:add) or multiplier (:mul).
  # To get what these mean, please refer to the explanation I gave in the
  # "Note-Tags" section (the explanation can be found in the details of the
  # first note-tag)!
  # You can omit this setting, in which case :add will be used by default!
  #
  #   :update => [:value,:min,:max],
  # This will decide if the value, max value, and/or min value for the parameter
  # should always be updated when the parameter is requested, or only once.
  # In the case of static parameters (which are not using any dynamic
  # (eval or method) values) you can omit this setting, and it will only read
  # the values once (when they are initialized). If you are using a dynamic
  # value setting for a parameter (eval or method), you should set this setting
  # up for your parameter, so that the code string/method that you entered could
  # be re-calculated every time the value of the parameter is requested.
  # So, in that case, this must be an array which can contain 3 symbols. These
  # symbols will decide which value should be updated when needed and which
  # shouldn't. The 3 symbols are:
  # :value = For the actual value of the parameter.
  # :max = For the maximum value of the parameter.
  # :min = For the minimum value of the parameter.
  # You can enter all 3 or only one or two of these symbols, it's up to you.
  # Do not update your parameters if you don't need to, that might cause some
  # performance loss depending on how you use your custom parameters!
  # Note that if you set one of these 3 values to be updated here, they will
  # always be updated when the parameter is requested on all database objects
  # used by the actor/enemy!
  # From v1.3, you can use a note-tag on your database objects to specify
  # exactly which param should be updated for that specific object.
  # This note-tag is object based, parameter based, and parameter value type
  # based (value, min value, max value), so you can be very specific as to which
  # parameters will update. This should be more performance friendly in case you
  # use a lot of dynamic parameters, but you don't need to re-calculate the
  # values on all objects or on all values. For example, if your default
  # parameter value uses an eval formula, but all your other objects (equipment,
  # states, classes, etc) use simple numeric values to raise/lower the
  # parameter, you don't really need to update anything but the normal value,
  # and only for the actors and enemies.
  # For more details on this, visit the note-tag section!
  #
  # NOTE:
  # If you are a scripter, you can also add your own settings to the custom
  # parameters as well. Just use a different key for your settings, and you can
  # easily reference them later from anywhere. For example, if you want to add
  # icon settings for a parameter drawing method, you could make a setting
  # named :icon and use that to set the icon index of the parameter.
  # This way you can keep all of your settings for your custom parameters at
  # one place.
  #-----------------------------------------------------------------------------
  Params = {
    'str' => {
      :name => "Strength", :short => "STR",
      :default => 10, :min => 1, :max => 999,
    },
    "dex" => {
      :name => "Dexterity", :short => "DEX",
      :default => 10, :min => 1, :max => 999,
    },
    'res' => {
      :name => "Resistance", :short => "RES",
      :default => 10, :min => 1, :max => 999,
    },
    'blk' => {
      :name => "Block", :short => "BLK",
      :default => 10, :min => 1, :max => 999,
    },
    'skl' => {
      :name => "Skill", :short => "SKL",
      :default => 10, :min => 1, :max => 999,
    },
    'pro' => {
      :name => "Profession", :short => "PRO",
      :default => 10, :min => 1, :max => 999,
    },
    "vit" => {
      :name => "Vitality", :short => "VIT",
      :default => [:lvl_formula, [0.009, 3, 5, 31, "true"]], # Uses the 'lvl_formula' method defined below
      :min => 1, :max => 999,
      #:update => [:value], <-- Will use the <vit value update> note-tag on the actor
    },
    "spi" => {
      :name => "Spirit", :short => "SPI",
      :default => "user.vit / 2", # Will be half of the VIT custom parameter
      :min => 1, :max => 999, :update => [:value],
    },
    "cdr" => {
      :name => "Crit Damage", :short => "CDR",
      :default => 1.0, :min => 0.0, :max => 3.0, :type => :mul,
    },
    "sta" => {
      :name => "Stamina", :short => "STA",
      :default => "user.agi * 10", # Will be equal with the user's AGI x 10
      :min => 10, :max => 2000, :update => [:value],
    },
    "cha" => {
      :name => "Charisma", :short => "CHA",
      :default => "$game_system.playtime / 60", # Will be equal with the minutes played
      :min => 0, :max => 9999, :update => [:value],
    },
    "mor" => {
      :name => "Morality", :short => "MOR",
      :default => 0, :min => -100, :max => 100,
    },
    "rge" => {
      :name => "Rage", :short => "RGE",
      :default => :hp_left, # Will use the method named 'hp_left' for the value calculation
      :min => 0, :max => 9999, :update => [:value],
    },
    # Add more custom parameter settings here!
  }
 
end
 
#-------------------------------------------------------------------------------
# Custom Parameter Methods:
#-------------------------------------------------------------------------------
# This is the place where you will need to set up your own methods you want
# to use for your custom parameters.
# You can make as many as you want!
# Remember that the first argument must be the user/owner of the parameter!
# The rest of the arguments can be freely set, you can add as many as you want,
# and you can do anything you want to do with them in your methods.
#
# NOTE:
# This is an advanced feature for people with coding knowledge!
# Calling these methods should be faster than calling an eval, so if you can,
# use your own methods set up here instead of always using eval formulas!
#-------------------------------------------------------------------------------
module CustomParamMethods # <-- No touchy-touchy!
 
  class << self # <-- No touchy-touchy!
   
    # A level based formula generated with 4 numeric values.
    # This is the same calculation like the built-in XP setting in the
    # database uses (it's called "EXP Curve" on the "Class" tab).
    def lvl_formula(user,base=1,extra=1,acc_a=1,acc_b=1,round_it="true")
      lv = user.level.to_f
      base = base.to_f
      extra = extra.to_f
      acc_a = acc_a.to_f
      acc_b = acc_b.to_f
      v = (base*((lv-1)**(0.9+acc_a/250))*lv*(lv+1)/
        (6+lv**2/50/acc_b)+(lv-1)*extra)
      v = v.round.to_i if round_it == "true"
      return v
    end
   
    # Another level based formula generated with 3 numeric values.
    def lvl_based(user,base="5",mul1="0.5",mul2="0.5",round_it="true")
      val = base.to_f + user.level * (mul1.to_f + (user.level * mul2.to_f))
      val = val.to_i if round_it == "true"
      return val
    end
   
    # The param scales in proportion of the actor's remaining HP
    def hp_left(user)
      return (user.mhp - user.hp) * 2
    end
   
    # The param scales in proportion of the actor's remaining mp
    # A minimum value can be set with arguments as well as the multiplier used
    def mp_left(user,min="10",mul="0.5")
      return min.to_i + ((user.mmp - user.mp) * mul.to_f).to_i
    end
   
  end # <-- No touchy-touchy!
 
end # <-- No touchy-touchy!
#===============================================================================
# End of settings! Editing anything below may lead to... you know it, right? o.o
#===============================================================================
 
module Vocab
 
  class << self
   
    def cparam(prm)
      return CustomParams::Params[prm][:name] || ""
    end
   
    def cparam_a(prm)
      return CustomParams::Params[prm][:short] || ""
    end
   
    CustomParams::Params.keys.each do |prm|
      cprm = %Q(
     
        def #{prm}
          return CustomParams::Params['#{prm}'][:name] || ""
        end
       
        def #{prm}_a
          return CustomParams::Params['#{prm}'][:short] || ""
        end
               
      )
      module_eval(cprm)
    end
   
  end
 
end
 
class RPG::BaseItem
 
  attr_accessor :cparam, :cparam_max, :cparam_min
 
  def update_cparam?(param,type)
    if CustomParams::Params[param][:update] &&
       CustomParams::Params[param][:update].include?(type)
      return true
    elsif self.cparam_update(param,type)
      return true
    end
    return false
  end
 
  def cparam_update(param,type)
    @cparam_update = {} if @cparam_update.nil?
    if @cparam_update[[param,type]].nil?
      if @note =~ /<#{param} #{type} update>/i
        @cparam_update[[param,type]] = true
      else
        @cparam_update[[param,type]] = false
      end
    end
    return @cparam_update[[param,type]]
  end
 
  def cparam(param,user)
    @cparam = {} if @cparam.nil?
    if @cparam[param].nil? || update_cparam?(param,:value)
      init_cparam(param,user)
    end
    return @cparam[param]
  end
 
  def init_cparam(param,user)
    if @note =~ /<#{param} formula: (.*)>/i
      @cparam[param] = eval($1)
    elsif @note =~ /<#{param} method: (.*)>/i
      args = [user]; mthd = ""
      $1.split(", ").each_with_index do |data,i|
        i == 0 ? mthd = data : args << data
      end
      if args.size > 1
        @cparam[param] = CustomParamMethods.send(mthd,*args)
      else
        @cparam[param] = CustomParamMethods.send($1,user)
      end
    elsif @note =~ /<#{param}: (.*)>/i
      @cparam[param] = $1.include?(".") ? $1.to_f : $1.to_i
    else
      case self
      when RPG::Actor, RPG::Enemy
        if CustomParams::Params[param][:default].is_a?(String)
          @cparam[param] = eval(CustomParams::Params[param][:default])
        elsif CustomParams::Params[param][:default].is_a?(Symbol)
          mthd = CustomParams::Params[param][:default]
          @cparam[param] = CustomParamMethods.send(mthd,user)
        elsif CustomParams::Params[param][:default].is_a?(Array)
          mthd = CustomParams::Params[param][:default][0]
          args = [user] + CustomParams::Params[param][:default][1]
          @cparam[param] = CustomParamMethods.send(mthd,*args)
        else
          @cparam[param] = CustomParams::Params[param][:default]
        end
      else
        if CustomParams::Params[param][:type] == :mul # Multiplier type
          @cparam[param] = 1
        else # Additive type
          @cparam[param] = 0
        end
      end
    end
  end
 
  def cparam_max(param,user)
    @cparam_max = {} if @cparam_max.nil?
    if @cparam_max[param].nil? || update_cparam?(param,:max)
      init_cparam_max(param,user)
    end
    return @cparam_max[param]
  end
 
  def init_cparam_max(param,user)
    if @note =~ /<#{param} max formula: (.*)>/i
      @cparam_max[param] = eval($1)
    elsif @note =~ /<#{param} max method: (.*)>/i
      args = [user]; mthd = ""
      $1.split(", ").each_with_index do |data,i|
        i == 0 ? mthd = data : args << data
      end
      if args.size > 1
        @cparam_max[param] = CustomParamMethods.send(mthd,*args)
      else
        @cparam_max[param] = CustomParamMethods.send($1,user)
      end
    elsif @note =~ /<#{param} max: (.*)>/i
      @cparam_max[param] = $1.include?(".") ? $1.to_f : $1.to_i
    else
      case self
      when RPG::Actor, RPG::Enemy
        if CustomParams::Params[param][:max].is_a?(String)
          @cparam_max[param] = eval(CustomParams::Params[param][:max])
        elsif CustomParams::Params[param][:max].is_a?(Symbol)
          mthd = CustomParams::Params[param][:max]
          @cparam_max[param] = CustomParamMethods.send(mthd,user)
        elsif CustomParams::Params[param][:max].is_a?(Array)
          mthd = CustomParams::Params[param][:max][0]
          args = [user] + CustomParams::Params[param][:max][1]
          @cparam_max[param] = CustomParamMethods.send(mthd,*args)
        else
          @cparam_max[param] = CustomParams::Params[param][:max]
        end
      else
        @cparam_max[param] = 0
      end
    end
  end
 
  def cparam_min(param,user)
    @cparam_min = {} if @cparam_min.nil?
    if @cparam_min[param].nil? || update_cparam?(param,:min)
      init_cparam_min(param,user)
    end
    return @cparam_min[param]
  end
 
  def init_cparam_min(param,user)
    if @note =~ /<#{param} min formula: (.*)>/i
      @cparam_min[param] = eval($1)
    elsif @note =~ /<#{param} min method: (.*)>/i
      args = [user]; mthd = ""
      $1.split(", ").each_with_index do |data,i|
        i == 0 ? mthd = data : args << data
      end
      if args.size > 1
        @cparam_min[param] = CustomParamMethods.send(mthd,*args)
      else
        @cparam_min[param] = CustomParamMethods.send($1,user)
      end
    elsif @note =~ /<#{param} min: (.*)>/i
      @cparam_min[param] = $1.include?(".") ? $1.to_f : $1.to_i
    else
      case self
      when RPG::Actor, RPG::Enemy
        if CustomParams::Params[param][:min].is_a?(String)
          @cparam_min[param] = eval(CustomParams::Params[param][:min])
        elsif CustomParams::Params[param][:min].is_a?(Symbol)
          mthd = CustomParams::Params[param][:min]
          @cparam_min[param] = CustomParamMethods.send(mthd,user)
        elsif CustomParams::Params[param][:min].is_a?(Array)
          mthd = CustomParams::Params[param][:min][0]
          args = [user] + CustomParams::Params[param][:min][1]
          @cparam_min[param] = CustomParamMethods.send(mthd,*args)
        else
          @cparam_min[param] = CustomParams::Params[param][:min]
        end
      else
        @cparam_min[param] = 0
      end
    end
  end
     
end
 
class Game_Battler < Game_BattlerBase
   
  def cparam(param)
    val = CustomParams::Params[param][:type] == :mul ? 1 : 0
    max = min = 0
    feature_objects.each do |obj|
      if CustomParams::Params[param][:type] == :mul
        val *= obj.cparam(param,self)
      else
        val += obj.cparam(param,self)
      end
      max += obj.cparam_max(param,self)
      min += obj.cparam_min(param,self)
    end
    max += self.cparam_max_bonus(param)
    min += self.cparam_min_bonus(param)
    if CustomParams::Params[param][:type] == :mul
      val *= self.cparam_bonus(param)
    else
      val += self.cparam_bonus(param)
    end
    val = max if val > max
    val = min if val < min
    return val
  end
     
  def cparam_bonus(param)
    @cparam_bonus = {} if @cparam_bonus.nil?
    init_cparam_bonus(param) if @cparam_bonus[param].nil?
    return @cparam_bonus[param]
  end
 
  def init_cparam_bonus(param)
    if CustomParams::Params[param][:type] == :mul # Multiplier type
      @cparam_bonus[param] = 1
    else # Additive type
      @cparam_bonus[param] = 0
    end
  end
 
  def add_cparam(param,val,limit=false)
    @cparam_bonus = {} if @cparam_bonus.nil?
    init_cparam_bonus(param) if @cparam_bonus[param].nil?
    if CustomParams::Params[param][:type] == :mul # Multiplier type
      @cparam_bonus[param] *= val
    else
      @cparam_bonus[param] += val
    end
    return unless limit
    max = cparam_max(param)
    min = cparam_min(param)
    @cparam_bonus[param] = max if @cparam_bonus[param] > max
    @cparam_bonus[param] = min if @cparam_bonus[param] < min
  end
 
  def cparam_max(param)
    max = 0
    feature_objects.each do |obj|
      max += obj.cparam_max(param,self)
    end
    max += self.cparam_max_bonus(param)
    return max
  end
 
  def cparam_max_bonus(param)
    @cparam_max_bonus = {} if @cparam_max_bonus.nil?
    @cparam_max_bonus[param] = 0 if @cparam_max_bonus[param].nil?
    return @cparam_max_bonus[param]
  end
 
  def add_cparam_max(param,val)
    @cparam_max_bonus = {} if @cparam_max_bonus.nil?
    @cparam_max_bonus[param] = 0 if @cparam_max_bonus[param].nil?
    @cparam_max_bonus[param] += val
  end
 
  def cparam_min(param)
    min = 0
    feature_objects.each do |obj|
      min += obj.cparam_min(param,self)
    end
    min += self.cparam_min_bonus(param)
    return min
  end
 
  def cparam_min_bonus(param)
    @cparam_min_bonus = {} if @cparam_min_bonus.nil?
    @cparam_min_bonus[param] = 0 if @cparam_min_bonus[param].nil?
    return @cparam_min_bonus[param]
  end
 
  def add_cparam_min(param,val)
    @cparam_min_bonus = {} if @cparam_min_bonus.nil?
    @cparam_min_bonus[param] = 0 if @cparam_min_bonus[param].nil?
    @cparam_min_bonus[param] += val
  end
 
  CustomParams::Params.keys.each do |prm|
    cprm = %Q(
   
      def #{prm}
        return self.cparam('#{prm}')
      end
     
      def #{prm}_bonus
        return self.cparam_bonus('#{prm}')
      end
     
      def add_#{prm}(val,limit=true)
        return self.add_cparam('#{prm}',val,limit)
      end
     
      def #{prm}_max
        return self.cparam_max('#{prm}')
      end
     
      def #{prm}_max_bonus
        return self.cparam_max_bonus('#{prm}')
      end
     
      def add_#{prm}_max(val)
        return self.add_cparam_max('#{prm}',val)
      end
     
      def #{prm}_min
        return self.cparam_min('#{prm}')
      end
     
      def #{prm}_min_bonus
        return self.cparam_min_bonus('#{prm}')
      end
     
      def add_#{prm}_min(val)
        return self.add_cparam_min('#{prm}',val)
      end
     
    )
    class_eval(cprm)
  end
 
end
#==============================================================================
# !!END OF SCRIPT - OHH, NOES!!
#==============================================================================