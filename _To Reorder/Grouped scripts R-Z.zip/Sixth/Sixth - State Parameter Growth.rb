=begin
 
Static State Parameter Bonuses
Made by: Sixth
 
- Description:
This script lets your states have static parameter bonuses (or debuffs).
 
- Usage:
Use this note-tag on your states:
 
  <static prm param_id: +value>   # Increases parameter
  <static prm param_id: -value>   # Lowers parameter
 
Replace the param_id with the ID of the parameter. They are:
  0 - MHP, 1 - MMP, 2 - ATK, 3 - DEF, 4 - MAG, 5 - MDF, 6 - AGI, 7 - LUK
 
Replace the value with the value of change. It must be an integer!
You must use a + or - sign before the value!
 
- Examples:
 
  <static prm 1: +200>
  <static prm 4: -50>
  <static prm 7: +777>
 
- Note:
The added values will get multiplied by the multiplier bonuses from the default
parameter features and buffs/debuffs!
 
=end
 
class RPG::State < RPG::BaseItem
 
  attr_accessor :static_prm
 
  def static_prm
    init_static_prm if @static_prm.nil?
    return @static_prm
  end
 
  def init_static_prm
    @static_prm = []
    8.times do |i|
      if @note =~ /<static prm #{i}(?:\s*):(?:\s*)([+\-]\d+)>/i
        @static_prm[i] = $1.to_i
      else
        @static_prm[i] = 0
      end
    end
  end
 
end
 
class Game_BattlerBase
 
  alias add_st_prms9927 param_plus
  def param_plus(pid)
    return states.inject(add_st_prms9927(pid)) {|r, st| r += st.static_prm[pid] }
	# for passive skill script compatibility below. Or the one above
#	return (states+passives).inject(add_st_prms9927(pid)) {|r, st| r += st.static_prm[pid] }
  end
 
end
# End of script! O_O