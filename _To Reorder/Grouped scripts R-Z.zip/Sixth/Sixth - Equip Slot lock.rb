=begin
 
Equip Slot Lock Feature
Made by: Sixth
 
By default, there is no way to lock an equipment slot, you can only lock entire
equip types, such as weapons, accessories, etc.
This script will let you lock the equip slots themselves regardless of what the
actor have equipped there.
 
You can use the following note-tag on actors, classes, weapons, armors and
states:
 
  <slot lock: slot_index1, slot_index2, ...>
 
Replace the slot_indexX parts with the index of the equipment slot you want to
lock. The 1st slot's index is 0, the 2nd slot's index is 1, and so on.
 
Examples: <slot lock: 0>, <slot lock: 2, 4, 6>, <slot lock: 0,1>
 
NOTE:
There are 2 ways of removing an equipment that is locked this way:
 
1.
Remove all feature objects containing the slot lock note-tag for the equipment
slot the equipment is on. This won't automatically unequip the equipment from
the slot, of course, but it will let the player change that equipment again if
he/she wants to.
 
2. Manually "force-remove" it by eventing.
Even if the equipment is removed, if the actor have some other feature objects
locking that slot, the slot will stay locked still.
 
If you want to temporary block a slot for an actor, doing it with states is a
pretty viable solution, but you can also put the note-tag on the equipment which
is equipped on that slot to get the same results. Doing the latter will lock the
slot whenever that equipment is equipped though, so if you don't want that, you
will have to use a state, I guess.
 
Place this script below the default scripts but above the "Main" slot.
 
=end
 
class RPG::BaseItem
 
  attr_accessor :slot_lock
 
  def slot_lock
    init_slot_lock if @slot_lock.nil?
    return @slot_lock
  end
 
  def init_slot_lock
    @slot_lock = []
    if @note =~ /<slot lock:(?:\s*)([^>]*)>/i
      $1.split(/(?:\s*,\s*)/).each {|sid| @slot_lock << sid.to_i }
    end
  end
 
end
 
class Game_Actor < Game_Battler
 
  def slot_lock
    return feature_objects.inject([]) {|r,obj| r += obj.slot_lock if obj }
  end
 
  alias add_slock9927 equip_change_ok?
  def equip_change_ok?(sid)
    return false if slot_lock.include?(sid)
    add_slock9927(sid)
  end
 
end
# End of script! O_O