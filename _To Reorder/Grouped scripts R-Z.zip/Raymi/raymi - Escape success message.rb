$imported = {} if $imported.nil? #DON'T EDIT
$imported["Raymi-EscapeSuccessMessage"] = true #DON'T EDIT
 
=begin
Raymi's Escape Success Message v.1.0
 
Update Log:
10/28/2017: v.1.0 - Script finished.
 
Directions:
Plug and play. Just change the message to what you want it to say when your
character's party successfully escapes a battle. Make sure to leave the quotes!
 
Terms of Use:
Free for commercial & non-commercial use, but you must credit Raymi/raymi100
and leave this header in tact. Don't claim this script as your own, and if you
want to edit it, feel free, just please don't post the edits without my
permission. Don't redistribute this script, just link back to this page.
Contact me with any issues you run into.
 
Contact Info:
rpgmakercentral.com Username: raymi100 - Best way to contact me
Email: raymithefangirl@aol.com - Not a good way to contact me
=end
 
#Configuration Start
module Raymi
  module EscapeSuccessConfig
  EscapeSuccessMessage = "They got away successfully!" #Change what's in between
                         #the quotes to what message you want it to say when
                         #you successfully escape a battle
  end
end
#Configuration End
 
#Code Start - Don't edit unless you know what you're doing.
module BattleManager
def self.process_escape
    $game_message.add(sprintf(Vocab::EscapeStart, $game_party.name))
    success = @preemptive ? true : (rand < @escape_ratio)
    Sound.play_escape
    if success
      $game_message.add('\.' + Raymi::EscapeSuccessConfig::EscapeSuccessMessage)
      process_abort
    else
      @escape_ratio += 0.1
      $game_message.add('\.' + Vocab::EscapeFailure)
      $game_party.clear_actions
    end
    wait_for_message
    return success
  end
end
#Code End