$imported = {} if $imported.nil? #DON'T EDIT
$imported["Raymi-DefeatMePlay"] = true #DON'T EDIT
 
=begin
Raymi's Defeat Me Play v.1.0
 
Update Log:
10/31/2017: v.1.0 - Script finished.
 
Directions:
Plug and play. Just change the sound to whatever ME you want to play when your
characters lose a battle. Make sure to leave the quotes!
 
Terms of Use:
Free for commercial & non-commercial use, but you must credit Raymi/raymi100
and leave this header in tact. Don't claim this script as your own, and if you
want to edit it, feel free, just please don't post the edits without my
permission. Don't redistribute this script, just link back to this page.
Contact me with any issues you run into.
 
Contact Info:
rpgmakercentral.com Username: raymi100 - Best way to contact me
Email: raymithefangirl@aol.com - Not a good way to contact me
=end
 
#Configuration Start
module Raymi
  module DefeatMeConfig
    DefeatMe = "Gameover2" #Change what's in between the quotes to which ME
                           #you want it to play when you lose a battle
  end
end
#Configuration End
 
#Code Start - Don't edit unless you know what you're doing.
module BattleManager
def self.process_defeat
    Audio.me_play('Audio/ME/' + Raymi::DefeatMeConfig::DefeatMe, 100, 100)
    $game_message.add(sprintf(Vocab::Defeat, $game_party.name))
    wait_for_message
    if @can_lose
      revive_battle_members
      replay_bgm_and_bgs
      SceneManager.return
    else      
      SceneManager.goto(Scene_Gameover)
    end
    battle_end(2)
    return true
  end
end
#Code End