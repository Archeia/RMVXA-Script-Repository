#Save Mouse Selection Part Two
#USE: Place under Save Mouse Selection Part One
#Use an event with this script call at the beginning of the game so that
#the game begins with the mouse enabled.
#$mouse.enabled = true
#To give the player the choice of enabling/disabling the mouse during the game
#provide an event - e.g. as a choice in the Main Menu - which does the
#following:
#To enable the mouse
#script call with 2 elements
#$mouse.enabled = true
#Mouse.shaz?(0)
#To disable the mouse
#script call with 2 elements
#$mouse.enabled = false
#Mouse.shaz?(1)
#
#CREDIT: Engr. Shana
#===============================================================================
module Mouse
  def self.shaz?(show)
    ShowCursor.call(show)
  end
end