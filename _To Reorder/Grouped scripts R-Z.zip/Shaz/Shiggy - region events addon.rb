class Game_Player < Game_Character
  
  alias trigger_region_update update
  def update
    trigger_region_update
	return if $game_map.interpreter.running?
	$game_map.check_trigger_region_event(@x, @y, @direction) if Input.trigger?(:C)
  end
end

class Game_Map 
    def check_trigger_region_event(x, y, dir)
		reg = region_id(x, y)
		next_reg = region_id(x_with_direction(x, dir), y_with_direction(y, dir))
		if @reg_evt[reg]
			if @reg_evt[reg]["trigger_on"]
				@req.push(@reg_evt[reg]["trigger_on"])
			end		
			case dir
			when 2
				if @reg_evt[reg]["tri_on_d"]
					@req.push(@reg_evt[reg]["tri_on_d"])
				end
			when 4
				if @reg_evt[reg]["tri_on_l"]
					@req.push(@reg_evt[reg]["tri_on_l"])
			end
			when 6
				if @reg_evt[reg]["tri_on_r"]
					@req.push(@reg_evt[reg]["tri_on_r"])
				end
			when 8
				if @reg_evt[reg]["tri_on_u"]
					@req.push(@reg_evt[reg]["tri_on_u"])
				end
			end
		end
		
		if @reg_evt[next_reg] 
			if @reg_evt[next_reg]["trigger_face"]
#				@req.push(@reg_evt[next_reg]["trigger_face"])
				@req.push(@reg_evt[reg]["trigger_face"])
			end
			case dir
			when 2
				if @reg_evt[next_reg]["tri_face_d"]
					@req.push(@reg_evt[next_reg]["tri_face_d"])
				end
			when 4
				if @reg_evt[next_reg]["tri_face_l"]
					@req.push(@reg_evt[next_reg]["tri_face_l"])
				end
			when 6
				if @reg_evt[next_reg]["tri_face_r"]
					@req.push(@reg_evt[next_reg]["tri_face_r"])
				end
			when 8
				if @reg_evt[next_reg]["tri_face_u"]
					@req.push(@reg_evt[next_reg]["tri_face_u"])
				end
			end	
		end		
    end
end