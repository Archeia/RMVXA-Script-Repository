#============================================================================
# REGION COMMON EVENTS
# v1.0 by Shaz
#----------------------------------------------------------------------------
# This script allows you to paint regions on your map, and set up common
# events to be run when the player walks onto or faces a tile with that
# region id.
#----------------------------------------------------------------------------
# To Install:
# Copy and paste into a new script slot in Materials.  This script aliases
# existing methods, so can go below all other custom scripts.
#----------------------------------------------------------------------------
# To Use:
# Paint regions on the map over the tiles you want to trigger events
# Create a common event that will do whatever you want to happen when the
#  player walks on or bumps into a tile with that region
# Add one of the following lines to the map's note box
#
# regevt: reg_id on common_event_id
#         This will trigger the common event when the player steps on the tile
#         eg: regevt: 63 on 15
#             will call common event 15 when the player steps on a region 63 tile
# regevt: reg_id face common_event_id
#         This will trigger the common event when the player is facing, but not
#         standing on the tile
#         eg: regevt: 62 face 12
#             will call common event 12 when the player is facing a region 62 tile
#             (you might use this if you want something to happen when the player
#             bumps into a wall - paint the bottom of the wall with region 62)
#----------------------------------------------------------------------------
# Terms:
# Use in free or commercial games
# Credit Shaz
#============================================================================

class Game_Map
  #--------------------------------------------------------------------------
  # * Setup
  #--------------------------------------------------------------------------
  alias shaz_re_game_map_setup setup
  def setup(map_id)
    shaz_re_game_map_setup(map_id)
    setup_region_events
  end
  #--------------------------------------------------------------------------
  # * Setup Common Events for Regions
  #--------------------------------------------------------------------------
  def setup_region_events
    @reg_evt = {}
    @req = []
    @map.note.split(/[\r\n+]/).each do |line|
      case line
      when /regevt:\s*(\d+)\s*(\w+)\s*(\d+)/i
        reg = $1.to_i
        mode = $2
        ce = $3.to_i
        if !@reg_evt.has_key?(reg)
          @reg_evt[reg] = {}
        end
        @reg_evt[reg][mode] = ce
      end
    end
  end
  #--------------------------------------------------------------------------
  # * Check Region Events
  #--------------------------------------------------------------------------
  def check_region_event(x, y, dir)
    reg = region_id(x, y)
    next_reg = region_id(x_with_direction(x, dir), y_with_direction(y, dir))
    if @reg_evt[reg] && @reg_evt[reg]["on"]
      @req.push(@reg_evt[reg]["on"])
    end
    if @reg_evt[next_reg] && @reg_evt[next_reg]["face"]
      @req.push(@reg_evt[next_reg]["face"])
    end
  end
  #--------------------------------------------------------------------------
  # * Frame Update
  #     main:  Interpreter update flag
  #--------------------------------------------------------------------------
  alias shaz_re_game_map_update update
  def update(main = false)
    shaz_re_game_map_update(main)
    $game_temp.reserve_common_event(@req.shift) if
      !$game_temp.common_event_reserved? && @req.size > 0
  end
end
  
class Game_Player < Game_Character
  #--------------------------------------------------------------------------
  # * Frame Update
  #--------------------------------------------------------------------------
  alias shaz_re_game_player_update update
  def update
    old_x = @x
    old_y = @y
    old_dir = @direction
    shaz_re_game_player_update
    $game_map.check_region_event(@x, @y, @direction) if
      @x != old_x || @y != old_y || @direction != old_dir
  end
end

# it should enable these commands
#
# trigger_face_l 
# trigger_face_d
# trigger_face_r
# trigger_face_u
#
# You just need to write it several times if you want several directions at once
class Game_Player < Game_Character
  
  alias trigger_region_update update
  def update
    trigger_region_update
	$game_map.check_trigger_region_event(@x, @y, @direction) if Input.trigger?(:C)
  end
end

class Game_Map 
    def check_trigger_region_event(x, y, dir)
		reg = region_id(x, y)
		next_reg = region_id(x_with_direction(x, dir), y_with_direction(y, dir))
		if @reg_evt[reg] && @reg_evt[reg]["trigger_on"]
		  @req.push(@reg_evt[reg]["trigger_on"])
		end
		if @reg_evt[next_reg] && @reg_evt[next_reg]["trigger_face"]
		  @req.push(@reg_evt[next_reg]["trigger_face"])
		end
    end
end