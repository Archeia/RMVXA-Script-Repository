#=============================================================================
#
# MultiTimers by Shaz
#
# Set up multiple timers with no on-screen display, to execute (by 'eval')
# a command.
#
#-----------------------------------------------------------------------------
#
# To set a timer:
# $game_timer.set_mt(unique_key, seconds, command)
#
# Examples:
# Turn on a switch after 10 seconds
# $game_timer.set_mt('TurnOnSwitch8', 10, '$game_switches[8] = true')
#
# Make the player jump in 5 seconds
# $game_timer.set_mt('PlayerJump', 5, '$game_player.jump(0,0)')
#
#-----------------------------------------------------------------------------
#
# To set a timer for a self switch:
# $game_timer.set_ss_mt(map_id, event_id, self_switch_id, seconds, value)
#
# Examples:
# Turn on a specific event's self switch 'A' in 5 seconds
# $game_timer.set_ss_mt(24, 5, 'A', 5, true)
#
# Turn on 'this' event's self switch 'A' in 5 seconds
# $game_timer.set_ss_mt(@map_id, @event_id, 'A', 5, true)
#
#-----------------------------------------------------------------------------
#
# To cancel a timer:
# $game_timer.delete_mt(key)
# $game_timer.delete_ss_mt(map_id, event_id, self_switch_id)
#
# To cancel the timers set above:
# $game_timer.delete_mt('TurnOnSwitch8')
# $game_timer.delete_mt('PlayerJump')
#
# To cancel the self switch timers set above:
# $game_timer.delete_ss_mt(24, 5, 'A')
# $game_timer.delete_ss_mt(@map_id, @event_id, 'A')
#
#=============================================================================

class Game_Timer
  alias shaz_mt_initialize initialize
  alias shaz_mt_update update
 
  def initialize
    shaz_mt_initialize
    @multi_timer = {}
  end
 
  def update
    shaz_mt_update
    update_mt
  end
 
  #--------------------------------------------------------------------------
  # * Set a timer
  #   key - unique id string
  #   seconds - how many seconds to wait
  #   command - string to eval
  #--------------------------------------------------------------------------
  def set_mt(key, seconds, command)
    @multi_timer[key] = [Graphics.frame_count + seconds * Graphics.frame_rate, command]
  end
  #--------------------------------------------------------------------------
  # * Set a timer for a self switch
  #   map, event, self switch - self switch to turn on/off
  #   seconds - how many seconds to wait
  #   value - new self switch value
  #--------------------------------------------------------------------------
  def set_ss_mt(map, event, selfswitch, seconds, value = true)
    key = sprintf('%d %d %s', map, event, selfswitch)
    command = sprintf('%s[[%d,%d,\'%s\']]=%s', '$game_self_switches', map, event,
      selfswitch, value)
    @multi_timer[key] = [Graphics.frame_count + seconds * Graphics.frame_rate, command]
  end
  #--------------------------------------------------------------------------
  # * Delete a timer
  #   cancels a previously set timer
  #--------------------------------------------------------------------------
  def delete_mt(key)
    @multi_timer.delete(key)
  end
  def delete_ss_mt(map, event, selfswitch)
    key = sprintf('%d %d %s', map, event, selfswitch)
    delete_mt(key)
  end
  #--------------------------------------------------------------------------
  # * Update timers
  #--------------------------------------------------------------------------
  def update_mt
    triggered = false
    @multi_timer = {} if !@multi_timer
    @multi_timer.select {|key, value| value[0] <= Graphics.frame_count}.each do |key, value|
      eval(value[1])
      @multi_timer.delete(key)
      triggered = true
    end
    $game_map.need_refresh = true if triggered
  end
end