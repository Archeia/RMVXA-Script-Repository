class Window_SkillCommand < Window_Command  
#--------------------------------------------------------------------------  
# * Create Command List  
#--------------------------------------------------------------------------  
  def make_command_list    
    return unless @actor    
    #@actor.added_skill_types.sort.each do |stype_id|    
    (@actor.skills.collect{|skill| skill.stype_id}).sort.uniq.each do |stype_id|      
    name = $data_system.skill_types[stype_id]      
    add_command(name, :skill, true, stype_id)    
    end  
  end
end