#Save Mouse selection Part One
#USE: Place under Shaz Super simple Mouse System
#Select a switch and NAME IT.  Insert the number at line 11 without
#leading zeros e.g. not switch = 008 but switch = 8
#For further use information see Save Mouse selection Part Two which
#must be used in conjunction with this script
#CREDITS: Shaz, Engr. Shana
#===============================================================================
module SHAZ
  module MouseSwitch
    ENABLED_SWITCH = 4
  end
end

class Sprite_Mouse < Sprite

  def enabled=(value)
    @enabled = value
    $game_switches[SHAZ::MouseSwitch::ENABLED_SWITCH] = value
    self.visible = value
  end
end

module DataManager
  class << self
    alias shaz_mouse_switch_load_game load_game
    alias shaz_mouse_switch_setup_new_game setup_new_game
  end

  def self.load_game(index)
    loaded = shaz_mouse_switch_load_game(index)
    if loaded
      $mouse.enabled = $game_switches[SHAZ::MouseSwitch::ENABLED_SWITCH] if $mouse && $game_switches
      return true
    else
      return false
    end
  end

  def setup_new_game
    shaz_mouse_switch_setup_new_game
    $mouse.enabled = true if $mouse
  end
end
class Sprite_Mouse < Sprite

  def enabled=(value)
    @enabled = value
    $game_switches[SHAZ::MouseSwitch::ENABLED_SWITCH] = value
    self.visible = value
    Mouse.update
  end
end