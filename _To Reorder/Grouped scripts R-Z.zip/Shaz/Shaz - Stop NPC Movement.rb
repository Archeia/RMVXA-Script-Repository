class Game_Event < Game_Character  
alias shaz_wait_for_message_game_event_update_self_movement
 update_self_movement  
 def update_self_movement    
 return if $game_message.busy? || $game_message.visible
 shaz_wait_for_message_game_event_update_self_movement
 end
end
