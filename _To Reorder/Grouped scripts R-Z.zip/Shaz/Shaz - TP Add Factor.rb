# TP Add Factor
# by Shaz
#
# Place <tp_add_factor: x> (where x is an integer) into an enemy's note tag.
# When a party member is attacked by that enemy, that number will be
# added to the resulting TP.

class Game_Battler < Game_BattlerBase
  alias shaz_tp_initialize initialize
  def initialize
    shaz_tp_initialize
    @tp_user = nil
  end

  alias shaz_tp_execute_damage execute_damage
  def execute_damage(user)
    @tp_user = user
    shaz_tp_execute_damage(user)
    @tp_user = nil
  end

  def charge_tp_by_damage(damage_rate)
    self.tp += 50 * damage_rate * tcr + (@tp_user ? @tp_user.tp_add_factor : 0)
  end
end

class Game_Actor < Game_Battler
  def tp_add_factor
    0
  end
end

class Game_Enemy < Game_Battler
  def tp_add_factor
    $data_enemies[@enemy_id].note =~ /<tp_add_factor:\s*(\d+)>/i ? $1.to_i : 0
  end
end