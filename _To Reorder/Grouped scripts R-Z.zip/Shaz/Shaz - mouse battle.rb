=begin
================================================================================
 ** Patch: Shaz mouse system + yanfly Battle System v1
 Diffuculty: super simple
 Author: AwesomeCool
 Date: Jan 25, 2014
  
--------------------------------------------------------------------------------
 ** Change log
  1.1: Jan  7, 2015
    -Fixed variable name error.
  1.0: Jan 25, 2014
    -Initial Release
     
--------------------------------------------------------------------------------
 *Requirements
 -SUPER SIMPLE MOUSE SCRIPT by Shaz
 -Yanfly Engine Ace - Ace Battle Engine
 
     
--------------------------------------------------------------------------------
 * Description
  
  Allows user to select enemy by putting mouse directly over it.
   
--------------------------------------------------------------------------------
  *Terms
   
  Free to use for all projects as long as credit is given to AwesomeCool, Shaz,
  and Yanfly
   
--------------------------------------------------------------------------------
 * How to Use
 
  -First, set Monster note tags
  -Second, Yell out loud
   
--------------------------------------------------------------------------------
 * Tags
  
    -Enemy:
     - <selectbox width: x>
      Description: replace x with width of character sprite 
      (if using battle symphony wth enemies that are either character sets or
      holder format, make it width of each INDIVIDUAL sprite on the sheet).
     - <selectbox height: y>
      Description: replace y with height of character sprite 
      (if using battle symphony wth enemies that are either character sets or
      holder format, make it height of each INDIVIDUAL sprite on the sheet).
       
    OPTIONAL:
     -<selectbox offset x: *>
      Description: replace * by offset of sprite's x value.
     -<selectbox offset y: *>
      Description: replace * by offset of sprite's y value.
       
           
--------------------------------------------------------------------------------
 *Script Calls
  
    -none
 
--------------------------------------------------------------------------------
=end
 
module Mouse #Do not touch this line.
  module Selection #Do not touch this line.
    #---------------------------------------------------------------------------
    #Configuration
    #---------------------------------------------------------------------------
     
    #Change 0 to number of default x offset you want
    DEFAULT_ENEMY_OFFSET_X = 0
     
    #Change -8 to number of default y offset you want
    DEFAULT_ENEMY_OFFSET_Y = -8
     
  end #Do not touch this line.
end #Do not touch this line.
 
#-------------------------------------------------------------------------------
#-------------------------------------------------------------------------------
#-------------------------------------------------------------------------------
#-------------------------------------------------------------------------------
### DO NOT EDIT BEYOND THIS POINT UNLESS YOU KNOW WHAT YOU ARE DOING ###
#-------------------------------------------------------------------------------
#-------------------------------------------------------------------------------
#-------------------------------------------------------------------------------
#-------------------------------------------------------------------------------
 
module Selection
   
    SelectboxOFFSET_X = /<(?:selectbox offset x):[ ](\d+)>/i
    SelectboxOFFSET_Y = /<(?:selectbox offset y):[ ](\d+)>/i
    Selectbox_W = /<(?:selectbox width):[ ](\d+)>/i
    Selectbox_H = /<(?:selectbox height):[ ](\d+)>/i
   
end
 
module DataManager
   
  #--------------------------------------------------------------------------
  # alias method: load_database
  #--------------------------------------------------------------------------
  class <<self; alias load_database_ms load_database; end
  def self.load_database
    load_database_ms
    load_notetags_ms
  end
   
  #--------------------------------------------------------------------------
  # new method: load_notetags_aoe
  #--------------------------------------------------------------------------
  def self.load_notetags_ms
    groups = [$data_enemies]
    for group in groups
      for obj in group
        next if obj.nil?
        obj.load_notetags_ms
      end
    end
  end
   
end # DataManager
 
#==============================================================================
# ¡ RPG::Enemy
#==============================================================================
 
class RPG::Enemy < RPG::BaseItem
   
  #--------------------------------------------------------------------------
  # public instance variables
  #--------------------------------------------------------------------------
  attr_accessor :offset_x
  attr_accessor :offset_y
  attr_accessor :hitbox_h
  attr_accessor :hitbox_w
   
  #--------------------------------------------------------------------------
  # common cache: load_notetags_aoe
  #--------------------------------------------------------------------------
  def load_notetags_ms
    @offset_x = Mouse::Selection::DEFAULT_ENEMY_OFFSET_X
    @offset_y = Mouse::Selection::DEFAULT_ENEMY_OFFSET_Y
    #---
    self.note.split(/[\r\n]+/).each { |line|
      case line
      #---
      when Selection::SelectboxOFFSET_X
        @offset_x = $1.to_i
      when Selection::SelectboxOFFSET_Y
        @offset_y = $1.to_i
      when Selection::Selectbox_W
        @hitbox_w = [$1.to_i, 1].max
      when Selection::Selectbox_H
        @hitbox_h = [$1.to_i, 1].max
      #---
      end
    } # self.note.split
    #---
  end
   
end # RPG::Enemy
 
class Scene_Battle < Scene_Base
  #--------------------------------------------------------------------------
  # * Start Processing
  #--------------------------------------------------------------------------
  alias  mouse_target_start start
  def start
    mouse_target_start
    enemySelectionSetup
  end
  #-----
   
  def enemySelectionSetup
    return if $game_troop.nil?
    $game_troop.members.each do |enemy|
      enemy.selectionBoxX = enemy.screen_x 
      enemy.selectionBoxWidth = enemy.screen_x + enemy.sprite.width
      enemy.selectionBoxY = enemy.screen_y
      enemy.selectionBoxHeight = enemy.screen_y + enemy.sprite.height
    end
  end
   
end
 
class Game_Battler < Game_BattlerBase
   
  attr_accessor :selectionBoxX
  attr_accessor :selectionBoxWidth
  attr_accessor :selectionBoxY
  attr_accessor :selectionBoxHeight
   
  alias selection_init initialize
  def initialize
    selection_init
    selectionBoxX = nil
    selectionBoxWidth = nil
    selectionBoxY = nil
    selectionBoxHeight = nil
  end
   
  def selectbox
    rect = Rect.new(0, 0, 32, 32)
    rect.x = screen_x  + selectbox_x_offset - selectbox_width/2
    rect.y = screen_y  + selectbox_y_offset - selectbox_height
    rect.width = selectbox_width
    rect.height = selectbox_height
    return rect
  end
   
  #--------------------------------------------------------------------------
  # new method: hitbox_x_offset
  #--------------------------------------------------------------------------
  def selectbox_x_offset
    return 0
  end
   
  #--------------------------------------------------------------------------
  # new method: hitbox_y_offset
  #--------------------------------------------------------------------------
  def selectbox_y_offset
    return 0
  end
   
  #--------------------------------------------------------------------------
  # new method: hitbox_width
  #--------------------------------------------------------------------------
  def selectbox_width
    return sprite.width
  end
   
  #--------------------------------------------------------------------------
  # new method: hitbox_height
  #--------------------------------------------------------------------------
  def selectbox_height
    return sprite.height
  end
   
end
 
class Game_Enemy < Game_Battler
   
  #--------------------------------------------------------------------------
  # new method: sprite
  #--------------------------------------------------------------------------
  def sprite
    return SceneManager.scene.spriteset.enemy_sprites.reverse[self.index]
  end
   
  #--------------------------------------------------------------------------
  # new method: hitbox_x_offset
  #--------------------------------------------------------------------------
  def selectbox_x_offset
    return enemy.offset_x unless enemy.offset_x.nil?
    return super
  end
   
  #--------------------------------------------------------------------------
  # new method: hitbox_y_offset
  #--------------------------------------------------------------------------
  def selectbox_y_offset
    return enemy.offset_y unless enemy.offset_y.nil?
    return super
  end
   
  #--------------------------------------------------------------------------
  # new method: hitbox_width
  #--------------------------------------------------------------------------
  def selectbox_width
    return enemy.hitbox_w unless enemy.hitbox_w.nil?
    return super
  end
   
  #--------------------------------------------------------------------------
  # new method: hitbox_height
  #--------------------------------------------------------------------------
  def selectbox_height
    return enemy.hitbox_h unless enemy.hitbox_h.nil?
    return super
  end
   
end # Game_Enemy
 
class Spriteset_Battle
  attr_accessor :actor_sprites
  attr_accessor :enemy_sprites
end
 
class Window_BattleEnemy < Window_Selectable
   
  def process_mouse_handling
    return unless $mouse.enabled? && cursor_movable?
    # Add a delay to prevent too-fast scrolling
    @delay = @delay ? @delay + 1 : 0
    return if @delay % 3 > 0
     
    mx, my = *Mouse.position
       
      alive_troop = $game_troop.alive_members
      alive_troop.sort! { |a,b| a.screen_x <=> b.screen_x }
       
      for i in 0 ... alive_troop.size
        rect = alive_troop[i].selectbox
        if mx.between?(rect.x, rect.x + rect.width) &&
          my.between?(rect.y, rect.y + rect.height)
          last_index = @index
          select(i)
          if @index != last_index
            Sound.play_cursor 
          end
          break
        end
      end
  end
   
end