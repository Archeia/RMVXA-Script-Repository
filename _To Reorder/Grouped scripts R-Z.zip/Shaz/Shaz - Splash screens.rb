#============================================================================
# SIMPLE SPLASH SCREENS# V 1.0
# ---------------------------------------------------------------------------
# Author: Shaz
# Date:   June 17, 2013
# ---------------------------------------------------------------------------
# Instructions:
# Place into a new slot below other scripts
# Adjust values in FADE_TIME, HOLD_TIME and CLICKTHROUGH as necessar
# Create a Graphics/Splash folder
# Add images to Graphics/Splash folder with a name of Splash#.*
#   where # is a number and * is the file type
#   eg: Splash1.png  Splash2.jpg
# When distributing, copy and remove Graphics/Splash folder during compression
#   and add it back in after extracting the compressed file - this allows
#   distributors to add and resequence splash screens to meet their own
#   requirements
#============================================================================
module Cache 
 def self.splash(filename)   
 load_bitmap("Graphics/Splash/", filename) 
 end
 end
 module SceneManager 
 def self.first_scene_class   
 $BTEST ? Scene_Battle : $TEST ? 
 Scene_Title : Scene_Splash 
 end
 end
 class Scene_Splash < Scene_Base  
 # fade/hold times in seconds  
 FADE_TIME = 0.5   
 HOLD_TIME = 3  
 # allow space bar to skip waiting  
 CLICKTHROUGH = true  
 #--------------------------------------------------------------------------  
 # * Start Processing  
 #--------------------------------------------------------------------------  
 def start    super    Graphics.fadeout(0)        
 # Create list of splash screens    
 @splashes = Dir.entries("Graphics/Splash").select {|name| name =~ /splash/i}.sort        
 # Display splash screens    
 @splashes.each do |splash|      
 show_splash(splash)    
 end        
 # Go to title    
 SceneManager.goto(Scene_Title)  
 end  
 #--------------------------------------------------------------------------  
 # * Show Splash Screen  
 #--------------------------------------------------------------------------  
 def show_splash(splash)    
 # display splash screen    
 @splash = Sprite.new    
 @splash.bitmap = Cache.splash(splash)        
 # fade in    
 Graphics.fadein(FADE_TIME * Graphics.frame_rate)    
 Graphics.wait(FADE_TIME * Graphics.frame_rate)    
 # pause    
 (HOLD_TIME * Graphics.frame_rate).times do      
 # break if skippable      
 Graphics.update     
 Input.update      
 break if CLICKTHROUGH && Input.trigger?(:C)    
 end    
 # fade out and dispose   
 Graphics.fadeout(FADE_TIME * Graphics.frame_rate)  
 Graphics.wait(FADE_TIME * Graphics.frame_rate) 
 @splash.bitmap.dispose   
 @splash.dispose 
 end
 end