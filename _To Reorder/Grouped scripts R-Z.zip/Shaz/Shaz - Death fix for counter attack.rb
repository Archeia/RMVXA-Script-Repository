#Engr. Shana fix for enemy not disappearing when death by counter-attack
#
class Scene_Battle
  def invoke_counter_attack(target, item)
    @log_window.display_counter(target, item)
    attack_skill = $data_skills[target.counterskill]
    if attack_skill.for_opponent?
      if attack_skill.for_all?
        show_animation(target.opponents_unit.alive_members, attack_skill.animation_id)
        for t in target.opponents_unit.alive_members
          t.item_apply(target, attack_skill)
          refresh_status
          @log_window.display_action_results(t, attack_skill)
          t.perform_collapse_effect if t.hp == 0
        end
      else
        show_animation([@subject], attack_skill.animation_id)
        @subject.item_apply(target, attack_skill)
        refresh_status
        @log_window.display_action_results(@subject, attack_skill)
        @subject.perform_collapse_effect if @subject.hp == 0   
      end
    else
      if attack_skill.for_all?
        if attack_skill.for_dead_friend?
          show_animation(target.friends_unit.dead_members, attack_skill.animation_id)
          for t in target.friends_unit.dead_members
            t.item_apply(target, attack_skill)
            refresh_status
            @log_window.display_action_results(t, attack_skill)
            t.perform_collapse_effect if t.hp == 0
          end
        else
          show_animation(target.friends_unit.alive_members, attack_skill.animation_id)
          for t in target.friends_unit.alive_members
            t.item_apply(target, attack_skill)
            refresh_status
            @log_window.display_action_results(t, attack_skill)
            t.perform_collapse_effect if t.hp == 0
          end
        end
      else
        show_animation([target], attack_skill.animation_id)
        target.item_apply(target, attack_skill)
        refresh_status
        @log_window.display_action_results(target, attack_skill)
        target.perform_collapse_effect if target.hp == 0
      end
    end
  end
end