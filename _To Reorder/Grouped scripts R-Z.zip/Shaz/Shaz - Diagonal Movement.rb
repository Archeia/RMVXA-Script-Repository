#----------------------------------------------------------------------------
# Simple Diagonal Movement 1.0
# by Shaz
#----------------------------------------------------------------------------
# This script lets you define tiles where a player, followers or events will move
# diagonally as they walk onto or off the tile - use for stairs, slopes, etc.
# Avoids the need for the player to use the up/down arrows, or for you to
# use events to force diagonal movement.
#----------------------------------------------------------------------------
# Paste script below others in the Materials section.
# May not be compatible with scripts that overwrite or alias the
# Game_CharacterBase.move_straight method
#----------------------------------------------------------------------------
# To use:
# Change the three constants below to reflect whether you are using terrain
# tags or regions to identify diagonal movement tiles, and what terrain tag
# or region id to look for.
#----------------------------------------------------------------------------



TERRAIN_LOOKUP = false # true for terrain tags, false for region ids
UPLR = 31 # terrain or region to go up when moving right 
DOWNLR = 32 # terrain or region to go down when moving right

class Game_CharacterBase
  #--------------------------------------------------------------------------
  # * Method aliases
  #--------------------------------------------------------------------------
  alias shaz_sdm_move_straight move_straight
  #--------------------------------------------------------------------------
  # * Diagonal Override
  #     d:        Direction (2,4,6,8)
  #--------------------------------------------------------------------------
  def diagonal_override(d)
    this_override = TERRAIN_LOOKUP ? $game_map.terrain_tag(@x, @y) : 
      $game_map.region_id(@x, @y)
    new_x = $game_map.round_x_with_direction(@x, d)
    new_y = $game_map.round_y_with_direction(@y, d)
    new_override = TERRAIN_LOOKUP ? $game_map.terrain_tag(new_x, new_y) : 
      $game_map.region_id(new_x, new_y)
      
    if (new_override == UPLR && d == 6)
      return 6, 8
    elsif (new_override == DOWNLR && d == 4)
      return 4, 8
    elsif (this_override == UPLR && d == 4)
      return 4, 2
    elsif (this_override == DOWNLR && d == 6)
      return 6, 2
    else
      return 0, 0
    end
  end
  #--------------------------------------------------------------------------
  # * Move Straight
  #     d:        Direction (2,4,6,8)
  #     turn_ok : Allows change of direction on the spot
  #--------------------------------------------------------------------------
  def move_straight(d, turn_ok = true)
    ovh, ovv = diagonal_override(d)
    if ovh != 0 && ovv != 0
      move_diagonal(ovh, ovv)
    else
      shaz_sdm_move_straight(d, turn_ok)
    end
  end
end

