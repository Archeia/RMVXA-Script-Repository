# ╔══════════════════════════════════════════════════════╤═══════╤════════════╗
# ║ Final Fantasy Style Battle Log                       │ v3.06 │ (09/04/15) ║
# ╠══════════════════════════════════════════════════════╧═══════╧════════════╣
# ║ Author  : William Couillard                                               ║
# ║ Thanks  : KilloZapIt, Swish, Daniel Babineau, AlliedG, Punisher667,       ║
# ║           GreeNRM & Keith Brewer                                          ║
# ║ E-Mail  : cooliebk18@yahoo.com                                            ║
# ╠═══════════════════════════════════════════════════════════════════════════╣
# ║ ABOUT                                                                     ║
# ╠═══════════════════════════════════════════════════════════════════════════╣
# ║ This script changes the behavior of the battle log window to act as the   ║
# ║ Battle Log window in a Final Fantasy game would.                          ║
# ╠═══════════════════════════════════════════════════════════════════════════╣
# ║ TERMS OF USE (Applies retroactively to previous versions of this script)  ║
# ╠═══════════════════════════════════════════════════════════════════════════╣
# ║ ► Do not edit the script's header or comments.                            ║
# ║ ► If the script code is modified for your own purposes, then it must      ║
# ║   remain encrypted in your project upon release.                          ║
# ║ ► NOT free to use in commercial projects.                                 ║
# ║ ► Proper credit is to be given to the script author, in-game and in any   ║
# ║   applicable documentation included with the game.                        ║
# ╠═══════════════════════════════════════════════════════════════════════════╣
# ║ FEATURES                                                                  ║
# ╠═══════════════════════════════════════════════════════════════════════════╣
# ║ ► Removes the black background behind the default Battle Log window.      ║
# ║ ► Custom opacity for the Battle Log window.                               ║
# ║ ► Text alignment settings for Battle Log custom messages.                 ║
# ║ ► Text alignment settings for Battle Log default messages.                ║
# ║ ► Restrict skills without any "use" message from showing up in the Battle ║
# ║   Log window, such as normal attacks, defending, or hidden skills.        ║
# ║ ► Width, offset and alignment settings for the Battle Log window.         ║
# ║ ► Option to use different windowskins for skills/items used by actors or  ║
# ║   enemies.                                                                ║
# ║ ► Option to use a different font for skills/items used by actors or       ║
# ║   enemies.                                                                ║
# ║ ► Customize the message speed of the Battle Log window.                   ║
# ║ ► Option to omit any default messages shown in the Battle Log window.     ║
# ╠═══════════════════════════════════════════════════════════════════════════╣
# ║ KNOWN ISSUES                                                              ║
# ╠═══════════════════════════════════════════════════════════════════════════╣
# ║ ► Possibility of unreported compatibility issues. Please report any bugs  ║
# ║   you experience as soon as possible!                                     ║
# ╠═══════════════════════════════════════════════════════════════════════════╣
# ║ CHANGE LOG                                                                ║
# ╠═════════════════════════════════════════════════════════════════╤═════════╣
# ║ ■ September 04, 2015 : Streamlined ignored skills; any skill    │ (v3.06) ║
# ║                        without a "use" message is now ignored   │         ║
# ║                        by default and will not bring up the     │         ║
# ║                        Battle Log to show the icon/name         │         ║
# ║                                                                 │         ║
# ║                        Font option for Actor/Enemy skills/items │         ║
# ╟─────────────────────────────────────────────────────────────────┼─────────╢
# ║ ■ September 02, 2015 : Aliased def use_item in order to improve │ (v3.05) ║
# ║                        compatibility with other scripts         │         ║
# ╟─────────────────────────────────────────────────────────────────┼─────────╢
# ║ ■ September 01, 2015 : Streamlined compatibilities for scripts  │ (v3.04) ║
# ║                        with import settings to make them plug   │         ║
# ║                        and play / Bugfixes                      │         ║
# ╟─────────────────────────────────────────────────────────────────┼─────────╢
# ║ ■ September 01, 2015 : Just a bit of code cleanup to remove     │ (v3.03) ║
# ║                        redundant lines                          │         ║
# ╟─────────────────────────────────────────────────────────────────┼─────────╢
# ║ ■ August 31, 2015    : Compatibility for CP Damage Popup 1.2a   │ (v3.02) ║
# ╟─────────────────────────────────────────────────────────────────┼─────────╢
# ║ ■ August 30, 2015    : Bugfixes (text width)                    │ (v3.01) ║
# ╟─────────────────────────────────────────────────────────────────┼─────────╢
# ║ ■ August 30, 2015    : Complete overhaul to provide more        │ (v3.00) ║
# ║                        options and maximum compatibility with a │         ║
# ║                        wide variety of popular battle scripts.  │         ║
# ╟─────────────────────────────────────────────────────────────────┼─────────╢
# ║ ■ August 28, 2015    : Bugfixes (enemy death animation)         │ (v2.04) ║
# ╟─────────────────────────────────────────────────────────────────┼─────────╢
# ║ ■ December 12, 2014  : Bugfixes (battle sounds playing again)   │ (v2.03) ║
# ╟─────────────────────────────────────────────────────────────────┼─────────╢
# ║ ■ December 11, 2014  : Bugfixes (y offset text positioning)     │ (v2.02) ║
# ╟─────────────────────────────────────────────────────────────────┼─────────╢
# ║ ■ December 11, 2014  : Bugfixes (blank window fix)              │ (v2.01) ║
# ╟─────────────────────────────────────────────────────────────────┼─────────╢
# ║ ■ December 10, 2014  : Almost a full rewrite. Needless features │ (v2.00) ║
# ║                        removed. Some new ones added. Skill and  │         ║
# ║                        Item icons displaying now. Option for    │         ║
# ║                        different font for ally and enemy skills │         ║
# ║                        added.                                   │         ║
# ╟─────────────────────────────────────────────────────────────────┼─────────╢
# ║ ■ October 31, 2014   : New option to use different windowskins  │ (v1.04) ║
# ║                        for actor and enemy attacks              │         ║
# ╟─────────────────────────────────────────────────────────────────┼─────────╢
# ║ ■ August 15, 2013    : Bugfixes                                 │ (v1.03) ║
# ╟─────────────────────────────────────────────────────────────────┼─────────╢
# ║ ■ December 12, 2012  : Font options added                       │ (v1.02) ║
# ╟─────────────────────────────────────────────────────────────────┼─────────╢
# ║ ■ December 06, 2012  : Width and Window alignment options added │ (v1.01) ║
# ║                        Show Name option added                   │         ║
# ╟─────────────────────────────────────────────────────────────────┼─────────╢
# ║ ■ December 05, 2012  : Initial release.                         │ (v1.00) ║
# ╠═════════════════════════════════════════════════════════════════╧═════════╣
# ║ NEXT VERSION                                                              ║
# ╠═══════════════════════════════════════════════════════════════════════════╣
# ║ ■ Compatibility Patches                                                   ║
# ╠═══════════════════════════════════════════════════════════════════════════╣
# ║ OVERWRITTEN METHODS                                                       ║
# ╠═══════════════════════════════════════════════════════════════════════════╣
# ║   This script overwrites almost every method in Window_BattleLog and also ║
# ║   overwrites one method in Scene_Battle, for compatibility.               ║
# ╟───────────────────────────────────────────────────────────────────────────╢
# ║ ■ class Scene_Battle < Scene_Base                                         ║
# ║    ► def use_item                                                         ║
# ╠═══════════════════════════════════════════════════════════════════════════╣
# ║ NEW METHODS                                                               ║
# ╠═══════════════════════════════════════════════════════════════════════════╣
# ║   There are several new methods added to Window_BattleLog.                ║
# ╟───────────────────────────────────────────────────────────────────────────╢
# ║ ■ class Window_BattleLog < Window_Selectable                              ║
# ║    ► def show_log                                                         ║
# ║    ► def window_left_position                                             ║
# ║    ► def window_center_position                                           ║
# ║    ► def window_right_position                                            ║
# ║    ► def y_offset                                                         ║
# ║    ► def item_name_width                                                  ║
# ║    ► def skill_name_width                                                 ║
# ║    ► def draw_skill_name                                                  ║
# ║    ► def draw_items_name                                                  ║
# ║    ► def v_align                                                          ║
# ║    ► def c_align                                                          ║
# ╠═══════════════════════════════════════════════════════════════════════════╣
# ║ INSTRUCTIONS                                                              ║
# ╠═══════════════════════════════════════════════════════════════════════════╣
# ║ Simply paste this script anywhere above the Main Process script and below ║
# ║ the "Materials" section. It's a good idea to place this script BELOW any  ║
# ║ battle system scripts you are using, to ensure compatibility.             ║
# ║                                                                           ║
# ║ NOTE: When setting the "use" message in the database for a skill, it is   ║
# ║       important to remember that the Actor name or Enemy name is OMITTED. ║
# ║       It's usually a good idea to just input the skill's name in the      ║
# ║       "use" message dialogue box. The skill/item icon is shown with the   ║
# ║       skill/item name. This is what will determine the text displayed.    ║
# ║       You can name the skill in the database whatever you want, and the   ║
# ║       script will display the icon and whatever is in the message box.    ║
# ║                                                                           ║
# ║ i.e.: Just input "Fire" instead of "casts Fire!"                          ║
# ║                                                                           ║
# ║ NOTE: You can also show a CUSTOM message, by using the second message box ║
# ║       in the database for skills. Simply write whatever you want in that  ║
# ║       box, and the skill/item icon will not be shown. Your new custom     ║
# ║       message will display instead.                                       ║
# ║                                                                           ║
# ║ i.e.: "Precious light, be our armor to protect us! Protect!"              ║
# ╠═══════════════════════════════════════════════════════════════════════════╣
# ║ IMPORT SETTING                                                            ║
# ╚═══════════════════════════════════════════════════════════════════════════╝
$imported = {} if $imported.nil?           # Do not edit!
$imported[:wc_ff_style_battle_log] = true  # Do not edit!
# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║ CUSTOMIZATION MODULE                                                      ║
# ╚═══════════════════════════════════════════════════════════════════════════╝
module COOLIE
  module LOG
# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║ Set window width (in pixels; 544 by default)                              ║
# ╚═══════════════════════════════════════════════════════════════════════════╝
    WINDOW_WIDTH            = 544
# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║ Set window X offset (in pixels; can be negative)                          ║
# ╚═══════════════════════════════════════════════════════════════════════════╝
    WINDOW_X_OFFSET         = 0
# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║ Set window Y offset (in pixels; can be negative)                          ║
# ╚═══════════════════════════════════════════════════════════════════════════╝
    WINDOW_Y_OFFSET         = 0
# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║ Set window alignment (0 = Left, 1 = Center, 2 = Right)                    ║
# ╚═══════════════════════════════════════════════════════════════════════════╝
    WINDOW_ALIGN            = 1
# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║ Window opacity (0-255; high numbers make the window more visible)         ║
# ╚═══════════════════════════════════════════════════════════════════════════╝
    WINDOWSKIN_OPACITY      = 255
# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║ Window back opacity (0-255; high numbers make the window more visible)    ║
# ╚═══════════════════════════════════════════════════════════════════════════╝
    WINDOWSKIN_BACK_OPACITY = 255
# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║ Windowskin used for actor skills/items (Graphics/System folder)           ║
# ╚═══════════════════════════════════════════════════════════════════════════╝
    WINDOWSKIN_ACTOR        = "Window"
# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║ Windowskin used for enemy skills/items (Graphics/System folder)           ║
# ╚═══════════════════════════════════════════════════════════════════════════╝
    WINDOWSKIN_ENEMY        = "Window"
# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║ Message speed of the Battle Log window (in frames)                        ║
# ╚═══════════════════════════════════════════════════════════════════════════╝
    MESSAGE_SPEED           = 20
# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║ Set custom message alignment (0 = Left, 1 = Center, 2 = Right)            ║
# ║ NOTE: Only applies to custom messages on skills!                          ║
# ╚═══════════════════════════════════════════════════════════════════════════╝
    CUSTOM_MESSAGE_ALIGN    = 1
# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║ Set log message alignment (0 = Left, 1 = Center, 2 = Right)               ║
# ║ NOTE: Only applies to default Battle Log messages (miss, etc.)            ║
# ╚═══════════════════════════════════════════════════════════════════════════╝
    LOG_MESSAGE_ALIGN       = 1
# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║ Font setting for skills/items used by actors                              ║
# ║ i.e. Font.default_name, "Arial", ["Arial", "Verdana"]                     ║
# ╚═══════════════════════════════════════════════════════════════════════════╝
    FONT_ACTOR              = Font.default_name
# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║ Font settings for skills/items used by enemies                            ║
# ║ i.e. Font.default_name, "Arial", ["Arial", "Verdana"]                     ║
# ╚═══════════════════════════════════════════════════════════════════════════╝
    FONT_ENEMY              = Font.default_name
# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║ Set which Battle Log messages to omit (true shows as normal, false omits) ║
# ╚═══════════════════════════════════════════════════════════════════════════╝
    SHOW_MISS               = true
    SHOW_CRIT               = true
    SHOW_EVADE              = true
    SHOW_DAMAGE             = true
    SHOW_COUNTER            = true
    SHOW_REFLECT            = true
    SHOW_SUB                = true
    SHOW_FAILURE            = true
    SHOW_ADDED_STATE        = true
    SHOW_CURRENT_STATE      = true
    SHOW_REMOVED_STATE      = true
    SHOW_AFFECTED_STATE     = true
    SHOW_BUFFS              = true
# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║ MODULE END                                                                ║
# ╚═══════════════════════════════════════════════════════════════════════════╝
  end # module LOG
end # module COOLIE

#   [Do not edit anything below this line unless you know what you're doing!]
#       [If you are having trouble with compatibility, please report it!]

# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║ WINDOW_BATTLELOG                                                          ║
# ╚═══════════════════════════════════════════════════════════════════════════╝
class Window_BattleLog < Window_Selectable
# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║ Object Initialization                                                     ║
# ╚═══════════════════════════════════════════════════════════════════════════╝
  def initialize
    case COOLIE::LOG::WINDOW_ALIGN
      when 0 # Left Aligned
        super(window_left_position, y_offset, window_width, window_height)
      when 1 # Center Aligned
        super(window_center_position, y_offset, window_width, window_height)
      when 2 # Right Aligned
        super(window_right_position, y_offset, window_width, window_height)
      end
    self.z -= 10
    self.opacity = 0
    @lines = []
    @num_wait = 0
    create_back_bitmap
    create_back_sprite
    refresh
  end
# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║ Get Window Width                                                          ║
# ╚═══════════════════════════════════════════════════════════════════════════╝
  def window_width
    COOLIE::LOG::WINDOW_WIDTH
  end
# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║ Get Window Y Offset                                                       ║
# ╚═══════════════════════════════════════════════════════════════════════════╝
  def y_offset
    return COOLIE::LOG::WINDOW_Y_OFFSET
  end
# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║ Get Maximum Number of Lines                                               ║
# ╚═══════════════════════════════════════════════════════════════════════════╝
  def max_line_number
    return 1
  end
# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║ Get Background Color                                                      ║
# ╚═══════════════════════════════════════════════════════════════════════════╝
  def back_color
    Color.new(0, 0, 0, 0)
  end
# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║ Show Log                                                     [NEW METHOD] ║
# ╚═══════════════════════════════════════════════════════════════════════════╝
  def show_log
    self.opacity = COOLIE::LOG::WINDOWSKIN_OPACITY
    self.back_opacity = COOLIE::LOG::WINDOWSKIN_BACK_OPACITY
    refresh
  end
# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║ Clear                                                                     ║
# ╚═══════════════════════════════════════════════════════════════════════════╝
  def clear
    @num_wait = 0
    @lines.clear
    self.opacity = 0
    self.back_opacity = 0
    refresh
  end
# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║ Get Message Speed                                                         ║
# ╚═══════════════════════════════════════════════════════════════════════════╝
  def message_speed
    return COOLIE::LOG::MESSAGE_SPEED
  end
# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║ Display Counterattack                                                     ║
# ╚═══════════════════════════════════════════════════════════════════════════╝
  def display_counter(target, item)
    target.do_pop(:counter) if $imported["CP_BATTLEVIEW"]
    Sound.play_evasion
    ww = window_width
    if COOLIE::LOG::SHOW_COUNTER
      show_log
      back_to(1)
      draw_text(0, 0, ww - 24, line_height, sprintf(Vocab::CounterAttack, target.name), v_align)
      wait
      clear
    end
  end
# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║ Display Reflection                                                        ║
# ╚═══════════════════════════════════════════════════════════════════════════╝
  def display_reflection(target, item)
    target.do_pop(:reflect) if $imported["CP_BATTLEVIEW"]
    Sound.play_reflection
    ww = window_width
    if COOLIE::LOG::SHOW_REFLECT
      show_log
      back_to(1)
      draw_text(0, 0, ww - 24, line_height, sprintf(Vocab::MagicReflection, target.name), v_align)
      wait
      clear
    end
  end
# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║ Display Substitute                                                        ║
# ╚═══════════════════════════════════════════════════════════════════════════╝
  def display_substitute(substitute, target)
    target.do_pop(:sub) if $imported["CP_BATTLEVIEW"]
    if COOLIE::LOG::SHOW_SUB
      show_log
      ww = window_width
      back_to(1)
      draw_text(0, 0, ww - 24, line_height, sprintf(Vocab::Substitute, substitute.name, target.name), v_align)
      wait
      clear
    end
  end
# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║ Display Action Results                                                    ║
# ╚═══════════════════════════════════════════════════════════════════════════╝
  def display_action_results(target, item)
    if target.result.used
      target.pop_reset if $imported["CP_BATTLEVIEW"]
      display_critical(target, item)
      display_damage(target, item)
      display_affected_status(target, item)
      display_failure(target, item)
    end
  end
# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║ Display Failure                                                           ║
# ╚═══════════════════════════════════════════════════════════════════════════╝
  def display_failure(target, item)
    if target.result.hit? && !target.result.success
      target.do_pop(:fail) if $imported["CP_BATTLEVIEW"]
      ww = window_width
      if COOLIE::LOG::SHOW_FAILURE
        show_log
        back_to(1)
        draw_text(0, 0, ww - 24, line_height, sprintf(Vocab::ActionFailure, target.name), v_align)
        wait
        clear
      end
    end
  end
# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║ Display Critical Hit                                                      ║
# ╚═══════════════════════════════════════════════════════════════════════════╝
  def display_critical(target, item)
    if target.result.critical
      target.do_pop(:critical) if $imported["CP_BATTLEVIEW"]
      if $imported[:ve_damage_pop]
        color = [255, 255, 255, 192] if VE_CRT_FLASH
        $game_troop.screen.start_flash(Color.new(*color), 10) if VE_CRT_FLASH
      end
      text = target.actor? ? Vocab::CriticalToActor : Vocab::CriticalToEnemy
      ww = window_width
      show_log if COOLIE::LOG::SHOW_CRIT
      back_to(1) if COOLIE::LOG::SHOW_CRIT
      draw_text(0, 0, ww - 24, line_height, sprintf(text), v_align) if COOLIE::LOG::SHOW_CRIT
      wait if COOLIE::LOG::SHOW_CRIT
      clear if COOLIE::LOG::SHOW_CRIT
    end
  end
# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║ Display Miss                                                              ║
# ╚═══════════════════════════════════════════════════════════════════════════╝
  def display_miss(target, item)
    if !item || item.physical?
      fmt = target.actor? ? Vocab::ActorNoHit : Vocab::EnemyNoHit
      Sound.play_miss
    else
      fmt = Vocab::ActionFailure
    end
    ww = window_width
    target.do_pop(:miss) if $imported["CP_BATTLEVIEW"]
    if COOLIE::LOG::SHOW_MISS
      show_log
      back_to(1)
      draw_text(0, 0, ww - 24, line_height, sprintf(fmt, target.name), v_align)
      wait
      clear
    end
  end
# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║ Display Evasion                                                           ║
# ╚═══════════════════════════════════════════════════════════════════════════╝
  def display_evasion(target, item)
    if !item || item.physical?
      fmt = Vocab::Evasion
      Sound.play_evasion
    else
      fmt = Vocab::MagicEvasion
      Sound.play_magic_evasion
    end
    ww = window_width
    if COOLIE::LOG::SHOW_EVADE
      show_log
      back_to(1)
      draw_text(0, 0, ww - 24, line_height, sprintf(fmt, target.name), v_align)
      wait
      clear
    end
    target.do_pop(:evade) if $imported["CP_BATTLEVIEW"]
  end
# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║ Display HP Damage                                                         ║
# ╚═══════════════════════════════════════════════════════════════════════════╝
  def display_hp_damage(target, item)
    return if target.result.hp_damage == 0 && item && !item.damage.to_hp?
    target.pop_hp(target.result.hp_damage) if $imported["CP_BATTLEVIEW"]
    if target.result.hp_damage > 0 && target.result.hp_drain == 0
      target.perform_damage_effect
    end
    Sound.play_recovery if target.result.hp_damage < 0
    ww = window_width
    if COOLIE::LOG::SHOW_DAMAGE
      show_log
      back_to(1)
      draw_text(0, 0, ww - 24, line_height, target.result.hp_damage_text, v_align)
      wait
      clear
    end
  end
# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║ Display MP Damage                                                         ║
# ╚═══════════════════════════════════════════════════════════════════════════╝
  def display_mp_damage(target, item)
    return if target.dead? || target.result.mp_damage == 0
    target.pop_mp(target.result.mp_damage) if $imported["CP_BATTLEVIEW"]
    Sound.play_recovery if target.result.mp_damage < 0
    ww = window_width
    if COOLIE::LOG::SHOW_DAMAGE
      show_log
      back_to(1)
      draw_text(0, 0, ww - 24, line_height, target.result.mp_damage_text, v_align)
      wait
      clear
    end
  end
# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║ Display TP Damage                                                         ║
# ╚═══════════════════════════════════════════════════════════════════════════╝
  def display_tp_damage(target, item)
    return if target.dead? || target.result.tp_damage == 0
    target.pop_tp(target.result.tp_damage) if $imported["CP_BATTLEVIEW"]
    Sound.play_recovery if target.result.tp_damage < 0
    ww = window_width
    if COOLIE::LOG::SHOW_DAMAGE
      show_log
      back_to(1)
      draw_text(0, 0, ww - 24, line_height, target.result.tp_damage_text, v_align)
      wait
      clear
    end
  end
# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║ Display Current State                                                     ║
# ╚═══════════════════════════════════════════════════════════════════════════╝
  def display_current_state(subject)
    unless subject.most_important_state_text.empty?
       if COOLIE::LOG::SHOW_CURRENT_STATE
         ww = window_width
         show_log
         back_to(1)
         draw_text(0, 0, ww - 24, line_height, sprintf(subject.name + subject.most_important_state_text), v_align)
         wait
         clear
       end
    end
  end
# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║ Display Affected Status                                                   ║
# ╚═══════════════════════════════════════════════════════════════════════════╝
  def display_affected_status(target, item)
    if target.result.status_affected?
      display_changed_states(target)
      display_changed_buffs(target)
    end
  end
# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║ Display Auto-Affected Status                                              ║
# ╚═══════════════════════════════════════════════════════════════════════════╝
  def display_auto_affected_status(target)
    if target.result.status_affected?
      display_affected_status(target, nil)
      wait
    end
  end
# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║ Display Added State                                                       ║
# ╚═══════════════════════════════════════════════════════════════════════════╝
  def display_added_states(target)
    ww = window_width
    target.result.added_state_objects.each do |state|
      state_msg = target.actor? ? state.message1 : state.message2
      if $imported[:ve_animated_battle]
        # VE Animated Battle handles collapses a different way
      else
        target.perform_collapse_effect if state.id == target.death_state_id
      end
      next if state_msg.empty?
      if $imported["CP_BATTLEVIEW"]
        if state.pop_values[4]
          create_state_pop(target, state, :addstate)
        else
          target.do_pop(:addstate, state.name) unless state.name.empty?
        end
      end
      show_log if COOLIE::LOG::SHOW_ADDED_STATE
      back_to(1) if COOLIE::LOG::SHOW_ADDED_STATE
      draw_text(0, 0, ww - 24, line_height, sprintf(target.name + state_msg), v_align) if COOLIE::LOG::SHOW_ADDED_STATE
      wait if COOLIE::LOG::SHOW_ADDED_STATE
      clear if COOLIE::LOG::SHOW_ADDED_STATE
    end
    wait_for_effect
  end
# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║ Display Removed States                                                    ║
# ╚═══════════════════════════════════════════════════════════════════════════╝
  def display_removed_states(target)
    ww = window_width
    target.result.removed_state_objects.each do |state|
      next if state.message4.empty?
      if $imported["CP_BATTLEVIEW"]
        if state.pop_values[4]
          create_state_pop(target, state, :substate)
        else
          target.do_pop(:substate, state.name) unless state.name.empty?
        end
      end
      if COOLIE::LOG::SHOW_REMOVED_STATE
        show_log
        back_to(1)
        draw_text(0, 0, ww - 24, line_height, sprintf(target.name + state.message4), v_align)
        wait
        clear
      end
    end
  end
# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║ Display Changed States                                                    ║
# ╚═══════════════════════════════════════════════════════════════════════════╝
  def display_changed_states(target)
    display_added_states(target)
    display_removed_states(target)
  end
# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║ Display Buff/Debuff                                                       ║
# ╚═══════════════════════════════════════════════════════════════════════════╝
  def display_changed_buffs(target)
    if $imported["CP_BATTLEVIEW"]
      display_cp_buffs(target, target.result.added_buffs, Vocab::BuffAdd, :buff)
      display_cp_buffs(target, target.result.added_debuffs, Vocab::DebuffAdd, :debuff)
      display_cp_buffs(target, target.result.removed_buffs, Vocab::BuffRemove, :rebuff)
    else
      display_buffs(target, target.result.added_buffs, Vocab::BuffAdd)
      display_buffs(target, target.result.added_debuffs, Vocab::DebuffAdd)
      display_buffs(target, target.result.removed_buffs, Vocab::BuffRemove)
    end
  end
# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║ Display Buffs/Debuffs                                                     ║
# ╚═══════════════════════════════════════════════════════════════════════════╝
  def display_buffs(target, buffs, fmt)
    ww = window_width
    buffs.each do |param_id|
      show_log if COOLIE::LOG::SHOW_BUFFS
      back_to(1) if COOLIE::LOG::SHOW_BUFFS
      draw_text(0, 0, ww - 24, line_height, sprintf(fmt, target.name, Vocab::param(param_id)), v_align) if COOLIE::LOG::SHOW_BUFFS
      wait if COOLIE::LOG::SHOW_BUFFS
      clear if COOLIE::LOG::SHOW_BUFFS
    end
  end
# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║ Display CP Buffs/Debuffs                                                  ║
# ╚═══════════════════════════════════════════════════════════════════════════╝
  def display_cp_buffs(target, buffs, fmt, pop = nil)
    ww = window_width
    buffs.each do |param_id|
      target.do_pop(pop, Vocab::param(param_id))
      show_log if COOLIE::LOG::SHOW_BUFFS
      back_to(1) if COOLIE::LOG::SHOW_BUFFS
      draw_text(0, 0, ww - 24, line_height, sprintf(fmt, target.name, Vocab::param(param_id)), v_align) if COOLIE::LOG::SHOW_BUFFS
      wait if COOLIE::LOG::SHOW_BUFFS
      clear if COOLIE::LOG::SHOW_BUFFS
    end
  end
# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║ Get Window Left Position                                     [NEW METHOD] ║
# ╚═══════════════════════════════════════════════════════════════════════════╝
  def window_left_position
    return 0 + COOLIE::LOG::WINDOW_X_OFFSET
  end
# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║ Get Window Center Position                                   [NEW METHOD] ║
# ╚═══════════════════════════════════════════════════════════════════════════╝
  def window_center_position
    return (Graphics.width / 2 - window_width / 2) + COOLIE::LOG::WINDOW_X_OFFSET
  end
# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║ Get Window Right Position                                    [NEW METHOD] ║
# ╚═══════════════════════════════════════════════════════════════════════════╝
  def window_right_position
    return (Graphics.width - window_width) + COOLIE::LOG::WINDOW_X_OFFSET
  end
# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║ Draw Skill Name                                              [NEW METHOD] ║
# ╚═══════════════════════════════════════════════════════════════════════════╝
  def draw_skill_name(item, x, y, enabled = true, width = 172)
    return unless item
    draw_icon(item.icon_index, x, 0, enabled)
    change_color(normal_color, enabled)
    draw_text(x + 24, 0, width, line_height, item.message1)
  end
# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║ Draw Item Name                                               [NEW METHOD] ║
# ╚═══════════════════════════════════════════════════════════════════════════╝
  def draw_items_name(item, x, y, enabled = true, width = 172)
    return unless item
    draw_icon(item.icon_index, x, 0, enabled)
    change_color(normal_color, enabled)
    draw_text(x + 24, 0, width, line_height, item.name)
  end
# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║ Skill Name Width                                             [NEW METHOD] ║
# ╚═══════════════════════════════════════════════════════════════════════════╝
  def skill_name_width(item)
    size = text_size(item.message1).width
    size += 24 if item.icon_index > 0
    return size
  end
# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║ Item Name Width                                              [NEW METHOD] ║
# ╚═══════════════════════════════════════════════════════════════════════════╝
  def item_name_width(item)
    size = text_size(item.name).width
    size += 24 if item.icon_index > 0
    return size
  end
# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║ Vocabulary Alignment                                         [NEW METHOD] ║
# ╚═══════════════════════════════════════════════════════════════════════════╝
  def v_align
    return COOLIE::LOG::LOG_MESSAGE_ALIGN
  end
# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║ Custom Message Alignment                                     [NEW METHOD] ║
# ╚═══════════════════════════════════════════════════════════════════════════╝
  def c_align
    return COOLIE::LOG::CUSTOM_MESSAGE_ALIGN
  end
# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║ Display Skill/Item Use                                                    ║
# ╚═══════════════════════════════════════════════════════════════════════════╝
  def display_use_item(subject, item)
    # Handle Font and Windowskin processing
    if subject.is_a?(Game_Enemy)
      self.contents.font.name = COOLIE::LOG::FONT_ENEMY
      self.windowskin = Cache.system(COOLIE::LOG::WINDOWSKIN_ENEMY.to_s)
    else
      self.contents.font.name = COOLIE::LOG::FONT_ACTOR
      self.windowskin = Cache.system(COOLIE::LOG::WINDOWSKIN_ACTOR.to_s)
    end
    # Handle display of Window, Opacity, Icons and Text
    if item.is_a?(RPG::Skill) && !item.message1.empty? && item.message2.empty? # For Skills
    # Showing skill icon and name when the first "use" message contains text
      show_log
      ix = (window_width / 2 - skill_name_width(item) / 2) - 12 if item.icon_index > 0
      ix = (window_width / 2 - skill_name_width(item) / 2) - 36 if item.icon_index <= 0
      draw_skill_name(item, ix, y, enabled = true)
    elsif item.is_a?(RPG::Skill) && item.message1.empty? && !item.message2.empty? # For Skills
    # Showing custom string when the second "use" message contains text
      show_log
      draw_text(0, 0, window_width - 24, line_height, item.message2, c_align)
      wait
    elsif item.is_a?(RPG::Skill) && !item.message1.empty? && !item.message2.empty? # For Skills
    # Showing custom string when the first and second "use" message contains text
    # This is a failsafe to bypass the first "use" message
      show_log
      draw_text(0, 0, window_width - 24, line_height, item.message2, c_align)
      wait
    elsif item.is_a?(RPG::Skill) && item.message1.empty? && item.message2.empty? # For Skills
    # Showing nothing when both "use" message fields contain no text
      wait
      clear
    elsif item.is_a?(RPG::Item) # For Items
    # Showing item icon and name when using an item in battle
      show_log
      ix = (window_width / 2 - item_name_width(item) / 2) - 12 if item.icon_index > 0
      ix = (window_width / 2 - item_name_width(item) / 2) - 36 if item.icon_index <= 0
      draw_items_name(item, ix, y, enabled = true)
    else # Failsafe
      show_log
      draw_text(0, 0, window_width - 24, line_height, item.name)
      wait
    end
    reset_font_settings
  end
end
# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║ End of Script                                                             ║
# ╚═══════════════════════════════════════════════════════════════════════════╝
end