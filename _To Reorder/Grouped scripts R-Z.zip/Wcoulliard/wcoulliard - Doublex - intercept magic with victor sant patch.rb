  #----------------------------------------------------------------------------|
  #  Alias method: use_item                                                    |
  #----------------------------------------------------------------------------| 
  alias use_item_intercept_magic use_item
  def use_item
    # This part is rewritten by this script to intercept magic when conditions are met
    item = @subject.current_action.item
    return use_item_intercept_magic if !item.is_a?(RPG::Skill) || item.intercept_tier <= 0
    interceptor = @subject.opponents_unit.intercept_magic(@subject, item)
    interceptor = @subject.friends_unit.intercept_magic(@subject, item) if !interceptor
    return use_item_intercept_magic if !interceptor
    @log_window.display_use_item(@subject, item)
    @subject.use_item(item)
    #WC - VE Animated Battle Compatibility
    @subject.poses.action_pose(item)
    #WC - VE Animated Battle Compatibility
    refresh_status
    intercept_magic(interceptor, item)
    #
  end # use_item