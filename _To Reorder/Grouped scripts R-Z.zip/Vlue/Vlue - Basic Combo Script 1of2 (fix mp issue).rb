=begin
An actor has a healing skill which can be used outside of battle. 
When it is used outside battle, the heal takes effect, 
but the MP is not removed, meaning that the player has a totally free heal. 
In battle is fine, the MP is subtracted in the normal way.

This is part 1/2 of the fix.
=end
class Game_Battler
  alias_method :use_item_original, :use_item
end 