# Ignore Input.
# Version 1.0.0
# 03/05/15 - DD/MM/YY
# www.rpgmakersource.com
# forums.rpgmakersource.com
## Use Input.ignore = true/false in a Script Event Command.
# Free to use on free or commercial games. Don't remove the original header.
class << Input 
attr_accessor :ignore 
[:trigger?, :press?, :repeat?, :dir4, :dir8].each 
{ |name| class_eval %Q(alias_method(:ignore_original_#{name}, :#{name}) 
def #{name}(*args) 
@ignore ? #{name[/\d/].nil? ? false : 0} 
:ignore_original_#{name}(*args) end)} 
end