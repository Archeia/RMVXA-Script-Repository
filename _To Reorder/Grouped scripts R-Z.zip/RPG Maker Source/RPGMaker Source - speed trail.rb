%Q(
╔════╦═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╦═════╗
║ ╔══╩═══╩═══╩═══╩═══╩═══╩═══╩═══╩═══╩═══╩═══╩═══╩═══╩═══╩═══╩═══╩═══╩═══╩═══╗ ║
╠─╣                               Speed Trail                                ╠─╣
╠─╣                           by RPG Maker Source.                           ╠─╣
╠─╣                          www.rpgmakersource.com                          ╠─╣
║ ╚══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╝ ║
╠════╩═╤═╩═╤═╩═╤═╩═╤═╩═╤═╩═╤═╩═╤═╩═╤═╩═╤═╩═╤═╩═╤═╩═╤═╩═╤═╩═╤═╩═╤═╩═╤═╩═╤═╩═════╣
║ ┌────┴───┴───┴───┴───┴───┴───┴───┴───┴───┴───┴───┴───┴───┴───┴───┴───┴─────┐ ║
╠─┤ Version 1.0.3                   02/12/14                        DD/MM/YY ├─╣
║ └────┬───┬───┬───┬───┬───┬───┬───┬───┬───┬───┬───┬───┬───┬───┬───┬───┬─────┘ ║
╠══════╧═══╧═══╧═══╧═══╧═══╧═══╧═══╧═══╧═══╧═══╧═══╧═══╧═══╧═══╧═══╧═══╧═══════╣
║                                                                              ║
║               This work is protected by the following license:               ║
║     ╔══════════════════════════════════════════════════════════════════╗     ║
║     │                                                                  │     ║
║     │ Copyright © 2014 Maker Systems.                                  │     ║
║     │                                                                  │     ║
║     │ This software is provided 'as-is', without any kind of           │     ║
║     │ warranty. Under no circumstances will the author be held         │     ║
║     │ liable for any damages arising from the use of this software.    │     ║
║     │                                                                  │     ║
║     │ Permission is granted to anyone to use this software on their    │     ║
║     │ free or commercial games made with a legal copy of RPG Maker     │     ║
║     │ VX Ace, as long as Maker Systems - RPG Maker Source is           │     ║
║     │ credited within the game.                                        │     ║
║     │                                                                  │     ║
║     │ Selling this code or any portions of it 'as-is' or as part of    │     ║
║     │ another code, is not allowed.                                    │     ║
║     │                                                                  │     ║
║     │ The original header, which includes this copyright notice,       │     ║
║     │ must not be edited or removed from any verbatim copy of the      │     ║
║     │ sotware nor from any edited version.                             │     ║
║     │                                                                  │     ║
║     ╚══════════════════════════════════════════════════════════════════╝     ║
║                                                                              ║
║                                                                              ║
╠══════════════════════════════════════════════════════════════════════════════╣
║ 1. VERSION HISTORY.                                                        ▼ ║
╠══════════════════════════════════════════════════════════════════════════════╣
║                                                                              ║
║ • Version 1.0.0, 29/11/14 - (DD/MM/YY).                                      ║
║                                                                              ║
║ • Version 1.0.1, 29/11/14 - (DD/MM/YY).                                      ║
║                                                                              ║
║ • Version 1.0.2, 30/11/14 - (DD/MM/YY).                                      ║
║                                                                              ║
║ • Version 1.0.3, 02/12/14 - (DD/MM/YY).                                      ║
║                                                                              ║
╠══════════════════════════════════════════════════════════════════════════════╣
╠══════════════════════════════════════════════════════════════════════════════╣
║ 2. USER MANUAL.                                                            ▼ ║
╠══════════════════════════════════════════════════════════════════════════════╣
║                                                                              ║
║ ┌──────────────────────────────────────────────────────────────────────────┐ ║
║ │ ■ Introduction.                                                          │ ║
║ └┬┬┬┬──────────────────────────────────────────────────────────────────┬┬┬┬┘ ║
║                                                                              ║
║  Hello there! This script is "plug and play", you can simply insert it       ║
║  into your project and it will perform flawlessly.                           ║
║                                                                              ║
║  This script can create awesome looking effects for characters in your       ║
║  game (both for Events and player characters). It can be used for many       ║
║  situations, to convey the idea of speed, power effects, skills, slow        ║
║  motion camera, ghosts, and even mitical beings. Your imagination is the     ║
║  limit.                                                                      ║
║                                                                              ║
║  There are a lot of different looking effects that are possible by just      ║
║  changing some parameter combinations when you call for the effect, so be    ║
║  sure to check the Feature Documentation section of this manual to           ║
║  experience the full power of the system.                                    ║
║                                                                              ║
║  We hope you enjoy it.                                                       ║
║                                                                              ║
║  Thanks for choosing our products.                                           ║
║                                                                              ║
║ ┌──────────────────────────────────────────────────────────────────────────┐ ║
║ │ ■ Configuration.                                                         │ ║
║ └┬┬┬┬──────────────────────────────────────────────────────────────────┬┬┬┬┘ ║
║                                                                              ║
║  The effect can be set to be performed automatically when the player         ║
║  dashes, and you can choose how it will look by changing the same            ║
║  parameters that you can use when you call for the effect to be performed    ║
║  on an event.                                                                ║
║                                                                              ║
║  The parameters are explained in the Feature Documentation section, to       ║
║  change certain parameter for the Player default (when dashing), click       ║
║  anywhere in the script editor and select "Find" or (CTRL + F), search       ║
║  for:                                                                        ║
║                                                                              ║
║  Player_Dash_ + parameter name. For example:                                 ║
║                                                                              ║
║  "PLAYER_DASH_RHYTHM" (without quotation marks)                              ║
║                                                                              ║
║  You will see something like "PLAYER_DASH_RHYTHM = 4"                        ║
║                                                                              ║
║  Change the number after the equality sign to any possible parameter         ║
║  value, the possible values are decribed in the next section (Feature        ║
║  Documentation).                                                             ║
║                                                                              ║
║ ┌──────────────────────────────────────────────────────────────────────────┐ ║
║ │ ■ Feature Documentation.                                                 │ ║
║ └┬┬┬┬──────────────────────────────────────────────────────────────────┬┬┬┬┘ ║
║                                                                              ║
║  There are two script calls documented in the following section, one is      ║
║  for starting the effect on a certain character and the other one is for     ║
║  ending the effect on a certain character.                                   ║
║                                                                              ║
║  ┌─────────────────────────────────────────────────────────────────────┐     ║
║  │ ms_start_speed_trail(id, rhythm, delay, blend_type, opacity, [...]) │     ║
║  ├─────────────────────────────────────────────────────────────────────┴──┐  ║
║  │ This command tells the system to start performing the effect on        │  ║
║  │ certain character.                                                     │  ║
║  │                                                                        │  ║
║  │ There are many properties that you can combine to make unique, cool    │  ║
║  │ effects for your scenes.                                               │  ║
║  │ There are 5 necessary parameters, this are "id", "rhythm", "delay",    │  ║
║  │ "blend_type" and "opacity". Any parameter after those is optional, but │  ║
║  │ should you include more, they need to be written in the following      │  ║
║  │ order:                                                                 │  ║
║  │                                                                        │  ║
║  │ ([...], color, wave_amp, wave_length, wave_speed, blur_level, limit)   │  ║
║  │                                                                        │  ║
║  │ If you want to include a parameter that comes after one that you       │  ║
║  │ don't, make 'nil' (without quotation marks) the value for those you    │  ║
║  │ don't want (to keep the order).                                        │  ║
║  │                                                                        │  ║
║  │ • What is "id"?                                                        │  ║
║  │ id is a number representing the character, 0 is for player, and 1 and  │  ║
║  │ up for event id.                                                       │  ║
║  │                                                                        │  ║
║  │ • What is "rhytm"?                                                     │  ║
║  │ Interval in frames of each Sprite appearance. Lower numbers result in  │  ║
║  │ a more continuous effect while bigger number makes each "blueprint"    │  ║
║  │ Sprite appear more far appart.                                         │  ║
║  │                                                                        │  ║
║  │ Use any number equal or greater than 0.                                │  ║
║  │                                                                        │  ║
║  │ • What is "delay"?                                                     │  ║
║  │ Number of frames that each Sprite will remain visible.                 │  ║
║  │                                                                        │  ║
║  │ Use any number equal or greater than 1.                                │  ║
║  │                                                                        │  ║
║  │ • What is "blendType"?                                                 │  ║
║  │ Blend mode for the Sprites used in the effect.                         │  ║
║  │                                                                        │  ║
║  │ Use 0 for normal, 1 for addition, and 2 for subtraction.               │  ║
║  │                                                                        │  ║
║  │ • What is "opacity"?                                                   │  ║
║  │ This represents the starting opacity for each Sprite.                  │  ║
║  │                                                                        │  ║
║  │ Use either a number between 0.0 and 1.0 to represent the percentage    │  ║
║  │ (0.9 being 90%, and so on), or a number from 0 to 255 (255 being 100%  │  ║
║  │ and so on).                                                            │  ║
║  │                                                                        │  ║
║  │ • What is "color"?                                                     │  ║
║  │ Color represents the color of the trail, in case you want the effect   │  ║
║  │ to have a different color than that of the normal character sprite.    │  ║
║  │                                                                        │  ║
║  │ Example: '0 255 0'                                                     │  ║
║  │                                                                        │  ║
║  │ You might be asking yourself "What is that supposed to mean?" but      │  ║
║  │ worry not, my friend, because it is actually very simple:              │  ║
║  │ The single quotes are used to encapsulate the color information. You   │  ║
║  │ can put either RGBA values in there or HEX values.                     │  ║
║  │ If you want to use RGBA colors, simple leave a space after each color  │  ║
║  │ value, like this:                                                      │  ║
║  │                                                                        │  ║
║  │ BACK_COLOR = 'RED GREEN BLUE ALPHA'                                    │  ║
║  │                                                                        │  ║
║  │ The values for RED, GREEN, BLUE, and ALPHA must be numbers between 0   │  ║
║  │ and 255.                                                               │  ║
║  │                                                                        │  ║
║  │ ALPHA is the opacity of the color.                                     │  ║
║  │                                                                        │  ║
║  │ On the other hand, if you want to use HEX codes, simply put a # (hash  │  ║
║  │ character) before it, like this:                                       │  ║
║  │                                                                        │  ║
║  │ BACK_COLOR = '#0000009B'                                               │  ║
║  │                                                                        │  ║
║  │ • What is "wave_amp"?                                                  │  ║
║  │ This represents the amplitude of the wave effect and it is not         │  ║
║  │ necessary for you to include it. It is deactivated by default. For     │  ║
║  │ more information, check RPG Maker Ace's help file, Sprite section.     │  ║
║  │                                                                        │  ║
║  │ • What is "wave_length"?                                               │  ║
║  │ This represents the wave frequency, it is not necessary for you to     │  ║
║  │ include it unless you want the system to perform a wave effect for     │  ║
║  │ this Speed Trail.                                                      │  ║
║  │                                                                        │  ║
║  │ • What is "wave_speed"?                                                │  ║
║  │ This represents the speed of the wave effect, it is not necessary for  │  ║
║  │ you to include it and the default is 360.                              │  ║
║  │                                                                        │  ║
║  │ • What is "blur_level"?                                                │  ║
║  │ This represents the strength of the blur effect in each Sprite, it is  │  ║
║  │ not necessary for you to include it and the default is nil             │  ║
║  │ (deactivated). Use either nil for no blur, or any number equal or      │  ║
║  │ greater than 1. Keep in mind that blur effects are CPU intensive, the  │  ║
║  │ bigger the strength (blur level), the more intensive.                  │  ║
║  │                                                                        │  ║
║  │ • What is "size_limit"?                                                │  ║
║  │ This represents the maximum number of Sprites that the effect can use  │  ║
║  │ for each character simultaneously.                                     │  ║
║  │ So for example, if you set the size limit of the Player to 22 and      │  ║
║  │ either the rhythm is too short or the spawn delay is too long, causing │  ║
║  │ many Sprites to appear on screen at the same time, the Sprite creation │  ║
║  │ will be capped at 22.                                                  │  ║
║  │ This is to ensure the good performance of your game.                   │  ║
║  │                                                                        │  ║
║  │ Any numer equal or greater than 1. If you don't include this           │  ║
║  │ parameter, the default SIZE_LIMIT will be used.                        │  ║
║  │                                                                        │  ║
║  └────────────────────────────────────────────────────────────────────────┘  ║
║  ┌─────────────────────────┐                                                 ║
║  │ ms_stop_speed_trail(id) │                                                 ║
║  ├─────────────────────────┴──────────────────────────────────────────────┐  ║
║  │ This command tells the system to stop performing the effect on certain │  ║
║  │ character.                                                             │  ║
║  │                                                                        │  ║
║  │ • What is "id"?                                                        │  ║
║  │ id is a number representing the character, 0 is for player, and 1 and  │  ║
║  │ up for event id.                                                       │  ║
║  │                                                                        │  ║
║  └────────────────────────────────────────────────────────────────────────┘  ║
║                                                                              ║
║  TL;DR:                                                                      ║
║  • The effect can be automatic each time the player dashes by pressing       ║
║    SHIFT. To customize the look of that effect, go to the configuration      ║
║    part of the script.                                                       ║
║    To turn the automatic effect off, set PLAYER_DASH_AUTOST to false.        ║
║  • You can activate the effect, and deactivate it for any character by       ║
║    using ms_start_speed_trail(the arguments) and ms_stop_speed_trail(id)     ║
║  • You're awesome.                                                           ║
║                                                                              ║
╠══════════════════════════════════════════════════════════════════════════════╣
╠══════════════════════════════════════════════════════════════════════════════╣
║ 3. NOTES.                                                                  ▼ ║
╠══════════════════════════════════════════════════════════════════════════════╣
║                                                                              ║
║  Have fun and enjoy!                                                         ║
║                                                                              ║
╠══════════════════════════════════════════════════════════════════════════════╣
╠══════════════════════════════════════════════════════════════════════════════╣
║ 4. CONTACT.                                                                ▼ ║
╠══════════════════════════════════════════════════════════════════════════════╣
║                                                                              ║
║  Keep in touch with us and be the first to know about new releases:          ║
║                                                                              ║
║  www.rpgmakersource.com                                                      ║
║  www.facebook.com/RPGMakerSource                                             ║
║  www.twitter.com/RPGMakerSource                                              ║
║  www.youtube.com/user/RPGMakerSource                                         ║
║                                                                              ║
║  Get involved! Have an idea for a system? Let us know.                       ║
║                                                                              ║
║  Spread the word and help us reach more people so we can continue creating   ║
║  awesome resources for you!                                                  ║
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝)

#==============================================================================
# ** Maker Systems
#------------------------------------------------------------------------------
#  Module for our scripts.
#==============================================================================

module MakerSystems
  
  #============================================================================
  # ** Speed Trail                                                        [NEW]
  #----------------------------------------------------------------------------
  #  Module for some configurable values in Speed Trail.
  #============================================================================
  
  module SpeedTrail
    
    #------------------------------------------------------------------------
    # * Default Speed Trail for Player Dashing.                         [OPT]
    #------------------------------------------------------------------------
    PLAYER_DASH_AUTOST      = true
    #------------------------------------------------------------------------
    # * Rhythm for Player Dashing.                                      [OPT]
    #------------------------------------------------------------------------
    PLAYER_DASH_RHYTHM      = 2
    #------------------------------------------------------------------------
    # * Delay for Player Dashing.                                       [OPT]
    #------------------------------------------------------------------------
    PLAYER_DASH_SPAWNDELAY  = 15
    #------------------------------------------------------------------------
    # * Blend Type for Player Dashing.                                  [OPT]
    #------------------------------------------------------------------------
    PLAYER_DASH_BLENDTYPE   = 0
    #------------------------------------------------------------------------
    # * Opacity for Player Dashing.                                     [OPT]
    #------------------------------------------------------------------------
    PLAYER_DASH_OPACITY     = 0.9
    #------------------------------------------------------------------------
    # * Color for Player Dashing.                                     [OPT]
    #------------------------------------------------------------------------
    PLAYER_DASH_COLOR       = nil
    #------------------------------------------------------------------------
    # * Wave Amp for Player Dashing.                                    [OPT]
    #------------------------------------------------------------------------
    PLAYER_DASH_WAVE_AMP    = nil
    #------------------------------------------------------------------------
    # * Wave Length for Player Dashing.                                 [OPT]
    #------------------------------------------------------------------------
    PLAYER_DASH_WAVE_LENGTH = nil
    #------------------------------------------------------------------------
    # * Wave Speed for Player Dashing.                                  [OPT]
    #------------------------------------------------------------------------
    PLAYER_DASH_WAVE_SPEED  = nil
    #------------------------------------------------------------------------
    # * Blur Level for Player Dashing.                                  [OPT]
    #------------------------------------------------------------------------
    PLAYER_DASH_BLUR_LEVEL  = 1
    #------------------------------------------------------------------------
    # * Trail Size Limit for Player Dashing.                            [OPT]
    #------------------------------------------------------------------------
    PLAYER_DASH_SIZE_LIMIT  = 22
    #------------------------------------------------------------------------
    # * Default Limit of Speed Trails (Sprites) for each Character.     [OPT]
    #------------------------------------------------------------------------
    SIZE_LIMIT              = 10
    
  end
  
end

#==============================================================================
# ** Game_CharacterBase                                                   [MOD]
#------------------------------------------------------------------------------
#  Adds some variables to handle the effect.
#==============================================================================

class Game_CharacterBase
  
  #--------------------------------------------------------------------------
  # * Public Instance Variables.                                        [NEW]
  #--------------------------------------------------------------------------
  attr_accessor :ms_speed_trail_enable, :ms_speed_trail_rhythm,
                :ms_speed_trail_delay, :ms_speed_trail_blend_type,
                :ms_speed_trail_opacity, :ms_speed_trail_wave_amp,
                :ms_speed_trail_wave_length, :ms_speed_trail_wave_speed,
                :ms_speed_trail_blur_level, :ms_speed_trail_limit,
                :ms_speed_trail_color
    
end

#==============================================================================
# ** Game_Player                                                          [MOD]
#------------------------------------------------------------------------------
#  Alias to Update. Adds method that handles the effect while player runs.
#==============================================================================

class Game_Player < Game_Character
  
  #--------------------------------------------------------------------------
  # * Public Instance Variables.                                        [NEW]
  #--------------------------------------------------------------------------
  attr_accessor :ms_speed_trail_previous
  #--------------------------------------------------------------------------
  # * Alias Update.                                                     [NEW]
  #--------------------------------------------------------------------------
  alias_method(:ms_speed_trail_original_update, :update)
  #--------------------------------------------------------------------------
  # * Update.                                                           [MOD]
  #--------------------------------------------------------------------------
  def update
    # Original method.
    ms_speed_trail_original_update
    # If the effect is automatically active for player dashing.
    if MakerSystems::SpeedTrail::PLAYER_DASH_AUTOST
      # Player dashing?
      if dash?
        if @ms_speed_trail_enable && !@ms_speed_trail_enable_from_dashing
          @ms_speed_trail_previous ||= [@ms_speed_trail_rhythm,
          @ms_speed_trail_delay, @ms_speed_trail_blend_type,
          @ms_speed_trail_opacity, @ms_speed_trail_color,
          @ms_speed_trail_wave_amp, @ms_speed_trail_wave_length,
          @ms_speed_trail_wave_speed, @ms_speed_trail_blur_level,
          @ms_speed_trail_limit]
        end
        # Shortcut to Speed Trail module.
        ms_speed_trail = MakerSystems::SpeedTrail
        # Set up the effect using Player values.
        @ms_speed_trail_rhythm      = ms_speed_trail::PLAYER_DASH_RHYTHM
        @ms_speed_trail_delay       = ms_speed_trail::PLAYER_DASH_SPAWNDELAY
        @ms_speed_trail_blend_type  = ms_speed_trail::PLAYER_DASH_BLENDTYPE
        @ms_speed_trail_opacity     = ms_speed_trail::PLAYER_DASH_OPACITY
        @ms_speed_trail_color       = ms_speed_trail::PLAYER_DASH_COLOR
        @ms_speed_trail_wave_amp    = ms_speed_trail::PLAYER_DASH_WAVE_AMP
        @ms_speed_trail_wave_length = ms_speed_trail::PLAYER_DASH_WAVE_LENGTH
        @ms_speed_trail_wave_speed  = ms_speed_trail::PLAYER_DASH_WAVE_SPEED
        @ms_speed_trail_blur_level  = ms_speed_trail::PLAYER_DASH_BLUR_LEVEL
        @ms_speed_trail_limit       = ms_speed_trail::PLAYER_DASH_SIZE_LIMIT
        # Effect ready flag.
        @ms_speed_trail_enable = true
        @ms_speed_trail_enable_from_dashing = true
      else
        if @ms_speed_trail_enable_from_dashing
          @ms_speed_trail_enable_from_dashing = nil
          if @ms_speed_trail_previous
            # Restores previous effect.
            @ms_speed_trail_rhythm, @ms_speed_trail_delay,
            @ms_speed_trail_blend_type, @ms_speed_trail_opacity,
            @ms_speed_trail_color, @ms_speed_trail_wave_amp,
            @ms_speed_trail_wave_length, @ms_speed_trail_wave_speed,
            @ms_speed_trail_blur_level, @ms_speed_trail_limit =
            *@ms_speed_trail_previous
            @ms_speed_trail_previous = nil
          else
            # Cancels the effect and clears its information.
            @ms_speed_trail_enable = nil
            @ms_speed_trail_delay = @ms_speed_trail_rhythm =
            @ms_speed_trail_blend_type = @ms_speed_trail_opacity =
            @ms_speed_trail_color = @ms_speed_trail_wave_amp = 
            @ms_speed_trail_wave_length = @ms_speed_trail_wave_speed =
            @ms_speed_trail_blur_level = @ms_speed_trail_limit = nil
          end
        end
      end
    end
  end

end

#==============================================================================
# ** MS_SpeedTrail_Sprite                                                 [NEW]
#------------------------------------------------------------------------------
#  This class is used to display the effect.
#==============================================================================

class MS_SpeedTrail_Sprite < Sprite
  
  #--------------------------------------------------------------------------
  # * Initialize.
  #--------------------------------------------------------------------------
  def initialize(parent)
    # Superclass method.
    super(parent.viewport)
    # Get parent character.
    character = parent.character
    # Get parent Sprite rect.
    rect  = parent.src_rect
    # Get parent character shift_y.
    shift = character.shift_y
    # Get parent character jump_height.
    jump  = character.jump_height
    # Set up target X & target Y.
    @target_x = $game_map.display_x * 32 + parent.x
    @target_y = $game_map.display_y * 32 + parent.y
    # Set up Offset X & Offset Y.
    self.ox = parent.ox
    self.oy = parent.oy
    # Opacity value.
    transparency = character.ms_speed_trail_opacity
    # If transparency value represents a percentage.
    if transparency < 1.0
      # Set opacity according to percentage given.
      @target_opacity = parent.opacity * transparency
    else
      # Set opacity according to desired value.
      @target_opacity = transparency
    end
    # Step value.
    @target_step = @target_opacity.to_f / character.ms_speed_trail_delay.to_f
    # Z order.
    self.z = character.direction == 8 ? parent.z + 1 : parent.z - 1
    # Set up X & Y position.
    self.x = -$game_map.display_x * 32 + @target_x
    self.y = -$game_map.display_y * 32 + @target_y
    # Set up desired blend type.
    self.blend_type = parent.character.ms_speed_trail_blend_type
    # Set up opacity.
    self.opacity = @target_opacity
    # Set up bitmap for correct character pose.
    self.bitmap = Bitmap.new(rect.width, rect.height)
    self.bitmap.blt(0, 0, parent.bitmap, rect)
    # Apply blur if needed.
    if character.ms_speed_trail_blur_level
      character.ms_speed_trail_blur_level.times { self.bitmap.blur }
    end
    # Set up wave effect if needed.
    if character.ms_speed_trail_wave_amp
      self.wave_amp    = character.ms_speed_trail_wave_amp
      self.wave_length = character.ms_speed_trail_wave_length
      self.wave_speed  = character.ms_speed_trail_wave_speed
    end
    # Set up Sprite color if needed.
    if parent.character.ms_speed_trail_color
      self.color = character.ms_speed_trail_color
    end
  end
  #--------------------------------------------------------------------------
  # * Update
  #--------------------------------------------------------------------------
  def update
    # Superclass method.
    super
    # Updates X & Y position.
    self.x = -$game_map.display_x * 32 + @target_x
    self.y = -$game_map.display_y * 32 + @target_y
    # Updates opacity and returns vital signs.
    self.opacity -= @target_step
    self.opacity > 0
  end
  
end

#==============================================================================
# ** Sprite_Character                                                     [MOD]
#------------------------------------------------------------------------------
#  Alias to Update. Adds method to handle the main effect.
#==============================================================================

class Sprite_Character < Sprite_Base
  
  #--------------------------------------------------------------------------
  # * Alias Update.                                                     [NEW]
  #--------------------------------------------------------------------------
  alias_method(:ms_speed_trail_original_update, :update)
  #--------------------------------------------------------------------------
  # * Update.                                                           [MOD]
  #--------------------------------------------------------------------------
  def update
    # Original method.
    ms_speed_trail_original_update
    # If child sprites exists.
    if @ms_speed_trail_sprites
      # Iterate through each Speed Trail Sprite.
      @ms_speed_trail_sprites.each do |sprite|
        # Update and check vitality.
        unless sprite.update
          # Dispose Bitmap and Sprite when dead.
          sprite.bitmap.dispose
          sprite.dispose
          # Remove from array.
          @ms_speed_trail_sprites.delete(sprite)
        end
      end
    end
    # If the effect is enabled.
    if @character.ms_speed_trail_enable
      # Unless there is already a Sprite container.
      unless @ms_speed_trail_sprites
        # Create Speed Trail if moving.
        if @character.moving?
          @ms_speed_trail_sprites = [MS_SpeedTrail_Sprite.new(self)] 
        end
        # Save this position for future reference.
        @ms_speed_trail_last_x = @character.real_x
        @ms_speed_trail_last_y = @character.real_y
        # Set up spawn rate.
        @ms_speed_trail_spawn_rate = @character.ms_speed_trail_rhythm
      end
      # Update rate.
      @ms_speed_trail_spawn_rate -= 1
      # Correct rate if needed.
      if @ms_speed_trail_spawn_rate < 0
        @ms_speed_trail_spawn_rate = 0 
      end
      # If time is up.
      if @ms_speed_trail_spawn_rate == 0
        # If character moved.
        if @character.real_x != @ms_speed_trail_last_x ||
           @character.real_y != @ms_speed_trail_last_y
          # Custom limit?
          if @character.ms_speed_trail_limit
            limit = @character.ms_speed_trail_limit
          else
            # Default limit.
            limit = MakerSystems::SpeedTrail::SIZE_LIMIT
          end
          # If trail is smaller than limit.
          if @ms_speed_trail_sprites.size < limit
            # Create Speed Trail if visible.
            if self.visible
              @ms_speed_trail_sprites << MS_SpeedTrail_Sprite.new(self) 
            end
          end
          # Save this position for future reference.
          @ms_speed_trail_last_x = @character.real_x
          @ms_speed_trail_last_y = @character.real_y
          # Reset spawn rate.
          @ms_speed_trail_spawn_rate = @character.ms_speed_trail_rhythm
        end
      end
    else
      # Speed Trail container?
      if @ms_speed_trail_sprites && @ms_speed_trail_sprites.empty?
        # Clear container.
        @ms_speed_trail_sprites.clear
        # Clear used variables.
        @ms_speed_trail_sprites = @ms_speed_trail_last_x =
        @ms_speed_trail_last_y = @ms_speed_trail_spawn_rate = nil
      end
    end
  end
  #--------------------------------------------------------------------------
  # * Alias Dispose.                                                    [NEW]
  #--------------------------------------------------------------------------
  alias_method(:ms_speed_trail_original_dispose, :dispose)
  #--------------------------------------------------------------------------
  # * Dispose.                                                          [MOD]
  #--------------------------------------------------------------------------
  def dispose
    # Original method.
    ms_speed_trail_original_dispose
    # Dispose existing trail Sprites.
    if @ms_speed_trail_sprites
      @ms_speed_trail_sprites.each do |sprite| 
        sprite.bitmap.dispose
        sprite.dispose
      end
    end
  end
  
end

  #--------------------------------------------------------------------------
  # * Start Speed Trail.                                                [NEW]
  #--------------------------------------------------------------------------
  def ms_start_speed_trail(id, rhythm, delay, blend_type = 1, opacity = 0.9,
                           color = nil, wave_amp = nil, wave_length = nil,
                           wave_speed = nil, ms_speed_trail_blur_level = nil,
                           limit = nil)
    # Get character based on id.
    character = id == 0 ? $game_player : $game_map.events[id]
    # Color object generation.
    if color
      if color.include?('#')
        color = color.delete!('#').scan(/../).map { |c| c.to_i(16) }
      else
        color = color.split(' ').map { |c| c.to_i }
      end
      color = Color.new(*color)
    end
    # Default value correction.
    blend_type = 1   unless blend_type
    opacity    = 0.9 unless opacity
    # Set up basic effect information.
    character.ms_speed_trail_rhythm      = rhythm
    character.ms_speed_trail_delay       = delay
    character.ms_speed_trail_blend_type  = blend_type
    character.ms_speed_trail_opacity     = opacity
    character.ms_speed_trail_wave_amp    = wave_amp
    character.ms_speed_trail_wave_length = wave_length
    character.ms_speed_trail_wave_speed  = wave_speed
    character.ms_speed_trail_blur_level  = ms_speed_trail_blur_level
    character.ms_speed_trail_limit       = limit
    character.ms_speed_trail_color       = color
    # Effect enabled.
    character.ms_speed_trail_enable = true
  end
  #--------------------------------------------------------------------------
  # * Stop Speed Trail.                                                 [NEW]
  #--------------------------------------------------------------------------
  def ms_stop_speed_trail(id)
    # Get character based on id.
    character = id == 0 ? $game_player : $game_map.events[id]
    # Effect disabled.
    character.ms_speed_trail_enable = false
    # Clears effect information.
    character.ms_speed_trail_rhythm = character.ms_speed_trail_delay =
    character.ms_speed_trail_blend_type = character.ms_speed_trail_opacity =
    character.ms_speed_trail_wave_amp = character.ms_speed_trail_wave_length =
    character.ms_speed_trail_wave_speed = character.ms_speed_trail_blur_level =
    character.ms_speed_trail_limit = character.ms_speed_trail_color = nil
  end