#Compatibility patch for Plane script and Yanfly's Enemy HP bars.
#written by Source 24 Dec 2014
class Plane < Sprite
  def bitmap
    super
 end
end
class Enemy_HP_Gauge_Viewport < Viewport
  def create_gauge_sprites
    @sprite = Plane.new(self)
    dw = self.rect.width * 2
    bit = Bitmap.new(dw, self.rect.height)
    case @type
    when :back
      colour1 = Colour.text_colour(@battler.enemy.back_gauge_colour)
      colour2 = Colour.text_colour(@battler.enemy.back_gauge_colour)
    when :hp
      colour1 = Colour.text_colour(@battler.enemy.hp_gauge_colour1)
      colour2 = Colour.text_colour(@battler.enemy.hp_gauge_colour2)
    end
    dx = 0
    dy = 0
    dw = self.rect.width
    dh = self.rect.height
    @gauge_width = target_gauge_width
    bit.gradient_fill_rect(dx, dy, dw, dh, colour1, colour2)
    bit.gradient_fill_rect(dw, dy, dw, dh, colour2, colour1)
    @sprite.bitmap = bit
    @visible_counter = 0
  end
end