%Q(
╔════╦═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╦═════╗
║ ╔══╩═══╩═══╩═══╩═══╩═══╩═══╩═══╩═══╩═══╩═══╩═══╩═══╩═══╩═══╩═══╩═══╩═══╩═══╗ ║
╠─╣                              Cutscene Skip                               ╠─╣
╠─╣                           by RPG Maker Source.                           ╠─╣
╠─╣                          www.rpgmakersource.com                          ╠─╣
║ ╚══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╦═══╝ ║
╠════╩═╤═╩═╤═╩═╤═╩═╤═╩═╤═╩═╤═╩═╤═╩═╤═╩═╤═╩═╤═╩═╤═╩═╤═╩═╤═╩═╤═╩═╤═╩═╤═╩═╤═╩═════╣
║ ┌────┴───┴───┴───┴───┴───┴───┴───┴───┴───┴───┴───┴───┴───┴───┴───┴───┴─────┐ ║
╠─┤ Version 1.0.0                   18/03/15                        DD/MM/YY ├─╣
║ └────┬───┬───┬───┬───┬───┬───┬───┬───┬───┬───┬───┬───┬───┬───┬───┬───┬─────┘ ║
╠══════╧═══╧═══╧═══╧═══╧═══╧═══╧═══╧═══╧═══╧═══╧═══╧═══╧═══╧═══╧═══╧═══╧═══════╣
║                                                                              ║
║               This work is protected by the following license:               ║
║     ╔══════════════════════════════════════════════════════════════════╗     ║
║     │                                                                  │     ║
║     │ Copyright © 2014 Maker Systems.                                  │     ║
║     │                                                                  │     ║
║     │ This software is provided 'as-is', without any kind of           │     ║
║     │ warranty. Under no circumstances will the author be held         │     ║
║     │ liable for any damages arising from the use of this software.    │     ║
║     │                                                                  │     ║
║     │ Permission is granted to anyone to use this software on their    │     ║
║     │ free or commercial games made with a legal copy of RPG Maker     │     ║
║     │ VX Ace, as long as Maker Systems - RPG Maker Source is           │     ║
║     │ credited within the game.                                        │     ║
║     │                                                                  │     ║
║     │ Selling this code or any portions of it 'as-is' or as part of    │     ║
║     │ another code, is not allowed.                                    │     ║
║     │                                                                  │     ║
║     │ The original header, which includes this copyright notice,       │     ║
║     │ must not be edited or removed from any verbatim copy of the      │     ║
║     │ sotware nor from any edited version.                             │     ║
║     │                                                                  │     ║
║     ╚══════════════════════════════════════════════════════════════════╝     ║
║                                                                              ║
║                                                                              ║
╠══════════════════════════════════════════════════════════════════════════════╣
║ 1. VERSION HISTORY.                                                        ▼ ║
╠══════════════════════════════════════════════════════════════════════════════╣
║                                                                              ║
║ • Version 1.0.0, 18/03/15 - (DD/MM/YY).                                      ║
║                                                                              ║
╠══════════════════════════════════════════════════════════════════════════════╣
╠══════════════════════════════════════════════════════════════════════════════╣
║ 2. USER MANUAL.                                                            ▼ ║
╠══════════════════════════════════════════════════════════════════════════════╣
║                                                                              ║
║ ┌──────────────────────────────────────────────────────────────────────────┐ ║
║ │ ■ Introduction.                                                          │ ║
║ └┬┬┬┬──────────────────────────────────────────────────────────────────┬┬┬┬┘ ║
║                                                                              ║
║  Hello there! This script is "plug and play", you can simply insert it into  ║
║  your project and it will perform flawlessly.                                ║
║                                                                              ║
║  Do you know what lots of games made in RPG Maker are missing? We know.      ║
║  Something that could really improve the gameplay experience and comfort     ║
║  your players.                                                               ║
║  What would that be? Two things mainly; a way two pause cutscenes and the    ║
║  ability to skip them at will!                                               ║
║                                                                              ║
║  And you know what's better? We specifically designed this system so you     ║
║  can easily add it to any existing game with minimal effort, no matter the   ║
║  development stage!                                                          ║
║                                                                              ║
║  That's right, and you know what's even better? Everything gets executed     ║
║  properly. Event commands and their results are not changed, your game       ║
║  will be exactly the same, except that now it will allow your players to     ║
║  pause or skip any cutscene that you mark as skip-able.                      ║
║                                                                              ║
║  Everything is executed exactly as if the cutscene were never skipped.       ║
║                                                                              ║
║  We hope you enjoy it.                                                       ║
║                                                                              ║
║  Thanks for choosing our products.                                           ║
║                                                                              ║
║ ┌──────────────────────────────────────────────────────────────────────────┐ ║
║ │ ■ Configuration.                                                         │ ║
║ └┬┬┬┬──────────────────────────────────────────────────────────────────┬┬┬┬┘ ║
║                                                                              ║
║  "How do I change the prompt style?"                                         ║
║  Right click anywhere in the script editor and select "Find" (or CTRL + F)   ║
║  search for "PROMPT_STYLE" (without quotation marks).                        ║
║                                                                              ║
║  You will see something like "PROMPT_STYLE    = :special"                    ║
║                                                                              ║
║  Choose between :normal, :special and :none.                                 ║
║  :normal uses a window (with the current windowskin), :special uses an       ║
║  elegant text-only look, and :none will skip the cutscene directly without   ║
║  prompting the player about it.                                              ║
║                                                                              ║
║ ┌──────────────────────────────────────────────────────────────────────────┐ ║
║ │ ■ Feature Documentation.                                                 │ ║
║ └┬┬┬┬──────────────────────────────────────────────────────────────────┬┬┬┬┘ ║
║                                                                              ║
║  This script is very, very easy to use. You only need to tell it where the   ║
║  cutscene starts and where the cutscene ends. That's it.                     ║
║  To indicate the beginning of a cutscene, add a Label (event command) with,  ║
║  by default, 'CUTSCENE START' (without quotation marks).                     ║
║  To indicate the end of a cutscene, add a Label (event command) with, by     ║
║  default, 'CUTSCENE END' (without quotation marks).                          ║
║                                                                              ║
║  While the events command between those labels are being executed, the       ║
║  player will be able to press B (ESC and X in the keyboard) to skip the      ║
║  cutscene. Keep in mind the system will still execute every command, but     ║
║  in almost the blink of an eye and while the screen is faded to              ║
║  black. It's like magic.                                                     ║
║                                                                              ║
║  There is a built-in way of knowing if the player skipped the last cutscene. ║
║  You can use $game_temp.ms_cutscene_skipped in a conditional branch (and     ║
║  in your scripts, of course) to know if the last cutscene was skipped.       ║
║                                                                              ║
╠══════════════════════════════════════════════════════════════════════════════╣
╠══════════════════════════════════════════════════════════════════════════════╣
║ 3. NOTES.                                                                  ▼ ║
╠══════════════════════════════════════════════════════════════════════════════╣
║                                                                              ║
║  This script REQUIRES "Audio Fade In" (also by us) to work.                  ║
║                                                                              ║
║  The skipped cutscene can continue in another page of the same event, as     ║
║  long as the page execution comes right after the execution of the page      ║
║  that started the skipping.                                                  ║
║                                                                              ║
║  Message-related event commands like Show Message and Show Choices are NOT   ║
║  executed, for obvious reasons.                                              ║
║                                                                              ║
║  Have fun and enjoy!                                                         ║
║                                                                              ║
╠══════════════════════════════════════════════════════════════════════════════╣
╠══════════════════════════════════════════════════════════════════════════════╣
║ 4. CONTACT.                                                                ▼ ║
╠══════════════════════════════════════════════════════════════════════════════╣
║                                                                              ║
║  Keep in touch with us and be the first to know about new releases:          ║
║                                                                              ║
║  www.rpgmakersource.com                                                      ║
║  www.facebook.com/RPGMakerSource                                             ║
║  www.twitter.com/RPGMakerSource                                              ║
║  www.youtube.com/user/RPGMakerSource                                         ║
║                                                                              ║
║  Get involved! Have an idea for a system? Let us know.                       ║
║                                                                              ║
║  Spread the word and help us reach more people so we can continue creating   ║
║  awesome resources for you!                                                  ║
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝)

#==============================================================================
# ** Maker Systems
#------------------------------------------------------------------------------
#  Module for our Systems.
#==============================================================================

module MakerSystems
  
  #==============================================================================
  # ** Cutscene Skip
  #------------------------------------------------------------------------------
  #  Contains configurable values for the system.
  #==============================================================================

  module CutsceneSkip
    
    #------------------------------------------------------------------------
    # * Label text to indicate beginning of cutscene.                                      
    #------------------------------------------------------------------------
    SKIP_FROM_LABEL = 'CUTSCENE START'
    
    #------------------------------------------------------------------------
    # * Label text to indicate end of cutscene.                                      
    #------------------------------------------------------------------------
    SKIP_TO_LABEL   = 'CUTSCENE END'
    
    #------------------------------------------------------------------------
    # * Prompt Style.   
    #------------------------------------------------------------------------
    # :special, :normal, :none
    #------------------------------------------------------------------------
    PROMPT_STYLE    = :special
    
    #------------------------------------------------------------------------
    # * Frames for Audio Fade Out.                                      
    #------------------------------------------------------------------------
    AUDIO_FADE_OUT_FRAMES = 240
    
    #------------------------------------------------------------------------
    # * Frames for Audio Fade In.                                      
    #------------------------------------------------------------------------
    AUDIO_FADE_IN_FRAMES  = 120
    
    #------------------------------------------------------------------------
    # * :special Font Name.                                      
    #------------------------------------------------------------------------
    SPECIAL_FONT_NAME = 'VL Gothic'
    
    #------------------------------------------------------------------------
    # * :special Font Color.                                      
    #------------------------------------------------------------------------
    SPECIAL_FONT_COLOR = '255 255 255 255'
    
    #------------------------------------------------------------------------
    # * :special Font Size.                                      
    #------------------------------------------------------------------------
    SPECIAL_FONT_SIZE = 44
    
    #------------------------------------------------------------------------
    # * :normal Font Name.                                      
    #------------------------------------------------------------------------
    NORMAL_FONT_NAME = 'VL Gothic'
    
    #------------------------------------------------------------------------
    # * :normal Font Color.                                      
    #------------------------------------------------------------------------
    NORMAL_FONT_COLOR = '255 255 255 255'
    
    #------------------------------------------------------------------------
    # * :normal Font Size.                                      
    #------------------------------------------------------------------------
    NORMAL_FONT_SIZE = 22
    
    #------------------------------------------------------------------------
    # * Commands to Skip.
    #------------------------------------------------------------------------
    # This are the command codes that will be skipped (not executed at all).
    #------------------------------------------------------------------------
    SKIP = [101, 102, 103, 104, 105, 261]
    
  end
  
end

#==============================================================================
# ** Graphics
#------------------------------------------------------------------------------
#  The module that carries out graphics processing.
#==============================================================================

module Graphics
  
  class << self
   
    #------------------------------------------------------------------------
    # * Alias Update.                                                   [NEW]
    #------------------------------------------------------------------------
    alias_method(:original_update, :update)
    
    #------------------------------------------------------------------------
    # * Update.                                                         [MOD]
    #------------------------------------------------------------------------
    def update
      # Don't draw while skipping a cutscene.
      original_update unless $game_temp.ms_cutscene_skip
    end
    
  end
  
end

#==============================================================================
# ** Audio
#------------------------------------------------------------------------------
#  The module that carries out music and sound processing.
#==============================================================================

module Audio
  
  class << self

    #------------------------------------------------------------------------
    # * Clear SE and ME cache.                                          [NEW]
    #------------------------------------------------------------------------
    def ms_cutscene_skip_clear
      @now_se = nil
      @now_me = nil
    end
    
  end
  
end

#==============================================================================
# ** Game_Temp
#------------------------------------------------------------------------------
#  This class handles temporary data that is not included with save data.
# The instance of this class is referenced by $game_temp.
#==============================================================================

class Game_Temp
  
  #--------------------------------------------------------------------------
  # * Public Instance Variables.                                        [NEW]
  #--------------------------------------------------------------------------
  attr_accessor :ms_cutscene_skip, :ms_cutscene_skipped
  
end

#==============================================================================
# ** Game_Interpreter
#------------------------------------------------------------------------------
#  An interpreter for executing event commands. This class is used within the
# Game_Map, Game_Troop, and Game_Event classes.
#==============================================================================

class Game_Interpreter
  
  #--------------------------------------------------------------------------
  # * Alias Command 118 (Label).                                        [NEW]
  #--------------------------------------------------------------------------
  alias_method(:ms_cutscene_skip_original_command_118, :command_118)
  
  #--------------------------------------------------------------------------
  # * Command 118 (Label).                                              [MOD]
  #--------------------------------------------------------------------------
  def command_118
    # Original method.
    ms_cutscene_skip_original_command_118
    # If Cutscene Start Label.
    if @params[0] == MakerSystems::CutsceneSkip::SKIP_FROM_LABEL
      # Mark event command sequence as cutscene.
      @ms_cutscene = true
      # This cutscene is not yet skipped.
      $game_temp.ms_cutscene_skipped = false
    # If Cutscene End Label.
    elsif @params[0] == MakerSystems::CutsceneSkip::SKIP_TO_LABEL
      # If cutscene has been skipped.
      if $game_temp.ms_cutscene_skip
        # Restore volume.
        Audio.bgm_volume = @ms_cutscene_last_bgm_volume
        Audio.bgs_volume = @ms_cutscene_last_bgs_volume
        Audio.se_volume  = @ms_cutscene_last_se_volume
        Audio.me_volume  = @ms_cutscene_last_me_volume
        # Fade in audio.
        Audio.bgm_fadein(MakerSystems::CutsceneSkip::AUDIO_FADE_IN_FRAMES)
        Audio.bgs_fadein(MakerSystems::CutsceneSkip::AUDIO_FADE_IN_FRAMES)
        Audio.me_fadein(MakerSystems::CutsceneSkip::AUDIO_FADE_IN_FRAMES)
        # Replay BGM and BGS.
        @ms_cutscene_bgm.replay
        @ms_cutscene_bgs.replay
        # No longer skipping.
        $game_temp.ms_cutscene_skip = false
        # No longer cutscene.
        @ms_cutscene = false
        # Fade in screen.
        Graphics.fadein(40)
      end
      # Release saved BGM and BGS.
      @ms_cutscene_bgm = nil
      @ms_cutscene_bgs = nil
    end
  end
  
  #--------------------------------------------------------------------------
  # * Alias Update.                                                     [NEW]
  #--------------------------------------------------------------------------
  alias_method(:ms_cutscene_skip_original_update, :update)
  
  #--------------------------------------------------------------------------
  # * Update.                                                           [MOD]
  #--------------------------------------------------------------------------
  def update
    # Marked as cutscene?
    if @ms_cutscene
      # Pressed Cancel Button?
      if Input.trigger?(:B)
        # Save current BGM and BGS.
        @ms_cutscene_bgm = RPG::BGM.last
        @ms_cutscene_bgs = RPG::BGS.last
        # Fade out audio.
        RPG::BGM.fade(MakerSystems::CutsceneSkip::AUDIO_FADE_OUT_FRAMES)
        RPG::BGS.fade(MakerSystems::CutsceneSkip::AUDIO_FADE_OUT_FRAMES)
        RPG::ME.fade(MakerSystems::CutsceneSkip::AUDIO_FADE_OUT_FRAMES)
        # If cutscene should be skipped.
        if ms_cutscene_skip?
          # Clear SE and ME cache.
          Audio.ms_cutscene_skip_clear
          # Clear messages.
          $game_message.clear
          # Fade out screen.
          Graphics.fadeout(20)
          # Save current volume for each Audio channel.
          @ms_cutscene_last_bgm_volume = Audio.bgm_volume
          @ms_cutscene_last_bgs_volume = Audio.bgs_volume
          @ms_cutscene_last_me_volume  = Audio.me_volume
          @ms_cutscene_last_se_volume  = Audio.se_volume
          # This whill prevent awful things from happening.
          Audio.se_volume  = 0
          Audio.me_volume  = 0
          Audio.bgm_volume = 0
          Audio.bgs_volume = 0
          # Reset message window.
          SceneManager.scene.message_window.dispose
          SceneManager.scene.message_window = Window_Message.new
          # Cutscene is being skipped, mark it as skipped too.
          $game_temp.ms_cutscene_skip = true
          $game_temp.ms_cutscene_skipped = true
        else
          # Replay BGM and BGS.
          @ms_cutscene_bgm.replay
          @ms_cutscene_bgs.replay
        end
      end
    end
    # Original method.
    ms_cutscene_skip_original_update
  end
  
  
  #--------------------------------------------------------------------------
  # * Skip Cutscene?                                                    [NEW]
  #--------------------------------------------------------------------------
  def ms_cutscene_skip?
    true
  end
  
  #--------------------------------------------------------------------------
  # * Alias Execute Command.                                            [NEW]
  #--------------------------------------------------------------------------
  alias_method(:ms_skip_cutscene_original_execute_command, :execute_command)
  
  #--------------------------------------------------------------------------
  # * Execute Command.                                                  [MOD]
  #--------------------------------------------------------------------------
  def execute_command
    # Skipping a cutscene?
    if $game_temp.ms_cutscene_skip
      # Update current BGM and current BGS.
      @ms_cutscene_bgm = RPG::BGM.last if @ms_cutscene_bgm != RPG::BGM.last
      @ms_cutscene_bgs = RPG::BGS.last if @ms_cutscene_bgs != RPG::BGS.last  
      # Don't execute command if code is blacklisted.
      return if MakerSystems::CutsceneSkip::SKIP.include?(@list[@index].code)
    end
    # Original method.
    ms_skip_cutscene_original_execute_command
  end

end

#==============================================================================
# ** Scene_Map
#------------------------------------------------------------------------------
#  This class performs the map screen processing.
#==============================================================================

class Scene_Map
  
  #--------------------------------------------------------------------------
  # * Public Instance Variables.                                        [NEW]
  #--------------------------------------------------------------------------
  attr_accessor :message_window
  
end

if MakerSystems::CutsceneSkip::PROMPT_STYLE == :special
 
#==============================================================================
# ** Maker Systems
#------------------------------------------------------------------------------
#  Module for our Systems.
#==============================================================================

module MakerSystems
  
  #============================================================================
  # ** Cutscene Skip
  #----------------------------------------------------------------------------
  #  Contains Prompt class.
  #============================================================================

  module CutsceneSkip
    
    #==========================================================================
    # ** Prompt
    #--------------------------------------------------------------------------
    #  Used to prompt the player and to pause the cutscene.
    #==========================================================================
   
    class Prompt

      #----------------------------------------------------------------------
      # * Initialize.
      #----------------------------------------------------------------------
      def initialize
        color = MakerSystems::CutsceneSkip::SPECIAL_FONT_COLOR
        if color.include?('#')
          color = color.delete!('#').scan(/../).map { |c| c.to_i(16) }
        else
          color = color.split(' ').map { |c| c.to_i }
        end
        color = Color.new(*color)
        Graphics.freeze
        @sprite = Sprite.new
        @sprite.z = 9999999
        @sprite.bitmap = Graphics.snap_to_bitmap
        @sprite.color = Color.new(0, 0, 0, 200)
        @sprite.bitmap.blur
        Graphics.transition(20)
        helper = Bitmap.new(32, 32)
        helper.font.name  = MakerSystems::CutsceneSkip::SPECIAL_FONT_NAME
        helper.font.size  = MakerSystems::CutsceneSkip::SPECIAL_FONT_SIZE
        helper.font.color = color
        rect1 = helper.text_size('Skip Scene?')
        Graphics.freeze
        @sprite_question = Sprite.new
        @sprite_question.z = @sprite.z + 1
        @sprite_question.bitmap = Bitmap.new(rect1.width, rect1.height * 4)
        @sprite_question.bitmap.font = helper.font
        @sprite_question.bitmap.draw_text(rect1, 'Skip Scene?', 1)
        @sprite_question.bitmap.font.size = 22
        @sprite_question.bitmap.font.color.alpha = 64
        @sprite_question.bitmap.draw_text(
          0,
          rect1.height,
          rect1.width / 2,
          rect1.height,
          'Yes',
          1
        )
        @sprite_question.bitmap.draw_text(
          rect1.width / 2,
          rect1.height,
          rect1.width / 2,
          rect1.height,
          'No',
          1
        )
        
        @sprite_question.x = (Graphics.width  - rect1.width) / 2
        @sprite_question.y = (Graphics.height - rect1.height * 4) / 2
        yes_bitmap = Bitmap.new(rect1.width, rect1.height * 4)
        yes_bitmap.font.size = 22
        yes_bitmap.draw_text(
          0,
          rect1.height,
          rect1.width / 2,
          rect1.height,
          'Yes',
          1
        )
        no_bitmap = Bitmap.new(rect1.width, rect1.height * 4)
        no_bitmap.font.size = 22
        no_bitmap.draw_text(
          rect1.width / 2,
          rect1.height,
          rect1.width / 2,
          rect1.height,
          'No',
          1
        )
                
        @sprite_yes = Sprite.new
        @sprite_yes.z = @sprite_question.z + 1
        @sprite_no = Sprite.new
        @sprite_no.z = @sprite_question.z + 1
        @sprite_yes.bitmap = yes_bitmap
        @sprite_yes.bitmap.clear_rect(rect1)
        @sprite_yes.opacity = 0
        @sprite_yes.x = @sprite_question.x
        @sprite_yes.y = @sprite_question.y
        no_rect = helper.text_size('No')
        @sprite_no.bitmap = no_bitmap
        @sprite_no.x = @sprite_question.x
        @sprite_no.y = @sprite_question.y
        @index = 1
        @stage = 0
        Graphics.transition(20)
        helper.dispose
      end
      
      #----------------------------------------------------------------------
      # * Dispose.
      #----------------------------------------------------------------------
      def dispose(skip)
        Graphics.freeze         unless skip
        @sprite_no.bitmap.dispose
        @sprite_no.dispose
        @sprite_yes.bitmap.dispose
        @sprite_yes.dispose
        @sprite_question.bitmap.dispose
        @sprite_question.dispose
        Graphics.transition(20) unless skip
        Graphics.freeze         unless skip
        @sprite.bitmap.dispose
        @sprite.dispose
        Graphics.transition(20) unless skip
      end
      
      #----------------------------------------------------------------------
      # * Update.
      #----------------------------------------------------------------------
      def update
        # Cursor update.
        if @index == 1
          selected = @sprite_no
          disabled = @sprite_yes
        elsif @index == 0
          selected = @sprite_yes
          disabled = @sprite_no
        end
        if @stage == 0
          selected.opacity -= 8
          @stage = 1 if selected.opacity == 0
        elsif @stage == 1
          selected.opacity += 8
          @stage = 0 if selected.opacity == 255
        end
        disabled.opacity -= 12
        # Input update.
        if Input.trigger?(:LEFT) || Input.trigger?(:RIGHT)
          Sound.play_cursor
          @index = @index == 0 ? 1 : 0 
        end
      end
      
      #----------------------------------------------------------------------
      # * Done?
      #----------------------------------------------------------------------
      def done?
        Input.trigger?(:C) || Input.trigger?(:B)
      end
      
      #----------------------------------------------------------------------
      # * Skip?
      #----------------------------------------------------------------------
      def skip?
        @index == 0 && Input.trigger?(:C)
      end
      
    end
    
  end
  
end

#==============================================================================
# ** Game_Interpreter
#------------------------------------------------------------------------------
#  An interpreter for executing event commands. This class is used within the
# Game_Map, Game_Troop, and Game_Event classes.
#==============================================================================

class Game_Interpreter
  
  #--------------------------------------------------------------------------
  # * Skip Cutscene?                                                    [NEW]
  #--------------------------------------------------------------------------  
  def ms_cutscene_skip?
    prompt = MakerSystems::CutsceneSkip::Prompt.new
    loop do
      Graphics.update
      Input.update
      prompt.update
      if prompt.done?
        result = prompt.skip?
        Graphics.fadeout(40) if result
        prompt.dispose(result)
        return result
      end
    end
  end

end

elsif MakerSystems::CutsceneSkip::PROMPT_STYLE == :normal
 
#==============================================================================
# ** Maker Systems
#------------------------------------------------------------------------------
#  Module for our Systems.
#==============================================================================

module MakerSystems
  
  #==============================================================================
  # ** Cutscene Skip
  #------------------------------------------------------------------------------
  #  Contains Prompt class.
  #==============================================================================

  module CutsceneSkip
    
    #==========================================================================
    # ** Prompt
    #--------------------------------------------------------------------------
    #  Used to prompt the player and to pause the cutscene.
    #==========================================================================

    class Prompt < Window_Command
      
      #----------------------------------------------------------------------
      # * Initialize.
      #----------------------------------------------------------------------
      def initialize
        super(
          (Graphics.width  - window_width)  / 2,
          (Graphics.height - window_height) / 2
        )
        self.openness = 0
        self.index = 1
        open
        set_handler(:ok, method(:on_ok))
        set_handler(:cancel, method(:on_cancel))
        @done = false
      end
      
      #----------------------------------------------------------------------
      # * Make Command List.
      #----------------------------------------------------------------------
      def make_command_list
        add_command('Yes', :ok)
        add_command('No', :cancel)
      end
      
      #----------------------------------------------------------------------
      # * Window Width.
      #----------------------------------------------------------------------
      def window_width
        192
      end
      
      #----------------------------------------------------------------------
      # * Visible Line Number.
      #----------------------------------------------------------------------
      def visible_line_number
        2
      end
      
      #----------------------------------------------------------------------
      # * Window Height.
      #----------------------------------------------------------------------
      def window_height
        super + standard_padding / 2
      end
      
      #----------------------------------------------------------------------
      # * On Okay.
      #----------------------------------------------------------------------
      def on_ok
        @done = true
        @skip = true
      end
      
      #----------------------------------------------------------------------
      # * On Cancel.
      #----------------------------------------------------------------------
      def on_cancel
        @done = true
      end
      
      #----------------------------------------------------------------------
      # * Column Max.
      #----------------------------------------------------------------------
      def col_max
        2
      end
      
      #----------------------------------------------------------------------
      # * Alignment.
      #----------------------------------------------------------------------
      def alignment
        1
      end
      
      #----------------------------------------------------------------------
      # * Item Rect.
      #----------------------------------------------------------------------
      def item_rect(index)
        rect = super(index)
        rect.y += contents.font.size
        rect
      end
      
      #----------------------------------------------------------------------
      # * Refresh.
      #----------------------------------------------------------------------
      def refresh
        super
        color = MakerSystems::CutsceneSkip::SPECIAL_FONT_COLOR
        if color.include?('#')
          color = color.delete!('#').scan(/../).map { |c| c.to_i(16) }
        else
          color = color.split(' ').map { |c| c.to_i }
        end
        color = Color.new(*color)
        change_color(color)
        draw_text(0, 0, contents_width, line_height, "Skip Scene?", 1)
      end
      
      #----------------------------------------------------------------------
      # * Done?
      #----------------------------------------------------------------------
      def done?
        @done
      end
      
      #----------------------------------------------------------------------
      # * Skip?
      #----------------------------------------------------------------------
      def skip?
        @skip
      end
      
    end
    
  end
  
end

#==============================================================================
# ** Game_Interpreter
#------------------------------------------------------------------------------
#  An interpreter for executing event commands. This class is used within the
# Game_Map, Game_Troop, and Game_Event classes.
#==============================================================================

class Game_Interpreter
  
  #--------------------------------------------------------------------------
  # * Skip Cutscene?                                                    [NEW]
  #--------------------------------------------------------------------------
  def ms_cutscene_skip?
    Graphics.freeze
    sprite = Sprite.new
    sprite.z = 9999999
    sprite.bitmap = Graphics.snap_to_bitmap
    sprite.color = Color.new(0, 0, 0, 200)
    sprite.bitmap.blur
    prompt = MakerSystems::CutsceneSkip::Prompt.new
    prompt.z = sprite.z + 1
    Graphics.transition(20)
    loop do
      Graphics.update
      Input.update
      prompt.update
      if prompt.done?
        result = prompt.skip?
        prompt.close
        until prompt.close?
          prompt.update
          Graphics.update
        end
        if result
          Graphics.fadeout(40)
          sprite.dispose
          prompt.dispose
        else
          Graphics.freeze
          sprite.dispose
          prompt.dispose
          Graphics.transition(20)
        end
        return result
      end
    end
  end

end

end