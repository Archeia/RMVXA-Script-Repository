# Large collision area for events. 
# Shaz, November 2012 AMENDED BY SOURCE MARCH 2015 for use with Effectus
#
# To use, place the following as a comment at the top of the event page.
# <collision: x,y>
# where x and y are the pixels wide/high.
# NB, the measurements are taken from centre bottom.
#
# Can be used for e.g. wide exits from map; any event where you are using
# using a graphic that is larger than one tile and don’t want to do multiple
# events or use a parallel process.
#===================================================
class Game_Event < Game_Character
  alias shaz_large_event_collision_clear_page_settings clear_page_settings
  alias shaz_large_event_collision_setup_page_settings setup_page_settings


  def clear_page_settings
    shaz_large_event_collision_clear_page_settings
    @collide_width = 0
    @collide_height = 0
  end


  def setup_page_settings
    shaz_large_event_collision_setup_page_settings
    @collide_width = 0
    @collide_height = 0
    list_index = 0
    while list_index < @list.size && [108,408].include?(@list[list_index].code)
      colx, coly = @list[list_index].parameters[0].scan(/<collision: (\d+),(\d+)>/i)[0]
      @collide_width = colx.nil? ? 0 : (colx.to_i / 64)
      @collide_height = coly.nil? ? 0 : (coly.to_i / 32 - 1)
      list_index = @list.size if @collide_width != 32 || @collide_height != 32
      list_index += 1
    end
  end


  def pos?(x,y)
    x.between?(@x - @collide_width, @x + @collide_width) && 
    y.between?(@y - @collide_height, @y)
  end
    
  alias_method(:effectus_slec_fix_original_update, :update)
  def update
    effectus_slec_fix_original_update
    return unless (@collide_width > 0 || @collide_height > 0)
    unless @ms_effectus_slec_position_registered
      events = $game_map.ms_effectus_event_pos
      width = $game_map.width
      ((@x - @collide_width)..(@x + @collide_width)).each do |domain_x|
        ((@y - @collide_height)..@y).each do |domain_y|
          unless @y == domain_y && @x == domain_x
            events[domain_y * width + domain_x] << self
          end
        end
      end
      @ms_effectus_slec_position_registered = true        
    end
  end
  
end