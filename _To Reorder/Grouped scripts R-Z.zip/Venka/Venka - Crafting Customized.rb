#===============================================================================
# Crafting Script Customize Settings - v3.8                 updated: 10/27/2014
#===============================================================================
# - Introduction -
#------------------------------------------------------------------------------
#  A script that allows the player to craft items. There's a menu to help the 
#  player keep track of their recipes and items needed to make their items.
#  You can have multiple crafts (Cooking, Smithing, Alchemy, etc). Each craft
#  has it's own exp, levels and recipes.
#  
#  You can set up a gauge that shows progress on crafting an item (you can turn 
#  the gauge off, make it a progress bar or set it as an interactive gauge). 
#  The interactive gauge will change colors when you can claim an item. If you 
#  press enter when the color changes, then you successfully craft the item. If 
#  you do it before the change then you consume the ingredients and make 
#  nothing (with the option of still earning some exp). If you try to claim the 
#  item after the gauge's color changes back to it's original color, then you 
#  have waited too long and you can receive a failed item (and the option of 
#  some exp).
#
#  For example, if you're cooking and you cook for too long then you could 
#  receive a burnt item.
#  
#  You can also make items that you can carry in the player's inventory that 
#  allows them to craft wherever they go. I used a Mortar and Pestle in the
#  demo for Alchemy.
#
#------------------------------------------------------------------------------
# - Instructions -
#------------------------------------------------------------------------------
#  This script is not plug and play since the database has been adjusted to 
#  show off what this script can do.
#  
#  Place this script below Materials, but above Main. If you are using this 
#  script with modern algebra's Icon Hues, then put this script below that one.
#  
#------------------------------------------------------------------------------
# - Item/Weapon/Armor Note Tags -
#------------------------------------------------------------------------------
#  Use the following note tag in any item, weapon, or armor that you don't 
#  want consumed when crafting. The item should be listed in the recipe's 
#  required ingredients.
#     <tool>
#  
#------------------------------------------------------------------------------
# - Script Calls -
#------------------------------------------------------------------------------
# To call the scene use:
#   craft(craft_id)
#      craft_id = This is the ID set for the craft at Craft_Info
#
#    EXAMPLE: craft(1)
#      This would call the Craft_Info at ID 1, which is "Cooking". So the 
#      windows would open and show recipes and info for Cooking.
#  
# To teach the player a new recipe use:
#   learn_recipe(recipe_id)
#      recipe_id is the ID in Recipes.
#
#    EXAMPLE: learn_recipe(1)
#      This would call the recipe that matches Recipes[1]. Which is the 
#      Loaf of Bread recipe for cooking. So it will show when the cook book 
#      is open, but not any other craft books.
#  
# To delete a recipe use:
#   forget_recipe(recipe_id)
#      recipe_id is the ID in Recipes.
#      NOTE: It's the same as learn_recipe but it removes the recipe.
#
# To check the current crafting level:
#   $craft[craft_id].level                   - player's level
#   $craft[craft_id].exp                     - player's total craft exp
#   $craft[craft_id].change_level(level)     - grant or loose levels
#      craft_id = This is the ID set for the craft at Craft_Info
#      level = the levels you want to add or loose.
#   $craft[craft_id].set_level(level)        - change to a specific level
#      craft_id = This is the ID set for the craft at Craft_Info
#      level = the levels you want to set the craft to.
#   recipe_learned?(recipe_id)               - checks if recipe is learned
#      You'd want to use this in a conditional branch to see if a skill is 
#      learned. You do NOT need to use this to prevent from learning a recipe
#      twice (you can only ever learn a recipe once).
#
#   EXAMPLES: $craft[2].level      - Checks the Smithing Level
#             $craft[3].exp        - Checks the total exp earned for Alchemy
#             $craft[1].change_level(3)     - Would grant 3 levels to Cooking
#                NOTE: You can use negative numbers to loose levels.
#             $craft[1].change_level(-1)    - Would loose 1 level to Cooking
#             $craft[3].set_level(8)        - Would set alchemy to level 8
#
#==============================================================================
$imported = {} unless $imported
$imported[:Venka_Crafting] = true
#===============================================================================
# ■ Venka Module
#===============================================================================
module Venka; module Crafting
  #=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  # - General Settings -
  #=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  Window_Opacity     = 225      # Window's over all opacity. Number 0 - 255
  Window_BGOpacity   = 180      # Window's background opacity (default 192)
  Auto_Learn         = false     # Automatically learn recipes when leveling
  Gold_Icon          = 2620      # Icon Index used for Gold Coins
  Gold_Text          = "Gold"   # Text used to represent currency
  Gold_Hue           = 0        # Icon Hue (if using modern alegbra's Icon Hues)
  Use_Line_Dividers  = true     # Toggle the display of line separators
  Failure_Exp_Rate   = 0     # Exp received when failed. Ex 0.25 is 25%
  Include_Equipment  = true     # Include equipped items in total owned items?
  Use_Craft_Exp      = true     # Use craft exp and levels true/false
  #=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  # - Craft Time Settings - 
  #----------------------------------------------------------------------------
  # This effects how the timer gauge will function. It can be :active, :timer,
  # or :none. 
  #   :active - The player must try to hit the action key while the gauge is 
  #             green to get a successfully crafted item. Too soon or too late 
  #             will result in failed items.
  #   :timer  - This will be a bar to show progress made. The time on the bar 
  #             will be set to the craft_time for the recipe. There are no 
  #             failure items or key presses.. it's just a progress bar.
  #   :none   - Skip the gauge all togeather, instantly craft the item.
  #=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  Timer_Type = :active         # Set to :active, :timer, or :none
  Crafting_Time_Max  = 1000    # Max craft time (total time)
  Crafting_Buffer    = 30      # Buffer to activated timer (window for claiming)
  Default_Craft_Time = 500     # Default craft time (when to claim item)
  Time_Variance      = 100     # Variance to craft time, set to 0 to disable
  Accelerate_Time    = true    # Craft time gets faster as you out level them
  # This is the rate to speed up craft time. This should be between 0.1 and 0.9
  Accelerate_Rate    = 0.9     # The lower the number, the faster it speeds up.
  #=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  # - Craft Stack Settings -
  #----------------------------------------------------------------------------
  # This is where you can set out if you want the player to be able to craft 
  # stacks of items. If you have the Timer_Type set to :none, then all other 
  # settings that effect the timers won't matter.
  #=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  Craft_Stacks = true        # Set to true to allow crafting of stacks of items
  #=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  # - Recipe List Sort Setting - 
  #----------------------------------------------------------------------------
  # You can set how the list will sort. You can sort it by required crafting 
  # level, alphabetically by the item's name that is crafted, or the default 
  # method of showing them in the order they were created.
  # If there is a typo in the choice setting, the it defaults to :default
  #=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  Sort_Type = :level      # choices are :level, :alphabet, or :default
  #=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  # - Gauge Color Settings - 
  #----------------------------------------------------------------------------
  # You can use window skin color code by simply putting the number (0 - 31) 
  # OR use RBG Colors by putting (red, blue, green, opacity) 0 - 255 each.
  #    Examples:    Exp_Gauge_Color1 = 27
  #                 Exp_Gauge_Color1 = [10, 100, 215, 100]
  #=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  Exp_Gauge_Color1   = [110,   0, 215, 200]   # Left side of the exp gauge
  Exp_Gauge_Color2   = [180, 150, 255, 230]   # Right side of the exp gauge
  Craft_Gauge_Color1 = 10                     # Left side of the crafting gauge
  Craft_Gauge_Color2 = 21                     # Right side of the crafting gauge
  Claim_Gauge_Color1 = [ 25, 100,   0, 255]   # Left side of the claim gauge
  Claim_Gauge_Color2 = [  0, 255,   0, 240]   # Right side of the claim gauge
  #=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  # - Sound Settings -
  #----------------------------------------------------------------------------
  # The file should be one found in the SE folder. Volume is 1 - 100
  # Pitch can be 50 - 200
  # Use this format: [ "FileName", Volume, Pitch ]
  #=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  Start_Scene      = ["Book1", 80, 100]            # Sound on book open
  Success_Sound    = ["Item1", 80, 75]             # Crafted successfully
  Premature_Sound  = ["Disappointment", 80, 100]   # Crafted too soon
  Failure_Sound    = ["Chime1", 80, 50]            # Crafted too late
  Level_Up_Sound   = ["Sound2", 80, 100]           # Gained crafting level
  #=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  # - Text Settings -
  #=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  Craft_Button_Text = "Craft"        # What the begin crafting button displays
  Directions_Msg    = "Press Enter/X/Square when the bar is green!" # Instructions Text
  Possessed_Text    = "Currently Owned:"                    # Total Owned Text
  Ingredients_Text  = "Ingredients:"                        # Ingredients Text
  Needed_Owned_Text = "Need/Have"                           # Needed/Owned Text
  Level_Text = "Lv:"                                        # Level Text
  EXP_Text   = "Exp"                                        # Exp Text
  #=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  # - Results Pop-up Window Settings -
  #=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  Pop_up_Window    = true     # Use the pop up window
  Result_Opacity   = 255      # Result window's over all opacity. Number 0 - 255
  Result_BGOpacity = 215      # Result window's background opacity (default 192)
  Results_Text = "Results"    # Text shown at the top of the Results Window
  Failed_Msg = "Crafting Failed."   # Fail message
  Result_Msg = "You successfully crafted:"                             # Success Message
  Lv_Gain    = "Leveled Up!"                             # Level up message
  Exp_Earned = "Exp earned:"                              # Exp Earned message
  Max_Exp    = "Maxed Out Exp."                               # Message for max exp
  Learn_Text = "Learned:"                                 # Learned prefix
  #=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  # - Font Settings -
  #----------------------------------------------------------------------------
  # :title_text   = the text craft's name in the Title Window.
  # :recipe_name  = the recipe's name at the top of the detail window
  # :recipe_list  = font used in the recipe list window
  # :header_text  = the "Ingredients: Needed/Owned" line in the detail window
  # :description  = the crafted item's description text.
  # :help_text    = the text that appears when crafting an item.
  # :other_text   = all other text
  # :button_text  = the Create/Cancel Buttons test
  # 
  # For each text type you need to set up the Fonts, Size, Boldness and Color.
  # Use the following format:
  #   [["Font_Name, Font_Name, etc], Font_Size, Bold?, Color]],
  #      Font_Name = an array holding font choices. The fist one is your first 
  #         choice to use, but if the player doesn't have that font on their 
  #         computer, it will go through the list until it finds one it can use
  #      Font_Size = the size font you want to use
  #      Bold? = this should be true for bold, false to turn bold off
  #      Color = This is the same format as setting colors for Gauge Color.
  #         Use [red, blue, green, opacity] or window skin color number.
  #=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  Line_Color = [150, 150, 250, 225] # Color used for divider lines
  Fonts = {       # [["Fonts"]],           Size, Bold?, Color
    :title_text  => [["Sylfaen", "Calibri"], 24, true,  0],
    :recipe_name => [["Sylfaen", "Calibri"], 25, true,  14],
    :recipe_list => [["Sylfaen", "Calibri"], 24, true,  0],
    :header_text => [["Sylfaen", "Calibri"], 24, true,  1],
    :description => [["Sylfaen", "Calibri"], 22, false, 0],
    :help_text   => [["Sylfaen", "Calibri"], 24, false, 17],
    :other_text  => [["Verdana", "Calibri"], 22, false, 0],
    :button_text => [["Verdana", "Calibri"], 24, true, [0, 255, 0, 200]],
    } # <- DO NOT REMOVE
  Craft_Info ||= {} # <- DO NOT REMOVE
  #=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  # - Craft_Info Settings -
  #----------------------------------------------------------------------------
  #  Craft_Info[ID] => {                          # ID must be a unique number
  #      :craft_name    => "Title",               # The name of the craft
  #          "Title" will be the name of the craft
  #      :craft_time    => n,                     # n would be the craft time
  #          You can set the default craft time of items by their craft type.
  #          This option can be omitted. If you do use this option, it will 
  #          overwrite the Default_Craft_Time set above for this craft type.
  #      :buffer_time   => n,                     # n would be the buffer time
  #          You can set the default buffer time of items by their craft type.
  #          The buffer time is the window of opportunity when you can craft 
  #          an item when using the :active crafting Timer_Type. You can omit 
  #          this setting and it will use the Crafting_Buffer time.
  #      :exp_table     => [A, B, C, D],          # Exp Curve
  #          A is the base exp needed (this number can be 10 or higher)
  #          B is the exp tacked on to each level (this can be 0 or higher)
  #          C is a curve that effects all levels (must be 10 or higher)
  #          D is another curve that effects high levels mostly (must be 10+)
  #          NOTE: This functions exactly like class exp in the database
  #      :max_level     => x,                     # Max Craft Level
  #          x is the maximum level for the craft (1-99)
  #      :mastered      => "Text",                # Title seen at Max Level
  #          "Text" is text shown when the exp gauge for the craft is maxed out
  #      :bg_image      => "File_Name",           # Background image for scene
  #          "File_Name" is file found Graphics/Titles1 or Graphics/Picture.
  #          Use nil to omit this option.
  #      :bg_music      => "File_Name",           # Background music for scene
  #          "File_Name" is file found Audio/BGM. Use nil to omit
  #      :active_sound  => ["File_Name", Volume, Pitch],  # Sound while crafting
  #          For this one, it will check in the Audio/BGS folder first if it 
  #          doesn't find the file, then it'll check in Audio/SE. If the file 
  #          is a SE (sound effect) it will play ever 2 seconds. Can be omitted.
  #=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  Craft_Info[1] = {  # Cooking
    :craft_name    => "Cook",
    :craft_time    => 30,
    :buffer_time   => 90,
    :exp_table     => [ 10, 5, 12, 20],
    :max_level     => 3,
    :mastered      => "Top Chef",
    :bg_image      => "Book",
    :bg_music      => nil,
    :active_sound  => ["Fire", 100, 100],
    } # <-DO NOT REMOVE
  Craft_Info[2] = {  # Blacksmith
    :craft_name    => "Smith",
    :exp_table     => [ 12, 3, 20, 15],
    :max_level     => 30,
    :mastered      => "Master Smith",
    :bg_image      => "CrossedSwords",
    :bg_music      => nil,
    :active_sound  => ["Hammer", 100, 100],
    } # <-DO NOT REMOVE
  Craft_Info[3] = {  # Alchemy
    :craft_name    => "Alchemy",
    :exp_table     => [ 10, 0, 10, 10],
    :max_level     => 35,
    :mastered      => "Potion Genius",
    :bg_image      => "Hexagram",
    :bg_music      => ["Dungeon7", 90, 100],
    :active_sound  => ["Drips", 100, 100],
    } # <-DO NOT REMOVE
  Craft_Info[4] = {  # Fishing
    :craft_name    => "Fishing",
    :exp_table     => [ 10, 0, 10, 10],
    :max_level     => 99,
    :mastered      => "Master Angler",
    :bg_image      => "Island",
    :bg_music      => nil,
    } # <-DO NOT REMOVE
  Craft_Info[5] = {  # Mining
    :craft_name    => "Mining",
    :exp_table     => [ 10, 0, 10, 10],
    :max_level     => 99,
    :mastered      => "Excavator",
    :bg_image      => "Crystal",
    :bg_music      => nil,
    } # <-DO NOT REMOVE
  Craft_Info[6] = {  # Lumberjack
    :craft_name    => "Lumberjack",
    :exp_table     => [ 10, 0, 10, 10],
    :max_level     => 99,
    :mastered      => "Paul Bunyan",
    :bg_image      => nil,
    :bg_music      => nil,
    } # <-DO NOT REMOVE
  #=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  # - Recipe Settings -
  #----------------------------------------------------------------------------
  # To create a recipe you will need to fill out the information below. Most of 
  # these entries are optional. The only ones that MUST be defined are the ID, 
  # :recipe_type, :crafted_item and :ingredients. The id is requred so the 
  # script can find the recipe. The :recipe_type is so it know which crafting 
  # category it belongs to. The :crafted_item is what it will produce (failed 
  # and prefailed items are optional). And lastly, you will need to set up 
  # atleast one required item to craft in :ingredients. It can be an item, gold, 
  # weapons or armor or any combo of these items. There are 10 recipes set up 
  # in the demo that should demonstrate the various things you can do.
  # 
  # Recipe[ID] => {      The ID must be a unique number.
  #   :recipe_type  => x,
  #         x = the Craft_Info ID this recipe belongs to.
  #             If it was 1 then it'd be a cooking recipe, 2 is blacksmith, etc
  #   :auto_learn    => false,
  #         This can be omitted. This option only works if Auto_Learn = true
  #         You'll set this option to false if you want this recipe to be 
  #         learned from a special source (like a NPC, quest, boss kill, etc).
  #   :req_level    => y
  #         y = the crafting level needed to make the recipe
  #   :display_name => "text"
  #         text is the text that will appear in place of the crafted item's 
  #         name. The crafted items icon will still show.
  #   :shop_fee => n,         # The cost to craft the recipe at a shop keeper
  #         n = a number in gold pieces. This only matters if using the Shop
  #             Craft & Decompile Add on script.
  #   :craft_time   => t,
  #         t = time in frames (60 frames = 1 second). This is the time when 
  #             the recipe can claim success. Before the time results in lost
  #             ingredients and no item. After this time results in lost
  #             ingredients and a failed attempt item is granted.
  #         NOTE: You can omit this one to use the Default_Craft_Time above
  #   :earned_exp   => exp,
  #         exp = the amount of exp received on successful crafting of the item
  #   :crafted_item => [:Type/Item_ID, Amount],
  #   :failed_item  => [:Type/Item_ID, Amount], # Item made if crafted too late
  #   :pre_failed   => [:Type/Item_ID, Amount], # Item made if crafted too soon
  #   :ingredients  => [[:Type/ItemID, Amount], [:Type/ItemID, Amount], ... ]
  #         Type = i for Items
  #                a for Armor
  #                w for Weapons
  #                g for Gold
  #         Item_ID = item's id in the database
  #         Amount  = the amount of items to reward
  # 
  # NOTE: :ingredients can have multiple entries. The following entries can be
  #     omitted - :failed_item, :pre_failed, and :craft_time
  #=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  Recipes ||= {}
  #--------------------------------------------------------------------------
  # - Custom Recipes Start Here -
  #--------------------------------------------------------------------------
  Recipes[1] = {     # Loaf of Bread
    :recipe_type  => 1,            # Cooking Recipe
    :auto_learn   => true,         # Auto-learn this recipe
    :req_level    => 1,            # Level required to use this recipe
    :display_name => "Bake Bread", # Name that appears on the recipe
    :shop_fee     => 20,           # Fee charged if crafted at a shop
    :craft_time   => 200,          # Time it takes to make the item
    :earned_exp   => 3,            # Exp gained on success
    :crafted_item => [:i20, 2],    # Makes 2x Loaf of Bread
    :failed_item  => [:i29, 1],    # 1x Piece of Charcoal if failed attempt
    :pre_failed   => [:i19, 1],    # Failed item if crafted before timer
    :ingredients  => [ # 2x Eggs,  1x Flour,   1x Fresh Milk, 5 Gold
                     [:i21, 2], [:i22, 1], [:i23, 1], [:g5],
    ]} # <- DO NOT REMOVE
  Recipes[2] = {     # Stew
    :recipe_type  => 1,          # Cooking Recipe
    :auto_learn   => false,      # Must learn this recipe from the Cook NPC
    :req_level    => 2,          # Level required to use this recipe
    :craft_time   => 250,        # Time it takes to make the item
    :earned_exp   => 5,          # Exp gained on success
    :crafted_item => [:i24, 1],  # Makes 1x Stew
   #:failed_item  => [:i29, 1],  # Omitting failed item. You'd just get no item
    :ingredients  => [# 2x Meat, 1x Carrot, 1x Bell Pepper, 1x Onion
                     [:i25, 2], [:i26, 1], [:i27, 1], [:i28, 1],
  ]} # <- DO NOT REMOVE
  Recipes[3] = {     # Cestus
    :recipe_type  => 2,          # Smithing Recipe
    :auto_learn   => false,      # Store bought recipe (add on required)
    :req_level    => 3,          # Level required to use this recipe
    :craft_time   => 400,        # Time it takes to make the item
    :earned_exp   => 0,          # Exp gained on success (0 exp test)
    :crafted_item => [:w7, 1],   # Makes 1x Cestus
    :failed_item  => [:i36, 1],  # 1x Slag on failed attempt
    :ingredients  => [ # 3x Iron Ore, x3 Claw
                     [:i33, 3], [:i37, 3],
  ]} # <- DO NOT REMOVE
  Recipes[4] = {     # Chain Mail
    :recipe_type  => 2,          # Smithing Recipe
    :req_level    => 2,          # Level required to use this recipe
    :craft_time   => 400,        # Time it takes to make the item
    :earned_exp   => 5,          # Exp gained on success
    :crafted_item => [:a31, 1],  # Makes 1x Chain Mail
    :failed_item  => [:i36, 1],  # 1x Slag on failed attempt
    :ingredients  => [# 2x Iron Ore, 3x Leather Straps, 1x Hammer
                     [:i33, 2], [:i34, 3], [:w43, 1]
  ]} # <- DO NOT REMOVE
  Recipes[5] = {     # Battle Axe
    :recipe_type  => 2,          # Smithing Recipe
    :req_level    => 1,          # Level required to use this recipe
   #:craft_time   => 300,        # Time omitted to use default time of 500
    :earned_exp   => 4,          # Exp gained on success
    :crafted_item => [:w2, 1],   # Makes 1x Battle Axe
    :failed_item  => [:i36, 1],  # 1x Slag on failed attempt
    :pre_failed   => [:i36, 1],  # 1x Slag on pre-timer fail
    :ingredients  => [# 1x Iron Ore, 1x Wooden Shaft
                     [:i33, 1], [:i35, 1],
  ]} # <- DO NOT REMOVE
  Recipes[6] = {     # Potion
    :recipe_type  => 3,          # Alchemy Recipe
    :auto_learn   => false,      # Eric auto learns this with the actor add-on
    :req_level    => 1,          # Level required to use this recipe
    :craft_time   => 350,        # Time it takes to make the item
    :earned_exp   => 4,          # Exp gained on success
    :crafted_item => [:i1, 1],   # Makes 1x Potion
    :failed_item  => [:i45,1],   # 1x Gelatinous Goo when crafted too late
   #:pre_failed   => [:i45,1],   # 1x Gelatinous Goo when crafted too soon
    :ingredients  => [# 1x Lizard Hearts, 1x Sea Shell, 1x Bunsen Burner
                     [:i40, 1], [:i42, 1], [:i45, 1],
  ]} # <- DO NOT REMOVE
  Recipes[7] = {     # Stimulant
    :recipe_type  => 3,          # Alchemy Recipe
    :auto_learn   => false,      # Eric will auto learn this recipe
    :req_level    => 2,          # Level required to use this recipe
    :craft_time   => 500,        # Time it takes to make the item
    :earned_exp   => 7,          # Exp gained on success
    :crafted_item => [:i5, 1],   # Makes 1x Stimulant
    :failed_item  => [:i45,1],   # 1x Gelatinous Goo when crafted too late
    :ingredients  => [# 1x Sea Shell, 1x Pixie Dust
                     [:i42, 1], [:i41, 1],
  ]} # <- DO NOT REMOVE
  Recipes[8] = {     # Magic Water
    :recipe_type  => 3,          # Alchemy Recipe
    :req_level    => 3,          # Level required to use this recipe
    :auto_learn   => false,      # Eric will auto learn this recipe
    :craft_time   => 450,        # Time it takes to make the item
    :earned_exp   => 12,         # Exp gained on success
    :crafted_item => [:i4, 1],   # Makes 1x Magic Water
    :failed_item  => [:i45,1],   # 1x Gelatinous Goo when crafted too late
    :ingredients  => [# 1x Pixie Dust, 1x Diamond Dust
                     [:i41, 1], [:i43, 1],
  ]} # <- DO NOT REMOVE
  Recipes[9] = {     # Hi-Potion
    :recipe_type  => 3,          # Alchemy Recipe
    :req_level    => 5,          # Level required to use this recipe
    :crafted_item => [:i2, 1],   # Makes 1x Hi-Potion
    :ingredients  => [# 3x Potions, 1x Diamond Dust
                     [:i1, 3], [:i43, 1],
  ]} # <- DO NOT REMOVE
  Recipes[10] = {     # Bamboo Pole
    :recipe_type  => 4,            # Fishing Recipe
    :req_level    => 1,            # Level required to use this recipe
    :craft_time   => 80,           # Time it takes to make the item
    :earned_exp   => 5,            # Exp gained on success
    :crafted_item => [:i53, 1],    # Makes 1x Bamboo Pole
    :failed_item  => [:i57, 1],    # 1x Bamboo
    :pre_failed   => [:i57, 1],    # 1x Bamboo
    :ingredients  => [ # 1x Bamboo,  1x Twine
                     [:i57, 1], [:i58, 1],
    ]} # <- DO NOT REMOVE
  Recipes[11] = {     # Fishing Pole
    :recipe_type  => 4,            # Fishing Recipe
    :req_level    => 10,           # Level required to use this recipe
    :craft_time   => 120,          # Time it takes to make the item
    :earned_exp   => 100,          # Exp gained on success
    :crafted_item => [:i54, 1],    # Makes 1x Fishing Pole
    :failed_item  => [:i53, 1],    # 1x Bamboo Pole
    :pre_failed   => [:i53, 1],    # 1x Bamboo Pole
    :ingredients  => [# Bamboo Pole,  1x Bamboo,  1x Twine
                     [:i53, 1], [:i57, 1], [:i58, 1],
    ]} # <- DO NOT REMOVE
  Recipes[12] = {     # Heavy Rod
    :recipe_type  => 4,            # Fishing Recipe
    :req_level    => 30,           # Level required to use this recipe
    :craft_time   => 200,          # Time it takes to make the item
    :earned_exp   => 500,          # Exp gained on success
    :crafted_item => [:i55, 1],    # Makes 1x Heavy Rod
    :failed_item  => [:i54, 1],    # 1x Fishing Pole
    :pre_failed   => [:i54, 1],    # 1x Fishing Pole
    :ingredients  => [# Fishing Pole,  1x Bamboo,  1x Twine
                     [:i53, 1], [:i57, 1], [:i58, 1],
    ]} # <- DO NOT REMOVE
#===============================================================================
# ■ Notetag settings. Skip edits here unless you know what you're doing
#===============================================================================
end; end
module Venka::Notetag
  Tool = /<(?:TOOL|tool)>/i
end
