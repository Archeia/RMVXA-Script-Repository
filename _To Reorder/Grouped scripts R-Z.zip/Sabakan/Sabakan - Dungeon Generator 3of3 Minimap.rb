#==============================================================================
# â–  Dungeon Creation 6 (Minimap)
#   @version 0.14 12/01/21 RGSS3
#   @author Saba Kan
#   @translator kirinelf
#------------------------------------------------------------------------------
# ã€€
#==============================================================================
module Saba
 module Dungeon
   PLAYER_COLOR_ID = 9     # Color ID of player on Minimap.
   FOLLOWER_COLOR_ID = 1   # Color ID of followers on Minimap.
 end
end

#=========================================================================
# Do not edit anything under this line unless you know what you're doing!
#=========================================================================

class << DataManager
 #--------------------------------------------------------------------------
 # â— å„ç¨®ã‚²ãƒ¼ãƒ ã‚ªãƒ–ã‚¸ã‚§ã‚¯ãƒˆã®ä½œæˆ
 #--------------------------------------------------------------------------
 alias saba_minimap_create_game_objects create_game_objects
 def create_game_objects
   saba_minimap_create_game_objects
   $game_minimap = Game_MiniMap.new
 end
 #--------------------------------------------------------------------------
 # â— ã‚»ãƒ¼ãƒ–å†…å®¹ã®ä½œæˆ
 #--------------------------------------------------------------------------
 alias saba_minimap_make_save_contents make_save_contents
 def make_save_contents
   contents = saba_minimap_make_save_contents
   contents[:minimap] = $game_minimap
   contents
 end
 #--------------------------------------------------------------------------
 # â— ã‚»ãƒ¼ãƒ–å†…å®¹ã®å±•é–‹
 #--------------------------------------------------------------------------
 alias saba_minimap_extract_save_contents extract_save_contents
 def extract_save_contents(contents)
   saba_minimap_extract_save_contents(contents)
   $game_minimap        = contents[:minimap]
 end
end

class Game_Map
 #--------------------------------------------------------------------------
 # â— ã‚»ãƒƒãƒˆã‚¢ãƒƒãƒ—
 #     map_id : ãƒžãƒƒãƒ— ID
 #--------------------------------------------------------------------------
 alias saba_minmap_setup setup
 def setup(map_id)
   saba_minmap_setup(map_id)
   if dungeon?
     $game_minimap.setup(self) 
   end
 end
 #--------------------------------------------------------------------------
 # â— æŒ‡å®šã®åº§æ¨™ã‚’ãƒžãƒƒãƒ”ãƒ³ã‚°
 #--------------------------------------------------------------------------
 def mapping(x, y)
   return unless floor?(x, y)
   for rect in @rect_list
     if rect.room.contains(x, y)
       $game_player.room = rect.room
       $game_minimap.mapping_room(rect.room)
       return
     end
   end
   $game_player.room = nil
   $game_minimap.mapping(x, y)
 end
end

class Game_MiniMap
 BLANK = 0   # ç©ºããƒžãƒƒãƒ—
 FLOOR = 1   # åºŠ
 WALL  = 2   # å£
 PASSAGE = 3 # é€šè·¯
 attr_accessor :changed_area
 attr_accessor :cleared
 attr_reader :events
 #--------------------------------------------------------------------------
 # â— ã‚ªãƒ–ã‚¸ã‚§ã‚¯ãƒˆåˆæœŸåŒ–
 #--------------------------------------------------------------------------
 def initialize
   @map_data = {}
   @events = []
 end
 #--------------------------------------------------------------------------
 # â— ãƒžãƒƒãƒ—æƒ…å ±ã‚’åˆæœŸåŒ–
 #--------------------------------------------------------------------------
 def setup(map)
   clear
   for x in 0..map.width
     for y in 0..map.height
       @map_data[[x, y]] = BLANK
     end
   end
 end
 #--------------------------------------------------------------------------
 # â— ãƒžãƒƒãƒ”ãƒ³ã‚°ã•ã‚Œã¦ã„ã‚‹ã‹ï¼Ÿ
 #--------------------------------------------------------------------------
 def mapping?(x, y)
   return @map_data[[x, y]] != BLANK
 end
 def floor_type(x, y)
   return @map_data[[x, y]]
 end
 #--------------------------------------------------------------------------
 # â— éƒ¨å±‹ã‚’ãƒžãƒƒãƒ”ãƒ³ã‚°
 #--------------------------------------------------------------------------
 def mapping_room(room)
   return if room.mapping
   room.mapping = true
   for x in room.lx...room.hx
     for y in room.ly...room.hy
       @map_data[[x, y]] = FLOOR
     end
   end
   mapping_edge(room)
   @changed_area = Rect.new(room.lx-1, room.ly-1, room.width+1, room.height+1)
 end
 #--------------------------------------------------------------------------
 # â— éƒ¨å±‹ã®å¤–å´ã‚’ãƒžãƒƒãƒ”ãƒ³ã‚°
 #--------------------------------------------------------------------------
 def mapping_edge(room)
   for x in (room.lx-1)...(room.hx+1)
     mapping_internal(x, room.ly-1)
     mapping_internal(x, room.hy)
   end
   for y in (room.ly)...(room.hy)
     mapping_internal(room.lx-1, y)
     mapping_internal(room.hx, y)
   end
 end
 #--------------------------------------------------------------------------
 # â— é“ã‚’ãƒžãƒƒãƒ”ãƒ³ã‚°
 #--------------------------------------------------------------------------
 def mapping(x, y)
   mapping_internal(x, y)
   mapping_internal(x-1, y)
   mapping_internal(x+1, y)
   mapping_internal(x, y-1)
   mapping_internal(x, y+1)
   mapping_internal(x-1, y-1)
   mapping_internal(x+1, y-1)
   mapping_internal(x-1, y+1)
   mapping_internal(x+1, y+1)
   @changed_area = Rect.new(x-1, y-1, 3, 3)
 end
 #--------------------------------------------------------------------------
 # â— é“ã‚’ãƒžãƒƒãƒ”ãƒ³ã‚°
 #--------------------------------------------------------------------------
 def mapping_internal(x, y)
   return if mapping?(x, y)
   if $game_map.floor?(x, y)
     @map_data[[x, y]] = PASSAGE
   else
     @map_data[[x, y]] = WALL
   end
 end
 def add_event(event)
   @events.push(event)
 end
 #--------------------------------------------------------------------------
 # â— ã‚¯ãƒªã‚¢
 #--------------------------------------------------------------------------
 def clear
   @cleared = true
   @map_data = {}
   @events = []
 end
end

class Game_Player
 attr_accessor :room
 #--------------------------------------------------------------------------
 # â— æŒ‡å®šä½ç½®ã«ç§»å‹•
 #--------------------------------------------------------------------------
 alias saba_minimap_moveto moveto
 def moveto(x, y)
   saba_minimap_moveto(x, y)
   $game_map.mapping(x, y)
 end
 #--------------------------------------------------------------------------
 # â— æ­©æ•°å¢—åŠ 
 #--------------------------------------------------------------------------
 alias saba_minimap_increase_steps increase_steps
 def increase_steps
   saba_minimap_increase_steps
   $game_map.mapping(self.x, self.y)
 end
end


class Sprite_MiniMap < Sprite_Base
 #--------------------------------------------------------------------------
 # â— å®šæ•°
 #--------------------------------------------------------------------------
 SQUARE_SIZE = 5 
 FLOOR_COLOR   = Color.new(70, 70, 180, 170)
 PASSAGE_COLOR = Color.new(160, 80, 160, 170)
 WALL_COLOR    = Color.new(200, 200, 200, 0)
 #--------------------------------------------------------------------------
 # â— ã‚ªãƒ–ã‚¸ã‚§ã‚¯ãƒˆåˆæœŸåŒ–
 #     viewport  : ãƒ“ãƒ¥ãƒ¼ãƒãƒ¼ãƒˆ
 #--------------------------------------------------------------------------
 def initialize(viewport)
   super(viewport)
   @windowskin = Cache.system("Window")
   @event_sprites = {}
   create_bitmap
   update_position
   redraw_all
   @follower_sprites = {}
   if $game_player.followers.visible
     for follower in $game_player.followers
       @follower_sprites[follower] = create_character_sprite(Saba::Dungeon::FOLLOWER_COLOR_ID)
     end
   end
   @player_sprite = create_character_sprite(Saba::Dungeon::PLAYER_COLOR_ID)

   update
 end
 #--------------------------------------------------------------------------
 # â— æ–‡å­—è‰²å–å¾—
 #     n : æ–‡å­—è‰²ç•ªå·ï¼ˆ0..31ï¼‰
 #--------------------------------------------------------------------------
 def text_color(n)
   @windowskin.get_pixel(64 + (n % 8) * 8, 96 + (n / 8) * 8)
 end
 #--------------------------------------------------------------------------
 # â— ã‚­ãƒ£ãƒ©ã‚¯ã‚¿ãƒ¼ç”¨ãƒ“ãƒƒãƒˆãƒžãƒƒãƒ—ã®ä½œæˆ
 #--------------------------------------------------------------------------
 def create_character_sprite(color)
   if color >= 1000
     hole = true
     color -= 1000
   end
   if color >= 100
     static = true
     color -= 100
   end

   sprite_color = text_color(color) if color != 0
   return Sprite_MiniMap_Character.new(viewport, sprite_color, static, hole)
 end
 #--------------------------------------------------------------------------
 # â— ãƒ“ãƒƒãƒˆãƒžãƒƒãƒ—ã®ä½œæˆ
 #--------------------------------------------------------------------------
 def create_bitmap
   self.bitmap = Bitmap.new(Graphics.width, Graphics.height)
   self.bitmap.font.size = 32
   self.bitmap.font.color.set(255, 255, 255)
 end
 #--------------------------------------------------------------------------
 # â— åº§æ¨™ã®æ›´æ–°
 #--------------------------------------------------------------------------
 def update_position
   self.x = (Graphics.width - SQUARE_SIZE * $game_map.width) / 2
   self.y = (Graphics.height - SQUARE_SIZE * $game_map.height) / 2
 end
 #--------------------------------------------------------------------------
 # â— è»¢é€å…ƒãƒ“ãƒƒãƒˆãƒžãƒƒãƒ—ã®æ›´æ–°
 #--------------------------------------------------------------------------
 def update_bitmap
   rect = $game_minimap.changed_area
   return unless rect
   $game_minimap.changed_area = nil
   for x in rect.x..(rect.width + rect.x)
     for y in rect.y..(rect.height + rect.y)
       case $game_minimap.floor_type(x, y)
       when Game_MiniMap::FLOOR then
         color = FLOOR_COLOR
       when Game_MiniMap::WALL then
         color = WALL_COLOR
       when Game_MiniMap::PASSAGE then
         color = PASSAGE_COLOR
       else
         next
       end
       self.bitmap.fill_rect(x*SQUARE_SIZE, y*SQUARE_SIZE, SQUARE_SIZE, SQUARE_SIZE, color)
     end
   end
 end

 def redraw_all
   self.bitmap.clear
   for x in 0..$game_map.width
     for y in 0..$game_map.height
       case $game_minimap.floor_type(x, y)
       when Game_MiniMap::FLOOR then
         color = FLOOR_COLOR
       when Game_MiniMap::PASSAGE then
         color = PASSAGE_COLOR
       when Game_MiniMap::WALL then
         color = WALL_COLOR
       else
         next
       end
       self.bitmap.fill_rect(x*SQUARE_SIZE, y*SQUARE_SIZE, SQUARE_SIZE, SQUARE_SIZE, color)
     end
   end
 end
 #--------------------------------------------------------------------------
 # â— ãƒ•ãƒ¬ãƒ¼ãƒ æ›´æ–°
 #--------------------------------------------------------------------------
 def update
   super
   clear if $game_minimap.cleared
   update_bitmap if $game_minimap.changed_area
   update_visibility
   update_player
   update_events
 end
 #--------------------------------------------------------------------------
 # â— å¯è¦–çŠ¶æ…‹ã®æ›´æ–°
 #--------------------------------------------------------------------------
 def update_visibility
   #self.visible = $game_timer.working?
 end
 #--------------------------------------------------------------------------
 # â— ãƒ—ãƒ¬ã‚¤ãƒ¤ãƒ¼ã®æ›´æ–°
 #--------------------------------------------------------------------------
 def update_player
   @player_sprite.x = self.x + $game_player.x * SQUARE_SIZE
   @player_sprite.y = self.y + $game_player.y * SQUARE_SIZE

   return unless $game_player.followers.visible
   for follower in $game_player.followers
     sprite = @follower_sprites[follower] 
     sprite.x = self.x + follower.x * SQUARE_SIZE
     sprite.y = self.y + follower.y * SQUARE_SIZE
   end
 end
 #--------------------------------------------------------------------------
 # â— å…¨ã‚¤ãƒ™ãƒ³ãƒˆã®æ›´æ–°
 #--------------------------------------------------------------------------
 def update_events
   for event in $game_map.events.values
     if event.erased
       sprite = @event_sprites[event.event_id]
       if sprite
         sprite.dispose
         @event_sprites.delete(event.event_id)
       end
       $game_map.events.delete(event.event_id)
       next
     end
     update_event(event)
   end
 end
 #--------------------------------------------------------------------------
 # â— ã‚¤ãƒ™ãƒ³ãƒˆã®æ›´æ–°
 #--------------------------------------------------------------------------
 def update_event(event)
   if @event_sprites[event.event_id]
     sprite = @event_sprites[event.event_id]
   else
     sprite = create_character_sprite(event.name.to_i)
     @event_sprites[event.event_id] = sprite
   end
   if sprite.static
     sprite.visible = $game_minimap.mapping?(event.x, event.y)
   else
     sprite.visible = false
     if $game_player.room
       sprite.visible = $game_player.room.contains(event.x, event.y)
     end
     sprite.visible |= $game_player.distance(event) == 1
     sprite.visible = true if Saba::Dungeon::DEBUG_MODE
   end
   sprite.x = self.x + event.x * SQUARE_SIZE
   sprite.y = self.y + event.y * SQUARE_SIZE
 end
 def next_enemy_sprite
   unless @spare_enemy_sprites.empty?
     return @spare_enemy_sprites.pop
   else
     return create_character_sprite(true)
   end
 end
 #--------------------------------------------------------------------------
 # â— ã‚¯ãƒªã‚¢
 #--------------------------------------------------------------------------
 def clear
   self.bitmap.clear
   update_position
   @event_sprites.values.each {|s| s.dispose }
   @event_sprites = {}
   $game_minimap.cleared = false
 end
 #--------------------------------------------------------------------------
 # â— è§£æ”¾
 #--------------------------------------------------------------------------
 def dispose
   self.bitmap.dispose
   @player_sprite.bitmap.dispose
   @player_sprite.dispose
   for sprite in @event_sprites.values
     sprite.dispose
   end
   for sprite in @follower_sprites.values
     sprite.dispose
   end
   super
 end
 def visible=(value)
   return if visible == value
   super
   @player_sprite.visible = value
   for sprite in @follower_sprites.values
     sprite.visible = value
   end
   for sprite in @event_sprites.values
     sprite.visible = value
   end
 end
end

class Sprite_MiniMap_Character < Sprite_Base
 attr_reader :static
 #--------------------------------------------------------------------------
 # â— ã‚ªãƒ–ã‚¸ã‚§ã‚¯ãƒˆåˆæœŸåŒ–
 #     viewport  : ãƒ“ãƒ¥ãƒ¼ãƒãƒ¼ãƒˆ
 #--------------------------------------------------------------------------
 def initialize(viewport, color, static, hole)
   super(viewport)
   @alive = true
   @color = color
   @static = static
   @hole = hole
   if @color

     create_bitmap
     update
   else   
     self.visible = false

   end
 end
 #--------------------------------------------------------------------------
 # â— ãƒ“ãƒƒãƒˆãƒžãƒƒãƒ—ã®ä½œæˆ
 #--------------------------------------------------------------------------
 def create_bitmap
   size = Sprite_MiniMap::SQUARE_SIZE
   self.bitmap = Bitmap.new(size, size)
   if @hole
     self.bitmap.fill_rect(0, 0, size, 1, @color)
     self.bitmap.fill_rect(0, size-1, size, 1, @color)
     self.bitmap.fill_rect(0, 1, 1, size-2, @color)
     self.bitmap.fill_rect(size-1, 1, 1, size-2, @color)
   else
     self.bitmap.fill_rect(0, 0, size, size, @color)
   end
 end
 #--------------------------------------------------------------------------
 # â— è§£æ”¾
 #--------------------------------------------------------------------------
 def dispose
   self.bitmap.dispose if self.bitmap
   super
 end
end

class Spriteset_Map
 attr_reader :character_sprites
 #--------------------------------------------------------------------------
 # â— ã‚ªãƒ–ã‚¸ã‚§ã‚¯ãƒˆåˆæœŸåŒ–
 #--------------------------------------------------------------------------
 alias saba_minimap_initialize initialize
 def initialize
   saba_minimap_initialize

   @mini_map = Sprite_MiniMap.new(@viewport2)
   if $game_map.dungeon?
     update
   else
     @mini_map.visible = false
   end
 end
 #--------------------------------------------------------------------------
 # â— è§£æ”¾
 #--------------------------------------------------------------------------
 alias saba_minimap_dispose dispose
 def dispose
   saba_minimap_dispose
   @mini_map.dispose if @mini_map
 end
 #--------------------------------------------------------------------------
 # â— ãƒ•ãƒ¬ãƒ¼ãƒ æ›´æ–°
 #--------------------------------------------------------------------------
 alias saba_minimap_update update
 def update
   saba_minimap_update
   return unless @mini_map
   if $game_map.dungeon?
     @mini_map.visible = true
     @mini_map.update
   else
     @mini_map.visible = false
   end
 end
 #--------------------------------------------------------------------------
 # â— ã‚¯ãƒªã‚¢
 #--------------------------------------------------------------------------
 def clear_minimap
   @mini_map.clear
 end
end