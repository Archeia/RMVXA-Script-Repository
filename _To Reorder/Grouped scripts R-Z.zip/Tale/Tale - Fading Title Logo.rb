#encoding:utf-8
 
=begin
*******************************************************************************************
   ＊ Fading Title Logo ＊
                       for RGSS3
        Ver 1.00   2014.04.16
   Author：魂(Lctseng)，Bahamut Forum ID：play123
   The original text published in: Bahamut RPG master Hara version
   Based on a script originally written by "william6k(KLL)"
   
   Instructions:
   To use your own logo, place an image file named "logo"
   in your project folder > "Graphics" > inside "System"
 
   Please keep this label reprinted
   Home link：http://home.gamer.com.tw/homeindex.php?owner=play123
   Description：
                       On the title screen, logo will fade in & out.
   Update log：
    Ver 1.00 ：
    Date：2014.04.16
    Summary：First version released
                Second version、summary：                  
                       First, title screen logo fades with dynamic layer
    Function, this script modifies or redefines the following categories：
                           1. Scene_Title
                           
                           
                        Second, this script provides a set of modules：
                          1.Lctseng::Flash_Title
                           
                         
*******************************************************************************************
=end
 
#==============================================================================
# ■ Lctseng::Flash_Title
#------------------------------------------------------------------------------
# 　Fading layer title setting module
#==============================================================================
module Lctseng
module Flash_Title
  #--------------------------------------------------------------------------
  # ● Fade time setting
  #--------------------------------------------------------------------------
  # Fade in time
  TITLE_FADEIN_TIME = 150
  # Fade out time
  TITLE_FADEOUT_TIME = 150
  #--------------------------------------------------------------------------
  # ● Fade speed setting
  #--------------------------------------------------------------------------
  # Logo fade in
  TITLE_FADEIN_SPEED = 5
  # Logo fade out
  TITLE_FADEOUT_SPEED = 2
  #--------------------------------------------------------------------------
  # ● Max & Min setting for fade, valid when fading
  #--------------------------------------------------------------------------
  # Fade in maximun opacity
  TITLE_MAX_FADEIN_OPACITY = 200
  # Fade out minimum opacity
  TITLE_MIN_FADEOUT_OPACITY = 50
  #--------------------------------------------------------------------------
  # ● Layers set，Z coordinate position
  #--------------------------------------------------------------------------
  # Z coordinate for fading layer
  TITLE_FLASH_Z = 50
  # Title logo Z coordinate
  TITLE_BACKGROUND_2_Z = 60
 
end
end
 
 
 
#*******************************************************************************************
#
#   DO NOT MODIFY UNLESS YOU KNOW WHAT TO DO !
#
#******************************************************************************************
 
 
 
#--------------------------------------------------------------------------
# ★ Script Information
#--------------------------------------------------------------------------
if !$lctseng_scripts  
  $lctseng_scripts = {}
end
$lctseng_scripts[:flashing_title] = "1.00"
 
puts "Load Script：Lctseng - Fading title logo：#{$lctseng_scripts[:flashing_title]}"
 
 
 
 
#encoding:utf-8
#==============================================================================
# ■ Scene_Title
#------------------------------------------------------------------------------
# 　Title Screen
#==============================================================================
 
class Scene_Title < Scene_Base
  #--------------------------------------------------------------------------
  # ● Setting Module
  #--------------------------------------------------------------------------
  include Lctseng::Flash_Title
  #--------------------------------------------------------------------------
  # ● Start Process - Redefinition
  #--------------------------------------------------------------------------
  alias lct_flashing_title_Scene_Base_start start
  #--------------------------------------------------------------------------
  def start(*args,&block)
    lct_flashing_title_Scene_Base_start(*args,&block)
    create_flashing_sprite
  end
  #--------------------------------------------------------------------------
  # ● Create Fade Manager
  #--------------------------------------------------------------------------
  def create_flashing_sprite
    @flash_sprite = Sprite.new
    @flash_sprite.bitmap = Cache.system("logo")
    @flash_sprite.z = TITLE_FLASH_Z
    @flash_sprite.opacity = 0
    @flash_count = TITLE_FADEIN_TIME + TITLE_FADEOUT_TIME
    center_sprite(@flash_sprite)
    @sprite2.z = TITLE_BACKGROUND_2_Z # Overwrite second layer header picture
  end
  #--------------------------------------------------------------------------
  # ● End Process - Redefinition
  #--------------------------------------------------------------------------
  alias lct_flashing_title_Scene_Base_terminate terminate
  #--------------------------------------------------------------------------
  def terminate(*args,&block)
    lct_flashing_title_Scene_Base_terminate(*args,&block)
    dispose_flashing_sprite
  end
  #--------------------------------------------------------------------------
  # ● Release Fade
  #--------------------------------------------------------------------------
  def dispose_flashing_sprite
    @flash_sprite.bitmap.dispose
    @flash_sprite.dispose
  end
  #--------------------------------------------------------------------------
  # ● Update Screen (basic)
  #--------------------------------------------------------------------------
  def update_basic
    super
    update_flashing_sprite
  end
  #--------------------------------------------------------------------------
  # ● Update Fade
  #--------------------------------------------------------------------------
  def update_flashing_sprite
    if @flash_count > TITLE_FADEOUT_TIME
      @flash_sprite.opacity += TITLE_FADEIN_SPEED
      if @flash_sprite.opacity > TITLE_MAX_FADEIN_OPACITY
        @flash_sprite.opacity = TITLE_MAX_FADEIN_OPACITY
      end
      @flash_count -= 1
    elsif @flash_count <= 0
      @flash_sprite.opacity = TITLE_MIN_FADEOUT_OPACITY
      @flash_count = TITLE_FADEIN_TIME + TITLE_FADEOUT_TIME
    else
      @flash_sprite.opacity -= TITLE_FADEOUT_SPEED
      @flash_count -= 1
      if @flash_sprite.opacity < TITLE_MIN_FADEOUT_OPACITY
        @flash_sprite.opacity = TITLE_MIN_FADEOUT_OPACITY
      end
 
 
    end
   
  end
end