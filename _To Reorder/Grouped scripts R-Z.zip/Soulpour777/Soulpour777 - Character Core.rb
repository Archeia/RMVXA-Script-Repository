# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
# Soul Character Core
# By: SoulPour777
# Web URL: infinitytears.wordpress.com
# Date Started: February 8, 2014, 10:39PM
# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
# Description:
# This is the core script that handles all configuration for Actor / Characters
# for the Soul Engine Ace.
# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
# Version History:
# Version 1 - Handles the Will_System
# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
# Instruction for Use:
# 1. Place this script on top of all other Character Related Scripts of S.E.A.
# 2. This script should be below Materials above Main.
# 3. Look for each module sections for the individual use and script 
# instructions on how to use the Core Script or Adjust the values of all methods
# and scripts involved.
# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
# All Soul Engine Ace scripts are bound by my Terms of Use.
# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
# Please preserve this script header.
# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
$imported = {} if $imported.nil?
$imported["Soul_Character_Core"] = true
module Soul_Character_Core
  
  #-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  # WILL SYSTEM
  # Description: This holds the variables that is used by the Will System.
  #-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  
  module BattleWillEffect
    VALOR_CHANCE = 1
    $valor_chance = 0
    VALOR_MESSAGE = "You must not surrender! The Power of Valor revives you!" 
  end
  
  
  module Will_System
    # ~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=
    # Configure Note Tags for Each Master Will Here:
    # ~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=
    RWOLF_WILL= "<Haste>"
    STOLL_WILL = "<Filch>"
    UNA_WILL = "<Wild>"
    MARLOK_WILL = "<Greed>"
    NJOMO_WILL = "<Pique>"
    MOMO_WILL = "<Drowse>"
    ABESS_WILL = "<Reck>"
    KYRIK_WILL = "<Finale>"
    LYTA_WILL = "<Guard>"
    GYOSIL_WILL = "<Ward>"
    BUNYAN_WILL = "<Vision>"
    KAHN_WILL = "<Valor>"
    
    # -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    # Parameter ID and Configuration Guide
    # Do not touch this section!
    # -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    # Command: add_param - Add Parameter
    # Command: add_sparam - Add SParameter
    # Command: add_xparam - Add XParameter
    # -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    #~   dmhp; param(0);                  # MHP  Maximum Hit Points
    DMHP = 0
    #~   mmp;  param(1);                  # MMP  Maximum Magic Points
    MMP = 1
    #~   atk;  param(2);                  # ATK  ATtacK power
    ATK = 2
    #~   def;  param(3);                  # DEF  DEFense power
    DEF = 3
    #~   mat;  param(4);                  # MAT  Magic ATtack power
    MAT = 4
    #~   mdf;  param(5);                  # MDF  Magic DeFense power
    MDF = 5
    #~   agi;  param(6);                  # AGI  AGIlity
    AGI = 6
    #~   luk;  param(7);                  # LUK  LUcK
    LUK = 7
    #~   hit;  xparam(0);                 # HIT  HIT rate
    HIT = 7
    #~   eva;  xparam(1);                 # EVA  EVAsion rate
    EVA = 1
    #~   cri;  xparam(2);                 # CRI  CRItical rate
    CRI = 2
    #~   cev;  xparam(3);                 # CEV  Critical EVasion rate
    CEV = 3
    #~   mev;  xparam(4);                 # MEV  Magic EVasion rate
    MEV = 4
    #~   mrf;  xparam(5);                 # MRF  Magic ReFlection rate
    MRF = 5
    #~   cnt;  xparam(6);                 # CNT  CouNTer attack rate
    CNT = 6
    #~   hrg;  xparam(7);                 # HRG  Hp ReGeneration rate
    HRG = 7
    #~   mrg;  xparam(8);                 # MRG  Mp ReGeneration rate
    MRG = 8
    #~   trg;  xparam(9);                 # TRG  Tp ReGeneration rate
    TRG = 9
    #~   tgr;  sparam(0);                 # TGR  TarGet Rate
    TGR = 0
    #~   grd;  sparam(1);                 # GRD  GuaRD effect rate
    GRD = 1
    #~   rec;  sparam(2);                 # REC  RECovery effect rate
    REC = 2
    #~   pha;  sparam(3);                 # PHA  PHArmacology
    PHA = 3
    #~   mcr;  sparam(4);                 # MCR  Mp Cost Rate
    MCR = 4
    #~   tcr;  sparam(5);                 # TCR  Tp Charge Rate
    TCR = 5
    #~   pdr;  sparam(6);                 # PDR  Physical Damage Rate
    PDR = 6
    #~   mdr;  sparam(7);                 # MDR  Magical Damage Rate
    MDR = 7
    #~   fdr;  sparam(8);                 # FDR  Floor Damage Rate
    FDR = 8
    #~   exr;  sparam(9);                 # EXR  EXperience Rate   
    EXR = 9
    # -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=      
  
  # ---====---===---====---===---====---===---====---===---====---===---===
  # Each Variable for the Wills are handled by their first letter, first
  # two letters or their holder's first name letter.
  # _DEC means decrease.
  # E.g. VI_MAT_DEC = 2
  # ^ this is the value of the Magical Attack Decrease per Level Up Increase
  # ---====---===---====---===---====---===---====---===---====---===---===
    
  # -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= 
  # Will: Haste - Configuration (Rwolf - Kurok)
  # Haste - Increases speed in combat
  # -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= 
    H_MMP = 1 # Haste MP Bonus
    H_ATK = 1 # Haste Attack Nonus
    H_MAT = 1 # Haste Magical Attack Bonus
  # -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= 
  
  # -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= 
  # Will: Filch - Configuration (Stoll - Hideout)
  # Filch-Steal new items
  # -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= 
    F_AGI = 1
  # -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=  
  
  # -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= 
  # Will: Wild - Configuration (Una - Worent)
  # Wild - Higher damage, but lower chance to hit
  # -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= 
    W_DMHP = 12
    W_MMP_DEC = 2
    W_ATK = 2
    W_MAT_DEC = 1
  # -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=    
  
  # -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= 
  # Will: Pique - Configuration (Njomo - Ahm Fen)
  # Pique - All counters are critical hits
  # -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= 
    P_DMHP_DEC = 8
    P_MMP = 1
    P_AGI = 2
  # -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=    
  
  # -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= 
  # Will: Drowse - Configuration (Momo - Wyndia)
  # Drowse - ** All sleeping characters adds an MP regen state.
  # -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= 
    D_DMHP = 8
  # -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=    
  
  # -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= 
  # Will: Reck - Configuration (Abess - Check)
  # Adjust the amount of increase you want for each parameter.
  # -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= 
    R_ATK_DEC = 2
    R_MAT = 4
    R_MMP = 2
    R_DEF_DEC = 2
  # -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=     
  
  # -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= 
  # Will: Greed - Configuration (Marlok - Synesta)
  # Greed - increase the amount of money after battles
  # -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= 
    G_DMHP = 16
    G_MMP = 3
    G_ATK_DEC = 1
    G_MAT_DEC = 1
    G_DEF_DEC = 1
    G_AGI_DEC = 1
  # -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=     
  
  # -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= 
  # Will: Finale - Configuration (Kyrik - Sail)
  # Finale-Finish off weakened opponent
  # -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= 
    K_DMHP = 25
    K_ATK = 3
    K_DEF = 2
    K_MAT_DEC = 2
    K_MMP_DEC = 2
    K_AGI_DEC = 2
  # -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=   
  
  # -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= 
  # Will: Ward - Configuration (Gyosil - Lyp)
  # Ward - An item may not be used up when you use it in battle
  # -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= 
    WARD_DMHP_DEC = 8
    WARD_MMP = 2
  # -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=    
  
  # -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= 
  # Will: Guard - Configuration (Lyta - Synesta)
  # Guard - Protect other characters
  # -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= 
    GU_MAT = 2
    GU_MMP = 1
    GU_DEF_DEC = 1
  # -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=   
  
  # -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= 
  # Will: Valor - Configuration (Kahn - Saldine)
  # Valor - Revives Fallen Party Member
  # -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= 
    V_DMHP = 20
    V_ATK = 3
    V_MAT_DEC = 3
    V_MMP_DEC = 4
    V_AGI = 1
  # -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=   
  
  # -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= 
  # Will: Vision - Configuration (Bunyan - Yohm)
  # Vision - To-hit chance is 100%
  # -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= 
    VI_DMHP_DEC = 16
    VI_ATK = 3
    VI_MAT = 1
    VI_MMP = 3
    VI_DEF = 1
    VI_AGI = 1
  # -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=   

  end
  
end