# -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# VXA - Choice Setup Position
# ** Author: Soulpour777
# Version 1.0
# -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# Description:
# Choices are, well permanently positioned to the right side of the screen.
# However, sometimes you do not want this, and perhaps might want to put the
# choice on the center, on the top, down, left side, right side or whatever 
# side there is. This script does that.
# -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# Usage:
# Script Calls:
# $game_system.change_y_pos(y_pos)
# ^ changes the y position of the choice list, where y_pos is the number.
# $game_system.change_x_pos(x_pos)
# ^ changes the x position of the choice list, where x_pos is the number.
# $game_system.change_window_width(w_width)
# ^ changes the width of the choice list window, where w_width is the number.
# $game_system.change_choice_height(c_height)
# ^ changes the window height of the choice list, where c_height is the number.
# -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# Author's Notes:
# You can use this to position your choices. I am really annoyed with the 
# choice position of the default maker.
# -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

#==============================================================================
# ** Game_System
#------------------------------------------------------------------------------
#  This class handles system data. It saves the disable state of saving and 
# menus. Instances of this class are referenced by $game_system.
#==============================================================================

class Game_System
  #--------------------------------------------------------------------------
  # * Public Instance Variables
  #--------------------------------------------------------------------------  
  attr_accessor :choice_width
  attr_accessor :choice_window_width
  attr_accessor :mb_y_pos
  attr_accessor :mb_x_pos
  attr_accessor :choice_height

  #--------------------------------------------------------------------------
  # * Alias Listings
  #--------------------------------------------------------------------------  
  alias message_choice_initialize initialize
  
  #--------------------------------------------------------------------------
  # * Object Initialization
  #--------------------------------------------------------------------------  
  def initialize
    message_choice_initialize
    @choice_width = 320
    @choice_height = 20
    @mb_y_pos = 30
    @mb_x_pos = 0
    @choice_window_width = Graphics.width - @choice_width
  end
  
  #--------------------------------------------------------------------------
  # * Change Y Position
  #--------------------------------------------------------------------------  
  def change_y_pos(y_pos)
    @mb_y_pos = y_pos
  end
  
  #--------------------------------------------------------------------------
  # * Change X Position
  #--------------------------------------------------------------------------  
  def change_x_pos(x_pos)
    @mb_x_pos = x_pos
  end  
  
  #--------------------------------------------------------------------------
  # * Change Window Width
  #--------------------------------------------------------------------------  
  def change_window_width(w_width)
    @choice_window_width = w_width
  end
  
  #--------------------------------------------------------------------------
  # * Change Choice Height
  #--------------------------------------------------------------------------  
  def change_choice_height(c_height)
    @choice_height = c_height
  end
  
end


#==============================================================================
# ** Window_ChoiceList
#------------------------------------------------------------------------------
#  This window is used for the event command [Show Choices].
#==============================================================================

class Window_ChoiceList < Window_Command
  
  #--------------------------------------------------------------------------
  # * Update Window Position
  #--------------------------------------------------------------------------
  alias window_choice_update_placement update_placement
  def update_placement
    window_choice_update_placement
    self.width = $game_system.choice_window_width
    self.height - $game_system.choice_height
    self.x = $game_system.mb_x_pos
    self.y = $game_system.mb_y_pos
  end  
  
end 