#-------------------------------------------------------------------------------
# Soulpour777 - Animated Battlers
# Euphoria    - EDIT TO SCRIPT
# Script Date: 11:01AM, 6 / 14 / 2014
# Web URL: www.infinitytears.wordpress.com
# Credits and Special Thanks to:
# - Moghunter for the Original Script Idea
# - TheoAllen for the update_origin help and move sidewards fix
#-------------------------------------------------------------------------------
# Description:
# This script allows your enemy battlers to be animated during battle. The
# enemies would also be subjected to three different animated behaviors,
# either they BREATH, FLOAT, or MOVE SIDEWARDS. This is a revival of Moghunter's
# sweet script called Battler L effects, but made it much more appealing and
# compatible with the now popular RPG Maker VX Ace.
#-------------------------------------------------------------------------------
module Soulpour
  module AnimatedBattlers
    # ---------------------- <Editable Region> ------------------------------ #
    # You can edit anything from this module. On this module, if you place
    # the enemy's id inside the arrays, either from Breath, Float and Move Side,
    # it means that those enemies included on the array will have their own
    # respective behaviors (Float, Breath and Move Sidewards).
    # Any enemy id not listed or included inside the array will remain static.
    #------------------------<End of Editable Region>------------------------ #
    BREATH_SPEED = 2                       # Speed of the Enemy's Breathing
    BREATH_EFFECT_ENEMY_ID = [1, 2, 3, 7, 8, 9, 10, 11, 12, 13, 14, 15]  # List of Enemy IDs who Breath
    FLOAT_EFFECT_ENEMY_ID = [5]  # List of Enemy IDs who Float
    MOVESIDE_EFFECT_ENEMY_ID = [4, 6] # List of Enemy IDs who moves sidewards
    STATES_CANCEL_EFFECT = [7] # States Cancel Effect
  end
end
  
class Game_Battler < Game_BattlerBase
  include Soulpour::AnimatedBattlers
  #--------------------------------------------------------------------------
  # * Alias Listings
  # Aliased Methods: add_state(state_id), remove_state(state_id)
  #--------------------------------------------------------------------------  
  alias :soulpour_battlerex_add_state                           :add_state
  alias :soulpour_battlerex_remove_state                        :remove_state
  #--------------------------------------------------------------------------
  # * Add State
  #--------------------------------------------------------------------------
  def add_state(state_id)
    soulpour_battlerex_add_state(state_id)
    if self.is_a?(Game_Enemy)
      for i in STATES_CANCEL_EFFECT
        if @states.include?(i)
          @breath_effect = false
          @float_effect = false
          @moveside_effect = false
        end
      end
    end
  end
  #--------------------------------------------------------------------------
  # * Remove State
  #--------------------------------------------------------------------------
  def remove_state(state_id)
    soulpour_battlerex_remove_state(state_id)
     if self.is_a?(Game_Enemy)     
        sce = false
        for i in STATES_CANCEL_EFFECT 
            sce = true if @states.include?(i)
        end    
        if sce == false    
           @breath_effect = true if BREATH_EFFECT_ENEMY_ID.include?(@enemy_id) 
           @float_effect = true if FLOAT_EFFECT_ENEMY_ID.include?(@enemy_id) 
           @moveside_effect = true if MOVESIDE_EFFECT_ENEMY_ID.include?(@enemy_id)           
        end   
     end        
  end  
end

class Game_Enemy
  #--------------------------------------------------------------------------
  # * Included Modules
  #--------------------------------------------------------------------------  
  include Soulpour::AnimatedBattlers
  #--------------------------------------------------------------------------
  # * Public Instance Variables
  #--------------------------------------------------------------------------
  attr_accessor :breath_effect                  # Breath Effect
  attr_accessor :float_effect                   # Float Effect
  attr_accessor :moveside_effect                # Move Side Effect
  #--------------------------------------------------------------------------
  # * Alias Listings
  # Aliased Methods: initialize(index, enemy_id)
  #--------------------------------------------------------------------------  
  alias :soulpour_battlerex_initialize                            :initialize
  #--------------------------------------------------------------------------
  # * Object Initialization
  #--------------------------------------------------------------------------
  def initialize(index, enemy_id)
    soulpour_battlerex_initialize(index, enemy_id)
    @breath_effect = false
    @float_effect = false
    @moveside_effect = false
    @breath_effect = true if BREATH_EFFECT_ENEMY_ID.include?(@enemy_id) 
    @float_effect = true if FLOAT_EFFECT_ENEMY_ID.include?(@enemy_id) 
    @moveside_effect = true if MOVESIDE_EFFECT_ENEMY_ID.include?(@enemy_id)     
  end
end

class Sprite_Battler
   include Soulpour::AnimatedBattlers
   alias :soulpour_battlerex_initialize                           :initialize
   alias :soulpour_battlerex_update                               :update
   alias :soulpour_battlerex_update_origin                     :update_origin
  #--------------------------------------------------------------------------
  # * Object Initialization
  #--------------------------------------------------------------------------
  def initialize(viewport, battler = nil)
    soulpour_battlerex_initialize(viewport, battler)
    breath_effect_setup(battler) 
    float_effect_setup(battler) 
    modeside_effect_setup(battler) 
  end   
  
   #--------------------------------------------------------------------------
   # ● Moveside Effect
   #--------------------------------------------------------------------------                       
   def modeside_effect_setup(battler) 
       @ox_offset = 5
       @moveside_duration = rand(30)
       @moveside_speed = 0
   end  
   
   #--------------------------------------------------------------------------
   # ● Float Effect Setup
   #--------------------------------------------------------------------------                      
   def float_effect_setup(battler) 
       @float_duration = rand(40)
       @float_speed = rand(3)
   end
   
   #--------------------------------------------------------------------------
   # ● Breath Effect Setup
   #--------------------------------------------------------------------------                     
   def breath_effect_setup(battler) 
       @breath_phase = 0
       @breath_effect = false
       @breath_effect_speed = 0
       if @battler.is_a?(Game_Enemy) and @battler.breath_effect
          initial_breath = 1.00 + (@battler.screen_x * 0.001) - (@battler.screen_y * 0.001)     
          initial_breath = 1.1 if initial_breath > 1.1
          initial_breath = 0.9 if initial_breath < 0.9
          self.zoom_y = initial_breath
          ex_speed = [[BREATH_SPEED, 1].max, 9].min
          speed = ex_speed * 0.001
          @breath_effect_speed = speed + (rand(99) * 0.00001)
       end    
   end  
 
  #--------------------------------------------------------------------------
  # * Frame Update
  #--------------------------------------------------------------------------
  def update
    soulpour_battlerex_update
     if @battler.is_a?(Game_Enemy) 
        update_breath_effect
        update_float_effect
        update_move_side_effect
     end       
  end
  
  def update_move_side_effect
    return if @battler == nil
    return unless @battler.moveside_effect
    @moveside_speed += 1
    return if @moveside_speed < 4
    @moveside_speed = 0
    @moveside_duration += 1
    case @moveside_duration
      when 0..10
        @ox_offset += 2
      when 11..15
        @ox_offset += 1
      when 16..25
        @ox_offset -= 2
      when 26..30
        @ox_offset -= 1
      else  
        @moveside_duration = 0
    end
    update_ox
  end
    
  def update_ox
    self.ox = width/2 + @ox_offset
  end
  
  def update_oy
    self.oy = height
  end
  
   
  def update_origin
    return if battler.is_a?(Game_Enemy)
    soulpour_battlerex_update_origin
  end
  
   #--------------------------------------------------------------------------
   # ● Update Float Effect
   #--------------------------------------------------------------------------                  
   def update_float_effect
     update_ox
     update_oy    
       return if @battler == nil
       return unless @battler.float_effect
   #    @float_speed += 1
   #    return if @float_speed < 2
       @float_speed = 10
       @float_duration += 1
       case @float_duration
          when 0..15
            self.oy += 2
          when 16..20  
            self.oy += 2
          when 21..35
            self.oy -= 2
          when 36..40  
            self.oy -= 2
          else  
            @float_duration = 0
       end
   end
   
   #--------------------------------------------------------------------------
   # ● Update Breath Effect
   #--------------------------------------------------------------------------                 
   def update_breath_effect 
       update_ox
       update_oy    
       return if @battler == nil
       return unless @battler.breath_effect
       if @breath_effect_speed == 0   
          ex_speed = [[BREATH_SPEED, 1].max, 9].min
          speed = ex_speed * 0.001       
          @breath_effect_speed = speed + (rand(99) * 0.00001)
          self.zoom_y = 1 + rand(10) * 0.01
       end   
       if @breath_phase == 0
          self.zoom_y += @breath_effect_speed
          @breath_phase = 1 if self.zoom_y >= 1.05
       else
          self.zoom_y -= @breath_effect_speed
          @breath_phase = 0 if self.zoom_y <= 0.9
       end            
   end  
end