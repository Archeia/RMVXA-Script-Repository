# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

# Soul Battle Core
# Core Script for Battle for Soul Engine Ace
# By: SoulPour777
# Date Created: February 6, 2014 - 4:39PM

# Description: 
# This holds all modules and methods to handle all Battle Scripts of Soul
# Engine Ace. Without this, most of the scripts for Battle will not work.
# Place this on top of all SEA Battle Scripts.

# Version History:
# Version 01 - Created the Battle Cursor and Ported Battle Battlers
# Version 02 - Created the Soul_Battle_CommonEvents module
# Version 03 - Created the SoulVarBattle for Variable Battles

# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

$imported = {} if $imported.nil?
$imported["Soul_Battle_Core"] = true

module Soul_Battle_Core
  
# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
# Soul Allow Battlers
# This part holds all variables and image names for Actor Battlers Script.
# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

  module Soul_Allow_Battlers
    
  #==============================================================================
  # Start Of Configuration
  #==============================================================================
    # Actor battler array
    ACTOR_BATTLER = Array.new
    # ------------------ Positioning ------------------# 
      BATTLER_PLACE_ON_CENTER = true #Places the Battlers on the Center
      BATTLER_MAXIMUM_PARTY  = 5   # Default maximum number of party.
      BATTLER_VERTICAL_HEIGHT    = 400 # Vertical height of battlers
      BATTLER_TRANSPARENT_OPTION = true  # makes the battlers transparent before attacking option
   
   
    # ------------------ List of Actors ------------------# 
    # Actor Number      Filename,  Hue (optional)
    # The Battler Images should be inside the Battlers folder.
    # ------------------ Add Your Actors ------------------# 
      ACTOR_BATTLER[1] = ["Erin"]
      ACTOR_BATTLER[2] = ["Natalie"]
      ACTOR_BATTLER[3] = ["Terence"]
      ACTOR_BATTLER[4] = ["Ernest"]
      ACTOR_BATTLER[5] = ["Ryoma"]
      ACTOR_BATTLER[6] = ["Brenda"]
      ACTOR_BATTLER[7] = ["Rick"]
      ACTOR_BATTLER[8] = ["Maia"]
    # ------------------ ------------------#      

  end  
  
# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
# module State Requirements
# This part holds the functions for Skill State Req. Script.
# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  module State_Requirements
    
    def self.required_state(skill)
      case skill.id
        # -------------------------------------------
        # Configuration of Skills and States
        # Example: when 26 then return 2
        # This means that, in order for Skill ID#26 (Heal) to be used,
        # the user must be Poisoned (State ID #2)
        # -------------------------------------------
        
        #START EDITING HERE
        when 26 then return 2
        when 44 then return 13 # To cast Quick Move --> state Hide must be applied
        when 21 then return 17 # To use Bodyslam --> state Ironbody must be applied
      end
      return 
    end

  end    
  
# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
# Soul_Battle_CommonEvents
# This part holds the variables needed to run Battle Common Events script.
# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

  module Soul_Battle_CommonEvents
    #-=-=-=-=-=-=-=-=-=-=-=-=-=-=-==
    # Add Configuration Here:
    #-=-=-=-=-=-=-=-=-=-=-=-=-=-=-==
      COMMON_EVENT_ON_BATLLE_ID = 1 #Common Event ID of running common event
      #during battle
      COMMAND_NAME = "Advantage" #Name of Command
  end

# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
# Soul_Variable_Battle
# This part holds the variables and some functions for the Variable Battle Script.
# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
# Script Call:
# Soul_Variable_Battle.pk_battle
# ^ This will initiate a random troop battle.
# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

  module SoulVarBattle
    ENEMIES_ON_BATTLE = [1,2,3,4,5,6,7,8,9,10] #enemy id of all killers / crime busters
    ENEM_COUNTER = rand(ENEMIES_ON_BATTLE.size)
    
    #--------------------------------------------------------------------------
    # * Battle
    #--------------------------------------------------------------------------  
    def self.pk_battle
        BattleManager.setup(ENEMIES_ON_BATTLE[ENEM_COUNTER], true, true)
        BattleManager.save_bgm_and_bgs #This is the method used for saving the map's BGM and BGS
        $game_player.make_encounter_count
        SceneManager.call(Scene_Battle)
    end
      
  end
  
# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
# Advanced Calculations
# This module holds all variables involving Damage Calculations in Battle.
# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

  module AdvancedCalculations
    OVERKILL_CRITICAL = [50, 150, 250, 350, 450] #Overkill Damage on Critical
    OVERKILL_CHANCE = rand(100) #Chance of Having an Overkill
    OVERKILL_OK = 75
  end
  

  
# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
# SoulBattleCursor
# This module holds the functions for the Battle Cursor Script.
# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

  module SoulBattleCursor
    CURSOR_POSITION = [-45, -90]
    CURSOR_NAME_POSITION = [-10, 35]
    CURSOR_Z = 0    
    
    def check_index_limit
        self.index = 0 if self.index >= item_max
        self.index = (item_max - 1) if self.index < 0
    end      
  
    #--------------------------------------------------------------------------
    # ? Set Cursor Position Enemy
    #--------------------------------------------------------------------------    
    def set_cursor_position_enemy
        return if !self.active
        $game_temp.battle_cursor[0] = $game_troop.alive_members[self.index].screen_x + CURSOR_POSITION[0] rescue nil
        $game_temp.battle_cursor[1] = $game_troop.alive_members[self.index].screen_y + CURSOR_POSITION[1] rescue nil
        $game_temp.battle_cursor[3] = $game_troop.alive_members[self.index].name rescue nil
        $game_temp.battle_cursor = [0,0,false,0] if $game_temp.battle_cursor[0] == nil
    end
    
    #--------------------------------------------------------------------------
    # ? Set Cursor Position Actor
    #--------------------------------------------------------------------------    
    def set_cursor_position_actor
        return if !self.active
        $game_temp.battle_cursor[0] = $game_party.members[self.index].screen_x + CURSOR_POSITION[0] rescue nil
        $game_temp.battle_cursor[1] = $game_party.members[self.index].screen_y + CURSOR_POSITION[1] rescue nil
        $game_temp.battle_cursor[3] = $game_party.members[self.index].name rescue nil
        $game_temp.battle_cursor = [0,0,false,0] if $game_temp.battle_cursor[0] == nil
    end  
    
    #--------------------------------------------------------------------------
    # ? Process Cursor Move
    #--------------------------------------------------------------------------
    def process_cursor_move
        return unless cursor_movable?
        last_index = @index
        cursor_move_index(+1) if Input.repeat?(:DOWN)
        cursor_move_index(-1) if Input.repeat?(:UP)
        cursor_move_index(+1) if Input.repeat?(:RIGHT)
        cursor_move_index(-1) if Input.repeat?(:LEFT)
        if @index != last_index
           Sound.play_cursor
        end
    end

    #--------------------------------------------------------------------------
    # ? Process Cursor Move Index
    #--------------------------------------------------------------------------  
    def cursor_move_index(value = 0)
        self.index += value
        check_index_limit
    end
    
  end
    
end