# -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# Soul Engine Ace - Vampiric and Siphonic Traits
# Author: Soulpour777
# Version 1.0
# Script Type: Battle Add On
# -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# Description: This script allows the developer to add a Vampiric and Siphonic
# Traits to Weapons and Enemies. A Vampiric Trait allows the Vampiric Weapon or
# Enemy to absorb a percentage of HP from the target which is indicated in the
# notebox of the weapon. A Siphonic Trait allows any Siphonic Weapon User /
# Enemy to absorb a target's MP.
# -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# Terms of Use:
# -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# For Non-Commercial Use:
# -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# You are free to use the script on any non-commercial projects.
# You are free to adapt the script. Any modifications are allowed as long 
# as it is provided as a note on the script.
# Credits to SoulPour777 for the script.
# Preserve the Script Header.
# Claiming the script as your own is prohibited.
# -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# INSTRUCTIONS
# -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# For Vampiric Weapons / Enemies, place a note tag on your Weapon / Enemy
# with <vampiric: n%>
# where n is the percentage of value you want to let the trait absorb.
# Example: <vampiric: 90%>
# For Siphonic Weapons / Enemies, place a note tag on your Weapon / Enemy with
# <siphonic: n>
# where n is the direct value you want to let the trait absorb.
# -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

#==============================================================================
# ** Game_Battler
#------------------------------------------------------------------------------
#  A battler class with methods for sprites and actions added. This class 
# is used as a super class of the Game_Actor class and Game_Enemy class.
#==============================================================================

imported = {} if $imported.nil?
$imported["SEA - Vampiric States"] = true

class Game_Battler < Game_BattlerBase
  #--------------------------------------------------------------------------
  # * Clear Actions
  #--------------------------------------------------------------------------
  alias soulpour_clear_actions_vampiric_siphonic clear_actions
  def clear_actions
    soulpour_clear_actions_vampiric_siphonic
    @vampiric = 0
    @siphonic = 0
  end
  
  #--------------------------------------------------------------------------
  # * Calculate Damage
  #--------------------------------------------------------------------------
  alias soulpour_make_damage_value_vampiric_siphonic make_damage_value
  def make_damage_value(user, item)
    soulpour_make_damage_value_vampiric_siphonic(user, item)
    return unless item.physical?
     @vampiric = [@result.hp_damage * user.vampiric_rate / 100, self.hp].min
     @result.mp_damage += user.siphonic_rate
     @siphonic = [@result.mp_damage, self.mp, user.siphonic_rate].min
  end  
  
  #--------------------------------------------------------------------------
  # * Apply Normal Attack Effects
  #--------------------------------------------------------------------------
  alias attack_apply_vampiric_siphonic attack_apply
  def attack_apply(attacker)
    attack_apply_vampiric_siphonic(attacker)
    @vampiric = [@result.hp_damage * attacker.vampiric_rate / 100, self.hp].min
    @result.mp_damage += attacker.siphonic_rate
    @siphonic = [@result.mp_damage, self.mp, attacker.siphonic_rate].min    
  end  
  
  #--------------------------------------------------------------------------
  # * Damage Processing
  #    @result.hp_damage @result.mp_damage @result.hp_drain
  #    @result.mp_drain must be set before call.
  #--------------------------------------------------------------------------
  alias soulpour_execute_damage_vampiric_siphonic execute_damage
  def execute_damage(user)
    soulpour_execute_damage_vampiric_siphonic(user)
    if @vampiric > 0
      $game_troop.screen.start_flash(Color.new(255,0,0,160), 20)
      user.hp += @vampiric 
    end
    if @siphonic > 0
      user.mp += @siphonic 
      $game_troop.screen.start_flash(Color.new(0,0,255,160), 20)
    end
  end  
  
end


class RPG::Weapon < RPG::EquipItem
  #--------------------------------------------------------------------------
  # * Vampiric
  #--------------------------------------------------------------------------
  def vampiric
    return @vampiric if @vampiric != nil
    @vampiric = 0
    self.note.split(/[\r\n]+/).each { |line|
      case line
      when /<(?:VAMPIRIC|vampire):[ ]*(\d+)([%%])>/i
        @vampiric = $1.to_i
      end
    }
    return @vampiric
  end
  #--------------------------------------------------------------------------
  # * Siphonic
  #--------------------------------------------------------------------------
  def siphonic
    return @siphonic if @siphonic != nil
    @siphonic = 0
    self.note.split(/[\r\n]+/).each { |line|
      case line
      when /<(?:SIPHONIC|siphon):[ ]*(\d+)>/i
        @siphonic = $1.to_i
      end
    }
    return @siphonic
  end
end

class RPG::Enemy < RPG::BaseItem
  #--------------------------------------------------------------------------
  # * Vampiric
  #--------------------------------------------------------------------------
  def vampiric
    return @vampiric if @vampiric != nil
    @vampiric = 0
    self.note.split(/[\r\n]+/).each { |line|
      case line
      when /<(?:VAMPIRIC|vampire):[ ]*(\d+)([%%])>/i
        @vampiric = $1.to_i
      end
    }
    return @vampiric
  end
  #--------------------------------------------------------------------------
  # * Siphonic
  #--------------------------------------------------------------------------
  def siphonic
    return @siphonic if @siphonic != nil
    @siphonic = 0
    self.note.split(/[\r\n]+/).each { |line|
      case line
      when /<(?:SIPHONIC|siphon):[ ]*(\d+)>/i
        @siphonic = $1.to_i
      end
    }
    return @siphonic
  end
end

class Game_Actor < Game_Battler
  #--------------------------------------------------------------------------
  # * Vampiric Rate
  #--------------------------------------------------------------------------
  def vampiric_rate
    result = 0
    for weapon in weapons.compact
      result += weapon.vampiric
    end
    return [result, 0].max
  end
  #--------------------------------------------------------------------------
  # * Siphonic Rate
  #--------------------------------------------------------------------------
  def siphonic_rate
    result = 0
    for weapon in weapons.compact
      result += weapon.siphonic
    end
    return [result, 0].max
  end
end

#==============================================================================
# ** Game_Enemy
#==============================================================================
 
class Game_Enemy < Game_Battler
  #--------------------------------------------------------------------------
  # * Vampiric Rate
  #--------------------------------------------------------------------------
  def vampiric_rate
    return [enemy.vampiric, 0].max
  end
  #--------------------------------------------------------------------------
  # * Siphonic Rate
  #--------------------------------------------------------------------------
  def siphonic_rate
    return [enemy.siphonic, 0].max
  end
end
