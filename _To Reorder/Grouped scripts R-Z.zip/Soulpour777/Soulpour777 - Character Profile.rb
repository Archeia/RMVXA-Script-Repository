# -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# Soul Engine Ace - Character Profile
# Version 1.0
# Author: Soulpour777
# Included in: Soul Engine Ace, Supported SEA Script: Will Parameter
# -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# Description: 
# This script allows the developer the option called Profile, where more info
# for each character present in the part can be viewed by the player.
# -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# Supports other SEA scripts such as:
# BOF4 Will Parameters
# -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# Terms of Use: (For Commercial Use, please contact me.)
# -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# This script is for Non-Commercial Use:
# -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# You are free to use the script on any non-commercial projects.
# You are free to adapt the script. Any modifications are allowed as long 
# as it is provided as a note on the script.
# Credits to SoulPour777 for the script.
# Preserve the Script Header.
# Claiming the script as your own is prohibited.
# -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
imported = {} if $imported.nil?
$imported["Soul Engine Ace - Character Profile"] = true
#==============================================================================
# ** Soul Profile
#------------------------------------------------------------------------------
#  This module performs the BGM, Background and Biography hashes needed to
# create the Character Profile scene.
#==============================================================================
module Soul_Profile
  
  # would you like to play a bgm when you're inside the profile?
  ALLOW_PROFILE_BGM = true
  # Would you like to use a custom background for your profile page?
  ALLOW_BACKGROUND = true
  
  PROFILE_BGM = "Theme4"
  
  # ------------------------------------------------------
  # Play Profile BGM
  # ------------------------------------------------------
  def play_profile_bgm
    RPG::BGM.new(PROFILE_BGM,100,100).play
  end
  
  # ------------------------------------------------------
  # Create Background for Default
  # ------------------------------------------------------  
  def create_background_default
    @background_sprite = Sprite.new
    @background_sprite.bitmap = SceneManager.background_bitmap
    @background_sprite.color.set(16, 16, 16, 128)
  end
  
  # ------------------------------------------------------
  # Dispose Background for Default
  # ------------------------------------------------------  
  def dispose_background_default
    @background_sprite.dispose
  end
  
  # ------------------------------------------------------
  # Create Background Custom
  # ------------------------------------------------------  
  def create_background_bg_allow
    @background_layout_sprite = Sprite.new
    @background_layout_sprite.bitmap = Cache.picture("Biography_Layout")
  end
  
  # ------------------------------------------------------
  # Dispose Background Custom
  # ------------------------------------------------------  
  def dispose_background_bg_allow
    @background_layout_sprite.bitmap.dispose
    @background_layout_sprite.dispose
  end
  
    # -----------------------------------------------
    # Actor's Full Name
    # -----------------------------------------------
    Actor_FullName = {
    
    1 => "Eric Brangwin",
    2 => "Natalie Strauss",
    3 => "Terence Seighart",
    4 => "Ernest Cromeweld"
    
    }
    
    # -----------------------------------------------
    # Actor's Skill - Noble Phantasm
    # -----------------------------------------------
    Actor_NoblePhantasm = {
    
    1 => "Berserker's Roar",
    2 => "Tiger Fist",
    3 => "Thunder Spear",
    4 => "Unlimited Blades"
    
    }
    
    # -----------------------------------------------
    # Actor's Motto
    # -----------------------------------------------
    Actor_Motto = {
    1 => "The more the merrier.",
    2 => "If others can, why can't I?",
    3 => "Practice is perfection.",
    4 => "I am justice!"
    
    
    }
    
    # -----------------------------------------------
    # Actor's Rank
    # -----------------------------------------------
    Actor_RankStat = {
    
    1 => "Pia's Boyfriend.",
    2 => "Heartless Monk",
    3 => "Hardworking Beast",
    4 => "Honored Hero"
    }
    
    # -----------------------------------------------
    # Actor's Will
    # -----------------------------------------------
    Actor_Wills = {
    
    1 => "Wild",
    2 => "Haste",
    3 => "Finale",
    4 => "Vision"
    }
    
    # -----------------------------------------------
    # Actor's Age
    # -----------------------------------------------
    Actor_Age = {
    
    1 => "18",
    2 => "19",
    3 => "24",
    4 => "18"
    
    }
    
    # -----------------------------------------------
    # Actor Description
    # -----------------------------------------------    
    Actor_Description = {
  # ------------------------------------------------------
  # Actor ID => Description
  # 1 => Description means Eric => Character's Description
  # This is different from the default description you see
  # in the Status.
  # ------------------------------------------------------   
    1 => "  Eric is a warrior from the southern seas. 
  When his father was killed in an Imperial War, 
  Eric swore revenge. Eric is known for his
  great Axe wielding skills and the use of Earth
  magic. It was said that Eric once broke hundreds
  of rocks by only using his hand.",
    2 => "  Natalie's parents were murdered by an
  unknown assassin. Since then, Natalie swore
  revenge and seeks the killer of her parents.
  She is a master martial artist who mastered
  the art of Jeet Kune Do. Apparently, Natalie
  is also skilled in using the Claw and Katar
  fighting method.",
    3 => "  Terence's past has been a mystery to
  anyone and to himself. Eric found him washed by
  the sea. He assumed that Terence could have been
  a traveler of the sea and the ship was wrecked,
  causing him to get washed up by the sea. Eric
  recruits him when he discovered Terence's great
  spear handling skills.",
    4 => "  Ernest thinks he is the best 
  swordsman on Earth. He always flaunts how great 
  his swordsmanship is. When his master died, he 
  promised to become a better man and teach the 
  world how to live happily. Aside from being a 
  kind spellblade, Ernest is also a man of honor 
  and honesty. Although he likes to flaunt his 
  abilities, it is often seen that Ernest only 
  flaunts something he actually has or did make."
    
    
    }
  
end


#==============================================================================
# ** Window_Soul_Biography
#------------------------------------------------------------------------------
#  This window displays full profile specs on the profile screen.
#==============================================================================

class Window_Soul_Biography < Window_Selectable
  include Soul_Profile
  #--------------------------------------------------------------------------
  # * Object Initialization
  #--------------------------------------------------------------------------
  def initialize(actor)
    super(0, 0, Graphics.width, Graphics.height)
    self.opacity = 0 if ALLOW_BACKGROUND
    self.opacity = 255 if ALLOW_BACKGROUND == false
    @actor = actor
    refresh
    activate
  end
  #--------------------------------------------------------------------------
  # * Set Actor
  #--------------------------------------------------------------------------
  def actor=(actor)
    return if @actor == actor
    @actor = actor
    refresh
  end
  #--------------------------------------------------------------------------
  # * Refresh
  #--------------------------------------------------------------------------
  def refresh
    contents.clear
    draw_block1   (line_height * 0)
    draw_block2   (line_height * 2)
    draw_block3   (line_height * 7)
    draw_block4   (line_height * 14)
  end
  #--------------------------------------------------------------------------
  # * Draw Block 1
  #--------------------------------------------------------------------------
  def draw_block1(y)
    draw_full_name(x, y)
    draw_actor_noble_phantasm(220, y)
  end
  
  
  #--------------------------------------------------------------------------
  # * Draw Actor Skill - Phantasm
  #--------------------------------------------------------------------------  
  def draw_actor_noble_phantasm(x, y)
    draw_text_ex(x, y, "Skill: " + Actor_NoblePhantasm.values[@actor.id - 1])
  end
  
  
  #--------------------------------------------------------------------------
  # * Draw Block 2
  #--------------------------------------------------------------------------
  def draw_block2(y)
    draw_actor_face(@actor, 8, y)
    draw_basic_info(136, y)
  end
  
  #--------------------------------------------------------------------------
  # * Draw Basic Information
  #--------------------------------------------------------------------------
  def draw_basic_info(x, y)
    draw_actor_ages(x, y)
    draw_actor_motto(x, y + line_height)
    draw_actor_wills(x, y + line_height * 2)
    actor_rank(x, y + line_height * 3)
  end
  
  
  def draw_biography_description
      
    current_text_size = 0
    text = Actor_Description.values[@actor.id-1]
    
    for i in 0..(text.length - 1)
      current_text_size += text_size(text[1]).width
      if current_text_size == self.width
        current_element = i
        while (text[current_element] != " ")
          break if (text[current_element]) == 0
          current_element = i
        end
        temp_text = ""
        for j in 0..(text.length - 1)
          temp_text += text[j]
          temp_text += "\n" if j > current_element
        end
        text = temp_text
        i = current_element
        current_text_size = 0
      end
      
    end
    draw_text_ex(0, 160, text) 
  end
  
  #--------------------------------------------------------------------------
  # * Draw Rank
  #--------------------------------------------------------------------------  
  def actor_rank(x, y)
     draw_text_ex(x, y, "Rank: " + Actor_RankStat.values[@actor.id - 1])
   end
   
  #--------------------------------------------------------------------------
  # * Draw Will
  #--------------------------------------------------------------------------  
  def draw_actor_wills(x, y)
    draw_text_ex(x, y, "Will: " + Actor_Wills.values[@actor.id - 1])
  end
  
  #--------------------------------------------------------------------------
  # * Draw Actor Motto
  #--------------------------------------------------------------------------  
  def draw_actor_motto(x, y)
    draw_text_ex(x, y, "Motto: " + Actor_Motto.values[@actor.id - 1])
  end
  
  #--------------------------------------------------------------------------
  # * Draw Actor Ages
  #--------------------------------------------------------------------------  
  def draw_actor_ages(x, y)
    draw_text_ex(x, y, "Age: " + Actor_Age.values[@actor.id - 1])
  end
  
  #--------------------------------------------------------------------------
  # * Draw Full Name
  #--------------------------------------------------------------------------  
  def draw_full_name(x, y)
    draw_text_ex(x, y, Actor_FullName.values[@actor.id - 1])
  end
  
  #--------------------------------------------------------------------------
  # * Draw Actor Knowledge
  #--------------------------------------------------------------------------  
  def draw_knowledge(x, y)
    draw_text_ex(x, y, Actor_Knowledge.values[@actor.id - 1])
  end  
  
  #--------------------------------------------------------------------------
  # * Draw Block 3
  #--------------------------------------------------------------------------
  def draw_block3(y)

  end
  #--------------------------------------------------------------------------
  # * Draw Block 4
  #--------------------------------------------------------------------------
  def draw_block4(y)
    draw_biography_description()
  end

  #--------------------------------------------------------------------------
  # * Get Color of Horizontal Line
  #--------------------------------------------------------------------------
  def line_color
    color = normal_color
    color.alpha = 48
    color
  end

end

#==============================================================================
# ** Scene_Soul_Biography
#------------------------------------------------------------------------------
#  This class performs the character profile screen processing.
#==============================================================================

class Scene_Soul_Biography < Scene_MenuBase
  include Soul_Profile
  #--------------------------------------------------------------------------
  # * Start Processing
  #--------------------------------------------------------------------------
  def start
    super
    play_profile_bgm if ALLOW_PROFILE_BGM
    @status_window = Window_Soul_Biography.new(@actor)
    @status_window.set_handler(:cancel,   method(:return_scene))
    @status_window.set_handler(:pagedown, method(:next_actor))
    @status_window.set_handler(:pageup,   method(:prev_actor))
  end
  #--------------------------------------------------------------------------
  # * Change Actors
  #--------------------------------------------------------------------------
  def on_actor_change
    @status_window.actor = @actor
    @status_window.activate
  end
  
  #--------------------------------------------------------------------------
  # * Create Background (from MenuBase)
  #--------------------------------------------------------------------------  
  def create_background
      create_background_bg_allow if ALLOW_BACKGROUND
      create_background_default if ALLOW_BACKGROUND == false
  end
  
  #--------------------------------------------------------------------------
  # * Dispose Baackground (from MenuBase)
  #--------------------------------------------------------------------------  
  def dispose_background
      dispose_background_bg_allow if ALLOW_BACKGROUND
      dispose_background_default if ALLOW_BACKGROUND == false
      if ALLOW_PROFILE_BGM
        RPG::BGM.stop
        $game_map.autoplay
      end
  end  
  
end

#==============================================================================
# ** Window_MenuCommand
#------------------------------------------------------------------------------
#  This command window appears on the menu screen.
#==============================================================================

class Window_MenuCommand < Window_Command
  #--------------------------------------------------------------------------
  # * Original Commands
  #--------------------------------------------------------------------------  
  def add_original_commands
    add_command("Biography",   :Soul_Biography,   main_commands_enabled)
  end
end

#==============================================================================
# ** Scene_Menu
#------------------------------------------------------------------------------
#  This class performs the menu screen processing.
#==============================================================================

class Scene_Menu < Scene_MenuBase
  #--------------------------------------------------------------------------
  # * Create Command Window
  #--------------------------------------------------------------------------
  alias soul_command_create_command_window create_command_window
  def create_command_window
   soul_command_create_command_window
    @command_window.set_handler(:Soul_Biography,    method(:command_Soul_Biography))
  end
  
  #--------------------------------------------------------------------------
  # * Create Sutom Command
  #--------------------------------------------------------------------------  
  def command_Soul_Biography
    SceneManager.call(Scene_Soul_Biography)
  end
  
end
