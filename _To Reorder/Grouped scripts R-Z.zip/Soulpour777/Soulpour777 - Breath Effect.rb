# -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# SEA - Breath Effect
# Author: Soulpour777
# Version 1.0
# Category: Character Related
# -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# Description: Creates a breathing effect when idle.
# -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# Pre-requisites: Soul Character Core Script
# -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

class Sprite_Character < Sprite_Base
  # -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
  # Alias Listings
  # -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
  alias character_effects_upd update
  # -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
  
  def update
    character_effects_upd #Call Original Method
    update_breath
  end
  
  # -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
  # update breath effect
  # -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
  def update_breath
    if sprite_is_controllable?(@character)
      @zoom_wait,b = [(@zoom_wait||0)-1,0].max, Soul_Character_Effects::CharacterAnimation::ZOOM_EQUAL_TIME
      if self.zoom_y < b && !@up && @zoom_wait == 0
        self.zoom_y += Soul_Character_Effects::CharacterAnimation::ZOOM_Y_ADD
        @up, @zoom_wait = true, Soul_Character_Effects::CharacterAnimation::ZOOM_WAIT if self.zoom_y >= b
      elsif self.zoom_y >= Soul_Character_Effects::CharacterAnimation::ZOOM_Y_COMPARE && @up && @zoom_wait == 0
        self.zoom_y -= Soul_Character_Effects::CharacterAnimation::ZOOM_Y_DEC
        @up, @zoom_wait = false,Soul_Character_Effects::CharacterAnimation::ZOOM_WAIT_IF_ONE if self.zoom_y <= Soul_Character_Effects::CharacterAnimation::ZOOM_Y_COMPARE
      end
    else
      self.zoom_y = @character.instance_variable_get(:@zoom_y) || 1
    end
  end
 
  # -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
  # Sprite Controllable?
  # -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
  def sprite_is_controllable?(character)
    return false if $game_map.interpreter.running? 
    return false if character.move_route_forcing
    return Soul_Character_Effects::CharacterAnimation::BREATH_MOVE if character.moving?
    return false if character.transparent
    return false if !character.is_a?(Game_Player) 
    return true
  end
  
end