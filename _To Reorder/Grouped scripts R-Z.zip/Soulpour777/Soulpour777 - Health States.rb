# -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# Soul Engine Ace - Health States
# ** Soulpour777
# Version 1.0
# Script Category: Battle Related
# -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# Instructions:
# Place the script below Materials above Main.
# -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# Usage: Check the module for the configurations.
# -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# Description: This script allows an extra state applied on the user whenever
# a percentage of their health is reached. The state is also removed when
# the actor has recovered or healed.
# -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

module Soulpour
  #--------------------------------------------------------------------------
  # * Assign Health States Here:
  #--------------------------------------------------------------------------  
  module HealthStates
    HP_State_Percentage = 160 #HP before state applies
    States = [2, 3, 4, 5, 6] #list of states
  end
end

class Scene_Battle < Scene_Base
  
  #--------------------------------------------------------------------------
  # * Battle Start
  #--------------------------------------------------------------------------
  alias soul_rend_battle_start battle_start
  def battle_start
   soul_rend_battle_start()
   recall_state_applied()
  end
  
  #--------------------------------------------------------------------------
  # * End Turn
  #--------------------------------------------------------------------------
  alias soul_rend_start_turn turn_start
  def turn_start
   soul_rend_start_turn
   $game_party.members.each do |soul_battlers|
     if soul_battlers.hp <= Soulpour::HealthStates::HP_State_Percentage
       soul_battlers.add_state($state_new_id)  
     else
       soul_battlers.remove_state($state_new_id)
     end
   end
  end
  
  #--------------------------------------------------------------------------
  # * Recall State Applied
  # * Assigns State to be applied when dying.
  #--------------------------------------------------------------------------  
  def recall_state_applied
    state_recall_id = Soulpour::HealthStates::States[rand(Soulpour::HealthStates::States.size)]
    $state_new_id = state_recall_id
  end
  
end