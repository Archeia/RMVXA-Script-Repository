# -=-==-=-=-==-=-=-==-=-=-==-=-=-==-=-=-==-=-=-==-=-=-==-=-=-==-=-=-==-=-=-==-=
# [SEA] Soul Engine Ace - Status Faces
# Author: Soulpour777
# Version 1.0
# -=-==-=-=-==-=-=-==-=-=-==-=-=-==-=-=-==-=-=-==-=-=-==-=-=-==-=-=-==-=-=-==-=
# Terms of Use:
#~ For Non-Commercial Use:
#~ You are free to use the script on any non-commercial projects.
#~ You are free to adapt the script. Any modifications are allowed as long as it is provided as a note on the script.
#~ Credits to SoulPour777 for the script.
#~ Preserve the Script Header.
#~ Claiming the script as your own is prohibited.
# -=-==-=-=-==-=-=-==-=-=-==-=-=-==-=-=-==-=-=-==-=-=-==-=-=-==-=-=-==-=-=-==-=
# Description: This script changes the Actor's Face depending on his/her HP and
# MP Status.
# -=-==-=-=-==-=-=-==-=-=-==-=-=-==-=-=-==-=-=-==-=-=-==-=-=-==-=-=-==-=-=-==-=
# Installation: Place the script below Materials above Main.
# -=-==-=-=-==-=-=-==-=-=-==-=-=-==-=-=-==-=-=-==-=-=-==-=-=-==-=-=-==-=-=-==-=
# Prerequisites: NONE
# -=-==-=-=-==-=-=-==-=-=-==-=-=-==-=-=-==-=-=-==-=-=-==-=-=-==-=-=-==-=-=-==-=
# Usage:
# Note that in a whole face set, counting begins at 0 for the index.
# A whole faceset then has 0,1,2,3,4,5,6,7
# You can set up the Good and Dying Status at the Status_Faces module.
# -=-==-=-=-==-=-=-==-=-=-==-=-=-==-=-=-==-=-=-==-=-=-==-=-=-==-=-=-==-=-=-==-=

module Soulpour
  # --------------------------------------------------------
  # Status Faces
  # --------------------------------------------------------  
  module Status_Faces
    HP_Value = "hp"
    OK_FACE_INDEX = 1 # Face Graphic Index for 'Good Status'.
    ALMOST_DYING = 5 #Face Graphic Index for 'Almost Dying' Status.
    DYING_FACE_INDEX = 4 # Face Graphic Index for Dying Status.
  end  
end

#==============================================================================
# ** Scene_Base
#------------------------------------------------------------------------------
#  This is a super class of all scenes within the game.
#==============================================================================
class Scene_Base
  # --------------------------------------------------------
  # Alias Listings
  # --------------------------------------------------------
  alias soul_status_faces_new_update update
  
  # --------------------------------------------------------
  # Update
  # --------------------------------------------------------
  def update
    soul_status_faces_new_update
    face_update
  end
  
  # --------------------------------------------------------
  # Face Update
  # --------------------------------------------------------
  def face_update
    for actor in $game_party.members
      status_face_val(actor)
    end
  end
  
  # --------------------------------------------------------
  # Status Face Value
  # --------------------------------------------------------
  def status_face_val(actor)
    
    @game_actor = actor
    @character_name = @game_actor.character_name
    @character_index = @game_actor.character_index
    @character_face_name = @game_actor.face_name

    case Soulpour::Status_Faces::HP_Value
      when "hp"; @value = @game_actor.hp; @max_value = @game_actor.mhp
      when "mp"; @value = @game_actor.mp; @max_value = @game_actor.mmp    
    end
    
    # -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    # Configure Index for each HP and MP Values Here:
    # -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    @face_index = Soulpour::Status_Faces::OK_FACE_INDEX if @value >= @max_value / 7 * 0 # Full
    @face_index = Soulpour::Status_Faces::ALMOST_DYING if @value >= @max_value / 7 * 1 # 1 / 7
    @face_index = Soulpour::Status_Faces::ALMOST_DYING if @value >= @max_value / 7 * 2 # 2 / 7
    @face_index = Soulpour::Status_Faces::ALMOST_DYING if @value >= @max_value / 7 * 3 # 3 / 7
    @face_index = Soulpour::Status_Faces::OK_FACE_INDEX if @value >= @max_value / 7 * 4 # 4 / 7
    @face_index = Soulpour::Status_Faces::OK_FACE_INDEX if @value >= @max_value / 7 * 5 # 5 / 7 
    @face_index = Soulpour::Status_Faces::OK_FACE_INDEX if @value >= @max_value / 7 * 6 # 6 / 7
    @face_index = Soulpour::Status_Faces::DYING_FACE_INDEX if @value <= 1               # <= 1 - Verge of Death
    
    @game_actor.set_graphic(@character_name, @character_index, @character_face_name, @face_index) if @face_index != @game_actor.face_index
  end
end