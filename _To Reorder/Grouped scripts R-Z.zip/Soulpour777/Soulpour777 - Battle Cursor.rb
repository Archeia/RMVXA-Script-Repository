# -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# SEA - Battle Cursor
# ** SoulPour777
# Web URL: infinitytears.wordpress.com
# -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# Description:
# This script shows a cursor and the enemy name during battle. This script
# needs the latest Soul_Battle_Core script.
# -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# All my scripts are bound to my Terms of Use. 
# -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# Instruction:
#  - Place this script below the core script, above Materials below Main.
# Preserve this script banner.
# -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

# -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# ¦ Game Temp
# -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
class Game_Temp 
  
  attr_accessor :battle_cursor
  
  #--------------------------------------------------------------------------
  # ? Initialize
  #--------------------------------------------------------------------------  
  alias soul_battle_cursor_init initialize
  def initialize
      @battle_cursor = [0,0,false,""]
      soul_battle_cursor_init() #Call Original Method
  end  
  
end

# -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# ¦ Spriteset Battle Cursor
# -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
class Sprite_Battle_Cursor < Sprite
  include Soul_Battle_Core::SoulBattleCursor
  
  #--------------------------------------------------------------------------
  # ? Initialize
  #--------------------------------------------------------------------------        
  def initialize(viewport = nil)
      super(viewport) 
      $game_temp.battle_cursor = [0,0,false,""] 
      self.bitmap = Cache.system("Battle_Cursor")
      self.visible = $game_temp.battle_cursor[2]
      self.z = CURSOR_Z
      @cursor_name = Sprite.new
      @cursor_name.bitmap = Bitmap.new(120,32)
      @cursor_name.z = self.z + 1
      @cursor_name.bitmap.font.size = 16
      @cursor_name_enemy = $game_temp.battle_cursor[3]
      @cursor_name_position = [CURSOR_NAME_POSITION[0] ,CURSOR_NAME_POSITION[1]]
      @cursor_float = [0,0]
      refresh_cursor_name
  end
  
  #--------------------------------------------------------------------------
  # ? Dispose Sprite
  #--------------------------------------------------------------------------          
  def dispose
      super
      dispose_sprite_cursor
  end
  
  #--------------------------------------------------------------------------
  # ? Dispose Sprite Cursor
  #--------------------------------------------------------------------------            
  def dispose_sprite_cursor
      if @cursor_name != nil
         @cursor_name.bitmap.dispose
         @cursor_name.dispose
      end
      self.bitmap.dispose
  end

  #--------------------------------------------------------------------------
  # ? Refresh Cursor Name
  #--------------------------------------------------------------------------              
  def refresh_cursor_name
      @cursor_name_enemy = $game_temp.battle_cursor[3]
      @cursor_name.bitmap.clear
      @cursor_name.bitmap.draw_text(0,0,120,32,@cursor_name_enemy.to_s,1)
  end 

  #--------------------------------------------------------------------------
  # ? Update
  #--------------------------------------------------------------------------            
  def update
      super
      update_sprite_cursor
  end

  #--------------------------------------------------------------------------
  # ? Update Sprite Cursor
  #--------------------------------------------------------------------------              
  def update_sprite_cursor
      update_visible
      execute_move(0,self.x,$game_temp.battle_cursor[0])
      execute_move(1,self.y,$game_temp.battle_cursor[1] + @cursor_float[1])
      update_sprite_name
  end

  #--------------------------------------------------------------------------
  # ? Update Visible
  #--------------------------------------------------------------------------                
  def update_visible
      self.visible = $game_temp.battle_cursor[2]
      if !self.visible
         self.x = -64
         self.y = -64
      end  
  end  
  
  #--------------------------------------------------------------------------
  # ? Update Sprite Name
  #--------------------------------------------------------------------------                
  def update_sprite_name
      return if @cursor_name == nil
      refresh_cursor_name  if @cursor_name_enemy != $game_temp.battle_cursor[3]
      @cursor_name.x = self.x + @cursor_name_position[0]
      @cursor_name.y = self.y + @cursor_name_position[1]
      @cursor_name.opacity = self.opacity
      @cursor_name.visible = self.visible
  end  
  
  
  #--------------------------------------------------------------------------
  # ? Execute Move
  #--------------------------------------------------------------------------      
  def execute_move(type,cp,np)
      sp = 5 + ((cp - np).abs / 5)
      if cp > np 
         cp -= sp
         cp = np if cp < np
      elsif cp < np 
         cp += sp
         cp = np if cp > np
      end     
      self.x = cp if type == 0
      self.y = cp if type == 1
  end      
  
end

# -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# ¦ Spriteset Battle
# -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
class Spriteset_Battle
  
  #--------------------------------------------------------------------------
  # ? Initialize
  #--------------------------------------------------------------------------      
  alias soul_battle_cursor_init initialize
  def initialize
      soul_battle_cursor_init
      create_cursor
  end
  
  #--------------------------------------------------------------------------
  # ? Dispose
  #--------------------------------------------------------------------------      
  alias soul_battle_cursor_dispose dispose
  def dispose
      soul_battle_cursor_dispose
      dispose_cursor
  end 
  
  #--------------------------------------------------------------------------
  # ? Update
  #--------------------------------------------------------------------------          
  alias soul_battle_cursor_upd update
  def update
      soul_battle_cursor_upd
      update_battle_cursor
  end  
  
  #--------------------------------------------------------------------------
  # ? Create_Cursor
  #--------------------------------------------------------------------------        
  def create_cursor
      return if @battle_cursor != nil
      @battle_cursor = Sprite_Battle_Cursor.new      
  end 
  
  #--------------------------------------------------------------------------
  # ? Dispose Cursor
  #--------------------------------------------------------------------------        
  def dispose_cursor
      return if @battle_cursor == nil
      @battle_cursor.dispose
  end  
  
  #--------------------------------------------------------------------------
  # ? Update Battle Cursor
  #--------------------------------------------------------------------------          
  def update_battle_cursor
      return if @battle_cursor == nil
      @battle_cursor.update      
  end
  
end

# -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# ¦ Window_BattleActor
# -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
class Window_BattleActor < Window_BattleStatus
  include Soul_Battle_Core::SoulBattleCursor
  
  #--------------------------------------------------------------------------
  # ? Update
  #--------------------------------------------------------------------------  
  def update
      super
      set_cursor_position_actor
  end  

  #--------------------------------------------------------------------------
  # ? Show
  #--------------------------------------------------------------------------
  alias soul_battle_cursor_show show
  def show
      if @info_viewport
         set_cursor_position_actor
         $game_temp.battle_cursor[2] = true
      end
      soul_battle_cursor_show
  end

  #--------------------------------------------------------------------------
  # ? Hide
  #--------------------------------------------------------------------------
  alias soul_battle_cursor_hide hide
  def hide
      if @info_viewport
          $game_temp.battle_cursor[2] = false
      end
      soul_battle_cursor_hide
  end  
  
end

# -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# ¦ Window_BattleEnemy
# -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
class Window_BattleEnemy < Window_Selectable
  include Soul_Battle_Core::SoulBattleCursor
  
  #--------------------------------------------------------------------------
  # ? Update
  #--------------------------------------------------------------------------  
  def update
      super
      set_cursor_position_enemy
  end

  #--------------------------------------------------------------------------
  # ? Show
  #--------------------------------------------------------------------------
  alias soul_battle_cursor_show show
  def show
      if @info_viewport
         set_cursor_position_enemy
         $game_temp.battle_cursor[2] = true
      end
      soul_battle_cursor_show
  end

  #--------------------------------------------------------------------------
  # ? Hide
  #--------------------------------------------------------------------------
  alias soul_battle_cursor_hide hide
  def hide
      if @info_viewport
          $game_temp.battle_cursor[2] = false
      end
      soul_battle_cursor_hide
  end  
  
end