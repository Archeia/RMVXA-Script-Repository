#~ #== Szyu Scripts presents =====================================================
# * Szyu Scripts' Simple Factions
# Version 1.1
# by Szyu
#
#== Download ==================================================================
# * pastebin:
# http://adf.ly/4920670/simple-factions
#
#== About =====================================================================
# * This script adds categorized factions to your game, which can be tracked 
#   and used for advanced event and script flow control.
#   You can define event pages to be of a certain faction with simple access.
#
#== How to Use ================================================================
# * Define your reputation levels, factions and faction categories in the module
#   SZS_Factions.
#
# * To access a faction, use '$game_factions[index]'
#   !The first faction has ID/index 0!
#
# * To add reputation to a faction, use 
#   '$game_factions.gain_reputation(id, amount)' to add reputation for a faction
#   or
#   '$game_factions.lose_reputation(id, amount)' to remove reputation for a faction
#   If the reputation was not visible, it now will be displayed in the 
#   factions list.
#
# * To define an event page to be from a certain faction, use a comment including
#   following line: '<faction: x>' where x is the index of the faction in the
#   module's Factions-list
#
# * You can check if an event page is from faction with following script call:
#   event.faction
#   This will return the index (id) of the event's faction.
#   If no faction is assigned, this will return nil.
#
# * With a Script-Condition like
#   if event.faction && $game_factions[event.faction].reputation > x
#   you can create a conditional branch, where you check for the players
#   reputation with the event page's faction to be higher than a specific value.
#
#== Terms of Use ==============================================================
# * You are free to use this script for commercial and non-commercial projects.
# However I'd like you to inform me of the projects you are planning to use it
# in, so I can keep track of where my scripts are used.
#
#== Import ====================================================================
$imported = {} if $imported.nil?
$imported["SZ-FACTIONS"] = true
#==============================================================================
module SZS_Factions
  # Define Reputation Levels:
  #   :name       - name of a level
  #   :rep_min    - minimum reputation for a level
  #   :bar_color1 - first color of the status bar
  #                 Default_BarColor1 if nil or not defined
  #   :bar_color2 - second color of the status bar, 
  #                 Default_BarColor2 if nil or not defined
  Levels = [
    {:name => "Hated", :rep_min => 0, 
          :bar_color1 => Color.new(220, 20,18),
          :bar_color2 => Color.new(140, 5,30)},
          
    {:name => "Neutral", :rep_min =>  1000, 
          :bar_color1 => Color.new(40, 32, 218)},
          
    {:name => "Respected", :rep_min => 1800},
    
    {:name => "Loved", :rep_min => 2400, 
          :bar_color1 => Color.new(52, 242, 32)}
  ]
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # Categories for factions. Add new factions to use in faction scene:
  #   :faction  - identifier symbol, used as :type
  #     => bla  - name of the type, used as vocab term
  FactionType = {
      :faction => "Faction", 
      :individual => "Individual"
  }
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # List of all factions:
  #   :name           - name of the faction
  #   :type           - category of the faction
  #   :initial_value  - reputation value when first discovered
  #   :discovered     - flag whether the faction is visible from game start or not
  #   :graphic        - displayed graphic if description option is on
  #   :description    - displayed description if description option is on
  Factions = [
    {:name => "Nemesis", :type => :faction, :initial_value => 1250, :discovered => true,
      :graphic => "logo",:description => "Absolute faction, always winning. Loyalty is one of its members principles. Do not take them lightly when facing them..."},
    {:name => "Genesis", :type => :faction, :initial_value => 1000},
    {:name => "Ghosty", :type => :individual, :initial_value => 0},
  ]
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # Term displayed in menu
  UseInMenu = true
  MenuTerm = "Factions"
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # Term displayed in menu
  UseDescriptions = false
  UseGraphics = false
  DescriptionAlignment = 1
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # Max value for a faction's reputation
  MaxReputation = 2500
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # Default colors for reputation status gauge
  Default_BarColor1 = Color.new(172,196,36)
  Default_BarColor2 = Color.new(82,106,16)
end

#==============================================================================
# ** Game Faction
#==============================================================================
class Game_Faction
  attr_reader :id
  attr_reader :name
  attr_reader :reputation
  attr_reader :type
  attr_reader :level
  #--------------------------------------------------------------------------
  # * Initialize
  #--------------------------------------------------------------------------
  def initialize(id)
    @id = id
    fac = SZS_Factions::Factions[id]
    @name = fac[:name]
    @type = fac[:type]
    @reputation = fac[:initial_value]
    check_level
  end
  #--------------------------------------------------------------------------
  # * Gain Reputation
  #--------------------------------------------------------------------------
  def gain_reputation(amount)
    @reputation += amount
    check_level
  end
  #--------------------------------------------------------------------------
  # * Lose Reputation
  #--------------------------------------------------------------------------
  def lose_reputation(amount)
    gain_reputation(-amount)
  end
  #--------------------------------------------------------------------------
  # * Check Reputation Level
  #--------------------------------------------------------------------------
  def check_level
    lv = -1
    SZS_Factions::Levels.each do |rlv|
      lv += 1 if @reputation >= rlv[:rep_min]
    end
    @level = lv
  end
end

#==============================================================================
# ** Game Factions
#==============================================================================
class Game_Factions
  #--------------------------------------------------------------------------
  # * Object Initialization
  #--------------------------------------------------------------------------
  def initialize
    @data = []
  end
  #--------------------------------------------------------------------------
  # * Get Actor
  #--------------------------------------------------------------------------
  def [](fac_id)
    return nil unless SZS_Factions::Factions[fac_id]
    @data[fac_id] ||= Game_Faction.new(fac_id)
  end
  #--------------------------------------------------------------------------
  # * Get All Factions not nil
  #--------------------------------------------------------------------------
  def all_factions
    return @data.select{|f| !f.nil?}
  end
  #--------------------------------------------------------------------------
  # * Get All Factions of a certain type
  #--------------------------------------------------------------------------
  def factions_of(type)
    return @data.select{|f| !f.nil? && f.type == type}
  end
  #--------------------------------------------------------------------------
  # * Gain Reputation
  #--------------------------------------------------------------------------
  def gain_reputation(fac_id, amount)
    return nil unless SZS_Factions::Factions[fac_id]
    @data[fac_id] ||= Game_Faction.new(fac_id)
    @data[fac_id].gain_reputation(amount)
  end
  #--------------------------------------------------------------------------
  # * Lose Reputation
  #--------------------------------------------------------------------------
  def lose_reputation(fac_id, amount)
    gain_reputation(fac_id, -amount)
  end
end

#==============================================================================
# ** Game_Event
#==============================================================================
class Game_Event < Game_Character
  #--------------------------------------------------------------------------
  # * Get Faction ID of the event's current page
  #--------------------------------------------------------------------------
  def faction
    @page.list.map{|l| l.parameters}.each do |line|
      next if line[0].nil?
      if line[0] =~ /<faction:\s*(\d+)\s*>/i
        fac_id = $1.to_i
        return fac_id if SZS_Factions::Factions[fac_id]
      end
    end
    return nil
  end
end

#==============================================================================
# ** Game_Interpreter
#==============================================================================
class Game_Interpreter
  #--------------------------------------------------------------------------
  # * Get Current event
  #--------------------------------------------------------------------------
  def event
    $game_map.events[@event_id] || nil
  end
end

#==============================================================================
# ** DataManager
#==============================================================================
class << DataManager
  alias :szs_factions_create_game_objects :create_game_objects
  alias :szs_factions_make_save_contents :make_save_contents
  alias :szs_factions_extract_save_contents :extract_save_contents
  alias :szs_factions_setup_new_game :setup_new_game
  #--------------------------------------------------------------------------
  # * Create Game Objects
  #--------------------------------------------------------------------------
  def create_game_objects
    szs_factions_create_game_objects
    $game_factions = Game_Factions.new
  end
  #--------------------------------------------------------------------------
  # * Create Save Contents
  #--------------------------------------------------------------------------
  def make_save_contents
    contents = szs_factions_make_save_contents
    contents[:factions]        = $game_factions
    contents
  end
  #--------------------------------------------------------------------------
  # * Extract Save Contents
  #--------------------------------------------------------------------------
  def extract_save_contents(contents)
    szs_factions_extract_save_contents(contents)
    $game_factions        = contents[:factions]
  end
  #--------------------------------------------------------------------------
  # * Set Up New Game
  #--------------------------------------------------------------------------
  def setup_new_game
    szs_factions_setup_new_game
    SZS_Factions::Factions.select{|f| f[:discovered]}.each do |f|
      $game_factions[SZS_Factions::Factions.index(f)]
    end
  end
end

#==============================================================================
# ** Scene FactionList
#==============================================================================
class Scene_FactionList < Scene_Base
  #--------------------------------------------------------------------------
  # * Start
  #--------------------------------------------------------------------------
  def start
    super
    create_category_window
    create_help_window
    create_fac_list_window
    create_desc_window if SZS_Factions::UseDescriptions
  end
  #--------------------------------------------------------------------------
  # * Create Category Window
  #--------------------------------------------------------------------------
  def create_category_window
    @category_win = Window_FactionCategory.new
    @category_win.set_handler(:ok,     method(:on_category_ok))
    @category_win.set_handler(:cancel, method(:return_scene))
  end
  #--------------------------------------------------------------------------
  # * Create Status Window
  #--------------------------------------------------------------------------
  def create_help_window
    @help_window = Window_FactionStatus.new
  end
  #--------------------------------------------------------------------------
  # * Create List Window
  #--------------------------------------------------------------------------
  def create_fac_list_window
    y = @category_win.height
    w = Graphics.width
    h = Graphics.height-y-@help_window.height
    w /= 2 if SZS_Factions::UseDescriptions
    @fac_list_win = Window_FactionList.new(0,y,w,h)
    @fac_list_win.help_window = @help_window
    @fac_list_win.set_handler(:cancel, method(:on_faction_cancel))
    @category_win.reputation_window = @fac_list_win
  end
  #--------------------------------------------------------------------------
  # * Create Description Window
  #--------------------------------------------------------------------------
  def create_desc_window
    y = @category_win.height
    h = Graphics.height-y-@help_window.height
    x = @fac_list_win.width
    w = Graphics.width - x
    @desc_window = Window_FactionDescription.new(x,y,w,h)
    @fac_list_win.description_window = @desc_window
  end
  #--------------------------------------------------------------------------
  # * Terminate
  #--------------------------------------------------------------------------
  def terminate
    super
    @category_win.dispose
    @fac_list_win.dispose
    @help_window.dispose
    @desc_window.dispose if @desc_window
  end
  #--------------------------------------------------------------------------
  # * On Category selected
  #--------------------------------------------------------------------------
  def on_category_ok
    @fac_list_win.activate.select(0)
  end
  #--------------------------------------------------------------------------
  # * On List cancel
  #--------------------------------------------------------------------------
  def on_faction_cancel
    @fac_list_win.deactivate.select(-1)
    @help_window.faction = nil
    @desc_window.faction = nil if @desc_window
    @category_win.activate
  end
end

#==============================================================================
# ** Scene_Menu
#==============================================================================
class Scene_Menu < Scene_MenuBase
  alias :szs_factions_create_command_window :create_command_window
  #--------------------------------------------------------------------------
  # * Create Command Window
  #--------------------------------------------------------------------------
  def create_command_window
    szs_factions_create_command_window
    @command_window.set_handler(:factions, method(:command_factions))
  end
  #--------------------------------------------------------------------------
  # * Command Factions
  #--------------------------------------------------------------------------
  def command_factions
    SceneManager.call(Scene_FactionList)
  end
end

#==============================================================================
# ** Window_FactionCategory
#==============================================================================
class Window_FactionCategory < Window_HorzCommand
  #--------------------------------------------------------------------------
  # * Public Instance Variables
  #--------------------------------------------------------------------------
  attr_reader   :reputation_window
  #--------------------------------------------------------------------------
  # * Object Initialization
  #--------------------------------------------------------------------------
  def initialize
    super(0, 0)
  end
  #--------------------------------------------------------------------------
  # * Get Window Width
  #--------------------------------------------------------------------------
  def window_width
    Graphics.width
  end
  #--------------------------------------------------------------------------
  # * Get Digit Count
  #--------------------------------------------------------------------------
  def col_max
    return SZS_Factions::FactionType.size
  end
  #--------------------------------------------------------------------------
  # * Frame Update
  #--------------------------------------------------------------------------
  def update
    super
    @reputation_window.category = current_symbol if @reputation_window
  end
  #--------------------------------------------------------------------------
  # * Create Command List
  #--------------------------------------------------------------------------
  def make_command_list
    SZS_Factions::FactionType.each do |k, v|
      add_command(v,k)
    end
  end
  #--------------------------------------------------------------------------
  # * Set Item Window
  #--------------------------------------------------------------------------
  def reputation_window=(reputation_window)
    @reputation_window = reputation_window
    update
  end
end

#==============================================================================
# ** Window_FactionList
#==============================================================================
class Window_FactionList < Window_Selectable
  attr_reader :description_window
  #--------------------------------------------------------------------------
  # * Object Initialization
  #--------------------------------------------------------------------------
  def initialize(x, y, width, height)
    super
    @category = :none
    @data = []
  end
  #--------------------------------------------------------------------------
  # * Set Category
  #--------------------------------------------------------------------------
  def category=(category)
    return if @category == category
    @category = category
    refresh
    self.oy = 0
  end
  #--------------------------------------------------------------------------
  # * Set Description Window
  #--------------------------------------------------------------------------
  def description_window=(dw)
    @description_window = dw
    refresh
  end
  #--------------------------------------------------------------------------
  # * Get Digit Count
  #--------------------------------------------------------------------------
  def col_max
    return SZS_Factions::UseDescriptions ? 1 : 2
  end
  #--------------------------------------------------------------------------
  # * Get Number of Items
  #--------------------------------------------------------------------------
  def item_max
    @data ? @data.size : 1
  end
  #--------------------------------------------------------------------------
  # * Get Item
  #--------------------------------------------------------------------------
  def item
    @data && index >= 0 ? @data[index] : nil
  end
  #--------------------------------------------------------------------------
  # * Get Activation State of Selection Item
  #--------------------------------------------------------------------------
  def current_item_enabled?
    return true
  end
  #--------------------------------------------------------------------------
  # * Create Item List
  #--------------------------------------------------------------------------
  def make_item_list
    @data = $game_factions.factions_of(@category)
  end
  #--------------------------------------------------------------------------
  # * Restore Previous Selection Position
  #--------------------------------------------------------------------------
  def select_last
    select(@data.index($game_party.last_item.object) || 0)
  end
  #--------------------------------------------------------------------------
  # * Draw Item
  #--------------------------------------------------------------------------
  def draw_item(index)
    item = @data[index]
    if item
      rect = item_rect(index)
      rect.width -= 4
      draw_text_ex(rect.x,rect.y, item.name)
    end
  end
  #--------------------------------------------------------------------------
  # * Update Help Text
  #--------------------------------------------------------------------------
  def update_help
    @help_window.faction = item if @help_window
    @description_window.faction = item if @description_window
  end
  #--------------------------------------------------------------------------
  # * Refresh
  #--------------------------------------------------------------------------
  def refresh
    make_item_list
    create_contents
    draw_all_items
  end
end

#==============================================================================
# ** Window_FactionStatus
#==============================================================================
class Window_FactionStatus < Window_Base
  attr_reader :faction
  #--------------------------------------------------------------------------
  # * Initialize
  #--------------------------------------------------------------------------
  def initialize
    h = fitting_height(1)
    super(0,Graphics.height-h,Graphics.width, h)
  end
  #--------------------------------------------------------------------------
  # * Set Faction
  #--------------------------------------------------------------------------
  def faction=(faction)
    @faction=faction
    refresh
  end
  #--------------------------------------------------------------------------
  # * Refresh
  #--------------------------------------------------------------------------
  def refresh
    contents.clear
    return unless @faction
    draw_reputation
    draw_reputation_text
  end
  #--------------------------------------------------------------------------
  # * Draw Reputation
  #--------------------------------------------------------------------------
  def draw_reputation
    draw_rep_gauge(0, 0, contents.width/3*2,line_height-8, 
      @faction.reputation.to_f/SZS_Factions::MaxReputation, 
      hp_gauge_color1, hp_gauge_color2)
    change_color(system_color)
    draw_current_and_max_values(96, 0, 132, 
      @faction.reputation, SZS_Factions::MaxReputation,
      normal_color, normal_color)
  end
  #--------------------------------------------------------------------------
  # * Draw Reputation Gauge
  #--------------------------------------------------------------------------
  def draw_rep_gauge(x, y, width,height, rate, color1, color2)
    fill_w = (width * rate).to_i
    gauge_y = y+(line_height-height)/2
    contents.fill_rect(x, gauge_y, width, height, gauge_back_color)
    contents.gradient_fill_rect(x, gauge_y, fill_w, height, 
    SZS_Factions::Levels[faction.level][:bar_color1] || SZS_Factions::Default_BarColor1, 
    SZS_Factions::Levels[faction.level][:bar_color2] || SZS_Factions::Default_BarColor2)
  end
  #--------------------------------------------------------------------------
  # * Draw Reputation Text
  #--------------------------------------------------------------------------
  def draw_reputation_text
    x = contents.width/3*2+8
    txt = SZS_Factions::Levels[faction.level][:name]
    fc = Color.new(0,0,0,96)
    contents.fill_rect(x,0,contents.width-x,line_height, fc)
    draw_text(x,0,contents.width-x,line_height, txt,1)
  end
end

#==============================================================================
# ** Window_FactionDescription
#==============================================================================
class Window_FactionDescription < Window_Base
  attr_reader :faction
  #--------------------------------------------------------------------------
  # * Initialize
  #--------------------------------------------------------------------------
  def initialize(x,y,w,h)
    super(x,y,w,h)
  end
  #--------------------------------------------------------------------------
  # * Set Faction
  #--------------------------------------------------------------------------
  def faction=(faction)
    @faction=faction
    refresh
  end
  #--------------------------------------------------------------------------
  # * Refresh
  #--------------------------------------------------------------------------
  def refresh
    contents.clear
    return unless @faction
    draw_faction_graphic if SZS_Factions::UseGraphics
    draw_faction_desc if SZS_Factions::UseDescriptions
  end
  #--------------------------------------------------------------------------
  # * Draw Faction Graphic
  #--------------------------------------------------------------------------
  def draw_faction_graphic
    return unless SZS_Factions::Factions[@faction.id][:graphic]
    gr = Cache.picture(SZS_Factions::Factions[@faction.id][:graphic])
    aspect = gr.width.to_f / gr.height.to_f
    h = contents.width * aspect
    contents.stretch_blt(Rect.new(0,(contents.height-h),contents.width, h),
        gr, Rect.new(0,0,gr.width, gr.height))
  end
  #--------------------------------------------------------------------------
  # * Draw Faction Description
  #--------------------------------------------------------------------------
  def draw_faction_desc
    return unless SZS_Factions::Factions[@faction.id][:description]
    i = 0
    split_text(SZS_Factions::Factions[@faction.id][:description]).each do |line|
      draw_line_back(0, line_height*i, contents.width, line_height)
      draw_text(0, line_height * i, contents.width, line_height, line, SZS_Factions::DescriptionAlignment)
      i += 1
    end
  end
  #--------------------------------------------------------------------------
  # * Draw Line Back
  #--------------------------------------------------------------------------
  def draw_line_back(x,y,w,h)
    contents.fill_rect(x,y+1,w,h-2, Color.new(0,0,0,96))
  end
  #--------------------------------------------------------------------------
  # * Split Text
  #--------------------------------------------------------------------------
  def split_text(txt)
    txt_splits = []
    line = ""
    txt.split.each do |word|
      line += word + " "
      if contents.text_size(line).width > width
        txt_splits << line
        line = ""
      end
    end
    txt_splits << line if line.size > 0
    txt_splits
  end
end

#==============================================================================
# ** Window_MenuCommand
#==============================================================================
class Window_MenuCommand < Window_Command
  alias :szs_factions_add_original_commands :add_original_commands
  #--------------------------------------------------------------------------
  # * For Adding Original Commands
  #--------------------------------------------------------------------------
  def add_original_commands
    szs_factions_add_original_commands
    add_command(SZS_Factions::MenuTerm,   :factions) if SZS_Factions::UseInMenu
  end
end