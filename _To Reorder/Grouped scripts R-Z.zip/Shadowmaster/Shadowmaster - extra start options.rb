=begin
===============================================================================
 Extra Start Options (18/1/2015)
-------------------------------------------------------------------------------
 Created By: Shadowmaster/Shadowmaster9000/Shadowpasta
 (www.crimson-castle.co.uk)
 
===============================================================================
 Information
-------------------------------------------------------------------------------
 This script allows you to add extra alternate start options on the title
 screen that can send you to different maps. This can be useful to setting up
 all different kinds of features on the title screen, such as tutorial modes,
 credit screens and more.
 
===============================================================================
 How to Use
-------------------------------------------------------------------------------
 Place this script under Materials, and preferably under any other scripts
 that overwrite the command list and command window methods in Window_TitleCommand
 and Scene_Title. There is an array you can use to set up your extra start
 options below.

===============================================================================
 Required
-------------------------------------------------------------------------------
 Nothing.
 
===============================================================================
 Change log
-------------------------------------------------------------------------------
 v1.0: First release. (18/1/2015)

===============================================================================
 Terms of Use
-------------------------------------------------------------------------------
 * Free to use for both commercial and non-commerical projects.
 * Credit me if used.
 * Do not claim this as your own.
 * You're free to post this on other websites, but please credit me and keep
 the header intact.
 * If you want to release any modifications/add-ons for this script, the
 add-on script must use the same Terms of Use as this script uses. (But you
 can also require any users of your add-on script to credit you in their game
 if they use your add-on script.)
 * If you're making any compatibility patches or scripts to help this script
 work with other scripts, the Terms of Use for the compatibility patch does
 not matter so long as the compatibility patch still requires this script to
 run.
 * If you want to use your own seperate Terms of Use for your version or
 add-ons of this script, you must contact me at http://www.rpgmakervxace.net
 or www.crimson-castle.co.uk

===============================================================================
=end
$imported = {} if $imported.nil?
$imported["ExtraStartPos"] = true

module ExtraStartingPositions
 
#==============================================================================
# ** Start Map Options
#------------------------------------------------------------------------------
#  This is where you can insert how many extra start options you want on your
#  title screen. They are added as arrays with various attributes you can
#  customise. If you want to add more start options, insert an array such as
#  this one:
#
#  ["Command Name", Map ID, X Co-Ord, Y Co-Ord, Menu Order, Transparent]
#
#  Command Name is the string used for the name of the extra start option that
#  will be displayed in the title screen menu.
#
#  Map ID is the ID of the map you want the player to be transported to when
#  this start option is selected.
#
#  X Co-Ord and Y Co-Ord are the X and Y Co-ordinates you want the player to be
#  transported to on the chosen map.
#
#  Menu Order is the order that you want the extra start option to be displayed
#  in the title screen menu. The lower the number, the higher up it will be
#  displayed in the menu (with 1 putting the option at the top). If you simply
#  want to put the extra start option at the bottom, use nil or 0.
#
#  Transparent sets whether you want the player to be transparent or not when
#  the player is transported to that map from the title screen. You can always
#  use the default event commands afterwards to change the player's transparency
#  as normal.
#
#==============================================================================

 StartMapOptions =[ # Do not remove!
   ["Tutorial", 2, 8, 6, 3, false, false],
   ["Credits", 3, 8, 6, 4, true, false],
 ] # Do not remove!

#==============================================================================
# ** DO NOT edit anything below this unless if you know what you're doing!
#==============================================================================
    
end

#==============================================================================
# ** Window_TitleCommand
#------------------------------------------------------------------------------
#  This window is for selecting New Game/Continue on the title screen.
#==============================================================================

class Window_TitleCommand < Window_Command
  #--------------------------------------------------------------------------
  # * Create Command List
  #--------------------------------------------------------------------------
  alias sesp_make_command_list make_command_list
  def make_command_list
    sesp_make_command_list
    for option in ExtraStartingPositions::StartMapOptions
      if option[4] != nil && option[4] > 0
        extrastart = {:name=>option[0], :symbol =>:alt_start, :enabled=>true, :ext=>option}
        @list.insert(option[4]-1, extrastart)
      else
        add_command(option[0], :alt_start, true, option)
      end
    end
  end
end


#==============================================================================
# ** Scene_Title
#------------------------------------------------------------------------------
#  This class performs the title screen processing.
#==============================================================================

class Scene_Title < Scene_Base
  #--------------------------------------------------------------------------
  # * Create Command Window
  #--------------------------------------------------------------------------
  alias sesp_create_command_window create_command_window
  def create_command_window
    sesp_create_command_window
    @command_window.set_handler(:alt_start, method(:command_alt_start))
  end
  #--------------------------------------------------------------------------
  # * [New Game using alternate Starting Position] Command
  #--------------------------------------------------------------------------
  def command_alt_start
    map = @command_window.current_ext
    DataManager.create_game_objects
    $game_party.setup_starting_members
    $game_map.setup(map[1])
    $game_player.moveto(map[2], map[3])
    if map[5] == true
      $game_player.transparent = true
    else
      $game_player.transparent = false
    end
    $game_player.refresh
    Graphics.frame_count = 0
    close_command_window
    fadeout_all
    $game_map.autoplay
    SceneManager.goto(Scene_Map)
  end
end