#===============================================================
#================== HIDE SHOP ITEM CATEGORIES v1.0 =============
#===============================================================
# Author: Seiryuki
# Date: 2011-Dec-31
# Type: VXA/RGSS3
#================================================================
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# This script can hide specified item categories from the Sell
# section of a shop, and any of the 4 item categories can also
# be renamed.
# The changes only take effect on the shop event the script-call
# was made.
#
# The 4 item categories that can be hidden and/or renamed are:
#	 Items, Weapons, Armor, Key Items
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# COMPATIBILITY (place above the following scripts):
#  - Mithran's Limit Shop (ported to VXA by Mr. Bubble)
#  - Enelvon's Sell-Only Shop (ported to VXA by Seiryuki)
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# INSTRUCTIONS:
# Place this script above Main, below Materials and above any
# other scripts that modify the Scene_Shop and Window_ItemCategory
# classes.
#
# This uses a script call in an event.
#
#   Use the below script calls BEFORE shop processing.
#
#   To HIDE Items category, use this script call:
#	 $game_temp.hidecat_item = true
#   To RENAME Items category, use this script call:
#	 $game_temp.cat_item_lbl= "Ingredients"
#
#   To HIDE Weapons category, use this script call:
#	 $game_temp.hidecat_weapon = true
#   To RENAME Weapons category, use this script call:
#	 $game_temp.cat_weapon_lbl= "Pens"
#
#
#   To HIDE Armor category, use this script call:
#	 $game_temp.hidecat_armor = true
#   To RENAME Armor category, use this script call:
#	 $game_temp.cat_armor_lbl= "Clothing"
#
#
#   To HIDE Key Items category, use this script call:
#	 $game_temp.hidecat_key_item = true
#   To RENAME Key Items category, use this script call:
#	 $game_temp.cat_key_item_lbl= "Gadgets"
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# EXAMPLE OF A SHOP EVENT:
#
# @> Script: $game_temp.hidecat_armor = true
# @> Script: $game_temp.hidecat_weapon = true
# @> Script: $game_temp.hidecat_key_item = true
# @> Script: $game_temp.cat_item_lbl = "LOOT"
# @> Shop Processing: [Flour]
# :				 : [Sugar]
#
# In the above example, only the Items category will be shown
# in the Sell section of the shop and it would be labelled LOOT.
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#================================================================

class Game_Temp
  attr_accessor :hidecat_item
  attr_accessor :hidecat_weapon
  attr_accessor :hidecat_armor
  attr_accessor :hidecat_key_item
  attr_accessor :cat_item_lbl
  attr_accessor :cat_weapon_lbl
  attr_accessor :cat_armor_lbl
  attr_accessor :cat_key_item_lbl
 
  alias hidecat_initialize initialize
  def initialize
    hidecat_initialize
    # Setup variables.
    @hidecat_item = false
    @hidecat_weapon = false
    @hidecat_armor = false
    @hidecat_key_item = false
    @cat_item_lbl = Vocab::item
    @cat_weapon_lbl = Vocab::weapon
    @cat_armor_lbl = Vocab::armor
    @cat_key_item_lbl = Vocab::key_item
  end
end

class Scene_MenuBase < Scene_Base
  alias hidecat_terminate terminate
  def terminate
    hidecat_terminate
    # Reset variables on shop exit.
    $game_temp.hidecat_item = false
    $game_temp.hidecat_weapon = false
    $game_temp.hidecat_armor = false
    $game_temp.hidecat_key_item = false
    $game_temp.cat_item_lbl = Vocab::item
    $game_temp.cat_weapon_lbl = Vocab::weapon
    $game_temp.cat_armor_lbl = Vocab::armor
    $game_temp.cat_key_item_lbl = Vocab::key_item
  end
end

class Window_ItemCategory < Window_HorzCommand
  alias hidecat_make_command_list make_command_list
  def make_command_list
    # Check if to hide/show item categories.
    if $game_temp.hidecat_item == false
	  add_command($game_temp.cat_item_lbl, :item)
    end
    if $game_temp.hidecat_weapon == false
	  add_command($game_temp.cat_weapon_lbl, :weapon)
    end
    if $game_temp.hidecat_armor == false
	  add_command($game_temp.cat_armor_lbl, :armor)
    end
    if $game_temp.hidecat_key_item == false
	  add_command($game_temp.cat_key_item_lbl, :key_item)
    end
  end
end
#================================================================
# END OF SCRIPT
#================================================================