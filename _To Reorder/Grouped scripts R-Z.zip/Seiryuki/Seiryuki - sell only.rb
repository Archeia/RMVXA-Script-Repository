###############################################################################
###############################################################################
# ~~~~~~~~~~~~~~~~~~~~~~SELL-ONLY SHOP SCRIPT v1.0~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~by Enelvon~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~concept, assistance by Seiryuki~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~Last Update: 2011.04.30~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# site: rpgmakervx.net~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# post: http://www.rpgmakervx.net/index.php?showtopic=45007~~~~~~~~~~~~~~~~~~~~
###############################################################################
# This script allows you to have shops that can only sell items by disabling
# the "Buy" option. Remember, you must enter at least one item to create the
# shop.
###############################################################################
#------------------------------------------------------------------------------
# COMPATIBILITY:
# This script is compatible with Mithran's LimitShopBuy script.
# This script has not been tested with other shop scripts.
#------------------------------------------------------------------------------
# INSTRUCTIONS:
# Place this script above Main and above any other scripts that modify the 
# command window of Scene_Shop.
# Rather than using a switch, this uses a script command in an event.
#
#   To make your shops sell-only:
#     $game_temp.shop_sell_only = true
#
#   To undo it, use this:
#     $game_temp.shop_sell_only = false
#
#------------------------------------------------------------------------------
# EXAMPLE OF A SELL-ONLY SHOP EVENT:
#
# @> Script: $game_temp.shop_sell_only = true
# @> Shop Processing: [Potion]
# :                 : [Hi-Potion]
# @> Script: $game_temp.shop_sell_only = false
#
#------------------------------------------------------------------------------
###############################################################################
###############################################################################

class Game_Temp
  attr_accessor :shop_sell_only
  alias enelvon_seiryuki_temp_init initialize
  def initialize
    enelvon_seiryuki_temp_init
    @shop_sell_only = false
  end
end

class Scene_Shop < Scene_Base

  #--------------------------------------------------------------------------
  # * Create Command Window
  #--------------------------------------------------------------------------
  alias enelvon_seiryuki_shop_window create_command_window
    def create_command_window
      enelvon_seiryuki_shop_window
      if $game_temp.shop_sell_only
       @command_window.draw_item(0, false)
      end
  end
  #--------------------------------------------------------------------------
  # * Update Command Selection
  #--------------------------------------------------------------------------
  def update_command_selection
    if Input.trigger?(Input::B)
      Sound.play_cancel
      $scene = Scene_Map.new
    elsif Input.trigger?(Input::C)
      case @command_window.index
      when 0 # buy
        if $game_temp.shop_sell_only
          Sound.play_buzzer
        else
          Sound.play_decision
          @command_window.active = false
          @dummy_window.visible = false
          @buy_window.active = true
          @buy_window.visible = true
          @buy_window.refresh
          @status_window.visible = true
        end
      when 1 # sell
        if $game_temp.shop_purchase_only
          Sound.play_buzzer
        else
          Sound.play_decision
          @command_window.active = false
          @dummy_window.visible = false
          @sell_window.active = true
          @sell_window.visible = true
          @sell_window.refresh
        end
      when 2 # Quit
        Sound.play_decision
        $scene = Scene_Map.new
      end
    end
  end
end
#END OF SCRIPT