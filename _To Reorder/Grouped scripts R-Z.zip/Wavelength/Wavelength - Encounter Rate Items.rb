############################################
#                                          #
#       ENCOUNTER RATE ITEMS SCRIPT        #
#                                          #
#        v1.0 for RPG Maker VX Ace         #
#                                          #
# Created by Jason "Wavelength" Commander  #
#                                          #
############################################

# "Stop it, Wave!  Why would the player want MORE random battles?"
#                            ~ Eric, after fighting off yet another 'Slime * 2'


############################################
#                                          #
#           ABOUT THIS SCRIPT              #
#                                          #
############################################

# This script allows you to create items that, when used, modify the Random
#      Encounter Rate for a period of time, and even allows you to create
#      items that *raise* the encounter rate.  The script also allows you
#      to (optionally) assign Common Events to run when the effects of one
#      of these items wears off.

# Note that only one Random Encounter Rate-changing item may be in effect
#      at a time.  If the player uses a Random Encounter Rate-changing item
#      while another one is already active, the newly-used item's effect
#      will override the old item's effect.

# The Encounter Rate multiplier from items will stack with other Encounter
#      Rate modifiers that RPG Maker VX Ace normally uses (such as lower
#      encounter rates while in a Ship and higher encounter rates while on
#      "bush" tiles).

# It is okay to designate items that have another effect (such as restoring
#      HP) as a Random Encounter Rate-changing item.  HOWEVER, note that if
#      a player uses such an item while in battle, the Encounter Rate
#      multiplier will not take effect - so ideally, you want the player
#      using these items outside of battle.

# This script should be placed in the "Materials" section of the script
#      editor.  If you are using other scripts, it's generally better to
#      place this script ABOVE those other scripts.

# This script is compatible with most other scripts, even most other
#      scripts that affect random encounters.

# The current (1.0) version of this script uses Global Variables, which
#      violates best practices for encapsulation.  If you can help me
#      rewrite this script to use only local/class variables, you'd be
#      awesome. :)


############################################
#                                          #
#              TERMS OF USE                #
#                                          #
############################################

#  Free to use for non-commercial projects - just credit me

#  A license is required to use this script in commercial or
#       semi-commercial projects.  Please visit my website
#       wavescripts.wordpress.com for more info about obtaining
#       a license for my scripts.

#  You may freely share or modify this script, but you cannot
#       sell it (even if modified) without my written permission

#  Please preserve the header (with version #) and terms of use;
#       besides that, feel free to remove any commenting you please

module Encounter_Items

# Group your Encounter Rate-changing items into Sets based on their effects.
#      If multiple items have the same Encounter Rate multiplier, Duration,
#      and Common Event, you can group them into the same Encounter Item Set.
#
#    * EI_Item_Set_X: The Item IDs of items in Encounter Item Set X.
#                     Using an Item in this Set will change the
#                     encounter rate based on this Set's properties.
#                     Example:  EI_Item_Set_1 = [22, 19, 25]
#
#    * EI_Enc_Rate_X: The Encounter Rate multiplier that this set grants.
#                     For example, 0.50 means half the encounters you'd
#                     run into if you didn't use the item, and 6.00 means
#                     six times the encounters.  Change this to your liking.
#
#    * EI_Duration_X: The duration (in STEPS) that the Encounter Rate
#                     multiplier effect lasts after you use an item from
#                     this set.  Change this to your liking.
#
#    * EI_Common_X:   The Common Event that will be played when an item's
#                     encounter rate multiplier effect ENDS.  You may leave
#                     this value as nil if you don't want a Common Event to
#                     play, or you may replace nil with the ID of the Common
#                     Event you want to run (e.g., "EI_Common_1 = 2")
#                     (To have a Common Event play when the effect *begins*, 
#                     simply add that Common Event to the effects list for
#                     the item in the database.)

  # Encounter Items Set 1  
  EI_Item_Set_1 = []
  EI_Enc_Rate_1 = 0.00
  EI_Duration_1 = 60
  EI_Common_1 = nil
  
  # Encounter Items Set 2  
  EI_Item_Set_2 = []
  EI_Enc_Rate_2 = 0.00
  EI_Duration_2 = 180
  EI_Common_2 = nil
  
  # Encounter Items Set 3  
  EI_Item_Set_3 = []
  EI_Enc_Rate_3 = 0.50
  EI_Duration_3 = 60
  EI_Common_3 = nil
  
  # Encounter Items Set 4  
  EI_Item_Set_4 = []
  EI_Enc_Rate_4 = 0.50
  EI_Duration_4 = 180
  EI_Common_4 = nil
  
  # Encounter Items Set 5  
  EI_Item_Set_5 = []
  EI_Enc_Rate_5 = 2.00
  EI_Duration_5 = 60
  EI_Common_5 = nil
  
  # Encounter Items Set 6  
  EI_Item_Set_6 = []
  EI_Enc_Rate_6 = 2.00
  EI_Duration_6 = 180
  EI_Common_6 = nil
  
  # Encounter Items Set 7  
  EI_Item_Set_7 = []
  EI_Enc_Rate_7 = 10.00
  EI_Duration_7 = 20
  EI_Common_7 = nil
  
  # Encounter Items Set 8  
  EI_Item_Set_8 = []
  EI_Enc_Rate_8 = 10.00
  EI_Duration_8 = 60
  EI_Common_8 = nil
  
  
############################################
#                                          #
#               ICKY CODE!                 #
#                                          #
############################################

# Everything from here on represents the inner workings of the script.
#       Please don't alter anything from here on unless you are an
#       advanced scripter yourself (in which case, have at it!)    
  
  EI_Sets_Full = [EI_Item_Set_1, EI_Item_Set_2, EI_Item_Set_3, EI_Item_Set_4, EI_Item_Set_5, EI_Item_Set_6, EI_Item_Set_7, EI_Item_Set_8]
  EI_Rates_Full = [EI_Enc_Rate_1, EI_Enc_Rate_2, EI_Enc_Rate_3, EI_Enc_Rate_4, EI_Enc_Rate_5, EI_Enc_Rate_6, EI_Enc_Rate_7, EI_Enc_Rate_8]
  EI_Durs_Full = [EI_Duration_1, EI_Duration_2, EI_Duration_3, EI_Duration_4, EI_Duration_5, EI_Duration_6, EI_Duration_7, EI_Duration_8]
  EI_Comms_Full = [EI_Common_1, EI_Common_2, EI_Common_3, EI_Common_4, EI_Common_5, EI_Common_6, EI_Common_7, EI_Common_8]
  
end


class Game_Player < Game_Character
  
  #--------------------------------------------------------------------------
  # * Get Encounter Progress Value - Enhanced to also process item-based
  #                                  encounter rates
  #--------------------------------------------------------------------------
  alias :encounter_progress_with_items :encounter_progress_value
  def encounter_progress_value
    value = encounter_progress_with_items
    if $enc_steps > 0
      value *= $mod_enc_rate
    else
      $enc_steps = -1
    end
    value
  end
  
end

  
class Game_Party < Game_Unit
  
  #--------------------------------------------------------------------------
  # * Public Instance Variables
  #--------------------------------------------------------------------------
  #attr_reader   :mod_enc_rate             # item-based modification to enc. rate
  #attr_reader   :enc_steps                # remaining duration of item enc. rate
  
  #--------------------------------------------------------------------------
  # * Object Initialization
  #--------------------------------------------------------------------------
  alias :init_with_enc_steps :initialize
  def initialize
    init_with_enc_steps
    $enc_steps = 1
    $mod_enc_rate = 1.00
    $enc_item_end = 0
  end
  
  #--------------------------------------------------------------------------
  # * Increase Steps
  #--------------------------------------------------------------------------
  alias :inc_enc_steps :increase_steps
  def increase_steps
    inc_enc_steps
    $enc_steps -= 1
    if $enc_steps == 0
      if ($enc_item_end != nil && $enc_item_end != 0)
        $game_temp.reserve_common_event($enc_item_end)
      end
    end
  end
  
end


class Scene_Item < Scene_ItemBase

  #--------------------------------------------------------------------------
  # * Use Item
  #--------------------------------------------------------------------------
  alias :use_enc_rate_item :use_item
  def use_item
    use_enc_rate_item
    new_mod_enc_rate(item)
  end
  
  #--------------------------------------------------------------------------
  # This method finds the Encounter Rate and sets the remaining duration 
  #      when you use an Encounter Rate Item
  #--------------------------------------------------------------------------
  def new_mod_enc_rate(item)
    for i in 0..(Encounter_Items::EI_Sets_Full.length - 1)
      if Encounter_Items::EI_Sets_Full[i].include?(item.id)
        $mod_enc_rate = Encounter_Items::EI_Rates_Full[i]
        $enc_steps = Encounter_Items::EI_Durs_Full[i]
        $enc_item_end = Encounter_Items::EI_Comms_Full[i]
      end
    end
  end
  
end