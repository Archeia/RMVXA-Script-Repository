# passive ability that will cause him to protect female party members 
# if they are below 50% health. 
# Make a new state with substitute

class Scene_Battle < Scene_Base
  #--------------------------------------------------------------------------
  # * Check Substitute Condition
  #--------------------------------------------------------------------------
  alias protect_girl check_substitute
  def check_substitute(target, item)
    if @states.include?(X)
      (target.actor_id == N1 or target.actor_id == N2 or target.actor_id == N3) && (!item || !item.certain?)
    else
      target.hp < target.mhp / 4 && (!item || !item.certain?)
    end
	protect_girl(target, item)
  end
end
  
# Replace X with the State ID of Protect Girls. Replace N1, N2, and N3 
# with the Actor ID (in the database) of your female party members, 
# and extend the statement with more "or" connectors as necessary for 
# however many females are in your party.

# Leave the "Substitute" property on the Protect Girls state; don't remove it.