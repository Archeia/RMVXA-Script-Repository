############################################
#                                          #
#        LIMITED SUPPLIES SCRIPT           #
#                                          #
#       v1.0 for RPG Maker VX Ace          #
#                                          #
# Created by Jason "Wavelength" Commander  #
#                                          #
############################################
 
# "So don't delay.  Act now!  Supplies are running out."
#                                     ~ Smash Mouth
 
 
############################################
#                                          #
#           ABOUT THIS SCRIPT              #
#                                          #
############################################
 
# This script allows you to create items for which shops
#      only have a limited supply ("stock"), and to manually
#      change the amount in stock using simple eventing.
 
# Just a few of the possible uses for this script:
#
#      * Limit the availability of healing items, crafting
#        items, etc., for balance purposes.
#
#      * Create one-of-a-kind items (such as a legendary
#        weapon or a quest item) that are available in a
#        shop but can only be bought once.
#
#      * Simulate the rising and falling demand for
#        items in shops, by combining this script with
#        events that take place as game time passes.
#
#      * Temporarily make specific items unavailable in
#        all shops around the world due to an in-game
#        event.
#
#      * Create a sidequest that turns a once rare or
#        unavailable item into a plentiful one that's
#        always available at shops once the quest's complete.
#        (Thanks to Big Rick Cook for this idea!)
 
# Note that the stock of an item available is tracked
#      globally - it cannot be tracked on a per-shop basis.
 
# This script is compatible with most other scripts, even most
#      other shop scripts.  However, it may cause unexpected
#      behavior when combined with scripts that modify the way
#      an item name is written on the Buy or Sell screens.
 
 
############################################
#                                          #
#              TERMS OF USE                #
#                                          #
############################################
 
#  Free to use for non-commercial projects - just credit me
 
#  A license is required to use this script in commercial or
#       semi-commercial projects.  Please visit my website
#       wavescripts.wordpress.com for more info about obtaining
#       a license for my scripts.
 
#  You may freely share or modify this script, but you cannot
#       sell it (even if modified) without my written permission
 
#  Please preserve the header (with version #) and terms of use;
#       besides that, feel free to remove any commenting you please
 
 
############################################
#                                          #
#         HOW TO USE THIS SCRIPT           #
#                                          #
############################################
 
# Add the Item ID of each Limited Item into the arrays in
#      the "SHOP SUPPLY SETUP" section below.  Items, Weapons,
#      and Armors each have their own array.
 
# Each Limited Supply Item uses a Variable to track its stock.
#      The first item in the Items array will use the variable
#      you have specified in the "First Var Items" option, the
#      next item in that array will use the next variable, and
#      so on.  So if you have 75 Limited Supply Items, be sure
#      to leave a block of 75 consecutive variables that you
#      don't use for other things.  Make sure that the blocks
#      of variables reserved for items, weapons, and armors do
#      not overlap.
 
# A particular item's stock can be manually changed at any
#      time simply by changing its corresponding variable
#      using event commands.  (For example, if Full Potion
#      is the fifth entry in the Limited_items_list array,
#      and your First_var_items is 101, and you want to set
#      the stock of Full Potions to zero, then simply use
#      an event command to set Variable 105 equal to 0.)
 
# This script should be placed in the "Materials" section
#      of the script editor.  If you are using other shop
#      scripts, it's generally better to place this script
#      below those other scripts.
 
 
############################################
#                                          #
#           SHOP SUPPLY SETUP              #
#                                          #
############################################
 
module Limited_Items
 
# Use these arrays to define your set of Limited Items.  Simply
#      add the IDs of your Limited Items into the appropriate
#      array (based on whether it's an item, weapon, or armor).
#      The order in which they appear here determines which
#      variable is used to track the stock of each Limited Item,
#      so if you're adding Limited Items as you make your game,
#      it's usually best to add them to the end of the array.
#
#      Example: Limited_items_list = [1, 9, 159, 24, 25, 26, 57, 182, 38]
 
# *** You must set up these arrays for the script to work properly. ***
 
  Limited_items_list = []
  Limited_weapons_list = []
  Limited_armors_list = []
 
# Choose which variable will track the stock of the first
#      Limited Item that you specified in the array above.
#      For example, if you want to use Variable 541 to track
#      the first weapon in the array above, then replace '201'
#      with '541'.  See "How to use this script" above for more info.
 
# *** You must correctly set these variables for the script to work properly. ***
 
  First_var_items = 101
  First_var_weapons = 201
  First_var_armors = 301
 
# If you've done the above two things correctly, this script
#      will work properly.  Everything from here on is entirely
#      optional and is used to customize the system to your liking.
 
# If you want global stock of a Limited Item to increase when
#      that Limited Item is sold to a shop (so that the player
#      can 'buy it back' at the appropriate shop, then leave
#      this option as "true".  If not, change it to "false".
 
  Buyback = true
 
# Normally the Limited Item will read "(Item Name) - (#) Left"
#      if it's in stock.  However, if there are a lot of the
#      the item left in stock, you might want to just say
#      "In Stock".  Set this number to the quantity above which
#      the display will read "(Item Name) - In Stock".  If you
#      always want the number to display no matter how big it is,
#      set this equal to -1.
 
  In_stock_label = 299
 
# You may specify in which color a Limited Items will appear
#      on the shop's Buy screen.  If an item is in stock, it
#      will appear in the Limited Color (or a grayed version
#      of the Limited Color, if you don't have enough money).
#      If it's out of stock, it will appear in a grayed version
#      of the Sold Out Color (regardless of your money).
#      Acceptable values are 0-31 and you can see which number
#      corresponds to which color by going to the Resource
#      Manager, choosing Graphics/System, and viewing "Window".
 
  Limited_Color = 14
  Sold_Out_Color = 8
 
# If you want Limited Items to be shown in the Limited Color
#      on the Sell Item window, leave this option as "true".
#      If you'd rather Limited Items appear just like regular
#      items on the Sell Item window, change it to "false".
 
  Sell_limited_color = true
 
 
############################################
#                                          #
#               ICKY CODE!                 #
#                                          #
############################################
 
# Everything from here on represents the inner workings of the script.
#       Please don't alter anything from here on unless you are an
#       advanced scripter yourself (in which case, have at it!)  
 
 
 
  #--------------------------------------------------------------------------
  # This method determines whether the item/weapon/armor is a Limited Item
  #--------------------------------------------------------------------------
  def self.find_presence(item)
    if item.class == RPG::Item && Limited_Items::Limited_items_list.index(item.id) != nil
      return true
    end
    if item.class == RPG::Weapon && Limited_Items::Limited_weapons_list.index(item.id) != nil
      return true
    end
    if item.class == RPG::Armor && Limited_Items::Limited_armors_list.index(item.id) != nil
      return true
    end
    return false
  end
 
  #--------------------------------------------------------------------------
  # This method finds the variable being used to track the Limited Item
  #--------------------------------------------------------------------------
  def self.tracking_vari(item)
    if item.class == RPG::Item
      return Limited_Items::Limited_items_list.index(item.id) + Limited_Items::First_var_items
    end
    if item.class == RPG::Weapon
      return Limited_Items::Limited_weapons_list.index(item.id) + Limited_Items::First_var_weapons
    end
    if item.class == RPG::Armor
      return Limited_Items::Limited_armors_list.index(item.id) + Limited_Items::First_var_armors
    end
  end  
 
end
 
 
 
class Window_ShopBuy < Window_Selectable
 
  #--------------------------------------------------------------------------
  # * Display in Enabled State? - Customized to add functionality to the
  #                               existing "enable?" method
  #--------------------------------------------------------------------------
  alias :enable_limited_items :enable?
  def enable?(item)
    # If it's a Limited Item...
    if Limited_Items.find_presence(item)
      # Determine whether the item is enabled.  Item is disabled if Sold Out.
      if $game_variables[Limited_Items.tracking_vari(item)] <= 0
        return false
      end
    end
    enable_limited_items(item)
  end
 
end
 
class Window_ShopBuy
 
  #--------------------------------------------------------------------------
  # * Draw Limited Item Name - A separate, customized method for drawing
  #                            Limited Item names along with remaining stock
  #
  #     enabled : Enabled flag. When false, draw semi-transparently.
  #--------------------------------------------------------------------------
  def draw_limited_item_name(item, x, y, enabled = true, width = 172)
    return unless item
    draw_icon(item.icon_index, x, y, enabled)
    # Choose a color based on whether the Limited Item is in stock or sold out
    if Limited_Items.find_presence(item)
      if $game_variables[Limited_Items.tracking_vari(item)] > 0
        change_color(text_color(Limited_Items::Limited_Color), enabled)
      else
        change_color(text_color(Limited_Items::Sold_Out_Color), enabled)
      end
    # Combine the item name and number remaining into a single string
      total = $game_variables[Limited_Items.tracking_vari(item)]
      if total > 0
        # If there's more than the "In Stock Label" in stock, print "In Stock"
        if total > Limited_Items::In_stock_label && Limited_Items::In_stock_label != -1
          namestring = item.name + " - In Stock"
        # Otherwise print the quantity of stock that remains
        else
          namestring = item.name + " - " + total.to_s + " Left"
        end
      else
        # If there's none remaining, print "Sold Out!" instead of the number
        namestring = item.name + " - Sold Out!"
      end
    end
    # Draw the item, per usual
    draw_text(x + 24, y, width + 24, line_height, namestring)
  end
 
  #--------------------------------------------------------------------------
  # * Draw Item - Customized to add functionality to the existing
  #               "draw_item" method
  #--------------------------------------------------------------------------
  alias :draw_full_item :draw_item
  def draw_item(index)
    # Either use the regular draw_item_name method or the custom
    #   draw_limited_item_name method, as appropriate
    item = @data[index]
    if !Limited_Items.find_presence(item)
      draw_full_item(index)
    else
      rect = item_rect(index)
      draw_limited_item_name(item, rect.x, rect.y, enable?(item))
      rect.width -= 4
      draw_text(rect, price(item), 2)
    end
  end
 
end
 
 
 
class Window_ShopSell
 
  #--------------------------------------------------------------------------
  # * Draw Item - Taken from Window_ItemList and customized to add
  #               functionality to the existing "draw_item" method
  #--------------------------------------------------------------------------
  alias :draw_full_for_sell :draw_item
  def draw_item(index)
    item = @data[index]
    if item
      # Special logic only occurs if Sell_limited_color option is "true"
      if Limited_Items::Sell_limited_color == true
        # Find the Limited Item ID's position in the array
        if !Limited_Items.find_presence(item)
          draw_full_for_sell(index)
        else
          # If it's in the array, use the Limited Color
          rect = item_rect(index)
          rect.width -= 4
          draw_limited_sell_name(item, rect.x, rect.y, enable?(item))
          draw_item_number(rect, item)
        end
      else
        draw_full_for_sell(index)
      end
    end
  end
 
  #--------------------------------------------------------------------------
  # * Draw Number of Items - Customized to add functionality to the
  #                          existing "draw_item_number" method, but
  #                          it will act like the existing method if
  #                          the Buyback option is "false".
  #--------------------------------------------------------------------------
  alias :draw_number_for_sell :draw_item_number
  def draw_item_number(rect, item)
    # Special logic only occurs if Sell_limited_color option is "true"
    if Limited_Items::Sell_limited_color == true
      # Find the Limited Item ID's position in the array
      if !Limited_Items.find_presence(item)
        draw_number_for_sell(rect, item)
      else
        # If it's in the array, use the Limited Color
        change_color(text_color(Limited_Items::Limited_Color))
        draw_text(rect, sprintf(":%2d", $game_party.item_number(item)), 2)
      end
    else
      draw_number_for_sell(rect, item)
    end
  end
 
  #--------------------------------------------------------------------------
  # * Draw Limited Item Name - A separate, customized method taken from
  #                            based on the "Draw Item Name" method.  It
  #                            draws the item in the Limited Item Color
  #                            if the Sell_limited_color option is "true".
  #
  #     enabled : Enabled flag. When false, draw semi-transparently.
  #--------------------------------------------------------------------------
  def draw_limited_sell_name(item, x, y, enabled = true, width = 172)
    return unless item
    draw_icon(item.icon_index, x, y, enabled)
    change_color(text_color(Limited_Items::Limited_Color), enabled)
    draw_text(x + 24, y, width, line_height, item.name)
  end
 
end
 
 
 
class Scene_Shop
 
  #--------------------------------------------------------------------------
  # * Get Maximum Quantity Buyable - Customized to add functionality to
  #                                  the existing "max_buy" method
  #--------------------------------------------------------------------------
  alias :max_limited_buy :max_buy
  def max_buy
    # If the max is greater than the quantity in stock, set it equal to
    #    the quantity in stock
    if Limited_Items.find_presence(@item)
      [max_limited_buy, $game_variables[Limited_Items.tracking_vari(@item)]].min
    else
      # If not a limited item, simply execute the standard method instead
      max_limited_buy
    end
  end
 
  #--------------------------------------------------------------------------
  # * Execute Purchase - Customized to add functionality to the existing
  #                      "do_buy" method
  #--------------------------------------------------------------------------
  alias :limited_buy :do_buy
  def do_buy(number)
    limited_buy(number)
    # If it's a Limited Item...
    if Limited_Items.find_presence(@item)
      # Reduce the Game Variable that represents the Limited Item by the
      #   quantity that you bought
      $game_variables[Limited_Items.tracking_vari(@item)] -= number
    end
  end
  #--------------------------------------------------------------------------
  # * Execute Sale - Customized to add functionality to the existing
  #                  "do_sell" method, but it will act like the existing
  #                  "do_sell" method if the Buyback option is "false".
  #--------------------------------------------------------------------------
  alias :limited_sell :do_sell
  def do_sell(number)
    limited_sell(number)
    # Special Sell Processing logic only applies if "Buyback" option is "true"
    if Limited_Items::Buyback == true
      # If it's a Limited Item...
      if Limited_Items.find_presence(@item)
        # Reduce the Game Variable that represents the Limited Item by the
        #   quantity that you bought
        $game_variables[Limited_Items.tracking_vari(@item)] += number
      end
    end
  end
 
end