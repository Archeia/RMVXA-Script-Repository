#==============================================================================
# [VX] SMS - Simple Mouse System
#------------------------------------------------------------------------------
# ◦ by Woratana [woratana@hotmail.com]
# ◦ Released on: 14/04/2008 (D-M-Y)
# ◦ Version: 1.5
#
# ◦ Credit: DerVVulfman, Near Fantastica, and Freak Boy [Mouse Input Module]
# lambchop, shun, Cybersam, Astro_mech, and Mr.Mo [Super Simple Mouse System]
# - Modern Algebra, Zeriab, Patrick Lester [Path Finding] 
# - Near Fantastica, Fuso [Path Finding]
#
# - I will not be able to script this without those people and scripts above
#-----------------------------------------------------------------------------
#====[REQUIRE]=====
# - DerVVulfman's Mouse Input Module
# - Modern Algebra's Path Finding [version 2.0]
#
#====[FEATURE]=====
# - Support to use mouse in many scenes / windows
# - Mouse Pointer
# - Click on map to move player with Path Finding
# - Click on event to go talk/interact with that event
# - Click on event to walk to that event and interact
# - You can choose scene(s) that don't want to use mouse
# - You can turn mouse ON/OFF automatically by call script:
# $scene.no_mouse = (true/false) # True to turn off mouse

#====[MOUSE TAGS]=====
# Put one (or more) of these tags in the event command 'Comment..'
# [mauto] : This event will run automatically after click on it
# [mnone] : This event will not be determine as event when click on it
# (a.k.a. Player will not interact with it)

# [mtop] : Player will always stop at tile above this event when click on it
# [mleft] : Same as [mtop], but left side
# [mright] : Same as [mtop], but right side
# [mdown] : Same as [mtop], but below
#------------------------------------------------------------------------------

ENEMY_BATTLE_CURSOR_RECT_ADJUSTMENT = 0.7
# detection area for enemies, 1.0 is normal, 0.7 is 70% etc

module Mouse
#==============================================================================
# MOUSE SETUP PART
#----------------------------------------------------------------------------
Scroll_Delay = 30 # (in Frames)
# Mouse Delay when scroll up or down the list

Path_Finding_Iteration = 0 # (Integer, 0 for no limit)
# How deep you want path finding to process until find the way
# less number will be able to find only easy path, less lag
# high number will be able to find complicated path, possible to increase lag

Scene_No_Mouse = []
# Scene(s) that you don't want to use mouse
# e.g. Scene_No_Mouse = [Scene_File, Scene_Map, Scene_Title]

Auto_Find_Destination = true
# It will automatically find the cloeset destination on map
# when click on unpassable tile.
#==============================================================================
end

#==============================================================================
# ** Mouse Input Module
#==============================================================================

module Mouse
  
  SHOW_CURSOR = Win32API.new('user32', 'ShowCursor', 'l', 'l')
  # takes 0 or 1, hides or shows cursor specific to the window handle of the current instance
  # SHOW_CURSOR.call(0)
  SET_CLASS_LONG = Win32API.new('user32', 'SetClassLong', 'pil', 'i')
  # set a class long property, takes a program instance handle, 
  # an integer signifying which property is to be changed, 
  # and a long unsigned, which specificies what the property is changed to

  # PERM_CHANGE_CURSOR.call(Mouse.hwnd, -12, 0)

  HINST = Win32API.new('user32', 'GetWindowLong', 'pi', 'l')
  # API call to get the handle for the current instance
  hinst = HINST.call(Mouse.hwnd, -6) # get the actual handle
  $CURSOR = Win32API.new('user32', 'LoadCursorFromFile', 'p', 'l').call('cursor.cur')
  # load a cursor from a file and save the handle into a global variable
  $SETCURSOR = Win32API.new('user32', 'SetCursor', 'l', 'l')
  # API call to change the cursor (not used)
  DESTROYCURSOR = Win32API.new('user32', 'DestroyCursor', 'l', 'l')
  # API call to destroy the cursor (not used)
  CC = Win32API.new('user32', 'CreateCursor', 'piiiipp', 'i')
  # API call to create a cursor (not used)
  # HINST = Win32API.new('kernel32', 'GetModuleHandle', 'i', 'p')
  # CURSOR = CC.call(hinst, 0, 0, 32, 32, "0", "0")
  #CT = Thread.new { loop do 
  #  $SETCURSOR.call($CURSOR)
  #end 
  # } 
  # thread to continually set cusror to the appropriate file (not used, lags)
  # $SETCURSOR.call($CURSOR)
  # set the current cursor to the cursor from the file
  # (not used, changes back whenever the cursor is moved)
  SET_CLASS_LONG.call(Mouse.hwnd, -12, $CURSOR)
  # call the set class long api
  # first argument is the handle for this instance,
  # second argument is -12, meaning we are setting the long for the cursor
  # long used is the cursor loaded in previous API call
  # using 0 as the cursor is supposed to clear the cursor, but it will reappear
  # in the window as soon as the cursor leaves the window and goes back in
  # therefore, we use a blank
  
  # p CT.inspect
end

class << Mouse

  $mousec = Sprite.new
  $mousec.z = 10001
  $mousec.x = $mousec.y = 1000
  $mouse_icon = $base_cursor = 'foxkeh_cursor'
  $mousec.bitmap = Cache.system($base_cursor)
  $mouse_duration = -1
  $mouse_changed = false
  
  @@calls = 0
  @@update_time = 0
  
  alias wor_mouse_upd_mouse update unless $@
  def Mouse.update
    #@@calls += 1
    #t = Time.now
    #SETCURSOR.call(CURSOR)
    #SHOW_CURSOR.call(2 ** 8)
    # $SETCURSOR.call($CURSOR)
    wor_mouse_upd_mouse
    if $scene.no_mouse
      $mousec.visible = false if $mousec.visible
      return
    else; $mousec.visible = true if !$mousec.visible
    end
    if $mouse_old_icon.nil? or $mouse_old_icon != $mouse_icon
      $mouse_old_icon = $mouse_icon
      $mousec.bitmap = Cache.system($mouse_old_icon)
    end
    if @pos.nil?
      $mousec.x = 1000 if $mousec.x != 1000
      $mousec.y = 1000 if $mousec.y != 1000
    else
      $mousec.x = @pos[0] if $mousec.x != @pos[0]
      $mousec.y = @pos[1] if $mousec.y != @pos[1]
    end
    #@@update_time += Time.now - t
    #if @@calls == 600
      #p @@update_time
      #@@calls = 0
      #@@update_time = 0
    #end
  end
  
  def Mouse.map_pos
    return nil if @pos == nil 
    x = ($game_map.display_x / 256) + (@pos[0] + 16) / 32
    y = ($game_map.display_y / 256) + (@pos[1] / 32)
    return [x, y]
  end
end

#==============================================================================
# ** Input
#==============================================================================
class << Input
  alias wor_input_upd_mouse update unless $@
  alias wor_input_trig_mouse trigger? unless $@
  alias wor_input_rep_mouse repeat? unless $@
  def Input.update
    wor_input_upd_mouse
    Mouse.update
  end
  
  def Input.trigger?(input)
    return wor_input_trig_mouse(input) if Mouse.pos.nil?
    if input == Input::B and !$scene.no_mouse
      return (wor_input_trig_mouse(input) or Mouse.click?(2))
    elsif input == Input::C and !$scene.no_mouse
      if $scene.is_a?(Scene_Map) and !$game_message.visible
        return wor_input_trig_mouse(input)
      else
        return (wor_input_trig_mouse(input) or Mouse.click?(1))
      end
    else
      return wor_input_trig_mouse(input)
    end
  end
  
  def Input.repeat?(input)
    if input == Input::B and !$scene.no_mouse
      return (wor_input_rep_mouse(input) or Mouse.click?(2))
    else
      return wor_input_rep_mouse(input)
    end
  end
end
#==============================================================================
# ** Graphics
#==============================================================================
class << Graphics
  alias wor_graph_fadeout_mouse fadeout unless $@
  def Graphics.fadeout(frames = 1)
    $mousec.visible = false if !$mousec.nil?
    wor_graph_fadeout_mouse(frames)
  end
end
#==============================================================================
# ** Window_Selectable
#==============================================================================
class Window_Selectable < Window_Base
  alias wor_winsel_ini_mouse initialize
  alias wor_winsel_upd_mouse update
  def initialize(*args)
    wor_winsel_ini_mouse(*args)
    @scroll_wait = 0
    @cursor_wait = 0
  end

  def update
    wor_winsel_upd_mouse
    update_mouse if self.active and self.visible
  end
  
  def update_mouse
    @cursor_wait -= 1 if @cursor_wait > 0
    (0..@item_max - 1).each do |i|
      irect = item_rect(i)
      irx = self.x + 16 + irect.x - self.ox
      iry = self.y + 16 + irect.y - self.oy
      if Mouse.area?(irx, iry, irect.width, irect.height)
        move_cursor(i)
        break
      end
    end
  end

  def move_cursor(index)
    return if @index == index
    @scroll_wait -= 1 if @scroll_wait > 0
    row1 = @index / @column_max
    row2 = index / @column_max
    bottom = self.top_row + (self.page_row_max - 1)
    if row1 == self.top_row and row2 < self.top_row
      return if @scroll_wait > 0
      @index = [@index - @column_max, 0].max
      @scroll_wait = Mouse::Scroll_Delay
    elsif row1 == bottom and row2 > bottom
      return if @scroll_wait > 0
      @index = [@index + @column_max, @item_max - 1].min
      @scroll_wait = Mouse::Scroll_Delay
    else
      @index = index
    end
    return if @cursor_wait > 0
    Sound.play_cursor
    @cursor_wait += 2
  end
end
#==============================================================================
# ** Window_MenuStatus
#==============================================================================
class Window_MenuStatus < Window_Selectable
  def item_rect(index)
    q = index == 0 ? 0 : 6
    r = index == 0 ? 6 : 0
    return Rect.new(0, index * 96 - 10 - index - q, contents.width, 95 - r)
  end
end
#==============================================================================
# ** Window_NameInput
#==============================================================================
class Window_NameInput < Window_Base
  alias wor_winnam_upd_mouse update
  def update
    wor_winnam_upd_mouse
    if self.active and self.visible
      (0..TABLE[@mode].size - 1).each do |i|
      irect = item_rect(i)
      irx = self.x + 16 + irect.x - self.ox
      iry = self.y + 16 + irect.y - self.oy
      @index = i if Mouse.area?(irx, iry, irect.width, irect.height)
      end
    end
  end
end
#==============================================================================
# ** Window_PartyCommand
#==============================================================================
class Window_PartyCommand < Window_Command
  def update_mouse
    (0..@item_max - 1).each do |i|
    irect = item_rect(i)
    irx = self.viewport.ox + 16 + irect.x - self.ox
    iry = 288 + 16 + irect.y - self.oy
    self.index = i if Mouse.area?(irx, iry, irect.width, irect.height)
    end
  end
end
#==============================================================================
# ** Window_ActorCommand
#==============================================================================
class Window_ActorCommand < Window_Command
  def update_mouse
    @cursor_wait -= 1 if @cursor_wait > 0
    (0..@item_max - 1).each do |i|
    irect = item_rect(i)
    irx = self.x + 16 + irect.x - self.ox
    #irx = self.viewport.ox + 288 + 16 + irect.x
    iry = self.y + 16 + irect.y
    #iry = 288 + 16 + irect.y
    if Mouse.area?(irx, iry, irect.width, irect.height)
      move_cursor(i)
      break
    end
    end
  end
end
#==============================================================================
# ** Window_Message
#==============================================================================
class Window_Message < Window_Selectable
  def update_mouse
    (0..@item_max - 1).each do |i|
      irect = item_rect(i)
      irx = self.x + 16 + irect.x - self.ox
      iry = self.y + 16 + irect.y - self.oy + ($game_message.choice_start * WLH)
      self.index = i if Mouse.area?(irx, iry, irect.width, irect.height)
    end
  end
end

#==============================================================================
# ** Scene_Base
#==============================================================================
class Scene_Base
  alias wor_scebase_posstr_mouse post_start
  alias wor_scebase_preter_mouse pre_terminate
  attr_accessor :no_mouse
  
  def post_start
    if !$mousec.nil?
      $mousec.visible = true
      @no_mouse = false
      # If this scene is in Scene_No_Mouse
      Mouse::Scene_No_Mouse.each do |sce|
        if $scene.is_a?(sce)
          $mousec.visible = false
          @no_mouse = true
        end
      end
    end
    wor_scebase_posstr_mouse
  end
  
  def pre_terminate
    $mousec.visible = false if !$mousec.nil?
    wor_scebase_preter_mouse
  end
end
#==============================================================================
# ** Scene_File
#==============================================================================
class Scene_File < Scene_Base
  alias wor_scefil_upd_mouse update
  def update
    (0..@item_max - 1).each do |i|
      ix = @savefile_windows[i].x
      iy = @savefile_windows[i].y
      iw = @savefile_windows[i].width
      ih = @savefile_windows[i].height
      if Mouse.area?(ix, iy, iw, ih)
        @savefile_windows[@index].selected = false
        @savefile_windows[i].selected = true
        @index = i
      end
    end
    wor_scefil_upd_mouse
  end
end
#==============================================================================
# ** Scene_Map
#==============================================================================
class Scene_Map < Scene_Base
  alias wor_scemap_upd_mouse update
  
  def update
    wor_scemap_upd_mouse
    if !@no_mouse
      # IF left click
      if Mouse.click?(1) and !$game_message.visible and
        !$game_map.interpreter.running? and !$game_player.moving?
        mouse_xy = Mouse.map_pos
        return if mouse_xy.nil?
        old_direction = $game_player.direction
        $game_player.turn_toward_pos(mouse_xy[0], mouse_xy[1])
        # IF click near player, and there's trigger to event, run event
        return if ($game_player.front?(mouse_xy[0],mouse_xy[1]) and
      $game_player.check_action_event)
      # $game_player.clear_path
      # $game_player.mouse_force_path(mouse_xy[0], mouse_xy[1])
      # IF middle click
      elsif Mouse.click?(3) and !$game_message.visible and
        !$game_map.interpreter.running?
        mouse_xy = Mouse.map_pos
        return if mouse_xy.nil?
        $game_player.clear_path
        $game_player.turn_toward_pos(mouse_xy[0], mouse_xy[1])
      end
    end
  end
end
#==============================================================================
# ** Game_Character
#==============================================================================
class Game_Character
  def mouse_force_path(x, y, auto_check = ($game_map.events_xy(x, y).size > 0))
    ori_x, ori_y = x, y
    path_xy = $game_map.find_dest_xy(x, y, @x, @y)
    return if path_xy.nil?
    x, y = path_xy[0] ,path_xy[1]
    # Force_move from MA's path finding
    if map_passable?(x,y)
      path = $game_map.find_path (self.x, self.y, x, y, false, 
      Mouse::Path_Finding_Iteration, self)
      path.reverse!
      # Turn toward destination
      newmove = RPG::MoveCommand.new
      newmove.code = 45 # Script..
      newmove.parameters = ["turn_toward_pos(#{ori_x},#{ori_y})"]
      path.push newmove
      # Add script to check if there's event trigger
      if auto_check
        newmove = RPG::MoveCommand.new
        newmove.code = 45
        newmove.parameters = ['check_action_event']
        path.push newmove
      end
      # Add an end command
      path.push (RPG::MoveCommand.new (0))
      move_route = RPG::MoveRoute.new
      move_route.list = path
      move_route.repeat = false
      force_move_route (move_route)
    end
  end
  
  def clear_path
    @move_route_index = 0
    @move_route = RPG::MoveRoute.new
    @move_route.repeat = false
  end

  def turn_toward_pos(x,y)
    sx = distance_x_from_pos(x)
    sy = distance_y_from_pos(y)
    if sx.abs > sy.abs                    # Horizontal distance is longer
      sx > 0 ? turn_left : turn_right
    elsif sx.abs < sy.abs                 # Vertical distance is longer
      sy > 0 ? turn_up : turn_down
    end
  end

  def distance_x_from_pos(x)
    sx = @x - x
    if $game_map.loop_horizontal?
      if sx.abs > $game_map.width / 2
        sx -= $game_map.width
      end
    end
    return sx
  end
  
  def distance_y_from_pos(y)
    sy = @y - y
    if $game_map.loop_vertical?
      if sy.abs > $game_map.height / 2
        sy -= $game_map.height
      end
    end
    return sy
  end
  
  def front?(x,y)
    case @direction
    when 2; return true if (x == @x and y == @y + 1)
    when 4; return true if (x == @x - 1 and y == @y)
    when 6; return true if (x == @x + 1 and y == @y)
    when 8; return true if (x == @x and y == @y - 1)
    end
    return false
  end
end
#==============================================================================
# ** Game_Map
#==============================================================================
class Game_Map
  # Find Destination for Path Finding
  def find_dest_xy(x, y, self_x, self_y)
    has_event = false
    event_ary = events_xy(x, y)
    # Remove Event that has 'mnone'
    (event_ary).each do |i|
      event_ary.delete(i) if i.comment?('[mnone]')
    end
    # Return original x, y if there are more than 1 events,
    # or the only event has priority type 'Below Character'
    if (event_ary.size == 1 and event_ary[0].priority_type != 1) or
    event_ary.size > 1
      return [x, y]
    elsif event_ary.size == 1
      # IF there's event, check for reserved direction
      has_event = true
      if event_ary[0].comment?('[mtop]')
        return [x, y-1]
      elsif event_ary[0].comment?('[mleft]')
        return [x-1, y]
      elsif event_ary[0].comment?('[mright]')
        return [x+1, y]
      elsif event_ary[0].comment?('[mdown]')
        return [x, y+1]
      elsif event_ary[0].comment?('[mauto]')
        event_ary[0].start
        return nil
      end
    end
    # Check for passable direction or it's Same X/Y or doesn't allow auto-find
    if (event_ary.size != 1 and $game_player.map_passable?(x, y)) or (self_x == x and self_y == y) or
  (!Mouse::Auto_Find_Destination and !has_event)
      return [x, y]
    end
    # Find nearest path
    nx = (self_x - x)
    ny = (self_y - y)
    npath_real = []
    if (nx.abs < ny.abs and nx != 0) or (ny == 0) # X is closer than Y
      npath_real << (nx > 0 ? 'right' : 'left')
    else # EQUAL, or Y is closer than X
      npath_real << (ny > 0 ? 'up' : 'down')
    end
    npath_real_tran = move_translate(npath_real, x, y) # Translate word to value
    # If the fastest way is possible, return it
    if $game_player.map_passable?(npath_real_tran[0][0], npath_real_tran[0][1])
      return [npath_real_tran[0][0], npath_real_tran[0][1]]
    end
    npath = []
    # Add other possible ways
    npath << 'up' if !npath_real.include?('up')
    npath << 'left' if !npath_real.include?('left')
    npath << 'down' if !npath_real.include?('down')
    npath << 'right' if !npath_real.include?('right')
    npath = move_translate(npath, x, y) # Translate other possible ways
    (0..npath.size-1).each do |np| # Calculate distance from each point
      npath[np] =
      [npath[np], (self_x - npath[np][0]).abs + (self_y - npath[np][1]).abs]
    end
    npath = npath.sort_by {|i| i[1]} # Sort by Distance
    # Check to move~
    npath.each do |n|
      return [n[0][0], n[0][1]] if $game_player.map_passable?(n[0][0], n[0][1])
    end
    # IF there's no way to go
    return nil
  end
  
  def move_translate(ary, x, y)
    (0..ary.size - 1).each do |n|
      if ary[n] == 'up'
        ary[n] = [x, y-1]
      elsif ary[n] == 'left'
        ary[n] = [x-1, y]
      elsif ary[n] == 'right'
        ary[n] = [x+1, y]
      elsif ary[n] == 'down'
        ary[n] = [x, y+1]
      end
    end
    return ary
  end
end
#==============================================================================
# ** Game_Event
#==============================================================================
class Game_Event < Game_Character
  def comment?(comment, return_index = false )
    if !@list.nil?
      for i in 0...@list.size - 1
        next if @list[i].code != 108
        (0..@list[i].parameters.size - 1).each do |j|
          if @list[i].parameters[j].include?(comment)
            return [true, [i,j]] if return_index
            return true
          end
        end
      end
    end
    return [false, nil] if return_index
    return false
  end
end

class Window_BattleStatus
  
  def update_mouse
    return unless cursor_movable?
    @cursor_wait -= 1 if @cursor_wait > 0
    (0..@item_max - 1).each do |i|
      irect = item_rect(i)
      irx = irect.x
      iry = 480 - 184
      if Mouse.area?(irx, iry, irect.width, 184)
        move_cursor(i)
        break
      end
    end
  end

end

class Window_System < Window_Selectable
  def item_rect(index)
    rect = Rect.new(0, 0, 0, 0)
    case index
    when 0
      rect.x = 0
      rect.y = 0
      rect.width = contents.width
      rect.height = WLH * 2
    when 1
      rect.x = 0
      rect.y = WLH * 2
      rect.width = contents.width
      rect.height = WLH * 2
    when 2
      rect.x = 0
      rect.y = WLH * 4
      rect.width = contents.width
      rect.height = WLH * 2
    when 3
      rect.x = 0
      rect.y = WLH * 6
      rect.width = contents.width
      rect.height = WLH * 2
    when 4
      rect.x = 0
      rect.y = WLH * 8
      rect.width = contents.width
      rect.height = WLH
    #---
    when 5
      rect.x = 0
      rect.y = WLH * 9
      rect.width = contents.width
      rect.height = WLH
    when 6
      rect.x = 0
      rect.y = WLH * 10
      rect.width = contents.width
      rect.height = WLH
    when 7
      rect.x = 0
      rect.y = WLH * 11
      rect.width = contents.width
      rect.height = WLH
    when 8
      rect.x = 0
      rect.y = WLH * 12
      rect.width = contents.width
      rect.height = WLH
    when 9
      rect.x = 0
      rect.y = WLH * 13
      rect.width = contents.width
      rect.height = WLH
    when 10
      rect.x = 0
      rect.y = WLH * 14
      rect.width = contents.width
      rect.height = WLH
    end
    return rect
  end
  
#~   def update_mouse
#~     (0..@item_max - 1).each do |i|
#~       irect = item_rect(i)
#~       vx = viewport.nil? ? 0 : viewport.rect.x
#~       vy = viewport.nil? ? 0 : viewport.rect.y
#~       irx = irect.x + self.x + 16 + vx
#~       iry = irect.y + self.y + 16 + vy
#~       move_cursor(i) if Mouse.area?(irx, iry, irect.width, irect.height)
#~       # rect_special_input_update if Mouse.click?(1)
#~     end
#~   end
  
#~   def rect_special_input_update
#~     pos = Mouse.pos
#~     return if pos.nil?
#~     posx, posy = pos[0] + self.x + 16, pos[1] + self.y + 16
#~     case @index
#~     when 0
#~       if posy > WLH
#~         dx = contents.width / 5
#~         
#~         
#~       end
#~     when 1
#~       
#~     when 2
#~       
#~     when 3
#~       
#~     when 4
#~       
#~     when 5
#~       
#~     when 6
#~       
#~     when 7
#~       
#~     when 8
#~       
#~     end
#~   end
#~   

  
end

class Window_TargetEnemy
  def item_rect(index)
    enemy = @enemies[index]
    rect = Rect.new(0, 0, 0, 0) 
    if enemy != nil
      rect.x = enemy.screen_x - (enemy.w_backref / 2) + 48
      rect.y = enemy.screen_y - enemy.h_backref + 32
      rect.height = enemy.h_backref
      rect.width = enemy.w_backref
    end
    return rect
  end
  
  def update_mouse
    # @sprites["cursor"].visible = false
    @cursor_wait -= 1 if @cursor_wait > 0
    (0..@item_max - 1).each do |i|
      irect = item_rect(i)
      vx = viewport.nil? ? 0 : viewport.rect.x - viewport.ox
      vy = viewport.nil? ? 0 : viewport.rect.y - viewport.oy
      irx = irect.x + vx 
      iry = irect.y + vy
      ca = ENEMY_BATTLE_CURSOR_RECT_ADJUSTMENT
      irx = irx + irect.width * (1 - ca) / 2
      iry = iry + irect.height * (1 - ca) / 2
      irw = irect.width * ca
      irh = irect.height * ca
      if Mouse.area?(irx, iry, irw, irh)
        move_cursor(i)
        break
      end
    end
  end


  
end

class Game_Enemy
  def h_backref
    $scene.spriteset.enemy_sprites[-1 - self.index].height
  end
  
  def w_backref
    $scene.spriteset.enemy_sprites[-1 - self.index].width    
  end
  
end
    
class Spriteset_Battle
  attr_reader :enemy_sprites
end

class Scene_Battle
  attr_reader :spriteset
end

class Scene_File
  
  def update
    (0..@item_max - 1).each do |i|
      ix = @savefile_windows[i].x + @viewport.rect.x - @viewport.ox
      iy = @savefile_windows[i].y + @viewport.rect.y - @viewport.oy - 10
      iw = @savefile_windows[i].width
      ih = @savefile_windows[i].height
      if Mouse.area?(ix, iy, iw, ih)
        @savefile_windows[@index].selected = false
        @savefile_windows[i].selected = true
        if @index != i
          @index = i
          Sound.play_cursor
        end
        break
      end
    end
    wor_scefil_upd_mouse
  end
end

class Window_Selectable
  def update_mouse
    @cursor_wait -= 1 if @cursor_wait > 0
    (0..@item_max - 1).each do |i|
      irect = item_rect(i)
      vx = viewport.nil? ? 0 : viewport.rect.x - viewport.ox
      vy = viewport.nil? ? 0 : viewport.rect.y - viewport.oy
      irx = self.x + 16 + irect.x - self.ox + vx
      iry = self.y + 16 + irect.y - self.oy + vy
      if Mouse.area?(irx, iry, irect.width, irect.height)
        move_cursor(i) 
        break
      end
    end
  end
  
  def move_cursor(index)
    return if @index == index
    @scroll_wait -= 1 if @scroll_wait > 0
    row1 = @index / @column_max
    row2 = index / @column_max
    bottom = self.top_row + (self.page_row_max - 1)
    if row1 == self.top_row and row2 < self.top_row
      return if @scroll_wait > 0
      @index = [@index - @column_max, 0].max
      @scroll_wait = Mouse::Scroll_Delay
    elsif row1 == bottom and row2 > bottom
      return if @scroll_wait > 0
      @index = [@index + @column_max, @item_max - 1].min
      @scroll_wait = Mouse::Scroll_Delay
    else
      @index = index
    end
    return if @cursor_wait > 0
    Sound.play_cursor
    @cursor_wait = 0
  end

end