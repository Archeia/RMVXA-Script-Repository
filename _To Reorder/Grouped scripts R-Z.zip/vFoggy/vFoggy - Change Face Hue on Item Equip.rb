# Changes the hue of the actor's face according to the note of one of the 
# equipments.
# 
# Note on equipment: 
#   <Hue: value>, where value is the hue degree of displacement.
# -------------------
# Script by: vFoggy


class RPG::EquipItem < RPG::BaseItem
  def hue
    note =~ /<Hue: (\d+)>/ ? $1.to_i : -1
  end
end


class Window_Base
  def draw_actor_face(actor, x, y, enabled = true)
    @actor = actor
    draw_face(actor.face_name, actor.face_index, x, y, enabled)
  end
  
  def draw_face(face_name, face_index, x, y, enabled = true)
    bitmap = Cache.face(face_name)
    if !@actor.nil?
      equip = @actor.equips.select{|e| !e.nil? && e.hue != -1}[0]
      bitmap.hue_change(equip.hue) unless equip.nil?
    end
    rect = Rect.new(face_index % 4 * 96, face_index / 4 * 96, 96, 96)
    contents.blt(x, y, bitmap, rect, enabled ? 255 : translucent_alpha)
    bitmap.dispose
  end
end