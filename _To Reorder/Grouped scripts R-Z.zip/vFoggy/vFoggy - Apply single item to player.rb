# Apply item to the player when there is only one player 
# in the game and none will be added.
# by vFoggy
# https://forums.rpgmakerweb.com/index.php?threads/when-use-item-automatically-force-it-to-player-1.75598/
#
#
class Scene_ItemBase < Scene_MenuBase 
  def determine_item
    if item.for_friend?
      @actor_window.select_for_item(item)
      @actor_window.process_ok
      hide_sub_window(@actor_window)
    else
      use_item
      activate_item_window
    end
  end
 
  def use_item
    play_se_for_item
    user.use_item(item)
    use_item_to_actors
    check_common_event
    check_gameover
  end
end