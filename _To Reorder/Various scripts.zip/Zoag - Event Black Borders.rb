=begin
#==============================================================
Title         : Event Borders V1.0
Author        : ZOAG & Signum1221
Last Modified : 21.02.2015

--------------------------------------------------------------
	Description
--------------------------------------------------------------
You know how some games make the screen smaller when an event is happening?
Like MOTHER 3 for example? They will add black borders at the top and bottom
of the screen.

This simple script was created to simulate exactly that.

Special thanks to Signum1221 for helping me out with the code!

--------------------------------------------------------------
	Terms of use
--------------------------------------------------------------
You're free to use and modify this script any way you want and use it for any
of your projects, be it commercial or non-commercial.
Credit not needed, would be nice though. :)

--------------------------------------------------------------
	How to use
--------------------------------------------------------------
To make use of this script in an event,
use the script calls "eventBorderStart()" and "eventBorderEnd()"
to make the event borders appear and disappear.

#==============================================================
=end



# script checks to see if any of the two variables are set to true.
# if "$eventBorderStartScene" is true, it will make the borders appear outside
# of the screen and move them into the screen.
# if "$eventBorderEndScene" is true, it will move the existing borders out of
# the screen and make them disappear once they're completely off-screen.
$eventBorderStartScene	= false
$eventBorderEndScene	= false

$borderYsize = 30   # y size of event border
$borderXsize = 544  # x size of event border

# color of event border, which is set as black
$borderColor = Color.new(0, 0, 0)

# amount of frames for the movement, which is equal to y size of border
$frames = $borderYsize

# amount of time it should wait before it gives control back to player
# it's equal to y size of border + 10
$wait = $borderYsize + 10

class Scene_Base

	alias event_border_default_update update
	
	# true if event borders are moving IN
	@eventBorderMovingIn = false
	
	# true if event borders are moving OUT
	@eventBorderMovingOut = false
	
	# creates both top and bottom event borders
	def eventBorderStartScene
	
		# creates sprite "containers" for both borders
		@eventBorderTop = Sprite.new()
		@eventBorderBot = Sprite.new()
		
		# assigns y and z positions of both borders
		# z position is needed in case your event border gets covered by another image
		# increase z position if that happens
		@eventBorderTop.y = -30
		@eventBorderTop.z = 10
		@eventBorderBot.y = 416
		@eventBorderBot.z = 10
		
		# creates a bitmap for both sprite containers
		# using the dimensions defined above
		@eventBorderTop.bitmap = Bitmap.new($borderXsize, $borderYsize)
		@eventBorderBot.bitmap = Bitmap.new($borderXsize, $borderYsize)
		
		# fills bitmap with dimensions and color defined above
		# first two 0s define x and y position INSIDE image (don't change them)
		@eventBorderTop.bitmap.fill_rect(0, 0, $borderXsize, $borderYsize, $borderColor)
		@eventBorderBot.bitmap.fill_rect(0, 0, $borderXsize, $borderYsize, $borderColor)
	end
	
	# disposes of both top and bottom event borders
	def eventBorderEndScene
		@eventBorderTop.dispose
		@eventBorderBot.dispose
	end
	
	# this runs each frame and updates the positions of both event borders
	def update
		
		event_border_default_update
		
		# checks to see if "$eventBorderStartScene" is true.
		# if it is, it sets it back to false and
		# executes the function "eventBorderStartScene" to create the event borders.
		# it then sets "@eventBorderMovingIn" to true,
		# so the event borders move into the screen.
		if($eventBorderStartScene)
			$eventBorderStartScene = false
			eventBorderStartScene
			@eventBorderMovingIn = true
		end
		
		# checks to see if "$eventBorderEndScene" is true.
		# if it is, it sets it back to false.
		# it then sets "@eventBorderMovingOut" to true,
		# so the event borders move out of the screen.
		if($eventBorderEndScene)
			$eventBorderEndScene = false
			@eventBorderMovingOut = true
		end
		
		# checks to see if "@eventBorderMovingIn" is true
		# if it is, it will keep moving the event borders further into the screen
		# with each frame
		if(@eventBorderMovingIn)
			$frames = $frames - 1
			@eventBorderTop.y = @eventBorderTop.y + 1
			@eventBorderBot.y = @eventBorderBot.y - 1
			
			# checks to see if "$frames" is <= 1
			# if it is, "@eventBorderMovingIn" is set back to false,
			# stopping the movement (event borders arrived at their destination).
			# it then resets "$frames" back to its original value of "$borderYsize".
			if($frames <= 1)
				@eventBorderMovingIn = false
				$frames = $borderYsize
			end
		end
		
		# checks to see if "@eventBorderMovingOut" is true.
		# if it is, it will keep moving the event borders further into the screen
		# with each frame
		if(@eventBorderMovingOut)
			$frames = $frames - 1
			@eventBorderTop.y = @eventBorderTop.y - 1
			@eventBorderBot.y = @eventBorderBot.y + 1
			
			# checks to see if "$frames" is <= 1
			# if it is, "@eventBorderMovingIn" is set back to false,
			# stopping the movement (event borders arrived at their destination).
			# it then resets "$frames" back to its original value of "$borderYsize"
			# and disposes the event borders through the function "eventBorderEndScene"
			if($frames <= 1)
				@eventBorderMovingOut = false
				$frames = $borderYsize
				eventBorderEndScene
			end
		end
	end
end

# the actual function calls you need to insert in your event
class Game_Interpreter

	# creates the event borders and moves them into the screen.
	# it waits the amount defined under "$wait" before player can do something.
	# used to prevent players from breaking the script,
	# for example if they call the event again too quickly before the borders
	# can fully disappear.
	def eventBorderStart()
		$eventBorderStartScene = true
		wait($wait)
	end
	
	# moves the event borders out of the screen and disposes of them.
	# it waits the amount defined under "$wait" before player can do something.
	# used to prevent players from breaking the script,
	# for example if they call the event again too quickly before the borders
	# can fully appear.
	def eventBorderEnd()
		$eventBorderEndScene = true
		wait($wait)
	end
end