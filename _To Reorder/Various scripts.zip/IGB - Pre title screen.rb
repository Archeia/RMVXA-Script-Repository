#=============================================================================#
#-----------------------------------------------------------------------------#
#---------------------IBG Flash Screen/Skip Title V2.0------------------------#
#=============================================================================#
#--------------------------------Free to use----------------------------------#                 
#-----------------------------No credit needed--------------------------------#
#----------Special Thanks to Doctor Todd for his contribution on BGM----------#
#=============================================================================#
#-----------------------------------Setup-------------------------------------#
#---Just place below materials and specify image to be used as flash screen.--#
#-------------------(Must be in Graphics/System folder)-----------------------#
#=============================================================================#
class IBG_PT < Scene_Base
  module IBG
    
#=============================================================================#
#------------------------------------Setup------------------------------------#
#=============================================================================#
# Flash: Flash image filenames. (must be in Graphics/System)                  #
# Ex. ["Flash1",Flash2",Flash3",]                                             #
# NumF: Number of flash screens. (Be sure to add all of them to Flash)        #
# Delay: How long to display flash screens in frames. (60 frames = 1 Second)  #
# Skip: Skip title if no save exists.                                         #
# MUS: Play music with flash screens.                                         #
# FAD: Fade out music before Title Screen.                                    #
# BGM: Name of music file to play.                                            #
# Skip_Key: Key to skip flash screens, nil to disallow.                       #
# Ex. :A, :B, or :C (Default :C)                                              #
#=============================================================================#
    Flash    = ["r2g"]
    NumF     = 1
    Delay    = 140
    Skip     = false
    MUS      = false
    FAD      = false
    BGM      = ""
    Skip_Key = :C
  end
  
#=============================================================================#
#---------------------------------Processing----------------------------------#
#=============================================================================#

  def initialize
    @time = IBG::Delay
    @screen = 0
    @shown = 0
  end

  def start
    super  
    create_background
    if IBG::MUS
      Audio.bgm_play("Audio/BGM/" + IBG::BGM, 100, 100) #(DoctorTodd edit)
    end
  end

  def create_background
    @time = IBG::Delay
    @sprite = Sprite.new
    @sprite.bitmap = Cache.system(IBG::Flash[@screen])
    @screen += 1
    @shown += 1
  end

  def update
    super
    if Input.press?(IBG::Skip_Key)
      goto_title
    end
    if  @shown == IBG::NumF and @time == 0
      goto_title
    else
      if @time == 0 and @shown <= IBG::NumF
        create_background
      else
        @time -= 1
      end
    end
  end

  def dispose_background
    @sprite.bitmap.dispose
    @sprite.dispose
  end

  def goto_title
    if IBG::Skip
      if DataManager.save_file_exists?
        if IBG::FAD
          fadeout_all
        end
        SceneManager.goto(Scene_Title)
        else
          DataManager.setup_new_game
        if IBG::FAD
          fadeout_all
        end
        $game_map.autoplay
        SceneManager.goto(Scene_Map)
      end
      else
      DataManager.save_file_exists?
        if IBG::FAD
          fadeout_all
        end
      SceneManager.goto(Scene_Title)
    end
  end
end

module SceneManager

  def self.first_scene_class
    $BTEST ? Scene_Battle : IBG_PT
  end
end