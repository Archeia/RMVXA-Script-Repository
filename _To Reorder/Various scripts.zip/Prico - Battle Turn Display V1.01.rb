#==============================================================================
# ★ RGSS3_TurnWindowDisplayforBattle Ver1.01
#==============================================================================
=begin
 
  Author:ぷり娘 (prico)
web site:Sister's Eternal 4th(Ancient)
     URL:http://pricono.whitesnow.jp/
Permission to use: Not required, but please mention in the game, Readme, etc.
 
Displays the current amount of turns on the battle screen.
The number of turns is displayed up to 3 digits (limit 999 turns)
 
By default, it'll appear in semi-transparent window.
Position of Turn Window can be change through script setting.
 
Also, it will hidden during battle events.
 
 
 
2012.06.21 Ver1.00 Public release
2012.06.23 Ver1.01 Fixed a bug where an enemy action does not match # turn display.
 
=end
 
 
#==============================================================================
# Setting
#==============================================================================
module Prico
 
  #X coordinate of Turn Window
  WindowX = 440
 
  #Y coordinate of Turn Window
  WindowY = 0
 
  #Turn Window width
  WindowW = 104

  #Turn Window Opacity
  View = 255
  
end

#==============================================================================
# ■ Scene_Battle
#------------------------------------------------------------------------------
# 　Class that performs battle screen processing
#==============================================================================
class Scene_Battle < Scene_Base
  #--------------------------------------------------------------------------
  # ● Create all windows(alias)
  #--------------------------------------------------------------------------
  alias create_all_windows_org create_all_windows
  def create_all_windows
    create_all_windows_org
    create_turn_window 
  end
 
  #--------------------------------------------------------------------------
  # ● Creating turn number window(new)
  #--------------------------------------------------------------------------
  def create_turn_window
    @turn_window = Window_Turn.new 
    @turn_window.visible = false
  end
 
  #--------------------------------------------------------------------------
  # ● Battle start(alias)
  #--------------------------------------------------------------------------
  alias battle_start_org battle_start
  def battle_start
    battle_start_org
    @turn_window.opacity = Prico::View
    @turn_window.visible = true
    @turn_window.refresh
  end
 
  #--------------------------------------------------------------------------
  # ● Turn start(alias)
  #--------------------------------------------------------------------------
  alias turn_start_org turn_start
  def turn_start
    turn_start_org
    @turn_window.visible = false
    @turn_window.refresh
  end
 
  #--------------------------------------------------------------------------
  # ● Turn end(alias)
  #--------------------------------------------------------------------------
  alias turn_end_org turn_end
  def turn_end
    turn_end_org
    @turn_window.visible = true
    @turn_window.refresh
  end
 
end
 
 
#==============================================================================
# ■ Window_Turn
# 　 Window that displays the current number of turns
#==============================================================================

class Window_Turn < Window_Base
  #--------------------------------------------------------------------------
  # ● Object initialization
  #--------------------------------------------------------------------------
  def initialize
    super(Prico::WindowX,Prico::WindowY,Prico::WindowW,line_height * 2)
    self.contents = Bitmap.new(self.width - 24, self.height - 28)
    refresh
  end
  #--------------------------------------------------------------------------
  # ● Refresh
  #--------------------------------------------------------------------------
  def refresh
    self.contents.clear
    self.contents.font.size = 23
    @text = sprintf("%03d %s",$game_troop.turn_count,"TURN")
    draw_text_ex(0, 0, @text)
    reset_font_settings
  end
end