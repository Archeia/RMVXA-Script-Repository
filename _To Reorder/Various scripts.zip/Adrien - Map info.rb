#==============================================================================
# ■ Map Info
#
#
# Author: Adrien. (A.)
# Version: 1.1
# Log: 1.0 (init release), 1.1 - adds switch ability
# Comptaibility?: No issue?
#
# This script show information on the map in the form of a box. Its very basic,
# very simple and very easy to use. The new version 1.1 allows for you to use
# a switch to say: if on, turn off the box and if off, make the box visable.
#
# Thanks to shaz for helping out with understanding switches in version 1.1
#
#------------------------------------------------------------------------------
# 　Plug and Play
#==============================================================================

module INFO
  #--------------------------------------------------------------------------
  # ● SWITCH_NUM = Switch
  #     --> must be on if you want the window to display. 
  #--------------------------------------------------------------------------
  SWITCH_NUM = 76
end


class Window_Show_InfoMap < Window_Base
  #--------------------------------------------------------------------------
  # ● initialize
  #--------------------------------------------------------------------------
  def initialize
        super(0, 0, 300, fitting_height(2))
        refresh
  end
  #--------------------------------------------------------------------------
  # ● refresh
  #     --> update the contents of the window
  #--------------------------------------------------------------------------            
  def refresh
        self.contents.clear  
        @total_sec = Graphics.frame_count / Graphics.frame_rate
        contents.clear
        draw_window_content
  end

  #--------------------------------------------------------------------------
  # ● draw_window_content
  #     --> Draw window contents
  #--------------------------------------------------------------------------
  def draw_window_content
        cx = text_size(16).width
        change_color(system_color)
        draw_text(x-190, y, 50, line_height, "Map Name: ")
        change_color(normal_color)
        draw_text(x-125, y, 70, line_height, $game_map.display_name, 2)
        change_color(system_color)
        draw_text(x-190, y+20, 70, line_height, "Party Size: ")
        change_color(normal_color)
        draw_text(x-170, y+20, 70, line_height, $game_party.max_battle_members, 2)
        change_color(system_color)
        draw_text(x-25, y, 50, line_height, "Gold: ")
        change_color(normal_color)
        draw_text(x, y, 70, line_height, $game_party.gold, 2)
        change_color(system_color)
        draw_text(x-25, y+20, 50, line_height, "Steps: ")
        change_color(normal_color)
        draw_text(x, y+20, 70, line_height, $game_party.steps, 2)
  end

  #--------------------------------------------------------------------------
  # ● update
  #     --> update the time
  #     --> if the switch is on, show the window else close it.
  #--------------------------------------------------------------------------
  def update
        super
        sec = (Graphics.frame_count / Graphics.frame_rate) % 1
        if sec > @total_sec % 1 or sec == 0
          refresh
        end
        if $game_switches[INFO::SWITCH_NUM]
          self.visible = true
        else
          self.visible = false
        end
  end

end


class Scene_Map

  #--------------------------------------------------------------------------
  # ● create_all_windows
  #     --> alias adrein_create_all_windows_add_iyuth6764
  #     --> add create_window_show_infomap to be created on the map.
  #--------------------------------------------------------------------------
  alias adrein_create_all_windows_add_iyuth6764 create_all_windows
  def create_all_windows
    adrein_create_all_windows_add_iyuth6764
    create_window_show_infomap
  end

  #--------------------------------------------------------------------------
  # ● create_window_show_infomap
  #     --> creates a new show_infomap window
  #--------------------------------------------------------------------------
  def create_window_show_infomap
    @show = Window_Show_InfoMap.new
    @show.x = 200
    @show.y = 0
  end

end