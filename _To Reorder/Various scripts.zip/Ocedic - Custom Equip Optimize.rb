# *****************************************************************************
#
# OC CUSTOM EQUIP OPTIMIZE
# Author: Ocedic
# Site: http://ocedic.wordpress.com/
# Version: 1.0
# Last Updated: 3/30/13
#
# Updates:
# 1.0  - First release
#
# *****************************************************************************

$imported = {} if $imported.nil?
$imported["OC-CustomOptimize"] = true

#==============================================================================
# ▼ Introduction
# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# This script allows you to set custom stat weight on a per-class basis when
# using the Optimize option in the Equip menu.
#==============================================================================
# ▼ Instructions
# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# Plug and play script. Simply paste it above Main. Settings can be adjusted
# in configuration section.
#
# In the notebox section of WEAPONS and ARMOR, you may add the following tag:
# <optimize: x>
# Where x is a flat adjustment to that item's value. This value may be negative.
#==============================================================================
# ▼ Compatibility
# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# This script may not be compatible with scripts that also change the Optimize
# option. It is compatible with Yanfly Ace Equip Engine.
#==============================================================================
# ▼ Terms of Use
# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# Can be freely used and modified in non-commercial projects. Proper attribution 
# must be given to Ocedic, and this header must be preserved.
# For commercial terms, see here: https://ocedic.wordpress.com/terms-of-use/
#==============================================================================

module OC
  module OPTIMIZE

#==============================================================================
# * Archetypes *
#------------------------------------------------------------------------------
#   Allows you to set the stat weight of each parameter for each class. 
#   Item value to that class will be determined the summation of each PARAM
#   multiplied by its WEIGHT.
#   To add additional classes, simply copy and paste a line and change its 
#   CLASS ID to the appropriate index.
#============================================================================== 
    W_ARCHETYPES = {
    
#     [Class ID, MaxHP, MaxMP, ATK, DEF, MAT, MDF, AGI, LUK]
           1 => [  0.5,     0,   4,   1,   1,   1,   1,   1],
           2 => [    1,     0,   2,   1,   2,   1,   1,   1],
    
    } # Don't delete this
    
    A_ARCHETYPES = {
    
#     [Class ID, MaxHP, MaxMP, ATK, DEF, MAT, MDF, AGI, LUK]
           1 => [  0.5,     0,   1,   2,   1,   2,   1,   1],
           2 => [    1,     0,   2,   1,   2,   1,   1,   1],
    
    } # Don't delete this
    
  end
end


#==============================================================================
# ■ Game_Actor
#==============================================================================

class Game_Actor < Game_Battler

#==============================================================================
# * Overwrite: Optimize Equipments *
#==============================================================================
  def optimize_equipments
    $game_temp.eds_actor = self if $imported["YEA-AceEquipEngine"]
    @optimize_clear = true if $imported["YEA-AceEquipEngine"]
    clear_equipments
    @optimize_clear = false if $imported["YEA-AceEquipEngine"]
    equip_slots.size.times do |i|
      next if !equip_change_ok?(i)
      if $imported["YEA-AceEquipEngine"]
        next unless can_optimize?(i)
      end
      items = $game_party.equip_items.select do |item|
        item.etype_id == equip_slots[i] &&
        equippable?(item) && item.performance(@class_id) >= 0
      end
      change_equip(i, items.max_by {|item| item.performance(@class_id) })
    end
    $game_temp.eds_actor = nil if $imported["YEA-AceEquipEngine"]
  end
  
end #class game_actor

#==============================================================================
# ■ RPG::Weapon
#==============================================================================

class RPG::Weapon < RPG::EquipItem
  
#==============================================================================
# * Alias: Performance *
#==============================================================================
  alias oc_rpg_weapon_performance_sl39k performance
  def performance(id)
    if OC::OPTIMIZE::W_ARCHETYPES[id]
      params.each_with_index.inject(optimize_adjust) {|result, (i, j)|
        result += i * OC::OPTIMIZE::W_ARCHETYPES[id][j]}
    else
      oc_rpg_weapon_performance_sl39k
    end    
  end  
  
end #class RPG::Weapon

#==============================================================================
# ■ RPG::Armor
#==============================================================================

class RPG::Armor < RPG::EquipItem
  
#==============================================================================
# * Alias: Performance *
#==============================================================================
  alias oc_rpg_armor_performance_mw93k performance
  def performance(id)
    if OC::OPTIMIZE::A_ARCHETYPES[id]
      params.each_with_index.inject(0) {|result, (i, j)|
        result += i * OC::OPTIMIZE::A_ARCHETYPES[id][j]}
    else
      oc_rpg_armor_performance_mw93k
    end    
  end  

end #class RPG::Weapon

#==============================================================================
# ■ RPG::EquipItem
#==============================================================================

class RPG::EquipItem
  
#==============================================================================
# * New Method: Optimize Adjust *
#============================================================================== 
  def optimize_adjust
    if @weight_adjust == nil
      if @note =~ /<optimize: (.*)>/i
        @weight_adjust = $1.to_i
      else
        @weight_adjust = 0
      end
    end
    @weight_adjust
  end
  
end #class RPG::EquipItem