#===============================================================================
#
# â™¦ THEX Fishing Script
# -- Author : Titanhex
# -- Version : 1.00
# -- Level : Normal
# -- Requires : None
# -- Engine : RMVX Ace
#
#===============================================================================
# â™¦ Version Notes
#-------------------------------------------------------------------------------
# 04/13/2013
# - Release
#
#===============================================================================
# â™¦ Introduction
#-------------------------------------------------------------------------------
# This script is a simpe fishing script based on an even simpler concept.
# Because the concept is so simple it can be altered to be something other
# than a fishign script just by changing the pictures.
#
# Basically the fish moves from the right to the left of the background,
# and after that the "fish" disappears. You have to catch it on it's way
# there. Whatever this may change help you make is up to you. For me, I
# packaged it as a Fishing Script.
#
#===============================================================================
#
#===============================================================================
# â™¦ How to Use
#-------------------------------------------------------------------------------
# This system might seem a bit foreign, but if you read the instructions it
# should be easy.
#
# First to call the Fishing scene, use this in a script call in an event.
# start_fishing
#
# However this only loads the default settings. You'll likely want to set
# up each scene differently. TO do this, check out the call:
#
# start_fishing(fishlist, water, BGS)
#
# To set up a fishlist just put the fish name, in quotes, within brackets
# and separate each fish by commas. It'll look something like this:
#
# ["Catfish", "Salmon", "Octopus"]
#
# Water is the name or sequence name you want to use for the water bar
# loaded. I.E. "Rushing Water" or "Swamp Water"
#
# BGS is the background sound you want to play when fishing.
#
# i.e. "River"
#
# An example of loading all these would be:
#
# start_fishing(["Catfish", "Salmon", "Octopus"], "Swamp Water", "River")
#
# But if you just wanted water or bgs:
#
# start_fishing(nil, "Rushing Water", nil)
#
# start_fishing(nil, nil, "River")
#
# As you can see, just put nil in the spot if you want to use the defaults.
#
# Make sure you set different fishes in the Fish Parameters to call.
# Also set your defaults in the module.
#
#===============================================================================
# â™¦ Instructions
#-------------------------------------------------------------------------------
# ----Folder----
# All images should be put in a new folder in your graphics directory.
# Name the folder is Fishing. Put your pictures in it.
#
# ----Images----
# Images need to be set up before the system will work. In order to set up
# the images you need to know how they must be set up.
#
# First things first you can set up a series of images to animate. The system
# checks to see how many pictures are in the series. Then it changes them
# depending on the swim or water speed.
#
# To set up a picture, you need to put a number after each picture frame.
# i.e. Salmon1, Salmon2, Salmon3, and the system will animate them in the
# right order. If you don't want it animated, just leave the picture at 1.
#
#===============================================================================
# â™¦ Fishes
#-------------------------------------------------------------------------------
# The fishes are the most important part of the system. Here's how they work:
#
# ----Item Acquisition----
# When you catch a fish you get an item. The item you receive depends on
# the name (picture name) of the fish. For example if the picture is
# "Salmon1", then the item the player gets is any item named "Salmon"
# So, name the item you want the player to get after the fish.
#
# ----Fish Parameters----
# The first parameter is the name of the Fish. I.E. "Salmon"
# The second parameter is Speed1
# The third parameter is Speed2
# The fourth parameter is Swim Type
#
# The name of the fish should also be the picture name sans the number.
# Swim Type determines what Speed1 and Speed2 do. The two settings are
# Random (0) and Glide (1). Random allows the fish to swim either at a
# random speed with a minimum and maximum or at a steady, constant speed.
# Glide is the movement of a frog or squid. The fish speeds up quickly,
# and slowly returns to no movement.
#
# Speed1 on Random swim is the minimum speed. Speed2 is the range.
# To get the maximum speed of the fish just add Speed1 and Speed2 together.
#
# Speed1 on Glide is the distance in pixels the fish will swim on each glide.
# Speed2 is the speed the fish starts at when it begins it's glide.
#
#===============================================================================

#Here you can set the default values for the system to use.
module THEX
SWIMSPEED = 2
#Sounds Effects to be played
BGSE = "River" #Default sound for the Background Sound
MISSME = "Gag" #Default music effect for when the fish hits the edge
HOOKSE = "Water1" #Sound played when you pull the hook with no fish
CATCHSE = "Water2" #Sound played when you pull the hook with a fish on it

#Default Fish to be Loaded
FISH_ARY = ["Catfish","Salmon"]

#Pictures to be Loaded
WATERBG = "Water-Bar-"
HOOK = "Hook"

#Hash Table to set values for your Fish. See Fish Parameters for instructions.
FISH_PARAMS ={
# :command => [speed Value 1, Speed Value 2, Swim Type],
"Catfish" => [ 2, 0, 0],
"Salmon" => [ 2, 2, 0],
"Squid" => [ 15, 25, 1],
} # Do not remove this.

#This is just the error message when a bad Swim Type is set.
#There is no need to change this value.
STYPE_ERROR_MSG = "ERROR: No valid Swim Type defined!"
end


# DO NOT EDIT BELOW THIS LINE UNLESS YOU KNOW WHAT YOU ARE DOING!!!
class Window_Catch_Fish < Window_Base
#--------------------------------------------------------------------------
# * Object Initialization
#--------------------------------------------------------------------------
def initialize
x = Graphics.width/2 - window_width/2
y = Graphics.height/2 - fitting_height(1)/2
super(x, y, window_width, fitting_height(1))
end

def window_width
220
end

def draw_fish_caught(fish, x, y)
contents.clear
text = "You caught a " + fish
#change_color(normal_color)
x -= standard_padding
draw_text(x, y, window_width, line_height, text, 1)
end

end

#==============================================================================
# ** Window_Fishing
#------------------------------------------------------------------------------
# This window displays the Fishing Bar.
#==============================================================================

class Window_Fishing < Window_Selectable
attr_writer :fishbit
attr_writer :hookbit
attr_writer :waterbit
attr_accessor :water
attr_accessor :fish
#--------------------------------------------------------------------------
# * Object Initialization
#--------------------------------------------------------------------------
def initialize(fish_ary, water, bgs, y = 265)
@range = 1..5
water.nil? ? @water = THEX::WATERBG : @water = water
fish_ary.nil? ? @fish_ary = THEX::FISH_ARY : @fish_ary = fish_ary
bgs.nil? ? @bgs = THEX::BGSE : @bgs = bgs
setup
super(Graphics.width/2 - window_width/2, y, window_width, window_height)
initialize_variables
end

def initialize_variables
@hook_calibration = 0
@fish_calibration = 0
@wait = 0
@wcount = 0
self.opacity = 0
@count_up = true
@hook_on_fish = false
@lastbgs = RPG::BGS.last
RPG::BGS.new(@bgs, 80).play
end

def setup
@waterbit = Cache.fishing(@water + "1")
@hookbit = Cache.fishing(THEX::HOOK)
@fishbit = Cache.fishing(@fish_ary[0] + "1")
@waterrect = Rect.new(0, 0, window_width, window_height)
@hookrect = Rect.new(-(waterbit_x*2), 0, window_width, window_height)
@fishrect = Rect.new(0, 0, window_width, window_height)
new_fish
end

#--------------------------------------------------------------------------
# * Misc & Utility Methods
#--------------------------------------------------------------------------
def gain_fish
for i in 1...$data_items.size
$game_party.gain_item($data_items[i],1) if $data_items[i].name == @fish
end
end

def pic_counter(string)
for i in 1..25
begin
Cache.fishing(string + i.to_s)
rescue
break
end
end
return i-1
end

def show_catch
SceneManager.scene.show_catch
end

def hide_catch
SceneManager.scene.hide_catch
end

#--------------------------------------------------------------------------
# * Determine Opacity Setting for Fish Bitmap
#--------------------------------------------------------------------------
def do_fade?
@hook_on_fish || @fishrect.x >= 0
end

def fish_opacity
dist = @waterbit.width-80 + @fishrect.x
dist > 0 ? opacity = 255 : opacity = 255 - dist.to_f/-80 * 255
opacity = 255+2*(@last-Graphics.frame_count) if do_fade?
opacity
end

#--------------------------------------------------------------------------
# * Width & Height for Window
#--------------------------------------------------------------------------
def window_width
@waterbit.width+50
end

def window_height
@hookbit.height*2+@waterbit.height+50
end

#--------------------------------------------------------------------------
# * X & Y of the various Bitmaps
#--------------------------------------------------------------------------
def waterbit_x
window_width - (window_width/2 + @waterbit.width/2 + 15)
end

def waterbit_y
window_height - @waterbit.height - 35
end

def hookbit_y
waterbit_y-@waterbit.height*4/3-@hook_calibration
end

def fishbit_y
waterbit_y - @fish_calibration
end

#--------------------------------------------------------------------------
# * Processes for Button Presses
#--------------------------------------------------------------------------
def process_left
if @hookrect.x < -(waterbit_x*2)
@hookrect.x += 1
end
end

def process_right
if @hookrect.x > -@waterbit.width+waterbit_x/2
@hookrect.x -= 1
end
end

def process_cancel
RPG::BGS.stop
@lastbgs.play
SceneManager.scene.return_scene
end

def process_ok
@hook_pulled = true
@wait = 180
if fish_hooked?
@hook_on_fish = true
RPG::SE.new(THEX::CATCHSE, 80).play
else
RPG::SE.new(THEX::HOOKSE, 80).play
end
end

#--------------------------------------------------------------------------
# * Handling Processing for Left, Right, OK and Cancel Etc.
#--------------------------------------------------------------------------
def process_handling
return unless open? && active
if @wait == 0
return process_ok if Input.trigger?(:C)
return process_cancel if Input.trigger?(: 
return process_left if Input.press?(:LEFT)
return process_right if Input.press?(:RIGHT)
end
end

#--------------------------------------------------------------------------
# * Update Grahpics
#--------------------------------------------------------------------------
def draw_bitmaps
contents.blt(waterbit_x, waterbit_y, @waterbit, @waterrect, 255)
contents.blt(0, hookbit_y, @hookbit, @hookrect, 255)
contents.blt(0, fishbit_y, @fishbit, @fishrect, fish_opacity)
end

def update_water
if Graphics.frame_count % 5 == 0
@wcount += 1
@waterbit = Cache.fishing(water + @wcount.to_s)
@wcount = 0 if @wcount >= pic_counter(water)
end
end

#------------------Hook Handling Methods----------------#
def fish_hooked?
dist = @hookrect.x - @fishrect.x
min = 4
max = min-@fishbit.width/3
return dist < min && dist > max
end

def hook_pull
@hook_calibration -= 2 if @wait <= 40 && @hook_calibration > 0
@hook_calibration += 2 if @wait > 40 && @hook_calibration < 20
if @hook_on_fish
@fish_calibration += 2 if @fish_calibration < 20
show_catch
if @wait == 0
hide_catch
@fish_calibration = 0
@hook_on_fish = false
gain_fish
new_fish
end
end
@hook_pulled = false if @wait == 0
end

#------------------Fish Handling Methods----------------#
def new_fish
fish = @fish_ary[rand(@fish_ary.size)]
@missed_fish = false
SceneManager.scene.fish = @fish = fish
@glide = THEX::FISH_PARAMS[@fish][0]
@fishrect.x = -@waterbit.width
end

def update_fish
speed1 = THEX::FISH_PARAMS[@fish][0]
speed2 = THEX::FISH_PARAMS[@fish][1]
stype = THEX::FISH_PARAMS[@fish][2]
@fish_frame ||= 0
if Graphics.frame_count % 7 == 0
if stype == 0 #Range
@count_up ? @fish_frame += 1 : @fish_frame -= 1
@count_up = true if @fish_frame == 1
@count_up = false if @fish_frame == pic_counter(@fish)
frame = @fish_frame
elsif stype == 1 #Glide
@fish_frame += 1
@fish_frame = 1 if speed2 < @fish_frame
frame = (@fish_frame.to_f/speed2) * pic_counter(@fish)
frame = frame.ceil
else
p THEX::STYPE_ERROR_MSG
frame = 1
end
frame = 1 if frame > pic_counter(@fish) || frame < 1
@fishbit = Cache.fishing(@fish+frame.to_s)
end
move_fish
end

def move_fish
if @fishrect.x >= 0
if !@missed_fish
RPG::ME.new(THEX::MISSME, 80).play
@wait = 240+rand(110)
end
@missed_fish = true
new_fish if @wait <= 0
else
fish_swim if Graphics.frame_count % THEX::SWIMSPEED == 0 && !@hook_on_fish
end
end

def fish_swim
speed1 = THEX::FISH_PARAMS[@fish][0]
speed2 = THEX::FISH_PARAMS[@fish][1]
stype = THEX::FISH_PARAMS[@fish][2]
if stype == 0 #Range
speed2 == 0 ? number = 0 : number = rand(speed2)
@fishrect.x += number + speed1
elsif stype == 1 #Glide
if @glide >= speed2+speed1
@glide = 1
elsif @glide >= speed2
#Do Nothing
else
@fishrect.x += speed2/@glide
end
@glide += 1
else
p THEX::STYPE_ERROR_MSG
@fishrect.x += 1
end
end

#--------------------------------------------------------------------------
# * Refresh. Just like update, but called from the Scene.
#--------------------------------------------------------------------------
def refresh(fish)
@fish = fish if @fish != fish
contents.clear
return unless active
update_water
update_fish
hook_pull if @hook_pulled
draw_bitmaps
@wait > 0 ? @wait -= 1 : @last = Graphics.frame_count
end

end

#==============================================================================
# ** Cache
#------------------------------------------------------------------------------
# This module loads graphics, creates bitmap objects, and retains them.
# To speed up load times and conserve memory, this module holds the
# created bitmap object in the internal hash, allowing the program to
# return preexisting objects when the same bitmap is requested again.
#==============================================================================

module Cache
#--------------------------------------------------------------------------
# * Get System Graphic
#--------------------------------------------------------------------------
def self.fishing(filename)
load_bitmap("Graphics/Fishing/", filename)
end

end
#==============================================================================
# ** Scene_Fishing
#------------------------------------------------------------------------------
# This class performs the Scene for Fishing
#==============================================================================

class Scene_Fishing < Scene_Base

attr_accessor :fish
attr_accessor :water
attr_accessor :bgs
#--------------------------------------------------------------------------
# * Start Processing
#--------------------------------------------------------------------------
def start
super
create_background
create_fishing_window
create_catch_window
end
#--------------------------------------------------------------------------
# * Create Background
#--------------------------------------------------------------------------
def create_background
@background_sprite = Sprite.new
@background_sprite.bitmap = SceneManager.background_bitmap
@background_sprite.color.set(180, 8, 8, 64)
end
#--------------------------------------------------------------------------
# * Free Background
#--------------------------------------------------------------------------
def dispose_background
@background_sprite.dispose
end
#--------------------------------------------------------------------------
# Create Windows
#--------------------------------------------------------------------------
def create_fishing_window
@fishing_window = Window_Fishing.new(@fish_ary, @water, @bgs)
@fishing_window.viewport = @viewport
@fishing_window.show.activate
end

def create_catch_window
@catch_window = Window_Catch_Fish.new
@catch_window.viewport = @viewport
@catch_window.draw_fish_caught(@fish, 0, 0)
@catch_window.close.hide
end

def show_catch
@catch_window.draw_fish_caught(@fish, 0, 0)
@catch_window.open.show
end

def hide_catch
@catch_window.close
end
#==============================================================================
# Scene Load methods. They allow you to set the scene's parameters.
#==============================================================================
def load_bgs(bgs)
@bgs = bgs
end

def load_fish(ary)
@fish_ary = ary
end

def load_water(graphic)
@water = graphic
end
#--------------------------------------------------------------------------
# * Frame Update
#--------------------------------------------------------------------------
def update
super
@fishing_window.refresh(@fish)
end
#--------------------------------------------------------------------------
# * Termination Processing
#--------------------------------------------------------------------------
def terminate
super
dispose_background
end

end

#==============================================================================
# ** Game_Interpreter
#------------------------------------------------------------------------------
# An interpreter for executing event commands. This class is used within the
# Game_Map, Game_Troop, and Game_Event classes.
#==============================================================================

class Game_Interpreter
def start_fishing(fish = nil, water = nil, bgs = nil)
SceneManager.call(Scene_Fishing)
SceneManager.scene.load_fish(fish)
SceneManager.scene.load_water(water)
SceneManager.scene.load_bgs(bgs)
end
end