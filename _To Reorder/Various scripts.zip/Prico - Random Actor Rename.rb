#==============================================================================
# RGSS3 Random Rename for Actor Ver1.01
#==============================================================================
=begin
 
  Author:ぷり娘 (prico)
web site:Sister's Eternal 4th(Ancient)
     URL:http://pricono.whitesnow.jp/
Permission to use: Not required, but please mention in the game, Readme, etc.
 
There's a way to randomly change the name of the actor.
It's done through event command → script
You can randomly name the actor from the name list below.
 
ChangeNameMale(X)
Will randomly assign male name to actor ID specified with X.
For X, specify the actor ID (number to the left of the actor's name)
 
Example：ChangeNameMale(3)
Will randomly give the male name to actor #3 from database.
 
ChangeNameFemale(X)
Will randomly assign a female name to actor ID specified by X.
For X, specify the actor ID (number to the left of the actor's name)
 
Example：ChangeNameFemale(7)
Will randomly give the female name to actor #7 from database.
 
Also, if you put a variable ($game_variables[variable ID]) in X
You can change the name of the actor whose number is (variable ID)
 
※I did not check for duplicates
 
2014.04.29  Fixed description, script remain unchanged
2013.04.15  Ver1.01　Fixed a bug where female name assigned as male name
2012.12.06  Ver1.00　Initial release
=end
 
#==============================================================================
# Name list, feel free to add on/ modify however you like
#==============================================================================
module Prico
  #male name
  NameDB_Male = [
  "Alex",
  "Bryan",
  "Enryuu",
  "Falcon",
  "Gomez",
  "Zack",
  "Albert",
  "Burns",
  "Klaus",
  "Arthur"
  ]
 
  #female name
  NameDB_Female = [
  "Carol",
  "Daisy",
  "Helen",
  "Erdith",
  "Fey-Lin",
  "Alyssa",
  "Mia",
  "Elene",
  "Cynthia",
  "Melissa"
  ]
end
 
#==============================================================================
# ■ Game_Interpreter
#------------------------------------------------------------------------------
# Game interpreter that executes event commands. This is Game_Map class,
# Game_Troop class, used inside Game_Event class.
#==============================================================================
class Game_Interpreter
  #change male name
  def ChangeNameMale(actor_id)
    @name = Prico::NameDB_Male[rand(Prico::NameDB_Male.size)]
    $game_actors[actor_id].name = @name
  end
 
  #change female name
  def ChangeNameFemale(actor_id)
    @name = Prico::NameDB_Female[rand(Prico::NameDB_Female.size)]
    $game_actors[actor_id].name = @name
  end
end