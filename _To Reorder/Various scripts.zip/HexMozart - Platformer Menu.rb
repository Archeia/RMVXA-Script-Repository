=begin
================================================================================
Platformer Menu
By HexMozart88
--------------------------------------------------------------------------------
Description: This is a menu I made to look like a classic Platformer game pause
screen. 
--------------------------------------------------------------------------------
Instructions: Place below Materials, but Above Main. You can change the names of
the commands in the below module. 

If you choose to customize the background, your image should be named

menu_back

and go into Graphics/System.
--------------------------------------------------------------------------------
Terms of use: Free in all projects with credit given.(It would also be nice to 
PM me for commercial use)
================================================================================
=end

#--------------------#
# COMPATIBILITY THING
#--------------------#
($imported ||= {})["Hex_Platform_Menu"] = true 
#---------#
# SETTINGS
#---------#

module Hex
module Platform_Menu

MENU_LIST = [] # Customize command names. 
MENU_LIST[0] = "Resume" # Return to game.
MENU_LIST[1] = "Stage Select" # To select levels.
MENU_LIST[2] = "Title" # Go back to title.
MENU_LIST[3] = "Exit" # Quit the game. 

EVENT_STAGE_SELECT = true # true = events, false = script
STAGE_SELECT_SWITCH = 30 # Set the switch to turn on for events. 

ENABLE_BACKGROUND = true # Customize backgrond or use default. 

WINDOWSKIN = "Window" # Choose the windowskin for commands.
end
end

#===============================================================================
# WARNING: May cause crashing if editted. You have been warned.
#===============================================================================

#===============================================================================
# Scene_Menu
#===============================================================================

class Scene_Menu < Scene_MenuBase

#------------------#
# Start Processing #
#------------------#
def start
super
create_command_window
end

#----------------#
# Command Window #
#----------------#
def create_command_window
@command_window = Window_MenuCommand.new
@command_window.set_handler:)resume, method:)return_scene))
@command_window.set_handler:)stages, method:)stage_select))
@command_window.set_handler:)title, method:)to_title))
@command_window.set_handler:)shutdown, method:)command_shutdown))
end
#----------------------#
# Close Command Window #
#----------------------#
def close_command_window
@command_window.close
update until @command_window.close?
end
#--------------#
# Stage Select #
#--------------#
def stage_select
if Hex::platform_Menu::EVENT_STAGE_SELECT
close_command_window
SceneManager.return
$game_switches[Hex::platform_Menu::STAGE_SELECT_SWITCH] = true
else
SceneManager.call(Scene_Stage_Select)
end
end

#-------#
# Title #
#-------#
def to_title
close_command_window
fadeout_all
SceneManager.goto(Scene_Title)
end

#-----------#
# Quit Game #
#-----------#
def command_shutdown
close_command_window
fadeout_all
SceneManager.exit
end
end
#===============================================================================
# Window_MenuCommand
#===============================================================================
class Window_MenuCommand < Window_Command

#------------#
# Initialize #
#------------#
def initialize
super(200, 150)
self.windowskin = Cache.system(Hex::platform_Menu::WINDOWSKIN)
end
#------------------#
# Get Window Width #
#------------------#
def window_width
return 160
end
#-----------------------------#
# Get Number of Lines to Show #
#-----------------------------#
def visible_line_number
item_max
end

#---------------#
# Command Names #
#---------------#
def make_command_list
add_command(Hex::platform_Menu::MENU_LIST[0], :resume)
add_command(Hex::platform_Menu::MENU_LIST[1], :stage_select)
add_command(Hex::platform_Menu::MENU_LIST[2], :title)
add_command(Hex::platform_Menu::MENU_LIST[3], :shutdown)
end

#-------#
# On OK #
#-------#
def process_ok
@@last_command_symbol = current_symbol
super
end
end

#===============================================================================
# Scene_MenuBase
#===============================================================================
class Scene_MenuBase < Scene_Base

#-------------------#
# Create Background #
#-------------------#
def create_background
@background_sprite = Sprite.new
if Hex::platform_Menu::ENABLE_BACKGROUND
@background_sprite.bitmap = Cache.system("menu_back")
else
@background_sprite.bitmap = SceneManager.background_bitmap
end
end
end

#==============================================================================
# END OF SCRIPT
#==============================================================================