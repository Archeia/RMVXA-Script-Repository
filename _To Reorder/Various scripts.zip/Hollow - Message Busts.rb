#==============================================================================
#** Simple Message Busts
#------------------------------------------------------------------------------
# Engine: RPG Maker VX Ace
# Author: Hollow
#==============================================================================
# * Instructions
#------------------------------------------------------------------------------
#  This script allows the use of large portraits (busts) in place of facesets
# in message boxes. All busts should be saved to the "Graphics/Faces" folder,
# and it's file-name must include the symbol chosen in the settings below. To
# use in game, simply select the bust you wish to use in the faceset box of the
# "Show Text" command. The script will do the rest.
#==============================================================================
# ** Settings
#==============================================================================
module HMB
  BUST_INDENT = 180          
  # Indentation width for text when bust is shown.  
  BUST_OFFSET = -75          
  # Bust image's offset on the x-axis.  
  BUST_SYMBOL = "!"          
  # Symbol to differentiate busts from facesets.
end
#==============================================================================
# ** Window_Message
#==============================================================================
class Window_Message < Window_Base
  #--------------------------------------------------------------------------
  # * Alias
  #--------------------------------------------------------------------------
  alias hmb_window_message_create_back_bitmap create_back_bitmap
  alias hmb_window_message_dispose       dispose
  alias hmb_window_message_update_back_sprite update_back_sprite
  #--------------------------------------------------------------------------
  # * Create Background Bitmap
  #--------------------------------------------------------------------------
  def create_back_bitmap  
    @bust = Sprite.new if @bust.nil?  
    @bust.visible = true  
    @bust.z = z + 1  
    hmb_window_message_create_back_bitmap
  end
  #--------------------------------------------------------------------------
  # * Free
  #--------------------------------------------------------------------------
  def dispose  
    hmb_window_message_dispose  
    dispose_bust
  end
 #--------------------------------------------------------------------------
 # * Free Bust
 #--------------------------------------------------------------------------
  def dispose_bust  
    @bust.dispose if !@bust.nil?  
    @bust.bitmap.dispose if !@bust.bitmap.nil?
  end
  #--------------------------------------------------------------------------
  # * Update Background Sprite
  #--------------------------------------------------------------------------
  def update_back_sprite  
    hmb_window_message_update_back_sprite  
    update_bust if openness > 0
  end
  #--------------------------------------------------------------------------
  # * Update Bust
  #--------------------------------------------------------------------------
  def update_bust  
    if $game_message.face_name.include?(HMB::BUST_SYMBOL)    
      @bust.bitmap = Cache.face($game_message.face_name)    
      @bust.x = HMB::BUST_OFFSET    
      @bust.y = Graphics.height - @bust.height  
    else    
      @bust.bitmap = nil  
    end  
    @bust.update
  end
  #--------------------------------------------------------------------------
  # * Get New Line Position
  #--------------------------------------------------------------------------
  def new_line_x  
    if $game_message.face_name.include?(HMB::BUST_SYMBOL)    
      $game_message.face_name.empty? ? 0 : HMB::BUST_INDENT  
    else    
      $game_message.face_name.empty? ? 0 : 112  
    end
  end
  #--------------------------------------------------------------------------
  # * Draw Face Graphic
  #--------------------------------------------------------------------------
  def draw_face(face_name, face_index, x, y, enabled = true)  
    return if $game_message.face_name.include?(HMB::BUST_SYMBOL)  
    super
  end
end # Window_Message