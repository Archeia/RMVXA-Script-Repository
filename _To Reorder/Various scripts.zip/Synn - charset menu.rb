#==============================================================================
# Synn's Charset Menu System V2.5
#------------------------------------------------------------------------------
#  This is my first script. It simply switches he reading of faces to reading charactersets
# instead. It is plug and play, though I am not sure on compatibility with anything else
# that would alter the way that the system draws faces.
#Special thanks to galv for pointing out my flaw with the index situation. =P
# Version 2.5 changes; I just scaled the size up of the Characters and centered them
#more. Also added the effect to name input
#==============================================================================

class Window_MenuStatus < Window_Selectable
  def draw_item(index)
    actor = $game_party.members[index]
    enabled = $game_party.battle_members.include?(actor)
    rect = item_rect(index)
    @frame = 1
    draw_item_background(index)
    draw_character(actor.character_name, actor.character_index, rect.x + 50, rect.y + 70, @frame)
    draw_actor_simple_status(actor, rect.x + 108, rect.y + line_height / 2)
  end
  def draw_character(character_name, character_index, x, y, frame = 1)
    return unless character_name
    bitmap = Cache.character(character_name)
    sign = character_name[/^[\!\$]./]
    if sign && sign.include?('$')
      cw = bitmap.width / 3
      ch = bitmap.height / 4
    else
      cw = bitmap.width / 12
      ch = bitmap.height / 8
    end
    n = character_index
    src_rect = Rect.new((n%4*3+frame)*cw, (n/4*4)*ch, cw, ch)
    ret_rect = Rect.new(x - cw, y - cw * 2, cw * 2, ch * 2)
    contents.stretch_blt(ret_rect, bitmap, src_rect)
  end
end

class Window_Status < Window_Selectable
  def draw_block2(y)
    @frame = 1
    draw_character(@actor.character_name, @actor.character_index, x+65, y+75, @frame)
    draw_basic_info(136, y)
    draw_exp_info(304, y)
  end
  def draw_character(character_name, character_index, x, y, frame = 1)
    return unless character_name
    bitmap = Cache.character(character_name)
    sign = character_name[/^[\!\$]./]
    if sign && sign.include?('$')
      cw = bitmap.width / 3
      ch = bitmap.height / 4
    else
      cw = bitmap.width / 12
      ch = bitmap.height / 8
    end
    n = character_index
    src_rect = Rect.new((n%4*3+frame)*cw, (n/4*4)*ch, cw, ch)
    ret_rect = Rect.new(x - cw, y - cw * 2, cw * 2, ch * 2)
    contents.stretch_blt(ret_rect, bitmap, src_rect)
  end
end

class Window_SkillStatus < Window_Base
  def refresh
    contents.clear
    return unless @actor
    @frame = 1
    draw_character(@actor.character_name, @actor.character_index, 50, 70, @frame)
    draw_actor_simple_status(@actor, 108, line_height / 2)
  end
  def draw_character(character_name, character_index, x, y, frame = 1)
    return unless character_name
    bitmap = Cache.character(character_name)
    sign = character_name[/^[\!\$]./]
    if sign && sign.include?('$')
      cw = bitmap.width / 3
      ch = bitmap.height / 4
    else
      cw = bitmap.width / 12
      ch = bitmap.height / 8
    end
    n = character_index
    src_rect = Rect.new((n%4*3+frame)*cw, (n/4*4)*ch, cw, ch)
    ret_rect = Rect.new(x - cw, y - cw * 2, cw * 2, ch * 2)
    contents.stretch_blt(ret_rect, bitmap, src_rect)
  end
 end
 
class Window_NameEdit < Window_Base
  def refresh
    contents.clear
    @frame = 1
    draw_character(@actor.character_name, @actor.character_index, 50, 70, @frame)
    @max_char.times {|i| draw_underline(i) }
    @name.size.times {|i| draw_char(i) }
    cursor_rect.set(item_rect(@index))
  end
  def draw_character(character_name, character_index, x, y, frame = 1)
    return unless character_name
    bitmap = Cache.character(character_name)
    sign = character_name[/^[\!\$]./]
    if sign && sign.include?('$')
      cw = bitmap.width / 3
      ch = bitmap.height / 4
    else
      cw = bitmap.width / 12
      ch = bitmap.height / 8
    end
    n = character_index
    src_rect = Rect.new((n%4*3+frame)*cw, (n/4*4)*ch, cw, ch)
    ret_rect = Rect.new(x - cw, y - cw * 2, cw * 2, ch * 2)
    contents.stretch_blt(ret_rect, bitmap, src_rect)
  end
 end