#===============================================================================
#					N.A.S.T.Y. Animated Main Menu
#				  Nelderson's Awesome Scripts To You
# By: Nelderson
# Made On: 12/20/2011
#===============================================================================
# Update History:
# - Version 1.0  - Initial release, made for the shit of it <img src='http://www.rpgmakervxace.net/public/style_emoticons/<#EMO_DIR#>/tongue.png' class='bbc_emoticon' alt=':P' />
# - Version 1.1 - Added the reverse transition for getting out of the menu
#===============================================================================
# *Notes:
# - This script uses moving windows everytime the main menu screen opens!
#  
#===============================================================================
# Credits:
#
# -Nelderson
#===============================================================================
module NEL
  
  #Transition Speed of the Windows(Higher is faster, and must be above 0)
  TRANS_SPEED = {
   :gold =>  30,
   :command => 35,
   :actor => 40
   }
  
   #Sets the transitions to come from random directions every time
   RANDOM_TRANS = true ####NOT USED YET#####
  
end

class Scene_Menu < Scene_MenuBase
  #--------------------------------------------------------------------------
  # ● 開始処理
  #--------------------------------------------------------------------------
  alias nel_custom_per_trans start
  def start
		nel_custom_per_trans
		@trans_flag = true
  end
  #--------------------------------------------------------------------------
  # ● コマンドウィンドウの作成
  #--------------------------------------------------------------------------
  alias nel_cre_comm_win create_command_window
  def create_command_window
		nel_cre_comm_win
		dir = (rand(4)+ 1).round		
		dir *= 2
		case dir
		when 2; @command_window.y = 416#Down
		when 4; @command_window.x = -160 #Left
		when 6; @command_window.x = 544#Right
		when 8; @command_window.y = 0 - @command_window.height#Up
		end
		@command_win_dir = dir
  end
  #--------------------------------------------------------------------------
  # ● ゴールドウィンドウの作成
  #--------------------------------------------------------------------------
  alias nel_creat_goldd create_gold_window
  def create_gold_window
		nel_creat_goldd
		dir = (rand(4)+ 1).round		
		dir *= 2		
		case dir
		when 2; @gold_window.y = 416#Down
		when 4; @gold_window.x = 0 - @gold_window.width #Left
		when 6; @gold_window.x = 544#Right
		when 8; @gold_window.y = 0 - @gold_window.height #Up
		end
		@gold_win_dir = dir
  end
		
  #--------------------------------------------------------------------------
  # ● ステータスウィンドウの作成
  #--------------------------------------------------------------------------
  alias nel_creat_stat_win create_status_window
  def create_status_window
		nel_creat_stat_win
		dir = (rand(4)+ 1).round		
		dir *= 2		
		case dir
		when 2; @status_window.y = 416#Down
		when 4; @status_window.x = 0 - @status_window.width #Left
		when 6; @status_window.x = 544 #Right
		when 8; @status_window.y = 0 - @status_window.height #Up
		end
		@status_win_dir = dir
  end
  
  def update
		if !SceneManager.background_bitmap.nil? && @trans_flag == true
		  perform_nel_transition
		end
		update_basic
  end
  
  def perform_nel_transition
		gold_window_trans
		status_window_trans
		command_window_trans
		@trans_flag = false
  end
  
  def gold_window_trans(dir = @gold_win_dir)
		orig_x = 0
		orig_y = Graphics.height - @gold_window.height
		sp = NEL::TRANS_SPEED[:gold]
		loop do
		  @gold_window.y -= sp if dir == 2
		  @gold_window.y = orig_y if @gold_window.y <= orig_y && dir == 2
		  @gold_window.x += sp if dir == 4
		  @gold_window.x = orig_x if @gold_window.x >= orig_x && dir == 4
		  @gold_window.x -= sp if dir == 6
		  @gold_window.x = orig_x if @gold_window.x <= orig_x && dir == 6
		  @gold_window.y += sp if dir == 8
		  @gold_window.y = orig_y if @gold_window.y >= orig_y && dir == 8
		  Graphics.update
		  break if @gold_window.y == orig_y && @gold_window.x == orig_x
		end
  end
  
  def status_window_trans(dir = @status_win_dir)
		orig_x, orig_y = @command_window.width, 0
		sp = NEL::TRANS_SPEED[:actor]
		loop do
		  @status_window.y -= sp if dir == 2
		  @status_window.y = orig_y if @status_window.y <= orig_y && dir == 2
		  @status_window.x += sp if dir == 4
		  @status_window.x = orig_x if @status_window.x >= orig_x && dir == 4
		  @status_window.x -= sp if dir == 6
		  @status_window.x = orig_x if @status_window.x <= orig_x && dir == 6
		  @status_window.y += sp if dir == 8
		  @status_window.y = orig_y if @status_window.y >= orig_y && dir == 8
		  Graphics.update
		  break if @status_window.x == orig_x && @status_window.y == orig_y
		end
  end
  
	def command_window_trans(dir = @command_win_dir)
		orig_x, orig_y = 0, 0
		sp = NEL::TRANS_SPEED[:command]
		loop do
		  @command_window.y -= sp if dir == 2
		  @command_window.y = orig_y if @command_window.y <= orig_y && dir == 2  
		  @command_window.x += sp if dir == 4
		  @command_window.x = orig_x if @command_window.x >= orig_x && dir == 4
		  @command_window.x -= sp if dir == 6
		  @command_window.x = orig_x if @command_window.x <= orig_x && dir == 6
		  @command_window.y += sp if dir == 8
		  @command_window.y = orig_y if @command_window.y >= orig_y && dir == 8
		  Graphics.update
		  break if @command_window.x == orig_x && @command_window.y == orig_y
		end
	  end
  alias nel_term_trans_win terminate	
  def terminate
	rev_gold_window_trans
	rev_status_window_trans
	rev_command_window_trans	
	nel_term_trans_win
  end
  
	def rev_gold_window_trans(dir = @gold_win_dir)
	  case dir
	  when 2
		orig_x, orig_y = @gold_window.x, Graphics.height
	  when 4
		orig_x, orig_y = 0 - @gold_window.width, @gold_window.y
	  when 6
		orig_x, orig_y = Graphics.width, @gold_window.y
	  when 8
		orig_x, orig_y = @gold_window.x, 0 - @gold_window.height
	  end
		sp = NEL::TRANS_SPEED[:gold]
		loop do
		  @gold_window.y += sp if dir == 2
		  @gold_window.y = orig_y if @gold_window.y >= orig_y && dir == 2
		  @gold_window.x -= sp if dir == 4
		  @gold_window.x = orig_x if @gold_window.x <= orig_x && dir == 4
		  @gold_window.x += sp if dir == 6
		  @gold_window.x = orig_x if @gold_window.x >= orig_x && dir == 6
		  @gold_window.y -= sp if dir == 8
		  @gold_window.y = orig_y if @gold_window.y <= orig_y && dir == 8
		  Graphics.update
		  break if @gold_window.y == orig_y && @gold_window.x == orig_x
		end
  end
  
  def rev_status_window_trans(dir = @status_win_dir)
	  case dir
	  when 2
		orig_x, orig_y = @status_window.x, Graphics.height
	  when 4
		orig_x, orig_y = 0 - @status_window.width, @status_window.y
	  when 6
		orig_x, orig_y = Graphics.width, @status_window.y
	  when 8
		orig_x, orig_y = @status_window.x, 0 - @status_window.height
	  end
		sp = NEL::TRANS_SPEED[:actor]
		loop do
		  @status_window.y += sp if dir == 2
		  @status_window.y = orig_y if @status_window.y >= orig_y && dir == 2
		  @status_window.x -= sp if dir == 4
		  @status_window.x = orig_x if @status_window.x <= orig_x && dir == 4
		  @status_window.x += sp if dir == 6
		  @status_window.x = orig_x if @status_window.x >= orig_x && dir == 6
		  @status_window.y -= sp if dir == 8
		  @status_window.y = orig_y if @status_window.y <= orig_y && dir == 8
		  Graphics.update
		  break if @status_window.x == orig_x && @status_window.y == orig_y
		end
  end
  
	def rev_command_window_trans(dir = @command_win_dir)
	  case dir
	  when 2
		orig_x, orig_y = @command_window.x, Graphics.height
	  when 4
		orig_x, orig_y = 0 - @command_window.width, @command_window.y
	  when 6
		orig_x, orig_y = Graphics.width, @command_window.y
	  when 8
		orig_x, orig_y = @command_window.x, 0 - @command_window.height
	  end
		sp = NEL::TRANS_SPEED[:command]
		loop do
		  @command_window.y += sp if dir == 2
		  @command_window.y = orig_y if @command_window.y >= orig_y && dir == 2  
		  @command_window.x -= sp if dir == 4
		  @command_window.x = orig_x if @command_window.x <= orig_x && dir == 4
		  @command_window.x += sp if dir == 6
		  @command_window.x = orig_x if @command_window.x >= orig_x && dir == 6
		  @command_window.y -= sp if dir == 8
		  @command_window.y = orig_y if @command_window.y <= orig_y && dir == 8
		  Graphics.update
		  break if @command_window.x == orig_x && @command_window.y == orig_y
		end
	  end
end