#===============================================================================
#
# YanPac Battle HUD (1.0)
# 22/06/2014
# By Yanfly and Pacman (originally by Yanfly, extracted and worked on by Pacman)
# This script adds the Actor HUD from Yanfly Engine Ace's Battle System to the
# default battle system. It draws the actor's name, face, HP, MP, TP, action
# and states. The script automatically detects whether to draw the actor's TP
# or MP depending on which skills they have. You can change some simple
# aesthetic options below.
# You can use simple notetags to make sure the actor's gauges are drawn:
# \def_draw_hp  - Definitely draw HP
# \def_draw_mp  - Definitely draw MP
# \def_draw_tp  - Definitely draw TP
# \def_not_hp   - Definitely don't draw HP
# \def_not_mp   - Definitely don't draw MP
# \def_not_tp   - Definitely don't draw TP
# The main point of this standalone script is to optimize compatibility with
# other scripts and increase efficiency (currently pending :P).
#
# Version list:
# 1.0: Compatible with Enemy HUD
#   http://pacmanvx.wordpress.com/2012/02/12/enemy-hud/
# 0.3: Compatible with Change Gauge Display
#   http://pacmanvx.wordpress.com/2012/02/11/change-gauge-display/
# 0.2: Compatible with Neo Gauge Ultimate
#   http://pacmanvx.wordpress.com/2012/02/05/neo-gauge-ultimate/
# 0.l: Script extracted / created.
#
#===============================================================================
 
module PAC_HUD
#===============================================================================
# BEGIN CONFIGURATION
#===============================================================================
  BATTLESTATUS_NAME_FONT_SIZE = 20    # Font size used for name.
  BATTLESTATUS_TEXT_FONT_SIZE = 16    # Font size used for HP, MP, TP.
  BATTLESTATUS_NO_ACTION_ICON = 185   # No action icon.
  BATTLESTATUS_HPGAUGE_Y_PLUS = 11    # Y Location buffer used for HP gauge.
  BATTLESTATUS_CENTER_FACES   = false # Center faces for the Battle Status.
  MP_OVER_TP = true                   # If TP is not drawn, draw MP? (still
                                      # applies notetag effects)
#===============================================================================
# END CONFIGURATION
#===============================================================================
end
 
$imported ||= {}
 
#==============================================================================
# ■ Numeric
#------------------------------------------------------------------------------
#  Numeric は数値の抽象クラスです。Ruby では異なる数値クラス間で演算を行うことができます。
# 演算や比較を行うメソッド (+, -, *, /, <=>) などはサブクラスで定義されます。また、効率のため Numeric
# のメソッドと同じメソッドがサブクラスで再定義されている場合があります。 私のひどい日本語を言い訳。
#==============================================================================
 
class Numeric
  #--------------------------------------------------------------------------
  # * Group Digits
  #--------------------------------------------------------------------------
  unless defined?(group); def group; return self.to_s; end; end
end
 
#==============================================================================
# ■ Game_Battler
#------------------------------------------------------------------------------
# 　スプライトや行動に関するメソッドを追加したバトラーのクラスです。このクラス
# は Game_Actor クラスと Game_Enemy クラスのスーパークラスとして使用されます。
#==============================================================================
 
class Game_Battler < Game_BattlerBase
  #--------------------------------------------------------------------------
  # * Draw Battler's HP?
  #--------------------------------------------------------------------------
  def draw_hp?; return true; end
  #--------------------------------------------------------------------------
  # * Draw Battler's MP?
  #--------------------------------------------------------------------------
  def draw_mp?; return true; end
  #--------------------------------------------------------------------------
  # * Draw Battler's TP?
  #--------------------------------------------------------------------------
  def draw_tp?
    return $imported[:pac_change_gauge] ? $game_system.opt_display_tp :
     $data_system.opt_display_tp
  end
end
 
#==============================================================================
# ■ Game_Actor
#------------------------------------------------------------------------------
# 　アクターを扱うクラスです。このクラスは Game_Actors クラス（$game_actors）
# の内部で使用され、Game_Party クラス（$game_party）からも参照されます。
#==============================================================================
 
class Game_Actor < Game_Battler
  #--------------------------------------------------------------------------
  # * Draw Actor's HP?
  #--------------------------------------------------------------------------
  def draw_hp?
    return true if !self.actor.note[/\\def[_ ]?draw[_ ]?hp/i].nil?
    return false if !self.actor.note[/\\def[_ ]?not[_ ]?hp/i].nil?
    if $imported[:pac_gauge_change]
      return false if self.actor.no_hp_display?
    end
    return true
  end
  #--------------------------------------------------------------------------
  # * Draw Actor's MP?
  #--------------------------------------------------------------------------
  def draw_mp?
    return true if !self.actor.note[/\\def[_ ]?draw[_ ]?mp/i].nil?
    return false if !self.actor.note[/\\def[_ ]?not[_ ]?mp/i].nil?
    if $imported[:pac_gauge_change]
      return false if self.actor.no_mp_display?
    end
    return true if !draw_tp? && PAC_HUD::MP_OVER_TP
    for skill in skills
      next unless added_skill_types.include?(skill.stype_id)
      return true if skill.mp_cost > 0
    end
    return false
  end
  #--------------------------------------------------------------------------
  # * Draw Actor's TP?
  #--------------------------------------------------------------------------
  def draw_tp?
    return true if !self.actor.note[/\\def[_ ]?draw[_ ]?tp/i].nil?
    return false if !self.actor.note[/\\def[_ ]?not[_ ]?tp/i].nil?
    if $imported[:pac_gauge_change]
      return false if self.actor.no_tp_display?
    end
    return false unless $imported[:pac_change_gauge] ?
     $game_system.opt_display_tp : $data_system.opt_display_tp
    for skill in skills
      next unless added_skill_types.include?(skill.stype_id)
      return true if skill.tp_cost > 0
    end
    return false
  end
end
 
#==============================================================================
# ■ Window_BattleStatus
#------------------------------------------------------------------------------
# 　バトル画面で、パーティメンバーのステータスを表示するウィンドウです。
#==============================================================================
 
class Window_YanPac_BattleStatus < Window_BattleStatus
  #--------------------------------------------------------------------------
  # * Object Initialization
  #--------------------------------------------------------------------------
  def initialize
    super
    self.openness = 0
    @party = $game_party.battle_members.clone
  end
  #--------------------------------------------------------------------------
  # * Column Max
  #--------------------------------------------------------------------------
  def col_max; return $game_party.max_battle_members; end
  #--------------------------------------------------------------------------
  # * Get Battle Members
  #--------------------------------------------------------------------------
  def battle_members; return $game_party.battle_members; end
  #--------------------------------------------------------------------------
  # * Get Current Actor
  #--------------------------------------------------------------------------
  def actor; return battle_members[@index]; end
  #--------------------------------------------------------------------------
  # * Frame Update
  #--------------------------------------------------------------------------
  def update
    super
    return if @party == $game_party.battle_members
    @party = $game_party.battle_members.clone
    refresh
  end
  #--------------------------------------------------------------------------
  # * Draw Item
  #     index : index of item to be drawn
  #--------------------------------------------------------------------------
  def draw_item(index)
    return if index.nil?
    clear_item(index)
    actor = battle_members[index]
    rect = item_rect(index)
    return if actor.nil?
    draw_actor_face(actor, rect.x+2, rect.y+2, actor.alive?)
    draw_actor_name(actor, rect.x, rect.y, rect.width-8)
    draw_actor_action(actor, rect.x, rect.y)
    draw_actor_icons(actor, rect.x, line_height*1, rect.width)
    gx = PAC_HUD::BATTLESTATUS_HPGAUGE_Y_PLUS
    contents.font.size = PAC_HUD::BATTLESTATUS_TEXT_FONT_SIZE
    if draw_hp?(actor)
      draw_actor_hp(actor, rect.x+2, line_height*2+gx, rect.width-4)
    end
    if draw_tp?(actor) && draw_mp?(actor)
      dw = rect.width/2-2
      dw += 1 if $imported["YEA-CoreEngine"] && YEA::CORE::GAUGE_OUTLINE
      draw_actor_tp(actor, rect.x+2, line_height*3, dw)
      dw = rect.width - rect.width/2 - 2
      draw_actor_mp(actor, rect.x+rect.width/2, line_height*3, dw)
    elsif draw_tp?(actor) && !draw_mp?(actor)
      draw_actor_tp(actor, rect.x+2, line_height*3, rect.width-4)
    elsif !draw_tp?(actor) && draw_mp?(actor)
      draw_actor_mp(actor, rect.x+2, line_height*3, rect.width-4)
    else
    end
  end
  #--------------------------------------------------------------------------
  # * Get Item Rect
  #     index : index of item to get rect for
  #--------------------------------------------------------------------------
  def item_rect(index)
    rect = Rect.new
    rect.width = contents.width / $game_party.max_battle_members
    rect.height = contents.height
    rect.x = index * rect.width
    if PAC_HUD::BATTLESTATUS_CENTER_FACES
      rect.x += (contents.width - $game_party.members.size * rect.width) / 2
    end
    rect.y = 0
    return rect
  end
  #--------------------------------------------------------------------------
  # * Draw Face (specifically for this HUD)
  #--------------------------------------------------------------------------
  def draw_face(face_name, face_index, dx, dy, enabled = true)
    bitmap = Cache.face(face_name)
    fx = [(96 - item_rect(0).width + 1) / 2, 0].max
    fy = face_index / 4 * 96 + 2
    fw = [item_rect(0).width - 4, 92].min
    rect = Rect.new(fx, fy, fw, 92)
    rect = Rect.new(face_index % 4 * 96 + fx, fy, fw, 92)
    contents.blt(dx, dy, bitmap, rect, enabled ? 255 : translucent_alpha)
    bitmap.dispose
  end
  #--------------------------------------------------------------------------
  # * Draw Actor Name
  #--------------------------------------------------------------------------
  def draw_actor_name(actor, dx, dy, dw = 112)
    reset_font_settings
    contents.font.size = PAC_HUD::BATTLESTATUS_NAME_FONT_SIZE
    change_color(hp_color(actor))
    draw_text(dx+24, dy, dw-24, line_height, actor.name)
  end
  #--------------------------------------------------------------------------
  # * Draw Actor's Action Icon
  #--------------------------------------------------------------------------
  def draw_actor_action(actor, dx, dy)
    draw_icon(action_icon(actor), dx, dy)
  end
  #--------------------------------------------------------------------------
  # * Get Actor's Action Icon
  #--------------------------------------------------------------------------
  def action_icon(actor)
    return PAC_HUD::BATTLESTATUS_NO_ACTION_ICON if actor.current_action.nil?
    return PAC_HUD::BATTLESTATUS_NO_ACTION_ICON if actor.current_action.item.nil?
    return actor.current_action.item.icon_index
  end
  #--------------------------------------------------------------------------
  # * Draw Actor's TP?
  #--------------------------------------------------------------------------
  def draw_tp?(actor)
    return actor.draw_tp?
  end
  #--------------------------------------------------------------------------
  # * Draw Actor's MP?
  #--------------------------------------------------------------------------
  def draw_mp?(actor)
    return actor.draw_mp?
  end
  #--------------------------------------------------------------------------
  # * Draw Actor's HP?
  #--------------------------------------------------------------------------
  def draw_hp?(actor)
    return actor.draw_hp?
  end
  #--------------------------------------------------------------------------
  # * Draw Current & Max Values
  #--------------------------------------------------------------------------
  def draw_current_and_max_values(dx, dy, dw, current, max, color1, color2)
    change_color(color1)
    draw_text(dx, dy, dw, line_height, current.group, 2)
  end
  #--------------------------------------------------------------------------
  # * Draw Actor's HP Gauge
  #--------------------------------------------------------------------------
  def draw_actor_hp(actor, dx, dy, width = 124, h = 6, *args)
    if defined?(draw_neo_gauge) # NGU Support
      gwidth = width * actor.hp / actor.mhp
      cg = neo_gauge_back_color
      c1, c2, c3 = cg[0], cg[1], cg[2]
      draw_neo_gauge(dx, dy + line_height - 8, width, h, c1, c2, c3)
      (1..3).each { |i| eval("c#{i} = HP_GCOLOR_#{i}")}
      draw_neo_gauge(dx, dy + line_height - 8, gwidth, h, c1, c2, c3, false,
       false, width, 40)
    else
      draw_gauge(dx, dy, width, actor.hp_rate, hp_gauge_color1, hp_gauge_color2)
    end
    change_color(system_color)
    cy = (Font.default_size - contents.font.size) / 2 + 1
    draw_text(dx+2, dy+cy, 30, line_height, Vocab::hp_a)
    draw_current_and_max_values(dx, dy+cy, width, actor.hp, actor.mhp,
      hp_color(actor), normal_color)
  end
  #--------------------------------------------------------------------------
  # * Draw Actor's MP Gauge
  #--------------------------------------------------------------------------
  def draw_actor_mp(actor, dx, dy, width = 124)
    if defined?(draw_neo_gauge) # NGU Support
      gwidth = width * actor.mp / [actor.mmp, 1].max
      cg = neo_gauge_back_color
      c1, c2, c3 = cg[0], cg[1], cg[2]
      draw_neo_gauge(dx, dy + line_height - 8, width, 6, c1, c2, c3)
      (1..3).each { |i| eval("c#{i} = MP_GCOLOR_#{i}")}
      draw_neo_gauge(dx, dy + line_height - 8, gwidth, 6, c1, c2, c3, false,
       false, width, 40)
    else
      draw_gauge(dx, dy, width, actor.mp_rate, mp_gauge_color1, mp_gauge_color2)
    end
    change_color(system_color)
    cy = (Font.default_size - contents.font.size) / 2 + 1
    draw_text(dx+2, dy+cy, 30, line_height, Vocab::mp_a)
    draw_current_and_max_values(dx, dy+cy, width, actor.mp, actor.mmp,
      mp_color(actor), normal_color)
  end
  #--------------------------------------------------------------------------
  # * Draw Actor's TP Gauge
  #--------------------------------------------------------------------------
  def draw_actor_tp(actor, dx, dy, width = 124)
    if defined?(draw_neo_gauge) # NGU Support
      gwidth = width * actor.tp / 100
      cg = neo_gauge_back_color
      c1, c2, c3 = cg[0], cg[1], cg[2]
      draw_neo_gauge(dx, dy + line_height - 8, width, 6, c1, c2, c3)
      (1..3).each { |i| eval("c#{i} = TP_GCOLOR_#{i}")}
      draw_neo_gauge(dx, dy + line_height - 8, gwidth, 6, c1, c2, c3, false,
       false, width, 40)
    else
      draw_gauge(dx, dy, width, actor.tp_rate, tp_gauge_color1, tp_gauge_color2)
    end
    change_color(system_color)
    cy = (Font.default_size - contents.font.size) / 2 + 1
    draw_text(dx+2, dy+cy, 30, line_height, Vocab::tp_a)
    change_color(tp_color(actor))
    draw_text(dx + width - 42, dy+cy, 42, line_height, actor.tp.to_i, 2)
  end
end

class Scene_Battle < Scene_Base
  def create_status_window
    @status_window = Window_YanPac_BattleStatus.new
    @status_window.x = 128
  end
end
 
($pac ||= {})[:yan_battle_hud] = [1.0]
 
#===============================================================================
#
# END OF SCRIPT
#
#===============================================================================