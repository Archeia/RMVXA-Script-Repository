$imported = {} if $imported.nil?
$imported["Karanum_SkillSubMenu"] = true

module KARANUM
  module SKILLSUBMENU
    
    # Define the skill types that shouldn't show up in this list.
    # Only enter the number they have in the database, not the name.
    # Multiple skill types must be separated by a comma (e.g. [1,2,3])
    HIDDEN_SKILL_TYPES = [3]
    
  end
end

#==============================================================================
# Window_ActorCommand
#==============================================================================
class Window_ActorCommand < Window_Command
  def add_skill_commands
    add_command("Skills", :skill, true)
  end
  
  def add_skill_commands_new
    if $imported["YEA-BattleCommandList"]
      @actor.added_skill_types.each do |stype_id|
        next if KARANUM::SKILLSUBMENU::HIDDEN_SKILL_TYPES.include?(stype_id)
        next if @stype_list.include?(stype_id)
        next if include_subclass_type?(stype_id)
        add_skill_type_command(stype_id)
      end
    else
      @actor.added_skill_types.sort.each do |stype_id|
        next if KARANUM::SKILLSUBMENU::HIDDEN_SKILL_TYPES.include?(stype_id)
        name = $data_system.skill_types[stype_id]
        add_command(name, :skill, true, stype_id)
      end
    end
  end
end

#==============================================================================
# Window_SubSkillCommand
#==============================================================================
class Window_SubSkillCommand < Window_ActorCommand
  def initialize
    super
    self.openness = 0
    deactivate
    @actor = nil
  end

  def window_width
    return 128
  end

  def visible_line_number
    return [4, @list.size].min
  end

  def make_command_list
    return unless @actor
    make_stype_list if $imported["YEA-BattleCommandList"]
    add_skill_commands
  end

  def make_stype_list
    return unless @actor
    @stype_list = []
    for command in @actor.battle_commands
      case command.upcase
      when /SKILL TYPE[ ](\d+)/i
        add_skill_type_command($1.to_i)
      when /SKILL[ ](\d+)/i
        add_skill_id_command($1.to_i)
      else; next
      end
    end
  end
  
  def add_skill_commands
    add_skill_commands_new
  end
  
  def setup(actor)
    @actor = actor
    clear_command_list
    make_command_list
    refresh
    select(0)
    move(x, y, width, fitting_height(visible_line_number))
    activate
    open
  end
end

#==============================================================================
# Scene_Battle
#==============================================================================
class Scene_Battle < Scene_Base
  alias karanum_subskill_createallwindows create_all_windows
  def create_all_windows
    karanum_subskill_createallwindows
    create_subskill_command_window
  end
  
  def create_subskill_command_window
    @subskill_command_window = Window_SubSkillCommand.new
    @subskill_command_window.viewport = @info_viewport
    @subskill_command_window.set_handler(:skill,  method(:on_subskill_ok))
    @subskill_command_window.set_handler(:cancel, method(:on_subskill_cancel))
    @subskill_command_window.x = @actor_command_window.x
    @subskill_command_window.width = @actor_command_window.width
  end
  
  def command_skill
    @subskill_command_window.setup(BattleManager.actor)
  end
  
  def on_skill_cancel
    @skill_window.hide
    @status_window.show
    @subskill_command_window.activate
  end
  
  alias karanum_subskill_actorok on_actor_ok
  def on_actor_ok
    @subskill_command_window.close
    karanum_subskill_actorok
  end
  
  alias karanum_subskill_enemyok on_enemy_ok
  def on_enemy_ok
    @subskill_command_window.close
    karanum_subskill_enemyok
  end
  
  def on_subskill_ok
    @status_window.hide
    @skill_window.actor = BattleManager.actor
    @skill_window.stype_id = @subskill_command_window.current_ext
    @skill_window.refresh
    @skill_window.show.activate
  end
  
  def on_subskill_cancel
    @subskill_command_window.deactivate
    @subskill_command_window.close
    @actor_command_window.activate
  end
end 