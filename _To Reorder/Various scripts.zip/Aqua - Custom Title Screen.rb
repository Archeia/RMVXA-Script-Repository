#============================================================================
# ? Title Screen Aqua ?
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# This script gives you control over the title screen, from customizing
# its appearance to adding extra options to it~
#============================================================================

$imported = {} if $imported.nil?
$imported["zeaq_titlescreen"] = true

module ZEAQ
  module TitleScreen

    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # ? Appearance Options ?
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # These options configure the appearance of the title screen. You can
    # customize these to make the title screen stand out!
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    # Enable custom appearance?
    # If this setting is false, the font and Windowskin options will remain
    # unchanged from the default.
    CHANGE_APPEARANCE = true

    # Font Options
    FONT_FACE = ["Segoe Script", "Verdana", "Arial", "Courier"] # Font name
    FONT_SIZE = 32       # Font size used on the title screen
    FONT_COL = [255, 255, 255] # The colour of text ([red, blue, green])
    FONT_BOLD = false    # Whether or not text should appear bold
    FONT_ITALIC = false  # Whether or not text should appear italic
    FONT_SHADOW = false  # Whether or not text should have a shadow
    FONT_OUTLINE = true  # Whether or not text should have an outline
    FONT_OUT_COL = [0, 0, 0] # The colour of the outline ([red, blue, green])

    # Window Options
    WINDOWSKIN = "Window2" # Windowskin used on the title screen
    OPACITY = 0         # Opacity (how visible) level of the Windowskin
    BACK_OPACITY = 0    # Opacity of the back of the Windowskin
    PADDING = 12          # The padding of text in the Window
    PADDING_BOTTOM = 12   # The bottom padding of text in the Window

    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # ? Size and Position Options ?
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # These options configure the position of the window on the title screen.
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    # Enable custom size and/or position?
    # If this setting is false, the position of the Window will remain
    # unchanged from the default.
    CHANGE_SIZE_POSITION = true

    # Size Options
    WINDOW_WIDTH = 180  # Window width; if 0, the default will be used

    # Position Options
    WINDOW_X = 400 # Window X position; if -1, the default will be used
    WINDOW_Y = 350 # Window Y position; if -1, the default will be used

    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # ? Game Title Options ?
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # These options allow you to customize how the game title will be
    # displayed on the title screen, if you've chosen to display it.
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    # Font Options
    NAME_FONT = ["Segoe Script", "Verdana", "Arial", "Courier"] # Font name
    NAME_SIZE = 0      # Font size used on the title screen
    NAME_COL = [255, 255, 255] # The colour of text ([red, blue, green])
    NAME_BOLD = true    # Whether or not text should appear bold
    NAME_ITALIC = true  # Whether or not text should appear italic
    NAME_SHADOW = true  # Whether or not text should have a shadow
    NAME_OUTLINE = true # Whether or not text should have an outline
    NAME_OUT_COL = [0, 0, 0] # The colour of the outline ([red, blue, green])

    # Position Options
    NAME_X = 0     # X movement from position on the screen
    NAME_Y = 68    # Y movement from top of the screen
    NAME_ALIGN = 1 # 0-Left; 1-Middle; 2-Right

    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # ? Graphic and Sound Options ?
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # These options allow you to customize the graphic and sound on the title
    # screen using advanced options.
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    # Here you can create a list of graphics that can be displayed on the title
    # screen. A random one from the list is shown every time the title screen
    # is shown, so you aren't stuck with just one graphic.
    # The format to use is: ["Title1", "Title2"],
    GRAPHICS = [
            ["WhitePearlTitle2", ""],
            ["WhitePearlTitle3", ""],
            ["WhitePearlTitle4", ""],
            ["WhitePearlTitle5", ""],
    ]

    # Here you can create a list of music to play on the title screen, and/or
    # add a BGS or ME to the title screen.
    #
    # The format to use is:
    # [["BGM", Volume, Pitch], ["BGS", Volume, "Pitch"], ["ME", Volume, Pitch]]
    #
    # If you don't want to use a BGS, ME or even don't want a BGM, but want
    # other sounds, set the one(s) you don't want to "nil"
    # [["BGM", Volume, Pitch], nil, nil] will produce a BGM only.
    # [["BGM", Volume, Pitch], ["BGS", Volume, "Pitch"], nil] will produce a BGM
    # and BGS.
    SOUNDS = [
            [[nil, nil, nil], [nil, nil, nil], [nil, nil, nil]],
            [[nil, nil, nil], nil, nil],
            [[nil, nil, nil], [nil, nil, nil], nil],
            [[nil, nil, nil], nil, [nil, nil, nil]],
    ]

    # This option sets whether sounds and graphics should be linked together. If
    # this is set to true, the first sound in the sounds list will always play
    # with the first graphic in the graphics list, the second sound with the
    # second graphic, and so on. If this is false, the graphics and sounds will
    # be randomized completely seperate from each other. If you enable this
    # option, you will need to have the same amount of graphics and sounds or
    # else the title screen could appear with no graphic or no sound.
    CONNECT_GRAPHICS_AND_SOUNDS = true

    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # ? Title Screen Menu ?
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # This allows you to list the options that will appear on the title
    # screen, in the order they should appear. Scroll further down to define
    # your own custom options.
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    MENU_OPTIONS = [
            :new_game,
            :continue,
            #:custom1,
            #:custom2,
            :shutdown,
    ]
    SHOW_CONTINUE = false # Show continue if there are no save files?

    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # ? Normal Menu Options ?
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # These are the normal menu options that have their own scripts to run.
    # If you are using a script that is meant to add an option to the title
    # screen, you can add it here.
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # ID:    The name and method of the option to be called from the option
    #        above. This is also the name of the handler used.
    # Name:  The name to be displayed on the title menu.
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    NORMAL_OPTIONS = {
            #--------------------------------#
            # ID        => "Name",           #
            #--------------------------------#
            :new_game   => "Begin Anew",
            :continue   => "Open The Book",
            :shutdown   => "Close The Book",
    }

    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # ? Extra Starting Positions ?
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # This allows you to add your own additional "New Game"-type options
    # where you can choose different starting positions.
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # ID:    The technical name of the extra option to be called from the
    #        option above.
    # Name:  The name to be displayed on the title menu.
    # Map:   The map where the players start when using this extra option.
    # Map X: The X position on the map.
    # Map Y: The Y position on the map.
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    EXTRA_OPTIONS = {
            #---------------------------------------------------#
            # ID        => ["Name",           Map, MapX, MapY], #
            #---------------------------------------------------#
            :custom1    => ["Tutorial",       3,   10,   12  ],
            :custom2    => ["Credits",        4,   4,    2   ],
    }

    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # ? Radial Animation Options ?
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # Here you can create an animation for the title screen background,
    # similar to RPG Maker VX's default battle system.
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    # Enable?
    RADIAL_ANIMATION = false

    # Blur Options
    RADIAL_BLUR_ANGLE = 10 # Radial blur angle
    RADIAL_BLUR_DIVISION = 12 # Radial blur division (smoothness)

    # Wave Options
    WAVE_AMP = 2      # Wave amplitude
    WAVE_LENGTH = 30 # Wave frequency
    WAVE_SPEED = 60  # Wave speed

  end #TitleScreen
end #ZEAQ

class Window_TitleCommand < Window_Command
  alias zeaq_titlescreen_initialize initialize
  def initialize
    zeaq_titlescreen_initialize
    if ZEAQ::TitleScreen::CHANGE_APPEARANCE
      self.windowskin     = Cache.system(ZEAQ::TitleScreen::WINDOWSKIN)
      self.opacity        = ZEAQ::TitleScreen::OPACITY
      self.back_opacity   = ZEAQ::TitleScreen::BACK_OPACITY
      self.padding        = ZEAQ::TitleScreen::PADDING
      self.padding_bottom = ZEAQ::TitleScreen::PADDING_BOTTOM
    end
  end
  alias zeaq_titlescreen_draw_item draw_item
  def draw_item(index)
    if ZEAQ::TitleScreen::CHANGE_APPEARANCE
      contents.font.name      = ZEAQ::TitleScreen::FONT_FACE
      contents.font.size      = ZEAQ::TitleScreen::FONT_SIZE
      contents.font.color     = Color.new(ZEAQ::TitleScreen::FONT_COL[0], ZEAQ::TitleScreen::FONT_COL[1], ZEAQ::TitleScreen::FONT_COL[2])
      contents.font.bold      = ZEAQ::TitleScreen::FONT_BOLD
      contents.font.italic    = ZEAQ::TitleScreen::FONT_ITALIC
      contents.font.shadow    = ZEAQ::TitleScreen::FONT_SHADOW
      contents.font.outline   = ZEAQ::TitleScreen::FONT_OUTLINE
      contents.font.out_color = Color.new(ZEAQ::TitleScreen::FONT_OUT_COL[0], ZEAQ::TitleScreen::FONT_OUT_COL[1], ZEAQ::TitleScreen::FONT_OUT_COL[2])
    end
    zeaq_titlescreen_draw_item(index)
  end
  alias zeaq_titlescreen_window_width window_width
  def window_width
    if ZEAQ::TitleScreen::WINDOW_WIDTH != 0 && ZEAQ::TitleScreen::CHANGE_SIZE_POSITION
      return ZEAQ::TitleScreen::WINDOW_WIDTH
    else
      zeaq_titlescreen_window_width
    end
  end
  def update_placement
    if ZEAQ::TitleScreen::WINDOW_X != -1 && ZEAQ::TitleScreen::CHANGE_SIZE_POSITION
      self.x = ZEAQ::TitleScreen::WINDOW_X
    else
      self.x = (Graphics.width - width) / 2
    end
    if ZEAQ::TitleScreen::WINDOW_Y != -1 && ZEAQ::TitleScreen::CHANGE_SIZE_POSITION
      self.y = ZEAQ::TitleScreen::WINDOW_Y
    else
      self.y = (Graphics.height * 1.6 - height) / 2
    end
  end
  def make_command_list
    ZEAQ::TitleScreen::MENU_OPTIONS.each{|n|
      if ZEAQ::TitleScreen::NORMAL_OPTIONS[n]
        if n == :continue && !continue_enabled && ZEAQ::TitleScreen::SHOW_CONTINUE
          add_command(ZEAQ::TitleScreen::NORMAL_OPTIONS[n], n, false)
        else
          add_command(ZEAQ::TitleScreen::NORMAL_OPTIONS[n], n, true)
        end
      end
      if ZEAQ::TitleScreen::EXTRA_OPTIONS[n]
        add_command(ZEAQ::TitleScreen::EXTRA_OPTIONS[n][0], :zeaq_command, true, ZEAQ::TitleScreen::EXTRA_OPTIONS[n])
      end
    }
  end
end

class Scene_Title < Scene_Base
  alias zeaq_titlescreen_start start
  def start
    if ZEAQ::TitleScreen::CONNECT_GRAPHICS_AND_SOUNDS
      if ZEAQ::TitleScreen::GRAPHICS.size >= ZEAQ::TitleScreen::SOUNDS.size
        @random_value = rand(ZEAQ::TitleScreen::GRAPHICS.size)
      else
        @random_value = rand(ZEAQ::TitleScreen::SOUNDS.size)
      end
    end
    zeaq_titlescreen_start
  end
  def create_background
    if @random_value
      graphic = ZEAQ::TitleScreen::GRAPHICS[@random_value]
    else
      graphic = ZEAQ::TitleScreen::GRAPHICS[rand(ZEAQ::TitleScreen::GRAPHICS.size)]
    end
    @sprite1 = Sprite.new
    @sprite1.bitmap = Cache.title1(graphic[0])
    if ZEAQ::TitleScreen::RADIAL_ANIMATION
      @sprite1.bitmap.radial_blur(ZEAQ::TitleScreen::RADIAL_BLUR_ANGLE, ZEAQ::TitleScreen::RADIAL_BLUR_DIVISION)
      @sprite1.wave_amp = ZEAQ::TitleScreen::WAVE_AMP
      @sprite1.wave_length = ZEAQ::TitleScreen::WAVE_LENGTH
      @sprite1.wave_speed = ZEAQ::TitleScreen::WAVE_SPEED
    end
    @sprite2 = Sprite.new
    @sprite2.bitmap = Cache.title2(graphic[1])
    center_sprite(@sprite1)
    center_sprite(@sprite2)
  end
  def draw_game_title
    @foreground_sprite.bitmap.font.name = ZEAQ::TitleScreen::NAME_FONT
    @foreground_sprite.bitmap.font.size = ZEAQ::TitleScreen::NAME_SIZE
    @foreground_sprite.bitmap.font.color = Color.new(ZEAQ::TitleScreen::NAME_COL[0], ZEAQ::TitleScreen::NAME_COL[1], ZEAQ::TitleScreen::NAME_COL[2])
    @foreground_sprite.bitmap.font.bold = ZEAQ::TitleScreen::NAME_BOLD
    @foreground_sprite.bitmap.font.italic = ZEAQ::TitleScreen::NAME_ITALIC
    @foreground_sprite.bitmap.font.shadow = ZEAQ::TitleScreen::NAME_SHADOW
    @foreground_sprite.bitmap.font.outline = ZEAQ::TitleScreen::NAME_OUTLINE
    @foreground_sprite.bitmap.font.out_color = Color.new(ZEAQ::TitleScreen::NAME_OUT_COL[0], ZEAQ::TitleScreen::NAME_OUT_COL[1], ZEAQ::TitleScreen::NAME_OUT_COL[2])
    rect = Rect.new(ZEAQ::TitleScreen::NAME_X, ZEAQ::TitleScreen::NAME_Y, Graphics.width, ZEAQ::TitleScreen::NAME_SIZE)
    @foreground_sprite.bitmap.draw_text(rect, $data_system.game_title, ZEAQ::TitleScreen::NAME_ALIGN)
  end
  def zeaq_titlescreen_command
    n = @command_window.current_ext
    DataManager.create_game_objects
    $game_party.setup_starting_members
    $game_map.setup(n[1])
    $game_player.moveto(n[2], n[3])
    $game_player.refresh
    Graphics.frame_count = 0
    close_command_window
    fadeout_all
    $game_map.autoplay
    SceneManager.goto(Scene_Map)
  end
  alias zeaq_titlescreen_create_command_window create_command_window
    def create_command_window
    zeaq_titlescreen_create_command_window
    @command_window.set_handler(:zeaq_command, method(:zeaq_titlescreen_command))
  end
  alias zeaq_titlescreen_update update
  def update
    zeaq_titlescreen_update
    if ZEAQ::TitleScreen::RADIAL_ANIMATION
      @sprite1.update
    end
  end
end