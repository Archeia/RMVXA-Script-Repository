#==============================================================================
# ■ 「SIMPLE STUPID」 Jump! ver.0.60
# by HBK61 (heartbreak61)
# Requires: N/A
# Rewrites method:  N/A
# Aliases method:
#   Game_Player#initialize
#   Scene_Map#update_scene
#              
#==============================================================================
# CHANGELOG
# - ver0.60  2013.05.12   Started the script & finished
#==============================================================================
# INTRODUCTION
# - Simply stupidly add jump effect on map with button press.
#==============================================================================
# INSTRUCTION
# - Set the properties below
#==============================================================================

module HBK
  module JUMP
#==============================================================================
# CONFIGURATION
    Jump_Distance = 3 # jump distance
    Jump_Button = :X # button to do jumping
    Jump_Delay = 0 # jump delay before another jump in seconds
    Jump_Switch = 0 # set this switch to enable/disable jump
# END of CONFIGURATION
#==============================================================================
  end
end

class Game_Player
  alias hbk_ssjs_initialize initialize
  def initialize
    hbk_ssjs_initialize
    @jump_delay = 0
  end
  
  def button_jump
  if $game_switches[HBK::JUMP::Jump_Switch] || HBK::JUMP::Jump_Switch == 0
    return unless normal_walk?
    return if @jump_delay > 0
    @jump_delay = (HBK::JUMP::Jump_Delay * Graphics.frame_rate).to_i
    i = HBK::JUMP::Jump_Distance
    while i > 1
      return if jumping?
      if @direction == 2
        xtgt = @x
        ytgt = @y + i
      elsif @direction == 4
        xtgt = @x - i
        ytgt = @y
      elsif @direction == 8
        xtgt = @x
        ytgt = @y - i
      elsif @direction == 6
        xtgt = @x + i
        ytgt = @y
      end
      ev = true
      $game_map.events.each_key{|e|
        if $game_map.events[e].x == xtgt && $game_map.events[e].y == ytgt && $game_map.events[e].normal_priority?
          ev = false
        end
      }
      if map_passable?(xtgt, ytgt, @direction) && ev
        case @direction
        when 2
          jump(0,i)
        when 4
          jump(-i,0)
        when 8
          jump(0,-i)
        when 6
          jump(i,0)
        end
        @followers.each{|f| f.button_jump}
        return
      end
      i -= 1
    end
  end
  end
  
  attr_accessor :jump_delay, :button_jumping
end

class Game_Follower
  def button_jump
    sx = dxffj($game_player.x)
    sy = dyffj($game_player.y)
    jump(sx,sy)
  end

  def dxffj(x)
    result = x - @x
    if $game_map.loop_horizontal? && result.abs > $game_map.width / 2
      if result < 0
        result += $game_map.width
      else
        result -= $game_map.width
      end
    end
    result
  end

  def dyffj(y)
    result = y - @y
    if $game_map.loop_vertical? && result.abs > $game_map.height / 2
      if result < 0
        result += $game_map.height
      else
        result -= $game_map.height
      end
    end
    result
  end
end

class Scene_Map
  alias hbk_ssjs_update_scene update_scene
  def update_scene
    hbk_ssjs_update_scene
    unless scene_changing?
      $game_player.button_jump if Input.press?(HBK::JUMP::Jump_Button)
      $game_player.jump_delay -= 1 if $game_player.jump_delay > 0
    end
  end  
end