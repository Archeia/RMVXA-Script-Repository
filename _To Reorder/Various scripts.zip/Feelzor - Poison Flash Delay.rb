if true # Change "true" to "false" if you want to disable it
################################################################################
#                           No More Flash Disaster                             #
#                                By Feelzor                                    #
#                                                                              #
# • DO NOT REMOVE OR ALTER THIS HEADER.                                        #
#                                                                              #
# ---------------------------------------------------------------------------- #
#                                                                              #
# • What this script does:                                                     #
#                                                                              #
# When you put a lot of damaging tiles on the ground, you can have a lot of    #
# flash effects, making your game epileptic and not enjoyable at all.          #
# This script is here to delay the next red flash when you walk on these       #
# tiles. By default, it's at maximum 1 flash per second.                       #
#                                                                              #
# If the delay you put in the settings is too long, I cannot guarantee it      #
# won't interfer with the poison flash delay.                                  #
#                                                                              #
# ---------------------------------------------------------------------------- #
#                                                                              #
# • Just plug and play!                                                        #
# No configuration needed but you can modify the FLASH_TIME to change how the  #
# script works.                                                                #
#                                                                              #
# ---------------------------------------------------------------------------- #
#                                                                              #
# • Free to use in any project: Commercial or Non-Commercial.                  #
# • Credits not required but appreciated!                                      #
#                                                                              #
# If you wish to credit, just write "No More Flash Disaster by Feelzor"        #
# somewhere.                                                                   #
#                                                                              #
################################################################################

  module NoMoreFlashDisaster
    FLASH_TIME = 2.0 # Time necessary between two flashes (in seconds)
  end

  class Game_Screen
    #-------------------------------------------------------------------------- 
    # • Start Flash (for Poison/Damage Floor) 
    #-------------------------------------------------------------------------- 
    def start_flash_for_damage
      @flash_time ||= NoMoreFlashDisaster::FLASH_TIME
      @last_time ||= Time.now - @flash_time
      
      if Time.now - @last_time >= @flash_time
        @last_time = Time.now
        start_flash(Color.new(255,0,0,128), 8)
      end
    end
  end
end