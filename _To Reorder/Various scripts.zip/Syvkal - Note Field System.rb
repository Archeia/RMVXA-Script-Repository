#==============================================================================
# ** Notes Field System
#------------------------------------------------------------------------------
# By Syvkal
# Version 1.3
# 24-12-12
#------------------------------------------------------------------------------
# * Original available at: 
#  www.rpgmakervxace.net  &  forums.rpgmakerweb.com
#  Please redistribute this script ;)
#==============================================================================
#
#  - INTRODUCTION -
#
#  I want to standardise how we use the notes field from the database to make
#  scripting and compatibility easier
#
#  So feel free to use this script in conjunction with any of your own scripts
#
#------------------------------------------------------------------------------
#
#  - USAGE -
#
#  I have designed the System to convert the contents of the notes field into
#  a Hash (also called an associative array), allowing you to set up note field
#  'tags' of any kind - which can be easily referenced from within a script. 
#
#       --- Setting Up Tags -------------------------------
#
#  To add a tag to the notes field simply write its name as a symbol
#  ie. start it with a colon ':' For Example:
#     :this_is_a_tag
#
#  As this is a Hash, define the tags value as follows:
#     :tag => x
#
#  Where x can be a string (wrapped in quote marks) eg.
#     :tag => 'Helloooo'
#  or x can be a number eg.
#     :tag => 3423
#  or x can be an array eg.
#     :tag => [567, 'hello', [0]]
#  or x can be another Hash eg.
#     :tag => {:thing => 'hello', :etc => [54, [0,1], 5] }
#
#  The tags can be placed in any order, the only restriction being that they
#  must be placed at the beginning of a line. So an example Notebox:
#     :tag1 => 1
#     Greeting Text:
#     :tag2 => 'Hello'
#     Weapon test :weapon_tags => [23, 2]
#     :tag3 => ['Extra', 'Options']
#
#  Will result in the following 'Note Field':
#     {:tag1 => 1,
#      :tag2 => 'Hello',
#      :tag3 => ['Extra', 'Options'] }
#
#       --- Compatability ---------------------------------
#
#  The System will only take valid 'tags' which have a colon ':' (at the
#  beginning of a line in the notes field) and the '=>' operator afterwards.
#
#  Any tagging method from other scripts will simply be ignored, so you don't
#  need to worry about changing anything else (idea inspired by KilloZapit)
#
#       --- Scripting -------------------------------------
#
#  Making your own scripts using this should be fairly simple
#  A base items note field can be called by:
#     item.note_field
#
#  Checking for tags can be done like this:
#     item.note_field.include?(:tag)
#
#  And finally taking that tags value is done like this:
#     item.note_field[:tag]
#
#  Make sure you check that the tag exists before trying to take its value,
#  as if it doesn't it will most likely end in errors.
#
#==============================================================================

#==============================================================================
# ** Script Import
#==============================================================================
  
  $imported = {} if $imported.nil?
  $imported["Notes Field System"] = true

#==============================================================================
# ** NOTES Module
#------------------------------------------------------------------------------
#  Handles Notes Field System operations
#==============================================================================

module NOTES
  #--------------------------------------------------------------------------
  # * Gets the Field
  #--------------------------------------------------------------------------  
  def field(note)
    notes = ''+note
    eval("{#{notes.split(/[,]*[\r\n]+/).delete_if{|line|(line =~ /^:.*=>.*/).nil?}.join(',')}}")
  end
end

#==============================================================================
# ** RPG::BaseItem
#------------------------------------------------------------------------------
#  Defines the Note Field
#==============================================================================

class RPG::BaseItem
  #--------------------------------------------------------------------------
  # * Includes The NOTES Module
  #--------------------------------------------------------------------------  
  include NOTES
  #--------------------------------------------------------------------------
  # * Gets the Note Field
  #--------------------------------------------------------------------------  
  def note_field
    @field = field(note) if @field.nil?
    return @field
  end
end