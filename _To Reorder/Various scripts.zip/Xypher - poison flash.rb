class Game_Party < Game_Unit
 
  def s_any?(state_2)
    members.any? {|actor| actor.state?(state_2)}
  end
 
end



class Game_Actor < Game_Battler
 
    def turn_end_on_map
    if $game_party.steps % steps_for_turn == 0
      on_turn_end
      perform_map_damage_effect if $game_party.s_any?(2)
    end
  end
 
end

