#-------------------------------------------------------------------------------
# Autopause At Punctuation v1.0
#-- Automatically pauses your dialogue, briefly, at punctuation marks.
#-- By mjshi
#-------------------------------------------------------------------------------
# Installation: Plug and play. Put above Main.
#-------------------------------------------------------------------------------
# You know, I bet your eyes paused for a moment at the comma in this sentence.
# And I bet you paused, too (but longer) at that period in the sentence above.
# What this script does is pause dialogue briefly at certain punctuation marks,
# mimicking natural speech.
#-------------------------------------------------------------------------------
# Currently supported punctuation:
# [Pauses for 1/4 second] , - :
# [Pauses for 1/2 second] . ? ! ~ ... ;
#-------------------------------------------------------------------------------
# This script also pauses for 1/2 second whenever there is valid punctuation
# followed by a " or ) or ' character.
# For example: (this would pause.) "this too:" 'and this-' (this would not)
# [Valid punctuation] , - : . ? ! ~ ;
#-------------------------------------------------------------------------------

class Window_Base
  alias _autopause_convert_escape_characters convert_escape_characters
  def convert_escape_characters(text)
    
    #handle word chars
    text.gsub!(/\. /, ".\\.\\. ")
    text.gsub!(/\.\.\.\\\.\\\. /, "...\\.\\. ")
    
    text.gsub!(/([.?!~;,-:])" /, "\\1\"\\.\\. ")
    text.gsub!(/([.?!~;,-:])' /, "\\1'\\.\\. ")
    text.gsub!(/([.?!~;,-:])\) /, "\\1)\\.\\. ")
    text.gsub!(/- /, "-\\. ")
    text.gsub!(/, /, ",\\. ")
    text.gsub!(/: /, ":\\. ")
    text.gsub!(/\? /, "?\\.\\. ")
    text.gsub!(/! /, "!\\.\\. ")
    text.gsub!(/; /, ";\\.\\. ")
    text.gsub!(/~ /, "~\\.\\. ")
    
    #handle newlines
    text.gsub!(/\.\n(?!$)/, ".\\.\\.\n")
    text.gsub!(/\.\.\.\\\.\\\.\n(?!$)/, "...\\.\\.\n")
    
    text.gsub!(/([.?!~;,-:])"\n(?!$)/, "\\1\"\\.\\.\n")
    text.gsub!(/([.?!~;,-:])'\n(?!$)/, "\\1'\\.\\.\n")
    text.gsub!(/([.?!~;,-:])\)\n(?!$)/, "\\1)\\.\\.\n")
    text.gsub!(/-\n(?!$)/, "-\\.\n")
    text.gsub!(/,\n(?!$)/, ",\\.\n")
    text.gsub!(/:\n(?!$)/, ":\\.\n")
    text.gsub!(/\?\n(?!$)/, "?\\.\\.\n")
    text.gsub!(/!\n(?!$)/, "!\\.\\.\n")
    text.gsub!(/;\n(?!$)/, ";\\.\\.\n")
    text.gsub!(/~\n(?!$)/, "~\\.\\.\n")
    
    _autopause_convert_escape_characters(text)
  end
end