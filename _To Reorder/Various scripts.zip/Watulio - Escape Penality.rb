#==============================================================================# 
# Simple Penalty for escape Script. (EXP for money)
# 
#==============================================================================
#==============================================================================
#
Sprite_Battler
#==============================================================================
class Game_Unit    
#--------------------------------------------------------------------------  
# * Calculate EXP  
#--------------------------------------------------------------------------  
def exp    
return 1 if members.size == 0   
 members.inject(0) {|r, member| r += member.exp }  
 end
 end
 module BattleManager  
 #--------------------------------------------------------------------------  
 # * Create Escape Success Probability  
 #-------------------------------------------------------------------------- 
 def self.make_escape_ratio    
 enemies_agi = $game_troop.exp    
 @escape_ratio = enemies_agi 
 end 
 #--------------------------------------------------------------------------  
 # * Escape Processing  
 #--------------------------------------------------------------------------  
 def self.process_escape    
 $game_message.add(sprintf(Vocab::EscapeStart, $game_party.name))   
 if @preemptive   
 success = true      
 text = "But then you remember you weren't seen by the enemy!"      
 $game_message.add('\.' + text)     
 text = "So you flee!"     
 $game_message.add('\.' + text)    
 else
 if $game_party.gold >= @escape_ratio       
 text = "You throw " + @escape_ratio.to_s + " gold and flee."     
 $game_message.add('\.' + text)      
 $game_party.lose_gold(@escape_ratio)      
 success = true      
 else        
 text = "But you don't have enough gold to distract the enemy."    
 $game_message.add('\.' + text)     
 end  
 end         
 if success     
 Sound.play_escape   
 wait_for_message    
 process_abort    
 else      
 @escape_ratio *= 0.9     
 $game_party.clear_actions  
 end     
 return success  
 end
 end