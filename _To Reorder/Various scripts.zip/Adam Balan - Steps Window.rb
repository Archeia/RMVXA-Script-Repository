#==============================================================================
# Window Steps Script
#------------------------------------------------------------------------------
#  Allows you to show the current amount of steps in the status menu when you
#  open up the menu via esc on the keyboard.
#
#  Author: Adam Balan (Adrien., A.)
#  Incomptaibility?: Nothing.
#  Notes: plug and play.
#  Version 1.1
#==============================================================================

#==============================================================================
# Module WindowVocab
#------------------------------------------------------------------------------
#   STEPS = name of the steps vocab.
#==============================================================================

module WindowVocab
  STEPS = "Steps" #name of the steps
end

#==============================================================================
# Window_Steps
#------------------------------------------------------------------------------
# 　Window Steps shows a steps window above the gold in the menu.
#==============================================================================

class Window_Steps < Window_Base
  #--------------------------------------------------------------------------
  #   Initialize the class.
  #--------------------------------------------------------------------------
  def initialize
	super(0, 0, 160, fitting_height(1))
	refresh
  end

  #--------------------------------------------------------------------------
  #   Refresh the box.
  #--------------------------------------------------------------------------
  def refresh
	contents.clear
	draw_currency_value(value, currency_unit, 4, 0, contents.width - 8)
  end
  #--------------------------------------------------------------------------
  #   Get the value of the steps.
  #--------------------------------------------------------------------------
  def value
	$game_party.steps
  end
  #--------------------------------------------------------------------------
  #   Define the Vocab.
  #--------------------------------------------------------------------------
  def currency_unit
	WindowVocab::STEPS
  end
end

#==============================================================================
# Scene_Menu
#------------------------------------------------------------------------------
#  Create the Menu - we are only editing one method and adding a new.
#
#  Alias: start method to add the steps window.
#==============================================================================

class Scene_Menu < Scene_MenuBase

  #--------------------------------------------------------------------------
  #   Alias: start method.
  #--------------------------------------------------------------------------
  alias start_a start
  def start
	start_a
	create_steps_window
  end

  #--------------------------------------------------------------------------
  #   Create the window.
  #--------------------------------------------------------------------------
  def create_steps_window
	@steps_window = Window_Steps.new
	@steps_window.x = 0
	@steps_window.y = (Graphics.height - @steps_window.height) - 50
  end

end