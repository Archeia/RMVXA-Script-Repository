#============================================================================
# * Gumps LevelUP Messenger
# * Author: Matt Sully (Gump)
# * Version: FINAL 1.02
#
# - Intended to replace the default level up messaging system with a 'popup'
# window displaying more details of the leveling process.
# - Old/new stats/lvl is shown, skill messages are also shown all within the
# window.
# - The LevelUP Window will not display if a character levels in a battle.
# when the player returns to a map (so scene_map is running) then any pending
# level messages will be drawn (in accordance with first-in-first-out).
# - If a character levels multiple times, the system has built in logic to
# handle that and appropriately puts together all data.
# - At most, 10 'new skill' messages can be displayed at any time in the
# Window. This means that if a character gains more than 10 skills, the
# extra skill messages will not be shown (as they will be beyond the windows
# boundaries). Could happen if a character levels multiple times before the
# level UP Window is able to send feedback to the player and that character
# gained a lot of skills. 10 skill messages is a pretty sizeable buffer though.
# - Because this system replaces the built in one, it is affected by 'show exp'
# based settings within VX Ace. Always enable "show" on any exp gain stuff if
# you want the LevelUP window to popup.
# - To use this script, paste it anywhere into your script materials section.
# - Be sure to give the settings a glance and change anything you need to, they
# are at the top of this script (scroll down).
#----------------------
# * ==[NEW STUFF SINCE FINAL 1.00]==
#
# - Added options for window x and y base/control position
# - Added extended window config options for Z, width and height (most will
# never use these)
# - Finalized the script with a witty comment or two including this one
#
# * ==[NEW STUFF SINCE FINAL 1.01]==
# - added in Support for Yanfly Victory Aftermath
#   Window will not show when leveling up in battle
#
#----------------------
#         ==[Modified Default Classes]==
#
# * GAME_ACTOR                     * SCENE_MAP
# > Aliased Methods: 1             > Aliased Methods: 2
# > Overwritten Methods: 1         > Overwritten Methods: 0
# > Added Methods: 3               > Added Methods: 6
#----------------------
# * Added Modules/Classes
#  > module LevelUP
#  > class Window_LevelMSG_Feedback
#----------------------
# * LEGAL CRAP
# (1) You may modify this script as you see fit, you may also release modifications
# to the public, but you may not make any demands that counter this scripts copy
# of the LEGAL CRAP text.
# (1- If you modify and release this script to the public in any format, you
# must include this scripts copy of the LEGAL CRAP text.
# (2) You may freely use this script in any free or commercial game.
# (3) If you use this script in your game, you must provide credit to the 'Author'
# of this script, defined at the top of this script.
#----------------------
# * Other Stuff
# If you Want to set any of the color settings to default colors, here are the
# defaults for your convenience:
# Default_Outline: Color.new(0, 0, 0, 128) 
# Default_Text: Color.new(255, 255, 255, 255)
# > If you have other scripts or systems that do things within scene_map, and you
# are a scripter, but the priority setting is not enough to get things working,
# you can use the method added to scene_map 'drawing_lvlmsg?'. The method will
# return true if a message is currently drawing, you can use this method to check
# if a LevelUP message is active and back out of doing anything else.
#============================================================================


#======================================
# * Levelup System Settings
#======================================
module LevelUP
  
  #---------------------------------------------
  # * Scene_Map Update Priority
  # > The priroity rating for when to update the levelup system
  # within scene_map.
  # Values: 1, 2
  # 1 - High (Levelup system updating is done first, then Scene_Map performs
  # its regular update routine).
  # 2 - Low (Scene_Map performs its regular update routine, then the Levelup
  # system updating is done).
  #---------------------------------------------
  Scene_Map_Update_Priority = 1
  
  #---------------------------------------------
  # * Use_Base_Parameters
  # > true or false setting
  # > if true, then base parameters are displayed as feedback
  # > if false, then actor parameters including any and all added parameters
  # such as state buffs or equipment bonuses are included and displayed 
  # as feedback.
  # > 'parameters' are things like hp, mp, attack, etc.
  #---------------------------------------------
  Use_Base_Parameters = true
  
  #---------------------------------------------
  # * Sound setting for Leveling up
  # > The sound is played when a Levelup feedback window animates on-screen
  # to display a message.
  # > Settings for Filename (sound must be in SE folder), Volume and
  # Pitch. Out of range or invalid settings may cause problems.
  # > Setting for enabling/disabling sound playback. Default = false,
  # supported values: true/false.
  # Volume range: 0 to 100
  # Pitch range: 50 to 150 (100 = normal)
  #---------------------------------------------
  LVLSound_Filename = "060-Cheer01"
  LVLSound_Volume = 80
  LVLSound_Pitch = 100
  Disable_LVLSound = false
  
  #---------------------------------------------
  # * Skill Gain Vocab Constants
  # > The strings used when displaying a feedback msg to the player
  # about gaining new skills on levelup.
  # > Depending on the GAINED_SKILL_MSGTYPE setting, one of these may
  # be empty.
  # > Long strings could result in squishy text!
  #---------------------------------------------
  VOCAB_GAINED_SKILL = "learned the skill"
  VOCAB_GAINED_SKILL_EXT = ""
  
  #---------------------------------------------
  # * GAINED_SKILL_MSGTYPE
  # > Has 4 different settings (0-3)
  # > Determines the structure of the "skill gained" message that is
  # to be displayed on levelup when a new skill is gained.
  # 0 - " {ACTOR_NAME} VOCAB_GAINED_SKILL {SKILL_NAME} "
  # 1 - " {SKILL_NAME} VOCAB_GAINED_SKILL {ACTOR_NAME} "
  # 2 - " {ACTOR_NAME} VOCAB_GAINED_SKILL {SKILL_NAME} VOCAB_GAINED_SKILL_EXT "
  # 3 - " VOCAB_GAINED_SKILL {SKILL_NAME} VOCAB_GAINED_SKILL_EXT {ACTOR_NAME} "
  #---------------------------------------------
  GAINED_SKILL_MSGTYPE = 0
  
  #---------------------------------------------
  # * Other GAINED SKILL MSG settings
  # > These settings only affect the 'learned skill' Messages.
  # > Bold = true or false setting.
  # > Color settings must be or point to color objects.
  #---------------------------------------------
  GAINED_SKILL_MSG_Bold = false
  GAINED_SKILL_MSG_Color = Color.new(255, 255, 255, 255)
  GAINED_SKILL_MSG_Outline_Color = Color.new(8, 8, 8, 216) 
  
  #---------------------------------------------
  # * Level Up Vocab Constant
  # > The string used when displaying a feedback msg to the player
  # about leveling up.
  #---------------------------------------------
  VOCAB_LEVEL_UP = "has gained a Level!"
  
  #---------------------------------------------
  # *LEVEL_UP_MSGTYPE
  # > Has 2 settings
  # > Determines the structure of the "level up" message that is to
  # be displayed on levelup.
  # 0 - "{ACTOR_NAME} VOCAB_LEVEL_UP"
  # 1 - "VOCAB_LEVEL_UP {ACTOR_NAME}"
  #---------------------------------------------
  LEVEL_UP_MSGTYPE = 0
  
  #---------------------------------------------
  # * Other Level up MSG settings
  # > These settings only affect the Level UP Message at the top of
  # the Window.
  # > Bold = true or false setting
  # > Color settings must be or point to color objects
  #---------------------------------------------
  Level_UP_MSG_Bold = true
  Level_UP_MSG_Color = Color.new(255, 255, 255, 255)
  Level_UP_MSG_Outline_Color = Color.new(0, 116, 0, 232)
  
  #---------------------------------------------
  # * VOCAB_STAT_CHANGE_SYMBOL
  # > The 'symbol' used (stored as a string) to separate old and
  # new status values, to show the changes from Leveling.
  #---------------------------------------------
  VOCAB_STAT_CHANGE_SYMBOL = "->"
  
  #---------------------------------------------
  # * VOCAB STATS SETTINGS
  # > Different Vocabs to use for HP, MP, etc.
  # > Also includes vocab settings for 'stats' and 'base stats'.
  # > If you want any of these to be empty, set them to ""
  #---------------------------------------------
  VOCAB_BASESTATS = "Base Stats:"
  VOCAB_STATS = "Stats:"
  VOCAB_LEVEL = "Level"
  VOCAB_HP = "HP"
  VOCAB_MP = "MP"
  VOCAB_ATK = "Attack"
  VOCAB_DEF = "Defense"
  VOCAB_MAT = "Mag-ATK"
  VOCAB_MDF = "Mag-DEF"
  VOCAB_AGI = "Agility"
  VOCAB_LUK = "Luck"
  
  #---------------------------------------------
  # * Bold_Stat_Feedback
  # > true or false setting. Other settings will break things.
  # > If true, bolds the text displaying old/new status changes.
  #---------------------------------------------
  Bold_Stat_Feedback = true
  
  #---------------------------------------------
  #            ==[Stats Feedback Color Settings]==
  #
  # * Enable_Feedback_Colors
  # > true or false values only please. 
  # > if true, will use the below color settings when applicable.
  # > if false, all feedback color settings will be ignored.
  #--------------------
  # * Stat_Feedback_UP_Color
  # > The color that is used to signfiy a stat increasing on level up.
  # > If a stat increases on level up, it is drawn with this color. If
  # a stat doesn't increase, it remains normal.
  #--------------------
  # * Stat_Feedback_UP_Outline_Color
  # > The outline color for when a stat increases on level up.
  #--------------------
  # * Enable_Stat_Feedback_Outline
  # > true or false values only, other values will break things.
  # > if true, the outline color will be used.
  # > if false, the outline color will not be used.
  #---------------------------------------------
  Enable_Feedback_Colors = true
  Stat_Feedback_UP_Color = Color.new(32, 255, 32, 216)
  Stat_Feedback_UP_Outline_Color = Color.new(0, 64, 0, 164)
  Enable_Stat_Feedback_Outline = true
  
  #---------------------------------------------
  # * Graphic_Display_Setting
  # > 0 - disabled, no character based graphics drawing
  # > 1 - draw character face
  # > 2 - draw character graphic
  #-----------------------
  # * X/Y Settings
  # > These are X/Y position settings for the character face and
  # graphics if they are used.
  #---------------------------------------------
  Graphic_Display_Setting = 1
  Face_X_Position = 0
  Face_Y_Position = 30
  Character_X_Position = 16
  Character_Y_Position = 128
  
  #---------------------------------------------
  # * Wait_For_OK
  # > true or false setting. Other settings will break things.
  # > If true, the player must press the OK button in order for the
  # LevelUP Feedback Window to animate off screen and close.
  # > If false, the LevelUP Feedback Window will animate off screen
  # after the set time has passed (Window_Levelup_Disp_Timer).
  #--------------------------
  # * Wait_For_OK_Buffer
  # > FRAME based value. 60 frames = 1 second on average.
  # > The buffer time, how long to wait after the window finishes animating
  # onto the screen before accepting 'OK' input from the player?
  # > Default value: 45
  #---------------------------------------------
  Wait_For_OK = true
  Wait_For_OK_Buffer = 360
  
  #---------------------------------------------
  # * Level Up Feedback Window Timer
  # > Value in SECONDS (value * 60 = frames) (3 seconds = 180 frames)
  # > Only used if Wait_For_OK is set to false.
  # Suggested Value: 5
  #---------------------------------------------
  Window_Levelup_Disp_Timer = 5
  
  #---------------------------------------------
  # * Feedback Window Animation Settings
  #----------------------
  # * Window_Anim_Distance: The distance off the screen that the feedback
  # window will reside when not in use, also the distance that the window
  # will animate to and from.
  #   > Value in Pixels
  #   > Suggested Value: 700
  #----------------------
  # * Window_Anim_Speed: The amount of time in FRAMES that the feedback
  # window will take to complete each animation.
  #   > Should be a low value, animations ran from Scene_Map tend to cause
  # some lag for the player. Higher values = more frames to complete the
  # animations.
  #   > Suggested Value: 5
  #---------------------------------------------
  Window_Anim_Distance = 700
  Window_Anim_Speed = 5
  
  #---------------------------------------------
  # * Feedback Window Opacity Settings
  #  > Value ranges: 0 - 255
  # * Window_Opacity - Opacity of the Window (border)
  # * Window_Back_Opacity - Opacity of the Window Background
  # * Window_Contents_Opacity - Opacity of the Contents (messages)
  #---------------------------------------------
  Window_Opacity = 192
  Window_Back_Opacity = 200
  Window_Contents_Opacity = 208
  
  #---------------------------------------------
  # * Window X and Y 'base' positions
  # > The base starting position on screen for the levelUP feedback window
  # > Also treated as the display position of the window for the player
  # > This should be in a visible position unless you're one of the odd ones.
  #---------------------------------------------
  Window_Base_X = 0
  Window_Base_Y = Graphics.height / 4
  
  #---------------------------------------------
  # * Advanced Window Settings
  # > Here are settings for other core things of the window
  # > You shouldn't need to change any of these and probably shouldn't play
  # with these. You should only change these settings if you have a reason.
  #---------------------------------------------
  Window_Z = 200
  Window_Width = Graphics.width
  Window_Height = 160
end




#================================================================================
# ***DO NOT EDIT ANYTHING BELOW THIS LINE UNLESS YOU KNOW WHAT YOU'RE DOING!***
#================================================================================


#--------------------------------------------------
# * Added & Modified Attribute Readers & Accessors
#--------------------------------------------------
class Game_Actor < Game_Battler
  attr_accessor   :level
end


#======================================
# * Levelup System Data+Methods
#======================================
module LevelUP
  PENDING_MESSAGES = {}
  PENDING_MESSAGES_EXTRA = {}
  def self.waiting_msg?
    if PENDING_MESSAGES.empty? == true
      return false
    else
      return true
    end
  end
  # has logic for adding new skill messages to any currently existing message
  # hash values.
  def self.save_msg(msgarray, key)
    return if msgarray == nil
    if PENDING_MESSAGES.include?(key)
      curvals = PENDING_MESSAGES[key]
      lvl = curvals[0]
      skills = curvals[1]
      newskills = msgarray[1]
      index = 0
      if newskills.size > 1
        for i in 0...newskills
          skills << newskills[index]; index += 1
        end
      elsif newskills.size == 1
        skills << newskills[0]
      end
      newmsg = [lvl, skills]
      PENDING_MESSAGES[key] = newmsg
    else
      PENDING_MESSAGES[key] = msgarray
    end
  end
  def self.save_extra_data(array, key)
    return if array == nil
    return if PENDING_MESSAGES_EXTRA.include?(key)
    PENDING_MESSAGES_EXTRA[key] = array
  end
  def self.fetch_extra_data
    keys = []; lkey = []
    keys = PENDING_MESSAGES_EXTRA.keys
    lkey << keys.shift
    lastkey = lkey[0]
    ret = PENDING_MESSAGES_EXTRA[lastkey]
    PENDING_MESSAGES_EXTRA.delete(lastkey)
    return ret
  end
  def self.fetch_waiting_msg
    keys = []; lkey = []
    keys = PENDING_MESSAGES.keys
    lkey << keys.shift
    lastkey = lkey[0]
    retval = PENDING_MESSAGES[lastkey]
    PENDING_MESSAGES.delete(lastkey)
    return retval
  end
end

class Scene_Battle < Scene_Base
  alias r2_update_lvlmsg_jg465yr update
  def update
    r2_update_lvlmsg_jg465yr
    $lvlbackset = false
  end
end


#======================================
# * Scene_Map
# > Aliased Methods: 2
# > Overwritten Methods: 0
# > Added Methods: 6
#======================================
class Scene_Map < Scene_Base
  alias :start_with_lvlupsys_exceptions   :start
  alias :update_scene_check_lvlsys        :update_scene
  def start
    start_with_lvlupsys_exceptions
    @lvlup_timer = LevelUP::Window_Levelup_Disp_Timer * 60
    @anim_timer = LevelUP::Window_Anim_Speed
    @anim_distance = LevelUP::Window_Anim_Distance
    create_lvlsys_windows
    @drawing_lvlmsg = false
    @lvlup_window_ticker = 0
  end
  def update_scene
    if $lvlbackset == false
      $lvlback = false
    else
      $lvlback = true
    end
    if LevelUP::Scene_Map_Update_Priority == 1
      draw_lvlmsg if @drawing_lvlmsg == true 
      check_for_lvlsys_msg unless scene_changing? || $game_message.busy? || @drawing_lvlmsg == true
      update_scene_check_lvlsys
    else
      update_scene_check_lvlsys
      draw_lvlmsg if @drawing_lvlmsg == true 
      check_for_lvlsys_msg unless scene_changing? || $game_message.busy? || @drawing_lvlmsg == true
    end
  end
  def drawing_lvlmsg?
    return @drawing_lvlmsg
  end
  def draw_lvlmsg
    return unless @drawing_lvlmsg == true
    return if $game_message.busy? || scene_changing?
    if @lvlup_window_ticker == 0
      animate_lvlsys_window(1)
      @lvlup_window_ticker = 1
    end  
    if Input.repeat?(:C) || LevelUP::Wait_For_OK == true && @lvlup_window_ticker >= LevelUP::Wait_For_OK_Buffer
      animate_lvlsys_window(2)
      @lvlup_window_ticker = 0
      @drawing_lvlmsg = false
      return
    end
    @lvlup_window_ticker += 1 if LevelUP::Wait_For_OK == true
    return if LevelUP::Wait_For_OK == true
    case @lvlup_window_ticker
    when 1..@lvlup_timer
      @lvlup_window_ticker += 1
    end
    if @lvlup_window_ticker >= @lvlup_timer
      animate_lvlsys_window(2)
      @lvlup_window_ticker = 0
      @drawing_lvlmsg = false
    end
  end
  def create_lvlsys_windows
    x = LevelUP::Window_Base_X
    y = LevelUP::Window_Base_Y
    @lvlsys_feedback_window = Window_LevelMSG_Feedback.new(x, y)
    @lvlsys_feedback_window.opacity = LevelUP::Window_Opacity
    @lvlsys_feedback_window.back_opacity = LevelUP::Window_Back_Opacity
    @lvlsys_feedback_window.contents_opacity = LevelUP::Window_Contents_Opacity
    @lvlsys_feedback_window.close
    @lvlsys_feedback_window.hide
    @lvlsys_feedback_window.y += @anim_distance
    @lvlsys_feedback_window.z = LevelUP::Window_Z
  end
  def check_for_lvlsys_msg
    return unless LevelUP.waiting_msg? == true
    @lvlsys_feedback_window.refresh_lvlmsg(true) if @drawing_lvlmsg == false
    @drawing_lvlmsg = true
    if $lvlback == false
      @drawing_lvlmsg = false
      $lvlbackset = true
    end  
    draw_lvlmsg if @drawing_lvlmsg == true
  end
  def animate_lvlsys_window(n=0)
    return if n == 0
    anim = @anim_timer
    if n == 1 #animate feedback window onto screen
      gumps_lvlsys_playsound(1) unless LevelUP::Disable_LVLSound == true #play sound effect
      @lvlsys_feedback_window.open
      @lvlsys_feedback_window.show
      while anim > 0
        Graphics.wait(1)
        @lvlsys_feedback_window.y -= @anim_distance / @anim_timer
        anim -= 1
      end
    end
    if n == 2 #animate feedback window off screen
      while anim > 0
        Graphics.wait(1)
        @lvlsys_feedback_window.y += @anim_distance / @anim_timer
        anim -= 1
      end
      @lvlsys_feedback_window.close
      @lvlsys_feedback_window.hide
    end
  end
  def gumps_lvlsys_playsound(n=nil)
    return unless n == 1
    Audio.se_stop
    file = LevelUP::LVLSound_Filename
    volume = LevelUP::LVLSound_Volume
    pitch = LevelUP::LVLSound_Pitch
    Audio.se_play('Audio/SE/' + file, volume, pitch)
    return
  end
end


#======================================
# * Game_Actor
# > Aliased Methods: 1
# > Overwritten Methods: 1
# > Added Methods: 3
#======================================
class Game_Actor < Game_Battler
  def save_old_stats
    if LevelUP::Use_Base_Parameters == false
      oldstat_ary = [actor.id, self.level, self.mhp, self.mmp, self.atk, self.def, self.mat, self.mdf, self.agi, self.luk]
      @oldstat_ary = oldstat_ary.dup
    else
      oldstat_ary = [actor.id, self.level, self.param_base(0), self.param_base(1), self.param_base(2), self.param_base(3), self.param_base(4), self.param_base(5), self.param_base(6), self.param_base(7)]
      @oldstat_ary = oldstat_ary.dup
    end
  end
  
  alias :change_exp_check_lvlupsys_exceptions   :change_exp
  def change_exp(exp, show)
    @lastlvl = @level
    @exp[@class_id] = [exp, 0].max
    save_old_stats if self.exp >= next_level_exp
    change_exp_check_lvlupsys_exceptions(exp, show)
  end
  
  def display_level_up(new_skills)
    skillmsgs = []; lvlmsg = []
    skillmsgs = compile_skill_msg_list(new_skills)
    lvlmsg = compile_lvl_msg
    sender = [lvlmsg, skillmsgs]
    key = actor.id
    LevelUP.save_msg(sender, key)
    LevelUP.save_extra_data(@oldstat_ary, key)
  end
  
  def compile_skill_msg_list(new_skills)
    msgary = []
    vocab1 = LevelUP::VOCAB_GAINED_SKILL
    vocab2 = LevelUP::VOCAB_GAINED_SKILL_EXT
    msgt = LevelUP::GAINED_SKILL_MSGTYPE
    new_skills.each do |skill|
      msgary << "#{@name} #{vocab1} #{skill.name}" if msgt == 0
      msgary << "#{skill.name} #{vocab1} #{@name}" if msgt == 1
      msgary << "#{@name} #{vocab1} #{skill.name} #{vocab2}" if msgt == 2
      msgary << "#{vocab1} #{skill.name} #{vocab2} #{@name}" if msgt == 3
    end
    return msgary
  end
  
  def compile_lvl_msg
    retval = []
    vocab1 = LevelUP::VOCAB_LEVEL_UP
    msgt = LevelUP::LEVEL_UP_MSGTYPE
    retval << "#{@name} #{vocab1}" if msgt == 0
    retval << "#{vocab1} #{@name}" if msgt == 1
    return retval
  end
  
end


#======================================
# * Feedback window for scene map
#======================================
class Window_LevelMSG_Feedback < Window_Base
  def initialize(x, y)
    width = LevelUP::Window_Width
    height = LevelUP::Window_Height
    @lvlarray = []; @skillsarray = []; @oldstats = []; @actor = nil
    super(x, y, width, height)
    draw_msg
  end
  def reboot_font
    deftxt = Color.new(255, 255, 255, 255); deftxtout = Color.new(0, 0, 0, 128)
    self.contents.font.bold = false
    self.contents.font.size = 24
    self.contents.font.color = deftxt
    self.contents.font.out_color = deftxtout
    return
  end
  def draw_msg
    return if @lvlarray.size == 0
    draw_graphics if LevelUP::Graphic_Display_Setting != 0
    x = 0; norm = 24; sm = 16; txtwidth = Graphics.width / 2 + 48; sklineh = line_height*3
    index = 0; lm = @lvlarray[0]
    lvlmsg = lm[0]; lvlmsg.to_s
    self.contents.font.bold = LevelUP::Level_UP_MSG_Bold
    self.contents.font.color = LevelUP::Level_UP_MSG_Color
    self.contents.font.out_color = LevelUP::Level_UP_MSG_Outline_Color
    draw_text(x, 0, txtwidth, line_height, lvlmsg, 0)
    reboot_font
    self.contents.font.size = sm
    self.contents.font.bold = LevelUP::GAINED_SKILL_MSG_Bold
    self.contents.font.color = LevelUP::GAINED_SKILL_MSG_Color
    self.contents.font.out_color = LevelUP::GAINED_SKILL_MSG_Outline_Color
    sklineh -= line_height if @skillsarray.size > 9
    for i in 0...@skillsarray.size
      mg = @skillsarray[index]
      msg = mg; msg.to_s
      draw_text(100, 0, txtwidth, sklineh, "#{msg}", 0)
      sklineh += line_height
      index += 1
    end
    reboot_font
    draw_msg_2 unless @oldstats == nil
  end
  def draw_graphics
    return if @actor == nil
    ax = LevelUP::Face_X_Position; ay = LevelUP::Face_Y_Position
    bx = LevelUP::Character_X_Position; by = LevelUP::Character_Y_Position
    if LevelUP::Graphic_Display_Setting == 1
      draw_actor_face(@actor, ax, ay)
    elsif LevelUP::Graphic_Display_Setting == 2
      draw_actor_graphic(@actor, bx, by)
    end
  end
  def draw_msg_2
    x = Graphics.width / 2 + 48
    symbx = x + 114
    oldx = symbx - 44
    txtwidth = Graphics.width / 2 - 112
    txtwidth2 = 80; txtwidth3 = 32
    lh = line_height
    deftxt = Color.new(255, 255, 255, 255); deftxtout = Color.new(0, 0, 0, 128)
    symb = LevelUP::VOCAB_STAT_CHANGE_SYMBOL; v_lvl = LevelUP::VOCAB_LEVEL
    v_hp = LevelUP::VOCAB_HP; v_mp = LevelUP::VOCAB_MP; v_atk = LevelUP::VOCAB_ATK
    v_def = LevelUP::VOCAB_DEF; v_mat = LevelUP::VOCAB_MAT; v_mdf = LevelUP::VOCAB_MDF
    v_agi = LevelUP::VOCAB_AGI; v_luk = LevelUP::VOCAB_LUK; base_stats_vc = LevelUP::VOCAB_BASESTATS; stats_vc = LevelUP::VOCAB_STATS 
    self.contents.font.size = 16
    self.contents.font.bold = LevelUP::Bold_Stat_Feedback
    draw_text(x, 0, txtwidth, lh, "#{base_stats_vc}", 0) if LevelUP::Use_Base_Parameters == true
    draw_text(x, 0, txtwidth, lh, "#{stats_vc}", 0) if LevelUP::Use_Base_Parameters == false
    draw_text(x, 0, txtwidth, lh*2, "#{v_lvl}", 0) 
    draw_text(x, 0, txtwidth, lh*3, "#{v_hp}", 0)
    draw_text(x, 0, txtwidth, lh*4, "#{v_mp}", 0)
    draw_text(x, 0, txtwidth, lh*5, "#{v_atk}", 0) 
    draw_text(x, 0, txtwidth, lh*6, "#{v_def}", 0) 
    draw_text(x, 0, txtwidth, lh*7, "#{v_mat}", 0) 
    draw_text(x, 0, txtwidth, lh*8, "#{v_mdf}", 0) 
    draw_text(x, 0, txtwidth, lh*9, "#{v_agi}", 0) 
    draw_text(x, 0, txtwidth, lh*10, "#{v_luk}", 0)
    draw_text(oldx, 0, txtwidth3, lh*2, "#{@oldstats[1]}", 0)
    draw_text(oldx, 0, txtwidth3, lh*3, "#{@oldstats[2]}", 0)
    draw_text(oldx, 0, txtwidth3, lh*4, "#{@oldstats[3]}", 0)
    draw_text(oldx, 0, txtwidth3, lh*5, "#{@oldstats[4]}", 0)
    draw_text(oldx, 0, txtwidth3, lh*6, "#{@oldstats[5]}", 0)
    draw_text(oldx, 0, txtwidth3, lh*7, "#{@oldstats[6]}", 0)
    draw_text(oldx, 0, txtwidth3, lh*8, "#{@oldstats[7]}", 0)
    draw_text(oldx, 0, txtwidth3, lh*9, "#{@oldstats[8]}", 0)
    draw_text(oldx, 0, txtwidth3, lh*10, "#{@oldstats[9]}", 0)
    color_for_increase(1)
    draw_text(symbx, 0, txtwidth2, lh*2, "#{symb} #{@newstats[1]}", 0)
    color_for_increase(2)
    draw_text(symbx, 0, txtwidth2, lh*3, "#{symb} #{@newstats[2]}", 0)
    color_for_increase(3)
    draw_text(symbx, 0, txtwidth2, lh*4, "#{symb} #{@newstats[3]}", 0)
    color_for_increase(4)
    draw_text(symbx, 0, txtwidth2, lh*5, "#{symb} #{@newstats[4]}", 0)
    color_for_increase(5)
    draw_text(symbx, 0, txtwidth2, lh*6, "#{symb} #{@newstats[5]}", 0)
    color_for_increase(6)
    draw_text(symbx, 0, txtwidth2, lh*7, "#{symb} #{@newstats[6]}", 0)
    color_for_increase(7)
    draw_text(symbx, 0, txtwidth2, lh*8, "#{symb} #{@newstats[7]}", 0)
    color_for_increase(8)
    draw_text(symbx, 0, txtwidth2, lh*9, "#{symb} #{@newstats[8]}", 0)
    color_for_increase(9)
    draw_text(symbx, 0, txtwidth2, lh*10, "#{symb} #{@newstats[9]}", 0)
    self.contents.font.bold = false
    self.contents.font.color = deftxt
    self.contents.font.out_color = deftxtout
    self.contents.font.size = 24
  end
  def color_for_increase(index)
    return if LevelUP::Enable_Feedback_Colors == false
    deftxt = Color.new(255, 255, 255, 255); deftxtout = Color.new(0, 0, 0, 128)
    upcolor = LevelUP::Stat_Feedback_UP_Color
    outcolor = LevelUP::Stat_Feedback_UP_Outline_Color
    flag = LevelUP::Enable_Stat_Feedback_Outline
    old = @oldstats[index]; new = @newstats[index]
    if new > old
      self.contents.font.color = upcolor
      self.contents.font.out_color = outcolor unless flag == false
    else
      self.contents.font.color = deftxt
      self.contents.font.out_color = deftxtout
    end
    return
  end
  def refresh_lvlmsg(call=false)
    return unless call == true
    grabby = []; lvlmsg = []; skillmsgs = []; smg = []; index = 0
    return unless LevelUP.waiting_msg? == true
    grabby = LevelUP.fetch_waiting_msg
    lvlmsg = grabby.shift
    smg << grabby.pop until grabby.size == 0
    skillmsgs = smg[0]
    @lvlarray.clear
    @lvlarray << lvlmsg
    @skillsarray.clear
    for i in 0...skillmsgs.size
      @skillsarray << skillmsgs[index]
      index += 1
    end
    @oldstats = LevelUP.fetch_extra_data
    return if @oldstats == nil
    id = @oldstats[0]
    @actor = $game_actors[id]
    if LevelUP::Use_Base_Parameters == false
      @newstats = [id, @actor.level, @actor.mhp, @actor.mmp, @actor.atk, @actor.def, @actor.mat, @actor.mdf, @actor.agi, @actor.luk]
    else
      @newstats = [id, @actor.level, @actor.param_base(0), @actor.param_base(1), @actor.param_base(2), @actor.param_base(3), @actor.param_base(4), @actor.param_base(5), @actor.param_base(6), @actor.param_base(7)]
    end
    contents.clear
    draw_msg
  end
end