=begin
Neil's Boot-Out Skill Type v 1.0
DESCRIPTION:
Removes Visibility of the SKill list of the specified skill type
during battle. Built originally to hide Passive Skills

Skill Type 3 is labeled as "Passive" by DEFAULT
So that skills under this tree and the skill list itself are not listed during
battle, this script identifies which skill type id (stype_id) to remove
using the array KICK and keeps skills under the skill type
out of the selectable skills in the Skill menus in battle. The skill menu is
still visible from the Map Menu.

Ask me and forums for help, and we'll see how we can help.

Script by: California Macky a.k.a. Neil

Instructions:
>Insert script above Main and below all other scripts altering skill order
and Battle Menu mods.
=end

module BOOTOUT
  #Variable for Skill Type ID to be blocked e.g. [3, 2, 1]
  KICK = [9]
  
  #This option allows whether or not the default ATTACK command is shown.
  #PERSONAL USE.
  REMOVE_ATTACK = false
  
end

class Window_ActorCommand < Window_Command
  
  include BOOTOUT
  #--------------------------------------------------------------------------
  # * Actor Command List
  #--------------------------------------------------------------------------
  def make_command_list
    return unless @actor
    if !(BOOTOUT::REMOVE_ATTACK)
      add_attack_command
    end
    add_skill_commands
    add_guard_command
    add_item_command
  end
  
  #--------------------------------------------------------------------------
  # * Add Skill Command to List
  #--------------------------------------------------------------------------
  def add_skill_commands
      @actor.added_skill_types.sort.each do |stype_id|
          next if KICK.include?(stype_id)
          name = $data_system.skill_types[stype_id]
          add_command(name, :skill, true, stype_id)
      end
  end
  
end