#----------------------------------------------------------------------------
# EXP gauges by Rbahamut
#----------------------------------------------------------------------------
# v1.4
#----------------------------------------------------------------------------
# Changes in 1.4 - EXP Gauges now work properly passed level 2! (There was a
# problem with the gauge not filling all the way past level 2)
# Changes in v1.3 - Adjusted ui to fit gauges properly in "Skills" window and
# other variations of the same window such as YEA Class changing window, etc
# Changes in v1.2 - Added another customizing capability of changing the
#                    gauge back color when empty!
# Changes in v1.1 - No more exp clearing on leveling!
#----------------------------------------------------------------------------
# RGSS3 only Plug n Play
#----------------------------------------------------------------------------
#*This script will add exp gauges to both the menu status and status windows
#----------------------------------------------------------------------------
# Edit below at own risk!
#----------------------------------------------------------------------------


class Window_Base < Window
  #--------------------------------------------------------------------------
  # * Get Text Colors
  #--------------------------------------------------------------------------

  def exp_gauge_color1;      text_color(11);  end;  # EXP gauge added lower half
  def exp_gauge_color2;      text_color(3);   end;  # EXP gauge added upper half
  def exp_gauge_back_color;  text_color(19);  end;  # EXP Gauge background

  #--------------------------------------------------------------------------
  # * Draw exp Gauge
  #     rate   : Rate (full at 1.0)
  #     color1 : Left side gradation
  #     color2 : Right side gradation
  #--------------------------------------------------------------------------
  def draw_expgauge(x, y, width, rate, color1, color2)
    fill_w = (width * rate).to_i
    gauge_y = y + line_height - 8
    contents.fill_rect(x, gauge_y, width, 6, exp_gauge_back_color)
    contents.gradient_fill_rect(x, gauge_y, fill_w, 6, color1, color2)
  end
  #--------------------------------------------------------------------------
  # * Draw EXP  This is the exp info to be drawn on the "menu" status
  #--------------------------------------------------------------------------
  def draw_exp(actor, x, y, width = 124)
        s1 = actor.max_level? ? "---------" : actor.exp
        s2 = actor.max_level? ? "0" : actor.next_level_exp - actor.exp
        if actor.max_level? ?
          draw_expgauge(x, y, width, 1, exp_gauge_color1, exp_gauge_color2) :
          draw_gauge(x, y,width,((((actor.exp - actor.current_level_exp).to_f/100) / ((actor.next_level_exp.to_f - actor.current_level_exp.to_f)/100))),  
          exp_gauge_color1, exp_gauge_color2)
        end
        change_color(system_color)
        draw_text(x, y, 30, line_height, "EXP")
        change_color(normal_color)
        if actor.max_level? ?
          draw_text(x + width - 72, y, 72, line_height, "------------", 2) :
          draw_text(x + width - 72, y, 72, line_height, actor.next_level_exp.to_i - actor.exp.to_i, 2)
        end
  end
  #--------------------------------------------------------------------------
  # * Draw Simple Status
  #--------------------------------------------------------------------------
  def draw_actor_simple_status(actor, x, y)
        draw_actor_name(actor, x, y + line_height *  -0.3)
        draw_actor_level(actor, x, y + line_height * 0.7)
        draw_actor_icons(actor, x, y + line_height * 1.7)
        draw_actor_class(actor, x + 120, y + line_height * -0.3)
        draw_actor_hp(actor, x + 120, y + line_height * 0.7)
        draw_actor_mp(actor, x + 120, y + line_height * 1.7)
        draw_exp(actor, x + 120, y + line_height * 2.7) #<== This line adds the exp gauge to "menu" status
  end
end

class Window_Status < Window_Selectable
  #--------------------------------------------------------------------------
  # * Draw  New Experience Information This is the exp info to be drawn in the "status" window
  #--------------------------------------------------------------------------
  def draw_exp_info(x, y)
        s1 = @actor.max_level? ? "-------" : @actor.exp
        s2 = @actor.max_level? ? "0" : @actor.next_level_exp - @actor.exp
        if @actor.max_level? ?
          draw_gauge(x, y + line_height * 3, 130, 1, exp_gauge_color1, exp_gauge_color2) :
          draw_gauge(x, y + line_height * 3, 130,((((@actor.exp - @actor.current_level_exp).to_f/100) / ((@actor.next_level_exp.to_f - @actor.current_level_exp.to_f)/100))),
          exp_gauge_color1, exp_gauge_color2)
        end
        s_next = sprintf(Vocab::ExpNext, Vocab::level)
        change_color(system_color)
        draw_text(x, y + line_height * 3, 30, line_height, "EXP")
        draw_text(x, y + line_height * 2, 180, line_height, s_next)
        draw_text(255, y + line_height * 3, 180, line_height, s2, 2)
        change_color(normal_color)
        if @actor.max_level? ?
          draw_text(x + width - 72, y, 72, line_height, "------------", 2) :
          draw_text(x + width - 72, y, 72, line_height, @actor.next_level_exp.to_i - @actor.exp.to_i, 2)
        end
  end
end