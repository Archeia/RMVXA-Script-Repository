#==============================================================================
# ■ Nio Kasgami Engine Ace "Blur Killer"
# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# Kill those dayum Blur in the Menu!
# Created by Nio Kasgami.
# Data : 2015/09/3
# Version : 1.0.0
# Credit : nio Kasgami
#==============================================================================
module Nio 
module Blur_Killer System ={ 
#true = no blur 
# false = blur 
:kill_blur => true, 
# true = darken the screen 
# no darken the screen 
:enable_color_set => false } 
end
end
module SceneManager 
#-------------------------------------------------------------------------- 
# * Create Snapshot to Use as Background 
#-------------------------------------------------------------------------- 
def self.snapshot_for_background 
@background_bitmap.dispose if @background_bitmap 
@background_bitmap = Graphics.snap_to_bitmap 
if !Nio::Blur_Killer::System[:kill_blur] 
@background_bitmap.blur 
end 
end
end
class Scene_MenuBase < Scene_Base 
def create_background 
@background_sprite = Sprite.new 
@background_sprite.bitmap = SceneManager.background_bitmap 
if Nio::Blur_Killer::System[:enable_color_set] 
@background_sprite.color.set(16, 16, 16, 128) 
end 
end
end
#Paste this one Below ALL YOUR SCRIPT but above main