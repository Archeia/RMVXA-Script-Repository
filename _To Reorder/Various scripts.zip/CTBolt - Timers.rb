#==============================================================================
# Title:  CT_Bolt's Timer
# Author: CT_Bolt
# Date:   March 03, 2013
# Version History:
#  v1.00 (02-28-2013)
#   -- First release
#  v1.02 (03-01-2013)
#   -- Bug Fix & More Comments
#  v2.0 (03-01-2013)
#   --Major Update
#    -- Changed from a Timer Add-on to it's own timer
#  v2.1 (03-03-2013)
#   --Added Features
#    -- Optional prefix & suffix can now be added
#    -- Multiple buttons can now be assigned for pressing
#  v2.2 (03-03-2013)
#   --Added more features
#    -- Add or remove time from a currently running CT_Timer
#    -- Pause & resume a currently running CT_Timer
#  v2.21 (03-08-2013)
#   --Bugfix - Save/Load wasn't working
#  v2.5  (07-21-2013)
#   -- Added features
#    --Audio was added
#     -- Ability to fade in
#------------------------------------------------------------------------------
# Description:
#  A whole new timer.
#  Custom properties (font color, font size, x, y, z, etc.)
#  Let's you press multiple buttons while a ct_timer is active.
#  Counts the button presses & stores them in a variable.
#  Allows a switch to be used to determine if the ct_timer will be visible.
#  Add\Remove time from a currently running CT_Timer with a simple script call.
#  Pause\Resume a currently running CT_Timer with a simple script call.
#------------------------------------------------------------------------------
# Compatibility:
#   This should be compatible with all scripts as long as they
#   don't overwrite any methods used in this script.
#
# Alias Methods:
#  module DataManager
#    create_game_objects
#    make_save_contents
#    extract_save_contents(contents)
#
#  class Spriteset_Map
#    initialize
#    dispose
#    update
#
#  class Spriteset_Battle
#    initialize
#    dispose
#    update
#
#  class Scene_Map < Scene_Base
#    update
#
#  class Scene_Battle < Scene_Base
#    def update
#    def update_basic
#
#------------------------------------------------------------------------------
# Usage:
# In a script call use the following method to start/stop a ct_timer:
#   ct_timer(mins, secs, start)
#
#   Examples:
#     ct_timer(1, 30)       # Starts a timer at 1 min 30 seconds
#     ct_timer(0, 80)       # Starts a timer at 1 min 20 seconds
#     ct_timer(2)           # Starts a timer at 2 mins
#     ct_timer(0, 0, false) # Stops the timer
#
#   In a script call you can also use the following:
#   Examples:
#     $ct_game_timer.add_time (1, 20) # Add 1 minute & 20 seconds
#     $ct_game_timer.lose_time(0, 15) # Subtract 15 seconds
#     $ct_game_timer.pause            # Pause countdown
#     $ct_game_timer.resume           # Resume countdown
#
# Configure module CT_Timer to the way you would like it.
#------------------------------------------------------------------------------
# Installation:
#  To install the script, open the script editor and paste this script on
#  a new section (insert) below the Materials & above Main Process.
#==============================================================================

#==============================================================================
# ** Module CT_Timer
#------------------------------------------------------------------------------
#==============================================================================
module CT_Timer
  STAY_IN_BATTLE_SWITCH_ID  = 1    # Switch used to keep the player in battle
                                   # after the timer expires
                                
  ACCEPT_INPUT_SWITCH_ID    = 2    # Switch used to determine if button input
                                   # will be accepted
                                
  HIDE_TIMER_SWITCH_ID      = 3    # Switch used to determine if the timer will
                                   # be displayed
                                
  PAUSE_IN_BATTLE_SWITCH_ID = 7    # Switch used to determine if the timer will
                                   # update in battle
                                
  WAIT_FOR_TIMER_SWITCH_ID  = 9    # Set true to "pause the battle"
 
  BUTTON_PRESS        = [:Z, :Y]  # Button symbols for what button will be used
                                  # Default valid button symbols:
                                  # :DOWN  = Down Arrow Key
                                  # :LEFT  = Left Arrow Key
                                  # :RIGHT = Right Arrow Key
                                  # :UP    = Up Arrow Key
                                  # :A     = Shift Key
                                  # :B     = X or Esc Key
                                  # :C     = Z or Enter or Space Key
                                  # :X     = A Key
                                  # :Y     = S Key
                                  # :Z     = D Key
                                  # :L     = Q Key
                                  # :R     = W Key
                                  # :SHIFT = Shift Key
                                  # :CTRL  = CTRL Key
                                  # :ALT   = ALT Key
                                  # :F5    = F5 Key
                                  # :F6    = F6 Key
                                  # :F7    = F7 Key
                                  # :F8    = F8 Key
                                  # :F9    = F9 Key
                                
                                  # Note if you never want to use that at all
                                  # set it to nil (BUTTON_PRESS = nil)
 
  BUTTON_COUNT_VAR_ID      = 1    # Variable ID used to keep count of how many
                                  # times the button was pressed
 
  COMMON_EVENT_ID          = 2    # Optional (set to nil if not used):
                                  # Common Event ID that will be called when the
                                  # timer expires
 
  AUTO_UNACCEPT_INPUT      = true # Set true to turn the ACCEPT_INPUT_SWITCH_ID
                                  # switch off when the timer expires
                                
  AUTO_STOP                = true # Set true to turn the ACCEPT_INPUT_SWITCH_ID
                                  # switch off when the timer expires

  DEFAULT_WIDTH            = 96   # Default width  for timer sprite
                                  # (a normal timer is 96)
                                
  DEFAULT_HEIGHT           = 48   # Default height for timer sprite
                                  # (a normal timer is 48)
 
                                  # bottom-middle of screen
                                  # can be changed to anything you want
  DEFAULT_X                = (Graphics.width   - DEFAULT_WIDTH ) / 2
  DEFAULT_Y                = (Graphics.height  - (DEFAULT_HEIGHT * 2)) / 2
 
  class Properties
    attr_accessor :font_color
    attr_accessor :font_out_color
    attr_accessor :font_size
    attr_accessor :font_bold
    attr_accessor :font_italic
    attr_accessor :font_outline
    attr_accessor :font_shadow
    attr_accessor :font_name
    attr_accessor :prefix_text
    attr_accessor :suffix_text
  
    attr_accessor :x
    attr_accessor :y
    attr_accessor :z
  
    def initialize(x = 50, y = 0, z = 200, font_color = [180, 0, 0],
                   font_out_color = [255, 100, 0], font_size = 50,
                   font_bold = true, font_italic = false,
                   font_outline = true, font_shadow = false,
                   font_name = ["Courier New", "Myriad", "Verdana"],
                   prefix_text = "", suffix_text = "")
                
      @font_color     = font_color
      @font_size      = font_size
      @font_bold      = font_bold
      @font_italic    = font_italic
      @font_outline   = font_outline
      @font_shadow    = font_shadow
      @font_name      = font_name
      @font_out_color = font_out_color
      @prefix_text    = prefix_text
      @suffix_text    = suffix_text
      @x = x
      @y = y
      @z = z
    end
  end
end


module DataManager
    class << self
        alias_method(:my_create_game_objects, :create_game_objects)
    alias_method(:my_make_save_contents, :make_save_contents)
    alias_method(:my_extract_save_contents, :extract_save_contents)
    end
 
  def self.create_game_objects
    my_create_game_objects
    $ct_game_timer = CT_Game_Timer.new
  end
 
  def self.make_save_contents
    contents = my_make_save_contents
    contents[:ct_timer] = $ct_game_timer
    contents
  end
 
   def self.extract_save_contents(contents)
     my_extract_save_contents(contents)
     $ct_game_timer = contents[:ct_timer]
   end
end

#==============================================================================
# ** CT_Audio
#------------------------------------------------------------------------------
#  This class handles timers. Instances of this class are referenced by
#  $ct_game_timer.
#==============================================================================
class CT_Audio
  attr_accessor :filename
  attr_accessor :from_start
  attr_accessor :fadein_step
  attr_accessor :start_volume
  attr_accessor :volume
  attr_accessor :end_volume
 
  #--------------------------------------------------------------------------
  # * Object Initialization
  #--------------------------------------------------------------------------
  def initialize(filename = "Field1", start_volume = 100, end_volume = nil, fadein_increase = 5, fadein_step = 20, from_start = false)
    if !filename.downcase.include?("/")
      filename = "Audio/BGM/" + filename
    end
  
    @filename        = filename
    @from_start      = from_start

    @fadein_step     = fadein_step
    @fadein_increase = fadein_increase
  
    @start_volume    = start_volume
    @volume          = @start_volume
    
    if end_volume
      @end_volume    = end_volume
    else
      @end_volume    = @start_volume
    end
  end
end

#==============================================================================
# ** CT_Game_Timer
#------------------------------------------------------------------------------
#  This class handles timers. Instances of this class are referenced by
#  $ct_game_timer.
#==============================================================================
class CT_Game_Timer
  attr_accessor :ct_audio
  attr_accessor :paused
 
  #--------------------------------------------------------------------------
  # * Object Initialization
  #--------------------------------------------------------------------------
  def initialize
    @count         = 0
    @fade_in_count = 20
    @ct_audio      = nil
    @working       = false
    @paused        = false
  end
  
  #--------------------------------------------------------------------------
  # * Frame Update
  #--------------------------------------------------------------------------
  def update
    if !@paused
      if $game_switches[CT_Timer::ACCEPT_INPUT_SWITCH_ID]
        if @working && @count > 0
          if CT_Timer::BUTTON_PRESS
            CT_Timer::BUTTON_PRESS.each do |bp|
              if Input.trigger?(bp)
                $game_variables[CT_Timer::BUTTON_COUNT_VAR_ID]=
                  $game_variables[CT_Timer::BUTTON_COUNT_VAR_ID]+1
              end
            end
          end
        end
      end
    
      if @working && @count > 0
        @count -= 1
        if @ct_audio
          if @ct_audio.volume < @ct_audio.end_volume
            @fade_in_count += 1
            if @fade_in_count >= @ct_audio.fadein_step
              @fade_in_count = 0
              @ct_audio.volume += 5 unless @ct_audio.volume >= @ct_audio.end_volume
              p @ct_audio.volume
            end
          end
          Audio.bgm_play(@ct_audio.filename, @ct_audio.volume)
        end
        on_expire if @count <= 0
      end
    
    end
  end
 
  #--------------------------------------------------------------------------
  # * Start
  #--------------------------------------------------------------------------
  def start(count)
    @count   = count
    @working = true
    @active  = true
    if @ct_audio
      if @ct_audio.from_start
        Audio.bgm_stop
      end
    end
  end
 
  #--------------------------------------------------------------------------
  # * Stop
  #--------------------------------------------------------------------------
  def stop
    if CT_Timer::ACCEPT_INPUT_SWITCH_ID
      $game_switches[CT_Timer::ACCEPT_INPUT_SWITCH_ID] = false
    end
    @working = false
  end
 
  #--------------------------------------------------------------------------
  # * Determine if Working
  #--------------------------------------------------------------------------
  def working?
    @working
  end
 
  def active?
    @active
  end
 
  #--------------------------------------------------------------------------
  # * Get Seconds
  #--------------------------------------------------------------------------
  def sec
    @count / Graphics.frame_rate
  end
 
  #--------------------------------------------------------------------------
  # * Processing When Timer Reaches 0
  #--------------------------------------------------------------------------
  def on_expire
    if $game_switches[CT_Timer::ACCEPT_INPUT_SWITCH_ID]
      puts "Total of buttons presses was " +
           $game_variables[CT_Timer::BUTTON_COUNT_VAR_ID].to_s + " times.\n"
      if CT_Timer::COMMON_EVENT_ID
        $game_temp.reserve_common_event(CT_Timer::COMMON_EVENT_ID)
      end
      if CT_Timer::AUTO_UNACCEPT_INPUT
        $game_switches[CT_Timer::ACCEPT_INPUT_SWITCH_ID] = false
      end
    else
      if CT_Timer::AUTO_STOP
        stop
      end
    end
    @active = false
    BattleManager.abort unless $game_switches[CT_Timer::STAY_IN_BATTLE_SWITCH_ID]
  end
 
  #--------------------------------------------------------------------------
  # * Add more time
  #--------------------------------------------------------------------------
  def add_time(min = 0, sec = 0)
    count = (min * 60) + sec
    @count += count * Graphics.frame_rate
  end

  #--------------------------------------------------------------------------
  # * Subtract more time
  #--------------------------------------------------------------------------
  def lose_time(min = 0, sec = 0)
    count = (min * 60) + sec
    @count = [@count - (count * Graphics.frame_rate), 1].max
  end

  #--------------------------------------------------------------------------
  # * Pause
  #--------------------------------------------------------------------------
  def pause
    @paused = true
  end

  #--------------------------------------------------------------------------
  # * Resume
  #--------------------------------------------------------------------------
  def resume
    @paused = false
  end
 
  #--------------------------------------------------------------------------
  # * Pause
  #--------------------------------------------------------------------------
  def paused?
    @paused
  end
end

#==============================================================================
# ** CT_Sprite_Timer
#------------------------------------------------------------------------------
#  This sprite is for ct_timer displays.
#  It monitors $ct_game_timer and automatically changes sprite states.
#==============================================================================
class CT_Sprite_Timer < Sprite
  #--------------------------------------------------------------------------
  # * Object Initialization
  #--------------------------------------------------------------------------
  def initialize(viewport, x = Graphics.width - CT_Timer::DEFAULT_WIDTH,
                 y = CT_Timer::DEFAULT_HEIGHT)
    super(viewport)
    create_bitmap
    @CT_Timer_Properties =
                CT_Timer::Properties.new(x, y)
    @i = 0
    create_font
    update
  end
 
  #--------------------------------------------------------------------------
  # * Free
  #--------------------------------------------------------------------------
  def dispose
    self.bitmap.dispose
    super
  end
 
  #--------------------------------------------------------------------------
  # * Create Bitmap
  #--------------------------------------------------------------------------
  def create_bitmap
    self.bitmap = Bitmap.new(CT_Timer::DEFAULT_WIDTH, CT_Timer::DEFAULT_HEIGHT)
  end

  #--------------------------------------------------------------------------
  # * Create Font
  #--------------------------------------------------------------------------
  def create_font
    self.bitmap.font.name      = @CT_Timer_Properties.font_name
    self.bitmap.font.outline   = @CT_Timer_Properties.font_outline
    self.bitmap.font.shadow    = @CT_Timer_Properties.font_shadow
    self.bitmap.font.bold      = @CT_Timer_Properties.font_bold
    self.bitmap.font.italic    = @CT_Timer_Properties.font_italic
    self.bitmap.font.size      = @CT_Timer_Properties.font_size
  
    self.bitmap.font.color.set(@CT_Timer_Properties.font_color[0],
                               @CT_Timer_Properties.font_color[1],
                               @CT_Timer_Properties.font_color[2])
                            
    self.bitmap.font.out_color.set(@CT_Timer_Properties.font_out_color[0],
                                   @CT_Timer_Properties.font_out_color[1],
                                   @CT_Timer_Properties.font_out_color[2])
  end
                          
  #--------------------------------------------------------------------------
  # * Frame Update
  #--------------------------------------------------------------------------
  def update
    if CT_Timer::HIDE_TIMER_SWITCH_ID
      if $game_switches[CT_Timer::HIDE_TIMER_SWITCH_ID]
        super
        update_bitmap
        update_position
        update_visibility
      else
        self.visible = false
      end
    else
      super
      update_bitmap
      update_position
      update_visibility
    end
  end

  #--------------------------------------------------------------------------
  # * Update Transfer Origin Bitmap
  #--------------------------------------------------------------------------
  def update_bitmap
    if $ct_game_timer.sec != @total_sec
      @total_sec = $ct_game_timer.sec
      redraw
    end
  end
 
  #--------------------------------------------------------------------------
  # * Redraw
  #--------------------------------------------------------------------------
  def redraw
    self.bitmap.clear
    self.bitmap.draw_text(self.bitmap.rect, timer_text, 1)
  end
 
  #--------------------------------------------------------------------------
  # * Create Text
  #--------------------------------------------------------------------------
  def timer_text
    sprintf(" " + @CT_Timer_Properties.prefix_text +
            "%02d:%02d" + @CT_Timer_Properties.suffix_text,
            @total_sec / 60, @total_sec % 60)
  end
 
  #--------------------------------------------------------------------------
  # * Update Position
  #--------------------------------------------------------------------------
  def update_position
    self.x = @CT_Timer_Properties.x
    self.y = @CT_Timer_Properties.y
    self.z = @CT_Timer_Properties.z
  end
 
  #--------------------------------------------------------------------------
  # * Update Visibility
  #--------------------------------------------------------------------------
  def update_visibility
    self.visible = $ct_game_timer.working?
  end
end

#==============================================================================
# ** Spriteset_Map
#------------------------------------------------------------------------------
# This class brings together map screen sprites, tilemaps, etc. It's used
# within the Scene_Map class.
#==============================================================================
class Spriteset_Map
  #--------------------------------------------------------------------------
  # * Object Initialization
  #--------------------------------------------------------------------------
  alias :my_init :initialize
  def initialize
    create_ct_timer
    my_init
    update
  end

  #--------------------------------------------------------------------------
  # * Free
  #--------------------------------------------------------------------------
  alias :my_dispose :dispose
  def dispose
    my_dispose
    dispose_ct_timer
  end

  #--------------------------------------------------------------------------
  # * Frame Update
  #--------------------------------------------------------------------------
  alias :my_update :update
  def update
    my_update
    update_ct_timer
  end

  #--------------------------------------------------------------------------
  # * Create CT_Timer Sprite
  #--------------------------------------------------------------------------
  def create_ct_timer
    @ct_timer_sprite = CT_Sprite_Timer.new(@viewport2,
                                           CT_Timer::DEFAULT_X,
                                           CT_Timer::DEFAULT_Y)
  end

  #--------------------------------------------------------------------------
  # * Free CT_Timer Sprite
  #--------------------------------------------------------------------------
  def dispose_ct_timer
    @ct_timer_sprite.dispose
  end
 
  #--------------------------------------------------------------------------
  # * Update CT_Timer Sprite
  #--------------------------------------------------------------------------
  def update_ct_timer
    @ct_timer_sprite.update
  end
end

#==============================================================================
# ** Spriteset_Battle
#------------------------------------------------------------------------------
# This class brings together battle screen sprites. It's used within the
# Scene_Battle class.
#==============================================================================
class Spriteset_Battle
  #--------------------------------------------------------------------------
  # * Object Initialization
  #--------------------------------------------------------------------------
  alias :my_init :initialize
  def initialize
    create_ct_timer
    my_init
    update
  end
 
  #--------------------------------------------------------------------------
  # * Free
  #--------------------------------------------------------------------------
  alias :my_dispose :dispose
  def dispose
    my_dispose
    dispose_ct_timer
  end

  #--------------------------------------------------------------------------
  # * Frame Update
  #--------------------------------------------------------------------------
  alias :my_update :update
  def update
    my_update
    update_ct_timer
  end
 
  #--------------------------------------------------------------------------
  # * Create CT_Timer Sprite
  #--------------------------------------------------------------------------
  def create_ct_timer
    @ct_timer_sprite = CT_Sprite_Timer.new(@viewport2,
                                           CT_Timer::DEFAULT_X,
                                           CT_Timer::DEFAULT_Y)
  end

  #--------------------------------------------------------------------------
  # * Free CT_Timer Sprite
  #--------------------------------------------------------------------------
  def dispose_ct_timer
    @ct_timer_sprite.dispose
  end

  #--------------------------------------------------------------------------
  # * Update CT_Timer Sprite
  #--------------------------------------------------------------------------
  def update_ct_timer
    @ct_timer_sprite.update
  end
end

#==============================================================================
# ** Scene_Map
#------------------------------------------------------------------------------
#  This class performs the map screen processing.
#==============================================================================
class Scene_Map < Scene_Base
  #--------------------------------------------------------------------------
  # * Frame Update
  #--------------------------------------------------------------------------
  alias :my_update :update
  def update
    my_update
    $ct_game_timer.update
    update_scene if scene_change_ok?
  end
end

module BattleManager
    class << self
        alias_method(:my_battle_start, :battle_start)
    alias_method(:my_battle_end, :battle_end)
    end
 
  def self.battle_start
    if CT_Timer::PAUSE_IN_BATTLE_SWITCH_ID
      if $game_switches[CT_Timer::PAUSE_IN_BATTLE_SWITCH_ID]
        $ct_game_timer.paused = true
      end
    end
    my_battle_start
  end

  def self.battle_end(result)
    if CT_Timer::PAUSE_IN_BATTLE_SWITCH_ID
      if $game_switches[CT_Timer::PAUSE_IN_BATTLE_SWITCH_ID]
        $ct_game_timer.paused = false
      end
    end
    my_battle_end(result)
  end
end

#==============================================================================
# ** Scene_Battle
#------------------------------------------------------------------------------
#  This class performs battle screen processing.
#==============================================================================
class Scene_Battle < Scene_Base
  #--------------------------------------------------------------------------
  # * Frame Update
  #--------------------------------------------------------------------------
  alias :my_update :update
  def update
    if CT_Timer::WAIT_FOR_TIMER_SWITCH_ID
      if $game_switches[CT_Timer::WAIT_FOR_TIMER_SWITCH_ID] && !$game_switches[CT_Timer::PAUSE_IN_BATTLE_SWITCH_ID]
        super
        if not $game_switches[CT_Timer::ACCEPT_INPUT_SWITCH_ID]
          if BattleManager.in_turn?
            process_event
            process_action
          end
        end
        BattleManager.judge_win_loss
      else
        my_update
      end
    else
      my_update
    end
  end
 
  #--------------------------------------------------------------------------
  # * Update Frame (Basic)
  #--------------------------------------------------------------------------
  alias :my_update_basic :update_basic
  def update_basic
    my_update_basic
    $ct_game_timer.update
  end
end

#==============================================================================
# ** Game_Interpreter
#------------------------------------------------------------------------------
# An interpreter for executing event commands. This class is used within the
# Game_Map, Game_Troop, and Game_Event classes.
#==============================================================================
class Game_Interpreter
  #--------------------------------------------------------------------------
  # * ct_timer
  #   Use this to set up a ct_timer
  #--------------------------------------------------------------------------
  def ct_timer(mins = 0, secs = 0, start = true, ct_game_timer = $ct_game_timer, ct_audio = nil)
    if start  # Start
      v = (mins * 60) + secs
      if ct_audio
        ct_game_timer.ct_audio = ct_audio
      end
      ct_game_timer.start(v * Graphics.frame_rate)
    else      # Stop
      ct_game_timer.stop
    end
  end
end