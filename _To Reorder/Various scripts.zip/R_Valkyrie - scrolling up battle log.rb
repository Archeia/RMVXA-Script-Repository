#==============================================================================
# ** Scrolling Battle Log
# ** by R_Valkyrie
#------------------------------------------------------------------------------
# Plug and Play.
# Free to use for non-commercial and commercial, just give credit to me.
#==============================================================================

#==============================================================================
# ** Settings
#==============================================================================

module SCROLLING_BATTLE_LOG
 
  LOG_HEIGHT = 6   #How many lines the log will show during battle.
  LOG_SPEED = 60   #How long the log will wait between every message.
  SCROLL_SPEED = 3 #How fast the log will scroll. Set to 0 for instant scroll.
 
end

#==============================================================================
# Don't edit anything below this line unless you know what you're doing.
#==============================================================================

#==============================================================================
# ** Window_BattleLog
#==============================================================================

class Window_BattleLog < Window_Selectable
  include SCROLLING_BATTLE_LOG
  def initialize
    super(0, 0, window_width, window_height)
    self.z = 200
    self.opacity = 0
    self.arrows_visible = false
    @lines = []
    @num_wait = 0
    create_back_bitmap
    create_back_sprite
    refresh
  end
  def max_line_number
    return 500
  end
  def clear
    self.oy = 0
    @lines.clear
    refresh
  end
  def back_one
    #
  end
  def add_text(text)
    if @lines.size > (LOG_HEIGHT - 1)
      distance = line_height
      speed = (SCROLL_SPEED == 0) ? line_height : SCROLL_SPEED
      until distance == 0 do
        self.oy += (distance < speed) ? distance : speed
        distance -= (distance < speed) ? distance : speed
        Graphics.update
      end
    end
    @lines.push(text)
    refresh
  end
  def refresh
    draw_background if @lines.size < (LOG_HEIGHT + 1)
    contents.clear
    @lines.size.times {|i| draw_line(i) }
  end
  def message_speed
    return LOG_SPEED
  end
  def wait_and_clear
    #
  end
  def display_current_state(subject)
    unless subject.most_important_state_text.empty?
      add_text(subject.name + subject.most_important_state_text)
      wait
    end
  end
  def display_action_results(target, item)
    if target.result.used
      display_critical(target, item)
      display_damage(target, item)
      display_affected_status(target, item)
      display_failure(target, item)
    end
  end
  def display_affected_status(target, item)
    if target.result.status_affected?
      display_changed_states(target)
      display_changed_buffs(target)
    end
  end
  def display_auto_affected_status(target)
    if target.result.status_affected?
      display_affected_status(target, nil)
    end
  end
  def display_added_states(target)
    target.result.added_state_objects.each do |state|
      state_msg = target.actor? ? state.message1 : state.message2
      target.perform_collapse_effect if state.id == target.death_state_id
      next if state_msg.empty?
      add_text(target.name + state_msg)
      wait
      wait_for_effect
    end
  end
  def display_removed_states(target)
    target.result.removed_state_objects.each do |state|
      next if state.message4.empty?
      add_text(target.name + state.message4)
      wait
    end
  end
  def display_buffs(target, buffs, fmt)
    buffs.each do |param_id|
      add_text(sprintf(fmt, target.name, Vocab::param(param_id)))
      wait
    end
  end
end

#==============================================================================
# ** Scene_Battle
#==============================================================================

class Scene_Battle < Scene_Base
  alias update_message_open_and_clear_log update_message_open
  def update_message_open
    @log_window.clear if $game_message.busy?
    update_message_open_and_clear_log
  end
  def turn_end
    all_battle_members.each do |battler|
      battler.on_turn_end
      refresh_status
      @log_window.display_auto_affected_status(battler)
    end
    @log_window.clear
    BattleManager.turn_end
    process_event
    start_party_command_selection
  end
end

#==============================================================================
# End of script.
#==============================================================================