#==============================================================================
#                   「Skip Text Wait」(ACE) ver1  by Nana
#
#   ◇Terms of Use
#   Please credit "Nana" and link http://heptanas.mamagoto.com/ if possible.
#   Feel free to modify this script and/or distribute it.
#   Also please include the credit in the readme or somewhere it's accessible. (Not from credit roll)
#  
#   ◇Use for non-profit indie games or doujin games.
#   Use is limited to games created as hobbies by individuals or groups.
#   May be used for games sold as either hard or soft (DL) copies.
#   *Not for use by commercial businesses.
#
#------------------------------------------------------------------------------
#
#   By default, you can fast forward the text with C button (Enter key)
#   Fast forwarding was impossible due to using waits with "\." or "\ |".
#   With this script it is possible to skip wait by pressing the Enter key.
#
#==============================================================================
 
class Window_Message < Window_Base
  #--------------------------------------------------------------------------
  # ● Process Escaoe Characters (Redefinition)
  #--------------------------------------------------------------------------
  def process_escape_character(code, text, pos)
    case code.upcase
    when '$'
      @gold_window.open
    when '.'
      wait(15) unless Input.press?(:C)
    when '|'
      wait(60) unless Input.press?(:C)
    when '!'
      input_pause
    when '>'
      @line_show_fast = true
    when '<'
      @line_show_fast = false
    when '^'
      @pause_skip = true
    else
      super
    end
  end
end