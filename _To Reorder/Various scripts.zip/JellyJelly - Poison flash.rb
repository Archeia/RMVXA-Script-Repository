#===============================================================================
# ** Jelly's Poison Flash Extension                                       [v1.1]
#    Fourm Post: http://goo.gl/QVuvPt
#-------------------------------------------------------------------------------
#  - Lets you select a switch to toggle the damage flash from walking while
#    poisoned or on a damage tile.
#  - Assign a sound to play when the flash occurs.
#  - Alter the duration, color and alpha of the flash.
#===============================================================================
# ** Credit
#-------------------------------------------------------------------------------
#  - Free to use in commercial and otherwise.
#  - A little shoutout to myself is appreciated.
#  - What I do require is that if you complete a game I be allowed to list it as
#    something my work has been included in.  I can be contacted at:
#    aaron.feldman911@gmail.com  Just make sure to have a relevant subject line!
#===============================================================================
# ** Change Log
#-------------------------------------------------------------------------------
#  9/9/15 - v1.1
#           - Settable/togglable sound on proc
#           - Settable duration/color/alpha of flash
#  9/8/15 - v1.0
#           - Initial toggle support
#===============================================================================
# ** Future Features
#-------------------------------------------------------------------------------
#  - Editable amount of damage from damage tiles.
#  - Two separate methods for poison and damage tiles procs.  Allows for
#    separate colors and sounds for each.
#  - Frequency of poison/damage tile proc.  Editable number of steps for each
#    type.  Perhaps even a editable range.
#  - Use of a picture as the flash.
#===============================================================================
# ** Compatibility
#-------------------------------------------------------------------------------
#  This script aliases start_flash_for_damage in Game_Screen, a method I have
#  rarely seen used.  I doubt it will cause any issues.
#===============================================================================
#EDITABLE================EDITABLE===============EDITABLE================EDITABLE
#========EDITABLE================EDITABLE===============EDITABLE================
#================EDITABLE================EDITABLE===============EDITABLE========
# Configuration Module
#-------------------------------------------------------------------------------                                                                  
module JELLY
  FLASH_SWITCH   = 1                 # change this number to the switch you wish to toggle the flash
  SOUND_SWITCH   = 2                 # change this number to the switch you wish to toggle the sound that plays on flash
  FLASH_SOUND    = ["Poison",60,100] # the name of the SE to play, volume, pitch of the SE to be played.  MUST be in the SE folder
  FLASH_COLOR    = [255, 0, 0, 128]  # the color and alpha of the flash # default is 255, 0, 0, 128
  FLASH_DURATION = 8                 # the time (in frames) the flash will be on the screen.  If you would like to flash in seconds multiply by 60 # default is 8 frames  
end
#===============================================================================
#===============================================================================
#===============================================================================
# EDIT AT OWN RISK
#===============================================================================
# ** Game_Screen
#-------------------------------------------------------------------------------
#  This class handles screen maintenance data, such as changes in color tone,
# flashes, etc. It's used within the Game_Map and Game_Troop classes.
#===============================================================================
class Game_Screen
  #-----------------------------------------------------------------------------
  # * Start Flash (for Poison/Damage Floor)
  #-----------------------------------------------------------------------------
  def start_flash_for_damage
  alias jelly_start_flash_for_damage    start_flash_for_damage
    if $game_switches[JELLY::FLASH_SWITCH] == true
      if $game_switches[JELLY::SOUND_SWITCH] == true
        Audio.se_play("Audio/SE/"+JELLY::FLASH_SOUND[0],JELLY::FLASH_SOUND[1],JELLY::FLASH_SOUND[2])
      end
      start_flash(Color.new(*JELLY::FLASH_COLOR), JELLY::FLASH_DURATION)
    end
  end
end