class Scene_Title < Scene_MenuBase
  def start
    super
    make_graphics
    make_command_window
    play_title_music
  end
  
  def make_graphics
    @background=Plane.new
    @background.bitmap=Cache.parallax("StarlitSky")
    @scroller=Plane.new
    @scroller.bitmap=Cache.picture("scroller")
    @scroller.blend_type=1
    @spinny=Sprite.new
    @spinny.bitmap=Cache.picture("spinny")
    @spinny.ox=@spinny.width/2
    @spinny.oy=@spinny.height/2
    @spinny.x=10
    @spinny.y=10
    @bars=Plane.new
    @bars.bitmap=Cache.picture("bars")
    @bars.blend_type=1
    @bars.opacity=150
    @bars.oy=145
    @bars2=Plane.new
    @bars.bitmap=Cache.picture("bars")
    @bars.blend_type=1
    @bars.opacity=150
    @bars.oy=190
    
    @foreground_sprite = Sprite.new
    @foreground_sprite.bitmap = Bitmap.new(Graphics.width, Graphics.height)
    @foreground_sprite.z = 100
    draw_game_title if $data_system.opt_draw_title
  end
  
  def draw_game_title
    @foreground_sprite.bitmap.font.size = 96
    rect = Rect.new(0, 0, Graphics.width, Graphics.height / 2)
    @foreground_sprite.bitmap.draw_text(rect, $data_system.game_title, 1)
  end
  
  def update
    super
    @background.oy+=1
    @spinny.angle+=5
    @scroller.ox+=15
    @bars.ox-=15
    @bars2.ox-=20
  end
  
  def make_command_window
    @command_window = Window_TitleCommand.new
    @command_window.set_handler(:new_game, method(:command_new_game))
    @command_window.set_handler(:continue, method(:command_continue))
    @command_window.set_handler(:shutdown, method(:command_shutdown))
  end
  def command_new_game
    DataManager.setup_new_game
    close_command_window
    fadeout_all
    $game_map.autoplay
    SceneManager.goto(Scene_Map)
  end
  def command_continue
    close_command_window
    SceneManager.call(Scene_Load)
  end
  def command_shutdown
    close_command_window
    fadeout_all
    SceneManager.exit
  end
  def play_title_music
    $data_system.title_bgm.play
    RPG::BGS.stop
    RPG::ME.stop
  end
  def close_command_window
    @command_window.close
    update until @command_window.close?
  end
end