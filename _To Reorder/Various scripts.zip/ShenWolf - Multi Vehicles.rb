class Game_Map
  
  def create_vehicles
    # clear default data
    $data_system.boat = []
    @vehicles = []
#--------------------------------------------------------------
#  Create new vehicles by add_vehicle() calls here
#   parameters > type, speed, name, index, map, x, y, bgm
#     type  > :boat for land, :ship for sea, :airship for air
#     speed > numbers 1-6, 4 is normal speed
#     name  > character_name for the graphic
#     index > numbers 0-7 character_index for the graphic
#     map   > map id number the vehicle starts on
#     x     > x position the vehicle starts on
#     y     > y position the vehicle starts on
#     bgm   > music name to play while driving
#--------------------------------------------------------------
    add_vehicle(:boat, 4, "Vehicle", 7, 1, 6, 6, "Ship")
    add_vehicle(:boat, 5, "Vehicle", 6, 1, 6, 7, "Ship")
    add_vehicle(:boat, 6, "Vehicle", 5, 1, 6, 8, "Ship")

    add_vehicle(:ship, 4, "Vehicle", 0, 1, 7, 11, "Ship")
    add_vehicle(:ship, 5, "Vehicle", 0, 1, 8, 11, "Ship")
    add_vehicle(:ship, 6, "Vehicle", 1, 1, 9, 11, "Ship")
    
    add_vehicle(:airship, 4, "Vehicle", 2, 1, 10, 6, "AirShip")
    add_vehicle(:airship, 5, "Vehicle", 2, 1, 10, 7, "AirShip")
    add_vehicle(:airship, 6, "Vehicle", 3, 1, 10, 8, "AirShip")
#--------------------------------------------------------------
  end
  
  # for boat to move on land
  def boat_passable?(x, y)
    check_passage(x, y, 0x0f)
  end
  # vehicle creation function
  def add_vehicle(type, speed, name, index, map, x, y, bgm)
    @id = $data_system.boat.length
    $data_system.boat.push(RPG::System::Vehicle.new)
    $data_system.boat[@id].character_name = name
    $data_system.boat[@id].character_index = index
    $data_system.boat[@id].bgm = RPG::BGM.new(bgm)
    $data_system.boat[@id].start_map_id = map
    $data_system.boat[@id].start_x = x
    $data_system.boat[@id].start_y = y
    @vehicles[@id] = Multi_Vehicle.new(@id, speed, type)
  end
end

class Multi_Vehicle < Game_Vehicle
  # used to identify vehicles
  attr_accessor :vehicle_id
  attr_accessor :type
  def initialize(id, speed, type)
    @vehicle_id = id
    super(type)
    @move_speed = speed
  end
  # new way to access vehicles
  def system_vehicle
    return $data_system.boat[@vehicle_id]
  end
end

class Game_CharacterBase
  # new vehicle collision check
  def collide_with_vehicles?(x, y)
    @i=0
    while @i < $game_map.vehicles.length
      @v = $game_map.vehicles[@i]
      if (@v.type == :boat || @v.type == :ship) && @v.pos_nt?(x, y)
        return true
      end
      @i +=1
    end
    return false
  end
end

class Game_Player < Game_Character
  # keep got on vehicle id
  attr_accessor :vehicle_id
  # new way to access vehicles
  def vehicle
    return nil if @vehicle_type == :walk
    $game_map.vehicles[@vehicle_id]
  end
  # new way to get on vehicles
  def get_on_vehicle
    front_x = $game_map.round_x_with_direction(@x, @direction)
    front_y = $game_map.round_y_with_direction(@y, @direction)
    @i = 0
    while @i < $game_map.vehicles.length
      @v = $game_map.vehicles[@i]
      if (@v.type == :boat && @v.pos?(front_x, front_y)) || 
         (@v.type == :ship && @v.pos?(front_x, front_y)) || 
         (@v.type == :airship && @v.pos?(@x, @y))
        @vehicle_id = @i
        @vehicle_type = $game_map.vehicles[@i].type
      end
      @i +=1
    end
    if vehicle
      @vehicle_getting_on = true
      force_move_forward unless in_airship?
      @followers.gather
    end
    @vehicle_getting_on
  end
end

class Spriteset_Map
  # this is for airship shadow
  def update_shadow
    airship = $game_player.vehicle
    return nil if airship == nil
    return nil if airship.type != :airship
    @shadow_sprite.x = airship.screen_x
    @shadow_sprite.y = airship.screen_y + airship.altitude
    @shadow_sprite.opacity = airship.altitude * 8
    @shadow_sprite.update
  end
end
