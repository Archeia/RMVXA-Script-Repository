#==============================================================================
# Gamepad Extender Game Adapter - Arc Engine
# by Jono99
#------------------------------------------------------------------------------
# This allows the game commands in Arc Engine by Khas Arcthunder to be handled
# in a more controller friendly way.
# 
# Based off of Gamepad Extender by Lone Wolf, GE Game Adapter by Jono99 and
# Arc Engine by Khas Arcthunder and requires all of the above scripts to function.
#
# It is reommended that you do not have a controller plugged in until you reach
# the title screen while testing as the menu that pops up before that does not
# play nice with controllers.
#
# It is also recommended that you have the scripts laid out in a specific order:
# Gamepad Extender, GE Game Adapter, Arc Engine then GEGA - Arc Engine (this script).
#
# Link to download Gamepad Extender: http://forums.rpgmakerweb.com/index.php?/topic/1284-gamepad-extender-v11-2202015/
# Link to download GE Game Adapter: http://forums.rpgmakerweb.com/index.php?/topic/69589-ge-game-adapter/
# Link to download Arc Engine: http://www.mediafire.com/?b1x1b18637b1wk2
#==============================================================================

module GEGAACOptions
  def self.jump
    WolfPad.plugged_in? ? :A : :X
  end
  EventInteract = :C
end
module PadConfig
  def self.dash
    WolfPad.plugged_in? ? :L2 : :A
  end
end





if defined?(WolfPad) == nil
  msgbox("WARNING: GamePad Extender is either missing or executes sometime after this. To avoid issues, GEGA Arc Engine will not execute!")
elsif defined?(GEGAOptions) == nil
  msgbox("WARNING: GE Game Adapter is either missing or executes sometime after this. To avoid issues, GEGA Arc Engine will not execute!")
elsif defined?(Arc_Core) == nil
  msgbox("WARNING: Arc Engine is either missing or executes sometime after this. To avoid issues, GEGA Arc Engine will not execute!")
else
  # Put GEGA - Arc Engine code here
  class Game_Player
    def gegaac_groundpound_input(down)
      if Input.trigger?(down) 
        if !jump_enabled? && !@groundpound
          stop
          apply_yforce(-Jump_Impulse)
          @groundpound = true
        end
      end
    end
    def arc_update
      try_event if Input.trigger?(GEGAACOptions::EventInteract)
      @wait_c -= 1 if @wait_c > 0
      unless @grab_stair
        if WolfPad.plugged_in?
          gegaac_groundpound_input(:DOWN) if GEGAOptions::MoveInput == 0 || GEGAOptions::MoveInput == 2
          gegaac_groundpound_input(:L_DOWN) if GEGAOptions::MoveInput > 0
        else
          gegaac_groundpound_input(:DOWN)
        end
        @vy += Gravity 
        @vy -= Air_Resistance*@vy*@vy/(@wg*Meter_Size) if @vy > Insignificant
      end
      if @tx != nil
        @tx > 0 ? @tx -= 1 : reset_vx
      end
      if @ty != nil
        @ty > 0 ? @ty -= 1 : reset_vy
      end
      if @move_route_forcing
        arc_move
        check_move_route
      else
        update_arcinput
        arc_move
        check_ungrab
      end
      kill if @ay > $game_map.y_limit
      if @vx.abs > Insignificant
        et = event_below_type
        if (@grab_stair || surface_below? || et == 0x01)
          refresh_animation
        elsif et == 0x02
          @pattern = 1
        else
          @pattern = 0
        end
      elsif @grab_stair && @vy.abs > Insignificant
        stair_animation
      else
        @pattern = 1 unless @move_route_forcing
        @atimer = 13
      end
    end
    def update_arcinput
      return if $game_map.interpreter.running? || $game_message.busy? || $game_message.visible
      if WolfPad.plugged_in?
        if GEGAOptions::MoveInput == 0 || GEGAOptions::MoveInput == 2
          try_grab if Input.trigger?(:UP)
        end
        if GEGAOptions::MoveInput > 0
          try_grab if Input.trigger?(:L_UP)
        end
      else
        try_grab if Input.trigger?(:UP)
      end
      if @grab_stair
        gegaac_dir8 = 0
        if WolfPad.plugged_in?
          if GEGAOptions::MoveInput == 0
            gegaac_dir8 = WolfPad.dird8
          elsif GEGAOptions::MoveInput == 1
            gegaac_dir8 = WolfPad.lstick8
          elsif GEGAOptions::MoveInput == 2
            gegaac_dir8 = WolfPad.dird8
            gegaac_dir8 = WolfPad.lstick8 if gegaac_dir8 == 0
          end
        else
          gegaac_dir8 = Input.dir8
        end
        case gegaac_dir8
        when 1
          move_x(-Stair_Speed)
          move_y(Stair_Speed)
        when 2
          reset_vx
          move_y(Stair_Speed)
        when 3
          move_x(Stair_Speed)
          move_y(Stair_Speed)
        when 4
          move_x(-Stair_Speed)
          reset_vy
        when 6
          move_x(Stair_Speed)
          reset_vy
        when 7
          move_x(-Stair_Speed)
          move_y(-Stair_Speed)
        when 8
          reset_vx
          move_y(-Stair_Speed)
        when 9
          move_x(Stair_Speed)
          move_y(-Stair_Speed)
        else
          reset_vx
          reset_vy
        end
        if Input.trigger?(:X)
          apply_yforce(Jump_Impulse)
          Arc_Sound.jump
          @grab_stair = false
          set_direction(@vx > 0 ? 6 : 4)
        end
      else
        gegaac_dir4 = 0
        if WolfPad.plugged_in?
          if GEGAOptions::MoveInput == 0
            gegaac_dir4 = WolfPad.dird4
          elsif GEGAOptions::MoveInput == 1
            gegaac_dir4 = WolfPad.lstick4
          elsif GEGAOptions::MoveInput == 2
            gegaac_dir4 = WolfPad.dird4
            gegaac_dir4 = WolfPad.lstick4 if gegaac_dir4 == 0
          end
        else
          gegaac_dir4 = Input.dir4
        end
        case gegaac_dir4
        when 4
          @vx -= @key_acc
          set_direction(4)
          @deny_resistance = false
          r = (Input.press?(PadConfig.dash) ? Running_Resistance : Body_Resistance)
        when 6
          @vx += @key_acc
          set_direction(6)
          @deny_resistance = false
          r = (Input.press?(PadConfig.dash) ? Running_Resistance : Body_Resistance)
        else
          r = (@wallkick ? Body_Resistance : Stop_Resistance)
        end
        if Input.trigger?(GEGAACOptions.jump)
          if jump_enabled?
            apply_yforce(Jump_Impulse + Jump_RBonus*@vx.abs)
            Arc_Sound.jump
          elsif wkick_left?
            stop
            @wk_pos = [@ax,@ay]
            @wallkick = true
            @deny_resistance = true
            apply_xforce(WKick_XImpulse)
            apply_yforce(WKick_YImpulse)
            Arc_Sound.jump
          elsif wkick_right?
            stop
            @wk_pos = [@ax,@ay]
            @wallkick = true
            @deny_resistance = true
            apply_xforce(-WKick_XImpulse)
            apply_yforce(WKick_YImpulse)
            Arc_Sound.jump
          end
        end
        if @deny_resistance
          @deny_resistance = false
        else
          if @vx.abs > Insignificant
            rb = r*@vx*@vx/@res_coef
            @vx += (@vx > 0 ? -rb : rb)
          end
        end
      end
    end
  end
end