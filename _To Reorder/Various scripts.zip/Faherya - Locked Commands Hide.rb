#===============================================================================
#                        Locked Commands Hidden
#===============================================================================
# This code removes locked options from several scenes, showing them normally
# when they are released.
#-------------------------------------------------------------------------------
# Free for commercial and non-commercial projects.
#-------------------------------------------------------------------------------
# Continue, on Title.
class Window_TitleCommand
    def make_command_list
      add_command(Vocab::new_game, :new_game)
      if continue_enabled
        add_command(Vocab::continue, :continue)
      end
      add_command(Vocab::shutdown, :shutdown)
    end
end
#-------------------------------------------------------------------------------
# Sell, on Shop.
class Window_ShopCommand
  def make_command_list
    add_command(Vocab::ShopBuy,    :buy)
    if !@purchase_only
      add_command(Vocab::ShopSell,   :sell)
    end
    add_command(Vocab::ShopCancel, :cancel)
  end
end
#-------------------------------------------------------------------------------
# Save and Formation, on Menu.
class Window_MenuCommand
  def add_save_command
    if save_enabled
      add_command(Vocab::save, :save)
    end
  end
  def add_formation_command
    if formation_enabled
    add_command(Vocab::formation, :formation)
    end
  end
end
#-------------------------------------------------------------------------------
# Escape, on Battle.
class Window_PartyCommand
  def make_command_list
    add_command(Vocab::fight,  :fight)
    if BattleManager.can_escape?
      add_command(Vocab::escape, :escape)
    end
  end
end
#-------------------------------------------------------------------------------