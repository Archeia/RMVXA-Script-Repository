#-------------------------------------------------------------------------------
# Name: WFz - Title
# Author: AlexxanderX
# SPECIAL THANKS TO NICLE
#-------------------------------------------------------------------------------
# To use scroll down and change what you want!
#-------------------------------------------------------------------------------
module WFz
 module Title # Settings
#-------------------------------------------------------------------------------
# $eff = 0 Only with background
# $eff = 1 With background and background effect
$eff = 0 # initial 0
#-------------------------------------------------------------------------------
# Change the number of $n to the number of your background.
$n = 0
#-------------------------------------------------------------------------------
# Change the number of $i to the number of your background effect.
$i = 0
#-------------------------------------------------------------------------------
# To add a background follow next steps:
#   1.Add the image in \Grapich\Titles1\
#   2.Implement the background:
#   $n == the number of your image( bigger than 19)
#   $title1 = "your image name"
#-------------------------------------------------------------------------------
if $n == 0; $title1 = "Book"; end; # example
#-------------------------------------------------------------------------------
# To add a background effect follow next steps:
#   1.Add the image in \Grapich\Titles2\
#   2.Implement the background effect:
#   $i == the number of your image( bigger than 8)
#   $title2 = "your image name"
#-------------------------------------------------------------------------------
if $i == 0; $title2 = "Dragons"; end; # example
#-------------------------------------------------------------------------------
# If you want to change title name change next:
$title_name = "" # the title name ( if is "" will show game name)
$d1 = 0 # move to right the title ( with - move to left( e.g. -200)
		# of title
$h1 = 0 # move down the title ( with - move up ( e.g. -200)
$titlen1_size = 48 # the size of title ( initial 48)
$c1 = 0 # the color of text
$title1_font = "" # the font of text ( initial "")
$bold1 = false # bold text

$title_name_two = "" # the 2nd line for text
$d2 = 0 # move to right the title ( with - move to left( e.g. -200)
		# of title
$h2 = 0 # move down the title ( with - move up ( e.g. -200)
$titlen2_size = 48 # the size of title ( initial 48)
$c2 = 0 # the color of text
$title2_font = "" # the font of text ( initial "")
$bold2 = false # bold text

$title_name_three = "" # the 3rd line for text
$d3 = 0 # move to right the title ( with - move to left( e.g. -200)
		# of title
$h3 = 0 # move down the title ( with - move up ( e.g. -200)
$titlen3_size = 48 # the size of title ( initial 48)
$c3 = 0 # the color of text
$title3_font = "" # the font of text ( initial "")
$bold3 = false # bold text
#-------------------------------------------------------------------------------
# To change the speed of showing the title window change the number of:
$speed_anim = 20 # initial 20
#-------------------------------------------------------------------------------
# Color numbers:
#	  White - 0
#	  LightRed - 1
#	  LightGreen - 2
#	  LightBlue - 3
#	  Alpha - 4
#	  Blue Violet - 5
#	  Aquamarine - 6
#	  Blue - 7
#	  Saddle Brown - 8
#	  Chocolate - 9
#	  Dark Green - 10
#	  Red - 11
#-------------------------------------------------------------------------------
# To add a personal color:
# For first title:
# $c1 == number( bigger than 11)
# Color.new(R,G, - need to put your color code( R, G, 
if $c1 == 0; $title1_color = Color.new(255,255,255); end; # example
#-------------------------------------------------------------------------------
# To add a personal color:
# For 2nd title:
# $c2 == number( bigger than 11)
# Color.new(R,G, - need to put your color code( R, G, 
if $c2 == 0; $title2_color = Color.new(255,255,255); end; # example
#-------------------------------------------------------------------------------
# To add a personal color:
# For 3rd title:
# $c3 == number( bigger than 11)
# Color.new(R,G, - need to put your color code( R, G, 
if $c3 == 0; $title3_color = Color.new(255,255,255); end; # example
#-------------------------------------------------------------------------------
# To change the position of menu simple change the coordonates:
$wx = -1 # put a value for x coordonate ( initial -1 )
$wy = -1 # put a value for y coordonate ( initial -1 )
#-------------------------------------------------------------------------------

if $c1 == 0; $title1_color = Color.new(255,255,255); end;
if $c1 == 1; $title1_color = Color.new(255,150,150); end;
if $c1 == 2; $title1_color = Color.new(150,255,150); end;
if $c1 == 3; $title1_color = Color.new(150,150,255); end;
if $c1 == 4; $title1_color = Color.new(0,0,0,128); end;
if $c1 == 5; $title1_color = Color.new(138,43,226); end;
if $c1 == 6; $title1_color = Color.new(112,219,147); end;
if $c1 == 7; $title1_color = Color.new(0,0,255); end;
if $c1 == 8; $title1_color = Color.new(139,69,19); end;
if $c1 == 9; $title1_color = Color.new(210,105,30); end;
if $c1 == 10; $title1_color = Color.new(0,100,0); end;
if $c1 == 11; $title1_color = Color.new(255,0,0); end;

if $c2 == 0; $title2_color = Color.new(255,255,255); end;
if $c2 == 1; $title2_color = Color.new(255,150,150); end;
if $c2 == 2; $title2_color = Color.new(150,255,150); end;
if $c2 == 3; $title2_color = Color.new(150,150,255); end;
if $c2 == 4; $title2_color = Color.new(0,0,0,128); end;
if $c2 == 5; $title2_color = Color.new(138,43,226); end;
if $c2 == 6; $title2_color = Color.new(112,219,147); end;
if $c2 == 7; $title2_color = Color.new(0,0,255); end;
if $c2 == 8; $title2_color = Color.new(139,69,19); end;
if $c2 == 9; $title2_color = Color.new(210,105,30); end;
if $c2 == 10; $title2_color = Color.new(0,100,0); end;
if $c2 == 11; $title2_color = Color.new(205,0,0); end;

if $c3 == 0; $title3_color = Color.new(255,255,255); end;
if $c3 == 1; $title3_color = Color.new(255,150,150); end;
if $c3 == 2; $title3_color = Color.new(150,255,150); end;
if $c3 == 3; $title3_color = Color.new(150,150,255); end;
if $c3 == 4; $title3_color = Color.new(0,0,0,128); end;
if $c3 == 5; $title3_color = Color.new(138,43,226); end;
if $c3 == 6; $title3_color = Color.new(112,219,147); end;
if $c3 == 7; $title3_color = Color.new(0,0,255); end;
if $c3 == 8; $title3_color = Color.new(139,69,19); end;
if $c3 == 9; $title3_color = Color.new(210,105,30); end;
if $c3 == 10; $title3_color = Color.new(0,100,0); end;
if $c3 == 11; $title3_color = Color.new(255,0,0); end;

$title1 = ""
$title2 = ""

if $n == 0; $title1 = "Book"; end;
if $n == 1; $title1 = "Castle"; end;
if $n == 2; $title1 = "CrossedSwords"; end;
if $n == 3; $title1 = "Crystal"; end;
if $n == 4; $title1 = "DemonCastle"; end;
if $n == 5; $title1 = "Devil"; end;
if $n == 6; $title1 = "Dragon"; end;
if $n == 7; $title1 = "Fountain"; end;
if $n == 8; $title1 = "Gates"; end;
if $n == 9; $title1 = "Hexagram"; end;
if $n == 10; $title1 = "Island"; end;
if $n == 11; $title1 = "Night"; end;
if $n == 12; $title1 = "Plain"; end;
if $n == 13; $title1 = "Sword"; end;
if $n == 14; $title1 = "Tower1"; end;
if $n == 15; $title1 = "Tower2"; end;
if $n == 16; $title1 = "Universe"; end;
if $n == 17; $title1 = "Volcano"; end;
if $n == 18; $title1 = "World"; end;
if $n == 19; $title1 = "WorldMap"; end;

if $i == 0; $title2 = "Dragons"; end;
if $i == 1; $title2 = "Fire"; end;
if $i == 2; $title2 = "Forest"; end;
if $i == 3; $title2 = "Gargoyles"; end;
if $i == 4; $title2 = "Heroes"; end;
if $i == 5; $title2 = "Leaves"; end;
if $i == 6; $title2 = "Metal"; end;
if $i == 7; $title2 = "Mist"; end;
if $i == 8; $title2 = "Mountains"; end;
 end
end

class Window_TitleCommand < Window_Command
 def update_placement
if $wx != -1
  self.x = $wx
else
  self.x = (Graphics.width - width) / 2
end
if $wy != -1
  self.y = $wy
else
  self.y = (Graphics.height * 1.6 - height) / 2
end
 end
end

class Scene_Title < Scene_Base
 #--------------------------------------------------------------------------
 # * Get Transition Speed
 #--------------------------------------------------------------------------
 def transition_speed
return $speed_anim
 end
 #--------------------------------------------------------------------------
 # * Create Background
 #--------------------------------------------------------------------------
 def create_background
if $eff == 1
  @sprite1 = Sprite.new
  @sprite1.bitmap = Cache.title1($title1)
  @sprite2 = Sprite.new
  @sprite2.bitmap = Cache.title2($title2)
  center_sprite(@sprite1)
  center_sprite(@sprite2)
end
if $eff == 0
  @sprite1 = Sprite.new
  @sprite1.bitmap = Cache.title1($title1)
  center_sprite(@sprite1)
end
 end
 #--------------------------------------------------------------------------
 # * Create Foreground
 #--------------------------------------------------------------------------
 def create_foreground
@foreground_sprite = Sprite.new
@foreground_sprite.bitmap = Bitmap.new(Graphics.width, Graphics.height)
@foreground_sprite.z = 100
draw_game_title if $data_system.opt_draw_title
 end
 #--------------------------------------------------------------------------
 # * Draw Game Title
 #--------------------------------------------------------------------------
 def draw_game_title
if not $title1_font == ""
  @foreground_sprite.bitmap.font = Font.new([$title1_font])
end
@foreground_sprite.bitmap.font.size = $titlen1_size
@foreground_sprite.bitmap.font.color = $title1_color
@foreground_sprite.bitmap.font.bold = $bold1
rect = Rect.new($d1, $h1, Graphics.width, Graphics.height / 2)
@foreground_sprite.bitmap.draw_text(rect, $title_name, 1)
if not $title1_font == ""
  @foreground_sprite.bitmap.font = Font.new([$title2_font])
end
@foreground_sprite.bitmap.font.size = $titlen2_size
@foreground_sprite.bitmap.font.color = $title2_color
@foreground_sprite.bitmap.font.bold = $bold2
rect2 = Rect.new($d2, $h2, Graphics.width, Graphics.height / 2)
@foreground_sprite.bitmap.draw_text(rect2, $title_name_two, 1)
if not $title1_font == ""
  @foreground_sprite.bitmap.font = Font.new([$title3_font])
end
@foreground_sprite.bitmap.font.size = $titlen3_size
@foreground_sprite.bitmap.font.color = $title3_color
@foreground_sprite.bitmap.font.bold = $bold3
rect3 = Rect.new($d3, $h3, Graphics.width, Graphics.height / 2)
@foreground_sprite.bitmap.draw_text(rect3, $title_name_three, 1)

if $title_name == ""
  if not $title1_font == ""
	@foreground_sprite.bitmap.font = Font.new([$title1_font])
  end
  @foreground_sprite.bitmap.font.size = $titlen1_size
  @foreground_sprite.bitmap.font.color = $title1_color
  @foreground_sprite.bitmap.font.bold = $bold1
  rect = Rect.new($d1, $h1, Graphics.width, Graphics.height / 2)
  @foreground_sprite.bitmap.draw_text(rect, $data_system.game_title, 1)
end
 end
 #--------------------------------------------------------------------------
 # * Free Background
 #--------------------------------------------------------------------------
 def dispose_background
if $eff == 1
  @sprite1.bitmap.dispose
  @sprite1.dispose
  @sprite2.bitmap.dispose
  @sprite2.dispose
end
if $eff == 0
  @sprite1.bitmap.dispose
  @sprite1.dispose
end
 end
 #--------------------------------------------------------------------------
 # * Create Command Window
 #--------------------------------------------------------------------------
 def create_command_window
@command_window = Window_TitleCommand.new

@command_window.set_handler(:new_game, method(:command_new_game))
@command_window.set_handler(:continue, method(:command_continue))
@command_window.set_handler(:shutdown, method(:command_shutdown))
 end
 #--------------------------------------------------------------------------
 # * Close Command Window
 #--------------------------------------------------------------------------
end