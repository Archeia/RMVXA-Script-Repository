#==============================================================================
# ■ Map Name Display Background
#  MapNameBgImage.rb
#------------------------------------------------------------------------------
# 　You can specify an image file for map name display as a background.
#
# ●How to use
# 1. Prepare an image you want to use for the background image and place it in
# "Graphics \ Pictures" folder.
# 2. Set the file name to the variable after "@@back_ground_filename" in the
# user defined area (below).
#
# ●Terms of Service:
#  It's possible to modify and redistribute without permission from the author.
#  And this plugin licensed under MIT License.
#-----------------------------------------------------------------------------
# Copyright (c) 2015 Triacontane
# This software is released under the MIT License.
# http://opensource.org/licenses/mit-license.php
#-----------------------------------------------------------------------------
# Version
# 1.0.0 2016/02/24 First release
# ----------------------------------------------------------------------------
# [Blog]   : http://triacontane.blogspot.jp/
# [Twitter]: https://twitter.com/triacontane/
# [GitHub] : https://github.com/triacontane/
#=============================================================================
 
#==============================================================================
# ■ Window_MapName
#------------------------------------------------------------------------------
# 　Window that displays a map name
#==============================================================================
class Window_MapName
  #--------------------------------------------------------------------------]
  # ● User defined area Start
  # Input an image file name where you want to use as a background image here.
  #--------------------------------------------------------------------------
  @@back_ground_filename = "background.png"
  #--------------------------------------------------------------------------
  # ● User defined area End
  #--------------------------------------------------------------------------
  #--------------------------------------------------------------------------
  # ● Update fade-in
  #--------------------------------------------------------------------------
  alias mapname_bgimage_update_fadein update_fadein
  def update_fadein
    mapname_bgimage_update_fadein
    @bg_sprite.opacity += 16 if @bg_sprite != nil
  end
  #--------------------------------------------------------------------------
  # ● Update fade-out
  #--------------------------------------------------------------------------
  alias mapname_bgimage_update_fadeout update_fadeout
  def update_fadeout
    mapname_bgimage_update_fadeout
    @bg_sprite.opacity -= 16 if @bg_sprite != nil
  end
  #--------------------------------------------------------------------------
  # ● Draw background
  #--------------------------------------------------------------------------
  alias mapname_bgimage_draw_background draw_background
  def draw_background(rect)
    if @@back_ground_filename == ""
      mapname_bgimage_draw_background(rect)
    else
      @bg_sprite = Sprite.new
      @bg_sprite.bitmap = Cache.picture(@@back_ground_filename)
      @bg_sprite.opacity = 0
      @bg_sprite.x = (self.x + self.width  / 2) - @bg_sprite.bitmap.width  / 2
      @bg_sprite.y = (self.y + self.height / 2) - @bg_sprite.bitmap.height / 2
      @bg_sprite.z = self.z - 1
    end
  end
  #--------------------------------------------------------------------------
  # ● Release
  #--------------------------------------------------------------------------
  def dispose
    super
    @bg_sprite.dispose if @bg_sprite != nil
  end
end