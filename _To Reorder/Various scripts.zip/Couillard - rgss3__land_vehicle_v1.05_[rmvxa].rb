# ╔════════════════════════════════════════════════════╤═══════╤══════════════╗
# ║ Land Vehicle                                       │ v1.05 │ (09/01/2015) ║
# ╠════════════════════════════════════════════════════╧═══════╧══════════════╣
# ║ Author:  William Couillard                                                ║
# ║ Thanks:  Galv (http://galveraxe.wordpress.com/)                           ║
# ║          Mr. Trivel                                                       ║
# ║ E-Mail:  cooliebk18@yahoo.com                                             ║
# ╠═══════════════════════════════════════════════════════════════════════════╣
# ║ ABOUT                                                                     ║
# ╠═══════════════════════════════════════════════════════════════════════════╣
# ║ This script changes how the "Boat" vehicle functions. By default, the     ║
# ║ boat an travel on water, the same as the ship. Why isn't there a land     ║
# ║ vehicle? This script changes the boat to function as a land vehicle, able ║
# ║ to travel over any terrain that the player can (at a faster speed and     ║
# ║ without encounters), and blocks it from traveling over water or           ║
# ║ activating touch and confirm event processes.                             ║
# ║                                                                           ║
# ║ Anyone familiar with how Chocobos functioned in the SNES-era Final        ║
# ║ Fantasy titles should notice similarities here.                           ║
# ╠═══════════════════════════════════════════════════════════════════════════╣
# ║ TERMS OF USE                                                              ║
# ╠═══════════════════════════════════════════════════════════════════════════╣
# ║ ► Do not edit the script's header or comments.                            ║
# ║ ► Free to use in commercial projects as long as proper credit is given to ║
# ║   ALL the names in the above header.                                      ║
# ╠═══════════════════════════════════════════════════════════════════════════╣
# ║ CHANGE LOG                                                                ║
# ╠═════════════════════════════════════════════════════════════════╤═════════╣
# ║ ■ September 01, 2015 : Added aliases to improve compatibility.  │ (v1.05) ║
# ║                        Patch for Galv On/Off integrated         │         ║
# ╟─────────────────────────────────────────────────────────────────┼─────────╢
# ║ ■ October 31, 2014   : Option to disable stepping animation.    │ (v1.04) ║
# ╟─────────────────────────────────────────────────────────────────┼─────────╢
# ║ ■ July 21, 2014      : Option to disable action button events.  │ (v1.03) ║
# ╟─────────────────────────────────────────────────────────────────┼─────────╢
# ║ ■ January  30, 2013  : Bug fixed.                               │ (v1.02) ║
# ╟─────────────────────────────────────────────────────────────────┼─────────╢
# ║ ■ December 01, 2012  : Added option to keep encounters & touch  │ (v1.01) ║
# ║                        events.                                  │         ║
# ╟─────────────────────────────────────────────────────────────────┼─────────╢
# ║ ■ November 27, 2012 : Initial release.                          │ (v1.00) ║
# ╠═════════════════════════════════════════════════════════════════╧═════════╣
# ║ NEXT VERSION                                                              ║
# ╠═══════════════════════════════════════════════════════════════════════════╣
# ║ ■ Script completed!                                                       ║
# ╠═══════════════════════════════════════════════════════════════════════════╣
# ║ OVERWRITTEN METHODS                                                       ║
# ╠═══════════════════════════════════════════════════════════════════════════╣
# ║   This script overwrites or aliases a few methods in various default      ║
# ║   scripts.                                                                ║
# ╟───────────────────────────────────────────────────────────────────────────╢
# ║ ■ class Game_Map                                                          ║
# ║    ► def boat_passable?                                                   ║
# ╟───────────────────────────────────────────────────────────────────────────╢
# ║ ■ class Game_Player < Game_Character                                      ║
# ║    ► def map_passable?                                                    ║
# ║    ► def update_encounter                                                 ║
# ║    ► def check_touch_event                                                ║
# ║    ► def check_action_event                                               ║
# ╟───────────────────────────────────────────────────────────────────────────╢
# ║ ■ class Game_Vehicle > Game_Character                                     ║
# ║    ► def init_move_speed                                                  ║
# ║    ► def get_on                                                           ║
# ╠═══════════════════════════════════════════════════════════════════════════╣
# ║ INSTRUCTIONS                                                              ║
# ╠═══════════════════════════════════════════════════════════════════════════╣
# ║   Paste this script ABOVE Main and BELOW Game_Vehicle.                    ║
# ╠═══════════════════════════════════════════════════════════════════════════╣
# ║ IMPORT SETTING                                                            ║
# ╚═══════════════════════════════════════════════════════════════════════════╝
$imported = {} if $imported.nil?
$imported[:wc_land_vehicle] = true
# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║ CUSTOMIZATION MODULE                                                      ║
# ╚═══════════════════════════════════════════════════════════════════════════╝
module COOLIE
  module VEHICLE
# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║ VEHICLE SPEED: Set from 1-6 [Higher no. = higher speed]                   ║
# ╚═══════════════════════════════════════════════════════════════════════════╝
    VEHICLE_SPEED      = 5
# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║ VEHICLE ENCOUNTERS: Set to true to allow enemy encounters while piloting. ║
# ╚═══════════════════════════════════════════════════════════════════════════╝
    VEHICLE_ENCOUNTERS = false
# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║ VEHICLE TOUCH: Set to true to allow touch event processing.               ║
# ╚═══════════════════════════════════════════════════════════════════════════╝
    VEHICLE_TOUCH      = false
# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║ VEHICLE PRESS: Set to true to allow action button event processing.       ║
# ╚═══════════════════════════════════════════════════════════════════════════╝
    VEHICLE_PRESS      = false
# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║ STEP ANIM: When false, vehicle will not use step animation when idle.     ║
# ╚═══════════════════════════════════════════════════════════════════════════╝
    STEP_ANIM          = false
  end
end
#-------------------------------------------------------------------------------
class Game_Map
# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║ Determine if Passable by Land Vehicle                  [OVERWRITE METHOD] ║
# ╟───────────────────────────────────────────────────────────────────────────╢
# ║ Changes the Boat vehicle to have the same passability as the player.      ║
# ║ I.E. Can travel on land, not water. Cannot pass through same level tiles. ║
# ╚═══════════════════════════════════════════════════════════════════════════╝
  def boat_passable?(x, y, d)
    check_passage(x, y, (1 << (d / 2 - 1)) & 0x0f)
  end
end

class Game_Player < Game_Character
# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║ Map Passable?                                          [OVERWRITE METHOD] ║
# ╟───────────────────────────────────────────────────────────────────────────╢
# ║ Determines passability.                                                   ║
# ╚═══════════════════════════════════════════════════════════════════════════╝
  def map_passable?(x, y, d)
    case @vehicle_type
    when :boat
      $game_map.boat_passable?(x, y, d)
    when :ship
      if $imported["Galv_Vehicle_On_Off"]
        $game_map.ship_passable?(x, y, d)
      else
        $game_map.ship_passable?(x, y)
      end
    when :airship
      true
    else
      super
    end
  end
# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║ Update Encounters                                      [OVERWRITE METHOD] ║
# ╟───────────────────────────────────────────────────────────────────────────╢
# ║ Turns off encounters if piloting the Land Vehicle.                        ║
# ╚═══════════════════════════════════════════════════════════════════════════╝
  def update_encounter
    return if $TEST && Input.press?(:CTRL)
    return if $game_party.encounter_none?
    return if in_airship?
    unless COOLIE::VEHICLE::VEHICLE_ENCOUNTERS
      return if in_boat?
    end
    return if @move_route_forcing
    @encounter_count -= encounter_progress_value
  end
# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║ Determine if Event Start Caused by Touch (Overlap)         [ALIAS METHOD] ║
# ╟───────────────────────────────────────────────────────────────────────────╢
# ║ Disables touch events when driving the Land Vehicle, including teleports. ║
# ╚═══════════════════════════════════════════════════════════════════════════╝
  alias :wc_land_vehicle_check_touch_event :check_touch_event
    def check_touch_event
    unless COOLIE::VEHICLE::VEHICLE_TOUCH
      return false if in_boat?
    end
    wc_land_vehicle_check_touch_event
  end
  
# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║ Determine if Event Start Caused by OK Button (Action)      [ALIAS METHOD] ║
# ╟───────────────────────────────────────────────────────────────────────────╢
# ║ Disables "action button" events when driving the Land Vehicle.            ║
# ╚═══════════════════════════════════════════════════════════════════════════╝
  alias :wc_land_vehicle_check_action_event :check_action_event
    def check_action_event
    unless COOLIE::VEHICLE::VEHICLE_PRESS
      return false if in_boat?
    end
    wc_land_vehicle_check_action_event
  end
end # class Game_Player

class Game_Vehicle < Game_Character
# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║ Initialize Move Speed                                      [ALIAS METHOD] ║
# ╟───────────────────────────────────────────────────────────────────────────╢
# ║ Changes the player's movement speed when piloting the Land Vehicle.       ║
# ╚═══════════════════════════════════════════════════════════════════════════╝
  alias :wc_land_vehicle_init_move_speed :init_move_speed
  def init_move_speed
    wc_land_vehicle_init_move_speed
    @move_speed = COOLIE::VEHICLE::VEHICLE_SPEED if @type == :boat
  end
  
# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║ Get On                                                     [ALIAS METHOD] ║
# ╟───────────────────────────────────────────────────────────────────────────╢
# ║ Handles the functions of the vehicle when entering it.                    ║
# ╚═══════════════════════════════════════════════════════════════════════════╝
  alias :wc_land_vehicle_get_on :get_on
    def get_on
    wc_land_vehicle_get_on
    @step_anime = COOLIE::VEHICLE::STEP_ANIM
    end
end # class Game_Vehicle