#==============================================================================#
#                       RK5's Custom Scrolling Text Speed                      #
#==============================================================================#
#                           Author:  Rikifive                                  #
#                           For:     RPGMAKER VX ACE                           #
#                           Version: 1.0                                       #
#------------------------------------------------------------------------------#
# -=[ VERSION HISTORY ]=-                                                      #
#------------------------------------------------------------------------------#
#  2015-11-25 -> Version 1.0                                                   #
#             - Release                                                        #
#------------------------------------------------------------------------------#
# -=[ DESCRIPTION ]=-                                                          #
#------------------------------------------------------------------------------#
# This script allows you to tweak the scrolling text's speed more precisely.   #
# By default, in editor you can choose the speed ranged from 1 to 8.           #
# Sometimes, the slowest one may be still too fast, so there you can adjust    #
# it to your needs.                                                            #
# It basically allows you to adjust these 8 pre-configured speed variations.   #
#------------------------------------------------------------------------------#
# -=[ USAGE ]=-                                                                #
#------------------------------------------------------------------------------#
# This script is Plug & Play                                                   #
#------------------------------------------------------------------------------#
# -=[ INSTRUCTIONS ]=-                                                         #
#------------------------------------------------------------------------------#
# In the configuration, you'll find 8 speed variations, that are connected     #
# with the Event Editor.                                                       #
# By default, they are set to their original values, but you can adjust them   #
# one-by-one.                                                                  # 
#------------------------------------------------------------------------------#
# -=[ TERMS OF USE ]=-                                                         #
#------------------------------------------------------------------------------#
# -[ NON-COMMERCIAL use ]-                                                     #
#   Free; No credit requirement, let's be honest - this is a tiny script,      #
#   that doesn't change much.                                                  #
#   Nevertheless, if you'd be kind enough to credit me, then just put          #
#   "Rikifive" in the credits.                                                 #   
# -[ COMMERCIAL use ]-                                                         #
#   Free; No credit requirement. Same as above.                                #
# -[ REPOSTING ]-                                                              #
#   You ARE NOT allowed to repost this script. Link to it instead.             #
# -[ EDITING ]-                                                                #
#   You ARE allowed to edit this script to your needs, but to post edited      #
#   version anywhere, you need my permission.                                  #
# -[ PRESERVE THIS HEADER ]-                                                   #
#   Do not remove this header and claim this script as your own.               #
#   Also, it's longer than the script itself, so it's a nice decoration. ;)    #
#------------------------------------------------------------------------------#
# -=[ COMPATIBILITY ]=-                                                        #
#------------------------------------------------------------------------------#
# It basically should be compatible with almost everything.                    #
#==============================================================================#

module RK5_170513
  SP = Array.new(8)
  
  #----------------------------------------------------------------------------#
  # -=[ CONFIGURATION ]=-                                                      #
  #----------------------------------------------------------------------------#
  
  # Adjust speed for particular 'speed' value configurable in the Event Editor.
  # You can use float numbers like 0.2 to make it even slower.
  SP[0] = 1 # SPEED: 1
  SP[1] = 2 # SPEED: 2
  SP[2] = 3 # SPEED: 3
  SP[3] = 4 # SPEED: 4
  SP[4] = 5 # SPEED: 5
  SP[5] = 6 # SPEED: 6
  SP[6] = 7 # SPEED: 7
  SP[7] = 8 # SPEED: 8
  
  #----------------------------------------------------------------------------#
  # END OF CONFIGURATION                                                       #
  #----------------------------------------------------------------------------#
  
end

class Game_Interpreter
  #--------------------------------------------------------------------------
  # [OVERWRITE] Show Scrolling Text
  #--------------------------------------------------------------------------
  def command_105
    Fiber.yield while $game_message.visible
    $game_message.scroll_mode = true
    $game_message.scroll_speed = RK5_170513::SP[@params[0] - 1]
    $game_message.scroll_no_fast = @params[1]
    while next_event_code == 405
      @index += 1
      $game_message.add(@list[@index].parameters[0])
    end
    wait_for_message
  end
end