﻿#RogueDeus  15_0629
#Last Updated  15_0630
#RDeus - Surprise and Preempt Options v1.00

$imported = {} if $imported.nil?
$imported["RDeus-FTB-Plugin"] = true
puts("#{$imported.size}~ RDeus - Surprise and Preempt Options v1.00") if $TEST

=begin
CHANGELOG:
  v1.00 - Initial Release


CREDITS:
  - Hime of Hime Works: http://himeworks.com/
    For the constant advice and assistance.
    For writing the Troop Surprise Condition script, way way way back when.


#===============================================================================
!!IMPORTANT NOTES!!    !!IMPORTANT NOTES!!    !!IMPORTANT NOTES!!
#-----------------------------------------------------------------------------

  #1) Preempt supersedes Surprise in all cases, except when surprise is guaranteed 
  and preempt is only a rate. Then preempt is ignored.


  #2) CURSES ALWAYS SUPERSEDE BENIFITS. 
  Thus if ANY actor is cursed to always be surprised, AND another (or the same)
  actor is blessed to NEVER be surprised, OR to ALWAYS preempt, the CURSE
  will always prevail and the party will ALWAYS be surprised. 
  So, make sure NO ONE is cursed. Or else...


  #3) When using custom formulas, the Party Ability: Raise Preempt, is NOT 
  automatically included. It must be included in your formula to have
  any effect!



#===============================================================================
Description:
#-----------------------------------------------------------------------------

 - Allows for guarantee Surprise and Preempt with switches.

 - Allows for temporary chance Surprise and Preempt with float variables.
    (Defined before encounter execution, reset after)

 - Allows for default formula override.

 - Allows for temporary chance Surprise and Preempt formulas.
    (Defined before encounter execution, reset after)

 - Allows for feature object traits to ADJUST non-guarantee surprise 
    and preempt rates.

 - Allows for 'cursed' feature objects (states, equips, etc) that guarantee
    no battle will ever preempt, or every battle will be a surprise. 
    Regardless of all other factors.
    (+)Cursed never preempt, overrides benefit raise preempt.
    (+)Cursed always surprise, overrides benefit never surprised.

#===============================================================================
# NOTE TAG - QUICK REFERENCE:
#-----------------------------------------------------------------------------

<preempt_adj: formula>    Feature Items
<surprise_adj: formula>   Feature Items
<never_preempt>           Feature Items
<always_surprised>        Feature Items


#===============================================================================
# PREEMPT:
#-------------------------------------------------------------------------------
  Applied only to Feature Items. (Actor, Enemy, Class, Equip, State)

  <preempt_adj: formula>

      troop_agi = (avg ENEMY agility)
      agi       = (avg PARTY agility)

      v = $game_variables
      s = $game_switches
      p = $game_party
      t = $game_troop

    Example: (Default RPGMaker Preempt Formula)
      ((agi >= troop_agi ? 0.05 : 0.03) * (raise_preemptive? ? 4 : 1))

    Any feature object will 'additively' effect the parties chance of 
    fighting a preemptive battle. This is then the party gets a free first 
    turn, without retaliation from enemies. 

    Thus, if one object has a +0.05 (+5%) and another has a -0.02 (-2%) 
    the total adjustment made to the total chance of preempt is (+3%). 

    Note: Because this is a PARTY based adjustment, the wearers stats are 
      not considered for formula results. For those so inclined, add whatever
      methods you wish to call, within the formula, to the Game_Party class 
      and you will be able to call them with the 'p' parameter. An example of
      such a method already available is 'agi' which would be called via
      'p.agi' (minus the apostrophes). It will return the parties AVG agility.

    Scripting Note: 
      Its best to use the 'p' parameter, despite the evaluation occurring
      inside the Game_Party class, as this may not always remain the case.
      To be safe, simply make sure to preface all such methods with the 'p'
      parameter.


#===============================================================================
# SURPRISE:
#-------------------------------------------------------------------------------
  Applied only to Feature Items. (Actor, Enemy, Class, Equip, State)

  <surprise_adj: formula>

      troop_agi = (avg ENEMY agility)
      agi       = (avg PARTY agility)

      v = $game_variables
      s = $game_switches
      p = $game_party
      t = $game_troop
    
    Example: (Default RPGMaker Surprise Formula)
      (cancel_surprise? ? 0 : (agi >= troop_agi ? 0.03 : 0.05))

    Any feature object will 'additively' effect the parties chance of 
    being surprised in battle. This is then the enemy gets a free first 
    turn, without retaliation from the party. 

    (See: PREEMPT, for identical use details and examples.)


#===============================================================================
# NEVER PREEMPT:
#-------------------------------------------------------------------------------
  Applied only to Feature Items. (Actor, Enemy, Class, Equip, State)

  <never_preempt> 

    Any noted object will completely prevent any battle from EVER being 
    preemptive for the party. No exceptions. 


#===============================================================================
# ALWAYS SURPRISED:
#-------------------------------------------------------------------------------
  Applied only to Feature Items. (Actor, Enemy, Class, Equip, State)

  <always_surprised> 

    Any noted object will guarantee that every battle is a surprise battle
    AGAINST the party. However, this can be ignored if the proper switch
    is enabled before hand. This is to allow authors to 'stage' a battle 
    where the party isn't surprised. For plot purposes. It can also be used
    as a convenient way to override the curse with a common event.


#===============================================================================
# SWITCHES AND VARIABLES:
#-------------------------------------------------------------------------------
  Below, is a list of constants that allow you to define which game switch(sw)
  or game variable(var * frm) is assigned for that specific task. 

  REMEMBER!!
  All rates are 0.0 -> 1.0 (0% through 100%) thus using an integer for a 
  rate will result in a 100% success every time. Be sure to ONLY use float
  values to represent rates. 

  #------------------------------------
  Formulas:
  #------------------------------------
  Formulas have access to the following parameters.
      
      troop_agi = (avg ENEMY agility)
      agi       = (avg PARTY agility)

      v = $game_variables
      s = $game_switches
      p = $game_party
      t = $game_troop


#-----------------------------------------------------------------------------

TODO:

 - XXXXX


#-----------------------------------------------------------------------------
=end

module RDeus
  module SupPreempt  #RDeus::SupPreempt::DISABLE_ADJUSTS_SW

    #--------------------------------------------
    #The multiple applied to the default Party Ability: Raise Preemptive
    #(Remember, this is applied to the TOTAL RATE. It is very powerful.)
    RAISE_PREEMPT = 2.0

    #The $game_switches that disables Party Ability: Cancel Surprise
    #(This is intended to be an override for PLOT based surprises.)
    DISABLE_CANCEL_SUPRISE_SW = 16

    #--------------------------------------------
    #The $game_switches that disables feature object accumulated 
    #adjustments to party rates.
    #(Such as a -10% Surprise rate. +5% Preempt rate... etc...)
    DISABLE_ADJUSTS_SW = 14
    #The $game_switches that disables feature object to CURSE the party
    #either always causing surprise, or never allowing preempt
    DISABLE_CURSES_SW = 15

    #--------------------------------------------
    #The $game_switches
    PREEMPT_SW = 9
    SURPRSIE_SW = 12

    #--------------------------------------------
    #The $game_varaibles that hold the percent rate of the selected option.
    # 
    #TEMP variable values are reset after each battle. Thus they do not
    #work well for random encounters, unless the rate is somehow re-defined
    #before each random encounter...
    # 
    #Use 'ALL_' or 'OVR_' versions to ensure every battle maintains the rate.
    #REMEMBER: Variables require float based rates. (0.1 = 10%)
    TEMP_PREEMPT_VAR = 41
    TEMP_SURPRSIE_VAR = 42

    #--------------------------------------------
    #The $game_varaibles that hold the string FORMULAS to be evaluated 
    #instead of the default or any overrides given below.
    #(This is done by using the 'script' option, in the variable assignment)
    #
    #TEMP variable values are reset after each battle. Thus they do not
    #work well for random encounters, unless the rate is somehow re-defined
    #before each random encounter...
    # 
    #Use 'ALL_' or 'OVR_' versions to ensure every battle maintains the rate.
    #REMEMBER: Formulas require float based rates. (0.1 = 10%)
    # troop_agi, p=$game_party, t=$game_troop, v=$game_variables, s=$game_switches
    TEMP_PREEMPT_FRM = 43
    TEMP_SURPRSIE_FRM = 44

    #--------------------------------------------
    #The $game_varaibles that holds the percent rate of the selected option.
    #ALL variables apply to ALL encounters not superseded with a TEMP value
    #or a switch guarantee. It will apply until it is reset to 0. At which
    #time, normal override and default formula based rates are used.
    #REMEMBER: Variables require float based rates. (0.1 = 10%)
    ALL_PREEMPT_VAR = 37
    ALL_SURPRSIE_VAR = 38

    #--------------------------------------------
    #Custom Formulas that override default formulas. 
    # troop_agi, p=$game_party, t=$game_troop, v=$game_variables, s=$game_switches
    #
    #"(agi >= troop_agi ? 0.05 : 0.03) * (raise_preemptive? ? 4 : 1)"
    OVR_PREEMPT = ""
    #
    #"cancel_surprise? ? 0 : (agi >= troop_agi ? 0.03 : 0.05)"
    OVR_SURPRISE = ""
  end
end


#-----------------------------------------------------------------------------
#-----------------------------------------------------------------------------
# BEYOND HERE THERE BE DRAGONS!!!
#-----------------------------------------------------------------------------
#-----------------------------------------------------------------------------


#===============================================================================
#
#===============================================================================
module RDeus
  #-----------------------------------------------------------------------------
  # RDeus.cache_sup_pre(object, method_symb, lambda)
  #-----------------------------------------------------------------------------
  def self.cache_sup_pre(object, method_symb, lambda)
    @cache_sup_pre ||= {}
    @cache_sup_pre[object] ||= {}
    return @cache_sup_pre[object][method_symb] ||= eval(lambda)
  end
end


#===============================================================================
# 
#===============================================================================
class RPG::BaseItem
  #-----------------------------------------------------------------------------
  # new: 15_0629
  # <preempt_adj: formula>
  # - Flat rate adjustment to preempt.
  #-----------------------------------------------------------------------------
  def preempt_adjust(p=$game_party, t=$game_troop, v=$game_variables, s=$game_switches)
    if @preempt_adjust_form.nil?
      @note =~ /<preempt[-_ ]?adj:\s*(.*)\s*>/i 
      @preempt_adjust_form = "lambda {|p,t,v,s| #{$1 ? $1 : "0.0"} } "
    end
    return RDeus.cache_sup_pre(self, :preempt_adjust, @preempt_adjust_form).call(p,t,v,s)
  end
  #-----------------------------------------------------------------------------
  # new: 15_0629
  # <surprise_adj: formula>
  # - Flat rate adjustment to surprise.
  #-----------------------------------------------------------------------------
  def surprise_adjust(p=$game_party, t=$game_troop, v=$game_variables, s=$game_switches)
    if @surprise_adjust_form.nil?
      @note =~ /<surprise[-_ ]?adj:\s*(.*)\s*>/i 
      @surprise_adjust_form = "lambda {|p,t,v,s| #{$1 ? $1 : "0.0"} } "
    end
    return RDeus.cache_sup_pre(self, :surprise_adjust, @surprise_adjust_form).call(p,t,v,s)
  end
  #-----------------------------------------------------------------------------
  # new: <always_surprised>
  #-----------------------------------------------------------------------------
  def always_surprised?
    return @always_surprised if !@always_surprised.nil?
    @note =~ /<(always[-_ ]?surprised)>/i 
    @always_surprised = $1 ? true : false
    return @always_surprised
  end
  #-----------------------------------------------------------------------------
  # new: <never_preempt>
  #-----------------------------------------------------------------------------
  def never_preempt?
    return @never_preempt if !@never_preempt.nil?
    @note =~ /<(never[-_ ]?preempt)>/i 
    @never_preempt = $1 ? true : false
    return @never_preempt
  end
end


#===============================================================================
# 
#===============================================================================
module BattleManager
  class << self
    alias :on_encounter_rdspo :on_encounter
    alias :battle_start_rdspo :battle_start
    # alias :rate_preemptive_rdspo :rate_preemptive
    # alias :rate_surprise_rdspo :rate_surprise
  end

  #-----------------------------------------------------------------------------
  # self.alias: 15_0630
  # - To ensure surprise and preempt are processed even during events.
  #-----------------------------------------------------------------------------
   def self.battle_start
     on_encounter
     battle_start_rdspo
   end

  #-----------------------------------------------------------------------------
  # self.alias: 15_0629
  #-----------------------------------------------------------------------------
  def self.on_encounter
    on_encounter_rdspo
    @preemptive = determine_preempt
    @surprise = determine_surprsie
    $game_party.clear_temp_pre_var #To make sure its 'reset' each time its wanted.
    $game_party.clear_temp_sup_var
  end

  #-----------------------------------------------------------------------------
  # new: 15_0629
  #-----------------------------------------------------------------------------
  def self.determine_preempt
    #If we are cursed, preempt rate is ALWAYS ignored.
    return false if $game_party.always_surprised? || $game_party.never_preempt?
    return true if $game_switches[RDeus::SupPreempt::PREEMPT_SW]
    #If we are guaranteeing surprise, preempt rate should be ignored.
    return false if $game_switches[RDeus::SupPreempt::SURPRSIE_SW]
    puts("\n  Preempt Rate: #{rate_preemptive}")
    return (rand < rate_preemptive)
  end

  #-----------------------------------------------------------------------------
  # new: 15_0629
  #-----------------------------------------------------------------------------
  def self.determine_surprsie
    return false if @preemptive
    #cursed surprise overrides benefit never surprised.
    return true if $game_party.always_surprised?

    unless $game_switches[RDeus::SupPreempt::DISABLE_CANCEL_SUPRISE_SW]
      return false if $game_party.cancel_surprise?
    end

    return true if $game_switches[RDeus::SupPreempt::SURPRSIE_SW]
    puts("  Surprise Rate: #{rate_surprise}")
    return (rand < rate_surprise)
  end

  #-----------------------------------------------------------------------------
  # self.alias: 15_0629
  #-----------------------------------------------------------------------------
  # def self.rate_preemptive
  #   $game_party.rate_preemptive($game_troop.agi)
  # end

  #-----------------------------------------------------------------------------
  # self.alias: 15_0629
  #-----------------------------------------------------------------------------
  # def self.rate_surprise
  #   $game_party.rate_surprise($game_troop.agi)
  # end
end


#===============================================================================
# 
#===============================================================================
class Game_Party < Game_Unit
  #-----------------------------------------------------------------------------
  # alias: 15_0629
  #-----------------------------------------------------------------------------
  alias :rate_preemptive_rdspo :rate_preemptive
  def rate_preemptive(troop_agi)
    if raise_preemptive?
      raise_pre = RDeus::SupPreempt::RAISE_PREEMPT
    else
      raise_pre = 1.0
    end

    return temp_pre_var * raise_pre if temp_pre_var > 0.0
    return all_pre_var * raise_pre  if all_pre_var > 0.0
    return eval_preempt(troop_agi) #raise preempt should be included in formula!
  end

  #-----------------------------------------------------------------------------
  # new: 15_0629
  #-----------------------------------------------------------------------------
  def eval_preempt(troop_agi, p=$game_party, t=$game_troop, v=$game_variables, s=$game_switches)
    if !($game_variables[RDeus::SupPreempt::TEMP_PREEMPT_FRM]).is_a?(String)
      $game_variables[RDeus::SupPreempt::TEMP_PREEMPT_FRM] = 
        ($game_variables[RDeus::SupPreempt::TEMP_PREEMPT_FRM]).to_s 
    end

    unless ($game_variables[RDeus::SupPreempt::TEMP_PREEMPT_FRM]).empty?
      return eval($game_variables[RDeus::SupPreempt::TEMP_PREEMPT_FRM]) + adj_preempt
    else
      if (RDeus::SupPreempt::OVR_PREEMPT).empty?
        #(agi >= troop_agi ? 0.05 : 0.03) * (raise_preemptive? ? 4 : 1)
        return rate_preemptive_rdspo(troop_agi) + adj_preempt
      else
        return eval(RDeus::SupPreempt::OVR_PREEMPT) + adj_preempt
      end
    end
  end

  #-----------------------------------------------------------------------------
  # alias: 15_0629
  #-----------------------------------------------------------------------------
  alias :rate_surprise_rdspo :rate_surprise
  def rate_surprise(troop_agi)
    return temp_sup_var if temp_sup_var > 0.0
    return all_sup_var  if all_sup_var > 0.0
    return eval_surprsie(troop_agi)
  end

  #-----------------------------------------------------------------------------
  # new: 15_0629
  #-----------------------------------------------------------------------------
  def eval_surprsie(troop_agi, p=$game_party, t=$game_troop, v=$game_variables, s=$game_switches)
    if !($game_variables[RDeus::SupPreempt::TEMP_SURPRSIE_FRM]).is_a?(String)
      $game_variables[RDeus::SupPreempt::TEMP_SURPRSIE_FRM] = 
        ($game_variables[RDeus::SupPreempt::TEMP_SURPRSIE_FRM]).to_s 
    end

    unless ($game_variables[RDeus::SupPreempt::TEMP_SURPRSIE_FRM]).empty?
      return eval($game_variables[RDeus::SupPreempt::TEMP_SURPRSIE_FRM]) + adj_surprise
    else
      if (RDeus::SupPreempt::OVR_SURPRISE).empty?
        #cancel_surprise? ? 0 : (agi >= troop_agi ? 0.03 : 0.05)
        return rate_surprise_rdspo(troop_agi) + adj_surprise
      else
        return eval(RDeus::SupPreempt::OVR_SURPRISE) + adj_surprise
      end
    end
  end

  #-----------------------------------------------------------------------------
  # new: 15_0629   
  #-----------------------------------------------------------------------------
  def allow_sup_pre_adj?
    return !$game_switches[RDeus::SupPreempt::DISABLE_ADJUSTS_SW]
  end

  #-----------------------------------------------------------------------------
  # new: 15_0630 disable 
  #-----------------------------------------------------------------------------
  def allow_sup_pre_cursed?
    return !$game_switches[RDeus::SupPreempt::DISABLE_CURSES_SW]
  end

  #-----------------------------------------------------------------------------
  # new: 15_0629  
  #-----------------------------------------------------------------------------
  def adj_preempt
    return 0.0 unless allow_sup_pre_adj?
    adjust = 0.0
    members.each{|member|
      member.feature_objects.each{|obj| adjust += obj.preempt_adjust}
    }
    return adjust 
  end

  #-----------------------------------------------------------------------------
  # new: 15_0629
  #-----------------------------------------------------------------------------
  def adj_surprise
    return 0.0 unless allow_sup_pre_adj?
    adjust = 0.0
    members.each{|member|
      member.feature_objects.each{|obj| adjust += obj.surprise_adjust}
    }
    return adjust
  end

  #-----------------------------------------------------------------------------
  # new: 15_0630
  #-----------------------------------------------------------------------------
  def always_surprised?
    return false unless allow_sup_pre_cursed?
    members.each{|member|
      member.feature_objects.each{|obj| return true if obj.always_surprised?}
    }
    return false
  end

  #-----------------------------------------------------------------------------
  # new: 15_0630
  #-----------------------------------------------------------------------------
  def never_preempt?
    return false unless allow_sup_pre_cursed?
    members.each{|member|
      member.feature_objects.each{|obj| return true if obj.never_preempt?}
    }
    return false
  end

  #-----------------------------------------------------------------------------
  # new: 15_0629
  #-----------------------------------------------------------------------------
  def temp_pre_var #(agi >= troop_agi ? 0.05 : 0.03) * (raise_preemptive? ? 4 : 1)
    return $game_variables[RDeus::SupPreempt::TEMP_PREEMPT_VAR] + adj_preempt
  end
  #-----------------------------------------------------------------------------
  # new: 15_0629
  #-----------------------------------------------------------------------------
  def all_pre_var
    return $game_variables[RDeus::SupPreempt::ALL_PREEMPT_VAR] + adj_preempt
  end

  #-----------------------------------------------------------------------------
  # new: 15_0629
  #-----------------------------------------------------------------------------
  def temp_sup_var #(agi >= troop_agi ? 0.05 : 0.03) * (raise_preemptive? ? 4 : 1)
    return $game_variables[RDeus::SupPreempt::TEMP_SURPRSIE_VAR] + adj_surprise
  end
  #-----------------------------------------------------------------------------
  # new: 15_0629
  #-----------------------------------------------------------------------------
  def all_sup_var
    return $game_variables[RDeus::SupPreempt::ALL_SURPRSIE_VAR] + adj_surprise
  end

  #-----------------------------------------------------------------------------
  # new: 15_0629
  #-----------------------------------------------------------------------------
  def clear_temp_sup_var
    $game_variables[RDeus::SupPreempt::TEMP_SURPRSIE_VAR] = 0.0
    $game_variables[RDeus::SupPreempt::TEMP_SURPRSIE_FRM] = ""
  end
  #-----------------------------------------------------------------------------
  # new: 15_0629
  #-----------------------------------------------------------------------------
  def clear_temp_pre_var
    $game_variables[RDeus::SupPreempt::TEMP_PREEMPT_VAR] = 0.0
    $game_variables[RDeus::SupPreempt::TEMP_PREEMPT_FRM] = ""
  end
end


#===============================================================================
#
#===============================================================================
# class Game_Interpreter
#   #-----------------------------------------------------------------------------
#   # default:
#   #-----------------------------------------------------------------------------
#   def command_301
#     return if $game_party.in_battle
#     if @params[0] == 0                      # Direct designation
#       troop_id = @params[1]
#     elsif @params[0] == 1                   # Designation with variables
#       troop_id = $game_variables[@params[1]]
#     else                                    # Map-designated troop
#       troop_id = $game_player.make_encounter_troop_id
#     end

#     if $data_troops[troop_id]
#       BattleManager.setup(troop_id, @params[2], @params[3])
#       BattleManager.event_proc = Proc.new {|n| @branch[@indent] = n }
#       $game_player.make_encounter_count
#       SceneManager.call(Scene_Battle)
#     end

#     Fiber.yield
#   end
# end