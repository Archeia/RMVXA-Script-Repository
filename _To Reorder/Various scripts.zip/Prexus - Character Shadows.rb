#==============================================================================
#
# ▼ Prexus Ace - Character Shadow
# -- Last Updated: 2012.10.04
# -- Level: Easy
# -- Requires: n/a
#
#==============================================================================

$imported = {} if $imported.nil?
$imported["PRX-CharacterShadow"] = true

#==============================================================================
# ▼ Updates
# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# 2012.10.04 - Added a way to give individual events a shadow or not by putting
#              a $ as the first character of the event name.
#              Note: If event shadows are turned ON by default, this will REMOVE
#              the shadow instead of adding it.
# 2012.04.05 - Fixed an issue with shadow sprites not disposing properly.
# 2012.04.03 - Added Default values for Player, Followers, and Events.
#              Also added some logic for hiding shadows when characters aren't
#              visible.
# 2012.04.02 - First Draft Complete
#
#==============================================================================
# ▼ Introduction
# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# This script will allow you to add a Shadow graphic underneath the player,
# followers, and any event you feel should have a shadow graphic.
#
#==============================================================================
# ▼ Instructions
# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# To install this script, open up your script editor and copy/paste this script
# to an open spot above Main.
#
# Each Game_CharacterBase and any object whose parent is Game_CharacterBase can
# have a shadow added under it's sprite by setting the shadow value to true.
#
# eg: To show the shadow graphic for the player, a Call Script such as
#   $game_player.shadow = true
# will add the shadow. Conversely,
#   $game_player.shadow = false
# will turn the shadow off.
#
# To turn the shadow ON/OFF for the player:
# $game_player.shadow = true/false
#
# To turn the shadow ON/OFF for the followers:
# $game_player.followers[index].shadow = true/false
#
# To turn the shadow ON/OFF for the events:
# $game_map.events[event_id].shadow = true/false
#
# This will also work for Followers (the 'Caterpillar' characters) and any
# map event.
#
# If Event Shadows are OFF by default, putting a $ as the first character in an
# event name will give it a shadow.
# If Event Shadows are ON by default, the $ character will remove the shadow.
#
#==============================================================================
# ▼ Compatibility
# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# This script is made for RPG Maker VX Ace and designed to be as modular as
# possible to avoid script conflicts. It is however possible that conflicts may
# occur with other scripts that make changes/use of the Game_CharacterBase or
# Sprite_Character.
#
#==============================================================================

module PRX
  module SHADOW
    
    #==========================================================================
    # ▼ Settings
    # =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    #
    # To use a shadow graphic other than the Shadow.png found in the System
    # cache, change the following:
    #==========================================================================
    SHADOW_GRAPHIC = "Shadow"             # The name of the Shadow file
    
    #==========================================================================
    # Change the following to have players, followers, or events use shadows
    # by default
    #==========================================================================
    DEFAULT_ON_PLAYER   = true            # Set to 'true' for default shadows
    DEFAULT_ON_FOLLOWER = false            # Set to 'true' for default shadows
    DEFAULT_ON_EVENT    = false            # Set to 'true' for default shadows
      
  end # SHADOW
end # PRX

class Sprite_Character < Sprite_Base
 
  #--------------------------------------------------------------------------
  # * alias method update
  #--------------------------------------------------------------------------
  alias :prx_shadow_sprite_character_update :update
  def update
    prx_shadow_sprite_character_update
    update_shadow
  end
 
  #--------------------------------------------------------------------------
  # * alias method dispose
  #--------------------------------------------------------------------------
  alias :prx_shadow_sprite_character_dispose :dispose
  def dispose
    dispose_shadow
    prx_shadow_sprite_character_dispose
  end
 
  #--------------------------------------------------------------------------
  # * start_shadow : draw and initialize
  #--------------------------------------------------------------------------
  def start_shadow
    dispose_shadow
    @shadow_sprite = ::Sprite.new(viewport)
    @shadow_sprite.bitmap = Cache.system(PRX::SHADOW::SHADOW_GRAPHIC)
    @shadow_sprite.z = self.z - 1
    @shadow_sprite.ox = 16
    @shadow_sprite.oy = -4
    update_shadow
  end
 
  #--------------------------------------------------------------------------
  # * update_shadow : validate, draw if necessary, adjust position, destroy
  #--------------------------------------------------------------------------
  def update_shadow
    if @character.shadow and !@character.transparent
      if @character.is_a?(Game_Follower) and !@character.visible?
        dispose_shadow if @shadow_sprite
        return
      end
      start_shadow unless @shadow_sprite
      @shadow_sprite.x = x
      @shadow_sprite.y = y - @shadow_sprite.height
      @shadow_sprite.z = z - 1
    else
      dispose_shadow if @shadow_sprite
    end
  end
 
  #--------------------------------------------------------------------------
  # * dispose_shadow : destroy
  #--------------------------------------------------------------------------
  def dispose_shadow
    if @shadow_sprite
      @shadow_sprite.dispose
      @shadow_sprite = nil
    end
  end
    
end # < Sprite_Character

class Game_CharacterBase
  #--------------------------------------------------------------------------
  # * Public Instance Variables
  #--------------------------------------------------------------------------
  attr_accessor :shadow                   # Character Shadow

  #--------------------------------------------------------------------------
  # * Initialize Public Member Variables
  #--------------------------------------------------------------------------
  alias :prx_shadow_game_characterbase_init_public_members :init_public_members
  def init_public_members
    prx_shadow_game_characterbase_init_public_members
    @shadow = PRX::SHADOW::DEFAULT_ON_PLAYER   if self.is_a?(Game_Player)
    @shadow = PRX::SHADOW::DEFAULT_ON_FOLLOWER if self.is_a?(Game_Follower)
    @shadow = PRX::SHADOW::DEFAULT_ON_EVENT    if self.is_a?(Game_Event)
    @shadow = false if @shadow.nil?
  end
 
end # < Game_CharacterBase

class Game_Event < Game_Character
  #--------------------------------------------------------------------------
  # * Public Instance Variables
  #--------------------------------------------------------------------------
  attr_reader :event_name
 
  #--------------------------------------------------------------------------
  # * Initialize
  #--------------------------------------------------------------------------
  alias :prx_shadow_game_event_initialize :initialize
  def initialize(*args)
    prx_shadow_game_event_initialize(*args)
    @event_name = @event.name.to_s
    shadow_symbol = @event_name[/^[\!\$]./]
    event_image = @character_name
    if shadow_symbol && shadow_symbol.include?('$') and find_proper_page != 0
      @shadow = (PRX::SHADOW::DEFAULT_ON_EVENT ? false : true)
    else
      @shadow = false
    end
    end
  end