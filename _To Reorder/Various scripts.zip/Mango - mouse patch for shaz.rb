  #--------------------------------------------------------------------------
  # * Mouse Grid Position
  #--------------------------------------------------------------------------
  def self.grid
    return nil if @pos.nil?
    mx, my = SceneManager.scene.instance_variable_get(:@spriteset).tilemap_offset
 
    x = (@pos[0] + mx) / 32
    y = (@pos[1] + my) / 32    
   
    #fix for widescreen resolutions
    x = (@pos[0] - (Graphics.width  - ($game_map.width * 32)) / 2) /
                                32 if ($game_map.width * 32) < Graphics.width
    y = (@pos[1] - (Graphics.height - ($game_map.height * 32)) / 2) /
                                32 if ($game_map.height * 32) < Graphics.height
    return [x, y]
  end