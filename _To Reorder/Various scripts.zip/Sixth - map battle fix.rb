# put it below the Map Battle and Map Objects scripts

class Spriteset_MapBattle < Spriteset_Battle
 
  attr_accessor :mobjs
 
  def create_viewports
    @mobjs = {}
    super
  end
 
  alias add_mobj_stuffs1111 dispose_characters
  def dispose_characters
    dispose_mobjs
    add_mobj_stuffs1111
  end
 
  alias add_mobj_stuffs2222 create_characters
  def create_characters
    load_mobjs
    add_mobj_stuffs2222
  end
 
  def load_mobjs
    $game_map.map_objs.each do |mobj|
      add_mobj(mobj)
    end
  end
 
  def add_mobj(dt,save=false)
    same = @mobjs.keys.select {|mky| mky.include?(dt['name']) }
    if same.empty?
      id = 0
    else
      sel = same.max_by {|mky|
        if mky =~ /#{dt['name']}_(\d+)/
          val = $1.to_i
        end
      }
      if sel =~ /#{dt['name']}_(\d+)/
        max_id = $1.to_i + 1
      end
      id = max_id
      max_id.times do |i|
        cky = dt['name'] + "_#{i}"
        next if @mobjs[cky]
        id = i
        break
      end
    end
    ky = dt['name'] + "_#{id}"
    dt['key'] = ky
    @mobjs[ky] = MapO::MapObj.new(dt,@viewport1)
    if save
      $game_map.map_objs << dt
      save_mobj_data
    end
  end
 
  def save_mobj_data
    file = sprintf(MapO::Data[:folder]+MapO::Data[:mdata],$game_map.map_id)
    save_data($game_map.map_objs,file)
  end
 
  alias add_mobj_stuffs1357 update_characters
  def update_characters
    add_mobj_stuffs1357
    update_mobjs
  end
 
  def update_mobjs
    @mobjs.each do |ky,sp|
      sp.update
      sp.upd_pos
    end
  end
 
  def dispose_mobjs
    @mobjs.each do |ky,sp|
      sp.bitmap.dispose
      sp.dispose
    end
    @mobjs = {}
  end

end