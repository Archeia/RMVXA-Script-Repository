#==============================================================================
# ■ Game_Interpreter
#==============================================================================
#
#
# How to add more:
# when "emotion"
#    emotion_id = variable value
#
# How to call?
#
# In a script call, put in 
# ["CharacterName", "Emotion"]
# example: ["Remius", "Angry"]
# to set to default emotion: ["CharacterName", ""]
# Example: ["Remius", ""] hell even ["Remius", "basbduaisd"]
#
#==============================================================================

class Game_Interpreter
  def emotion_manipulation_magic
    if $game_variables[4].is_a?(Array)
      case $game_variables[4][0]
      
      #------------------------------------------------------------------------
      # Remius
      #------------------------------------------------------------------------
      
      when "Remius"
        name_id = 1
        case $game_variables[4][1]
        when "Normal"
          emotion_id = 0
        when "Happy"
          emotion_id = 1
        when "Serious"
          emotion_id = 2
        else
          emotion_id = 0
        end
        
      #------------------------------------------------------------------------
      # Ralph
      #------------------------------------------------------------------------
      
      when "Ralph"
        name_id = 2
        case $game_variables[4][1]
        when "Normal"
          emotion_id = 0
        when "Happy"
          emotion_id = 1
        when "Serious"
          emotion_id = 2
        when "Sad"
          emotion_id = 3
        when "Jealous"
          emotion_id = 4
        when "Appalled"
          emotion_id = 5
        when "Blush"
          emotion_id = 6
        when "Angry"
          emotion_id = 7
        else
          emotion_id = 0
        end
        
      #------------------------------------------------------------------------
      # Sairen
      #------------------------------------------------------------------------
      
      when "Sairen"
        name_id = 3
        case $game_variables[4][1]
        when "Normal"
          emotion_id = 0
        else
          emotion_id = 0
        end
                
           
      #------------------------------------------------------------------------
      # Erik
      #------------------------------------------------------------------------
      
      when "Erik"
        name_id = 4
        case $game_variables[4][1]
        when "Normal"
          emotion_id = 0
        when "Happy"
          emotion_id = 1
        when "Serious"
          emotion_id = 2
        when "Eh"
          emotion_id = 5
        when "Blush"
          emotion_id = 6
        else
          emotion_id = 0
        end
      
      #------------------------------------------------------------------------
      # Naia
      #------------------------------------------------------------------------
      
      when "Naia"
        name_id = 5
        case $game_variables[4][1]
        when "Normal"
          emotion_id = 0
        when "Happy"
          emotion_id = 1
        else
          emotion_id = 0
        end

      else
        name_id = 0
      end
    else
      name_id = 0
      emotion_id = 0
    end
    $game_variables[2] = name_id
    $game_variables[3] = emotion_id
  end
end