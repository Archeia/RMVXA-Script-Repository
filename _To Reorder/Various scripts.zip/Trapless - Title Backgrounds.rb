#==============================================================================
# ** Script Name: Selection Relevant Title Backgrounds (subject to change)
#    Written by:  trapless
#    Created:     not yet..
#==============================================================================
# \\\\\____________________________/////
#  |||| BACKUP FILE BEFORE EDITING ||||      LINE 54 EDITS IMAGE SELECTION
# /////============================\\\\\       yeah yeah... hold on a sec..
#==============================================================================
# ** Edits: *Scene_Base*, *Scene_Title* and *Window_TitleCommand* via alias
#    to present highlighted command relevant title screen background images.
#    I made this so the command menu can slide up or down while keeping the
#    current selection at screen center.
#==============================================================================
#==============================================================================
  #--------------------------------------------------------------------------
  # * Might as well set highest resoulution...,
  # * because 320 x 240 won't play nice.           *sadface*
  # * Default = (544, 416) -----> ( 17x13 map tiles )
  #--------------------------------------------------------------------------
Graphics.resize_screen(640, 480) #( 20x15 map tiles )
#==============================================================================
  #--------------------------------------------------------------------------
  # * Setting up in-title scene background changing.
  #--------------------------------------------------------------------------
class Scene_Title < Scene_Base
  attr_accessor :ttlpicnum
  def ttlpicnum=(index)
  @ttlpicnum = index
  end
  alias trapless_srtb_st_cb_als create_background
  def update
    super
    if SceneManager.scene_is?(Scene_Title)
      if Input.trigger?(Input::UP) || Input.trigger?(Input::DOWN)
        @sprite1.bitmap = Cache.title1(@piclst[@ttlpicnum])
      end
    end
  end
  def create_background
    trapless_srtb_st_cb_als
  #--------------------------------------------------------------------------
  # * Set @piclst["1"] if player has a saved game.
  #--------------------------------------------------------------------------
    unless DataManager.save_file_exists?
      @ttlpicnum = 0
    else
      @ttlpicnum = 1
    end
  #--------------------------------------------------------------------------
  # * @piclst = ["0", "1", "2"] <-- Replace w/picture names in Titles1 folder.
  # * -DO NOT INCLUDE PICTURE EXTENSION IN NAME-
  #--------------------------------------------------------------------------
    @piclst = ["Begin", "Resume", "Quit"]
    @sprite1 = Sprite.new
    @sprite1.bitmap = Cache.title1(@piclst[@ttlpicnum])
  end
end
#==============================================================================
  #--------------------------------------------------------------------------
  # * Prevent windowskin load so only command text and background are drawn.
  #--------------------------------------------------------------------------
class Window_TitleCommand < Window_Command
  alias trapless_srtb_wtc_init_als initialize
  def initialize
    trapless_srtb_wtc_init_als
    self.windowskin = Cache.system("")
  end
  #--------------------------------------------------------------------------
  # * Prevent tacky command selection wrap. Delete this section if wrap wanted.
  #--------------------------------------------------------------------------
  def cursor_down(wrap = false)
    if index < 2
      select(index + 1)
      if SceneManager.scene_is?(Scene_Title)
        SceneManager.scene.ttlpicnum = index
      end
    end
  end
  def cursor_up(wrap = false)
    @ttlpicnum = Scene_Title.new
    if index > 0
      select(index - 1)
      if SceneManager.scene_is?(Scene_Title)
        SceneManager.scene.ttlpicnum = index
      end
    end
  end
  #--------------------------------------------------------------------------
  # * Vertically centering command window.
  # * self.y default = "(Graphics.height * 1.6 - height) / 2"
  #--------------------------------------------------------------------------
  def update_placement
    self.x = (Graphics.width - width) / 2
    self.y = (Graphics.height - height) / 2
  end
  #--------------------------------------------------------------------------
  # * Aligning command text to center of command window.  (0 = left, 2 = right)
  #--------------------------------------------------------------------------
  def alignment
    return 1
  end
  #--------------------------------------------------------------------------
  # * Show single command to allow shifting of command box via pictures.
  # * Default = 3  ( Delete this section do obtain default. )
  #--------------------------------------------------------------------------
  def visible_line_number
    return 1
  end
#==============================================================================
end
#==============================================================================
# #--------------------------------------------------------------------------
# # *CREDITS*
# # * DoubleX for showing me whats up with the attr_accessor in this script.
# # * Galv and Yanfly for enlightening me of RGSS capability with their scripts.
# # * DiamondandPlatinum3 and GubiD for facilitating my skills via tutorials.
# # * Coffee(drink) for keeping my eyes open and my blood pulsing.
# #--------------------------------------------------------------------------
# ** trpscripts = 1
#==============================================================================