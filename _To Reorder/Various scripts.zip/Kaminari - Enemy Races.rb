#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#   Brandon Kaminari: Enemy Races v1.0
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#   Use in Non-Commercial or Commercial, just credit me :)
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#   Place below Materials and over Main Process
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#   Instructions:
#   For your enemies, go to their note box and type in the following:
#   <Race: ???>
#   <Sub Race: ???>
#   (Where ??? is your desired race. Sub Race won't register until you have a main Race.
#   Then create your desired race in the Class Tab with the desired features.
#   WARNING: IT'S JUST THE FEATURES, NOT SKILLS
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
class RPG::Enemy < RPG::BaseItem
  def load_notetag_enemy_race
    regex = /<Race:\s*(\w*)\s*>/i
    @race_name = note =~ regex ? $1 : ""
    @races.push(@race_name)
  end
  
  def load_notetag_enemy_subrace
    sub_regex = /<Sub Race:\s*(\w*)\s*>/i
    results = note.scan(sub_regex) {|res|
      @race_name = note =~ sub_regex ? res : ""
      @races.push(@race_name[0])
    }
  end
end

class Game_Enemy < Game_Battler
  def load_notetag_enemy_race
    regex = /<Race:\s*(\w*)\s*>/i
    @race_name = enemy.note =~ regex ? $1 : ""
    @races.push(@race_name)
  end
  
  def load_notetag_enemy_subrace
    sub_regex = /<Sub Race:\s*(\w*)\s*>/i
    results = enemy.note.scan(sub_regex)
    results.each do |res|
      @race_name = enemy.note =~ sub_regex ? res : ""
      @races.push(@race_name[0])
    end
  end

  #--------------------------------------------------------------------------
  # * Get Array of All Objects Retaining Features
  alias bkami_add_race_stats_45ws   feature_objects
  #--------------------------------------------------------------------------
  def feature_objects
    return bkami_add_race_stats_45ws + race
  end
  
  def race
    return @race_array unless @race_array.nil?
    @race_array = []
    @races = []
    load_notetag_enemy_race
    load_notetag_enemy_subrace if @races.size != 0
    therace
    return @race_array
  end
  
  def therace
    @races.each do |whee|
      next unless whee != ""
      $data_classes.each do |whoo|
        next unless whoo
        @race_array.push(whoo) if whoo.name == whee
      end
    end
  end
  
end