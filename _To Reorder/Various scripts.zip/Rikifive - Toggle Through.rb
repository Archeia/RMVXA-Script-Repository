#===============================================================================
# NOCLIP SWITCH
# Author: Rikifive
#===============================================================================
# This little snippet allows you to toggle noclip with a switch.
# Turn this switch ON to allow the player to go through everything.
#
# Terms of use: Use it as you wish, it's just a tiny piece of code.
#-------------------------------------------------------------------------------

#===============================================================================
# CONFIGURATION
#===============================================================================
module RK5_238957
  # SET THE ID OF THE NOCLIP SWITCH
  NOCLIP_SWITCH = 100
end

#===============================================================================
# END OF CONFIGURATION
#===============================================================================

class Game_Player < Game_Character
  #-----------------------------------------------------------------------------
  # >>> [ALIAS] debug_through?
  # -> Implements Noclip Mode.
  #--------------------------------------------------------------------------
  alias :prev_debug_through? :debug_through?
  def debug_through?
    prev_debug_through? || $game_switches[RK5_238957::NOCLIP_SWITCH]
  end
end