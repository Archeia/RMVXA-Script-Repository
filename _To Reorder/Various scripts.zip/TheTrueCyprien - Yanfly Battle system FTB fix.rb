#==============================================================================
# 
# ▼ Bug Fix for Yanfly Engine Ace - Battle System Add-On: Free Turn Battle
# -- Last Updated: Dec 20, 2014
# -- Authors: TheTrueCyprien, TheoAllen, Yanfly(original script)
# -- Requires: Yanfly Engine Ace - Battle System Add-On: Free Turn Battle v1.02+
# 
#==============================================================================
# ▼ Description
# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# This script currently fixes the following bugs:
# 1. If LIMITED_ACTIONS_PER_MEMBER is disabled, the party member won't change if
# he spent all of his own actions.
# 2. If the last party member is killed by a counter attack or magic reflection,
# the game over message won't show up twice.
# 3. Status window will now properly show after troop events.
# 4. Enemies have now FTB actions as well, so AGI and FTB (de-)buffs will
# also work on them. However, you'll have to give the ftb points to them via 
# bonus actions or states as I haven't managed to make notetags working for
# them.
# If you find any other bug, message me and I might take a look.
# 
#==============================================================================
# ▼ Instructions
# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# To install this script, open up your script editor and copy/paste this script
# to an open slot below the actual Free Turn Battle script, but above ▼ Main. 
# Remember to save.
# 
#==============================================================================

#==============================================================================
# ■ Game_BattlerBase
#==============================================================================

class Game_BattlerBase

#--------------------------------------------------------------------------
# new method: ftb_item_conditions_met?
#--------------------------------------------------------------------------
def ftb_item_conditions_met?(item)
return true unless SceneManager.scene_is?(Scene_Battle)
return true unless BattleManager.btype?:ftb
return true if BattleManager.in_turn?
return $game_party.ftb_actions_remaining >= item.ftb_cost if actor?
return $game_troop.ftb_actions_remaining >= item.ftb_cost if enemy?
end

end # Game_BattlerBase

#==============================================================================
# ■ Game_Troop
#==============================================================================

class Game_Troop < Game_Unit

#--------------------------------------------------------------------------
# new method: ftb_actions_remaining
#--------------------------------------------------------------------------
def ftb_actions_remaining
return ftb_actions_maximum - ftb_actions_used
end

#--------------------------------------------------------------------------
# new method: ftb_actions_maximum
#--------------------------------------------------------------------------
def ftb_actions_maximum
n = 0
for member in $game_troop.members
next unless member.game_battlerbase_inputable_ftb
n += member.max_ftb_actions
end
return [n, YEA::FTB::MAXIMUM_FTB_ACTIONS].min
end

#--------------------------------------------------------------------------
# new method: ftb_actions_used
#--------------------------------------------------------------------------
def ftb_actions_used
n = 0
for member in $game_troop.members
next unless member.game_battlerbase_inputable_ftb
n += member.ftb_actions
end
return n
end

end # Game_Troop

#==============================================================================
# ■ Game_Enemy
#==============================================================================

class Game_Enemy

#--------------------------------------------------------------------------
# Overwrite method: make action times
#--------------------------------------------------------------------------
def make_action_times
max_ftb_actions
end

#--------------------------------------------------------------------------
# Overwrite method: max ftb action
#--------------------------------------------------------------------------
def max_ftb_actions
n = make_ftb_action_times
n += agi_bonus_max_ftb_actions
n += trait_bonus_max_ftb_actions
return [n, 1].max
end

end

class Scene_Battle

def end_ftb_action
if $game_party.inputable?
select_next_member
else
status_redraw_target(BattleManager.actor)
BattleManager.next_command
turn_start
end
$game_troop.make_actions
end

end # Game_Enemy

#==============================================================================
# ■ Scene_Battle
#==============================================================================

class Scene_Battle < Scene_Base 

#--------------------------------------------------------------------------
# overwrite method: perform_ftb_action
#--------------------------------------------------------------------------
def perform_ftb_action
hide_ftb_action_windows
@subject = BattleManager.actor
item = @subject.current_action.item
execute_action
process_event
loop do
@subject.remove_current_action
break if $game_troop.all_dead?
break unless @subject.current_action
@subject.current_action.prepare
execute_action if @subject.current_action.valid?
end
return if $game_troop.alive_members.size <= 0
process_action_end
@status_window.open
consume_ftb_action(item)
@subject.make_actions
@subject = nil
show_ftb_action_windows unless $game_party.all_dead?
end

#--------------------------------------------------------------------------
# overwrite method: next_ftb_member?
#--------------------------------------------------------------------------
def next_ftb_member?(last_index)
actor = BattleManager.actor
return true if actor.nil? || !actor.movable?
return false if $game_party.ftb_actions_maximum > actor.ftb_actions && !YEA::FTB::LIMITED_ACTIONS_PER_MEMBER
return false if actor.max_ftb_actions > actor.ftb_actions
return false if BattleManager.actor.index >= last_index
return BattleManager.actor.index != last_index
end

end #Scene_Battle

#==============================================================================
# 
# ▼ End of File
# 
#==============================================================================