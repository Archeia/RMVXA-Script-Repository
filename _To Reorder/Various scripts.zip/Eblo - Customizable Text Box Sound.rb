#==============================================================================
# ** Customizable Textbox Sound
# By Eblo (Vincent in some places)
#------------------------------------------------------------------------------
# Customizable EarthBound-styled textbox sound. I doubt I will release this.
#
# Versions:
#
# June 18, 2015     - First release.
# May 1, 2015       - Changed MsgSE to a hash containing multiple SEs for
#                     utility. Changed TextFrameSpace to a game variable
#                     because changing its value via script call sometimes made
#                     no sound play at all until a different window class was
#                     called.
# April 29, 2015    - Changed the entire pitch modulation so that all the MsgSE
#                     stuff is inside one array. Much cleaner, code is shorter.
# January 25, 2015  - Changed EndSE stuff to just one variable. MsgSE has to
#                     remain divided into multiple variables.
# December 20, 2014 - Added SE for the end of the message box, a la Zelda.
# October 23, 2014  - Fixed the randomness of the pitch to be proper.
# October 22, 2014  - Modulized the constants. Changed the textse_pitch global
#                     variable to a local variable.
# October 19, 2014  - Fixed modulation so as not to exceed SEMaxPitch.
# October 17, 2014  - First version. Basic necessary stuff. Added pitch
#                     modulation and frame spacing.
#==============================================================================

module TextSound
  MsgSE             = {
                      0 =>["Cursor1", 115, 65],
                      1 => ["Key", 135, 65],
                      }
  TextFrameSpaceVar = 12        #Frames between SE instances, determined by game variable
  UseSESwitch       = 3         #When this switch is on, textbox sounds are off.
  Var               = 11        #Variable to tell what SE to use
  EndSE             = "Saint3", 65, 100
  Range             = 15        #Range for pitch modulation
end

#==============================================================================
# no edit past here plz. or you can. just keep a backup.
#==============================================================================
class Window_Message < Window_Base
  #--------------------------------------------------------------------------
  # * Object Initialization
  #--------------------------------------------------------------------------
  alias initialize_sound initialize
  def initialize
    initialize_sound
    if $game_variables[TextSound::TextFrameSpaceVar] == 0
      $game_variables[TextSound::TextFrameSpaceVar] = 5
    end
  end
  #--------------------------------------------------------------------------
  # * Normal Character Processing (to use sounds and frame spacing)
  #--------------------------------------------------------------------------
  alias sound_text_play process_character
  def process_character(c, text, pos)
    sound_text_play(c, text, pos)
    unless $game_switches[TextSound::UseSESwitch]
      @text_se_space = 0 if @text_se_space == nil
      if @text_se_space == 0
        unless @show_fast || @line_show_fast
          unless SceneManager.scene_is?(Scene_Battle)
            textse_pitch = rand(TextSound::Range) - rand(TextSound::Range)
            textse_pitch = TextSound::MsgSE[$game_variables[TextSound::Var]][1] +
                           textse_pitch
            RPG::SE.new(TextSound::MsgSE[$game_variables[TextSound::Var]][0],
            TextSound::MsgSE[$game_variables[TextSound::Var]][2],
            textse_pitch).play
          end
        end
      end
      @text_se_space += 1
      @text_se_space = 0 if @text_se_space == $game_variables[TextSound::TextFrameSpaceVar]
    end
    if text.empty?
      RPG::SE.new(*TextSound::EndSE).play
    end
  end
end