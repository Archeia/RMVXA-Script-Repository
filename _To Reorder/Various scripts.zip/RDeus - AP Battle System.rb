﻿#RogueDeus  15_0619
#Last Updated  16_0225
#RDeus - AP Battle System v1.04.3

$imported = {} if $imported.nil?
$imported["RDeus-AP-BattleSystem"] = true
puts("#{$imported.size}~ RDeus - AP Battle System v.1.04") if $TEST

=begin
#-------------------------------------------------------------------------------
TODO:
  - Add individual point initiative adjustments to feature objects.
    (+)Support custom param! INI = initiative!
      Will factor in nimble & clumsy into its total.

  - Allow for guaranteed preempt round if all party members are under a 
    specific state. Such as invisible.
    (+)The chance can change, based on the enemy. Have chances of seeing 
      through such states? Such as a blind enemy, immune to invisible preempt.
      Etc...

  - Include my 'Battle Menu Plugin' fix.

  - Attempt to display results of AP use before they are used. 
    (+)Since AP's are displayed during skill selection, they should be able
      to update upon selection change to indicate cost of ability use.

  - Add <instant> note tag, for ease of use. Equivalent to <ap: 0>

MAYBE:

  - Allow actions to restore (and temporary hold) and remove AP from targets.
    (+)States can already grant bonus AP in a battle.
    (+)Actions that restore AP, should be self only.
    (+)Actions that remove AP, should function like damage.

  - Allow for AP removal resistance. 
    (+)Ignores X AP when an action attempts to remove them.

  - Dynamic AP costs for qualified abilities. 
    (+)Much like usable item restrictions

  - Allow for Surprise/Preempt rounds to have attacker bonus AP? 
    (+)Amount definable via note tag. Or default +1AP? 

  - Actions that do not have a minimum AP cost, but still consume AP. 
      This way some actions can be used regardless of available AP, and then
      consume whatever AP's it can. Possibly even adjusting its effect to
      match the number of AP used.

  - Command: ASSIST
    (+)Skill that boosts the targets initiative to help ensure it acts sooner.

  - Command: OBSTRUCT
    (+)Skill that reduces the targets initiative to help ensure it acts later.



CHANGELOG:
  v1.00 - Initial Release

  v1.01 -----------------------------------------
    - Ensured surprise & preempt messages display when true.
    - Removed dependency on Hime's Command Manager. (Now Optional)
    - Misc housekeeping.

  v1.02 -----------------------------------------
    - Fixed a 'Pass Turn' Bug, caused by inadequate action clearing.
    - Fixed visible glitch when enemies acted first on first turn.
    - Fixed hitching in 'left' access to party command menu.
    - Actors now lose Initiative on Delay. Unless disabled. (See: details)
      (Implementation still getting tweaked.)
    - Added 'Pass' & 'Delay' popups.

  v1.03 -----------------------------------------
    - Added 'AP Schedules' for Enemies.
    - Added MAX_AP_MULTI for customizing default MAX AP.
    - Added NEW TURN popup.
    - Added SURPRSIE TURN popup.
    - Fixed 'on_turn_end' issue with 'Pass Turn'
    - Added 'BattleManager.surprise?' event script call.
    - Added Support for Yanfly - Combat Log script.
    - Added 'Delay' and 'Pass Turn' reporting to battle log.
    - Fixed 'next_command' bug regarding 'actor.movable?'

  v1.04 -----------------------------------------
    - Fixed NEW TURN popup on dead battlers BUG.
    - Fixed BattleManager.next_command BUG causing enemy actions to not
      clear next_command correctly, if confused.
  v1.04.1
    - Added CLOSE_ACTOR_COMMAND_ON_ACT option to support LUNA Engine.
    - Fixed irritating actor command flicker on turn end.
  v1.04.2
    - Added popup hold & fade support. (Req: RDeus - Popup Details)
    - Added pre-load methods.
    - Fixed Rare confusion removal conflict in 'Scene_Battle.next_command'
    - Added Pass Turn Initiative BONUS option.
  v1.04.3
    - Fixed rare bug when all actors are permanently non-movable and turn ends.
      Causing infinite net turns!

#===============================================================================

KNOWN ISSUES:
  - None at the moment!

REQUIRES:
  - Yanfly's Battle Engine.
  - Some note-tag use. (otherwise it will not work) !!READ BELOW!!

SUPPORTS:
  - Yanfly's Battle Core.
  - Yanfly's Combat Log.
  - Hime Command Manager: www.himeworks.com/2014/10/command-manager/
    (If you wish to move the actor commands location in command list)
  - RDeus - Popup Details

CREDITS:
  - Hime of Hime Works: http://himeworks.com/
    For the constant advice and assistance.

  - Yanfly of https://yanflychannel.wordpress.com/
    For the basic battle mechanic this plugs into.
    And the FTB plugin I stole some code from. :)


#===============================================================================
# Description:
#-------------------------------------------------------------------------------

  - Every battler has a number of AP that can be used every battle turn.

  - Almost all actions require some kind of AP cost to use. As long as the
    battler has the AP, they can repeat any number of actions. 

  - If a battler runs out of AP, the next battler acts. 

  - If a battler has AP they can not use (all actions require more AP than 
    they currently have) they can 'Pass Turn'

  - Using the 'Pass Turn' option before using any AP, carries over 
    approximately 60% of the battlers total AP, into the next turn. 
    This allows for the use of much higher AP actions.

  - A battler (actor) can 'Delay' their action, allowing the next actor
    to complete their actions, before taking their own actions. The 
    consequence is not knowing who the next actor is. 

#===============================================================================
# NOTE TAG - QUICK REFERENCE:
#-------------------------------------------------------------------------------
<ap: formula>             Usable Items
<ap_adjust: formula>      Feature Items
<ap_max_adjust: formula>  Feature Items
<nimble>                  Feature Items
<clumsy>                  Feature Items

*** Hime - Command Manager ONLY ***
<cmd: pass>               Actor or Class Only (See Hime - Command Manager!)
<cmd: delay>              Actor or Class Only (See Hime - Command Manager!)


#===============================================================================
# SCRIPT CALLS - QUICK REFERENCE:
#-------------------------------------------------------------------------------

BattleManager.surprise?   Event Scripts (returns false unless encounter was 
                                          a surprise)


#===============================================================================
# ACTION POINTS (AP):
#-------------------------------------------------------------------------------
  
  #------------------------------------
  ACTION AP COSTS:
  #------------------------------------
  Applied only to Usable Items. (Skills, Items)

  <ap: formula>

      a = battler.self (the battler acting)
      v = $game_variables
      s = $game_switches
      p = $game_party
      t = $game_troop

    The default BASE cost of all actions without note-tags is (3). 

    Guidelines are:
      0 AP = Instant Action (Extremely limited in use, such as rare items.)
        Note: Instant actions completely BREAK game balance. Use cautiously.

      1 AP = Quick Action   (Should be limited to limited SELF only actions.)
      2 AP = Partial Action (Intended for Item use, and SELF only actions.)

      3 AP = Full Action    (All actions that effect other battlers.)

      4 AP = Slow Action    (Intended for extra powerful effects.)
      5 AP = V.Slow Action  (Intended for RARE extra powerful effects.)

    Note: 
      The above guidelines are based on the DEFAULT values for Battler AP
      and action Cost. However, changing the defaults will make these 
      guidelines pointless. Thus, all AP defined note tags utilize 
      value formulas for such flexibility.


  #------------------------------------
  BATTLER BASE AP:
  #------------------------------------
  Applied only to Feature Items. (Actor, Enemy, Class, Equip, State)

  <ap_adjust: formula>

      a = battler.self (the battler acting)
      v = $game_variables
      s = $game_switches
      p = $game_party
      t = $game_troop

    All battlers being equal, have a base of 3 AP to use every turn. However, 
    this can change due to the addition of any feature object with AP 
    Adjustments. (Such as a state, or class, or piece of equipment)


  #------------------------------------
  BATTLER MAXIMUM AP:
  #------------------------------------
  Applied only to Feature Items. (Actor, Enemy, Class, Equip, State)

  <ap_max_adjust: formula>

      a = battler.self (the battler acting)
      v = $game_variables
      s = $game_switches
      p = $game_party
      t = $game_troop

    Battlers are limited to a default maximum AP of (10) in a single turn.
    This can be changed like all other limits. However, its hard to justify
    why a battler would be able to perform more than THREE FULL ACTIONS in
    a single turn... Unless under extremely rare haste effects.


  #------------------------------------
  ENEMY AP SCHEDULES:
  #------------------------------------
  Applied only to Enemies.

  <ap_schedule: schedule>
  
      Replace 'schedule' with the string name of the schedule you create
      inside the options area below.

    Enemy AP Schedules, are very powerful overrides for default AP behavior.
    The value in the schedule is the 'base' value the enemy will have for
    that turn of battle. It will still receive all normal AP adjustments 
    from feature items (listed above).

    Example:
      In the options section you'll find the below hash constant.

      AP_SCHEDULES = {
        :default      => [],
        :test         => [3,4,3]
      }

      Each array [#,] represents a chance to act for every enemy assigned 
      that schedule. (starting with the very first action) 

      The turn on which the first action occurs, will change if the enemy 
      happens to have been preemptively attacked, or is benefiting from 
      surprise. (Just think of each turn as CHANCES TO ACT.)

      In the 'test' schedule, the battler will always get at least 4 AP,
      with any adjustments added to it, on its second chance to act, its
      fifth chance, its eighth chance, etc... As the array repeats until
      the battler dies. 

      Note: An actor unable to move (stun, etc) LOSES their chance to act
        that turn! The chance to act in the array is still tracked, and
        the battler will resume right were they would be if they had been
        able to move all along. 


#===============================================================================
# INITIATIVE:
#-------------------------------------------------------------------------------

  #------------------------------------
  ORDER OF ACTION: (Initiative)
  #------------------------------------
    Initiative is determined dynamically at the beginning of every turn.

    Every battler is assigned an initiative based on that battlers Finesse
    (aka: Agility or AGI) with a slight bias based on whether the battler 
    is above or below the battlefield finesse average, and its Ingenuity 
    (aka: Luck or LUK) as compared to the average of all battler's 
    Ingenuity.

    In essence, if a battler has greater than average finesse, its initiative 
    has less variation (positive or negative) randomization, but it is also
    less effected by its ingenuity. But, if a battler has average or 
    lower than average finesse, its initiative variation is slightly MORE
    randomized and its MORE effected by ingenuity. This way, even extremely 
    superior targets have at least some chance of being beaten to the punch. 

  #------------------------------------
  FOOTING!
  #------------------------------------
  Applied only to Feature Items. (Actor, Enemy, Class, Equip, State)

  <nimble>
  <clumsy>

    Flagging a feature object as nimble, will grant a +1 Footing, while
    flagging it clumsy will grant a -1 Footing. The total of which is 
    applied to the final initiative of the battler.

    Ex: A footing of -2 is by default -20% of the average finesse of the
      battlefield, applied to that battlers final initiative. So, if 10% 
      of the battlefield avg finesse is 1, and the battlers total
      initiative was to be a 10, it becomes an 8. Due to the battlers 
      footing.


  #------------------------------------
  PASS TURN (Battle Command)
  #------------------------------------
  Applied only to Actor or Class objects. 

  <cmd: pass>

    Has two uses. First, it allows the battler to end its turn if it can no
    longer act, such as when all its actions requiring more AP than it has 
    to use. Second, it allows an actor that has not taken any AP consuming 
    action (instant actions do not use AP!) to 'save' roughly half of its 
    total AP and carry it over into its next turn. 

    By default, 50% (rounded down) of the battlers AP is saved. Thus if a 
    battler has 3 AP, 2 AP will carry over. If that same battler had 4 AP,
    still only 2 AM will carry over.

    <ap_max_adjust: formula>

    Note: The total AP that a battler can 'accumulate' this way is limited
      by their AP CAP and adjusted by any feature objects with any AP Max
      Adjustments. 

    Note: The AP carried over is based on the 'total' AP of the battler at
      the time of passing the turn. Thus, there is a diminishing return as
      this total increases. It is always most efficient to pass only ONE 
      turn before acting. 

  #------------------------------------
  DELAY (Battle Command)
  #------------------------------------
  Applied only to Actor or Class objects. 
  
  <cmd: delay>

    This simply 'pauses' the current actors turn, and allows the next most 
    battler to act instead. It can be done at any time, even if the actor
    has already acted and consumed AP. 

    As long as an actor has AP to spend they can Delay its use until the 
    very end of the turn.

  #------------------------------------
  NEW TURN! (Popup)
  #------------------------------------

    By default this popup uses the "DURSTATE" rule in Yanfly's Battle Engine
    POPUP_RULES hash. If you wish to change its size, color, etc... Simply
    change that rules details. 

    Or, if you wish, you can add your own rule, and change the string called
    for the popup rule.

  #------------------------------------
  SURPRISE SCRIPT CALL
  #------------------------------------
    
    Intended for use inside a troop event as a conditional. This way you can
    check to see if the battle is a surprise, in order to execute an event
    on that turn. Such as a tutorial, or plot trigger.
    
    BattleManager.surprise?

    Simply add the above script call in the 'script' section of a conditional
    branch of an event.


#===============================================================================
# IMPORTANT!!!:
#-------------------------------------------------------------------------------

  #------------------------------------
  EFFECT DURATIONS:
  #------------------------------------

    Due to the 'fluid' way that turns process in this system, effects such as 
    'Guard' might have significantly limited utility. It is suggested that for
    those types of 'one turn' fire and forget type effects, you change their
    Auto-removal Timing: from Turn End, to Action End. 

    Be sure to keep in mind that such effects will remain active on the 
    character until they 'ACT'. Thus 'Dealy' will NOT trigger Action End 
    processing!! Effectively, it allows for a guarding character 
    to stay guarded while they wait out the current turn. 'Pass Turn' however
    does trigger Action End normally. This way, total 'turn' durations for 
    Action End triggers remains standard. 




#-------------------------------------------------------------------------------


=end
module RDeus
  module APCombat  #RDeus::APCombat::CLOSE_ACTOR_COMMAND_ON_ACT

    DISSABLE_HIME_COMMAND_MANAGER = false
    CLOSE_ACTOR_COMMAND_ON_ACT = false

    #--------------------------------------------
    #This is the popup rule used for new turn indications.
    NEW_TURN_RULE = "DURSTATE"
    #Note: For reference the settings I use are:
    #[   2.50,   1.0, 18, true,  false, 255,   0,   0, DEFAULT]
    NEW_TURN_TEXT = "NEW TURN!"

    #This is the popup rule used for new turn indications.
    SUP_TURN_RULE = "DURSTATE"
    #
    SUP_TURN_TEXT = "!!SURPRISE TURN!!"

    #--------------------------------------------
    ICON_ACTION = 187      # Icon displayed when there are actions left.
    ICON_EMPTY  = 185      # Icon displayed to indicate a used action.

    #--------------------------------------------
    #The default AP for a battler without custom assignments.
    BATTLER_AP = 3

    #The default MAX AP of a battler, as a multiple of that battlers
    #initial AP. Including initial AP adjustments. 
    #Ex: Init = 3, adj + 0, Max = ((3+0) * 1.35).to_i or (4.05) = 4
    #Ex: Init = 3, adj + 3, Max = ((3+3) * 1.35).to_i or (8.10) = 8
    #Note: Regardless, MAX AP will never be less than a battlers initial AP.
    MAX_AP_MULTI = 1.35

    #The absolute maximum AP a battler can have. No exceptions.
    AP_CAP = 10

    #The default base AP cost of actions without defined formulas.
    COST_BASE = 3

    #--------------------------------------------
    #This enables any battler that passes a turn with at least 1 AP remaining
    #to gain a bonus to next turns initiative. 
    PASS_TURN_INIT = true

    #The rate applied to passed turn initiative. (if true)
    #1.3 = 125% or +25% of the battlers effective init.
    #Result is rounded UP.
    PASS_INIT_RATE = 1.25

    #--------------------------------------------
    #Setting this TRUE, will prevent actors from losing initiative when
    #selecting delay. 
    # 
    #Note: Initiative loss was added to prevent a full party of very fast
    #actors from 'delay' dancing their way through all of their AP before
    #enemies could even act. This way, there was a good chance that given
    #enough delays, an enemies action would sneak in.
    DISSABLE_DELAY_INIT_LOSS = false
    #The amount of initiative (speed) lost when delaying.
    INIT_LOST = 1
    #The chance of losing double... Delaying to often, has consequences.
    DOUBLE_LOSS_RATE = 0.25

    #Note: Disabling init loss on delay WILL regularly result in moments
    #where the next two battlers to act are ACTORS, and this they will
    #be able to 'act' and 'delay' into each other, repeatedly, until
    #all their AP is gone. Kind of defeating the purpose of initiative 
    #all together. So be warned.

    #--------------------------------------------
    #The percentage adjustment applied to the battlers initiative, for each
    #value (positive or negative) of footing. 
    #(Based on scene's total finesse average)
    FOOTING = 0.1

    #The variance assigned battlers with greater than average finesse. 
    #This value is tighter, to prevent greater negative results. 
    H_AMP = 0.25

    #The variance assigned battlers with lower than average finesse. 
    #(The large variance allows for rare overlap with high finesse battlers.)
    L_AMP = 0.33

    #Note: To make ALL battlers use the same variance, simply make H_AMP 
    #   and L_AMP the same value. But do not make them ZERO, or there 
    #   will be NO randomization of speed values. Battlers will act 100%
    #   in order of their totals, in every battle. 
    #   
    #   Conversely making them 1.0 will make all speed totally random, 
    #   regardless of total initiative. However, higher finesse battlers 
    #   will still have a greater potential result.

    #--------------------------------------------
    #The total of the resulting ingenuity adjustment to apply to speed.
    #(Making this 0, will base speed on only finesse and footing)
    ING_RATE = 1.0

    #The % of avg battlefield ingenuity to reduce from adjustments for 
    #higher than average finesse battlers. Higher finesse battlers are
    #less effected by ingenuity.
    #(Finesse is always the primary determining factor)
    ING_BIAS_1 = 0.25 

    #Battlers with less finesse depend greater on their ingenuity. But
    #shouldn't often surpass battlers with far greater finesse.
    ING_BIAS_2 = 0.33 

    #Essentially any random ingenuity bonuses that don't exceed bias % of
    #the avg ingenuity of the battlefield, are ignored. Higher values
    #require battlers to have greater ingenuity to gain speed.

    #NOTE: Lower than average ingenuity has a penalty effect.


    #---------------------------------------------------------------------------
    #AP SCHEDULES:  RDeus::APCombat::AP_SCHEDULES
    #---------------------------------------------------------------------------
    #Make sure that the enemies MAX AP is capable of handling the values
    #given to it by schedule arrays.
    #
    #Make sure the note tag contains a 'string' value identical to the
    #  schedule symbol. Ex: the :test schedules tag would be 
    #  <ap_schedule: test>
    #  
    #Note: Its possible to schedule AP greater than max, planning that
    #  some enemies assigned the schedule will make better use of it,
    #  while others will effectively act as though no schedule existed.

    AP_SCHEDULES = { #EDIT ONLY WHATS BETWEEN THE DASHED LINES!
    # :default      => [], #Keep this for reference. (Copy the syntax exactly)
    #--------------------------------------------

      :default      => [],
      :test         => [3,4,3],

    #--------------------------------------------
    }#AP_SCHEDULES - DO NOT TOUCH THIS LINE


    #---------------------------------------------------------------------------
    #POPUP DETAILS:  RDeus - Popup Details, script support.
    #---------------------------------------------------------------------------
    # [Delay, Fade]
    # Delay = Number of frames popup waits before fading. (Higher = longer wait)
    # Fade = Amount of transparency popup loses while fading. (Higher = faster)
    NEW_TURN_DETAILS      = [30, 3] 
    SURPRISE_TURN_DETAILS = [30, 3]
    #Note: You will want these to fade quickly enough not to obstruct the
    #   first few actions in the turn.
  end
end

#-----------------------------------------------------------------------------
#-----------------------------------------------------------------------------
# BEYOND HERE THERE BE DRAGONS!!!
#-----------------------------------------------------------------------------
#-----------------------------------------------------------------------------


#===============================================================================
#
#===============================================================================
module RDeus
  #-----------------------------------------------------------------------------
  # RDeus.cache_ap(object, method_symb, lambda)
  #-----------------------------------------------------------------------------
  def self.cache_ap(object, method_symb, lambda)
    @cache_ap ||= {}
    @cache_ap[object] ||= {}
    return @cache_ap[object][method_symb] ||= eval(lambda)
  end
end


#===============================================================================
# 
#===============================================================================
class RPG::BaseItem
  #-----------------------------------------------------------------------------
  # new: <ap_adjust: xxxxx>
  # - Bonus AP's on init.
  #   a = battler.self
  #-----------------------------------------------------------------------------
  def ap_adjust(a, p=$game_party, t=$game_troop, v=$game_variables, s=$game_switches)
    if @ap_adjust_form.nil?
      @note =~ /<ap[-_ ]?adjust:\s*(.*)\s*>/i 
      @ap_adjust_form = "lambda {|a,p,t,v,s| #{$1 ? $1 : "0"} } "
    end
    return RDeus.cache_ap(self, :ap_adjust, @ap_adjust_form).call(a,p,t,v,s)
  end

  #-----------------------------------------------------------------------------
  # new: <ap_max_adjust: xxxxx>
  # - Bonus MAXIMUM AP's. Primarily for carry over limits.
  #   a = battler.self
  #-----------------------------------------------------------------------------
  def ap_max_adjust(a, p=$game_party, t=$game_troop, v=$game_variables, s=$game_switches)
    if @ap_max_adjust_form.nil?
      @note =~ /<ap[-_ ]?max[-_ ]?adjust:\s*(.*)\s*>/i 
      @ap_max_adjust_form = "lambda {|a,p,t,v,s| #{$1 ? $1 : "0"} } "
    end
    return RDeus.cache_ap(self, :ap_max_adjust, @ap_max_adjust_form).call(a,p,t,v,s)
  end

  #-----------------------------------------------------------------------------
  # new: <nimble>
  #-----------------------------------------------------------------------------
  def nimble?
    return @nimble if !@nimble.nil?
    @note =~ /<(nimble)>/i 
    @nimble = $1 ? true : false
    return @nimble
  end
  #-----------------------------------------------------------------------------
  # new: <clumsy>
  #-----------------------------------------------------------------------------
  def clumsy?
    return @clumsy if !@clumsy.nil?
    @note =~ /<(clumsy)>/i 
    @clumsy = $1 ? true : false
    return @clumsy
  end
end


#===============================================================================
# 
#===============================================================================
class RPG::Enemy < RPG::BaseItem
  #-----------------------------------------------------------------------------
  # new: <ap_schedule: schedule>
  #-----------------------------------------------------------------------------
  def ap_schedule
    return @ap_schedule if !@ap_schedule.nil?
    @note =~ /<ap[-_ ]?schedule:\s*(.*)\s*>/i 
    @ap_schedule = $1 ? RDeus::APCombat::AP_SCHEDULES[$1.to_sym] : []
    return @ap_schedule
  end
end


#===============================================================================
# 
#===============================================================================
class RPG::UsableItem < RPG::BaseItem
  #-----------------------------------------------------------------------------
  # new: <ap: formula>
  #   a = battler.self
  #-----------------------------------------------------------------------------
  def ap_cost(a, p=$game_party, t=$game_troop, v=$game_variables, s=$game_switches)
    if @ap_cost_form.nil?
      @note =~ /<ap:\s*(.*)\s*>/i 
      @ap_cost_form = "lambda {|a,p,t,v,s| #{$1 ? $1 : RDeus::APCombat::COST_BASE} } "
    end
    return RDeus.cache_ap(self, :ap_cost, @ap_cost_form).call(a,p,t,v,s)
  end
end


#===============================================================================
# 
#===============================================================================
module BattleManager
  #--------------------------------------------------------------------------
  # new: 15_0706
  #--------------------------------------------------------------------------
  def self.surprise?
    return @surprise ? true : false
  end

  #-----------------------------------------------------------------------------
  # overwrite:
  #-----------------------------------------------------------------------------
  def self.battle_start
    $game_system.battle_count += 1
    $game_party.on_battle_start
    $game_troop.on_battle_start
    if YEA::BATTLE::MSG_ENEMY_APPEARS #<---- Added
      $game_troop.enemy_names.each do |name|
        $game_message.add(sprintf(Vocab::Emerge, name))
      end
    end
    if @preemptive
      $game_message.add(sprintf(Vocab::Preemptive, $game_party.name))
    elsif @surprise
      $game_message.add(sprintf(Vocab::Surprise, $game_party.name))
    end
    wait_for_message
  end

  #-----------------------------------------------------------------------------
  # overwrite: 
  #-----------------------------------------------------------------------------
  def self.actor
    subject = @action_battlers[0]
  end

  #-----------------------------------------------------------------------------
  # overwrite: 
  #-----------------------------------------------------------------------------
  def self.input_start
    if @phase != :input
      @phase = :input
      make_action_orders

      if @surprise
        surprsie_turn_popups
      else
        new_turn_popups
      end

      $game_party.make_actions
      $game_troop.make_actions
      clear_actor
    end
    puts("BattleManager.input_start: #{(!@surprise && $game_party.inputable?)}")
    return !@surprise && $game_party.inputable?
  end

  #-----------------------------------------------------------------------------
  # new: 15_0702
  #-----------------------------------------------------------------------------
  def self.new_turn_popups
    if $imported["RDeus-PopupDetails"]
      @action_battlers.each {|battler| 
        next unless battler.alive?
        battler.create_popup(RDeus::APCombat::NEW_TURN_TEXT, 
                             RDeus::APCombat::NEW_TURN_RULE, [], [30, 3])}
    else
      @action_battlers.each {|battler| 
        next unless battler.alive?
        battler.create_popup(RDeus::APCombat::NEW_TURN_TEXT, 
                             RDeus::APCombat::NEW_TURN_RULE, [])}
    end
  end

  #-----------------------------------------------------------------------------
  # new: 15_0702
  #-----------------------------------------------------------------------------
  def self.surprsie_turn_popups
    if $imported["RDeus-PopupDetails"]
      @action_battlers.each {|battler| 
        next unless battler.alive?
        battler.create_popup(RDeus::APCombat::SUP_TURN_TEXT, 
                             RDeus::APCombat::SUP_TURN_RULE, [], [30, 3])}
    else
      @action_battlers.each {|battler| 
        next unless battler.alive?
        battler.create_popup(RDeus::APCombat::SUP_TURN_TEXT, 
                             RDeus::APCombat::SUP_TURN_RULE, [])}
    end
  end

  #-----------------------------------------------------------------------------
  # overwrite: 
  #-----------------------------------------------------------------------------
  def self.turn_start
    @phase = :turn
    clear_actor
    $game_troop.increase_turn
  end

  #-----------------------------------------------------------------------------
  # default: 
  #-----------------------------------------------------------------------------
  def self.turn_end
    puts("  ** BattleManager - turn_end **")
    @phase = :turn_end
    @preemptive = false
    @surprise = false
  end

  #-----------------------------------------------------------------------------
  # overwrite: 
  # last: 15_0627
  #-----------------------------------------------------------------------------
  def self.make_action_orders
    # puts("  ** Make Action Orders **")
    @action_battlers = []
    @action_battlers += $game_party.members unless @surprise
    @action_battlers += $game_troop.members unless @preemptive
    #Same speed order should be more random with shuffle.
    @action_battlers.shuffle! unless @preemptive #No predetermined order.

    @bias_array = make_speed_bias(@action_battlers)
    @action_battlers.each {|battler| battler.make_speed(@bias_array) }
    @action_battlers.sort! {|a,b| b.speed - a.speed } 
  end

  #-----------------------------------------------------------------------------
  # new: 
  # - Swaps index [0] and [1] in array. 
  #-----------------------------------------------------------------------------
  def self.make_delay_reorder
    return false unless @action_battlers[0] && @action_battlers[1]
    first = @action_battlers[0]
    second = @action_battlers[1]
    unless RDeus::APCombat::DISSABLE_DELAY_INIT_LOSS
      speed1 = first.speed
      speed2 = second.speed

      second.set_speed(speed1)
      first.set_speed(speed2 - rnd_speed_adjust)
      resort_order_by_speed
    else
      @action_battlers[0] = second
      @action_battlers[1] = first
    end
    return true
  end

  #-----------------------------------------------------------------------------
  # new: 15_0701
  #-----------------------------------------------------------------------------
  def self.rnd_speed_adjust
    return rand < (1.0 - RDeus::APCombat::DOUBLE_LOSS_RATE) ? 
      RDeus::APCombat::INIT_LOST : RDeus::APCombat::INIT_LOST * 2
  end

  #-----------------------------------------------------------------------------
  # new: 
  # - Called, if an action changes speeds during a turn.
  #-----------------------------------------------------------------------------
  def self.resort_order_by_speed
    @action_battlers.sort! {|a,b| b.speed - a.speed }
  end

  #-----------------------------------------------------------------------------
  # new: 
  # last: 15_0627
  # Battler FINESSE/INGENUITY can change from round to round... 
  #-----------------------------------------------------------------------------
  def self.make_speed_bias(battlers)
    total_i = total_f = 0
    battlers.each {|battler|
      total_f += battler.fin
      total_i += battler.ing
    }
    avg_f = (total_f/battlers.length).to_i
    avg_i = (total_i/battlers.length).to_i

    return [avg_f, avg_i]
  end

  #-----------------------------------------------------------------------------
  # overwrite: 
  # last: 15_0827
  #-----------------------------------------------------------------------------
  def self.next_command
    # puts("\n    ** BattleManager - Next Command #{actor ? actor.name : "NIL!"}**")
    @actor_index = actor.index if actor
    begin
      #15_0709: Added movable? check
      # puts("      #{actor ? actor.name : "NIL!"}...")
      if !actor || !actor.movable? || !actor.has_ap? || !actor.next_command
        @action_battlers.shift          #Discard them, and get the next.
        # puts("      >> #{actor ? actor.name : "NIL!"} ")
        return false if actor.nil?      #end if no more remain.
        @actor_index = actor.index
      end
    end until actor.inputable? || (actor.has_ap? && actor.confusion?) #Can move (Not stunned)
    # puts("    ** #{actor.name} (index: #{@actor_index}) is acting. **\n\n")
    return true
  end

  #-----------------------------------------------------------------------------
  # overwrite: 15_0701
  #-----------------------------------------------------------------------------
  def self.prior_command
    begin
      if !actor || !actor.prior_command
        return false
      end
    end until actor.inputable?
    return true
  end
end


#===============================================================================
# 
#===============================================================================
class Game_BattlerBase
  attr_accessor :passed_init
  #-----------------------------------------------------------------------------
  # alias: last: 15_1005
  #-----------------------------------------------------------------------------
  # alias :rdapcm_initialize :initialize
  # def initialize
  #   rdapcm_initialize
  #   @passed_init = false
  # end
  #-----------------------------------------------------------------------------
  # new: 
  #-----------------------------------------------------------------------------
  def ap
    init_ap unless @ap
    return @ap
  end

  #-----------------------------------------------------------------------------
  # new: 
  #-----------------------------------------------------------------------------
  def init_ap
    @passed_ap ||= 0
    init_value = determine_init_ap #Prevent repeat loops.
    @ap = [init_value + @passed_ap, max_ap(init_value)].min
    @ap_used = 0
    @passed_ap = 0
    # puts("#{self.name} Initializing (#{init_value} + #{@passed_ap} = #{@ap}) AP. Max: #{max_ap(init_value)}")
  end

  #-----------------------------------------------------------------------------
  # new: last: 15_0702
  #-----------------------------------------------------------------------------
  def determine_init_ap
    value = RDeus::APCombat::BATTLER_AP
   
    if self.enemy? #AP Schedule added 15_0702
      @ap_schedule ||= self.enemy.ap_schedule.clone
      if !@ap_schedule.empty?
        value = @ap_schedule.shift if !@ap_schedule.empty?
        puts("\n#{self.name} has an AP Schedule! (#{value})AP this turn\n\n")
        @ap_schedule = nil if @ap_schedule.empty?
      end
    end

    self.feature_objects.each{|obj| value += obj.ap_adjust(self) }
    return value
  end

  #-----------------------------------------------------------------------------
  # new: 
  #-----------------------------------------------------------------------------
  def use_ap(value = 1)
    init_ap unless @ap
    @ap -= value
    @ap_used += value
  end

  #-----------------------------------------------------------------------------
  # new: 
  #-----------------------------------------------------------------------------
  def max_ap(init_ap = RDeus::APCombat::BATTLER_AP)
    adjust = 0
    self.feature_objects.each{|obj| adjust += obj.ap_max_adjust(self) if obj }
    return [([init_ap * RDeus::APCombat::MAX_AP_MULTI,init_ap].max).to_i + adjust, RDeus::APCombat::AP_CAP].min
  end

  #-----------------------------------------------------------------------------
  # new: 
  #-----------------------------------------------------------------------------
  def passed_ap(value)
    init_ap unless @passed_ap
    @passed_ap = value
  end

  #-----------------------------------------------------------------------------
  # new: 
  #-----------------------------------------------------------------------------
  def ap_used
    init_ap unless @ap_used
    return @ap_used
  end

  #-----------------------------------------------------------------------------
  alias :rdapcm_inputable? :inputable?
  def inputable?
    value = rdapcm_inputable?
    return false unless value
    return value unless SceneManager.scene_is?(Scene_Battle)
    #Count AP remaining... 
    return false unless self.ap > 0
    return true
  end

  #-----------------------------------------------------------------------------
  alias :rdapcm_skill_conditions_met? :skill_conditions_met?
  def skill_conditions_met?(item)
    return false unless rdapcm_skill_conditions_met?(item)
    return ap_conditions_met?(item)
  end

  #-----------------------------------------------------------------------------
  alias :rdapcm_item_conditions_met? :item_conditions_met?
  def item_conditions_met?(item)
    return false unless rdapcm_item_conditions_met?(item)
    return ap_conditions_met?(item)
  end

  #-----------------------------------------------------------------------------
  # new: 
  #-----------------------------------------------------------------------------
  def ap_conditions_met?(item)
    return false unless self.ap >= item.ap_cost(self)
    return true
  end
end


#===============================================================================
# 
#===============================================================================
class Game_Battler < Game_BattlerBase
  #-----------------------------------------------------------------------------
  # overwrite: 
  #-----------------------------------------------------------------------------
  def make_actions
    clear_actions
    return unless movable?
    @actions = [Game_Action.new(self)]
  end

  #-----------------------------------------------------------------------------
  # new: 
  #-----------------------------------------------------------------------------
  def has_ap?
    value = self.ap > 0
    if value && @actions.empty?
      self.make_actions 
    end
    return value
  end

  #-----------------------------------------------------------------------------
  alias :rdapcm_on_battle_start :on_battle_start
  def on_battle_start
    init_ap
    rdapcm_on_battle_start
  end

  #-----------------------------------------------------------------------------
  alias :rdapcm_on_turn_end :on_turn_end
  def on_turn_end
    puts("  ** Game_Battler - on_turn_end **")
    init_ap
    rdapcm_on_turn_end
  end

  #-----------------------------------------------------------------------------
  # alias :rdapcm_remove_states_auto :remove_states_auto
  # def remove_states_auto(timing)
  #   puts("remove_states_auto")
  #   rdapcm_remove_states_auto(timing)
  # end

  #-----------------------------------------------------------------------------
  # default: 
  #-----------------------------------------------------------------------------
  def remove_current_action
    @actions.shift
  end

  #-----------------------------------------------------------------------------
  # overwrite: 
  # last: 15_1005
  # RDeus::APCombat::ING_RATE
  #-----------------------------------------------------------------------------
  def make_speed(bias_array = nil)
    @speed = self.fin
    if self.fin > bias_array[0] #higher ingenuity
      # puts("\n  #{self.name}, FASTER")

      amp = [self.fin * RDeus::APCombat::H_AMP, 0].max.to_i #Tighter Finesse range.
      adjust = rand(amp + 1) + rand(amp + 1) - amp
      # print("    [#{self.fin} * #{RDeus::APCombat::H_AMP},0].max.to_i = #{amp}, Raw Adj: #{adjust}")

      adjust += ([rand * ([(self.ing - bias_array[1]),0].max - (bias_array[1] * RDeus::APCombat::ING_BIAS_1) ), 0].max) * RDeus::APCombat::ING_RATE
      # print(", Adj: #{adjust.to_i}")

    else
      # puts("\n  #{self.name}, SLOWER")

      amp = [self.fin * RDeus::APCombat::L_AMP, 0].max.to_i
      adjust = rand(amp + 1) + rand(amp + 1) - amp
      # print("    [#{self.fin} * #{RDeus::APCombat::H_AMP},0].max.to_i = #{amp}, Raw Adj: #{adjust}")
      
      adjust += ([rand * ([(self.ing - bias_array[1]),0].max - (bias_array[1] * RDeus::APCombat::ING_BIAS_2) ), 0].max) * RDeus::APCombat::ING_RATE
      # print(", Adj: #{adjust.to_i}")

    end

    @speed += adjust.to_i
    @speed += self.footing * (bias_array[0] * RDeus::APCombat::FOOTING).to_i
    # puts(", Footing: #{self.footing}, Spd: #{@speed}")

    if RDeus::APCombat::PASS_TURN_INIT && passed_init
      puts("\n  #{self.name}, INITIATIVE: #{@speed}")
      @speed = (@speed * RDeus::APCombat::PASS_INIT_RATE).ceil
      puts("    PASSED TURN INITIATIVE RATE: #{RDeus::APCombat::PASS_INIT_RATE}")
    end
    puts(" #{self.name}, FINAL INITIATIVE: #{@speed}")

    passed_init = false 
  end

  #-----------------------------------------------------------------------------
  # new: 
  #-----------------------------------------------------------------------------
  def set_speed(value)
    # puts("#{self.name} speed (#{value})")
    @speed = value
  end

  #-----------------------------------------------------------------------------
  # new: 
  #-----------------------------------------------------------------------------
  def footing
    bonus = 0
    penalty = 0
    self.feature_objects.each{|obj|
      if obj.clumsy?
        penalty += 1 
      elsif obj.nimble?
        bonus += 1
      end 
    }
    return (bonus - penalty)
  end
  #-----------------------------------------------------------------------------
  # new: 
  #-----------------------------------------------------------------------------
  def clumsy?
    self.feature_objects.each{|obj|
      return true if obj.clumsy?
    }
    return false
  end
end


#===============================================================================
# 
#===============================================================================
class Game_Actor < Game_Battler
  #-----------------------------------------------------------------------------
  # 15_0630: To help those who do not want to worry about Hime's TOU.
  #-----------------------------------------------------------------------------
  unless RDeus::APCombat::DISSABLE_HIME_COMMAND_MANAGER
    # #-----------------------------------------------------------------------------
    # # new: 
    # #-----------------------------------------------------------------------------
    # def add_command_xxxxx(args)
    #   cmd = Game_BattlerCommand.new("xxxxx", :xxxxx)
    #   add_command(cmd)
    # end
    # CommandManager.register(:xxxxx, :actor)
  
    #-----------------------------------------------------------------------------
    # new: 
    #-----------------------------------------------------------------------------
    def add_command_delay(args)
      cmd = Game_BattlerCommand.new("Delay", :delay)
      add_command(cmd)
    end
    CommandManager.register(:delay, :actor)
    
    #-----------------------------------------------------------------------------
    # new: 
    #-----------------------------------------------------------------------------
    def add_command_pass(args)
      cmd = Game_BattlerCommand.new("Pass Turn", :pass)
      add_command(cmd)
    end
    CommandManager.register(:pass, :actor)
  end

  #-----------------------------------------------------------------------------
  # default: 
  #-----------------------------------------------------------------------------
  def make_actions
    super
    if auto_battle?
      make_auto_battle_actions
    elsif confusion?
      make_confusion_actions
    end
  end

  #-----------------------------------------------------------------------------
  # overwrite: 
  #-----------------------------------------------------------------------------
  def next_command
    return false if @actions.empty?
    return true
  end
end


#===============================================================================
# 
#===============================================================================
class Game_Enemy < Game_Battler
  #-----------------------------------------------------------------------------
  # new - 15_0827
  #-----------------------------------------------------------------------------
  def ap_conditions_met?(item)
    return false unless self.ap >= item.ap_cost(self)
    return true
  end
  #-----------------------------------------------------------------------------
  # 15_0827
  #-----------------------------------------------------------------------------
  alias :dsadsd_conditions_met? :conditions_met?
  def conditions_met?(action)
    # puts("        ** conditions_met? #{action} **")
    value = dsadsd_conditions_met?(action)
    value = false unless ap_conditions_met?($data_skills[action.skill_id])
    return value
  end
  #-----------------------------------------------------------------------------
  # overwrite: 
  #-----------------------------------------------------------------------------
  def make_actions
    # puts("        ** #{self.name} - make_actions #{self.ap}AP**")
    super
    return if @actions.empty?
    action_list = enemy.actions.select {|a| action_valid?(a) } #conditions_met?

    if action_list.empty?
      enemy_pass
      return 
    end

    rating_max = action_list.collect {|a| a.rating }.max
    rating_zero = rating_max - 3
    action_list.reject! {|a| a.rating <= rating_zero }
    # puts("        Performing #{@actions.length} actions.")
    @actions.each do |action|
      action.set_enemy_action(select_enemy_action(action_list, rating_zero))
    end
  end

  #-----------------------------------------------------------------------------
  # new: 
  #-----------------------------------------------------------------------------
  def enemy_pass
    cost = self.ap #Costs all AP unless passing a full turn.
    if self.ap_used < 1
      cost = (self.ap * 0.5).to_i #Full turn = 50%, rounded down
      create_popup("Pass + AP", "DEFAULT", [])
    else
      create_popup("Pass", "DEFAULT", [])
    end
    passed_init = true if self.ap > 0 #Passed turn with ANY remaining AP
    self.use_ap(cost)
    self.passed_ap(self.ap)
    self.use_ap(self.ap)
    SceneManager.scene.log_window.add_text("#{self.name} passed their turn.") if SceneManager.scene_is?(Scene_Battle)
    self.on_action_end #<--- 15_0702
  end

  #-----------------------------------------------------------------------------
  # new: 
  #-----------------------------------------------------------------------------
  def next_command
    return false if @actions.empty?
    return true
  end
end


#===============================================================================
# 
#===============================================================================
class Game_Unit
  #-----------------------------------------------------------------------------
  # yanfly alias:  battle
  #-----------------------------------------------------------------------------
  def make_actions
    game_unit_make_actions_abe
    refresh_autobattler_status_window
  end
end


#===============================================================================
# 
#===============================================================================
# class Game_Party < Game_Unit
#   #-----------------------------------------------------------------------------
#   def inputable?
#   end
# end


#===============================================================================
# 15_0630: To help those who do not want to worry about Hime's TOU.
#===============================================================================
if RDeus::APCombat::DISSABLE_HIME_COMMAND_MANAGER
class Window_ActorCommand < Window_Command
  #-----------------------------------------------------------------------------
  alias :make_command_list_rdabs :make_command_list
  def make_command_list
    make_command_list_rdabs
    return unless @actor
    add_delay_command
    add_pass_command
  end

  #-----------------------------------------------------------------------------
  # new: 
  #-----------------------------------------------------------------------------
  def add_delay_command
    add_command("Delay", :delay, @actor.inputable?)
  end

  #-----------------------------------------------------------------------------
  # new: 
  #-----------------------------------------------------------------------------
  def add_pass_command
    add_command("Pass Turn", :pass_turn, @actor.inputable?)
  end
end
end

#===============================================================================
# 
#===============================================================================
class Scene_Battle < Scene_Base
  attr_reader :log_window

  #-----------------------------------------------------------------------------
  # 15_0630: To help those who do not want to worry about Hime's TOU.
  #-----------------------------------------------------------------------------
  if RDeus::APCombat::DISSABLE_HIME_COMMAND_MANAGER
    #-----------------------------------------------------------------------------
    alias :create_actor_command_window_rdabs :create_actor_command_window
    def create_actor_command_window
      create_actor_command_window_rdabs
      @actor_command_window.set_handler(:delay,   method(:command_delay))
      @actor_command_window.set_handler(:pass_turn,   method(:command_pass))
    end
  end

  # #-----------------------------------------------------------------------------
  # # new: 
  # #-----------------------------------------------------------------------------
  # def command_xxxxx
    # puts("xxxxx HERE")
  #   next_command
  # end

  #-----------------------------------------------------------------------------
  # new: 
  #-----------------------------------------------------------------------------
  def command_delay
    BattleManager.actor.create_popup("Delay", "DEFAULT", [])
    if BattleManager.make_delay_reorder
    end
    @log_window.add_text("#{BattleManager.actor.name} delayed their turn.")
    next_command
  end

  #-----------------------------------------------------------------------------
  # new: 
  # - Can only pass FULL TURN. Partial turns are wasted.
  # - Due to the math, there is diminishing return after the first pass.
  #-----------------------------------------------------------------------------
  def command_pass
    battler = BattleManager.actor
    cost = battler.ap #Costs all AP unless passing a full turn.
    if battler.ap_used < 1
      cost = (battler.ap * 0.5).to_i #Full turn = 50%, rounded down
      battler.create_popup("Pass + AP", "DEFAULT", [])
    else
      battler.create_popup("Pass", "DEFAULT", [])
    end
    if battler.ap > 0 #Passed turn with ANY remaining AP
      battler.passed_init = true 
      @log_window.add_text("#{BattleManager.actor.name} passed their turn, with initiative.")
    else
      @log_window.add_text("#{BattleManager.actor.name} passed their turn.")
    end
    battler.use_ap(cost)
    battler.passed_ap(battler.ap)
    battler.use_ap(battler.ap)

    battler.clear_actions
    battler.on_action_end #<--- 15_0702
    next_command
  end

  #-----------------------------------------------------------------------------
  # overwrite:
  #-----------------------------------------------------------------------------
  def next_command
    # puts("\n  ** Scene_Battle - Next Command(#{BattleManager.actor.name}) **")
    # redraw_current_status
    @party_command_window.hide  #<--- 15_0701
    @status_aid_window.hide
    @status_window.show
    @actor_command_window.show
    status_redraw_target(BattleManager.actor)
    refresh_ftb_gauge(@subject)

    if BattleManager.next_command #The current actor is valid.
      #15_1001: re-up actions added in the RARE case where an BATTLER has no 
      #action due to being confused and then NOT being confused in the same 
      #turn.
      if BattleManager.actor.current_action.nil?
        BattleManager.actor.make_actions 
      end

      @subject = BattleManager.actor
      item = @subject.current_action.item
      if @subject.current_action.item.nil? #Currently only if this is an actor.
        # puts("  ** #{@subject.name} Command Select **")
        start_actor_command_selection
        return
      else
        # puts("  ** #{@subject.name} Command Execute #{item.name}**")
        refresh_ftb_gauge(@subject)
        execute_action
        process_event

        loop do
          @subject.remove_current_action
          break if $game_troop.all_dead?
          break unless @subject.current_action
          # puts("  ** #{@subject.name} Command Execute Again**")
          @subject.current_action.prepare
          execute_action if @subject.current_action.valid?
        end

        consume_action_ap(item)
        @subject.remove_current_action

        return if $game_troop.alive_members.size <= 0
        process_action_end
        next_command
      end
    else
      turn_start
    end
  end

  #-----------------------------------------------------------------------------
  # new:
  #-----------------------------------------------------------------------------
  def consume_action_ap(item)
    # puts("  #{@subject.name} consumed #{item.ap_cost(@subject)} AP's using #{item.name}")
    @subject.use_ap(item.ap_cost(@subject))
  end


  #-----------------------------------------------------------------------------
  # overwrite: 15_0701
  #-----------------------------------------------------------------------------
  def battle_start
    scene_battle_battle_start_abe #<--- start_party_command_selection (turn_start on surprise)

    return unless YEA::BATTLE::SKIP_PARTY_COMMAND
    @party_command_window.deactivate
    @party_command_window.hide  #15_0701

    if !BattleManager.surprise?  #15_0706
      if BattleManager.input_start 
        command_fight #(next_command)
      else
        turn_start
      end
    end
  end
  #-----------------------------------------------------------------------------
  # overwrite: 15_0701
  #-----------------------------------------------------------------------------
  def start_party_command_selection
    puts("start_party_command_selection")
    unless scene_changing?
      refresh_status
      @party_command_window.show #15_0701
      @status_window.unselect
      @status_window.open
      if BattleManager.input_start && !BattleManager.surprise? #15_0706
        @actor_command_window.close
        @party_command_window.setup
      else
        @party_command_window.deactivate
        @party_command_window.hide #15_0701
        # turn_start #16_0225 Is causing infinite next turn when all actors are non-movable.
        command_fight #(next_command)
      end
    end
    refresh_ftb_gauge(@subject) 
  end

  #-----------------------------------------------------------------------------
  # default: 
  #-----------------------------------------------------------------------------
  def turn_start
    puts("turn_start")
    @party_command_window.close
    # @actor_command_window.close #15_0917 - Removed to stop window flicker.
    @status_window.unselect
    @subject =  nil
    BattleManager.turn_start
    @log_window.wait
    @log_window.clear
  end

  #-----------------------------------------------------------------------------
  # yanfly:  battle
  #-----------------------------------------------------------------------------
  def turn_end
    puts("turn_end")
    # puts("  ** Scene_Battle - turn_end **")
    all_battle_members.each do |battler|
      battler.on_turn_end
      status_redraw_target(battler)
      @log_window.display_auto_affected_status(battler)
      @log_window.wait_and_clear
    end

    update_party_cooldowns if $imported["YEA-CommandParty"]
    BattleManager.turn_end #surprise & preempt reset here.
    process_event
    start_party_command_selection
    
    return if end_battle_conditions?
    return unless YEA::BATTLE::SKIP_PARTY_COMMAND
    if BattleManager.input_start && !BattleManager.surprise? #15_0706
      @party_command_window.deactivate
      command_fight #(next_command)
    else
      @party_command_window.deactivate
      turn_start
    end
  end
  #-----------------------------------------------------------------------------
  # yanfly:  battle  15_0917
  #-----------------------------------------------------------------------------
  def on_enemy_ok
    puts("on_enemy_ok")
    $game_temp.battle_aid = nil
    #15_0917
    @actor_command_window.close if RDeus::APCombat::CLOSE_ACTOR_COMMAND_ON_ACT
    scene_battle_on_enemy_ok_abe
  end
  #-----------------------------------------------------------------------------
  # yanfly:  ftb
  #-----------------------------------------------------------------------------
  alias start_actor_command_selection_ftbrd start_actor_command_selection
  def start_actor_command_selection
    start_actor_command_selection_ftbrd
    refresh_ftb_gauge(@subject)
  end
  #-----------------------------------------------------------------------------
  # yanfly:  ftb
  #-----------------------------------------------------------------------------
  alias scene_battle_create_all_windows_ftbrb create_all_windows
  def create_all_windows
    scene_battle_create_all_windows_ftbrb
    create_ftb_gauge
  end
  #-----------------------------------------------------------------------------
  # yanfly:  ftb
  #-----------------------------------------------------------------------------
  def create_ftb_gauge
    @ftb_gauge = Window_FTB_Gauge.new(@help_window)
  end
  #-----------------------------------------------------------------------------
  # overwrite:  ftb
  #-----------------------------------------------------------------------------
  def refresh_ftb_gauge(subject)
    @ftb_gauge.refresh(subject)
  end
  #-----------------------------------------------------------------------------
  # yanfly:  ftb
  #-----------------------------------------------------------------------------
  def hide_ftb_gauge
    @ftb_gauge.hide
  end
  #-----------------------------------------------------------------------------
  # yanfly:  ftb
  #-----------------------------------------------------------------------------
  def hide_ftb_action_windows
    @info_viewport.visible = true
    @status_aid_window.hide
    @status_window.show
    @actor_command_window.show
  end
  #-----------------------------------------------------------------------------
  # yanfly:  ftb
  #-----------------------------------------------------------------------------
  def show_ftb_action_windows
    @info_viewport.visible = true
  end
  #-----------------------------------------------------------------------------
  # yanfly:  ftb
  #-----------------------------------------------------------------------------
  alias scene_battle_hide_extra_gauges_ftb hide_extra_gauges
  def hide_extra_gauges
    scene_battle_hide_extra_gauges_ftb
    @ftb_gauge.hide
  end
  #-----------------------------------------------------------------------------
  # yanfly:  ftb
  #-----------------------------------------------------------------------------
  alias scene_battle_show_extra_gauges_ftb show_extra_gauges
  def show_extra_gauges
    scene_battle_show_extra_gauges_ftb
    @ftb_gauge.show
  end
end


#===============================================================================
# 
#===============================================================================
class Window_FTB_Gauge < Window_Base
  #-----------------------------------------------------------------------------
  # yanfly:  ftb
  #-----------------------------------------------------------------------------
  def initialize(help_window)
    @help_window = help_window
    super(0, 0, Graphics.width, fitting_height(1))
    self.opacity = 0
    self.contents_opacity = 0
    self.z = 200
  end
  #-----------------------------------------------------------------------------
  # yanfly:  ftb
  #-----------------------------------------------------------------------------
  def refresh(subject = nil)
    contents.clear
    return unless subject && subject.actor?
    draw_empty_icons(subject)
    draw_filled_icons(subject)
  end
  #-----------------------------------------------------------------------------
  # overwrite: 
  #-----------------------------------------------------------------------------
  def draw_empty_icons(subject)
    n = subject.max_ap(subject.determine_init_ap)
    dx = contents.width
    n.times do
      dx -= 24
      draw_icon(RDeus::APCombat::ICON_EMPTY, dx, 0)
    end
  end
  #-----------------------------------------------------------------------------
  # overwrite: 
  #-----------------------------------------------------------------------------
  def draw_filled_icons(subject)
    n = subject.ap
    dx = contents.width
    n.times do
      dx -= 24
      draw_icon(RDeus::APCombat::ICON_ACTION, dx, 0)
    end
  end
  #-----------------------------------------------------------------------------
  # overwrite: 
  #-----------------------------------------------------------------------------
  def update
    super
    self.contents_opacity = 0 unless SceneManager.scene_is?(Scene_Battle)
    return unless SceneManager.scene_is?(Scene_Battle)
    change_contents_opacity
    change_y_position
  end
  #-----------------------------------------------------------------------------
  # yanfly:  ftb
  #-----------------------------------------------------------------------------
  def change_contents_opacity
    rate = BattleManager.in_turn? ? -8 : 8
    self.contents_opacity += rate
  end
  #-----------------------------------------------------------------------------
  # yanfly:  ftb
  #-----------------------------------------------------------------------------
  def change_y_position
    self.y = @help_window.visible ? @help_window.height : 0
  end
end # Window_FTB_Gauge


if $imported["YEA-CombatLogDisplay"]
#===============================================================================
# 
#===============================================================================
class Scene_Battle < Scene_Base
  #-----------------------------------------------------------------------------
  # alias: 15_0706
  # Needed to hide "Turn Number: 0" report for free surprise turns.
  #-----------------------------------------------------------------------------
  alias :turn_start_rdabs :turn_start
  def turn_start
    turn_start_rdabs

    if !BattleManager.surprise?
      @combatlog_window.add_line("-")
      text = sprintf(YEA::COMBAT_LOG::TEXT_TURN_NUMBER, $game_troop.turn_count)
      @combatlog_window.add_line(text)
      @combatlog_window.add_line("-")
    elsif !@surprise_report
      @surprise_report = true
      @combatlog_window.add_line("-")
      @combatlog_window.add_line("\\c[4]SURPRISE TURN: \\c[6]#{$game_troop.turn_count}")
      @combatlog_window.add_line("-")
    end
  end
end
end



#===============================================================================
# Below here are the new parameter methods...
#===============================================================================

#===============================================================================
# 
#===============================================================================
class Game_BattlerBase
  #--------------------------------------------------------------------------
  # * Access Method by Parameter Abbreviations
  #--------------------------------------------------------------------------
  def mig;  param(2);   end               # MIGHT     = ATK 
  def sor;  param(4);   end               # SORCERY   = MAT
  def exa;  param(5);   end               # EXALT     = MDF
  def fin;  param(6);   end               # FINESSE   = AGI  
  def ing;  param(7);   end               # INGENUITY = LUK
end




#===============================================================================
# PRE LOAD MORE COMPLEX NON-CHANGING SEARCHES
#===============================================================================
module DataManager
  #--------------------------------------------------------------------------
  # alias method: load_database
  #--------------------------------------------------------------------------
  class <<self; alias rd_apbattlesystem_load_database load_database; end
  def self.load_database
    rd_apbattlesystem_load_database
    rd_apbattlesystem_load_notetags
  end
  
  #--------------------------------------------------------------------------
  # new method: load_notetags_rdgt
  #--------------------------------------------------------------------------
  def self.rd_apbattlesystem_load_notetags
    groups = [$data_actors, $data_classes, $data_skills, $data_items, 
      $data_weapons, $data_armors, $data_states]
    puts("AP Battle system Info Pre-Loaded...") if $TEST
    for group in groups
      # puts("TraitsInfo Pre-Loaded for #{group[1].class}") if $TEST && group[1]
      for obj in group
        next if obj.nil?
        obj.rd_apbattlesystem_load_notetags
      end
    end
  end
end # DataManager

#For future use...
class RPG::BaseItem
  def rd_apbattlesystem_load_notetags
    self.nimble?
    self.clumsy?
    if self.is_a?(RPG::Enemy)
      self.ap_schedule
    end
  end
end