################################################################################
#RSTW - Reedo's Scrolling Text Window
## Version 1.0
## September 24, 2013
## By Reedo
##############################################################################
# REFERENCES#
### None. This is an original script by Reedo.#
###############################################################################
# FEATURES#### + New scene with single-window scrolling text area.
## + Menu option for displaying scene, or various script calls.
## + Scene loads plain text file automatically when shown.
## + Text file supports game message slash-command mark-up.
## + Text is scrolled using up/down arrows, sped up with "Z" key (A button),
## and can jump to top or bottom with page up (L) and page down (R).
## + Text can be loaded in "Block mode" to only read up to a specified
## number of text blocks (paragraphs, seperated by a blank line).
## + Block mode index (max blocks shown) can be controlled automatically
## via an associated game variable value, or by script using a static
## property on the scene itself.
## + Scene can always be shown "own demand" via script calls with the
## supplied message text, even if a text file was loaded.
## + Text files can be up to 15K or so with reasonable performance.
## (the upper limit of text size is not fully tested)
## + The Window_Reedo_ScrollText class can be reused by other scenes.
## + The Scene_Reedo_ScrollText class can be used as a basis for other scenes.
#################################################################################
## COMPATIBILITY##
## Should be compatible with most other scripts.
###############################################################################
## REQUIREMENTS#### None.## Optional text file containing text to display.
###############################################################################
## INSTALLATION##
## Plug-and-play##
## Insert below Materials, above other add-on scripts.##
#############################################################################
## RIGHTS & RESTRICTIONS##
## As with most Reedo scripts, this script is free to re-use, as-is,
## in personal, educational, and commercial RPGVX Ace development projects,
## providing that: this script is credited in writing displayed readily
## to the user of the final compiled code assembly.##
## Reedo retains all rights of intellect and ownership.
## You forego all rights of warranty by utilizing this script.##
#############################################################################
## Values from this class are used for settings in the module below.
## Do not modify this class directly.
class RSTW_LoadMode
  NONE = 0 # Specifies that the loading process do nothing.
  ALL = 1 # Reads the entire text file into the window.
  BLOCK = 2 # Reads the text file in blocks (up to a blank line) for the
  # maximum number of blocks defined by the block index.
  CUSTOM = 3 # Allows for custom loading by overriding read_custom.
end
###############################################################################
## USER OPTIONS##
#############################################################################
module RSTW # Display a command in the menu for opening the scene.
  USE_MENU_COMMAND = true # The name of the command when displayed.
  MENU_COMMAND_NAME = "Journal"
  # True to load the specified text file whenever the scene opens.
  LOAD_ON_START = true # The processing mode used to load the text file.
  LOAD_MODE = 1 # 0, 1, 2, 3 - RSTW_LoadMode
  # The Id of the game variable used to store the index of the last displayed
  # text block when using block-mode processing, or nil to use the scene's
  # static block_index property.
  BLOCK_INDEX_VARIABLE = 5
  # The name of the text file to load when LOAD_ON_START is true.
  TEXT_FILE = "Data/Journal.txt"
  # The message displayed in the window when the text file fails to load.
  FILE_READ_ERROR = "[ERROR READING FILE]"
  # The fastest scroll speed for the window; normal scroll is half this value.
  WINDOW_SCROLL_SPEED = 8
end
###############################################################################
## MAIN SCRIPT##
#############################################################################
## EDITS BEYOND THIS POINT ARE AT YOUR OWN RISK!!!##
############################################################################
## Base class override to add menu command
class Window_MenuCommand
  alias rstw_wmc_add_original_commands add_original_commands

  def add_original_commands
    rstw_wmc_add_original_commands
    add_command(RSTW::MENU_COMMAND_NAME, :RSTWCommand, main_commands_enabled) if RSTW::USE_MENU_COMMAND
  end
end

# This is the core scrolling text window which can be reused in other scenes.
class Window_Reedo_ScrollText < Window_Base
  attr_accessor :text
  attr_accessor :text_scroll_speed
  attr_accessor :terminate_at_end

  def initialize
    super(0, 0, Graphics.width, Graphics.height)
    self.arrows_visible = true
    @handler = {}
    @text = ""
    @text_scroll_speed = RSTW::WINDOW_SCROLL_SPEED
    @terminate_at_end = false
    @scroll_pos = 0
    @scroll_on = false
    @scroll_dir = 1
    hide
  end

  def update
    super
    update_message if @text
    process_handling
  end

  def process_handling
    @scroll_on = false
    return unless open? && active
    return process_ok if ok_enabled? && Input.trigger?(:C)
    return process_cancel if cancel_enabled? && Input.trigger?(:B) 
    scrollDelta = contents.height - height + standard_padding * 2 
    if Input.trigger?(:L) && (@scroll_pos > 0)
    then
      @scroll_pos = 0
    end
    if Input.trigger?(:R) && (@scroll_pos < scrollDelta)
    then
      @scroll_pos = scrollDelta
    end
    if Input.press?(:UP) && (@scroll_pos > 0) then
      @scroll_on = true
      @scroll_dir = -1
      return
    end
    if Input.press?(:DOWN) && (@scroll_pos < scrollDelta)
    then
      @scroll_on = true
      @scroll_dir = 1
      return
    end
  end

  def ok_enabled?
    handle?(:ok)
  end

  def cancel_enabled?
    handle?(:cancel)
  end

  def process_ok
    if current_item_enabled?
      Sound.play_ok
      Input.update
      deactivate
      call_ok_handler
    else
      Sound.play_buzzer
    end
  end

  def call_ok_handler
    call_handler(:ok)
  end

  def process_cancel
    Sound.play_cancel
    Input.update
    deactivate
    call_cancel_handler
  end

  def call_cancel_handler
    call_handler(:cancel)
  end

  def set_handler(symbol, method)
    @handler[symbol] = method
  end

  def handle?(symbol)
    @handler.include?(symbol)
  end

  def call_handler(symbol)
    @handler[symbol].call if handle?(symbol)
  end

  def start_message(messageText = nil)
    @text = messageText if messageText
    refresh
    show
  end

  def refresh
    reset_font_settings
    update_all_text_height
    create_contents
    draw_text_ex(4, 0, @text)
  end

  def update_all_text_height
    @all_text_height = 1
    convert_escape_characters(@text).each_line do |line|
    @all_text_height += calc_line_height(line, false)
    end
    reset_font_settings
  end

  def contents_height
    @all_text_height ? @all_text_height : super
  end

  def update_message
    @scroll_pos += (scroll_speed * @scroll_dir) if @scroll_on
    self.oy = @scroll_pos
    terminate_message if ((@scroll_pos >= contents.height) && @terminate_at_end)
  end

  def scroll_speed
    @text_scroll_speed * (show_fast? ? 1.0 : 0.5)
  end

  def show_fast?
    (Input.press?(:A) || Input.press?(:C))
  end

  def terminate_message
    @text = nil
    hide
  end
end

# Base class override to provide menu option handler
class Scene_Menu
  alias rstw_sm_create_command_window create_command_window

  def create_command_window
    rstw_sm_create_command_window
    @command_window.set_handler(:RSTWCommand, method(:command_reedo_show_stw))
  end

  def command_reedo_show_stw
    SceneManager.call(Scene_Reedo_ScrollText)
  end
end

# The custom scene class. This class can be extended to make other scenes that
# use the scrolling text window. Additional windows can be added as needed.
class Scene_Reedo_ScrollText < Scene_Base
  @@selfshow = false
  @@selftext = ""
  @@block_index = 0

  def self.display(text)
    @@selfshow = true
    @@selftext = text
    SceneManager.call(Scene_Reedo_ScrollText)
  end

  def self.block_index
    @@block_index
  end

  def self.block_index=(value)
    @@block_index = value
  end

  def start
    super
    create_background
    create_text_window
    if @@selfshow
      @@selfshow = false
      show_text(@@selftext)
    else
      show_text(load_scene_text) if RSTW::LOAD_ON_START
    end
  end

  def load_scene_text
    case RSTW::LOAD_MODE
    when RSTW_LoadMode::NONE
    when RSTW_LoadMode::CUSTOM
      read_custom
    when RSTW_LoadMode::ALL
      read_all_text
    when RSTW_LoadMode::BLOCK
      read_block_text
    end
  end

# override to provide custom text loading when scene begins
# method should return a string containing the text to display
# should provide acceptable performance up to 10,000 characters
  def read_custom
  end

  def read_all_text
    result = ""
    begin
      File.open(RSTW::TEXT_FILE) do |file|
        result = file.read
      end
    rescue
      result = RSTW::FILE_READ_ERROR
    end
    return result
  end
  
  def read_block_text 
    result = "" 
    max = $game_variables[RSTW::BLOCK_INDEX_VARIABLE] if RSTW::BLOCK_INDEX_VARIABLE 
    max = @@block_index if !max 
    index = 0 
    begin 
      File.open(RSTW::TEXT_FILE) do |file| 
      file.each_line do |line| 
        break if index > max 
        result += line #+ "\n" 
        index +=1 if line == "\n" 
      end 
    end 
    rescue result = RSTW::FILE_READ_ERROR 
    end 
    return result 
  end 

  def terminate
    super
    dispose_background
  end

  def create_background
    @background_sprite = Sprite.new
    @background_sprite.bitmap = SceneManager.background_bitmap
    @background_sprite.color.set(16, 16, 16, 128)
  end

  def dispose_background
    @background_sprite.dispose
  end

  def create_text_window
    @text_window = Window_Reedo_ScrollText.new
    @text_window.set_handler(:cancel, method(:return_scene))
  end

  def show_text(text)
    @text_window.start_message(text)
    @text_window.activate
  end

  def close_text
    @text_window.terminate_message
  end
end