=begin
================================================================================ 
---INFO

Script:     SUPER SIMPLE MOUSE SCRIPT diagonal movement patch
Difficulty: Plug and Play
Author:     Shaz + Amaranth (mouse script), Lordosthyvel (patch)

-------------------------------------------------------------------------------- 
---REQUIREMENTS

SUPER SIMPLE MOUSE SCRIPT by Shaz + Amaranth
(http://forums.rpgmakerweb.com/index.php?/topic/17829-amaranths-super-simple-mouse-system-for-ace/)
  
-------------------------------------------------------------------------------- 
---DESCRIPTION

Allows for diagonal movement in "SUPER SIMPLE MOUSE SCRIPT" by Shaz + Amaranth.    
-------------------------------------------------------------------------------- 
---TERMS
    
Free to use in any project, credits optional.
Make sure you check the terms for super simple mouse script as well :)
    
-------------------------------------------------------------------------------- 
---INSTALLATION

1. Install Super Simple Mouse Script above "Main"
2. Install this script below Materials
3. ???
4. PROFIT

-------------------------------------------------------------------------------- 
---ADDITIONAL INFO

MIGHT be incompatible with scripts that overwrites or modifies "move_diagonal"
function on Game_CharacterBase class.

-------------------------------------------------------------------------------

=end

class Game_CharacterBase
  def run_path
    return if moving?
    @step = @map.nil? || @map[@x, @y].nil? ? 0 : @map[@x, @y] - 1
    if @step < 1
      clear_path
    else
      x, y = @x, @y
      dirs = []
      dirs.push(6) if @map[@x+1, @y] == @step && passable?(@x, @y, 6)
      dirs.push(4) if @map[@x-1, @y] == @step && passable?(@x, @y, 4)
      dirs.push(2) if @map[@x, @y+1] == @step && passable?(@x, @y, 2)
      dirs.push(8) if @map[@x, @y-1] == @step && passable?(@x, @y, 8)
      

      while dirs.size > 0
        # move diagonal if we have 2 dirs to move and the tile is passable
        if dirs.size == 2 && diagonal_passable?(@x,@y,dirs[0],dirs[1])
          move_diagonal(dirs[0],dirs[1])
          dirs.delete_at(0)
          dirs.delete_at(0)
        # only one dir, so move straight
        else
          dir = dirs.delete_at(rand(dirs.size))
          move_straight(dir)
        end
        break if x != @x || y != @y
      end
      # clear the path if we couldn't move
      clear_path if x == @x && y == @y
    end
  end
end