# *****************************************************************************
#
# OC AUDIO ENCRYPTION
# Author: Ocedic
# Site: http://ocedic.wordpress.com/
# Version: 1.0
# Last Updated: 7/17/13
#
# Updates:
# 1.0  - First release
#
# *****************************************************************************

$imported = {} if $imported.nil?
$imported["OC-AudioEncryption"] = true

#==============================================================================
# ▼ Introduction
# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# This script will encrypt your audio files and decrypt them during play.
# Some important notes:
#
# * MP3s cannot be encrypted
# * This encryption is very rudimentary and easy to circumvent
# 
# Essentially, this script is designed to protect your audio files from your
# regular Average Joe user. The fact is even if a 100% unbreakable 
# encryption script existed, people could simply record the audio from your
# game and extract it that way.
#==============================================================================
# ▼ Instructions
# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# First, it's recommended that you change the default CIPHER_KEY and 
# ENCRYPTED_FILE values in the configuration settings before you proceed.
#
# Run the script with ENCRYPT_AT_STARTUP set to true. This will create an
# encrypted version of all audio files in your music folder.
#
# Set ENCRYPT_AT_STARTUP to false and move your original audio files to a new
# location.
#==============================================================================
# ▼ Compatibility
# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# This script may not be compatible with scripts that change the way audio is
# played. If an incompatibility occurs, try placing this script above other
# scripts.
#==============================================================================
# ▼ Terms of Use
# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# Can be freely used and modified in non-commercial projects. Proper attribution 
# must be given to Ocedic, and this header must be preserved.
# For commercial terms, see here: https://ocedic.wordpress.com/terms-of-use/
#==============================================================================

#==============================================================================
# ■ Configuration
#------------------------------------------------------------------------------
#  Change customizable settings here
#==============================================================================
module OC
  module ENCRYPT
    
#==============================================================================
# * Encrypt at Startup *
#------------------------------------------------------------------------------
#   This boolean value controls whether or not files are encrypted when the
#   game is booted. If true, the script will iterate through all audio files
#   in "Audio/BGM/" and encrypt them. When you have done this once, it's
#   recommended that you move the original audio files to a secure backup
#   directory and set this value to false.
#==============================================================================  
    ENCRYPT_AT_STARTUP = true
    
#==============================================================================
# * Cipher Key *
#------------------------------------------------------------------------------
#   This key will be used to encrypt and decrypt audio files. Note that 
#   changing this string after you have encrypted your files will cause they to 
#   be incorrectly decrypted. It's advised that you choose a string at the 
#   beginning and stick with it!
#==============================================================================    
    CIPHER_KEY = "DONKEY"
    
#==============================================================================
# * Encrypted Extension *
#------------------------------------------------------------------------------
#   The extension of the encrypted audio files.
#------------------------------------------------------------------------------
# * Encrypted File *
#------------------------------------------------------------------------------
#   The name and path of unencrypted audio files. It's recommended that you
#   change this filepath to a more obtuse directory.
#============================================================================== 
    ENCRYPTED_EXT = ".dog"
    ENCRYPTED_FILE = "System/RGSSAudio"
    
  end #ENCRYPT
end #OC

#==============================================================================
# ■ SceneManager
#==============================================================================
module SceneManager
  
  class << self
    alias oc_scene_manager_run_8pqe91 run
  end
  def self.run
    if OC::ENCRYPT::ENCRYPT_AT_STARTUP
      Dir.foreach("Audio/BGM/") do |item|
        next if item == "." || item == ".." 
        next if item =~ /#{OC::ENCRYPT::ENCRYPTED_EXT}/
        item = "Audio/BGM/" + item
        Audio.encrypt(item)
      end
    end
    oc_scene_manager_run_8pqe91
  end
    
end

#==============================================================================
# ■ Audio
#==============================================================================
module Audio
  
  @fileswitch = false
  
#==============================================================================
# * New Method: Encrypt *
#==============================================================================
  def self.encrypt(filename)
    sourcefile = File.open(filename, "rb")
    content = sourcefile.readlines
    sourcefile.close
    encry_filename = Audio.strip_extension(filename)
    targetfile = File.open(encry_filename + OC::ENCRYPT::ENCRYPTED_EXT, "wb")
    for i in 0...content.size
      content[i] = OC::ENCRYPT::CIPHER_KEY + content[i]
    end
    Marshal.dump(content, targetfile)
    targetfile.close
  end
  
#==============================================================================
# * New Method: Decrypt *
#==============================================================================  
  def self.decrypt(filename)
    sourcefile = File.open(filename + OC::ENCRYPT::ENCRYPTED_EXT, "rb")
    content = Marshal.load(sourcefile)
    for i in 0...content.size
      value = content[i]
      content[i] = value[OC::ENCRYPT::CIPHER_KEY.length, content[i].size]
    end
    sourcefile.close
    begin
      targetfile = File.open(OC::ENCRYPT::ENCRYPTED_FILE, "wb")
      @fileswitch = false
    rescue
      targetfile = File.open(OC::ENCRYPT::ENCRYPTED_FILE + "1", "wb")
      @fileswitch = true
    end
    for i in 0...content.size
      targetfile.write(content[i])
    end
    targetfile.close
  end
  
#==============================================================================
# * New Method: Strip Extension *
#==============================================================================
  def self.strip_extension(filename)
    result = filename.chomp(File.extname(filename))
    return result
  end
  
#==============================================================================
# * New Method: Fileswitch *
#==============================================================================
  def self.fileswitch
    return @fileswitch
  end
  
end

#==============================================================================
# ■ RPG::BGM
#==============================================================================
class RPG::BGM < RPG::AudioFile
  
#==============================================================================
# * Overwrite: Play *
#==============================================================================
  def play(pos = 0)
    if @name.empty?
      Audio.bgm_stop
      @@last = RPG::BGM.new
    else
      filename = "Audio/BGM/" + @name
      if FileTest.exist?(filename + OC::ENCRYPT::ENCRYPTED_EXT)
        Audio.decrypt(filename)
        if !Audio.fileswitch
         Audio.bgm_play(OC::ENCRYPT::ENCRYPTED_FILE, @volume, @pitch, pos)
         begin
           File.delete(OC::ENCRYPT::ENCRYPTED_FILE + "1")
         rescue
         end
        else
         Audio.bgm_play(OC::ENCRYPT::ENCRYPTED_FILE + "1", @volume, @pitch, pos)
         begin
           File.delete(OC::ENCRYPT::ENCRYPTED_FILE)
         rescue
         end
        end
      else
        Audio.bgm_play(filename, @volume, @pitch, pos)
      end
      @@last = self.clone
    end
  end
  
end