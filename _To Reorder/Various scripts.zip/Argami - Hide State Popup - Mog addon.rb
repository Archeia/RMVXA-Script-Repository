#==============================================================================
# ■ [ACE] Hide State's PopUp Addon for MOG - DAMAGE POPUP (v4.5)
#==============================================================================
# * Made by Argami
#==============================================================================
#==============================================================================
# ● DESCRIPTION
#------------------------------------------------------------------------------
# Disables the Popup effect of the States you want.
#------------------------------------------------------------------------------
# ● REQUERIMENTS
#------------------------------------------------------------------------------
# Requires MOG - DAMAGE POPUP (v4.5) Script by Moghunter:
# https://atelierrgss.wordpress.com/rgss3-damage-popup/
#------------------------------------------------------------------------------
# ● INSTALLATION
#------------------------------------------------------------------------------
# Place this script below MOG - DAMAGE POPUP (v4.5) Script but above ▼ Main!
#------------------------------------------------------------------------------
# ● HOW TO USE
#------------------------------------------------------------------------------
# Add the following code in the Databases's Note Box of the State you don't
# want to show the popup effect off:
#
#  <State Popup OFF>
#
#==============================================================================

class Game_Battler < Game_BattlerBase
  include MOG_DAMAGEPOPUP
  attr_accessor :damage , :skip_dmg_popup

  #--------------------------------------------------------------------------
  # ● Execute Popup Add New State
  #--------------------------------------------------------------------------
 def execute_popup_add_new_state(state_id)
      st = $data_states[state_id]
      #Check the State Note Box to find <State Popup OFF>
      state_popup_off = st.note =~ /<State Popup OFF>/ ? st : nil
      #Stop here if there's <State Popup OFF>
      return if state_popup_off != nil
      if self.hp > 0
         unless (SceneManager.scene_is?(Scene_Battle) and !STATES_POPUP_BATTLE) or
                (SceneManager.scene_is?(Scene_Map) and !STATES_POPUP_MAP)
                self.damage.push([st.name.to_s,"States Plus",false,st.icon_index])
         end
      end
  end

  #--------------------------------------------------------------------------
  # ● Execute Popup Remove State
  #--------------------------------------------------------------------------
  def execute_popup_remove_state(state_id)
      if state?(state_id) and self.hp > 0
         st = $data_states[state_id]
         #Check the State Note Box to find <State Popup OFF>
         state_popup_off = st.note =~ /<State Popup OFF>/ ? st : nil
         #Stop here if there's <State Popup OFF>
         return if state_popup_off != nil
         unless (SceneManager.scene_is?(Scene_Battle) and !STATES_POPUP_BATTLE) or
                (SceneManager.scene_is?(Scene_Map) and !STATES_POPUP_MAP)
                self.damage.push([st.name.to_s,"States Minus",false,st.icon_index]) unless BattleManager.escape?
         end
      end
  end  
end