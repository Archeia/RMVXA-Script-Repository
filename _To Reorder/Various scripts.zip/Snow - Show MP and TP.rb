#==============================================================================
# ■ [Snow] MP and TP display addon for Yanfly's Ace Battle Engine
#------------------------------------------------------------------------------
# This script will display TP and MP in the Skill List if both are required.
#------------------------------------------------------------------------------
# This was made for people who use Yanfly's Ace Battle Engine.
# It repositions the actor window when bringing up the skill window, so that
# the MP and TP costs get the space they need.
#------------------------------------------------------------------------------
# Place UNDER Yanfly's Ace Battle Engine. Plug 'n Play script.
#==============================================================================
class Scene_Battle < Scene_Base  
  def create_battle_status_aid_window
    @status_aid_window = Window_BattleStatusAid.new
    @status_aid_window.status_window = @status_window
    @status_aid_window.x = 0
    @status_aid_window.y = 176
  end
 
  def create_skill_window
    scene_battle_create_skill_window_abe
    @skill_window.height = @info_viewport.rect.height
    @skill_window.width = 544
    @skill_window.y = Graphics.height - @skill_window.height
  end  
end

class Window_SkillList < Window_Selectable  
   def draw_skill_cost(rect, skill)
    if @actor.skill_tp_cost(skill) > 0    
	  change_color(tp_cost_color, enable?(skill))
	  draw_text(rect, @actor.skill_tp_cost(skill), 2)
    end
	  if @actor.skill_mp_cost(skill) > 0   
	    change_color(mp_cost_color, enable?(skill))
	    rect.width -= 35
	    draw_text(rect, @actor.skill_mp_cost(skill), 2)
	  end
  end
end