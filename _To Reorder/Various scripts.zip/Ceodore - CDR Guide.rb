=begin
================================================================================
 CDR - Guide 1.0
 -------------------------------------------------------------------------------
 Author: Ceodore
 Mail: ceodore@email.com
 https://ceodoremaker.wordpress.com

===============================Change log=======================================
  16/03/2013 - 1.0 release.
  
===============================Description======================================
  This implementation is meant to provide a way to guide the user on a scene. It
  was made to allow in-game tutorials, like menu or battle tutorials. 

=================================License========================================
  You may freely use and modify this script as long as you do not change the
  original author information. If you use this on your game, include the author
  on the credits.

=========================Instalation & Compatibility============================   
  Insert this script above main. Currently, only menu scenes, shop scenes and 
  battle scenes were tested.

===================================Use==========================================
  You just need to follow the examples and create your sequences. To enable a 
  guide on the list, call a script event command and paste this line:
  
  GuideManager.enable(x)
  
  Where x is the guide id/switch.
  
  Alternatively, you can enable the guide by turning it's Switch ON. In this
  case, the guide will start automatically once when you enter the scene, but 
  this feature is still experimental, you may use it at your own risk.

  You can use wathever tags you would use on a message, just don't forget to 
  escape code characters, for example, \C[1] must be put as \\C[1]. This
  happens because the strings on this script are not treated as your regular 
  message strings, where the \ character is automatically escaped.

=================================Commands=======================================
  The guide will follow a list of commands, wich can be a key input or a 
  message, this is the list of currently supported commands:
  
  ## Show Message ##
  [:msg, "string", {:face_name => string, 
                    :face_index => int, 
                    :background => int, 
                    :position => int}]
  This will display the string on a message window. The values on the
  dictionary are all optional, If you are not using any options, you can just
  use this format:
  [:msg, string]
  :face_name stands for the face file name placed on the Graphics/Faces dir
  :face_index stands for the face index inside the image, if you define a
              face name, you MUST define a face index.
  
  The :background and :position have specific values, explained below:
  
  :background 
    0 -> Normal Window
    1 -> Dim Background
    2 -> Transparent
  
  :position
    0 -> Top of the screen
    1 -> Middle of the screen
    2 -> Bottom of the screen
  
   ## Show Message (Battle) ##
   [:msg, {:wait => int}]
   For the sake of compatibility with various battle scripts, the guide messages
   are displayed in the battle log on battle scenes, instead of a normal
   message window. You can use pretty much all message codes, like display 
   icons, change colors, an all... but there are obvious limitations:
   1. The battle log works with a line at a time. You can pile then in 
      sequence, but it will hardly look like a default message window.
   2. The battle log will not accept default message window options, like
      face, position or background.
   The big advantage is that the battle log window can be displayed at any 
   moment without closing any window, so the guide flux will not be stopped to
   show a message.
   The :wait option stands for the time before the message closes automatically.
   It's optional, default is 10.
  
  ## Change Switch ##
  [:sw, number, boolean]
  Specifies a switch to be turned on or off.
  
  ## Change Variable ##
  [:var, number, string]
  The string can contain a number or any expression wich could be processed by 
  the eval() method, like "1 * 2" or "$game_variables[2]", the generated value 
  will be assigned to the specified variable.
  
  ## Input Key ##
  [:key, input, times]
  This will force a key input. It supports any inputable character the RPG 
  Maker accepts. Here are the main ones for menus:
    :DOWN  -> Forces down key
    :UP    -> Forces up key
    :RIGHT -> Forces right key
    :LEFT  -> Forces left key
    :R     -> Forces page down key
    :L     -> Forces page up key
    :C     -> Forces confirm key
    :B     -> Forces cancel key
  The times parameter is optional and stands for the number of times this 
  command will repeat. When no times attribute is found, it will execute the 
  command once.
  
  ## Change Rate ##
  [:rate, number]
  Changes the update rate to this number, the update rate will be restored to 
  default value at the guide's end.
================================================================================
=end
$imported = {} if $imported.nil?
$imported['CDR-Rows'] = true
module CDR_GUIDE
  # This defines the interval between commands, in frames. Smaller the value,
  # higher the speed
  DEFAULT_UPDATE_RATE = 40
  
  # This defines if the Guide List menu item will be added. This new item
  # will be placed below End Game and can access the guide list scene.
  ADD_MENU_ITEM = true
  
  # This defines the index of the icon wich will be displayed as the file
  # icon for each available guide on the Guide_Scene.
  GUIDE_FILE_ICON = 286
  
  # The menu item name
  MENU_ITEM_NAME = "Guide List"
  
  # The string for unread guides on guide list
  NEW_STRING = "NEW"
  
  # The string for the help window on the guide list scene
  HELP_WINDOW_TEXT = "Select a Guide"
  
  # The color for unread guides on guide list
  NEW_COLOR = 6
  
  # The bgm to be played when you are on a guide. Set as nil if you do not wish 
  # a specific BGM.
  #           [file name, {options}]
  GUIDE_BGM = ["Field2",{:volume=>100, :pitch=>100, :pos=>0}]
  
  # The bgm to be played when you are on a shop guide. Set as nil if you do not 
  # wish  a specific BGM.
  #           [file name, {options}]
  SHOP_GUIDE_BGM = ["Field2"]
  
  # The bgm to be played when you are on a battle guide. Set as nil if you
  # do not wish a specific BGM.
  #           [file name, {options}]
  BATTLE_GUIDE_BGM = ["Battle2"]
  
  #=============================================================================
  # MOCK_PARTY_DATA
  #=============================================================================   
  # Here is the list of fake parties for guide purposes. It can be realy useful
  # if your guide depends on the selection of a specific party member, or a
  # specific party state, like certain item available on top of the item list,
  # a member with depleted HP or high TP. After the guide stops, the original
  # party will be automatically restored as it was. The dictionary key is for
  # reference only, but must be unique for each mock party.
  MOCK_PARTY_DATA = {
     1 => { # Optional, the party member's ids
            :members => [11,12],
            # Optional, the weapons on the party inventory
            :weapon => [# [id, quantity]
                          [1,1]
                        ],
            # Optional, the armor's id's on the party inventory
            :armor => [# [id, quantity]
                         [1,1],
                         [2,1]
                      ],
            # Optional, the item's id's on the party inventory
            :item => [# [id, quantity]
                        [1,2]
                      ],
            # Optional, the party gold amount
            :gold => 1000,
            # Actor setup, here you can define default values for each actor
            :setup => [
              # [actor_id, {options}]
              [11, {:hp => 100, :tp => 20, :mp => 20}],
              [12, {:hp => 150}],
            ]
          }, #end of example mock party
  }#end of mock party data
  
  #=============================================================================
  # GUIDE_DATA
  #=============================================================================
  # This is the dictionary of guides, please follow the example to create one,
  # please read the comments carefully.
  # The ID of the guide (the key for the dictionary item) references for a 
  # game SWITCH, so the guide will be ready to start every time the switch is
  # turned on and you are on the guide's scene.
  GUIDE_DATA = {
  
  # Example of menu guide. This will guide the player to the status scene. 
    1 =>   {# The guide type can be either :menu or :battle, a menu guide will
            # aways start from the main menu.
            :scene => Scene_Status,
            # The mock party id, this is optional, when no :party attribute is
            # defined, the current party will be used.
            :party => 1,
            # The guide name to be displayed on the guide list.
            :name => "How to Use the Status Screen", 
            # An array containing this guide's commands
            :commands =>  [ 
                # Notice how the message is placed on this example. When you
                # break a line on the editor, the line break will be considered
                # on the message, however, the spaces from the left corner too,
                # so unless you intent to leave spaces on the line's left, lean 
                # the line on the left corner. Another thing to notice are the 
                # escaped characters, let's say you would put a message 
                # code \C[1], instead you MUST put the extra \ before it, so it 
                # becomes \\C[1]. If you don't, it will display an error.
                [:msg, "This is the Status screen. Here you can see
the hero details. You can switch between 
heroes using \\c[4]Q\\c[0] and \\c[4]W\\c[0] keys on your 
keyboard. ", {:background => 1, :position => 1}],
                [:key, :R, 3],
                [:msg, "Now you know how to use the Status screen!", 
                                        {:background => 1, :position => 1}],
           ]}, #end of example guide
           
      # Example of battle guide
      2 => {
          :scene => Scene_Battle,
          :troop => 31, # Required, a battle must have a troop id.
          :party => 1,
          :name => "How to Attack the Enemy",
          :commands => [
              [:key, :C],
              [:msg, "When the actor menu appears, select Attack." ],
              [:key, :C],
              [:msg, "Now, select an enemy." ],
              [:key, :C,3],
              [:msg, "Now you know how to attack!" ]
            ]
          },
      # Example of shop guide
      3 => {
          :scene => Scene_Shop,
          :name => "How to Buy an Item",
          :party => 1,
          :goods => { # Optional, this will define the goods the shop will sell
                      :weapon => [1,2,3],
                      :armor => [1,2,3],
                      :item => [1,2,3]
                    },
          :commands => [
                [:msg, "Select the Buy option."],
                [:key, :C],
                [:msg, "Now you select an item."],
                [:key, :C],
                [:msg, "Select the quantity."],
                [:key, :RIGHT, 2],
                [:msg, "Now, confirm the buy."],
                [:key, :C],
                [:msg, "Now you know how to buy!"],
              ]
      },
  }#end of guide data

end
#==============================================================================
# DO NOT CHANGE beyond this point, unless you know what you're doing.
#==============================================================================

# Input module duplicate to use the original methods.
SuperInput = Input.dup

#==============================================================================
# ** Input
#==============================================================================
module Input

  # Flag that defines the currently forced key.
  @force_key = :NONE  

  # Flag that defines if player input is halted.
  @halt_player_input = false
  
  # Flag that indicates if the key to be forced was used
  @pending_key = false
  
  #--------------------------------------------------------------------------
  # * method rewrite: adds key forcing logics
  #--------------------------------------------------------------------------
  def self.repeat?(input)
    return true if @force_key == input
    return false if @force_key != :NONE
    return SuperInput.repeat?(input) if !@halt_player_input
    return false
  end
  
  #--------------------------------------------------------------------------
  # * method rewrite: adds key forcing logics
  #--------------------------------------------------------------------------
  def self.trigger?(input)
    if @force_key == input
      @force_key = :NONE
      return true
    end
    return SuperInput.trigger?(input) if !@halt_player_input
    return false
  end
  #--------------------------------------------------------------------------
  # * method rewrite: adds key forcing logics
  #--------------------------------------------------------------------------
  def self.press?(input)
    return true if @force_key == input  
    return false if @force_key != :NONE
    return SuperInput.press?(input) if !@halt_player_input
    return false
  end
  
  #--------------------------------------------------------------------------
  # * new method: defines the key to be forced
  #--------------------------------------------------------------------------
  def self.force_key(input)
    @force_key = input
  end  
  
  #--------------------------------------------------------------------------
  # * new method: returns true if a key is being forced
  #--------------------------------------------------------------------------
  def self.force_key?
    return @force_key != :NONE
  end
  
  #--------------------------------------------------------------------------
  # * new method: halts player input
  #--------------------------------------------------------------------------
  def self.halt
    @halt_player_input = true
  end
  
  #--------------------------------------------------------------------------
  # * new method: releases player input
  #--------------------------------------------------------------------------
  def self.release
    @halt_player_input = false
  end
end
#==============================================================================
# ** Sound
#==============================================================================
module Sound
  #--------------------------------------------------------------------------
  # * new method: plays the guide default bgm
  #--------------------------------------------------------------------------
  def self.play_guide_bgm
    play_bgm(CDR_GUIDE::GUIDE_BGM) if CDR_GUIDE::GUIDE_BGM
  end
  #--------------------------------------------------------------------------
  # * new method: plays the battle guide default bgm
  #--------------------------------------------------------------------------
  def self.play_battle_guide_bgm
    play_bgm(CDR_GUIDE::BATTLE_GUIDE_BGM) if CDR_GUIDE::BATTLE_GUIDE_BGM
  end
  #--------------------------------------------------------------------------
  # * new method: plays the shop guide default bgm
  #--------------------------------------------------------------------------
  def self.play_shop_guide_bgm
    play_bgm(CDR_GUIDE::SHOP_GUIDE_BGM) if CDR_GUIDE::SHOP_GUIDE_BGM
  end
  #--------------------------------------------------------------------------
  # * new method: plays a guide bgm
  #--------------------------------------------------------------------------
  def self.play_bgm(guide_bgm)
    volume = 100
    pitch = 100
    pos = 0
    if guide_bgm[1]      
      volume = guide_bgm[1][:volume] if guide_bgm[1][:volume]    
      pitch = guide_bgm[1][:pitch] if guide_bgm[1][:pitch]
      pos = guide_bgm[1][:pos] if guide_bgm[1][:pos]
    end
    Audio.bgm_play(sprintf('Audio/BGM/%s', guide_bgm[0]), volume, pitch, pos)
    Audio.bgs_stop
  end
end
#==============================================================================
# ** Input
#==============================================================================
module GuideManager
  @memory = []
  @read = []
  @commands = []
  @index = 0
  @repeat_count = 0
  @last_command = false  
  @current_key = 0
  @type = nil
  @update_rate = CDR_GUIDE::DEFAULT_UPDATE_RATE
  #--------------------------------------------------------------------------
  # * new method: defines the guide to be followed
  #--------------------------------------------------------------------------
  def self.guide(key, guide)  
    @current_key = key
    @memory.push(key)
    @memory.compact!
    @memory.uniq!
    @memory.sort!
    @commands = guide[:commands]
    @scene = guide[:scene]
    return if !guide[:party]
    mock_party = CDR_GUIDE::MOCK_PARTY_DATA[guide[:party]]
    $party_backup = $game_party unless $game_party.mock_party?
    $game_party = Game_MockParty.new
    if mock_party[:members]
      mock_party[:members].each{|actor_id| $game_party.add_actor(actor_id)}
    end
    if mock_party[:weapon]
      mock_party[:weapon].each{|item|
       $game_party.gain_item($data_weapons[item[0]], item[1]) 
      }
    end
    if mock_party[:armor]
      mock_party[:armor].each{|item|
       $game_party.gain_item($data_armors[item[0]], item[1]) 
      }  
    end
    if mock_party[:item]
      mock_party[:item].each{|item|
       $game_party.gain_item($data_items[item[0]], item[1]) 
      }      
    end
    if mock_party[:gold]
      $game_party.gain_gold(mock_party[:gold])
    end
    if mock_party[:setup]
      mock_party[:setup].each{|change|
        actor = $game_actors[change[0]]
        options = change[1]
        actor.set_hp(options[:hp]) if options[:hp]
        actor.set_tp(options[:tp]) if options[:tp]
        actor.set_mp(options[:mp]) if options[:mp]
      }
    end
  end
  #--------------------------------------------------------------------------
  # * new method: enabled a guide in the Guide_Scene
  #--------------------------------------------------------------------------
  def self.enable(key)  
    @memory.push(key)
    @memory.compact!
    @memory.uniq!
    @memory.sort!
  end
  #--------------------------------------------------------------------------
  # * new method: returns true if guide variable is an empty array
  #--------------------------------------------------------------------------
  def self.disable(key)  
    @memory.remove(key)
    @memory.sort!
  end
  #--------------------------------------------------------------------------
  # * new method: enabled a guide in the Guide_Scene
  #--------------------------------------------------------------------------
  def self.mark_as_read  
    return if @current_key == 0
    @read.push(@current_key)
    @read.compact!
    @read.uniq!
    @read.sort!
  end
  #--------------------------------------------------------------------------
  # * new method: returns true if guide variable is an empty array
  #--------------------------------------------------------------------------
  def self.read?(key)  
    @read.include?(key)    
  end
  #--------------------------------------------------------------------------
  # * new method: clears the guide sequence and control variables
  #--------------------------------------------------------------------------
  def self.clear  
    mark_as_read
    self.replay_bgm_and_bgs
    @last_command = false    
    @current_key = 0
    @commands = []
    @index = 0
    @repeat_count = 0 
    @scene = nil
    @update_rate = CDR_GUIDE::DEFAULT_UPDATE_RATE
    $game_party = $party_backup if $game_party.mock_party?  
    $game_player.refresh
    $game_map.need_refresh = true
    SceneManager.return
  end 
  #--------------------------------------------------------------------------
  # * new method: returns true if guide variable is an empty array
  #--------------------------------------------------------------------------
  def self.empty?
    @commands.empty?
  end 
  #--------------------------------------------------------------------------
  # * new method: defines a new list of guide commands
  #--------------------------------------------------------------------------
  def self.commands=(commands)
    @commands = commands
  end 
  #--------------------------------------------------------------------------
  # * new method: defines a new update rate
  #--------------------------------------------------------------------------
  def self.update_rate=(update_rate)
    @update_rate = update_rate
  end
  #--------------------------------------------------------------------------
  # * new method: access the current update rate
  #--------------------------------------------------------------------------
  def self.update_rate
    [@update_rate,1].max
  end
  #--------------------------------------------------------------------------
  # * new method: returns true if guide variable is an empty array
  #--------------------------------------------------------------------------
  def self.guide_list
    named = []
    @memory.each{|switch|
      if !CDR_GUIDE::GUIDE_DATA[switch][:name].nil?
        named.push(switch)
      end
    }
    return named
  end 
  #--------------------------------------------------------------------------
  # * new method: returns true if guide variable is an empty array
  #--------------------------------------------------------------------------
  def self.battle_guide?  
    CDR_GUIDE::GUIDE_DATA[@current_key][:scene] == Scene_Battle   
  end
  #--------------------------------------------------------------------------
  # * new method: defines a new value for guide index
  #--------------------------------------------------------------------------
  def self.index=(index)
    @index = index
  end 
  #--------------------------------------------------------------------------
  # * new method: defines a new value for repetition counter
  #--------------------------------------------------------------------------
  def self.repeat_count=(count)
    @repeat_count = count-1
  end   
  #--------------------------------------------------------------------------
  # * new method: decreases the repetition count
  #--------------------------------------------------------------------------
  def self.decrease_count
    @repeat_count -= 1 if counting?
  end 
  #--------------------------------------------------------------------------
  # * new method: returns true if the repeat count is bigger than zero
  #--------------------------------------------------------------------------
  def self.counting?
    @repeat_count > 0
  end 
  #--------------------------------------------------------------------------
  # * new method: returns the current guide command being processed
  #--------------------------------------------------------------------------
  def self.current_command
    @last_command = !next_command?
    @commands[@index]
  end
  #--------------------------------------------------------------------------
  # * new method: steps to the next command
  #--------------------------------------------------------------------------
  def self.next_command    
    @index += 1 
  end  
  #--------------------------------------------------------------------------
  # * new method: return true if the are any commands left to process
  #--------------------------------------------------------------------------
  def self.next_command?
    return !@commands[@index+1].nil?
  end
  #--------------------------------------------------------------------------
  # * new method: returns true if a guide command is running
  #--------------------------------------------------------------------------
  def self.running?
    return (counting? or next_command?)
  end
    #--------------------------------------------------------------------------
  # * Save BGM and BGS
  #--------------------------------------------------------------------------
  def self.save_bgm_and_bgs
    @map_bgm = RPG::BGM.last
    @map_bgs = RPG::BGS.last
  end
  #--------------------------------------------------------------------------
  # * Resume BGM and BGS
  #--------------------------------------------------------------------------
  def self.replay_bgm_and_bgs
    @map_bgm.replay unless @map_bgm.nil?
    @map_bgs.replay unless @map_bgs.nil?
  end
end

#==============================================================================
# ** Game_Party
#==============================================================================
class Game_Party < Game_Unit
  #--------------------------------------------------------------------------
  # * new method: identifies as a mock party
  #--------------------------------------------------------------------------
  def mock_party?
    false
  end
end
#==============================================================================
# ** Game_Actor
#==============================================================================
class Game_Actor < Game_Battler
  #--------------------------------------------------------------------------
  # * new method: changes the actor's hp value
  #--------------------------------------------------------------------------
  def set_hp(hp)
    self.hp = hp
  end
  #--------------------------------------------------------------------------
  # * new method: changes the actor's mp value
  #--------------------------------------------------------------------------
  def set_mp(mp)
    self.mp = mp
  end
  #--------------------------------------------------------------------------
  # * new method: changes the actor's tp value
  #--------------------------------------------------------------------------
  def set_tp(tp)
    self.tp = tp
  end  
end
#==============================================================================
# ** Game_MockParty
#==============================================================================
class Game_MockParty < Game_Party
  #--------------------------------------------------------------------------
  # * new method: identifies as a mock party
  #--------------------------------------------------------------------------
  def mock_party?
    true
  end
end
#==============================================================================
# ** Scene_Base
#==============================================================================
class Scene_Base  
  #--------------------------------------------------------------------------
  # * method alias: creates the guide message window
  #--------------------------------------------------------------------------
  alias cdr_guide_start start
  def start
    Input.halt              
    $game_message.visible = false
    if (!self.is_a?(Scene_Map))
      create_message_window
      CDR_GUIDE::GUIDE_DATA.each{ |switch, guide|  
        if($game_switches[switch] and self.is_a?(guide[:scene]))        
          $game_switches[switch] = false
          GuideManager.guide(switch, guide)
          break
        end
      }
    end
    cdr_guide_start    
    Input.release  
  end
  
  #--------------------------------------------------------------------------
  # * new method: creates the message window
  #--------------------------------------------------------------------------
  def create_message_window
    @message_window = Window_Message.new
    @message_window.z = @message_window.z+100
  end
  
  #--------------------------------------------------------------------------
  # * method alias: fires the guide process
  #--------------------------------------------------------------------------
  alias cdr_guide_update update 
  def update  
    update_guide  
    cdr_guide_update
  end
  
  #--------------------------------------------------------------------------
  # * new method: process guide logic
  #--------------------------------------------------------------------------
  def wait_for_message
    @message_window.update
    update_for_wait while $game_message.visible
  end
  
  #--------------------------------------------------------------------------
  # * new method: process guide logic
  #--------------------------------------------------------------------------
  def update_guide 
    return if skip_guide_update?
    if GuideManager.current_command.nil?
      GuideManager.clear
      return
    end 
    Input.halt
    return if Graphics.frame_count%GuideManager.update_rate != 0     
    process_guide_command(GuideManager.current_command)
  end   
  #--------------------------------------------------------------------------
  # * new method: returns true if a guide update must be skipped
  #--------------------------------------------------------------------------
  def skip_guide_update?
    return true if GuideManager.empty?
  end
  #--------------------------------------------------------------------------
  # * new method: returns true if a guide update must be skipped
  #--------------------------------------------------------------------------
  def process_guide_command(command)
    case command[0]
      when :key 
        Input.force_key(command[1])
        if GuideManager.counting?
          GuideManager.decrease_count  
        else
          GuideManager.repeat_count = command[2] if !command[2].nil?
        end
        GuideManager.next_command if !GuideManager.counting?
      when :msg   
        process_message(command)       
        GuideManager.next_command
      when :sw
        $game_switches[command[1]] = command[2]
        GuideManager.next_command
      when :var
        $game_variables[command[1]] = eval(command[2])
        GuideManager.next_command
      when :rate
        GuideManager.update_rate = command[1]
        GuideManager.next_command
    end           
  end
  #--------------------------------------------------------------------------
  # * new method: process the current message command
  #--------------------------------------------------------------------------
  def process_message(command)
    $game_message.add(command[1])
    if !command[2].nil?
      options = command[2]
      $game_message.face_name = options[:face_name] if options[:face_name]
      $game_message.face_index = options[:face_index] if options[:face_index]
      $game_message.background = options[:background] if options[:background]
      $game_message.position = options[:position] if options[:position]
    end
    Input.release
    wait_for_message
    Input.halt
  end
  #--------------------------------------------------------------------------
  # * new method: generic method to wait for message proessing
  #--------------------------------------------------------------------------
  def update_for_wait
    update_basic
  end 

  #--------------------------------------------------------------------------
  # * new method, disposes message window
  #--------------------------------------------------------------------------
  alias cdr_guide_dispose_all_windows dispose_all_windows
  def dispose_all_windows
    cdr_guide_dispose_all_windows
    @message_window.dispose
  end
end

class Scene_Battle < Scene_Base
  alias cdr_guide_process_message process_message
  def process_message(command)    
    if GuideManager.battle_guide?
      wait = 10
      wait = command[2][:wait] if command[2] and command[2][:wait]      
      @log_window.add_text(command[1])
      wait.times do @log_window.wait end
      @log_window.back_one
    else
      cdr_guide_process_message(command)
    end
  end
  #--------------------------------------------------------------------------
  # * new method: returns true if a guide update must be skipped
  #--------------------------------------------------------------------------
  alias cdr_guide_battle_skip_guide_update? skip_guide_update?
  def skip_guide_update?
    return true if cdr_guide_battle_skip_guide_update?
    return false if @item_window.active
    return false if @skill_window.active
    return false if @party_command_window.active
    return false if @actor_command_window.active
    return false if @status_window.active
    return false if @enemy_window.active
    return true
  end
end

class Window_Selectable < Window_Base  
  #--------------------------------------------------------------------------
  # * alias: can only process handlers when not locked
  #--------------------------------------------------------------------------
  alias cdr_guide_process_handling process_handling
  def process_handling
    wm = self.is_a?(Window_Message)
    return if (!wm and $game_message.busy? and GuideManager.running?)
    cdr_guide_process_handling
  end  
  #--------------------------------------------------------------------------
  # * alias: can only process cursor moves when not locked
  #--------------------------------------------------------------------------
  alias cdr_guide_process_cursor_move process_cursor_move
  def process_cursor_move
    wm = self.is_a?(Window_Message)
    return if (!wm and $game_message.busy? and GuideManager.running?)
    cdr_guide_process_cursor_move
  end
end

#==============================================================================
# ** Scene_Guide
#==============================================================================
class Scene_Guide < Scene_Base
  #--------------------------------------------------------------------------
  # * Start Processing
  #--------------------------------------------------------------------------
  def start
    super
    create_help_window
    create_guide_window
    create_background
    @guide_window.set_handler(:ok,   method(:on_guide_ok))
    @guide_window.set_handler(:cancel,   method(:return_scene))
  end
  
  #--------------------------------------------------------------------------
  # * Termination Processing
  #--------------------------------------------------------------------------
  def terminate
    super
    dispose_background
  end
  #--------------------------------------------------------------------------
  # * Create Background
  #--------------------------------------------------------------------------
  def create_background
    @background_sprite = Sprite.new
    @background_sprite.bitmap = SceneManager.background_bitmap
    @background_sprite.color.set(16, 16, 16, 128)
  end
  #--------------------------------------------------------------------------
  # * Free Background
  #--------------------------------------------------------------------------
  def dispose_background
    @background_sprite.dispose
  end
  
  def update
    super
    @guide_window.refresh
  end
  #--------------------------------------------------------------------------
  # * Aquisição do texto da janela de ajuda
  #--------------------------------------------------------------------------
  def help_window_text
    return CDR_GUIDE::HELP_WINDOW_TEXT
  end
  
  #--------------------------------------------------------------------------
  # * new method: creates each guide window
  #--------------------------------------------------------------------------
  def create_guide_window
    width = Graphics.width
    height = Graphics.height - @help_window.height
    @guide_window = Window_GuideList.new(0, @help_window.height, width, height)
    @guide_window.viewport = @viewport
  end

  #--------------------------------------------------------------------------
  # * new method: call selected guide
  #--------------------------------------------------------------------------
  def on_guide_ok
    $game_switches[@guide_window.item] = true
    guide = CDR_GUIDE::GUIDE_DATA[@guide_window.item]
    Sound.play_ok
    if guide[:scene] == Scene_Battle
      call_battle_guide(guide[:troop])
    elsif guide[:scene] == Scene_Shop
      call_shop_guide(guide[:goods], guide[:sell])
    else
      GuideManager.save_bgm_and_bgs
      Sound.play_guide_bgm
      SceneManager.call(guide[:scene])
    end         
  end
  #--------------------------------------------------------------------------
  # * new method: call a battle guide
  #--------------------------------------------------------------------------  
  def call_battle_guide(troop_id)
    if $data_troops[troop_id]
      GuideManager.save_bgm_and_bgs
      BattleManager.setup(troop_id, false, true)
      Sound.play_battle_guide_bgm
      Sound.play_battle_start
      SceneManager.call(Scene_Battle)
    end
  end
  #--------------------------------------------------------------------------
  # * rewrite: call a shop guide
  #--------------------------------------------------------------------------
  def call_shop_guide(goods_data, sell)
    goods = []
    types = [:item, :weapon, :armor]
    for type in 0..2
      if goods_data[types[type]]
        goods_data[types[type]].each{|id|
          goods.push([type, id, 0])
        }
      end
    end
    GuideManager.save_bgm_and_bgs
    Sound.play_shop_guide_bgm
    SceneManager.call(Scene_Shop)
    SceneManager.scene.prepare(goods, !sell)
  end
  #--------------------------------------------------------------------------
  # * Create Help Window
  #--------------------------------------------------------------------------
  def create_help_window
    @help_window = Window_Help.new(1)
    @help_window.set_text(help_window_text)
    @help_window.viewport = @viewport
  end
end

#==============================================================================
# ** Window_GuideList
#==============================================================================
class Window_GuideList < Window_Selectable
  def initialize(x, y, width, height)
    super(x, y, width, height)
    make_item_list
    refresh
    @index = 0
    self.activate
  end
  #--------------------------------------------------------------------------
  # * Create Item List
  #--------------------------------------------------------------------------
  def make_item_list
    @data = GuideManager.guide_list
  end
  #--------------------------------------------------------------------------
  # * Draw Item
  #--------------------------------------------------------------------------
  def draw_item(index)
    rect = item_rect(index)
    draw_icon(CDR_GUIDE::GUIDE_FILE_ICON, 4, rect.y, enabled = true)
    change_color(normal_color)
    draw_guide_name(index, rect.x+28, rect.y)
    contents.font.bold = true
    change_color(text_color(CDR_GUIDE::NEW_COLOR))
    draw_new_flag(index, rect.x+text_size(guide(index)[:name]).width+24, rect.y)
    contents.font.bold = false
    change_color(normal_color)    
  end
  #--------------------------------------------------------------------------
  # * new method: draw_guide_name
  #--------------------------------------------------------------------------
  def draw_guide_name(index, x, y)
    name = guide(index)[:name]
    draw_text(x, y, Graphics.width - 120, line_height, name)
  end
  #--------------------------------------------------------------------------
  # * new method: draw_new_flag
  #--------------------------------------------------------------------------
  def draw_new_flag(index, x, y)
    return if GuideManager.read?(@data[index])
    text = CDR_GUIDE::NEW_STRING   
    draw_text(x, y, 128, line_height, text)
  end
  #--------------------------------------------------------------------------
  # * method rewrite: returns the max number of guides on the list
  #--------------------------------------------------------------------------
  def item_max
    GuideManager.guide_list.size
  end
  #--------------------------------------------------------------------------
  # * new method: returns the guide corresponding to the key
  #--------------------------------------------------------------------------
  def guide(index)
    CDR_GUIDE::GUIDE_DATA[@data[index]]
  end
  #--------------------------------------------------------------------------
  # * method rewrite: returns the selected guide key
  #--------------------------------------------------------------------------
  def item
    @data[@index]
  end
end

#==============================================================================
# ** Scene_Menu
#==============================================================================
class Scene_Menu < Scene_MenuBase 
  #--------------------------------------------------------------------------
  # * alias: adds a guide list accessor to the main menu
  #--------------------------------------------------------------------------
  alias cdr_guide_create_command_window create_command_window
  def create_command_window
    cdr_guide_create_command_window
    if CDR_GUIDE::ADD_MENU_ITEM
      @command_window.set_handler(:guide_list,  method(:command_guide_list))
    end
  end
  
  #--------------------------------------------------------------------------
  # * new method: calls the guide list scene
  #--------------------------------------------------------------------------
  def command_guide_list
    SceneManager.call(Scene_Guide)
  end
end
#==============================================================================
# ** Window_MenuCommand
#==============================================================================
class Window_MenuCommand < Window_Command
  #--------------------------------------------------------------------------
  # * alias
  #--------------------------------------------------------------------------
  alias cdr_guide_select_last select_last
  def select_last    
    if GuideManager.running?
      select_symbol(nil) 
      return
    end
    cdr_guide_select_last
  end
    
  #--------------------------------------------------------------------------
  # * alias: to add guide command menu item
  #--------------------------------------------------------------------------
  alias cdr_guide_add_original_commands add_original_commands
  def add_original_commands
    cdr_guide_add_original_commands
    add_guide_list_command if CDR_GUIDE::ADD_MENU_ITEM
  end  
  #--------------------------------------------------------------------------
  # * new method: to add guide command menu item
  #--------------------------------------------------------------------------
  def add_guide_list_command    
    add_command(CDR_GUIDE::MENU_ITEM_NAME, :guide_list, has_guides?)
  end
  
  #--------------------------------------------------------------------------
  # * new method: returns true if there is any guides on the list
  #--------------------------------------------------------------------------
  def has_guides?
    !GuideManager.guide_list.empty?
  end
end