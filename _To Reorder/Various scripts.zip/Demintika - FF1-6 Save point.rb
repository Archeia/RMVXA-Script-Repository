#==============================================================================
# *
#==============================================================================
=begin
  #--------------------------------------------------------------------------
  # *
  #--------------------------------------------------------------------------
  Item Note Tag:
    <tent>  : The item can only usable when the player is at Save Point. You
    can trigger Common Event for Sound and Visual effect (Fade out, play music,
    Fade in, recovery all, special story process.)
  #--------------------------------------------------------------------------
  # *
  #--------------------------------------------------------------------------
  Event Command Tag:
    <save_point>    : Make the event a normal save point.
    <save_point: 1> : Save only
    <save_point: 2> : Use tent only
  #--------------------------------------------------------------------------
  # *
  #--------------------------------------------------------------------------
  Event Setting:
    If Above or Below player: Save point only active when the player is in the
    same spot as the save point.
    If Same as player: Save point only active when the player stand next to the
    save point.
  #--------------------------------------------------------------------------
  # *
  #--------------------------------------------------------------------------
  About Save point:
    Save point actives passively. It actives the Save command in the Menu and
    Tent items in inventory.
  #--------------------------------------------------------------------------
  # *
  #--------------------------------------------------------------------------
  Disable Save:
    You can disable Save Point by using normal event's Save Disable
    (Event Commands / Page 3 / Change Save Access)
=end
#==============================================================================
# *
#==============================================================================
module DMTK
  module SAVE_POINT
  #--------------------------------------------------------------------------
  # * SAFE_MAPS: List of ids of maps which is savable and tent is usable.
  #--------------------------------------------------------------------------
    SAFE_MAPS = []
  end
end

#==============================================================================
# *
#==============================================================================
module DataManager
  
  #--------------------------------------------------------------------------
  # *
  #--------------------------------------------------------------------------
  class << self
    alias dmtk_load_database_save load_database
  end
  
  #--------------------------------------------------------------------------
  # *
  #--------------------------------------------------------------------------
  def self.load_database
    dmtk_load_database_save
    dmtk_load_notetag_save
  end
  
  #--------------------------------------------------------------------------
  # *
  #--------------------------------------------------------------------------
  def self.dmtk_load_notetag_save
    $data_items.each {|obj|
      next if obj.nil?
      obj.dmtk_load_notetag_save
    }
  end
end

#==============================================================================
# * 
#==============================================================================
class RPG::Item < RPG::UsableItem
  
  attr_reader :is_tent
  #--------------------------------------------------------------------------
  # *
  #--------------------------------------------------------------------------
  def dmtk_load_notetag_save
    self.note.split(/[\r\n]+/).each { |line|
      if line =~ /<tent>/i
        @is_tent = true
        break
      end
    }
  end
  
end

#==============================================================================
# * 
#==============================================================================
class Game_System
  alias dmtk_save_point_disabled save_disabled
  def save_disabled
    return true if dmtk_save_point_disabled
    return !$game_map.dmtk_savable?
  end
end

#==============================================================================
# * 
#==============================================================================
class Game_Map
  
  #--------------------------------------------------------------------------
  # *
  #--------------------------------------------------------------------------
  def dmtk_setup_save_points
    @save_points = []
    self.events.values.each {|event|
      @save_points.push(event) if event.save_point
    }
  end
  
  #--------------------------------------------------------------------------
  # *
  #--------------------------------------------------------------------------
  def dmtk_savable?
    return true if safe_map?
    @save_points.each {|event|
      next unless event.savable
      return true if event.dmtk_player_contact?
    }
    return false
  end
  
  #--------------------------------------------------------------------------
  # *
  #--------------------------------------------------------------------------
  def dmtk_tent_usable?
    return true if safe_map?
    @save_points.each {|event|
      next unless event.tent_usable
      return true if event.dmtk_player_contact?
    }
    return false
  end
  
  #--------------------------------------------------------------------------
  # *
  #--------------------------------------------------------------------------
  def safe_map?
    DMTK::SAVE_POINT::SAFE_MAPS.include?(@map_id)
  end
  
end

#==============================================================================
# * 
#==============================================================================
class Game_Event < Game_Character
  
  #--------------------------------------------------------------------------
  # *
  #--------------------------------------------------------------------------
  attr_reader :save_point
  attr_reader :savable
  attr_reader :tent_usable
  
  #--------------------------------------------------------------------------
  # *
  #--------------------------------------------------------------------------
  alias dmtk_save_setup_page_settings setup_page_settings
  def setup_page_settings
    dmtk_save_setup_page_settings
    dmtk_setup_save_point
  end
  
  #--------------------------------------------------------------------------
  # *
  #--------------------------------------------------------------------------
  def dmtk_setup_save_point
    @list.each do |command|
      next unless command.code == 108 || command.code == 408
      if command.parameters[0] =~ /<save[ _]point(?::[ ]*(\d+))?>/i
        @save_point = true
        @savable = true
        @tent_usable = true
        unless $1.nil?
          case $1.to_i
          when 1
            @tent_usable = false
          when 2
            @savable = false
          end
        end
      end
    end
  end
  
  #--------------------------------------------------------------------------
  # *
  #--------------------------------------------------------------------------
  def dmtk_player_contact?
    return true if self.x == $game_player.x && self.y == $game_player.y
    if normal_priority?
      return dmtk_next_to_player?
    end
    return false
  end
  
  #--------------------------------------------------------------------------
  # *
  #--------------------------------------------------------------------------
  def dmtk_next_to_player?
    return [2,4,6,8].any? {|dir|
      $game_map.round_x_with_direction($game_player.x,dir) == self.x &&
      $game_map.round_y_with_direction($game_player.y,dir) == self.y
    }
  end
  
end

#==============================================================================
# * 
#==============================================================================
class Game_BattlerBase
  
  #--------------------------------------------------------------------------
  # *
  #--------------------------------------------------------------------------
  alias dmtk_tent_usable? usable?
  def usable?(item)
    return false unless dmtk_tent_usable?(item)
    return true unless item.is_a?(RPG::Item) && item.is_tent
    return $game_map.dmtk_tent_usable?
  end
end
  
#==============================================================================
# * 
#==============================================================================
class Scene_Map < Scene_Base
  
  #--------------------------------------------------------------------------
  # *
  #--------------------------------------------------------------------------
  alias dmtk_save_point_start start
  def start
    dmtk_save_point_start
    $game_map.dmtk_setup_save_points
  end
  
end

#==============================================================================
# * 
#==============================================================================