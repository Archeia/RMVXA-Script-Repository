class Game_Player < Game_Character
  alias amn_dashrune_gameplayer_dash? dash?
  def dash?
    unless @move_route_forcing
      return true if $game_party.dash_rune?
    end
    amn_dashrune_gameplayer_dash?
  end
end

class Game_Party < Game_Unit
 
  def dash_rune?
    battle_members.any? { |m| m.equips.any? { |a| a && a.note =~ /<dash_rune>/i } }
  end
 
end