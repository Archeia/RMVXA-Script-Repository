#Script by GreatRedSpirit, NOT mine!!

class Game_Action

  alias :prepare_change_state :prepare unless $@
  def prepare
    # Add/Remove states as needed
    remove_states = @item.object.remove_states_before_use
    remove_states.each { |state| @subject.remove_state(state) }
    
    add_states = @item.object.add_states_before_use
    add_states.each { |state| @subject.add_state(state) }
    
    # Now call the original method
    prepare_change_state 
  end
  
end

class Scene_Battle < Scene_Base
  
  alias :execute_action_change_state :execute_action unless $@
  def execute_action
    # Call the original method to execute the action
    execute_action_change_state
    # And remove current action states
    return if @subject.current_action.nil?
    
    usable_item = @subject.current_action.item
    print "Found item #{usable_item}\n"
    
    remove_states = usable_item.remove_states_after_use
    remove_states.each { |state| @subject.remove_state(state) }
  
    add_states = usable_item.add_states_after_use
    add_states.each { |state| @subject.add_state(state) }
  end
  
end



class RPG::UsableItem < RPG::BaseItem
  
  RemoveStateBeforeUseRegEx = 
    /^<remove_state_before_use>(([0-9]+,?)+)+<\/remove_state_before_use>/mix
  
  def remove_states_before_use
    # First execute the regex for this property
    if @remove_states_before_use.nil?
      if @note =~ RemoveStateBeforeUseRegEx
        @remove_states_before_use = $1.split(',').map { |x| x.to_i }
      else
        @remove_states_before_use = []
      end
    end
    # Return the property
    return @remove_states_before_use
  end
  
  
  RemoveStateAfterUseRegEx =
    /^<remove_state_after_use>(([0-9]+,?)+)+<\/remove_state_after_use>/mix
  
  def remove_states_after_use
    # First execute the regex for this property
    if @remove_states_after_use.nil?
      if @note =~ RemoveStateAfterUseRegEx
        @remove_states_after_use = $1.split(',').map { |x| x.to_i }
      else
        @remove_states_after_use = []
      end
    end
    # Return the property
    return @remove_states_after_use
  end
  
  
  AddStateBeforeUseRegEx =
    /^<add_state_before_use>(([0-9]+,?)+)+<\/add_state_before_use>/mix
  
  def add_states_before_use
    # First execute the regex for this property
    if @add_states_before_use.nil?
      if @note =~ AddStateBeforeUseRegEx
        @add_states_before_use = $1.split(',').map { |x| x.to_i }
      else
        @add_states_before_use = []
      end
    end
    # Return the property
    return @add_states_before_use
  end
  
  
  AddStateAfterUseRegEx = 
    /^<add_state_after_use>(([0-9]+,?)+)+<\/add_state_after_use>/mix
  
  def add_states_after_use
    # First execute the regex for this property
    if @add_states_after_use.nil?
      if @note =~ AddStateAfterUseRegEx
        @add_states_after_use = $1.split(',').map { |x| x.to_i }
      else
        @add_states_after_use = []
      end
    end
    # Return the property
    return @add_states_after_use
  end
  
end