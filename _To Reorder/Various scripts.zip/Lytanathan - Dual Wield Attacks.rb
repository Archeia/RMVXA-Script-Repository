#==============================================================================
#
# Dual Wield Separate Attacks by Lytanathan
#
# When a character is wielding more than one weapon, perform an attack for
# each weapon equipped, using only that stats of that weapon and not the
# others.
#
# Instructions: Place any skills that are attack skills inside the array
#               ATTACK_SKILL_IDS found below. That is all.
#
# Is (as far as I can tell) compatible with Yanfly's Ace Equip Engine.
#
# So far, partially compatible with Yanfly's and Victor Sant's scripts for 
# changing the attack formula of the equipped weapon. (Or rather, those scripts
# work as they are supposed to, but both weapons end up using the same formula.
# If both weapons HAVE the same formula then it everything is good, but if not
# then the slot 1 weapon's formula overrides the slot 2 formula)
# I am working on this, but I am not a very good scripter and I am not very
# confident I will be able to fix it. It took me nearly 24 total hours of coding
# just to come up with the single function you see below here.
#
#==============================================================================

#==============================================================================
#+-----------------------------------------------------------------------------
#| BEGIN EDITABLE REGION
#+-----------------------------------------------------------------------------
#==============================================================================
module LytBase
  ATTACK_SKILL_IDS = [1]
end
#==============================================================================
#+-----------------------------------------------------------------------------
#| END EDITABLE REGION
#+-----------------------------------------------------------------------------
#==============================================================================
class Scene_Battle
  
  alias lyt_dwsa_apply_item_effects apply_item_effects
  def apply_item_effects(target, item)
    
    #If attacker is an actor
    if @subject.is_a?(Game_Actor) && LytBase::ATTACK_SKILL_IDS.include?(item.id)
      #Remember equipped weapons
      weapon_list = @subject.weapons
          
      for current_weapon in 0..weapon_list.size-1

        #Remove weapons not being used to attack        
        for weapon in 0..weapon_list.size-1
          if weapon != current_weapon
            @subject.change_equip(weapon, nil)
          end
        end
        
        #Perform attack

        lyt_dwsa_apply_item_effects(target, item)

        #Replace weapons not being used to attack
        for weapon in 0..weapon_list.size-1
          @subject.change_equip(weapon, weapon_list[weapon])
        end
      end
    
    #If attacker is not an actor  
    else
      lyt_dwsa_apply_item_effects(target, item)
    end
  end  