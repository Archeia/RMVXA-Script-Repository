=begin
====================================================================
  GENERAL INFORMATION
--------------------------------------------------------------------
  Title: Quick Save/Load System
  Author: Adiktuzmiko
  Version: 1.01 - Khas' Fix
  Requirements: None

  This script allows you to set a button in the game for quick save and load.
  If you press the quicksave button, the game will automatically save
  your progress in the designated slot without going thru the save screen.
  The same goes for quickload.

====================================================================

====================================================================
  FEATURES
--------------------------------------------------------------------

  Quick Save/Load Anytime
  - Save/Load your progress with the press of a button

  Customizable
  - Modify which file index is used as the quick slot
  - Modify which buttons
  - Determine if quick system is usable in battle and during show text
    event commands
   
  Works with Khas' Awesome Light Effects

====================================================================

====================================================================
  INSTRUCTIONS
--------------------------------------------------------------------

  After importing this script to your project, go to the config part
  below (after TERMS AND CONDITIONS) and edit to suit your needs.

====================================================================

====================================================================
  TERMS AND CONDITIONS
--------------------------------------------------------------------

  View it here: http://lescripts.wordpress.com/terms-and-conditions/

====================================================================

=end

module ADIK
  module QUICK
   
    #Is the system enabled?
    ENABLED = true
   
    #Save file index to be used by Quick save/load
    #Note that by default the first file is index 0
    INDEX = 1
   
    #SaveLoad Keybindings
    #Default are L and R keys (Q/W at the keyboard by default)
    SAVE_KEY = :L
    LOAD_KEY = :L
   
    #Set these if you want to use a button "combo" to activate the system
    #Example if SAVE_KEY is set as :L and SAVE_KEY_2 is set as :A
    #then you need to press both to activate the quick save
    SAVE_KEY_2 = nil
    LOAD_KEY_2 = :A
   
    #Is the system allowed in battle scene?
    #I suggest keeping this as false
    ALLOW_AT_BATTLE = false
   
    #Is the system allowed during the Show Text event command?
    ALLOW_AT_TEXT = false
   
  end
end

# DO NOT EDIT BELOW THIS LINE

if ADIK::QUICK::ENABLED

  class Scene_Quick < Scene_File
   
    attr_accessor :quick_save
    attr_accessor :quick_load
   
    def create_help_window
    end
    def help_window_text
    end
    def create_savefile_viewport
      @savefile_viewport = Viewport.new
      @savefile_viewport.rect.y = 0
      @savefile_viewport.rect.height = 0
    end
    def create_savefile_windows
      @savefile_windows = Array.new(item_max) do |i|
        Window_SaveFile.new(savefile_height, i)
      end
      @savefile_windows.each {|window| window.viewport = @savefile_viewport; window.hide }
    end
    def init_selection
    end
   
    def update
      if @quick_save
        if DataManager.save_game(ADIK::QUICK::INDEX)
          Sound.play_save
        else
          Sound.play_buzzer
        end
        @quick_save = false
        SceneManager.return
      end
      if @quick_load
        if DataManager.load_game(ADIK::QUICK::INDEX)
          Sound.play_load
          $game_system.on_after_load
          @quick_load = false
          SceneManager.goto(Scene_Map)
        else
          Sound.play_buzzer
          @quick_load = false
          SceneManager.return
        end
      end
    end
   
    def quicksave
      @quick_save = true
    end
   
    def quickload
      @quick_load = true
    end
   
  end

  class Scene_Base
   
    def quicksave
      SceneManager.call(Scene_Quick)
      SceneManager.scene.quicksave
    end
   
    def quickload
      SceneManager.call(Scene_Quick)
      SceneManager.scene.quickload
    end
   
    def is_quicksave
      if ADIK::QUICK::SAVE_KEY_2 != nil
        return (Input.trigger?(ADIK::QUICK::SAVE_KEY) and Input.press?(ADIK::QUICK::SAVE_KEY_2))
      else
        if ADIK::QUICK::LOAD_KEY_2 != nil
          return false if Input.press?(ADIK::QUICK::LOAD_KEY_2)
        end
        return Input.trigger?(ADIK::QUICK::SAVE_KEY)
      end
    end
   
    def is_quickload
      if ADIK::QUICK::LOAD_KEY_2 != nil
        return (Input.trigger?(ADIK::QUICK::LOAD_KEY) and Input.press?(ADIK::QUICK::LOAD_KEY_2))
      else
        if ADIK::QUICK::SAVE_KEY_2 != nil
          return false if Input.press?(ADIK::QUICK::SAVE_KEY_2)
        end
        return Input.trigger?(ADIK::QUICK::LOAD_KEY)
      end
    end

   
    def quicksystem
      if is_quicksave and not SceneManager.scene_is?(Scene_Save)
        if SceneManager.scene_is?(Scene_Battle) then
          if ADIK::QUICK::ALLOW_AT_BATTLE
            quicksave
          end
        else
          quicksave
        end
        return
      end
      if is_quickload and not SceneManager.scene_is?(Scene_Load)
        if SceneManager.scene_is?(Scene_Battle) then
          if ADIK::QUICK::ALLOW_AT_BATTLE
            quickload
          end
        else
          quickload
        end
        return
      end
    end
   
    alias update_quicksystem update
    def update
      update_quicksystem
      quicksystem
    end
   
  end

  class Game_Interpreter

    def wait_for_message
      while $game_message.busy?
        SceneManager.scene.quicksystem
        Fiber.yield 
      end
    end
    
  end
  
################################################
#  Addon by Sixth
################################################

class Window_SaveFile < Window_Base

  def refresh
    contents.clear
    change_color(normal_color)
      case @file_index
      when 0
        name = AUTOSAVE_FILE_NAME
      when ADIK::QUICK::INDEX
        name = "Quick-Save"
      else
        name = Vocab::File + " #{@file_index}"
      end    draw_text(4, 0, 200, line_height, name)
    @name_width = text_size(name).width
    draw_party_characters(152, 58)
    draw_playtime(0, contents.height - line_height, contents.width - 4, 2)
  end
 
end
end