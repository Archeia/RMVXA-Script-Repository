#==============================================================================
# ~Wyrelade's Simple Mainmenu (UPDATE)
# made only for RGSS3 / RPGmakerVXAce
# Script creation date: 2012 - April - 9
# Last Modification date: 2012 - September - 06
# Last Updated:
# 2012 - September - 06 : Fixed some window sizes and stuff.
# Now Updated: Window made transparent, WAY MORE cooler. Done some new
# modifications.
# The mainmenu window bit more prettyer / better.
# Current Script version: 1.3 (BETA)
# Outdate versions: 1.0 (alpha), 1.1 (beta), 1.2 (beta
#==============================================================================
class Window_TitleCommand < Window_Command#Window_Command
#--------------------------------------------------------------------------
# * Object Initialization
#--------------------------------------------------------------------------
def initialize
super(((Graphics.width - window_width) / 80), Graphics.height)
@final_x, @final_y, self.active = self.x, ((Graphics.height * 2.05 - window_height) / 2).to_i, false
select_symbol :continue if continue_enabled
self.openness = 1
open
end
#--------------------------------------------------------------------------
# * Get Window Width
#--------------------------------------------------------------------------
def window_width
return (240 - standard_padding) * 2
end
#--------------------------------------------------------------------------
# * Update Window Position
#--------------------------------------------------------------------------
def update_placement
self.x += (self.x > @final_x ? -1 : 1) if self.x != @final_x
self.y += (self.y > @final_y ? -1 : 1) if self.y != @final_y
end
#--------------------------------------------------------------------------
# * Create Command List
#--------------------------------------------------------------------------
def make_command_list
add_command(Vocab::new_game, :new_game)
add_command(Vocab::continue, :continue, continue_enabled)
add_command(Vocab::shutdown, :shutdown)
end
#--------------------------------------------------------------------------
# * Get Activation State of Continue
#--------------------------------------------------------------------------
def continue_enabled
DataManager.save_file_exists?
end
#--------------------------------------------------------------------------
# * Get Digit Count
#--------------------------------------------------------------------------
def col_max
return 3
end
#--------------------------------------------------------------------------
# * Frame Update
#--------------------------------------------------------------------------
def update
super
if self.x == @final_x and self.y == @final_y and !self.active
self.active = true
else
update_placement
end
end
end
#-------------------------------------------------------------------------
# * Transparent menu window
#-------------------------------------------------------------------------
class Window_TitleCommand < Window_Command
  alias initialize_opacity_original initialize
  def initialize
    initialize_opacity_original
    self.opacity = 0
  end
end