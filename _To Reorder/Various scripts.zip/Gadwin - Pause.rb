###############################################################################
#Pause Script Version 3                                       
# Author: Unsigned_Zero
# Updated by Tsukihime
###############################################################################

# Pause picture should be placed in the Graphics/System folder

module U0_Pause_module

  PAUSE_BUTTON = "F8"
  Pause_Picture = "pause"

  #dim the screen during pause
  Dim_Screen = false
  Dim_Brightness = 100
  #The bgm to play when paused
  Pause_Music = "Dungeon2"
  #The bgm volume when paused
  Pause_Volume = 60
  # Freeze Time when in pause mode?
  TIME_STOP = true
  PAUSE_BUTTON2 = eval("Input::#{PAUSE_BUTTON}")
  PAUSE_OPACITY = 220 #opacity of the picture

  def stopping
    bgm = RPG::BGM.last
    bgs = RPG::BGS.last
    prev_brightness = Graphics.brightness
    RPG::BGM.stop
    Audio.bgm_play('Audio/BGM/' + Pause_Music, Pause_Volume)
    viewport1 = Viewport.new(0, 0, Graphics.width, Graphics.height)
    viewport1.z = 10000
    pause_sprite = Sprite.new(viewport1)
    pause_sprite.tone = Tone.new(0, 0, 0, 0)
    pause_sprite.bitmap = Cache.system (Pause_Picture)
    pause_sprite.opacity = PAUSE_OPACITY
    loop do
      Graphics.update
      Graphics.brightness = Dim_Brightness if Dim_Screen
      Input.update
      if Input.trigger?(PAUSE_BUTTON2)
        break
      end
    end
    Graphics.brightness = prev_brightness
    bgm.play(bgm.pos)
    bgs.play(bgs.pos)
    pause_sprite.dispose
    pause_sprite = nil
  end

end
#==============================================================================
#  Scene_Base
#==============================================================================

class Scene_Base
  include U0_Pause_module
  alias u0_pause_update update
  def update
    if Input.trigger?(PAUSE_BUTTON2)
      frame = Graphics.frame_count
      stopping
      if TIME_STOP
        Graphics.frame_count = frame
      end
    end
  u0_pause_update
  end
end