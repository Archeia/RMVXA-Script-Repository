#===============================================================================
# * SEE - Item Menu ACE
# * By Crazyninjaguy
# * Requested by BizarreMonkey
# * http://www.stormxstudios.co.uk
# * 02/01/2012
# * If you like my scripts, please show your appreciation by checking out
#   my friendly, helpful Game Development Community, StormCross Studios.
#  ---------------------------------------------------------------------------
# * Aliased Methods
#	- start (Scene_Item)
#	- update_item_selection (Scene_Item)
#	- terminate (Scene_Item)
#  ---------------------------------------------------------------------------
# * This script adds a new item description window with support for four text
#   text lines and a 96 x 96 picture in Graphics/Pictures.
# * To add a picture for your item, add this into the notebox of that item in
#   the database
# * <picture potionpicture>
# * Replacing potionpicture for your image filename.
#===============================================================================

$imported = {} if $imported == nil
$imported["SEE - Item Menu Ace"] = true

#===============================================================================
# * Main StormCross Engine Evolution Configuration Module
#===============================================================================
module SEE
 #=============================================================================
 # * Item Menu Configuration Module
 #=============================================================================
 module Item
ITEMS = []
#===========================================================================
# * The number at the beginning of the ITEMS[1] is the item id in the
#   database.
# * Each line of text in quotes is a seperate line in the window.
#   Seperate each with a comma
#===========================================================================
ITEMS[1] = ["This is a potion.", "It's very nice and restores 500hp.", "Costs 50 Gil in a shop.", "Has a purplish glow."]
ITEMS[2] = ["This is a high potion.", "It's very nice and restores 2500hp.", "Costs 150 Gil in a shop.", "Has a purplish glow."]

WEAPONS = []
WEAPONS[1] = ["Derp", "", "", ""]

ARMORS = []
ARMORS[1] = ["", "", "", ""]

ITEM_COLOURS = []
#===========================================================================
# * As with the previous, the number at the beginning of COLOURS[1] is the
#   item id in the database.
# * The numbers in the array correspond to the text_color() argument of
#   window base. 0 is white. You can find these by looking at the
#   Window.png graphic. Seperate each value with a comma.
#===========================================================================
ITEM_COLOURS[1] = [0, 1, 2, 3]

WEAPON_COLOURS = []
WEAPON_COLOURS[1] = [0, 1, 2, 3]

ARMOR_COLOURS = []
ARMOR_COLOURS[1] = [0, 1, 2, 3]
 end # Item
end # SEE

module ReadNote
 def read_note(note, tag, position = 1)
note2 = note.dup
lines = note2.scan(/<.+>/)
for line in lines
  words = line.split(/[ <>]/)
  words.delete("")
  for word in words
	if word == tag
	  result = words[words.index(word) + position]
	  return true if result == nil
	  return result
	end
  end
end
return false
 end
end

class Scene_Item < Scene_ItemBase
 def start
super
create_description_window
create_category_window
create_item_window
@description_index = 0
 end
 def create_description_window
@description = Window_ItemDescription.new
@description.viewport = @viewport
 end
 def create_category_window
@category_window = Window_ItemCategory.new
@category_window.viewport = @viewport
@category_window.y = @description.height
@category_window.set_handler(:ok,	 method(:on_category_ok))
@category_window.set_handler(:cancel, method(:return_scene))
 end
 def create_item_window
wy = @category_window.y + @category_window.height
wh = Graphics.height - wy
@item_window = Window_ItemList.new(0, wy, Graphics.width, wh)
@item_window.set_handler(:ok,	 method(:on_item_ok))
@item_window.set_handler(:cancel, method(:on_item_cancel))
@category_window.item_window = @item_window
@item_window.viewport = @viewport
 end
 def on_item_cancel
@item_window.unselect
@category_window.activate
@description.refresh(nil)
 end
 def update
super
if @description_index != @item_window.index
  @description.refresh(@item_window.item)
  @description_index = @item_window.index
end
 end
end

class Window_ItemDescription < Window_Base
 include ReadNote
 include SEE::Item
 def initialize(item = nil)
super(0, 0, Graphics.width, (Graphics.height - 288))
refresh(item)
 end # initialize
 def refresh(item)
self.contents.clear
if item != nil
  if item.is_a?(RPG::Item)
	picture = read_note($data_items[item.id].note, "picture")
  elsif item.is_a?(RPG::Weapon)
	picture = read_note($data_weapons[item.id].note, "picture")
  elsif item.is_a?(RPG::Armor)
	picture = read_note($data_armors[item.id].note, "picture")
  end
  if picture != false
	bitmap = Cache.picture(picture)
	rect = Rect.new(0, 0, 96, 96)
	self.contents.blt(0, 0, bitmap, rect)
  end
  if item.is_a?(RPG::Item)
	if ITEMS[item.id] != nil
	  if ITEM_COLOURS[item.id] != nil
		self.contents.font.color = text_color(ITEM_COLOURS[item.id][0])
		self.contents.draw_text(96, 0, width - 128, 24, ITEMS[item.id][0])
		self.contents.font.color = text_color(ITEM_COLOURS[item.id][1])
		self.contents.draw_text(96, 24, width - 128, 24, ITEMS[item.id][1])
		self.contents.font.color = text_color(ITEM_COLOURS[item.id][2])
		self.contents.draw_text(96, 48, width - 128, 24, ITEMS[item.id][2])
		self.contents.font.color = text_color(ITEM_COLOURS[item.id][3])
		self.contents.draw_text(96, 72, width - 128, 24, ITEMS[item.id][3])
		self.contents.font.color = text_color(0)
	  else
		self.contents.draw_text(96, 0, width - 128, 24, ITEMS[item.id][0])
		self.contents.draw_text(96, 24, width - 128, 24, ITEMS[item.id][1])
		self.contents.draw_text(96, 48, width - 128, 24, ITEMS[item.id][2])
		self.contents.draw_text(96, 72, width - 128, 24, ITEMS[item.id][3])
	  end
	end
  elsif item.is_a?(RPG::Weapon)
	if WEAPONS[item.id] != nil
	  if WEAPON_COLOURS[item.id] != nil
		self.contents.font.color = text_color(WEAPON_COLOURS[item.id][0])
		self.contents.draw_text(96, 0, width - 128, 24, WEAPONS[item.id][0])
		self.contents.font.color = text_color(WEAPON_COLOURS[item.id][1])
		self.contents.draw_text(96, 24, width - 128, 24, WEAPONS[item.id][1])
		self.contents.font.color = text_color(WEAPON_COLOURS[item.id][2])
		self.contents.draw_text(96, 48, width - 128, 24, WEAPONS[item.id][2])
		self.contents.font.color = text_color(WEAPON_COLOURS[item.id][3])
		self.contents.draw_text(96, 72, width - 128, 24, WEAPONS[item.id][3])
		self.contents.font.color = text_color(0)
	  else
		self.contents.draw_text(96, 0, width - 128, 24, WEAPONS[item.id][0])
		self.contents.draw_text(96, 24, width - 128, 24, WEAPONS[item.id][1])
		self.contents.draw_text(96, 48, width - 128, 24, WEAPONS[item.id][2])
		self.contents.draw_text(96, 72, width - 128, 24, WEAPONS[item.id][3])
	  end
	end
  elsif item.is_a?(RPG::Armor)
	if ARMORS[item.id] != nil
	  if ARMOR_COLOURS[item.id] != nil
		self.contents.font.color = text_color(ARMOR_COLOURS[item.id][0])
		self.contents.draw_text(96, 0, width - 128, 24, ARMORS[item.id][0])
		self.contents.font.color = text_color(ARMOR_COLOURS[item.id][1])
		self.contents.draw_text(96, 24, width - 128, 24, ARMORS[item.id][1])
		self.contents.font.color = text_color(ARMOR_COLOURS[item.id][2])
		self.contents.draw_text(96, 48, width - 128, 24, ARMORS[item.id][2])
		self.contents.font.color = text_color(ARMOR_COLOURS[item.id][3])
		self.contents.draw_text(96, 72, width - 128, 24, ARMORS[item.id][3])
		self.contents.font.color = text_color(0)
	  else
		self.contents.draw_text(96, 0, width - 128, 24, ARMORS[item.id][0])
		self.contents.draw_text(96, 24, width - 128, 24, ARMORS[item.id][1])
		self.contents.draw_text(96, 48, width - 128, 24, ARMORS[item.id][2])
		self.contents.draw_text(96, 72, width - 128, 24, ARMORS[item.id][3])
	  end
	end
  end
end
 end # refresh
end # Window_ItemDescription