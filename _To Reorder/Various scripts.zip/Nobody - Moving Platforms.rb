#==============================================================================
# Sticky Moving Platforms
# by ???nOBodY???
#==============================================================================
# To set up a moving platform, you'll need an event.
# The platform will never be "sticky", if you don't use the
# accessible public instance variable. To turn it on and off in
# an event's move route, use a script call with either
# self.accessible = true or self.accessible = false.
#
# A "sticky" platform will essentially force the player that steps on it to
# move along with the platform, until getting off. The other half of the
# spectrum, is the event itself, for a self-contained moving platform.
# A basic design for such an event would go something like this, set
# to parallel processing:
#
# Conditional Branch: Script: get_character(0).accessible
#   Script: get_character(0).through = false
#   Conditional Branch: Script: get_character(0).x == $game_player.x &&
#                               get_character(0).y == $game_player.y
#     Script: $game_player.platformID = @event_id
#   Branch End
# else
#   Script: get_character(0).through = true
# Branch End
#==============================================================================

class Game_CharacterBase
  #--------------------------------------------------------------------------
  # * Public Instance Variables
  #--------------------------------------------------------------------------
  attr_accessor :through                  # pass-through
  attr_accessor :accessible               # able to be boarded
  #--------------------------------------------------------------------------
  # * Object Initialization
  #--------------------------------------------------------------------------
  alias movingPlatformsChar_initializer initialize
  def initialize
    movingPlatformsChar_initializer
    @accessible = false
  end
 
  #--------------------------------------------------------------------------
  # ● 通行可能判定
  #     d : 方向（2,4,6,8）
  #--------------------------------------------------------------------------
  def passableEx?(x, y, d)
    x2 = $game_map.round_x_with_direction(x, d)
    y2 = $game_map.round_y_with_direction(y, d)
    return false unless $game_map.valid?(x2, y2)
    return true if @through || debug_through?
    #PATCH
    if !$game_map.events_xy(x2, y2).empty?
      for event in $game_map.events_xy(x2, y2)
        return true if event.accessible
      end
    end
    if !$game_map.events_xy(x, y).empty?
      #no need to check current location
    else
      return false unless map_passable?(x, y, d)
    end
    #return false unless map_passable?(x, y, d)
    #PATCH
    return false unless map_passable?(x2, y2, reverse_dir(d))
    return false if collide_with_characters?(x2, y2)
    return true
  end
  #--------------------------------------------------------------------------
  # ● まっすぐに移動
  #     d       : 方向（2,4,6,8）
  #     turn_ok : その場での向き変更を許可
  #--------------------------------------------------------------------------
  def move_straight(d, turn_ok = true)
    @move_succeed = passableEx?(@x, @y, d)
    if @move_succeed
      set_direction(d)
      @x = $game_map.round_x_with_direction(@x, d)
      @y = $game_map.round_y_with_direction(@y, d)
      @real_x = $game_map.x_with_direction(@x, reverse_dir(d))
      @real_y = $game_map.y_with_direction(@y, reverse_dir(d))
      increase_steps
    elsif turn_ok
      set_direction(d)
      check_event_trigger_touch_front
    end
  end
end

#==============================================================================
# ** Game_Player
#------------------------------------------------------------------------------
#  This class handles maps. It includes event starting determinants and map
# scrolling functions. The instance of this class is referenced by $game_map.
#==============================================================================
class Game_Player < Game_Character
  #--------------------------------------------------------------------------
  # * Get Character
  #     param : if -1, player. If 0, this event. Otherwise, event ID.
  #--------------------------------------------------------------------------
  def get_character(param)
    case param
    when -1   # Player
      return $game_player #self?
    when 0    # This event
      events = $game_map.events
      return events == nil ? nil : events[@event_id]
    else      # Particular event
      events = $game_map.events
      return events == nil ? nil : events[param]
    end
  end
 
  #--------------------------------------------------------------------------
  # * Public Instance Variables
  #--------------------------------------------------------------------------
  attr_accessor :platformID               # if greater than 0, an event ID
  #--------------------------------------------------------------------------
  # * Object Initialization
  #--------------------------------------------------------------------------
  alias movingPlatformsPlyr_initializer initialize
  def initialize
    movingPlatformsPlyr_initializer
    @platformID = 0
    @exitingPlatform = false
    @fixingPosition = false
  end
  #--------------------------------------------------------------------------
  # * Frame Update
  #--------------------------------------------------------------------------
  alias movingPlatforms_updater update
  def update
    if @platformID > 0
      last_real_x = @real_x
      last_real_y = @real_y
      @x = get_character(@platformID).x
      @y = get_character(@platformID).y
      
      #Get realMoveSpeed & distancePerFrame
      realMoveSpeed = get_character(@platformID).move_speed + 1#(dash? ? 1 : 0)
      distancePerFrame = 2 ** realMoveSpeed / 256.0
      
      temp = @real_x != get_character(@platformID).real_x ||
             @real_y != get_character(@platformID).real_y ? true : false
      if temp && !@fixingPosition
        # Fixing position check
        @fixingPosition=false
        if @real_x != get_character(@platformID).real_x
          if @real_x < get_character(@platformID).real_x
            if get_character(@platformID).real_x <= @real_x + distancePerFrame
              @fixingPosition=true
            end
          end
          if @real_x > get_character(@platformID).real_x
            if get_character(@platformID).real_x >= @real_x - distancePerFrame
              @fixingPosition=true
            end
          end
        end
        if @real_y != get_character(@platformID).real_y
          if @real_y < get_character(@platformID).real_y
            if get_character(@platformID).real_y <= @real_y + distancePerFrame
              @fixingPosition=true
            end
          end
          if @real_y > get_character(@platformID).real_y
            if get_character(@platformID).real_y >= @real_y - distancePerFrame
              @fixingPosition=true
            end
          end
        end
        # Convert to movement
        @real_x = [@real_x - distancePerFrame, @x].max if @x < @real_x
        @real_x = [@real_x + distancePerFrame, @x].min if @x > @real_x
        @real_y = [@real_y - distancePerFrame, @y].max if @y < @real_y
        @real_y = [@real_y + distancePerFrame, @y].min if @y > @real_y
        update_bush_depth unless moving?
        update_animation
      else
        @real_x = get_character(@platformID).real_x
        @real_y = get_character(@platformID).real_y
      end
      
      move_by_input_onPlatform
      if @exitingPlatform
        movingPlatforms_updater
        @platformID = 0
        @exitingPlatform = false
        @fixingPosition = false
      end
      update_scroll(last_real_x, last_real_y)
    else
      movingPlatforms_updater
    end
  end
  #--------------------------------------------------------------------------
  # * Processing of Movement via input from the Directional Buttons
  #--------------------------------------------------------------------------
  def move_by_input_onPlatform
    return unless get_character(@platformID).accessible
    return if !movable? || $game_map.interpreter.running?
    case Input.dir4
    when 2
      move_straight(Input.dir4) if Input.dir4 > 0
      @exitingPlatform = @move_succeed ? true : false
    when 4
      move_straight(Input.dir4) if Input.dir4 > 0
      @exitingPlatform = @move_succeed ? true : false
    when 6
      move_straight(Input.dir4) if Input.dir4 > 0
      @exitingPlatform = @move_succeed ? true : false
    when 8
      move_straight(Input.dir4) if Input.dir4 > 0
      @exitingPlatform = @move_succeed ? true : false
    end
  end
end

class Game_Player
  alias patch_update update
  def update
    @platformID ||= 0
    patch_update
  end
end