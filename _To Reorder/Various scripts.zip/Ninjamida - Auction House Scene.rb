################################
## Auction House Scene Script ##
################################
##        By Ninjamida        ##
################################

### Compatibility: This operates in its own scene. Therefore, it should
###                be compatible with just about anything. However, it may
###                have issues with scripts that modify how windows work. It
###                is compatible with resolution-changing scripts. However you
###                may need to adjust the size of the windows to suit any other
###                resolution but the standard one (they will still fill the
###                screen, but the offer window will be disproportionately large).
###
### Dependancies: None. This script will work in vanilla RMVXA projects.

### Configuration:
###
### Most of the configuration is below and explained next to the options.
### However, the prices for items is set in the database via notetag.
### <start price: xxx>
### <reserve price: xxx>
### <max price: xxx>
### <increment: xxx>
### Use these notetags to set the prices for an item.
### An item will start at the start price. The final sale price will be
### no less than the reserve and no more than the maximum.
### The increment is how much the value goes up with each bid.
### If any of these are not set for an item, the default ones from the
### configuration below will be used.
###
### If you want an item to only be winnable once, this is also set via
### notetags. Add the following notetag to an item:
### <unique>
### If you set this, the item can only be won in an auction once ever,
### even if there's more than one hash containing it. This does not in
### any way prevent another one of it from being obtained elsewhere in
### the game, whether pre- or post- winning it in an auction. Just for
### the record, this tag will apply across all auction types, not just
### special auctions.

######################
### Config Options ###
######################

module Ninjamida
  module Auction
    
    ##############################
    ### Auction General Config ###
    ##############################
    
    ### Width of Auction Type and Gold Windows
    TYPE_WINDOW_WIDTH = 200
    ### You can set Special Auctions to be disabled (by turning off the switch
    ### that enables them) when they've been won or lost. Note that this disables
    ### the set as a whole. If you just want to make one item not winnable again,
    ### set it as unique using the notetag described above.
    DISABLE_SPECIAL_ON_LOSE = false
    DISABLE_SPECIAL_ON_WIN = false
    ### Reserved switch. This switch is used by the script, do not use elsewhere
    ### in your project.
    RESERVED_SWITCH = 1
    ### Set the names of the auction types
    NORMAL_AUCTION = "Normal Auction"
    FAST_AUCTION = "Quick Auction"
    SPECIAL_AUCTION = "Rare Auction"
    ### Set the description of the auction types
    NORMAL_DESC = "A standard auction."
    FAST_DESC = "A higher-speed auction."
    SPECIAL_DESC = "A special auction with rare items."
    ### Set the text to appear in the help window once the auction starts.
    FIRST_LINE = "Press OK button to bid."
    SECOND_LINE = "Time Remaining: "
    ### Display remaining time at end of 2nd line in help window? This will
    ### show in minutes/seconds, not frames.
    SHOW_REMAINING_TIME = true
    ### Text expressions for various events.
    BID_TEXT = "%1$s bids %2$s%3$s." #%1$s = bidder, %2$s = amount, %3$s = currency
    PLAYER_NAME = "$game_party.leader.name" #Player name. You can use Ruby code here.
    WIN_TEXT = "Bought %1$s for %3$s %4$s!" #%1$s = item, %2$s = player name, %3$s = amount, %4$s = currency
    LOSE_TEXT = "%2$s bought %1$s for %3$s %4$s." #Same as above, %2$s = winning bidder
    FINISHED_HELP_TEXT = "The auction has ended! Press OK button to exit." #Plain text only.
    ### Sound effects for various events. (Filename, Volume, Pitch)
    PLAYER_BID_SFX = RPG::SE.new("Confirm (FF7)", 100, 100) #When player bids
    AI_BID_SFX = RPG::SE.new("Decision1", 100, 100) #When an AI bids
    CANT_BID_SFX = RPG::SE.new("Buzzer (FF7)", 100, 100) #When player cannot bid
    WIN_ITEM_SFX = RPG::SE.new("Distant Worlds II - Victory Theme", 100, 100) #When player wins
    LOSE_ITEM_SFX = RPG::SE.new("Failed Dance (FF7)", 100, 100) #When an AI wins
    ### Duration of the auctions. This is in frames. Assuming you don't have
    ### any script that changes it, 1 second = 60 frames.
    NORMAL_DURATION = 3600
    FAST_DURATION = 900
    SPECIAL_DURATION = 3600
    ### If a bid is placed (whether by the player or by AI) when the auction
    ### is close to ending, the auction can extend. Set the number of frames
    ### to extend by here. The extension will only occur if the auction already
    ### has fewer than that many frames remaining. Set this to 0 if you want
    ### no extensions. (eg: if set to 180, and auction has less than 180 frames
    ### remaining and a bid is placed, auction will extend by 180 frames)
    NORMAL_EXTEND = 0
    FAST_EXTEND = 0
    SPECIAL_EXTEND = 0
    ### Set the default prices. These will be used for any item that doesn't
    ### have its own prices set.
    DEFAULT_START_PRICE = 500
    DEFAULT_RESERVE_PRICE = 1000
    DEFAULT_MAX_PRICE = 1500
    DEFAULT_INCREMENT = 50
    
    ####################
    ### Prize Config ###
    ####################
    
    ### Each prize hash should be surrounded by [ ]
    ### Inside this, set [x, y] where x is item type and y is item ID
    ### Item type is 0 for items, 1 for weapons, 2 for armors
    ### The minimum number of prizes in a set is 1
    ### There is no maximum number of prizes in a set
    ### You may have a different amount of items in different sets
    NORMAL_PRIZE =  [ # For normal prizes, simply set each item
                     [[0, 1], [0, 8], [0, 13], [0, 31]], # X-Potion/Dry Ether/Phoenix Ember/Remedy
                     [[0, 4], [0, 5], [0, 6], [0, 140]], # Al Bhed Items
                     [[0, 15], [0, 16], [0, 17], [0, 10]], # Special Battle Items
                     [[0, 33], [0, 36], [0, 39], [0, 42]], # Elemental Items
                     [[0, 57], [0, 59], [0, 61], [0, 64]], # State Items
                     [[0, 3], [0, 8], [0, 31], [0, 79]], # Deconstructor Special
                     [[0, 83], [0, 84], [0, 144], [0, 146]], # ALL UNIQUE 
                     [[0, 66], [0, 67], [0, 70], [0, 128]], # Fixed Dice Special
                     [[1, 6], [1, 25], [1, 55], [1, 69]], # Weapons
                     [[2, 6], [2, 33], [2, 34], [2, 69]], # Shield
                     [[2, 66], [2, 68], [2, 70], [2, 146]], # Armor
                     [[1, 80], [1, 108], [2, 7], [2, 8]], # Weapon & Shield
                     [[2, 111], [2, 125], [2, 135], [2, 148]] # Relics & Armor
                    ]
    FAST_PRIZE =    [ # If fast prizes is left blank, it will copy normal
                     
                    ]
    SPECIAL_PRIZE = [ # For special auctions, the lone number is the switch
                     [2, [2, 231]],
                     [3, [2, 240]]
                    ]
                    
    #########################              
    ### AI Bidders Config ###
    #########################
    
    ### To add a bidder, use the following format:
    ### ["NAME", Min, Max, Agr, Std, Rbd, Nrm, Fst, Spc]
    ### "NAME" is the name of the bidder. Must be in quotes!
    ### Min is the minimum starting price of an item for them to bid on.
    ###    If an item's starting price is below this, that bidder will never
    ###    appear in the auction.
    ### Max is the highest amount that bidder will ever bid on an item.
    ###    Note that the bidder may still participate even if the max or reserve
    ###    price is higher than their maximum, as long as the starting price
    ###    is equal to or less than it.
    ### Agr determines how aggresively the bidder will bid for an
    ###    item. This is a value from 0 to 100. A value of 0 means they will never
    ###    bid once the reserve has been reached, a value of 100 means they will
    ###    bid without fail once their delay is up unless it would exceed their
    ###    maximum price.
    ### Std is how many frames from the start of the auction until this
    ###    bidder will place a starting bid. Note that the starting bid is 100%
    ###    guaranteed to occur, provided no other bid has been placed by that
    ###    time. So basically, unless the player does first, whichever AI bidder
    ###    has the lowest StartDelay will end up placing the starting bid.
    ### Rbd is how many frames from a previous bid the bidder will wait
    ###    before possibly placing their next bid. Whether or not they actually
    ###    place one is random, dependant on their aggressiveness.
    ### Nrm, Fst and Spc are whether that bidder will take part in normal, fast
    ###    and special auctions respectively.
    ### Note that AI bidders may bid more often than their aggressiveness would
    ###    usually allow for if it's to ensure the reserve price is met. They
    ###    will not exceed their maximum to do so unless you enable them to.
    ### If you need to access them outside this script for any reason, they get
    ###    loaded into $ninjamida_bidders. @name, @min_gold, @max_gold, @aggression,
    ###    @start_delay, @rebid_delay, @auction_types[0=normal, 1=fast, 2=special].
    ###    $ninjamida_bidders is used for both the data and the actively-used object.
    ### 
    AI_BIDDERS = [
                  ["Stella", 1, 10000, 35, 30, 240, true, true, true],
                  ["Dona", 1, 22000, 60, 40, 240, true, true, true],
                  ["Gordon", 1, 30000, 33, 30, 240, true, true, true],
                  ["Raine", 1, 32000, 25, 300, 120, true, true, true],
                  ["Maechen", 1, 35000, 80, 300, 240, true, true, true],
                  ["Brahne", 1, 45000, 50, 240, 60, true, true, true],
                  ["Goldor", 1, 75000, 75, 600, 180, false, false, true],
                  ["Setzer", 1, 40000, 40, 120, 30, true, true, false],
                  ["Gestahl", 1, 50000, 15, 60, 90, true, true, true],
                  ["Ellone", 1, 60000, 50, 256, 120, true, true, true],
                  ["Don Corneo", 1, 100000, 90, 450, 150, false, false, true],
                  ["Shera", 1, 20000, 20, 150, 60, true, true, true]
                 ]
    ### To ensure that the reserve price is met, you can allow AI bidders to
    ### exceed their maximum bid if the going price is less than reserve. They
    ### still will only do so if none of the AI bidders in the auction have a
    ### maximum price higher than the reserve. It's reccomended to enable this
    ### just in case you set an item's reserve higher than any of your bidders.
    ALLOW_EXCESS_BID = true
    ### Select how many AI bidders will be present in an auction. The bidders
    ### who enter will be randomly selected, and when possible at least one will
    ### have a maximum price equal or higher than the item's reserve price. Note
    ### that if not enough valid bidders (by price range or auction type) exist,
    ### fewer than this may end up being selected. If enough are available, this
    ### amount will always be picked.
    NUM_AI_BIDDERS = 4
    ### You can set points at which the AI bidders will get more aggressive to
    ### ensure the reserve is met. This is a global setting to all AI bidders.
    ### These are set as a % of the remaining auction time. Once the reserve is
    ### met, aggressiveness returns to normal. If any is set to 0, it will
    ### not occur.
    LOW_AGR_POINT = 75   # At this point, aggressiveness increases
    MID_AGR_POINT = 50   # At this point, aggressiveness raises to 100%
    HIGH_AGR_POINT = 25  # At this point, rebid delay is halved
    ### Please note that no check is performed at the end to ensure that reserve
    ### is met. Therefore, if your bidders aren't aggressive enough and/or these
    ### high aggression points aren't used, there is a chance the player will be
    ### able to buy items for lower than the reserve price.
    ### If anyone wants to know, the increase at the low agression point will
    ### halve their chance of *not* bidding. So basically:
    ### new_agr = 100 - ((100 - agr) / 2)
    
  end
end

### Auction Scene

class Scene_Auction < Scene_Base
  
  ### Setup Scene ###
  def start
    super
    pick_auction_offers
    $game_switches[Ninjamida::Auction::RESERVED_SWITCH] = not(@special_offer.nil?)
    create_help_window
    create_atype_window
    create_gold_window
    create_offer_window
    create_process_window
    finish_setup_atype_window
  end
  
  ### Pick the prize selections
  def pick_auction_offers
    normaloffers = Ninjamida::Auction::NORMAL_PRIZE.clone
    fastoffers = Ninjamida::Auction::FAST_PRIZE.clone
    specialoffers = Ninjamida::Auction::SPECIAL_PRIZE.clone
    fastoffers = normaloffers if fastoffers.empty?
    
    @normal_offer = normaloffers[rand(normaloffers.size)]
    @fast_offer = fastoffers[rand(fastoffers.size)]
    
    specialpool = []
    specialoffers.each do |spof|
      specialpool += [spof] if $game_switches[spof[0]]
    end
    
    if specialpool.empty?
      @special_offer = nil
    else
      @special_offer = specialpool[rand(specialpool.size)].clone
      @special_offer.delete_at(0)
      $game_party.unique_items_won.each do |it|
        @special_offer.delete(it)
      end
      @special_offer = nil if @special_offer.empty?
    end

  end
  
  ### Create Help Window
  def create_help_window
    @help_window = Window_AuctionHelp.new
    @help_window.viewport = @viewport
  end
  
  ### Create Auction Type Window
  def create_atype_window
    @atype_window = Window_AuctionType.new
    @atype_window.set_handler(:standard,  method(:start_standard_auction))
    @atype_window.set_handler(:fast,      method(:start_fast_auction))
    @atype_window.set_handler(:special,   method(:start_special_auction))
    @atype_window.set_handler(:cancel,    method(:return_scene))
  end
  
  ### These need to be run for atype after ALL windows set up.
  def finish_setup_atype_window
    @atype_window.offers = [@normal_offer, @fast_offer, @special_offer]
    @atype_window.offer_window = @offer_window
    @atype_window.help_window = @help_window
  end
  
  ### Create Gold Window
  def create_gold_window
    @gold_window = Window_AuctionGold.new
    @gold_window.y = @help_window.height + @atype_window.height
  end
  
  ### Create Offer Window
  def create_offer_window
    @offer_window = Window_AuctionOffer.new
    @offer_window.unselect
    @offer_window.deactivate
    @offer_window.set_handler(:cancel,    method(:return_type))
    @offer_window.set_handler(:ok,        method(:start_auction))
    @offer_window.help_window = @help_window
  end
  
  ### Create Process Window
  def create_process_window
    @process_window = Window_AuctionProcess.new
    @process_window.help_window = @help_window
  end
  
  ### Select Standard Auction
  def start_standard_auction
    @auction_type = 0
    @duration = Ninjamida::Auction::NORMAL_DURATION
    @extend = Ninjamida::Auction::NORMAL_EXTEND
    to_offer_window
  end
  
  ### Select Fast Auction
  def start_fast_auction
    @auction_type = 1
    @duration = Ninjamida::Auction::FAST_DURATION
    @extend = Ninjamida::Auction::FAST_EXTEND
    to_offer_window
  end
  
  ### Select Special Auction
  def start_special_auction
    @auction_type = 2
    @duration = Ninjamida::Auction::SPECIAL_DURATION
    @extend = Ninjamida::Auction::SPECIAL_EXTEND
    to_offer_window
  end
  
  ### Activate Item Selection
  def to_offer_window
    @atype_window.deactivate
    @offer_window.select(0)
    @offer_window.activate
  end
  
  ### Return to Type Selection
  def return_type
    @offer_window.unselect
    @offer_window.deactivate
    @atype_window.activate
  end
  
  ### Start The Auction
  def start_auction
    case @auction_type
    when 0
      @prize = @normal_offer[@offer_window.index]
    when 1
      @prize = @fast_offer[@offer_window.index]
    when 2
      @prize = @special_offer[@offer_window.index]
    end
    case @prize[0]
    when 0
      @prize = $data_items[@prize[1]]
    when 1
      @prize = $data_weapons[@prize[1]]
    when 2
      @prize = $data_armors[@prize[1]]
    end
    @process_window.start_point = Graphics.frame_count
    @process_window.duration = @duration
    @process_window.display_help_message
    @opponents = select_other_bidders
    @auction_length = @duration
    reset_other_bidders
    run_auction
  end
  
  def select_other_bidders
    start_price = @prize.auction_start_price
    potentials = []
    $ninjamida_bidders.each do |bidder|
      bidder_okay = bidder.auction_types[@auction_type]
      bidder_okay = false if start_price > bidder.max_gold
      bidder_okay = false if start_price < bidder.min_gold
      potentials += [bidder] if bidder_okay
    end
    return [$ninjamida_bidders[0]] if potentials.empty?
    until potentials.size <= Ninjamida::Auction::NUM_AI_BIDDERS
      potentials.delete_at(rand(potentials.size))
    end
    return potentials
  end
  
  def reset_other_bidders
    @opponents.each do |opp|
      opp.reset
    end
  end    
  
  ### Run The Auction
  def run_auction
    @price = @prize.auction_start_price
    @reserve = @prize.auction_reserve_price
    @maxprice = @prize.auction_max_price
    @increm = @prize.auction_increment
    @gold = $game_party.gold
    
    @leading_bidder = -2
    @messages = ['', '', '']
    
    update_action_time(true)
    
    until @duration == 0
      check_player_bid
      check_cpu_bid
      check_aggression_updates if @price < @reserve
      next_frame
      @process_window.display_help_message if Ninjamida::Auction::SHOW_REMAINING_TIME
    end
    
    if @leading_bidder == -1
      process_player_win
    else
      process_cpu_win
    end
  end
  
  def process_player_win
    winmsg = sprintf(Ninjamida::Auction::WIN_TEXT, @prize.name, eval(Ninjamida::Auction::PLAYER_NAME), @price, $data_system.currency_unit)
    new_line(winmsg)
    $game_party.gain_item(@prize, 1)
    $game_party.lose_gold(@price)
    Ninjamida::Auction::WIN_ITEM_SFX.play
    wait_for_ok
  end
  
  def process_cpu_win
    losemsg = sprintf(Ninjamida::Auction::LOSE_TEXT, @prize.name, $ninjamida_bidders[@leading_bidder].name, @price, $data_system.currency_unit)
    new_line(losemsg)
    Ninjamida::Auction::LOSE_ITEM_SFX.play
    wait_for_ok
  end
  
  def wait_for_ok
    @help_window.set_text(Ninjamida::Auction::FINISHED_HELP_TEXT)
    until Input.trigger?(:C)
      update_basic
    end
    return_scene
  end
  
  def check_player_bid
    if Input.trigger?(:C)
      if not(@price + @increm > @gold or @leading_bidder == -1)
        update_action_time
        @leading_bidder = -1
        Ninjamida::Auction::PLAYER_BID_SFX.play
        increase_bid
      else
        Ninjamida::Auction::CANT_BID_SFX.play
      end
    end
  end
  
  def check_cpu_bid
    return false if @price >= @prize.auction_max_price
    @opponents.each do |ai_bidder|
      unless @leading_bidder == ai_bidder.id
        if ai_bidder.place_bid?(@price + @increm)
          update_action_time
          @leading_bidder = ai_bidder.id
          increase_bid
          Ninjamida::Auction::AI_BID_SFX.play
        end
      end
    end
  end
  
  def check_aggression_updates
    set_aggression(1) if @duration == (@auction_length * 100 / Ninjamida::Auction::LOW_AGR_POINT).to_i
    set_aggression(2) if @duration == (@auction_length * 100 / Ninjamida::Auction::MID_AGR_POINT).to_i
    set_aggression(3) if @duration == (@auction_length * 100 / Ninjamida::Auction::HIGH_AGR_POINT).to_i
  end
  
  def check_first_bid
    if @leading_bidder == -2
      @opponents.each do |ai_bidder|
        ai_bidder.first_bid
      end
    end
  end
  
  def set_reserve_met
    @opponents.each do |ai_bidder|
      ai_bidder.reserve_met
    end
  end
  
  def set_aggression(agrlevel)
    @opponents.each do |ai_bidder|
      ai_bidder.set_aggression_level(agrlevel)
    end
  end
  
  def increase_bid
    @price += @increm
    if @leading_bidder == -1
      new_line(make_bid_text(eval(Ninjamida::Auction::PLAYER_NAME), @price))
    else
      new_line(make_bid_text($ninjamida_bidders[@leading_bidder].name, @price))
    end
    set_reserve_met if @price >= @reserve
    check_extension
  end
  
  def check_extension
    if @duration < @extend
      @duration += @extend
      @auction_length += @extend
      @process_window.duration = @auction_length
    end
  end
  
  def update_action_time(initializing = false)
    check_first_bid if not initializing
    @opponents.each do |ai_bidder|
      ai_bidder.set_last_action(Graphics.frame_count)
    end
  end
  
  def make_auction_message(updatewindow=true)
    outmsg = @messages[0] + "\n" + @messages[1] + "\n" + @messages[2]
    @process_window.update_message(outmsg) if updatewindow
    return outmsg
  end
  
  def new_line(nltext, updatewindow=true)
    @messages.delete_at(2)
    @messages = [nltext] + @messages
    make_auction_message if updatewindow
  end
  
  def make_bid_text(bidder, bidamt)
    bidtxt = sprintf(Ninjamida::Auction::BID_TEXT, bidder, bidamt, $data_system.currency_unit)
    return bidtxt
  end
  
  ### Advance Frame
  def next_frame
    @duration -= 1
    update_basic
  end
  
end

class Game_Party < Game_Unit
  
  attr_accessor :unique_items_won
  
  alias ninjamida_auction_initialize initialize
  def initialize
    ninjamida_auction_initialize
    @unique_items_won = []
  end
  
end

class Ninjamida_AuctionBidder
  
  attr_accessor :id
  attr_accessor :name
  attr_accessor :min_gold
  attr_accessor :max_gold
  attr_accessor :aggression
  attr_accessor :start_delay
  attr_accessor :rebid_delay
  attr_accessor :auction_types
  
  def initialize(id)
    @id = id
    @name = Ninjamida::Auction::AI_BIDDERS[id][0]
    @min_gold = Ninjamida::Auction::AI_BIDDERS[id][1]
    @max_gold = Ninjamida::Auction::AI_BIDDERS[id][2]
    @aggression = Ninjamida::Auction::AI_BIDDERS[id][3]
    @start_delay = Ninjamida::Auction::AI_BIDDERS[id][4]
    @rebid_delay = Ninjamida::Auction::AI_BIDDERS[id][5]
    normal_auction = Ninjamida::Auction::AI_BIDDERS[id][6]
    fast_auction = Ninjamida::Auction::AI_BIDDERS[id][7]
    special_auction = Ninjamida::Auction::AI_BIDDERS[id][8]
    @auction_types = [normal_auction, fast_auction, special_auction]
    reset
  end
  
  def reset
    @last_action = Graphics.frame_count
    @aggression_level = 0
    @first_bid_placed = false
    @reserve_met = false
  end
  
  def set_last_action(action_time)
    @last_action = action_time
  end
  
  def set_aggression_level(level)
    @aggression_level = level
  end
  
  def first_bid
    @first_bid_placed = true
  end
  
  def reserve_met
    @aggression_level = 0
    @reserve_met = true
  end
    
  def place_bid?(item_price)
    return false if not check_bid_time
    return false if not check_bid_price(item_price)
    set_last_action(Graphics.frame_count)
    return determine_bid
  end
  
  def aggression
    case @aggression_level
    when 0
      return @aggression
    when 1
      return 100 - ((100 - @aggression) / 2)
    else
      return 100
    end
  end
  
  def check_bid_time
    delay = @rebid_delay
    delay = @start_delay if not @first_bid_placed
    delay /= 2 if @aggression_level == 3
    return true if Graphics.frame_count >= @last_action + delay
    return false
  end
  
  def check_bid_price(item_price)
    return true if Ninjamida::Auction::ALLOW_EXCESS_BID and not(@reserve_met)
    return true if item_price < @max_gold
    return false
  end
  
  def determine_bid
    return true if rand(100) < aggression
    return false
  end  
  
end

module DataManager
  class << self
    
    alias ninjamida_auction_create_game_objects create_game_objects
    def create_game_objects
      ninjamida_auction_create_game_objects
      $ninjamida_bidders = self.load_auction_bidders
    end
    
    def load_auction_bidders
      bidders = []
      Ninjamida::Auction::AI_BIDDERS.each_index do |id|
        bidders += [Ninjamida_AuctionBidder.new(id)]
      end
      return bidders
    end
  end
end

###### Auction Windows ######

### Customized Help Window
class Window_AuctionHelp < Window_Help

end

### Customized Gold Window
class Window_AuctionGold < Window_Gold
  
  ### Change Width
  def window_width
    return Ninjamida::Auction::TYPE_WINDOW_WIDTH
  end
  
end

### New window: Auction Type Window
class Window_AuctionType < Window_Command
  
  ### Setup Window
  def initialize
    super(0, fitting_height(2))
    @help_texts = [Ninjamida::Auction::NORMAL_DESC,
                   Ninjamida::Auction::FAST_DESC,
                   Ninjamida::Auction::SPECIAL_DESC]
  end
    
  ### Add The Options
  def make_command_list
    spswitch = $game_switches[Ninjamida::Auction::RESERVED_SWITCH]
    add_command(Ninjamida::Auction::NORMAL_AUCTION, :standard, true)
    add_command(Ninjamida::Auction::FAST_AUCTION, :fast, true)
    add_command(Ninjamida::Auction::SPECIAL_AUCTION, :special, spswitch)
  end
  
  ### Show Help Comments
  def update_help
    @help_window.set_text(@help_texts[@index])
    @offer_window.set_item_hash(@offers[@index])
  end
  
  ### Change The Width
  def window_width
    return Ninjamida::Auction::TYPE_WINDOW_WIDTH
  end
  
  ### Change The Height
  def window_height
    return Graphics.height - (fitting_height(2) + fitting_height(3) + fitting_height(1))
  end
  
  ### Set Hashes
  def offers=(offers)
    @offers = offers
  end
  
  ### Set Offer Window
  def offer_window=(offwin)
    @offer_window = offwin
  end
  
end

### New window: Auction Offer Window
class Window_AuctionOffer < Window_ItemList
  
  ### Setup Window
  def initialize
    super(Ninjamida::Auction::TYPE_WINDOW_WIDTH, fitting_height(2), window_width, window_height)
  end
  
  ### Change The Width
  def window_width
    return Graphics.width - Ninjamida::Auction::TYPE_WINDOW_WIDTH
  end
  
  ### Change The Height
  def window_height
    return Graphics.height - (fitting_height(2) + fitting_height(3))
  end
  
  ### Change Displayed Hash
  def set_item_hash(itemhash)
    @itemset = []
    if not itemhash.nil?
      itemhash.each do |thishash|
        case thishash[0]
        when 0
          @itemset += [$data_items[thishash[1]]]
        when 1
          @itemset += [$data_weapons[thishash[1]]]
        when 2
          @itemset += [$data_armors[thishash[1]]]
        end
      end
    end
    refresh
    return @itemset
  end
  
  ### Show Current Offers
  def make_item_list
    @data = @itemset
  end

  ### Override Showing Item By Type
  def include?(item)
    return true
  end
  
  ### Don't show items side-by-side
  def col_max
    return 1
  end
  
  ### Replace number display with starting price. Heh. Kludgy but works.
  def draw_item_number(rect, item)
    draw_text(rect, sprintf(item.auction_start_price.to_s + $data_system.currency_unit), 2)
  end
  
  ### Override the enable setting
  def enable?(item)
    $game_party.gold >= item.auction_start_price
  end
  
end

### Auction Processing Window
class Window_AuctionProcess < Window_Base
  
  def initialize
    super(0, Graphics.height - fitting_height(3), window_width, window_height)
    self.y = Graphics.height - fitting_height(3)
    self.openness = 255
  end
  
  def window_width
    Graphics.width
  end
  
  def window_height
    fitting_height(3)
  end
  
  def help_window=(help_window)
    @help_window = help_window
  end
  
  def start_point=(start_point)
    @start_point = start_point
  end
  
  def duration=(duration)
    @duration = duration
  end
  
  def display_help_message
    text = Ninjamida::Auction::FIRST_LINE + "\n" + Ninjamida::Auction::SECOND_LINE
    if Ninjamida::Auction::SHOW_REMAINING_TIME
      remtime = (Graphics.frame_count - @start_point)
      remtime = @duration - remtime
      remtime /= 60
      text += remtime.to_s + "s"
    end
    @help_window.set_text(text)
  end
  
  def update_message(text)
    create_contents
    draw_text_ex(0, 0, text)
  end
  
end
  

### Modify item structure so it can include auction data
class RPG::BaseItem
  
  def auction_start_price
    if @auction_start_price.nil?
      if @note =~ /<(?:start price):[ ](\d+)>/i
        @auction_start_price = $1.to_i
      else
        @auction_start_price = Ninjamida::Auction::DEFAULT_START_PRICE
      end
    end
    @auction_start_price
  end
  
  def auction_reserve_price
    if @auction_reserve_price.nil?
      if @note =~ /<(?:reserve price):[ ](\d+)>/i
        @auction_reserve_price = $1.to_i
      else
        @auction_reserve_price = Ninjamida::Auction::DEFAULT_RESERVE_PRICE
      end
    end
    @auction_reserve_price
  end
  
  def auction_max_price
    if @auction_max_price.nil?
      if @note =~ /<(?:max price):[ ](\d+)>/i
        @auction_max_price = $1.to_i
      else
        @auction_max_price = Ninjamida::Auction::DEFAULT_MAX_PRICE
      end
    end
    @auction_max_price
  end
  
  def auction_increment
    if @auction_increment.nil?
      if @note =~ /<(?:increment):[ ](\d+)>/i
        @auction_increment = $1.to_i
      else
        @auction_increment = Ninjamida::Auction::DEFAULT_INCREMENT
      end
    end
    @auction_increment
  end
  
  def auction_unique
    if @auction_unique.nil?
      if @note =~ /<(?:unique)>/i
        @auction_unique = true
      else
        @auction_unique = false
      end
    end
    @auction_unique
  end
  
end