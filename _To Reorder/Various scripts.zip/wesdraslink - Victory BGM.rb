#==================================================
# Victory Music
# Author: WesdrasLink
# Ver: 1.0 
# Release date: 31/05/2013
#===================================================
#This small script changes the Victory ME to a BGM.
#=================<CONFIGURATION>===================
BGM_WIN = "Town1" # The file name in Audio/BGM
VOLUME = 100 # 0 to 100 (Default is 100)
PITCH = 100  # 0 to 150  (Default is 100)
#===============<END CONFIGURATION>=================

module BattleManager
   def self.process_victory
    RPG::BGM.new(BGM_WIN, VOLUME, PITCH).play
    $game_message.add(sprintf(Vocab::Victory, $game_party.name))
    display_exp
    gain_gold
    gain_drop_items
    gain_exp
    replay_bgm_and_bgs
    SceneManager.return
    battle_end(0)
    return true
  end
end