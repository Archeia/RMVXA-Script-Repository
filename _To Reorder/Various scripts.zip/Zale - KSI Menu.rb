module Zale
  module KsiMenu
    Window_Skin = "" # if this is not empty, it will set the windowskin to this.
    line_height = 24 #24 is the default
    Face_WP = 2# Add additional padding here
    Face_HP = 2
    Win_W = 96 * 3 + 24 + (Face_WP * 3)
    Win_H = 96 * 2 + 24 + Face_HP
    Pos_X = Graphics.width / 2 - (Win_W / 2) # Center it on screen
    Pos_Y = Graphics.height * 0.1
    Face_W = 96
    Face_H = 96
   
    Arrows = false # Show arrows on the help window? (they're there because we shrunk the window
                   # And it thinks that something is there).
  end
end
 
class Window_MenuHCommand < Window_HorzCommand
  # We include Zale::KsiMenu in ever class because it's faster
  # to write out 'Variable' rather than 'Zale::KsiMenu::Variable' for everything
  include Zale::KsiMenu
 
  # Initialize is called whenever any object is make. It's built into ruby to do
  # that, so this is where you would put everything to set up what you're making.
  # In this case, we call this window's superclass, which we see above is
  # Window_HorzCommand (Horizontal command window). It needs to know where to place
  # the window, so we use the variables x and y, which we got when the object was
  # originally made.
  # Then we check if the Window_Skin variable is "" (empty). If it is, don't do
  # anything. If it is different though, use that as our window skin. Then we
  #use self.width = blah to change how wide the window is. We want all the windows
  # to be the same width, so we use the same variable (Technically, variables that
  # start with capital letters are constants, we're not allowed to change them,
  # though there is *technically* a way to).
  # Next we call the refresh method, and then update the cursor.
  #
  # The refresh method is not in this class, so where is it? Kind of like when we
  # called super in initialize, if we don't define a method in out class, and then
  # some other script calls this method (such as refresh), we see if the superclass
  # has it. If it does, we do that, if not, check its superclass. This keeps going
  # until we find the method or we run out of classes, in which case we'll get an
  # error saying we can't find this method.
  # These types of errors are 'undefined local variable or method `something' for
  # MyClass:0xItsMemoryAddress.
  def initialize(x, y)
    super(x, y)
    if Zale::KsiMenu::Window_Skin != ""
      self.windowskin = Cache.system(Window_Skin)
    end
    self.width = Win_W
    refresh
    update_cursor
  end
 
  # We use the add_command method, defined in Window_Command to add a command to the
  # window so we can select it later. We give it a symbol, the thing with the : in front
  # so that we can handle that specifically later. Vocab.whatever is the set of terms that
  # are defined in the Terms tab of the database. You can see the available terms at the
  # Vocab script at the top of the script editor. Check the bottom for the ones you can use
  # They'll look like:
  # def self.item;        command(4);   end   # Items
  def make_command_list
    add_command(Vocab.item,     :item)
    add_command(Vocab.save,     :save)
    add_command(Vocab.shutdown, :quit)
  end
 
  # Here we define how many columns out window will have. By default, a Window_HorzCommand
  # window will have four columns, but we only want 3, item, save, and quit. So this is how
  # we set that up.
  def col_max
    return 3
  end
end
 
class Window_KsiStatus < Window_Selectable
  include Zale::KsiMenu
 
  # Same as above.
  # @index = -1 is used to make sure we don't have a cursor over any
  # of the actor's faces (even though it shouldn't be there anyway).
  def initialize
    super(Pos_X, Pos_Y, Win_W, Win_H)
    if Window_Skin != ""
      self.windowskin = Cache.system(Window_Skin)
    end
    @index = -1
    draw_actors
  end
 
  # Here's an example of a refresh method. This will clear the contents
  # of a window, which is just a bitmap, a picture. It's refered to by
  # a method named 'contents'. So we clear it using contents.clear, and
  # then we use the create_contents method which will make a new bitmap
  # to use. This will make it whatever size we need and make sure it's
  # cleared. Then we redraw the actor's faces.
  def refresh
    contents.clear
    create_contents
    draw_actors
  end
 
  # First we setup variables for position, since we'll be changing them
  # based on how many faces we've already drawn. Then, for the size of
  # our party, we go through all the people. 'i' starts at 0 whenever you
  # use the 'times' method, and it increases by one each time the loop end
  # until it has done the number of loops. So we want to see, if i is greater
  # than 5(it drew 6 faces), then we just skip to the next iteration by using
  # 'next' This will keep happening until we run out of actors. We do this
  # because we won't fit them onto the screen anyway, so don't waste the time
  # to draw them.
  def draw_actors
    x = y = 0
    $game_party.members.size.times{ |i|
      if i > 5
        next # index starts at 0, greater than 5 won't be drawn on the screen unless you change the dimensions.
      end
      act = $game_party.members[i]
      draw_face(act.face_name, act.face_index, x, y)
      x += Face_W + Face_WP
      if x >= Face_W * 3 + (Face_WP * 3)
        x = 0
        y += Face_H + Face_HP
      end
    }
  end
end
 
class Scene_Menu < Scene_MenuBase
  include Zale::KsiMenu
  def start
    super
    create_status
    create_command
  end
 
  # Create the window that we use to select our commands. This is where
  # we use those symbols to handle processing separately. First, though,
  # we make the command window with the x position, and the y position
  # PLUS the height of the status window, because we want the command
  # window to be on the bottom of the status window.
 
  # Then we use the set_handler command for window so we can tell
  # Ruby what to do when we select an option. We need to specify the
  # symbol we gave them when we added the commands, and then a method
  # to handle the option. the method() command is part of Ruby's kernel
  # which will give you a way to call a method from anyway. We can pass
  # the method around from class to class, and still use it. So in this
  # case we're putting the method 'command_item' into another class,
  # because that's where its held until we select the option. They're
  # all stored in Window_Command. It has a container (A simple Hash)
  # to hold them all.
  def create_command
    @cmd = Window_MenuHCommand.new(Pos_X, Pos_Y + @stat.height)
    @cmd.set_handler(:item, method(:command_item))
    @cmd.set_handler(:save, method(:command_save))
    @cmd.set_handler(:quit, method(:command_quit))
  end
 
  # Create the status menu, which sets itself up automatically, we don't
  # need to pass any values to its initialize method for it to finish
  # properly.
  def create_status
    @stat = Window_KsiStatus.new
  end
 
  # The SceneManager is what handles all the scenes in the game. As such,
  # that's how we change them too. The command_whatever methods just change
  # the scene.
  def command_item
    SceneManager.call(Scene_Items)
  end
 
  def command_save
    SceneManager.call(Scene_Save)
  end
 
  def command_quit
    SceneManager.call(Scene_End)
  end
 
  # Update is called by Scene_Base every frame. In this scene, we're going
  # to run Scene_Base's update so that the game doesn't crash, and then we
  # check to see if we press the :B key, which is the escape key by default.
  # If we do press it, we return to the scene that was up before this.
  def update
    super
    if Input.trigger?(:B)
      SceneManager.return
    end
  end
 
  # When the scene is being closed, we need to clean up, so we dispose our
  # windows so that we can free up the memory they used.
  def terminate
    super
    @stat.dispose
    @cmd.dispose
  end
 
end
 
class Window_KsiItem < Window_Selectable
  # This class is mostly recycled from the Window_ItemList class, as it mainly still all
  # applied, I just took out the category window. The attr_accessor is saying to let
  # a class that has a KsiItem window to change or see what we have for our @help_window
  # variable. We use this to give it the window under the item list in the item scene
  # so that it can update the description.
  attr_accessor :help_window
  include Zale::KsiMenu
  def initialize
    @items = []
    super(Pos_X, Pos_Y, Win_W, Win_H)
    refresh
    select(0)
    activate
  end
 
  def make_item_list
    @items = $game_party.all_items
    @items.empty? ? @items.push(nil) : nil
  end
 
  def col_max
    return 2
  end
 
  def enable?(item)
    $game_party.usable?(item)
  end
 
  def draw_item(index)
    item = @items[index]
    if item
      rect = item_rect(index)
      rect.width -= 4
      draw_item_name(item, rect.x, rect.y, enable?(item), rect.width - 24)
      draw_item_number(rect, item)
    end
  end
 
  def draw_item_number(rect, item)
    # draw_text(rect, sprintf(":%2d", $game_party.item_number(item)), 2)
  end
 
  def item
    @items && index >= 0 ? @items[index] : nil
  end
 
  def update_help
    @help_window.set_item(item)
  end
 
  def cursor_move
    super
    update_help
  end
 
  def item_max
    return @items.size
  end
 
  def refresh
    make_item_list
    create_contents
    draw_all_items
  end
end
 
class Scene_Items < Scene_ItemBase
  # The Item scene class. In the initialize method, we setup the help window
  # that displays the item's description, as well as create the item window.
  include Zale::KsiMenu
  def start
    super
    create_help_window
    create_item
    @actor_window.hide
    @help_window.x = Pos_X
    @help_window.y = Pos_Y + Win_H
    @help_window.height = @help_window.fitting_height(1)
    @help_window.width = Win_W
    @help_window.arrows_visible = Arrows
    if Window_Skin != ""
      @help_window.windoskin = Cache.system(Window_Skin)
      @item_window.windowskin = Cache.system(Window_Skin)
    end
  end
 
  # We create the item window, set its help window using the attr_accessor we made
  # earlier, and then update the help window so that the description is updated and
  # ready when the scene starts.
  def create_item
    @item_window = Window_KsiItem.new
    @item_window.help_window = @help_window
    @item_window.update_help
  end
 
  # Check to see if we want to leave the item scene!
  def update
    super
    if Input.trigger?(:B)
      SceneManager.return
    end
  end
 
  # Clean up our item window. The help window was made by the superclass, so we
  # letit take care of that.
  def terminate
    super
    @item_window.dispose
  end
end