#==============================================================================#
#                              Title: Quest Log                                #
#                                Version: 1.2                                  #
#                                 Author: DRS                                  #
#                            Date: August 31, 2014                             #
#==============================================================================#

#==============================================================================
#                               Instructions
#------------------------------------------------------------------------------
#        Using the Game_System class you can add, remove, or edit quests
#
# - $game_system::add_active_quest(objective, description, rewards=nil)
#   ex. $game_system::add_quest("Slay Dragon", "The town needs your help.",
#        "Experience: +300, Gold: + 200, Weapon: Dragon Fang")
#
# - $game_system::add_inactive_quest(objective, description, rewards=nil)
#   ex. $game_system::add_quest("Slay Dragon", "The town needs your help."),
#        "Experience: +300, Gold: + 200, Weapon: Dragon Fang")
#
# - $game_system::edit_quest(objective, new_objective=nil, new_description=nil, new_reward=nil)
#   ex. $game_system::edit_quest("Slay Dragon", "2 Dragons", "Now there's two.",
#        Experience: +600, Gold: + 400, Weapon: Dragon Fang x2")
#
# - $game_system::remove_quest(objective, failure=false)
#   ex. $game_system::remove_quest("2 Dragons")       = SUCCESS
#   ex. $game_system::remove_quest("2 Dragons", true) = FAILURE 
#==============================================================================

#==============================================================================
#                              Editable Region
#==============================================================================
# ** DRS_QLOG
#------------------------------------------------------------------------------
#  This is a custom module used to store constants.
#==============================================================================
module DRS_QLOG
  QLOG_COMMAND_NAME     = "Quest Log"     # Name that appears in the menu
  QLOG_ANIMATION_SPEED  = 20              # Speed of transitional screen animations
  
  QLOG_IMAGE_BOOL       = true            # Turn background image off/on
  QLOG_IMAGE            = "qlog_bg_v1_2"  # Background image from Picture folder
  QLOG_IMAGE_X          = 0               # Background image x
  QLOG_IMAGE_Y          = 0               # Background image y
  QLOG_IMAGE_Z          = 25              # Background image z
  QLOG_IMAGE_OPACITY    = 255             # Background image opacity
  QLOG_IMAGE_VISIBLE    = true            # Background image visible
  
  QLOG_OL_BOOL          = false           # Turn overlay off/on
  QLOG_OL_IMAGE         = "qlog_overlay"  # Overlay image from Picture folder
  QLOG_OL_IMAGE_X       = 0               # Overlay image x
  QLOG_OL_IMAGE_Y       = 0               # Overlay image y
  QLOG_OL_IMAGE_Z       = 50              # Overlay image z
  QLOG_OL_IMAGE_OPACITY = 255             # Overlay image opacity
  QLOG_OL_IMAGE_VISIBLE = true            # Overlay image visible
end
#==============================================================================

#==============================================================================
# ** DRS_Quest
#------------------------------------------------------------------------------
#  This is a custom class used for the Quest_Lost.
#==============================================================================
class DRS_Quest
#--------------------------------------------------------------------------
# * Public Instance Variables
#--------------------------------------------------------------------------
  attr_accessor  :objective
  attr_accessor  :description
  attr_accessor  :rewards
  attr_accessor  :failure
#--------------------------------------------------------------------------
# * Object Initialization
#--------------------------------------------------------------------------  
  def initialize(objective, description, rewards, failure=false)
    @objective   = objective
    @description = description
    @rewards     = rewards
    @failure     = failure
  end
#--------------------------------------------------------------------------
# * Checking Method
#--------------------------------------------------------------------------
  def size()
    return "DRS"
  end
end

#==============================================================================
# ** Quest_Log
#------------------------------------------------------------------------------
#  This is a custom scene that displays current quests in the menu.
#==============================================================================
class Quest_Log < Scene_Base
  include DRS_QLOG
#--------------------------------------------------------------------------
# * Start Processing
#--------------------------------------------------------------------------
  def start
    super()
    if QLOG_IMAGE_BOOL
      # Background image
      @qlog_bg         = Sprite.new()
      @qlog_bg.bitmap  = Cache.picture(QLOG_IMAGE)
      @qlog_bg.x       = QLOG_IMAGE_X
      @qlog_bg.y       = QLOG_IMAGE_Y
      @qlog_bg.z       = QLOG_IMAGE_Z
      @qlog_bg.zoom_x  = Graphics.width.to_f / @qlog_bg.bitmap.width
      @qlog_bg.zoom_y  = Graphics.height.to_f / @qlog_bg.bitmap.height
      @qlog_bg.opacity = QLOG_IMAGE_OPACITY
      @qlog_bg.visible = QLOG_IMAGE_VISIBLE
    end
    
    if QLOG_OL_BOOL
      # Background overlay
      @qlog_ol         = Sprite.new()
      @qlog_ol.bitmap  = Cache.picture(QLOG_OL_IMAGE)
      @qlog_ol.x       = QLOG_OL_IMAGE_X
      @qlog_ol.y       = QLOG_OL_IMAGE_Y
      @qlog_ol.z       = QLOG_OL_IMAGE_Z
      @qlog_ol.zoom_x  = Graphics.width.to_f / @qlog_ol.bitmap.width
      @qlog_ol.zoom_y  = Graphics.height.to_f / @qlog_ol.bitmap.height
      @qlog_ol.opacity = QLOG_OL_IMAGE_OPACITY
      @qlog_ol.visible = QLOG_OL_IMAGE_VISIBLE
    end
    
    # Quests, objectives, and description windows
    @qlog_questlists_window    = DRS_Quest_Lists.new()
    @qlog_quests_window        = DRS_Quests_Window.new()
    @qlog_objectives_window    = DRS_Objectives_Window.new()
    @qlog_description_window   = DRS_Description_Window.new()
    @qlog_info_window          = DRS_Info_Window.new()
    @qlog_quest_options_window = DRS_Options_Window.new()
    
    # Initialize windows
    set_questlists_handlers()
    @qlog_questlists_window.activate
    @qlog_quests_window.deactivate
  end
#--------------------------------------------------------------------------
# * Post-Start Processing
#--------------------------------------------------------------------------
  def post_start
    super()
    while @qlog_questlists_window.x > 0
      @qlog_quests_window.drs_clear()
      @qlog_questlists_window.x -= QLOG_ANIMATION_SPEED
      @qlog_quests_window.x += QLOG_ANIMATION_SPEED
      Graphics.update()
    end
    @qlog_questlists_window.x = 0 if @qlog_questlists_window.x < 0
    @qlog_quests_window.x = 0 if @qlog_quests_window.x > 0
  end
#--------------------------------------------------------------------------
# * Set QuestLists Handlers
#--------------------------------------------------------------------------
    def set_questlists_handlers
      @qlog_questlists_window.set_handler(:active,    method(:drs_deactivate))
      @qlog_questlists_window.set_handler(:inactive,  method(:drs_deactivate))
      @qlog_questlists_window.set_handler(:completed, method(:drs_deactivate))
    end
#--------------------------------------------------------------------------
# * Set Quests Handlers
#--------------------------------------------------------------------------
    def set_quests_handlers
      if $game_system.current_arraylist == 0
        $game_system.active_quests.each do |quest| 
          @qlog_quests_window.set_handler(quest.objective.to_sym, method(:drs_options_menu))
        end
      elsif $game_system.current_arraylist == 1
        $game_system.inactive_quests.each do |quest| 
          @qlog_quests_window.set_handler(quest.objective.to_sym, method(:drs_options_menu))
        end
      end
    end
#--------------------------------------------------------------------------
# * Set Options Handlers
#--------------------------------------------------------------------------
    def set_options_handlers
      @qlog_quest_options_window.set_handler(:select, method(:drs_select))
      @qlog_quest_options_window.set_handler(:switch, method(:drs_switch))
      @qlog_quest_options_window.set_handler(:cancel, method(:drs_cancel))
    end
#--------------------------------------------------------------------------
# * Options Menu
#--------------------------------------------------------------------------
  def drs_options_menu
    @qlog_quest_options_window.index = 0
    @qlog_quest_options_window.y = Graphics.height*0.5-50
    @qlog_quest_options_window.activate()
    @qlog_quests_window.deactivate()
    set_options_handlers()
  end
#--------------------------------------------------------------------------
# * Select Option
#--------------------------------------------------------------------------
  def drs_select
    if $game_system.current_arraylist == 0
      $game_system.main_quest = $game_system.active_quests[$game_system.current_element]
    elsif $game_system.current_arraylist == 1
      $game_system.main_quest = $game_system.inactive_quests[$game_system.current_element]
    end
    @qlog_quest_options_window.deactivate
    @qlog_quests_window.activate
    @qlog_quest_options_window.y = 600
  end
#--------------------------------------------------------------------------
# * Switch Option
#--------------------------------------------------------------------------
  def drs_switch
    cur_element = $game_system.current_element
    if $game_system.current_arraylist == 0
      $game_system.inactive_quests.unshift($game_system.active_quests[cur_element])
      $game_system.active_quests.delete_at(cur_element)
      @qlog_quests_window.index -= 1
      @qlog_quests_window.index = 0 if @qlog_quests_window.index < 0
    elsif $game_system.current_arraylist == 1
      $game_system.active_quests.unshift($game_system.inactive_quests[cur_element])
      $game_system.inactive_quests.delete_at(cur_element)
      @qlog_quests_window.index -= 1
      @qlog_quests_window.index = 0 if @qlog_quests_window.index < 0
    end
    @qlog_quest_options_window.deactivate
    @qlog_quests_window.activate
    @qlog_quest_options_window.y = 600
  end
#--------------------------------------------------------------------------
# * Cancel Option
#--------------------------------------------------------------------------
  def drs_cancel
    @qlog_quest_options_window.deactivate()
    @qlog_quests_window.activate()
    @qlog_quest_options_window.y = 600
  end
#--------------------------------------------------------------------------
# * Deactiveate Questlist Array
#--------------------------------------------------------------------------
  def drs_deactivate
    @qlog_questlists_window.drs_update_arraylist()
    @qlog_questlists_window.deactivate()
    @qlog_quests_window.activate()
    drs_deactivate_animation()
    $game_system.display_quests = true
  end
#--------------------------------------------------------------------------
# * Deactivate Questlist Animation
#--------------------------------------------------------------------------
  def drs_deactivate_animation
    while @qlog_quests_window.width > (Graphics.width*0.5+4)
      @qlog_quests_window.drs_clear()
      @qlog_objectives_window.drs_clear()
      @qlog_description_window.drs_clear()
      @qlog_info_window.drs_clear()
      @qlog_quests_window.width  -= 20
      @qlog_objectives_window.x  -= 20
      @qlog_description_window.x -= 20
      @qlog_info_window.x        -= 20
      Graphics.update()
    end
    @qlog_quests_window.width  = Graphics.width*0.5+4 if @qlog_quests_window.width  < Graphics.width*0.5+4
    @qlog_objectives_window.x  = Graphics.width*0.5-4 if @qlog_objectives_window.x  < Graphics.width*0.5-4
    @qlog_description_window.x = Graphics.width*0.5-4 if @qlog_description_window.x < Graphics.width*0.5-4
    @qlog_info_window.x        = Graphics.width*0.5-4 if @qlog_info_window.x        < Graphics.width*0.5-4
    
    set_quests_handlers()
  end
#--------------------------------------------------------------------------
# * Activate Quest Array
#--------------------------------------------------------------------------
  def drs_activate
    @qlog_questlists_window.activate()
    @qlog_quests_window.deactivate()
    drs_activate_animation()
    @qlog_quests_window.index = 0
    $game_system.display_quests = false
  end
#--------------------------------------------------------------------------
# * Activate Quest Animation 
#--------------------------------------------------------------------------
  def drs_activate_animation()
    while @qlog_quests_window.width < Graphics.width
      @qlog_quests_window.drs_clear()
      @qlog_objectives_window.drs_clear()
      @qlog_description_window.drs_clear()
      @qlog_info_window.drs_clear()
      @qlog_quests_window.width  += 20
      @qlog_objectives_window.x  += 20
      @qlog_description_window.x += 20
      @qlog_info_window.x        += 20
      Graphics.update()
    end
    @qlog_quests_window.width  = Graphics.width if @qlog_quests_window.width  > Graphics.width
    @qlog_objectives_window.x  = Graphics.width if @qlog_objectives_window.x  < Graphics.width
    @qlog_description_window.x = Graphics.width if @qlog_description_window.x < Graphics.width
    @qlog_info_window.x        = Graphics.width if @qlog_info_window.x        < Graphics.width
  end
#--------------------------------------------------------------------------
# * Frame Update
#--------------------------------------------------------------------------
  def update
    # Exits scene if escape is pressed
    if Input.trigger?(:B) && @qlog_questlists_window.active
      RPG::SE.new("Cancel2", 80, 100).play
      return_scene() 
    end
    
    # Backs out of current quest list
    if Input.trigger?(:B) && @qlog_questlists_window.active == false
      drs_activate
    end
    
    # Call to original method
    super()
  end  
#--------------------------------------------------------------------------
# * Pre-Termination Processing
#--------------------------------------------------------------------------
  def pre_terminate
    # Terminate Animation
    while @qlog_quests_window.y < Graphics.height
      @qlog_quests_window.drs_clear()
      @qlog_questlists_window.y -= QLOG_ANIMATION_SPEED
      @qlog_quests_window.y     += QLOG_ANIMATION_SPEED
      Graphics.update
    end
    @qlog_questlists_window.y = 0
    @qlog_quests_window.y = 0
    
    # Dispose background and overlay images
    if QLOG_IMAGE_BOOL
      @qlog_bg.bitmap.dispose()
      @qlog_bg.dispose()
    end
    if QLOG_OL_BOOL
      @qlog_ol.bitmap.dispose()
      @qlog_ol.dispose()
    end
  end
#--------------------------------------------------------------------------
# * Termination Processing
#--------------------------------------------------------------------------
  def terminate
    # Dispose of Quest_Log background, overlay, and windows
    @qlog_questlists_window.dispose    unless @qlog_questlists_window.disposed?
    @qlog_quests_window.dispose        unless @qlog_quests_window.disposed?
    @qlog_objectives_window.dispose    unless @qlog_objectives_window.disposed?
    @qlog_description_window.dispose   unless @qlog_description_window.disposed?
    @qlog_info_window.dispose          unless @qlog_info_window.disposed?
    @qlog_quest_options_window.dispose unless @qlog_quest_options_window.disposed?
    
    # Call to original method
    super()
  end
end

#==============================================================================
# ** DRS_Quest_Lists
#------------------------------------------------------------------------------
#  Cycles through active, inactive, and completed quests
#==============================================================================
class DRS_Quest_Lists < Window_HorzCommand
#--------------------------------------------------------------------------
# * Object Initialization
#--------------------------------------------------------------------------
  def initialize
    super(Graphics.width, 0) # Call to original method
    @within_quest = false
  end
#--------------------------------------------------------------------------
# * Frame Update
#--------------------------------------------------------------------------
  def update
    super
    drs_update_arraylist()
  end
#--------------------------------------------------------------------------
# * Get Window Width
#--------------------------------------------------------------------------
  def window_width
    return Graphics.width
  end
#--------------------------------------------------------------------------
# * Get Window Height
#--------------------------------------------------------------------------
  def window_height
    return 48
  end
#--------------------------------------------------------------------------
# * Get Digit Count
#--------------------------------------------------------------------------
  def col_max
    return 3
  end
#--------------------------------------------------------------------------
# * Create Command List
#--------------------------------------------------------------------------
  def make_command_list
    add_command("Active Quests",    :active)
    add_command("Inactive Quests",  :inactive)
    add_command("Completed Quests", :completed)
  end
#--------------------------------------------------------------------------
# * Update Current Arraylist
#--------------------------------------------------------------------------
  def drs_update_arraylist
    $game_system.current_arraylist = @index
  end
end

#==============================================================================
# ** DRS_Quests_Window
#------------------------------------------------------------------------------
#  Displays all quests in current quest list.
#==============================================================================
class DRS_Quests_Window < Window_Command
#--------------------------------------------------------------------------
# * Object Initialization
#--------------------------------------------------------------------------
  def initialize
    super(Graphics.width*-1, 42) # Call to original method
  end
#--------------------------------------------------------------------------
# * Get Window Width
#--------------------------------------------------------------------------
  def window_width
    Graphics.width
  end
#--------------------------------------------------------------------------
# * Get Window Height
#--------------------------------------------------------------------------
  def window_height
    Graphics.height-42
  end
#--------------------------------------------------------------------------
# * Create Command List
#--------------------------------------------------------------------------
  def make_command_list
    @list = []
    if $game_system.current_arraylist == 0 && $game_system.active_quests != []
      $game_system.active_quests.each {|quest| add_command(quest.objective, quest.objective.to_sym)}
    elsif $game_system.current_arraylist == 1 && $game_system.inactive_quests != []
      $game_system.inactive_quests.each {|quest| add_command(quest.objective, quest.objective.to_sym)}
    elsif $game_system.current_arraylist == 2 && $game_system.completed_quests != []
      $game_system.completed_quests.each {|quest| add_command(quest.objective, quest.objective.to_sym)}
    else
      @list = []
    end
  end
#--------------------------------------------------------------------------
# * Frame Update
#--------------------------------------------------------------------------
  def update
    super                                 # Call to original method
    contents.clear()                      # Clear previous data
    $game_system.current_element = @index # Update quest objective and description
    make_command_list                     # Call make command list
    draw_quests() 
  end
#--------------------------------------------------------------------------
# * Draw Quests List
#--------------------------------------------------------------------------
  def draw_quests()
    for i in 0...@list.size()
      draw_item(i) if $game_system.display_quests
    end
  end
#--------------------------------------------------------------------------
# * Clear Screens
#--------------------------------------------------------------------------
  def drs_clear()
    contents.clear()
  end
end

#==============================================================================
# ** DRS_Objectives_Window
#------------------------------------------------------------------------------
#  This message window is used to display a list of current quests.
#==============================================================================
class DRS_Objectives_Window < Window_Base
#--------------------------------------------------------------------------
# * Object Initialization
#--------------------------------------------------------------------------
  def initialize
    #Call to original method
    super(Graphics.width, 42, Graphics.width*0.5+4, 48)
  end
#--------------------------------------------------------------------------
# * Frame Update
#--------------------------------------------------------------------------
  def update
    super
    contents.clear
    draw_objective() if $game_system.display_quests
  end
#--------------------------------------------------------------------------
# * Draw Quest Objective
#--------------------------------------------------------------------------
  def draw_objective()
    text = ""

    if $game_system.current_arraylist == 0 && $game_system.active_quests != []
      text = $game_system.active_quests[$game_system.current_element].objective
    elsif $game_system.current_arraylist == 1 && $game_system.inactive_quests != []
      text = $game_system.inactive_quests[$game_system.current_element].objective
    elsif $game_system.current_arraylist == 2 && $game_system.completed_quests != []
      text = $game_system.completed_quests[$game_system.current_element].objective
    end
    
    if text != ""
      center_text = (self.width/2.15) - (self.text_size(text).width/2)
      draw_text_ex(center_text,0,text)
    end
  end
#--------------------------------------------------------------------------
# * Clear Screens
#--------------------------------------------------------------------------
  def drs_clear()
    contents.clear()
  end
end

#==============================================================================
# ** DRS_Description_Window
#------------------------------------------------------------------------------
#  This message window is used to display quest description.
#==============================================================================
class DRS_Description_Window < Window_Base
#--------------------------------------------------------------------------
# * Object Initialization
#--------------------------------------------------------------------------
  def initialize
    #Call to original method
    super(Graphics.width, 82, Graphics.width*0.5+4, Graphics.height-48)
  end
#--------------------------------------------------------------------------
# * Frame Update
#--------------------------------------------------------------------------
  def update
    super
    contents.clear
    draw_description() if $game_system.display_quests
  end
#--------------------------------------------------------------------------
# * Draw Quest Description
#--------------------------------------------------------------------------
  def draw_description()
    text = ""

    if $game_system.current_arraylist == 0 && $game_system.active_quests != []
      text = $game_system.active_quests[$game_system.current_element].description
    elsif $game_system.current_arraylist == 1 && $game_system.inactive_quests != []
      text = $game_system.inactive_quests[$game_system.current_element].description
    elsif $game_system.current_arraylist == 2 && $game_system.completed_quests != []
      text = $game_system.completed_quests[$game_system.current_element].description
    end
    
    if text != ""
      text = wordwrapper(text)
      draw_text_ex(20,0,text)
    end
  end
#--------------------------------------------------------------------------
# * Wrap Window Text
#--------------------------------------------------------------------------
  def wordwrapper(text)
    if text != nil
      temp_text        = ""        # Temporary text var
      current_text_pos = 10        # Current text position
      average = 0
      average_index = 0
      
      for i in 0...text.size
        # Update text position
        temp_text += text[i]
        text_size_width = text_size(text[i]).width
        current_text_pos += text_size_width
        average += text_size_width
        average_index += 1
        
        # Check if text has reached end of the screen
        if current_text_pos > self.width - 50
          # Reverse through string and check for a " "
          index = i
          while index > 0
            if text[index] == " "
              temp_text[index] = "\n"
              current_text_pos = 10
              break
            else
              index -= 1
            end # if
          end # while
        end # if
      end # for
      
      text = temp_text
      
    end # if  
    return text
  end # def
#--------------------------------------------------------------------------
# * Clear Screens
#--------------------------------------------------------------------------
  def drs_clear()
    contents.clear()
  end
end

#==============================================================================
# ** DRS_Info_Window
#------------------------------------------------------------------------------
#  This message window is used to display quest description.
#==============================================================================
class DRS_Info_Window < Window_Base
#--------------------------------------------------------------------------
# * Object Initialization
#--------------------------------------------------------------------------
  def initialize
    #Call to original method
    super(Graphics.width, Graphics.height-48, Graphics.width*0.5+4, 48)
    @frame_index = 0
    @frame_time  = 0
    @frame_end   = 60
  end
#--------------------------------------------------------------------------
# * Frame Update
#--------------------------------------------------------------------------
  def update
    super
    contents.clear
    draw_info() if $game_system.display_quests
  end
#--------------------------------------------------------------------------
# * Draw Quest Description
#--------------------------------------------------------------------------
  def draw_info()
    # Check if list is empty
    temp_bool = true
    temp_bool = false if $game_system.active_quests    == [] && $game_system.current_arraylist == 0
    temp_bool = false if $game_system.inactive_quests  == [] && $game_system.current_arraylist == 1
    temp_bool = false if $game_system.completed_quests == [] && $game_system.current_arraylist == 2
    
    if temp_bool
      # Collect rewards data
      temp_rewards = $game_system.active_quests[$game_system.current_element]    if $game_system.current_arraylist == 0  
      temp_rewards = $game_system.inactive_quests[$game_system.current_element]  if $game_system.current_arraylist == 1
      temp_rewards = $game_system.completed_quests[$game_system.current_element] if $game_system.current_arraylist == 2
    
      # Utilize frame index
      @frame_time += 1
      if @frame_time > @frame_end
        @frame_time   = 0
        @frame_index += 1
        @frame_index = 0 if @frame_index >= temp_rewards.rewards.size().to_i()
      end
      
      # Declare text
      text = temp_rewards.rewards[@frame_index]
      
      # Draw text
      center_text = (self.width/2.15) - (self.text_size(text).width/2)
      draw_text_ex(center_text,0,text)
    end
  end
#--------------------------------------------------------------------------
# * Clear Screens
#--------------------------------------------------------------------------
  def drs_clear()
    contents.clear()
  end
end

#==============================================================================
# ** DRS_Options_Window
#------------------------------------------------------------------------------
#  Displays all quests in current quest list.
#==============================================================================
class DRS_Options_Window < Window_Command
#--------------------------------------------------------------------------
# * Object Initialization
#--------------------------------------------------------------------------
  def initialize
    super((Graphics.width*0.5)-70, 600) # Call to original method
  end
#--------------------------------------------------------------------------
# * Get Window Width
#--------------------------------------------------------------------------
  def window_width
    140
  end
#--------------------------------------------------------------------------
# * Get Window Height
#--------------------------------------------------------------------------
  def window_height
    100
  end
#--------------------------------------------------------------------------
# * Get Number of Items
#--------------------------------------------------------------------------
  def item_max
    3
  end
#--------------------------------------------------------------------------
# * Create Command List
#--------------------------------------------------------------------------
  def make_command_list
    add_command("Make Current Quest", :select)
    add_command("Switch Quests List", :switch)
    add_command("     Cancel       ", :cancel)
  end
#--------------------------------------------------------------------------
# * Frame Update
#--------------------------------------------------------------------------
  def update
    super()          # Call to original method
    contents.clear() # Clear previous data   # Call make command list
    draw_options()   # Draw ques
  end
#--------------------------------------------------------------------------
# * Draw Quests List
#--------------------------------------------------------------------------
  def draw_options()
    for i in 0...@list.size()
      draw_item(i)
    end
  end
#--------------------------------------------------------------------------
# * Clear Screens
#--------------------------------------------------------------------------
  def drs_clear()
    contents.clear()
  end
end

#==============================================================================
# ** Game_System
#------------------------------------------------------------------------------
#  This class handles system data. It saves the disable state of saving and 
#  menus. Instances of this class are referenced by $game_system.
#==============================================================================
class Game_System
#--------------------------------------------------------------------------
# * Public Instance Variables
#--------------------------------------------------------------------------
  attr_accessor :active_quests 
  attr_accessor :inactive_quests
  attr_accessor :completed_quests
  attr_accessor :current_arraylist
  attr_accessor :current_element
  attr_accessor :display_quests
  attr_accessor :display_info
  attr_accessor :main_quest
#--------------------------------------------------------------------------
# * Object Initialization
#--------------------------------------------------------------------------
  alias drs_questlog_gamesystem_initialize initialize
#--------------------------------------------------------------------------
  def initialize
    # Initializing instance variables
    @active_quests     = []
    @inactive_quests   = []
    @completed_quests  = []
    @current_arraylist = 0
    @current_element   = 0
    @display_quests    = false
    @display_info      = false
    @main_quest        = nil
    
    # Call original method
    drs_questlog_gamesystem_initialize()
  end
#--------------------------------------------------------------------------
# * Add Active Quest
#--------------------------------------------------------------------------
  def add_active_quest(objective, description, reward=nil)
    @active_quests.unshift(DRS_Quest.new(objective, description, drs_decypher(reward)))
  end
#--------------------------------------------------------------------------
# * Add Inactive Quest
#--------------------------------------------------------------------------
  def add_inactive_quest(objective, description, reward=nil)
    @inactive_quests.unshift(DRS_Quest.new(objective, description, drs_decypher(reward)))
  end
#--------------------------------------------------------------------------
# * Edit Quest
#--------------------------------------------------------------------------
  def edit_quest(objective, new_objective=nil, new_description=nil, new_reward=nil)
    # Check active quests
    @active_quests.each do |quest|
      if quest.objective == objective
        quest.objective   = new_objective   if new_objective   != nil
        quest.description = new_description if new_description != nil
        quest.rewards     = drs_decypher(new_reward)
        break
      end
    end
    # Check inactive quests
    @inactive_quests.each do |quest|
      if quest.objective == objective
        quest.objective   = new_objective   if new_objective   != nil
        quest.description = new_description if new_description != nil
        quest.rewards     = drs_decypher(new_reward)
        break
      end 
    end
  end    
#--------------------------------------------------------------------------
# * Remove A Quest
#--------------------------------------------------------------------------
  def remove_quest(objective, failure=false)
    # Check active quests
    for i in 0...@active_quests.size
      if @active_quests[i].objective == objective
        @completed_quests.unshift(@active_quests[i])
        @completed_quests[0].failure = failure
        if failure
          @completed_quests[0].description = "FAILURE: " + @completed_quests[0].description
        else
          @completed_quests[0].description = "SUCCESS: " + @completed_quests[0].description
        end
        @active_quests.delete_at(i)
        break
      end
    end
    # Check inactive quests
    for i in 0...@inactive_quests.size
      if @inactive_quests[i].objective == objective
        @completed_quests.unshift(@inactive_quests[i])
        @completed_quests[0].failure = failure
        if failure == false
          @completed_quests[0].description = "FAILURE: " + @completed_quests[0].description
        else
          @completed_quests[0].description = "SUCCESS: " + @completed_quests[0].description
        end
        @inactive_quests.delete_at(i)
        break
      end
    end
  end
#--------------------------------------------------------------------------
# * Decypher Info
#--------------------------------------------------------------------------
  def drs_decypher(string)
    # Temporary variables
    temp_array = []
    temp_word  = ""
    
    # Returns empty arraylist if 
    return ["No Reward!"] if string == nil
    
    # Decypher array_list
    for i in 0...string.length()
      # Add current letter to temp_word
      temp_word += string[i] if string[i] != "," && string[i] != "\n"
      
      # Add temp_word to temp_array
      if string[i] == "," && temp_word != ""
        temp_array.push(temp_word)
        temp_word = ""
        next
      end
      
      # Add temp_word to temp_array
      if i >= string.length() - 1 && temp_word != ""
        temp_array.push(temp_word)
        temp_word = ""
      end
    end
    return temp_array
  end
end

#==============================================================================
# ** Window_MenuCommand
#------------------------------------------------------------------------------
#  This command window appears on the menu screen.
#==============================================================================
class Window_MenuCommand < Window_Command
  include DRS_QLOG
#--------------------------------------------------------------------------
# * Add Quest Log Command to Menu
#--------------------------------------------------------------------------
  alias drs_questlog_windowmenucommand_addoriginalcommands add_original_commands
#--------------------------------------------------------------------------
  def add_original_commands
    drs_questlog_windowmenucommand_addoriginalcommands  # Call original method
    add_command(QLOG_COMMAND_NAME,   :questlog,   true) # Menu 'Quest Log' command 
  end
end

#==============================================================================
# ** Scene_MenuBase
#------------------------------------------------------------------------------
#  This class performs basic processing related to the menu screen.
#==============================================================================
class Scene_Menu < Scene_MenuBase
#--------------------------------------------------------------------------
# * Create Command Window
#--------------------------------------------------------------------------
  alias drs_questlog_scenemenu_createcommandwindow create_command_window
#--------------------------------------------------------------------------
  def create_command_window
    drs_questlog_scenemenu_createcommandwindow()
    @command_window.set_handler(:questlog,    method(:questlog))
  end
#--------------------------------------------------------------------------
# * Create Quest_Log Scene
#--------------------------------------------------------------------------
  def questlog
    SceneManager.call(Quest_Log)
  end
end