# Pause While Talking by Thomas Smith
# This script pauses all other movement during message windows.
# Good for cut scenes on map or for an ABS.

class Game_Event < Game_Character
  alias update_self_movement_orig update_self_movement
  def update_self_movement
    return if $game_message.busy?
    update_self_movement_orig
  end
end