#==============================================================================
# Dynamic Title Screen Music
# by: Racheal
# Version 1.0
# Created: 22/11/2014
#==============================================================================
# Changes the title screen music based on a variable set in-game.
#==============================================================================
# Instructions:
# * Insert in the Materials section
# * Configure to your liking below
#==============================================================================
# Compatibility:
# This script is for RPG Maker VX Ace
# * Overwrites: Scene_Title: play_title_music
#==============================================================================

#==============================================================================
# Customization
#==============================================================================
module Racheal_Title_Music
  #Set which variable controls the change in the title screen
  TITLE_MUSIC_VARIABLE = 6
  
  #Set whether to check the highest variable in all the save files or
  #just use the most recent save
  CHECK_ALL_SAVES = false
  
  #Set music file info here
  MUSIC_SETTINGS = [#[name, volume, pitch],
                     ["Theme1", 100, 100],
                     ["Theme2", 100, 100]
                   ]
end
#==============================================================================
# End Customization
#==============================================================================

#==============================================================================
# ** DataManager
#==============================================================================

module DataManager
  #--------------------------------------------------------------------------
  # * Create Save Header
  #--------------------------------------------------------------------------
  class << self; alias dynamic_title_music_make_save_header make_save_header; end
  def self.make_save_header
      header = dynamic_title_music_make_save_header
      header[:music] = $game_variables[Racheal_Title_Music::TITLE_MUSIC_VARIABLE]
      header
  end 
end

#==============================================================================
# ** Scene_Title
#==============================================================================

class Scene_Title < Scene_Base
  #--------------------------------------------------------------------------
  # * Play Title Screen Music
  #--------------------------------------------------------------------------
  def play_title_music
    music = get_music
    Audio.bgm_play('Audio/BGM/' + music[0], music[1], music[2])
    RPG::BGS.stop
    RPG::ME.stop
  end
  #--------------------------------------------------------------------------
  # * Get Music Title
  #--------------------------------------------------------------------------
  def get_music
    music = 0
    if Racheal_Title_Music::CHECK_ALL_SAVES
      #Check all saves
      for i in 0...DataManager.savefile_max
        header = DataManager.load_header(i)
        next unless header and header[:music]
        music = [music, header[:music]].max
      end
    else
      #Check latest save
      header = DataManager.load_header(DataManager.latest_savefile_index)
      if header and header[:music]
        music = [music, header[:music]].max
      end
    end
    #---
    return Racheal_Title_Music::MUSIC_SETTINGS[music]
  end
end