#--------------------------------------------------------------------------
# 
### Downwinds ###
# -- Created: 13/05/14
#--------------------------------------------------------------------------
# Status screen window that displays EXP progress to next level as a gauge. 
# Also allows TP to be displayed as a gauge if it is not reset
# after battle.
#--------------------------------------------------------------------------
class Window_Status < Window_Selectable
#--------------------------------------------------------------------------
# * Object Initialization
#--------------------------------------------------------------------------
def initialize(actor)
super(0, 0, Graphics.width, Graphics.height)
@actor = actor
refresh
activate
end
#--------------------------------------------------------------------------
# * Set Actor
#--------------------------------------------------------------------------
def actor=(actor)
return if @actor == actor
@actor = actor
refresh
end
#--------------------------------------------------------------------------
# * Refresh
#--------------------------------------------------------------------------
def refresh
contents.clear
draw_block1 (line_height * 0)
draw_horz_line(line_height * 4)
draw_block3 (line_height * 5)
draw_horz_line(line_height * 11)
draw_block4 (line_height * 12)
end
#--------------------------------------------------------------------------
# * Draw Block 1
#--------------------------------------------------------------------------
def draw_block1(y)
draw_actor_face(@actor, 8, y)
draw_basic_info(300, y)
draw_actor_name(@actor, 136, y)
draw_actor_level(@actor, 136, y + line_height * 1)
draw_actor_class(@actor, 136, y+line_height*2)
draw_actor_nickname(@actor, 136, y+line_height*3)
end
#--------------------------------------------------------------------------
# * EXP Gauge
#--------------------------------------------------------------------------
 def draw_actor_exp(actor, x, y, width = 124)
 @s1 = actor.exp-actor.exp_for_level(actor.level)
 @s2 = actor.exp_for_level(actor.level+1)-actor.exp_for_level(actor.level)
 def exp_rate
 @s2 > 0 ? 
 @s1.to_f / @s2 : 0
 end
 draw_gauge(x, y, width, exp_rate, mp_gauge_color1, mp_gauge_color2)
 change_color(system_color)
 draw_text(x, y, 30, line_height, "EXP")
 draw_current_and_max_values(x, y, width, @s1, @s2, mp_color(actor), normal_color)
 end
 #--------------------------------------------------------------------------
 # * Draw Block 3
 #--------------------------------------------------------------------------
 def draw_block3(y)
 draw_parameters(32, y)
 draw_equipments(288, y)
 end
 #--------------------------------------------------------------------------
 # * Draw Block 4
 #--------------------------------------------------------------------------
 def draw_block4(y)
 draw_description(4, y)
 end
 #--------------------------------------------------------------------------
 # * Draw Horizontal Line
 #--------------------------------------------------------------------------
 def draw_horz_line(y)line_y = y + line_height / 2 - 1
 contents.fill_rect(0, line_y, contents_width, 2, line_color)
 end
 #--------------------------------------------------------------------------
 # * Get Color of Horizontal Line
 #--------------------------------------------------------------------------
 def line_color
 color = normal_color
 color.alpha = 48
 color
 end
 #--------------------------------------------------------------------------
 # * Draw Basic Information
 #--------------------------------------------------------------------------
 def draw_basic_info(x, y)
 draw_actor_hp(@actor, x, y + line_height * 0)
 draw_actor_mp(@actor, x, y + line_height * 1)
 draw_actor_tp(@actor, x, y + line_height * 2)
 draw_actor_exp(@actor, x, y + line_height * 3)
 end
 #--------------------------------------------------------------------------
 # * Draw Parameters
 #--------------------------------------------------------------------------
 def draw_parameters(x, y)
 6.times {|i| draw_actor_param(@actor, x, y + line_height * i, i + 2) }
 end
 #--------------------------------------------------------------------------
 # * Draw Equipment
 #--------------------------------------------------------------------------
 def draw_equipments(x, y)
 @actor.equips.each_with_index do |item, i|
 draw_item_name(item, x, y + line_height * i)
 end
 end
 #--------------------------------------------------------------------------
 # * Draw Description
 #--------------------------------------------------------------------------
 def draw_description(x, y)
 change_color(system_color)
 draw_text(x, y, 50, line_height, "Bio:")
 draw_text_ex(x, y + line_height * 1, @actor.description)
 end
 end