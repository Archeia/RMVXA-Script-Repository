=begin
# https://forums.rpgmakerweb.com/index.php?threads/snake-minigame-v1-0.16770/
#==============================================================================#
#   R2 Snake minigame Mod
#   Version 1.01
#   Author: Zarby
#   Date: 10 Dec 2018
#   Latest: 10 Dec 2018
#==============================================================================#
#   UPDATE LOG
#------------------------------------------------------------------------------#
# 10 Dec 2018 - Modified to take out Global variables 
#               and add in Screen Resolution option.
#==============================================================================#
#   TERMS OF USE
#------------------------------------------------------------------------------#
# - Please credit Zarby
# - Follow whatever terms Zarby has
#==============================================================================#

This script creates a mini game of an old classic Snake. Where you move a 
snake around and eat food causing the snake to grow.

Gameplay:
    Move the snake up down left and right to collect food.
    Continue until you die.

you do have the option to quit. Press excape.

=end

#==============================================================================
# ** General Configuration
#------------------------------------------------------------------------------
#  You can set Parameters here
#==============================================================================
module Zarby_snake
  
Snake_speed = 1
Speed_acceleration = 0.2
#return score to variable [Set it to 0 if you don't want to return score to a variable] :
Score_variable_id = 20
#text if we lose :
Lose_text = "Game Over"
#Score Management :
#every time snake move it decrease by 1 the value of the score the food give
Everytime_snake_move = 1
Everytime_snake_eat = 100

#Graphics Settings
#if you don't want graphics set all to : nil
#(image must be 32x16 pixel in picture folder first 16 pixel = looking to right side, last 16 pixel = looking to down side)
Head_graphics = "head"
Body_graphics = "body"
Food_graphics = nil

# Screen Size Switch. True is 640 x 480, false is 544 x 416
Resolution = 10 # Game_Switch

end


#==============================================================================
# ** Window_PauseCommand
#------------------------------------------------------------------------------
#  This command window appears when escape is pressed while playing
#==============================================================================

class Window_PauseCommand < Window_Command
  def initialize(x,y)
    super(x, y)

  end

  def make_command_list
    add_command("Continue",   :continue,   true)
    add_command("Leave",   :leave,   true)
  end
 
end

#===============================================================================
# ** Score_Window
#-------------------------------------------------------------------------------
#  This window display the score                                           
#===============================================================================
class Window_Score < Window_Base

  def initialize(x, y)
    super(x, y, 160, line_height + 32)
    @score = 0
    refresh
    self.opacity = 0
    self.back_opacity = 0
  end

  def update_score(score)
    @score = score
  end
 
  def refresh
    self.contents.clear
    self.contents.draw_text(0, 0, 200, line_height, @score)
  end
end

#===============================================================================
# ** Snake_Body
#-------------------------------------------------------------------------------
#  This class is the snake head and body                                           
#===============================================================================

class Snake_Body
    attr_accessor :x
    attr_accessor :y
    attr_accessor :direction
  def initialize(x,y,direction)
    @sprite = Sprite.new
    @x = x
    @y = y
    @sprite.x = x*16
    @sprite.y = y*16
    @lastx = @x
    @lasty = @y
    @graphicx = 0
    @graphicy = 0
    @sprite.bitmap = Bitmap.new(16,16)
    @bmp = nil
    
    if (direction != -1)#body
      if (Zarby_snake::Body_graphics != nil)
        @bmp = Cache.picture(Zarby_snake::Body_graphics)
        @sprite.bitmap.blt(0,0,@bmp,Rect.new(16,0,16,16))
      else
        @sprite.bitmap.fill_rect(Rect.new(0,0,16,16),Color.new(0,200,0))
      end
    else#head
      if (Zarby_snake::Body_graphics != nil)
        @bmp = Cache.picture(Zarby_snake::Head_graphics)
        @sprite.bitmap.blt(0,0,@bmp,Rect.new(16,0,16,16))
      else
        @sprite.bitmap.fill_rect(Rect.new(0,0,16,16),Color.new(0,250,0))
      end
      @direction = 0
    end
    @speed = 0
  end

 
  def updatelastpos()
    @lastx = @x
    @lasty = @y
    @graphicx = 0
    @graphicy = 0
  end
 
  def dispose()
    @bmp.dispose
    @sprite.dispose
  end
    
  def updatepos(speed)
    @speed = speed
    if (@x> @lastx)
      @graphicx = (@graphicx+@speed)
    end
    if (@y > @lasty)
      @graphicy = (@graphicy+@speed)
    end
    if (@x< @lastx)
      @graphicx = (@graphicx-@speed)
    end
    if (@y < @lasty)
      @graphicy = (@graphicy-@speed)
    end


    @sprite.x = (@lastx*16)+@graphicx
    @sprite.y = (@lasty*16)+@graphicy
    
  if @bmp != nil
    if @lastdirection != @direction
      @sprite.bitmap.clear
      case @direction
      when 0
        @sprite.bitmap.blt(0,0,@bmp,Rect.new(16,0,16,16))
      when 1
        @sprite.bitmap.blt(0,0,@bmp,Rect.new(0,0,16,16))
      when 2
        @sprite.bitmap.blt(0,0,@bmp,Rect.new(16,16,16,-16))
      when 3
        @sprite.bitmap.blt(0,0,@bmp,Rect.new(16,0,-16,16))
      end
    end
  end
 
    @lastdirection = @direction
  end
 
 
end  
 
class Scene_Snake < Scene_Base
 

  def initialize
    super
    create_window_score
    create_window_command
    create_sprites
    create_settings
    create_object_array
    generate_food(rand(34),rand(26))
  end


  def update
    super

    if Input.trigger?(:B)
      pause
    end

    if @pause == false
      get_direction
      if (@direction != -1)
        @timer += @snake_speed
        every_tick
        update_snake
        
      end
    end
 
  end
 

  def terminate
    super
    
  end
 
 
  def every_tick
    
    if (@timer >= 16)
      if @food_score > 0
        @food_score = @food_score - 1
      end
      (@snakebody.size-1).downto(1){ |i|
      @snakebody[i].direction = @snakebody[i-1].direction
      @snakebody[i].updatelastpos()
      @snakebody[i].x = @snakebody[i-1].x
      @snakebody[i].y = @snakebody[i-1].y
      }
      @snakebody[0].direction = @direction
      @snakebody[0].updatelastpos()
        
      if (@direction == 0)#Down
        @snakebody[0].y = @snakebody[0].y+1
      end
      if (@direction == 1)#Right
        @snakebody[0].x = @snakebody[0].x+1
      end
      if (@direction == 2)#Up
        @snakebody[0].y = @snakebody[0].y-1
      end
      if (@direction == 3)#Left
        @snakebody[0].x= @snakebody[0].x-1
      end
       
      @window_score.update_score(@score)
      @window_score.refresh
      
      if $game_switches[Zarby_snake::Resolution] == true
        if (@snakebody[0].x > 39)
          @snakebody[0].x = 0
        end

        if (@snakebody[0].x < 0)
          @snakebody[0].x = 39
        end

        if (@snakebody[0].y > 29)
          @snakebody[0].y = 0
        end

        if (@snakebody[0].y < 0)
          @snakebody[0].y = 29
        end
      else
        if (@snakebody[0].x > 33)
          @snakebody[0].x = 0
        end

        if (@snakebody[0].x < 0)
          @snakebody[0].x = 33
        end

        if (@snakebody[0].y > 25)
          @snakebody[0].y = 0
        end

        if (@snakebody[0].y < 0)
          @snakebody[0].y = 25
        end
      end
      @timer = 0
    end
    
  end
 
 
  def get_direction
    
    if Input.press?(Input::DOWN)
      @direction = 0
    end
    if Input.press?(Input::UP)
      @direction = 2
    end
    if Input.press?(Input::LEFT)
      @direction = 3
    end
    if Input.press?(Input::RIGHT)
      @direction = 1
    end
  end
 
  def update_snake
    (@snakebody.size-1).downto(0){ |i|
          
      if (i != 0)
        if ((@snakebody[0].x == @snakebody[i].x) and 
           (@snakebody[0].y == @snakebody[i].y))
                        
          $game_message.texts.push(Zarby_snake::Lose_text)
          command_leave
          if Zarby_snake::Score_variable_id  != 0
            $game_variables[Zarby_snake::Score_variable_id] = @score
          end
                     
          break;
        end
      end
      @snakebody[i].updatepos(@snake_speed)}
       
      
    if ((@snakebody[0].x == @food_x) and (@snakebody[0].y == @food_y))
      @snakebody.push(Snake_Body.new(
      @snakebody[@snakebody.size-1].x,@snakebody[@snakebody.size-1].y,@snakebody[@snakebody.size-1].direction))
      @snake_speed = @snake_speed + @speed_acceleration
      @score =  @score + @food_score
      @window_score.update_score(@score)
      @food_score = Zarby_snake::Everytime_snake_eat
      generate_food(rand(34),rand(26))
    end
       
  end

 
 
  def pause
    if @pause == false
      @window_command.activate
      @window_command.visible = true
      @pause = true
    else
      unpause
    end
  end
 
  def unpause
    @window_command.visible = false
    @pause = false
  end
 
  def create_window_score
    @window_score = Window_Score.new(0,0)
  end
 
  def create_window_command
    @window_command = Window_PauseCommand.new(192,160)
    @window_command.set_handler(:continue,      method(:command_continue))
    @window_command.set_handler(:leave,      method(:command_leave))
    @window_command.visible = false
    @window_command.deactivate
  end
 
  def create_sprites
    @food_sprite = Sprite.new
    @food_sprite.bitmap = Bitmap.new(16,16)
    if Zarby_snake::Food_graphics != nil
      @food_sprite.bitmap = Cache.picture(Zarby_snake::Food_graphics)
    else
      @food_sprite.bitmap.fill_rect(Rect.new(0,0,16,16),Color.new(250,230,130))
    end
  end
 
  def create_object_array
  @snakebody = []
    @snakebody.push(Snake_Body.new(17,13,-1))
    @snakebody.push(Snake_Body.new(17,13,0))
    @snakebody.push(Snake_Body.new(17,13,0))
  end
 
  def create_settings
    @snake_speed = Zarby_snake::Snake_speed
    @speed_acceleration = Zarby_snake::Speed_acceleration
    @direction = -1
    @score = 0
    @food_score = Zarby_snake::Everytime_snake_eat
    @timer = 25
    generate_food(rand(34),rand(26))
    @food_x = 0
    @food_y = 0
    @leaving = false
    @pause = false
  end
 
  def generate_food(x,y)
    @food_x = x
    @food_y = y
    @food_sprite.x = x * 16
    @food_sprite.y = y * 16
  end
 
  def command_continue
    @window_command.visible = false
    @pause = false
  end
 
  def command_leave
    @window_command.dispose
    SceneManager.call(Scene_Map)
  end
 
end