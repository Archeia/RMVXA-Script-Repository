=begin

 Particle Engine
 by arevulopapo
 port by PK8
 Created: 11/15/2007
 Modified: 5/9/2012 - 5/12/2012
 Ported: 5/10/2012 (VX), 5/12/2012 (Ace)
 ──────────────────────────────────────────────────────────────────────────────
 ■ Introduction
   This script lets you create particle effects in your game. Particles are
   integrated into "Spriteset_Map", so the can be displayed over/under an event.
 ──────────────────────────────────────────────────────────────────────────────
 ■ Methods Aliased
   Spriteset_Map.initialize
   Spriteset_Map.update
   Spriteset_Map.dispose
 ──────────────────────────────────────────────────────────────────────────────
 ■ Thanks
   mobychan for helping out and pointing me to Archeia's RPG Maker VX's Ace
   tips and tricks page, which talked about how events set to parallel process
   need to be put in a loop in order for them to keep animating while events
   are being interacted with.
 ──────────────────────────────────────────────────────────────────────────────
 ■ Usage
   Effects are called from "Script" command like this:
     particle_effect(EVENT_ID, EFFECT, LOCK, X, Y)
       EVENT_ID  - ID of an event the particles will flow from.
                    -7/"follower3" for Follower 3
                    -6/"follower2" for Follower 2
                    -5/"follower1" for Follower 1
                    -4/"airship" for Airship.
                    -3/"ship" for Ship.
                    -2/"boat" for Boat.
                    -1/"player" for Player.
                     1 and above for Events.
                     * Use @event_id for "This Event"
                     * Use an array to specify multiple IDs.
       EFFECT    - name of the effect to call. Names are defined in the
                   Spriteset_Map. (Find: case effect)
                     * Use an array to specify multiple effects.
       LOCK      - alignment of the particles. 'event' to align particles
                   with event's map position, 'screen' to align with event's
                   screen position.
                   For static events, like fireplaces, teleports, etc.
                    'event' alignment is recommended.
                   For moving events use 'screen' mode.
       X, Y      - number of pixels that will be added to the event's position
                   to determine the starting point of particles.
                   That's your most powerful weapon. See the demo for examples.
                    * Use an array to specify multiple X/Y coordinates.
 ──────────────────────────────────────────────────────────────────────────────
 ■ Port Modifications
   o Added shortcuts within the script calls. You can now use arrays in
     EVENT_ID, EFFECT, X, and Y to set more events, effects, and coordinates.
   o Users can now set particles onto vehicles by setting EVENT_ID to "boat",
     "ship", and "airship".
                   
=end

#==============================================================================
# ** Spriteset_Map
#------------------------------------------------------------------------------
#  This class brings together map screen sprites, tilemaps, etc. It's used
# within the Scene_Map class.
#==============================================================================

class Spriteset_Map
  #--------------------------------------------------------------------------
  # * Add Effect
  #--------------------------------------------------------------------------
  def add_effect(event=1, effect='', lock='event', x=0, y=0)
    # Case: Event
    event = event.downcase.gsub(/\s+/, "") if event.is_a?(String)
    case event
    when -20, "follower16"; object = $game_player.followers[15]
    when -19, "follower15"; object = $game_player.followers[14]
    when -18, "follower14"; object = $game_player.followers[13]
    when -17, "follower13"; object = $game_player.followers[12]
    when -16, "follower12"; object = $game_player.followers[11]
    when -15, "follower11"; object = $game_player.followers[10]
    when -14, "follower10"; object = $game_player.followers[9]
    when -13, "follower9";  object = $game_player.followers[8]
    when -12, "follower8";  object = $game_player.followers[7]
    when -11, "follower7";  object = $game_player.followers[6]
    when -10, "follower6";  object = $game_player.followers[5]
    when -9,  "follower5";  object = $game_player.followers[4]
    when -8,  "follower4";  object = $game_player.followers[3]
    when -7,  "follower3";  object = $game_player.followers[2]
    when -6,  "follower2";  object = $game_player.followers[1]
    when -5,  "follower1";  object = $game_player.followers[0]
    when -4,  "airship";    object = $game_map.airship
    when -3,  "ship";       object = $game_map.ship
    when -2,  "boat";       object = $game_map.boat
    when -1,  "player";     object = $game_player
    else
      if event.is_a?(Integer); object = $game_map.events[event]
      else; object = event
      end
    end
    object = nil if object.is_a?(Game_Follower) and $game_player.vehicle != nil
    
    #------------------------------------------------------------------------
    # Configuration
    #------------------------------------------------------------------------
    case effect
    # (sprite, acceleration[x,y], gravity[x,y], opacity[base,loss], blending)
    when 'blue'
      sprite='star_blue'
      add_particles(object, x, y, sprite, [1.00*(-15+rand(30))/10, 1.00*(-15+rand(30))/10], [0,0], [160,5+rand(15)], lock, 1)
    when 'red'
      sprite='star_red'
      add_particles(object, x, y, sprite, [1.00*(-15+rand(30))/10, 1.00*(-15+rand(30))/10], [0,0], [160,5+rand(15)], lock, 1)
    when 'green'
      sprite='star_green'
      add_particles(object, x, y, sprite, [1.00*(-15+rand(30))/10, 1.00*(-15+rand(30))/10], [0,0], [160,5+rand(15)], lock, 1)
    when 'yellow'
      sprite='star_yellow'
      add_particles(object, x, y, sprite, [1.00*(-15+rand(30))/10, 1.00*(-15+rand(30))/10], [0,0], [160,5+rand(15)], lock, 1)
    when 'smash'
      sprite='smash'
      add_particles(object, x, y, sprite, [1.00*(-15+rand(30))/10, 1.00*(-15+rand(30))/10], [0,0], [160,5+rand(15)], lock, 1)
    when 'fire'
      sprite='particle_yellow'
      add_particles(object, x, y, sprite, [(rand(7)-3)*0.2, 0], [0,0.15], [255,8+rand(5)], lock, 1)
    when 'fire2'
      sprite='particle_orange'
      add_particles(object, x, y, sprite, [(rand(7)-3)*0.2, 0], [0,0.15], [255,8+rand(5)], lock, 1)
    when 'sparks'
      sprite='particle_red'
      add_particles(object, x, y, sprite, [0.5*(-25+rand(50))/10, -4], [0,-0.5], [255,20], lock, 1)
    when 'smoke'
      sprite='smoke'
      add_particles(object, x, y, sprite, [0.1*(-25+rand(50))/10, 0], [0,0.13], [128,3], lock, 1)
    when 'cells'
      sprite='particle_red'
      dx = 1.00*(-100 + rand(200))/100
      dy = 1.00*(-100 + rand(200))/100
      add_particles(object, x, y, sprite, [5*dx, 5*dy], [0.3*dx,0.3*dy],
      [255,10], lock, 1)
      #sines
    when 'black'
      sprite='star_sine'
      add_particles(object, x, y, sprite, [(rand(7)-3)*0.2, 0], [0,0.15],
      [255,8+rand(5)], lock, 1)
      #sines
    when 'portal'
      sprite='portal'
      add_particles(object, x, y, sprite, [0,0.2], [0,0.1], [255,1+rand(10)], lock, 1)
    end
  end
  #--------------------------------------------------------------------------
  # * Public Instance Variables
  #--------------------------------------------------------------------------
  attr_reader :particles
  #--------------------------------------------------------------------------
  # * Alias Listings
  #--------------------------------------------------------------------------
  alias :particle_ssm_init :initialize
  alias :particle_ssm_update :update
  alias :particle_ssm_dispose :dispose
  #--------------------------------------------------------------------------
  # * Object Initialization
  #--------------------------------------------------------------------------
  def initialize
    @particles = []
    particle_ssm_init
  end
  #--------------------------------------------------------------------------
  # * Dispose
  #--------------------------------------------------------------------------
  def dispose
    @particles.each{ |d| d.dispose }
    particle_ssm_dispose
  end
  #--------------------------------------------------------------------------
  # * Frame Update
  #--------------------------------------------------------------------------
  def update
    @particles.each_with_index{ |p,i|
      @particles[i].update
      if p.opacity == 0
        p.dispose
        @particles.delete_at(i)
      end
      }
    particle_ssm_update
  end
  #--------------------------------------------------------------------------
  # * Add Particles
  #--------------------------------------------------------------------------
  def add_particles(object = $game_player, x = 0, y = 0, sprite = '',
    acc = [0,0], grav = [0,0], opacity = [255,0], lock = 'event', blend = 0)
    if !object.is_a?(NilClass)
      if lock == 'event'
        @particles << Particle_Event.new(@viewport1, object, x, y, sprite, acc,
          grav, opacity, blend)
      elsif lock == 'screen'
        @particles << Particle_Screen.new(@viewport1, object, x, y, sprite, acc,
          grav, opacity, blend)
      end
    end
  end
end

#===============================================================================​
# ** Particle_Screen
#===============================================================================​

class Particle_Screen < Sprite
  #--------------------------------------------------------------------------
  # * Object Initialization
  #--------------------------------------------------------------------------
  def initialize(viewport = Viewport.new(0,0,800,600), object = $game_player,
    x = 0, y = 0, sprite = '', acc = [0,0], grav = [0,0], opacity = [255,3],
    blend = 0)
    if !object.is_a?(NilClass)
      super(viewport)
      self.bitmap = Cache.picture('Particles/' + sprite)
      self.x = object.screen_x + x
      self.y = object.screen_y - 16 + y
      self.ox = self.oy = self.bitmap.width/2
      self.blend_type = blend
      self.opacity = opacity[0]
      @object = object
      @origin = [self.x, self.y]
      @acceleration = acc
      @gravity = grav
      @coords = [0.00, 0.00]
      @opacity = opacity[1]
      update
    end
  end
  #--------------------------------------------------------------------------
  # * Frame Update
  #--------------------------------------------------------------------------
  def update
    if !@object.is_a?(NilClass)
      @acceleration[0] -= @gravity[0] if @gravity[0] != 0
      @acceleration[1] -= @gravity[1] if @gravity[1] != 0
      @coords[0] += @acceleration[0]
      @coords[1] += @acceleration[1]
      self.opacity -= @opacity
      self.x = @origin[0] + @coords[0]
      self.y = @origin[1] + @coords[1]
      if self.y > (@object.screen_y - 16)
        self.z = @object.screen_z + 32
      else
        if @object == $game_map.airship; self.z = @object.screen_z + 120
        elsif @object.is_a?(Game_Follower); self.z = @object.screen_z + 1
        else
          self.z = @object.screen_z - 32
        end
      end
    end
  end
end

#===============================================================================​
# ** Particle_Event
#===============================================================================​

class Particle_Event < Sprite
  #--------------------------------------------------------------------------
  # * Object Initialization
  #--------------------------------------------------------------------------
  def initialize(viewport = Viewport.new(0,0,800,600), object = $game_player,
    x = 0, y = 0, sprite = '', acc = [0,0], grav = [0,0], opacity = [255,3],
    blend = 0)
    if !object.is_a?(NilClass)
      super(viewport)
      self.bitmap = Cache.picture('Particles/' + sprite)
      self.x = object.x*32 + 16 - $game_map.display_x * 32 + x
      self.y = object.y*32 + 32 - $game_map.display_y * 32 + y
      self.ox = self.oy = self.bitmap.width/2
      self.blend_type = blend
      self.opacity = opacity[0]
      @object = object
      @origin = [object.x*32 + x + 16, object.y*32 + y + 32]
      @acceleration = acc
      @gravity = grav
      @coords = [0.00, 0.00]
      @opacity = opacity[1]
      update
    end
  end
  #--------------------------------------------------------------------------
  # * Frame Update
  #--------------------------------------------------------------------------
  def update
    if !@object.is_a?(NilClass)
      @acceleration[0] -= @gravity[0] if @gravity[0] != 0
      @acceleration[1] -= @gravity[1] if @gravity[1] != 0
      @coords[0] += @acceleration[0]
      @coords[1] += @acceleration[1]
      self.opacity -= @opacity
      self.x = @origin[0] + @coords[0] - $game_map.display_x * 32
      self.y = @origin[1] + @coords[1] - $game_map.display_y * 32 - 16
      if self.y > (@object.screen_y - 16)
        self.z = @object.screen_z + 40
      else
        self.z = @object.screen_z - 40
      end
    end
  end
end

#==============================================================================
# ** Scene_Map
#------------------------------------------------------------------------------
#  This class performs the map screen processing.
#==============================================================================

class Scene_Map < Scene_Base
  #--------------------------------------------------------------------------
  # * Public Instance Variables
  #--------------------------------------------------------------------------
  attr_reader :spriteset
end

#==============================================================================
# ** Game_Interpreter
#------------------------------------------------------------------------------
#  An interpreter for executing event commands. This class is used within the
# Game_Map, Game_Troop, and Game_Event classes.
#==============================================================================

class Game_Interpreter
  #--------------------------------------------------------------------------
  # * Add effect
  #--------------------------------------------------------------------------
  def particle_effect(event=@event_id, effect='', lock='event', x=0, y=0)
    event, effect, x, y = Array(event), Array(effect), Array(x), Array(y)
    event.each{ |event_i| effect.each{ |effect_i| x.each{ |x_i| y.each{ |y_i|
      SceneManager.scene.spriteset.add_effect(event_i, effect_i, lock, x_i, y_i)
    } } } }
  end
end