#==============================================================================
# ■ VXAce-RGSS3-25 Strong and new game [Ver.1.1.0]          by Claimh
#------------------------------------------------------------------------------
# ・You can start from the beginning by taking over the data when clearing the game.
#------------------------------------------------------------------------------
#【引継ぎ対象】
# $game_temp          (Game_Temp)         : ×
# $game_system        (Game_System)       : ○
# $game_timer         (Game_Timer)        : ×
# $game_message       (Game_Message)      : ×
# $game_switches      (Game_Switches)     : ○
# $game_variables     (Game_Variables)    : ○
# $game_self_switches (Game_SelfSwitches) : ×
# $game_actors        (Game_Actors)       : ○
# $game_party         (Game_Party)        : ○
# $game_troop         (Game_Troop)        : ×
# $game_map           (Game_Map)          : ×
# $game_player        (Game_Player)       : ×
#------------------------------------------------------------------------------
#【Clear setting】
#   $game_system.game_clear
#【Acquired clear information】
#   $game_system.game_clear?
#【Acquisition of number of clearing】
#   $game_system.clrd.count
#------------------------------------------------------------------------------
# (Note) Set it to "true" if you do not introduce the item marked "○".
#==============================================================================

module Renewgame
  # Strong and SE at the time of loading the new game
  RENEW_SE = RPG::SE.new("Barrier")

  #---------------------------------------------------------------------------
  # ● System information (Game_System) takeover setting
  #---------------------------------------------------------------------------
  # Take over the number of battles
  RENEW_BATTLE_CNT = true

  # Take over the save count
  RENEW_SAVE_CNT = true

  # Take over the playing time
  RENEW_TIME = true

  # Take over the terminology dictionary information (required · terminology dictionary)
  RENEW_DICTIONAY = true

  # Take over quest information (required · quest system)
  RENEW_QUEST = true

  # Take over smith information (essential: blacksmith)
  RENEW_BLACKSMITH = true

  # Take over world map information (required: world map)
  RENEW_WORLDMAP = true

  # Take over field map information (required: field map)
  RENEW_FIELDMAP = true

  #---------------------------------------------------------------------------
  # ● Switch information (Game_Switches) takeover setting
  #---------------------------------------------------------------------------
  # Switch ID list to inherit
  RENEW_SW = [1, 10]

  #---------------------------------------------------------------------------
  # ● Variable information (Game_Variables) takeover setting
  #---------------------------------------------------------------------------
  # Variable ID list to take over
  RENEW_VAL = [1, 5]

  #---------------------------------------------------------------------------
  # ● Party information (Game_Party) takeover setting
  #---------------------------------------------------------------------------
  # It does not inherit anything (in the case of true, subsequent setting is unnecessary)
  PT_NOT_RENEW = false

  # Take over money
  RENEW_GOLD = true
  # To take over the number of steps
  RENEW_STEP = true

  # Take over items
  RENEW_ITEM = true
  # Item ID list not inherited
  NOT_RENEW_ITEMS = [5, 15]

  # Take over weapons
  RENEW_WEAPON = true
  # Weapon ID list not inherited
  NOT_RENEW_WEAPONS = [20, 25]

  # Take armor
  RENEW_ARMOR = true
  # Armor ID list not taken over
  NOT_RENEW_ARMORS  = [9, 23]

  # Take over Quest rank (required · quest system)
  RENEW_QUEST_RANK = true

  #---------------------------------------------------------------------------
  # ● Actor information (Game_Actor) takeover setting
  #    Initialize name, character, face graphic
  #---------------------------------------------------------------------------
  # It does not inherit anything (in the case of true, subsequent setting is unnecessary)
  ACT_NOT_RENEW = false

  # Initialize (do not take over anything) Actor ID list
  NOT_RENEW_ACTORS = [2]

  # Occupation handover
  RENEW_CLASS = true
  # Level (experience value) takeover
  RENEW_LV = true
  # Two name succession
  RENEW_NICKNAME = true

  # Skill inheritance
  RENEW_SKILL = true
  # Skill ID list that does not inherit
  NOT_RENEW_SKILLS = {
    # Actor ID => [Skill ID, ...],
    0 => [22],
    1 => [23]
  }

  # Transfer of ability value change
  RENEW_PARAM = true

  # Equipment transfer handover
  RENEW_EQUIP = true

  # Skill level of skill (required skill level system)
  RENEW_ATTR_LV = true

##############################################################################
  #--------------------------------------------------------------------------
  # ● data check
  #--------------------------------------------------------------------------
  def self.chk_include?(ary, id)
    return false if ary.nil?
    ary.include?(id)
  end
  #--------------------------------------------------------------------------
  # ● Actor skill handover determination
  #--------------------------------------------------------------------------
  def self.chk_skill(actor_id, skill_id)
    return true if chk_include?(NOT_RENEW_SKILLS[0], skill_id)
    return true if chk_include?(NOT_RENEW_SKILLS[actor_id], skill_id)
    false
  end
  #--------------------------------------------------------------------------
  # ● Item inheritance
  #--------------------------------------------------------------------------
  def self.lose_items
    flag = [RENEW_ITEM, RENEW_WEAPON, RENEW_ARMOR]
    ary  = [NOT_RENEW_ITEMS, NOT_RENEW_WEAPONS, NOT_RENEW_ARMORS]
    flag.each_index do |i|
      flag[i] ? lose_select_items(pitems(i), ary[i]) : $game_party.init_items(i)
    end
  end
  #--------------------------------------------------------------------------
  # ● party item
  #--------------------------------------------------------------------------
  def self.pitems(type)
    case type
    when 0; return $game_party.items
    when 1; return $game_party.weapons
    when 2; return $game_party.armors
    end
  end
  #--------------------------------------------------------------------------
  # ● Discard all extracted items
  #--------------------------------------------------------------------------
  def self.lose_select_items(items, ary)
    $game_party.lose_all_items(items.select {|item| ary.include?(item.id)}, true)
  end
end

#==============================================================================
# ■ Renewgame::ClearData    : Clear information class
#==============================================================================
class Renewgame::ClearData
  #--------------------------------------------------------------------------
  # ● Public instance variable
  #--------------------------------------------------------------------------
  attr_accessor :renew                 # Strong new game activation flag
  attr_reader   :clear                 # Cleared flag
  attr_reader   :count                 # Clear count
  attr_reader   :time                  # Clear time
  attr_reader   :lv_ave                # Average level
  attr_reader   :lv_max                # Max level
  #--------------------------------------------------------------------------
  # ● Object initialization
  #--------------------------------------------------------------------------
  def initialize
    @renew = false
    @clear = false
    @count = 0
    @time = [0]
    @lv_ave = [0]
    @lv_max = [0]
  end
  #--------------------------------------------------------------------------
  # ● Clear setting
  #--------------------------------------------------------------------------
  def game_clear
    @renew = true
    @clear = true
    @count += 1
    members = $game_party.members
    set_clear_time
    @time[@count] -= @time[@count-1] if Renewgame::RENEW_TIME
    @lv_ave[@count] = members.inject(0) {|r, a| r += a.level} / members.size
    @lv_max[@count] = $game_party.highest_level
  end
  #--------------------------------------------------------------------------
  # ● Clear time setting
  #--------------------------------------------------------------------------
  def set_clear_time
    @time[@count] = $game_system.playtime
  end
  #--------------------------------------------------------------------------
  # ● Total time spent before clearing
  #--------------------------------------------------------------------------
  def played_time
    return @time[@count] unless Renewgame::RENEW_TIME
    @count.inject(0) {|r, i| r += @time[i+1]}
  end
end


#==============================================================================
# ■ DataManager
#==============================================================================
class << DataManager
  #--------------------------------------------------------------------------
  # ● Create save header
  #--------------------------------------------------------------------------
  alias make_save_header_renew make_save_header
  def make_save_header
    header = make_save_header_renew
    header[:game_clear] = $game_system.game_clear?
    header[:regame] = $game_system.clrd.renew
    header
  end
end


#==============================================================================
# ■ Scene_Load
#==============================================================================
class Scene_Load < Scene_File
  #--------------------------------------------------------------------------
  # ● Start processing
  #--------------------------------------------------------------------------
  def start
    super
    create_renew_window
  end
  #--------------------------------------------------------------------------
  # ● Strong and new game activation window generation
  #--------------------------------------------------------------------------
  def create_renew_window
    @renew_window = Window_RenewGame.new
    @renew_window.set_handler(:renew_yes, method(:renew_yes))
    @renew_window.set_handler(:cancel,    method(:renew_no))
  end
  #--------------------------------------------------------------------------
  # ● Update save file selection
  #--------------------------------------------------------------------------
  def update_savefile_selection
    return if @renew_window.active
    super
  end
  #--------------------------------------------------------------------------
  # ● Determining Save File
  #--------------------------------------------------------------------------
  alias on_savefile_ok_renew on_savefile_ok
  def on_savefile_ok
    if renewgame?
      Sound.play_ok
      @renew_window.activate.open.index = 1
      @help_window.set_text("Would you like to inherit the data at the time of clearing and start a new game？")
    else
      on_savefile_ok_renew
    end
  end
  #--------------------------------------------------------------------------
  # ● Strong new game save data？
  #--------------------------------------------------------------------------
  def renewgame?
    header = DataManager.load_header(@index)
    return false unless header
    header[:regame]
  end
  #--------------------------------------------------------------------------
  # ● Strong processing at the time of a new game
  #--------------------------------------------------------------------------
  def renew_yes
    if DataManager.load_game(@index)
      on_renew_success
    else
      @help_window.set_text(help_window_text)
      Sound.play_buzzer
    end
    @renew_window.deactivate.close
  end
  #--------------------------------------------------------------------------
  # ● Processing at the time of strong and successful new game
  #--------------------------------------------------------------------------
  def on_renew_success
    Renewgame::RENEW_SE.play
    DataManager.renew_game
    $game_system.clrd.renew = false
    fadeout_all
    $game_map.autoplay
    SceneManager.goto(Scene_Map)
  end
  #--------------------------------------------------------------------------
  # ● Strong processing at the time of a new game
  #--------------------------------------------------------------------------
  def renew_no
    @renew_window.deactivate.close
    @help_window.set_text(help_window_text)
  end
end

#==============================================================================
# ■ Window_RenewGame
#==============================================================================
class Window_RenewGame < Window_Command
  #--------------------------------------------------------------------------
  # ● Object initialization
  #--------------------------------------------------------------------------
  def initialize
    super(0, 0)
    update_placement
    deactivate.openness = 0
  end
  #--------------------------------------------------------------------------
  # ● Obtain window width
  #--------------------------------------------------------------------------
  def window_width
    return 100
  end
  #--------------------------------------------------------------------------
  # ● Update window position
  #--------------------------------------------------------------------------
  def update_placement
    self.x = (Graphics.width - width) / 2
    self.y = (Graphics.height - height) / 2
  end
  #--------------------------------------------------------------------------
  # ● Create command list
  #--------------------------------------------------------------------------
  def make_command_list
    add_command("はい",   :renew_yes)
    add_command("いいえ", :cancel)
  end
end


module DataManager
  #--------------------------------------------------------------------------
  # ● Strong and new game
  #--------------------------------------------------------------------------
  def self.renew_game
    renew_game_data
    $game_party.setup_starting_members
    $game_map.setup($data_system.start_map_id)
    $game_player.moveto($data_system.start_x, $data_system.start_y)
    $game_player.refresh
  end
  #--------------------------------------------------------------------------
  # ● Strong and resetting various game objects at the time of new game
  #--------------------------------------------------------------------------
  def self.renew_game_data
    $game_temp          = Game_Temp.new
    renew_game_system
    $game_timer         = Game_Timer.new
    $game_message       = Game_Message.new
    renew_game_switches
    renew_game_variables
    $game_self_switches = Game_SelfSwitches.new
    Renewgame::ACT_NOT_RENEW ? init_game_actors : renew_game_actors
    Renewgame::PT_NOT_RENEW  ? init_game_party  : renew_game_party
    $game_troop         = Game_Troop.new
    $game_map           = Game_Map.new
    $game_player        = Game_Player.new
  end
  #--------------------------------------------------------------------------
  # ● Game_Switches Initialization
  #--------------------------------------------------------------------------
  def self.init_game_switches
    $game_switches      = Game_Switches.new
  end
  #--------------------------------------------------------------------------
  # ● Game_Variables Initialization
  #--------------------------------------------------------------------------
  def self.init_game_variables
    $game_variables     = Game_Variables.new
  end
  #--------------------------------------------------------------------------
  # ● Game_Actors Initialization
  #--------------------------------------------------------------------------
  def self.init_game_actors
    $game_actors        = Game_Actors.new
  end
  #--------------------------------------------------------------------------
  # ● Game_Party Initialization
  #--------------------------------------------------------------------------
  def self.init_game_party
    $game_party         = Game_Party.new
  end
  #--------------------------------------------------------------------------
  # ● Game_System Take over
  #--------------------------------------------------------------------------
  def self.renew_game_system
    $game_system.battle_count = 0 unless Renewgame::RENEW_BATTLE_CNT
    $game_system.save_count = 0   unless Renewgame::RENEW_SAVE_CNT
    $game_system.reset_playtime(Renewgame::RENEW_TIME)
    $game_system.clrd.set_clear_time  # セーブされていたplaytimeに補正
    $game_system.dictionary.reset unless Renewgame::RENEW_DICTIONAY
    $game_system.quest.reset      unless Renewgame::RENEW_QUEST
    $game_system.bs.reset_all     unless Renewgame::RENEW_BLACKSMITH
    $game_system.worldmap.reset   unless Renewgame::RENEW_WORLDMAP
    $game_system.init_fieldmap    unless Renewgame::RENEW_FIELDMAP
    #
    $game_system.reset
  end
  #--------------------------------------------------------------------------
  # ● Game_Switches Take over
  #--------------------------------------------------------------------------
  def self.renew_game_switches
    ids = $game_switches.on_sw_ids.select {|id| Renewgame::RENEW_SW.include?(id)}
    init_game_switches
    ids.each {|id| $game_switches[id] = true}
  end
  #--------------------------------------------------------------------------
  # ● Game_Variables Take over
  #--------------------------------------------------------------------------
  def self.renew_game_variables
    vals = {}
    Renewgame::RENEW_VAL.each {|id| vals[id] = $game_variables[id]}
    init_game_variables
    Renewgame::RENEW_VAL.each {|id| $game_variables[id] = vals[id]}
  end
  #--------------------------------------------------------------------------
  # ● Game_Actors Take over
  #--------------------------------------------------------------------------
  def self.renew_game_actors
    $game_actors.each {|a| renew_game_actor(a)}
  end
  #--------------------------------------------------------------------------
  # ● Game_Actor Take over
  #--------------------------------------------------------------------------
  def self.renew_game_actor(actor)
    if Renewgame::NOT_RENEW_ACTORS.include?(actor.id)
      actor.setup(actor.id)
      return
    end
    new_act = Game_Actor.new(actor.id)
    unless Renewgame::RENEW_SKILL
      actor.init_skills
    else
      skills = actor.skills.select {|skill| Renewgame.chk_skill(actor.id, skill.id)}
      skills.each {|skill| actor.forget_skill(skill.id)}
    end
    actor.init_lv_exp unless Renewgame::RENEW_LV
    actor.change_class(new_act.class_id) unless Renewgame::RENEW_CLASS
    actor.nickname = new_act.nickname    unless Renewgame::RENEW_NICKNAME
    actor.clear_param_plus unless Renewgame::RENEW_PARAM
    unless Renewgame::RENEW_EQUIP
      actor.clear_equipments
      actor.init_equips(actor.actor.equips)
    end
    actor.attr = ActorAttrList.new(actor.id) unless Renewgame::RENEW_ATTR_LV
    #
    actor.recover_all
  end
  #--------------------------------------------------------------------------
  # ● Game_Party Take over
  #--------------------------------------------------------------------------
  def self.renew_game_party
    $game_party.gold  = 0 unless Renewgame::RENEW_GOLD
    $game_party.steps = 0 unless Renewgame::RENEW_STEP
    Renewgame.lose_items
    $game_party.quest_rank = 1 unless Renewgame::RENEW_QUEST_RANK
  end
end


class Game_System
  #--------------------------------------------------------------------------
  # ● Public instance variable
  #--------------------------------------------------------------------------
  attr_writer   :save_count               # Number of saves
  attr_reader   :clrd                     # Clear information
  #--------------------------------------------------------------------------
  # ● Object initialization
  #--------------------------------------------------------------------------
  alias initialize_renew initialize
  def initialize
    initialize_renew
    @clrd = Renewgame::ClearData.new
  end
  #--------------------------------------------------------------------------
  # ● Clear setting
  #--------------------------------------------------------------------------
  def game_clear
    @clrd.game_clear
  end
  #--------------------------------------------------------------------------
  # ● Clear setting
  #--------------------------------------------------------------------------
  def game_clear?
    @clrd.clear
  end
  #--------------------------------------------------------------------------
  # ● Variable Reset
  #--------------------------------------------------------------------------
  def reset
    @save_disabled = false
    @menu_disabled = false
    @encounter_disabled = false
    @formation_disabled = false
    @window_tone = nil
    @battle_bgm = nil
    @battle_end_me = nil
    @saved_bgm = nil
  end
  #--------------------------------------------------------------------------
  # ● Reset play time
  #--------------------------------------------------------------------------
  def reset_playtime(load_reset=false)
    @frames_on_save = 0 unless load_reset
    Graphics.frame_count = @frames_on_save
  end
end

class Game_Switches
  #--------------------------------------------------------------------------
  # ● Obtain switch ID in ON state
  #--------------------------------------------------------------------------
  def on_sw_ids
    ids = []
    @data.each_index {|i| ids.push(i) if self.[](i) }
    ids
  end
end


class Game_Actors
  #--------------------------------------------------------------------------
  # ● Iterator
  #--------------------------------------------------------------------------
  def each
    @data.select {|a| !a.nil?}.each {|actor| yield actor } if block_given?
  end
end

class Game_Actor < Game_Battler
  #--------------------------------------------------------------------------
  # ● Level, Initialization of EXP
  #--------------------------------------------------------------------------
  def init_lv_exp
    @level = actor.initial_level
    @exp = {}
    init_exp
  end
end

class Game_Party < Game_Unit
  #--------------------------------------------------------------------------
  # ● Public instance variable
  #--------------------------------------------------------------------------
  attr_writer   :gold                     # Gold held
  attr_writer   :steps                    # Step count
  #--------------------------------------------------------------------------
  # ● Initialize item list
  #--------------------------------------------------------------------------
  def init_items(type)
    case type
    when 0; @items = {}
    when 1; @weapons = {}
    when 2; @armors = {}
    end
  end
  #--------------------------------------------------------------------------
  # ● Throw away all items
  #     include_equip : Include equipment as well
  #--------------------------------------------------------------------------
  def lose_all_item(item, include_equip = false)
    lose_item(item, max_item_number(item), include_equip)
  end
  #--------------------------------------------------------------------------
  # ● Throw away all item lists
  #     include_equip : Include equipment as well
  #--------------------------------------------------------------------------
  def lose_all_items(items, include_equip = false)
    items.each {|item| lose_all_item(item, include_equip)}
  end
end