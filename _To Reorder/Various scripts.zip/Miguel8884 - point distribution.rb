#===============================================================================
# ** GST Distribute Points System
# Author: miguel8884
#-------------------------------------------------------------------------------
# Release date of: 10/09/2014
# Version: 1.0
#-------------------------------------------------------------------------------
# Dependencies:
# * None
#-------------------------------------------------------------------------------
# Description:
#
# The script allows you to have a point distribution scene for everyone
# The heroes, where they could increase their attributes with points.
#-------------------------------------------------------------------------------
# characteristics:
# * Possibility of addition in the menu!
# * No lag!
# * All heroes can distribute points!
# * High configuration!
# * Easy addition of dots!
#-------------------------------------------------------------------------------
# Log:
# v1.0
#   10/09/2014 - Script released!
#-------------------------------------------------------------------------------
# - Calling the scene by events, adding and removing points -
# To call the scene by events, just use in the script call:
# call_distribute(id)
# In place of id place the hero id in the team, starting from 0 to 3
#
# To add points, just use in the script call:
# add_points(amount,actor)
# In place of amount, enter the amount you want to increase
# In place of actor put the id of the hero in the team, from 0 to 3
#
# To withdraw, use the same command, but in the amount put the negative number
# According to how much you want to take
#===============================================================================
module Distribute_Config
  #--------------------------------------------------------------------------
  # * Creating Variables - Do not Change
  #--------------------------------------------------------------------------
  Param_Conf = Hash.new
  Actor = Array.new
  #--------------------------------------------------------------------------
  # * Configuration - Color
  #--------------------------------------------------------------------------
  # Color Green on the text #
  Green_Color = Color.new(120,230,120)
  #--------------------------------------------------------------------------
  # * Configuration General
  #--------------------------------------------------------------------------
  # Put option in the menu #
  Put_On_Menu = true
  # Recover player after increasing hp or max mp? #
  Heal_Player = true
  # SE name if command is not able to execute #
  Wrong_Select = "buzzer1"
  # Points each hero starts with #
  Initial_Points = 36
  #--------------------------------------------------------------------------
  # * Vocabulary
  #--------------------------------------------------------------------------
  # Vocabulary for price #
  Price_Vocab = "Cost: "
  # Vocabulary of the top #
  Top_Vocab = "Distribute Points"
  # Vocabulary points
  Points_Vocab = "Points: "
  # Vocabulary in the menu
  Menu_Vocab = "Increase Stats"
  #--------------------------------------------------------------------------
  # * Settings - skills (Hero)
  #--------------------------------------------------------------------------
  #--------------------------------------------------------------------------
  # * Instruções 
  # \/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\
  # You set here the name and other price settings for each skill
  # Of the hero in question followed by the id of each one of them!
  #
  # The first thing we have is Actor[id] = [
  # Here we put in place of id the number of the player in the team, starting
  # From 0 and ending at 3 normally. In the script you will already have Actor
  # Configured in sequence, you can only edit one by one!
  #
  # Param_Conf[id] = { It's the next setup
  # Here we have to put the id of the parameter that we are going to use,
  # There are 8 parameters and the count starts from 0, so we will have until
  # parameter 7, following this sequence:
  # 0 = HP Max
  # 1 = MP Max
  # 2 = Attack
  # 3 = Defense
  # 4 = Attack Magic
  # 5 = Defense Magic
  # 6 = Agility
  # 7 = Luck
  #
  # Within Param Config we will have the settings of the current parameter, in case
  # Your id corresponding to the table above.
  # vocab: "vocabulary for the parameter",
  # icon: id parameter icon,
  # point_value: Added value in the parameter to each point spent,
  # point_price: Points spent on each confirmation,
  # inc_exp: add experience the hero in question to increase some
  # parameter if you do not want to put 0,
  # change_price_level: Level at which the hero in question should be
  # Points become more expensive or give more to each,
  # change_price_points: Added points that will be spent after the level is
  # Exceeded, that is, how much will it be,
  # change_price_value: after being made the threshold is exceeded as
  #  Hero gets more with every purchase,
  # des: parameter description,
  #
  # OBS: Never forget to put the comma at the end of all settings
  #
  # Example:
  #
  # Param_Conf[0] = {
  # vocab: "HP Max",
  # icon: 1,
  # point_value: 36,
  # point_price: 1,
  # inc_exp: 50,
  # change_price_level: 3,
  # change_price_points: 2,
  # change_price_value: 100,
  # des: "They say that a warrior with great life has more
  # Chances of surviving"
  # },
  #--------------------------------------------------------------------------
  Actor[0] = [
  Param_Conf[0] = {
  vocab: "HP Max",
  icon: 1,
  point_value: 36,
  point_price: 1,
  inc_exp: 50,
  change_price_level: 3,
  change_price_points: 2,
  change_price_value: 100,
  des: "They say that a warrior with great life has more chances of surviving"
  },
  Param_Conf[1] = {
  vocab: "MP Max",
  icon: 2,
  point_value: 4,
  point_price: 1,
  inc_exp: 50,
  change_price_level: 3,
  change_price_points: 2,
  change_price_value: 7,
  des: "A warrior without mana, can not get the most
High spells of a great magician"
  },
  Param_Conf[2] = {
  vocab: "Attack",
  icon: 3,
  point_value: 2,
  point_price: 1,
  inc_exp: 0,
  change_price_level: 3,
  change_price_points: 2,
  change_price_value: 7,
  des: "The stronger, more excelled"
  },
  Param_Conf[3] = {
  vocab: "Defense",
  icon: 4,
  point_value: 3,
  point_price: 1,
  inc_exp: 0,
  change_price_level: 3,
  change_price_points: 2,
  change_price_value: 7,
  des: "The attack is important, but someone with a catch so easy"
  },
  Param_Conf[4] = {
  vocab: "Magic Power",
  icon: 5,
  point_value: 1,
  point_price: 1,
  inc_exp: 0,
  change_price_level: 3,
  change_price_points: 2,
  change_price_value: 7,
  des: "The strength and magic are the best allies"
  },
  Param_Conf[5] = {
  vocab: "Magic Defense",
  icon: 6,
  point_value: 2,
  point_price: 1,
  inc_exp: 0,
  change_price_level: 3,
  change_price_points: 2,
  change_price_value: 7,
  des: "Use magic to protect yourself, just make wise that"
  },
  Param_Conf[6] = {
  vocab: "Agility",
  icon: 7,
  point_value: 4,
  point_price: 1,
  inc_exp: 0,
  change_price_level: 3,
  change_price_points: 2,
  change_price_value: 7,
  des: "How do they attack something they can not see?"
  },
  Param_Conf[7] = {
  vocab: "Luck",
  icon: 8,
  point_value: 7,
  point_price: 1,
  inc_exp: 0,
  change_price_level: 3,
  change_price_points: 2,
  change_price_value: 7,
  des: "If luck is on your side, everything will be easier."
  },
  ]
  #--------------------------------------------------------------------------
  # * Hero 2
  #--------------------------------------------------------------------------
  Actor[0] = [
  Param_Conf[0] = {
  vocab: "HP Max",
  icon: 1,
  point_value: 36,
  point_price: 1,
  inc_exp: 50,
  change_price_level: 3,
  change_price_points: 2,
  change_price_value: 100,
  des: "They say that a warrior with great life has more chances of surviving"
  },
  Param_Conf[1] = {
  vocab: "MP Max",
  icon: 2,
  point_value: 4,
  point_price: 1,
  inc_exp: 50,
  change_price_level: 3,
  change_price_points: 2,
  change_price_value: 7,
  des: "A warrior without mana, can not get the most
High spells of a great magician"
  },
  Param_Conf[2] = {
  vocab: "Attack",
  icon: 3,
  point_value: 2,
  point_price: 1,
  inc_exp: 0,
  change_price_level: 3,
  change_price_points: 2,
  change_price_value: 7,
  des: "The stronger, more excelled"
  },
  Param_Conf[3] = {
  vocab: "Defense",
  icon: 4,
  point_value: 3,
  point_price: 1,
  inc_exp: 0,
  change_price_level: 3,
  change_price_points: 2,
  change_price_value: 7,
  des: "The attack is important, but someone with a catch so easy"
  },
  Param_Conf[4] = {
  vocab: "Magic Power",
  icon: 5,
  point_value: 1,
  point_price: 1,
  inc_exp: 0,
  change_price_level: 3,
  change_price_points: 2,
  change_price_value: 7,
  des: "The strength and magic are the best allies"
  },
  Param_Conf[5] = {
  vocab: "Magic Defense",
  icon: 6,
  point_value: 2,
  point_price: 1,
  inc_exp: 0,
  change_price_level: 3,
  change_price_points: 2,
  change_price_value: 7,
  des: "Use magic to protect yourself, just make wise that"
  },
  Param_Conf[6] = {
  vocab: "Agility",
  icon: 7,
  point_value: 4,
  point_price: 1,
  inc_exp: 0,
  change_price_level: 3,
  change_price_points: 2,
  change_price_value: 7,
  des: "How do they attack something they can not see?"
  },
  Param_Conf[7] = {
  vocab: "Luck",
  icon: 8,
  point_value: 7,
  point_price: 1,
  inc_exp: 0,
  change_price_level: 3,
  change_price_points: 2,
  change_price_value: 7,
  des: "If luck is on your side, everything will be easier."
  },
  ]
  #--------------------------------------------------------------------------
  # * Hero 3
  #--------------------------------------------------------------------------
  Actor[0] = [
  Param_Conf[0] = {
  vocab: "HP Max",
  icon: 1,
  point_value: 36,
  point_price: 1,
  inc_exp: 50,
  change_price_level: 3,
  change_price_points: 2,
  change_price_value: 100,
  des: "They say that a warrior with great life has more chances of surviving"
  },
  Param_Conf[1] = {
  vocab: "MP Max",
  icon: 2,
  point_value: 4,
  point_price: 1,
  inc_exp: 50,
  change_price_level: 3,
  change_price_points: 2,
  change_price_value: 7,
  des: "A warrior without mana, can not get the most
High spells of a great magician"
  },
  Param_Conf[2] = {
  vocab: "Attack",
  icon: 3,
  point_value: 2,
  point_price: 1,
  inc_exp: 0,
  change_price_level: 3,
  change_price_points: 2,
  change_price_value: 7,
  des: "The stronger, more excelled"
  },
  Param_Conf[3] = {
  vocab: "Defense",
  icon: 4,
  point_value: 3,
  point_price: 1,
  inc_exp: 0,
  change_price_level: 3,
  change_price_points: 2,
  change_price_value: 7,
  des: "The attack is important, but someone with a catch so easy"
  },
  Param_Conf[4] = {
  vocab: "Magic Power",
  icon: 5,
  point_value: 1,
  point_price: 1,
  inc_exp: 0,
  change_price_level: 3,
  change_price_points: 2,
  change_price_value: 7,
  des: "The strength and magic are the best allies"
  },
  Param_Conf[5] = {
  vocab: "Magic Defense",
  icon: 6,
  point_value: 2,
  point_price: 1,
  inc_exp: 0,
  change_price_level: 3,
  change_price_points: 2,
  change_price_value: 7,
  des: "Use magic to protect yourself, just make wise that"
  },
  Param_Conf[6] = {
  vocab: "Agility",
  icon: 7,
  point_value: 4,
  point_price: 1,
  inc_exp: 0,
  change_price_level: 3,
  change_price_points: 2,
  change_price_value: 7,
  des: "How do they attack something they can not see?"
  },
  Param_Conf[7] = {
  vocab: "Luck",
  icon: 8,
  point_value: 7,
  point_price: 1,
  inc_exp: 0,
  change_price_level: 3,
  change_price_points: 2,
  change_price_value: 7,
  des: "If luck is on your side, everything will be easier."
  },
  ]
  #--------------------------------------------------------------------------
  # * Hero 4
  #--------------------------------------------------------------------------
  Actor[0] = [
  Param_Conf[0] = {
  vocab: "HP Max",
  icon: 1,
  point_value: 36,
  point_price: 1,
  inc_exp: 50,
  change_price_level: 3,
  change_price_points: 2,
  change_price_value: 100,
  des: "They say that a warrior with great life has more chances of surviving"
  },
  Param_Conf[1] = {
  vocab: "MP Max",
  icon: 2,
  point_value: 4,
  point_price: 1,
  inc_exp: 50,
  change_price_level: 3,
  change_price_points: 2,
  change_price_value: 7,
  des: "A warrior without mana, can not get the most
High spells of a great magician"
  },
  Param_Conf[2] = {
  vocab: "Attack",
  icon: 3,
  point_value: 2,
  point_price: 1,
  inc_exp: 0,
  change_price_level: 3,
  change_price_points: 2,
  change_price_value: 7,
  des: "The stronger, more excelled"
  },
  Param_Conf[3] = {
  vocab: "Defense",
  icon: 4,
  point_value: 3,
  point_price: 1,
  inc_exp: 0,
  change_price_level: 3,
  change_price_points: 2,
  change_price_value: 7,
  des: "The attack is important, but someone with a catch so easy"
  },
  Param_Conf[4] = {
  vocab: "Magic Power",
  icon: 5,
  point_value: 1,
  point_price: 1,
  inc_exp: 0,
  change_price_level: 3,
  change_price_points: 2,
  change_price_value: 7,
  des: "The strength and magic are the best allies"
  },
  Param_Conf[5] = {
  vocab: "Magic Defense",
  icon: 6,
  point_value: 2,
  point_price: 1,
  inc_exp: 0,
  change_price_level: 3,
  change_price_points: 2,
  change_price_value: 7,
  des: "Use magic to protect yourself, just make wise that"
  },
  Param_Conf[6] = {
  vocab: "Agility",
  icon: 7,
  point_value: 4,
  point_price: 1,
  inc_exp: 0,
  change_price_level: 3,
  change_price_points: 2,
  change_price_value: 7,
  des: "How do they attack something they can not see?"
  },
  Param_Conf[7] = {
  vocab: "Luck",
  icon: 8,
  point_value: 7,
  point_price: 1,
  inc_exp: 0,
  change_price_level: 3,
  change_price_points: 2,
  change_price_value: 7,
  des: "If luck is on your side, everything will be easier."
  },
  ]
  #--------------------------------------------------------------------------
  # * End of configurations
  #--------------------------------------------------------------------------
end

class Game_Interpreter
  #--------------------------------------------------------------------------
  # * Call distribution window
  #    actor   : Window character
  #--------------------------------------------------------------------------
  def call_distribute(actor)
    $gst_actor = actor
    SceneManager.call(Scene_Distribute)
  end
  #--------------------------------------------------------------------------
  # * Increase points
  #    actor   : character
  #    amount  : quantity
  #--------------------------------------------------------------------------
  def add_points(amount,actor)
    $game_party.members[actor].points += amount
  end
end

class Game_Actor < Game_Battler
  #--------------------------------------------------------------------------
  # * Public variable
  #--------------------------------------------------------------------------
  attr_accessor :points
  #--------------------------------------------------------------------------
  # * Alias
  #--------------------------------------------------------------------------
  alias gst_actor_dist_ini initialize
  #--------------------------------------------------------------------------
  # * Initialization of the object
  #     actor_id : ID of Hero
  #--------------------------------------------------------------------------
  def initialize(actor_id)
    gst_actor_dist_ini(actor_id)
    @points = Distribute_Config::Initial_Points
  end
end

class Window_DistDescription < Window_Base
  #--------------------------------------------------------------------------
  # * Public variable
  #--------------------------------------------------------------------------
  attr_accessor :id
  #--------------------------------------------------------------------------
  # * Initialization of the object
  #     x      : coordinate X
  #     y      : coordinate Y
  #     width  : Window width
  #     height : Window height
  #--------------------------------------------------------------------------
  def initialize(x,y,width,height)
    super(x,y,width,height)
    @id = 0
    set_text
  end
  #--------------------------------------------------------------------------
  # * Make text
  #--------------------------------------------------------------------------
  def set_text
    self.contents.clear
    draw_text_ex(0,0,Distribute_Config::Param_Conf[@id][:des])
  end
end

class Window_DistParams < Window_Selectable
  #--------------------------------------------------------------------------
  # * Initialization of the object
  #     x      : coordinate X
  #     y      : coordinate Y
  #     width  : largura da janela
  #--------------------------------------------------------------------------
  def initialize(x,y,height)
    super(x,y,window_width,height)
    refresh
  end
  #--------------------------------------------------------------------------
  # * Acquiring window width
  #--------------------------------------------------------------------------
  def window_width
    Graphics.width
  end
  #--------------------------------------------------------------------------
  # * Acquisition of the maximum number of items
  #--------------------------------------------------------------------------
  def item_max
    return 8
  end
  #--------------------------------------------------------------------------
  # * Item Height Acquisition
  #--------------------------------------------------------------------------
  def item_height
    return 24
  end
  #--------------------------------------------------------------------------
  # * Drawing an item
  #     index : index of item
  #--------------------------------------------------------------------------
  def draw_item(index)
    case index
    when 0
      paramw = Distribute_Config::Actor[$gst_actor][0]
      param_id = 0
    when 1
      paramw = Distribute_Config::Actor[$gst_actor][1]
      param_id = 1
    when 2
      paramw = Distribute_Config::Actor[$gst_actor][2]
      param_id = 2
    when 3
      paramw = Distribute_Config::Actor[$gst_actor][3]
      param_id = 3
    when 4
      paramw = Distribute_Config::Actor[$gst_actor][4]
      param_id = 4
    when 5
      paramw = Distribute_Config::Actor[$gst_actor][5]
      param_id = 5
    when 6
      paramw = Distribute_Config::Actor[$gst_actor][6]
      param_id = 6
    when 7
      paramw = Distribute_Config::Actor[$gst_actor][7]
      param_id = 7
    end
    if $game_party.members[$gst_actor].level >= paramw[:change_price_level]
      draw_icon(paramw[:icon],5,index*24)
      draw_text(29,index*24,Graphics.width-200,24,paramw[:vocab])
      draw_text(200,index*24,140,24,$game_party.members[$gst_actor].param(param_id))
      draw_text(390,index*24,140,24,"#{Distribute_Config::Price_Vocab}#{paramw[:point_price] + paramw[:change_price_points]}")
      change_color(Distribute_Config::Green_Color)
      draw_text(300,index*24,140,24,$game_party.members[$gst_actor].param(param_id) + paramw[:point_value] + paramw[:change_price_value])
      draw_right_arrow(250,index*24)
      change_color(normal_color)
    else
      draw_icon(paramw[:icon],5,index*24)
      draw_text(29,index*24,Graphics.width-200,24,paramw[:vocab])
      draw_text(200,index*24,140,24,$game_party.members[$gst_actor].param(param_id))
      draw_text(390,index*24,140,24,"#{Distribute_Config::Price_Vocab}#{paramw[:point_price]}")
      change_color(Distribute_Config::Green_Color)
      draw_text(300,index*24,140,24,$game_party.members[$gst_actor].param(param_id) + paramw[:point_value])
      draw_right_arrow(250,index*24)
      change_color(normal_color)
    end
  end
  #--------------------------------------------------------------------------
  # * Desenho de flecha
  #     x    : coordinate X
  #     y    : coordinate Y
  #--------------------------------------------------------------------------
  def draw_right_arrow(x, y)
    change_color(system_color)
    draw_text(x, y, 22, line_height, "→", 1)
  end
  #--------------------------------------------------------------------------
  # * Return to previous selection
  #--------------------------------------------------------------------------
  def select_last
    select(index)
  end
end

class Window_DistStatus < Window_Base
  #--------------------------------------------------------------------------
  # * Initialization of the object
  #--------------------------------------------------------------------------
  def initialize
    super(0,fitting_height(1),Graphics.width-200,fitting_height(1))
    @actor = $game_party.members[$gst_actor]
    refresh
  end
  #--------------------------------------------------------------------------
  # * Renew content
  #--------------------------------------------------------------------------
  def refresh
    self.contents.clear
    draw_actor_hp(@actor,0,0)
    draw_actor_mp(@actor,150,0)
  end
end

class Window_DistTop < Window_Base
  #--------------------------------------------------------------------------
  # * Initialization of the object
  #--------------------------------------------------------------------------
  def initialize
    super(0,0,Graphics.width,fitting_height(1))
    refresh
  end
  #--------------------------------------------------------------------------
  # * Renew content
  #--------------------------------------------------------------------------
  def refresh
    draw_text(-10,0,Graphics.width,24,Distribute_Config::Top_Vocab,1)
  end
end

class Window_DistPoints < Window_Base
  #--------------------------------------------------------------------------
  # * Public variable
  #--------------------------------------------------------------------------
  attr_accessor :actor
  #--------------------------------------------------------------------------
  # * Initialization of the object
  #     x      : coordinate X
  #     y      : coordinate Y
  #     width  : Window Width
  #     height : Window Height
  #--------------------------------------------------------------------------
  def initialize(x,y,width,height)
    super(x,y,width,height)
    @actor = $game_party.members[$gst_actor]
    refresh
  end
  #--------------------------------------------------------------------------
  # * Renew content
  #--------------------------------------------------------------------------
  def refresh
    self.contents.clear
    draw_text(0,0,self.width,24,"#{Distribute_Config::Points_Vocab}#{@actor.points}")
  end
end

class Scene_Distribute < Scene_Base
  #--------------------------------------------------------------------------
  # * Initialization of the process
  #--------------------------------------------------------------------------
  def start
    super
    @switch = false
    create_background
    create_status_window
    create_points_window
    create_top_window
    create_param_list
    create_description_window
  end
  #--------------------------------------------------------------------------
  # * Screen refresh
  #--------------------------------------------------------------------------
  def update
    super
    @des_window.id = @param_window.index
    @des_window.set_text
  end
  #--------------------------------------------------------------------------
  # * Completion of the process
  #--------------------------------------------------------------------------
  def terminate
    super
    dispose_background
    dispose_all_windows
  end
  #--------------------------------------------------------------------------
  # * Create hero data window
  #--------------------------------------------------------------------------
  def create_status_window
    @status_window = Window_DistStatus.new
  end
  #--------------------------------------------------------------------------
  # * Create Top Window
  #--------------------------------------------------------------------------
  def create_top_window
    @top_window = Window_DistTop.new
  end
  #--------------------------------------------------------------------------
  # * Create Points Window
  #--------------------------------------------------------------------------
  def create_points_window
    wx = @status_window.width
    wy = @status_window.y
    wh = @status_window.height
    ww = Graphics.width - @status_window.width
    @points_window = Window_DistPoints.new(wx,wy,ww,wh)
  end
  #--------------------------------------------------------------------------
  # * Create Hero Parameters List Window
  #--------------------------------------------------------------------------
  def create_param_list
    wx = 0
    wy = @points_window.y + @points_window.height
    wh = Graphics.height - @points_window.height - @top_window.height - 96
    @param_window = Window_DistParams.new(wx,wy,wh)
    @param_window.set_handler(:ok,method(:on_increase_ok))
    @param_window.set_handler(:cancel,method(:on_cancel))
    @param_window.activate
    @param_window.select(0)
  end
  #--------------------------------------------------------------------------
  # * Create description window
  #--------------------------------------------------------------------------
  def create_description_window
    wx = 0
    wy = @param_window.height + 96
    ww = Graphics.width
    wh = Graphics.height - @param_window.height - 96
    @des_window = Window_DistDescription.new(wx,wy,ww,wh)
  end
  #--------------------------------------------------------------------------
  # * By confirming in the list
  #--------------------------------------------------------------------------
  def on_increase_ok
    case @param_window.index
    when 0
      paramw = Distribute_Config::Actor[$gst_actor][0]
      param_id = 0
    when 1
      paramw = Distribute_Config::Actor[$gst_actor][1]
      param_id = 1
    when 2
      paramw = Distribute_Config::Actor[$gst_actor][2]
      param_id = 2
    when 3
      paramw = Distribute_Config::Actor[$gst_actor][3]
      param_id = 3
    when 4
      paramw = Distribute_Config::Actor[$gst_actor][4]
      param_id = 4
    when 5
      paramw = Distribute_Config::Actor[$gst_actor][5]
      param_id = 5
    when 6
      paramw = Distribute_Config::Actor[$gst_actor][6]
      param_id = 6
    when 7
      paramw = Distribute_Config::Actor[$gst_actor][7]
      param_id = 7
    end
    if $game_party.members[$gst_actor].level >= paramw[:change_price_level]
      @param_window.refresh
      if $game_party.members[$gst_actor].points >= paramw[:point_price] + paramw[:change_price_points]
        $game_party.members[$gst_actor].points -= paramw[:point_price] + paramw[:change_price_points]
        $game_party.members[$gst_actor].add_param(param_id,paramw[:point_value] + paramw[:change_price_value])
        $game_party.members[$gst_actor].gain_exp(paramw[:inc_exp])
        if Distribute_Config::Heal_Player
          $game_party.members[$gst_actor].hp = $game_party.members[$gst_actor].mhp
          $game_party.members[$gst_actor].mp = $game_party.members[$gst_actor].mmp
        end
        @param_window.activate
        @param_window.select_last
      else
        RPG::SE.new(Distribute_Config::Wrong_Select,80).play
        @param_window.activate
        @param_window.select_last
      end
    else
      if $game_party.members[$gst_actor].points >= paramw[:point_price]
        $game_party.members[$gst_actor].points -= paramw[:point_price]
        $game_party.members[$gst_actor].add_param(param_id,paramw[:point_value])
        $game_party.members[$gst_actor].gain_exp(paramw[:inc_exp])
        if Distribute_Config::Heal_Player
          $game_party.members[$gst_actor].hp = $game_party.members[$gst_actor].mhp
          $game_party.members[$gst_actor].mp = $game_party.members[$gst_actor].mmp
        end
        @param_window.activate
        @param_window.select_last
      else
        RPG::SE.new(Distribute_Config::Wrong_Select,80).play
        @param_window.activate
        @param_window.select_last
      end
    end
    refresh_all_window
  end
  #--------------------------------------------------------------------------
  # * When connecting to the list
  #--------------------------------------------------------------------------
  def on_cancel
    return_scene
  end
  #--------------------------------------------------------------------------
  # * Delete all windows
  #--------------------------------------------------------------------------
  def dispose_all_windows
    @status_window.dispose
    @points_window.dispose
    @top_window.dispose
    @param_window.dispose
    @des_window.dispose
  end
  #--------------------------------------------------------------------------
  # * Renew all windows
  #--------------------------------------------------------------------------
  def refresh_all_window
    @status_window.refresh
    @points_window.refresh
    @param_window.redraw_current_item
  end
  #--------------------------------------------------------------------------
  # * Creation of Background
  #--------------------------------------------------------------------------
  def create_background
    @background_sprite = Sprite.new
    @background_sprite.bitmap = SceneManager.background_bitmap
    @background_sprite.color.set(16, 16, 16, 128)
  end
  #--------------------------------------------------------------------------
  # * Delete background
  #--------------------------------------------------------------------------
  def dispose_background
    @background_sprite.dispose
  end
end

class Window_MenuCommand < Window_Command
  #--------------------------------------------------------------------------
  # * Make Command List
  #--------------------------------------------------------------------------
  def make_command_list
    add_main_commands
    if Distribute_Config::Put_On_Menu
      add_dist_command
    end
    add_formation_command
    add_original_commands
    add_save_command
    add_game_end_command
  end
  #--------------------------------------------------------------------------
  # * Add Distribute Command
  #--------------------------------------------------------------------------
  def add_dist_command
    add_command(Distribute_Config::Menu_Vocab, :dist)
  end
end

class Scene_Menu < Scene_MenuBase
  #--------------------------------------------------------------------------
  # * Create Command Window
  #--------------------------------------------------------------------------
  def create_command_window
    @command_window = Window_MenuCommand.new
    @command_window.set_handler(:item,      method(:command_item))
    @command_window.set_handler(:skill,     method(:command_personal))
    @command_window.set_handler(:equip,     method(:command_personal))
    if Distribute_Config::Put_On_Menu
      @command_window.set_handler(:dist,    method(:command_personal))
    end
    @command_window.set_handler(:status,    method(:command_personal))
    @command_window.set_handler(:formation, method(:command_formation))
    @command_window.set_handler(:save,      method(:command_save))
    @command_window.set_handler(:game_end,  method(:command_game_end))
    @command_window.set_handler(:cancel,    method(:return_scene))
  end
  #--------------------------------------------------------------------------
  # * Individual Commands [Confirmation]
  #--------------------------------------------------------------------------
  def on_personal_ok
    case @command_window.current_symbol
    when :skill
      SceneManager.call(Scene_Skill)
    when :equip
      SceneManager.call(Scene_Equip)
    when :status
      SceneManager.call(Scene_Status)
    when :dist
      SceneManager.call(Scene_Distribute)
      $gst_actor = @status_window.index
    end
  end
end
#===============================================================================
# End of script
#===============================================================================