#-----------------------------------------------------------------------------
# Credits to Greedski
# 
#
# Version 1.01
#
# Script calls: 
#
# Hide the clock          =  SceneManager.scene.hide_clock 
# Show the clock          =  SceneManager.scene.show_clock
# Pass the time           =  $tiem.pass(hours)
# Set the time to         =  $tiem.set(hours, minutes)
# Set time progression    =  $tiem.set_progression(frames) set to 0 to stop
# Stop and tint dark      =  $tone.set_tone(red, green, blue, gray, duration)
# Start tone change       =  $tone.start_tone_change
#
WINDOWX = 450 # X Position of the clock in the map
WINDOWY = 0  # Y Position of the clock in the map
WINDOWXi = 0 # X Position of the clock in the menu
WINDOWYi = 328 # Y Position of the clock in the menu
MENUCLOCK = true # Clock in the menu
REGULARCLOCK = true # Clock in the map
#-----------------------------------------------------------------------------
# Time 
#-----------------------------------------------------------------------------
class Time
  def start # This is where the time starts
    $frames = 0
    $minute = 30
    $hour = 6
    @framers = 30
  end
  def set_progression(frames)
    @framers = frames
  end
  def update # Update the time each frame
      if @framers != 0
        $frames += 1
        if $frames >= @framers
          $minute += 5
          $frames -= @framers
        end
      end
         if $minute >= 60
           $hour += 1
           $minute -= 60
         end
         if $hour >= 24
           $hour -=24
         end
       end
  def pass(tiem) # This is used to advance some time
    $hour += tiem
  end
  def set(hour = $hour, minute = $minute)
    $hour = hour
    $minute = minute
    $frames = 0
  end
end
#----------------------------------------------------------------------------
# Screen Tone
#----------------------------------------------------------------------------
class TimeTint
  def tint
    if !$game_switches[100]
      case $hour
      when 0
        tone = Tone.new(-120, -120, -120, 60)
        duration = 30
      when 1
        tone = Tone.new(-100, -100, -100, 50)
        duration = 30
      when 2
        tone = Tone.new(-80, -80, -80, 40)
        duration = 30
      when 3
        tone = Tone.new(-60, -60, -60, 30)
        duration = 30
      when 4
        tone = Tone.new(-40, -40, -40, 20)
        duration = 30
      when 5
        tone = Tone.new(-20, -20, -20, 10)
        duration = 30
      when 6..18
        tone = Tone.new(0, 0, 0, 0)
        duration = 30
      when 18
        tone = Tone.new(-20, -20, -20, 10)
        duration = 30
      when 19
        tone = Tone.new(-40, -40, -40, 20)
        duration = 30
      when 20
        tone = Tone.new(-60, -60, -60, 30)
        duration = 30
      when 21
        tone = Tone.new(-80, -80, -80, 40)
        duration = 30
      when 22
        tone = Tone.new(-100, -100, -100, 50)
        duration = 30
      when 23
        tone = Tone.new(-120, -120, -120, 60)
        duration = 30
      end
      $game_map.screen.start_tone_change(tone, duration)
    end
  end
  def stop_tone_change
      $game_switches[100] = true
      $game_map.screen.start_tone_change(tone, duration)
    end
    def set_tone(red = 0, green = 0, blue = 0, gray = 0, duration = 30)
      $game_switches[100] = true
      tone = Tone.new(red, green, blue, gray)
      duration = duration
      $game_map.screen.start_tone_change(tone, duration)
    end
    def start_tone_change
      $game_switches[100] = false
      duration = 0
    end
end
#------------------------------------------------------------------------------
# Clock 
#------------------------------------------------------------------------------
class Clock < Window_Base
  def initialize(x, y)
		super(x, y, 96, 40)
		self.contents.font.bold = false
		self.contents.font.size = 22
		self.contents.font.outline = false
		self.contents.font.shadow = true
		self.contents.font.color = normal_color
	end
  
  def update # This will update the clock
    self.contents.clear
		wid     = contents.width 
		hei     = 64
    
    if $minute > 0
      if $minute < 10
        if $hour <= 9
          text = "0" + $hour.to_s + ":" + "0" + $minute.to_s
        else 
          text = $hour.to_s + ":" + "0" + $minute.to_s
        end
      else
        if $hour <= 9
          text = "0" + $hour.to_s + ":" + $minute.to_s
        else 
          text = $hour.to_s + ":" + $minute.to_s
        end                                                                              
      end
    else
      if $hour <= 9
        text = "0" + $hour.to_s + ":00"
      else 
        text = $hour.to_s + ":00"
      end                 
    end
    self.contents.font.color = Color.new(255, 255, 255)
		self.contents.draw_text( 0, -24, wid, hei, text, 1)
  end  
end
#-----------------------------------------------------------------------------
# Scene Manager
#-----------------------------------------------------------------------------
if MENUCLOCK
  class Scene_Menu < Scene_MenuBase
    def clock_start
      @clockmenu = Clock.new(WINDOWXi, WINDOWYi)
    end
    alias :clock_start :start
    def start
      clock_start
      @clockmenu = Clock.new(WINDOWXi, WINDOWYi)
    end
  end
end
if REGULARCLOCK
  class Scene_Map < Scene_Base
    def update_clock
      @clock.update
    end
    alias :update_clock :update
    def update
      update_clock
      @clock.update
    end
    def create_time_clock
      create_clock_window
    end
    alias :create_time_clock :create_all_windows
    def create_all_windows
      create_time_clock
      create_clock_window
    end
    #---------------------------------------------------------------------------
    # * Create Clock
    #---------------------------------------------------------------------------
    def create_clock_window
      @clock = Clock.new(WINDOWX, WINDOWY)
    end
    #--------------------------------------------------------------------------
    # * Hide Clock
    #--------------------------------------------------------------------------
    def hide_clock
      @clock.hide
    end
    #--------------------------------------------------------------------------
    # * Show Clock
    #--------------------------------------------------------------------------
    def show_clock
      @clock.show
    end
  end
end
class Scene_Map < Scene_Base
  #--------------------------------------------------------------------------
  # * Frame Update
  #--------------------------------------------------------------------------
  def update_time
    $tiem.update # UPDATE TIME
    $tone.tint
  end
  alias :update_time :update
  def update
    update_time
    $tiem.update # UPDATE TIME
    $tone.tint
  end
end

#---------------------------------------------------------------------------
# Scene start
#---------------------------------------------------------------------------

class Scene_Title < Scene_Base
  def time_new_game
    StartTime.setup_time
  end
  alias :time_new_game :command_new_game
  def command_new_game
    time_new_game
    StartTime.setup_time
  end
end
#---------------------------------------------------------------------------
# Module to create and start time
#---------------------------------------------------------------------------
module StartTime
  #---------------------------------------------------------------------------
  # * Creating Time var
  #---------------------------------------------------------------------------
  def self.create_time
    $tiem = Time.new
    $tone = TimeTint.new
  end
  #---------------------------------------------------------------------------
  # * Starting variables
  #---------------------------------------------------------------------------
  def self.setup_time
    create_time
    $tiem.start
  end
end