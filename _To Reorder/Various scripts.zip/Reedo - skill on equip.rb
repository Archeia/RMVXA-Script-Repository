###############################################################################
##  Skill-On-Equip Lite
##  Version 1.0
##  November 29, 2009
##  By Reedo
###############################################################################
##  SOURCE
##
##  http://www.rpgmakervx.net/index.php?showtopic=23261
###############################################################################
##  REFERENCES
##
##  None.  This is an original script by Reedo.
###############################################################################
##  DESCRIPTION
##
##  This script allows you to specify one or more skills to be learned when
##  a character equips a certain weapon or armor.  When the player equips
##  a registered weapon or armor onto a character, that character immediately
##  gains the skill (or skills) associated with the weapon or armor.  As
##  soon as the weapon or armor is unequipped, the skill is removed from the
##  character.
##
##  This is the "Lite" version of the script and the item/skill registrations
##  in the script are permanent.  I will release a "Pro" version where they
##  registrations are variable, and Controllable.
###############################################################################
##  COMPATIBILITY
##
##  Should be compatible with any other scripts.
###############################################################################
##  REQUIREMENTS
##
##  None.  This is a very simple script.
###############################################################################
##  INSTALLATION
##
##  Plug-and-play.
##  Insert below Materials, or other Reedo scripts.
###############################################################################
##  RIGHTS & RESTRICTIONS
##
##  As with most Reedo scripts, this script is free to re-use, as-is, 
##  in personal, educational, and commercial RPGVX development projects, 
##  providing that:  this script, as well as the rpgmakervx.net forum link  
##  from which it was obtained, are credited in writing displayed readily 
##  to the user of the final compiled code assembly.
##
##  Reedo and rgpmakervx.net retain all rights of intellect and ownership.
##  You forego all rights of warranty by utilizing this script.
###############################################################################
##  USAGE
##
##  Register weapons to give skills using the WEAPON_SKILLS hash.  The first
##  value is the weapon ID, the second is the skill ID to learn.  To learn
##  multiple skills, specify an array of skill IDs instead of a single ID.
##
##  Register armors to give skills using the ARMOR_SKILLS hash.  The first
##  value is the armor ID, the second is the skill ID to learn.  To learn
##  multiple skills, specify an array of skill IDs instead of a single ID.
###############################################################################

###############################################################################
##  USER OPTIONS
###############################################################################
module SKILL_ON_EQUIP
  # This example makes the Long Sword (ID 2) give the skill Double Attack (ID 2)
   WEAPON_SKILLS = {50 => 7}
  # This makes the Leather Breastplate (ID 14) give the skill Body Attack (ID 28)
   ARMOR_SKILLS = {89 => 39}
  #
  # Example of multiple item/skill pairs and items with multiple skill effects:
  # 
  #   WEAPON_SKILLS = {2 => 2, 10 => [30, 32], 3 => [7, 9, 12]}
end
###############################################################################
##  MAIN SCRIPT
###############################################################################
##  EDITS BEYOND THIS POINT ARE AT YOUR OWN RISK!!!
###############################################################################
class Game_Actor
  alias reedo_soe_ga_setup setup
  def setup(actor_id)
    reedo_soe_ga_setup(actor_id)
    addskill = 0
    addskill = @weapon_id if SKILL_ON_EQUIP::WEAPON_SKILLS.has_key?(@weapon_id)
    addskill = @armor1_id if SKILL_ON_EQUIP::WEAPON_SKILLS.has_key?(@armor1_id) if two_swords_style
    if addskill > 0
      learn_skill(SKILL_ON_EQUIP::WEAPON_SKILLS[addskill])
    end
    addskill = 0
    addskill = @armor1_id if SKILL_ON_EQUIP::ARMOR_SKILLS.has_key?(@armor1_id) if !two_swords_style
    if addskill > 0
      learn_skill(SKILL_ON_EQUIP::ARMOR_SKILLS[addskill])
    end
    addskill = 0
    addskill = @armor2_id if SKILL_ON_EQUIP::ARMOR_SKILLS.has_key?(@armor2_id)
    if addskill > 0
      learn_skill(SKILL_ON_EQUIP::ARMOR_SKILLS[addskill])
    end
    addskill = 0
    addskill = @armor3_id if SKILL_ON_EQUIP::ARMOR_SKILLS.has_key?(@armor3_id)
    if addskill > 0
      learn_skill(SKILL_ON_EQUIP::ARMOR_SKILLS[addskill])
    end
    addskill = 0
    addskill = @armor4_id if SKILL_ON_EQUIP::ARMOR_SKILLS.has_key?(@armor4_id)
    if addskill > 0
      learn_skill(SKILL_ON_EQUIP::ARMOR_SKILLS[addskill])
    end
  end
  
  alias reedo_soe_ga_change_equip change_equip
  def change_equip(equip_type, item, test = false)
    cur_item = equips[equip_type]
    reedo_soe_ga_change_equip(equip_type, item, test)
    return if test
    skill = nil
    list = nil
    if equip_type == 0 or (equip_type == 1 and two_swords_style)
      skill = SKILL_ON_EQUIP::WEAPON_SKILLS[cur_item.id]
      list = SKILL_ON_EQUIP::WEAPON_SKILLS
    else
      skill = SKILL_ON_EQUIP::ARMOR_SKILLS[cur_item.id]
      list = SKILL_ON_EQUIP::ARMOR_SKILLS
    end
    if skill != nil
      if skill.is_a?(Array)
        skill.each do |i|
          forget_skill(i)
        end
      elsif skill.is_a?(Fixnum)
        forget_skill(skill) 
      end
    end
    item_id = item == nil ? 0 : item.id
    list.each do |w, s|
      if item_id == w
        if s.is_a?(Array)
          s.each do |i|
            learn_skill(i)
          end
        elsif s.is_a?(Fixnum)
          learn_skill(s)
        end
        break
      end
    end
  end
end