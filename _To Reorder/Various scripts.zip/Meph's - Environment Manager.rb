#==============================================================================
# ** Meph's Environment Manager
#------------------------------------------------------------------------------
# MephistoX (Meph's Labs)
# Version 1.0b
# 22/02/2012
# RPGMaker VXAce
#------------------------------------------------------------------------------
# * Version History :
#
#   Version 1 ---------------------------------------------------- (22/02/2012)
#                           
#------------------------------------------------------------------------------
# * Description :
#
#   As a spin-off of my Grab & Throw, this script allows you to create dinamic
#   objects in the map, as pushable, pullable, throwable and others 'ables.
#   Easily to create and configure them, this would help to reduce the work
#   of the eventers and engineers to make fast puzzles and give the game
#   more life as much as poekmon does.
#
#   But not stopping above, these system also add new player skills like
#   jump, swim, float, and others.
#
#------------------------------------------------------------------------------
# * List of Actions and Object Environments :
#
#   - Grab & Throw
#   - Swimming for Player and Events
#
#------------------------------------------------------------------------------
# * Instructions :
#
#   Place The Script in the Materiales Section of your Script List
#------------------------------------------------------------------------------
# * Syntax :
#
#   The basic for all, is that you have to create a comment in the event and   
#   put:
#        - ENV::LST => []
#   And in the array, add the different symbols to create an object type.
#
#     =========================== GRAB & THROW ============================
#
#   Symbol => :throw
#
#   To Grab an Object use:
#    - <character>.grab_character(id)
#        - Reeplace character for 0 to $game_player or id to event
#
#        - Reeplace id for the id of the character to be carried.
#          is recomendable not to use with player. by that i mean, a event
#          carrying the player, not tested, but must work anyways.
#
#   To put a character away:
#    - <character>.throw_character
#      - Reeplace character as above
#
#
#   To Configure the throw options create a new comment in the event and put:
#     - Comment: ENV::CFG => [A, B, C, D, E]
#                            from c to F are optional, if you configure c,
#    Reeplace                you must configure D, E & F
#    A => Max distance of throw, the system will check the max distance
#         of throw based on this number. (integer)
#    B => Break Probabilty: integer of the probability of break the event
#    C => Break Sound : Sound when break
#    D => Break Animation: Animation when break (can be nil)
#    E => Local Switch when break
#
#    To defined a pickup graphic just create a new graphic with the original
#    character name + the suffix '_Pickup' if no character graphic found
#    it wont be changed.
#
#    When you are in water you can throw objects aswell, but only to the water
#    you must return to land to throw objects in land again.
#
#
#      =========================== SWIMMING ============================
#
#    More than configure the Swim Input button, you can create automatic
#    swimming characters, just add in the Environment List the following:
#
#    - :swim    = To make the character a swimmer (can move in the water)
#    - :aquatic = To make the character only can move in the water
#
#    Add in the module SwimRegions, the list of regions where you can swim.
#
#------------------------------------------------------------------------------
# * Notes :
#  
#   - Feature Pickup character thanks to Moghunter for the Character Graphic.
#   - Tile Front Coordinates by SephirothSpawn & MACL.
#   - Data Parser based on the work of trickster.
#==============================================================================


#==============================================================================
# ** Environment_Manager
#==============================================================================

module Environment_Manager
  #--------------------------------------------------------------------------
  # * Graphics : Graphics for Actions
  #--------------------------------------------------------------------------
  Graphics = {:pickup => '_Pickup'}
  #--------------------------------------------------------------------------
  # * Object Types : Types of Objects of the Environment Manager
  #--------------------------------------------------------------------------
  ObjectTypes = [:throw, :swim, :aquatic]
  #--------------------------------------------------------------------------
  # * Swim Regions : Regions where is allowed to swim
  #--------------------------------------------------------------------------
  SwimRegions = [40]
end

#==============================================================================
# ** Module Sound
#==============================================================================

module Sound
  #--------------------------------------------------------------------------
  # * Play Jump Sound
  #--------------------------------------------------------------------------
  def self.play_jump
    Audio.se_play('Audio/SE/Jump1', 80)
  end
  #--------------------------------------------------------------------------
  # * Play Dive Sound
  #--------------------------------------------------------------------------
  def self.play_dive
    Audio.se_play('Audio/SE/Dive', 80)
  end
  #--------------------------------------------------------------------------
  # * Play Throw Sound
  #--------------------------------------------------------------------------
  def self.play_throw
    Audio.se_play('Audio/SE/Jump2', 80)
  end
end


#==============================================================================
# ** Game_Map
#==============================================================================

class Game_Map
  #--------------------------------------------------------------------------
  # * Swimming Water? : Tile is a swimming tile?
  #--------------------------------------------------------------------------
  def swimming_water?(x, y)
    valid?(x, y) && Environment_Manager::SwimRegions.include?(region_id(x, y))
  end
end

#==============================================================================
# ** Game_CharacterBase
#==============================================================================

class Game_CharacterBase
  #--------------------------------------------------------------------------
  # * Public Instance Variables
  #--------------------------------------------------------------------------
  attr_accessor :real_priority
  attr_accessor :default_graphic
  attr_accessor :can_move
  attr_accessor :carrier
  attr_accessor :carrying
  attr_accessor :bgrabbed
  attr_accessor :swimming
  #--------------------------------------------------------------------------
  # * Alias Listing
  #--------------------------------------------------------------------------
  alias_method :meph_mapenman_gcharbs_inpbmem, :init_public_members
  alias_method :meph_mapenman_gcharbs_rmspeed, :real_move_speed
  alias_method :meph_mapenman_gcharbs_mpasble, :map_passable?
  alias_method :meph_mapenman_ghcarbs_screenx, :screen_x
  alias_method :meph_mapenman_gcharbs_screeny, :screen_y
  alias_method :meph_mapenman_gcharbs_screenz, :screen_z
  alias_method :meph_mapenman_gcharbs_update,  :update
  alias_method :meph_mapenman_gcharbs_updmove, :update_move
  alias_method :meph_mapenman_gcharbs_updjump, :update_jump
  alias_method :meph_mapenman_gcharbs_upbush,  :update_bush_depth
  #--------------------------------------------------------------------------
  # * Initialize Public Members
  #--------------------------------------------------------------------------
  def init_public_members
    # Original Method
    meph_mapenman_gcharbs_inpbmem
    # Set Default Graphic Variable
    @default_graphic = ['', 0]
    # Set Can Move Flag
    @can_move = true
    # Add Carrier Char Variable
    @carrier = nil   # Who is Carrying the character
    # Add Carrying Char Variable
    @carrying  = nil   # Who is being carried
    # Add Grabbing Flag
    @bgrabbed = false
    # Set Swimming Flag
    @swimming = false
  end
  #--------------------------------------------------------------------------
  # * Character : Set & Get Character
  #--------------------------------------------------------------------------
  def character(id)
    # Check id
    char = (id == 0 ? $game_player : $game_map.events[id])
    # Return Result
    char
  end
  #--------------------------------------------------------------------------
  # * Throwable : Check if the Character is Throwable/Grabbable
  #--------------------------------------------------------------------------
  def throwable?
    (!@envilst.nil? && @envilst.include?(:throw))
  end  
  #--------------------------------------------------------------------------
  # * Swimmer : Check if the Character can swim (walk in water)
  #--------------------------------------------------------------------------
  def swimmer?
    (!@envilst.nil? && @envilst.include?(:swim))
  end
  #--------------------------------------------------------------------------
  # * Lander? : Check if is aquatic? or can't walk on land
  #--------------------------------------------------------------------------
  def aquatic?
    (!@envilst.nil? && @envilst.include?(:aquatic))
  end
  #--------------------------------------------------------------------------
  # * Carried : Returns the carried character
  #--------------------------------------------------------------------------
  def carried
    character(@carrying)
  end
  #--------------------------------------------------------------------------
  # * Save Current Graphic
  #--------------------------------------------------------------------------
  def save_graphic(name, index)
    @default_graphic = [name, index]
  end
  #--------------------------------------------------------------------------
  # * Action Graphic: Return the Action graphic also used for tests.
  #--------------------------------------------------------------------------
  def graphic_exists?(suffix)
    # Return graphic exists or false if testing
    Cache.character(@character_name + suffix) rescue false
  end
  #--------------------------------------------------------------------------
  # * Change Priority Type
  #--------------------------------------------------------------------------
  def change_priority(type)
    # Set new priority type
    @priority_type = type
  end
  #--------------------------------------------------------------------------
  # * Restore Real Priority : Restore Event's real priority
  #--------------------------------------------------------------------------
  def restore_real_priority
    @priority_type = @real_priority
  end
  #--------------------------------------------------------------------------
  # * Name      : Tile Front (Version 2.4)
  #   Info      : Gets x and y position of tile in front of character
  #   Author    : SephirothSpawn
  #   Other     : Extracted from MACL 2.4
  #--------------------------------------------------------------------------
  def tile_front(distance = 1)
    d = @direction
    x = @x + (d == 6 ? distance : d == 4 ? -distance : 0)
    y = @y + (d == 2 ? distance : d == 8 ? -distance : 0)
    [x, y]
  end
  #--------------------------------------------------------------------------
  # * Swimming? : Check if Character is Swimming?
  #--------------------------------------------------------------------------
  def swimming?
    # Return Flag
    @swimming
  end
  #--------------------------------------------------------------------------
  # * Character is in Water? : Check if Character is in Water
  #--------------------------------------------------------------------------
  def in_water?
    $game_map.swimming_water?(@x, @y)
  end
  #--------------------------------------------------------------------------
  # * Real Move Speed : Get Real Move Speed
  #--------------------------------------------------------------------------
  def real_move_speed
    # Return Original Minus 1 if swimming
    meph_mapenman_gcharbs_rmspeed - (in_water? ? 1 : 0)
  end
  #--------------------------------------------------------------------------
  # * Map Passable? : Check if Map is Passable?(Added Swimming water)
  #--------------------------------------------------------------------------
  def map_passable?(x, y, d)
    # Return tile is swimming water if swimming?
    return $game_map.swimming_water?(x, y) if swimming?
    # The Usual
    meph_mapenman_gcharbs_mpasble(x, y, d)
  end
  #--------------------------------------------------------------------------
  # * Screen X
  #--------------------------------------------------------------------------
  def screen_x
    # Set Screen Y as the Carrier Character Screen Y if Exists
    return character(@carrier).screen_x unless (@carrier.nil? || @bgrabbed)    
    # The Usual
    meph_mapenman_ghcarbs_screenx
  end
  #--------------------------------------------------------------------------
  # * Screen Y
  #--------------------------------------------------------------------------
  def screen_y
    # Set Screen Y as the Carrier Character Screen Y if Exists
    return character(@carrier).screen_y - 20 unless (@carrier.nil? || @bgrabbed)
    # The usual
    meph_mapenman_gcharbs_screeny
  end
  #--------------------------------------------------------------------------
  # * Screen Z
  #--------------------------------------------------------------------------
  def screen_z
    # Return 200 (Priority type 2 * 100) if being carried
    return 200 unless (@carrier.nil? || @bgrabbed)
    # The usual if not carried
    meph_mapenman_gcharbs_screenz
  end
  #--------------------------------------------------------------------------
  # * Jump to a Determinated Coordinate
  #--------------------------------------------------------------------------
  def jump_to(x, y)
    # Determine the Jump Coordinates
    jplusx, jplusy = x - @x, y - @y
    # Jump
    jump(jplusx, jplusy)
  end
  #--------------------------------------------------------------------------
  # * Can Jump?(x, y, d)
  #     Check if can jump to defined coordinate.
  #--------------------------------------------------------------------------
  def can_jump?(x, y, d = @direction)
    return false unless $game_map.valid?(x, y)
    return true if @through || debug_through?
    return false unless map_passable?(x, y, d)
    return false unless map_passable?(x, y, reverse_dir(d))
    return false if collide_with_characters?(x, y)
    return true
  end
  #--------------------------------------------------------------------------
  # * Jump To Front (Distance >= 1)
  #     Jump to front * distance
  #--------------------------------------------------------------------------
  def jump_to_front(distance = 1)
    # Determine to jump coordinate based on tile front and distance
    fx, fy = *tile_front(distance)
    # Jump to new coordinates
    jump_to(fx, fy)
  end
  #--------------------------------------------------------------------------
  # * Update
  #--------------------------------------------------------------------------
  def update
    # Update Event Swimming
    update_event_swimming if self.is_a?(Game_Event)
    # Original Update
    meph_mapenman_gcharbs_update
    # Return Update Carried if there is a Carrier char
    return update_carrying unless (@carrier.nil? || @bgrabbed)
  end
  #--------------------------------------------------------------------------
  # * Update Event Swimming : Update Swimming for event if is in water or not
  #--------------------------------------------------------------------------
  def update_event_swimming
    # Set to swimming if not swimming and can swim and is in water
    @swimming = true  if !@swimming && swimmer?  && in_water?
    # Set to Not Swimming if swimming and isn't aquatic and isn't in water
    @swimming = false if  @swimming && !aquatic? && !in_water?
  end
  #--------------------------------------------------------------------------
  # * Update Move
  #--------------------------------------------------------------------------
  def update_move
    # Return if can't move
    return unless @can_move || @carrier.nil?
    # The Usual
    meph_mapenman_gcharbs_updmove
  end
  #--------------------------------------------------------------------------
  # * Update Carrying : Update x, y pos when being carried
  #--------------------------------------------------------------------------
  def update_carrying
    # Change Coordinates
    @x, @y = -1, -1 if [@x, @y] != [-1, -1]
    @direction = character(@carrier).direction unless @direction_fix
  end
  #--------------------------------------------------------------------------
  # * Update Jump
  #--------------------------------------------------------------------------
  def update_jump
    # The Usual
    meph_mapenman_gcharbs_updjump
    # Update Throw if character is throwable
    update_throw if throwable?
    # If jump count is 0 and is player and is in water
    if @jump_count == 0 && self.is_a?(Game_Player) && in_water?
      # Play Swimming effect
      Sound.play_dive
    end
  end
  #--------------------------------------------------------------------------
  # * Update Jump
  #--------------------------------------------------------------------------
  def update_throw
    # If Jumping
    return unless @jump_count == 0
    # Restore Original Priority
    restore_real_priority
    # Update Bush Depth
    update_bush_depth
    # Finalize Grab for grabber if being grabbed
    return character(@carrier).finalize_grab(@id) if @bgrabbed
    # If Probability is greater than random 100
    if !@envicfg[1].nil? && (rand(100) < @envicfg[1])
      # Play Break Sound
      Audio.se_play('Audio/SE/' + @envicfg[2], 80) if !@envicfg[2].nil?
      # Play Animation if not nil
      @animation_id = @envicfg[3] unless @envicfg[3].nil?
      # Set Keys
      key = [@map_id, @id, @envicfg[4]]
      # Activate Switch
      $game_self_switches[key] = true
    # If didn't break and in water
    elsif in_water?
      # Play dive sound
      Sound.play_dive
    end
  end
  #--------------------------------------------------------------------------
  # * Update Bush Depth
  #--------------------------------------------------------------------------
  def update_bush_depth
    # Set No Bush Depth if being carried (because is above)
    return @bush_depth = 0 unless @carrier.nil?
    # Set Deeper bush depth if swimming
    return @bush_depth = 14 if (normal_priority? && in_water? && !jumping? &&
    @carrier.nil?)
    # The Usual
    meph_mapenman_gcharbs_upbush
  end
  #--------------------------------------------------------------------------
  # * Grab Character : Grab a Character
  #--------------------------------------------------------------------------
  def grab_character(char)
    # Return if carrying already or moving or jumping
    return if !@carrying.nil? || moving? || jumping?
    # Set Tile Front
    fx, fy = *tile_front
    # Return if tile_front is not passable
    return unless map_passable?(fx, fy, @direction)
    # Save Current Graphic
    save_graphic(@character_name, @character_index)
    # Check if Pickup Graphic Exists
    pickgraphic = Environment_Manager::Graphics[:pickup]
    if graphic_exists?(pickgraphic)
      # Change Graphic
      set_graphic(@character_name + pickgraphic, @character_index)
    end
    # Set Carrier as Self
    character(char).carrier = @id
    # Save Original Priority Type
    character(char).real_priority = character(char).priority_type
    # Set Being Grabbed Flag to true
    character(char).bgrabbed = true
    # Change Priority Type unless thrower direction is up
    character(char).change_priority(2) unless @direction == 8
    # Play Grab Sound
    Sound.play_jump
    # Make Character Jump to make a 'grabbing' effect
    character(char).jump_to(@x, @y)
  end
  #--------------------------------------------------------------------------
  # * Finalize Grab : Finalize the Grabbing Process
  #--------------------------------------------------------------------------
  def finalize_grab(char)
    # Set Grabbed Character being grabbing flag to false
    character(char).bgrabbed = false
    # Set Carring Character
    @carrying = character(char).id
    # Update Bush Depth
    character(char).update_bush_depth
  end
  #--------------------------------------------------------------------------
  # * Max Distance : Get Max Distance to throw based on Range
  #--------------------------------------------------------------------------
  def max_throw_distance(range)
    # Do Range times (as integer)
    range.downto(0) do |r|
      # Get tile front based on checking distance
      x, y = *tile_front(r)
      return r if (can_jump?(x, y, @direction) || r == 0)
      next
    end
  end
  #--------------------------------------------------------------------------
  # * Placeable? : Check if Coordinates are used to place items
  #--------------------------------------------------------------------------
  def placeable?(x, y)
    # Return false if coordinates are a ladder type tile
    return false if $game_map.ladder?(x, y)
    # Return true if counter & no event or passable
    return $game_map.counter?(x, y) && !collide_with_events?(x, y) ||
    passable?(@x, @y, @direction)
  end
  #--------------------------------------------------------------------------
  # * Throw Character : Throw the Carried Character
  #--------------------------------------------------------------------------
  def throw_character
    # Return if not carrying object
    return if @carrying.nil? || moving? || jumping?
    # Get Max throw distance
    range = max_throw_distance(carried.envicfg[0])
    # Determine tile where the character will be thrown
    rangex, rangey = *tile_front(range)
    # Return Throw distance is
    return if range == 0
    # Return to Deafault Character Graphic
    if @character_name != @default_graphic[0]
      # Set Graphic to default
      set_graphic(@default_graphic[0], @default_graphic[1])
    end
    # Move Carried character to coordinates
    carried.moveto(@x, @y)
    # Set Carrier to nil
    carried.carrier = nil
    # Play Throw Sound
    Sound.play_throw
    # Change Priority Type unless thrower direction is up
    carried.change_priority(2) #unless @direction == 8
    # Make throw effect as Character Jumping
    carried.jump_to(rangex, rangey)
    # Set Carrying to nil
    @carrying = nil
  end
  #--------------------------------------------------------------------------
  # * Swim : Begin Swimming Process
  #--------------------------------------------------------------------------
  def swim
    # Get Tile Front
    fx, fy = *tile_front
    # If character is swimming or in water?
    if swimming || in_water?
      # Set Swimming flag to false (temporaly)
      @swimming = false
      # Set swimming flag to true again if can't jump to swimming area
      return @swimming = true unless can_jump?(fx, fy)
    # Else if not swimming
    else
      # Set flag to true (temp)
      @swimming = true
      # Set Swimming to false again if can't jump to land
      return @swimming = false unless can_jump?(fx, fy)
    end
    # Play Jump Sound
    Sound.play_jump
    # Jump to front
    jump_to_front
  end
end

#==============================================================================
# ** Game_Event
#==============================================================================

class Game_Event < Game_Character
  #--------------------------------------------------------------------------
  # * Public Instance Variable
  #--------------------------------------------------------------------------
  attr_accessor :envilst
  attr_accessor :envicfg
  #--------------------------------------------------------------------------
  # * Alias Listing
  #--------------------------------------------------------------------------
  alias_method :meph_mapenman_gevent_refresh, :refresh
  #--------------------------------------------------------------------------
  # * Refresh
  #--------------------------------------------------------------------------
  def refresh
    # The usual
    meph_mapenman_gevent_refresh
    # Get Environment List
    @envilst = get_event_comment('ENV::LST',  :array)
    # Get Environment Config
    @envicfg = get_event_comment('ENV::CFG',  :array)
  end
end

#==============================================================================
# ** Scene_Map
#==============================================================================

class Scene_Map
  #--------------------------------------------------------------------------
  # * Alias Listing
  #--------------------------------------------------------------------------
  alias_method :meph_mapenman_scmap_updscene, :update_scene
  #--------------------------------------------------------------------------
  # * Update Scene
  #--------------------------------------------------------------------------
  def update_scene
    # The usual
    meph_mapenman_scmap_updscene
    # Update Place Char
    update_place_char unless scene_changing?
  end
  #--------------------------------------------------------------------------
  # * Update Place Character : Put away a carried character
  #--------------------------------------------------------------------------
  def update_place_char
    # Place Character if L Inputted
    if Input.trigger?(:L)
      $game_player.throw_character
    end
    
    if Input.trigger?(:R)
      $game_player.swim
    end
    
    
  end
end