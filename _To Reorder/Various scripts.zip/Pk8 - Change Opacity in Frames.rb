=begin
 
 Change Character Opacity in Frames 2.1.1
 by PK8
 Created: 5/12/2009
 Modified: 6/11/2012
 ──────────────────────────────────────────────────────────────────────────────
 ■ Introduction
   This allows game creators to change the opacity of character sprites to a
   certain amount in a set number of frames.
 ──────────────────────────────────────────────────────────────────────────────
 ■ Features
   Change the opacity of a character's sprite in a certain number of frames
   with a script call.
 ──────────────────────────────────────────────────────────────────────────────
 ■ Usage
   Script call for changing the player's sprite opacity:
   $game_player.opacity_change(opacity, duration, relative)
 
   Script call for changing an event's sprite opacity:
   $game_map.events[id].opacity_change(opacity, duration, relative)
   
   Script call for changing a vehicle's sprite opacity:
   $game_map.vehicle[id].opacity_change(opacity, duration, relative)
   * 0: Boat, 1: Ship, 2: Airship
   
   Script call for changing a follower's sprite opacity:
   $game_player.followers[id].opacity_change(opacity, duration, relative)
   * Starts with 0.
 
   opacity:  Min: 0, Max: 255
   duration: Min: 0
   relative: true or false (Optional. Defaults to false)
 ──────────────────────────────────────────────────────────────────────────────
 ■ Examples
   This would lower the player's sprite opacity by 20 in 20 frames
   $game_player.opacity_change(-20, 20, true)
 
   This would raise the player's sprite opacity back up by 20 in 20 frames
   $game_player.opacity_change(20, 20, true)
 ──────────────────────────────────────────────────────────────────────────────
 ■ What's New? (MM/DD/YYYY)
   v1     (05/12/2009): Initial release
   v2     (04/11/2012): Recoded.
   v2.1   (04/15/2012): Adds new relative argument to opacity_change
   v2.1.1 (06/11/2012): Shortened the code, made @opacity, @opacity_target, and
                        @opacity_duration accessible via script call, and
                        improved the documentation.
 ──────────────────────────────────────────────────────────────────────────────
 ■ Methods Aliased
   o Game_CharacterBase.init_public_members
   o Game_CharacterBase.update
   
=end
 
#==============================================================================
# ** Game_CharacterBase
#------------------------------------------------------------------------------
#  This base class handles characters. It retains basic information, such as
# coordinates and graphics, shared by all characters.
#==============================================================================
 
class Game_CharacterBase
  #---------------------------------------------------------------------------
  # * Alias Listings
  #---------------------------------------------------------------------------
  unless method_defined?(:pk8_cco_init_public_members)
    alias_method(:pk8_cco_init_public_members, :init_public_members)
    alias_method(:pk8_cco_update, :update)
  end
  #--------------------------------------------------------------------------
  # * Initialize Public Member Variables
  #--------------------------------------------------------------------------
  def init_public_members
    pk8_cco_init_public_members
    @opacity_target, @opacity_duration = 0, 0
  end
  #--------------------------------------------------------------------------
  # * Opacity Change
  #     opacity : Target opacity. (0 - 255)
  #     duration : Frame amount.
  #     relative : References current value and adds to it, if true.
  #--------------------------------------------------------------------------
  def opacity_change(opacity, duration, relative = false)
    @opacity_target = (relative == true ? @opacity + opacity : opacity)
    @opacity_duration = duration
    @opacity = @opacity_target.clone if @opacity_duration == 0
  end
  #--------------------------------------------------------------------------
  # * Frame Update
  #--------------------------------------------------------------------------
  def update
    pk8_cco_update
    if @opacity_duration >= 1
      d = @opacity_duration
      @opacity = (@opacity * (d - 1) + @opacity_target) / d
      @opacity_duration -= 1
    end
  end
end