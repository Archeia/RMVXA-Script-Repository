#===============================================================================
#
# Neo Gauge Ultimate Ace (1.1a)
# 21/02/2012
# Ported to Ace by Pacman (original script by Woratana and edited by Pacman)
# This script changes the way gauges are drawn. This script supports drawing
# gauges horizontally and vertically, uses a 3-colour gradient, has a very
# simple setup and two brilliant methods to change the bitmap.
# Note that much of this work is Woratana's, you should credit him the same as
# (if not more than) me. I do not claim writing this script entirely, I edited
# the VX version a while back, and this is the VXA port of that.
#
# Detailed instructions on the configuration are below.
#
#===============================================================================

class Window_Base < Window  # DO NOT TOUCH THIS
  
  #==========================================================================
  # NEO GAUGE SETTING #
  # Color: Color.new(Red, Green, Blue) # Each number you can put integer 0-255
  # * You can use this site to get RGB color:
  # http://web.njit.edu/~kevin/rgb.txt.html
  #==========================================================================
  GAUGE_GLOW_EFFECT = true # Use glow effect?
  GAUGE_GLOW_COLOR = Color.new(0,0,0) # Glow color
 
  GAUGE_OUTSIDE_BORDER = true # Use outside border?
  GAUGE_OUTSIDE_BORDER_COLOR = Color.new(255,255,255)
  GAUGE_OUTSIDE_BORDER_COLOR2 = Color.new(255,255,255)
  GAUGE_CLEAR_CORNER_OUTSIDE_BORDER = true
 
  GAUGE_INSIDE_BORDER = false # Use inside border?
  GAUGE_INSIDE_BORDER_COLOR = Color.new(255, 255, 255)
  GAUGE_INSIDE_BORDER_COLOR2 = Color.new(0, 0, 0)
  #=============================================================
  # NEO HP/MP/TP/STATS GAUGE SETTING #
  #=============================================================
  # Note: The HPMP options also apply to the TP gauge.
  HPMP_GAUGE_HEIGHT = 8 # gauge height (minumum: 6)
  # Recommend to use HPMP_GAUGE_HEIGHT at least 8,
  # if you're using GAUGE_INSIDE_BORDER in Neo-Gauge
  HPMP_GAUGE_X_PLUS = 0 # Move gauge horizontally (+,-)
  HPMP_GAUGE_Y_PLUS = ((-1)*(HPMP_GAUGE_HEIGHT - 6)) # (+,-)
  # Change '((-1)*(HPMP_GAUGE_HEIGHT - 6))' to number to move gauge vertically
 
  # BACK GAUGE COLORS
  BACK_GCOLOR_1 = Color.new(0, 0, 0) # Black [Color1]
  BACK_GCOLOR_2 = Color.new(100, 100, 100) # Dark Gray [Color2]
  BACK_GCOLOR_3 = Color.new(200, 200, 200) # Light Gray [Color3]
 
  USE_HP_GAUGE = true # Use HP Gauge? (true/false)
  USE_MP_GAUGE = true # Use MP Gauge?
  USE_TP_GAUGE = true # Use TP Gauge?
  USE_STATS_GAUGE = true # Use Attack/Defense/Spirit/Agility/Luck Gauge?
 
  # HP GAUGE COLORS
  HP_GCOLOR_1 = Color.new(139,0,0) # Dark Red
  HP_GCOLOR_2 = Color.new(255,0,0) # Pure Red
  HP_GCOLOR_3 = Color.new(255,193,37) # Goldenrod
 
  # MP GAUGE COLORS
  MP_GCOLOR_1 = Color.new(0,0,128) # Dark Blue
  MP_GCOLOR_2 = Color.new(0,191,255) # Blue
  MP_GCOLOR_3 = Color.new(46,139,87) # Light Green
  
  # TP GAUGE COLORS
  TP_GCOLOR_1 = Color.new(0, 100, 0)  # Dark Green
  TP_GCOLOR_2 = Color.new(191, 255, 0)  # Lime Green
  TP_GCOLOR_3 = Color.new(173, 255, 47) # Yellow Green
 
  # STAT GAUGE COLORS
  STAT_GCOLOR_1 = Color.new(0,0,128)
  STAT_GCOLOR_2 = Color.new(0,191,255)
  STAT_GCOLOR_3 = Color.new(152,251,152)

#===============================================================================
#
# END CONFIGURATION
#
#===============================================================================

#==============================================================================
# ■ Window_Base
#------------------------------------------------------------------------------
# 　ゲーム中の全てのウィンドウのスーパークラスです。
#==============================================================================
  #--------------------------------------------------------------------------
  # * Get Gauge Back Colours
  #--------------------------------------------------------------------------
  def neo_gauge_back_color
    return BACK_GCOLOR_1, BACK_GCOLOR_2, BACK_GCOLOR_3
  end
  #--------------------------------------------------------------------------
if USE_HP_GAUGE
  #--------------------------------------------------------------------------
  # * Draw Actor HP
  #--------------------------------------------------------------------------
  def draw_actor_hp(actor, x, y, width = 124)
    gwidth = width * actor.hp / actor.mhp
    cg = neo_gauge_back_color
    c1, c2, c3 = cg[0], cg[1], cg[2]
    draw_neo_gauge(x + HPMP_GAUGE_X_PLUS, y + line_height - 8 +
      HPMP_GAUGE_Y_PLUS, width, HPMP_GAUGE_HEIGHT, c1, c2, c3)
    (1..3).each {|i| eval("c#{i} = HP_GCOLOR_#{i}")}
    draw_neo_gauge(x + HPMP_GAUGE_X_PLUS, y + line_height - 8 +
      HPMP_GAUGE_Y_PLUS, gwidth, HPMP_GAUGE_HEIGHT, c1, c2, c3, false, false,
      width, 30)
    change_color(system_color)
    draw_text(x, y, 30, line_height, Vocab::hp_a)
    draw_current_and_max_values(x, y, width, actor.hp, actor.mhp,
      hp_color(actor), normal_color)
  end
  #--------------------------------------------------------------------------
end
if USE_MP_GAUGE
  #--------------------------------------------------------------------------
  # * Draw Actor MP
  #--------------------------------------------------------------------------
  def draw_actor_mp(actor, x, y, width = 124)
    gwidth = width * actor.mp / [actor.mmp, 1].max
    cg = neo_gauge_back_color
    c1, c2, c3 = cg[0], cg[1], cg[2]
    draw_neo_gauge(x + HPMP_GAUGE_X_PLUS, y + line_height - 8 +
      HPMP_GAUGE_Y_PLUS, width, HPMP_GAUGE_HEIGHT, c1, c2, c3)
    (1..3).each {|i| eval("c#{i} = MP_GCOLOR_#{i}")}
    draw_neo_gauge(x + HPMP_GAUGE_X_PLUS, y + line_height - 8 + 
      HPMP_GAUGE_Y_PLUS, gwidth, HPMP_GAUGE_HEIGHT, c1, c2, c3, false, false,
      width, 40)
    change_color(system_color)
    draw_text(x, y, 30, line_height, Vocab::mp_a)
    draw_current_and_max_values(x, y, width, actor.mp, actor.mmp,
      mp_color(actor), normal_color)
  end
  #--------------------------------------------------------------------------
end
if USE_TP_GAUGE
  #--------------------------------------------------------------------------
  # * Draw Actor TP
  #--------------------------------------------------------------------------
  def draw_actor_tp(actor, x, y, width = 124)
    gwidth = width * actor.tp / 100
    cg = neo_gauge_back_color
    c1, c2, c3 = cg[0], cg[1], cg[2]
    draw_neo_gauge(x + HPMP_GAUGE_X_PLUS, y + line_height - 8 +
      HPMP_GAUGE_Y_PLUS, width, HPMP_GAUGE_HEIGHT, c1, c2, c3)
    (1..3).each {|i| eval("c#{i} = TP_GCOLOR_#{i}")}
    draw_neo_gauge(x + HPMP_GAUGE_X_PLUS, y + line_height - 8 + 
      HPMP_GAUGE_Y_PLUS, gwidth, HPMP_GAUGE_HEIGHT, c1, c2, c3, false, false,
      width, 40)
    change_color(system_color)
    draw_text(x, y, 30, line_height, Vocab::tp_a)
    change_color(tp_color(actor))
    draw_text(x + width - 42, y, 42, line_height, actor.tp.to_i, 2)
  end
  #--------------------------------------------------------------------------
end
if USE_STATS_GAUGE
  #--------------------------------------------------------------------------
  # * Draw Actor Stats
  #--------------------------------------------------------------------------
  def draw_actor_param(actor, x, y, param_id)
    param_name = Vocab::param(param_id)
    param_value = actor.param(param_id)
    param_max = actor.neo_param_max(param_id)
    width = 156
    gwidth = width * param_value / [param_max, 1].max
    cg = neo_gauge_back_color
    draw_neo_gauge(x + HPMP_GAUGE_X_PLUS, y + line_height - 8 +
      HPMP_GAUGE_Y_PLUS, width, HPMP_GAUGE_HEIGHT, cg[0], cg[1], cg[2])
    c1, c2, c3 = STAT_GCOLOR_1, STAT_GCOLOR_2, STAT_GCOLOR_3
    draw_neo_gauge(x + HPMP_GAUGE_X_PLUS, y + line_height - 8 +
      HPMP_GAUGE_Y_PLUS, gwidth, HPMP_GAUGE_HEIGHT, c1, c2, c3, false, false,
      width, 40)
    change_color(system_color)
    draw_text(x, y, 120, line_height, param_name)
    change_color(normal_color)
    draw_text(x + 120, y, 36, line_height, param_value, 2)
  end
  #--------------------------------------------------------------------------
end
  #--------------------------------------------------------------------------
  # * Draw Neo Gauge
  #     c1, c2, c3  : 3 Colours in the gradient
  #     vert  : Whether the gauge is vertical or not.
  #     outline   : Draw an outline of the gauge?
  #     max_width : Maximum width the gauge can reach.
  #     c2_spot   : Point where the second colour is drawn.
  #--------------------------------------------------------------------------
  def draw_neo_gauge(x, y, width, height, c1, c2, c3, vert = false,
      outline = true, max_width = nil, c2_spot = 50)  
    if max_width.nil? # Get Max Width
      max_width = vert ? height : width
    end
    glow = GAUGE_GLOW_EFFECT
    dx = x; dy = y
    x = y = 0
    bitmap = Bitmap.new(max_width, height)
    if glow # If drawing glow
      if outline  # If drawing outline
        if vert; rect = Rect.new(x, y, width, max_width)  # Make vertical gauge
        else; rect = Rect.new(x, y, max_width, height)  # Make horizontal gauge
        end
        bitmap.fill_rect(rect, GAUGE_GLOW_COLOR)  # Make glow
        bitmap.neo_clear_corner(rect.x, rect.y, rect.width, rect.height) # Clear
      else  # No outline
        height -= 2; width -= 2; x += 1; y += 1
        if GAUGE_INSIDE_BORDER
          height -= 2; width -= 2; x += 1; y += 1
        end
      end
    end
  #--------------------------------------------------------------------------
  # I'm not going to comment every line. There's a lot of stuff here. It may
  # look daunting, but it's actually not that diffciult to get your head
  # around. If you really want to figure this all out, just look at it a lot.
  # Failing that, you could probably just ask a more experienced scripter or
  # myself.
  #--------------------------------------------------------------------------
    if vert
      if glow; gx = gx2 = x + 1; gy = y
      else; gx = gx2 = x; gy = y
      end
      gy2 = gy - 1 + ((c2_spot * max_width) / 100)
      gw = gw2 = width - 2; gh = ((c2_spot * max_width) / 100)
      gh2 = max_width - gh - 2
      bitmap.gradient_fill_rect(gx, gy, gw, gh, c1, c2, true)
      bitmap.gradient_fill_rect(gx2, gy2, gw2, gh2, c2, c3, true)
      gh = (gh + gh2)
    else
      if glow; gx = x; gy = gy2 = y
        gx = x + 1; gy = gy2 = y + 1
      else; gx = x; gy = gy2 = y
      end
      gx2 = gx - 1 + ((c2_spot *  max_width) / 100)
      gw = ((c2_spot * max_width) / 100); gh = gh2 = (height - 2)
      gw2 = max_width - gw - 2
      bitmap.gradient_fill_rect(gx, gy, gw, gh, c1, c2)
      bitmap.gradient_fill_rect(gx2, gy2, gw2, gh2, c2, c3)
      gw = (gw + gw2)
    end
    if outline
      if GAUGE_OUTSIDE_BORDER
        bitmap.draw_neo_border(gx, gy, gw, gh, GAUGE_OUTSIDE_BORDER_COLOR,
          GAUGE_OUTSIDE_BORDER_COLOR2)
        if GAUGE_CLEAR_CORNER_OUTSIDE_BORDER
          bitmap.neo_clear_corner(gx, gy, gw, gh)
        end
      end
      if GAUGE_INSIDE_BORDER
        gx += 1; gy += 1; gw -= 2; gh -= 2
        bitmap.draw_neo_border(gx, gy, gw, gh, GAUGE_INSIDE_BORDER_COLOR,
          GAUGE_INSIDE_BORDER_COLOR2)
      end
    end
    rect = Rect.new(0, 0, width, bitmap.height)
    self.contents.blt(dx, dy, bitmap, rect)
    bitmap.dispose
  end
end

#==============================================================================
# ■ Bitmap
#------------------------------------------------------------------------------
# 　かわいいですね。
#==============================================================================

class Bitmap
  #--------------------------------------------------------------------------
  # * Draw border of Neo Gauge
  #--------------------------------------------------------------------------
  def draw_neo_border(x, y, width, height, color, color2 = color, size = 1)
    gradient_fill_rect(x, y, width, size, color, color2)
    fill_rect(x, y, size, height, color)
    fill_rect(x + width - size, y, size, height, color2)
    gradient_fill_rect(x, y + height - size, width, size, color, color2)
  end
  #--------------------------------------------------------------------------
  # * Clear Corner of Neo Gauge
  #--------------------------------------------------------------------------
  def neo_clear_corner(x, y, width, height, size = 1)
    clear_rect(x, y, size, size)
    clear_rect(x + width - size, y, size, size)
    clear_rect(x, y + height - size, size, size)
    clear_rect(x + width - size, y + height - size, size, size)
  end
end

#==============================================================================
# ■ Game_Battler
#------------------------------------------------------------------------------
# 　スプライトや行動に関するメソッドを追加したバトラーのクラスです。このクラス
# は Game_Actor クラスと Game_Enemy クラスのスーパークラスとして使用されます。
#==============================================================================

class Game_Battler < Game_BattlerBase
  #--------------------------------------------------------------------------
  # * Get class (simpler method)
  #--------------------------------------------------------------------------
  def klass
    self.class if self.is_a?(Game_Actor)
  end
  #--------------------------------------------------------------------------
  # * Get Neo Parameter Max
  #--------------------------------------------------------------------------
  def neo_param_max(param_id)
    case param_id
    when 2; maxatk
    when 3; maxdef
    when 4; maxspi
    when 5; maxmdef
    when 6; maxagi
    when 7; maxluk
    end
  end
  #--------------------------------------------------------------------------
  # * Max attack
  #--------------------------------------------------------------------------
  def maxatk
    n = atk
    if self.is_a?(Game_Actor)
      n = n - klass.params[2, @level] + klass.params[2, 99]
    end
    return n
  end
  #--------------------------------------------------------------------------
  # * Max defense
  #--------------------------------------------------------------------------
  def maxdef
    n = atk
    if self.is_a?(Game_Actor)
      n = n - klass.params[3, @level] + klass.params[3, 99]
    end
    return n
  end
  #--------------------------------------------------------------------------
  # * Max magic
  #--------------------------------------------------------------------------
  def maxspi
    n = atk
    if self.is_a?(Game_Actor)
      n = n - klass.params[4, @level] + klass.params[4, 99]
    end
    return n
  end
  #--------------------------------------------------------------------------
  # * Max magic defense
  #--------------------------------------------------------------------------
  def maxmdef
    n = atk
    if self.is_a?(Game_Actor)
      n = n - klass.params[5, @level] + klass.params[5, 99]
    end
    return n
  end
  #--------------------------------------------------------------------------
  # * Max agility
  #--------------------------------------------------------------------------
  def maxagi
    n = atk
    if self.is_a?(Game_Actor)
      n = n - klass.params[6, @level] + klass.params[6, 99]
    end
    return n
  end
  #--------------------------------------------------------------------------
  # * Max luck
  #--------------------------------------------------------------------------
  def maxluk
    n = atk
    if self.is_a?(Game_Actor)
      n = n - klass.params[7, @level] + klass.params[7, 99]
    end
    return n
  end
end

$imported ||= {}
$imported[:neo_gauge_ultimate]

#===============================================================================
#
# END OF SCRIPT
#
#===============================================================================