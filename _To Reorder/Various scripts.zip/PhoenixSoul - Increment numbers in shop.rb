=begin Shop Quantity Change Value Alteration Plugin 
This will change the way the numbers are updated in the Shop. 
Devised by Amyrakunejo, assisted by Dr.Pantload (/c) 2017, 
PHANTOM Enterprises Change the values of the following: 
if Input.press?(:SHIFT) || Input.press?(:A) value *= 2 
end 
To just about anything you'd like. 
In the example above, '||' indicates that either :SHIFT or :A 
must be pressed for the conditions to be met 
Change the 2 in value *= 2 to whatever you'd like. 
You can take the template above, and add it to the script below,
as long as you keep it below elsif 
Input.repeat?(:DOWN) value = -10 
end 
and above change_number(value) 
end 
end 
Tips: You can have it be required that BOTH :A and :SHIFT 
be pressed to increase the value multiplier by replacing '||' with '&&' 
You can also change the way the values change by default. 
Like, you can flip right and left, as well as up and down, 
by inverting their respctive integers. 
Example: if Input.repeat?(:RIGHT) value = -1 
elsif Input.repeat?(:LEFT) value = 1 
elsif Input.repeat?(:UP) value = -10 
elsif Input.repeat?(:DOWN) value = 10 
end 
Can also rotate the intergers, like so: 
if Input.repeat?(:RIGHT) value = 10 
elsif Input.repeat?(:LEFT) value = -10 
elsif Input.repeat?(:UP) value = 1 
elsif Input.repeat?(:DOWN) value = -1 
end 
Or even rotate and invert the integers, like this: 
if Input.repeat?(:RIGHT) value = -10 
elsif Input.repeat?(:LEFT) value = 10 
elsif Input.repeat?(:UP) value = -1 
elsif Input.repeat?(:DOWN) value = 1 
end 
Personally, I don't recommend the above, but it can be done, 
though if you do, you might want to tell your fellow players. 
Here are some examples of value multiplier alteration commands: 
if Input.press?(:SHIFT) || Input.press?(:A) value *= 2 
end 
if Input.press?(:SHIFT) && Input.press?(:A) value *= 5 
end 
if Input.press?(:X) || Input.press?(:A) || Input.press?(:Z) value *= 2 
end 
if Input.press?(:Y) value *= $game_variables[x] 
end 
Alias: Window_ShopNumber -> Update Quantity 
=end 
class Window_ShopNumber < Window_Selectable 
#-------------------------------------------------------------------------- 
# * Update Quantity 
#-------------------------------------------------------------------------- 
def update_number value = 0 
if Input.repeat?(:RIGHT) value = 1 
elsif Input.repeat?(:LEFT) value = -1 
elsif Input.repeat?(:UP) value = 10 
elsif Input.repeat?(:DOWN) value = -10 
end 
if Input.press?(:SHIFT) || Input.press?(:A) value *= 2 
end 
if Input.press?(:Z) value *= 5 
end 
#~ if Input.press?(:SHIFT) || Input.press?(:A) && Input.press?(:X) 
#~ value *= 10 
#~ end if Input.press?(:SHIFT) || Input.press?(:A) && Input.press?(:Z) value *= 10 
#~ end 
#~ if Input.press?(:SHIFT) || Input.press?(:A) && Input.press?(:Y) 
#~ value *= 50 
#~ end 
#~ if Input.press?(:X) 
#~ value *= 50 
#~ end 
#~ if Input.press?(:Y) 
#~ value *= 100 
#~ end 
#~ if Input.press?(:X) && Input.press?(:Y) 
#~ value *= 500 
#~ end change_number(value) end end