#===============================================================================
# ** Custom Menu Backgrounds 2.0 **
#===============================================================================
#
# Version:      2.0
# Datum:        29.06.2014
# Author:       eugene222
#  
#===============================================================================
#   CHANGELOG:
#
#   Version 2.0  ,  29.06.2014:   rewrote the script, added many features
#   Version 1.1a ,  13.05.2014:   improved compatibility
#   Version 1.1  ,  24.04.2014:   layouts added
#   Version 1.01 ,  21.03.2014:   code optimized
#   Version 1.0  ,  02.03.2014:   Script created
#
#===============================================================================
# Features:
#
#   - Custom Background For Every Scene (Custom Scenes should work, too)
#   - Custom Layout Which Will Be Displayed Over The Background
#   - Custom Opacity For The Windows
#   - Particle Effects
#
#===============================================================================
# Installation:
#
#  Place this script above main but below the default scripts 
#
#  The background and layout pictures have to be in "Graphics\Menu"
#   => Create the Folder if you dont have one.
#  The particle picture has to be in "Graphics\Menu", too.
#  The size dont matter but I recommend 32x32
#
#===============================================================================
module EVG
  module SceneBG
    
    USED_SCENES = ["Scene_Menu", "Scene_Item", "Scene_Skill", "Scene_Equip",
                   "Scene_Status", "Scene_Save", "Scene_Load", "Scene_End"]
    
    #---------------------------------------------------------------------------
    # You need to define the default Attributes below
    # All Scenes in USED_SCENES will use these values as their default
    # A little bit more below you can overwrite attributes for certain scenes 
    #----------------------------------------------------------------------------
    DEFAULT_CONFIG = {
      #------------------------------------------------------------------------
      # You can set :opacity, :background, :layout and :particle to :disabled
      # This means, that this script wont touch disabled attributes
      # But you can overwrite them for certain scenes.
      #-------------------------------------------------------------------------
      
      # :opacity => value or :disabled,
      :opacity          => 128,
      
      # :background => "filename" or :disabled,
      :background       => "bg", 
      
      # :layout => "filename" or :disabled,
      :layout           => :disabled,
      
      # :particle => "filename" or :disabled,
      :particle         => "particle",
      
      # How many particles should be shown on the screen?
      :particle_number  => 10,
      
      # The x-axis speed per frame
      :particle_speed_x => 0,
      
      # The y-axis speed per frame
      :particle_speed_y => 3,
      
      # The angle speed per frame
      :particle_speed_a => 1,
    #--------------------------------------------------------------------------- 
    } # Diese Zeile nicht ver�ndern
    #---------------------------------------------------------------------------
    # Here you can define individual settings for the used scenes
    # The default attributes get overwriten by this.
    #---------------------------------------------------------------------------
    OVERWRITE = { # Diese Zeile nicht ver�ndern
    #---------------------------------------------------------------------------
    # Custom Scene Config:
    #  - The overwriten attributes needs to be seperated by a comma
    #---------------------------------------------------------------------------
    
    "Scene_Menu"  =>   {
    
      :particle_number => 20,
        
    },  


    #---------------------------------------------------------------------------
    # CONFIG END
    #---------------------------------------------------------------------------   
    } # Diese Zeile nicht ver�ndern
    #---------------------------------------------------------------------------
  end
end
#===============================================================================
# ** Cache
#===============================================================================
class Scene_MenuBase
  #---------------------------------------------------------------------------
  # Post Start
  #---------------------------------------------------------------------------
  alias :evg_smb_ps_cmb          :post_start
  #---------------------------------------------------------------------------
  def post_start
    if custom_bg_scene?
      change_opacity
      create_layout
      create_particles
    end
    evg_smb_ps_cmb
  end
  #--------------------------------------------------------------------------
  # * Custom Background Scene?
  #--------------------------------------------------------------------------  
  def custom_bg_scene?
    return EVG::SceneBG::USED_SCENES.include?(current_scene)
  end
  #--------------------------------------------------------------------------
  # * Current Scene
  #--------------------------------------------------------------------------  
  def current_scene
    return SceneManager.scene.class.to_s
  end
  #--------------------------------------------------------------------------
  # * Is type An Overwrite Type?
  #--------------------------------------------------------------------------
  def overwrite_type?(type)
    EVG::SceneBG::OVERWRITE[current_scene.to_s] &&
    EVG::SceneBG::OVERWRITE[current_scene.to_s][type]
  end  
  #--------------------------------------------------------------------------
  # * Create Viewport
  #--------------------------------------------------------------------------
  alias :evg_smb_cmv_cmb      :create_main_viewport
  def create_main_viewport
    evg_smb_cmv_cmb
    w = Graphics.width + 32; h = Graphics.height + 32
    @particle_viewport = Viewport.new(-32, -32, w, h)
    @particle_viewport.z = 5
  end
  #---------------------------------------------------------------------------
  #  Return Value For Type
  #---------------------------------------------------------------------------
  def return_value(type)
    if overwrite_type?(type)
      return EVG::SceneBG::OVERWRITE[current_scene.to_s][type]
    else
      return EVG::SceneBG::DEFAULT_CONFIG[type]
    end
  end
  #---------------------------------------------------------------------------
  # Get Opacity
  #---------------------------------------------------------------------------
  def get_opacity
    return_value(:opacity)
  end
  #---------------------------------------------------------------------------
  # Get Background
  #---------------------------------------------------------------------------
  def get_background
    return_value(:background)
  end
  #---------------------------------------------------------------------------
  # Get Layout
  #---------------------------------------------------------------------------
  def get_layout
    return_value(:layout)
  end
  #---------------------------------------------------------------------------
  # New Create Background
  #---------------------------------------------------------------------------
  def new_create_background
    @background_sprite = Sprite.new
    @background_sprite.bitmap = Cache.menu(get_background)
  end
  #---------------------------------------------------------------------------
  # Create Background
  #---------------------------------------------------------------------------
  alias :evg_smb_cb_cmb          :create_background
  #---------------------------------------------------------------------------
  def create_background
    if custom_bg_scene?
      return evg_smb_cb_cmb if get_background == :disabled
      return new_create_background
    else
      evg_smb_cb_cmb
    end
  end
  #---------------------------------------------------------------------------
  # Create �ayout
  #---------------------------------------------------------------------------
  def create_layout
    return if get_layout == :disabled
    @layout_sprite = Sprite.new
    @layout_sprite.z = @background_sprite.z + 1
    @layout_sprite.bitmap = Cache.menu(get_layout)
  end
  #--------------------------------------------------------------------------
  # Create Particles
  #--------------------------------------------------------------------------  
  def create_particles
    return if return_value(:particle) == :disabled
    dispose_particles
    file = return_value(:particle)
    speed_x = return_value(:particle_speed_x)
    speed_y = return_value(:particle_speed_y)
    speed_a = return_value(:particle_speed_a)
    @particles = Array.new(return_value(:particle_number)) do
      EVGParticle.new(@particle_viewport, speed_x, speed_y, speed_a, file)
    end
  end
  #---------------------------------------------------------------------------
  # Change Opacity
  #---------------------------------------------------------------------------
  def change_opacity
    return if get_opacity == :disabled
    instance_variables.each do |name|
      instance = instance_variable_get(name)
      set_opacity(instance) if instance.is_a?(Window)
    end
    update_file_opacity if @savefile_windows
  end
  #---------------------------------------------------------------------------
  # For Scene File
  #---------------------------------------------------------------------------
  def update_file_opacity
    @savefile_windows.each do |window|  
      set_opacity(window)
    end
  end
  #---------------------------------------------------------------------------
  # Set Window Opacity
  #---------------------------------------------------------------------------
  def set_opacity(window)
    return if window.nil?
    return if window.disposed?
    window.opacity = get_opacity
  end
  #---------------------------------------------------------------------------
  # Update
  #---------------------------------------------------------------------------
  alias :evg_smb_update_cbs            :update
  #---------------------------------------------------------------------------
  def update
    evg_smb_update_cbs
    @particles.each(&:update) if @particles
  end
  #---------------------------------------------------------------------------
  # Dispose �ayout
  #---------------------------------------------------------------------------
  def dispose_layout
    return unless @layout_sprite
    @layout_sprite.bitmap.dispose
    @layout_sprite.dispose
  end
  #---------------------------------------------------------------------------
  # Dispose Particles
  #---------------------------------------------------------------------------
  def dispose_particles
    return unless @particles
    @particles.each(&:dispose)
    @particle_viewport.dispose
    @particles = nil
  end 
  #---------------------------------------------------------------------------
  # Terminate
  #---------------------------------------------------------------------------
  alias :evg_smb_terminate_cbs         :terminate
  #---------------------------------------------------------------------------
  def terminate
    evg_smb_terminate_cbs
    dispose_layout
    dispose_particles
  end
  #---------------------------------------------------------------------------
end 
#===============================================================================
# ** Particle
#===============================================================================
class EVGParticle < Sprite
  #-----------------------------------------------------------------------------
  # Initialize
  #-----------------------------------------------------------------------------
  def initialize(viewport = nil, speed_x, speed_y, speed_angle, file)
    super(viewport)
    self.bitmap = Cache.menu(file)
    @sx = speed_x
    @sy = speed_y
    @sa = speed_angle
    reset_particle(true)
  end
  #-----------------------------------------------------------------------------
  # Particle Width
  #-----------------------------------------------------------------------------
  def pw
    return self.bitmap.width
  end
  #-----------------------------------------------------------------------------
  # Particle Height
  #-----------------------------------------------------------------------------
  def ph
    return self.bitmap.height
  end
  #-----------------------------------------------------------------------------
  # Particle Visible?
  #-----------------------------------------------------------------------------
  def on_screen?
    self.x.between?(-pw, Graphics.width + pw) &&
    self.y.between?(-ph, Graphics.height + ph)
  end
  #-----------------------------------------------------------------------------
  # Reset Particle
  #-----------------------------------------------------------------------------
  def reset_particle(init = false)
    self.opacity = 0
    reset_zoom
    reset_position(init)
    reset_speed
  end
  #-----------------------------------------------------------------------------
  # Reset Zoom
  #-----------------------------------------------------------------------------
  def reset_zoom
    zoom = (50 + rand(75)) / 100.0
    self.zoom_x = zoom
    self.zoom_y = zoom
  end
  #-----------------------------------------------------------------------------
  # Reset Position
  #-----------------------------------------------------------------------------
  def reset_position(init)
    self.x = rand(Graphics.width)
    self.y = init ? rand(Graphics.height + pw) : Graphics.height + rand(ph + 32)   
  end
  #-----------------------------------------------------------------------------
  # Reset Speed
  #-----------------------------------------------------------------------------
  def reset_speed
    @speed_x = @sx == 0 ? 0 : [[rand(@sx), 20].min, 1].max
    @speed_y = @sy == 0 ? 0 : [[rand(@sy), 20].min, 1].max
    @speed_a = @sa == 0 ? 0 : [[rand(@sa), 20].min, 1].max
  end
  #-----------------------------------------------------------------------------
  # Update
  #-----------------------------------------------------------------------------
  def update
    super
    self.x += @speed_x
    self.y -= @speed_y
    self.angle += @speed_a 
    self.opacity += 5
    reset_particle unless on_screen?
  end
  #-----------------------------------------------------------------------------
  # Dispose
  #-----------------------------------------------------------------------------
  def dispose
    self.bitmap.dispose
    super
  end
end
#===============================================================================
# ** Cache
#===============================================================================
module Cache
  #-----------------------------------------------------------------------------
  def self.menu(filename)
    load_bitmap("Graphics/Menu/", filename)
  end
  #-----------------------------------------------------------------------------
end
#===============================================================================
# END
#===============================================================================