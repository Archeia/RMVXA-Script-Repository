class Game_Follower
  alias :jump_nojumpforactor :jump

  def jump(x_plus, y_plus)
    jump_nojumpforactor(x_plus, y_plus)
    @jump_count = 0 if actor.id == x
    # Replace "x" with the database ID of the actor who will not jump.
    # Replace the above line with the alternate one below for multiple actors.
    # @jump_count = 0 if [x,y].include?(actor.id)
  end
end