################################################################################
#  RRSBL - Reedo's Random Shop-by-Level
#  Version 0.2
#  September 30, 2013
#  By Reedo
###############################################################################
#  REFERENCES
#  None.  This is an original script by Reedo.
###############################################################################
#  FEATURES#
#  + Allows shop processing to use a random selection of items determined
#    by the player's current level.
#  + Individual items-per-level also have their own chance of appearing.
#  + Simple event command script calls control shop processing options.
#  + Possible to control "random" selection based on some other value.
#  + Selection can be limited by "shop type".
################################################################################
#  COMPATIBILITY
#  Should be compatible with most other scripts.
################################################################################
#  REQUIREMENTS
#  Script commands in events to activate/control random shop processing.
################################################################################
#  INSTALLATION
#  Plug-and-play
#  Insert below Materials, above other add-on scripts.
################################################################################
#  RIGHTS & RESTRICTIONS
#  As with most Reedo scripts, this script is free to re-use, as-is,
#  in personal, educational, and commercial RPGVX Ace development projects,
#  providing that:  this script is credited in writing displayed readily
#  to the user of the final compiled code assembly.
#  Reedo retains all rights of intellect and ownership.
#  You forego all rights of warranty by utilizing this script.
################################################################################
################################################################################
#  USER OPTIONS
################################################################################
# The following variables have been added to the Game_Interpreter to support
# using this script:
# @reedo_random_shop   <- Set to True to enable random shopping, Nil/False to
# disable.
#
# @reedo_item_min      <- Set minimum number of items to show in shop.
# @reedo_item_max      <- Set maximum number of items to show in shop.
# @reedo_random_seed   <- Control the "random" selection by setting this value;
#                         set Nil for new random selection ever time.
# @reedo_shop_type     <- Set to a single shop type keyword, or array of shop
#                         type keywords.
#
# In any event that will show a shop scene where you want to use the random
# shopping, be sure to set @reedo_random_shop = true in a script command before
# you begin the shop scene processing. You can set the @reedo_item_min/max
# variables before shop scene processing to set the number of items for sale
# in each shop. If you do not set these values for each event, then the defaults
# defined in RSSBL are used instead. You can set the @reedo_random_seed to
# specific value to force the "random" selection to be the same every time.
# If you had another script such as a calendar that could give you a unique
# value every "day", then you could set the random seed to this value to force
# the same selection for an entire day, and create a new random selection on the
# next day. All other options are configured below:
################################################################################

module RRSBL
 
  SHOP_ITEMS = {} # Do not modify; configured below. 
 
  # Min number of items to show in shop
  ITEM_COUNT_MIN = 1
 
  # Max number of items to show in shop; set min = max to always show the same
  #amount
  ITEM_COUNT_MAX = 3
 
  # Auto-reset the random shop after use if true.
  AUTO_RESET_RANDOM = true 
 
  # ITEM CONFIGURATION
  #  Enter items as array of sales-item, percent chance to be sold, and optional
  #  shop type name used to filter selection with @reedo_shop_type.
  #  Sales-item array consists of:
  #  [type, id, defaultPrice, price]
  #  Where type = 0 for items, 1 for weapons, and 2 for armor
  #         id = the item id from the database
  #         defaultPrice = 0 to use item price, or 1 to use custom price
  #         price = the custom price, or nil when defaultprice = 0
  #  Percent chance is a float between 0.0 (0% chance) and 1.0 (100% chance)
  #  Shop type name is a single string or array of strings used to further
  #    restrict the possible random item selection. 
  # Configure possible items when level is equal or greater than 1
  LEVEL_1_ITEMS = []
  LEVEL_1_ITEMS.push([[0, 1, 0, nil], 1.0, "items"])
  LEVEL_1_ITEMS.push([[1, 1, 0, nil], 1.0, "weapons"])
  LEVEL_1_ITEMS.push([[2, 1, 0, nil], 1.0, "armor"]) 
 
  # Configure possible items when level is equal or greater than 3
  LEVEL_3_ITEMS = []
  LEVEL_3_ITEMS.push([[0, 2, 0, nil], 1.0])
  LEVEL_3_ITEMS.push([[1, 2, 0, nil], 1.0])
  LEVEL_3_ITEMS.push([[2, 2, 0, nil], 1.0]) 
 
  # Create and configure more items as needed... 
  # Add all configured items-per-level to the SHOP_ITEMS hash
  SHOP_ITEMS[1] = LEVEL_1_ITEMS
  SHOP_ITEMS[3] = LEVEL_3_ITEMS 
 
end

################################################################################
# MAIN SCRIPT
################################################################################
#  EDITS BEYOND THIS POINT ARE AT YOUR OWN RISK!!!
###############################################################################

class Game_Interpreter
  #--------------------------------------------------------------------------
  # * Shop Processing
  #--------------------------------------------------------------------------
  alias reedo_rrsbl_gi_command_302 command_302
  def command_302 
    return if $game_party.in_battle 
    if !@reedo_random_shop   
      reedo_rrsbl_gi_command_302 
    else   
      @reedo_random_shop = nil if RRSBL::AUTO_RESET_RANDOM   
      index = 1   
      level = $game_player.actor.level   
      RRSBL::SHOP_ITEMS.keys.each do |key|     
        if (key > index - 1) || (key > level)
          break     
        else       
          index += 1     
        end   
      end   
      goods = []         
      min = @reedo_item_min   
      min = RRSBL::ITEM_COUNT_MIN if !min   
      max = @reedo_item_max   
      max = RRSBL::ITEM_COUNT_MAX if !max   
      oldseed = nil   
      oldseed = srand(@reedo_random_seed) if @reedo_random_seed         
      possible = []   
      RRSBL::SHOP_ITEMS[index].each do |item|     
        if item.size > 2 && @reedo_shop_type && @reedo_shop_type.size > 0       
          next if !@reedo_shop_type.include?(item[2])     
        end     
        if rand <= item[1]       
          possible.push(item[0])     
        end   
      end               
      count = [min, rand(max + 1)].max   
      count.times do |cnt|     
        selectedindex = rand(possible.size)     
        goods.push(possible[selectedindex])     
        possible.delete_at(selectedindex)     
        break if possible.size == 0   
      end         
      srand(oldseed) if oldseed   
      SceneManager.call(Scene_Shop)   
      SceneManager.scene.prepare(goods, @params[4])   
      Fiber.yield 
    end
  end
 
end