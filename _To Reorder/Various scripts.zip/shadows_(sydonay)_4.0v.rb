#=============================================================================#
# WyreScript (SYDONAY) - Character Shadow                                     #
# Last Updated: 2014 - April - 24                                             #
# 2012 - September - 07 (Release date)                                        #
# Version updates 2.0+ by Vindaca                                             #
# This script adds shadows to your player character and followers of him.     #
# Outdated versions: 1.0, 2.0, 2.1, 2.5, 3.0, 3.1                             #
# Current version: 4.0                                                        #
#-----------------------------------------------------------------------------#
# ** How To Use                                                               #
#-----------------------------------------------------------------------------#
#                                                                             #
#  * This script is Plug & Play.                                              #
#                                                                             #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#                                                                             #
#  * Shadows can be turned on and off as soon as the map loads by making a    #
#  comment with one of the following commands on the event pages first line.  #
#                                                                             #
#    shadow_on                                                                #
#    shadow_off                                                               #
#                                                                             #
#  * Additional Shadows can be turned on and off by using these script calls. #
#                                                                             #
#    shadow_on                                                                #
#    shadow_off                                                               #
#                                                                             #
#-----------------------------------------------------------------------------#
#==============================================================================
$imported = {} if $imported.nil?
$imported["Ws-CharacterShadow"] = true
#==============================================================================
# ** SYDOSHADOW
#------------------------------------------------------------------------------
#  This module manages the Shadow module.
#==============================================================================
module SYDOSHADOW
#==============================================================================
# ** Shadow
#------------------------------------------------------------------------------
#  This module manages the cutomizable features for the shadows.
#==============================================================================
  module SHADOW
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
#                                                                              #
#                           Start Customizable Area.                           #
#                                                                              #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#                                                                              #
#                        ONLY EDIT THE DESIGNATED AREAS.                       #
#                                                                              #
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#



  #=============================================================================
  # * Shadow Graphic Name
  #=============================================================================
    SHADOW_GRAPHIC = "Shadow"
   
  #=============================================================================
  # * Default Settings For Shadows
  #=============================================================================
    DEFAULT_ON_PLAYER       = true # Shadow on player
    DEFAULT_ON_FOLLOWER     = true # Shadow on players party members when following
    DEFAULT_ON_EVENT        = true # Shadow in all events
     
  #=============================================================================
  # * Additional Settings For Shadows
  #=============================================================================
    Shadow_Off_In_Bush      = true # Shadow turns off if you walk into a bush automatically
    Use_Shadow_Off_Regions  = true # Shadow turns off if you walk into Regions below automatically
    Shadow_Off_Region_Ids   = [1, 2, 3] # Shadow turns off if you walk into Regions in array automatically
    Character_Shadow_Match_Opacity   = true # Shadow matchs Character Opacity
     
  #=============================================================================
  # * Sticky Shadows~ Shadows stick to ground when you jump.
  #=============================================================================
    Sticky_Shadows = true
    Use_Region_Sticky_Shadow_Size = true
    Small_Shadow_Regions = [4]
    Large_Shadow_Regions = [5]
    #---------------------------------------------------------------------------
    # This is overwritten if Use_Region_Sticky_Shadow_Size is equal to true
    # This acts as a default size if you do not want to use regions.
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # * 0 ~ Normal Size Shadows When Jumping
    # * 1 ~ Over Sized Shadows When Jumping
    # * 2 ~ Small Size Shadows When Jumping
    #---------------------------------------------------------------------------
    Sticky_Shadow_Size = 1
     
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
#                                                                              #
#         DO NOT EDIT PAST THIS POINT UNLESS YOU KNOW WHAT YOUR DOING.         #
#                                                                              #
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#





















  end #<--- End of Shadow Module===============================================

end #<--- End of SYDOSHADOW Module=============================================


#==============================================================================
# ** Sprite_Character
#------------------------------------------------------------------------------
#  This sprite is used to display characters. It observes an instance of the
# Game_Character class and automatically changes sprite state.
#==============================================================================

class Sprite_Character < Sprite_Base
 
  #--------------------------------------------------------------------------
  # * alias method update
  #--------------------------------------------------------------------------
  alias :shadow_sprite_character_update :update
  def update
    shadow_sprite_character_update
    update_shadow
  end
 
  #--------------------------------------------------------------------------
  # * alias method dispose
  #--------------------------------------------------------------------------
  alias :shadow_sprite_character_dispose :dispose
  def dispose
    dispose_shadow
    shadow_sprite_character_dispose
  end
 
  #--------------------------------------------------------------------------
  # * start_shadow : draw and initialize
  #--------------------------------------------------------------------------
  def start_shadow
    dispose_shadow
    @shadow_sprite = ::Sprite.new(viewport)
    @shadow_sprite.bitmap = Cache.system(SYDOSHADOW::SHADOW::SHADOW_GRAPHIC)
    @shadow_sprite.z = self.z - 1
    @shadow_sprite.ox = 16
    @shadow_sprite.oy = -4
    @shadow_sprite.zoom_x = (@cw / @shadow_sprite.width).to_f
    @shadow_sprite.opacity = @character.opacity if SYDOSHADOW::SHADOW::Character_Shadow_Match_Opacity
    @shadow_size = 0
    update_shadow
  end
 
  #--------------------------------------------------------------------------
  # * update_shadow : validate, draw if necessary, adjust position, destroy
  #--------------------------------------------------------------------------
  def update_shadow
    @shadow_size = 0
    if @character.shadow and !@character.transparent
      if @character.is_a?(Game_Follower) and !@character.visible?
        dispose_shadow if @shadow_sprite
        return
      end
      start_shadow unless @shadow_sprite
      @shadow_sprite.x = x
      @shadow_sprite.z = z - 1
      @shadow_sprite.opacity = @character.opacity if SYDOSHADOW::SHADOW::Character_Shadow_Match_Opacity
      if @character.jumping?
        if SYDOSHADOW::SHADOW::Sticky_Shadows
          @shadow_sprite.y = (y - @shadow_sprite.height) + @character.jump_height
          if SYDOSHADOW::SHADOW::Use_Region_Sticky_Shadow_Size == true
            SYDOSHADOW::SHADOW::Small_Shadow_Regions.each { |i|
              if i == $game_map.region_id((@shadow_sprite.x / 32).to_i, (@shadow_sprite.y / 32).to_i)
                @shadow_size = 1
              end
            }
            SYDOSHADOW::SHADOW::Large_Shadow_Regions.each { |i|
              if i == $game_map.region_id((@shadow_sprite.x / 32).to_i, (@shadow_sprite.y / 32).to_i)
                @shadow_size = 2
              end
            }
            case @shadow_size
            when 0
              @shadow_sprite.zoom_x = ((@cw / @shadow_sprite.width).to_f)
            when 1
              @shadow_sprite.zoom_x = ((@cw / @shadow_sprite.width).to_f) / 2
            when 2
              @shadow_sprite.zoom_x = ((@cw / @shadow_sprite.width).to_f) * 1.5
            end
          else
            case SYDOSHADOW::SHADOW::Sticky_Shadow_Size
            when 0
              @shadow_sprite.zoom_x = ((@cw / @shadow_sprite.width).to_f)
            when 1
              @shadow_sprite.zoom_x = ((@cw / @shadow_sprite.width).to_f) / 2
            when 2
              @shadow_sprite.zoom_x = ((@cw / @shadow_sprite.width).to_f) * 2
            end
          end
        else
          @shadow_sprite.y = y - @shadow_sprite.height
          @shadow_sprite.zoom_x = (@cw / @shadow_sprite.width).to_f
          @shadow_sprite.zoom_y = @shadow_height
        end
      else
        @shadow_sprite.y = y - @shadow_sprite.height
        @shadow_sprite.zoom_x = (@cw / @shadow_sprite.width).to_f
      end
    else
      dispose_shadow if @shadow_sprite
    end
  end
 
  #--------------------------------------------------------------------------
  # * dispose_shadow : destroy
  #--------------------------------------------------------------------------
  def dispose_shadow
    if @shadow_sprite
      @shadow_sprite.dispose
      @shadow_sprite = nil
    end
  end
   
end #<--- End of Sprite_Character Class========================================
 

#==============================================================================
# ** Game_CharacterBase
#------------------------------------------------------------------------------
#  This base class handles characters. It retains basic information, such as
# coordinates and graphics, shared by all characters.
#==============================================================================

class Game_CharacterBase
 
  #--------------------------------------------------------------------------
  # * Public Instance Variables
  #--------------------------------------------------------------------------
  attr_accessor :shadow_on #check for character to see if it should have a shadow
  attr_accessor :shadow
  attr_accessor :shadow_size
 
  #--------------------------------------------------------------------------
  # * Initialize Public Member Variables
  #--------------------------------------------------------------------------
  alias :sydoshadow_shadow_game_characterbase_init_public_members :init_public_members
  def init_public_members
    sydoshadow_shadow_game_characterbase_init_public_members
    case
    when self.is_a?(Game_Player)
      @shadow = SYDOSHADOW::SHADOW::DEFAULT_ON_PLAYER
    when self.is_a?(Game_Follower)
      @shadow = SYDOSHADOW::SHADOW::DEFAULT_ON_FOLLOWER
    when self.is_a?(Game_Event)
      @shadow = SYDOSHADOW::SHADOW::DEFAULT_ON_EVENT
    end
    @shadow = false if @shadow.nil?
    @shadow_on = @shadow
    @shadow_size = 0
  end

  #--------------------------------------------------------------------------
  # * Frame Update
  #--------------------------------------------------------------------------
  alias :v_shadow_game_characterbase_update65465432 :update
  def update
    v_shadow_game_characterbase_update65465432
    if @shadow_on
      (bush? ? @shadow = false : @shadow = true) if SYDOSHADOW::SHADOW::Shadow_Off_In_Bush
      if @shadow == true
        if SYDOSHADOW::SHADOW::Use_Shadow_Off_Regions == true
          SYDOSHADOW::SHADOW::Shadow_Off_Region_Ids.each { |i|
            if region_id == i
              @shadow = false
            end
          }
        end
      end
    end
  end
 
end #<--- End of Game_CharacterBase Class======================================


#==============================================================================
# ** Game_Event
#------------------------------------------------------------------------------
#  This class handles events. Functions include event page switching via
# condition determinants and running parallel process events. Used within the
# Game_Map class.
#==============================================================================

class Game_Event < Game_Character
 
  #--------------------------------------------------------------------------
  # * Aliased Method: Set Up Event Page Settings
  #--------------------------------------------------------------------------
  alias :gesps35435435 :setup_page_settings
 
  #--------------------------------------------------------------------------
  # * Set Up Event Page Settings
  #--------------------------------------------------------------------------
  def setup_page_settings
    gesps35435435
    if @list[0].code == 108
      @shadow = true if @list[0].parameters[0] == "shadow_on"
      @shadow = false if @list[0].parameters[0] == "shadow_off"
      @shadow_on = @shadow
    end
  end
 
end #<--- End of Game_Event Class==============================================


#==============================================================================
# ** Game_Interpreter
#------------------------------------------------------------------------------
#  An interpreter for executing event commands. This class is used within the
# Game_Map, Game_Troop, and Game_Event classes.
#==============================================================================

class Game_Interpreter

  #--------------------------------------------------------------------------
  # * Shadow On
  #--------------------------------------------------------------------------
  def shadow_on
    $game_map.events[@event_id].shadow = true
    $game_map.events[@event_id].shadow_on = true
  end

  #--------------------------------------------------------------------------
  # * Shadow Off
  #--------------------------------------------------------------------------
  def shadow_off
    $game_map.events[@event_id].shadow = false
    $game_map.events[@event_id].shadow_on = false
  end

end #<--- End of Game_Interpreter Class========================================