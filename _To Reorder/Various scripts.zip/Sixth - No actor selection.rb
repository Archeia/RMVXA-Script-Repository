# Sixth - no Actor selection with item

# when i selecting an item the item will "heal" 
# for example automatically without having the actor menu to pop up?

class Window_ItemList < Window_Selectable

  def process_ok
    if current_item_enabled?
      Input.update
      deactivate
      call_ok_handler
    else
      Sound.play_buzzer
    end
  end

end

class Window_SkillList < Window_Selectable

  def process_ok
    if current_item_enabled?
      Input.update
      deactivate
      call_ok_handler
    else
      Sound.play_buzzer
    end
  end
 
end

class Scene_ItemBase < Scene_MenuBase

  def determine_item
    if item_usable?
      use_item
    else
      Sound.play_buzzer
    end
    activate_item_window
  end
 
end