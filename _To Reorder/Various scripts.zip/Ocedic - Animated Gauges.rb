# *****************************************************************************
#
# OC ANIMATED GAUGES
# Author: Ocedic
# Site: http://ocedic.wordpress.com/
# Version: 1.3b
# Last Updated: 3/16/13
#
# Updates:
# 1.3b - Rate methods are now aliased
# 1.3  - Now updates every two frames instead of every frame, update rate for
#        specific bars can be set
# 1.2  - Fixed a bug that prevented HP/MP comparison conditionals from
#        functioning correctly
# 1.1  - Rate change now works properly, added configuration option to disable
#        animation for specific bars
# 1.0  - First release
#
# *****************************************************************************

$imported = {} if $imported.nil?
$imported["OC-AnimatedGauges"] = true

#==============================================================================
# ▼ Introduction
# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# This script changes HP, MP and TP gauges to have a gradual adjustment rather
# than the default instantaneous feedback.
#==============================================================================
# ▼ Instructions
# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# Plug and play script. Simply paste it above Main. Settings can be adjusted
# in configuration section.
#==============================================================================
# ▼ Compatibility
# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# This script is designed to work for the Default Battle System and Yanfly's
# Battle Engine/Core Engine. Other custom gauge and battle systems may not be
# compatible.
#==============================================================================
# ▼ Terms of Use
# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# Can be freely used and modified in non-commercial projects. Proper attribution 
# must be given to Ocedic, and this header must be preserved.
# For commercial terms, see here: https://ocedic.wordpress.com/terms-of-use/
#==============================================================================

#==============================================================================
# ■ Configuration
#------------------------------------------------------------------------------
#  Change customizable settings here
#==============================================================================
module OC
  module GAUGE
    
#==============================================================================
# * Enable Rates *
#------------------------------------------------------------------------------
#   This allows you to turn off animated gauges for any of the supported bars.
#   To disable bar animation, simply set the corresponding switch to false.
#==============================================================================
  
    ENABLE_HP_RATE = true
    ENABLE_MP_RATE = true
    ENABLE_TP_RATE = true
  
#==============================================================================
# * Rate Change *
#------------------------------------------------------------------------------
#   Sets how much the gauge will change in each frame for each gauge type,
#   denoted in %.
#==============================================================================
# * Max TP *
#------------------------------------------------------------------------------
#   Input the max TP here if you use a custom value for max TP.
#==============================================================================
    RATE_CHANGE_HP = 0.03    # Default 0.03
    RATE_CHANGE_MP = 0.01    # Default 0.01
    RATE_CHANGE_TP = 0.02    # Default 0.02
    MAX_TP = 100             # Default 100
  
  end # BATTLE
end #OC
  
#==============================================================================
# ■ End of Configuration
#==============================================================================

#==============================================================================
# ■ Game_BattlerBase
#==============================================================================
class Game_BattlerBase
  
#==============================================================================
# * Accessors *
#==============================================================================
  attr_accessor :current_hp_rate                 
  attr_accessor :current_mp_rate              
  attr_accessor :current_tp_rate
  
#==============================================================================
# * Alias: Initialize *
#==============================================================================
  alias oc_game_battlerbase_initialize_nl2d9s initialize
  def initialize
    oc_game_battlerbase_initialize_nl2d9s
    @current_hp_rate = 1.0
    @current_mp_rate = 1.0
    @current_tp_rate = 1.0
  end    
  
end #class game_battlerbase

#==============================================================================
# ■ Game_Actor
#==============================================================================
class Game_Actor < Game_Battler
  
#==============================================================================
# * Alias: HP Rate *
#==============================================================================
  alias oc_game_actor_hp_rate_n43ps hp_rate
  def hp_rate
    if OC::GAUGE::ENABLE_HP_RATE && SceneManager.scene_is?(Scene_Battle)
      rate_diff = @hp.to_f / mhp - @current_hp_rate
      if rate_diff > 0
        @current_hp_rate += [OC::GAUGE::RATE_CHANGE_HP, rate_diff.abs / 5].min
      elsif rate_diff < 0
        @current_hp_rate -= [OC::GAUGE::RATE_CHANGE_HP, rate_diff.abs / 5].min
      end
      @current_hp_rate
    else
      oc_game_actor_hp_rate_n43ps
    end
  end 
  
#==============================================================================
# * Alias: MP Rate *
#==============================================================================
  alias oc_game_actor_mp_rate_a02sf mp_rate
  def mp_rate
    if OC::GAUGE::ENABLE_MP_RATE && SceneManager.scene_is?(Scene_Battle)
      return 0 if mmp == 0
      rate_diff = @mp.to_f / mmp - @current_mp_rate
      if rate_diff > 0
        @current_mp_rate += [OC::GAUGE::RATE_CHANGE_MP, rate_diff.abs / 5].min
      elsif rate_diff < 0
        @current_mp_rate -= [OC::GAUGE::RATE_CHANGE_MP, rate_diff.abs / 5].min
      end
      @current_mp_rate
    else
      oc_game_actor_mp_rate_a02sf
    end
  end  
  
#==============================================================================
# * Alias: TP Rate *
#==============================================================================
  alias oc_game_actor_tp_rate_03ldn tp_rate
  def tp_rate
    if OC::GAUGE::ENABLE_TP_RATE && SceneManager.scene_is?(Scene_Battle)
      rate_diff = @tp.to_f / OC::GAUGE::MAX_TP - @current_tp_rate
      if rate_diff > 0
        @current_tp_rate += [OC::GAUGE::RATE_CHANGE_TP, rate_diff.abs / 5].min
      elsif rate_diff < 0
        @current_tp_rate -= [OC::GAUGE::RATE_CHANGE_TP, rate_diff.abs / 5].min
      end
      @current_tp_rate
    else
      oc_game_actor_tp_rate_03ldn
    end
  end  
  
end #class game_actor

#==============================================================================
# ■ Window_BattleStatus
#==============================================================================

class Window_BattleStatus < Window_Selectable

#==============================================================================
# * New Method: Refresh Gauges *
#------------------------------------------------------------------------------
#   Updates the HP, MP and TP bars of Yanfly's Battle Status. This part is
#   isolated from the rest of Draw_Item in order to reduce lag by not having
#   to draw actor graphics every update
#==============================================================================   
  def refresh_gauges
    i = 0
    $game_party.battle_members.each do |member|
      rectwidth = contents.width / $game_party.max_battle_members
      rectx = i * rectwidth
      draw_actor_hp(member, rectx+2, line_height*2+11, rectwidth-4)
      if draw_tp?(member) && draw_mp?(member)
        dw = rectwidth/2-2
        dw += 1 if $imported["YEA-CoreEngine"] && YEA::CORE::GAUGE_OUTLINE
        draw_actor_tp(member, rectx+2, line_height*3, dw)
        dw = rectwidth - rectwidth/2 - 2
        draw_actor_mp(member, rectx+rectwidth/2, line_height*3, dw)
      elsif draw_tp?(member) && !draw_mp?(member)
        draw_actor_tp(member, rectx+2, line_height*3, rectwidth-4)
      else
        draw_actor_mp(member, rectx+2, line_height*3, rectwidth-4)
      end
      i += 1
    end    
  end
  
end #class window_battlestatus

#==============================================================================
# ■ Scene_Battle
#==============================================================================
class Scene_Battle < Scene_Base
  
#==============================================================================
# * Alias: Start *
#============================================================================== 
  alias oc_scene_battle_start_3njs9 start
  def start
    oc_scene_battle_start_3njs9
    $game_party.battle_members.each do |actor|
      actor.current_hp_rate = actor.hp.to_f / actor.mhp
      actor.current_mp_rate = actor.mp.to_f / actor.mmp
      actor.current_tp_rate = actor.tp.to_f / OC::GAUGE::MAX_TP
    end
  end
  
#==============================================================================
# * Alias: Update Basic *
#============================================================================== 
  alias oc_scene_battle_update_vj902 update_basic
  def update_basic
    oc_scene_battle_update_vj902
    @update_timer ||= 0
    @update_timer += 1
    return if @update_timer % 2 != 0
    if $imported["YEA-BattleEngine"]
      @status_window.refresh_gauges
    else
      @status_window.refresh
    end
  end
  
end #class scene_battle