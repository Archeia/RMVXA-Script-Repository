###########################################################
#Multiple Windowskins v 1.0
#by Crimson Rose
###########################################################
module CR_MultipleWindowSkins 
#The Skin that is used for any windows other than the ones listed below. 
#Included for compatibility. Do not remove, but feel free to change the 
#windowskin given. 
DEFAULT_WINDOW_SKIN = "Window" 
#If this is true, then you don't need to bother with the next array. 
ALL_DEFAULT = false 
$windowskins = [ "Window", 
#Help Window 
"Window", 
#Gold Window 
"Window2", 
#Menu Command 
"Window", 
#Window_MenuStatus 
"Window", 
#Window_MenuActor 
"Window", 
#Window_ItemCategory 
"Window", 
#Window_ItemList 
"Window", 
#Window_SkillCommand 
"Window", 
#Window_SkillStatus 
"Window", 
#Window_SkillList 
"Window", 
#Window_EquipStatus 
"Window", 
#Window_EquipCommand 
"Window", 
#Window_EquipSlot 
"Window", 
#Window_EquipItem 
"Window", 
#Window_Status 
"Window", 
#Window_SaveFile 
"Window", 
#Window_ShopCommand 
"Window", 
#Window_ShopBuy 
"Window", 
#Window_ShopSell 
"Window", 
#Window_ShopNumber 
"Window", 
#Window_ShopStatus 
"Window", 
#Window_NameEdit 
"Window", 
#Window_NameInput 
"Window", 
#Window_ChoiceList 
"Window", 
#Window_NumberInput 
"Window", 
#Window_KeyItem 
"Window", 
#Window_Message 
"Window", 
#Window_ScrollText 
"Window", 
#Window_MapName 
"Window", 
#Window_BattleLog 
"Window", 
#Window_PartyCommand 
"Window", 
#Window_ActorCommand 
"Window", 
#Window_BattleStatus 
"Window", 
#Window_BattleActor 
"Window", 
#Window_BattleEnemy 
"Window", 
#Window_BattleSkill 
"Window", 
#Window_BattleItem 
"Window", 
#Window_TitleCommand 
"Window", 
#Window_GameEnd 
"Window" 
#Skin no. 39 
] 
#If you wish to add more for custom windows, just 
#extend the array to include them and make sure to 
#pass the name of the windowskin to the Window's parent. 
#The last element in this array is 38, so any more windows 
#that you would add would be greater or equal to 39. 
#Just add your windowskin to the array, and when calling super in your 
#new window, make sure to pass the following variable at the end of the other 
#variables you're giving: 
#CR_MultipleWindowSkins::getSkin(the windowskin position in the array) 
##### DO NOT EDIT PAST THIS POINT UNLESS YOU KNOW WHAT YOU ARE DOING! 
def self.getSkin(num) 
return $windowskins[num] unless ALL_DEFAULT 
return DEFAULT_WINDOW_SKIN 
end
end 

class Window_Base < Window alias 
CR_MultipleWindowSkins_WindowBase_Initialize initialize 
def initialize(x, y, width, height, skin = CR_MultipleWindowSkins::DEFAULT_WINDOW_SKIN)
 CR_MultipleWindowSkins_WindowBase_Initialize(x,y,width,height) 
 self.windowskin = Cache.system(skin) 
 end 
 end
 
 class Window_Selectable < Window_Base 
 #-------------------------------------------------------------------------- 
 # * Object Initialization 
 #------------------------------------------------------------------------- 
 def initialize(x, y, width, height, skin=CR_MultipleWindowSkins::DEFAULT_WINDOW_SKIN) 
 super(x,y,width,height,skin) 
 @index = -1 
 @handler = {} 
 @cursor_fix = false 
 @cursor_all = false 
 update_padding 
 deactivate 
 end
 end
 
 class Window_Command < Window_Selectable 
 def initialize(x, y, skin = CR_MultipleWindowSkins::DEFAULT_WINDOW_SKIN) 
 clear_command_list 
 make_command_list 
 super(x,y,window_width,window_height,skin) 
 refresh 
 select(0) 
 activate 
 end
 end
 
 ###################################################
 class Window_Help < Window_Base 
 #-------------------------------------------------------------------------- 
 # * Object Initialization 
 #-------------------------------------------------------------------------- 
 def initialize(line_number = 2, skin = CR_MultipleWindowSkins::getSkin(0)) 
 super(0, 0, Graphics.width, fitting_height(line_number), skin) 
 end
 end
 
 class Window_Gold < Window_Base 
 #-------------------------------------------------------------------------- 
 # * Object Initialization 
 #-------------------------------------------------------------------------- 
 def initialize(skin = CR_MultipleWindowSkins::getSkin(1)) 
 super(0, 0, window_width, fitting_height(1),skin) 
 refresh 
 end
 end
 
 class Window_MenuCommand < Window_Command 
 #-------------------------------------------------------------------------- 
 # * Object Initialization #-------------------------------------------------------------------------- 
 def initialize(skin = CR_MultipleWindowSkins::getSkin(2)) 
 super(0, 0, skin) 
 select_last 
 end
 end
 
 class Window_MenuStatus < Window_Selectable 
 #-------------------------------------------------------------------------- 
 # * Public Instance Variables 
 #-------------------------------------------------------------------------- 
 attr_reader  :pending_index 
 # Pending position (for formation) 
 #-------------------------------------------------------------------------- 
 # * Object Initialization 
 #-------------------------------------------------------------------------- 
 def initialize(x, y, skin = CR_MultipleWindowSkins::getSkin(3)) 
 super(x, y, window_width, window_height, skin) 
 @pending_index = -1 
 refresh 
 end
 end
 
 class Window_MenuActor < Window_MenuStatus 
 #-------------------------------------------------------------------------- 
 # * Object Initialization 
 #-------------------------------------------------------------------------- 
 def initialize (skin = CR_MultipleWindowSkins::getSkin(4)) 
 super(0, 0, skin) 
 self.visible = false 
 end
 end
 
 class Window_ItemCategory < Window_HorzCommand 
 def initialize(skin = CR_MultipleWindowSkins::getSkin(5)) 
 super(0, 0, skin) 
 end
 end
 
 class Window_ItemList < Window_Selectable 
 #-------------------------------------------------------------------------- 
 # * Object Initialization 
 #-------------------------------------------------------------------------- 
 def initialize(x, y, width, height, skin = CR_MultipleWindowSkins::getSkin(6)) 
 super(x,y,width,height, skin) 
 @category = :none 
 @data = [] 
 end
 end
 
 class Window_SkillCommand < Window_Command 
 def initialize(x, y, skin = CR_MultipleWindowSkins::getSkin(7)) 
 super(x, y, skin) 
 @actor = nil 
 end
 end
 
 class Window_SkillStatus < Window_Base 
 #-------------------------------------------------------------------------- 
 # * Object Initialization 
 #-------------------------------------------------------------------------- 
 def initialize(x, y, skin = CR_MultipleWindowSkins::getSkin(8)) 
 super(x, y, window_width, fitting_height(4), skin) 
 @actor = nil 
 end
 end
 
 class Window_SkillList < Window_Selectable 
 #-------------------------------------------------------------------------- 
 # * Object Initialization 
 #-------------------------------------------------------------------------- 
 def initialize(x, y, width, height, skin = CR_MultipleWindowSkins::getSkin(9)) 
 super(x,y,width,height, skin) 
 @actor = nil 
 @stype_id = 0 
 @data = [] 
 end
 end
 
 class Window_EquipStatus < Window_Base 
 #-------------------------------------------------------------------------- 
 # * Object Initialization 
 #-------------------------------------------------------------------------- 
 def initialize(x, y, skin = CR_MultipleWindowSkins::getSkin(10)) 
 super(x, y, window_width, window_height, skin) 
 @actor = nil 
 @temp_actor = nil 
 refresh 
 end
 end
 
 class Window_EquipCommand < Window_HorzCommand 
 #-------------------------------------------------------------------------- 
 # * Object Initialization 
 #-------------------------------------------------------------------------- 
 def initialize(x, y, width, skin=CR_MultipleWindowSkins::getSkin(11)) 
 @window_width = width 
 super(x, y, skin) 
 end
 end
 
 class Window_EquipSlot < Window_Selectable 
 def initialize(x, y, width, skin = CR_MultipleWindowSkins::getSkin(12)) 
 super(x, y, width, window_height, skin) 
 @actor = nil 
 refresh 
 end
 end
 class Window_EquipItem < Window_ItemList 
 def initialize(x, y, width, height, skin = CR_MultipleWindowSkins::getSkin(13)) 
 super(x,y,width,height, skin) 
 @actor = nil 
 @slot_id = 0 
 end
 end
 
 class Window_Status < Window_Selectable 
 #-------------------------------------------------------------------------- 
 # * Object Initialization 
 #-------------------------------------------------------------------------- 
 def initialize(actor, skin=CR_MultipleWindowSkins::getSkin(14)) 
 super(0, 0, Graphics.width, Graphics.height, skin) 
 @actor = actor 
 refresh 
 activate 
 end
 end
 
 class Window_SaveFile < Window_Base 
 def initialize(height, index, skin = CR_MultipleWindowSkins::getSkin(15)) 
 super(0, index * height, Graphics.width, height, skin) 
 @file_index = index 
 refresh 
 @selected = false 
 end
 end
 
 class Window_ShopCommand < Window_HorzCommand 
 #-------------------------------------------------------------------------- 
 # * Object Initialization 
 #-------------------------------------------------------------------------- 
 def initialize(window_width, purchase_only, skin = CR_MultipleWindowSkins::getSkin(16)) 
 @window_width = window_width 
 @purchase_only = purchase_only 
 super(0, 0, skin) 
 end
 end
 
 class Window_ShopBuy < Window_Selectable 
 def initialize(x, y, height, shop_goods, skin = CR_MultipleWindowSkins::getSkin(17)) 
 super(x, y, window_width, height, skin) 
 @shop_goods = shop_goods 
 @money = 0 
 refresh 
 select(0) 
 end
 end
 
 class Window_ShopSell < Window_ItemList 
 #-------------------------------------------------------------------------- 
 # * Object Initialization 
 #-------------------------------------------------------------------------- 
 def initialize(x, y, width, height, skin = CR_MultipleWindowSkins::getSkin(18)) 
 super(x, y, width, height, skin) 
 end
 end
 
 class Window_ShopNumber < Window_Selectable 
 def initialize(x, y, height, skin = CR_MultipleWindowSkins::getSkin(19)) 
 super(x, y, window_width, height, skin) 
 @item = nil 
 @max = 1 
 @price = 0 
 @number = 1 
 @currency_unit = Vocab::currency_unit 
 end
 end
 
 class Window_ShopStatus < Window_Base 
 #-------------------------------------------------------------------------- 
 # * Object Initialization 
 #-------------------------------------------------------------------------- 
 def initialize(x, y, width, height, skin = CR_MultipleWindowSkins::getSkin(20)) 
 super(x, y, width, height, skin) 
 @item = nil 
 @page_index = 0 
 refresh 
 end
 end
 
 class Window_NameEdit < Window_Base 
 def initialize(actor, max_char, skin = CR_MultipleWindowSkins::getSkin(21)) 
 x = (Graphics.width - 360) / 2 
 y = (Graphics.height - (fitting_height(4) + fitting_height(9) + 8)) / 2 
 super(x, y, 360, fitting_height(4), skin) 
 @actor = actor 
 @max_char = max_char 
 @default_name = @name = actor.name[0, @max_char] 
 @index = @name.size 
 deactivate 
 refresh 
 end
 end
 
 class Window_NameInput < Window_Selectable 
 def initialize(edit_window, skin = CR_MultipleWindowSkins::getSkin(22)) 
 super(edit_window.x, edit_window.y + edit_window.height + 8, edit_window.width, fitting_height(9), skin) 
 @edit_window = edit_window 
 @page = 0 
 @index = 0 
 refresh 
 update_cursor 
 activate 
 end
 end
 
 class Window_ChoiceList < Window_Command 
 #-------------------------------------------------------------------------- 
 # * Object Initialization 
 #-------------------------------------------------------------------------- 
 def initialize(message_window,skin=CR_MultipleWindowSkins::getSkin(23)) 
 @message_window = message_window 
 super(0, 0, skin) 
 self.openness = 0 
 deactivate 
 end
 end
 
 class Window_NumberInput < Window_Base 
 #-------------------------------------------------------------------------- 
 # * Object Initialization 
 #-------------------------------------------------------------------------- 
 def initialize(message_window, skin=CR_MultipleWindowSkins::getSkin(24)) 
 @message_window = message_window 
 super(0, 0, 0, 0, skin) 
 @number = 0 
 @digits_max = 1 
 @index = 0 
 self.openness = 0 
 deactivate 
 end
 end
 
 class Window_KeyItem < Window_ItemList 
 #-------------------------------------------------------------------------- 
 # * Object Initialization 
 #-------------------------------------------------------------------------- 
 def initialize(message_window, skin=CR_MultipleWindowSkins::getSkin(25)) 
 @message_window = message_window 
 super(0, 0, Graphics.width, fitting_height(4), skin) 
 self.openness = 0 
 deactivate 
 set_handler(:ok, method(:on_ok)) 
 set_handler(:cancel, method(:on_cancel)) 
 end
 end
 
 class Window_Message < Window_Base 
 #-------------------------------------------------------------------------- 
 # * Object Initialization 
 #-------------------------------------------------------------------------- 
 def initialize(skin = CR_MultipleWindowSkins::getSkin(26)) 
 super(0, 0, window_width, window_height, skin) 
 self.z = 200 
 self.openness = 0 
 create_all_windows 
 create_back_bitmap 
 create_back_sprite 
 clear_instance_variables 
 end
 end
 
 class Window_ScrollText < Window_Base 
 #-------------------------------------------------------------------------- 
 # * Object Initialization 
 #-------------------------------------------------------------------------- 
 def initialize(skin = CR_MultipleWindowSkins::getSkin(27)) 
 super(0, 0, Graphics.width, Graphics.height, skin) 
 self.opacity = 0 
 self.arrows_visible = false 
 hide 
 end
 end
 
 class Window_MapName < Window_Base 
 #-------------------------------------------------------------------------- 
 # * Object Initialization 
 #-------------------------------------------------------------------------- 
 def initialize(skin = CR_MultipleWindowSkins::getSkin(28)) 
 super(0, 0, window_width, fitting_height(1), skin) 
 self.opacity = 0 
 self.contents_opacity = 0 
 @show_count = 0 
 refresh 
 end
 end
 
 class Window_BattleLog < Window_Selectable 
 #-------------------------------------------------------------------------- 
 # * Object Initialization 
 #-------------------------------------------------------------------------- 
 def initialize(skin = CR_MultipleWindowSkins::getSkin(29)) 
 super(0, 0, window_width, window_height, skin) 
 self.z = 200 
 self.opacity = 0 
 @lines = [] 
 @num_wait = 0 
 create_back_bitmap 
 create_back_sprite 
 refresh 
 end
 end
 
 class Window_PartyCommand < Window_Command 
 #-------------------------------------------------------------------------- 
 # * Object Initialization 
 #-------------------------------------------------------------------------- 
 def initialize(skin = CR_MultipleWindowSkins::getSkin(30)) 
 super(0, 0, skin) 
 self.openness = 0 
 deactivate 
 end
 end
 
 class Window_ActorCommand < Window_Command 
 #-------------------------------------------------------------------------- 
 # * Object Initialization 
 #-------------------------------------------------------------------------- 
 def initialize(skin = CR_MultipleWindowSkins::getSkin(31)) 
 super(0, 0, skin) 
 self.openness = 0 
 deactivate 
 @actor = nil 
 end
 end
 
 class Window_BattleStatus < Window_Selectable 
 #-------------------------------------------------------------------------- 
 # * Object Initialization 
 #-------------------------------------------------------------------------- 
 def initialize(skin = CR_MultipleWindowSkins::getSkin(32)) 
 super(0, 0, window_width, window_height, skin) 
 refresh 
 self.openness = 0 
 end
 end
 
 class Window_BattleActor < Window_BattleStatus 
 #-------------------------------------------------------------------------- 
 # * Object Initialization 
 # info_viewport : Viewport for displaying information 
 #-------------------------------------------------------------------------- 
 def initialize(info_viewport, skin = CR_MultipleWindowSkins::getSkin(33)) 
 super(skin) 
 self.y = info_viewport.rect.y 
 self.visible = false 
 self.openness = 255 
 @info_viewport = info_viewport 
 end
 end
 
 class Window_BattleEnemy < Window_Selectable 
 #-------------------------------------------------------------------------- 
 # * Object Initialization 
 # info_viewport : Viewport for displaying information 
 #-------------------------------------------------------------------------- 
 def initialize(info_viewport, skin = CR_MultipleWindowSkins::getSkin(34)) 
 super(0, info_viewport.rect.y, window_width, fitting_height(4), skin) 
 refresh 
 self.visible = false 
 @info_viewport = info_viewport 
 end
 end
 
 class Window_BattleSkill < Window_SkillList 
 #-------------------------------------------------------------------------- 
 # * Object Initialization 
 # info_viewport : Viewport for displaying information #-------------------------------------------------------------------------- 
 def initialize(help_window, info_viewport, skin=CR_MultipleWindowSkins::getSkin(35)) 
 y = help_window.height 
 super(0, y, Graphics.width, info_viewport.rect.y - y, skin) 
 self.visible = false 
 @help_window = help_window 
 @info_viewport = info_viewport 
 end
 end
 
 class Window_BattleItem < Window_ItemList 
 #-------------------------------------------------------------------------- 
 # * Object Initialization 
 # info_viewport : Viewport for displaying information 
 #-------------------------------------------------------------------------- 
 def initialize(help_window, info_viewport, skin = CR_MultipleWindowSkins::getSkin(36)) 
 y = help_window.height 
 super(0, y, Graphics.width, info_viewport.rect.y - y, skin) 
 self.visible = false 
 @help_window = help_window 
 @info_viewport = info_viewport 
 end
 end
 
 class Window_TitleCommand < Window_Command 
 #-------------------------------------------------------------------------- 
 # * Object Initialization 
 #-------------------------------------------------------------------------- 
 def initialize(skin = CR_MultipleWindowSkins::getSkin(37)) 
 super(0, 0, skin) 
 update_placement 
 select_symbol(:continue) 
 if continue_enabled 
 self.openness = 0 
 open 
 end 
 end
 
 class Window_GameEnd < Window_Command 
 #-------------------------------------------------------------------------- 
 # * Object Initialization 
 #-------------------------------------------------------------------------- 
 def initialize(skin = CR_MultipleWindowSkins::getSkin(38)) 
 super(0, 0, skin) 
 update_placement 
 self.openness = 0 
 open 
 end
 end