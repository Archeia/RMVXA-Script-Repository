
=begin
Sugh's Hidden Items & Skills
This is a very simple script to hide skills and items based on a switch.
It requires Skyval's Note Tagging system.
Instructions:
Notetags:

   :hide_me
       this will cause the item/skill to be hidden if the selected switch is ON.
       
   :hide_me_sw => X
       replace X with a number. Regardless of type, the skill or item will be 
       hidden if the switch X is turned ON.

Configuration:

SWITCH_HIDE_ALL = X -> replace X with the switch number you want to
 hide tagged items/skills
SWITCH_HIDE_SKILL = X -> replace X with a switch number that when
 activated will affect only skills, but not items.
SWITCH_HIDE_ITEM = X -> same as above, but works only for items. 
       
Author: Sughayyer
Based on: Skyval notes system and Evaan's request.
Credits: Skyval for the notes system and Sughayyer for the script.

=end
module SUGH
 module HIDE_ITEMS
  #choose the switch that will determine the item's presence.
  SWITCH_HIDE_ALL =  1
  SWITCH_HIDE_SKILL = 2
  SWITCH_HIDE_ITEM = 3
 end
end
 
class Window_SkillList < Window_Selectable

#new method: is_hidden?
  def is_hidden?(item)
    return true if item.note_field.include?(:hide_me)
    return true if $game_switches[SUGH::HIDE_ITEMS::SWITCH_HIDE_ALL]
    return true if $game_switches[SUGH::HIDE_ITEMS::SWITCH_HIDE_SKILL]
    if item.note_field[:hide_me_sw]
     return true if $game_switches[item.note_field[:hide_me_sw]]
    end
    return false
  end
  
#overwritten method: include?     
 def include?(item)
   item && item.stype_id == @stype_id && !is_hidden?(item)
 end
  
  
end #class Window_SkillList
 
class Window_ItemList < Window_Selectable

#new method: is_hidden?
  def is_hidden?(item)
    return true if item.note_field.include?(:hide_me)
    return true if $game_switches[SUGH::HIDE_ITEMS::SWITCH_HIDE_ALL]
    return true if $game_switches[SUGH::HIDE_ITEMS::SWITCH_HIDE_SKILL]
    if item.note_field[:hide_me_sw]
     return true if $game_switches[item.note_field[:hide_me_sw]]
    end
    return false
  end
  
 #overwritten method: include?
  def include?(item)
    case @category
    when :item
      item.is_a?(RPG::Item) && !item.key_item? && !is_hidden?(item)
    when :weapon
      item.is_a?(RPG::Weapon) && !is_hidden?(item)
    when :armor
      item.is_a?(RPG::Armor) && !is_hidden?(item)
    when :key_item
      item.is_a?(RPG::Item) && item.key_item? && !is_hidden?(item)
    else
      false
    end
  end
end #class Window_ItemList