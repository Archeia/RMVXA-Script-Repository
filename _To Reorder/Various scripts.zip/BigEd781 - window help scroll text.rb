# Original VX script by BigEd781
# Converted for VX Ace by Xypher
# Script is provided as is
# ------------------------------
# Heavy edit by Sixth
# ------------------------------
class Window_Help < Window_Base
 
  @@SCROLL_DELAY = 2 # seconds
  @@SCROLL_SPEED = 1 # pixels / frame (60 frames / sec)
 
  alias :scroll_init :initialize
  def initialize(*args)
    @tdt = {:x => 0, :y => 0, :w => 1, :h => 1}
    scroll_init(*args)
    @count = 0
    @dir = 1
    @long = false
    #self.windowskin = $game_system.window_skin_bitmap(self.class)
  end
 
  def get_altered_skin # No idea what's this for...
    default = Cache.system('Window')
    window = Bitmap.new(default.width, default.height)
    window.blt(0, 0, default, default.rect)
    window.fill_rect(80, 16, 32, 32, Color.new(0,0,0,0))
    return window
  end
 
  def winw
    return self.width - standard_padding * 2
  end
 
  def winh
    return self.height - standard_padding * 2
  end
 
  def set_text(text, align = 0)
    unless (text == @text) && (align == @align)
      @text = text
      @align = align
      @count = 0
      @fake = true
      refresh
      @fake = false
      tw = @tdt[:x] + @tdt[:w]
      th = @tdt[:y] + @tdt[:h]
      @long = tw > winw
      self.contents.dispose
      cw = @long ? tw : winw
      self.contents = Bitmap.new(cw, winh)
      self.ox = 0
      refresh
    end
  end
 
  def update
    super
    return unless @long
    if @count >= @@SCROLL_DELAY * 60
      if self.ox <= 0 && @dir < 0
        @dir = 1; @count = 0
      elsif self.ox >= contents.width - winw && @dir > 0
        @dir = -1; @count = 0
      else
        self.ox += @dir * @@SCROLL_SPEED
      end
    else
      @count += 1
    end
  end
    
  def draw_text_ex(x, y, text)
    @tdt = {:x => x, :y => y, :w => 0, :h => 0}
    super
  end
    
  def process_normal_character(c, pos)
    if @fake
      #return unless c >= ' ' Only enable this line if you use LoneWolf's character fix!
      text_width = text_size(c).width
      pos[:x] += text_width
      @tdt[:w] = pos[:x] if @tdt[:w] < pos[:x]
      @tdt[:h] = pos[:y] + pos[:height]
    else
      super
    end
  end

end