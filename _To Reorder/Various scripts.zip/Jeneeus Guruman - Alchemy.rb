#==============================================================================
# ** Alchemy System
# by: Jeneeus Guruman
#------------------------------------------------------------------------------
#  This script allows to:
#     - Create items, weapons, and armors via using skills or items with a 
#     success rate based on the user's parameters, $game_variables, etc. 
#
#   How to use:
#
#     * Plug-n-play
#     * Place this below default and non-aliased scripts.
#     * Only usable outside the battle. Therefore, the occasion must be set to 
#     "only from the menu" or the skill/item won't work.
#     * When using an item creation SKILL, the scope must be set to "none" or 
#     the skill won't work.
#     * When using an item creation ITEM, the scope must be set to either 
#     "one ally" or "user" or the item won't work.
#       
#       <alchemy>
#         * Using the skill or item will activate item creation scene.
#
#     * Note: Place this notetag to the skill or item that opens the 
#       alchemy scene.
#
#       <alche_ireq: type, id, amount>
#       type: the type of item
#         0 = Items ($data_items)
#         1 = Weapons ($data_weapons)
#         2 = Armors ($data_armors)
#       id: the id of an item/weapon/armor in the database
#       amount: the amount of the specified item needed to create this item
#       Notetag examples: 
#         <alche_ireq: 0, 1, 2>  => An item needs to have at least 2 "Potions"
#       in the inventory to create this item.
#
#     * Note: If you put more than 1 requirement, the item can be made if ALL of 
#       the items is in the party's inventory.
#
#       <alche_areq: id>
#       id: the actor that will able to exclusively create the item.
#
#     * Note: This notetag is optional. If this is not specified, all actors 
#       that have the ability can create this item.
#
#       <alche_lreq: n>
#       n: the required level to create this item. the item will not be shown 
#       if the level is below the requirement.
#
#     * Note: This notetag is required or the item will not be shown.
#
#       <alche_greq: n>
#       n: the required gold to create this item.
#
#     * Note: This notetag is optional. If this is not specified, no gold is
#       needed.
#
#       <success_rate: 'formula'>
#       formula: The formula for calculating the creation success rate.
#       The formula is the same as the formula in skill damage except that 
#       there is no target (which is supposed to be expressed as 'b').
#       Take note that the quotations (') are included to make it work.
#       Also multiple lines of one fourmula are allowed.
#       Notetag examples: 
#         <alche_success>: 'a.level + a.luk / 10'>  
#       => If the user's level is 50 having 300 LUK, the success rate will have
#       80% chance to make this item, provided that the maximum success rate is 100.
#         <alche_success: '100'>  
#       => The item has 100% chance to create this, provided that the maximum success rate is 100.
#
#     * Note: This notetag is required. To display the decimal parts, put #.0
#     (if it is a whole number) or variable.to_f (if it is a variable). 
#     For example, <success_rate: 'a.level.to_f + a.luk.to_f / 10.0'>
#
#==============================================================================

module Jene
  #--------------------------------------------------------------------------
  # * BASE_SUCCESS
  #     Minimum success rate chance.
  #--------------------------------------------------------------------------
  BASE_SUCCESS = 0
  #--------------------------------------------------------------------------
  # * MAX_SUCCESS
  #     The target success rate to have sure creation. Take note that it needs
  #   to be higher than BASE_SUCCESS.
  #--------------------------------------------------------------------------
  MAX_SUCCESS = 100
  #--------------------------------------------------------------------------
  # * CREATION_TIME
  #     The time in frames that the item creation will be done. 
  #   60 frames = 1 second
  #--------------------------------------------------------------------------
  CREATION_TIME = 60
  #--------------------------------------------------------------------------
  # * CREATION_NAME
  #     The text to be displayed during CREATION_TIME.
  #--------------------------------------------------------------------------
  CREATION_NAME = 'Creating Item'
  #--------------------------------------------------------------------------
  # * CREATION_FAIL_NAME
  #     The text to be displayed if failed.
  #--------------------------------------------------------------------------
  CREATION_FAIL_NAME = 'EPIC FAIL!!!'
  #--------------------------------------------------------------------------
  # * CREATION_SUCCESS_NAME
  #     The text to be displayed if successful.
  #--------------------------------------------------------------------------
  CREATION_SUCCESS_NAME = 'SO MUCH WIN!!!'
  #--------------------------------------------------------------------------
  # * CREATION_SOUND
  #     The ME to play while creating an item. This will not be played if the
  #   CREATION_TIME is less than 30 frames.
  #--------------------------------------------------------------------------
  CREATION_SOUND = 'Bell2'
  #--------------------------------------------------------------------------
  # * CREATION_FAIL_SOUND
  #     The ME to play if item creation fails.
  #--------------------------------------------------------------------------
  CREATION_FAIL_SOUND = 'Break'
  #--------------------------------------------------------------------------
  # * CREATION_SUCCESS_SOUND
  #     The ME to play if item creation is successful.
  #--------------------------------------------------------------------------
  CREATION_SUCCESS_SOUND = 'Item3'
  
#----------------------------------------------------------------------------
# * Do not edit anything below here. Or else, evil errors will be released 
# from the other dimension of evil.
#----------------------------------------------------------------------------

  JENE_ALCHEMY = /<alchemy>/i
  ALCHE_SUCCESS_RATE = /<alche_success[:]?\s+'([\s\S]*)'>/i
  ALCHE_LEVEL_REQ = /<alche_lreq[:]?\s+(\d+)>/i
  ALCHE_GOLD_REQ = /<alche_greq[:]?\s+(\d+)>/i
  ALCHE_ACTOR_REQ = /<alche_areq[:]?\s+(\d+)>/i
  ALCHE_ITEM_REQ = /<alche_ireq[:]?\s*(\d+)\s*[,]?\s*(\d+)\s*[,]?\s*(\d+)>/i

  def self.alche_creation_se
    Audio.se_play("Audio/SE/" + CREATION_SOUND) 
  end
  
  def self.alche_fail_se
    Audio.se_play("Audio/SE/" + CREATION_FAIL_SOUND) 
  end
  
  def self.alche_success_se
    Audio.se_play("Audio/SE/" + CREATION_SUCCESS_SOUND) 
  end
  
  def self.success_rate(f, a, v)
    [[eval(f), BASE_SUCCESS].max, MAX_SUCCESS].min rescue BASE_SUCCESS
  end
end

class RPG::Item
  
  def alche_success(actor)
    self.note.each_line { |line|
      if line =~ Jene::ALCHE_SUCCESS_RATE
        return Jene.success_rate($1, actor, $game_variables)
      end
    }
    return Jene::BASE_SUCCESS
  end
  
  def alche_ireq
    bonus_arr = []
    self.note.each_line { |line|
      if line =~ Jene::ALCHE_ITEM_REQ
        bonus_arr.push([$1.to_i, $2.to_i, $3.to_i])
      end
    }
    return bonus_arr
  end
  
  def alche_lreq
    self.note.each_line { |line|
      if line =~ Jene::ALCHE_LEVEL_REQ
        return $1.to_i
      end
    }
    return 0
  end
  
  def alche_areq
    bonus_arr = []
    self.note.each_line { |line|
      if line =~ Jene::ALCHE_ACTOR_REQ
        return bonus_arr.push($1.to_i)
      end
    }
    return bonus_arr
  end
  
  def alche_greq
    self.note.each_line { |line|
      if line =~ Jene::ALCHE_GOLD_REQ
        return $1.to_i
      end
    }
    return 0
  end
end

class RPG::EquipItem
  
  def alche_success(actor)
    self.note.each_line { |line|
      if line =~ Jene::ALCHE_SUCCESS_RATE
        return Jene.success_rate($1, actor, $game_variables)
      end
    }
    return Jene::BASE_SUCCESS
  end
  
  def alche_ireq
    bonus_arr = []
    self.note.each_line { |line|
      if line =~ Jene::ALCHE_ITEM_REQ
        bonus_arr.push([$1.to_i, $2.to_i, $3.to_i])
      end
    }
    return bonus_arr
  end
  
  def alche_lreq
    self.note.each_line { |line|
      if line =~ Jene::ALCHE_LEVEL_REQ
        return $1.to_i
      end
    }
    return 0
  end
  
  def alche_areq
    bonus_arr = []
    self.note.each_line { |line|
      if line =~ Jene::ALCHE_ACTOR_REQ
        return bonus_arr.push($1.to_i)
      end
    }
    return bonus_arr
  end
  
  def alche_greq
    self.note.each_line { |line|
      if line =~ Jene::ALCHE_GOLD_REQ
        return $1.to_i
      end
    }
    return 0
  end
end

class RPG::UsableItem
  def alchemy?
    self.note.each_line { |line|
      if line =~ Jene::JENE_ALCHEMY
        return true
      end
    }
    return false
  end
end

#==============================================================================
# ** Game_BattlerBase
#------------------------------------------------------------------------------
#  This base class handles battlers. It mainly contains methods for calculating
# parameters. It is used as a super class of the Game_Battler class.
#==============================================================================

class Game_Actor < Game_Battler
  #--------------------------------------------------------------------------
  # * Determine Skill/Item Usability
  #--------------------------------------------------------------------------
  alias jene_alche_usable? usable?
  def usable?(item)
    return true if item.is_a?(RPG::UsableItem) && alche_any? && actor? && item.alchemy?
    jene_alche_usable?(item)
  end
  #--------------------------------------------------------------------------
  # * Check If Any Item Creation Exists
  #--------------------------------------------------------------------------
  def alche_any?
    items = []
    $data_items.each do |i|
      next if i == nil
      if i.alche_lreq <= level && i.alche_lreq > 0
        items.push(i)
      end
    end
    !items.empty?
  end
end

#==============================================================================
# ** Window_Gold
#------------------------------------------------------------------------------
#  This window displays the party's gold.
#==============================================================================

class Window_AlcheLoad < Window_Base
  #--------------------------------------------------------------------------
  # * Object Initialization
  #--------------------------------------------------------------------------
  def initialize
    x = (Graphics.width - window_width) / 2
    y = (Graphics.height - window_height) / 2
    super(x, y, window_width, window_height)
    @text = Jene::CREATION_NAME + "..."
    @loaded = 0.0
    @start = false
    @item = nil
    @success_rate = Jene::BASE_SUCCESS
  end
  #--------------------------------------------------------------------------
  # * Get Window Width
  #--------------------------------------------------------------------------
  def window_width
    return Graphics.width / 2
  end
  #--------------------------------------------------------------------------
  # * Get Window Width
  #--------------------------------------------------------------------------
  def window_height
    return fitting_height(2)
  end
  #--------------------------------------------------------------------------
  # * Check Loading
  #--------------------------------------------------------------------------
  def loading?
    @start
  end
  #--------------------------------------------------------------------------
  # * Check Loading
  #--------------------------------------------------------------------------
  def done_loading?
    !@start && @loaded > 0
  end
  #--------------------------------------------------------------------------
  # * Start Loading
  #--------------------------------------------------------------------------
  def start_loading(item)
    @loaded = 0.0
    @start = true
    @item = item
  end
  #--------------------------------------------------------------------------
  # * Get Window Width
  #--------------------------------------------------------------------------
  def text=(text)
    @text = text
  end
  #--------------------------------------------------------------------------
  # * Set Success Rate
  #--------------------------------------------------------------------------
  def set_success
    @success_rate = rand(Jene::MAX_SUCCESS)
  end
  #--------------------------------------------------------------------------
  # * Get Success Rate
  #--------------------------------------------------------------------------
  def success?
    return false if @item == nil
    actor = SceneManager.scene.previous_scene.is_a?(Scene_Skill) ? 
      $game_party.menu_actor : $game_party.target_actor
    @item.alche_success(actor) > @success_rate
  end
  #--------------------------------------------------------------------------
  # * Frame Update
  #--------------------------------------------------------------------------
  def update
    super
    update_progress if @start
  end
  #--------------------------------------------------------------------------
  # * Update Item Creation Processing
  #--------------------------------------------------------------------------
  def update_progress
    contents.clear
    pw = window_width - 24
    if @loaded >= pw
      @start = false
      set_success
      if success?
        Jene.alche_success_se
        @text = Jene::CREATION_SUCCESS_NAME
      else
        Jene.alche_fail_se
        @text = Jene::CREATION_FAIL_NAME
      end
    else
      @loaded += pw.to_f / [Jene::CREATION_TIME.to_f, 1.0].max
    end
    draw_text(4, 0, pw, line_height, @text, 1)
    rate = [@loaded / pw, 1].min
    draw_gauge(4, line_height + 4, pw, rate, system_color, normal_color)
  end
end

#==============================================================================
# ** Game_Battler
#------------------------------------------------------------------------------
#  A battler class with methods for sprites and actions added. This class 
# is used as a super class of the Game_Actor class and Game_Enemy class.
#==============================================================================

class Game_Battler < Game_BattlerBase
  #--------------------------------------------------------------------------
  # * Use Skill/Item
  #    Called for the acting side and applies the effect to other than the user.
  #--------------------------------------------------------------------------
  alias jene_alche_use_item use_item
  def use_item(item)
    if !SceneManager.scene_is?(Scene_Battle) && item.alchemy? && actor?
      scene = SceneManager.scene
      SceneManager.call(Scene_Alche)
      SceneManager.scene.previous_scene = scene
    end
    jene_alche_use_item(item) unless item.alchemy?
  end
end

#==============================================================================
# ** Window_Alche
#------------------------------------------------------------------------------
#  This window displays a list of buyable goods on the shop screen.
#==============================================================================

class Window_Alche < Window_Selectable
  #--------------------------------------------------------------------------
  # * Public Instance Variables
  #--------------------------------------------------------------------------
  attr_reader   :status_window            # Status window
  #--------------------------------------------------------------------------
  # * Object Initialization
  #--------------------------------------------------------------------------
  def initialize(x, y, height, actor)
    super(x, y, window_width, height)
    @actor = actor
    @money = 0
    refresh
    select(0)
  end
  #--------------------------------------------------------------------------
  # * Get Window Width
  #--------------------------------------------------------------------------
  def window_width
    return 200
  end
  #--------------------------------------------------------------------------
  # * Get Number of Items
  #--------------------------------------------------------------------------
  def item_max
    @data ? @data.size : 1
  end
  #--------------------------------------------------------------------------
  # * Get Item
  #--------------------------------------------------------------------------
  def item
    @data[index]
  end
  #--------------------------------------------------------------------------
  # * Get Activation State of Selection Item
  #--------------------------------------------------------------------------
  def current_item_enabled?
    enable?(@data[index])
  end
  #--------------------------------------------------------------------------
  # * Get Price of Item
  #--------------------------------------------------------------------------
  def ingre_ok?(item)
    return false if item.alche_greq > $game_party.gold
    item.alche_ireq.each_with_index do |ingre, i|
      item_ingre = nil
      case ingre[0]
      when 0
        item_ingre = $data_items[ingre[1]]
      when 1
        item_ingre = $data_weapons[ingre[1]]
      when 2
        item_ingre = $data_armors[ingre[1]]
      end
      return false if item_ingre == nil
      return false if ingre[2] > $game_party.item_number(item_ingre)
    end
    return true
  end
  #--------------------------------------------------------------------------
  # * Display in Enabled State?
  #--------------------------------------------------------------------------
  def enable?(item)
    item && ingre_ok?(item) && !$game_party.item_max?(item)
  end
  #--------------------------------------------------------------------------
  # * Refresh
  #--------------------------------------------------------------------------
  def refresh
    make_item_list
    create_contents
    draw_all_items
  end
  #--------------------------------------------------------------------------
  # * Create Item List
  #--------------------------------------------------------------------------
  def make_item_list
    @data = []
    ($data_items + $data_weapons + $data_armors).each do |items|
      next if items == nil
      if items.alche_lreq <= @actor.level && items.alche_lreq > 0 &&
        (items.alche_areq.include?(@actor.id) || items.alche_areq.empty?)
        @data.push(items)
      end
    end
  end
  #--------------------------------------------------------------------------
  # * Draw Item
  #--------------------------------------------------------------------------
  def draw_item(index)
    item = @data[index]
    rect = item_rect(index)
    draw_item_name(item, rect.x, rect.y, enable?(item), window_width * 3 / 4)
  end
  #--------------------------------------------------------------------------
  # * Set Status Window
  #--------------------------------------------------------------------------
  def status_window=(status_window)
    @status_window = status_window
    call_update_help
  end
  #--------------------------------------------------------------------------
  # * Update Help Text
  #--------------------------------------------------------------------------
  def update_help
    @help_window.set_item(item) if @help_window
    @status_window.item = item if @status_window
  end
end

#==============================================================================
# ** Window_GameEnd
#------------------------------------------------------------------------------
#  This window is for selecting Go to Title/Shut Down on the game over screen.
#==============================================================================

class Window_AlcheCommand < Window_Command
  #--------------------------------------------------------------------------
  # * Object Initialization
  #--------------------------------------------------------------------------
  def initialize(y)
    super(12, y)
    self.openness = 0
    select(1)
  end
  #--------------------------------------------------------------------------
  # * Create Command List
  #--------------------------------------------------------------------------
  def make_command_list
    add_command("Yes", :make)
    add_command("No",  :cancel)
  end
end


#==============================================================================
# ** Scene_Shop
#------------------------------------------------------------------------------
#  This class performs shop screen processing.
#==============================================================================

class Scene_Alche < Scene_MenuBase
  #--------------------------------------------------------------------------
  # * Start Processing
  #--------------------------------------------------------------------------
  def start
    super
    create_help_window
    create_alche_window
    create_status_window
    create_confirm_window
    create_progress_window
    activate_alche_window
  end
  #--------------------------------------------------------------------------
  # * Set Previous Scene
  #--------------------------------------------------------------------------
  def previous_scene=(scene)
    @scene = scene
  end
  #--------------------------------------------------------------------------
  # * Set Previous Scene
  #--------------------------------------------------------------------------
  def previous_scene
    @scene
  end
  #--------------------------------------------------------------------------
  # * Frame Update
  #--------------------------------------------------------------------------
  def update
    super
    if @progress_window.active && @progress_window.done_loading?
      on_alche_done if Input.trigger?(:C)
    end
  end
  #--------------------------------------------------------------------------
  # * Create Progress Window
  #--------------------------------------------------------------------------
  def create_progress_window
    @progress_window = Window_AlcheLoad.new
    @progress_window.viewport = @viewport
    @progress_window.hide
  end
  #--------------------------------------------------------------------------
  # * Create Status Window
  #--------------------------------------------------------------------------
  def create_status_window
    wx = @result_window.width
    wy = @help_window.y + @help_window.height
    ww = Graphics.width - wx
    wh = Graphics.height - wy
    @status_window = Window_AlcheIngre.new(wx, wy, ww, wh)
    @status_window.viewport = @viewport
    @result_window.status_window = @status_window
  end
  #--------------------------------------------------------------------------
  # * Create Status Window
  #--------------------------------------------------------------------------
  def create_confirm_window
    wy = @result_window.y + 12 + @result_window.line_height * (@result_window.index + 1)
    @confirm_window = Window_AlcheCommand.new(wy)
    @confirm_window.viewport = @viewport
    @confirm_window.set_handler(:make, method(:on_alche_confirm))
    @confirm_window.set_handler(:cancel, method(:on_alche_cancel))
  end
  #--------------------------------------------------------------------------
  # * Create Purchase Window
  #--------------------------------------------------------------------------
  def create_alche_window
    wy = @help_window.y + @help_window.height
    wh = Graphics.height - wy
    actor = @scene.is_a?(Scene_Skill) ? $game_party.menu_actor : $game_party.target_actor
    @result_window = Window_Alche.new(0, wy, wh, actor)
    @result_window.viewport = @viewport
    @result_window.help_window = @help_window
    @result_window.set_handler(:ok,     method(:on_alche_ok))
    @result_window.set_handler(:cancel, method(:return_scene))
  end
  #--------------------------------------------------------------------------
  # * Activate Purchase Window
  #--------------------------------------------------------------------------
  def activate_alche_window
    @result_window.show.activate
    @status_window.show
  end
  #--------------------------------------------------------------------------
  # * Buy [OK]
  #--------------------------------------------------------------------------
  def on_alche_ok
    @confirm_window.open
    @confirm_window.activate
    @help_window.set_text("Continue " + Jene::CREATION_NAME + "?")
  end
  #--------------------------------------------------------------------------
  # * Activate Purchase Window
  #--------------------------------------------------------------------------
  def activate_progress_window
    @item = @result_window.item
    @progress_window.text = Jene::CREATION_NAME
    @progress_window.show.activate
    @progress_window.start_loading(@item)
  end
  #--------------------------------------------------------------------------
  # * Activate Purchase Window
  #--------------------------------------------------------------------------
  def deactivate_progress_window
    @progress_window.hide.deactivate
  end
  #--------------------------------------------------------------------------
  # * Buy [OK]
  #--------------------------------------------------------------------------
  def on_alche_confirm
    Jene.alche_creation_se if Jene::CREATION_TIME >= 30
    @confirm_window.close
    activate_progress_window
  end
  #--------------------------------------------------------------------------
  # * Buy [OK]
  #--------------------------------------------------------------------------
  def on_alche_done
    Sound.play_ok
    if @progress_window.success?
      do_make
    else
      do_consume
    end
    deactivate_progress_window
    @result_window.activate
    @status_window.show
    @result_window.refresh
    @status_window.refresh
  end
  #--------------------------------------------------------------------------
  # * Buy [OK]
  #--------------------------------------------------------------------------
  def on_alche_loaded
    @confirm_window.open
    @confirm_window.activate
  end
  #--------------------------------------------------------------------------
  # * Buy [OK]
  #--------------------------------------------------------------------------
  def on_alche_cancel
    @confirm_window.close
    @result_window.activate
  end
  #--------------------------------------------------------------------------
  # * Execute Purchase
  #--------------------------------------------------------------------------
  def do_make
    do_consume
    $game_party.gain_item(@item, 1)
  end
  #--------------------------------------------------------------------------
  # * Lose All Item Requirements
  #--------------------------------------------------------------------------
  def do_consume
    $game_party.lose_gold(@item.alche_greq)
    @item.alche_ireq.each do |ingre|
      item_ingre = nil
      case ingre[0]
      when 0
        item_ingre = $data_items[ingre[1]]
      when 1
        item_ingre = $data_weapons[ingre[1]]
      when 2
        item_ingre = $data_armors[ingre[1]]
      end
      next if item_ingre == nil
      $game_party.lose_item(item_ingre, ingre[2])
    end
  end
  #--------------------------------------------------------------------------
  # * Get Party Gold
  #--------------------------------------------------------------------------
  def money
    @gold_window.value
  end
  #--------------------------------------------------------------------------
  # Get Currency Unit
  #--------------------------------------------------------------------------
  def currency_unit
    @gold_window.currency_unit
  end
  #--------------------------------------------------------------------------
  # * Get Purchase Price
  #--------------------------------------------------------------------------
  def alche_price
    @item.alche_greq
  end
end

#==============================================================================
# ** Window_AlcheIngre
#------------------------------------------------------------------------------
#  This window displays number of items in possession and the actor's
# equipment on the shop screen.
#==============================================================================

class Window_AlcheIngre < Window_Base
  #--------------------------------------------------------------------------
  # * Object Initialization
  #--------------------------------------------------------------------------
  def initialize(x, y, width, height)
    super(x, y, width, height)
    @item = nil
    @page_index = 0
    refresh
  end
  #--------------------------------------------------------------------------
  # * Refresh
  #--------------------------------------------------------------------------
  def refresh
    contents.clear
    draw_success_rate(4, 0)
    draw_gold_cost(4, line_height)
    draw_ingredients(4, line_height * 2) if @item != nil
  end
  #--------------------------------------------------------------------------
  # * Set Actor
  #--------------------------------------------------------------------------
  def actor
    SceneManager.scene.previous_scene.is_a?(Scene_Skill) ? 
      $game_party.menu_actor : $game_party.target_actor
  end
  #--------------------------------------------------------------------------
  # * Set Item
  #--------------------------------------------------------------------------
  def item=(item)
    @item = item
    refresh
  end
  #--------------------------------------------------------------------------
  # * Draw Quantity Possessed
  #--------------------------------------------------------------------------
  def draw_success_rate(x, y)
    rect = Rect.new(x, y, contents.width - 4 - x, line_height)
    change_color(system_color)
    draw_text(rect, "Success Rate")
    change_color(normal_color)
    success = Jene::BASE_SUCCESS
    if @item != nil
      success = @item.alche_success(actor)
    end
    draw_text(rect, (100.0 / Jene::MAX_SUCCESS * success).to_s + "%", 2)
  end
  #--------------------------------------------------------------------------
  # * Draw Quantity Possessed
  #--------------------------------------------------------------------------
  def draw_gold_cost(x, y)
    rect = Rect.new(x, y, contents.width - 4 - x, line_height)
    alche_gold = 0
    if @item != nil
      alche_gold = @item.alche_greq
    end
    change_color(system_color)
    draw_text(rect, "Cost")
    change_color(normal_color, alche_gold <= $game_party.gold)
    draw_text(rect, $game_party.gold.to_s + Vocab::currency_unit + 
      "/" + alche_gold.to_s + Vocab::currency_unit, 2)
  end
  #--------------------------------------------------------------------------
  # * Draw Equipment Information
  #--------------------------------------------------------------------------
  def draw_ingredients(x, y)
    rect = Rect.new(x, y, contents.width - 4 - x, line_height)
    change_color(system_color)
    draw_text(rect, "Ingredients")
    if @item.alche_ireq.empty?
      rect.x += 24
      rect.y += line_height
      change_color(normal_color)
      draw_text(rect, "None")
    else
      @item.alche_ireq.each_with_index do |ingre, i|
        draw_individual_ingredients(x, y + line_height * i, ingre)
      end
    end
  end
  #--------------------------------------------------------------------------
  # * Draw Actor Equipment Information
  #--------------------------------------------------------------------------
  def draw_individual_ingredients(x, y, ingre)
    item_ingre = nil
    case ingre[0]
    when 0
      item_ingre = $data_items[ingre[1]]
    when 1
      item_ingre = $data_weapons[ingre[1]]
    when 2
      item_ingre = $data_armors[ingre[1]]
    end
    qty_left = $game_party.item_number(item_ingre)
    change_color(normal_color, qty_left >= ingre[2])
    draw_item_name(item_ingre, x, y + line_height, qty_left >= ingre[2], 
      width * 3 / 4)
    rect = Rect.new(x, y + line_height, contents.width - 4 - x, line_height)
    draw_text(rect, qty_left.to_s + "/" + ingre[2].to_s, 2)
  end
end

#==============================================================================
# ** Scene_ItemBase
#------------------------------------------------------------------------------
#  This class performs common processing for the item screen and skill screen.
#==============================================================================

class Scene_ItemBase < Scene_MenuBase
  #--------------------------------------------------------------------------
  # * Determine if Item is Usable
  #--------------------------------------------------------------------------
  alias jene_alche_item_usable? item_usable?
  def item_usable?
    return true if alche_any? && [7, 11].include?(item.scope) 
    jene_alche_item_usable?
  end
  #--------------------------------------------------------------------------
  # * Check If Any Item Creation Exists
  #--------------------------------------------------------------------------
  def alche_any?
    items = []
    ($data_items + $data_weapons + $data_armors).each do |i|
      next if i == nil
      if i.alche_lreq <= user.level && i.alche_lreq > 0
        items.push(i)
      end
    end
    !items.empty?
  end
end