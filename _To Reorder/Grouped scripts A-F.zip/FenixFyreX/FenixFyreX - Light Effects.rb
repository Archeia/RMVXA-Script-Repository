# -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-==-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=- #
# FenixFyreX's Light Effects (FFXLFX)
# Version 1.1
# http://www.rpgmakervx.net
# http://www.rpgmakervxace.net
# -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-==-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=- #
#
# To use this script, either make a preset then setup an event's comment like so:
#
#  <prelfx string> OR <prelfx=string> OR <prelfx = string>    # You get the idea.
#
# Where string is the name of the preset below,
# or setup an event's comment like so:
#
#  <lfx fn "image";>
#
# Where opts is any option defined below that you can put in a preset.
#
# fn = string   # The filename of the image to use. Always pulls from Graphics/LFX.
# fa = number   # Fadein? Default is 0(false).
# zx = number   # The zoom x of the effect.
# zy = number   # The zoom y of the effect.
# bl = number   # Either 0(normal), 1(add), or 2(subtract).
# op = number   # Anything from 0 to 255. Sets maximum opacity for effect.
# z  = number   # 0 is in front, the default. 1 is behind.
# s  = number   # Adheres to the light switch? 0 is false, 1 is true. Default is 1.
# fl = number   # [n,n]. First n determines randomness of visibility. Second n
#                        determines the range of opacity change.
# cl = array    # [n,n,n] or [n,n,n,n]. [red,green,blue,transparency].
# os = array    # [x,y]. will offset the graphic by x,y.
#  w = array    # [n,n,n] or [n,n,n,n]. [strength,length,speed,phase].
#
# You must include filename if you make a direct light effect in a comment.
# -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-==-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=- #
# Event Script Command Calls
# -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-==-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=- #
# These are commands you can call via Advanced/Script.
#
#   remove_lfx(key)
#     This will remove any light effects by the key. key has to be 1 or greater.
#
#   player_lfx(preset_name,fade = false)
#     This will add a light effect to the player. Must be a preset defined below.
#     If you leave fade out, the effect will not fade in. If you set it to true,
#     it will. es.g:
#         player_lfx("Ground")        # Will not fadein
#         player_lfx("Ground",true)   # Will fadein
#
#   stop_player_lfx(fade = false)
#     This will remove the player's light effect. If you leave out fade, the effect
#     will just go away. If fade is true, the effect will fadeout. es.g:
#         stop_player_lfx             # Will not fadeout
#         stop_player_lfx(true)       # Will fadeout
#    
# -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-==-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=- #
module FFXLFX
  # -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=- #
  #
  # Set up preset light fx here. the preset can be named anything as long as it
  # is a string(e.g. within " ")
  # Options for the preset are as follows; if a * is next to it, its mandatory:
  #
  #   :filename *  The name of the file in Graphics/Lights/
  #   :fadein      Should the effect fadein? 0 is false(default), 1 is true.
  #   :flicker     Should the light flicker? Must be an array of two numbers.
  #   :zx          Zoom X of the effect, 1 is default
  #   :zy          Zoom Y of the effect, 1 is default
  #   :z           Z coordinate of the effect. 0 is in front, 1 is behind.
  #   :blend       0 is normal, 1 is add, 2 is subtract
  #   :switch      Adheres to the light switch? true or false. Default is true.
  #   :color       An array of 3-4 numbers, like so: [155,100,0] # Yellow
  #                To make a random color, put -1 in the color index spot, so
  #                a fully random color would be [-1,-1,-1]
  #   :offset      An array of two numbers. [-1,1] will offset the image left
  #                and down one pixel.
  #   :opacity     Anything from 0 to 255. Sets maximum opacity for the effect.
  #   :wave        An array of 3-4 numbers, [amp, length, speed, phase]
  #
  # :wave makes the image wiggle. Use the help file for further information on
  # wave effects. Look up Sprite in the help file.
  
  
  Presets = { # do NOT delete this.
    # -=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=--=- #
    # Preset 1: Ground
    # -=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=--=- #
    "Ground" => {
      :filename => "ground",
      :flicker => [200,100],
      :zx => 4,
      :zy => 4,
      :blend => 1,
      :color => [155,100,0],
    },
    # -=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=--=- #
    # Preset 2: Lantern
    # -=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=--=- #
    "Lantern" => {
      :filename => "lantern",
      :flicker => [500,100],
      :zx => 1,
      :zy => 1,
      :blend => 1,
      :color => [190,100,0],
      :offset => [0,0],
    },
    # -=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=--=- #
    # Preset 3: Lightbug
    # -=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=--=- #
    "Lightbug" => {
      :filename => "ground",
      :flicker => [500,200],
      :zx => 1,
      :zy => 1,
      :z  => 0,
      :blend => 1,
      :color => [-1,-1,-1],
      :offset => [0,-6],
      :switch => false,
    },
    # -=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=--=- #
    # Preset 4: Headstone
    # -=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=--=- #
    "Ghost" => {
      :filename => "ghost",
      :flicker => [0,0],
      :zx => 2,
      :zy => 2,
      :blend => 1,
      :color => [-1,-1,-1],
      :offset => [0,-16],
      :opacity => -170,
      :wave => [2,5,1],
      :fadein => true,
    },
    # -=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=--=- #
    # Preset 5: Fireplace
    # -=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=--=- #
    "Fireplace" => {
      :filename => "fireplace",
      :flicker => [500,200],
      :color => [220,10,0],
      :blend => 1,
    },
    # -=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=--=- #
    # Preset 6: Drunk
    # -=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=--=- #
    "Drunk" => {
      :filename => "ground",
      :switch => false,
      :zx => 3,
      :zy => 4,
      :color => [220,10,0],
      :blend => 1,
    },
    
     "Torch1" => {
      :filename => "Light",
      :switch => false,
      :zx => 6,
      :zy => 6,
      :color => [220,-100,-255],
      :blend => 1,
    },
  # -=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=-=--=- #
  } # DO NOT DELETE THIS
  
  
  
  # The switch that turns the whole system on or off. If on, the system will be off.
  On_Off_Switch = 200
  
  # Is the system on at startup? If true, it does. False, it doesn't.
  Sys_Starts_On = true
  
  # This number determines the speed at which light effects fade on and off.
  # Higher numbers result in faster fading.
  Fade_Time = 3
end

# -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-==-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=- #
# DO NOT EDIT FURTHER UNLESS YOU KNOW WHAT YOU ARE DOING.
# -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-==-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=- #

class Game_Switches
  alias initialize_ffxlfx_switch_value initialize
  def initialize(*a,&b)
    initialize_ffxlfx_switch_value(*a,&b)
    @data[FFXLFX::On_Off_Switch] = FFXLFX::Sys_Starts_On
  end
end

module Cache
  
  def self.lights(filename)
    load_bitmap("Graphics/Lights/",filename)
  end
end

module FFXLFX
  def self.scene
    return defined?($scene) ? $scene : SceneManager.scene
  end
end

class Sprite
  
  def start_wave(amp,speed,length,phase=nil)
    self.wave_amp = amp
    self.wave_speed = speed
    self.wave_length = length
    self.wave_phase = phase.to_i unless phase.nil?
  end
end

class Spriteset_Map
  
  alias initialize_ffxlfx_old initialize unless $@
  alias update_ffxlfx_old update unless $@
  alias dispose_ffxlfx_old dispose unless $@
  
  def initialize(*a, &b)
    @ffxlfx_sprites = {}
    initialize_ffxlfx_old(*a, &b)
    initialize_ffxlfx
    update_ffxlfx
  end
  
  def update(*a, &b)
    update_ffxlfx_old(*a, &b)
    update_ffxlfx
  end
  
  def dispose(*a, &b)
    dispose_ffxlfx
    dispose_ffxlfx_old(*a, &b)
  end
  
  def initialize_ffxlfx
    $game_map.events.each_pair do |id,event|
      s = nil
      cache = event.light_cache
      if cache
        s = Sprite_FFXLight.new(@viewport1,id)
        s.setup(cache)
      end
      @ffxlfx_sprites[id] = s
    end      
    @ffxlfx_sprites[:player] = nil
    player_lfx
  end
  
  def refresh_ffxlfx
    @ffxlfx_sprites.each_key do |key|
      next unless key.is_a?(Integer)
      if (@ffxlfx_sprites[key].nil? || @ffxlfx_sprites[key].disposed?)
        cache = $game_map.events[key].nil? ? nil : $game_map.events[key].light_cache
        next if (cache.nil? || cache.empty?)
        @ffxlfx_sprites[key] = Sprite_FFXLight.new(@viewport1,key)
        @ffxlfx_sprites[key].setup(cache)
      else
        cache = $game_map.events[key].nil? ? nil : $game_map.events[key].light_cache
        if cache.nil?
          remove_lfx(key)
        elsif cache == @ffxlfx_sprites[key].cache
          next
        else
          @ffxlfx_sprites[key].setup(cache)
        end
      end
    end
  end
  
  def update_ffxlfx
    rs = []
    @ffxlfx_sprites.each_pair do |key,s|
      next if s.nil?
      next if s.disposed?
      s.update
      if s.to_nil?
        rs << key
      end
    end
    rs.each do |r|
      @ffxlfx_sprites[r].dispose
      @ffxlfx_sprites[r] = nil
    end
  end
  
  def dispose_ffxlfx
    @ffxlfx_sprites.each_pair do |key,s|
      next if s.nil?
      next if s.disposed?
      s.dispose
    end
    @ffxlfx_sprites = {}
  end
  
  def remove_lfx(key)
    @ffxlfx_sprites[key].fade2nil
  end
  
  def change_lfx(key,key2)
    if @ffxlfx_sprites[key].nil?
      @ffxlfx_sprites[key] = Sprite_FFXLight.new(@viewport1,key)
      @ffxlfx_sprites[key].setup(FFXLFX::Presets[key2])
    end
  end
  
  def player_lfx
    return if $game_player.light_cache.nil?
    return unless $game_player.light_cache[:filename]
    if @ffxlfx_sprites[:player].nil? || @ffxlfx_sprites[:player].disposed?
      @ffxlfx_sprites[:player] = Sprite_FFXLight.new(@viewport1,:player)
      @ffxlfx_sprites[:player].cache = {}
      @ffxlfx_sprites[:player].set_cache
    end
  end
  
  def stop_player_lfx(fade)
    return if @ffxlfx_sprites[:player].nil? || @ffxlfx_sprites[:player].disposed?
    if fade
      @ffxlfx_sprites[:player].fade2nil
    else
      @ffxlfx_sprites[:player].dispose
      @ffxlfx_sprites[:player] = nil
    end
  end
  
#~   def add_lfx(opts)
#~   end
end

class Game_Player < Game_Character
  attr_accessor :light_cache
  alias initialize_light_cache initialize unless $@
  def initialize(*a,&b)
    initialize_light_cache(*a,&b)
    @light_cache = nil
  end
end

class Game_Event < Game_Character
  
  FFXLFX_Light_Rgxp    = /<lfx[ ]*[=]?/i
  FFXLFX_Prelight_Rgxp = /<prelfx[ ]*[=]?[ ]*(.*)>/i
  
  alias refresh_ffxlfx_refresh refresh unless $@
  def refresh(*a,&b)
    refresh_ffxlfx_refresh(*a,&b)
    if FFXLFX.scene.is_a?(Scene_Map)
      FFXLFX.scene.refresh_ffxlfx_lights
    end
  end
  
  def name
    return @event.nil? ? "" : @event.name
  end
  
  def comment?(txt,ret = false)
    return false if @page.nil?
    @page.list.each do |item|
      if [108,408].include?(item.code)
        item_text = item.parameters[0]
        case txt
        when Regexp
          m = (item_text.match(txt))
          if ret && !m.nil?
            return m.captures
          else
            return !m.nil?
          end
        when String
          if ret && (m = item_text.include?(txt))
            return item.parameters[0]
          else
            return m
          end
        end
      end
    end
    return false
  end
  
  def light?
    return comment?(FFXLFX_Light_Rgxp)
  end
  
  def prelight?
    return comment?(FFXLFX_Prelight_Rgxp)
  end
  
  def light_cache
    cache = nil
    if light?
      txt = comment_block(FFXLFX_Prelight_Rgxp, ">")
      cache = parse_lfx(txt)
    elsif prelight?
      txt = comment?(FFXLFX_Prelight_Rgxp, true)
      cache = FFXLFX::Presets[txt[0]]
    end
    unless cache.nil?
      cache[:fadein] = false if cache[:fadein].nil?
    end
    return cache
  end
  
  def comment_block(txt1,txt2)
    s = [""]
    start = false
    stop = false
    return s if @page.nil?
    @page.list.each do |item|
      if [108,408].include?(item.code)
        item_text = item.parameters[0]
        case txt1
        when Regexp
          if item_text =~ txt1
            start = true
          end
        when String
          if item_text.include?(txt1)
            start = true
          end
        end
        case txt2
        when Regexp
          if item_text =~ txt2
            stop = true
          end
        when String
          if item_text.include?(txt2)
            stop = true
          end
        end
        s << item_text
        if stop
          break
        end
      end
    end
    return s.join("")
  end
  
  def parse_lfx(txt="")
    cache = {}
    ary = txt.split(";")
    ary.each do |item|
      case item
      when /fn[ ]*[=]?[ ]*(.*)/i
        cache[:filename] = $1.to_s.gsub(">","")
      when /fa[ ]*[=]?[ ]*(\d+)[>]?/i
        cache[:fadein] = ($1.to_i == 1)
      when /fl[ ]*[=]?[ ]*\[[ ]*(\d+)[ ]*,[ ]*(\d+)\][>]?/i
        cache[:flicker] = [$1.to_i,$2.to_i]
      when /zx[ ]*[=]?[ ]*(\d+)[>]?/i
        cache[:zx] = $1.to_i
      when /zy[ ]*[=]?[ ]*(\d+)[>]?/i
        cache[:zy] = $1.to_i
      when /z[ ]*[=]?[ ]*(0|1)[>]?/i
        cache[:z] = ($1.to_i == 1)
      when /a[ ]*[=]?[ ]*(0|1)[>]?/i
        cache[:switch] = ($1.to_i == 1)
      when /bl[ ]*[=]?[ ]*(0|1|2)[>]?/i
        cache[:blend] = $1.to_i
      when /op[ ]*[=]?[ ]*(\d+)[>]?/i
        cache[:opacity] = $1.to_i
      when /cl[ ]*[=]?[ ]*\[[ ]*(\d+)[ ]*,[ ]*(\d+)[ ]*,[ ]*(\d+)[ ]*[,]?[ ]*(\d+)?\][>]?/i
        cache[:color] = [$1.to_i,$2.to_i,$3.to_i]
        cache[:color] << $4.to_i unless $4.nil?
      when /os[ ]*[=]?[ ]*\[[ ]*([-]?\d+)[ ]*,[ ]*([-]?\d+)\][>]?/i
        cache[:offset] = [$1.to_i,$2.to_i]
      when /w[ ]*[=]?[ ]*\[[ ]*(\d+)[ ]*,[ ]*(\d+)[ ]*,[ ]*(\d+)[ ]*[,]?[ ]*(\d+)?\][>]?/i
        cache[:wave] = [$1.to_i,$2.to_i,$3.to_i]
        cache[:wave] << $4.to_i unless $4.nil?
      end
    end
    return cache
  end
end

class Sprite_FFXLight < Sprite_Base
  
  attr_reader :charID,:char
  attr_accessor :cache,:offset,:flicker
  
  def initialize(viewport, charID)
    super(viewport)
    @charID = charID
    @char = nil
    @cache = {}
    @offset = [0,0]
    @flicker = nil
    @go2nil = @to_nil = false
    set_char
    set_xyz
  end
  
  def setup(cache={})
    if cache.nil?
      @cache = {}
      return
    end
    begin
      self.bitmap = Cache.lights(cache[:filename]).clone
    rescue
      fn = "Graphics/Lights/" + cache[:filename] + ".png"
      msgbox "File does not exist: " + fn
      exit
    end
    self.flicker = cache[:flicker] unless cache[:flicker].nil?
    self.zoom_x = cache[:zx] unless cache[:zx].nil?
    self.zoom_y = cache[:zy] unless cache[:zy].nil?
    unless cache[:color].nil?
      self.color = Color.new(*cache[:color])
      self.color.red = rand(256) if cache[:color][0] == -1
      self.color.green = rand(256) if cache[:color][1] == -1
      self.color.blue = rand(256) if cache[:color][2] == -1
    end
    self.blend_type = cache[:blend] unless cache[:blend].nil?
    self.offset = cache[:offset] unless cache[:offset].nil?
    self.start_wave(*cache[:wave]) unless cache[:wave].nil?
    if cache[:fadein]
      self.opacity = 0
      fadein
      if get_char.is_a?(Game_Player)
        get_char.light_cache[:fadein] = false
      end
    else
      self.opacity = max_opacity
    end
    cache[:switch] = true if cache[:switch].nil?
    @cache = cache
    set_char
  end
  
  def max_opacity
    result = 170
    result = @cache[:opacity] unless @cache[:opacity].nil?
    if !$game_switches[FFXLFX::On_Off_Switch]
      result = 0 if @cache[:switch]
    end
    return result
  end
  
  def update
    super
    if @cache != get_cache
      set_char
      set_cache
      if [nil,{}].include?(@cache)
        fadeout
      end
      setup(@char.light_cache)
    end
    set_xyz
    update_fadeinout
    update_flicker if !fading
  end
  
  def update_fadeinout
    fade_time = FFXLFX::Fade_Time
    if @fadein
      self.opacity = [[self.opacity+fade_time,0].max, max_opacity].min
      if self.opacity >= max_opacity
        self.opacity = max_opacity
        @fadein = false
      else
        return
      end
    elsif @fadeout
      self.opacity -= fade_time
      if self.opacity == 0
        if @go2nil
          @to_nil = true
        end
        @fadeout = false
      else
        return
      end
    end
  end
  
  def update_flicker
    if !@flicker.nil?
      self.visible = (rand(@flicker[0]) != @flicker[0]-1)
      self.opacity = 255-rand(@flicker[1])
      self.opacity = max_opacity if self.opacity > max_opacity
    else
      self.visible = true
      self.opacity = max_opacity
    end
  end
  
  def set_cache
    @cache = get_cache
    setup(@cache)
  end
  
  def get_cache
    return @char.light_cache
  end
  
  def fadein
    @fadeout = false
    @fadein = true
  end
  
  def fadeout
    @fadein = false
    @fadeout = true
  end
  
  def set_char
    @char = get_char
  end
  
  def get_char
    if @charID.is_a?(Integer)
      return $game_map.events[@charID]
    elsif @charID == :player
      return $game_player
    else
      p "A light effect is assigned a nil character. Exiting for safety."
      exit
    end
  end
  
  def set_xyz
    a = (@char.screen_x.to_f)
    b = (@char.screen_y.to_f)
    a -= 16+((self.zoom_x-1)*self.width/2)
    b -= 32+((self.zoom_y-1)*self.height/2)
    if self.width > 32
      n1 = (self.width - 32) / 2
      a -= n1
    elsif self.width < 32
      n1 = (32 - self.width) / 2
      a += n1
    end
    if self.height > 32
      n2 = (self.height - 32) / 2
      b -= n2
    elsif self.height < 32
      n2 = (32 - self.height) / 2
      b += n2
    end
    a += @offset[0]
    b += @offset[1]
    self.x = a
    self.y = b
    fz = @char.screen_z
    if @cache[:z]
      fz -= 1
    else
      fz += 1
    end
    self.z = fz
  end
  
  def to_nil?
    return @to_nil
  end
  
  def fade2nil
    @go2nil = true
    fadeout
  end
  
  def fading
    return true if @fadein || @fadeout || @go2nil
    return false
  end
end

class Game_Interpreter
  
  def remove_lfx(key)
    FFXLFX.scene.remove_lfx(key)
  end
  
#~   def add_lfx(x,y,key)
#~     opts = {}
#~     opts[:x] = x
#~     opts[:y] = y
#~     opts[:k] = key
#~     FFXLFX.scene.add_lfx(opts)
#~   end
  
  def player_lfx(preset,fade=false)
    FFXLFX.scene.player_lfx(preset,fade)
  end
  
  def stop_player_lfx(fade=false)
    FFXLFX.scene.stop_player_lfx(fade)
  end
end

class Scene_Map < Scene_Base
  def refresh_ffxlfx_lights
    return if @spriteset.nil?
    @spriteset.refresh_ffxlfx
  end
  
  def remove_lfx(key)
    @spriteset.remove_lfx(key)
  end
  
#~   def add_lfx(opts)
#~     @spriteset.add_lfx(opts)
#~   end
  
  def player_lfx(preset,fade)
    $game_player.light_cache = FFXLFX::Presets[preset]
    return if $game_player.light_cache.nil?
    $game_player.light_cache[:fadein] = fade
    @spriteset.player_lfx
  end
  
  def stop_player_lfx(fade)
    @spriteset.stop_player_lfx(fade)
  end
  
  alias pre_transfer_lfx pre_transfer
  def pre_transfer(*a,&b)
    pre_transfer_lfx(*a,&b)
    @spriteset.dispose_ffxlfx
  end
  
  alias post_transfer_lfx post_transfer
  def post_transfer(*a,&b)
    @spriteset.initialize_ffxlfx
    post_transfer_lfx(*a,&b)
  end
end