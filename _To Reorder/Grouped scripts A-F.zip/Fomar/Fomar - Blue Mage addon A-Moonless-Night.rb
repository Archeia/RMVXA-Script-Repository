=begin
#==============================================================================#
#   AMN Fomar0153 Blue Mages Script addon
#   Version 1.01
#   Author: AMoonlessNight
#   Date: 27 Oct 2018
#   Latest: 27 Oct 2018
#==============================================================================#
#   UPDATE LOG
#------------------------------------------------------------------------------#
# 27 Oct 2018 - created the script
#==============================================================================#
#   TERMS OF USE
#------------------------------------------------------------------------------#
# - Please credit AMoonlessNight or A-Moonless-Night
# - Please credit Fomar0153, creator of the original script
# - Free for non-commercial use
# - Contact for commercial use
# - I'd love to see your game if you end up using one of my scripts
#==============================================================================#

This script is an addon for Fomar0153's Stand Alone Blue Mages script. It makes
it so that blue mages can learn skills with self- or ally-related scopes
when used by enemies.
 
=end

#==============================================================================
#  Please do not edit below this point unless you know what you are doing.
#==============================================================================
class Game_Actor < Game_Battler
  def blue_mage?
    BlueMages.include?(@actor_id)
  end
end

class Scene_Battle < Scene_Base 
  alias amn_bluemage_scenebattle_useitem  use_item
  def use_item
    amn_bluemage_scenebattle_useitem
    item = @subject.current_action.item
    if self_blue_magic?(item)
      $game_party.battle_members.each { |actor|
      if actor.blue_mage?
        i = actor.skills.size
        actor.learn_skill(item.id)
        if !(i == actor.skills.size)
          @log_window.add_text(actor.name + " learns " + item.name + ".")
          @log_window.wait
        end
      end
      }
    end
  end
 
  def self_blue_magic?(item)
    return true if item.is_a?(RPG::Skill) && Game_Actor::BlueMagic.include?(item.id) &&
    item.scope.between?(7, 11) && @subject.is_a?(Game_Enemy) &&
    $game_party.battle_members.any? { |actor| actor.blue_mage? }
  end
 
end