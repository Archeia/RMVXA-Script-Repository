=begin
Evolution Script
by Fomar0153
Version 1.0
----------------------
Notes
----------------------
Implements two types of evolution:
leveling
item use
----------------------
Instructions
----------------------
First copy the script into your game then set the variables in the Fomar module
to your liking.

Evolve_Class = true
means that when evolving the class will change.

Evolve_Class = false
means that when evolving the actor it uses as a base will change.

Evolve_Keep_Exp = true
means you keep your level when you change class if Evolve_Class is set to true.

I'll cover Evolution after the notetags. But for now it's the effect played 
when an evolution takes place.

Ok notetags there are 3 and they can be placed on actors or classes (actors
will always take priority over class):

<battler_name str>
where str is the name of the battler. This will be used as the graphic in
the evolution scene.
examples:
<battler_name bat>
<battler_name imp>
<evolution_item if item.id == 17;@evolution = 4;end;>

<evolution_level_up str>
where str is code to be run when that actor or class levels up.
To trigger an evolution set @evolution to the id of the new actor or class.
examples:
<evolution_level_up if @level >= 2; @evolution = 2; end;>

<evolution_item str>
where str is code to be run when an item is used on that actor or class.
To trigger an evolution set @evolution to the id of the new actor or class.
examples:
<evolution_item if item.id == 17;@evolution = 4;end;>

Ok the last thing I need to go through is Evolution from the Fomar module.
It's an array of effects to be used.
The two images are @sprite1 (the old battler) and @sprite2 (the new battler).
Both start off centered and invisible.

To make a sprite visible use:
@sprite1.visible = true

To make the scene wait use:
wait(n)

To change a sprites tone use:
@sprite1.tone = Tone.new(red,green,blue)

To make a sprite shrink use:
while @sprite1.zoom_x > a; @sprite1.zoom_x -= b; @sprite1.zoom_y -= b; update_basic; end;
where a is the percentage you want to shrink to e.g. 0.5 (half size), 0.25 (quarter size)
where b is the speed it shrinks by, I reccomend 0.01 or 0.02 otherwise it will shrink very quickly

To enlarge a sprite use:
while @sprite1.zoom_x < a; @sprite1.zoom_x += b; @sprite1.zoom_y += b; update_basic; end;
where a is the percentage you want to enlarge to e.g. 1 (normal size), 1.5 (one and a half size)
where b is the speed it enlarges by, I reccomend 0.01 or 0.02 otherwise it will shrink very quickly

To play an animation use:
@sprite1.start_animation($data_animations[x], false)
where x is the id of the animation

To add a message use:
$game_message.add(\"message here\")
I suggest looking at my example and if you get stuck asking for help.
@old_name will be the old name and @new_name will be the new name of the actor/class

To make it pause for the user to close the mesage use:
wait_for_message

When you have finished call:
SceneManager.return
----------------------
Known bugs
----------------------
None
=end

module Fomar
  
  Evolution = [
  "@sprite1.visible = true",
  "wait(120)",
  "@sprite1.tone = Tone.new(255,255,255)",
  "while @sprite1.zoom_x > 0.25; @sprite1.zoom_x -= 0.01; @sprite1.zoom_y -= 0.01; update_basic; end;",
  "@sprite1.start_animation($data_animations[39], false)",
  "update_basic while @sprite1.animation?",
  "while @sprite1.zoom_x < 1.25; @sprite1.zoom_x += 0.01; @sprite1.zoom_y += 0.01; update_basic; end;",
  "@sprite2.tone = Tone.new(255,255,255)",
  "@sprite2.zoom_x = 0.02; @sprite2.zoom_y = 0.02;",
  "@sprite2.visible = true",
  "while @sprite2.zoom_x < 1.0; @sprite2.zoom_x += 0.02; @sprite2.zoom_y += 0.02; update_basic; end;",
  "@sprite2.start_animation($data_animations[40], false)",
  "while @sprite1.zoom_x > 0.0; @sprite1.zoom_x -= 0.05; @sprite1.zoom_y -= 0.05; update_basic; end;",
  "update_basic while @sprite2.animation?",
  "@sprite2.tone = Tone.new(0,0,0)",
  "$game_message.add(\"Congradulations your \" + @old_name + \"  evolved into a \" + @new_name)",
  "wait_for_message",
  "SceneManager.return"
  ]
  
  Evolve_Class = true
  
  Evolve_Keep_Exp = true
  
end

module SceneManager
  #--------------------------------------------------------------------------
  # * Return to Caller
  #--------------------------------------------------------------------------
  def self.return
    if @scene.is_a?(Scene_Battle) || @scene.is_a?(Scene_Evolution)
      for member in $game_party.members
        if member.evolution > 0
          @scene = Scene_Evolution.new
          @scene.prepare(member)
          return
        end
      end
    end
    @scene = @stack.pop
  end
end


class Scene_Evolution < Scene_Base
  #--------------------------------------------------------------------------
  # * Start Processing
  #--------------------------------------------------------------------------
  def start
    super
    create_message_window
    @index = 0
  end
  #--------------------------------------------------------------------------
  # * Prepare
  #--------------------------------------------------------------------------
  def prepare(actor)
    @actor = actor
    create_battlers
  end
  #--------------------------------------------------------------------------
  # * Termination Processing
  #--------------------------------------------------------------------------
  def terminate
    super
    @sprite1.dispose
    @sprite2.dispose
  end
  #--------------------------------------------------------------------------
  # * Create Message Window
  #--------------------------------------------------------------------------
  def create_message_window
    @message_window = Window_Message.new
  end
  #--------------------------------------------------------------------------
  # * Create Battlers
  #--------------------------------------------------------------------------
  def create_battlers
    @sprite1 = Sprite_Base.new
    @sprite1.bitmap = Cache.battler(@actor.battler_name,0)
    @sprite1.x = Graphics.width / 2
    @sprite1.ox = @sprite1.bitmap.width / 2
    @sprite1.y = Graphics.height / 2
    @sprite1.oy = @sprite1.bitmap.height / 2
    @sprite1.visible = false
    if Fomar::Evolve_Class
      @old_name = @actor.class.name
    else
      @old_name = @actor.actor.name
    end
    @actor.evolve
    @sprite2 = Sprite_Base.new
    @sprite2.bitmap = Cache.battler(@actor.battler_name,0)
    @sprite2.x = Graphics.width / 2
    @sprite2.ox = @sprite2.bitmap.width / 2
    @sprite2.y = Graphics.height / 2
    @sprite2.oy = @sprite2.bitmap.height / 2
    @sprite2.visible = false
    if Fomar::Evolve_Class
      @new_name = @actor.class.name
    else
      @new_name = @actor.actor.name
    end
  end
  #--------------------------------------------------------------------------
  # * Update Frame (Basic)
  #--------------------------------------------------------------------------
  def update_basic
    super
    @sprite1.update
    @sprite2.update
  end
  #--------------------------------------------------------------------------
  # * Wait Until Message Display has Finished
  #--------------------------------------------------------------------------
  def wait_for_message
    @message_window.update
    update_basic while $game_message.visible
  end
  #--------------------------------------------------------------------------
  # * Wait
  #--------------------------------------------------------------------------
  def wait(duration)
    duration.times { update_basic }
  end
  #--------------------------------------------------------------------------
  # * Update
  #--------------------------------------------------------------------------
  def update
    super
    unless Fomar::Evolution[@index] == nil
      eval(Fomar::Evolution[@index])
      @index += 1
    end
  end
end

class RPG::BaseItem
  
  def battler_name
    if @battler_name.nil?
      if @note =~ /<battler_name (.*)>/i
        @battler_name = $1
      else
        @battler_name = ""
      end
    end
    @battler_name
  end
  
  def evolution_level_up
    if @evolution_level_up.nil?
      if @note =~ /<evolution_level_up (.*)>/i
        @evolution_level_up = $1
      else
        @evolution_level_up = "false"
      end
    end
    @evolution_level_up
  end
  
  def evolution_item
    if @evolution_item.nil?
      if @note =~ /<evolution_item (.*)>/i
        @evolution_item = $1
      else
        @evolution_item = ""
      end
    end
    @evolution_item
  end
end

class Game_Actor < Game_Battler
  #--------------------------------------------------------------------------
  # * Public Instance Variables
  #--------------------------------------------------------------------------
  attr_accessor :evolution
  attr_accessor :battler_name
  #--------------------------------------------------------------------------
  # * Setup
  #--------------------------------------------------------------------------
  alias evo_setup setup
  def setup(actor_id)
    evo_setup(actor_id)
    @evolution = 0
    if self.class.battler_name != ""
      @battler_name = self.class.battler_name
    end
    if self.actor.battler_name != ""
      @battler_name = self.actor.battler_name
    end
  end
  #--------------------------------------------------------------------------
  # * Evolve
  #--------------------------------------------------------------------------
  def evolve
    if Fomar::Evolve_Class
      change_class(@evolution, Fomar::Evolve_Keep_Exp)
      if self.class.battler_name != ""
        @battler_name = self.class.battler_name
      end
    else
      @actor_id = @evolution
      if self.actor.battler_name != ""
        @battler_name = self.actor.battler_name
      end
    end
    @evolution = 0
  end
  #--------------------------------------------------------------------------
  # * Level Up
  #--------------------------------------------------------------------------
  alias evo_level_up level_up
  def level_up
    evo_level_up
    if self.class.evolution_level_up != ""
      eval(self.class.evolution_level_up)
    end
    if self.actor.evolution_level_up != ""
      eval(self.actor.evolution_level_up)
    end
  end
  #--------------------------------------------------------------------------
  # * Test Skill/Item Application
  #    Used to determine, for example, if a character is already fully healed
  #   and so cannot recover anymore.
  #--------------------------------------------------------------------------
  def item_test(user, item)
    if self.actor.evolution_item != "" and !$game_party.in_battle
      eval(self.actor.evolution_item)
      if @evolution > 0
        @evolution = 0
        return true
      end
    end
    if self.class.evolution_item != "" and !$game_party.in_battle
      eval(self.class.evolution_item)
      if @evolution > 0
        @evolution = 0
        return true
      end
    end
    return super(user, item)
  end
  #--------------------------------------------------------------------------
  # * Apply Effect of Skill/Item
  #--------------------------------------------------------------------------
  def item_apply(user, item)
    super(user, item)
    if item.is_a?(RPG::Item)
      if self.actor.evolution_item != "" and !$game_party.in_battle
        eval(self.actor.evolution_item)
        if @evolution > 0
          SceneManager.call(Scene_Evolution)
          SceneManager.scene.prepare(self)
          return
        end
      end
      if self.class.evolution_item != "" and !$game_party.in_battle
        eval(self.class.evolution_item)
        if @evolution > 0
          SceneManager.call(Scene_Evolution)
          SceneManager.scene.prepare(self)
          return
        end
      end
    end
  end
end
