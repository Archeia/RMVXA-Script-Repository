=begin
Equipable Passive Skills
by Fomar0153
Version 1.0
----------------------
Notes
----------------------
Restaff Script please do not re-distribute.
----------------------
Instructions
----------------------
First follow the instructions in the Fomar module.
Then notetag skills with:
<passive_points x>
where x is the amount of points required to equip the skill.

<passive_features x>
will use state x's feature list
<passive_features x;y>
will use state x and state y's feature list

<passive_features x,y,z>
will use a feature with code x, data_id y and value z
<passive_features x,y,z;x2,y2,z2>
will use a feature with code x, data_id y and value z
and also a feature with code x2, data_id y2 and value z2

You can mix them as well:
<passive_features a;b;x,y,z;c>
----------------------
Known bugs
----------------------
None
=end

module Fomar
  
  # Set this to the passive skill type'd id
  PASSIVE_SKILL_TYPE = 3
  # Colors of the graident bar, refers to the Windowskin
  COLOR1 = 31
  COLOR2 = 30
  # Text that appears on the gradient bar for passive points
  PP = "PP"
  
  # Formula for amount of points an actor has to equip passive skills with
  def self.passive_points(actor)
    return actor.level
  end
  
end

class Game_Actor < Game_Battler
  #--------------------------------------------------------------------------
  # * Public Instance Variables
  #--------------------------------------------------------------------------
  attr_accessor :passive_skills
  #--------------------------------------------------------------------------
  # * Setup
  #--------------------------------------------------------------------------
  alias passives_setup setup
  def setup(actor_id)
    @passive_skills = []
    passives_setup(actor_id)
  end
  #--------------------------------------------------------------------------
  # * Get Array of All Objects Retaining Features
  #--------------------------------------------------------------------------
  alias passive_feature_objects feature_objects
  def feature_objects
    passive_feature_objects + @passive_skills
  end
end

class Window_Base < Window
  #--------------------------------------------------------------------------
  # * Draw Simple Status
  #--------------------------------------------------------------------------
  alias passive_draw_actor_simple_status draw_actor_simple_status
  def draw_actor_simple_status(actor, x, y)
    y -= line_height / 2
    passive_draw_actor_simple_status(actor, x, y)
    draw_actor_pp(actor, x + 120, y + line_height * 3)
  end
  #--------------------------------------------------------------------------
  # * Draw MP
  #--------------------------------------------------------------------------
  def draw_actor_pp(actor, x, y, width = 124)
    pp_rate = (Fomar.passive_points(actor) - actor.passive_skills.inject(0) {|cost,skill| cost+skill.mp_cost}) / Fomar.passive_points(actor).to_f
    draw_gauge(x, y, width, pp_rate, text_color(Fomar::COLOR1), text_color(Fomar::COLOR2))
    change_color(system_color)
    draw_text(x, y, 30, line_height, Fomar::PP)
    draw_current_and_max_values(x, y, width, Fomar.passive_points(actor) - actor.passive_skills.inject(0) {|cost,skill| cost+skill.mp_cost}, Fomar.passive_points(actor),
      normal_color, normal_color)
  end
end

class Window_SkillList < Window_Selectable
  #--------------------------------------------------------------------------
  # * Display Skill in Active State?
  #--------------------------------------------------------------------------
  alias passive_enable? enable?
  def enable?(item)
    if item && item.stype_id == Fomar::PASSIVE_SKILL_TYPE
      return @actor.passive_skills.include?(item)
    else
      return passive_enable?(item)
    end
  end
  #--------------------------------------------------------------------------
  # * Get Activation State of Selection Item
  #--------------------------------------------------------------------------
  alias passive_current_item_enabled? current_item_enabled?
  def current_item_enabled?
    if @data[index] && @stype_id == Fomar::PASSIVE_SKILL_TYPE
      return @actor.passive_skills.include?(item) || @data[index].mp_cost <= Fomar.passive_points(@actor) - @actor.passive_skills.inject(0) {|cost,skill| cost+skill.mp_cost}
    else
      return passive_current_item_enabled?
    end
  end
end

class Scene_Skill < Scene_ItemBase
  #--------------------------------------------------------------------------
  # * Item [OK]
  #--------------------------------------------------------------------------
  alias passive_on_item_ok on_item_ok
  def on_item_ok
    if item.stype_id == Fomar::PASSIVE_SKILL_TYPE
      if @actor.passive_skills.include?(item)
        @actor.passive_skills.delete(item)
      else
        @actor.passive_skills.push(item)
      end
      @status_window.refresh
      @item_window.refresh
      @item_window.activate
    else
      passive_on_item_ok
    end
  end
end

class Window_ActorCommand < Window_Command
  #--------------------------------------------------------------------------
  # * Add Skill Command to List except Passive
  #--------------------------------------------------------------------------
  def add_skill_commands
    @actor.added_skill_types.sort.each do |stype_id|
      next if stype_id == Fomar::PASSIVE_SKILL_TYPE
      name = $data_system.skill_types[stype_id]
      add_command(name, :skill, true, stype_id)
    end
  end
end

class RPG::Skill
  #--------------------------------------------------------------------------
  # * How many points a skill costs to equip
  #--------------------------------------------------------------------------
  def mp_cost
    return @mp_cost unless @stype_id == Fomar::PASSIVE_SKILL_TYPE
    if @passive_points.nil?
      if @note =~ /<passive_points (.*)>/i
        @passive_points = $1.to_i
      else
        @passive_points = 1
      end
    end
    @passive_points
  end
  #--------------------------------------------------------------------------
  # * Features that the skill provides
  #--------------------------------------------------------------------------
  def features
    if @passive_features.nil?
      @passive_features = []
      if @note =~ /<passive_features (.*)>/i
        for f in $1.split(";")
          feat = f.split(",")
          if feat.size == 1
            @passive_features = $data_states[feat[0].to_i].features.clone
          else
            @passive_features.push(RPG::BaseItem::Feature.new(eval(feat[0]),eval(feat[1]),eval(feat[2])))
          end
        end
      end
    end
    @passive_features
  end
end