=begin
Fade In BGM
by Fomar0153
Version 1.0
----------------------
Notes
----------------------
Allows you to fade in BGM.
----------------------
Instructions
----------------------
First play the BGM you want to fade in.
Then use a script call:
bgm_fadein(frames,volume)
e.g.
bgm_fadein(120,100)
at 60 frames per second that would fade in the music to 100% volume over 2 seconds.
----------------------
Known bugs
----------------------
None
=end

class Game_Interpreter
  #--------------------------------------------------------------------------
  # * Public Instance Variables
  #--------------------------------------------------------------------------
  def bgm_fadein(frames,volume)
    SceneManager.scene.bgm_fadein(frames,volume)
  end
end

class Scene_Base
  #--------------------------------------------------------------------------
  # * Public Instance Variables
  #--------------------------------------------------------------------------
  def bgm_fadein(frames,volume)
    @fadein = RPG::BGM.last
    RPG::BGM.fade(0)
    @t = 1
    @volume = volume
    @frames = frames
  end
  #--------------------------------------------------------------------------
  # * Update Frame (Basic)
  #--------------------------------------------------------------------------
  alias fadein_update_basic update_basic
  def update_basic
    fadein_update_basic
    if @fadein != nil
      @fadein.volume = (@volume * ((@t) / @frames.to_f)).to_i
      @t += 1
      @fadein.play
      if @fadein.volume == @volume
        @fadein = nil
        @volume = nil
        @t = nil
        @frames = nil
      end
    end
  end
end