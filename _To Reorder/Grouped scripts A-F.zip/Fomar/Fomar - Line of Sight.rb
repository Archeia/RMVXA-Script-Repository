=begin
Line of Sight
by Fomar0153
Version 1.0
----------------------
Notes
----------------------
Allows you to have events trigger when they see the player
----------------------
Instructions
----------------------
Nametag events with:
<sight x>
where x is the range.

Also the events should be either player touch or event touch.
----------------------
Known bugs
----------------------
None
=end

class Game_Player < Game_Character
  #--------------------------------------------------------------------------
  # * Trigger Map Event
  #     triggers : Trigger array
  #     normal   : Is priority set to [Same as Characters] ?
  #--------------------------------------------------------------------------
  def start_sight_event(x, y, triggers, normal)
    return if $game_map.interpreter.running?
    $game_map.sight_xy(x, y).each do |event|
      if event.trigger_in?(triggers)
        event.start
      end
    end
  end
  #--------------------------------------------------------------------------
  # * Determine if Same Position Event is Triggered
  #--------------------------------------------------------------------------
  alias sight_check_event_trigger_here check_event_trigger_here
  def check_event_trigger_here(triggers)
    sight_check_event_trigger_here(triggers)
    start_sight_event(@x, @y, [1,2], true) if triggers.include?(1)
  end
end

class Game_Map
  #--------------------------------------------------------------------------
  # * Get Array of Events at Designated Coordinates
  #--------------------------------------------------------------------------
  def sight_xy(x, y)
    @events.values.select {|event| event.see?(x, y) }
  end
end

class Game_CharacterBase
  #--------------------------------------------------------------------------
  # * Determine Coordinate Match
  #--------------------------------------------------------------------------
  def see?(x, y)
    s = sight
    xx = [x, x - (@direction == 6 ? 1 : @direction == 4 ? -1 : 0) * s]
    yy = [y, y - (@direction == 2 ? 1 : @direction == 8 ? -1 : 0) * s]
    @x.between?(xx.min, xx.max) && @y.between?(yy.min, yy.max)
  end
  #--------------------------------------------------------------------------
  # * Determine Range of Sight
  #--------------------------------------------------------------------------
  def sight
    if @sight.nil?
      if !@event.nil? && @event.name =~ /<sight (.*)>/i
        @sight = $1.to_i
      else
        @sight = 0
      end
    end
    @sight
  end
end

class Game_Event < Game_Character
  #--------------------------------------------------------------------------
  # * Change Direction to Designated Direction
  #     d : Direction (2,4,6,8)
  #--------------------------------------------------------------------------
  def set_direction(d)
    super
    check_player_spotted
  end
  #--------------------------------------------------------------------------
  # * Determine if the player is in sight
  #--------------------------------------------------------------------------
  def check_player_spotted
    return if $game_map.interpreter.running? || @starting
    if @trigger == 2 && self.see?($game_player.x,$game_player.y)
      start if !jumping? && normal_priority?
    end
  end
end