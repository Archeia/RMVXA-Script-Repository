=begin
Party Builder
by Fomar0153
Version 1.0
----------------------
Notes
----------------------
Allows you to build your party when clicking new game.
----------------------
Instructions
----------------------
The script will use the first however many actors you tell it to.
Follow the instruction below in the PB module.
=end

module PB
  
  # How big is your party? This is how many database slots this will use.
  PARTY_SIZE = 3
  # These next two variables customise the interface slightly.
  ITEM_HEIGHT = 80
  # 80 = 4 onscreen options, not enough room for faces
  # 106 = 3 onscreen options, enough room for faces
  SHOW_FACES = false
  # Max name length
  MAX_CHAR = 8
  # Begin game text.
  START = "Begin your adventure."
  # Which classes can you choose from? Enter the IDs in the array.
  CLASSES = [1,2]
  # Usually the number below should be the number of classes available but if you have ~20+ set it lower and
  # the choosing window will scroll instead of showing them all.
  CLASS_SLOTS = 2
  # Class descriptions in the same order as they appear in the classes array
  CLASS_DESC = [
  "Soldiers kill things.",
  "Monks also kill things."
  ]
  # Do not edit.
  CLASS_IMG = {}
  # Ok edit below like this:
  #  CLASS_IMG[ CLASS_ID ] = [
  #    ["CHARACTER_NAME", CHARACTER_INDEX,"FACE_NAME", FACE_INDEX], <-- only have a comma if you want to choose
  # from a selection of appearences. Last entry should not have a comma. If there's only one visual choice then
  # the game will not ask players to choose an appearence.
  CLASS_IMG[1] = [
    ["Actor4", 0,"Actor4", 0],
    ["Actor1", 0,"Actor1", 0]
  ]
  CLASS_IMG[2] = [
    ["Actor4", 1,"Actor4", 1]
  ]
  
end

class Window_PartyBuilder < Window_Selectable
  #--------------------------------------------------------------------------
  # * Public Instance Variables
  #--------------------------------------------------------------------------
  attr_accessor :created
  #--------------------------------------------------------------------------
  # * Object Initialization
  #--------------------------------------------------------------------------
  def initialize(help_window)
    @help_window = help_window
    super(0, @help_window.height, window_width, window_height)
    @created = []
    PB::PARTY_SIZE.times do
      @created.push(false)
    end
    refresh
  end
  #--------------------------------------------------------------------------
  # * Get Window Width
  #--------------------------------------------------------------------------
  def window_width
    Graphics.width
  end
  #--------------------------------------------------------------------------
  # * Get Window Height
  #--------------------------------------------------------------------------
  def window_height
    Graphics.height - @help_window.height
  end
  #--------------------------------------------------------------------------
  # * Get Number of Items
  #--------------------------------------------------------------------------
  def item_max
    PB::PARTY_SIZE + 1
  end
  #--------------------------------------------------------------------------
  # * Get Item Height
  #--------------------------------------------------------------------------
  def item_height
    PB::ITEM_HEIGHT
  end
  #--------------------------------------------------------------------------
  # * Get Activation State of Selection Item
  #--------------------------------------------------------------------------
  def current_item_enabled?
    if index == item_max - 1
      for flag in @created
        return false if !flag
      end
      return true
    else
      return true
    end
  end
  #--------------------------------------------------------------------------
  # * Draw Item
  #--------------------------------------------------------------------------
  def draw_item(index)
    rect = item_rect(index)
    if index == item_max - 1
      enabled = true
      for flag in @created
        if !flag
          enabled = false
          break
        end
      end
      change_color(normal_color, enabled)
      draw_text(rect.x,rect.y,rect.width,rect.height,PB::START,1)
      return
    end
    actor = $game_actors[index + 1]
    draw_actor_simple_status(actor, rect.x, rect.y + line_height / 2)
  end
  #--------------------------------------------------------------------------
  # * Draw Simple Status
  #--------------------------------------------------------------------------
  def draw_actor_simple_status(actor, x, y)
    draw_actor_graphic(actor, x + 48, y + 48)
    draw_actor_face(actor, x + 108, y - 8) if PB::SHOW_FACES
    x += 108
    draw_actor_name(actor, x + 120, y)
    draw_actor_class(actor, x + 256, y)
    draw_actor_hp(actor, x + 120, y + line_height * 1)
    draw_actor_mp(actor, x + 256, y + line_height * 1)
  end
  #--------------------------------------------------------------------------
  # * Update Help Text
  #--------------------------------------------------------------------------
  def update_help
    @help_window.set_text("Choose which character to set up.")
  end
end

class Window_ClassCommand < Window_Command
  #--------------------------------------------------------------------------
  # * Object Initialization
  #--------------------------------------------------------------------------
  def initialize(help_window)
    super(0, 0)
    @help_window = help_window
    make_command_list
    refresh
    select(0)
    activate
  end
  #--------------------------------------------------------------------------
  # * Get Window Width
  #--------------------------------------------------------------------------
  def window_width
    return 180
  end
  #--------------------------------------------------------------------------
  # * Get Number of Lines to Show
  #--------------------------------------------------------------------------
  def visible_line_number
    return PB::CLASS_SLOTS
  end
  #--------------------------------------------------------------------------
  # * Create Command List
  #--------------------------------------------------------------------------
  def make_command_list
    for class_id in PB::CLASSES
      add_command($data_classes[class_id].name, :class, true, class_id)
    end
  end
  #--------------------------------------------------------------------------
  # * Update Help Text
  #--------------------------------------------------------------------------
  def update_help
    @help_window.set_text(PB::CLASS_DESC[index])
  end
end

class Window_NameInput < Window_Selectable
  #--------------------------------------------------------------------------
  # * Go Back One Character
  #--------------------------------------------------------------------------
  def process_back
    if @edit_window.back
      Sound.play_cancel
    else
      call_cancel_handler
    end
  end
end

class Window_CharacterChoice < Window_Selectable
  #--------------------------------------------------------------------------
  # * Object Initialization
  #--------------------------------------------------------------------------
  def initialize(characters)
    @characters = characters
    @item_max = characters.size
    super(0,0,108 * characters.size + standard_padding * 2, [196 + standard_padding * 2,Graphics.height].min)
    refresh
    select(0)
  end
  #--------------------------------------------------------------------------
  # * Get Digit Count
  #--------------------------------------------------------------------------
  def col_max
    return @item_max
  end
  #--------------------------------------------------------------------------
  # * Get Number of Items
  #--------------------------------------------------------------------------
  def item_max
    @item_max
  end
  #--------------------------------------------------------------------------
  # * Get Item Height
  #--------------------------------------------------------------------------
  def item_height
    196
  end
  #--------------------------------------------------------------------------
  # * Get Spacing for Items Arranged Side by Side
  #--------------------------------------------------------------------------
  def spacing
    return 0
  end
  #--------------------------------------------------------------------------
  # * Get Activation State of Selection Item
  #--------------------------------------------------------------------------
  def current_item_enabled?
    true
  end
  #--------------------------------------------------------------------------
  # * Draw Item
  #--------------------------------------------------------------------------
  def draw_item(index)
    character = @characters[index]
    rect = item_rect(index)
    draw_character(character[0],character[1], rect.x + 48, rect.y + 64)
    draw_face(character[2],character[3], rect.x + 4, rect.y + 96)
  end
  #--------------------------------------------------------------------------
  # * Refresh
  #--------------------------------------------------------------------------
  def refresh
    create_contents
    draw_all_items
  end
end

class Scene_PartyBuilder < Scene_Base
  #--------------------------------------------------------------------------
  # * Start Processing
  #--------------------------------------------------------------------------
  def start
    super
    create_help_window
    create_party_window
    @party_window.select(0)
    @party_window.activate
  end
  #--------------------------------------------------------------------------
  # * Create Help Window
  #--------------------------------------------------------------------------
  def create_help_window
    @help_window = Window_Help.new
    @help_window.viewport = @viewport
  end
  #--------------------------------------------------------------------------
  # * Create Command Window
  #--------------------------------------------------------------------------
  def create_party_window
    @party_window = Window_PartyBuilder.new(@help_window)
    @party_window.set_handler(:ok,      method(:command_setup))
  end
  #--------------------------------------------------------------------------
  # * Command Setup
  #--------------------------------------------------------------------------
  def command_setup
    if @party_window.index == @party_window.item_max - 1
      command_new_game
      return
    end
    @class_window = Window_ClassCommand.new(@help_window)
    @class_window.x = (Graphics.width - @class_window.width) / 2
    @class_window.y = (Graphics.height - @class_window.height) / 2
    @class_window.z = 100
    @class_window.set_handler(:ok,      method(:command_portrait))
    @class_window.set_handler(:cancel,  method(:command_cancelsetup))
  end
  #--------------------------------------------------------------------------
  # * [New Game] Command
  #--------------------------------------------------------------------------
  def command_new_game
    fadeout_all
    $game_player.refresh
    Graphics.frame_count = 0
    $game_map.autoplay
    SceneManager.goto(Scene_Map)
  end
  #--------------------------------------------------------------------------
  # * Cancel Setup
  #--------------------------------------------------------------------------
  def command_cancelsetup
    @class_window.dispose
    @class_window = nil
    @party_window.created[@party_window.index] = false
    $game_actors[@party_window.index + 1].setup(@party_window.index + 1)
    @party_window.refresh
    @party_window.activate
  end
  #--------------------------------------------------------------------------
  # * Command Portrait
  #--------------------------------------------------------------------------
  def command_portrait
    if PB::CLASS_IMG[@class_window.current_ext].size == 1
      character_name  = PB::CLASS_IMG[@class_window.current_ext][0][0]
      character_index = PB::CLASS_IMG[@class_window.current_ext][0][1]
      face_name       = PB::CLASS_IMG[@class_window.current_ext][0][2]
      face_index      = PB::CLASS_IMG[@class_window.current_ext][0][3]
      $game_actors[@party_window.index + 1].set_graphic(character_name, character_index, face_name, face_index)
      $game_actors[@party_window.index + 1].change_class(@class_window.current_ext)
      $game_actors[@party_window.index + 1].recover_all
      command_name
    else
      @character_window = Window_CharacterChoice.new(PB::CLASS_IMG[@class_window.current_ext])
      @character_window.x = (Graphics.width - @character_window.width) / 2
      @character_window.y = (Graphics.height - @character_window.height) / 2
      @character_window.z = 200
      @character_window.set_handler(:ok,      method(:command_name))
      @character_window.set_handler(:cancel,  method(:command_cancelcharacter))
      @character_window.activate
    end
  end
  #--------------------------------------------------------------------------
  # * Cancel Character
  #--------------------------------------------------------------------------
  def command_cancelcharacter
    @character_window.dispose
    @character_window = nil
    @class_window.activate
  end
  #--------------------------------------------------------------------------
  # * Command Name
  #--------------------------------------------------------------------------
  def command_name
    if PB::CLASS_IMG[@class_window.current_ext].size > 1
      character_name  = PB::CLASS_IMG[@class_window.current_ext][@character_window.index][0]
      character_index = PB::CLASS_IMG[@class_window.current_ext][@character_window.index][1]
      face_name       = PB::CLASS_IMG[@class_window.current_ext][@character_window.index][2]
      face_index      = PB::CLASS_IMG[@class_window.current_ext][@character_window.index][3]
      $game_actors[@party_window.index + 1].set_graphic(character_name, character_index, face_name, face_index)
      $game_actors[@party_window.index + 1].change_class(@class_window.current_ext)
      $game_actors[@party_window.index + 1].recover_all
    end
    @edit_window = Window_NameEdit.new($game_actors[@party_window.index + 1], PB::MAX_CHAR)
    @input_window = Window_NameInput.new(@edit_window)
    @input_window.set_handler(:ok, method(:on_input_ok))
    @input_window.set_handler(:cancel, method(:on_input_cancel))
    @edit_window.z = 300
    @input_window.z = 300
  end
  #--------------------------------------------------------------------------
  # * Input [OK]
  #--------------------------------------------------------------------------
  def on_input_ok
    $game_actors[@party_window.index + 1].name = @edit_window.name
    @edit_window.dispose
    @edit_window = nil
    @input_window.dispose
    @input_window = nil
    @character_window.dispose if @character_window
    @character_window = nil
    @class_window.dispose
    @class_window = nil
    @party_window.created[@party_window.index] = true
    @party_window.refresh
    @party_window.activate
  end
  #--------------------------------------------------------------------------
  # * Input [Cancel]
  #--------------------------------------------------------------------------
  def on_input_cancel
    @edit_window.dispose
    @edit_window = nil
    @input_window.dispose
    @input_window = nil
    if @character_window
      @character_window.activate
    else
      @class_window.activate
    end
  end
end

class Scene_Title < Scene_Base
  #--------------------------------------------------------------------------
  # * [New Game] Command
  #--------------------------------------------------------------------------
  def command_new_game
    DataManager.setup_new_game
    close_command_window
    fadeout_all
    SceneManager.goto(Scene_PartyBuilder)
  end
  #--------------------------------------------------------------------------
  # * Fade Out All Sounds and Graphics
  #--------------------------------------------------------------------------
  def fadeout_all(time = 1000)
    Graphics.fadeout(time * Graphics.frame_rate / 1000)
  end
end
