=begin
Faces to Busts
by Fomar0153
Version 1.0
----------------------
Notes
----------------------
Allows you to use busts in place of faces in the editor.
----------------------
Instructions
----------------------
All busts should be placed in the Faces folder.
They should all contain a symbol in the filename by
default it is "!"
You can change the default values in the Fomar module.
----------------------
Known bugs
----------------------
None
=end

module Fomar
  BUST_SYMBOL = "!"
  BUST_WIDTH = 272
  BUST_HEIGHT = 288
end

class Window_Message < Window_Base
  #--------------------------------------------------------------------------
  # * Draw Face Graphic
  #     enabled : Enabled flag. When false, draw semi-transparently.
  #--------------------------------------------------------------------------
  def draw_face(face_name, face_index, x, y, enabled = true)
    if face_name.include?(Fomar::BUST_SYMBOL)
      if @position == 0
        y = (Graphics.height - Fomar::BUST_HEIGHT)
      else
        y = [2 * (Graphics.height - height) / 2 - Fomar::BUST_HEIGHT,0].max
      end
      screen.pictures[101].show(face_name, 0, 0, y, 100.0, 100.0, 255, 0)
    else
      super(face_name, face_index, x, y, enabled)
    end
  end
  #--------------------------------------------------------------------------
  # * New Page
  #--------------------------------------------------------------------------
  alias bust_new_page new_page
  def new_page(text, pos)
    screen.pictures[101].erase if screen.pictures[101]
    bust_new_page(text, pos)
  end
  #--------------------------------------------------------------------------
  # * Close
  #--------------------------------------------------------------------------
  def close
    screen.pictures[101].erase if screen.pictures[101]
    super
  end
  #--------------------------------------------------------------------------
  # * Screen
  #--------------------------------------------------------------------------
  def screen
    $game_party.in_battle ? $game_troop.screen : $game_map.screen
  end
  #--------------------------------------------------------------------------
  # * Get New Line Position
  #--------------------------------------------------------------------------
  def new_line_x
    if $game_message.face_name.empty? or $game_message.face_name.include?(Fomar::BUST_SYMBOL)
      return 0
    else
      return 112
    end
  end
end

class Sprite_Picture < Sprite
  #--------------------------------------------------------------------------
  # * Update Transfer Origin Bitmap
  #--------------------------------------------------------------------------
  alias bust_update_bitmap update_bitmap
  def update_bitmap
    if !@picture.name.empty? and @picture.name.include?(Fomar::BUST_SYMBOL)
      self.bitmap = Cache.face(@picture.name)
    else
      bust_update_bitmap
    end
  end
end
