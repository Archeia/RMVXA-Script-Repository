#=============================================================================#
# 
#  EatYourBeetS stealing script  v 1.0.3
#
# -1.0.3: Added turn on spot while pressing a default key
# -1.0.2: Added Party Followers Jump and Sprite Change
# -1.0.1: Added Jump speed and Jump height
#
#
#  Desc: This script allow you to jump any time by pressing a button, you
#        can set Jump Button, Jump Se, and delay between jumps, as well
#        as regions and terrain tag which are always "unjumpable"
#        however the script already recognize most of the impassable tiles
#        the only ones not easily recognizable are vertical walls large 1 tile,
#        I suggest either using Region/TerrainTag or making walls large 2 tiles.
#
#  P.S:  The Keyboard_Full_input module can easily be accessed from other 
#        scripts too, you are free to detach it from this script if you want.
#
#  *Free to use anywhere
#  *Credits: EatYourBeetS
#  *If you find bugs or have an idea about how to improve this,
#   please let me know!
#
#  I overwrited update_jump, just for the game_player class, not the events,
#  now you can set the jump speed
#
#=============================================================================# 
module Eat_Jump    
JUMP_BUTTON = :space 
#Refer to the list below, it should cover ALL of the                        
#keyboard input buttons   
JUMP_SE     = RPG::SE.new("Jump1", 60, 120) 
#("Sound.name", volume, pitch)    
DELAY       = 25 
#Delay between jumps(increase this if you use followers)    
JUMP_HEIGHT = 10 
#If you want your player to visit space set it higher!    
JUMP_SPEED  = 1.0
#Don't set it too high, unless you want to teleport    
SPRITE      = 0  
#If you want to change sprite while jumping change this                   
#to the jumping sprite table, remember the "", otherwhise                    
#leave it to 0                     
TURN_ON_SPOT= :ctrl 
#the player will just turn on spot instead of moving if                      
#this button is being pressed, set it to nil if you don't                      
#want this feature (remember that if you set this to                      
#ctrl while playtesting you won't be able to pass through                      
#wall, unless you jump in the meantime)                     
JUMP_SWITCH = 20 
#If this switch is off you can't jump    
IMPASSABLE  = 50 
#You can never jump over tiles with this region id    
PASSABLE    = 51 
#Viceversa    
ALLOWED     = 52 
#These tiles can be jumped over even when jump switch is off    
TERRAINTAG  = 7  
#You can never jump over tiles with this terrain tag, very                   
#useful for walls or trees    
JUMP_DIST   = 2  
#Not ready yet, leave it to 2
end
module Keyboard_Full_input    
#Do not change these | | | |  
#                    V V V V  
CHECK = Win32API.new 'user32', 'GetAsyncKeyState', ['p'], 'i'   
KEYS  = { :lmbutton => 0x01, :backspace => 0x08, :tab => 0x09, :enter => 0x0D, 
:shift => 0x10, :ctrl => 0x11, :alt => 0x12, :pause => 0x13, :caps => 0x14, 
:escape => 0x1B, :space => 0x20, :pageup => 0x21, :pagedown => 0x22, 
:end => 0x23, :home => 0x24, :left => 0x25, :up => 0x26, :right => 0x27, 
:down => 0x28, :print => 0x2C, :insert => 0x2D, :delete => 0x2E, :N0 => 0x30, 
:N1 => 0x31, :N2 => 0x32, :N3 => 0x33, :N4 => 0x34, :N5 => 0x35, :N6 => 0x36, 
:N7 => 0x37, :N8 => 0x38, :N9 => 0x39, :A => 0x41, :B => 0x42, :C => 0x43,
:D => 0x44, :E => 0x45, :F => 0x46, :G => 0x47, :H => 0x48, :I => 0x49, 
:J => 0x4A, :K => 0x4B, :L => 0x4C, :M => 0x4D, :N => 0x4E, :O => 0x4F, 
:P => 0x50, :Q => 0x51, :R => 0x52, :S => 0x53, :T => 0x54, :U => 0x55, 
:V => 0x56, :W => 0x57, :X => 0x58, :Y => 0x59, :Z => 0x5A, :F1 => 0x70, 
:F2 => 0x71, :F3 => 0x72, :F4 => 0x73, :F5 => 0x74, :F6 => 0x75, :F7 => 0x76, 
:F8 => 0x77, :F9 => 0x78, :F10 => 0x79, :F11 => 0x7A, :F12 => 0x7B, 
:num => 0x90, :scroll => 0x91, :lshift => 0xA0, :rshift => 0xA1, :lctrl => 0xA2, 
:rctrl => 0xA3, :lalt => 0xA4, :ralt => 0xA5, :colon => 0xBa, :plus => 0xBB, 
:comma => 0xBC, :minus => 0xBD, :period => 0xBE, :slash => 0xBF, :tilde => 0xC0, 
:lbrace => 0xDB, :backslash => 0xDC, :rbrace => 0xDD, :quote => 0xDE} 
def self.press?(symbol)    
return true unless CHECK.call(KEYS[symbol]) == 0  
end  
end 
#=============================================================================
class Scene_Map < Scene_Base 
#Checks if conditions to jump are met
#=============================================================================  
@@eat_jump_delay = 0
#--------------------------------------------------------------------------
# * Jump update                                     [ALIAS METHOD]
#--------------------------------------------------------------------------
alias eaty_jump_update update
def update  
eaty_jump_update
if @@eat_jump_delay>0  
@@eat_jump_delay-=1  
elsif Keyboard_Full_input.press?(Eat_Jump::JUMP_BUTTON)  
jump_call  
@@eat_jump_delay=Eat_Jump::DELAY 
end
end
#--------------------------------------------------------------------------
# * Jump call                                       [NEW METHOD]
#--------------------------------------------------------------------------
def jump_call
return if !Keyboard_Full_input.press?(Eat_Jump::JUMP_BUTTON)
$game_player.jumperino_check
end 
#=============================================================================
end 
# Scene_Map class end
#=============================================================================
class Game_Player < Game_Character  
#--------------------------------------------------------------------------
# * Jump check                                      [NEW METHOD]
#--------------------------------------------------------------------------
def jumperino_check 
return if $game_message.busy? || $game_message.visible
n=Eat_Jump::JUMP_DIST
d_up = self.direction
d_do = 10-d_up
d_le = eat_other_dir(d_up)
d_ri = eat_other_dir(d_do)
@jdx  = n*(eat_x_mov(d_up))
@jdy  = n*(eat_y_mov(d_up))
x_p2 = self.x + @jdx    
y_p2 = self.y + @jdy    
x_p1 = self.x + @jdx/n  
y_p1 = self.y + @jdy/n  
#-------------
if $game_map.loop_horizontal?   
#Check if looping map  
x_p2=$game_map.round_x(x_p2)  
x_p1=$game_map.round_x(x_p1)
end
if $game_map.loop_vertical?     
#Check if looping map  
y_p2=$game_map.round_y(y_p2)  
y_p1=$game_map.round_y(y_p1)
end  
#-------------
return if $game_switches[Eat_Jump::JUMP_SWITCH]==false && 
$game_map.region_id(x_p1, y_p1)!=Eat_Jump::ALLOWED
#-------------
v2 = total_pass(x_p2, y_p2, d_up, d_do, d_le, d_ri)
#second tile ahead
v1 = total_pass(x_p1, y_p1, d_up, d_do, d_le, d_ri)
#first tile ahead
if v1.include?(3) && !v2.include?(2) 
#v1 always jumpable?     
self.eat_Jump_exec(@jdx,@jdy)
#-----
elsif   v1[1]==1 
#v1 accessible from current direction?  
if    v1[0]==1 
#v1 accessible from opposite direction?  
self.eat_Jump_exec(@jdx,@jdy)
elsif v2[1]==0 || v2.include?(2) 
#v2 not access. from current dir?/Impassable?  
@jdx /= n  
@jdy /= n  
self.eat_Jump_exec(@jdx,@jdy)    
end 
#-----
elsif v1[1]==0   
#v1 unaccessible from current direction?  
if   v1[0]==0 && v2.include?(1) 
#v1 accessible from opp. dir?/v2 accessible?  
self.eat_Jump_exec(@jdx,@jdy)   
end 
end  
#-----
end   
#--------------------------------------------------------------------------
# * Total passability check                              [NEW METHOD]
#-------------------------------------------------------------------------
def total_pass(x, y, d1,d2,d3,d4)
#checks passability for each direction   
pass = Array.new([0,0,0,0])  
#-----  
if $game_map.region_id(x, y) == Eat_Jump::IMPASSABLE ||    
($game_map.terrain_tag(x, y)==Eat_Jump::TERRAINTAG &&     
$game_map.terrain_tag(self.x, self.y)!=Eat_Jump::TERRAINTAG)  
pass=[2,2,2,2]   
return pass  
elsif $game_map.region_id(x, y) == Eat_Jump::PASSABLE  
pass=[3,3,3,3]  
return pass  
end    
#-----  
return pass if $game_player.collide_with_events?(x, y)  
pass[0]+=1  if $game_player.passable?(x, y, d1) 
#forward  
pass[1]+=1  if $game_player.passable?(x, y, d2) 
#backward  
pass[2]+=1  if $game_player.passable?(x, y, d3) 
#left  
pass[3]+=1  if $game_player.passable?(x, y, d4) 
#right  
return pass
end
#--------------------------------------------------------------------------
# * Other directions check                               [NEW METHOD]
#------------------------------------------------------------------------- 
def eat_other_dir(d)
#checks player current left and right 
return 4 if d==8
return 6 if d==2
return 8 if d==4
return 2 if d==6
end
#--------------------------------------------------------------------------
# * Determine x movement                                 [NEW METHOD]
#-------------------------------------------------------------------------   
def eat_x_mov(d)
#define x movement
return 1  if d==6
return -1 if d==4
return 0
end
#--------------------------------------------------------------------------
# * Determine y movement                                 [NEW METHOD]
#-------------------------------------------------------------------------  
def eat_y_mov(d)
#define y movement
return 1  if d==2
return -1 if d==8
return 0  
end
#--------------------------------------------------------------------------
# * Execute jump with sound                              [NEW METHOD]
#------------------------------------------------------------------------- 
def eat_Jump_exec(x_plus,y_plus)
#Execute jump and play sound    
Eat_Jump::JUMP_SE.play    
@followers.move    
@x += x_plus    
@y += y_plus    
distance = Math.sqrt(x_plus * x_plus + y_plus * y_plus).round    
@jump_peak =  distance - @move_speed + Eat_Jump::JUMP_HEIGHT    
@jump_count = @jump_peak * 2    
@stop_count = 0    
#straighten
end
#--------------------------------------------------------------------------
# * Update While Jumping                             [OVERWRITE METHOD]
#--------------------------------------------------------------------------  
def update_jump    
@jump_count -= Eat_Jump::JUMP_SPEED      
if Eat_Jump::SPRITE.is_a?(String)    
@@sprite_name ||= self.character_name     
self.set_graphic("#{Eat_Jump::SPRITE}", self.character_index)     
if @jump_count <= 0    
self.set_graphic("#{@@sprite_name}", self.character_index)    
@@sprite_name=nil     
end      
end    
@real_x = (@real_x * @jump_count + @x) / (@jump_count + 1.0)    
@real_y = (@real_y * @jump_count + @y) / (@jump_count + 1.0)    
update_bush_depth    
if @jump_count <= 0     
 @jump_count=0      
 @followers.each { |f| f.jump(@x - f.x, @y - f.y) }      
 @real_x = @x = $game_map.round_x(@x)      
 @real_y = @y = $game_map.round_y(@y)   
 end  
 end
 #--------------------------------------------------------------------------
 # * move_by_input                                    [OVERWRITE METHOD]
 #--------------------------------------------------------------------------    
 def move_by_input    
 return if !movable? || $game_map.interpreter.running?    
 if Keyboard_Full_input.press?(Eat_Jump::TURN_ON_SPOT)    
 set_direction(Input.dir4)    
 return    
 end    
 move_straight(Input.dir4) if Input.dir4 > 0 
 end
 #================================================================== 
 end   
 # Game_Player class end
 #=============================================================================