#=============================================================================#
# 
#  EatYourBeetS stealing script
#
# In any event put this in the first line: 
# Eaty_Steal(['g',0],32,100,@event_id,10,"How dare you!")
#
# ['g', = item type: 'g'=gold, 'i'=item, 'a'=armor, 'w'=weapon
#   0], = item ID, not checked when you choose 'g'
#  32 , = quantity of item or gold that will be stolen
#  100, = attention level, used to determine the chances of stealing or
#         getting caught, check the formula in Dinamic setup
#  @event_id, used for the self switch, just pass it as @event_id
#  10 , = ID of the switch to activate when caught, 0 if you don't need it 
#         (I use one switch per city)
#  "How dare you!" = optional, determines what will the npc say if you 
#  )                 get caught, you can change the default below
#
#
#  *Free to use anywhere
#  *Credits: EatYourBeetS
#  *If you find bugs or have an idea about how to improve this,
#  please let me know!
#
#=============================================================================#  

class Game_Interpreter
#--------------------------------------------------------------------------
# * Steal from NPCs                                        [NEW METHOD]
#--------------------------------------------------------------------------
def Eaty_Steal(i=['g',0],q=1,a=50,event_id,switch,line)
#=============================================================================
#      Custom conditions
#
#  Add other conditions here if you want, e.g, if you want to steal only when
#  an item is equipped add: 
#  return unless $game_party.members_equip_include?($data_armors[ID])

return unless Input.press?(:SHIFT) #Steal Button(to press with Z/space/enter)
return if $game_switches[switch]==true && switch!=0
#=============================================================================                                  
if $game_self_switches[[$game_map.map_id,event_id,'D']]==false #SW check 
                           #Dinamic setup                          

line.is_a?(String) ? line : (line=nil; line="Thief!") #-> default line
data_id = i[1] #Don't change
#-----
a       = rand(a) + a/5                      #Stealing Formula
value   = a - $game_party.leader.agi         #Stealing Formula
#-----

#============================================================================
#       Stealing successful
#=========================================================================     
if value < 0
        $game_message.background = 1
        $game_message.add("\nYou stole something!")
        $game_self_switches[[map_id,event_id,'D']] = true  #SW ON
       #$game_variables[16] -= 3 #this is my 'karma' variable, 
       #     if you have something similar just change the id       
        q_s=q.to_s+" " if q!=1
        q_s=""         if q==1 
        RPG::SE.new("Chime2", 100, 120).play  #Success Sound
#----------------------------------------------------------------------          
 if i[0] != 'g'         
  if    i[0] == 'w'
      icon = $data_weapons[data_id].icon_index
      name = $data_weapons[data_id].name
      $game_party.gain_item($data_weapons[data_id], q)
  elsif i[0] == 'a'
      icon = $data_armors[data_id].icon_index
      name = $data_armors[data_id].name  
      $game_party.gain_item($data_armors[data_id], q)
  elsif i[0] == 'i'
      icon = $data_items[data_id].icon_index
      name = $data_items[data_id].name
      $game_party.gain_item($data_items[data_id], q)
  end
 $game_message.background = 1
 $game_message.add("#{q_s}#{name} \\i[#{icon}] Obtained!")          
 else
#----------------------------------------------------------------------   
 $game_party.gain_gold(q)
 $game_message.background = 1
 $game_message.add("#{q}\\i[361] Obtained!")  #361 is my gold icon index       
 end      
#==========================================================================
#       Stealing failed
#========================================================================       
elsif  value >= 0 && value < (a/2)
        $game_message.background = 1
        $game_message.add("\nStealing failed!")
elsif  value >= a/2
        $game_message.add("#{line}")
        RPG::SE.new("Reflection", 100, 120).play #Failure Sound
        $game_switches[switch]=true if switch != 0
end
#----------------------------------------------------------------------
else #If Self Switch is on
$game_message.background = 1
$game_message.add("\nYou already stole something") 
end     # Self switch check end
#----------------------------------------------------------------------
command_115 #Exit event processing
end     # Method end

#==============================================================================
end     # Game_Interpreter class end
#==============================================================================