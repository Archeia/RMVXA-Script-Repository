#+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+
# ■ Window_GameCompletion [RMVXace]
# ■ Author: Bigace360 
# ■ Version: 1.0
# ■ Date: 5.25.2012
# Home Blog: http://bigaceworld.wordpress.com/
#+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+ 
#                                INTRODUCTION                                  #
#+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+
#  Shows how much percentage of the game is completed by calling how much a
#  variable is.
#+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+
#                                INSTRUCTIONS                                  #
#+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+
# In the Event Editor, under the Control Variable tab, set the variable to the 
# number you have in the module below. Then have the Operation at Set and then, 
# change the constant to whatever number you want to add between 1~100. 
#+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+
module ACE
	module Completion
		#The set game_variable
		PROGRESS_VARIABLE = 1
	  # The way progress percentage will be displayed.
		COMPLETE_PERCENT  = "%1.0f%%"    
		#Name of the window
		HEADER            = 'Game Completion'
		#Colors for the bar
		PRG_COLOR1 = Color.new(150, 0, 0, 255)
		PRG_COLOR2 = Color.new(255, 255, 60, 255)
		#Color for a 100% game completion bar
		FULL_COLOR = Color.new(0, 255, 0, 255)
	end
end
class Window_Progress < Window_Base
	include ACE::Completion
	attr_reader   :progress   # PROGRESS
	def initialize
		super(0, 0, window_width, fitting_height(2))
		@progress = 0
		refresh
	end
	def window_width;  return 160;                                     end	 
	def progres_v;     return $game_variables[PROGRESS_VARIABLE];      end
	def complete_rate; progres_v > 0 ? @progress.to_f / progres_v : 0; end
	def refresh
		contents.clear
		draw_completion_bar(x, y, progress)
	end
  def draw_gauge(dx, dy, dw, rate, color1, color2)
		dw += 2 if true
		fill_w = dw * progres_v / [100, 1].max
		gauge_h = 12
		gauge_y = dy + 24
		if true
			outline_colour = gauge_back_color
			outline_colour.alpha = translucent_alpha
			self.contents.fill_rect(dx, gauge_y, dw, gauge_h, outline_colour)
			dx += 1
		end
		self.contents.fill_rect(dx, gauge_y, dw, gauge_h, outline_colour)
		contents.gradient_fill_rect(dx, gauge_y, fill_w, gauge_h, color1, color2)
  end
	def draw_completion_bar(x, y, progress, width = 120)
		draw_gauge(x+5, y+10, width, complete_rate, PRG_COLOR1, PRG_COLOR2)
		if progres_v == 100
			draw_gauge(x+5, y+10, width, complete_rate, FULL_COLOR, FULL_COLOR)
		end
		change_color(system_color)
		draw_text(x, y-6, window_width-32, 32, HEADER, 1)
		change_color(normal_color)
		xr = x + width
		if @progress == 0
			text = sprintf(COMPLETE_PERCENT, progres_v)
		else
      text = sprintf(COMPLETE_PERCENT, @progress.to_i * 100 / 100)
    end
    draw_text(x+10, y+15, width, 32, text, 2)
	end
end