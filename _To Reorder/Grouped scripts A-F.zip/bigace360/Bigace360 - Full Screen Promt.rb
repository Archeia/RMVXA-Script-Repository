#+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+
# ■ Full Screen Promt                                      
# ■ Author: Bigace360  
# ■ Version: 1.0
# ■ Date: August 28, 2012
# ■ Blog: http://bigaceworld.wordpress.com/
#+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+
#                               VERSION HISTORY                                #
#+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+
# v 1.0 - 2.28.2012 > Started and Finished Script
#+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+
#                                INTRODUCTION                                  #
#+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+
# This script is for those who want to make the option of haveing the player
# decide if they would want to play in full screen with out having to press
# Alt + Enter
#+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+
#                                INSTRUCTIONS                                  #
#+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+
# This script is plug and play, just paste it ABOVE main, and BELLOW everything
# else! There is small configurations in the module, which can be left alone,
# if you like whats already there.
#+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+
#                                  SECTIONS                                    #
#+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+
#  ■ Game_Objects
# ** ACE Module
# ** SceneManager Module
#
#  ■ Windows
# ** Window_ScreenCommand
#
#  ■ Scenes
# ** Scene_FullPromp
#
#+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+
#
# Credits/Thanks:
#   - Bigace360, for the script.
#
#+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+
#                     Script Conflicts and Compatability                       #
#=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=
# No Known issues
#
#   module SceneManager
#     overwrites - def self.first_scene_class
#+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+
#
#:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=
# ■ Module ACE::Fullscreen
#:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=
module ACE
        module Fullscreen
                #=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
                # - Fullscreen Command Settings -
                #=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
                FULL_COMMANDS =[
                        [:full,   'Full Screen'],
                        [:normal, 'Windowed'],
                ] # Do not remove this.
               
                # Place the following images in the Graphics folder / System if you're
                # planing on have a background, else leave the field blank.
                BACKGROUND = ''
        end
end
 
#:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=
# ■ module SceneManager
#:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=
module SceneManager
        def self.first_scene_class; $BTEST ? Scene_Battle : Scene_FullPromp; end
end
 
#:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=
# ■ Window_ScreenCommand
#:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=
class Window_ScreenCommand < Window_Command
        include ACE::Fullscreen
        def initialize
                super(0, 0)
                update_placement
                self.openness = 0
                open
        end
        def window_width; return 160; end
        def update_placement
                self.x = (Graphics.width - width) / 2
                self.y = (Graphics.height * 1.6 - height) / 2
        end
        def make_command_list
                FULL_COMMANDS.each do |command|
                        case command[0]
                        when :full, :normal then add_command(command[1], command[0])
                        end
                end
        end
end
 
#:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=
# ■ Scene_FullPromp
#:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=
class Scene_FullPromp < Scene_Base
        include ACE::Fullscreen
        $data_system = load_data("Data/System.rvdata2")
        $game_system = Game_System.new 
        def start
                super
                execute_dispose
                create_layout
                create_command_window
        end
        def create_layout
                @background = Plane.new  
                @background.bitmap = Cache.system(BACKGROUND)
                @background.z = 0              
        end
        def execute_dispose
                return if @background.nil?
                Graphics.freeze
                @background.bitmap.dispose
                @background.dispose
                @background = nil
        end
        def create_command_window
                @command_window = Window_ScreenCommand.new
                @command_window.set_handler(:full,   method(:full_mode))
                @command_window.set_handler(:normal, method(:normal_mode))             
        end
        def close_command_window
                @command_window.close
                update until @command_window.close?
        end
        def full_mode
                Sound.play_ok
                keybd = Win32API.new 'user32.dll', 'keybd_event', ['i', 'i', 'l', 'l'], 'v'
                keybd.call(0xA4, 0, 0, 0)
                keybd.call(13, 0, 0, 0)
                keybd.call(13, 0, 2, 0)
                keybd.call(0xA4, 0, 2, 0)
                SceneManager.goto(Scene_Title)
        end
        def normal_mode
                Sound.play_ok
                SceneManager.goto(Scene_Title)
        end
        def update; super; update_slide_window; end
  def update_slide_window; @background.ox += 1; end
        def terminate; super; execute_dispose; end
end