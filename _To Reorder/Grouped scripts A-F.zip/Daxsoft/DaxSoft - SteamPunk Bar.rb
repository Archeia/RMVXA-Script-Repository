#==============================================================================
# • Steampunk Hud
#==============================================================================
# Autor: Dax
# Versão: 2.6
# Site: www.dax-soft.weebly.com
# Requerimento: Dax Core
#==============================================================================
# • Descrição: TODAS AS IMAGENS NA PASTA 'SYSTEM'
#   Description: All the pictures in the paste 'System'
#------------------------------------------------------------------------------
#  Sistema de HUD com Design Steampunk, onde mostra o HP mais o MP. 
#  System of HUD with design Steampunk, where show the hp and the mp.
# **** Para ativar desativar HUD ****
# **** To active/desactive HUD ***
# Aperte a tecla do teclado 'D' — pode se mudar na linha 47
# Press the key of keyboard 'D' - you can change in the line 47.
# Use o comando (No chamar script) : 
# Use the command (In the call script) : 
#  $game_system.steam_hud = true # Ativa a HUD | Active the HUD.
#  $game_system.steam_hud = false # Desativa a HUD | Desactive the HUD.
#==============================================================================
Ligni.register(:steampunk_hud, "dax", 2.6) {
#==============================================================================
# • Game_System
#==============================================================================
class Game_System
  attr_accessor :steam_hud
  alias :steam_hud_initialize :initialize
  def initialize
    steam_hud_initialize
    @steam_hud = true
  end
end
#==============================================================================
# • Steampunk_HUD : Setup
#==============================================================================
rkey = [:steampunk_hud, "dax"]
Ligni.param(rkey, :layout0, "S: Layout 0 - Back HUD")
Ligni.param(rkey, :layout1, "S: Layout 1 - Icon HUD")
Ligni.param(rkey, :layout_effect, "S: Efeito HUD")
Ligni.param(rkey, :hp_meter, "Hp Meter HUD")
Ligni.param(rkey, :mp_meter, "Mp Meter HUD")
Ligni.param(rkey, :blend_type, 1)
Ligni.param(rkey, :speed, 4)
Ligni.param(rkey, :key, :D)
Ligni.param(rkey, :actor_id, 1)
#==============================================================================
# • Sprite_Steampunk_Hud
#==============================================================================
class Sprite_Steampunk_Hud

  def param(key); Ligni.getParam([:steampunk_hud, "dax"], key); end;  
  #----------------------------------------------------------------------------
  # • Inicialização dos objetos.
  #----------------------------------------------------------------------------
  def initialize
    @addon_x = 0
    @addon_y = 0
    @actor = $game_actors[param(:actor_id)]
    @layout0 = Sprite.new(param(:layout0))
    @layout0.z = 200
    @layout0.x = 30 + @addon_x
    @layout0.y = 16 + @addon_y
    @layout1 = Sprite.new(param(:layout1))
    @layout1.z = 203
    @layout1.x = 19 + @addon_x
    @layout1.y = 10 + @addon_y
    @hp = Cache.system(param(:hp_meter))
    @mp = Cache.system(param(:mp_meter))
    @shp = Sprite.new([@hp.width, @hp.height])
    @shp.bitmap.blt(0,0,@hp,Rect.new(0,0,@hp.width.to_p(@actor.hp, @actor.mhp),@hp.height))
    @shp.z = 200
    @shp.x = 42 + @addon_x
    @shp.y = 22 + @addon_y
    @smp = Sprite.new([@mp.width, @mp.height])
    @smp.bitmap.blt(0,0,@mp,Rect.new(0,0,@mp.width.to_p(@actor.mp, @actor.mmp),@mp.height))
    @smp.z = 200
    @smp.x = 44 + @addon_x
    @smp.y = 43 + @addon_y
    @efeito = Sprite.new(param(:layout_effect))
    @efeito.opacity = 128
    @efeito.z = 202
    @efeito.blend_type = param(:blend_type)
    @efeito.x = 42 + @addon_x
    @efeito.y = 22 + @addon_y
  end
  #----------------------------------------------------------------------------
  # • Renovação dos objetos.
  #----------------------------------------------------------------------------
  def dispose
    @layout0.dispose
    @layout1.dispose
    @shp.dispose
    @smp.dispose
    @efeito.dispose
  end
  #----------------------------------------------------------------------------
  # • Atualização dos objetos.
  #----------------------------------------------------------------------------
  def update
    @shp.bitmap.clear
    @smp.bitmap.clear
    @shp.bitmap.blt(0,0,@hp,Rect.new(0,0,@hp.width.to_p(@actor.hp, @actor.mhp),@hp.height))
    @smp.bitmap.blt(0,0,@mp,Rect.new(0,0,@mp.width.to_p(@actor.mp, @actor.mmp),@mp.height))
    trigger?(param(:key)) { $game_system.steam_hud = !$game_system.steam_hud }
    if $game_system.steam_hud
      Opacity.sprite_opacity(@efeito, 2, 122, 62, :efeito_steampunk_hud)
      [@layout0, @layout1, @shp, @smp].each do |variables|
        Opacity.sprite_opacity_out(variables, param(:speed), 255) 
      end
    else
      [@layout0, @layout1, @shp, @smp, @efeito].each do |variables|
        Opacity.sprite_opacity_in(variables, param(:speed), 0) 
      end
    end
  end
end
#==============================================================================
# • Scene_Map
#==============================================================================
class Scene_Map < Scene_Base
  alias :steampunk_hud_main :main
  def main
    @steampunk_hud = Sprite_Steampunk_Hud.new
    steampunk_hud_main
    @steampunk_hud.dispose
  end
  alias :steampunk_hud_update :update
  def update
    steampunk_hud_update
    @steampunk_hud.update
  end
end

}