﻿#==============================================================================
# 
# GaryCXJk - Battle Background v1.02
# * Last Updated: 2012.12.26
# * Level: Medium
# * Requires: N/A
# 
#==============================================================================

$imported = {} if $imported.nil?
$imported["CXJ-BattleBackground"] = true

#==============================================================================
#
# Changelog:
#
#------------------------------------------------------------------------------
# 2012.12.30 - v1.02
#
# * Added: Methods can now be used to draw the background
#
#------------------------------------------------------------------------------
# 2012.12.27 - v1.01
#
# * Added: On refresh, re-initialize battle background set
# * Fixed: Vehicles not workin
# * Fixed: Not copying default settings when on overworld
#
#------------------------------------------------------------------------------
# 2012.12.26 - v1.00
#
# * Initial release
#
#==============================================================================
#
# It's always a hassle to customize the battle backgrounds for each tile.
# It used to be so much easier. With this script, the process is a little
# bit simplified, as you can now modify this simple script or even use
# notetags to customize the battle backgrounds per tile.
#
# Note that it automatically gets disabled when using a custom background,
# as that will get priority over this script. This is intentional.
#
#==============================================================================
#
# Installation:
#
# Make sure to put this below Materials, but above Main Process.
#
# This script overrides several methods. If you are sure no method that is
# used by other scripts get overridden, you can place it anywhere, otherwise,
# make sure this script is loaded first. Do know that there is a possibility
# that this script will stop working due to that.
#
# This script adds aliases for several methods. If you are sure no method that
# is used by other scripts get overridden, you can place it anywhere,
# otherwise, make sure this script is loaded after any other script overriding
# these methods, otherwise this script stops working.
#
#------------------------------------------------------------------------------
# Overridden functions:
#
# * class Spriteset_Battle
#   - battleback1_bitmap
#   - battleback2_bitmap
#   - battleback1_name
#   - battleback2_name
#   - terrain_battleback1_name(type)
#   - terrain_battleback2_name(type)
#   - default_battleback1_name
#
#------------------------------------------------------------------------------
# Aliased methods:
#
# * class Game_Map
#   - setup(map_id)
#   - refresh
#
#==============================================================================
#
# Usage:
#
# You can set the default settings for the script below. You can also use
# notetags.
#
#------------------------------------------------------------------------------
# Map notetags
#
# <battle background set>
# Loads the de default battle background list, as used for the overworld.
#
# <battle background set: string>
# Loads a battle background list from the specified list set below.
#   - string: a string that defines the name of the background list.
#
# <battle background set floor>
# ...
# string
# ...
# </battle background set floor>
# Specifies a list of strings that define which tile needs to use which floor.
#
# <battle background set wall>
# ...
# string
# ...
# </battle background set wall>
# Specifies a list of strings that define which tile needs to use which floor.
#
#------------------------------------------------------------------------------
# String notes
#
# The <battle background set floor> and <battle background set wall> tags both
# use the following string types.
#
# x, ..., x: string_background
# Defines a set of integers that are associated with a background image.
#   - x: an integer that defines a tile number
#   - string_background: a string defining the name of the background image.
#     Use a dash (-) to set it to none. You can also specify a method that
#     draws the bitmap image, if you prefix it with a colon (:).
#
# string_tag: string_background
# Associates a special tag with a background image.
#   - string_tag: the special tag defined below. Use default to set a custom
#     default.
#   - string_background: a string defining the name of the background image.
#     Use a dash (-) to set it to none. You can also specify a method that
#     draws the bitmap image, if you prefix it with a colon (:).
#
#==============================================================================
#
# License:
#
# Creative Commons Attribution 3.0 Unported
#
# The complete license can be read here:
# http://creativecommons.org/licenses/by/3.0/legalcode
#
# The license as it is described below can be read here:
# http://creativecommons.org/licenses/by/3.0/deed
#
# You are free:
#
# to Share — to copy, distribute and transmit the work
# to Remix — to adapt the work
# to make commercial use of the work
#
# Under the following conditions:
#
# Attribution — You must attribute the work in the manner specified by the
# author or licensor (but not in any way that suggests that they endorse you or
# your use of the work).
#
# With the understanding that:
#
# Waiver — Any of the above conditions can be waived if you get permission from
# the copyright holder.
#
# Public Domain — Where the work or any of its elements is in the public domain
# under applicable law, that status is in no way affected by the license.
#
# Other Rights — In no way are any of the following rights affected by the
# license:
#
# * Your fair dealing or fair use rights, or other applicable copyright
#   exceptions and limitations;
# * The author's moral rights;
# * Rights other persons may have either in the work itself or in how the work
#   is used, such as publicity or privacy rights.
#
# Notice — For any reuse or distribution, you must make clear to others the
# license terms of this work. The best way to do this is with a link to this
# web page.
#
#------------------------------------------------------------------------------
# Extra notes:
#
# Despite what the license tells you, I will not hunt down anybody who doesn't
# follow the license in regards to giving credits. However, as it is common
# courtesy to actually do give credits, it is recommended that you do.
#
# As I picked this license, you are free to share this script through any
# means, which includes hosting it on your own website, selling it on eBay and
# hang it in the bathroom as toilet paper. Well, not selling it on eBay, that's
# a dick move, but you are still free to redistribute the work.
#
# Yes, this license means that you can use it for both non-commercial as well
# as commercial software.
#
# You are free to pick the following names when you give credit:
#
# * GaryCXJk
# * Gary A.M. Kertopermono
# * G.A.M. Kertopermono
# * GARYCXJK
#
# Personally, when used in commercial games, I prefer you would use the second
# option. Not only will it actually give me more name recognition in real
# life, which also works well for my portfolio, it will also look more
# professional. Also, do note that I actually care about capitalization if you
# decide to use my username, meaning, capital C, capital X, capital J, lower
# case k. Yes, it might seem stupid, but it's one thing I absolutely care
# about.
#
# Finally, if you want my endorsement for your product, if it's good enough
# and I have the game in my posession, I might endorse it. Do note that if you
# give me the game for free, it will not affect my opinion of the game. It
# would be nice, but if I really did care for the game I'd actually purchase
# it. Remember, the best way to get any satisfaction is if you get people to
# purchase the game, so in a way, I prefer it if you don't actually give me
# a free copy.
#
# This script was originally hosted on:
# http://area91.multiverseworks.com
#
#==============================================================================
#
# The code below defines the settings of this script, and are there to be
# modified.
#
#==============================================================================

module CXJ
  module BATTLE_BACKGROUND
    
    # The default battle background
    DEFAULT_FLOOR = "Grassland"
    DEFAULT_WALL = "Grassland"
    
    # The default vehicle background
    VEHICLE_DEFAULT_FLOOR = "Ship"
    VEHICLE_DEFAULT_WALL = "Ship"
    
    # The default background for each individual vehicle
    VEHICLE ={}
    VEHICLE["FLOOR"] = {
      :boat => "Ship",
      :ship => "Ship",
      :airship => "Ship",
    }
    VEHICLE["WALL"] = {
      :boat => "Ship",
      :ship => "Ship",
      :airship => "Ship",
    }
    
    BACKGROUND_LIST = {}
    #------------------------------------------------------------------------
    # The default background list.
    # You can use symbols, for examples for vehicles, here as well.
    # Use a colon (:) in front of a background name to notify that it is a
    # method, for example, :create_blurry_background_bitmap will call that
    # method instead to draw the background image.
    #------------------------------------------------------------------------
    BACKGROUND_LIST["DEFAULT"] = {}
    # The list for floors.
    BACKGROUND_LIST["DEFAULT"]["FLOOR"] = {
    24 => "Wasteland",
    25 => "Wasteland",
    26 => "DirtField",
    27 => "DirtField",
    32 => "Desert",
    33 => "Desert",
    34 => "Lava1",
    35 => "Lava2",
    40 => "Snowfield",
    41 => "Snowfield",
    42 => "Clouds",
    4 => "PoisonSwamp",
    5 => "PoisonSwamp"
    }
    # The list for walls.
    BACKGROUND_LIST["DEFAULT"]["WALL"] = {
    20 => "Forest1",
    21 => "Forest1",
    22 => "Cliff",
    30 => "Cliff",
    38 => "Cliff",
    24 => "Wasteland",
    25 => "Wasteland",
    26 => "Wasteland",
    27 => "Wasteland",
    32 => "Desert",
    33 => "Desert",
    34 => "Lava",
    35 => "Lava",
    40 => "Snowfield",
    41 => "Snowfield",
    42 => "Clouds",
    4 => "PoisonSwamp",
    5 =>"PoisonSwamp"
    }
    
    # Associate special tags with symbols here, for use with special
    # functionality.
    SPECIAL_TAGS = {
    "default" => :default, # Defines a custom default tag, do not remove.
    "boat" => :boat,
    "ship" => :ship,
    "airship" => :airship,
    }

    #------------------------------------------------------------------------
    # Add methods below, or in the class Spriteset_Battle.
    # It is preferable to add them to the Spriteset_Battle class for better
    # compatibility, which is why there is a special block below. However,
    # in most instances you could put the methods here if you want to, for
    # example to keep the code as clean as possible.
    #------------------------------------------------------------------------
  end
end

#==============================================================================
# ** Spriteset_Battle
#------------------------------------------------------------------------------
#  This class brings together battle screen sprites. It's used within the
# Scene_Battle class.
#==============================================================================
#  Add methods below.
#==============================================================================

class Spriteset_Battle
  #--------------------------------------------------------------------------
  # * New Create Battle Background Bitmap from Processed Map Screen
  #--------------------------------------------------------------------------
  def cxj_bb_create_background_bitmap
    source = SceneManager.background_bitmap
    bitmap = Bitmap.new(640, 480)
    bitmap.stretch_blt(bitmap.rect, source, source.rect)
    bitmap
  end
  
  #--------------------------------------------------------------------------
  # * New Create Battle Background Bitmap from Processed Map Screen
  #     Top half only
  #--------------------------------------------------------------------------
  def cxj_bb_create_background_bitmap_top_only
    source = SceneManager.background_bitmap
    bitmap = Bitmap.new(640, 480)
    cprc = Rect.new(0, 0, 640, 240)
    bitmap.stretch_blt(cprc, source, cprc)
    bitmap
  end
end

#==============================================================================
#
# The code below should not be altered unless you know what you're doing.
#
#==============================================================================

#==============================================================================
# ** RPG::Map
#------------------------------------------------------------------------------
#  The data class for maps.
#==============================================================================

class RPG::Map
  attr_accessor :battle_background_set

  #--------------------------------------------------------------------------
  # * New: Initializing Battle Background Set
  #     Processes all the notetags.
  #--------------------------------------------------------------------------
  def initialize_battle_background_set
    # The following line makes sure the set is empty but existing.
    @battle_background_set = {
    "FLOOR" => {},
    "WALL" => {}
    }
    
    # These tags are used later on to determine in which list the data has to
    # be put.
    tag_type = ["", "FLOOR", "WALL"]
    
    # This will define which of the two tags have been opened.
    tag_opened = 0
    
    # Loads the default background set in if the appropriate tag has been
    # used, or if the tileset is in Field mode.
    @battle_background_set = CXJ::BATTLE_BACKGROUND::BACKGROUND_LIST["DEFAULT"].dup if $data_tilesets[self.tileset_id].mode == 0 || self.note =~ /<battle background set>/i
    
    # Loads a specified background set.
    if self.note =~ /<battle background set:\s*(.*)>/i
      @battle_background_set = CXJ::BATTLE_BACKGROUND::BACKGROUND_LIST[$1].dup if !CXJ::BATTLE_BACKGROUND::BACKGROUND_LIST[$1].nil?
    end
    
    # Splits each line to process the tags.
    self.note.split(/[\r\n]+/).each { |line|
      case line
      when /<battle background set floor>/i # Floor tag opened
        tag_opened = 1
      when /<\/battle background set floor>/i # Floor tag closed
        tag_opened = 0 if tag_opened = 1
      when /<battle background set wall>/i # Wall tag opened
        tag_opened = 2
      when /<\/battle background set wall>/i # Wall tag closed
        tag_opened = 0 if tag_opened = 2
      when /(\d+(?:\s*,\s*\d+)*)\s*:\s*(.*)\s*/i # Label by tile number
        next unless tag_opened > 0
        bbg_name = ($2 == '-' ? '' : $2)
        $1.scan(/\d+/).each { |num|
        @battle_background_set[tag_type[tag_opened]][num.to_i] = bbg_name}
      when /(.*)\s*:\s*(.*)\s*/i # Label by special tag
        next unless tag_opened > 0
        special_tag = battle_background_set_special_tag($1)
        bbg_name = ($2 == '-' ? '' : $2)
        @battle_background_set[tag_type[tag_opened]][special_tag] = bbg_name if !special_tag.nil?
      end
    }
  end
  
  #--------------------------------------------------------------------------
  # * New: Getting the Special Tag's Canonical Name
  #--------------------------------------------------------------------------
  def battle_background_set_special_tag(special_tag)
    CXJ::BATTLE_BACKGROUND::SPECIAL_TAGS[special_tag] if !CXJ::BATTLE_BACKGROUND::SPECIAL_TAGS[special_tag].nil?
  end
end

#==============================================================================
# ** Game_Map
#------------------------------------------------------------------------------
#  This class handles maps. It includes scrolling and passage determination
# functions. The instance of this class is referenced by $game_map.
#==============================================================================

class Game_Map
  #--------------------------------------------------------------------------
  # * Alias: Setup
  #--------------------------------------------------------------------------
  alias game_map_setup_cxj_bb setup
  def setup(map_id)
    game_map_setup_cxj_bb(map_id)
    @map.initialize_battle_background_set
  end
  
  #--------------------------------------------------------------------------
  # * New: Checks For Battle Background
  #--------------------------------------------------------------------------
  def has_battle_background_set?
    (@map.battle_background_set["FLOOR"].size + @map.battle_background_set["WALL"].size) > 0
  end
  #--------------------------------------------------------------------------
  # * New: Battle Background
  #--------------------------------------------------------------------------
  def battle_background_set
    @map.battle_background_set
  end
  
  #--------------------------------------------------------------------------
  # * Alias: Refresh
  #--------------------------------------------------------------------------
  alias game_map_refresh_cxj_bb refresh
  def refresh
    game_map_refresh_cxj_bb
    @map.initialize_battle_background_set
  end
  
  #--------------------------------------------------------------------------
  # * New: Add New Set Data
  #--------------------------------------------------------------------------
  def add_battle_background(key, image, on_floor, on_wall)
    bbg_name = (image == '-' ? '' : image)
    if key.kind_of?(Enumerable)
      key.collect do |subkey|
        add_battle_background(subkey, image, on_floor, on_wall)
      end
    elsif key.kind_of?(String)
      special_tag = battle_background_set_special_tag(key)
      if !special_tag.nil?
        @map.battle_background_set["FLOOR"][special_tag] = bbg_name if on_floor
        @map.battle_background_set["WALL"][special_tag] = bbg_name if on_wall
      end
    else
      @map.battle_background_set["FLOOR"][key] = bbg_name if on_floor
      @map.battle_background_set["WALL"][key] = bbg_name if on_wall
    end
  end
  
  #--------------------------------------------------------------------------
  # * New: Remove New Set Data
  #--------------------------------------------------------------------------
  def remove_battle_background(key, on_floor, on_wall)
    if key.kind_of?(Enumerable)
      key.collect do |subkey|
        remove_battle_background(subkey, on_floor, on_wall)
      end
    elsif key.kind_of?(String)
      special_tag = battle_background_set_special_tag(key)
      if !special_tag.nil?
        battle_background_set["FLOOR"].delete(special_tag) if on_floor
        battle_background_set["WALL"].delete(special_tag) if on_wall
      end
    else
        battle_background_set["FLOOR"].delete(key) if on_floor
        battle_background_set["WALL"].delete(key) if on_wall
    end
  end
end

class Spriteset_Battle
  #--------------------------------------------------------------------------
  # * Override: Get Battle Background (Floor) Bitmap
  #--------------------------------------------------------------------------
  def battleback1_bitmap
    bb1_name = battleback1_name
    if bb1_name
      if bb1_name[0,1] == ":"
        bb1_sym = bb1_name[1, bb1_name.size - 1].to_sym
        bb1_mtd = method(bb1_sym) if respond_to?(bb1_sym)
        bb1_mtd = CXJ::BATTLE_BACKGROUND.method(bb1_sym) if bb1_mtd.nil? && CXJ::BATTLE_BACKGROUND.respond_to?(bb1_sym)
        return bb1_mtd.call if !bb1_mtd.nil?
      end
      Cache.battleback1(battleback1_name)
    else
      create_blurry_background_bitmap
    end
  end
  #--------------------------------------------------------------------------
  # * Override: Get Battle Background (Wall) Bitmap
  #--------------------------------------------------------------------------
  def battleback2_bitmap
    bb2_name = battleback2_name
    if bb2_name
      if bb2_name[0,1] == ":"
        bb2_sym = bb2_name[1, bb2_name.size - 1].to_sym
        bb2_mtd = method(bb2_sym) if respond_to?(bb2_sym)
        bb2_mtd = CXJ::BATTLE_BACKGROUND.method(bb2_sym) if bb2_mtd.nil? && CXJ::BATTLE_BACKGROUND.respond_to?(bb2_sym)
        return bb2_mtd.call if !bb2_mtd.nil?
      end
      Cache.battleback2(battleback2_name)
    else
      Bitmap.new(1, 1)
    end
  end
  #--------------------------------------------------------------------------
  # * Override: Get Filename of Battle Background (Floor)
  #--------------------------------------------------------------------------
  def battleback1_name
    if $BTEST
      $data_system.battleback1_name
    elsif $game_map.battleback1_name
      $game_map.battleback1_name
    elsif $game_map.has_battle_background_set?
      custom_battleback1_name
    elsif $game_map.overworld?
      overworld_battleback1_name
    end
  end
  #--------------------------------------------------------------------------
  # * Override: Get Filename of Battle Background (Wall)
  #--------------------------------------------------------------------------
  def battleback2_name
    if $BTEST
      $data_system.battleback2_name
    elsif $game_map.battleback2_name
      $game_map.battleback2_name
    elsif $game_map.has_battle_background_set?
      custom_battleback2_name
    elsif $game_map.overworld?
      overworld_battleback2_name
    end
  end
  #--------------------------------------------------------------------------
  # * New: Get Filename of Field Battle Background (Floor)
  #--------------------------------------------------------------------------
  def custom_battleback1_name
    return custom_ship_battleback1_name if $game_player.vehicle
    return custom_terrain_battleback1_name(autotile_type(1)) ||
    custom_terrain_battleback1_name(autotile_type(0)) ||
    custom_default_battleback1_name
  end
  #--------------------------------------------------------------------------
  # * New: Get Filename of Field Battle Background (Wall)
  #--------------------------------------------------------------------------
  def custom_battleback2_name
    return custom_ship_battleback2_name if $game_player.vehicle
    return custom_terrain_battleback2_name(autotile_type(1)) ||
    custom_terrain_battleback2_name(autotile_type(0)) ||
    custom_default_battleback2_name
  end
  #--------------------------------------------------------------------------
  # * Get Filename of Battle Background (Floor) Corresponding to Terrain
  #--------------------------------------------------------------------------
  def custom_terrain_battleback1_name(type)
    $game_map.battle_background_set["FLOOR"][type] if !$game_map.battle_background_set["FLOOR"][type].nil?
  end
  #--------------------------------------------------------------------------
  # * Get Filename of Battle Background (Wall) Corresponding to Terrain
  #--------------------------------------------------------------------------
  def custom_terrain_battleback2_name(type)
    $game_map.battle_background_set["WALL"][type] if !$game_map.battle_background_set["WALL"][type].nil?
  end
  #--------------------------------------------------------------------------
  # * Override: Get Filename of Battle Background (Floor) Corresponding to Terrain
  #--------------------------------------------------------------------------
  def terrain_battleback1_name(type)
    CXJ::BATTLE_BACKGROUND::BACKGROUND_LIST["DEFAULT"]["FLOOR"][type] if !CXJ::BATTLE_BACKGROUND::BACKGROUND_LIST["DEFAULT"]["FLOOR"][type].nil?
  end
  #--------------------------------------------------------------------------
  # * Override: Get Filename of Battle Background (Wall) Corresponding to Terrain
  #--------------------------------------------------------------------------
  def terrain_battleback2_name(type)
    CXJ::BATTLE_BACKGROUND::BACKGROUND_LIST["DEFAULT"]["WALL"][type] if !CXJ::BATTLE_BACKGROUND::BACKGROUND_LIST["DEFAULT"]["WALL"][type].nil?
  end
  #--------------------------------------------------------------------------
  # * New: Get Filename of Battle Background (Floor) When on Ship
  #--------------------------------------------------------------------------
  def custom_ship_battleback1_name
    !$game_map.battle_background_set["FLOOR"][$game_player.vehicle].nil? ?
    $game_map.battle_background_set["FLOOR"][$game_player.vehicle] :
    ship_battleback1_name
  end
  #--------------------------------------------------------------------------
  # * New: Get Filename of Battle Background (Wall) When on Ship
  #--------------------------------------------------------------------------
  def custom_ship_battleback2_name
    !$game_map.battle_background_set["WALL"][$game_player.vehicle_type].nil? ?
    $game_map.battle_background_set["WALL"][$game_player.vehicle_type] :
    ship_battleback2_name
  end
  #--------------------------------------------------------------------------
  # * Override: Get Filename of Default Battle Background (Floor)
  #--------------------------------------------------------------------------
  def custom_default_battleback1_name
    !$game_map.battle_background_set["FLOOR"][:default].nil? ?
    $game_map.battle_background_set["FLOOR"][:default] :
    default_battleback1_name
  end
  #--------------------------------------------------------------------------
  # * Override: Get Filename of Default Battle Background (Wall)
  #--------------------------------------------------------------------------
  def custom_default_battleback2_name
    !$game_map.battle_background_set["WALL"][:default].nil? ?
    $game_map.battle_background_set["WALL"][:default] :
    default_battleback2_name
  end
  #--------------------------------------------------------------------------
  # * Override: Get Filename of Default Battle Background (Floor)
  #--------------------------------------------------------------------------
  def default_battleback1_name
    CXJ::BATTLE_BACKGROUND::DEFAULT_FLOOR
  end
  #--------------------------------------------------------------------------
  # * Override: Get Filename of Default Battle Background (Wall)
  #--------------------------------------------------------------------------
  def default_battleback2_name
    CXJ::BATTLE_BACKGROUND::DEFAULT_WALL
  end
  #--------------------------------------------------------------------------
  # * Override: Get Filename of Battle Background (Floor) When on Ship
  #--------------------------------------------------------------------------
  def ship_battleback1_name
    !CXJ::BATTLE_BACKGROUND::VEHICLE["FLOOR"][$game_player.vehicle_type].nil? ?
    CXJ::BATTLE_BACKGROUND::VEHICLE["FLOOR"][$game_player.vehicle_type] :
    CXJ::BATTLE_BACKGROUND::VEHICLE_DEFAULT_FLOOR
  end
  #--------------------------------------------------------------------------
  # * Override: Get Filename of Battle Background (Wall) When on Ship
  #--------------------------------------------------------------------------
  def ship_battleback2_name
    !CXJ::BATTLE_BACKGROUND::VEHICLE["WALL"][$game_player.vehicle_type].nil? ?
    CXJ::BATTLE_BACKGROUND::VEHICLE["WALL"][$game_player.vehicle_type] :
    CXJ::BATTLE_BACKGROUND::VEHICLE_DEFAULT_WALL
  end
end
#==============================================================================
# ** Game_Player
#------------------------------------------------------------------------------
#  This class handles the player. It includes event starting determinants and
# map scrolling functions. The instance of this class is referenced by
# $game_player.
#==============================================================================

class Game_Player < Game_Character
  #--------------------------------------------------------------------------
  # * New: Vehicle Type
  #--------------------------------------------------------------------------
  def vehicle_type
    @vehicle_type
  end
end