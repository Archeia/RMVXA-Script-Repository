#==============================================================================
# 
# GaryCXJk - TimeZowned v1.00
# * Last Updated: 2013.06.17
# * Level: Hard
# * Requires: N/A
# * Optional: CXJ - Savedata Extender v1.01+
# 
#==============================================================================

$imported = {} if $imported.nil?
$imported["CXJ-TimeZowned"] = "1.00"

#==============================================================================
#
# Changelog:
#
#------------------------------------------------------------------------------
# 2013.06.17 - v1.00
#
# * Initial release
#
#==============================================================================
#
# Everybody loves real-time time progression, and most do that by adding a
# day-night cycle. Harder would be however to add a calendar system.
#
# Now, this script doesn't add a day-night cycle or an actual calendar, but
# it does provide you with a framework to work with.
#
#==============================================================================
#
# Installation:
#
# Make sure to put this below Materials, but above Main Process.
#
# This script adds aliases for several methods. If you are sure no method that
# is used by other scripts get overridden, you can place it anywhere,
# otherwise, make sure this script is loaded after any other script overriding
# these methods, otherwise this script stops working.
#
#------------------------------------------------------------------------------
# Aliased methods:
#
# * module DataManager
#   - self.create_game_objects
#   - self.make_save_header (Without Savedata Extender)
#   - self.make_save_contents (Without Savedata Extender)
#   - self.extract_save_contents (Without Savedata Extender)
# * class Window_Base
#   - convert_escape_characters
# * class Scene_Base
#   - update
#
#==============================================================================
#
# Usage:
#
# When left alone, TimeZowned will run at a set pace as long as the global
# variable $cxj_timezowned_running or a defined switch is enabled. The total
# amount of seconds passed since the start of a new game is stored in an array
# called $cxj_timezowned_time, and the amount of frames between each second
# is stored as an integer in $cxj_timezowned_frame.
#
# The amount of seconds passed are stored in an array because this would allow
# for a very big amount of seconds, larger than even a 64-bit long could store.
# The smallest number is stored at index 0, with each being at most 999,999,999
# long. So, if the amount of seconds is 122,333,444,455,555, then index 0
# contains 444455555 while index 1 contains 122333.
#
# This information is required when you're writing your own date format. There
# are five methods that zones use. The first method calculates the current
# date from the amount of seconds and the given data. The second converts this
# date to a readable string. The third calculates the current time, and the
# fourth converts the time to a readable string. Finally, the fifth method
# converts the date to a readable string using a format string.
#
# This script already is preloaded with two sets of these methods. The first
# one emulates the Earth calendar without the leap years, the second does this
# with leap years. Use these as a reference for your own system, although you
# could always just fall back on the default.
#
# When writing your own script, you are always free in your choice of output
# format, but do know that the second, fourth and fifth method (all three
# used to display the date and time in a readable format) are used in the text
# output.
#
# To display the current date in a dialog, you can use either of the three
# text strings:
#
# [[timezowned_date zone]]
# [[timezowned_time zone]]
# [[timezowned_datef zone format]]
#
# The formatted date in the default scripts works similar to most other date
# formatting strings.
#
# d - Day of the month, two digits with leading zeros
# D - Textual representation of the day of the week, three letters (Mon, Tue..)
# j - Day of the month, no leading zeros
# l - Full textual representation of the day of the week (Monday, Tuesday...)
# F - Full representation of the month (January, February...)
# m - Numeric representation of the month, two digits with leading zeros
# M - Short textual representation of the month, three letters (Jan, Feb...)
# n - Numeric representation of the month, no leading zeros
# Y - Year, four digits
# H - 24-hour format of the hour, two digits with leading zeros
# i - Minutes, two digits with leading zeros
# s - Seconds, two digits with leading zeros
#
#==============================================================================
#
# License:
#
# Creative Commons Attribution 3.0 Unported
#
# The complete license can be read here:
# http://creativecommons.org/licenses/by/3.0/legalcode
#
# The license as it is described below can be read here:
# http://creativecommons.org/licenses/by/3.0/deed
#
# You are free:
#
# to Share — to copy, distribute and transmit the work
# to Remix — to adapt the work
# to make commercial use of the work
#
# Under the following conditions:
#
# Attribution — You must attribute the work in the manner specified by the
# author or licensor (but not in any way that suggests that they endorse you or
# your use of the work).
#
# With the understanding that:
#
# Waiver — Any of the above conditions can be waived if you get permission from
# the copyright holder.
#
# Public Domain — Where the work or any of its elements is in the public domain
# under applicable law, that status is in no way affected by the license.
#
# Other Rights — In no way are any of the following rights affected by the
# license:
#
# * Your fair dealing or fair use rights, or other applicable copyright
#   exceptions and limitations;
# * The author's moral rights;
# * Rights other persons may have either in the work itself or in how the work
#   is used, such as publicity or privacy rights.
#
# Notice — For any reuse or distribution, you must make clear to others the
# license terms of this work. The best way to do this is with a link to this
# web page.
#
#------------------------------------------------------------------------------
# Extra notes:
#
# Despite what the license tells you, I will not hunt down anybody who doesn't
# follow the license in regards to giving credits. However, as it is common
# courtesy to actually do give credits, it is recommended that you do.
#
# As I picked this license, you are free to share this script through any
# means, which includes hosting it on your own website, selling it on eBay and
# hang it in the bathroom as toilet paper. Well, not selling it on eBay, that's
# a dick move, but you are still free to redistribute the work.
#
# Yes, this license means that you can use it for both non-commercial as well
# as commercial software.
#
# You are free to pick the following names when you give credit:
#
# * GaryCXJk
# * Gary A.M. Kertopermono
# * G.A.M. Kertopermono
# * GARYCXJK
#
# Personally, when used in commercial games, I prefer you would use the second
# option. Not only will it actually give me more name recognition in real
# life, which also works well for my portfolio, it will also look more
# professional. Also, do note that I actually care about capitalization if you
# decide to use my username, meaning, capital C, capital X, capital J, lower
# case k. Yes, it might seem stupid, but it's one thing I absolutely care
# about.
#
# Finally, if you want my endorsement for your product, if it's good enough
# and I have the game in my possession, I might endorse it. Do note that if you
# give me the game for free, it will not affect my opinion of the game. It
# would be nice, but if I really did care for the game I'd actually purchase
# it. Remember, the best way to get any satisfaction is if you get people to
# purchase the game, so in a way, I prefer it if you don't actually give me
# a free copy.
#
# This script was originally hosted on:
# http://area91.multiverseworks.com
#
#==============================================================================
#
# The code below defines the settings of this script, and are there to be
# modified.
#
#==============================================================================
module CXJ
  module TIMEZOWNED
    #------------------------------------------------------------------------
    # Basic settings.
    #------------------------------------------------------------------------
    TIME_RUNS_ON_NEW_GAME = true  # Whether it will run on a new game
    TIME_ON_MENU = false          # Whether it will run on menus
    TIME_DURING_BATTLE = true     # Whether it will run during combat
    
    # Switch ID that enables / disables TimeZowned (0 to use global variable)
    TIME_SWITCH = 0
    
    # The amount of seconds per real-life second.
    TIME_PER_SECOND = 1
    
    #------------------------------------------------------------------------
    # Time zones
    # These define the different zones of time. This however isn't
    # restricted to actual time zones, you can define different types of
    # date / time systems.
    #
    # Usage:
    #
    # :zone => [
    #   [:date, :display_date, :time, :display_time, :formatted_date]], data
    #   ]
    #
    # Data can be of any type, as you yourself need to define what the type
    # is in your own methods. Also, if you aren't planning on using a certain
    # method or that method isn't implemented, you should set it to nil.
    #------------------------------------------------------------------------
    ZONES = {
      :default=> [[:date_default, :disp_date_default, :time_default, :disp_time_default, :disp_datef_default], [1970, 1, 1, 0, 0, 0, :thu, :EARTH_MONTHS, :EARTH_DAYS]],
      :earth => [[:date_earth, :disp_date_earth, :time_earth, :disp_time_earth, :disp_datef_earth], [1970, 1, 1, 0, 0, 0, :thu]],
      :bttf2 => [[:date_earth, :disp_date_earth, :time_earth, :disp_time_earth, :disp_datef_earth], [2015, 10, 21, 12, 0, 0, :wed]],
    }
    
    #------------------------------------------------------------------------
    # Use this module (CXJ::HT_CREDITS::METHODS) to add new methods.
    #------------------------------------------------------------------------
    module METHODS
      
      EARTH_MONTHS = [
      [31, :jan, "January", "Jan"],
      [28, :feb, "February", "Feb"],
      [31, :mar, "March", "Mar"],
      [30, :apr, "April", "Apr"],
      [31, :may, "May", "May"],
      [30, :jun, "June", "Jun"],
      [31, :jul, "July", "Jul"],
      [31, :aug, "August", "Aug"],
      [30, :sep, "September", "Sep"],
      [31, :oct, "October", "Oct"],
      [30, :nov, "November", "Nov"],
      [31, :dec, "December", "Dec"]
      ]
      
      EARTH_DAYS = [
      [:mon, "Monday", "Mon"],
      [:tue, "Tuesday", "Tue"],
      [:wed, "Wednesday", "Wed"],
      [:thu, "Thursday", "Thu"],
      [:fri, "Friday", "Fri"],
      [:sat, "Saturday", "Sat"],
      [:sun, "Sunday", "Sun"]
      ]
      
      #----------------------------------------------------------------------
      # * Get the current date (Default)
      #----------------------------------------------------------------------
      def self.date_default(zone, base_data = nil, current_time = $cxj_timezowned_time)
        if base_data.nil?
          data = [1970, 1, 1, 0, 0, 0]
          month_data = EARTH_MONTHS
        else
          data = [base_data[0], base_data[1], base_data[2], base_data[3], base_data[4], base_data[5]]
          month_data = (base_data[7].nil? ? EARTH_MONTHS : const_get(base_data[7]))
        end
        
        data[1]-= 1
        data[2]-= 1
        
        total_days = 0
        for i in 0..(month_data.size - 1)
          total_days+= month_data[i][0]
        end
        
        #....................................................................
        # Calculate the total amount of days passed.
        #....................................................................
        spd = 60 * 60 * 24
        i = current_time.size - 1
        num = 0
        days = []
        cur = current_time[i]
        remainder = 0
        while i >= 0
          num+= cur / spd
          days.unshift(num)
          num = 0
          remainder = cur % spd
          i-= 1
          break if i < 0
          cur = current_time[i]
          next if remainder == 0
          maxval = 100000000
          minval = 10
          while cur / maxval + remainder * minval < spd
            maxval/= 10
            minval*= 10
          end
          num = ((cur / maxval + remainder * minval) / spd) * maxval
          cur-= (cur / maxval) * maxval
        end
        while days[-1] == 0
          days.pop
        end
        remsec = remainder
        
        #....................................................................
        # Calculate the total amount of years passed.
        #....................................................................
        dpy = spd * total_days
        i = days.size - 1
        num = 0
        years = []
        cur = days[i]
        remainder = 0
        while i>= 0
          num+= cur / dpy
          years.unshift(num)
          num = 0
          remainder = cur % dpy
          i-= 1
          break if i < 0
          cur = days[i]
          next if remainder == 0
          maxval = 100000000
          minval = 10
          while cur / maxval + remainder * minval < dpy
            maxval/= 10
            minval*= 10
          end
          num = ((cur / maxval + remainder * minval) / dpy) * maxval
          cur-= (cur / maxval) * maxval
        end
        while years[-1] == 0
          years.pop
        end
        remdays = remainder

        #....................................................................
        # Calculate the current date.
        #....................................................................
        years[0] = 0 if years.empty?
        date = [data[0] + years[0],data[1],data[2],data[3],data[4],data[5]]
        remdays+= date[2]
        date[2] = 0
        while remdays > month_data[date[1]][0] - date[2]
          remdays-= month_data[date[1]][0] - date[2]
          date[1] += 1
          date[2] = 0
          if date[1] >= month_data.size
            date[1]-= month_data.size
            date[0]+= 1
          end
        end
        date[2] = remdays
        
        date[3] = date[3] + remsec / (60 * 60)
        date[4] = date[4] + (remsec % 3600) / 60
        date[5] = date[5] + remsec % 60
        
        while date[5] >= 60
          date[5]-= 60
          date[4]+= 1
        end
        
        while date[4] >= 60
          date[4]-= 60
          date[3]+= 1
        end
        
        while date[3] >= 24
          date[3]-= 24
          date[2]+= 1
        end
        while date[2] >= month_data[date[1]][0]
          date[2]-= month_data[date[1]][0]
          date[1]+= 1
          if date[1] >= month_data.size
            date[1]-= month_data.size
            date[0]+= 1
          end
        end
        
        while date[1] >= month_data.size
          date[1]-= month_data.size
          date[0]+= 1
        end
        
        i = 0
        years[0] = date[0]
        while years[i] > 999999999
          years[i]-= 999999999
          years[i + 1] = 0 if years[i + 1].nil?
          years[i + 1]+= 1
          next if years[i] > 999999999
          i+= 1
        end
        
        date[0] = years
        date[1]+= 1
        date[2]+= 1
        
        return_date = {
          :year => date[0],
          :month => date[1],
          :day => date[2],
          :hour => date[3],
          :minute => date[4],
          :second => date[5]
        }
      end

      #----------------------------------------------------------------------
      # * Display the current date (Default)
      #----------------------------------------------------------------------
      def self.disp_date_default(zone, base_data = nil, current_time = $cxj_timezowned_time)
        data = date_default(zone, base_data, current_time)
        
        month_data = (base_data[7].nil? ? EARTH_MONTHS : const_get(base_data[7]))

        years = data[:year]
        str_y = ""
        while !years.empty?
          str_y+= sprintf((str_y.empty? ? "%d" : "%09d"), years.pop)
        end
        str_year = ""
        if(str_y.size > 4)
          str_year = str_y[0, str_y.size % 3] if str_y.size % 3 != 0
          for i in 0..str_y.size / 3 - 1
            str_year+= "," if !str_year.empty?
            str_year+= str_y[str_y.size % 3 + i * 3, 3]
          end
        else
          str_year = str_y
        end
        str = sprintf("%s %d %s, %02d:%02d:%02d", month_data[data[:month] - 1][2], data[:day], str_year, data[:hour], data[:minute], data[:second])
        str
      end
      
      #----------------------------------------------------------------------
      # * Get the current time (Default)
      #----------------------------------------------------------------------
      def self.time_default(zone, base_data = nil, current_time = $cxj_timezowned_time)
        if base_data == nil
          data = [1970, 1, 1, 0, 0, 0]
        else
          data = [base_data[0], base_data[1], base_data[2], base_data[3], base_data[4], base_data[5]]
        end
        spd = 60 * 60 * 24
        i = current_time.size - 1
        cur = current_time[i]
        remainder = 0
        while i >= 0
          remainder = cur % spd
          i-= 1
          next if remainder == 0
          cur = current_time[i]
          break if i < 0
          maxval = 100000000
          minval = 10
          while (cur / maxval + remainder * minval) % spd >= minval
            maxval/= 10
            minval*= 10
          end
          cur = ((cur / maxval + remainder * minval) % spd) * maxval + cur % maxval
        end
        
        time = {
        :hour => data[3],
        :minute => data[4],
        :second => data[5]
        }
        
        time[:hour] = time[:hour] + remainder / (60 * 60)
        time[:minute] = time[:minute] + (remainder % 3600) / 60
        time[:second] = time[:second] + remainder % 60
        
        while time[:second] >= 60
          time[:second]-= 60
          time[:minute]+= 1
        end
        
        while time[:minute] >= 60
          time[:minute]-= 60
          time[:hour]+= 1
        end
        
        time[:hour] = time[:hour] % 24
        
        return time
      end
      
      #----------------------------------------------------------------------
      # * Display the current time (Default)
      #----------------------------------------------------------------------
      def self.disp_time_default(zone, base_data = nil, current_time = $cxj_timezowned_time)
        data = time_default(zone, base_data, current_time)
        str = sprintf("%02d:%02d:%02d", data[:hour], data[:minute], data[:second])
        str
      end
      
      #----------------------------------------------------------------------
      # * Display the current formatted date (Default)
      #     Does not implement everything.
      #----------------------------------------------------------------------
      def self.disp_datef_default(zone, format = "D, d M Y H:i:s", base_data = nil, current_time = $cxj_timezowned_time)
        data = date_default(zone, base_data, current_time)
        month_data = (base_data[7].nil? ? EARTH_MONTHS : const_get(base_data[7]))
        day_data = (base_data[8].nil? ? EARTH_DAYS : const_get(base_data[8]))
        str = ""
        spw = 3600 * 24 * day_data.size
        i = current_time.size - 1
        cur = current_time[i]
        remainder = 0
        while i >= 0
          remainder = cur % spw
          i-= 1
          next if remainder == 0
          cur = current_time[i]
          break if i < 0
          maxval = 100000000
          minval = 10
          while (cur / maxval + remainder * minval) % spw>= minval
            maxval/= 10
            minval*= 10
          end
          cur = ((cur / maxval + remainder * minval) % spw) * maxval + cur % maxval
        end
        start_day = 0
        for i in 0..(day_data.size - 1)
          start_day = i if base_data[6] == day_data[i][0]
        end
        dayofweek = (remainder / (3600 * 24) + start_day) % day_data.size
        full_year = ""
        for j in 0..(data[:year].size - 1)
          if data[:year].size > 1 && j == 0
            full_year+= sprintf("%d", data[:year][j])
          elsif data[:year].size == 1 && j == 0
            full_year+= sprintf("%04d", data[:year][j])
          else
            full_year+= sprintf("%d09d", data[:year][j])
          end
        end
        for i in 0..(format.size - 1)
          case format[i,1]
          when "d"
            str+= sprintf("%02d", data[:day])
          when "D"
            str+= day_data[dayofweek][2]
          when "j"
            str+= sprintf("%d", data[:day])
          when "l"
            str+= day_data[dayofweek][1]
          when "N"
            str+= sprintf("%d", dayofweek + 1)
          when "S"
            if data[:day] % 10 == 1 && data[:day] != 11
              str+= "st"
            elsif data[:day] %10 == 2 && data[:day] !=12
              str+= "nd"
            elsif data[:day] %10 == 3 && data[:day] != 13
              str+= "rd"
            else
              str+= "th"
            end
          when "w"
            str+= sprintf("%d", (dayofweek + 1) % day_data.size)
          when "z"
            j = 0
            month = data[:month]
            day = data[:day]
            dayofyear = 0
            while j < month - 2
              dayofyear+=month_data[j][0]
            end
            dayofyear+= day - 1
            str+= sprintf("%d", dayofyear)
          when "F"
            str+= month_data[data[:month] - 1][2]
          when "M"
            str+= month_data[data[:month] - 1][3]
          when "Y"
            str+= full_year
          when "y"
            str+= full_year[-2, 2] if full_year.size >= 2
            str+= full_year if full_year.size < 2
          when "H"
            str+= sprintf("%02d", data[:hour])
          when "i"
            str+= sprintf("%02d", data[:minute])
          when "s"
            str+= sprintf("%02d", data[:second])
          else
            str+= format[i,1]
          end
        end
        str
      end
      
      #----------------------------------------------------------------------
      # The following pieces of code tries to emulate the Earth time cycle,
      # including leap years. The script itself has been specifically made
      # with Earth leap years in mind. This means that even though it's
      # very possible to adjust it to your own system, it would require quite
      # some tinkering.
      #
      # If you aren't planning on using this code, you are free to remove it,
      # given that you remove any references to these methods in the
      # CXJ::TIMEZOWNED::ZONES constant.
      #----------------------------------------------------------------------

      #----------------------------------------------------------------------
      # * Get the current date (Earth)
      #----------------------------------------------------------------------
      def self.date_earth(zone, base_data = nil, current_time = $cxj_timezowned_time)
        if base_data.nil?
          data = [1970, 1, 1, 0, 0, 0]
        else
          data = [base_data[0], base_data[1], base_data[2], base_data[3], base_data[4], base_data[5]]
        end
        data[1]-= 1
        data[2]-= 1
        
        #....................................................................
        # Calculate the total amount of days passed.
        #....................................................................
        spd = 60 * 60 * 24
        i = current_time.size - 1
        num = 0
        days = []
        cur = current_time[i]
        remainder = 0
        while i >= 0
          num+= cur / spd
          days.unshift(num)
          num = 0
          remainder = cur % spd
          i-= 1
          break if i < 0
          cur = current_time[i]
          next if remainder == 0
          maxval = 100000000
          minval = 10
          while cur / maxval + remainder * minval < spd
            maxval/= 10
            minval*= 10
          end
          num = ((cur / maxval + remainder * minval) / spd) * maxval
          cur-= (cur / maxval) * maxval
        end
        while days[-1] == 0
          days.pop
        end
        remsec = remainder
        
        #....................................................................
        # Calculate the amount of years.
        #....................................................................
        # First, calculate per four centuries.
        #....................................................................
        dpc = (365 * 4 + 1) * 25 - 1
        dpfc = (dpc) * 4 + 1
        i = days.size - 1
        num = 0
        fyears = []
        cur = days[i]
        remainder = 0
        while i>= 0
          num+= (cur / dpfc)
          fyears.unshift(num)
          remainder = cur % dpfc
          i-= 1
          break if i < 0
          cur = days[i]
          next if remainder == 0
          maxval = 100000000
          minval = 10
          while cur / maxval + remainder * minval < dpfc
            maxval/= 10
            minval*= 10
          end
          num = ((cur / maxval + remainder * minval) / dpfc) * maxval
          cur-= (cur / maxval) * maxval
        end
        while fyears[-1] == 0
          fyears.pop
        end
        remdays = remainder
        #....................................................................
        # Convert to years.
        #....................................................................
        years = []
        i = 0
        oldrem = 0
        while i < fyears.size
          rem = ((fyears[i] / 1000000) * 4)
          years.push((fyears[i] % 1000000) * 400 + (rem % 10) * 1000000 + oldrem)
          oldrem = rem / 10
        end
        years.push(oldrem)
        #....................................................................
        # Centuries.
        #....................................................................
        while remdays >= dpc + ((data[0] + years[0] + 100) / 100 % 4 == 0 && ((data[0] + years[0] + 100) % 100 != 0 || data[1] > 2) ? 1 : 0)
          remdays-= dpc + ((data[0] + years[0] + 100) / 100 % 4 == 0 && ((data[0] + years[0] + 100) % 100 != 0 || data[1] > 2) ? 1 : 0)
          years[0] += 100
        end
        #....................................................................
        # Every four years.
        #....................................................................
        dpfy = 365 * 4 + 1
        while remdays >= dpfy - (((data[0] + years[0] + 4) % 400 == 0 && data[1] > 2) || ((data[0] + years[0] + 4) % 100 == 0 && data[1] <= 2) ? 1 : 0)
          remdays-= dpfy - (((data[0] + years[0] + 4) % 400 == 0 && data[1] > 2) || ((data[0] + years[0] + 4) % 100 == 0 && data[1] <= 2) ? 1 : 0)
          years[0] += 4
        end
        #....................................................................
        # Years.
        #....................................................................
        while remdays >= 365 + ((data[1] >= 2 && (data[0] + years[0] + 1) % 4 == 0 && ((data[0] + years[0] + 1) % 100 != 0 || (data[0] + years[0] + 1) % 400 == 0)) || (data[1] < 2 && (data[0] + years[0]) % 4 == 0 && ((data[0] + years[0]) % 100 != 0 || (data[0] + years[0]) % 400 == 0)) ? 1 : 0)
          remdays-= 365 + ((data[1] >= 2 && (data[0] + years[0] + 1) % 4 == 0 && ((data[0] + years[0] + 1) % 100 != 0 || (data[0] + years[0] + 1) % 400 == 0)) || (data[1] < 2 && (data[0] + years[0]) % 4 == 0 && ((data[0] + years[0]) % 100 != 0 || (data[0] + years[0]) % 400 == 0)) ? 1 : 0)
          years[0] += 1
        end
        
        #....................................................................
        # Calculate the current date.
        #....................................................................
        date = [data[0] + years[0],data[1],data[2],data[3],data[4],data[5]]
        remdays+= date[2]
        date[2] = 0
        while remdays > EARTH_MONTHS[date[1]][0] - date[2] + (date[1] == 2 && date[0] % 4 == 0 && (date[0] % 100 != 0 || date[0] % 400 == 0) ? 1 : 0)
          remdays-= EARTH_MONTHS[date[1]][0] - (date[1] == 2 && date[0] % 4 == 0 && (date[0] % 100 != 0 || date[0] % 400 == 0) ? 1 : 0)
          date[1] += 1
          date[2] = 0
          if date[1] >= 12
            date[1]-= 12
            date[0]+= 1
          end
        end
        date[2] = remdays
        
        date[3] = date[3] + remsec / (60 * 60)
        date[4] = date[4] + (remsec % 3600) / 60
        date[5] = date[5] + remsec % 60
        
        while date[5] >= 60
          date[5]-= 60
          date[4]+= 1
        end
        
        while date[4] >= 60
          date[4]-= 60
          date[3]+= 1
        end
        
        while date[3] >= 24
          date[3]-= 24
          date[2]+= 1
        end
        while date[2] >= EARTH_MONTHS[date[1]][0] + (date[1] == 2 && date[0] % 4 == 0 && (date[0] % 100 != 0 || date[0] % 400 == 0) ? 1 : 0)
          date[2]-= EARTH_MONTHS[date[1]][0] + (date[1] == 2 && date[0] % 4 == 0 && (date[0] % 100 != 0 || date[0] % 400 == 0) ? 1 : 0)
          date[1]+= 1
        end
        
        while date[1] >= 12
          date[1]-= 12
          date[0]+= 1
        end
        
        i = 0
        years[0] = date[0]
        while years[i] > 999999999
          years[i]-= 999999999
          years[i + 1] = 0 if years[i + 1].nil?
          years[i + 1]+= 1
          next if years[i] > 999999999
          i+= 1
        end
        
        date[0] = years
        date[1]+= 1
        date[2]+= 1
        
        return_date = {
          :year => date[0],
          :month => date[1],
          :day => date[2],
          :hour => date[3],
          :minute => date[4],
          :second => date[5]
        }
        
        return return_date
      end
      
      #----------------------------------------------------------------------
      # * Display the current date (Earth)
      #----------------------------------------------------------------------
      def self.disp_date_earth(zone, data = nil, current_time = $cxj_timezowned_time)
        data = date_earth(zone, data, current_time)
        years = data[:year]
        str_y = ""
        while !years.empty?
          str_y+= sprintf((str_y.empty? ? "%d" : "%09d"), years.pop)
        end
        str_year = ""
        if(str_y.size > 4)
          str_year = str_y[0, str_y.size % 3] if str_y.size % 3 != 0
          for i in 0..str_y.size / 3 - 1
            str_year+= "," if !str_year.empty?
            str_year+= str_y[str_y.size % 3 + i * 3, 3]
          end
        else
          str_year = str_y
        end
        str = sprintf("%s %d %s, %02d:%02d:%02d", EARTH_MONTHS[data[:month] - 1][2], data[:day], str_year, data[:hour], data[:minute], data[:second])
        str
      end
      
      #----------------------------------------------------------------------
      # * Get the current time (Earth)
      #----------------------------------------------------------------------
      def self.time_earth(zone, data = nil, current_time = $cxj_timezowned_time)
        if data == nil
          data = [1970, 1, 1, 0, 0, 0]
        end
        spd = 60 * 60 * 24
        i = current_time.size - 1
        cur = current_time[i]
        remainder = 0
        while i >= 0
          remainder = cur % spd
          i-= 1
          next if remainder == 0
          cur = current_time[i]
          break if i < 0
          maxval = 100000000
          minval = 10
          while (cur / maxval + remainder * minval) % spd >= minval
            maxval/= 10
            minval*= 10
          end
          cur = ((cur / maxval + remainder * minval) % spd) * maxval + cur % maxval
        end
        
        time = {
        :hour => data[3],
        :minute => data[4],
        :second => data[5]
        }
        
        time[:hour] = time[:hour] + remainder / (60 * 60)
        time[:minute] = time[:minute] + (remainder % 3600) / 60
        time[:second] = time[:second] + remainder % 60
        
        while time[:second] >= 60
          time[:second]-= 60
          time[:minute]+= 1
        end
        
        while time[:minute] >= 60
          time[:minute]-= 60
          time[:hour]+= 1
        end
        
        time[:hour] = time[:hour] % 24
        
        return time
      end
      
      #----------------------------------------------------------------------
      # * Display the current time (Earth)
      #----------------------------------------------------------------------
      def self.disp_time_earth(zone, data = nil, current_time = $cxj_timezowned_time)
        data = time_earth(zone, data, current_time)
        str = sprintf("%02d:%02d:%02d", data[:hour], data[:minute], data[:second])
        str
      end
      
      #----------------------------------------------------------------------
      # * Display the current formatted date (Earth)
      #     Does not implement everything.
      #----------------------------------------------------------------------
      def self.disp_datef_earth(zone, format = "D, d M Y H:i:s", base_data = nil, current_time = $cxj_timezowned_time)
        data = date_earth(zone, base_data, current_time)
        str = ""
        leap = (data[:year][0] % 4 == 0 && (data[:year][0] % 100 != 0 || data[:year][0] % 400 == 0) ? 1 : 0)
        spw = 3600 * 24 * 7
        i = current_time.size - 1
        cur = current_time[i]
        remainder = 0
        while i >= 0
          remainder = cur % spw
          i-= 1
          next if remainder == 0
          cur = current_time[i]
          break if i < 0
          maxval = 100000000
          minval = 10
          while (cur / maxval + remainder * minval) % spw>= minval
            maxval/= 10
            minval*= 10
          end
          cur = ((cur / maxval + remainder * minval) % spw) * maxval + cur % maxval
        end
        start_day = 0
        for i in 0..(EARTH_DAYS.size - 1)
          start_day = i if base_data[6] == EARTH_DAYS[i][0]
        end
        dayofweek = (remainder / (3600 * 24) + start_day) % 7
        full_year = ""
        for j in 0..(data[:year].size - 1)
          if data[:year].size > 1 && j == 0
            full_year+= sprintf("%d", data[:year][j])
          elsif data[:year].size == 1 && j == 0
            full_year+= sprintf("%04d", data[:year][j])
          else
            full_year+= sprintf("%d09d", data[:year][j])
          end
        end
        for i in 0..(format.size - 1)
          case format[i,1]
          when "d"
            str+= sprintf("%02d", data[:day])
          when "D"
            str+= EARTH_DAYS[dayofweek][2]
          when "j"
            str+= sprintf("%d", data[:day])
          when "l"
            str+= EARTH_DAYS[dayofweek][1]
          when "N"
            str+= sprintf("%d", dayofweek + 1)
          when "S"
            if data[:day] % 10 == 1 && data[:day] != 11
              str+= "st"
            elsif data[:day] %10 == 2 && data[:day] !=12
              str+= "nd"
            elsif data[:day] %10 == 3 && data[:day] != 13
              str+= "rd"
            else
              str+= "th"
            end
          when "w"
            str+= sprintf("%d", (dayofweek + 1) % 7)
          when "z"
            j = 0
            month = data[:month]
            day = data[:day]
            dayofyear = 0
            while j < month - 2
              dayofyear+=EARTH_MONTHS[j][0]
              dayofyear+=1 if j == 1 && leap == 1
            end
            dayofyear+= day - 1
            str+= sprintf("%d", dayofyear)
          when "F"
            str+= EARTH_MONTHS[data[:month] - 1][2]
          when "M"
            str+= EARTH_MONTHS[data[:month] - 1][3]
          when "L"
            str+= sprintf("%d", leap)
          when "Y"
            str+= full_year
          when "y"
            str+= full_year[-2, 2] if full_year.size >= 2
            str+= full_year if full_year.size < 2
          when "H"
            str+= sprintf("%02d", data[:hour])
          when "i"
            str+= sprintf("%02d", data[:minute])
          when "s"
            str+= sprintf("%02d", data[:second])
          else
            str+= format[i,1]
          end
        end
        str
      end
    end
  end
end

#==============================================================================
#
# The code below should not be altered unless you know what you're doing.
#
#==============================================================================
module CXJ
  module TIMEZOWNED
    #------------------------------------------------------------------------
    # * TimeZowned save handler
    #------------------------------------------------------------------------
    def self.timezowned_saver
      data = {}
      data[:timezowned_time] = $cxj_timezowned_time
      data[:timezowned_frame] = $cxj_timezowned_frame
      data[:timezowned_running] = $cxj_timezowned_running
      return data
    end
    
    #------------------------------------------------------------------------
    # * TimeZowned load handler
    #------------------------------------------------------------------------
    def self.timezowned_loader(data)
      $cxj_timezowned_time = data[:timezowned_time]
      $cxj_timezowned_frame = data[:timezowned_frame]
      $cxj_timezowned_running = data[:timezowned_running]
    end
    
    #------------------------------------------------------------------------
    # * Increase time by a certain amount of frames
    #------------------------------------------------------------------------
    def self.increase(amount = 1, frame_increase = false)
      if amount == 0
        return
      end
      if frame_increase == true
        $cxj_timezowned_frame+= amount
        amount = 0
        while !(0..(Graphics.frame_rate - 1)).include?($cxj_timezowned_frame)
          if $cxj_timezowned_frame < 0
            amount-= 1 * CXJ::TIMEZOWNED::TIME_PER_SECOND
            $cxj_timezowned_frame += Graphics.frame_rate
          end
          if $cxj_timezowned_frame > Graphics.frame_rate - 1
            amount+= 1 * CXJ::TIMEZOWNED::TIME_PER_SECOND
            $cxj_timezowned_frame -= Graphics.frame_rate
          end
        end
      end
      $cxj_timezowned_time[0] += amount
      i = 0
      while !(0..999999999).include?($cxj_timezowned_time[i])
        mod = 0
        while $cxj_timezowned_time[i] < 0
          $cxj_timezowned_time[i]+= 1000000000
          mod-= 1
        end
        while $cxj_timezowned_time[i] > 999999999
          $cxj_timezowned_time[i]-= 1000000000
          mod+= 1
        end
        i+= 1
        if i >= $cxj_timezowned_time.size
          if mod < 0
            $cxj_timezowned_time = [0]
          else
            $cxj_timezowned_time[i] = mod
          end
        end
      end
      while $cxj_timezowned_time.size > 1 && $cxj_timezowned_time[-1] == 0
        $cxj_timezowned_time.pop
      end
    end
    
    #------------------------------------------------------------------------
    # * Get the current date of a certain timezone
    #------------------------------------------------------------------------
    def self.get_date(sym, type = 0)
      zone = CXJ::TIMEZOWNED::ZONES[sym]
      return nil if zone.nil?
      data = nil
      data = zone[1]
      return nil if(zone[0].nil?)
      return nil if(zone[0][type].nil?)
      return CXJ::TIMEZOWNED::METHODS.method(zone[0][type]).call(sym, data)
    end
    
    #------------------------------------------------------------------------
    # * Get the current date of a certain timezone, formatted
    #------------------------------------------------------------------------
    def self.get_datef(sym, format = "D, d M Y H:i:s")
      zone = CXJ::TIMEZOWNED::ZONES[sym]
      return nil if zone.nil?
      data = nil
      data = zone[1]
      return nil if(zone[0].nil?)
      return nil if(zone[0][4].nil?)
      return CXJ::TIMEZOWNED::METHODS.method(zone[0][4]).call(sym, format, data)
    end

    #------------------------------------------------------------------------
    # * Bind save and load handlers
    #------------------------------------------------------------------------
    if($imported["CXJ-SavedataExtender"])
      CXJ::SAVEDATA_EXTENDER::add_save_handler(self.method(:timezowned_saver), true, true)
      CXJ::SAVEDATA_EXTENDER::add_load_handler(self.method(:timezowned_loader))
    end
  end
end

#==============================================================================
# ** DataManager
#------------------------------------------------------------------------------
#  This module manages the database and game objects. Almost all of the 
# global variables used by the game are initialized by this module.
#==============================================================================

module DataManager
  #--------------------------------------------------------------------------
  # * Alias: Create Save Header
  #--------------------------------------------------------------------------
  class << self
    datamanager_create_game_objects_cxj_tz = instance_method(:create_game_objects)
    define_method :create_game_objects do
      $cxj_timezowned_time = [0]
      $cxj_timezowned_frame = 0
      $cxj_timezowned_running = CXJ::TIMEZOWNED::TIME_RUNS_ON_NEW_GAME
      datamanager_create_game_objects_cxj_tz.bind(self).call
      $game_switches[CXJ::TIMEZOWNED::TIME_SWITCH] = CXJ::TIMEZOWNED::TIME_RUNS_ON_NEW_GAME if CXJ::TIMEZOWNED::TIME_SWITCH > 0
    end
  end
  
  #--------------------------------------------------------------------------
  # Savedata Extender compatibility
  #--------------------------------------------------------------------------
  if(!$imported["CXJ-SavedataExtender"])
    #------------------------------------------------------------------------
    # * Alias: Create Save Header
    #------------------------------------------------------------------------
    class << self
      datamanager_make_save_header_cxj_tz = instance_method(:make_save_header)
      define_method :make_save_header do
        header = datamanager_make_save_header_cxj_tz.bind(self).call
        data = CXJ::TIMEZOWNED.timezowned_saver
        data.each {|key, value|
          header[key]= value
        }
        header
      end
      #----------------------------------------------------------------------
      # * Alias: Create Save Contents
      #----------------------------------------------------------------------
      datamanager_make_save_contents_cxj_tz = instance_method(:make_save_contents)
      define_method :make_save_contents do
        contents = datamanager_make_save_contents_cxj_tz.bind(self).call
        data = CXJ::TIMEZOWNED.timezowned_saver
        data.each {|key, value|
          contents[key]= value
        }
        contents
      end
      #----------------------------------------------------------------------
      # * Alias: Extract Save Contents
      #----------------------------------------------------------------------
      datamanager_extract_save_contents_cxj_tz = instance_method(:extract_save_contents)
      define_method :extract_save_contents do|contents|
        datamanager_extract_save_contents_cxj_tz.bind(self).call(contents)
        CXJ::TIMEZOWNED.timezowned_loader(contents)
      end
    end
  end
end

#==============================================================================
# ** Window_Base
#------------------------------------------------------------------------------
#  This is a super class of all windows within the game.
#==============================================================================

class Window_Base < Window
  #--------------------------------------------------------------------------
  # * Alias: Preconvert Control Characters
  #    As a rule, replace only what will be changed into text strings before
  #    starting actual drawing. The character "\" is replaced with the escape
  #    character (\e).
  #--------------------------------------------------------------------------
  window_base_convert_escape_characters_cxj_tz = instance_method(:convert_escape_characters)
  define_method :convert_escape_characters do |text|
    result = window_base_convert_escape_characters_cxj_tz.bind(self).call(text)
    result = timezowned_convert_escape_characters(result)
    return result
  end
  
  #--------------------------------------------------------------------------
  # * New: Adds new text commands for TimeZowned.
  #--------------------------------------------------------------------------
  def timezowned_convert_escape_characters(result)
    result.gsub!(/\[\[timezowned_date (\w+)\]\]/i) { CXJ::TIMEZOWNED.get_date($1.to_sym, 1) }
    result.gsub!(/\[\[timezowned_time (\w+)\]\]/i) { CXJ::TIMEZOWNED.get_date($1.to_sym, 3) }
    result.gsub!(/\[\[timezowned_datef (\w+) (.*?)\]\]/i) { CXJ::TIMEZOWNED.get_datef($1.to_sym, $2) }
    return result
  end
end

#==============================================================================
# ** Scene_Base
#------------------------------------------------------------------------------
#  This is a super class of all scenes within the game.
#==============================================================================

class Scene_Base
  #--------------------------------------------------------------------------
  # * Alias: Frame Update
  #--------------------------------------------------------------------------
  scene_base_update_cxj_tz = instance_method(:update)
  define_method :update do
    update_timezowned
    scene_base_update_cxj_tz.bind(self).call
  end
  
  #--------------------------------------------------------------------------
  # * New: Updates TimeZowned
  #--------------------------------------------------------------------------
  def update_timezowned
    return if !timezowned_enabled
    return if (CXJ::TIMEZOWNED::TIME_SWITCH == 0 && !$cxj_timezowned_running) || (CXJ::TIMEZOWNED::TIME_SWITCH > 0 && !$game_switches[CXJ::TIMEZOWNED::TIME_SWITCH])
    CXJ::TIMEZOWNED.increase(1, true)
  end
  
  #--------------------------------------------------------------------------
  # * New: Determines if TimeZowned should be enabled for this screen
  #--------------------------------------------------------------------------
  def timezowned_enabled
    return false
  end
end

#==============================================================================
# ** Scene_Map
#------------------------------------------------------------------------------
#  This class performs the map screen processing.
#==============================================================================

class Scene_Map < Scene_Base
  #--------------------------------------------------------------------------
  # * New: Determines if TimeZowned should be enabled for this screen
  #--------------------------------------------------------------------------
  def timezowned_enabled
    return true
  end
end

#==============================================================================
# ** Scene_MenuBase
#------------------------------------------------------------------------------
#  This class performs basic processing related to the menu screen.
#==============================================================================

class Scene_MenuBase < Scene_Base
  #--------------------------------------------------------------------------
  # * New: Determines if TimeZowned should be enabled for this screen
  #--------------------------------------------------------------------------
  def timezowned_enabled
    return CXJ::TIMEZOWNED::TIME_ON_MENU
  end
end

#==============================================================================
# ** Scene_Battle
#------------------------------------------------------------------------------
#  This class performs battle screen processing.
#==============================================================================

class Scene_Battle < Scene_Base
  #--------------------------------------------------------------------------
  # * New: Determines if TimeZowned should be enabled for this screen
  #--------------------------------------------------------------------------
  def timezowned_enabled
    return CXJ::TIMEZOWNED::TIME_DURING_BATTLE
  end
end