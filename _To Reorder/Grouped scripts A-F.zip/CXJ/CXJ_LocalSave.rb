#==============================================================================
# 
# GaryCXJk - Local Save v1.00
# * Last Updated: 2014.10.19
# * Level: Easy
# * Requires: N/A
#
#==============================================================================

$imported = {} if $imported.nil?
$imported["CXJ-LocalSave"] = "1.00"

#==============================================================================
#
# Changelog:
#
# 2014.10.19 - v1.00
#
# * Initial release
#
#==============================================================================
#
# To put it simple, I needed a script that allowed me to store my data locally,
# in case I wanted to make a sequel to a game and wanted to import data from
# said game. After some research I found out that most people are kind of dicks
# and require some form of permission, so I made my own.
#
#==============================================================================
#
# Installation:
#
# Make sure to put this below Materials, but above Main Process.
#
# This script adds aliases for several methods. If you are sure no method that
# is used by other scripts get overridden, you can place it anywhere,
# otherwise, make sure this script is loaded after any other script overriding
# these methods, otherwise this script stops working.
#
#------------------------------------------------------------------------------
# Aliased methods:
#
# * module DataManager
#   - save_file_exists?
#   - make_filename(index)
#
#==============================================================================
#
# Usage:
#
# This is quite literally plug-and-play. The only thing I want to say is that
# the save files are located inside the appdata folder.
#
#==============================================================================
#
# License:
#
# CC0 1.0 Universal (CC0 1.0) 
# Public Domain Dedication
#
# The complete license can be read here:
# https://creativecommons.org/publicdomain/zero/1.0/legalcode
#
# The license as it is described below can be read here:
# https://creativecommons.org/publicdomain/zero/1.0/deed
#
# No Copyright
#
# The person who associated a work with this deed has dedicated the work to the
# public domain by waiving all of his or her rights to the work worldwide under
# copyright law, including all related and neighboring rights, to the extent
# allowed by law.
#
# You can copy, modify, distribute and perform the work, even for commercial
# purposes, all without asking permission. See Other Information below.
#
# Other Information
#
# * In no way are the patent or trademark rights of any person affected by CC0,
#   nor are the rights that other persons may have in the work or in how the
#   work is used, such as publicity or privacy rights.
# * Unless expressly stated otherwise, the person who associated a work with
#   this deed makes no warranties about the work, and disclaims liability for
#   all uses of the work, to the fullest extent permitted by applicable law.
# * When using or citing the work, you should not imply endorsement by the
#   author or the affirmer.
#
#------------------------------------------------------------------------------
# Clarifications and reasoning:
#
# This script has been given a CC0 license because I feel it deserves to be
# used by everyone without restriction. This ensures that people don't feel
# obligated to add a license notice or credits whenever the script is being
# used.
#
# Additional reasoning:
#
# This script was literally done in an hour, two hours if you include
# research and browsing reddit. To put it bluntly, it's insulting to put any
# form of limitations on this script or anything similar.
#
#------------------------------------------------------------------------------
# Extra notes:
#
# You are free to pick the following names when you give credit:
#
# * GaryCXJk
# * Gary A.M. Kertopermono
# * G.A.M. Kertopermono
# * GARYCXJK
#
# I actually don't mind if you don't credit me, but it would always be nice.
#
# This script was originally hosted on:
# http://area91.multiverseworks.com
#
#==============================================================================
#
# The code below defines the settings of this script, and are there to be
# modified.
#
#==============================================================================

module CXJ
  module LOCALSAVE
    # Modify the following variables to specify the save folder inside your
    # appdata folder. You're actually free to format this however you want,
    # you can just leave some of them empty if you feel like and lump
    # everything inside one of the three variables. I don't care.
    ROOT_SAVE_FOLDER = "/CXJ/"
    GAME_SAVE_FOLDER = "LocalSave/"
    SAVE_FOLDER = "/Test Project/Save/"
  end
end


#==============================================================================
#
# The code below should not be altered unless you know what you're doing.
#
#==============================================================================

module CXJ
  module LOCALSAVE
    def self.get_environment_variable(variable, length = 256)
      testvalue = "\0" * length
      Win32API.new('Kernel32', 'GetEnvironmentVariable', 'PPL', 'V').call(variable, testvalue, length)
      returnvalue = testvalue[0, testvalue.index("\0")]
      if returnvalue[-1, 1] != "\\" && returnvalue[-1, 1] != '/'
        returnvalue+= '/'
      end
      returnvalue.gsub!(/\\/) { '/' }
      returnvalue
    end
    
    LOCAL_APPDATA_FOLDER = get_environment_variable('APPDATA', 256)
    
    def self.automake_dirs(file)
      while !file.index('//').nil?
        file.gsub!(/\/\//) { '/' }
      end
      if file[-1, 1] == '/'
        file.slice!(-1, 1)
      end
      dir = file.clone
      mdir = []
      while !File.exists?(dir) && !dir.rindex('/').nil? && dir.rindex('/') > 0
        mdir.unshift(dir)
        dir = dir[0, dir.rindex('/')]
      end
      mdir.each do |dir|
        Dir.mkdir(dir)
      end
      file + '/'
    end
    
    LOCAL_SAVE_FOLDER = automake_dirs( LOCAL_APPDATA_FOLDER + ROOT_SAVE_FOLDER + GAME_SAVE_FOLDER + SAVE_FOLDER);
  end
end
#==============================================================================
# ** DataManager
#------------------------------------------------------------------------------
#  This module manages the database and game objects. Almost all of the 
# global variables used by the game are initialized by this module.
#==============================================================================

module DataManager
  class << self
    #------------------------------------------------------------------------
    # * Determine Existence of Save File
    #------------------------------------------------------------------------
    alias datamanager_save_file_exists_cxj_localsave? save_file_exists?
    def save_file_exists?
      !Dir.glob(CXJ::LOCALSAVE::LOCAL_SAVE_FOLDER + 'Save*.rvdata2').empty? || datamanager_save_file_exists_cxj_localsave?
    end
  
    #------------------------------------------------------------------------
    # * Create Filename
    #     index : File Index
    #------------------------------------------------------------------------
    alias datamanager_make_filename_cxj_localsave make_filename
    def make_filename(index)
      CXJ::LOCALSAVE::LOCAL_SAVE_FOLDER + datamanager_make_filename_cxj_localsave(index)
    end
  end
end