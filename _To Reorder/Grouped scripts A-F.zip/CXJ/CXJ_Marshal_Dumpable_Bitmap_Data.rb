﻿#==============================================================================
# 
# GaryCXJk - Marshal Dumpable Bitmap Data v1.00
# * Last Updated: 2012.12.28
# * Level: Medium
# * Requires: N/A
#
# Aditional credits:
# * Tsukihime
#
#==============================================================================

$imported = {} if $imported.nil?
$imported["CXJ-MarshalDumpableBitmapData"] = true

#==============================================================================
#
# Changelog:
#
#------------------------------------------------------------------------------
# 2012.12.28 - v1.00
#
# * Initial release
#
#==============================================================================
#
# Here's a hypothetical question:
#
# Let's say you want to store screenshots of the travels of your protagonists.
# You know, to display during the end credits. Or you want to show a little
# screenshot on the save menu. Maybe you'd like to customize your character's
# appearance in some way by allowing people to directly draw on them.
#
# But wait! You can't use Marshal.dump on these images! This means that next
# time the save file is loaded, the image gets lost because it couldn't be
# stored with your save game. What to do now?
#
# Well, luckily, I've come with a solution. By directly taking the image data
# from the bitmap, I can actually use Marshal.dump to store it.
#
#==============================================================================
#
# Installation:
#
# Make sure to put this below Materials, but above Main Process.
#
#==============================================================================
# Usage:
#
# When you have your Bitmap data ready, you can create a new BitmapData object
# by using it as its argument.
#
# Example:
#
# bitmap = Bitmap.new(16, 16)
# color1 = Color.new(255, 0, 0, 255)
# color2 = Color.new(0, 0, 255, 255)
# bitmap.gradient_fill_rect(0, 0, 16, 16, color1, color2)
# bitmap_data = CXJ::BitmapData.new(bitmap)
#
# The BitmapData class is encapsulated in the CXJ module, to avoid any
# potential conflicts with other scripts.
#
# To retrieve the bitmap data again, you can use the load_bitmap method. Do
# note that the sizes must match, otherwise there might be a conflict. To
# simplify this process however, I've also added a method to the BitmapData
# class called bitmap, which automatically creates a Bitmap object with the
# correct size, after which the data is injected.
#
# Example:
#
# bitmap = Bitmap.new(bitmap_data.width, bitmap_data.height)
# bitmap.load_data(bitmap_data)
#
# bitmap = bitmap_data.bitmap
#
# Both practically do the same.
#
#==============================================================================
#
# License:
#
# Creative Commons Attribution 3.0 Unported
#
# The complete license can be read here:
# http://creativecommons.org/licenses/by/3.0/legalcode
#
# The license as it is described below can be read here:
# http://creativecommons.org/licenses/by/3.0/deed
#
# You are free:
#
# to Share — to copy, distribute and transmit the work
# to Remix — to adapt the work
# to make commercial use of the work
#
# Under the following conditions:
#
# Attribution — You must attribute the work in the manner specified by the
# author or licensor (but not in any way that suggests that they endorse you or
# your use of the work).
#
# With the understanding that:
#
# Waiver — Any of the above conditions can be waived if you get permission from
# the copyright holder.
#
# Public Domain — Where the work or any of its elements is in the public domain
# under applicable law, that status is in no way affected by the license.
#
# Other Rights — In no way are any of the following rights affected by the
# license:
#
# * Your fair dealing or fair use rights, or other applicable copyright
#   exceptions and limitations;
# * The author's moral rights;
# * Rights other persons may have either in the work itself or in how the work
#   is used, such as publicity or privacy rights.
#
# Notice — For any reuse or distribution, you must make clear to others the
# license terms of this work. The best way to do this is with a link to this
# web page.
#
#------------------------------------------------------------------------------
# Extra notes:
#
# Despite what the license tells you, I will not hunt down anybody who doesn't
# follow the license in regards to giving credits. However, as it is common
# courtesy to actually do give credits, it is recommended that you do.
#
# As I picked this license, you are free to share this script through any
# means, which includes hosting it on your own website, selling it on eBay and
# hang it in the bathroom as toilet paper. Well, not selling it on eBay, that's
# a dick move, but you are still free to redistribute the work.
#
# Yes, this license means that you can use it for both non-commercial as well
# as commercial software.
#
# You are free to pick the following names when you give credit:
#
# * GaryCXJk
# * Gary A.M. Kertopermono
# * G.A.M. Kertopermono
# * GARYCXJK
#
# Personally, when used in commercial games, I prefer you would use the second
# option. Not only will it actually give me more name recognition in real
# life, which also works well for my portfolio, it will also look more
# professional. Also, do note that I actually care about capitalization if you
# decide to use my username, meaning, capital C, capital X, capital J, lower
# case k. Yes, it might seem stupid, but it's one thing I absolutely care
# about.
#
# Finally, if you want my endorsement for your product, if it's good enough
# and I have the game in my posession, I might endorse it. Do note that if you
# give me the game for free, it will not affect my opinion of the game. It
# would be nice, but if I really did care for the game I'd actually purchase
# it. Remember, the best way to get any satisfaction is if you get people to
# purchase the game, so in a way, I prefer it if you don't actually give me
# a free copy.
#
# This script was originally hosted on:
# http://area91.multiverseworks.com
#
# Don't forget to also credit:
# * Tsukihime (Original code to retrieve bitmap data, who might have gotten it
#     from another script)
#
#==============================================================================
#
# The code below should not be altered unless you know what you're doing.
#
#==============================================================================

#==============================================================================
# ** CXJ::BitmapData
#------------------------------------------------------------------------------
#  This class acts like a container for the bitmap data.
#==============================================================================

module CXJ
  class BitmapData
    #--------------------------------------------------------------------------
    # * Initialization
    #--------------------------------------------------------------------------
    def initialize(bmp)
      @width = bmp.width
      @height = bmp.height
      @data = bmp.dumpable_data
    end
    
    #--------------------------------------------------------------------------
    # * Image Width
    #--------------------------------------------------------------------------
    def width
      @width
    end
    
    #--------------------------------------------------------------------------
    # * Image Height
    #--------------------------------------------------------------------------
    def height
      @height
    end
    
    #--------------------------------------------------------------------------
    # * Bitmap Data
    #--------------------------------------------------------------------------
    def data
      @data
    end
    
    #--------------------------------------------------------------------------
    # * Bitmap Created From Bitmap Data
    #--------------------------------------------------------------------------
    def bitmap
      bmp = Bitmap.new(width, height)
      bmp.load_data(self)
      bmp
    end
  end
end

#==============================================================================
# ** Bitmap
#------------------------------------------------------------------------------
#  The bitmap class. Bitmaps represent images.
#  Sprites (Sprite) and other objects must be used to display bitmaps onscreen.
#==============================================================================

class Bitmap
  #--------------------------------------------------------------------------
  # * New: Pointer To Bitmap Data
  #--------------------------------------------------------------------------
  def pointer_data
    rdata_ptr = DL::CPtr.new((object_id<<1)+16, 4)[0, 4].unpack('I')[0]
    bm_info_ptr = DL::CPtr.new(rdata_ptr+8, 4)[0, 4].unpack('I')[0]
    bm_data_ptr = DL::CPtr.new(bm_info_ptr+12, 4)[0, 4].unpack('I')[0]
    data = DL::CPtr.new(bm_data_ptr-((height-1)*width*4))
    data
  end
  
  #--------------------------------------------------------------------------
  # * New: Dumpable Bitmap Data
  #--------------------------------------------------------------------------
  def dumpable_data
    pointer_data[0, height * width * 4]
  end
  
  #--------------------------------------------------------------------------
  # * New: Fill Bitmap With Bitmap Data
  #--------------------------------------------------------------------------
  def load_data(bitmap_data)
    raise("No BitmapData is supplied.") if !bitmap_data.instance_of?(CXJ::BitmapData)
    raise("Size does not match.") if width != bitmap_data.width || height != bitmap_data.height
    pointer_data[0, height * width * 4] = bitmap_data.data
  end
end