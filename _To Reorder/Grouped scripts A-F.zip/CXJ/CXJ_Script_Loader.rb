﻿#==============================================================================
# 
# GaryCXJk - Script Loader v1.02
# * Last Updated: 2012.01.15
# * Level: Medium
# * Requires: N/A
# 
#==============================================================================

$imported = {} if $imported.nil?
$imported["CXJ-ScriptLoader"] = true

#==============================================================================
#
# Changelog:
#
#------------------------------------------------------------------------------
# 2012.01.15 - v1.02
#
# * Fixed: Packed scripts still not being executed on root
#
#------------------------------------------------------------------------------
# 2012.01.02 - v1.01
#
# * Fixed: Packed scripts not being executed on root
#
#------------------------------------------------------------------------------
# 2012.12.30 - v1.00
#
# * Initial release
#
#==============================================================================
#
# Sometimes you want to load in some external scripts, for example, if you
# want to add DLC. It already is hard enough to get a script to pack, anyway.
# This script will take care of any script loading, and it allows for scripts
# to be packed as .rvdata2 files. Of course, you could be a Scrooge and keep
# your script releases relatively close sourced that way to those who don't
# know much scripting, but its main purpose is still to add new functionality
# post-release.
#
#==============================================================================
#
# Installation:
#
# Make sure to put this below Materials, but above Main Process.
#
# As this script adds a way to load new scripts, depending on whether the
# scripts added in the editor require the scripts externally loaded or vice
# versa, either place this script above your scripts or below. However, since
# this script was mainly created to extend functionality, it's best to put it
# below all other scripts, but still above the Main script.
#
#==============================================================================
#
# Usage:
#
# This script consists of two parts, the script loading part and the script
# packing part. Loading goes automatically, so you won't have to run any method
# to do that, script packing uses a method.
#
# CXJ::SCRIPT_LOADER.pack_script_folder(folder[, recursive[, destination]])
#
# Folder refers to the folder you want to pack. If recursive isn't specified,
# it is assumed to be set to true, and will therefore recursively search
# through the folder and its subfolder. If destination isn't specified, it will
# add the first extension specified at CXJ::SCRIPT_LOADER::PACKED_SUFFIXES at
# the end of the folder name, otherwise it will use the specified file.
#
# Note that folder should have no lead or trailing slash.
#
# If you, for some reason, need to load a specific file directly, you can use
# the following method:
#
# CXJ::SCRIPT_LOADER.load_script(filename[, mode])
#
# The mode specifies how the file should be treated.
# 0: Treat as Ruby script file
# 1: Treat as packed script archive
# 2: Auto-detect, based on the specified extensions (default)
#
#==============================================================================
#
# License:
#
# Creative Commons Attribution 3.0 Unported
#
# The complete license can be read here:
# http://creativecommons.org/licenses/by/3.0/legalcode
#
# The license as it is described below can be read here:
# http://creativecommons.org/licenses/by/3.0/deed
#
# You are free:
#
# to Share — to copy, distribute and transmit the work
# to Remix — to adapt the work
# to make commercial use of the work
#
# Under the following conditions:
#
# Attribution — You must attribute the work in the manner specified by the
# author or licensor (but not in any way that suggests that they endorse you or
# your use of the work).
#
# With the understanding that:
#
# Waiver — Any of the above conditions can be waived if you get permission from
# the copyright holder.
#
# Public Domain — Where the work or any of its elements is in the public domain
# under applicable law, that status is in no way affected by the license.
#
# Other Rights — In no way are any of the following rights affected by the
# license:
#
# * Your fair dealing or fair use rights, or other applicable copyright
#   exceptions and limitations;
# * The author's moral rights;
# * Rights other persons may have either in the work itself or in how the work
#   is used, such as publicity or privacy rights.
#
# Notice — For any reuse or distribution, you must make clear to others the
# license terms of this work. The best way to do this is with a link to this
# web page.
#
#------------------------------------------------------------------------------
# Extra notes:
#
# Despite what the license tells you, I will not hunt down anybody who doesn't
# follow the license in regards to giving credits. However, as it is common
# courtesy to actually do give credits, it is recommended that you do.
#
# As I picked this license, you are free to share this script through any
# means, which includes hosting it on your own website, selling it on eBay and
# hang it in the bathroom as toilet paper. Well, not selling it on eBay, that's
# a dick move, but you are still free to redistribute the work.
#
# Yes, this license means that you can use it for both non-commercial as well
# as commercial software.
#
# You are free to pick the following names when you give credit:
#
# * GaryCXJk
# * Gary A.M. Kertopermono
# * G.A.M. Kertopermono
# * GARYCXJK
#
# Personally, when used in commercial games, I prefer you would use the second
# option. Not only will it actually give me more name recognition in real
# life, which also works well for my portfolio, it will also look more
# professional. Also, do note that I actually care about capitalization if you
# decide to use my username, meaning, capital C, capital X, capital J, lower
# case k. Yes, it might seem stupid, but it's one thing I absolutely care
# about.
#
# Finally, if you want my endorsement for your product, if it's good enough
# and I have the game in my posession, I might endorse it. Do note that if you
# give me the game for free, it will not affect my opinion of the game. It
# would be nice, but if I really did care for the game I'd actually purchase
# it. Remember, the best way to get any satisfaction is if you get people to
# purchase the game, so in a way, I prefer it if you don't actually give me
# a free copy.
#
# This script was originally hosted on:
# http://area91.multiverseworks.com
#
#==============================================================================
#
# The code below defines the settings of this script, and are there to be
# modified.
#
#==============================================================================

module CXJ
  module SCRIPT_LOADER
    #------------------------------------------------------------------------
    # You can specify suffixes for script files.
    #------------------------------------------------------------------------
    RUBY_SUFFIXES = [
    "rb",
    "txt",
    ]
    
    #------------------------------------------------------------------------
    # You can specify suffixes for packed script archives.
    #------------------------------------------------------------------------
    PACKED_SUFFIXES = [
    "rvdata2",
    "dat",
    ]
    
    #------------------------------------------------------------------------
    # This defines the folders to search through.
    #   "Folder"    - The folder to search through
    #                 Don't add a trailing or lead slash
    #   Recursive?  - Whether it should search through its subfolders as well
    #   Mode        - The kind of files it should load
    #                 0: Ruby scripts only
    #                 1: Packed scripts only
    #                 2: Both
    #------------------------------------------------------------------------
    LOCATIONS = [
    # ["Folder",    Recursive?, Mode],
      ["Script",   true,       2],
    ]
  end
end

#==============================================================================
#
# The code below should not be altered unless you know what you're doing.
#
#==============================================================================

#----------------------------------------------------------------------------
# Evaluate Scipt list
#----------------------------------------------------------------------------
def evaluate_packed_scripts
  Kernel.eval(CXJ::SCRIPT_LOADER.shift_packed_script_queue, Kernel.binding) while packed_script_queue_size > 0
end

module CXJ
  module SCRIPT_LOADER
    @external_script = []
    #------------------------------------------------------------------------
    # Load Script
    #   mode: The way the file should be treated.
    #         0: Treat as Ruby script file
    #         1: Treat as packed script archive
    #         2: Auto-detect, based on the specified extensions (default)
    #------------------------------------------------------------------------
    def self.load_script(filename, mode = 2)
      ext = File.extname(filename)
      ext = ext[1,ext.size-1]
      if (CXJ::SCRIPT_LOADER::PACKED_SUFFIXES).include?(ext) || mode == 1
        File.open(filename, "rb") do |file|
          Marshal.load(file).each do |script|
            @external_script.push(script)
          end
        end
      elsif (CXJ::SCRIPT_LOADER::RUBY_SUFFIXES).include?(ext) || mode == 0
        load filename
      end
      evaluate_packed_scripts
    end
    
    #------------------------------------------------------------------------
    # Pack Script Folder
    #   folder      : Name of folder without trailing or lead slash
    #   recursive   : Whether or not to iterate over its subfolders as well
    #   destination : The destination file name
    #------------------------------------------------------------------------
    def self.pack_script_folder(folder, recursive = true, destination = folder + ".rvdata2")
      script_list = []
      ruby_files = "*.rb"
      ruby_files = File.join("**", ruby_files) if recursive
      Dir[File.join(folder, ruby_files)].each do |filename|
        File.open(filename, "rb") do |file|
          script_list.push(file.read)
        end
      end
      File.open(destination, "wb") do |file|
        Marshal.dump(script_list, file)
      end
    end
    
    #------------------------------------------------------------------------
    # Removes First Entry From Script List And Returns
    #------------------------------------------------------------------------
    def self.shift_packed_script_queue
      @external_script.shift
    end
    
    #------------------------------------------------------------------------
    # Get Size Of Script List
    #------------------------------------------------------------------------
    def self.packed_script_queue_size
      @external_script.size
    end
    
    #------------------------------------------------------------------------
    # Automatically run script that loads scripts based on location settings.
    #------------------------------------------------------------------------
    LOCATIONS.each do |location|
      ruby_ext = ''
      pack_ext = ''
      CXJ::SCRIPT_LOADER::RUBY_SUFFIXES.each do |ext|
        ruby_ext+= ',' if !ruby_ext.empty?
        ruby_ext+= ext
      end
      CXJ::SCRIPT_LOADER::PACKED_SUFFIXES.each do |ext|
        pack_ext+= ',' if !pack_ext.empty?
        pack_ext+= ext
      end
      folder = location[0]
      recursive = location[1]
      mode = location[2]
      case(mode)
      when 0
        ruby_files = "*.{" + ruby_ext + "}"
      when 1
        ruby_files = "*.{" + pack_ext + "}"
      else
        ruby_files = "*.{" + ruby_ext + "," + pack_ext + "}"
      end
      ruby_files = File.join("**", ruby_files) if recursive
      Dir[File.join(folder, ruby_files)].each do |filename|
        load_script(filename)
      end
    end
  end
end