﻿#==============================================================================
# 
# GaryCXJk - Savedata Extender v1.01
# * Last Updated: 2013.01.19
# * Level: Medium
# * Requires: N/A
# 
#==============================================================================

$imported = {} if $imported.nil?
$imported["CXJ-SavedataExtender"] = true

#==============================================================================
#
# Changelog:
#
#------------------------------------------------------------------------------
# 2013.01.19 - v1.01
#
# * Added: Made it compatible with anything editing the save format
#
#------------------------------------------------------------------------------
# 2012.12.28 - v1.00
#
# * Initial release
#
#==============================================================================
#
# Sometimes you want to save that extra bit of data, either to show in the
# header (when on the save loading screen), or because you're exclusively
# using scripts to store your variables. Which is okay, really.
#
# This script will allow you to easily do all that. To be honest, I only
# created this for another script I wanted to make, which allows you to add
# a thumbnail to the saves.
#
#==============================================================================
#
# Installation:
#
# Make sure to put this below Materials, but above Main Process. Also, this
# overrides several functions. If you are sure no function that is used by
# other scripts get overridden, you can place it anywhere, otherwise, make
# sure this script is loaded first. Do know that there is a possibility that
# this script will stop working due to that.
#
#==============================================================================
#
# Overridden functions:
#
# * module DataManager
#   - self.make_save_header
#   - self.make_save_contents
#
#==============================================================================
#
# Usage:
#
# In your own script, create methods for stuff you want to save and / or load.
#
# To save data, make a method that has no arguments and returns a Hash
# containing data, using symbols as keys.
#
# Example:
#
# def data_saver
#   data = {}
#   data[:example] = $some_data
#   return data
# end
#
# To load data, make a method that takes a Hash as an argument. It contains the
# data in the same way you save data.
#
# Example:
#
# def data_loader(data)
#   $some_data = data[:example]
# end
#
# Note that there are some symbols reserved by RPG Maker VX Ace.
#
# To add a method to the save or load list, use the following functions:
#
# CXJ::SAVEDATA_EXTENDER::add_save_handler(m, on_header, on_content)
# CXJ::SAVEDATA_EXTENDER::add_load_handler(m)
#
# m is either a symbol referencing the method, or a method object itself.
# on_header defines whether or not data will be saved on the header.
# on_content defines whether or not data will be saved as regular content.
#
#------------------------------------------------------------------------------
# Reserved symbols:
#
# * Header:
#     :characters
#     :playtime_s
#
# * Content (also reserved on the header using Yanfly's Ace Save Engine):
#     :system
#     :timer
#     :message
#     :variables
#     :self_switches
#     :actors
#     :party
#     :troop
#     :map
#     :player
#
#==============================================================================
#
# License:
#
# Creative Commons Attribution 3.0 Unported
#
# The complete license can be read here:
# http://creativecommons.org/licenses/by/3.0/legalcode
#
# The license as it is described below can be read here:
# http://creativecommons.org/licenses/by/3.0/deed
#
# You are free:
#
# to Share — to copy, distribute and transmit the work
# to Remix — to adapt the work
# to make commercial use of the work
#
# Under the following conditions:
#
# Attribution — You must attribute the work in the manner specified by the
# author or licensor (but not in any way that suggests that they endorse you or
# your use of the work).
#
# With the understanding that:
#
# Waiver — Any of the above conditions can be waived if you get permission from
# the copyright holder.
#
# Public Domain — Where the work or any of its elements is in the public domain
# under applicable law, that status is in no way affected by the license.
#
# Other Rights — In no way are any of the following rights affected by the
# license:
#
# * Your fair dealing or fair use rights, or other applicable copyright
#   exceptions and limitations;
# * The author's moral rights;
# * Rights other persons may have either in the work itself or in how the work
#   is used, such as publicity or privacy rights.
#
# Notice — For any reuse or distribution, you must make clear to others the
# license terms of this work. The best way to do this is with a link to this
# web page.
#
#------------------------------------------------------------------------------
# Extra notes:
#
# Despite what the license tells you, I will not hunt down anybody who doesn't
# follow the license in regards to giving credits. However, as it is common
# courtesy to actually do give credits, it is recommended that you do.
#
# As I picked this license, you are free to share this script through any
# means, which includes hosting it on your own website, selling it on eBay and
# hang it in the bathroom as toilet paper. Well, not selling it on eBay, that's
# a dick move, but you are still free to redistribute the work.
#
# Yes, this license means that you can use it for both non-commercial as well
# as commercial software.
#
# You are free to pick the following names when you give credit:
#
# * GaryCXJk
# * Gary A.M. Kertopermono
# * G.A.M. Kertopermono
# * GARYCXJK
#
# Personally, when used in commercial games, I prefer you would use the second
# option. Not only will it actually give me more name recognition in real
# life, which also works well for my portfolio, it will also look more
# professional. Also, do note that I actually care about capitalization if you
# decide to use my username, meaning, capital C, capital X, capital J, lower
# case k. Yes, it might seem stupid, but it's one thing I absolutely care
# about.
#
# Finally, if you want my endorsement for your product, if it's good enough
# and I have the game in my posession, I might endorse it. Do note that if you
# give me the game for free, it will not affect my opinion of the game. It
# would be nice, but if I really did care for the game I'd actually purchase
# it. Remember, the best way to get any satisfaction is if you get people to
# purchase the game, so in a way, I prefer it if you don't actually give me
# a free copy.
#
# This script was originally hosted on:
# http://area91.multiverseworks.com
#
#==============================================================================
#
# The code below defines the settings of this script, and are there to be
# modified.
#
#==============================================================================

module CXJ
  module SAVEDATA_EXTENDER
    # Enables or disables debug messages whenever an error occurs during save.
    SAVE_DEBUG = false
  end
end
#==============================================================================
#
# The code below should not be altered unless you know what you're doing.
#
#==============================================================================

module CXJ
  module SAVEDATA_EXTENDER
    HEADER_EXTENSION = []
    CONTENT_EXTENSION = []
    LOAD_EXTENSION = []
    
    #------------------------------------------------------------------------
    # * New: Add Save Handler
    #     This allows you to add methods that add data to the save file.
    #   This method doesn't have any arguments and should return a Hash,
    #   using symbols for keys.
    #------------------------------------------------------------------------
    def self.add_save_handler(m, on_header, on_content)
      if m.instance_of?(Symbol)
        HEADER_EXTENSION.push(self.method(m)) if on_header
        CONTENT_EXTENSION.push(self.method(m)) if on_content
      elsif m.instance_of?(Method)
        HEADER_EXTENSION.push(m) if on_header
        CONTENT_EXTENSION.push(m) if on_content
      end
    end
    #------------------------------------------------------------------------
    # * New: Add Load Handler
    #     This allows you to add methods that load data from the save file.
    #   This method takes one argument containing a Hash with the data.
    #------------------------------------------------------------------------
    def self.add_load_handler(m)
      if m.instance_of?(Symbol)
        LOAD_EXTENSION.push(self.method(m))
      elsif m.instance_of?(Method)
        LOAD_EXTENSION.push(m)
      end
    end
  end
end

module DataManager
  #--------------------------------------------------------------------------
  # * Alias: Create Save Header
  #--------------------------------------------------------------------------
  class << self
    datamanager_make_save_header_cxj_se = instance_method(:make_save_header)
    define_method :make_save_header do
      header = datamanager_make_save_header_cxj_se.bind(self).call
      CXJ::SAVEDATA_EXTENDER::HEADER_EXTENSION.each do |m|
        begin
          data = m.call
          data.each {|key, value|
            header[key]= value
          }
        rescue
          puts($!.message) if CXJ::SAVEDATA_EXTENDER::SAVE_DEBUG
        end
      end
      header
    end
  end
  #--------------------------------------------------------------------------
  # * Alias: Create Save Contents
  #--------------------------------------------------------------------------
  class << self
    data_manager_make_save_contents_cxj_se = instance_method(:make_save_contents)
    define_method :make_save_contents do
      contents = data_manager_make_save_contents_cxj_se.bind(self).call
      CXJ::SAVEDATA_EXTENDER::CONTENT_EXTENSION.each do |m|
        begin
          data = m.call
          data.each {|key, value|
            contents[key]= value
          }
        rescue
          puts($!.message) if CXJ::SAVEDATA_EXTENDER::SAVE_DEBUG
        end
      end
      contents
    end
  end
  #--------------------------------------------------------------------------
  # * Alias: Extract Save Contents
  #--------------------------------------------------------------------------
  class << self
    datamanager_extract_save_contents_cxj_se = instance_method(:extract_save_contents)
    define_method :extract_save_contents do |contents|
      datamanager_extract_save_contents_cxj_se.bind(self).call(contents)
      CXJ::SAVEDATA_EXTENDER::LOAD_EXTENSION.each do |m|
        m.call(contents)
      end
    end
  end
end