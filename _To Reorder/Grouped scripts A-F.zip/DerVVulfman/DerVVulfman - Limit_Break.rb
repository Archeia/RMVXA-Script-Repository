#==============================================================================
# ** Limit Break (DVV's)
#------------------------------------------------------------------------------
#    by DerVVulfman
#    version 2.6
#    07-25-2008
#    Full SDK 2.2 Compatible (Does not need or require SDK 2.2)
#------------------------------------------------------------------------------
#
# INTRODUCTION:
#
#   This system is a revamped & rewritten system that disables 'element-tagged'
#   skills until the hero's limitbreak bar is filled.   Once the skill is used,
#   the skill becomes disabled again.   Works with and without the RTAB system.
#   
#   One feature  that was sadly lacking in all other systems  was the inability
#   to fill the limitbreak bar with item damage.   Previous systems only looked
#   to damage inflicted through attacks and skill use.   Items such as grenades
#   were entirely overlooked.
#
#   It has been designed 'menu-less' by intent, and this is to prevent any pos-
#   sible conflicts with any custom menu system. However Alistor (RMXP.ORG) has
#   designed a menu system  that can change  an actor's  limit break fill-type:
#   (Attack/Defend/Guard).  It is ready for plug-n-play use.
#
#   The system, by itself, does not change the 'ATTACK' option  in the Actor's
#   command window either.   Instead, this system  enables/disables the skills
#   in the skill menu  for you to select.   Another add-on has been created by
#   me to change the 'Attack' option for you.      * It's been asked for. :) *
#
#   It still requires a bar-drawing system such as 'Cogwheel's HP/SP/EXP Gauge' 
#   script to draw the Limit Break bar, unless a suitable Bar Drawing script is
#   available.  However, when not using a bar-drawing system, you merely do not
#   have bars visible in-game.  Previous versions either had their own built-in
#   cheaply designed bar system,  or required a separate script  to prevent the 
#   project from crashing.   This system neither needs bars  to be drawn or re-
#   quires a bar system to prevent crashes.
#
#------------------------------------------------------------------------------
#
#  SYSTEMS OF NOTE:
#
#   While most of the configuration system is set via CONSTANTS,  the 'Flexible
#   Positioning System' is set via ($)Global values that can be edited from any
#   MAP EVENT script call.   That way,  positioning of the bars  can be changed
#   based on which menu or battlestatus window you are using at the time.   The
#   RTAB battlesystem  uses its own set of $Global values ($lb_rtab_pos & _var)
#   as it has an almost unique way  to draw its own  BattleStatus window.   The
#   ParaDog v 2.58 battlesystem  also uses  these two values  for its own limit
#   break bar placement.
#
#   The $lb_hidden global array can hold the ID of actors in your database that
#   do not have their Limit Break bars visible on the screen.  It also disables
#   the Limit Break Sound Effect from playing if the same actor's 'limit-break' 
#   value has maxed out (his/her non-visible bar becomes filled).  As a $global
#   value, it too can be edited from any MAP EVENT script call.
#
#------------------------------------------------------------------------------
#
#  COMPATABILITY:
#
#   This system has been designed initially for the default and RTAB battlesys-
#   tems, however by the use of ALIASes throughout the system... this script is
#   also SDK 2.2 compliant, and compliant with both the XRXS #65 and the Para-
#   Dog V 2.58 battlesystem:
#
#   RE:  ParaDog's V 2.58
#   *  As stated above, the ParaDog system also uses the same section of the
#      'Flexible Positioning System as RTAB.   This allows the use of Verti-
#      cally aligned Limit Break bars instead of the default Horizontal bars.
#
#
#------------------------------------------------------------------------------
#
#  CREDITS AND THANKS:
#
#   Thanks goes to link2795 for discovering the 'healing items/RTAB' bug.  And
#   to Jaide for recommending the 'Death Wipe' feature, & finding an RTAB bug.
#   Also to VinVulpis for noting a misplaced @active_battler value, and final-
#   ly to Nadim who found that enemies attacking themselves caused nil errors
#   as no 'actor' performed these actions.
#
#==============================================================================


   #=======================================================================#
   #  **  C  O  N  F  I  G  U  R  A  T  I  O  N      S  Y  S  T  E  M  **  #
   #=======================================================================#

  # Name of the Limit Break element 
  LB_NAME   = "Limit Break"


  # Starting/Default Limit Break Setting
  LB_START  = 0   # 0 = Attack          |  1 = Critical      |  2 = Damaged
                  # 3 = Killed an enemy |  4 = Killed a Boss |  5 = Hero Died
                  # 6 = Victory         |  7 = Escape/Flee   |  8 = Defending
                  # 9 = Lone Combatant  | 10 = Any Action    | 11 = Crit. Health
  

  # Enemy Bosses (by ID)
  # Related to the LB_Rate, it determines if points garnered through 'killing'
  # an ememy gives regular 'enemy' points or 'boss' points to your LB gauge.
  LB_BOSSES = [17]   # Set to enemy 17 (Skeleton)
  
  # Hidden Actors (by ID)
  # This array holds the ID number of Actors who hide their own Limit Break bars
  # in both the battle and menu screens.  Will only apply to both battle & menu.
  $lb_hidden = [7]  # Set to actor #7: Gloria
  
 
  # Limit Break Max Value
  LB_MAX    = 1000

  
  # Limit Break Fill Rates
  # For flat rates & max value settings, the max value should not exceed LB_MAX.
  LB_RATE   = [ 100,  500, 1000,  # Hero Attacks the Enemy    (rate, min., max.)
                250,  250, 1000,  # Hero delivers a CRITICAL! (rate, min., max.)
                300,  100, 1000,  # Hero takes Damage         (rate, min., max.)
                500,  750, 1000,  # Fatalaties:  Enemy, Boss or Self (flat rate)
                200,  200, 1000,  # Victory, Escape & Defending      (flat rate)
                160,  400, 1000]  # Loner, Action & Crit. Health     (flat rate)

  # Limit Break Death Wipe                
  # This supercedes the LB_RATE condition for the 'Hero Died' setting.
  LB_D_WIPE = true                # If true, death wipes out their LB points.
                
  
  # Flexible positioning system.  Default position appears under the STATUS txt.
  $lb_menu_on    = 1              # If set to '1', the bar is shown in the menu.
  $lb_menu_pos   = [ 0,   0, 190] # Positioning in the menu:  X, Y, & bar width.
  $lb_battle_pos = [ 0,  64, 120] # Positioning in the battle menu.  Same setup.
  
  # For special consideration...  # RTAB and ParaDog Limit break bars use below.
  
  $lb_rtab_pos   = [ 0, -25, 111] # Position if using RTAB system.   Same setup.
  $lb_rtab_var   = [0, 40]        # Variable distances between hero's LB gauges.
  
  
  # SE played when Limit Break filled
  LB_RING   = "006-System06"
    

#------------------------------------------------------------------------------#
# Do not edit below unless you know what you're doing.  The following code is  #
# for automatic systems in the script.  Values are edited or passed elsewhere. #
#------------------------------------------------------------------------------#

  # Stores the battler id for item users (needed for non-RTAB systems)
  $item_user = nil
  # Obtain the Limit Break 'id' from the system
  $data_system = load_data("Data/System.rxdata")
  $lb_element_id = $data_system.elements.index(LB_NAME)
  
   #========================================================================
   #            C O N F I G U R A T I O N   S Y S T E M   E N D            #
   #========================================================================


module Limit_Shortcuts
  #--------------------------------------------------------------------------
  # * Attack / Struck an enemy (for type 0 conditions)
  #     aggressor : battler
  #     victim    : battler
  #--------------------------------------------------------------------------  
  def lb_attacker(aggressor, victim, current_dmg)
    # Check to make sure the victim is an enemy and the aggressor is self
    if aggressor.is_a?(Game_Actor) && victim.is_a?(Game_Enemy) && aggressor.lb_type == 0
      # Limit Break growth calculation
      lb_calc = current_dmg * LB_RATE[0] * 10 / victim.base_damage
      # Adjust Limit Break growth between min & max values
      lb_add = [[lb_calc, LB_RATE[1]].max, LB_RATE[2]].min
      # OD gauge increase
      aggressor.limitbreak += lb_add
    end  
  end
  #--------------------------------------------------------------------------
  # * Damaged by an enemy (for type 2 conditions)
  #     aggressor : battler
  #     victim    : battler
  #--------------------------------------------------------------------------  
  def lb_damaged(aggressor, victim, current_dmg)
    # Check to make sure the agressor is an enemy and the victim is self
    if aggressor.is_a?(Game_Enemy) && victim.is_a?(Game_Actor) && victim.lb_type == 2
      lb_calc = current_dmg * LB_RATE[6] * 10 / victim.maxhp
      # Adjust Limit Break growth between min & max values
      lb_add = [[lb_calc, LB_RATE[7]].max, LB_RATE[8]].min
      victim.limitbreak += lb_add
    end    
  end
end

#============================================================================== 
# ** Game_System
#------------------------------------------------------------------------------
#  This class handles data surrounding the system. Backround music, etc.
#  is managed here as well. Refer to "$game_system" for the instance of 
#  this class.
#==============================================================================

class Game_System
  #--------------------------------------------------------------------------
  # * Public Instance Variables
  #--------------------------------------------------------------------------
  # Additional values for the save/load feature
  attr_accessor :lb_rtab_detected         # Detect RTAB system
  attr_accessor :lb_para_detected         # Detect ParaDog system
  attr_accessor :lb_mn                    # menu on
  attr_accessor :lb_mp                    # menu position
  attr_accessor :lb_bp                    # battle position
  attr_accessor :lb_rp                    # rtab position
  attr_accessor :lb_rv                    # rtab variance
  attr_accessor :lb_h                     # hidden
  #--------------------------------------------------------------------------
  # * Object Initialization
  #--------------------------------------------------------------------------
  alias lb_init initialize
  def initialize
    # Perform the original call
    lb_init
    @lb_rtab_detected = nil
    @lb_para_detected = nil
    # Create the savable values
    @lb_mn            = 0
    @lb_mp            = []
    @lb_bp            = []
    @lb_rp            = []
    @lb_rv            = []
    @lb_h             = []
  end  
end  



#==============================================================================
# ** Scene_Save
#------------------------------------------------------------------------------
#  This class performs save screen processing.
#==============================================================================

class Scene_Save < Scene_File
  #--------------------------------------------------------------------------
  # * Write Save Data
  #     file : write file object (opened)
  #--------------------------------------------------------------------------
  alias lb_wsd write_save_data
  def write_save_data(file)
    # Store the globals
    $game_system.lb_mn  = $lb_menu_on
    $game_system.lb_mp  = $lb_menu_pos
    $game_system.lb_bp  = $lb_battle_pos
    $game_system.lb_rp  = $lb_rtab_pos
    $game_system.lb_rv  = $lb_rtab_var
    $game_system.lb_h   = $lb_hidden
    # Perform the original call
    lb_wsd(file)
  end
end



#==============================================================================
# ** Scene_Load
#------------------------------------------------------------------------------
#  This class performs load screen processing.
#==============================================================================

class Scene_Load < Scene_File
  #--------------------------------------------------------------------------
  # * Read Save Data
  #     file : file object for reading (opened)
  #--------------------------------------------------------------------------
  alias lb_rsd read_save_data
  def read_save_data(file)
    #Perform the original call
    lb_rsd(file)
    # ReStore the globals
    $lb_menu_on    = $game_system.lb_mn
    $lb_menu_pos   = $game_system.lb_mp
    $lb_battle_pos = $game_system.lb_bp
    $lb_rtab_pos   = $game_system.lb_rp
    $lb_rtab_var   = $game_system.lb_rv
    $lb_hidden     = $game_system.lb_h
  end
end



#==============================================================================
# ** Game_Battler
#------------------------------------------------------------------------------
#  This class deals with battlers. It's used as a superclass for the Game_Actor
#  and Game_Enemy classes.
#==============================================================================

class Game_Battler
  include Limit_Shortcuts
  #--------------------------------------------------------------------------
  # * Public Instance Variables
  #--------------------------------------------------------------------------
  attr_accessor :max_ct
  attr_accessor :base_damage
  #--------------------------------------------------------------------------
  # * Object Initialization
  #--------------------------------------------------------------------------
  alias lb_init initialize
  def initialize
    lb_init
    if max_ct != nil
      $game_system.lb_para_detected = true
    end
  end
  #--------------------------------------------------------------------------
  # * Applying Normal Attack Effects (Edited)
  #     attacker : battler
  #--------------------------------------------------------------------------
  alias lb_attack_effect attack_effect
  def attack_effect(attacker)
    # Attach base damage to battler (for self.base_damage)
    @base_damage = nil
    # Execute the original process
    result = lb_attack_effect(attacker)
    # Set current damage (rtab or not)
    current_dmg = self.damage
    if $game_system.lb_rtab_detected; current_dmg = self.damage[attacker]; end
    # Set crit flag (rtab or not)
    current_crit = self.critical
    if $game_system.lb_rtab_detected; current_crit = self.critical[attacker]; end
    # Calculate basic damage
    if @base_damage == nil
      @base_damage = 
      [attacker.atk - self.pdef / 2, 0].max * (20 + attacker.str) / 20
    end
    # When actual physical damage is applied
    if result && current_dmg.is_a?(Numeric) && self.base_damage > 0
      # When HERO attacking the enemy (and tagged for 'Attack')
      lb_attacker(attacker, self, current_dmg)
      # If the HERO made a critical hit on the Enemy
      if attacker.is_a?(Game_Actor) && self.is_a?(Game_Enemy) && attacker.lb_type == 1 
        if current_crit
          # Limit Break growth calculation
          lb_calc = current_dmg * LB_RATE[3] * 10 / self.base_damage
          # Adjust Limit Break growth between min & max values
          lb_add = [[lb_calc, LB_RATE[4]].max, LB_RATE[5]].min
          # OD gauge increase
          attacker.limitbreak += lb_add  
        end
      end
      # When HERO is damaged by the enemy (and tagged for 'Damaged')
      lb_damaged(attacker, self, current_dmg)
    end
    return result
  end
  #--------------------------------------------------------------------------
  # * Apply Skill Effects
  #     user  : the one using skills (battler)
  #     skill : skill
  #--------------------------------------------------------------------------  
  alias lb_skill_effect skill_effect  
  def skill_effect(user, skill)
    # Attach base damage to battler (for self.base_damage)
    @base_damage = nil
    # Execute the original process
    result = lb_skill_effect(user, skill)
    # Set current damage (rtab or not)
    current_dmg = self.damage
    if $game_system.lb_rtab_detected; current_dmg = self.damage[user]; end
    # Recalculate the base (unadjusted) damage
    if @base_damage == nil
      # Calculate power
      power = skill.power + user.atk * skill.atk_f / 100
      if power > 0
        power -= self.pdef * skill.pdef_f / 200
        power -= self.mdef * skill.mdef_f / 200
        power = [power, 0].max
      end
      # Calculate rate
      rate = 20
      rate += (user.str * skill.str_f / 100)
      rate += (user.dex * skill.dex_f / 100)
      rate += (user.agi * skill.agi_f / 100)
      rate += (user.int * skill.int_f / 100)
      # Calculate basic damage
      @base_damage = power * rate / 20
    end
    # When actual physical damage is applied
    if result && current_dmg.is_a?(Numeric) && self.base_damage > 0
      # When HERO attacking the enemy (and tagged for 'Attack')
      lb_attacker(user, self, current_dmg)
      # When HERO is damaged by the enemy (and tagged for 'Damaged')
      lb_damaged(user, self, current_dmg)
    end
    # When limitbreak skill is used
    if user.is_a?(Game_Actor) && skill.element_set.include?($lb_element_id)
      # Reset gauge
      user.limitbreak = 0
    end
    return result
  end
  #--------------------------------------------------------------------------
  # * Application of Item Effects
  #     item : item
  #--------------------------------------------------------------------------
  alias lb_item_effect item_effect  
  def item_effect(item, battler = @active_battler)
    # Attach base damage to battler (for self.base_damage)
    @base_damage = nil
    # Set 'user' to the current battler (and ensure if RTAB)
    user = $item_user
    if $game_system.lb_rtab_detected; user = battler; end
    # Execute the original process (RTAB or not)
    if $game_system.lb_rtab_detected
      result = lb_item_effect(item, user)
    else
      result = lb_item_effect(item)
    end
    # Set current damage (rtab or not)
    current_dmg = self.damage
    if $game_system.lb_rtab_detected; current_dmg = self.damage[user]; end
    # Recalculate the base (unadjusted) damage
    if @base_damage == nil
      #Calculate power
      power = maxhp * item.recover_hp_rate / 100 + item.recover_hp
      if power < 0
        power += self.pdef * item.pdef_f / 20
        power = [power, 0].min
      end
      # Set damage value and reverse item power amount
      @base_damage = -power
    end
    # When actual physical damage is applied
    if result && current_dmg.is_a?(Numeric) && self.base_damage > 0
      # When HERO attacking the enemy (and tagged for 'Attack')
      lb_attacker(user, self, current_dmg)
      # When HERO is damaged by the enemy (and tagged for 'Damaged')
      lb_damaged(user, self, current_dmg)
    end
    return result
  end
end



#==============================================================================
# ** Game_Actor
#------------------------------------------------------------------------------
#  This class handles the actor. It's used within the Game_Actors class
#  ($game_actors) and refers to the Game_Party class ($game_party).
#==============================================================================

class Game_Actor < Game_Battler 
  #--------------------------------------------------------------------------
  # * Public Instance Variables
  #--------------------------------------------------------------------------
  attr_reader   :limitbreak               # Limitbreak value
  attr_accessor :lb_type                  # Limitbreak action type
  attr_accessor :limitbreak_ring          # Limit Break Ring Checker
  attr_accessor :battle_started
  #--------------------------------------------------------------------------
  # * Setup
  #     actor_id : actor ID
  #--------------------------------------------------------------------------
  alias lb_setup setup
  def setup(actor_id)
    # Perform the original call
    lb_setup(actor_id)
    @limitbreak = 0           # Reset Limit Break gauge to zero
    @lb_type = LB_START       # Set the Limit Break type to 'config' settings.
    @limitbreak_ring = false  # Turn the 'ring' off
    @battle_started  = false
  end
  #--------------------------------------------------------------------------
  # * Determine if Skill can be Used
  #     skill_id : skill ID
  #--------------------------------------------------------------------------
  alias lb_skill_can_use? skill_can_use?
  def skill_can_use?(skill_id)
    # Get result from original call
    result = lb_skill_can_use?(skill_id)
    # Return if already disabled
    return if result == false
    # Obtain skill from database
    skill = $data_skills[skill_id]
    # Only perform if skill
    if skill != nil
      # Only perform if includes the Element
      if skill.element_set.include?($lb_element_id)
        # If the limitbreak bar is filled, skill is available
        if self.limitbreak >= LB_MAX
          result = true
        # Otherwise, it isn't
        else
          result = false
        end
      end
    end
    return result & super
  end 
  #--------------------------------------------------------------------------
  # * Adjust the limitbreak value (permits addition & keeps within range)
  #--------------------------------------------------------------------------
  def limitbreak=(limitbreak)
    @limitbreak = limitbreak
    @limitbreak = LB_MAX if @limitbreak > LB_MAX 
    @limitbreak = 0 if @limitbreak < 0
  end
  #--------------------------------------------------------------------------
  # * Acquire Limit Break value (nil values won't cause errors now)
  #--------------------------------------------------------------------------
  def limitbreak
    # Return 0 if nil (prevent errors)
    @limitbreak = 0 if @limitbreak == nil
    return @limitbreak
  end
end



#==============================================================================
# ** Window_Base
#------------------------------------------------------------------------------
#  This class is for all in-game windows.
#==============================================================================
class Window_Base
  #--------------------------------------------------------------------------
  # * Draw Actor Name
  #--------------------------------------------------------------------------
  alias lb_draw_actor_name draw_actor_name
  def draw_actor_name(actor, x, y)
    # Only perform if the actor isn't hidden
    unless $lb_hidden.include?(actor.id)
      # Set/reset the x, y and width of the Limit Break bar.    
      ox = $game_temp.in_battle ? $lb_battle_pos[0] : $lb_menu_pos[0]
      oy = $game_temp.in_battle ? $lb_battle_pos[1] : $lb_menu_pos[1]
      ow = $game_temp.in_battle ? $lb_battle_pos[2] : $lb_menu_pos[2]
      # To menu... or not to menu
      if $lb_menu_on == 1 && !$game_temp.in_battle
        draw_actor_lb(actor, x + ox, y + oy + 32, ow)
      elsif $game_temp.in_battle
        unless $game_system.lb_rtab_detected or $game_system.lb_para_detected
          draw_actor_lb(actor, x + ox, y + oy + 32, ow)
        end
      end
    end
    lb_draw_actor_name(actor, x, y)
  end  
  #--------------------------------------------------------------------------
  # * Draw Battler Name
  #--------------------------------------------------------------------------
  # If the BattleStatus value of 'Alignment' exists
  if $bstat_align != nil
    alias lb_draw_battler_name draw_battler_name
    def draw_battler_name(actor, x, y)
      # Only perform if the actor isn't hidden
      unless $lb_hidden.include?(actor.id)
        # Set/reset the x, y and width of the Limit Break bar.    
        ox = $game_temp.in_battle ? $lb_battle_pos[0] : $lb_menu_pos[0]
        oy = $game_temp.in_battle ? $lb_battle_pos[1] : $lb_menu_pos[1]
        ow = $game_temp.in_battle ? $lb_battle_pos[2] : $lb_menu_pos[2]
        # To menu... or not to menu
        if $lb_menu_on == 1 && !$game_temp.in_battle
          draw_actor_lb(actor, x + ox, y + oy + 32, ow)
        elsif $game_temp.in_battle
          unless $game_system.lb_rtab_detected or $game_system.lb_para_detected
            draw_actor_lb(actor, x + ox, y + oy + 32, ow)
          end
        end
      end
      lb_draw_battler_name(actor, x, y)
    end    
  end
  #--------------------------------------------------------------------------
  # * Draw Limit Break Meter
  #--------------------------------------------------------------------------
  def draw_actor_lb(actor, x, y, width = 144)
    if defined?(gauge_rect)
      rate = actor.limitbreak.to_f / LB_MAX
      plus_x = 0
      rate_x = 0
      plus_y = 25
      plus_width = 0
      rate_width = 100
      height = 10
      align1 = 1
      align2 = 2
      align3 = 0
      grade1 = 1
      grade2 = 0
      color1 = Color.new(0, 0, 0, 192)
      color2 = Color.new(255, 255, 192, 192)
      color3 = Color.new(0, 0, 0, 192)
      color4 = Color.new(64, 0, 0, 192)
      color5 = Color.new(80 - 24 * rate, 80 * rate, 14 * rate, 192)
      color6 = Color.new(240 - 72 * rate, 240 * rate, 62 * rate, 192)
      lb = (width + plus_width) * actor.limitbreak * rate_width / 100 / LB_MAX
      gauge_rect(x + plus_x + width * rate_x / 100, y + plus_y,
        width, plus_width + width * rate_width / 100,
        height, lb, align1, align2, align3,
        color1, color2, color3, color4, color5, color6, grade1, grade2)
    end      
  end
end



#==============================================================================
# ** Window_BattleStatus
#------------------------------------------------------------------------------
#  This window displays the status of all party members on the battle screen.
#==============================================================================
class Window_BattleStatus < Window_Base
  
  alias lb_init initialize
  def initialize
    lb_init
    if defined?(at_refresh)
      $game_system.lb_rtab_detected = true
    end
    refresh
  end
  #--------------------------------------------------------------------------
  # * Full Limit Break Gauge SE
  #--------------------------------------------------------------------------
  def full_lb_se
    if LB_RING != nil
      if LB_RING != ""
        Audio.se_play("Audio/SE/" + LB_RING, 80, 100)
      end
    end
  end
  #--------------------------------------------------------------------------
  # * Frame renewal
  #--------------------------------------------------------------------------
  alias lb_refresh refresh
  def refresh(number = 0)
    # Call the original def
    if $game_system.lb_rtab_detected
      lb_refresh(number)
    else
      lb_refresh
    end
    # This block is needed only if RTAB in use
    if $game_system.lb_rtab_detected or $game_system.lb_para_detected
      # Ensure bitmap available for bar drawing
      if self.contents == nil
        self.contents = Bitmap.new(width - 32 ,height - 32)
      end
      # Search through actors & draw bar if applicable
      if number == 0
        for i in 0...$game_party.actors.size
          rtab_pos_x = $lb_rtab_pos[0] + ($lb_rtab_var[0] * i)
          rtab_pos_y = $lb_rtab_pos[1] + ($lb_rtab_var[1] * i)
          unless $lb_hidden.include?($game_party.actors[i].id)
            draw_actor_lb($game_party.actors[i], rtab_pos_x, rtab_pos_y+10,  $lb_rtab_pos[2])
          end
        end
      else
        if $game_party.actors[number].is_a?(Game_Actor)
          rtab_pos_x = $lb_rtab_pos[0] + ($lb_rtab_var[0] * number)
          rtab_pos_y = $lb_rtab_pos[1] + ($lb_rtab_var[1] * number)
          unless $lb_hidden.include?($game_party.actors[number].id)
            draw_actor_lb($game_party.actors[number], rtab_pos_x, rtab_pos_y+10, $lb_rtab_pos[2])
          end
        end
      end
    end
    # Go through the Actors
    $game_party.actors.each { |actor|
      # Only perform if the actor exists
      next unless actor.exist?
      # When the Limit Break gauge is set to zero,
      # Reset the Limit Break Ringer to false
      if actor.limitbreak == 0
        actor.limitbreak_ring = false
      end
      # When the Limit Break Ringer hasn't rung
      if actor.limitbreak_ring == false
        # But, if the Limit Break Bar is filled
        if actor.limitbreak == LB_MAX
          # Do not permit hidden actor bars to ring
          unless $lb_hidden.include?(actor.id)
            # If the battle only just started
            if actor.battle_started == true
              # turn off the battle started flag
              actor.battle_started = false
            else
              # Play the Limit Break Sound Effect
              full_lb_se
            end
          end
          # And Set the Limit Break Ringer to true
          actor.limitbreak_ring = true
        end
      end
      }        
  end
end



#==============================================================================
# ** Scene_Battle
#------------------------------------------------------------------------------
#  This class performs battle screen processing.
#==============================================================================

class Scene_Battle
  #--------------------------------------------------------------------------
  # * Main Processing
  #--------------------------------------------------------------------------
  alias lb_main main
  def main  
    # Ensure that the limitbreak SE doesn't chime at battle start
    for i in 0...$game_party.actors.size
      if $game_party.actors[i].limitbreak == LB_MAX
        $game_party.actors[i].battle_started  = true
        $game_party.actors[i].limitbreak_ring = true
      end
    end
    lb_main
  end
  #--------------------------------------------------------------------------
  # * Battle Ends
  #     result : results (0:win 1:lose 2:escape)
  #--------------------------------------------------------------------------
  alias lb_battle_end battle_end
  def battle_end(result)
    # Branch on Battle condition
    case result
    when 0 # Victory
      $game_party.actors.each { |actor|
      next unless actor.exist?
      # For each actor who won & set to Victory
      if actor.lb_type == 6
        actor.limitbreak += LB_RATE[12]
      end
      }
    when 1 # Escape
      $game_party.actors.each { |actor|
      next unless actor.exist?
      # For each actor who ran & set to Escape
      if actor.lb_type == 7
        actor.limitbreak += LB_RATE[13]
      end
      }
    end
    # Defeat
    lb_battle_end(result)
  end
  #--------------------------------------------------------------------------
  # * Frame Update (main phase step 2 : start action)
  #--------------------------------------------------------------------------
  alias lb_adddate_p4_s2 update_phase4_step2
  def update_phase4_step2(battler = @active_battler)
    # Perform only if actor
    if battler.is_a?(Game_Actor)
      # Reset adding value
      lb_add = 0
      # Branch on LimitBreak type
      case battler.lb_type
      when 8 # When Defending
        if battler.current_action.kind == 0
          if battler.current_action.basic == 1
            lb_add = LB_RATE[14]
          end
        end
      when 9 # When it's a lone battler
        if $game_party.actors.size == 1
          lb_add = LB_RATE[15]
        end
      when 10 # When performing ANY acton
        lb_add = LB_RATE[16]
      when 11 # If in CRITICAL
        if battler.hp <= battler.maxhp / 4
          lb_add = LB_RATE[17]
        end
      end
      # Add values to limitbreak
      battler.limitbreak += lb_add
    end
    # Perform the original call
    if $game_system.lb_rtab_detected; lb_adddate_p4_s2(battler); else; lb_adddate_p4_s2; end
  end
  #--------------------------------------------------------------------------
  # * Make Item Action Results
  #--------------------------------------------------------------------------  
  alias lb_miar make_item_action_result 
  def make_item_action_result(battler = @active_battler)
    $item_user = battler
    # Perform the original call
    if $game_system.lb_rtab_detected; lb_miar(battler); else; lb_miar; end
  end  
  #--------------------------------------------------------------------------
  # * Frame Update (main phase step 4 : animation for target)
  #--------------------------------------------------------------------------  
  alias lb_update_p4_s4 update_phase4_step4 
  def update_phase4_step4(battler = @active_battler)
     if $game_system.lb_rtab_detected
      @status_window.update
      @status_window.refresh
     end
    # Perform the original call
    if $game_system.lb_rtab_detected; lb_update_p4_s4(battler); else lb_update_p4_s4 ; end    
  end
  #--------------------------------------------------------------------------
  # * Frame Update (main phase step 6 : refresh)
  #--------------------------------------------------------------------------
  alias lb_up4s6 update_phase4_step6
  def update_phase4_step6(battler = @active_battler)
    @rtab = !@target_battlers
    for target in (@rtab ? battler.target : @target_battlers)
      # If a battler has died
      if target.dead?
        # If the target battler is an enemy
        if target.is_a?(Game_Enemy)
          # Only if the attacker is an actor
          if battler.is_a?(Game_Actor)
            # If an enemy killed check is performed
            if battler.lb_type == 3
              battler.limitbreak += LB_RATE[9]
            # If a boss enemy check is performed
            elsif battler.lb_type == 4
              if LB_BOSSES.include?(target.id)
                battler.limitbreak += LB_RATE[10]
              end
            end
          end
        # else the battler is an actor
        else
          # if a 'Hero Dies' check is performed
          if target.lb_type == 5
            target.limitbreak += LB_RATE[11]
          end
          # If the Limit Break Death Wipe feature is on
          if LB_D_WIPE
            target.limitbreak = 0
          end
        end
        if $game_system.lb_rtab_detected
           @status_window.update
           @status_window.refresh
        end        
      end
    end    
    @rtab ? lb_up4s6(battler) : lb_up4s6
  end  
end