#==============================================================================
# ** Mouse Input Module (Revised)
#------------------------------------------------------------------------------
#   by DerVVulfman
#   version 1.2
#   08-18-2007
#------------------------------------------------------------------------------
#   Based on...
#   Mouse Input Module
#   by Near Fantastica
#------------------------------------------------------------------------------
#   Set_Pos feature by
#   Freakboy
#------------------------------------------------------------------------------
#
#   THE CALLS: 
#
#   Mouse.click?
#   This returns a true/false value  when you test whether a button is clicked.
#   The values you pass are 1 (for the left mouse button), 2 (for the right) or
#   3 (for the middle button).
#
#   Mouse.press?
#   This returns a true/false value  when you test  whether a button is pressed
#   and kept depressed.  The values you pass are 1 (for the left mouse button),
#   2 (for the right mouse button), or 3 (for the middle).
#
#   Mouse.pixels
#   This returns the  mouse's screen coordinates  in pixels.  Based on a screen
#   with a 640x480 dimension,  this returns an array of the mouse's position in
#   index values.  Calling Mouse.pixels returns both x & y positions  in a sin-
#   gle string,  but calling Mouse.pixels[0] returns the x position (0-639) and
#   calling Mouse.pixels[1]  returns  the y position (0-439).   If the mouse is
#   outside of the game's window region, this call returns nil.
#
#   Mouse.tiles
#   This returns  the mouse's screen  coordinates  in map tiles.   Based on the
#   system's 20x15 tile size,  this returns it in index values  (a 0-19 width & 
#   a 0-14 height).  This functions the same manner as Mouse.pixels.
#
#   Mouse.set_pos
#   This allows you  to forcefully position the mouse at an x/y position within
#   the game screen by pixel coordinates.  Given the game's normal screen width
#   of 640x480, adding:  Mouse.set_pos(320,240)  should position the mouse dead
#   center of the gaming window.
#
#   Mouse.update
#   Add this routine  into your update routines  to update  the mouse position.
#   It must be called otherwise you won't get valid mouse coordinates.
#
#==============================================================================

module Mouse
  @mouse_menu = 0
  #--------------------------------------------------------------------------
  # * Mouse Click
  #     button      : button
  #--------------------------------------------------------------------------
  def Mouse.click?(button)
    return true if @keys.include?(button)
    return false
  end  
  #--------------------------------------------------------------------------
  # * Mouse Pressed
  #     button      : button
  #--------------------------------------------------------------------------
  def Mouse.press?(button)
    return true if @press.include?(button)
    return false
  end
  #--------------------------------------------------------------------------
  # * Mouse Pressed
  #     button      : button
  #--------------------------------------------------------------------------
  def Mouse.area?(x, y, width=32, height=32)
    return false if @pos == nil
    return true if @pos[0] >= x and @pos[0] <= (x+width) and @pos[1] >= y and @pos[1] <= (y+height)
    return false
  end
  #--------------------------------------------------------------------------
  # * Mouse Pixel Position
  #--------------------------------------------------------------------------
  def Mouse.pixels
    return @pos == nil ? [0, 0] : @pos
  end
  #--------------------------------------------------------------------------
  # * Mouse Tile Position
  #--------------------------------------------------------------------------
  def Mouse.tiles
    return nil if @pos == nil
    x = @pos[0] / 32
    y = @pos[1] / 32
    return [x, y]
  end
  #--------------------------------------------------------------------------
  # * Set Mouse Position
  #-------------------------------------------------------------------------- 
  def Mouse.set_pos(x_pos=0, y_pos=0)
    width, height = Mouse.client_size
    x_pos, y_pos = Mouse.client_to_screen(x_pos, y_pos)
    if (x_pos.between?(0, width) && y_pos.between?(0, height))
      x = x_pos; y = y_pos
      SET_CURSOR_POS.call(x, y)
    end
  end
  
  def Mouse.set_pos_global(x_pos=0, y_pos=0)
    width, height = Mouse.client_size
    if (x_pos.between?(0, width) && y_pos.between?(0, height))
      #x = Mouse.client_pos[0] + x_pos; y = Mouse.client_pos[1] + y_pos
      SET_CURSOR_POS.call(x_pos, y_pos)
    end
  end
  #--------------------------------------------------------------------------
  # * Mouse Update
  #--------------------------------------------------------------------------
  def Mouse.update
    @pos            = Mouse.pos
    @keys, @press   = [], []
#~     @keys.push(1)   if GET_ASYNC_STATE.call(1) & 0X01 == 1
#~     @keys.push(2)   if GET_ASYNC_STATE.call(2) & 0X01 == 1
#~     @keys.push(3)   if GET_ASYNC_STATE.call(4) & 0X01 == 1
#~     @press.push(1)  if GET_KEY_STATE.call(1) & 0X08000 == 0X08000
#~     @press.push(2)  if GET_KEY_STATE.call(2) & 0X08000 == 0X08000
#~     @press.push(3)  if GET_KEY_STATE.call(4) & 0X08000 == 0X08000

    key1 = GET_ASYNC_STATE.call(1)
    key2 = GET_ASYNC_STATE.call(2)
    key3 = GET_ASYNC_STATE.call(4)
    
    key1b = GET_KEY_STATE.call(1) 
    key2b = GET_KEY_STATE.call(2) 
    key3b = GET_KEY_STATE.call(4) 

    @keys.push(1)   if key1 & 0X01 == 1
    @keys.push(2)   if key2 & 0X01 == 1
    @keys.push(3)   if key3 & 0x01 == 1
    
    @press.push(1)  if key1 & 0X08000 == 0X08000
    @press.push(2)  if key2 & 0X08000 == 0X08000
    @press.push(3)  if key3 & 0X08000 == 0X08000
  end  
  #--------------------------------------------------------------------------
  # * Automatic functions below 
  #--------------------------------------------------------------------------
  #
  #--------------------------------------------------------------------------
  # * Obtain Mouse position in screen
  #--------------------------------------------------------------------------
  def Mouse.global_pos
    pos = [0, 0].pack('ll')
    if GET_CURSOR_POS.call(pos) != 0
      return pos.unpack('ll')
    else
      return nil
    end
  end
  #--------------------------------------------------------------------------
  # * Return Screen mouse position within game window
  #--------------------------------------------------------------------------
  def Mouse.pos
    x, y = Mouse.screen_to_client(*Mouse.global_pos)
    width, height = Mouse.client_size
    begin
      if (x >= 0 and y >= 0 and x < width and y < height)
        return x, y
      else
        return nil
      end
    rescue
      return nil
    end
  end
  #--------------------------------------------------------------------------
  #  * Pass Screen to Game System
  #--------------------------------------------------------------------------
  def Mouse.screen_to_client(x, y)
    return nil unless x and y
    pos = [x, y].pack('ll')
    if SCREEN_TO_CLIENT.call(Mouse.hwnd, pos) != 0
      return pos.unpack('ll')
    else
      return nil
    end
  end
  
  def Mouse.client_to_screen(x, y)
    pos = [x, y].pack('ll')
    if CLIENT_TO_SCREEN.call(Mouse.hwnd, pos) != 0
      return pos.unpack('ll')
    else
      return nil
    end    
  end
  
  #--------------------------------------------------------------------------
  # * Get Screen Window Handle
  #--------------------------------------------------------------------------
  def Mouse.hwnd
    game_name = "\0" * 256
    PVT_PROFILE_STRING.call('Game','Title','',game_name,255,".\\Game.ini")
    game_name.delete!("\0")
    return FIND_WINDOW.call('RGSS Player',game_name)
  end
  #--------------------------------------------------------------------------
  # * Get Game Window Size
  #--------------------------------------------------------------------------
  def Mouse.client_size
    rect = [0, 0, 0, 0].pack('l4')
    GET_CLIENT_RECT.call(Mouse.hwnd, rect)
    right, bottom = rect.unpack('l4')[2..3]
    return right, bottom
  end
  #--------------------------------------------------------------------------
  # * Get Window Position (RGSS Player)
  #--------------------------------------------------------------------------
  def Mouse.client_pos
    rect = [0, 0, 0, 0].pack('l4')
    GET_WINDOW_RECT.call(Mouse.hwnd, rect)
    left, upper = rect.unpack('l4')[0..1]
    return left+4, upper+30
  end
end

module Mouse
  # api calls as constants
  SET_CURSOR_POS = Win32API.new('user32', 'SetCursorPos', 'NN', 'N')
  GET_ASYNC_STATE = Win32API.new("user32","GetAsyncKeyState",['i'],'i')
  GET_KEY_STATE = Win32API.new("user32","GetKeyState",['i'],'i')
  GET_CURSOR_POS = Win32API.new('user32', 'GetCursorPos', 'p', 'i')
  SCREEN_TO_CLIENT = Win32API.new('user32', 'ScreenToClient', %w(l p), 'i')
  CLIENT_TO_SCREEN = Win32API.new('user32', 'ClientToScreen', %w(l p), 'i')
  PVT_PROFILE_STRING = Win32API.new('kernel32', 'GetPrivateProfileStringA', %w(p p p p l p), 'l')
  FIND_WINDOW = Win32API.new('user32', 'FindWindowA', %w(p p), 'l')
  GET_CLIENT_RECT = Win32API.new('user32', 'GetClientRect', %w(l p), 'i')
  GET_WINDOW_RECT = Win32API.new('user32', 'GetWindowRect', %w(l p), 'i')
end  

# Mithran update
module Mouse
  def Mouse.hwnd
    return @hwnd if @hwnd
    game_name = "\0" * 256
    PVT_PROFILE_STRING.call('Game','Title','',game_name,255,".\\Game.ini")
    game_name.delete!("\0")
    return @hwnd ||= FIND_WINDOW.call('RGSS Player',game_name)
  end
end