#===========================================================================#
#  #*****************#              Game Resolution 1.1                     #
#  #*** By Falcao ***#              Add the resolution option to the menu   #
#  #*****************#              RMVXACE Date Aungust 6 2012             #
#===========================================================================#
#---------------------------------------------------------------------------
# This script add a resolution option to the game menu, you can choose from
# Normal screen 544 x 416 and Full screen, also it remember your last option
# when you start the game.
#
# Installation: copy and paste above main
#--------------------------------------------------------------------------
module FalRes
  def self.write_decision
    File.delete("System/Resolution.txt") rescue nil
    File.open("System/Resolution.txt","a+") {|fh|fh.puts($game_resolution)}
  end

  def self.read_decision
    decision = File.read("System/Resolution.txt").split("\n") rescue [0]
    return decision.last.to_i
  end

  def self.resolution
    res = Win32API.new 'user32', 'keybd_event', %w(l l l l), ''
    res.call(18,0,0,0)
    res.call(13,0,0,0)
    res.call(13,0,2,0)
    res.call(18,0,2,0)
  end
  $game_resolution = self.read_decision
  self.resolution if $game_resolution == 1
end
class Window_MenuCommand < Window_Command
  alias falcao_addnew_command add_original_commands
  def add_original_commands
    add_command('Resolution',   :reso, main_commands_enabled)
    falcao_addnew_command
  end
end
class Scene_Menu < Scene_MenuBase
  alias falcao_reso_command create_command_window
  def create_command_window
    falcao_reso_command
    @command_window.set_handler(:reso,     method(:resolution_window))
  end

  def resolution_window
    @commands_reso = Window_ResoCommand.new
    @commands_reso.set_handler(:normal,    method(:reso_selection))
    @commands_reso.set_handler(:full,      method(:reso_selection))
    @commands_reso.set_handler(:cancel,    method(:cancelar))
  end

  def reso_selection
    case @commands_reso.current_symbol
    when :normal
      if $game_resolution == 1
        $game_resolution = 0
        make_resolution
      else
        cancelar ; return
      end
    @commands_reso.activate
    when :full
      if $game_resolution == 0
        $game_resolution = 1
        make_resolution
      else
        cancelar ; return
      end
      @commands_reso.activate
    end
  end

  def make_resolution
    FalRes.resolution
    FalRes.write_decision
  end

  def cancelar
    @commands_reso.dispose
    @commands_reso = nil
    @command_window.activate
  end
end
class Window_ResoCommand < Window_Command
  def initialize
    super(164, 130)
    self.openness = 0
    open
  end
  def window_width
    return 180
  end
  def make_command_list
    add_command('Normal 544x416',     :normal)
    add_command('Full Screen ',       :full)
  end
end