#==============================================================================#
#  #*****************#                                                         #
#  #*** By Falcao ***#          * Falcao Mana Stones Enchants 1.6              #
#  #*****************#          This script allows you to enchants, weapons and#
#                               armors in order to increase the actor stats.   #
#       RMVXACE                                                                #
#                               Date: October 22 2012                          #
#                                                                              #
# Falcao RGSS site:  http://falcaorgss.wordpress.com                           #
# Falcao Forum site: http://makerpalace.com                                    #
#==============================================================================#
# 1.6 change log
# - Fixed crash when mana stones are destroyed before the socketing process
#
# 1.5 change log
# - Added new stand alone GUI
# - Fixed bug when you set the DefaultSockets to cero and unequipp a weapon/armo
# - Mana stones container expanded on more line
#-------------------------------------------------------------------------------
# * Installation
# Copy and paste the script above main, no methods where overwritten so
# compatibility is very hight.
#-------------------------------------------------------------------------------
# * Features
# - Weapons and Armors enchantment enabled
# - Weapons and armors can have as many mana stones slots you want.
# - When soketing the actor stats increase according to especified mana stone
# - Mana stones are created with a simple note tag
# - Chance to Fail the enchantment process
# - If mana stones enchants fail all socketed mana stones are destroyed.
# - A user friendly GUI.
#
# Note: weapons and armors are concidered uniques, so if you have more than one
# weapon of the same id, the mana stones apply to all of them
#
#-------------------------------------------------------------------------------
# * Usage
#
# Mana stones are socketed in the equippment window scene by pressing 'A' key,
# weapon / armor must be equipped in order to start enchanting
#
# Tag weapons and armors with
# <sockets: x>      - Change x for the number of sockets you want
#
# Tag Items with (this items would be the mana stones)
# <mana_mhp: x>
# <mana_mmp: x>
# <mana_atk: x>
# <mana_def: x>       => Change x for the param amount to add
# <mana_mat: x>
# <mana_mdf: x>
# <mana_agi: x>
# <mana_luk: x>
#
# <socket_chance: x>  Change x for the socket chance, it may be a number between
#                     0 and 100. if you dont especified this defaults apply.
#
# Note: the chance is measured from a number between 0 and 100, you cannot
# put a number greater than 100. where 100 = 100% chance, when 0 = 0 %chance
#-------------------------------------------------------------------------------
# * License
# For non-comercial games only, for comercial games contact me:
# falmc99@gmail.com
#-------------------------------------------------------------------------------

module FalMana
  
  # Deafault sockets for weapons and armors, set 0 if you dont want defaults
  DefaultSockets = 1
  
  # Default enchantsment chance (a percent between 0 and 100)
  DefaultChance = 80
  
  # Sound played while socketing mana stones
  SoketingSe = "Heal6"
  
  # Sound played when success socketing
  SocketSuccessSe = "Decision2"
  
  # Sound played when fail socketing
  SocketFailSe = "Down1"
  
  # Sound played when clearing socket
  ClearSocketSe = "Equip3"
  
#-------------------------------------------------------------------------------
  def self.stones(actor)
    @actor = actor
    SceneManager.call(Scene_ManaStones)
  end
  
  def self.actor ; @actor ; end

  def self.socket_manastone(item, index, value, actor)
    item.manaslots[index] = value
    actor.add_param(value.manastone_param[0], value.manastone_param[1])
  end
  
  def self.remove_manastone(item, index, value, actor)
    item.manaslots[index] = nil
    actor.add_param(value.manastone_param[0], - value.manastone_param[1])
  end
  
  def self.clear_manastones(item, actor)
    item.manaslots.each {|m| actor.add_param(m.manastone_param[0],
    - m.manastone_param[1]) unless m.nil?}
    item.manaslots.size.times {|i| item.manaslots[i] = nil}
  end
  
  def self.add_param(actor, item, sub=false)
    return if item.nil?
    return if item.manaslots.nil?
     item.manaslots.each {|m| actor.add_param(m.manastone_param[0],
     sub ? - m.manastone_param[1] : m.manastone_param[1]) unless m.nil?}
  end
end

# Game system: Register mana stones values
class Game_System
  attr_reader   :weapon_slots, :armor_slots
  alias falcaomana_slots_ini initialize
  def initialize
    @weapon_slots = {}
    @armor_slots = {}
    dataslots_ini(@weapon_slots, $data_weapons)
    dataslots_ini(@armor_slots, $data_armors)
    falcaomana_slots_ini
  end
  
  def dataslots_ini(operand, item)
    for kind in item
      next if kind.nil?
      if kind.given_sl != nil
        data = []
        kind.given_sl.times {|i| data.push(nil)}
        operand[kind.id] = data
      end
    end
  end
end

# Scene_Equip: main mana stones socketing system
class Scene_Equip < Scene_MenuBase
  def update
    super
    update_manacalling
  end
  
  def update_manacalling
    update_enchant_help
    if Input.trigger?(:X)
      FalMana.stones(@actor) 
      Sound.play_ok
    end
  end
  
  def update_enchant_help
    @help_window.contents.font.size = Font.default_size
    @help_window.refresh
    @help_window.contents.font.size = 18
    @help_window.draw_text(-22,22,@help_window.width,32, 'Press A to enchant',2)
  end
end

# RPG::EquipItem: get slots data for each weapon and armor
class RPG::EquipItem < RPG::BaseItem
  def given_sl
    @note =~ /<sockets: (.*)>/i ? n = $1.to_i : n = nil
    n = FalMana::DefaultSockets if n.nil? and FalMana::DefaultSockets > 0
    return n 
  end
  
  def manaslots
    self.is_a?(RPG::Weapon) ? i = $game_system.weapon_slots[self.id] :
    i = $game_system.armor_slots[self.id]
    return i
  end
end

# RPG::Item: Mana stones item definition
class RPG::Item < RPG::UsableItem
  def socket_chance
    @note =~ /<socket_chance: (.*)>/i ? n = $1.to_i : n = FalMana::DefaultChance
    return n
  end
  
  def manastone_param
    param = [0, $1.to_i] if @note =~ /<mana_mhp: (.*)>/i
    param = [1, $1.to_i] if @note =~ /<mana_mmp: (.*)>/i
    param = [2, $1.to_i] if @note =~ /<mana_atk: (.*)>/i
    param = [3, $1.to_i] if @note =~ /<mana_def: (.*)>/i
    param = [4, $1.to_i] if @note =~ /<mana_mat: (.*)>/i
    param = [5, $1.to_i] if @note =~ /<mana_mdf: (.*)>/i
    param = [6, $1.to_i] if @note =~ /<mana_agi: (.*)>/i
    param = [7, $1.to_i] if @note =~ /<mana_luk: (.*)>/i
    return param
  end
end

#-------------------------------------------------------------------------------
# Window mana slots
class Window_ItemSlots < Window_Selectable
  def initialize(x=0, y=0, w=280, h=124)
    super(x, y,  w, h)
    unselect
  end
  
  def item()        return @data[self.index] end
  def line_height() return 24                end
  def spacing()     return 6                 end
  def col_max()     return 2                 end
    
  def refresh(object)
    self.contents.clear if self.contents != nil
    @data = []
    return if object.manaslots.nil? rescue return
    object.manaslots.each {|i| @data.push(i)}
    @item_max = @data.size
    if @item_max > 0
      self.contents = Bitmap.new(width - 32, row_max * 26)
      for i in 0...@item_max
        draw_item(i)
      end
    end
  end
 
  def draw_item(index)
    item = @data[index]
    x, y = index % col_max * (129), index / col_max  * 24
    self.contents.font.size = 18
    self.contents.draw_text(x + 2, y - 2, 212, 32, 's:', 0)
    draw_icon(item.icon_index, x, y) rescue nil
    param = Vocab.param(item.manastone_param[0]) rescue nil
    value = item.manastone_param[1] rescue nil
    self.contents.draw_text(x + 24,y,212,32, param + " +#{value}") rescue nil
  end
  
  def item_max
    return @item_max.nil? ? 0 : @item_max 
  end 
end

#-------------------------------------------------------------------------------
# Window mana stones
class Window_ManaStones < Window_Selectable
  def initialize(x=0, y=124, w=280, h=148)
    super(x, y,  w, h)
    refresh ; unselect
  end
  
  def item() return @data[self.index] end
  
  def refresh
    self.contents.clear if self.contents != nil
    @data = []
    for it in $data_items
      next if it.nil?
      @data.push(it) if $game_party.has_item?(it) and !it.manastone_param.nil?
    end
    @item_max = @data.size
    if @item_max > 0
      self.contents = Bitmap.new(width - 32, row_max * 26)
      for i in 0...@item_max
        draw_item(i)
      end
    end
  end
 
  def draw_item(index)
    item = @data[index]
    x, y = index % col_max * (90), index / col_max  * 24
    self.contents.font.size = 18
    draw_icon(item.icon_index, x, y)
    param = Vocab.param(item.manastone_param[0])
    value = item.manastone_param[1]
    number = $game_party.item_number(item)
    contents.draw_text(x + 24,y,212,32, item.name + "  #{param} +#{value}")
    contents.draw_text(x -30, y, self.width, 32, ':' + number.to_s, 2)
  end
  
  def item_max
    return @item_max.nil? ? 0 : @item_max 
  end 
end

class Game_Actor < Game_Battler
  alias falcaomanastones_change change_equip
  def change_equip(slot_id, item)
    FalMana.add_param(self, @equips[slot_id].object, true) 
    FalMana.add_param(self, item) 
    falcaomanastones_change(slot_id, item)
  end
end


#-------------------------------------------------------------------------------
# Window actor equipped
class Window_Equippedwa < Window_Selectable
  def initialize(x=0, y=124)
    super(x, y,  190, 148)
    refresh(FalMana.actor) ; activate ; select(0)
  end
  
  def item() return @data[self.index] end
  
  def refresh(actor)
    self.contents.clear if self.contents != nil
    @data = []
    actor.equips.each {|equips| @data.push(equips) if !equips.nil?}
    @item_max = @data.size
    if @item_max > 0
      self.contents = Bitmap.new(width - 32, row_max * 26)
      for i in 0...@item_max
        draw_item(i)
      end
    end
  end
 
  def draw_item(index)
    item = @data[index]
    x, y = index % col_max * (90), index / col_max  * 24
    self.contents.font.size = 18
    draw_icon(item.icon_index, x, y)
    contents.draw_text(x + 24,y,212,32, item.name)
  end
  
  def item_max
    return @item_max.nil? ? 0 : @item_max 
  end 
end

# Scene mana stones
class Scene_ManaStones < Scene_MenuBase
  def start
    super
    w = Graphics.width ; h = Graphics.height ; @actor = FalMana.actor
    @slot_window = Window_Equippedwa.new(w/2 - 190/2 - 137, h/2 - 148/2 - 106)
    @param_window = Window_Base.new(@slot_window.x,@slot_window.y + 148,190,214)
    refresh_param
    @socket_window = Window_Base.new(w/2 - 280/2 + 97,h/2 - 90/2 - 136, 280, 90)
    @col = [Color.new(180, 225, 245), Color.new(20, 160, 225), Color.new(0,0,0)]
    @itemslots = Window_ItemSlots.new(@socket_window.x, @socket_window.y + 90)
    @manastones = Window_ManaStones.new(@itemslots.x, @itemslots.y + 124)
    @result = '' ; @meter = 0
    update_indexes
  end
  
  def refresh_param
    @param_window.contents.clear
    @param_window.contents.font.size = 18
    @param_window.contents.font.color = @param_window.normal_color
    @param_window.contents.fill_rect(0, 0, 190, 44, Color.new(0, 0, 0, 60))
    @param_window.draw_character(@actor.character_name, 
    @actor.character_index, 20, 42)
    @param_window.draw_text(50, -6, 190, 32, @actor.name)
    @param_window.draw_text(50, 18, 190, 32, 'Equippment')
    y = 0
    for i in 0...8
      y += 17
      @param_window.contents.font.color = @param_window.normal_color
      @param_window.draw_text(0, y + 28, 190, 32, Vocab.param(i))
      @param_window.contents.font.color = @param_window.system_color
      @param_window.draw_text(70, y + 28, 190, 32, "=> #{@actor.param(i)}")
    end
  end
  
  def refresh_socketing
    @socket_window.contents.clear
    @socket_window.contents.font.size = 18
    if @slot_window.item.nil? || @slot_window.item.manaslots.nil?
      @socket_window.draw_text(-16, 0, 280, 32, 'No sockets', 1)
      return
    end
    @socket_window.draw_icon(@slot_window.item.icon_index, 0, 0)
    @socket_window.draw_text(26, 0, @socket_window.width, 32,
    @slot_window.item.name + " sockets: #{@slot_window.item.manaslots.size}")
    @socket_window.draw_text(-20, 44, 280, 32, 'S = clear socket', 2)
    if @meter > 0 and @meter < 100
      x, y = 78, 34
      @socket_window.draw_text(0, 22, 212, 32, 'Socketing:')
      @socket_window.contents.fill_rect(x, y, 152, 12, @col[2])
      @socket_window.contents.fill_rect(x+1, y+1, 150 *@meter / 100, 5, @col[0])
      @socket_window.contents.fill_rect(x+1, y+6, 150 *@meter / 100, 5, @col[1])
    elsif @meter > 100
      @socket_window.draw_text(0, 22, @socket_window.width, 32, @result)
    elsif @meter == 0
      @itemslots.item.nil? ? @result = 'Socket ready' : @result = 'Socket busy'
      @socket_window.draw_text(0, 22, @socket_window.width, 32, @result)
    end
  end

  def terminate
    super
    @itemslots.dispose
    @manastones.dispose
    @socket_window.dispose
    @slot_window.dispose
    @param_window.dispose
  end

  def update
    super
    update_selection       if Input.trigger?(:C)
    update_cancel          if Input.trigger?(:B)
    update_clear_socket    if Input.trigger?(:Y)
    start_socketing
    update_indexes
  end
  
  def update_indexes
    if @equipp_slot != @slot_window.index
      @itemslots.refresh(@slot_window.item)
      refresh_socketing
      @equipp_slot = @slot_window.index
    elsif @slots_index != @itemslots.index and @itemslots.visible
      @slots_index = @itemslots.index
      refresh_socketing
    end
  end
  
  def start_socketing
    return if @soketing.nil?
    @meter += 1 ; refresh_socketing
    if @meter == 100
      r = rand(101)
      r <= @manastones.item.socket_chance ? success_socketing : fail_socketing
    elsif @meter == 200
      @soketing = nil ; @meter = 0 ; @manastones.activate
      refresh_socketing
    end
  end
  
  def update_selection
    return if @meter > 0 || !@itemslots.visible
    if !@itemslots.item.nil? || @slot_window.item.nil? || 
      @slot_window.item.manaslots.nil?
      if !@slot_window.active
        Sound.play_buzzer; return
      elsif @slot_window.active and @slot_window.item.nil?
        Sound.play_buzzer; return
      elsif @slot_window.item.manaslots.nil?
        Sound.play_buzzer; return
      end
    end
    if @slot_window.active and !@itemslots.active
      @itemslots.select(0)
      @itemslots.activate
      @slot_window.deactivate ; Sound.play_ok
    elsif @itemslots.active and !@manastones.active
      @itemslots.deactivate
      @manastones.activate ; @manastones.select(0)
      Sound.play_ok
    elsif @manastones.active and !@manastones.item.nil?
      @manastones.deactivate 
      RPG::SE.new(FalMana::SoketingSe, 80,).play
      @soketing = true
    end
  end
  
  def fail_socketing
    FalMana.clear_manastones(@slot_window.item, @actor)
    @itemslots.refresh(@slot_window.item)
    refresh_param 
    @result = 'Mana stones destroyed!'
    RPG::SE.new(FalMana::SocketFailSe, 80,).play
    destroy_manastone
  end
  
  def success_socketing
    FalMana.socket_manastone(@slot_window.item, @itemslots.index,
    @manastones.item, @actor)
    @itemslots.refresh(@slot_window.item)
    refresh_param 
    @result = 'Socketing successful!'
    RPG::SE.new(FalMana::SocketSuccessSe, 80,).play
    destroy_manastone
  end
  
  def destroy_manastone
    $game_party.lose_item(@manastones.item, 1)
    @manastones.refresh
  end
  
  def update_cancel
    return if @meter > 0
    Sound.play_cancel
    if @slot_window.active
      SceneManager.return
    elsif @itemslots.active
      @slot_window.activate
      @itemslots.unselect
      @itemslots.deactivate
    elsif @manastones.active
      @manastones.unselect ; @manastones.deactivate
      @itemslots.activate
    end
  end
  
  def update_clear_socket 
    return if @itemslots.item.nil? || !@itemslots.active
    RPG::SE.new(FalMana::ClearSocketSe, 80,).play
    FalMana.remove_manastone(@slot_window.item, @itemslots.index,
    @itemslots.item, @actor)
    @itemslots.refresh(@slot_window.item)
    refresh_param
    refresh_socketing
  end
end