#==============================================================================#
#  #*****************#                                                         #
#  #*** By Falcao ***#          * Falcao Map Drop version 1.1                  #
#  #*****************#          This script allow you set events to drop: items#
#                               weapons, armor and gold. everything work with a#
#       RMVXACE                 simple comment tag                             #
#                               Date: Octuber 18 2012                          #
#                               updated March 2013                             #
# Falcao RGSS site:  http://falcaorgss.wordpress.com                           #
# Falcao Forum site: http://makerpalace.com                                    #
#==============================================================================#
 
# March 2013  update change log (1.1 versiom)
# - Reduced cpu consuming by a notable amount

#-------------------------------------------------------------------------------
# * Installation
#
# Copy and paste this script above main, no methods were overwritten so,
# compatibility is very high.
#-------------------------------------------------------------------------------
#
# Instructions:
#
# Tag events as follows
#
# <drop_item: id>    
# <drop_weapon: id>    - Change id for the item id to drop. Ex: <drop_item: 2>
# <drop_armor: id>
# <quantity: x>        - Change x for the quantity of items/weapon/armor to gain
#
# <drop_gold: amount>  - Change amount for gold value Ex: <drop_gold: 25>
#
# Important!
# Events drops only one item/weapon etc. at the time.
# Event start when the player take the drop, so you have the chance to,
# erase the event, activate a self switch or whatever you want.
#-------------------------------------------------------------------------------
# * License
#
# For non-comercial games only, for comercial use please contactme to
# falmc99@gamail.com
#-------------------------------------------------------------------------------
 
module FalMapDrop
 
  # Gold icon index
  GoldIcon = 245
 
end
 
# Spriteset map
class Spriteset_Map
  alias falcao_mapdrop_create_characters create_characters
  def create_characters
    dispose_mapdrop_sprites if !@mapdrop_sprites.nil?
    @mapdrop_sprites = []
    @mapdrop_events = []
    falcao_mapdrop_create_characters
  end
 
  alias falcao_mapdrop_characters_update update_characters
  def update_characters
    update_mapdrop_sprites
    falcao_mapdrop_characters_update
  end
 
  alias falcao_mapdrop_dispose_h dispose
  def dispose
    dispose_mapdrop_sprites
    falcao_mapdrop_dispose_h
  end
 
  def update_mapdrop_sprites
    for event in $game_map.events.values
      kind = nil
      kind = $data_items[event.d_item] if event.d_item != 0
      kind = $data_weapons[event.d_weapon] if event.d_weapon != 0
      kind = $data_armors[event.d_armor] if event.d_armor != 0
      kind = event.d_gold if event.d_gold != 0
      if kind != nil
        unless @mapdrop_events.include?(event)
          sprite = Sprite_MapDrop.new(@viewport1, event, kind)
          @mapdrop_sprites.push(sprite)
          @mapdrop_events.push(event)
        end
      end
    end
    for drop in @mapdrop_sprites
      drop.update
      @mapdrop_sprites.delete(drop) if drop.disposed?
    end
  end
 
  def dispose_mapdrop_sprites
    @mapdrop_sprites.each {|sprite| sprite.dispose }
    @mapdrop_sprites = nil
  end
end
 
# Basic drop sprites
class Sprite_MapDrop < Sprite
  def initialize(viewport, event, item)
    super(viewport)
    @event = event
    @item = item
    n = @event.check_drop("<quantity: ")
    n > 0 ? @num = n : @num = 1
    self.z = @event.screen_z + 1
    @object_zooming = 0
    set_bitmap
    update
  end
 
  def update
    super
    @event.through = true if not @event.through
    self.bush_depth = @event.bush_depth
    @object_zooming += 1
    case @object_zooming
    when 1..8  ; self.zoom_x -= 0.01 ;  self.zoom_y -= 0.01
    when 9..16 ; self.zoom_x += 0.01 ;  self.zoom_y += 0.01
    when 17..24 ; self.zoom_x = 1.0   ;  self.zoom_y = 1.0; @object_zooming = 0
    end
    self.x = @event.screen_x - 12
    self.y = @event.screen_y - 24
    if @event.x == $game_player.x and @event.y == $game_player.y and
      !$game_player.moving?
      if @item.is_a?(Fixnum)
        $game_party.gain_gold(@item)
        RPG::SE.new("Shop", 80).play
      else
        $game_party.gain_item(@item, @num)
        RPG::SE.new("Item1", 80).play
      end
      @event.start
      dispose
    end
  end
 
  def dispose
    self.bitmap.dispose
    self.bitmap = nil
    super
  end
 
  def set_bitmap
    self.bitmap = Bitmap.new(26, 38)
    bitmap = Cache.system("Iconset")
    icon = @item.is_a?(Fixnum) ? FalMapDrop::GoldIcon : @item.icon_index
    rect = Rect.new(icon % 16 * 24, icon / 16 * 24, 24, 24)
    self.bitmap.blt(0, 0, bitmap, rect)
    @item.is_a?(Fixnum) ? n = @item : n = @num
    self.bitmap.font.size = 14
    self.bitmap.draw_text(0, 8, 26, 32, n.to_s, 1)
  end
end
 
# Event tag definition
class Game_Event < Game_Character
  attr_accessor :through
  attr_reader :d_item, :d_weapon, :d_armor, :d_gold
  
  alias falcaodrop_ini initialize
  def initialize(map_id, event)
    @d_item = 0; @d_weapon = 0; @d_armor = 0; @d_gold = 0
    falcaodrop_ini(map_id, event)
  end

  alias falcaodrop_setup_page_settings setup_page_settings
  def setup_page_settings
    falcaodrop_setup_page_settings
    @d_item   = check_drop("<drop_item: ")
    @d_weapon = check_drop("<drop_weapon: ")
    @d_armor  = check_drop("<drop_armor: ")
    @d_gold   = check_drop("<drop_gold: ")
  end

  def check_drop(comment, sw=true)
    return 0 if @list.nil? or @list.size <= 0
    for item in @list
      if item.code == 108 or item.code == 408
        return sw ?$1.to_i : $1.to_s if item.parameters[0] =~ /#{comment}(.*)>/i
      end
    end
    return 0
  end
end