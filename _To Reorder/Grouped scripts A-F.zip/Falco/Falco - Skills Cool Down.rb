#==============================================================================#
#  #*****************#                                                         #
#  #*** By Falcao ***#          * Falcao Skills Cool Down 1.0                  #
#  #*****************#          This script allows you set waiting time to a   #
#                               used skill, so you have to wait x time before  #
#       RMVXACE                 use it again. Date: Octuber 8 2012             #
#                                                                              #
# Falcao RGSS site:  http://falcaorgss.wordpress.com                           #
# Falcao Forum site: http://makerpalace.com                                    #
#==============================================================================#

#-------------------------------------------------------------------------------
# * Installation
# 
# Paste this script above main and below any custom battle system
#-------------------------------------------------------------------------------
# * Features
# 
#- Bring more balance to the game skills system, just imagine you create a
#  really powerful skill that kills all enemies, it dont make sense if you can
#  use that powerful skill over and over again, just put waiting time now.
#- A simple time meter is displayed at the help window showing time left
#-------------------------------------------------------------------------------
# * Usage
#
# It is pretty simple just tag a skill as follows (skill note tags)
#
# <cooldown: x>          Instead x puts cooldown integer, time in seconds    
#-------------------------------------------------------------------------------
# * License
#
# Free to use in any project, but you still need to credit me as creator
#-------------------------------------------------------------------------------

module FalCooldown
  def self.apply_cooldown(skill)
    i = skill.id - 1 ; data = $game_system
    data.cooldown[i] = skill.cooldown * 60 if data.cooldown[i] == 0
  end
end

class Game_System
  attr_accessor :cooldown
  alias falcaocooldown_ini initialize
  def initialize
    @cooldown = []
    $data_skills.size.times do ; @cooldown.push(0) ; end
    falcaocooldown_ini
  end
end

class Window_SkillList < Window_Selectable
  alias falcaocooldown_enable enable?
  def enable?(item)
    return false if !item.nil? and cool_data(item.id) > 0
    falcaocooldown_enable(item)
  end
  
  def update
    @refresh_delay = 0 if @refresh_delay.nil?
    refresh_cooldown(cool_data(item.id)) if !item.nil? and
    cool_data(item.id) > 0
    if @skill_index != self.index
      @skill_index = self.index
      refresh_cooldown(cool_data(item.id)) if !item.nil?
    end
    @refresh_delay -= 1 if @refresh_delay > 0
    refresh if @refresh_delay == 1
    for i in 0...$game_system.cooldown.size
      @refresh_delay = 2 if $game_system.cooldown[i] == 1
    end
    super
  end
  
  def refresh_cooldown(cooldown)
    @help_window.contents.font.size = Font.default_size
    @help_window.refresh
    @help_window.contents.font.size = 20
    cooldown > 0 ? operand = cooldown : operand = item.cooldown * 60
    total_sec = operand / Graphics.frame_rate
    cd = sprintf("%02d:%02d", total_sec / 60, total_sec % 60)
    @help_window.contents.draw_text(-30, 22, @help_window.width, 32,
    "Cooldown: #{cd}", 2)
  end
  
  def cool_data(id)
    value = $game_system.cooldown[id - 1] if $game_system.cooldown[id - 1] > 0
    return value.nil? ? 0 : value
  end
end

class RPG::Skill
  def cooldown
    @note =~ /<cooldown: (.*)>/i ? cd = $1.to_i : cd = 0
    return cd
  end
end

class << Input
  unless self.method_defined?(:falcaocd_update)
    alias_method :falcaocd_update,   :update
  end
  def update
    update_cooldown_global
    falcaocd_update
  end
  def update_cooldown_global
    data = $game_system
    unless data.nil?
      for i in 0...data.cooldown.size
        data.cooldown[i] -= 1 if data.cooldown[i] > 0
      end
    end
  end
end

class Scene_Battle < Scene_Base
  alias falcao_cooldown_use_item use_item
  def use_item
    item = @subject.current_action.item
    FalCooldown.apply_cooldown(item) if item.is_a?(RPG::Skill)
    falcao_cooldown_use_item
  end
end

class Scene_ItemBase < Scene_MenuBase
  alias falcaocd22_use_item use_item
  def use_item 
    FalCooldown.apply_cooldown(item) if item.is_a?(RPG::Skill)
    falcaocd22_use_item
  end
end