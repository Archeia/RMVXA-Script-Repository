#==============================================================================#
#  #*****************#                                                         #
#  #*** By Falcao ***#          * Falcao Pets Servants System 1.3              #
#  #*****************#          This script allow you to have pet servants     #
#                               that perform a avance command system helping   #
#       RMVXACE                 the game player to complete tasks.             #
#                               Date: Octuber 4 2012                           #
#                                                                              #
# Falcao RGSS site:  http://falcaorgss.wordpress.com                           #
# Falcao Forum site: http://makerpalace.com                                    #
#                                                                              #
#==============================================================================#

# 1.3 change log
# - Fixed minor bug when mood overload with other mood commands
# - Added option to enable or disable the followers spot for the pet

#-------------------------------------------------------------------------------
# * Installation
#
# Paste this script above main, no graphics required just copy and paste it into
# your project, 5 item have been created in the database, witch are the gift
# bundle items, if you are using my FA Interactive system 2.0 paste this script
# below it, commons events has been created, to show how to make custom commands
#
#-------------------------------------------------------------------------------
# * Features
#
# - Create as many pets you want at the pet factory below
# - Assigns commands to the pets (you can create as many command you want)
# - Pets level up
# - Pets have a mood bar
# - Pets give a gift bunndle when mood reach the maximun
# - Each pet  give special bonus when is in use
# - A avance command action system is implemented such as
#   pet Steal, pet Grab objects, Pet Trigger targets, Pet Climb etc
# - Pet minder Shop available!
# - You can assign unique commands for each pet
# - Pet are able to: create item, weapons, armor, gold, heal party, increase
#   mood when dancing or playing with pet
# - Custom command system implemented, so you can create your own fully 
#   custamizable commands via common events.
# - Commands cooldown system, that mean you can assigh waiting time to each
#   command available
# - Mouse system buttons support!, you can select targets with the mouse in case
#   you are using my mouse system buttons script
#  
#-------------------------------------------------------------------------------
# * Compatibility
# 
# Despite the complex of this system, i design this script to be compatible with
# any other script, tested with ABS systems, pixel movement system etc
#-------------------------------------------------------------------------------
# * License
#
# For non-comercial games only
# If you need this script for comercial games contact me  falmc99@gmail.com
#-------------------------------------------------------------------------------

#-------------------------------------------------------------------------------
#                            * Game flow usage
#
# Use the following events comments tags to complete pet tasks
#
# /PET TRIGGER             - The event start when touched by the pet, it is
#                            usable with 'Trigger Targets cmd'
# /PET CLIMB               - This make the event as a referencial point for
#                            the command climb
# /PET GRAB                - The event become grab-able for the pet
#
# /PET STEAL ITEM x        - Intead x put the item id you want the pet to steal
#                            from the event. ex: PET STEAL ITEM 1
# /PET STEAL WEAPON x      - Instead x put weapon id you want the pet to steal
#                            from the event. ex: /PET STEAL WEAPON 5
# /PET STEAL ARMOR x       - Instead x put armor id you want the pet to steal
#                            from the event. ex: /PET STEAL ARMOR 3
# /PET STEAL GOLD x        - Instead x put gold amount you want the pet to steal
#                            from the event. ex: /PET STEAL GOLD 35
# /PET STEAL CHANCE 1 / x  - Instead x put the probability to steal any kind
#                            ex: /PET STEAL CHANCE 1 / 3 (chance one of three)
# /IGNORE TARGETING          The tags above use a event target to perform action
#                            this will avoid events on map from being targeted
#
# Important note:
# The pet take only one task from the steal command per event, so if you assign
# steal items, the pet going to steal items nothing else.
#-------------------------------------------------------------------------------
#                       * In-Game script calls
#
# SceneManager.call(Scene_PetShop)      Call the pet minder Shop
# SceneManager.call(Scene_PetCommands)  Call manually the pet command window
#
# $game_player.gamepet.mood_cmd(x)      Instead x put mood command id to add  

# $game_player.adopt_pet(x)             If you dont want to buy pets from the
#                                       shop you can add them manually, instead
#                                       x put pet id from the pet factory
#
# See game demo for details and examples.
#-------------------------------------------------------------------------------

module FalPet
  
#=============================================================================
# * Pets global settings

# Starting Mood Maximun
  StartingMoodMax = 30
  
# After how many gifts the pet level up?
  Growing = 3
  
# Amount added to to the StartingMoodMax value when pet level up
  MoodMaxPlus = 18
  
# The pet give you a gift when level up, define here the level and the gift
# The maximun level will be the maximun gift
# A = pet level   B = Item id
  GiftBundle = {
  
  1 => 17,
  2 => 18,
  3 => 19,
  4 => 20,
  5 => 21,
  
  }
  
# Ballon id showed when the pet play
  BalloonPlaying = 1
 
# Balloon played when pet play dead
  PlayDeadBalloon = 8
 
# BGM played when pet dancing
  DancingBgm = "Town7"
  
# Mood text when pet mood is low
  MoodLowText = 'Feels sad...'
 
# Mood text when pet mood is overage
  MoodOverageText = 'Feels content!'
 
# Mood text when pet mood is medium
  MoodMediumText = 'Loves you!'
 
# Mood text when pet mood is hight
  MoodHight = 'Want pussy!'
  
# Cursor icon index showed when selecting and event target
  CursorIcon = 389
  
# Pet get stacked sometimes when performing action task such as Climb, Grab etc
# after how many stucked times pet give up?
  StuckCount = 15
  
# Buttom to call the pet commands, (W key from the keyboard)
  CommandsKey = :R
  
# Do you want to use the key? you can call the scene commands manually
  UseKey = true
  
# Allow the followers to yiled spot for the pet? change true or false
  YieldSpot = true

#=============================================================================
#                      * Pet Factory
#
# You can create as many pets you want, set the prices, set speciallity skills
# for each pet and give the entire party a bonus when using the pet, 10 pets
# has been created as examples.
#
  
  Pets = {
                                                #-----------------------------#
                                                #           * Sounds          #
                                                #
# Pet Id      Graphic    Index     Name            Voice       Vol     Pitch 
    1   =>  ["Animal",     0,    "Isidoro",       "Dog",       80,     150],
    2   =>  ["Animal",     1,    "Mitcha",        "Cat",       80,     100],
    3   =>  ["Spiritual",  5,    "Navis",         "Ice1",      100,    100],
    4   =>  ["Animal",     3,    "Gordura",       "Coin",      80,     100],
    5   =>  ["Animal",     4,    "Fart Cow",      "Cow",       80,     100],
    6   =>  ["Animal",     5,    "Laziness",      "Horse",     80,     120],
    7   =>  ["Animal",     6,    "Coyote",        "Wolf",     100,     150],
    8   =>  ["Monster3",   5,    "Draconic",      "Monster6",  80,     150],
    9   =>  ["Monster3",   7,    "Spiderpussy",   "Monster3",  80,     150],
    10  =>  ["Monster3",   4,    "Rataliony",     "Miss",      80,     100],
 
  }
  
# Edit the pet prices, this will be the price displayed at the pet shop
  Price = {
  
#   Pet id   Price
     1  =>   10000,
     2  =>   200,
     3  =>   700,
     4  =>   100,
     5  =>   500,
     6  =>   3000,
     7  =>   6000,
     8  =>   8000,
     9  =>   5000,
     10 =>   900,
     
     
  
  }
  
# You can assign especific specialities for each pet, there are 16 commands
# Availables listed below. (listed default ones only, you can create more!)

# 10 = Trigger Targets  14 = Heal Party       18 = Create Gold   22 = Custom4
# 11 = Steal Items      15 = Create Items     19 = Rainsing S    23 = Custom5
# 12 = Grab objects     16 = Create Weapons   20 = Custom2       24 = Custom6
# 13 = Climb            17 = Create Armors    21 = Custom3       25 = Custom7
#
# Each command id going inside the arrays below
  Speciality = {
  
# Pet id    Command Speciality ids
    1  =>  [10, 11, 12, 13, 14, 15, 16, 17, 18],
    2  =>  [16],
    3  =>  [14, 19, 21],
    4  =>  [17],
    5  =>  [15],
    6  =>  [12],
    7  =>  [11],
    8  =>  [10, 20],
    9  =>  [13],
    10 =>  [18],
    
  }
  
  
# Game party guarantee a bonus when using specific pet, each parameters is added
# when the pet is in use, and it is losed when you equip another pet
# This is oriented to the 8 parameters available in game, this make a huge
# diference for each pet. see examples below

  Bonus = {
  
# Pet id                 * Bonus Parameters
    1  => [mhp =  10,   mmp =   0,   atk =   0,  defe =   0,
           mat =   0,   mdf =   0,   agi =   0,  luk  =   0],
          
    2  => [mhp =  20,   mmp =  20,   atk =   2,  defe =  10,
           mat =   1,   mdf =   1,   agi =  10,  luk  =  10],
          
    3  => [mhp = 200,   mmp = 200,   atk =   0,  defe =   20,
           mat =   6,   mdf =   6,   agi =   0,  luk  =   0],
  
    4  => [mhp =   0,   mmp =   0,   atk =  10,  defe =   120,
           mat =   0,   mdf =   0,   agi =   0,  luk  =   0],
          
    5  => [mhp = 100,   mmp =  50,   atk =   0,  defe =   0,
           mat =   0,   mdf =   0,   agi =   0,  luk  =   0],
          
    6  => [mhp =   0,   mmp =   0,   atk =  10,  defe =   0,
           mat =   0,   mdf =   0,   agi =   0,  luk  =  50],
          
    7  => [mhp =   0,   mmp =   0,   atk =   0,  defe =  60,
           mat =   0,   mdf =  11,   agi =  10,  luk  =  10],
  
    8  => [mhp =  60,   mmp =  60,   atk =   9,  defe =   0,
           mat =   0,   mdf =   0,   agi =   0,  luk  =   0],
          
    9  => [mhp =  50,   mmp =  50,   atk =  10,  defe =   0,
           mat =   0,   mdf =   0,   agi =   0,  luk  =   0],
   
    10 => [mhp =   0,   mmp =   0,   atk =   0,  defe =  6,
           mat =   0,   mdf =   0,   agi =  14,  luk  =  11],    
          
  }
  
  
#=============================================================================
#               * Pet Commands configuration
#
# There are 3 types of commands available, Defaults, Mood gain and Speciality
#
#- Defaults commands are the basics and are always available for the pets
#- Moods gain commands are those commands that increase the mood of the pet
#  by performing an act, like playing with pet, dancing atc.
#- Speciality commands give the pet tasks to do, this category breaks into 3
#  sub-categories such, Action, Casting and Custom
#
# Terms explanation
#
# Cmd_Name           - Command name
# Cmd_IconIndex      - Command icon index
# Cmd_Description    - Command short description
# Cmd_CoolDown       - Cool Down is the time you have to wait to use a command
#                      again, time is measured in seconds
# 
# Cmd_MoodGain       - Amount of mood added to the pet when using a mood command
# Cmd_ActionTime     - Time in frames of the command duration (only for custom)
#

#===============================================================================
# * Deafault commands

  # command 1
  Cmd1_Name = 'Toggle Pet'
  Cmd1_IconIndex = 217
  Cmd1_Description = 'Toggle pet on off'
  Cmd1_CoolDown = 0
  
  # command 26
  Cmd26_Name = 'Adopted pets'
  Cmd26_IconIndex = 168
  Cmd26_Description = 'List of adopted pets'
  Cmd26_CoolDown = 0
  
#=============================================================================
# * Mood gain commands (Play commands)
#
# There are 8 default moods commands available listed below 
#
# 2 = Jumpa          4 = Take a breath   6 = Make a twist  8 = Dance
# 3 = Turn around    5 = Chase jump      7 = Play dead     9 = Trampoline
#
# Moods commands are added manually to menu, use the next script calls to add 
# $game_player.gamepet.mood_cmd(id)       id = id of the mood command

# You can also set defaults mood commands, they will be added automatically
  DeafaultMoodCommands = [2]
  
  # command 2
  Cmd2_Name = 'Jumpa'
  Cmd2_IconIndex = 122
  Cmd2_Description = 'Perform jumps showing happiness'
  Cmd2_CoolDown = 8
  Cmd2_MoodGain = 4
  
  # command 3
  Cmd3_Name = 'Turn around'
  Cmd3_IconIndex = 12
  Cmd3_Description = 'Turn around command'
  Cmd3_CoolDown = 20
  Cmd3_MoodGain = 8
  
  # command 4
  Cmd4_Name = 'Take a breath'
  Cmd4_IconIndex = 177
  Cmd4_Description = 'Pet take a big breath'
  Cmd4_CoolDown = 10
  Cmd4_MoodGain = 6
  
  # command 5
  Cmd5_Name = 'Chase jump'
  Cmd5_IconIndex = 176
  Cmd5_Description = 'Jump to his handsome owner'
  Cmd5_CoolDown = 18
  Cmd5_MoodGain = 10
  
  # command 6
  Cmd6_Name = 'Make a twist'
  Cmd6_IconIndex = 103
  Cmd6_Description = 'Play twist'
  Cmd6_CoolDown = 30
  Cmd6_MoodGain = 16
  
  # command 7
  Cmd7_Name = 'Play dead'
  Cmd7_IconIndex = 1
  Cmd7_Description = 'Play dead emote'
  Cmd7_CoolDown = 60
  Cmd7_MoodGain = 22
  
  # command 8
  Cmd8_Name = 'Dance'
  Cmd8_IconIndex = 118
  Cmd8_Description = 'Pet start dancing!'
  Cmd8_CoolDown = 120
  Cmd8_MoodGain = 46
  
  # command 9
  Cmd9_Name = 'Trampoline'
  Cmd9_IconIndex = 119
  Cmd9_Description = 'Start making a trampoline!'
  Cmd9_CoolDown = 120
  Cmd9_MoodGain = 36
  
#=============================================================================
# * Pet speciality commands configurations
#=============================================================================
# * Action commands
  
  # command 10
  Cmd10_Name = 'Trigger Targets'
  Cmd10_IconIndex = 398
  Cmd10_Description = 'Command the Pet to trigger selected targets'
  Cmd10_CoolDown = 0
  
  # command 11
  Cmd11_Name = 'Steal items'
  Cmd11_IconIndex = 9
  Cmd11_Description = 'Command the pet to steal items and money'
  Cmd11_CoolDown = 0
  
  # command 12
  Cmd12_Name = 'Grab objects'
  Cmd12_IconIndex = 491
  Cmd12_Description = 'Command the pet to grab selected objects'
  Cmd12_CoolDown = 0
  
  # command 13
  Cmd13_Name = 'Climb'
  Cmd13_IconIndex = 275
  Cmd13_Description = 'Command the pet to help the owner to climb'
  Cmd13_CoolDown = 0
  
#=============================================================================
# * Casting commands
  
  # command 14
  Cmd14_Name = 'Heal Party'
  Cmd14_IconIndex = 14
  Cmd14_Description = 'Heal hp and mp for a fixed percentage'
  Cmd14_CoolDown = 60
  
  # This casting command heals your entire party by a percentage, there are four
  # available: '25%'  '50%'   '75%'  '100%'
  HealPercent = '75%'
#---------------------

  # command 15
  Cmd15_Name = 'Create Items'
  Cmd15_IconIndex = 213
  Cmd15_Description = 'Create random items for the owner party'
  Cmd15_CoolDown = 120
  
  # Animation played when pet is creating items
  ItemAnime = 107
  
  # This command give you random items, add the participants items below
  # A => B     A = Item id    B = Quantity
  RandomItems = {
  
  1 =>  10,
  2 =>  25,
  6 =>  35,
  
  }
#-----------------------

  # command 16
  Cmd16_Name = 'Create Weapons'
  Cmd16_IconIndex = 402
  Cmd16_Description = 'Create random weapons for the owner party'
  Cmd16_CoolDown = 240
  
  # Animation played when pet is creating weapons
  WeaponAnime = 107
  
  # This command give you random weapons, add the participants weapons below
  # A => B     A = Weapon id    B = Quantity
  RandomWeapons = {
  
  1 => 11,
  2 => 2,
  6 => 7,
  
  }
#-------------------------
  
  # command 17
  Cmd17_Name = 'Create Armors'
  Cmd17_IconIndex = 170
  Cmd17_Description = 'Create random armors for the owner party'
  Cmd17_CoolDown = 300
  
  # Animation played when pet is creating armors
  ArmorAnime = 107
  
  # This command give you random armors, add the participants armors below
  # A => B     A = Armor id    B = Quantity
  RandomArmors = {
  
  1 => 17,
  2 => 2,
  6 => 8,
  
  }
#--------------------------
  # command 18
  Cmd18_Name = 'Create Gold'
  Cmd18_IconIndex = 344
  Cmd18_Description = 'Create random Gold for the owner party'
  Cmd18_CoolDown = 180
  
  # Animation played when pet is creating gold
  GoldAnime = 107
  
  # This command give you random gold, add the gold amount partisipant
  # Random gold amount go inside the array
  RandomGold = [100, 25, 77, 45, 88]
  
  
#--------------------------
  # command 19
  Cmd19_Name = 'Raising Spirit'
  Cmd19_IconIndex = 112
  Cmd19_Description = 'For short time cool down become instant!'
  Cmd19_CoolDown = 600
  
  # Instant cool down buff duration in seconds
  BuffDuration = 60
  
#=============================================================================
# * Custom commands
#
# Custom commands are designed to work via common events, a switch is activated
# when the command time is running and it is deactivated when time ends.
# So the common event should be parallel process as condition the switch
# assigned below
  
  # Switch id that remains active when a custom command is running
  CustomSwitch = 100
  
# List of special tasks you can give the pet inside the common event
# when a custom command is running
# 
# * Basics
#
# pet                  Get currently using pet
# pet.cmd(id)          Get pet command (change id for command id integer)
# pet.time?(x)         Get current command action time (change x for an integer)
# pet.level            Get currently pet level
# pet.ending?          Check if action time command is about to finish
#
# * Actions
#
# pet.prepare          Player and pet turn face to face   
# pet.liedown          Pet lie down                 
# pet.reset_liedown    Pet stand up
# pet.cast             Pet make a casting position
# pet.jump_high(x,y,h) Jump higher than normal, chan x,y,h for an integer
# pet.play_voice       Play the pet voice
# pet.pop_mood         Pet start gaining the custom command mood assigned
# pet.pop_text(t,time) Pet start poping a window with custom text, change
#                      t for 'text to display' and time for time in seconds
# pet.zoom(x, y)       Pet start zooming, change x,y for desire integers,  
#                      zoom support decimals.
# pet.reset_zoom       Reset zoom to normal size         
#
# Those are just special commands for the pet, since the pet is a character
# he can use any command from the move route such as, move_up, 
# animation_id, balloon_id, move_away_from_player etc.
  
  # command 20
  Cmd20_Name = 'Sleep'
  Cmd20_IconIndex = 6
  Cmd20_Description = 'Start sleeping'
  Cmd20_CoolDown = 40
  Cmd20_MoodGain = 12
  Cmd20_ActionTime = 300
  Cmd20_Type = 'Mood +'
  
  # command 21
  Cmd21_Name = 'Iron Body'
  Cmd21_IconIndex = 13
  Cmd21_Description = 'Cast a magic shield'
  Cmd21_CoolDown = 120
  Cmd21_MoodGain = 0
  Cmd21_ActionTime = 200
  Cmd21_Type = 'Casting'
  
  # command 22
  Cmd22_Name = 'Command name'
  Cmd22_IconIndex = 344
  Cmd22_Description = 'Any description'
  Cmd22_CoolDown = 5
  Cmd22_MoodGain = 0
  Cmd22_ActionTime = 200
  Cmd22_Type = ''
  
  # command 23
  Cmd23_Name = 'Command name'
  Cmd23_IconIndex = 344
  Cmd23_Description = 'Any description'
  Cmd23_CoolDown = 5
  Cmd23_MoodGain = 0
  Cmd23_ActionTime = 200
  Cmd23_Type = ''
  
  # command 24
  Cmd24_Name = 'Command name'
  Cmd24_IconIndex = 344
  Cmd24_Description = 'Any description'
  Cmd24_CoolDown = 5
  Cmd24_MoodGain = 0
  Cmd24_ActionTime = 200
  Cmd24_Type = ''
  
  # command 25
  Cmd25_Name = 'Command name'
  Cmd25_IconIndex = 344
  Cmd25_Description = 'Any description'
  Cmd25_CoolDown = 5
  Cmd25_MoodGain = 0
  Cmd25_ActionTime = 200
  Cmd25_Type = ''
  
  #-----------------------------------------------------------------------------
  # * Commands database
  Commands = {
  
  1 =>  [Cmd1_Name,   c = 1, ii = Cmd1_IconIndex,  t = 0,   tg = false, nil, 
         Cmd1_Description, Cmd1_CoolDown, 0, ty = 'Triggering'],
  2 =>  [Cmd2_Name,  c = 2, Cmd2_IconIndex,      t = 160, tg = false, nil,
         Cmd2_Description, Cmd2_CoolDown, Cmd2_MoodGain, ty = 'Mood +'],
  3 =>  [Cmd3_Name, c = 3, Cmd3_IconIndex, t = 160, tg = false, nil,
         Cmd3_Description, Cmd3_CoolDown, Cmd3_MoodGain, ty = 'Mood +'],
  4 =>  [Cmd4_Name,      c = 4, ii = Cmd4_IconIndex,  t = 160, tg = false, nil,
         Cmd4_Description, Cmd4_CoolDown, Cmd4_MoodGain, ty = 'Mood +'],
  5 =>  [Cmd5_Name,      c = 5, Cmd5_IconIndex,  t = 160, tg = false, nil,
         Cmd5_Description, Cmd5_CoolDown, Cmd5_MoodGain, ty = 'Mood +'],
  6 =>  [Cmd6_Name,      c = 6, Cmd6_IconIndex,  t = 200, tg = false, nil,
         Cmd6_Description, Cmd6_CoolDown, Cmd6_MoodGain, ty = 'Mood +'],
  7 =>  [Cmd7_Name,      c = 7, Cmd7_IconIndex,  t = 500, tg = false, nil,
         Cmd7_Description, Cmd7_CoolDown, Cmd7_MoodGain, ty = 'Mood +'],
  8 =>  [Cmd8_Name,      c = 8, Cmd8_IconIndex,  t = 500, tg = false, nil,
         Cmd8_Description, Cmd8_CoolDown, Cmd8_MoodGain, ty = 'Mood +'],
  9 =>  [Cmd9_Name,      c = 9, Cmd9_IconIndex,  t = 400, tg = false, nil,
         Cmd9_Description, Cmd9_CoolDown, Cmd9_MoodGain, ty = 'Mood +'],
  #----------------------- # Actions 
  10 => [Cmd10_Name,    c = 10,  Cmd10_IconIndex, t = 0,   tg = true, nil,
         Cmd10_Description, Cmd10_CoolDown, 0, ty = 'Action'],
  11 => [Cmd11_Name,    c = 11,  Cmd11_IconIndex, t = 0,   tg = true, nil,
         Cmd11_Description, Cmd11_CoolDown, 0, ty = 'Action'],
  12 => [Cmd12_Name,    c = 12,  Cmd12_IconIndex, t = 0,   tg = true, nil,
         Cmd12_Description, Cmd12_CoolDown, 0, ty = 'Action'],
  13 => [Cmd13_Name,    c = 13,  Cmd13_IconIndex, t = 0,   tg = true, nil,
         Cmd13_Description, Cmd13_CoolDown, 0, ty = 'Action'],
  #-------------------- casting commands
  14 => [Cmd14_Name,    c = 14,  Cmd14_IconIndex, t = 300,   tg = false, nil,
         Cmd14_Description, Cmd14_CoolDown, 0, ty = 'Casting'],
  15 => [Cmd15_Name,    c = 15,  Cmd15_IconIndex, t = 200,   tg = false, nil,
         Cmd15_Description, Cmd15_CoolDown, 0, ty = 'Casting'],
  16 => [Cmd16_Name,    c = 16,  Cmd16_IconIndex, t = 200,   tg = false, nil,
         Cmd16_Description, Cmd16_CoolDown, 0, ty = 'Casting'],
  17 => [Cmd17_Name,    c = 17,  Cmd17_IconIndex, t = 200,   tg = false, nil,
         Cmd17_Description, Cmd17_CoolDown, 0, ty = 'Casting'],
  18 => [Cmd18_Name,    c = 18,  Cmd18_IconIndex, t = 200,   tg = false, nil,
         Cmd18_Description, Cmd18_CoolDown, 0, ty = 'Casting'],
  19 => [Cmd19_Name,    c = 19,  Cmd19_IconIndex, t = 200,   tg = false, nil,
         Cmd19_Description, Cmd19_CoolDown, 0, ty = 'Casting'],
         
  #----------------------- custom commands       
  20 => [Cmd20_Name, c = 20, Cmd20_IconIndex, Cmd20_ActionTime, tg = false, nil,
         Cmd20_Description, Cmd20_CoolDown, Cmd20_MoodGain, Cmd20_Type],
  21 => [Cmd21_Name, c = 21, Cmd21_IconIndex, Cmd21_ActionTime, tg = false, nil,
         Cmd21_Description, Cmd21_CoolDown, Cmd21_MoodGain, Cmd21_Type],
  22 => [Cmd22_Name, c = 22, Cmd22_IconIndex, Cmd22_ActionTime, tg = false, nil,
         Cmd22_Description, Cmd22_CoolDown, Cmd22_MoodGain, Cmd22_Type],
  23 => [Cmd23_Name, c = 23, Cmd23_IconIndex, Cmd23_ActionTime, tg = false, nil,
         Cmd23_Description, Cmd23_CoolDown, Cmd23_MoodGain, Cmd23_Type],
  24 => [Cmd24_Name, c = 24, Cmd24_IconIndex, Cmd24_ActionTime, tg = false, nil,
         Cmd24_Description, Cmd24_CoolDown, Cmd24_MoodGain, Cmd24_Type],
  25 => [Cmd25_Name, c = 25, Cmd25_IconIndex, Cmd25_ActionTime, tg = false, nil,
         Cmd25_Description, Cmd25_CoolDown, Cmd25_MoodGain, Cmd25_Type],
  #--------------------------------------------------------------
  26 => [Cmd26_Name,    c = 26,  Cmd26_IconIndex, t = 0,   tg = false, s = true,
         Cmd26_Description, Cmd26_CoolDown, 0, ty = 'Listing'],
         
  #----this is the command return, this is not listed, it cannot be changed
  27 => [nil, nil, nil, nil, nil, nil,
         nil, nil, nil, nil],
         
  #-----------------------------------------------------------------------------
  # Need more custom commands? you can create as many custom commands you need
  # the next command on database would be 28, see examples below
  #  28 => ['name', id, icon_index, action_time, target, nil,
  #          'Description', Cool down, mood gainig, type],
  #
  #  So the command should be as follows
  #
  # 28 => ['Any name', id = 28, icon = 19, action_time = 200, false, nil,
  #        'Any description', cooldown = 5, mood_gain = 0, type = 'Any type'],
  #
  #
  # Do not change the values  "false, nil" from the commands data, they are
  # defaults for the action commands.
  #-----------------------------------------------------------------------------
  # * Start creating new custom commands here
 
  
  
  }
  
end


#-------------------------------------------------------------------------------
# Game Pet class

class Game_Pet < Game_Character
  include FalPet
  attr_accessor :command, :stucked, :lastspot, :action_time, :short_jump
  attr_accessor :chase_event_id, :mood, :cooldown, :unlock_command,:reservedmood
  attr_accessor :pet_level, :grow_inflation, :lvup_pop, :stealed_item, :pet_id
  attr_accessor :character_name, :character_index, :petname, :sounds, :casting
  attr_accessor :randomitem, :custom_mode, :stuck_count, :instantcd, :through
  def initialize
    super
    @pet_id = 0
    @priority_type = 1
    @mood = 0
    @pet_level = 1
    @cooldown = []
    FalPet::Commands.keys.size.times do ; @cooldown.push(0) ; end
    @unlock_command = DeafaultMoodCommands
    @grow_inflation = [StartingMoodMax, grow = 0, GiftBundle.max_by{|k,v| v}[0]]
    @lvup_pop = false
    @instantcd = 0
    @reservedmood = 0
    reset_pet
  end
  
  def reset_pet
    @command = 0
    @stucked = 0
    @action_time = 0
    @short_jump = false
    @lastspot = nil
    @casting = false
    @custom_mode = nil
    @stuck_count = 0
    @through = true
    $game_switches[CustomSwitch] = false if $game_switches[CustomSwitch]
  end
  
  # set up
  def setup_pet(id)
    get_bonus(@pet_id, sub = true) if @pet_id > 0
    @pet_id = id
    set = Pets[@pet_id]
    @character_name = set[0]
    @character_index = set[1]
    @petname = set[2]
    @sounds = [set[3], set[4], set[5]]
    @balloon_id = 1 if SceneManager.scene_is?(Scene_Map)
    play_voice
    get_bonus(@pet_id)
  end
  
  def get_bonus(id, sub=false)
    set = Bonus[id]
    for member in $game_party.members
      for i in 0...8
        sub ? member.add_param(i, -set[i]) : member.add_param(i, set[i])
      end
    end
  end
  
  def play_voice
    RPG::SE.new(@sounds[0],@sounds[1],@sounds[2]).play
  end
  
  def busy?
    @command > 0
  end
  
  def custom_command?
    return true if @command.between?(20, 25)
    return true if @command.between?(28, FalPet::Commands.keys.size)
    return false
  end
  
  def time?(t)
    t == @action_time
  end
  
  def prepare
    $game_player.prepare_petact
  end
  
  def pop_text(text, time)
    $game_player.gamepet.custom_mode = text
    $game_player.petpop_time = time * 60
  end
  
  def pop_mood
    $game_player.start_poping_window(1, 3)
  end
  
  def level
    return @pet_level
  end
  
  def cast
    @casting = true
  end
  
  def ending?
    @action_time == 2
  end
  
  def cmd?(c)
    c == @command
  end
  
  def play_balloon
    @balloon_id = BalloonPlaying
  end
  
  def zoom(x, y)
    @zoomfx_x = x
    @zoomfx_y = y
  end
  
  def reset_zoom
    @zoomfx_x = 1.0
    @zoomfx_y = 1.0
  end
  
  def gain_mood(n)
    @mood = [[@mood + n, 0].max, @grow_inflation[0]].min
  end
  
  def gain_level(n)
    @pet_level = [[@pet_level + n, 0].max, @grow_inflation[2]].min
  end
  
  def mood_full?
    @mood == @grow_inflation[0]
  end
  
  # apply pet growing
  def apply_growing
    @grow_inflation[1] += 1
    if @grow_inflation[1] == Growing
      if @pet_level != @grow_inflation[2]
        @grow_inflation[0] = @grow_inflation[0] + MoodMaxPlus
        gain_level(1)
        @lvup_pop = true
      end
      @grow_inflation[1] = 0
    end
  end
  
  def twist(value, m)
    set_direction(2) if @action_time == value
    set_direction(4) if @action_time == value - m
    set_direction(6) if @action_time == value - m - m
    set_direction(8) if @action_time == value - m - m - m
  end
  
  def mood_cmd(id)
    return unless id.between?(2, 9)
    @unlock_command.push(id) unless @unlock_command.include?(id)
  end
  
  # gift item
  def mood_item
    FalPet::GiftBundle.each do |level, item_id|
      if level == @pet_level
        item = $data_items[item_id]
        return item if !item.nil?
      end
    end
    return $data_items[1]
  end
  
  # radom items
  def get_randomitem(type, variable)
    case type
    when 'item'   ; operand = $data_items
    when 'weapon' ; operand = $data_weapons
    when 'armor'  ; operand = $data_armors
    when 'gold'   ; operand = nil
    end
    if operand != nil
      data = []
      variable.each {|id, value|  data.push([id, value])}
      item = data[rand(data.size)]
      @randomitem = [operand[item[0]], item[1]]
    else
      gold = variable[rand(variable.size)]
      @randomitem = [gold]
    end
  end

  def update
    @pattern = 0 if @casting 
    @move_speed = $game_player.real_move_speed if !busy?
    if custom_command?
      $game_switches[CustomSwitch] = true if !$game_switches[CustomSwitch]
    end
    for event in $game_map.events.values
      if event.check_evcom("/PET GRAB")
        event.priority_type = 1 if event.priority_type != 1
      end
    end
    super
  end
  
  def cast_item_producing(anime, ct=false)
    case @action_time
    when 180 ; jump_high(0, 0, 16) ; @casting = true
    when 160 ; ct ? $game_player.animation_id = anime : @animation_id = anime
    when 6   ; play_balloon ; play_voice
    when 1   ; RPG::SE.new("Item3",80).play if !ct
    ct ? $game_player.start_poping_window(13, 2) :
    $game_player.start_poping_window(11, 3)
    end
  end
  
  def update_anime_pattern
    @casting ? return : super
  end
end

#-------------------------------------------------------------------------------
# * Character base new methods and variabbles

class Game_CharacterBase
  attr_accessor :x, :y, :direction, :priority_type, :pattern, :through
  attr_accessor :step_anime, :direction_fix, :move_speed, :egrabbing
  attr_accessor :zoomfx_x
  attr_accessor :zoomfx_y
  attr_accessor :anglefx
  
  alias falcao_zoomfx_ini initialize
  def initialize
    @zoomfx_x = 1.0
    @zoomfx_y = 1.0
    @anglefx = 0.0
    @layingdown = false
    falcao_zoomfx_ini
  end
  
  def liedown
    set_direction(8)
    @anglefx = 100
    @layingdown = true
  end
  
  def reset_liedown
    @anglefx = 0.0
    @layingdown = false
  end
  
  def move_toward_char(character)
    sx = distance_x_from(character.x)
    sy = distance_y_from(character.y)
    if sx != 0 && sy != 0
      move_diagonal(sx > 0 ? 4 : 6, sy > 0 ? 8 : 2)
    elsif sx != 0
      move_straight(sx > 0 ? 4 : 6)
    elsif sy != 0
      move_straight(sy > 0 ? 8 : 2)
    end
  end
  
  # jump to specific tiles
  def jumpto_tile(x, y)
    jumpto(0, [x, y])
  end
  
  # jumpto character ( 0 = Game Player, 1 and up event id)
  def jumpto(char_id, tilexy=nil)
    char_id > 0 ? char = $game_map.events[char_id] : char = $game_player
    tilexy.nil? ? condxy = [char.x, char.y] : condxy = [tilexy[0], tilexy[1]]
    jx = + eval_distance(tilexy.nil? ? char : tilexy)[0] if condxy[0] >= @x
    jy = - eval_distance(tilexy.nil? ? char : tilexy)[1] if condxy[1] <= @y
    jx = - eval_distance(tilexy.nil? ? char : tilexy)[0] if condxy[0] <= @x
    jy = - eval_distance(tilexy.nil? ? char : tilexy)[1] if condxy[1] <= @y
    jx = - eval_distance(tilexy.nil? ? char : tilexy)[0] if condxy[0] <= @x
    jy = + eval_distance(tilexy.nil? ? char : tilexy)[1] if condxy[1] >= @y
    jx = + eval_distance(tilexy.nil? ? char : tilexy)[0] if condxy[0] >= @x
    jy = + eval_distance(tilexy.nil? ? char : tilexy)[1] if condxy[1] >= @y
    jump(jx, jy)
  end
  
  def eval_distance(target)
    if target.is_a?(Array)
      distance_x = (@x - target[0]).abs
      distance_y = (@y - target[1]).abs
    else
      distance_x = (@x - target.x).abs
      distance_y = (@y - target.y).abs
    end
    return [distance_x, distance_y] 
  end
  
  # climb area
  def climb_area?(target, size)
    distance = (@x - target.x).abs + (@y - target.y).abs
    enable   = (distance <= size-1)
    return true if enable
    return false
  end
  
  # controlled jump x, y , height
  def jump_high(x_plus, y_plus, heigh)
    if x_plus.abs > y_plus.abs
      set_direction(x_plus < 0 ? 4 : 6) if x_plus != 0
    else
      set_direction(y_plus < 0 ? 8 : 2) if y_plus != 0
    end
    @x += x_plus
    @y += y_plus
    distance = Math.sqrt(x_plus * x_plus + y_plus * y_plus).round
    @jump_peak = heigh + distance - @move_speed
    @jump_count = @jump_peak * 2
    @stop_count = 0
    straighten ; @priority_type = 2
  end
  
  def samepos?(target)
    @x == target.x and @y == target.y
  end
  
  # get distance passable tile_x and tile_y
  def tiles_pass
    dir = @direction
    operand = 17 if dir == 4 || dir == 6
    operand = 13 if dir == 2 || dir == 8
    for i in 1...operand
      return [@x, @y + i] if dir == 2 and $game_map.passable?(@x, @y + i, dir)
      return [@x, @y - i] if dir == 8 and $game_map.passable?(@x, @y - i, dir) 
      return [@x - i, @y] if dir == 4 and $game_map.passable?(@x - i, @y, dir)  
      return [@x + i, @y] if dir == 6 and $game_map.passable?(@x + i, @y, dir)  
    end
    return nil
  end
  
  def adjustpxy
    push_x, push_y =   0,   1 if @direction == 2
    push_x, push_y = - 1,   0 if @direction == 4
    push_x, push_y =   1,   0 if @direction == 6
    push_x, push_y =   0, - 1 if @direction == 8
    return [push_x, push_y]
  end
  
end

#-------------------------------------------------------------------------------
# * Game player new methods and variabbles

class Game_Player < Game_Character
  attr_reader   :gamepet
  attr_reader   :showing_pet
  attr_accessor :petpop_time
  attr_accessor :petpop_refresh
  attr_accessor :petpop_type
  attr_accessor :adopted_pets
  attr_accessor :just_jumped
  alias falcao_pet_ini initialize
  def initialize
    @gamepet = Game_Pet.new
    @showing_pet = false
    @petpop_refresh = false
    @petpop_time = 0
    @petpop_type = 0
    @climb_wait = 0
    @adopted_pets = []
    @just_jumped = false
    falcao_pet_ini
  end
  
  alias falcao_pet_main_update update
  def update
    update_gamepet
    falcao_pet_main_update
  end
  
  def adopt_pet(id)
    @adopted_pets.include?(id) ? return :  @adopted_pets.push(id)
    @gamepet.setup_pet(id)
    @showing_pet = true
  end
  
  def have_pet?
    !@adopted_pets.empty?
  end
  
  def update_gamepet
    return unless have_pet?
    
    if @gamepet.action_time > 0
      @gamepet.action_time -= 1
      globalpet_reset if @gamepet.action_time == 0
    end
    @petpop_time -= 1 if @petpop_time > 0
    @climb_wait -= 1 if @climb_wait > 0
    @gamepet.update if @showing_pet 
    update_path_manager
    update_call_commands
    case @gamepet.command
    when 1
      update_command_showhide
    when 2..9
      update_command_play
    when 10
      update_command_startevet(@gamepet.chase_event_id)
    when 11
      update_command_steal(@gamepet.chase_event_id)
    when 12
      update_command_grab(@gamepet.chase_event_id)
    when 13
      update_command_climb(@gamepet.chase_event_id)
    when 14
      update_command_heal
    when 15
      update_command_randomitems
    when 16
      update_command_randomweapons
    when 17
      update_command_randomarmors
    when 18
      update_command_randomgold
    when 19
      update_command_instantcd
    when 27
      update_command_return
    end
    update_poppetwindow
  end
  
  def update_call_commands
    return unless FalPet::UseKey
    SceneManager.call(Scene_PetCommands) if Input.trigger?(FalPet::CommandsKey)
  end
  
  # command return
  def update_command_return
    @gamepet.move_toward_character(self) unless @gamepet.moving?
    globalpet_reset if @gamepet.x == @x and @gamepet.y == @y
  end
  
  # path manager
  def update_path_manager
    return unless @gamepet.command == 27 || @gamepet.command.between?(10, 13)
    @gamepet.stucked += 1 if not @gamepet.moving?
    @gamepet.stucked = 0 if @gamepet.moving? 
    @gamepet.stucked = 0 if @climb_wait > 0 and !@gamepet.moving? 
    if @gamepet.stuck_count >= FalPet::StuckCount
      @gamepet.command = 27
      @gamepet.stuck_count = 0
      start_poping_window(12, 3)
    end
    #------------------------------------------
    if @gamepet.stucked == 45
      if @gamepet.command == 27
        event = $game_map.events[@gamepet.chase_event_id] rescue nil
        @gamepet.turn_toward_character(self)
        if @gamepet.tiles_pass != nil
          tilex, tiley = @gamepet.tiles_pass[0], @gamepet.tiles_pass[1]
          @gamepet.jumpto_tile(tilex, tiley)
          event.jumpto_tile(tilex,tiley) if !event.nil? && !event.egrabbing.nil?
        else
          @gamepet.jumpto(0)
          event.jumpto(0) if !event.nil? and !event.egrabbing.nil?
        end
      
        # command activate / steal / grab / climb
      elsif @gamepet.command.between?(10, 13)
        event = $game_map.events[@gamepet.chase_event_id] 
        @gamepet.turn_toward_character(event)
        if @gamepet.tiles_pass != nil
          if @gamepet.climb_area?(event, 3)
            @gamepet.jumpto(@gamepet.chase_event_id)
            return
          end
          @gamepet.jumpto_tile(@gamepet.tiles_pass[0], @gamepet.tiles_pass[1])
        else
          @gamepet.jumpto(@gamepet.chase_event_id)
        end
      end
      @gamepet.stucked = 0
      @gamepet.stuck_count += 1
    end
  end
  
  def start_poping_window(type, time, seconds=true)
    @petpop_type = type
    seconds ? @petpop_time = time * 60 : @petpop_time = time
  end
  
  # comand showhide
  def update_command_showhide
    # hide
    if @showing_pet
      @gamepet.balloon_id = 1
      unless @gamepet.jumping?
        @showing_pet = false
        @gamepet.reset_pet
      end
      # show
    else
      @gamepet.balloon_id = 4
      @showing_pet = true
      @gamepet.reset_pet
    end
  end
  
  # play with pet
  def update_command_play
    prepare_petact
    time = @gamepet.action_time
    case @gamepet.command
    when 2 # jump jump
      @gamepet.jump(0,0) if time == 130
      @gamepet.jump(0,0) if time == 100
      @gamepet.jump(0,0) if time == 70
      @gamepet.play_balloon if time == 40
      @gamepet.play_voice  if time == 20
      
    when 3 # tun r around
      @gamepet.jump(0,0) if time == 130
      @gamepet.twist(100, 10)
      @gamepet.turn_toward_character(self) if time == 50
      @gamepet.play_balloon if time == 30
      @gamepet.play_voice if time == 20
      
    when 4 # zoom
      if time > 90 and time < 130
        @gamepet.zoomfx_x += 0.02
        @gamepet.zoomfx_y += 0.02
      elsif time > 30 and time < 70
        @gamepet.zoomfx_x -= 0.02
        @gamepet.zoomfx_y -= 0.02
      end
      @gamepet.play_balloon if time == 30
      @gamepet.play_voice if time == 20
      
    when 5 #chase jump 
      if time == 130
        @gamepet.lastspot = [@gamepet.x, @gamepet.y]
        @gamepet.jumpto(0)
      elsif time == 90
        @gamepet.jumpto_tile(@gamepet.lastspot[0], @gamepet.lastspot[1])
      end
      @gamepet.move_forward if time == 70
      @gamepet.turn_toward_character(self) if time == 50
      @gamepet.move_forward if time == 10
      @gamepet.play_balloon if time == 30
      @gamepet.play_voice if time == 20
      
    when 6 # twist
      @gamepet.move_away_from_player if time == 170
      @gamepet.turn_toward_character(self) if time == 150
      @gamepet.twist(140, 5) ; @gamepet.twist(120, 5)
      @gamepet.twist(100, 5) ; @gamepet.twist(80, 5)
      @gamepet.twist(60, 5)  ; @gamepet.twist(40, 10)
      @gamepet.play_balloon if time == 20
      @gamepet.play_voice if time == 10
      @gamepet.jump(0,0) if time == 10
      @gamepet.turn_toward_character(self) if time == 10
      
    when 7 # play dead
      @gamepet.move_away_from_player if time == 470
      @gamepet.turn_toward_character(self) if time == 450
      @gamepet.balloon_id = FalPet::PlayDeadBalloon if  time == 400
      @gamepet.liedown if time == 430
      @gamepet.play_balloon if time == 20
      @gamepet.play_voice if time == 10
      @gamepet.turn_toward_character(self) if time == 10
      
    when 8 # dance
      RPG::BGM.fade(1 * 1000) if time == 590
      @gamepet.move_away_from_player if time == 470
      @gamepet.turn_toward_character(self) if time == 450
      if time == 410
        $game_system.save_bgm
        RPG::BGM.new(FalPet::DancingBgm,80).play 
        @gamepet.step_anime = true
        @gamepet.move_speed = 5
      end
      @gamepet.move_forward if time == 320
      @gamepet.move_backward if time == 260
      @gamepet.jump(0, 0) if time == 220
      @gamepet.jump(0, 0) if time == 205
      @gamepet.twist(180, 5) ; @gamepet.twist(160, 5)
      @gamepet.turn_toward_character(self) if time == 130
      @gamepet.move_speed = 4 if time == 125
      @gamepet.liedown if time == 120
      @gamepet.reset_liedown if time == 110
      @gamepet.play_balloon if time == 40
      @gamepet.play_voice if time == 40
      @gamepet.move_toward_player if time == 30
      $game_system.replay_bgm if time == 2
      
    when 9 # trampoline
      case time
      when 350; @gamepet.jump_high(0,0, 20); RPG::SE.new("Jump2",80,).play
      when 300; jump_high(0, 0, 20); ; RPG::SE.new("Jump2",80,).play
      when 250; @gamepet.jump_high(0,0, 20); RPG::SE.new("Jump2",80,).play
      when 200; jump_high(0, 0, 20); ; RPG::SE.new("Jump2",80,).play
      when 150; @gamepet.jump_high(0,0, 20); RPG::SE.new("Jump2",80,).play
      when 112; @gamepet.liedown; RPG::SE.new("Crossbow",80,).play
                $game_map.screen.start_shake(7, 7, 20)
      when 80;  @gamepet.play_balloon; RPG::SE.new("Miss",80,).play
      when 10;  @gamepet.reset_liedown; @gamepet.play_voice
                @gamepet.turn_toward_player
      end
    end
    start_poping_window(1, 3) if time == 1
  end
  
  # reseting
  def globalpet_reset
    @gamepet.reset_pet
    @gamepet.zoomfx_x = 1.0
    @gamepet.zoomfx_y = 1.0
    @gamepet.reset_liedown
    @vastored = nil
    @gamepet.step_anime = false
    @gamepet.direction_fix = false
    @gamepet.priority_type = 1
    @climb_wait = 0
    if @gamepet.chase_event_id != nil
      event = $game_map.events[@gamepet.chase_event_id]
      if !event.nil? and !event.egrabbing.nil?
        event.egrabbing = nil 
        event.move_speed = @gvdata[0]
        event.move_type = @gvdata[1]
        event.priority_type = @gvdata[2]
      end
    end
  end
  
  def update_poppetwindow
    if @gamepet.lvup_pop and @petpop_time == 0
      start_poping_window(3, 80, false)
      @petpop_refresh = true
      @gamepet.lvup_pop = false
      RPG::SE.new("Up1",80).play
      @gamepet.jump(0, 0)
    end
    if @petpop_time == 2 * 60 and @petpop_type == 1 and
      @gamepet.reservedmood != 0
      @gamepet.gain_mood(@gamepet.reservedmood)
      @gamepet.mood_full? ? @petpop_type = 2 : @petpop_type = 1
      @petpop_refresh = true
      @gamepet.reservedmood = 0
    end
  end
  
#-------------------------------------------------------------------------------
# Pet trigger targets
  def update_command_startevet(id)
    event = $game_map.events[id]
    @gamepet.through = false if @gamepet.through
    @gamepet.move_toward_character(event) unless @gamepet.moving?
    if @gamepet.samepos?(event) && @gamepet.command == 10 && !@gamepet.jumping?
      event.check_evcom("/PET TRIGGER") ? event.start : start_poping_window(4,2)
      @gamepet.command = 27
    end
  end
  
  #-----------------------------------------------------------------------------
  # steal
  
  def update_command_steal(id)
    event = $game_map.events[id]
    @gamepet.through = false if @gamepet.through
    @gamepet.move_toward_character(event) unless @gamepet.moving?
    if @gamepet.samepos?(event) && @gamepet.command == 11 && !@gamepet.jumping?
      item   = event.check_evvar("/PET STEAL ITEM")
      weapon = event.check_evvar("/PET STEAL WEAPON")
      armor  = event.check_evvar("/PET STEAL ARMOR")
      gold   = event.check_evvar("/PET STEAL GOLD")
      chance = event.check_evvar("/PET STEAL CHANCE 1 / ")
      chance = 1 if chance == 0
      have_something = item > 0 || weapon > 0 || gold > 0 || armor > 0
      unless have_something
        start_poping_window(7, 3)
        @gamepet.play_voice
        @gamepet.command = 27
        return
      end
      if rand(chance) == 0
        if item != 0
          gain_stealed_item($data_items[item])
        elsif weapon != 0
          gain_stealed_item($data_weapons[weapon])
        elsif armor != 0
          gain_stealed_item($data_armors[armor])
        elsif gold != 0
          @gamepet.stealed_item = gold
          $game_party.gain_gold(gold)
          RPG::SE.new("Shop",80).play
          start_poping_window(5, 3)
        end
      else
        start_poping_window(6, 3)
        @gamepet.play_voice
      end
      @gamepet.command = 27
    end
  end
  
  def gain_stealed_item(stealed)
    @gamepet.stealed_item = stealed
    $game_party.gain_item(stealed, 1)
    RPG::SE.new("Item3",80).play
    start_poping_window(5, 3)
  end
  
  #-----------------------------------------------------------------------------
  # Grab
  
  def update_command_grab(id)
    event = $game_map.events[id]
    @gamepet.through = false if @gamepet.through
    @gamepet.move_toward_character(event) unless @gamepet.moving?
    if @gamepet.samepos?(event) && @gamepet.command == 12 && !@gamepet.jumping?
      @gvdata = [event.move_speed, event.move_type, event.priority_type]
      event.check_evcom("/PET GRAB") ? event.egrabbing = true :
      start_poping_window(8, 2)
      @gamepet.command = 27
    end
  end
  
  #-----------------------------------------------------------------------------
  # Climb CLIMB MIERDDAAAAAAAAAAAAAAAAAAAA
  
  def update_command_climb(id)
    event = $game_map.events[id]
    event.priority_type = 0 if event.priority_type != 0
    event.through = true if !event.through
    @gamepet.through = false if @gamepet.through
    @gamepet.move_toward_character(event) if !@gamepet.moving? and
    @climb_wait == 0
    @gamepet.turn_toward_character(self) if @climb_wait > 0
    if @climb_wait == 1 and @gamepet.x == event.x and @gamepet.y == event.y
      @gamepet.command = 27
      return
    end
    if climb_area?(event, 7) and @climb_wait > 0 and !moving?
      if @gamepet.x == @x and @gamepet.y == @y
        globalpet_reset
        return
      end
      # jump to cimb aerea player
      if !passable?(@x, @y, @direction) and @gamepet.x == event.x and 
        @gamepet.y == event.y and Input.dir8 != 0
        jumpto(event.id)
        self.followers.reverse_each do |f|
          f.move_toward_player ; f.move_toward_player ; f.move_toward_player
          f.jumpto(event.id)
        end
        RPG::SE.new("Shot1",80).play
        globalpet_reset
      end
    end
    if @gamepet.samepos?(event) && @climb_wait == 0 && !@gamepet.jumping?
      if event.check_evcom("/PET CLIMB")
        unless @gamepet.x == @x and @gamepet.y == @y
          start_poping_window(9, 1)
          @gamepet.play_voice
          @gamepet.jump(0, 0)
          @climb_wait = 12 * 60
        end
      end
    end
  end
  
  # preparation for pet acting
  def prepare_petact
    if @vastored.nil?
      turn_toward_character(@gamepet) ; @gamepet.turn_toward_character(self)
      @vastored = true ; followers.gather
    end
  end
  
  #-----------------------------------------------------------------------------
  # heal command
  
  def update_command_heal
    prepare_petact
    @gamepet.move_away_from_player if @gamepet.action_time == 270
    @gamepet.turn_toward_character(self) if @gamepet.action_time == 250
    if @gamepet.action_time == 210
      @gamepet.jump_high(0, 0, 18) 
      @gamepet.casting = true
    end
    $game_map.screen.start_shake(5, 5, 60) if @gamepet.action_time == 160
    if @gamepet.action_time == 120
      @gamepet.balloon_id = 1
      @gamepet.play_voice
    end
    self.animation_id = 40 if @gamepet.action_time == 100
    if @gamepet.action_time == 1
      for member in $game_party.members
        case FalPet::HealPercent
        when '25%'  ; hp = 4    ; when '50%'  ; hp = 2
        when '75%'  ; hp = 1.32 ; when '100%' ; hp = 1
        end
        member.change_hp((member.mhp  / hp).truncate, false)
        member.mp += (member.mmp  / hp).truncate
        start_poping_window(10, 3)
      end
    end
  end
  
  #-----------------------------------------------------------------------------
  # Make random item
  def update_command_randomitems
    prepare_petact
    @gamepet.cast_item_producing(FalPet::ItemAnime)
    if @gamepet.action_time == 2
      @gamepet.get_randomitem('item', FalPet::RandomItems)
      $game_party.gain_item(@gamepet.randomitem[0], @gamepet.randomitem[1])
    end
  end
  
  #-----------------------------------------------------------------------------
  # Make random weapon
  def update_command_randomweapons
    prepare_petact
    @gamepet.cast_item_producing(FalPet::WeaponAnime)
    if @gamepet.action_time == 2
      @gamepet.get_randomitem('weapon', FalPet::RandomWeapons)
      $game_party.gain_item(@gamepet.randomitem[0], @gamepet.randomitem[1])
    end
  end
  
  #-----------------------------------------------------------------------------
  # Make random armor
  def update_command_randomarmors
    prepare_petact
    @gamepet.cast_item_producing(FalPet::ArmorAnime)
    if @gamepet.action_time == 2
      @gamepet.get_randomitem('armor', FalPet::RandomArmors)
      $game_party.gain_item(@gamepet.randomitem[0], @gamepet.randomitem[1])
    end
  end
  
  #-----------------------------------------------------------------------------
  # Make random gold
  def update_command_randomgold
    prepare_petact
    @gamepet.cast_item_producing(FalPet::GoldAnime)
    if @gamepet.action_time == 2
      @gamepet.get_randomitem('gold', FalPet::RandomGold)
      $game_party.gain_gold(@gamepet.randomitem[0])
      RPG::SE.new("Shop",80).play
    end
  end
  
  #-----------------------------------------------------------------------------
  # Command instant cooldown
  def update_command_instantcd
    prepare_petact
    @gamepet.cast_item_producing(FalPet::GoldAnime, true)
    if @gamepet.action_time == 2
      @gamepet.instantcd = FalPet::BuffDuration * 60
    end
  end
  
  #-----------------------------------------------------------------------------
  alias falcaopet_move_straight move_straight
  def move_straight(d, turn_ok = true)
    return if @layingdown
    @gamepet.move_toward_char(self) if passable?(@x, @y, d) and
    not @gamepet.busy?
    falcaopet_move_straight(d, turn_ok = true)
    @just_jumped = false if @just_jumped
  end
 
  alias falcaopet_move_diagonal move_diagonal
  def move_diagonal(horz, vert)
    @gamepet.move_toward_char(self) if diagonal_passable?(@x,@y, horz, vert) and
    not @gamepet.busy?
    falcaopet_move_diagonal(horz, vert)
  end
  
  alias falcaopet_perform_transfer perform_transfer
  def perform_transfer
    $game_system.replay_bgm if @gamepet.command == 8
    globalpet_reset
    falcaopet_perform_transfer
    @gamepet.moveto(@x, @y)
    @gamepet.set_direction(@direction)
  end
  
  alias falcaopet_get_on_vehicle get_on_vehicle
  def get_on_vehicle
    falcaopet_get_on_vehicle
    if vehicle
      @showing_pet = false
      $game_system.replay_bgm if @gamepet.command == 8 ; globalpet_reset
    end
  end
end

# sprite set
class Spriteset_Map
  alias falcao_pet_create_characters create_characters
  def create_characters
    create_pet_sprite
    falcao_pet_create_characters
  end
  
  alias falcao_pet_dispose dispose
  def dispose
    dispose_pet_sprite
    dispose_petpop_window
    falcao_pet_dispose
  end
  
  def create_petpop_window
    return if not @mood_window.nil?
    @mood_window = Window_Base.new(544 / 2 - 230 / 2, 0, 230, 76)
    refresh_petpop_window
  end
  
  # refresh pet pop
  def refresh_petpop_window
    return if @mood_window.nil?
    @mood_window.contents.clear
    pet = $game_player.gamepet
    if pet.custom_mode != nil
      draw_extra_text(pet.custom_mode, 0, 20)
      return
    end
    case $game_player.petpop_type
  
    # Gain mood
    when 1
      @mood_window.draw_petmoodbar(0, 38)
      case (pet.mood.to_f / pet.grow_inflation[0].to_f * 100.0)
      when  0..25  ;  text = FalPet::MoodLowText
      when 26..50  ;  text = FalPet::MoodOverageText
      when 51..75  ;  text = FalPet::MoodMediumText
      when 76..100  ; text = FalPet::MoodHight
      end
      draw_extra_text(text, 100, 5, @mood_window.normal_color)
      # Giving gift
    when 2
      @mood_window.draw_petgift(110, 20)
      draw_extra_text('Gave you a gift', 0, 20)
      return if pet.mood == 0
      $game_party.gain_item(pet.mood_item, 1)
      RPG::SE.new("Item3",80).play
      pet.mood = 0
      pet.apply_growing
      
    when 3;  draw_extra_text('Level Up!', 0, 20, Color.new(255, 120, 0, 255))
    when 4;  draw_extra_text('Cannot be triggered...', 0, 20)
    when 5;  @mood_window.draw_stealed_item(0, 20)
             @mood_window.draw_petname(0, -8)
    when 6;  draw_extra_text('Could not steal!', 0, 20)
    when 7;  draw_extra_text('Nothing to steal!', 0, 20)
    when 8;  draw_extra_text('I cannot grab this shit!', 0, 20)
    when 9;  draw_extra_text('Hey come!', 0, 20)  
    when 10
      draw_extra_text("Your party was healed by #{FalPet::HealPercent}!",0, 20)
    when 11
      item = pet.randomitem
      @mood_window.contents.fill_rect(166, -6, 30, 30, Color.new(0, 0, 0, 60))
      if item[0].is_a? Fixnum 
        @mood_window.draw_icon(344, 168, 0)
        draw_extra_text("Gave you x#{item[0]} #{Vocab::currency_unit}!", 0, 20)
      else
        @mood_window.draw_icon(item[0].icon_index, 168, 0)
        draw_extra_text("Gave you #{item[0].name} x#{item[1]}!", 0, 20)
      end
    when 12; draw_extra_text('Fuck that!', 0, 20)
    when 13; draw_extra_text('Cool down become instant!', 0, 20)  
    end
  end
  
  def draw_extra_text(text, x, y, color=nil)
    @mood_window.contents.font.color = color if !color.nil?
    @mood_window.draw_petname(0, -8)
    @mood_window.contents.font.size = 18
    @mood_window.contents.draw_text(x, y, @mood_window.width, 32, text)
  end
  
  def dispose_petpop_window
    return if @mood_window.nil?
    @mood_window.dispose
    @mood_window = nil
  end
  
  alias falcao_pet_update update
  def update
    if $game_player.petpop_refresh
      refresh_petpop_window
      $game_player.petpop_refresh = false
    end
    $game_player.showing_pet ? create_pet_sprite : dispose_pet_sprite
    $game_player.petpop_time > 0 ? create_petpop_window : dispose_petpop_window
    @pet_sprite.update unless @pet_sprite.nil?
    falcao_pet_update
  end
  
  def create_pet_sprite
    return if not @pet_sprite.nil?
    @pet_sprite = Sprite_Character.new(@viewport1, $game_player.gamepet)
  end
  
  def dispose_pet_sprite
    return if @pet_sprite.nil?
    @pet_sprite.dispose
    @pet_sprite = nil
  end
end

class Game_Event < Game_Character
  attr_accessor  :move_type
  attr_accessor  :target_index
  def check_evcom(comment)
    return false if @list.nil? or @list.size <= 0
    for item in @list
      if item.code == 108 or item.code == 408
        if item.parameters[0].include?(comment)
          return true
        end
      end
    end
    return false
  end
  
  def check_evvar(comment)
    return 0 if @list.nil? or @list.size <= 0
    for item in @list
      if item.code == 108 or item.code == 408
        if item.parameters[0] =~ /#{comment}[ ]?(\d+)?/
          return $1.to_i
        end
      end
    end
    return 0
  end
  
  def on_current_screen?
    px = ($game_map.display_x).truncate
    py = ($game_map.display_y).truncate
    distance_x = @x - px
    distance_y = @y - py
    return true if distance_x.between?(0, 16) and distance_y.between?(0, 12)
    return false
  end
end

# data manager
class << DataManager
  alias falcaopet_setup_new_game setup_new_game unless $@
  def setup_new_game
    falcaopet_setup_new_game
    $game_player.gamepet.moveto($data_system.start_x, $data_system.start_y)
  end
end

# Sprite character
class Sprite_Character < Sprite_Base
  alias falcaopet_zoom_update update
  def update
    self.zoom_x = @character.zoomfx_x
    self.zoom_y = @character.zoomfx_y
    self.angle = @character.anglefx
    falcaopet_zoom_update
  end
  
  alias falcaopet_update_pos update_position
  def update_position
    falcaopet_update_pos
    if @character.egrabbing
      self.x = $game_player.gamepet.screen_x
      self.y = $game_player.gamepet.screen_y - 14
      @character.x = $game_player.gamepet.x
      @character.y = $game_player.gamepet.y
      @character.set_direction($game_player.gamepet.direction) unless
      @character.direction_fix
      @character.move_speed = 6
      @character.move_type = 0
      @character.priority_type = 1
    end
  end
end

# get custom command data
class Game_Interpreter
  def pet
    return $game_player.gamepet
  end
end

# Game followers plugin, this fit the pet with followers members
class Game_Follower < Game_Character
  def chase_preceding_character
    unless moving?
      prechar = @preceding_character
      if $game_player.showing_pet
        if prechar.is_a?(Game_Player) and !prechar.followers.gathering? and
           !prechar.just_jumped and FalPet::YieldSpot
          sx = distance_x_from(prechar.x - prechar.adjustpxy[0])
          sy = distance_y_from(prechar.y - prechar.adjustpxy[1])
        else
          sx = distance_x_from(prechar.x) ; sy = distance_y_from(prechar.y)
        end
      else
        sx = distance_x_from(prechar.x) ; sy = distance_y_from(prechar.y)
      end
      if sx != 0 && sy != 0
        move_diagonal(sx > 0 ? 4 : 6, sy > 0 ? 8 : 2)
      elsif sx != 0
        move_straight(sx > 0 ? 4 : 6)
      elsif sy != 0
        move_straight(sy > 0 ? 8 : 2)
      end
    end
  end
end

#===============================================================================
# * Scenes and Windows
#===============================================================================

# Window base new methods
class Window_Base < Window
  def draw_petmoodbar(x, y)
    contents.font.color = normal_color
    mood = $game_player.gamepet.mood
    max = $game_player.gamepet.grow_inflation[0]
    contents.fill_rect(x, y, 102, 10, Color.new(0, 0, 0))
    contents.fill_rect(x+1, y+1, 100 *mood / max, 4, Color.new(180, 225, 245))
    contents.fill_rect(x+1, y+5, 100 *mood / max, 4, Color.new(20, 160, 225))
    contents.font.size = 16
    contents.draw_text(x,y -24,self.width, 32, 'Mood: ' + mood.to_s + "/#{max}")
  end
  
  def draw_petname(x, y, a=0)
    contents.font.size = 18
    contents.font.color = normal_color
    lv = $game_player.gamepet.pet_level ; name = $game_player.gamepet.petname
    contents.draw_text(x, y, self.width, 32, name + " Lv #{lv}", a)
  end
  
  def draw_petgift(x, y)
    contents.fill_rect(x, y - 18, 106, 76, Color.new(0, 0, 0, 60))
    item = $game_player.gamepet.mood_item
    draw_icon(item.icon_index, x + 30, y - 3)
    contents.font.size = 15
    contents.font.color = normal_color
    contents.draw_text(x -2, y - 24, 90, 32, 'Gift', 1)
    contents.draw_text(x, y + 10, 90, 32, item.name, 1)
  end
  
  def draw_stealed_item(x, y)
    contents.fill_rect(x + 160, y - 21, 30, 30, Color.new(0, 0, 0, 60))
    contents.font.color = normal_color
    contents.font.size = 18
    item = $game_player.gamepet.stealed_item
    if item.is_a? Fixnum 
      draw_icon(344, x + 163, y - 19)
      text = item.to_s + " #{Vocab::currency_unit}"
    else
      text = item.name
      draw_icon(item.icon_index, x + 163, y - 19)
    end
    contents.draw_text(x, y + 1, 200, 32, "Have stealed #{text}!")
  end
end

#-------------------------------------------------------------------------------
# Pets commands selectable
class Window_PetCommands < Window_Selectable
  def initialize(x=0, y=0, w=350, h=242) #192
    super(x, y + 76,  w, h)
    self.z = 101
    refresh
    self.index = 0
    activate if !busy?
  end
  
  def busy?
    return true if $game_player.gamepet.busy? || $game_player.in_airship? ||
    $game_player.in_boat? || $game_player.in_ship?
    return false
  end
  
  def item
    return @data[self.index]
  end
 
  def refresh
    self.contents.clear if self.contents != nil
    @data = []
    FalPet::Commands.sort.reverse.each do |id, command |
      next if id == 27
      @data.push(command) if id == 1 or id == 26
      @data.push(command) if $game_player.gamepet.unlock_command.include?(id)
      next if id == 26
      next unless id.between?(10, FalPet::Commands.keys.size)
      @data.push(command) if 
      FalPet::Speciality[$game_player.gamepet.pet_id].include?(id)
    end
    @item_max = @data.size
    if @item_max > 0
      self.contents = Bitmap.new(width - 32, row_max * 26)
      for i in 0...@item_max
        draw_item(i)
      end
    end
  end
 
  def draw_item(index)
    item = @data[index]
    x, y = index % col_max * (145 + 32), index / col_max  * 24
    self.contents.font.size = 18
    draw_icon(item[2], x, y, !$game_player.gamepet.busy? )
    unless busy?
      cool_down(item[1]) > 0 ? self.contents.font.color = disable_color :
      self.contents.font.color = normal_color
    else
      self.contents.font.color = disable_color
    end
    self.contents.font.color = disable_color  if item[1] != 1 and
    !$game_player.showing_pet
    self.contents.draw_text(x + 24, y, 212, 32, item[0], 0)
  end
  
  def disable_color
    return Color.new(255, 255, 255, 128)
  end
  
  def cool_down(i)
    cd = $game_player.gamepet
    cooldown = 0
    FalPet::Commands.each do |id, cmd |
      cooldown = cd.cooldown[cmd[1]-1] if i == id and cd.cooldown[cmd[1] -1] > 0
    end
    return cooldown
  end
  
  def cool_data(i)
    data = [false, nil]
    FalPet::Commands.each do |id, cmd |
      data = [true, cmd[1] - 1] if i == id
    end
    return data
  end
  
  def item_max
    return @item_max.nil? ? 0 : @item_max 
  end 
  
  def col_max
    return 2
  end 
end

#-------------------------------------------------------------------------------
# Scene pet commands
class Scene_PetCommands < Scene_Base
  def start
    super
    @pet = $game_player.gamepet
    x, y  = 544 / 2 - 350 / 2, 10
    @info_window = Window_Base.new(x, y, 350, 76)
    @color = Color.new(255, 120, 0, 255)
    @petCommand_window = Window_PetCommands.new(x, y)
    @mood_window = Window_Base.new(x, y + 76 + 242, 350, 76)
    @mood_window.draw_petmoodbar(0, 38)
    @mood_window.draw_petname(0, -8)
    @mood_window.draw_character(@pet.character_name,@pet.character_index,170,54)
    @mood_window.draw_petgift(236, 20)
    @background_sprite = Sprite.new
    @background_sprite.bitmap = SceneManager.background_bitmap
    @refresh_delay = 0
    refresh_info
  end
  
  def refresh_info
    @info_window.contents.clear
    @info_window.contents.font.size = 18
    @info_window.contents.font.color = @info_window.normal_color
    @petCommand_window.busy? ? text = 'Pet is busy...' : 
    text = @petCommand_window.item[6]
    @info_window.contents.draw_text(- 10, 0,@info_window.width, 32, text, 1)
    action = @petCommand_window.item[9]
    mood = @petCommand_window.item[8]
    mood = '' if mood == 0
    @info_window.contents.draw_text(0, 28, @info_window.width, 32,
    'Type: ' + action + " #{mood}")
    cooldown > 0 ? operand = cooldown : operand = @petCommand_window.item[7] *60
    operand = @pet.instantcd if @pet.instantcd > 0
    total_sec = operand / Graphics.frame_rate
    cd = sprintf("%02d:%02d", total_sec / 60, total_sec % 60)
    if @pet.instantcd > 0 
      text = "Instant!:  #{cd}"
      @info_window.contents.font.color = @color
    else
      text = "Cooldown:  #{cd}"
    end
    @info_window.contents.draw_text(-50, 28, 350, 32, text, 2)
  end
  
  def cooldown
    return @petCommand_window.cool_down(@petCommand_window.item[1])
  end
  
  def update
    super
    if Input.trigger?(:B)
      SceneManager.goto(Scene_Map)
      Sound.play_cancel
    end
    return if @petCommand_window.busy?
    update_refresh
    if Input.trigger?(:C)
      cmd = @petCommand_window
      if cmd.item[1] != 1
        if cooldown > 0 || !$game_player.showing_pet
          Sound.play_buzzer
          return
        end
      end
      Sound.play_ok
      if @petCommand_window.item[4]
        apply_cooldown(cmd)
        SceneManager.callp(Scene_Event, @petCommand_window.item[1])
      elsif @petCommand_window.item[5]
        apply_cooldown(cmd)
        SceneManager.goto(Scene_Pets)
      else
        apply_cooldown(cmd)
        @pet.command = @petCommand_window.item[1]
        @pet.action_time = @petCommand_window.item[3]
        if @pet.custom_command?
          @pet.action_time = @pet.action_time + 1 if (@pet.action_time%2 == 0)
        end
        @pet.jumpto(0) if @petCommand_window.item[1] == 1 and
        $game_player.showing_pet
        $game_player.petpop_time =0 if @pet.reservedmood > 0 and cmd.item[8] > 0
        @pet.reservedmood = cmd.item[8]
        SceneManager.goto(Scene_Map)
      end
    end
  end
  
  def update_refresh
    refresh_info if cooldown > 0 || @pet.instantcd > 0
    if @index != @petCommand_window.index
      @index = @petCommand_window.index
      refresh_info 
    end
    @refresh_delay -= 1 if @refresh_delay > 0
    @refresh_delay = 2 if @pet.instantcd == 1
    if @refresh_delay == 1
      @petCommand_window.refresh 
      refresh_info 
    end
    for i in 0...@pet.cooldown.size
      if @pet.cooldown[i] == 1
        @refresh_delay = 2
      end
    end
  end
  
  def apply_cooldown(cmd)
    if cmd.cool_data(cmd.item[1])[0] and cmd.cool_down(cmd.item[1]) == 0
      index = cmd.cool_data(cmd.item[1])[1]
      @pet.cooldown[index] = @petCommand_window.item[7] * 60
    end
  end
  
  def terminate
    super
    @petCommand_window.dispose
    @background_sprite.dispose
    @info_window.dispose
  end
end

#-------------------------------------------------------------------------------
# Invisible window event selection
class Window_Event < Window_Selectable
  attr_reader   :participants
  def initialize(x=0, y=0, w=150, h=192)
    super(x, y,  w, h)
    self.z = 101
    @participants = []
    refresh
    self.index = 0
    self.visible = false
    activate
  end
  
  def item
    return @data[self.index]
  end
 
  def refresh
    self.contents.clear if self.contents != nil
    @data = []
    for event in $game_map.events.values
      if event.on_current_screen?
        next if event.tile_id == 0 and event.character_name == ""
        next if event.check_evcom("/IGNORE TARGETING")
        @data.push(event)
        event.target_index = @data.size - 1
        @participants.push(event)
      end
    end
    @item_max = @data.size
    if @item_max > 0
      self.contents = Bitmap.new(width - 32, row_max * 26)
      for i in 0...@item_max
        draw_item(i)
      end
    end
  end
 
  def draw_item(index)
    item = @data[index]
    x, y = index % col_max * (120 + 32), index / col_max  * 24
    self.contents.font.size = 16
    self.contents.draw_text(x + 24, y, 212, 32, item.id.to_s, 0)
  end
  
  def item_max
    return @item_max.nil? ? 0 : @item_max 
  end 
  
  def col_max
    return 1
  end 
end

#-------------------------------------------------------------------------------
# Scenen events selection target
class Scene_Event < Scene_Base
  def initialize(command)
    @command = command
  end
  
  def start
    super
    @mouse_exist = defined?(Map_Buttons).is_a?(String)
    @event_window = Window_Event.new
    @info_window = Sprite.new
    @info_window.bitmap = Bitmap.new(300, 60)
    @info_window.z = 900; @info_window.x = 544/2 -200/2; @info_window.y = 180
    @info_window.bitmap.font.size = 28; @info_window.bitmap.font.bold = true
    @event_window.item.nil? ? t = 'No targets!' : t = 'Select target'
    @info_window.bitmap.draw_text(-30, 0, @info_window.width, 32, t, 1)
    @background_sprite = Sprite.new
    @background_sprite.bitmap = SceneManager.background_bitmap
    @info_time = 60
    create_cursor unless @event_window.item.nil?
  end
  
  def refresh_info(type)
    @info_window.bitmap.clear
    t = 'I cant climb that bich!' if type == 1
    t = 'Invalid Target!' if type == 2
    @info_window.bitmap.draw_text(-30, 0, @info_window.width, 32, t, 1)
  end
  
  def create_cursor
    if @mouse_exist
      @cursor = $mouse_cursor
      @cursor_zooming = 0 ; update_cursor_position
      return
    end
    
    @cursor = Sprite.new
    icon = FalPet::CursorIcon
    @cursor.bitmap = Bitmap.new(24, 24)
    bitmap = Cache.system("Iconset")
    rect = Rect.new(icon % 16 * 24, icon / 16 * 24, 24, 24)
    @cursor.bitmap.blt(0, 0, bitmap, rect)
    @cursor_zooming = 0
    update_cursor_position
  end
  
  def update
    super
    if Input.trigger?(:B)
      SceneManager.goto(Scene_PetCommands)
      Sound.play_cancel
    end
    @info_time -= 1 if @info_time > 0
    if @info_time == 0
      @info_window.opacity -= 8 if @info_window.opacity > 0
      if @info_window.opacity == 0 and @event_window.item.nil?
        Sound.play_cancel
        SceneManager.goto(Scene_PetCommands)
      end
    end
      
    return if @event_window.item.nil?
    update_cursor_position
    update_target_selection
  end
  
  # target selection
  def update_target_selection
    if Input.trigger?(:C)
      if @mouse_exist
        for event in @event_window.participants
          if Mouse.map_grid[0] == event.x and Mouse.map_grid[1] == event.y
            @event_window.select(event.target_index)
            @selected = true
          end
        end
        if @selected.nil?
          refresh_info(2)
          @info_time = 60; @info_window.opacity = 255
          Sound.play_buzzer
          return
        end
      end
      if @command == 13 and not @event_window.item.check_evcom("/PET CLIMB")
        refresh_info(1)
        @info_time = 60; @info_window.opacity = 255
        Sound.play_buzzer
        return
      end
      Sound.play_ok
      $game_player.gamepet.chase_event_id = @event_window.item.id
      $game_player.gamepet.command = @command
      SceneManager.goto(Scene_Map)
    end
  end
  
  def update_cursor_position
    if @mouse_exist
      @cursor.x = Mouse.pos[0]
      @cursor.y = Mouse.pos[1]
    else
      @cursor.x = @event_window.item.screen_x
      @cursor.y = @event_window.item.screen_y - 16
    end
    @cursor_zooming += 1
    case @cursor_zooming
    when 1..10 ; @cursor.zoom_x -= 0.01 ; @cursor.zoom_y -= 0.01
    when 11..20; @cursor.zoom_x += 0.01 ; @cursor.zoom_y += 0.01
    when 21..30; @cursor.zoom_x = 1.0   ; @cursor.zoom_y = 1.0
      @cursor_zooming = 0 
    end
  end
  
  def terminate
    super
    @event_window.dispose
    @background_sprite.dispose
    @info_window.dispose
    @info_window.bitmap.dispose
    if @mouse_exist
      @cursor.zoom_x = 1.0   ; @cursor.zoom_y = 1.0 ; @selected = nil
    else
      @cursor.dispose unless @cursor.nil?
      @cursor.bitmap.dispose unless @cursor.nil?
    end
  end
end

#-------------------------------------------------------------------------------
# Window pets
class Window_Pets < Window_Selectable
  def initialize(shop)
    super(0, 0,  406, 122)
    self.z = 101
    @shop = shop
    refresh
    self.index = 0
    activate
  end
  
  def item
    return @data[self.index]
  end
 
  def refresh
    self.contents.clear if self.contents != nil
    @data = []
    FalPet::Pets.each do |id , pet|
      pet.push(id) unless pet.include?(id)
      @data.push(pet) if @shop
      @data.push(pet) if $game_player.adopted_pets.include?(id) and !@shop
    end
    @item_max = @data.size
    if @item_max > 0
      self.contents = Bitmap.new(width - 32, row_max * 26)
      for i in 0...@item_max
        draw_item(i)
      end
    end
  end
 
  def draw_item(index)
    item = @data[index]
    x, y = index % col_max * (107 + 32), index / col_max  * 24
    self.contents.font.size = 18
    self.contents.draw_text(x, y, 212, 32, item[2], 0)
  end
  
  def item_max
    return @item_max.nil? ? 0 : @item_max 
  end 
  
  def col_max
    return 3
  end 
end

#-------------------------------------------------------------------------------
# Scene pets base, refered at pep shop and pets adopted
class Scene_PetsBase < Scene_Base
  def start
    super
    @pet = $game_player.gamepet
    SceneManager.scene_is?(Scene_PetShop) ? @shop = true : @shop = false
    @pet_window = Window_Pets.new(@shop)
    x, y = 544 / 2 -406 / 2, 0
    @pet_window.x = x
    @pet_window.y = y + 110
    @info_window = Window_Base.new(x, y, 406, 110)
    @bonus_window = Window_Base.new(x, y + 122 + 110, 406, 184)
    @background_sprite = Sprite.new
    @background_sprite.bitmap = SceneManager.background_bitmap
    refresh_infodata
  end
  
  def refresh_infodata
    @info_window.contents.clear
    @info_window.contents.font.size = 18
    @shop ? xy = [0, 0] : xy = [286, 0]
    @info_window.contents.fill_rect(xy[0], xy[1],90,76, Color.new(0,0,0,60))
    @info_window.draw_character(@pet_window.item[0],
    @pet_window.item[1], xy[0] + 45, xy[1] + 64)
    @info_window.draw_text(xy[0] + 20, xy[1] + 66, 350, 32, 'Pet id')
    create_price_info if @shop
    refresh_bonus
    return if @shop
    @info_window.contents.fill_rect(0, -18, 90, 90, Color.new(0, 0, 0, 60))
    @info_window.draw_text(0, 64, @info_window.width, 32, 'Current Pet')
    @info_window.draw_text(-16, 0, @info_window.width, 32, @pet.petname, 1)
    @info_window.draw_character(@pet.character_name,@pet.character_index,45,64)
  end
  
  def refresh_bonus
    @bonus_window.contents.clear
    @bonus_window.contents.font.size = 20
    y = 0; manager = 0
    @bonus_window.contents.font.color = Color.new(255, 120, 0, 255)
    @bonus_window.draw_text(40, -6, 406, 32, 'Pet Special Skills', 1)
    @bonus_window.draw_text(0, -6, 406, 32, 'Bonus')
    @bonus_window.contents.font.color = @bonus_window.normal_color
    
    # draw speciality
    @bonus_window.contents.font.size = 16
    enable = FalPet::Speciality[@pet_window.item[6]]
    FalPet::Commands.each do |id, command |
      if enable.include?(id)
        manager += 1
        (manager%2 == 0) ? x = 260 : y += 17
        x = 128 unless (manager%2 == 0)
        @bonus_window.draw_text(x, y, @bonus_window.width, 32, command[0])
      end
    end
    
    #draw bonus parameters
    bonus = FalPet::Bonus[@pet_window.item[6]]
    y = 0
    for i in 0...8
      y += 17
      @bonus_window.draw_text(0, y, 406, 32, Vocab.param(i))
      @bonus_window.draw_text(58, y, 406, 32, "=> #{bonus[i].to_s}")
    end
  end
  
  def create_price_info
    @info_window.contents.font.size = 22
    @info_window.draw_text(156, 0, @info_window.width, 32, 'Pet Shop')
    @info_window.contents.font.size = 18
    @info_window.draw_text(156, 32, 350, 32, "Name: #{@pet_window.item[2]}")
    v = pet_price
    @info_window.draw_text(156,64,350,18,"Price: $#{v} " + Vocab::currency_unit)
    @info_window.contents.fill_rect(320, -18, 62, 56, Color.new(0, 0, 0, 60))
    @info_window.draw_text(28, 0, 350, 18, $game_party.gold.to_s, 2)
    @info_window.draw_text(28, 18, 350, 18, Vocab::currency_unit, 2)
  end
  
  def pet_price
    return FalPet::Price[@pet_window.item[6]]
  end
  
  def terminate
    super
    @bonus_window.dispose
    @background_sprite.dispose
    @info_window.dispose
    @pet_window.dispose
  end
end

#-------------------------------------------------------------------------------
# Scene pet adopted
class Scene_Pets < Scene_PetsBase
  
  def start() super end
  def update
    super
    if Input.trigger?(:B)
      SceneManager.goto(Scene_PetCommands)
      Sound.play_cancel
    end
    if @index != @pet_window.index
      @index = @pet_window.index
      refresh_infodata
    end
    if Input.trigger?(:C)
      @pet.setup_pet(@pet_window.item[6])
      refresh_infodata    
    end
  end
end

#-------------------------------------------------------------------------------
# Scene pet shop

class Scene_PetShop < Scene_PetsBase

  def start
    super
    @pop_window = Window_Base.new(200, 170, 150, 110)
    @pop_window.z = 500
    @pop_time = 0
    @pop_window.visible = false
  end
  
  def refresh_pop(type)
    @pop_window.contents.clear
    @pop_window.contents.font.size = 18
    case type
    when 1
      @pop_window.draw_text(0, 0, @pop_window.width, 32, "You have buyed!")
      @pop_window.draw_text(0, 22, @pop_window.width, 32, @pet_window.item[2]) 
      @pop_window.draw_text(0, 44, @pop_window.width, 32, 
      Vocab::currency_unit + " -#{pet_price}") 
    when 2
      @pop_window.draw_text(0, 0, 200, 32, "You dont have")
      @pop_window.draw_text(0, 22, 200, 32, "enough #{Vocab::currency_unit}")
    when 3
      @pop_window.draw_text(0, 0, @pop_window.width, 32, "You already owned!")
      @pop_window.draw_text(0, 22, @pop_window.width, 32, @pet_window.item[2]) 
    end
  end
  
  def update
    super
    if Input.trigger?(:B)
      SceneManager.goto(Scene_Map)
      Sound.play_cancel
    end
    if @index != @pet_window.index
      @index = @pet_window.index
      refresh_infodata
    end
    update_buying
  end
  
  def update_buying
    @pop_time -= 1 if @pop_time > 0
    @pop_time > 0 ? @pop_window.visible = true : @pop_window.visible = false
    if Input.trigger?(:C)
      if $game_player.adopted_pets.include?(@pet_window.item[6])
        refresh_pop(3)
        @pop_time = 2 * 60
        Sound.play_cancel
        return
      end
      if $game_party.gold >= pet_price
        $game_party.lose_gold(pet_price)
        RPG::SE.new("Shop", 80,).play 
        $game_player.adopt_pet(@pet_window.item[6])
        refresh_infodata
        refresh_pop(1)
        @pop_time = 2 * 60
      else
        refresh_pop(2)
        @pop_time = 2 * 60
        Sound.play_buzzer
      end
    end
  end
  
  def terminate
    super
    @pop_window.dispose
  end
end

#-------------------------------------------------------------------------------

# update global cool down
class << Input
  unless self.method_defined?(:falcaopet_ccd_update)
    alias_method :falcaopet_ccd_update,   :update
  end
  
  def update
    update_cooldown_system
    falcaopet_ccd_update
  end
  
  def update_cooldown_system
    player = $game_player
    unless player.nil?
      player.gamepet.instantcd -= 1 if player.gamepet.instantcd > 0
      for i in 0...player.gamepet.cooldown.size
        if player.gamepet.cooldown[i] > 0 and player.gamepet.instantcd > 0    
          player.gamepet.cooldown[i] = 0 if not i == 19 - 1
        end
        player.gamepet.cooldown[i] -= 1 if player.gamepet.cooldown[i] > 0
      end
    end
  end
end

module SceneManager
  def self.callp(scene_class, *args)
    @scene = scene_class.new(*args)
  end
end

#-------------------------------------------------------------------------------
# FA Interactive System 2.0 pet plug-ins

class Game_Player < Game_Character
  if defined?(FalInt).is_a?(String)
    alias falcaopetplugins_fall player_start_falling
    def player_start_falling
      @showing_pet = false
      $game_system.replay_bgm if @gamepet.command == 8 ; globalpet_reset
      falcaopetplugins_fall
    end
  end
end

class Game_CharacterBase
  if defined?(FalInt).is_a?(String)
    alias falcaopetplugins_start_jump start_jump
    def start_jump(power)
      player = self.is_a?(Game_Player)
      if player and Input.dir4 != 0
        self.followers.reverse_each {|f| f.move_toward_player }
        self.gamepet.move_toward_player ; self.gamepet.move_toward_player
        self.gamepet.jump(0,  power)  if @direction == 2
        self.gamepet.jump(- power, 0) if @direction == 4
        self.gamepet.jump(power,  0)  if @direction == 6
        self.gamepet.jump(0, - power) if @direction == 8
        self.just_jumped = true
      end
      falcaopetplugins_start_jump(power)
    end
  end
end