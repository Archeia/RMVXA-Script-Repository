#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
#             Show Damage State Messages
#             Authors: DiamondandPlatinum3
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#  Description:
#
#    This script show messages in battle when you have been dealt damage as a
#    result of a state: such as poison or burn
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#------------------------------------------------------------------------------
#  Instructions:
#  
#     In the editable region below you can set up what is necessary
#
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
class Game_Battler
  STATES_DAMAGE_VOCAB = [
  #==================================
  #     Editable Region
  #==================================
  # You can add more states by copying the below lines one after another
 
  # Id of the state;    what you see when you are affected by this state
  [ 2,        "Due to the effects of Poison"            ],
  [ 3,        "If Blind could hurt you, you would have" ], # Lost HP :P
  #==================================
 
 
 
 
 
 
 
 
 
 
  ]
  #--------------------------------------------------------------------------
  # * Regenerate HP
  #--------------------------------------------------------------------------
  alias dp3_showmessg_whenpois_gmbttlr_regenHP_83nd87           regenerate_hp
  def regenerate_hp
    # Make Temp Value
    temporaryHP = self.hp
   
    # Call Original Method
    dp3_showmessg_whenpois_gmbttlr_regenHP_83nd87()
   
    # If Health is lower than before
    if self.hp < temporaryHP && SceneManager.scene_is?(Scene_Battle)
      $game_message.add(sprintf(actor_damage_state_string + " " + self.name + " lost " + @result.hp_damage.to_s + "HP"))
    end
  end
  #--------------------------------------------------------------------------
  # * Get Actor Damage State String
  #--------------------------------------------------------------------------
  def actor_damage_state_string
    self.states.each do |state|
      STATES_DAMAGE_VOCAB.each do |element|
        return element[1] if state.id == element[0]
      end
    end
    return ""
  end
end