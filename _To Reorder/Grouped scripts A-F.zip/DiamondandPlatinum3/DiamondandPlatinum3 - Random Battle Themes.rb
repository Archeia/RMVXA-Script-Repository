#==============================================================================
#  Random Battle Themes
#  Version: 1.0
#  Author: DiamondandPlatinum3
#  Date: July 23, 2012
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#  Description:
#    This script allows you to play a random battle theme upon starting a
#    battle, it can be turned off before a boss battle via switch so that 
#    the appropriate battle them still plays for them.
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#------------------------------------------------------------------------------
#  Instructions:
#  
#     - Just take a look at the editable region and modify things 
#       appropriately.
#
#==============================================================================
module DiamondandPlatinum3
  module RandomBattleThemes
  
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
#                                                        -= 
#                 Editable Region        ////            ==
#                                                        =-
#-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

  # Turn this switch on before a boss battle so that the 
  # music you actually want to play will play.
  EVENT_SWITCH_ID = 10

  
  THEMES_ARRAY   = [    # Don't touch this line
  #============================================================ 
  # You can add more battle themes / change the current ones 
  # or remove any you don't need. I'd like to think you can 
  # figure out what to do by looking at this so I'm not going 
  # to write lines of comment explaining it.
  #
  # Simply copy one line of code and paste it under the last, 
  # then edit it to add more battle themes.
  # Otherwise simply delete one line of code to remove that 
  # battle theme.
  #
  # Battle Theme has to be in quotation marks (" ")
  # And it has to be EXACT Filename.
  #===========================================================

  # Battle Theme, Volume, Pitch
  [ "Battle1",    100,    100 ], # The Info for One of the Random Battle Themes
  [ "Battle2",    100,    100 ], # The Info for One of the Random Battle Themes
  [ "Battle3",    100,    100 ], # The Info for One of the Random Battle Themes
  [ "Battle4",    100,    100 ], # The Info for One of the Random Battle Themes
  [ "Battle5",    100,    100 ], # The Info for One of the Random Battle Themes
  [ "Battle6",    100,    100 ], # The Info for One of the Random Battle Themes
  [ "Battle7",    100,    100 ], # The Info for One of the Random Battle Themes
  [ "Battle8",    100,    100 ], # The Info for One of the Random Battle Themes
  [ "Battle9",    100,    100 ], # The Info for One of the Random Battle Themes
  [ "Town2",      100,    100 ], # The Info for One of the Random Battle Themes
  
  
#=========================================================== 
#                                           \/
#               End of Editable Region      /\
]#                                          \/
#===========================================================
#---------------------------------------------------------
# No touchie past here unless you know what you are 
# doing. Failure to heed this warning could cause your 
# computer to yell and scream at you. 
#
# Edit at your own risk.
#--------------------------------------------------------
  end
end





#==============================================================================
# ** BattleManager
#------------------------------------------------------------------------------
#  This module manages battle progress.
#==============================================================================

module BattleManager
  #--------------------------------------------------------------------------
  # * Overwritten Method: Play Battle BGM
  #--------------------------------------------------------------------------
  def self.play_battle_bgm
    unless $game_switches[DiamondandPlatinum3::RandomBattleThemes::EVENT_SWITCH_ID]
      randbttlnum = rand(DiamondandPlatinum3::RandomBattleThemes::THEMES_ARRAY.size) 
      RPG::BGM.new(*DiamondandPlatinum3::RandomBattleThemes::THEMES_ARRAY[randbttlnum]).play 
    else
      $game_system.battle_bgm.play
    end
    RPG::BGS.stop
  end
end