#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
#             Delay Time Transitions
#             Author: DiamondandPlatinum3
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#  Description:
#
#    This script will allow you to delay when the title screen and battle
#    scene will enter their phase. Its only usefulness is for sound purposes.
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~



module QueMusicWaitTime
  #===============================
  #    Editable Region
  #===============================
 
  TITLESCREEN_WAIT_TIME = 400 # you'll need to play around with this.
 
  BATTLESCENE_WAIT_TIME = 400 # you'll need to play around with this.
 
  #===============================
 
end






class Scene_Title < Scene_Base
  #--------------------------------------------------------------------------
  # * Start processing
  #--------------------------------------------------------------------------
  alias quemusicwaittime_scntitl_start_47cn37 start
  def start
    # Start Playing Music
    play_title_music

    # Wait for Music
    Graphics.wait(QueMusicWaitTime::TITLESCREEN_WAIT_TIME)
   
    # Run Original Method
    quemusicwaittime_scntitl_start_47cn37  
  end
end



class Scene_Battle < Scene_Base
  #--------------------------------------------------------------------------
  # * Start Processing
  #--------------------------------------------------------------------------
  alias quemusicwaittime_scnbttl_start_47cn37 start
  def start
    # Wait For Music
    Graphics.wait(QueMusicWaitTime::BATTLESCENE_WAIT_TIME)
   
    # Run Original Method
    quemusicwaittime_scnbttl_start_47cn37
  end
end