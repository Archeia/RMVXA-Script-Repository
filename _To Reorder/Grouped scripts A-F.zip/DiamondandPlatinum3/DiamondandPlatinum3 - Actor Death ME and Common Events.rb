#==============================================================================
#  Actor Death ME & Common Events
#  Version: 1.1
#  Author: DiamondandPlatinum3
#  Date: July 31, 2012      (Original)
#        September 22, 2012 (Updated)
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#  Description:
#    This script will allow you to play an ME when one of your actors die in 
#    battle. It'll also allow you to use a common event when it occurs. 
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#------------------------------------------------------------------------------
#  Instructions:
#  
#     - Place this script in the materials section, above Main.
#
#     - Edit the editable region options
#
#     - Set your common events to do what you want them to do (in the database)
#
#
#
#     - You can change the ME and it's properties via an event with a script call:
#       
#         Change_ActorDeathME(ME, Volume, Pitch, Frames)
#
#       If you do not wish to change a specific value, simply pass in nil as the 
#       parameter.
#
#       You can find a visual reference for it
#       Here: http://img4host.net/upload/22035729505d1b0939257.png
#
#==============================================================================
module Actor_Death_ME
  #=========================================================
  #               EDITABLE REGION
  #=========================================================
    Death_ME         = "Gameover2" # Set to nil if you don't want any ME to play upon death
    ME_Volume        = 100
    ME_Pitch         = 100 
    Framewait_Amount = 100 # Set to zero if not using any ME
    
    
    #-------------------------------------------------------
    Common_Event_ID_To_Run = [  0,  # Don't touch this line
    #-------------------------------------------------------
    10,       #Actor1's Common Event to run if incapacitated
    11,       #Actor2's Common Event to run if incapacitated
    12,       #Actor3's Common Event to run if incapacitated
    13,       #Actor4's Common Event to run if incapacitated
    14,       #Actor5's Common Event to run if incapacitated
    15,       #Actor6's Common Event to run if incapacitated
    16,       #Actor7's Common Event to run if incapacitated
    17,       #Actor8's Common Event to run if incapacitated
    18,       #Actor9's Common Event to run if incapacitated
    
  #=========================================================
  ]#            END OF EDITABLE REGION
  #=========================================================
  
  
  
  
  
  
  
  
  
  
  
  
  
  # Setter Functions
  def self.ChangeME( newsound )
    self.const_set(:Death_ME, newsound)
  end
  def self.ChangeVolume( newvolume )
    self.const_set(:ME_Volume, newvolume)
  end
  def self.ChangePitch( newpitch )
    self.const_set(:ME_Pitch, newpitch)
  end
  def self.ChangeFramewait_Amount( newframewait )
    self.const_set(:Framewait_Amount, newframewait)
  end
  
  
end # Module
  








  

#==============================================================================
# ** Game_Battler
#------------------------------------------------------------------------------
#  A battler class with methods for sprites and actions added. This class 
# is used as a super class of the Game_Actor class and Game_Enemy class.
#==============================================================================
class Game_Battler
  #--------------------------------------------------------------------------
  # * Knock Out
  #--------------------------------------------------------------------------
  alias actordeathme_die_ufh343 die
  def die
    
    # Call original method
    actordeathme_die_ufh343
    
    
    #/////////////////////////////////////////////////////////////////////
    if @actor_id && SceneManager.scene_is?(Scene_Battle)
      RPG::ME.new(Actor_Death_ME::Death_ME, Actor_Death_ME::ME_Volume, Actor_Death_ME::ME_Pitch).play if Actor_Death_ME::Death_ME
      Graphics.wait(Actor_Death_ME::Framewait_Amount)
      $game_temp.reserve_common_event(Actor_Death_ME::Common_Event_ID_To_Run[@actor_id])
    end
    #/////////////////////////////////////////////////////////////////////
    
  end # Function
end # Class





#==============================================================================
# ** Game_Interpreter
#------------------------------------------------------------------------------
#  An interpreter for executing event commands. This class is used within the
# Game_Map, Game_Troop, and Game_Event classes.
#==============================================================================
class Game_Interpreter
  #--------------------------------------------------------------------------
  # * Change Actor Death ME
  #--------------------------------------------------------------------------
  def Change_ActorDeathME( me, volume, pitch, frames )
    Actor_Death_ME::ChangeME( me )                    if me.is_a?(String) # if not nil and is a string
    Actor_Death_ME::ChangeVolume( volume )            if volume.is_a?(Integer)
    Actor_Death_ME::ChangePitch( pitch )              if pitch.is_a?(Integer)
    Actor_Death_ME::ChangeFramewait_Amount( frames )  if frames.is_a?(Integer)
  end # Function
end # Class