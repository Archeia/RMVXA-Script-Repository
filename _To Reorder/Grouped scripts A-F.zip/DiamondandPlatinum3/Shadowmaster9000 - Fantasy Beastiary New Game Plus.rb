=begin
===============================================================================
 Fantasy Bestiary New Game Plus Add-On v1.5 (10/9/2014)
-------------------------------------------------------------------------------
 Created By: Shadowmaster/Shadowmaster9000/Shadowpasta
 (www.crimson-castle.co.uk)
 Special Thanks: Yanfly (For Yanfly's New Game Plus)
 
===============================================================================
 Information
-------------------------------------------------------------------------------
 This script is an add-on for both my Fantasy Bestiary script and Yanfly's New
 Game Plus script which allows you to save various data for the Bestiary to
 be carried over to a new save file.
 
===============================================================================
 How to Use
-------------------------------------------------------------------------------
 Place this script under Materials and below Yanfly's New Game Plus.
 
 Further down are some options you can change to your liking.
 
===============================================================================
 Required
-------------------------------------------------------------------------------
 Fantasy Bestiary (Will only work with versions 3.2 and higher!)
 (http://www.rpgmakervxace.net/topic/14951-fantasy-bestiary/)

 Yanfly's New Game Plus (which also requires Yanfly's Save Engine)
 (http://yanflychannel.wordpress.com/rmvxa/menu-scripts/ace-save-engine/new-game/)
 
 This script is intended to be an add-on for Fantasy Bestiary and Yanfly's New
 Game Plus. This script is not a standalone script.

===============================================================================
 Change log
-------------------------------------------------------------------------------
 v1.5: Fixed all errors and tested script this time. (10/9/2014)
 v1.2: Fixed an error due to function not ending properly. (01/9/2014)
 v1.1: Hopefully fixed an error in concerns to saving Bestiary data. (01/9/2014)
 v1.0: First release. (27/8/2013)

===============================================================================
 Terms of Use
-------------------------------------------------------------------------------
 * Free to use for both commercial and non-commerical projects.
 * Credit me and Yanfly if used.
 * Do not claim this as your own.
 * You're free to post this on other websites, but please credit me and keep
 the header intact.
 * If you want to release any modifications/add-ons for this script, you must
 use the same Terms of Use as this script uses.
 * If you want to use your own seperate Terms of Use for your version or
 add-ons of this script, you must contact me at http://www.rpgmakervxace.net
 or www.crimson-castle.co.uk

===============================================================================
=end
$imported = {} if $imported.nil?
$imported["FantasyBestiaryNGP"] = true

module FantasyBestiary_NGP
  
#==============================================================================
# ** Carry Over Settings
#------------------------------------------------------------------------------
#  Lets you set which data from the Bestiary to be carried over. The data
#  options that are set to true will have their data carried over when using
#  New Game Plus. Any data options that are set to false will not have their
#  data carried over.
#==============================================================================
  
  Carry_Over_Enemies_Found = true
  Carry_Over_Enemies_Total = true
  Carry_Over_Enemies_Bonus = true
  Carry_Over_Enemies_Kills = true
  Carry_Over_Enemies_Revealed = true
  Carry_Over_Enemies_Hidden = true
  Carry_Over_Enemies_Level = true
  Carry_Over_Enemies_Icon = true
  
end

#==============================================================================
# ** DataManager
#------------------------------------------------------------------------------
#  This module manages the database and game objects. Almost all of the 
#  global variables used by the game are initialized by this module.
#==============================================================================

module DataManager
  #--------------------------------------------------------------------------
  # * Alias: ngp_reset_party
  #--------------------------------------------------------------------------
  class <<self; alias bestiary_ngp_reset_party ngp_reset_party; end
  def self.ngp_reset_party
    ngp_enemies_found = 0
    ngp_enemies_total = 0
    ngp_completion_bonus = 0
    ngp_kill_count = []
    ngp_bestiary_level = []
    ngp_bestiary_icon = []
    ngp_enemies_revealed = []
    ngp_enemies_hidden = []
    ngp_enemies_found = $game_party.enemies_found
    ngp_enemies_total = $game_party.enemies_total
    ngp_completion_bonus = $game_party.completion_bonus
    ngp_kill_count = $game_party.kill_count
    ngp_bestiary_level = $game_party.bestiary_level
    ngp_bestiary_icon = $game_party.bestiary_icon
    ngp_enemies_revealed = $game_party.enemies_revealed
    ngp_enemies_hidden = $game_party.enemies_hidden
    bestiary_ngp_reset_party
    $game_party.enemies_found = ngp_enemies_found if FantasyBestiary_NGP::Carry_Over_Enemies_Found
    $game_party.enemies_total = ngp_enemies_total if FantasyBestiary_NGP::Carry_Over_Enemies_Total
    $game_party.completion_bonus = ngp_completion_bonus if FantasyBestiary_NGP::Carry_Over_Enemies_Bonus
    $game_party.kill_count = ngp_kill_count if FantasyBestiary_NGP::Carry_Over_Enemies_Kills
    $game_party.bestiary_level = ngp_bestiary_level if FantasyBestiary_NGP::Carry_Over_Enemies_Level
    $game_party.bestiary_icon = ngp_bestiary_icon if FantasyBestiary_NGP::Carry_Over_Enemies_Icon
    $game_party.enemies_revealed = ngp_enemies_revealed if FantasyBestiary_NGP::Carry_Over_Enemies_Revealed
    $game_party.enemies_hidden = ngp_enemies_hidden if FantasyBestiary_NGP::Carry_Over_Enemies_Hidden
    end
end