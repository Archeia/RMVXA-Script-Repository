#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
#             Outside Event Self-Switch Control
#             Author: DiamondandPlatinum3
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#  Description:
#
#    This script allows you modify one event's self-switch from another event.
#    This can save you lots of event switches from being used if done correctly.
#
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#------------------------------------------------------------------------------
#  Instructions:
#  
#     Use the following in a script call:
#       mod_self_switch( map_id, event_id, switch, on_or_off )
#
#     Replace 'map_id'     with the id of the map the event is located on.
#     Replace 'event_id'   with the event id (obviously)
#     Replace 'switch'     with either "A", "B", "C", or "D"
#     Replace 'on_or_off'  with either true or false, 
#                          true sets the switch on, whilst false turns that switch off.
#
#
#     Screenshot Example can be found here: goo.gl/Gb5Kl
#
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=






class Game_Interpreter
  #--------------------------------------------------------------------------
  # * Control Self Switch
  #--------------------------------------------------------------------------
  def mod_self_switch( map_id, event_id, switch, on_or_off )
    current_map_id    = @map_id
    current_event_id  = @event_id
    current_params    = [ @params[0], @params[1] ]
    
    @map_id     = map_id
    @event_id   = event_id
    @params[0]  = switch
    if on_or_off; @params[1] = 0; else; @params[1] = 1; end
      
    # Self Switch Command
    command_123()
    
    @map_id     = current_map_id    
    @event_id   = current_event_id 
    @params[0]  = current_params[0]
    @params[1]  = current_params[1]
  end
end