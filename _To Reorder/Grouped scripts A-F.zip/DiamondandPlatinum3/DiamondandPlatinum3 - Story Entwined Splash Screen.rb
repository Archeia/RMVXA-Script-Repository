#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
#             Story-Entwined Splash Screen Map
#             Version: 1.0
#             Author: DiamondandPlatinum3
#             Date: June 7, 2014
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#  Description:
#
#    This script allows you to start your game on various different Splash 
#     Maps upon GameStart.
#
#    This means that you can use these maps to show a splash screen or a 
#     backstory (or anything else) before the Title Screen is shown.
#
#    In addition, this script is based upon story progress. So these Splash 
#     Maps may be shown when the player has unlocked them
#
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#------------------------------------------------------------------------------
#  Instructions:
#
#  ~  Modify Editable Region to your liking.
#
#  ~  When Transferring to the Map, the map begins in a screen_fadeout state.
#       This is to allow you to set up the map behind the scenes.
#       When the map is ready to view, use the "Fadein Screen" Event.
#
#  ~  When finished eventing on a Splash Map. Make sure the 
#       "Return to Title Screen" event is used.
#
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
($diamondandplatinum3_scripts ||= {})[:StoryEntwinedSplashScreenMap] = true
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
module DiamondandPlatinum3
  module StoryEntwinedSplashScreenMap
    #=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
    #                                                        -= 
    #                 Editable Region        ////            ==
    #                                                        =-
    #-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    
    # The Variable which will contain the data for the Splash Screen Map.
    # By default this variable 100, which means that as variable 100 changes
    # numbers, so too could the splash screen map, if you allow it.
    VariableID = 100
    
    
    # Reset Splash Screen Map Back to Default Splash Screen Map if starting 
    # a new game?
    ResetSplashScreenMapOnNewGame = true
    
    
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    Splash_Screen_Maps = {              # <= Do not touch this line
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    
    # Variable Value => Splash_Map_ID ,
    
    
      0 =>  1 ,  # This is your default Splash Screen Map ID
      1 =>  1 ,
      2 =>  3 , 
      4 =>  4 , 
      5 =>  5 , 

      
      
      
      # Add as many as you want.
    
      
    #-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= 
    #                                           \/
    #               End of Editable Region      /\
    #                                           \/
    #-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    }
    
    
    
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # * New Class Variables
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @@can_display_splash_screen_map = true
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # * New Class Method: Can Display Splash Screen Map?
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def self.can_display?
      return @@can_display_splash_screen_map
    end
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # * New Class Method: Set Display Value
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def self.set_display_value(val)
      @@can_display_splash_screen_map = val
    end    
  end
end








#==============================================================================
# ** DataManager
#------------------------------------------------------------------------------
#  This module manages the database and game objects. Almost all of the 
# global variables used by the game are initialized by this module.
#==============================================================================

module DataManager
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # *= Alias Listings
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  class << self
    alias_method(:dp3_storyentss_dataman_setupnewgame,       :setup_new_game)
  end
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * Aliased Method: Set Up New Game
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def self.setup_new_game(*args)
    dp3_storyentss_dataman_setupnewgame(*args)
    save_storyentwinedsplashscreen_data() if DiamondandPlatinum3::StoryEntwinedSplashScreenMap::ResetSplashScreenMapOnNewGame
  end
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * New Method: Save Story Entwined Title Screen Data
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def self.save_storyentwinedsplashscreen_data()
    variable = $game_variables[DiamondandPlatinum3::StoryEntwinedSplashScreenMap::VariableID]
    save_data(variable, "Data/Story-Entwined-Splash-Screen.rvdata2")
  end
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * New Method: Save Story Entwined Title Screen Data
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def self.load_storyentwinedsplashscreen_data()
    return load_data("Data/Story-Entwined-Splash-Screen.rvdata2") rescue 0
  end
end



#==============================================================================
# ** SceneManager
#------------------------------------------------------------------------------
#  This module manages scene transitions. For example, it can handle
# hierarchical structures such as calling the item screen from the main menu
# or returning from the item screen to the main menu.
#==============================================================================

module SceneManager
  class << self
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # *= Alias Listings
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    alias_method(:dp3_storyentss_scnman_firstsceneclass,  :first_scene_class)
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # * Get First Scene Class
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def first_scene_class(*args)
      if DiamondandPlatinum3::StoryEntwinedSplashScreenMap::can_display?
        # Stop Allowing Display. So F12 Resetting doesn't cause a Splash Map to show up again
        DiamondandPlatinum3::StoryEntwinedSplashScreenMap::set_display_value(false)
        # Look through Available Maps, finding the appropriate map to goto
        maps = DiamondandPlatinum3::StoryEntwinedSplashScreenMap::Splash_Screen_Maps.sort.reverse
        variable = DataManager.load_storyentwinedsplashscreen_data()
        maps.each do |info| 
          if variable >= info[0]
            DataManager.create_game_objects()
            $game_map.setup(info[1])
            $game_player.moveto(0, 0)
            $game_map.autoplay()
            $game_map.screen.start_fadeout(1)
            return Scene_Map
          end
        end
      end
      return dp3_storyentss_scnman_firstsceneclass(*args)
    end
  end
end







#==============================================================================
# ** Scene_Save
#------------------------------------------------------------------------------
#  This class performs save screen processing. 
#==============================================================================

class Scene_Save < Scene_File
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # *= Alias Listings
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  alias_method(:dp3_storyentss_scnsave_onsavesuccess,       :on_save_success)
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * Alias Method: On Save Success
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def on_save_success(*args)
    DataManager.save_storyentwinedsplashscreen_data()
    dp3_storyentss_scnsave_onsavesuccess(*args)
  end
end