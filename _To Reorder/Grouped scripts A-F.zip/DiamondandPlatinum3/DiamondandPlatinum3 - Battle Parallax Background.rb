#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
#             Battle Parallax Background
#             Version: 1.0
#             Author: DiamondandPlatinum3
#             Date: September 6, 2012
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#  Description:
#
#    This script allows you to use a parallax as a background for your
#    Battles. It also allows you to scroll the parallax like any regular
#    map parallax.
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#------------------------------------------------------------------------------
#  Instructions:
#  
#     -  There are two methods of changing the battle parallax options.
#     
#     ~  One of which is to use a script call with the following line of code
#
#         setbattleparallax( filename, scrollx, scrolly )
#
#        Where 'filename' is where you enter the name of the parallax, this must be 
#        done in quotation marks ( ' ' ).
#        'scrollx' is the amount the parallax will scroll to the left or right.
#        'scrolly' is the amount the parallax will scroll up or down.
#
#
#     -  If you do not want to change a specific value, simply pass in nil as the 
#        parameter
#
#
#
#
#     ~  The other method is to use notetags for the map, exactly like the following:
#     
#         ~BP_NAME: "Filename"
#         ~BP_SCRX: Number 
#         ~BP_SCRY: Number
#
#        This has the same effect as calling the function, in that you can change 
#        the name of the battle parallax and it's scrolling variables.
#
#
#
#     -  You can find screenshots to visually explain both methods
#        Here: http://img4host.net/upload/07161653504a01d5e21c4.png
#        Here: http://img4host.net/upload/061210075048767f2a69d.png
#
#        
#     -  The advantage of using the map note is that you can set the parallax to
#        a specific map like when you specify the battle backgrounds in the map
#        settings. The function method is really for use when you want to change 
#        the parallax for a specific bossfight.
#
#     -  You can also use negative numbers to reverse the directions of the 
#        parallax scroll. You'll need to play around with it to achieve the 
#        desired effect
#
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
#
#
#                  THERE IS NO EDITABLE REGION TO THIS SCRIPT
#
#==============================================================================











#==============================================================================
# ** Spriteset_Battle
#------------------------------------------------------------------------------
#  This class brings together battle screen sprites. It's used within the
# Scene_Battle class.
#==============================================================================

class Spriteset_Battle
  #--------------------------------------------------------------------------
  # * Overwritten Functions
  #--------------------------------------------------------------------------
  #     create_battleback1
  #     create_battleback2
  #     update_battleback1
  #     update_battleback2
  #     dispose_battleback1
  #     dispose_battleback2
  #
  #--------------------------------------------------------------------------
  # * Alias Listings
  #--------------------------------------------------------------------------
  alias dp3_batlparallax_sprsetbatl_init_1h2g       initialize
  alias dp3_batlparallax_sprsetbatl_dispose_1h2g    dispose
  alias dp3_batlparallax_sprsetbatl_update_1h2g     update
  #--------------------------------------------------------------------------
  # * Object Initialization
  #--------------------------------------------------------------------------
  def initialize
    # Call Original Method
    dp3_batlparallax_sprsetbatl_init_1h2g
    
    create_parallax
  end
  #--------------------------------------------------------------------------
  # * Frame Update
  #--------------------------------------------------------------------------
  def update
    update_parallax
    
    # Call Original Method
    dp3_batlparallax_sprsetbatl_update_1h2g
  end
  #--------------------------------------------------------------------------
  # * Free
  #--------------------------------------------------------------------------
  def dispose
    dispose_parallax
    
    # Call Original Method
    dp3_batlparallax_sprsetbatl_dispose_1h2g
  end
  
  
  
  #--------------------------------------------------------------------------
  # * Create Battle Background (Floor) Sprite
  #--------------------------------------------------------------------------
  def create_battleback1
    @back1_sprite = nil
  end
  #--------------------------------------------------------------------------
  # * Create Battle Background (Wall) Sprite
  #--------------------------------------------------------------------------
  def create_battleback2
    @back2_sprite = nil
  end
  #--------------------------------------------------------------------------
  # * Create Parallax
  #--------------------------------------------------------------------------
  def create_parallax
    @backparallax = Plane.new(@viewport1)
    @backparallax.bitmap = Cache.parallax($game_system.battleparallaxgraphicname)
    @backparallax.z = 0
  end
  
  
  
  
  
  #--------------------------------------------------------------------------
  # * Update Battle Background (Floor) Sprite
  #--------------------------------------------------------------------------
  def update_battleback1
    @back1_sprite.update if @back1_sprite
  end
  #--------------------------------------------------------------------------
  # * Update Battle Background (Wall) Sprite
  #--------------------------------------------------------------------------
  def update_battleback2
    @back2_sprite.update if @back2_sprite
  end
  #--------------------------------------------------------------------------
  # * Update Parallax
  #--------------------------------------------------------------------------
  def update_parallax
    if @backparallax
      @backparallax.ox += $game_system.battleparallaxgraphicscrollx
      @backparallax.oy += $game_system.battleparallaxgraphicscrolly
    end
  end
  
  
  
  
  #--------------------------------------------------------------------------
  # * Free Battle Background (Floor) Sprite
  #--------------------------------------------------------------------------
  def dispose_battleback1
    if @back1_sprite
      @back1_sprite.bitmap.dispose
      @back1_sprite.dispose 
    end
  end
  #--------------------------------------------------------------------------
  # * Free Battle Background (Wall) Sprite
  #--------------------------------------------------------------------------
  def dispose_battleback2
    if @back2_sprite
      @back2_sprite.bitmap.dispose
      @back2_sprite.dispose 
    end
  end
  #--------------------------------------------------------------------------
  # * Free Battle Parallax
  #--------------------------------------------------------------------------
  def dispose_parallax
    if @backparallax
      @backparallax.bitmap.dispose
      @backparallax.dispose 
    end
  end
  
end # of Class




#==============================================================================
# ** Game_System
#------------------------------------------------------------------------------
#  This class handles system data. It saves the disable state of saving and 
# menus. Instances of this class are referenced by $game_system.
#==============================================================================

class Game_System
  #--------------------------------------------------------------------------
  # * New Public Instance Variables
  #--------------------------------------------------------------------------
  attr_accessor :battleparallaxgraphicname
  attr_accessor :battleparallaxgraphicscrollx
  attr_accessor :battleparallaxgraphicscrolly
  #--------------------------------------------------------------------------
  # * Alias Listings
  #--------------------------------------------------------------------------
  alias dp3_batlparallax_gamesys_init_1h2g     initialize
  #--------------------------------------------------------------------------
  # * Object Initialization
  #--------------------------------------------------------------------------
  def initialize
    
    # Call Original Method
    dp3_batlparallax_gamesys_init_1h2g
    
    # Setup Parallax (safety precautions in case the user doesn't do it themselves)
    @battleparallaxgraphicname    = "BlueSky"
    @battleparallaxgraphicscrollx = 0
    @battleparallaxgraphicscrolly = 0
  end
  
end # of Class





#==============================================================================
# ** Game_Interpreter
#------------------------------------------------------------------------------
#  An interpreter for executing event commands. This class is used within the
# Game_Map, Game_Troop, and Game_Event classes.
#==============================================================================

class Game_Interpreter  
  #--------------------------------------------------------------------------
  # * Set Battle Parallax
  #--------------------------------------------------------------------------
  def setbattleparallax( filename, scrollx, scrolly )
    $game_system.battleparallaxgraphicname    = filename if filename.is_a?(String)
    $game_system.battleparallaxgraphicscrollx = scrollx  if scrollx.is_a?(Integer)
    $game_system.battleparallaxgraphicscrolly = scrolly  if scrolly.is_a?(Integer)
  end
  
end # of Class    





#==============================================================================
# ** Game_Map
#------------------------------------------------------------------------------
#  This class handles maps. It includes scrolling and passage determination
#  functions. The instance of this class is referenced by $game_map.
#==============================================================================

class Game_Map
  #--------------------------------------------------------------------------
  # * Alias Listings
  #--------------------------------------------------------------------------
  alias dp3_battleparallaxmapnote_setup_1h2g     setup  
  #--------------------------------------------------------------------------
  # * Setup
  #      map_id : map ID  
  #--------------------------------------------------------------------------
  def setup(*args)
    # Call Original Method
    dp3_battleparallaxmapnote_setup_1h2g(*args)
    
    # Check Map Note
    checkbattleparallax_mapnote
  end  
  #--------------------------------------------------------------------------
  # * Check Map Note for Battle Parallax Info
  #--------------------------------------------------------------------------
  def checkbattleparallax_mapnote
    
    # Set instance variables to current values
    prlxname = $game_system.battleparallaxgraphicname
    scrollx  = $game_system.battleparallaxgraphicscrollx
    scrolly  = $game_system.battleparallaxgraphicscrolly
    
    # Check Map Notetags
    
    # Code by Modern Algebra -----------------------------
    @map.note[/~BP_NAME:\s*\"(.+?)\"/im]
    prlxname = $1.gsub(/[\n\r]+/, "") if $1 # if not nil
    #-----------------------------------------------------
    @map.note[/~BP_SCRX: ([-0-9]+)/]
    scrollx = $1.to_i if $1
    @map.note[/~BP_SCRY: ([-0-9]+)/]
    scrolly = $1.to_i if $1
        
    $game_system.battleparallaxgraphicname    = prlxname
    $game_system.battleparallaxgraphicscrollx = scrollx
    $game_system.battleparallaxgraphicscrolly = scrolly
  end
  
end # of Class