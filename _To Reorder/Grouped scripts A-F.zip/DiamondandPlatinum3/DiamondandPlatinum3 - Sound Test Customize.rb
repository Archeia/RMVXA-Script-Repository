#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
#             Sound Test Scene ~ Customisable Version
#             Version: 1.0
#             Author: DiamondandPlatinum3
#             Date: June 18, 2013
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#  Description:
#
#    This script creates a new scene in your game which allows you to listen to
#    music that is played throughout your game. It also allows for some 
#    customisation to be made when playing a sound, such as modifying Volume, 
#    Pitch and/or Position.
#    Music can also be locked until a certain Event Switch is turned on.
#
#    It also allows you to have categories for your Sound Files and individual 
#    album art for each audio file.
#
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#------------------------------------------------------------------------------
#  Instructions:
#  
#  ~  You can load the SoundTestScene at anytime by inputting the following in
#     a script call:
#                       SceneManager.call(Scene_SoundTest)
#
#
#  ~  Go into the Script and Modify the Editable Region as Needed
#
#
#  ~  Be sure your Album Art Images are placed in the approriate folder.
#
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
module DiamondandPlatinum3
  module SoundTestScene
    #=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
    #                                                        -=
    #                 Editable Region        ////            ==
    #                                                        =-
    #-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
      
    # Text to be Displayed when Selecting a Category
    CategorySelectHelpWindowTextLine1   = "Select a Category"
    CategorySelectHelpWindowTextLine2   = "Press 'Esc or X' to Exit"
    
    # Text to be displayed on the help window when Selecting a Sound
    SoundSelectHelpWindowTextLine1      = "Select a Sound"
    SoundSelectHelpWindowTextLine2      = "Press 'Esc or X' to Exit"
   
    # Text to be displayed on the help window when Hovering over the 'Play Sound' Option
    PlaySoundOptionHelpWindowTextLine1  = "Select To Play Sound"
    PlaySoundOptionHelpWindowTextLine2  = "(Default Settings)"
   
    # Text to be displayed on the help window when Hovering over the 'Volume' Option
    VolumeOptionHelpWindowTextLine1     = "Select To Play Sound"
    VolumeOptionHelpWindowTextLine2     = "(At Specific Volume)"
   
    # Text to be displayed on the help window when Hovering over the 'Pitch' Option
    PitchOptionHelpWindowTextLine1      = "Select To Play Sound"
    PitchOptionHelpWindowTextLine2      = "(At Specific Pitch)"
   
    # Text to be displayed on the help window when Hovering over the 'Position' Option
    PositionOptionHelpWindowTextLine1   = "Select To Play Sound At Specific Position"
    PositionOptionHelpWindowTextLine2   = "(Only works for WAV & OGG Files)"
   
    # Text to be displayed on the help window when inputting a value in the NuberInput Window
    NumberInputHelpWindowTextLine1      = "Input A Value"
    NumberInputHelpWindowTextLine2      = ""
   
   
    
    # Where Will the Script Find the Album Art Associated with the Music?
    AlbumArtFolder                      = "Graphics/Pictures/"
    
    
    # Filename of Background Image to be Displayed if no Album Art is provided
    # If You do not want a default image, leave an empty string ( "" )
    DefaultBackgroundSpriteFilename     = "SoundTest_BackgroundImage"
   
    
    
    # Position only works with Wav|Ogg files, if you're lacking these filetypes,
    # then the Position command is pretty awkward, you can disable it here.
    EnablePositionCommand               = true
    
    
    # If Enabled, Windows will animate into the scene when entered (either via 
    #  transparency or by flying in).
    # If Disabled, all windows will be there from the get-go
    EnableIntroAnimation                = true
    
    
    
    # If Enabled, The SoundTestScene will be available to select in the Main Menu
    EnableMenuOption                    = true
    
    # The Text that is displayed for the Option in the Menu
    MenuCommandText                     = "Sound Test"
    
    # If Menu Enabled, this Switch (when activated) will allow the user to select
    # the SoundTestScene. If not activated, no access will be granted to the scene
    # via menu.
    #
    # If Set to Zero, the SoundTestScene will always be available via menu.
    EnableSwitchID                      = 0
    
    
    
    # How Many Category Commands can be on one line? Modify this if you find 
    # your text being cut off.
    MaxCategoryHorizontalCommands       = 3
    
    
    # Categories of Music to be used in the Scene, add as many as you'd like
    Music_Categories =
    [
    
      "Battle Themes",
      "Event Themes",
      "Town Themes",
      "Overworld Themes",
      
    ]
   
   
    #--------------------------------------
    Sounds = { # <=   Do Not Touch
    #--------------------------------------
   
   
    # Exact Filename of BGM you want to Have in the Scene
      "Airship" =>
      {
        :display_name       =>  "Airship Theme",              # Display Name of Sound
        :default_volume     =>  100,                          # Deault Volume
        :default_pitch      =>  100,                          # Default Pitch
        :conditional_switch =>  0,                            # Conditional Switch (Must be on before sound will be available, unless event switch is Zero)
        :category           =>  "Overworld Themes",           # Which Category will this Sound Appear in?
        :info_line1         =>  "Author: Enterbrain",         # Info Line1, can be anything you want to say about the Individual Sound
        :info_line2         =>  "Used As: Airship Theme",     # Info Line2, can be anything you want to say about the Individual Sound
        :info_line3         =>  "",                           # Info Line3, can be anything you want to say about the Individual Sound
        :info_line4         =>  "From: RPG Maker VX Ace RTP", # Info Line4, can be anything you want to say about the Individual Sound
        :album_art_filename =>  "Skit_Background_Image",                           # Filename for Custom Album Art, If no custom album art, leave as empty string ( "" )
      },
     
     
      # Rinse, Repeat. Keep Doing this until all your desired SoundFiles are Available to be played
      "Battle1" =>
      {
        :display_name       => "Battle Theme 1",    
        :default_volume     =>  100,                
        :default_pitch      =>  100,                
        :conditional_switch =>  0,                  
        :category           =>  "Battle Themes",
        :info_line1         =>  "Author: Enterbrain",                
        :info_line2         =>  "Used As: Normal Battle Theme",                
        :info_line3         =>  "",                
        :info_line4         =>  "From: RPG Maker VX Ace RTP",
        :album_art_filename =>  "", 
      },
     
     
      "Battle2" =>
      {
        :display_name       => "Battle Theme 2",    
        :default_volume     =>  100,                
        :default_pitch      =>  100,                
        :conditional_switch =>  0,                  
        :category           =>  "Battle Themes",
        :info_line1         =>  "Author: Enterbrain",                
        :info_line2         =>  "Used As: Normal Battle Theme",                
        :info_line3         =>  "",                
        :info_line4         =>  "From: RPG Maker VX Ace RTP",
        :album_art_filename =>  "Emily4.jpg", 
      },
     
     
      "Battle3" =>
      {
        :display_name       => "Battle Theme 3",    
        :default_volume     =>  100,                
        :default_pitch      =>  100,                
        :conditional_switch =>  0,                  
        :category           =>  "Battle Themes",
        :info_line1         =>  "Author: Enterbrain",                
        :info_line2         =>  "Used As: Mini-Boss Battle Theme",                
        :info_line3         =>  "",                
        :info_line4         =>  "From: RPG Maker VX Ace RTP",
        :album_art_filename =>  "", 
      },
     
     
      "Battle4" =>
      {
        :display_name       => "Battle Theme 4",    
        :default_volume     =>  100,                
        :default_pitch      =>  100,                
        :conditional_switch =>  0,                  
        :category           =>  "Battle Themes",
        :info_line1         =>  "Author: Enterbrain",                
        :info_line2         =>  "Used As: Normal Battle Theme",                
        :info_line3         =>  "",                
        :info_line4         =>  "From: RPG Maker VX Ace RTP",
        :album_art_filename =>  "", 
      },
     
     
      "Battle5" =>
      {
        :display_name       => "Battle Theme 5",    
        :default_volume     =>  100,                
        :default_pitch      =>  100,                
        :conditional_switch =>  0,                  
        :category           =>  "Battle Themes",
        :info_line1         =>  "Author: Enterbrain",                
        :info_line2         =>  "Used As: Normal Battle Theme",                
        :info_line3         =>  "",                
        :info_line4         =>  "From: RPG Maker VX Ace RTP",
        :album_art_filename =>  "",
      },
     
     
      "Battle6" =>
      {
        :display_name       => "Battle Theme 6",    
        :default_volume     =>  100,                
        :default_pitch      =>  100,                
        :conditional_switch =>  0,                  
        :category           =>  "Battle Themes",
        :info_line1         =>  "Author: Enterbrain",                
        :info_line2         =>  "Used As: Normal Battle Theme",                
        :info_line3         =>  "",                
        :info_line4         =>  "From: RPG Maker VX Ace RTP",
        :album_art_filename =>  "", 
      },
     
     
      "Battle7" =>
      {
        :display_name       => "Battle Theme 7",    
        :default_volume     =>  100,                
        :default_pitch      =>  100,                
        :conditional_switch =>  0,                  
        :category           =>  "Battle Themes",
        :info_line1         =>  "Author: Enterbrain",                
        :info_line2         =>  "Used As: Normal Battle Theme",                
        :info_line3         =>  "",                
        :info_line4         =>  "From: RPG Maker VX Ace RTP",
        :album_art_filename =>  "", 
      },
     
     
      "Battle8" =>
      {
        :display_name       => "Battle Theme 8",    
        :default_volume     =>  100,                
        :default_pitch      =>  100,                
        :conditional_switch =>  0,                  
        :category           =>  "Battle Themes",
        :info_line1         =>  "Author: Enterbrain",                
        :info_line2         =>  "Used As: Boss Battle Theme",                
        :info_line3         =>  "",                
        :info_line4         =>  "From: RPG Maker VX Ace RTP",
        :album_art_filename =>  "", 
      },
     
     
      "Battle9" =>
      {
        :display_name       => "Battle Theme 9",    
        :default_volume     =>  100,                
        :default_pitch      =>  100,                
        :conditional_switch =>  0,                  
        :category           =>  "Battle Themes",
        :info_line1         =>  "Author: Enterbrain",                
        :info_line2         =>  "Used As: Final Boss Battle Theme",                
        :info_line3         =>  "",                
        :info_line4         =>  "From: RPG Maker VX Ace RTP",
        :album_art_filename =>  "", 
      },
     
     
      "Dungeon1" =>
      {
        :display_name       => "Dungeon Theme 1",    
        :default_volume     =>  100,                
        :default_pitch      =>  100,                
        :conditional_switch =>  0,                  
        :category           =>  "Dungeon Themes",
        :info_line1         =>  "Author: Enterbrain",                
        :info_line2         =>  "Used As: BootCamp Cave Theme",                
        :info_line3         =>  "",                
        :info_line4         =>  "From: RPG Maker VX Ace RTP",
        :album_art_filename =>  "", 
      },
     
     
      "Dungeon2" =>
      {
        :display_name       => "Dungeon Theme 2",    
        :default_volume     =>  100,                
        :default_pitch      =>  100,                
        :conditional_switch =>  0,                  
        :category           =>  "Dungeon Themes",
        :info_line1         =>  "Author: Enterbrain",                
        :info_line2         =>  "Used As: Heavy Rain Theme",                
        :info_line3         =>  "",                
        :info_line4         =>  "From: RPG Maker VX Ace RTP",
        :album_art_filename =>  "", 
      },
     
     
      "Dungeon3" =>
      {
        :display_name       => "Dungeon Theme 3",    
        :default_volume     =>  100,                
        :default_pitch      =>  100,                
        :conditional_switch =>  0,                  
        :category           =>  "Dungeon Themes",
        :info_line1         =>  "Author: Enterbrain",                
        :info_line2         =>  "Used As: Underground Base Theme",                
        :info_line3         =>  "",                
        :info_line4         =>  "From: RPG Maker VX Ace RTP",
        :album_art_filename =>  "", 
      },
     
     
      "Dungeon4" =>
      {
        :display_name       => "Dungeon Theme 4",    
        :default_volume     =>  100,                
        :default_pitch      =>  100,                
        :conditional_switch =>  0,                  
        :category           =>  "Dungeon Themes",
        :info_line1         =>  "Author: Enterbrain",                
        :info_line2         =>  "Used As: Thought Before War Theme",                
        :info_line3         =>  "",                
        :info_line4         =>  "From: RPG Maker VX Ace RTP",
        :album_art_filename =>  "", 
      },
     
     
      "Dungeon5" =>
      {
        :display_name       => "Dungeon Theme 5",    
        :default_volume     =>  100,                
        :default_pitch      =>  100,                
        :conditional_switch =>  0,                  
        :category           =>  "Dungeon Themes",
        :info_line1         =>  "Author: Enterbrain",                
        :info_line2         =>  "Used As: Magical Cavern Theme",                
        :info_line3         =>  "",                
        :info_line4         =>  "From: RPG Maker VX Ace RTP",
        :album_art_filename =>  "", 
      },
     
     
      "Dungeon6" =>
      {
        :display_name       => "Dungeon Theme 6",    
        :default_volume     =>  100,                
        :default_pitch      =>  100,                
        :conditional_switch =>  0,                  
        :category           =>  "Dungeon Themes",
        :info_line1         =>  "Author: Enterbrain",                
        :info_line2         =>  "Used As: Following a Trail Theme",                
        :info_line3         =>  "",                
        :info_line4         =>  "From: RPG Maker VX Ace RTP",
        :album_art_filename =>  "", 
      },
     
     
      "Dungeon7" =>
      {
        :display_name       => "Dungeon Theme 7",    
        :default_volume     =>  100,                
        :default_pitch      =>  100,                
        :conditional_switch =>  0,                  
        :category           =>  "Dungeon Themes",
        :info_line1         =>  "Author: Enterbrain",                
        :info_line2         =>  "Used As: Climbing the Heavens Theme",                
        :info_line3         =>  "",                
        :info_line4         =>  "From: RPG Maker VX Ace RTP",
        :album_art_filename =>  "", 
      },
     
     
      "Dungeon8" =>
      {
        :display_name       => "Dungeon Theme 8",    
        :default_volume     =>  100,                
        :default_pitch      =>  100,                
        :conditional_switch =>  0,                  
        :category           =>  "Dungeon Themes",
        :info_line1         =>  "Author: Enterbrain",                
        :info_line2         =>  "Used As: Descending to the Ground Theme",                
        :info_line3         =>  "",                
        :info_line4         =>  "From: RPG Maker VX Ace RTP",
        :album_art_filename =>  "", 
      },
     
     
      "Dungeon9" =>
      {
        :display_name       => "Dungeon Theme 9",    
        :default_volume     =>  100,                
        :default_pitch      =>  100,                
        :conditional_switch =>  0,                  
        :category           =>  "Dungeon Themes",
        :info_line1         =>  "Author: Enterbrain",                
        :info_line2         =>  "Used As: Last Dungeon Theme",                
        :info_line3         =>  "",                
        :info_line4         =>  "From: RPG Maker VX Ace RTP",
        :album_art_filename =>  "", 
      },
     
     
      "Field1" =>
      {
        :display_name       => "Field Map Theme 1",    
        :default_volume     =>  100,                
        :default_pitch      =>  100,                
        :conditional_switch =>  0,                  
        :category           =>  "Overworld Themes",
        :info_line1         =>  "Author: Enterbrain",                
        :info_line2         =>  "Used As: Starting Your Journey Theme",                
        :info_line3         =>  "",                
        :info_line4         =>  "From: RPG Maker VX Ace RTP",
        :album_art_filename =>  "", 
      },
     
     
      "Field2" =>
      {
        :display_name       => "Field Map Theme 2",    
        :default_volume     =>  100,                
        :default_pitch      =>  100,                
        :conditional_switch =>  0,                  
        :category           =>  "Overworld Themes",
        :info_line1         =>  "Author: Enterbrain",                
        :info_line2         =>  "Used As: World Map Theme",                
        :info_line3         =>  "",                
        :info_line4         =>  "From: RPG Maker VX Ace RTP",
        :album_art_filename =>  "", 
      },
     
     
      "Field3" =>
      {
        :display_name       => "Field Map Theme 3",    
        :default_volume     =>  100,                
        :default_pitch      =>  100,                
        :conditional_switch =>  0,                  
        :category           =>  "Overworld Themes",
        :info_line1         =>  "Author: Enterbrain",                
        :info_line2         =>  "Used As: The Heroes of this Tale Theme",                
        :info_line3         =>  "",                
        :info_line4         =>  "From: RPG Maker VX Ace RTP",
        :album_art_filename =>  "", 
      },
     
     
      "Field4" =>
      {
        :display_name       => "Field Map Theme 4",    
        :default_volume     =>  100,                
        :default_pitch      =>  100,                
        :conditional_switch =>  0,                  
        :category           =>  "Overworld Themes",
        :info_line1         =>  "Author: Enterbrain",                
        :info_line2         =>  "Used As: A World in Chaos Theme",                
        :info_line3         =>  "",                
        :info_line4         =>  "From: RPG Maker VX Ace RTP",
        :album_art_filename =>  "", 
      },
     
     
      "Scene1" =>
      {
        :display_name       => "Custom Scene Theme 1",    
        :default_volume     =>  100,                
        :default_pitch      =>  100,                
        :conditional_switch =>  0,                  
        :category           =>  "Event Themes",
        :info_line1         =>  "Author: Enterbrain",                
        :info_line2         =>  "Used As: In Danger Theme",                
        :info_line3         =>  "",                
        :info_line4         =>  "From: RPG Maker VX Ace RTP",
        :album_art_filename =>  "", 
      },
     
     
      "Scene2" =>
      {
        :display_name       => "Custom Scene Theme 2",    
        :default_volume     =>  100,                
        :default_pitch      =>  100,                
        :conditional_switch =>  0,                  
        :category           =>  "Event Themes",
        :info_line1         =>  "Author: Enterbrain",                
        :info_line2         =>  "Used As: Villain Appears Theme",                
        :info_line3         =>  "",                
        :info_line4         =>  "From: RPG Maker VX Ace RTP",
        :album_art_filename =>  "", 
      },
     
     
      "Scene3" =>
      {
        :display_name       => "Custom Scene Theme 3",    
        :default_volume     =>  100,                
        :default_pitch      =>  100,                
        :conditional_switch =>  0,                  
        :category           =>  "Event Themes",
        :info_line1         =>  "Author: Enterbrain",                
        :info_line2         =>  "Used As: Villain Two Appears Theme",                
        :info_line3         =>  "",                
        :info_line4         =>  "From: RPG Maker VX Ace RTP",
        :album_art_filename =>  "", 
      },
     
     
      "Scene4" =>
      {
        :display_name       => "Custom Scene Theme 4",    
        :default_volume     =>  100,                
        :default_pitch      =>  100,                
        :conditional_switch =>  0,                  
        :category           =>  "Event Themes",
        :info_line1         =>  "Author: Enterbrain",                
        :info_line2         =>  "Used As: Found a New Friend Theme",                
        :info_line3         =>  "",                
        :info_line4         =>  "From: RPG Maker VX Ace RTP",
        :album_art_filename =>  "", 
      },
     
     
      "Scene5" =>
      {
        :display_name       => "Custom Scene Theme 5",    
        :default_volume     =>  100,                
        :default_pitch      =>  100,                
        :conditional_switch =>  0,                  
        :category           =>  "Event Themes",
        :info_line1         =>  "Author: Enterbrain",                
        :info_line2         =>  "Used As: HeartWarming Discussion Theme",                
        :info_line3         =>  "",                
        :info_line4         =>  "From: RPG Maker VX Ace RTP",
        :album_art_filename =>  "", 
      },
     
     
      "Scene6" =>
      {
        :display_name       => "Custom Scene Theme 6",    
        :default_volume     =>  100,                
        :default_pitch      =>  100,                
        :conditional_switch =>  0,                  
        :category           =>  "Event Themes",
        :info_line1         =>  "Author: Enterbrain",                
        :info_line2         =>  "Used As: Happiness Theme",                
        :info_line3         =>  "",                
        :info_line4         =>  "From: RPG Maker VX Ace RTP",
        :album_art_filename =>  "", 
      },
     
     
      "Ship" =>
      {
        :display_name       => "Ship Theme",    
        :default_volume     =>  100,                
        :default_pitch      =>  100,                
        :conditional_switch =>  0,                  
        :category           =>  "Overworld Themes",
        :info_line1         =>  "Author: Enterbrain",                
        :info_line2         =>  "Used As: Riding in a Ship Theme",                
        :info_line3         =>  "",                
        :info_line4         =>  "From: RPG Maker VX Ace RTP",
        :album_art_filename =>  "", 
      },
     
     
      "Theme1" =>
      {
        :display_name       => "Custom Theme 1",    
        :default_volume     =>  100,                
        :default_pitch      =>  100,                
        :conditional_switch =>  0,                  
        :category           =>  "Event Themes",
        :info_line1         =>  "Author: Enterbrain",                
        :info_line2         =>  "Used As: We are a Team Theme",                
        :info_line3         =>  "",                
        :info_line4         =>  "From: RPG Maker VX Ace RTP",
        :album_art_filename =>  "", 
      },
     
     
      "Theme2" =>
      {
        :display_name       => "Custom Theme 2",    
        :default_volume     =>  100,                
        :default_pitch      =>  100,                
        :conditional_switch =>  0,                  
        :category           =>  "Event Themes",
        :info_line1         =>  "Author: Enterbrain",                
        :info_line2         =>  "Used As: Fallen Heroes Theme",                
        :info_line3         =>  "",                
        :info_line4         =>  "From: RPG Maker VX Ace RTP",
        :album_art_filename =>  "", 
      },
     
     
      "Theme3" =>
      {
        :display_name       => "Custom Theme 3",    
        :default_volume     =>  100,                
        :default_pitch      =>  100,                
        :conditional_switch =>  0,                  
        :category           =>  "Event Themes",
        :info_line1         =>  "Author: Enterbrain",                
        :info_line2         =>  "Used As: Art Museum Theme",                
        :info_line3         =>  "",                
        :info_line4         =>  "From: RPG Maker VX Ace RTP",
        :album_art_filename =>  "",
      },
     
     
      "Theme4" =>
      {
        :display_name       => "Custom Theme 4",    
        :default_volume     =>  100,                
        :default_pitch      =>  100,                
        :conditional_switch =>  0,                  
        :category           =>  "Event Themes",
        :info_line1         =>  "Author: Enterbrain",                
        :info_line2         =>  "Used As: Ending Credits Theme",                
        :info_line3         =>  "",                
        :info_line4         =>  "From: RPG Maker VX Ace RTP",
        :album_art_filename =>  "",
      },
     
     
      "Theme5" =>
      {
        :display_name       => "Custom Theme 5",    
        :default_volume     =>  100,                
        :default_pitch      =>  100,                
        :conditional_switch =>  0,                  
        :category           =>  "Event Themes",
        :info_line1         =>  "Author: Enterbrain",                
        :info_line2         =>  "Used As: Supporters Theme",                
        :info_line3         =>  "",                
        :info_line4         =>  "From: RPG Maker VX Ace RTP",
        :album_art_filename =>  "", 
      },
     
     
      "Town1" =>
      {
        :display_name       => "Town Theme 1",    
        :default_volume     =>  100,                
        :default_pitch      =>  100,                
        :conditional_switch =>  0,                  
        :category           =>  "Town Themes",
        :info_line1         =>  "Author: Enterbrain",                
        :info_line2         =>  "Used As: Hero's Home Town Theme",                
        :info_line3         =>  "",                
        :info_line4         =>  "From: RPG Maker VX Ace RTP",
        :album_art_filename =>  "", 
      },
     
     
      "Town2" =>
      {
        :display_name       => "Town Theme 2",    
        :default_volume     =>  100,                
        :default_pitch      =>  100,                
        :conditional_switch =>  0,                  
        :category           =>  "Town Themes",
        :info_line1         =>  "Author: Enterbrain",                
        :info_line2         =>  "Used As: Capital City Theme",                
        :info_line3         =>  "",                
        :info_line4         =>  "From: RPG Maker VX Ace RTP",
        :album_art_filename =>  "", 
      },
     
     
      "Town3" =>
      {
        :display_name       => "Town Theme 3",    
        :default_volume     =>  100,                
        :default_pitch      =>  100,                
        :conditional_switch =>  0,                  
        :category           =>  "Town Themes",
        :info_line1         =>  "Author: Enterbrain",                
        :info_line2         =>  "Used As: Scummy Area of Town Theme",                
        :info_line3         =>  "",                
        :info_line4         =>  "From: RPG Maker VX Ace RTP",
        :album_art_filename =>  "", 
      },
     
     
      "Town4" =>
      {
        :display_name       => "Town Theme 4",    
        :default_volume     =>  100,                
        :default_pitch      =>  100,                
        :conditional_switch =>  0,                  
        :category           =>  "Town Themes",
        :info_line1         =>  "Author: Enterbrain",                
        :info_line2         =>  "Used As: Elderly Village Theme",                
        :info_line3         =>  "",                
        :info_line4         =>  "From: RPG Maker VX Ace RTP",
        :album_art_filename =>  "", 
      },
     
     
      "Town5" =>
      {
        :display_name       => "Town Theme 5",    
        :default_volume     =>  100,                
        :default_pitch      =>  100,                
        :conditional_switch =>  0,                  
        :category           =>  "Town Themes",
        :info_line1         =>  "Author: Enterbrain",                
        :info_line2         =>  "Used As: Peaceful Village Theme",                
        :info_line3         =>  "",                
        :info_line4         =>  "From: RPG Maker VX Ace RTP",
        :album_art_filename =>  "", 
      },
     
     
      "Town6" =>
      {
        :display_name       => "Town Theme 6",    
        :default_volume     =>  100,                
        :default_pitch      =>  100,                
        :conditional_switch =>  0,                  
        :category           =>  "Town Themes",
        :info_line1         =>  "Author: Enterbrain",                
        :info_line2         =>  "Used As: A Town for Adventurer's Theme",                
        :info_line3         =>  "",                
        :info_line4         =>  "From: RPG Maker VX Ace RTP",
        :album_art_filename =>  "",
      },
     
     
      "Town7" =>
      {
        :display_name       => "Town Theme 7",    
        :default_volume     =>  100,                
        :default_pitch      =>  100,                
        :conditional_switch =>  0,                  
        :category           =>  "Town Themes",
        :info_line1         =>  "Author: Enterbrain",                
        :info_line2         =>  "Used As: Mermaid Village Theme",                
        :info_line3         =>  "",                
        :info_line4         =>  "From: RPG Maker VX Ace RTP",
        :album_art_filename =>  "", 
      },
     
     
     
    # If you want to add more Sounds, you may do so above this Line, just
    # copy-paste the above format and change things as needed.
    #///////////////////////
   
   
    #-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    #                                           \/
    #               End of Editable Region      /\
    #                                           \/
    #-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    #---------------------------------------------------------
    # No touchie past here unless you know what you are
    # doing. Failure to heed this warning could cause your
    # computer to yell and scream at you.
    #
    # Edit at your own risk.
    #--------------------------------------------------------
    }
    
    
    
    
    
    
    
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # * New Method: Perform Temporary Compatibility Resolution
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def self.perform_temporary_compatibility_resolution()
    end
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # * New Method: Revert Temporary Compatibility Resolution
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def self.revert_temporary_compatibility_resolution()
    end
  end
end
 
 
 
 
#==============================================================================
# ** SoundTestSound
#------------------------------------------------------------------------------
#  This is a class which hold Individual Sound Information for Play
#==============================================================================
 
class SoundTestSound
  include DiamondandPlatinum3::SoundTestScene
  #--------------------------------------------------------------------------
  # * Public Instance Variables
  #--------------------------------------------------------------------------
  attr_accessor :filename
  attr_accessor :name
  attr_accessor :volume
  attr_accessor :pitch
  attr_accessor :position
  attr_accessor :default_volume
  attr_accessor :default_pitch
  #--------------------------------------------------------------------------
  # * Intialize
  #--------------------------------------------------------------------------
  def initialize( filename, name, volume, pitch )
    @filename       = filename
    @name           = name
    @volume         = volume
    @pitch          = pitch  
    @position       = 0
    @default_volume = volume
    @default_pitch  = pitch
  end
  #--------------------------------------------------------------------------
  # * Play Sound
  #--------------------------------------------------------------------------
  def play()
    RPG::BGM.stop()
    RPG::BGM.new( @filename, volume, pitch ).play
  end
  #--------------------------------------------------------------------------
  # * Play Sound at Position
  #--------------------------------------------------------------------------
  def play_at_position( position )
    @position = position
    RPG::BGM.stop()
    RPG::BGM.new( @filename, volume, pitch ).play( position )
  end
  #--------------------------------------------------------------------------
  # * Play Sound ( Default )
  #--------------------------------------------------------------------------
  def default_play()
    RPG::BGM.stop()
    RPG::BGM.new( @filename, @default_volume, @default_pitch ).play
  end
end
 
 
 
 
 
#==============================================================================
# ** Scene_SoundTest
#------------------------------------------------------------------------------
#  This Clas Holds the Scene Information for the SoundTest
#==============================================================================
 
class Scene_SoundTest < Scene_Base
  include DiamondandPlatinum3::SoundTestScene
  #--------------------------------------------------------------------------
  # * Start Processing
  #--------------------------------------------------------------------------
  def start
    super()
    DiamondandPlatinum3::SoundTestScene::perform_temporary_compatibility_resolution()
    
    create_soundtestfiles_hash()
    if is_valid_scene?()
      save_current_bgm()
      create_album_art_hash()
      create_command_windows()
      create_help_window()
      create_soundinfo_window()
      create_numberinput_window()
      set_input_variables()
      setup_scene_intro_animation()   if EnableIntroAnimation
    else
      msgbox_p("There are no Sounds to listen to")
      return_scene()
    end
    
    # Current Selected Sound
    @current_sound_symbol = nil
  end
  #--------------------------------------------------------------------------
  # * Post-Start Processing
  #--------------------------------------------------------------------------
  def post_start
    if is_valid_scene?()
      super()
      animate_intro_scene()   if EnableIntroAnimation
    end
  end  
  #--------------------------------------------------------------------------
  # * Frame Update
  #--------------------------------------------------------------------------
  def update
    super()
   
    @sound_select_cmmdwindows[get_category()].update()
    
    update_sounds_visibility()
    update_window_info_text()
    update_album_art_image()
    update_help_text()
    update_scene_changes()
    update_user_input()
  end
  #--------------------------------------------------------------------------
  # * Pre-Termination Processing
  #--------------------------------------------------------------------------
  def pre_terminate
    super()
   
    @current_map_bgm.replay() unless @current_map_bgm.nil?
  end
  #--------------------------------------------------------------------------
  # * Termination Processing
  #--------------------------------------------------------------------------
  def terminate
    @soundcategory_commandwindow.dispose()  unless @soundcategory_commandwindow.nil?  || @soundcategory_commandwindow.disposed?
    @sound_play_cmmdwindow.dispose()        unless @sound_play_cmmdwindow.nil?        || @sound_play_cmmdwindow.disposed?
    @help_window.dispose()                  unless @help_window.nil?                  || @help_window.disposed?
    @sound_info_window.dispose()            unless @sound_info_window.nil?            || @sound_info_window.disposed?
    @numberinput_window.dispose()           unless @numberinput_window.nil?           || @numberinput_window.disposed?
   
    unless @sound_select_cmmdwindows.nil?
      @sound_select_cmmdwindows.each_key do |category|
        @sound_select_cmmdwindows[category].dispose() unless @sound_select_cmmdwindows[category].disposed?
      end
      @sound_select_cmmdwindows.clear()
    end
    
    unless @album_art_hash.nil?
      @album_art_hash.each_key do |key|
        if @album_art_hash[key].is_a?(Sprite) && !@album_art_hash[key].disposed?
          @album_art_hash[key].bitmap.dispose()
          @album_art_hash[key].dispose()
        end
      end
      @album_art_hash.clear()
    end
   
    super()
    DiamondandPlatinum3::SoundTestScene::revert_temporary_compatibility_resolution()
  end  
  #--------------------------------------------------------------------------
  # * Create SoundTest Files Hash
  #--------------------------------------------------------------------------
  def create_soundtestfiles_hash()
    @soundfiles_hash = {}
    Sounds.each_key do |key|
      if Sounds[key][:conditional_switch] < 1 || $game_switches[Sounds[key][:conditional_switch]]
        category  = check_if_valid_category(Sounds[key][:category]) ? Sounds[key][:category] : "Unaffiliated"
        name      = Sounds[key][:display_name]      
        volume    = Sounds[key][:default_volume]
        pitch     = Sounds[key][:default_pitch]
        (@soundfiles_hash[category] ||= {})[ key ] = SoundTestSound.new( key, name, volume, pitch )
      end
    end
  end
  #--------------------------------------------------------------------------
  # * Save Current BGM
  #--------------------------------------------------------------------------
  def save_current_bgm()
    # Get Current BGM
    @current_map_bgm = RPG::BGM.last
    RPG::BGM.stop()
  end
  #--------------------------------------------------------------------------
  # * Create Album Art Sprites
  #--------------------------------------------------------------------------
  def create_album_art_hash()
    @album_art_hash = { :current_image_name => "", }
    
    if !DefaultBackgroundSpriteFilename.nil? && DefaultBackgroundSpriteFilename != ""
      @album_art_hash[DefaultBackgroundSpriteFilename] = create_background_sprite(DefaultBackgroundSpriteFilename)
      @album_art_hash[DefaultBackgroundSpriteFilename].visible = true
      @album_art_hash[:current_image_name] = DefaultBackgroundSpriteFilename
    end
  end
  #--------------------------------------------------------------------------
  # * Create Background Sprite
  #--------------------------------------------------------------------------
  def create_background_sprite(filename)
    image         = Sprite.new()
    image.bitmap  = Bitmap.new(AlbumArtFolder + filename)
    image.x       = 0
    image.y       = 0
    image.z       = 1
    image.zoom_x  = (Graphics.width.to_f / image.bitmap.width)
    image.zoom_y  = (Graphics.height.to_f / image.bitmap.height)
    image.visible = false
    return image
  end
  #--------------------------------------------------------------------------
  # * Create Command Windows
  #--------------------------------------------------------------------------
  def create_command_windows()
    # Setting Up Command Window for the Sound Category
    @soundcategory_commandwindow = Window_SoundTest_SoundCategoryCommand.new(0, 72)
    command_window_ypos = (@soundcategory_commandwindow.y + @soundcategory_commandwindow.height)
    set_soundcategorycommandwindow_handlers()
    
    # Setting Up Command Windows for Sounds
    @sound_select_cmmdwindows = { }
    Music_Categories.each do |category|
      if !@soundfiles_hash[category].nil?
        cmmdwindow = Window_SoundTest_SoundCommand.new(0, command_window_ypos, category)
        cmmdwindow.height = Graphics.height - command_window_ypos
        cmmdwindow.visible = false
        @sound_select_cmmdwindows[category] = cmmdwindow
      end
    end
    if !@soundfiles_hash["Unaffiliated"].nil?
      cmmdwindow = Window_SoundTest_SoundCommand.new(0, command_window_ypos, "Unaffiliated")
      cmmdwindow.height = Graphics.height - command_window_ypos
      cmmdwindow.visible = false
      @sound_select_cmmdwindows["Unaffiliated"] = cmmdwindow
    end
    
    @sound_select_cmmdwindows[get_first_category()].visible = true
    set_soundcommand_window_handlers()
   
    @sound_select_cmmdwindows.each_key do |category|
      @sound_select_cmmdwindows[category].deactivate()
    end
    
    # Setting Up Command Window for Play Sound
    @sound_play_cmmdwindow = Window_SoundTest_PlayCommand.new(Graphics.width * 0.5, command_window_ypos)
    @sound_play_cmmdwindow.deactivate()
    set_soundplay_window_handlers()
  end
  #--------------------------------------------------------------------------
  # * Set Sound Category Command Handlers
  #--------------------------------------------------------------------------
  def set_soundcategorycommandwindow_handlers()
    Music_Categories.each do |category|
      @soundcategory_commandwindow.set_handler(category.to_sym, method(:deactivate_soundcategory_window)) 
    end
    if !@soundfiles_hash["Unaffiliated"].nil?
      @soundcategory_commandwindow.set_handler("Unaffiliated".to_sym, method(:deactivate_soundcategory_window)) 
    end
  end
  #--------------------------------------------------------------------------
  # * Set Command Handlers
  #--------------------------------------------------------------------------
  def set_soundcommand_window_handlers
    @soundfiles_hash.each_key do |category|
      @soundfiles_hash[category].each_key do |key_name|
        @sound_select_cmmdwindows[category].set_handler(key_name.to_sym, method(:deactivate_soundcommand_window))
      end
    end
  end
  #--------------------------------------------------------------------------
  # * Set SoundPlay Handlers
  #--------------------------------------------------------------------------
  def set_soundplay_window_handlers
    @sound_play_cmmdwindow.set_handler(:play_sound, method(:playsound_command))
    @sound_play_cmmdwindow.set_handler(:volume,     method(:playsound_at_volume))
    @sound_play_cmmdwindow.set_handler(:pitch,      method(:playsound_at_pitch))
    @sound_play_cmmdwindow.set_handler(:position,   method(:playsound_at_position)) if EnablePositionCommand
  end
  #--------------------------------------------------------------------------
  # * Create Help Window
  #--------------------------------------------------------------------------
  def create_help_window()
    # Setting up Help Window
    @help_window = Window_Help.new()
    @help_window.set_text(CategorySelectHelpWindowTextLine1 + "\n" + CategorySelectHelpWindowTextLine2)
  end
  #--------------------------------------------------------------------------
  # * Create SoundInfo Window
  #--------------------------------------------------------------------------
  def create_soundinfo_window()
    # Setting up Sound Info Window
    @sound_info_window_defaultY = @sound_play_cmmdwindow.y + @sound_play_cmmdwindow.height
    @sound_info_window          = Window_SoundInfo.new()
    @sound_info_window.x        = Graphics.width * 0.5
    @sound_info_window.y        = @sound_info_window_defaultY
  end
  #--------------------------------------------------------------------------
  # * Create NumberInput Window
  #--------------------------------------------------------------------------
  def create_numberinput_window()
    # Setting Up Number Input
    @numberinput_window = Window_SoundTest_NumberInput.new()
    @numberinput_window.z = 200
  end
  #--------------------------------------------------------------------------
  # * Set Input Variables
  #--------------------------------------------------------------------------
  def set_input_variables()
    @user_currently_inputting_value     = false
    @currently_entering_volume_value    = false
    @currently_entering_pitch_value     = false
    @currently_entering_position_value  = false
  end
  #--------------------------------------------------------------------------
  # * Setup Scene Intro Animation
  #--------------------------------------------------------------------------
  def setup_scene_intro_animation()
    @background_image.opacity                           = 0     unless @background_image.nil?
    @soundcategory_commandwindow.opacity                = 0
    @sound_select_cmmdwindows[get_first_category()].x  -= 500
    @sound_play_cmmdwindow.x                           += 600
    @help_window.y                                     -= 400
    @sound_info_window.y                               += 300
  end
  #--------------------------------------------------------------------------
  # * Animate Intro Sequence
  #--------------------------------------------------------------------------
  def animate_intro_scene()
    while( true )
      bool1 = animate_sceneintro_background_image()
      bool2 = animate_sceneintro_soundcategorycmmdwindow()
      bool3 = animate_sceneintro_soundselectcmmdwindow()
      bool4 = animate_sceneintro_soundplaycmmdwindow()
      bool5 = animate_sceneintro_helpwindow()
      bool6 = animate_sceneintro_soundinfowindow()
      Graphics.update()
      break if bool1 && bool2 && bool3 && bool4 && bool5 && bool6
    end
  end
  #--------------------------------------------------------------------------
  # * Animate BackgroundImage Opacity for Intro Sequence
  #--------------------------------------------------------------------------
  def animate_sceneintro_background_image()
    return true if @background_image.nil?
    return true if @background_image.opacity == 255
    @background_image.opacity += 5
    return @background_image.opacity == 255
  end
  #--------------------------------------------------------------------------
  # * Animate SoundCategoryCommand Window for Intro Sequence
  #--------------------------------------------------------------------------
  def animate_sceneintro_soundcategorycmmdwindow()
    return true if @soundcategory_commandwindow.opacity == 255
    @soundcategory_commandwindow.opacity += 4
    return @soundcategory_commandwindow.opacity == 255
  end
  #--------------------------------------------------------------------------
  # * Animate SoundSelectCommand Window for Intro Sequence
  #--------------------------------------------------------------------------
  def animate_sceneintro_soundselectcmmdwindow()
    return true if @sound_select_cmmdwindows[get_first_category()].x == 0
    @sound_select_cmmdwindows[get_first_category()].x += 20
    return @sound_select_cmmdwindows[get_first_category()].x == 0
  end
  #--------------------------------------------------------------------------
  # * Animate SoundPlayCommand Window for Intro Sequence
  #--------------------------------------------------------------------------
  def animate_sceneintro_soundplaycmmdwindow()
    return true if @sound_play_cmmdwindow.x == (Graphics.width * 0.5)
    @sound_play_cmmdwindow.x -= 20
    return @sound_play_cmmdwindow.x == (Graphics.width * 0.5)
  end
  #--------------------------------------------------------------------------
  # * Animate Help Window for Intro Sequence
  #--------------------------------------------------------------------------
  def animate_sceneintro_helpwindow()
    return true if @help_window.y == 0
    @help_window.y += 10
    return @help_window.y == 0
  end
  #--------------------------------------------------------------------------
  # * Animate Sound Info Window
  #--------------------------------------------------------------------------
  def animate_sceneintro_soundinfowindow()
    return true if @sound_info_window.y == @sound_info_window_defaultY
    @sound_info_window.y -= 6
    return @sound_info_window.y == @sound_info_window_defaultY
  end
  #--------------------------------------------------------------------------
  # * Deactivate Sound Command Windows
  #--------------------------------------------------------------------------
  def deactivate_soundcommand_windows()
    @sound_select_cmmdwindows[get_category()].deactivate()
    @sound_play_cmmdwindow.deactivate()
    @soundcategory_commandwindow.deactivate()
  end
  #--------------------------------------------------------------------------
  # * Deactivate Sound Category Command Window
  #--------------------------------------------------------------------------
  def deactivate_soundcategory_window()
    @sound_select_cmmdwindows[get_category()].activate()
    @soundcategory_commandwindow.deactivate()
  end
  #--------------------------------------------------------------------------
  # * Deactivate Sound Command Window
  #--------------------------------------------------------------------------
  def deactivate_soundcommand_window(activate_play_window = true)
    @sound_select_cmmdwindows[get_category()].deactivate()
    if activate_play_window
      @sound_play_cmmdwindow.activate()
    else
      @soundcategory_commandwindow.activate()
    end
  end
  #--------------------------------------------------------------------------
  # * Deactivate SoundSelect Command Window
  #--------------------------------------------------------------------------
  def deactivate_soundselectcommand_window()
    @sound_select_cmmdwindows[get_category()].activate()
    @sound_play_cmmdwindow.deactivate()
  end
  #--------------------------------------------------------------------------
  # * Deactivate SoundPlay Command Window
  #--------------------------------------------------------------------------
  def deactivate_soundplaycommand_window()
    @sound_select_cmmdwindows[get_category()].activate()
    @sound_play_cmmdwindow.deactivate()
  end
  #--------------------------------------------------------------------------
  # * Update Sounds Command Visibility
  #--------------------------------------------------------------------------
  def update_sounds_visibility()
    @sound_select_cmmdwindows.each_key do |category|
      @sound_select_cmmdwindows[category].visible = (category == get_category())
    end
  end
  #--------------------------------------------------------------------------
  # * Update Info Window Text
  #--------------------------------------------------------------------------
  def update_window_info_text()
    if @current_sound_symbol != @sound_select_cmmdwindows[get_category()].current_symbol
      @current_sound_symbol = @sound_select_cmmdwindows[get_category()].current_symbol      
    
      text  = Sounds[@current_sound_symbol.to_s][:info_line1].gsub("\n", "") + "\n"
      text += Sounds[@current_sound_symbol.to_s][:info_line2].gsub("\n", "") + "\n"
      text += Sounds[@current_sound_symbol.to_s][:info_line3].gsub("\n", "") + "\n"
      text += Sounds[@current_sound_symbol.to_s][:info_line4].gsub("\n", "")
      @sound_info_window.draw_text_soundinfo(text)
    end
  end
  #--------------------------------------------------------------------------
  # * Update Album Art Image
  #--------------------------------------------------------------------------
  def update_album_art_image()
    if @soundcategory_commandwindow.active
      return if @album_art_hash[:current_image_name] == DefaultBackgroundSpriteFilename
      unless @album_art_hash[DefaultBackgroundSpriteFilename].nil?
        @album_art_hash[@album_art_hash[:current_image_name]].visible = false
        @album_art_hash[:current_image_name] = DefaultBackgroundSpriteFilename
        @album_art_hash[DefaultBackgroundSpriteFilename].visible = true
      end
      
    else
      filename = Sounds[@current_sound_symbol.to_s][:album_art_filename]
      if filename != @album_art_hash[:current_image_name]
        filename = DefaultBackgroundSpriteFilename if filename == ""
        return if filename == "" || filename == @album_art_hash[:current_image_name]
        @album_art_hash[@album_art_hash[:current_image_name]].visible = false if @album_art_hash[@album_art_hash[:current_image_name]] != ""
        @album_art_hash[:current_image_name] = filename
        if @album_art_hash[filename].nil?
          @album_art_hash[filename] = create_background_sprite(filename)
        end
        @album_art_hash[filename].visible = true
      end
    end
  end
  #--------------------------------------------------------------------------
  # * Update Help Text
  #--------------------------------------------------------------------------
  def update_help_text()
    # If SoundCategory Command Window is Active
    if @soundcategory_commandwindow.active
      @help_window.set_text(CategorySelectHelpWindowTextLine1 + "\n" + CategorySelectHelpWindowTextLine2)
    # If SoundSelect Command Window is Active
    elsif @sound_select_cmmdwindows[get_category()].active
      @help_window.set_text(SoundSelectHelpWindowTextLine1 + "\n" + SoundSelectHelpWindowTextLine2)
    # If NumberInput Window is Active
    elsif @numberinput_window.active
      @help_window.set_text(NumberInputHelpWindowTextLine1 + "\n" + NumberInputHelpWindowTextLine2)
     # If Hovering Over PlaySound
    elsif @sound_play_cmmdwindow.current_symbol == :play_sound
      @help_window.set_text(PlaySoundOptionHelpWindowTextLine1 + "\n" + PlaySoundOptionHelpWindowTextLine2)
     # If Hovering Over Volume Input
    elsif @sound_play_cmmdwindow.current_symbol == :volume
      @help_window.set_text(VolumeOptionHelpWindowTextLine1 + "\n" + VolumeOptionHelpWindowTextLine2)
     # If Hovering Over Pitch Input
    elsif @sound_play_cmmdwindow.current_symbol == :pitch
      @help_window.set_text(PitchOptionHelpWindowTextLine1 + "\n" + PitchOptionHelpWindowTextLine2)
     # If Hovering Over Position Input
    else
      @help_window.set_text(PositionOptionHelpWindowTextLine1 + "\n" + PositionOptionHelpWindowTextLine2)
    end
  end
  #--------------------------------------------------------------------------
  # * Update Scene Changes
  #--------------------------------------------------------------------------
  def update_scene_changes()
    if Input.trigger?(:B)
      Sound.play_cancel()
      return_scene()                          if @soundcategory_commandwindow.active()
      deactivate_soundcommand_window(false)   if @sound_select_cmmdwindows[get_category()].active
      deactivate_soundplaycommand_window()    if @sound_play_cmmdwindow.active
    end
  end
  #--------------------------------------------------------------------------
  # * Update User Input
  #--------------------------------------------------------------------------
  def update_user_input()
    if @user_currently_inputting_value && @numberinput_window.completed
      receive_volume_value()    if @currently_entering_volume_value
      receive_pitch_value()     if @currently_entering_pitch_value
      receive_position_value()  if @currently_entering_position_value  
    end
  end
  #--------------------------------------------------------------------------
  # * Play Sound Command
  #--------------------------------------------------------------------------
  def playsound_command()
    @soundfiles_hash[get_category()][@current_sound_symbol.to_s].default_play()    
    @sound_play_cmmdwindow.activate()
  end
  #--------------------------------------------------------------------------
  # * Play Sound 'At Volume' Command
  #--------------------------------------------------------------------------
  def playsound_at_volume()
    deactivate_soundcommand_windows()
    @user_currently_inputting_value = true
    @currently_entering_volume_value = true
    number = @soundfiles_hash[get_category()][@current_sound_symbol.to_s].volume
    @numberinput_window.start( number, 3 )
  end
  #--------------------------------------------------------------------------
  # * Play Sound 'At Pitch' Command
  #--------------------------------------------------------------------------
  def playsound_at_pitch()
    deactivate_soundcommand_windows()
    @user_currently_inputting_value = true
    @currently_entering_pitch_value = true
    number = @soundfiles_hash[get_category()][@current_sound_symbol.to_s].pitch
    @numberinput_window.start( number, 3 )
  end
  #--------------------------------------------------------------------------
  # * Play Sound 'At Position' Command
  #--------------------------------------------------------------------------
  def playsound_at_position()
    @currently_entering_position_value = true
    @user_currently_inputting_value = true
    deactivate_soundcommand_windows()
    number = @soundfiles_hash[get_category()][@current_sound_symbol.to_s].position
    @numberinput_window.start( number, 9 )
  end
  #--------------------------------------------------------------------------
  # * Receive Volume Value
  #--------------------------------------------------------------------------
  def receive_volume_value()
    if @numberinput_window.processed_ok
      @soundfiles_hash[get_category()][@current_sound_symbol.to_s].volume = @numberinput_window.result
      @soundfiles_hash[get_category()][@current_sound_symbol.to_s].play()
    end
    @sound_play_cmmdwindow.activate()
    set_input_variables()
  end
  #--------------------------------------------------------------------------
  # * Receive Pitch Value
  #--------------------------------------------------------------------------
  def receive_pitch_value()
    if @numberinput_window.processed_ok
      @soundfiles_hash[get_category()][@current_sound_symbol.to_s].pitch = @numberinput_window.result
      @soundfiles_hash[get_category()][@current_sound_symbol.to_s].play()
    end
    @sound_play_cmmdwindow.activate()
    set_input_variables()
  end
  #--------------------------------------------------------------------------
  # * Receive Position Value
  #--------------------------------------------------------------------------
  def receive_position_value()
    if @numberinput_window.processed_ok
      @soundfiles_hash[get_category()][@current_sound_symbol.to_s].play_at_position( @numberinput_window.result )
    end
    @sound_play_cmmdwindow.activate()
    set_input_variables()
  end
  #--------------------------------------------------------------------------
  # * Check if Valid Category
  #--------------------------------------------------------------------------
  def check_if_valid_category(category)
    return Music_Categories.include?(category)
  end
  #--------------------------------------------------------------------------
  # * Get Current Category Text
  #--------------------------------------------------------------------------
  def get_category()
    return @soundcategory_commandwindow.current_symbol.to_s
  end
  #--------------------------------------------------------------------------
  # * Get First Category Text
  #--------------------------------------------------------------------------
  def get_first_category()
    return @soundcategory_commandwindow.get_first_command_name
  end
  #--------------------------------------------------------------------------
  # * Is Valid Scene?
  #--------------------------------------------------------------------------
  def is_valid_scene?()
    return !@soundfiles_hash.empty?
  end
end
 
 
if DiamondandPlatinum3::SoundTestScene::EnableMenuOption
  #==============================================================================
  # ** Window_MenuCommand
  #------------------------------------------------------------------------------
  #  This command window appears on the menu screen.
  #==============================================================================
   
  class Window_MenuCommand < Window_Command
    #--------------------------------------------------------------------------
    # * Add Exit Game to Command List
    #--------------------------------------------------------------------------
    alias dp3_soundtestscene_windowmenucommd_addgameendcmmd_ofa     add_game_end_command
    #--------------------------------------------------------------------------
    def add_game_end_command
      enabled = (DiamondandPlatinum3::SoundTestScene::EnableSwitchID > 0) ? $game_switches[DiamondandPlatinum3::SoundTestScene::EnableSwitchID] : true
      add_command(DiamondandPlatinum3::SoundTestScene::MenuCommandText, :dp3_sound_test, enabled)
      
      dp3_soundtestscene_windowmenucommd_addgameendcmmd_ofa() # Call Original Method
    end
  end
   
   
   
  #==============================================================================
  # ** Scene_Menu
  #------------------------------------------------------------------------------
  #  This class performs the menu screen processing.
  #==============================================================================
   
  class Scene_Menu < Scene_MenuBase
    #--------------------------------------------------------------------------
    # * Create Command Window
    #--------------------------------------------------------------------------
    alias dp3_soundtestscene_scenemenu_creatcmmdwind_ofa      create_command_window
    #--------------------------------------------------------------------------
    def create_command_window
      dp3_soundtestscene_scenemenu_creatcmmdwind_ofa() # Call original Method  
      @command_window.set_handler(:dp3_sound_test,    method(:command_soundtest))
    end
    #--------------------------------------------------------------------------
    # * Command Sound Test
    #--------------------------------------------------------------------------
    def command_soundtest
      SceneManager.call(Scene_SoundTest)
    end
  end
  
end
 
 
 
#==============================================================================
# ** SoundCategory_Command
#------------------------------------------------------------------------------
# The Command Window that is used when selecting a sound category
#==============================================================================
 
class Window_SoundTest_SoundCategoryCommand < Window_Command
  #--------------------------------------------------------------------------
  # * Get Window Width
  #--------------------------------------------------------------------------
  def window_width
    return Graphics.width
  end
  #--------------------------------------------------------------------------
  # * Get Digit Count
  #--------------------------------------------------------------------------
  def col_max
    return DiamondandPlatinum3::SoundTestScene::MaxCategoryHorizontalCommands
  end
  #--------------------------------------------------------------------------
  # * Get Number of Lines to Show
  #--------------------------------------------------------------------------
  def visible_line_number
    return (SceneManager.scene.instance_variable_get('@soundfiles_hash').size.to_f / col_max).ceil
  end
  #--------------------------------------------------------------------------
  # * Get Spacing for Items Arranged Side by Side
  #--------------------------------------------------------------------------
  def spacing
    return 4
  end
  #--------------------------------------------------------------------------
  # * Get First Command Name
  #--------------------------------------------------------------------------
  def get_first_command_name()
    return @list[0][:name]
  end
  #--------------------------------------------------------------------------
  # * Make Command List
  #--------------------------------------------------------------------------
  def make_command_list
    soundfiles_hash = SceneManager.scene.instance_variable_get('@soundfiles_hash')
    DiamondandPlatinum3::SoundTestScene::Music_Categories.each do |category|     
      add_command(category, category.to_sym) if !soundfiles_hash[category].nil?
    end
    command = "Unaffiliated"
    add_command(command, command.to_sym) if !soundfiles_hash[command].nil?
  end  
end


#==============================================================================
# ** SoundTest_Command
#------------------------------------------------------------------------------
# The Command Window that is used when selecting a sound
#==============================================================================
 
class Window_SoundTest_SoundCommand < Window_Command
  #--------------------------------------------------------------------------
  # * Initialize
  #--------------------------------------------------------------------------
  attr_reader :category
  def initialize(*args, a_category)
    @category = a_category
    super(*args)
  end
  #--------------------------------------------------------------------------
  # * Get Window Width
  #--------------------------------------------------------------------------
  def window_width
    return Graphics.width * 0.5
  end
  #--------------------------------------------------------------------------
  # * Make Command List
  #--------------------------------------------------------------------------
  def make_command_list
    sounds_hash = SceneManager.scene.instance_variable_get('@soundfiles_hash')
    sounds_hash[@category].each_key do |key_name|     
      add_command(sounds_hash[@category][key_name].name, key_name.to_sym)
    end
  end  
end
 
 
#==============================================================================
# ** PlaySound_Command
#------------------------------------------------------------------------------
# The Command Window that is used for playing a sound
#==============================================================================
 
class Window_SoundTest_PlayCommand < Window_Command
  #--------------------------------------------------------------------------
  # * Get Window Width
  #--------------------------------------------------------------------------
  def window_width
    return Graphics.width * 0.5
  end
  #--------------------------------------------------------------------------
  # * Make Command List
  #--------------------------------------------------------------------------
  def make_command_list
    add_command("Play Sound", :play_sound)
    add_command("Volume",     :volume)
    add_command("Pitch",      :pitch)
    add_command("Position",   :position) if DiamondandPlatinum3::SoundTestScene::EnablePositionCommand
  end  
end
 
 
 
 
#==============================================================================
# ** Window_SoundInfo
#------------------------------------------------------------------------------
#  This message window is used to display Sound Information
#==============================================================================
 
class Window_SoundInfo < Window_Base
  #--------------------------------------------------------------------------
  # * Object Initialization
  #--------------------------------------------------------------------------
  def initialize
    super(0, 0, window_width, window_height)
    self.z = 200
  end
  #--------------------------------------------------------------------------
  # * Set Font
  #--------------------------------------------------------------------------
  def set_font
    contents.font.size = 18
  end
  #--------------------------------------------------------------------------
  # * Get Window Width
  #--------------------------------------------------------------------------
  def window_width
    return Graphics.width * 0.5
  end
  #--------------------------------------------------------------------------
  # * Get Window Height
  #--------------------------------------------------------------------------
  def window_height
    return Graphics.height - SceneManager.scene.instance_variable_get('@sound_info_window_defaultY')
  end  
  #--------------------------------------------------------------------------
  # * Draw Text
  #--------------------------------------------------------------------------
  def draw_text_soundinfo(text)
    contents.clear
    set_font()
    draw_text_ex(0, 0, word_wrapping(text))
  end  
  #--------------------------------------------------------------------------
  # * Draw Text with Control Characters
  #--------------------------------------------------------------------------
  def draw_text_ex(x, y, text)
    text = convert_escape_characters(text)
    pos = {:x => x, :y => y, :new_x => x, :height => calc_line_height(text)}
    until text.empty?
      c = text.slice!(0, 1)
      if c == "\n"
        pos[:x] = pos[:new_x]
        pos[:y] += pos[:height]
        pos[:height] = calc_line_height(text)
      else
        text_width = text_size(c).width
        draw_text(pos[:x], pos[:y], text_width * 2, pos[:height], c)
        pos[:x] += text_width
      end
    end
  end
  #--------------------------------------------------------------------------
  # * Word Wrapping
  #--------------------------------------------------------------------------
  def word_wrapping(text, pos = 0)
   
    # Current Text Position
    current_text_position = 0    
   
    for i in 0..(text.length - 1)
      if text[i] == "\n"
        current_text_position = 0
        next
      end
     
      # Current Position += character width
      current_text_position += contents.text_size(text[i]).width
     
      # If Current Position > Window Width
      if (pos + current_text_position) >= (contents.width)
        # Then Format the Sentence to fit Line
        current_element = i
        while(text[current_element] != " ")
          break if current_element == 0
          current_element -= 1
        end
       
        temp_text = ""
        for j in 0..(text.length - 1)
          temp_text += text[j]
          temp_text += "\n" if j == current_element
        end
        text = temp_text
        i = current_element
        current_text_position = 0
      end
    end
    return text
  end
end
 
 
 
#==============================================================================
# ** Window_NumberInput
#------------------------------------------------------------------------------
#  This window is used for the event command [Input Number].
#==============================================================================
 
class Window_SoundTest_NumberInput < Window_NumberInput
  #--------------------------------------------------------------------------
  # * Public Instance Variables
  #--------------------------------------------------------------------------
  attr_reader :result       # The Result of User Input
  attr_reader :completed    # User Finished Input Processing?
  attr_reader :processed_ok # User Did not Cancel User Input?
  #--------------------------------------------------------------------------
  # * Initialize
  #--------------------------------------------------------------------------
  def initialize()
    super( self )
    @result       = 0
    @completed    = true
    @processed_ok = false
  end
  #--------------------------------------------------------------------------
  # * Start Input Processing
  #--------------------------------------------------------------------------
  def start( number, digits )
    @digits_max = digits
    @number = number
    @index = 0
    @completed = false
    update_placement
    create_contents
    refresh
    open
    activate
  end
  #--------------------------------------------------------------------------
  # * Update Window Position
  #--------------------------------------------------------------------------
  def update_placement
    self.width = @digits_max * 20 + padding * 2
    self.height = fitting_height(1)
    self.x = (Graphics.width - width) * 0.5
    self.y = 192
  end
  #--------------------------------------------------------------------------
  # * Processing When OK Button Is Pressed
  #--------------------------------------------------------------------------
  def process_ok
    Sound.play_ok
    @result = @number
    @completed = true
    @processed_ok = true
    deactivate
    close
  end
  #--------------------------------------------------------------------------
  # * Processing When Cancel Button Is Pressed
  #--------------------------------------------------------------------------
  def process_cancel
    Sound.play_cancel
    @completed    = true
    @processed_ok = false
    deactivate
    close
  end
end