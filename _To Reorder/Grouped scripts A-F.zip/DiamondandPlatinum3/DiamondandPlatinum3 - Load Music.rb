# Play BGM on loading menu
# Code snippet by DiamondandPlatinum3

class Scene_Load < Scene_File
#======================================
#	 Editable Region
#======================================
BGM_MUSIC_FOR_LOAD_SCREEN = "Scene6"
BGM_VOLUME				 = 100
BGM_PITCH				 = 100
#======================================




alias play_music_onloadscreen first_savefile_index
def first_savefile_index
	RPG::BGM.new(BGM_MUSIC_FOR_LOAD_SCREEN, BGM_VOLUME, BGM_PITCH).play
	play_music_onloadscreen
end
end