#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
#             Sound Message System Add-on
#             Version: 1.0
#             Authors: DiamondandPlatinum3, Modern Algebra
#             Date: September 23, 2012
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#  Description:
#
#    This script adds on to the default message system allowing you to use
#    a new escape character to generate an SE whilst displaying text and to
#    have a constant SE play whilst scrolling through text.
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#------------------------------------------------------------------------------
#  Instructions:
#  
#     -  If you want to have an SE play whilst your text is progressing, then 
#        edit your options in the editable region
#
#     -  In order to have an SE play during text, you simply enter an escape 
#        code similar to the colour code.
#
#           \se[]
#
#        Inside the brackets you input the sound effect that you want to play.
#        Examples: 
#
#             \se[Jump1]
#             \se["Jump1"]
#             \se[Jump1, 80, 100]         <= Including Volume and Pitch
#             \se["Jump1", 20, 140]
#
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
module DP3_SoundMessageCodes
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
#                                                        -= 
#                 Editable Region        ////            ==
#                                                        =-
#-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=


  # If this switch ID is turned on, your Message boxes will play
  # The SE you have selected as your text progresses
  TurnOnCharacterSE_SwitchID = 10
  
  
  
  
  SEtoPlayWhenDisplayingText = "Bow1"
  SEVolume                   = 80
  SEPitch                    = 80..120 # This means that a pitch between 80-120
                                       # will play on each hit.
                                       # If you want a difinitive number, you can
                                       # give it a normal number same as volume.
  
  
  
  
  # It sounds pretty bad to hear it play on EVERY single character, 
  # so here you get to choose how many characters along it must be before
  # playing the TextDisplaySE  
  Position_For_SEtoPlay = 5 
  
  
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
end # of Editable Region
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
#---------------------------------------------------------
# No touchie past here unless you know what you are 
# doing. Failure to heed this warning could cause your 
# computer to yell and scream at you. 
#
# Edit at your own risk.
#--------------------------------------------------------











#==============================================================================
# ** Window_Base
#------------------------------------------------------------------------------
#  This is a super class of all windows within the game.
#==============================================================================

class Window_Base < Window
  #--------------------------------------------------------------------------
  # * Alias Listings
  #--------------------------------------------------------------------------
  alias dp3_procmessound_winbase_procesccode_idkg57     process_escape_character
  #--------------------------------------------------------------------------
  # * Control Character Processing
  #--------------------------------------------------------------------------
  def process_escape_character(code, text, pos)
    case code.upcase
    when 'SE'
      #!---------- Code By Modern Algebra ----------!#
      text.sub!(/\[\s*\"?([^\",\]]+)\"?(.*?)\]/, "")
      filename = $1
      digits = $2.scan(/\d+/).collect {|i| i.to_i }
      digits = digits[0, 2] if digits.size > 2
      RPG::SE.new( filename, *digits ).play
      #!--------------------------------------------!#
    else
      # Call Original Method
      dp3_procmessound_winbase_procesccode_idkg57(code, text, pos)
    end # Case
  end # Function
end # Class






#==============================================================================
# ** Window_Message
#------------------------------------------------------------------------------
#  This message window is used to display text.
#==============================================================================

class Window_Message < Window_Base
  #--------------------------------------------------------------------------
  # * Alias Listings
  #--------------------------------------------------------------------------
  alias dp3_procmessound_winmes_init_idkg57          initialize
  alias dp3_procmessound_winmes_procalltxt_idkg57    process_all_text
  alias dp3_procmessound_winmes_procnormchar_idkg57  process_normal_character
  #--------------------------------------------------------------------------
  # * Object Initialization
  #--------------------------------------------------------------------------
  def initialize    
    # Call Original Method
    dp3_procmessound_winmes_init_idkg57
    
    # Initialise text count
    @dp3_soundmessage_textcount = 0
  end
  #--------------------------------------------------------------------------
  # * Process All Text
  #--------------------------------------------------------------------------
  def process_all_text
    
    # Call Original Method
    dp3_procmessound_winmes_procalltxt_idkg57
    
    # Set Count Back to Zero
    @dp3_soundmessage_textcount = 0
  end
  #--------------------------------------------------------------------------
  # * Normal Character Processing
  #--------------------------------------------------------------------------
  def process_normal_character(*args)
    
    # Call original Method
    dp3_procmessound_winmes_procnormchar_idkg57(*args)
    
    # Increment text position
    @dp3_soundmessage_textcount += 1
    
    # Are we allowed to play an SE?
    if $game_switches[DP3_SoundMessageCodes::TurnOnCharacterSE_SwitchID]
      # Find out if position is equal to one specified
      if @dp3_soundmessage_textcount == DP3_SoundMessageCodes::Position_For_SEtoPlay
        @dp3_soundmessage_textcount = 0
        se  = DP3_SoundMessageCodes::SEtoPlayWhenDisplayingText
        vol = DP3_SoundMessageCodes::SEVolume
        pit = DP3_SoundMessageCodes::SEPitch
        pit = rand(pit.max - pit.min) + pit.min if pit.is_a?(Range)
        RPG::SE.new(se, vol, pit).play
      end # If Position == TextCount
    end # If $game_switches Statement
  end # Function
end # Class