#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
#             Play SE On Balloon Pop-Up
#             Version: 1.0
#             Author: DiamondandPlatinum3
#             Date: July 31, 2012
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#  Description:
#
#    This script allows you to play an SE (Sound Effect) when a ballon icon 
#    pops-up above someones head.
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#------------------------------------------------------------------------------
#  Instructions:
#  
#     -  All you have to do is go into the editable region and change the 
#        appropriate settings to suit your needs. This includes which SE plays
#        depending on the balloon icon that is being shown.
#
#     -  If you do not wish for an SE to play on any specific balloon icon,
#        simply set the value to nil.
#
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
module BalloonSoundOptions
  
# Turn this Switch On if you do not wish for soundeffects to play on balloon
Event_Switch_ID = 10
  
                # SE to Play, Volume, Pitch
Exclamation_SE  = [ "Raise1",   80,   100 ] # SE played with Exclamation Balloon
Question_SE     = [ "Confuse",  80,   100 ] # SE played with Question Balloon
Music_Note_SE   = [ "Sound1",   80,   100 ] # SE played with Music Note Balloon
Heart_SE        = [ "Recovery", 80,   100 ] # SE played with Heart Balloon
Anger_SE        = [ "Buzzer1",  80,   100 ] # SE played with Anger Balloon
Sweat_SE        = [ "Fall",     80,   100 ] # SE played with Sweat Balloon
Cobweb_SE       = [ "Sand",     80,   100 ] # SE played with Cobweb Balloon
Silence_SE      = [ "Silence",  80,   100 ] # SE played with Silence Balloon
Lightbulb_SE    = [ "Stare",    80,   100 ] # SE played with Lightbulb Balloon
Zzz_SE          = [ nil,        80,   100 ] # SE played with Zzz Balloon
  
  
end
#==============================================================================
# ** Sprite_Character
#------------------------------------------------------------------------------
#  This sprite is used to display characters. It observes an instance of the
# Game_Character class and automatically changes sprite state.
#==============================================================================

class Sprite_Character < Sprite_Base
  #--------------------------------------------------------------------------
  # * Start Balloon Icon Display
  #--------------------------------------------------------------------------
  alias dp3_seonballoon_spritecharacter_startballoon_vcxs       start_balloon
  def start_balloon
    unless $game_switches[BalloonSoundOptions::Event_Switch_ID]
    #--------------------------------------------------------
      case @balloon_id
      when 1
        RPG::SE.new(*BalloonSoundOptions::Exclamation_SE).play   if BalloonSoundOptions::Exclamation_SE[0]
      when 2
        RPG::SE.new(*BalloonSoundOptions::Question_SE).play      if BalloonSoundOptions::Question_SE[0]
      when 3
        RPG::SE.new(*BalloonSoundOptions::Music_Note_SE).play    if BalloonSoundOptions::Music_Note_SE[0]
      when 4
        RPG::SE.new(*BalloonSoundOptions::Heart_SE).play         if BalloonSoundOptions::Heart_SE[0]
      when 5
        RPG::SE.new(*BalloonSoundOptions::Anger_SE).play         if BalloonSoundOptions::Anger_SE[0]
      when 6
        RPG::SE.new(*BalloonSoundOptions::Sweat_SE).play         if BalloonSoundOptions::Sweat_SE[0]
      when 7
        RPG::SE.new(*BalloonSoundOptions::Cobweb_SE).play        if BalloonSoundOptions::Cobweb_SE[0]
      when 8
        RPG::SE.new(*BalloonSoundOptions::Silence_SE).play       if BalloonSoundOptions::Silence_SE[0]
      when 9
        RPG::SE.new(*BalloonSoundOptions::Lightbulb_SE).play     if BalloonSoundOptions::Lightbulb_SE[0]
      when 10
        RPG::SE.new(*BalloonSoundOptions::Zzz_SE).play           if BalloonSoundOptions::Zzz_SE[0]
      end
    #--------------------------------------------------------
    end
    dp3_seonballoon_spritecharacter_startballoon_vcxs() # Call Original Method
  end
end