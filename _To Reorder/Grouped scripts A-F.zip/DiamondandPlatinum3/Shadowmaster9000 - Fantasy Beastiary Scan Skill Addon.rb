=begin
===============================================================================
 Fantasy Bestiary Scan Skill Add-On v1.0 (28/6/2015)
-------------------------------------------------------------------------------
 Created By: Shadowmaster/Shadowmaster9000/Shadowpasta
 (www.crimson-castle.co.uk)

===============================================================================
 Information
-------------------------------------------------------------------------------
 This script is an add-on for my Fantasy Bestiary script. It allows players
 to reveal enemies in the Bestiary by using skills and items with the scan
 effect attached to them.
 
===============================================================================
 How to Use
-------------------------------------------------------------------------------
 Place this script under Materials and below Fantasy Bestiary.

===============================================================================
 Note Tags
-------------------------------------------------------------------------------
 Place any of these note tags within a database object.
 
 -------------------
 Item/Skill Notetags
 -------------------
 <bestiary scan: n%>
 Makes the skill/item reveal the enemy in the Bestiary, where n is the chance
 of that effect succeeding. If you want to make the skill/item always succeed,
 set the value to 100.
 
 -------------------
 Enemy Notetags
 -------------------
 <scan chance: +n%>
 <scan chance: -n%>
 Modifies the chance of successful scans from skills/items, where n is the
 number that the chance of the scan succeeding will increase (or decrease)
 by. Setting the value to -100 will make the enemy unscannnable.
 
===============================================================================
 Required
-------------------------------------------------------------------------------
 Fantasy Bestiary
 (http://www.rpgmakervxace.net/topic/14951-fantasy-bestiary/)
 
 This script is intended to be an add-on for Fantasy Bestiary. This script is
 not a standalone script.

===============================================================================
 Change log
-------------------------------------------------------------------------------
 v1.0: First release. (28/6/2013)

===============================================================================
 Terms of Use
-------------------------------------------------------------------------------
 * Free to use for both commercial and non-commerical projects.
 * Credit me if used.
 * Do not claim this as your own.
 * You're free to post this on other websites, but please credit me and keep
 the header intact.
 * If you want to release any modifications/add-ons for this script, the
 add-on script must use the same Terms of Use as this script uses. (But you
 can also require any users of your add-on script to credit you in their game
 if they use your add-on script.)
 * If you're making any compatibility patches or scripts to help this script
 work with other scripts, the Terms of Use for the compatibility patch does
 not matter so long as the compatibility patch still requires this script to
 run.
 * If you want to use your own seperate Terms of Use for your version or
 add-ons of this script, you must contact me at http://www.rpgmakervxace.net
 or www.crimson-castle.co.uk

===============================================================================
=end
$imported = {} if $imported.nil?
$imported["FantasyBestiaryScan"] = true
if $imported["FantasyBestiary3.7"]

#==============================================================================
# ** DataManager
#------------------------------------------------------------------------------
#  This module manages the database and game objects. Almost all of the 
# global variables used by the game are initialized by this module.
#==============================================================================

module DataManager
  #--------------------------------------------------------------------------
  # * Load Database
  #--------------------------------------------------------------------------
  class <<self; alias load_database_bestiaryscan load_database; end
  def self.load_database
    load_database_bestiaryscan
    load_notetags_bestiaryscan
  end
  #--------------------------------------------------------------------------
  # * Load Notetags for Fantasy Bestiary
  #--------------------------------------------------------------------------
  def self.load_notetags_bestiaryscan
    groups = [$data_skills, $data_items, $data_enemies]
    for group in groups
      for obj in group
        next if obj.nil?
        obj.load_notetags_bestiaryscan
      end
    end
  end
end

#==============================================================================
# ** RPG::UsableItem
#------------------------------------------------------------------------------
#  A Superclass of Skill and Item.
#==============================================================================

class RPG::UsableItem
  #--------------------------------------------------------------------------
  # * Public Instance Variables
  #--------------------------------------------------------------------------
  attr_accessor :scan_chance
  #--------------------------------------------------------------------------
  # * Defining Pierce Guard Attribute
  #--------------------------------------------------------------------------
  def load_notetags_bestiaryscan
    @scan_chance = 0
    if @note =~ /<bestiary scan: (.*)%>/
      @scan_chance = $1.to_f
      @scan_chance /= 100
      @scan_chance = 1 if @scan_chance > 1
      @scan_chance = -1 if @scan_chance < -1
    end
  end
end

#==============================================================================
# ** RPG::Enemy
#------------------------------------------------------------------------------
#  This class defines attributes for enemies. Its superclass is RPG::BaseItem.
#==============================================================================

class RPG::Enemy
  #--------------------------------------------------------------------------
  # * Public Instance Variables
  #--------------------------------------------------------------------------
  attr_accessor :scan_mod
  #--------------------------------------------------------------------------
  # * Defining Attributes
  #--------------------------------------------------------------------------
  def load_notetags_bestiaryscan
    @scan_mod = 0
    if @note =~ /<scan chance: (.*)>/i
      @scan_mod = $1.to_f
      @scan_mod /= 100
      @scan_mod = 1 if @scan_mod > 1
      @scan_mod = -1 if @scan_mod < -1
    end
  end
end

#==============================================================================
# ** Game_Battler
#------------------------------------------------------------------------------
#  A battler class with methods for sprites and actions added. This class 
# is used as a super class of the Game_Actor class and Game_Enemy class.
#==============================================================================

class Game_Battler < Game_BattlerBase
  #--------------------------------------------------------------------------
  # * Effect of Skill/Item on Using Side
  #--------------------------------------------------------------------------
  alias item_user_effect_bestiary_scan item_user_effect
  def item_user_effect(user, item)
    apply_scan_effect(user, item)
    item_user_effect_bestiary_scan(user, item)
  end
  #--------------------------------------------------------------------------
  # * Apply Bestiary Scanning Effect
  #--------------------------------------------------------------------------
  def apply_scan_effect(user, item)
    if item.scan_chance > 0 && self.enemy?
      total_scan_chance = self.enemy.scan_mod + item.scan_chance
      if rand < total_scan_chance
        $game_party.add_found(self.enemy.id)
        $game_party.enemies_revealed.push(self.enemy.id) unless $game_party.enemies_hidden.include?(self.enemy.id)
      end
    end
  end
end
end