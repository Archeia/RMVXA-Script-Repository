#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Fire Emblem / Disgaea Weapon System 'Weapon Level Status Command' Add-on for GubiD's Tactical Battle System
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
class Commands_All < TBS_Win_Actor
 
  # Editable Section
  Weapon_Level_Status    = "Weapon Level Status"                             # Command Title
  Help_WeaponLevelStatus = "Shows the Active Battler's Weapon Skills Status" # Command 'Help' Text
 
 
 
  #----------------------------------------------------------------------------
  # Alias Listings
  #----------------------------------------------------------------------------
  alias dp3_firemblemdisgaeaweaponsystem_gtbs_makecommandlist    make_command_list
  alias dp3_firemblemdisgaeaweaponsystem_gtbs_updatehelp         update_help
  #--------------------------------------------------------------------------
  # * Aliased Method: Create Command List
  #--------------------------------------------------------------------------
  def make_command_list(*args)
    return unless @actor
    dp3_firemblemdisgaeaweaponsystem_gtbs_makecommandlist(*args) # Call Original Method
   
    # Add in Weapon Level Status Command just after Status command
    temp_list = []
    @list.each do |command|
      temp_list.push(command)
      if command[:symbol] == :status
        temp_list.push({:name=>Weapon_Level_Status, :symbol=>:weapon_level_status, :enabled=>true, :ext=>nil})
      end
    end
    @list = temp_list
  end
  #--------------------------------------------------------------------------
  # * Aliased Method: Update Help
  #--------------------------------------------------------------------------
  def update_help
    if current_symbol == :weapon_level_status
      @help_window.set_text(Help_WeaponLevelStatus)
    else
      dp3_firemblemdisgaeaweaponsystem_gtbs_updatehelp() # Call Original Method
    end
  end
end


#=============================================================
# Scene Battle (TBS Mode)
#=============================================================
class Scene_Battle_TBS < Scene_Base
  #----------------------------------------------------------------------------
  # Alias Listings
  #----------------------------------------------------------------------------
  alias dp3_firemblemdisgaeaweaponsystem_gtbs_createwindows      create_windows
  alias dp3_firemblemdisgaeaweaponsystem_gtbs_createcommdwin     create_command_window
  alias dp3_firemblemdisgaeaweaponsystem_gtbs_update             update
  #----------------------------------------------------------------------------
  # Aliased Method: Create Windows
  #----------------------------------------------------------------------------
  def create_windows(*args)
    dp3_firemblemdisgaeaweaponsystem_gtbs_createwindows(*args) # Call Original Method
   
    @windows[:weap_lev_status_win] = Window_WeaponLevelStatus.new($game_actors[1])
    @windows[:weap_lev_status_win].back_opacity = GTBS::CONTROL_OPACITY
    @windows[:weap_lev_status_win].visible = false
    @windows[:weap_lev_status_win].active = false
  end
  #----------------------------------------------------------------------------
  # Aliased Method: Create Command Window
  #----------------------------------------------------------------------------
  def create_command_window(*args)
    dp3_firemblemdisgaeaweaponsystem_gtbs_createcommdwin(*args) # Call Original Method
    @windows[Menu_Actor].set_handler(:weapon_level_status, method(:open_weapon_level_status_window))
  end
  #----------------------------------------------------------------------------
  # Aliased Method: Update Process
  #----------------------------------------------------------------------------
  def update(*args)
    if @windows[:weap_lev_status_win].active
      update_weapon_level_status_window()
      super()
    else
      dp3_firemblemdisgaeaweaponsystem_gtbs_update(*args) # Call Original Method
    end
  end
  #----------------------------------------------------------------------------
  # New Method: Open Weapon Level Status Window for battler
  #----------------------------------------------------------------------------
  def open_weapon_level_status_window()
    Sound.play_decision
    @windows[Menu_Actor].hide()
    @windows[Win_Help].hide()
    @windows[Win_Status].hide()
   
    @windows[:weap_lev_status_win].actor = @active_battler
    @windows[:weap_lev_status_win].refresh()
    @windows[:weap_lev_status_win].activate()
    @windows[:weap_lev_status_win].show()
  end
  #----------------------------------------------------------------------------
  # Update Weapon Level Status Window
  #----------------------------------------------------------------------------
  def update_weapon_level_status_window
    @windows[:weap_lev_status_win].update()
    if Input.trigger?(Input::B)  
      Sound.play_cancel
      @windows[:weap_lev_status_win].deactivate
      @windows[:weap_lev_status_win].hide
      @windows[Menu_Actor].activate()
      @windows[Menu_Actor].show()
      @windows[Win_Help].show()
      @windows[Win_Status].show()
    end
  end
end