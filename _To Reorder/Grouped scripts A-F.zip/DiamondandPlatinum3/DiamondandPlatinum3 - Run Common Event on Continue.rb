#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
#             Run Common Event On Continue
#             Author: DiamondandPlatinum3
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#  Description:
#
#    This script allows you to run a common event when the player loads a
#     save game.
#
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#------------------------------------------------------------------------------
#  Instructions:
#
#  ~  Modify Editable Region to your liking.
#
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=



#==============================================================================
# ** Scene_Load
#------------------------------------------------------------------------------
#  This class performs load screen processing. 
#==============================================================================

class Scene_Load < Scene_File
  #=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  #                                                        -= 
  #                 Editable Region        ////            ==
  #                                                        =-
  #-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
  
  # The Event ID of the Common Event that will be used when the player 
  # loads a saved game
  COMMON_EVENT_ID_TO_RUN = 10
  
  # Load the save file with the Screen Faded Out?
  # This will allow you to set things up with the common event without 
  # interupting the visuals on the screen.
  # Note: If true, you will need to use the "screen fadein" event when you are 
  #       finished with the common event.
  ContinueScreenFadeout = true
  
  #-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= 
  #                                           \/
  #               End of Editable Region      /\
  #                                           \/
  #-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
  
  #--------------------------------------------------------------------------
  # * Processing When Load Is Successful
  #--------------------------------------------------------------------------
  alias dp3_sceneload_onloadsuccess_09qd8uj     on_load_success
  #--------------------------------------------------------------------------
  def on_load_success
    # Run Common Event
    $game_temp.reserve_common_event(COMMON_EVENT_ID_TO_RUN)
    
    # Call Original Method
    dp3_sceneload_onloadsuccess_09qd8uj()
    
    # Fadeout Screen
    $game_map.screen.start_fadeout(1) if ContinueScreenFadeout
  end
end