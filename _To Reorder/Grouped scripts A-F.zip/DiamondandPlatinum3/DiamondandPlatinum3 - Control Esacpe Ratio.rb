#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
#             Control Escape Ratio
#             Author: DiamondandPlatinum3
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#  Description:
#
#    This script will allow you to set a constant rate at which you can escape
#    from battle, as well as setting an item that will guarantee you can
#    escape.
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
module DP3ESCAPERATIO
  #=========================================================
  #               EDITABLE REGION
  #=========================================================
 
  ESCAPE_RATIO              = 25 # out of 100
  GUARANTEE_ESCAPE_ITEM_ID  = 2  # Item ID of item that will guarantee you can escape
 
  #=========================================================
end







module BattleManager
  #--------------------------------------------------------------------------
  # * Create Escape Ratio
  #--------------------------------------------------------------------------
  def self.make_escape_ratio
    @escape_ratio = DP3ESCAPERATIO::ESCAPE_RATIO
  end
  #--------------------------------------------------------------------------
  # * Modify Escape Ratio ~ New Method
  #--------------------------------------------------------------------------
  def self.mod_escape_ratio( value )
    @escape_ratio = value
  end
  #--------------------------------------------------------------------------
  # * Escape Processing
  #--------------------------------------------------------------------------
  def self.process_escape
    $game_message.add(sprintf(Vocab::EscapeStart, $game_party.name))
   
    # !-============ Replaced Line ============-! #
   
    success = @preemptive ? true : (rand(100) < @escape_ratio)
   
    # !-=======================================-! #
   
    Sound.play_escape
    if success
      process_abort
    else
      @escape_ratio += 0.1
      $game_message.add('\.' + Vocab::EscapeFailure)
      $game_party.clear_actions
    end
    wait_for_message
    return success
  end
end
 








class Scene_Battle
  #--------------------------------------------------------------------------
  # * Apply Skill/Item Effect
  #--------------------------------------------------------------------------
  alias dp3_mod_escrat_sb_app_itm_eff_845wc apply_item_effects
  def apply_item_effects(target, item)
    # Change Escape Ratio
    BattleManager.mod_escape_ratio(100) if item.is_a?(RPG::Item) && item.id == DP3ESCAPERATIO::GUARANTEE_ESCAPE_ITEM_ID
   
    # Call Original Method
    dp3_mod_escrat_sb_app_itm_eff_845wc(target, item)
  end
end