begin
===============================================================================
 Fantasy Bestiary Battle Add-On v1.0 (28/9/2015)
-------------------------------------------------------------------------------
 Created By: Shadowmaster/Shadowmaster9000/Shadowpasta
 (www.crimson-castle.co.uk)
 Special Thanks: Yanfly (Some of Yanfly's scripts for loading scenes in other
                        scenes is what helped me to make this add-on)

===============================================================================
 Information
-------------------------------------------------------------------------------
 This script is an add-on for my Fantasy Bestiary script. It allows players
 to view the Bestiary while in battle from a party command, an actor command
 or from an item/skill's effect.
 
===============================================================================
 How to Use
-------------------------------------------------------------------------------
 Place this script under Materials and below Fantasy Bestiary. It's also
 recommended to put this below any other scripts that adds effects to
 skills/items to make sure that the Bestiary shows up after all effects of
 skills and items have been processed.

===============================================================================
 Note Tags
-------------------------------------------------------------------------------
 Place the note tag below in any item or skill.
 
 <show bestiary>
 Lets the item/skill show the bestiary.
 
===============================================================================
 Required
-------------------------------------------------------------------------------
 Fantasy Bestiary
 (http://www.rpgmakervxace.net/topic/14951-fantasy-bestiary/)
 
 This script is intended to be an add-on for Fantasy Bestiary. This script is
 not a standalone script.

===============================================================================
 Change log
-------------------------------------------------------------------------------
 v1.0: First release. (28/9/2015)

===============================================================================
 Terms of Use
-------------------------------------------------------------------------------
 * Free to use for both commercial and non-commerical projects.
 * Credit me if used.
 * Do not claim this as your own.
 * You're free to post this on other websites, but please credit me and keep
 the header intact.
 * If you want to release any modifications/add-ons for this script, the
 add-on script must use the same Terms of Use as this script uses. (But you
 can also require any users of your add-on script to credit you in their game
 if they use your add-on script.)
 * If you're making any compatibility patches or scripts to help this script
 work with other scripts, the Terms of Use for the compatibility patch does
 not matter so long as the compatibility patch still requires this script to
 run.
 * If you want to use your own seperate Terms of Use for your version or
 add-ons of this script, you must contact me at http://www.rpgmakervxace.net
 or www.crimson-castle.co.uk

===============================================================================
=end
$imported = {} if $imported.nil?
$imported["FantasyBestiaryBattle"] = true
if $imported["FantasyBestiary3.7"]

module FantasyBestiaryBattle
  
#==============================================================================
# ** Party Command Menu
#------------------------------------------------------------------------------
#  If set to true, an option to access the Bestiary will be displayed in the
#  party command menu. You can also set switches to toggle not only whether
#  the option can be viewed or not, but also if it can be used. If you do not
#  wish to use any of the switches, set them as 0.
#==============================================================================

  Party_Command_Menu = true
  Party_Command_Name = "Bestiary"
  Party_Show_Switch = 0 
  Party_Enable_Switch = 0
  
#==============================================================================
# ** Actor Command Menu
#------------------------------------------------------------------------------
#  If set to true, an option to access the Bestiary will be displayed in the
#  actor command menu, which can be useful if you have disabled access to the
#  party command menu. Accessing the Bestiary from the actor command menu does
#  not take up that actor's turn, meaning that actor can still act after viewing
#  the Bestiary.
#
#  You can also set switches to toggle not only whether the option can be
#  viewed or not, but also if it can be used. If you do not wish to use any of
#  the switches, set them as 0.
#==============================================================================

  Actor_Command_Menu = true
  Actor_Command_Name = "Bestiary"
  Actor_Show_Switch = 0 
  Actor_Enable_Switch = 0
    
#==============================================================================
# ** Bestiary on Hit
#------------------------------------------------------------------------------
#  When using the <show bestiary> note tag to have an item/skill show the
#  bestiary, having Bestiary on Hit set to true will make the Bestiary not
#  show up if the item/skill fails to hit the target.
#
#  Setting Bestiary on Hit to false will always make an item/skill with
#  the <show bestiary> note tag show the Bestiary regardless of whether the
#  item/skill hits the target or not.
#==============================================================================

  Bestiary_On_Hit = true
  
#==============================================================================
# ** Disable Bestiary BGM
#------------------------------------------------------------------------------
#  The Bestiary can be set to play BGMs for specific enemies when viewing
#  their page in the Bestiary. This option allows you to disable that music
#  from playing while viewing the Bestiary in battle.
#==============================================================================

  Disable_Bestiary_BGM = true
  
#==============================================================================
# ** DO NOT edit anything below this unless if you know what you're doing!
#==============================================================================
    
end

#==============================================================================
# ** DataManager
#------------------------------------------------------------------------------
#  This module manages the database and game objects. Almost all of the 
# global variables used by the game are initialized by this module.
#==============================================================================

module DataManager
  #--------------------------------------------------------------------------
  # * Load Database
  #--------------------------------------------------------------------------
  class <<self; alias load_database_battle_bestiary load_database; end
  def self.load_database
    load_database_battle_bestiary
    load_notetags_battle_bestiary
  end
  #--------------------------------------------------------------------------
  # * Load Notetags for Fantasy Bestiary Battle Add-On
  #--------------------------------------------------------------------------
  def self.load_notetags_battle_bestiary
    groups = [$data_skills, $data_items]
    for group in groups
      for obj in group
        next if obj.nil?
        obj.load_notetags_battle_bestiary
      end
    end
  end
end

#==============================================================================
# ** SceneManager
#------------------------------------------------------------------------------
#  This module manages scene transitions. For example, it can handle
# hierarchical structures such as calling the item screen from the main menu
# or returning from the item screen to the main menu.
#==============================================================================

module SceneManager
  #--------------------------------------------------------------------------
  # * Force Recall
  #--------------------------------------------------------------------------
  def self.force_recall(scene_class)
    @scene = scene_class
  end
end

#==============================================================================
# ** RPG::UsableItem
#------------------------------------------------------------------------------
#  This class defines attributes for usable items. Its superclass is RPG::BaseItem.
#==============================================================================

class RPG::UsableItem < RPG::BaseItem
  
  #--------------------------------------------------------------------------
  # * Public Instance Variables
  #--------------------------------------------------------------------------
  attr_accessor :bestiary
  
  #--------------------------------------------------------------------------
  # * Defining Attributes
  #--------------------------------------------------------------------------
  def load_notetags_battle_bestiary
    @bestiary = nil
    if @note =~ /<show bestiary>/i
      @bestiary = true
    end
  end
end

#==============================================================================
# ** Window_PartyCommand
#------------------------------------------------------------------------------
#  This window is used to select whether to fight or escape on the battle
# screen.
#==============================================================================

class Window_PartyCommand < Window_Command
  #--------------------------------------------------------------------------
  # * Alias: Make Command List
  #--------------------------------------------------------------------------
  alias make_command_list_bestiary make_command_list
  def make_command_list
    make_command_list_bestiary
    return if $imported["YEA-BattleCommandList"]
    add_bestiary_command if FantasyBestiaryBattle::Party_Command_Menu
  end
  #--------------------------------------------------------------------------
  # * Add Bestiary Command
  #--------------------------------------------------------------------------
  def add_bestiary_command
    return unless show_bestiary?
    text = FantasyBestiaryBattle::Party_Command_Name
    add_command(text, :bestiary, enable_bestiary?)
  end
  #--------------------------------------------------------------------------
  # * Show Bestiary
  #--------------------------------------------------------------------------
  def show_bestiary?
    return true if FantasyBestiaryBattle::Party_Show_Switch <= 0
    return $game_switches[FantasyBestiaryBattle::Party_Show_Switch]
  end
  #--------------------------------------------------------------------------
  # * Enable Bestiary
  #--------------------------------------------------------------------------
  def enable_bestiary?
    return true if FantasyBestiaryBattle::Party_Enable_Switch <= 0
    return $game_switches[FantasyBestiaryBattle::Party_Enable_Switch]
  end
end

#==============================================================================
# ** Window_ActorCommand
#------------------------------------------------------------------------------
#  This window is for selecting an actor's action on the battle screen.
#==============================================================================

class Window_ActorCommand < Window_Command
  #--------------------------------------------------------------------------
  # * Alias: Make Command List
  #--------------------------------------------------------------------------
  alias make_command_list_bestiary make_command_list
  def make_command_list
    return if @actor.nil?
    unless $imported["YEA-BattleCommandList"]
      add_bestiary_command if FantasyBestiaryBattle::Actor_Command_Menu
    end
    make_command_list_bestiary
  end
  #--------------------------------------------------------------------------
  # * Add Bestiary Command
  #--------------------------------------------------------------------------
  def add_bestiary_command
    return unless show_bestiary?
    text = FantasyBestiaryBattle::Actor_Command_Name
    add_command(text, :bestiary, enable_bestiary?)
  end
  #--------------------------------------------------------------------------
  # * Show Bestiary
  #--------------------------------------------------------------------------
  def show_bestiary?
    return true if FantasyBestiaryBattle::Actor_Show_Switch <= 0
    return $game_switches[FantasyBestiaryBattle::Actor_Show_Switch]
  end
  #--------------------------------------------------------------------------
  # * Enable Bestiary
  #--------------------------------------------------------------------------
  def enable_bestiary?
    return true if FantasyBestiaryBattle::Actor_Enable_Switch <= 0
    return $game_switches[FantasyBestiaryBattle::Actor_Enable_Switch]
  end
end

#==============================================================================
# ** Scene_Bestiary
#------------------------------------------------------------------------------
#  This class performs the Bestiary screen processing.
#==============================================================================

class Scene_Bestiary < Scene_MenuBase
  #--------------------------------------------------------------------------
  # * Alias: Refresh BGM
  #--------------------------------------------------------------------------
  alias refresh_bgm_battle_bestiary refresh_bgm
  def refresh_bgm
    return if $game_party.in_battle && FantasyBestiaryBattle::Disable_Bestiary_BGM
    refresh_bgm_battle_bestiary
  end
end

#==============================================================================
# ** Scene_Battle
#------------------------------------------------------------------------------
#  This class performs battle screen processing.
#==============================================================================

class Scene_Battle < Scene_Base
  #--------------------------------------------------------------------------
  # * Alias: Create Party Commands Window
  #--------------------------------------------------------------------------
  alias create_party_command_window_bestiary create_party_command_window
  def create_party_command_window
    create_party_command_window_bestiary
    @party_command_window.set_handler(:bestiary, method(:party_command_bestiary))
  end
  #--------------------------------------------------------------------------
  # * Alias: Create Actor Commands Window
  #--------------------------------------------------------------------------
  alias create_actor_command_window_bestiary create_actor_command_window
  def create_actor_command_window
    create_actor_command_window_bestiary
    @actor_command_window.set_handler(:bestiary, method(:actor_command_bestiary))
  end
  #--------------------------------------------------------------------------
  # * Apply Bestiary Effects
  #--------------------------------------------------------------------------
  alias scene_battle_apply_item_effects_bestiary apply_item_effects
  def apply_item_effects(target, item)
    scene_battle_apply_item_effects_bestiary(target, item)
    if FantasyBestiaryBattle::Bestiary_On_Hit
      command_bestiary if item.bestiary == true && target.result.hit?
    else
      command_bestiary if item.bestiary == true
    end
  end
  #--------------------------------------------------------------------------
  # * Command Bestiary
  #--------------------------------------------------------------------------
  def command_bestiary
    @log_window.back_one
    Graphics.freeze
    @info_viewport.visible = false
    hide_extra_gauges if $imported["YEA-BattleEngine"]
    SceneManager.snapshot_for_background
    SceneManager.call(Scene_Bestiary)
    SceneManager.scene.main
    SceneManager.force_recall(self)
    show_extra_gauges if $imported["YEA-BattleEngine"]
    @info_viewport.visible = true
    @status_window.refresh
    perform_transition
  end
  #--------------------------------------------------------------------------
  # * Party Command Bestiary
  #--------------------------------------------------------------------------
  def party_command_bestiary
    Graphics.freeze
    @info_viewport.visible = false
    hide_extra_gauges if $imported["YEA-BattleEngine"]
    SceneManager.snapshot_for_background
    index = @party_command_window.index
    oy = @party_command_window.oy
    SceneManager.call(Scene_Bestiary)
    SceneManager.scene.main
    SceneManager.force_recall(self)
    show_extra_gauges if $imported["YEA-BattleEngine"]
    @info_viewport.visible = true
    @status_window.refresh
    @party_command_window.setup
    @party_command_window.select(index)
    @party_command_window.oy = oy
    perform_transition
  end
  #--------------------------------------------------------------------------
  # * Actor Command Bestiary
  #--------------------------------------------------------------------------
  def actor_command_bestiary
    Graphics.freeze
    @info_viewport.visible = false
    hide_extra_gauges if $imported["YEA-BattleEngine"]
    SceneManager.snapshot_for_background
    actor = $game_party.battle_members[@status_window.index]
    index = @actor_command_window.index
    oy = @actor_command_window.oy
    SceneManager.call(Scene_Bestiary)
    SceneManager.scene.main
    SceneManager.force_recall(self)
    show_extra_gauges if $imported["YEA-BattleEngine"]
    @info_viewport.visible = true
    @status_window.refresh
    @actor_command_window.setup(actor)
    @actor_command_window.select(index)
    @actor_command_window.oy = oy
    perform_transition
  end
end
end