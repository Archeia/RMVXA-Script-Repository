#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
#             Sound Test Scene (Non-Customisable Version)
#             Version: 1.0
#             Author: DiamondandPlatinum3
#             Date: June 18, 2013
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#  Description:
#
#    This script creates a new scene in your menu which allows you to listen to
#    music in your game. This Version does not allow the control the other 
#    version has, but instead allows you to simply select a folder for audio to
#    be added and never have to update the script again for any new sounds in 
#    that folder.
#
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#------------------------------------------------------------------------------
#  Instructions:
#
#  ~  Go into the Script and Modify the Editable Region as Needed
#
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
module DiamondandPlatinum3
  module SoundTestScene
    #=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
    #                                                        -= 
    #                 Editable Region        ////            ==
    #                                                        =-
    #-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    
    # The Text that is displayed for the Option in the Menu
    MenuCommandText = "Sound Test"
    
    # Text to be displayed on the help window when Selecting a Sound
    SoundSelectHelpWindowTextLine1      = "Select a Sound"
    SoundSelectHelpWindowTextLine2      = "Press 'Esc or X' to Exit"
    
    # Text to be displayed on the help window when Hovering over the 'Play Sound' Option
    PlaySoundOptionHelpWindowTextLine1  = "Select To Play Sound"
    PlaySoundOptionHelpWindowTextLine2  = "(Default Settings)"
    
    # Text to be displayed on the help window when Hovering over the 'Volume' Option
    VolumeOptionHelpWindowTextLine1     = "Select To Play Sound"
    VolumeOptionHelpWindowTextLine2     = "(At Specific Volume)"
    
    # Text to be displayed on the help window when Hovering over the 'Pitch' Option
    PitchOptionHelpWindowTextLine1      = "Select To Play Sound"
    PitchOptionHelpWindowTextLine2      = "(At Specific Pitch)"
    
    # Text to be displayed on the help window when Hovering over the 'Position' Option
    PositionOptionHelpWindowTextLine1   = "Select To Play Sound At Specific Position"
    PositionOptionHelpWindowTextLine2   = "(Only works for WAV & OGG Files)"
    
    # Text to be displayed on the help window when inputting a value in the NuberInput Window
    NumberInputHelpWindowTextLine1      = "Input A Value"
    NumberInputHelpWindowTextLine2      = ""
    
    
    # Filename of background Image to be displayed when using the scene (Located in Pictures Folder)
    BackgroundSpriteFilename            = "SoundTest_BackgroundImage"
    
    
    # Default Audio Volume/Pitch
    DefaultVolume = 100
    DefaultPitch  = 100
    
    
    # Path to RTP Audio. This May be different on your own Computer
    IncludeRTP     = true
    PathToRTPAudio = "C:/Program Files (x86)/Common Files/Enterbrain/RGSS3/RPGVXAce/Audio/BGM/"
    
    
    # Custom Audio Paths
    CustomAudioPaths = 
    [
          "Audio/BGM/",     # Regular Custom Audio Path
          "",               # Put A Custom Audio Path Here if Desired
                            # Make As Many Custom Audio Paths as you would Like
          
    ]
    
    #-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= 
    #                                           \/
    #               End of Editable Region      /\
    #                                           \/
    #-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    #---------------------------------------------------------
    # No touchie past here unless you know what you are 
    # doing. Failure to heed this warning could cause your 
    # computer to yell and scream at you. 
    #
    # Edit at your own risk.
    #--------------------------------------------------------
  end
end




#==============================================================================
# ** SoundTestSound
#------------------------------------------------------------------------------
#  This is a class which hold Individual Sound Information for Play
#==============================================================================

class SoundTestSound
  include DiamondandPlatinum3::SoundTestScene
  #--------------------------------------------------------------------------
  # * Public Instance Variables
  #--------------------------------------------------------------------------
  attr_accessor :filename
  attr_accessor :display_name
  attr_accessor :volume
  attr_accessor :pitch
  #--------------------------------------------------------------------------
  # * Intialize
  #--------------------------------------------------------------------------
  def initialize( filename, volume, pitch, display )
    @filename     = filename
    @volume       = volume
    @pitch        = pitch 
    @display_name = display
  end
  #--------------------------------------------------------------------------
  # * Play Sound
  #--------------------------------------------------------------------------
  def play()
    RPG::BGM.stop()
    Audio.bgm_play( @filename, @volume, @pitch )
  end
  #--------------------------------------------------------------------------
  # * Play Sound at Position
  #--------------------------------------------------------------------------
  def play_at_position( position )
    RPG::BGM.stop()
    Audio.bgm_play( @filename, @volume, @pitch, position )
  end
  #--------------------------------------------------------------------------
  # * Play Sound ( Default )
  #--------------------------------------------------------------------------
  def default_play()
    RPG::BGM.stop()
    Audio.bgm_play( @filename, DefaultVolume, DefaultPitch )
  end
end





#==============================================================================
# ** Scene_SoundTest
#------------------------------------------------------------------------------
#  This Clas Holds the Scene Information for the SoundTest
#==============================================================================

class Scene_SoundTest < Scene_Base
  include DiamondandPlatinum3::SoundTestScene
  #--------------------------------------------------------------------------
  # * Start Processing
  #--------------------------------------------------------------------------
  def start
    super()
    
    save_current_bgm()
    create_background_image()
    create_soundtestfiles_array()
    create_command_windows()
    create_help_window()
    create_soundinfo_window()
    create_numberinput_window()
    set_input_variables()
    setup_scene_intro_animation()
    # Current Selected Sound
    @current_sound_symbol = nil
  end
  #--------------------------------------------------------------------------
  # * Post-Start Processing
  #--------------------------------------------------------------------------
  def post_start
    super()
    animate_intro_scene()
  end  
  #--------------------------------------------------------------------------
  # * Frame Update
  #--------------------------------------------------------------------------
  def update
    super()
    
    update_window_info_text()
    update_help_text()
    update_scene_changes()
    update_user_input()
  end
  #--------------------------------------------------------------------------
  # * Pre-Termination Processing
  #--------------------------------------------------------------------------
  def pre_terminate
    super()
    
    @current_map_bgm.replay()
  end
  #--------------------------------------------------------------------------
  # * Termination Processing
  #--------------------------------------------------------------------------
  def terminate
    @sound_select_cmmdwindow.dispose()  unless @sound_select_cmmdwindow.disposed?
    @sound_play_cmmdwindow.dispose()    unless @sound_play_cmmdwindow.disposed?
    @help_window.dispose()              unless @help_window.disposed?
    @sound_info_window.dispose()        unless @sound_info_window.disposed?
    @numberinput_window.dispose()       unless @numberinput_window.disposed?
    
    unless @background_image.disposed?
      @background_image.bitmap.dispose()
      @background_image.dispose()
    end
    
    super()
  end  
  #--------------------------------------------------------------------------
  # * Save Current BGM
  #--------------------------------------------------------------------------
  def save_current_bgm()
    # Get Current BGM
    @current_map_bgm = RPG::BGM.last
    RPG::BGM.stop()
  end
  #--------------------------------------------------------------------------
  # * Create Background Image
  #--------------------------------------------------------------------------
  def create_background_image()
    @background_image = Sprite.new()
    @background_image.bitmap = Cache.picture(BackgroundSpriteFilename)
    @background_image.x = 0
    @background_image.y = 0
    @background_image.z = 1
    @background_image.zoom_x = (Graphics.width.to_f / @background_image.bitmap.width)
    @background_image.zoom_y = (Graphics.height.to_f / @background_image.bitmap.height)
  end
  #--------------------------------------------------------------------------
  # * Create SoundTest Files Array
  #--------------------------------------------------------------------------
  def create_soundtestfiles_array()
    @soundfiles_hash = {}
    # Add Custom Sound Folders
    for folder_name in CustomAudioPaths
      next if folder_name == ""
      if does_directory_exist?( folder_name )
        sounds_array = get_sounds_in_directory( folder_name )
        for filename in sounds_array
          @soundfiles_hash[ (folder_name + filename).to_sym ] = SoundTestSound.new( (folder_name + filename), DefaultVolume, DefaultPitch, filename )
        end
      end
    end
    # Add RTP
    if IncludeRTP && does_directory_exist?( PathToRTPAudio )
      sounds_array = get_sounds_in_directory( PathToRTPAudio )
      for filename in sounds_array
        @soundfiles_hash[ filename.to_sym ] = SoundTestSound.new( (PathToRTPAudio + filename), DefaultVolume, DefaultPitch, filename )
      end
    end
  end
  #--------------------------------------------------------------------------
  # * Check if Directory Exists?
  #--------------------------------------------------------------------------
  def does_directory_exist?( directory_name )
    if Dir.exists?( directory_name )
      return true
    else
      msgbox_p( "Error: Cannot Find Folder Directory '#{directory_name}'") unless !$TEST
      return false 
    end
  end
  #--------------------------------------------------------------------------
  # * Get Sounds in Directory
  #--------------------------------------------------------------------------
  def get_sounds_in_directory( directory_name )
    sound_array = Dir.entries(directory_name)
    sound_array.delete( "." )   # Removes Directory Filenames
    sound_array.delete( ".." )  # "." = Self, ".." = Parent | <= Not Sound Filenames 
    
    # Only Get Audio Files
    accepted_formats = [ ".MP3", ".M4A", ".AAC", ".WAV", ".WMA", ".OGG", ".FLAC", ".APE", ".MID", ".MIDI", ]
    delete_indexes = []
    # If any FileExtension Does Not Match Above, Add it to the Delete Array
    for i in 0..(sound_array.size - 1)
      unless accepted_formats.include?(File.extname(sound_array[i]).upcase)
        delete_indexes.push(i)
      end
    end
    # Delete All Elements in the Sound_Array that have not been designated as a Sound_File
    index = delete_indexes.size - 1
    while( index >= 0 )
      sound_array.delete_at(delete_indexes[index])
      index -= 1
    end
    return sound_array
  end
  #--------------------------------------------------------------------------
  # * Create Command Windows
  #--------------------------------------------------------------------------
  def create_command_windows()
    
    # Setting Up Command Window for Sounds
    command_window_ypos = 72
    @sound_select_cmmdwindow = Window_SoundTest_SoundCommand.new(0, command_window_ypos, @soundfiles_hash)
    @sound_select_cmmdwindow.height = Graphics.height - command_window_ypos
    set_soundcommand_window_handlers()
    
    # Setting Up Command Window for Play Sound
    @sound_play_cmmdwindow = Window_SoundTest_PlayCommand.new(Graphics.width * 0.5, command_window_ypos)
    @sound_play_cmmdwindow.deactivate()
    set_soundplay_window_handlers()
  end
  #--------------------------------------------------------------------------
  # * Set Command Handlers
  #--------------------------------------------------------------------------
  def set_soundcommand_window_handlers
    @soundfiles_hash.each_key do |key_name|
      @sound_select_cmmdwindow.set_handler(key_name.to_sym, method(:deactivate_soundcommand_window))
    end
  end
  #--------------------------------------------------------------------------
  # * Set SoundPlay Handlers
  #--------------------------------------------------------------------------
  def set_soundplay_window_handlers
    @sound_play_cmmdwindow.set_handler(:play_sound, method(:playsound_command))
    @sound_play_cmmdwindow.set_handler(:volume,     method(:playsound_at_volume))
    @sound_play_cmmdwindow.set_handler(:pitch,      method(:playsound_at_pitch))
    @sound_play_cmmdwindow.set_handler(:position,   method(:playsound_at_position))
  end
  #--------------------------------------------------------------------------
  # * Create Help Window
  #--------------------------------------------------------------------------
  def create_help_window()
    # Setting up Help Window
    @help_window = Window_Help.new()
    @help_window.set_text(SoundSelectHelpWindowTextLine1 + "\n" + SoundSelectHelpWindowTextLine2)
  end
  #--------------------------------------------------------------------------
  # * Create SoundInfo Window
  #--------------------------------------------------------------------------
  def create_soundinfo_window()
    # Setting up Sound Info Window
    @sound_info_window = Window_SoundInfo.new()
    @sound_info_window.x = Graphics.width * 0.5
    @sound_info_window.y = 192
    @sound_info_window.openness = 255
  end
  #--------------------------------------------------------------------------
  # * Create NumberInput Window
  #--------------------------------------------------------------------------
  def create_numberinput_window()
    # Setting Up Number Input
    @numberinput_window = Window_SoundTest_NumberInput.new()
    @numberinput_window.z = 200
  end
  #--------------------------------------------------------------------------
  # * Set Input Variables
  #--------------------------------------------------------------------------
  def set_input_variables()
    @user_currently_inputting_value     = false
    @currently_entering_volume_value    = false
    @currently_entering_pitch_value     = false
    @currently_entering_position_value  = false
  end
  #--------------------------------------------------------------------------
  # * Setup Scene Intro Animation
  #--------------------------------------------------------------------------
  def setup_scene_intro_animation()
    @background_image.opacity    = 0
    @sound_select_cmmdwindow.x  -= 500
    @sound_play_cmmdwindow.x    += 500
    @help_window.y              -= 400
    @sound_info_window.y        += 300
  end
  #--------------------------------------------------------------------------
  # * Animate Intro Sequence
  #--------------------------------------------------------------------------
  def animate_intro_scene()
    while( true )
      bool1 = animate_sceneintro_background_image()
      bool2 = animate_sceneintro_soundselectcmmdwindow()
      bool3 = animate_sceneintro_soundplaycmmdwindow()
      bool4 = animate_sceneintro_helpwindow()
      bool5 = animate_sceneintro_soundinfowindow()
      Graphics.update()
      break if bool1 && bool2 && bool3 && bool4 && bool5
    end
  end
  #--------------------------------------------------------------------------
  # * Animate BackgroundImage Opacity for Intro Sequence
  #--------------------------------------------------------------------------
  def animate_sceneintro_background_image()
    return true if @background_image.opacity == 255
    @background_image.opacity += 5
    return @background_image.opacity == 255
  end
  #--------------------------------------------------------------------------
  # * Animate SoundSelectCommand Window for Intro Sequence
  #--------------------------------------------------------------------------
  def animate_sceneintro_soundselectcmmdwindow()
    return true if @sound_select_cmmdwindow.x == 0
    @sound_select_cmmdwindow.x += 20
    return @sound_select_cmmdwindow.x == 0
  end
  #--------------------------------------------------------------------------
  # * Animate SoundPlayCommand Window for Intro Sequence
  #--------------------------------------------------------------------------
  def animate_sceneintro_soundplaycmmdwindow()
    return true if @sound_play_cmmdwindow.x == (Graphics.width * 0.5)
    @sound_play_cmmdwindow.x -= 20
    return @sound_play_cmmdwindow.x == (Graphics.width * 0.5)
  end
  #--------------------------------------------------------------------------
  # * Animate Help Window for Intro Sequence
  #--------------------------------------------------------------------------
  def animate_sceneintro_helpwindow()
    return true if @help_window.y == 0
    @help_window.y += 10
    return @help_window.y == 0
  end
  #--------------------------------------------------------------------------
  # * Animate Sound Info Window
  #--------------------------------------------------------------------------
  def animate_sceneintro_soundinfowindow()
    return true if @sound_info_window.y == 192
    @sound_info_window.y -= 6
    return @sound_info_window.y == 192
  end
  #--------------------------------------------------------------------------
  # * Deactivate Sound Command Windows
  #--------------------------------------------------------------------------
  def deactivate_soundcommand_windows()
    @sound_select_cmmdwindow.deactivate()
    @sound_play_cmmdwindow.deactivate()
  end
  #--------------------------------------------------------------------------
  # * Deactivate Sound Command Window
  #--------------------------------------------------------------------------
  def deactivate_soundcommand_window()
    @sound_select_cmmdwindow.deactivate()
    @sound_play_cmmdwindow.activate()
  end
  #--------------------------------------------------------------------------
  # * Deactivate SoundPlay Command Window
  #--------------------------------------------------------------------------
  def deactivate_soundplaycommand_window()
    @sound_select_cmmdwindow.activate()
    @sound_play_cmmdwindow.deactivate()
  end
  #--------------------------------------------------------------------------
  # * Update Info Window Text
  #--------------------------------------------------------------------------
  def update_window_info_text()
    @current_sound_symbol = @sound_select_cmmdwindow.current_symbol
  end
  #--------------------------------------------------------------------------
  # * Update Help Text
  #--------------------------------------------------------------------------
  def update_help_text()
    # If SoundSelect Command Window is Active
    if @sound_select_cmmdwindow.active
      @help_window.set_text(SoundSelectHelpWindowTextLine1 + "\n" + SoundSelectHelpWindowTextLine2)
    # If NumberInput Window is Active
    elsif @numberinput_window.active
      @help_window.set_text(NumberInputHelpWindowTextLine1 + "\n" + NumberInputHelpWindowTextLine2)
     # If Hovering Over PlaySound
    elsif @sound_play_cmmdwindow.current_symbol == :play_sound
      @help_window.set_text(PlaySoundOptionHelpWindowTextLine1 + "\n" + PlaySoundOptionHelpWindowTextLine2)
     # If Hovering Over Volume Input
    elsif @sound_play_cmmdwindow.current_symbol == :volume
      @help_window.set_text(VolumeOptionHelpWindowTextLine1 + "\n" + VolumeOptionHelpWindowTextLine2)
     # If Hovering Over Pitch Input
    elsif @sound_play_cmmdwindow.current_symbol == :pitch
      @help_window.set_text(PitchOptionHelpWindowTextLine1 + "\n" + PitchOptionHelpWindowTextLine2)
     # If Hovering Over Position Input
    else
      @help_window.set_text(PositionOptionHelpWindowTextLine1 + "\n" + PositionOptionHelpWindowTextLine2)
    end
  end
  #--------------------------------------------------------------------------
  # * Update Scene Changes
  #--------------------------------------------------------------------------
  def update_scene_changes()
    return_scene()                        if Input.trigger?(:B) && @sound_select_cmmdwindow.active
    deactivate_soundplaycommand_window()  if Input.trigger?(:B) && @sound_play_cmmdwindow.active
  end
  #--------------------------------------------------------------------------
  # * Update User Input
  #--------------------------------------------------------------------------
  def update_user_input()
    if @user_currently_inputting_value && @numberinput_window.completed
      receive_volume_value()    if @currently_entering_volume_value
      receive_pitch_value()     if @currently_entering_pitch_value
      receive_position_value()  if @currently_entering_position_value   
    end
  end
  #--------------------------------------------------------------------------
  # * Play Sound Command
  #--------------------------------------------------------------------------
  def playsound_command()
    @soundfiles_hash[@current_sound_symbol].default_play()    
    @sound_play_cmmdwindow.activate()
  end
  #--------------------------------------------------------------------------
  # * Play Sound 'At Volume' Command
  #--------------------------------------------------------------------------
  def playsound_at_volume()
    deactivate_soundcommand_windows()
    @user_currently_inputting_value = true
    @currently_entering_volume_value = true
    number = @soundfiles_hash[@current_sound_symbol].volume
    @numberinput_window.start( number, 3 )
  end
  #--------------------------------------------------------------------------
  # * Play Sound 'At Pitch' Command
  #--------------------------------------------------------------------------
  def playsound_at_pitch()
    deactivate_soundcommand_windows()
    @user_currently_inputting_value = true
    @currently_entering_pitch_value = true
    number = @soundfiles_hash[@current_sound_symbol].pitch
    @numberinput_window.start( number, 3 )
  end
  #--------------------------------------------------------------------------
  # * Play Sound 'At Position' Command
  #--------------------------------------------------------------------------
  def playsound_at_position()
    @currently_entering_position_value = true
    @user_currently_inputting_value = true
    deactivate_soundcommand_windows()
    @numberinput_window.start( 0, 9 )
  end
  #--------------------------------------------------------------------------
  # * Receive Volume Value
  #--------------------------------------------------------------------------
  def receive_volume_value()
    if @numberinput_window.processed_ok
      @soundfiles_hash[@current_sound_symbol].volume = @numberinput_window.result
      @soundfiles_hash[@current_sound_symbol].play()
    end
    @sound_play_cmmdwindow.activate()
    set_input_variables()
  end
  #--------------------------------------------------------------------------
  # * Receive Pitch Value
  #--------------------------------------------------------------------------
  def receive_pitch_value()
    if @numberinput_window.processed_ok
      @soundfiles_hash[@current_sound_symbol].pitch = @numberinput_window.result
      @soundfiles_hash[@current_sound_symbol].play()
    end
    @sound_play_cmmdwindow.activate()
    set_input_variables()
  end
  #--------------------------------------------------------------------------
  # * Receive Position Value
  #--------------------------------------------------------------------------
  def receive_position_value()
    if @numberinput_window.processed_ok
      @soundfiles_hash[@current_sound_symbol].play_at_position( @numberinput_window.result )
    end
    @sound_play_cmmdwindow.activate()
    set_input_variables()
  end
end


#==============================================================================
# ** Window_MenuCommand
#------------------------------------------------------------------------------
#  This command window appears on the menu screen.
#==============================================================================

class Window_MenuCommand < Window_Command
  #--------------------------------------------------------------------------
  # * Add Exit Game to Command List
  #--------------------------------------------------------------------------
  alias dp3_soundtestscene_windowmenucommd_addgameendcmmd_ofa     add_game_end_command
  #--------------------------------------------------------------------------
  def add_game_end_command
    add_command(DiamondandPlatinum3::SoundTestScene::MenuCommandText, :sound_test)
    dp3_soundtestscene_windowmenucommd_addgameendcmmd_ofa()
  end
end



#==============================================================================
# ** Scene_Menu
#------------------------------------------------------------------------------
#  This class performs the menu screen processing.
#==============================================================================

class Scene_Menu < Scene_MenuBase
  #--------------------------------------------------------------------------
  # * Create Command Window
  #--------------------------------------------------------------------------
  alias dp3_soundtestscene_scenemenu_creatcmmdwind_ofa      create_command_window
  #--------------------------------------------------------------------------
  def create_command_window
    dp3_soundtestscene_scenemenu_creatcmmdwind_ofa() # Call original Method    
    @command_window.set_handler(:sound_test,    method(:command_soundtest))
  end
  #--------------------------------------------------------------------------
  # * Command Sound Test
  #--------------------------------------------------------------------------
  def command_soundtest
    SceneManager.call(Scene_SoundTest)
  end
end



#==============================================================================
# ** SoundTest_Command
#------------------------------------------------------------------------------
# The Command Window that is used when selecting a sound
#==============================================================================

class Window_SoundTest_SoundCommand < Window_Command
  include DiamondandPlatinum3::SoundTestScene
  #--------------------------------------------------------------------------
  # * Initialize
  #--------------------------------------------------------------------------
  alias old_init    initialize
  def initialize( x, y, soundfiles_hash )
    @soundfiles_hash = soundfiles_hash
    old_init( x, y )
  end
  #--------------------------------------------------------------------------
  # * Get Window Width
  #--------------------------------------------------------------------------
  def window_width
    return Graphics.width * 0.5
  end
  #--------------------------------------------------------------------------
  # * Make Command List
  #--------------------------------------------------------------------------
  def make_command_list
    @soundfiles_hash.each_key do |key_name|
      add_command(@soundfiles_hash[key_name].display_name, key_name)
    end
  end  
end


#==============================================================================
# ** PlaySound_Command
#------------------------------------------------------------------------------
# The Command Window that is used for playing a sound
#==============================================================================

class Window_SoundTest_PlayCommand < Window_Command
  include DiamondandPlatinum3::SoundTestScene
  #--------------------------------------------------------------------------
  # * Get Window Width
  #--------------------------------------------------------------------------
  def window_width
    return Graphics.width * 0.5
  end
  #--------------------------------------------------------------------------
  # * Make Command List
  #--------------------------------------------------------------------------
  def make_command_list
    add_command("Play Sound", :play_sound)
    add_command("Volume",     :volume)
    add_command("Pitch",      :pitch)
    add_command("Position",   :position)
  end  
end




#==============================================================================
# ** Window_SoundInfo
#------------------------------------------------------------------------------
#  This message window is used to display Sound Information
#==============================================================================

class Window_SoundInfo < Window_Message
  #--------------------------------------------------------------------------
  # * Set Font
  #--------------------------------------------------------------------------
  def set_font
    contents.font.size = 18
  end
  #--------------------------------------------------------------------------
  # * Get Window Width
  #--------------------------------------------------------------------------
  def window_width
    return Graphics.width * 0.5
  end
  #--------------------------------------------------------------------------
  # * Get Window Height
  #--------------------------------------------------------------------------
  def window_height
    return Graphics.height - 192
  end  
  #--------------------------------------------------------------------------
  # * Draw Text
  #--------------------------------------------------------------------------
  def draw_text_soundinfo(text)
    contents.clear
    set_font()
    draw_text_ex(0, 0, word_wrapping(text))
  end  
  #--------------------------------------------------------------------------
  # * Draw Text with Control Characters
  #--------------------------------------------------------------------------
  def draw_text_ex(x, y, text)
    text = convert_escape_characters(text)
    pos = {:x => x, :y => y, :new_x => x, :height => calc_line_height(text)}
    process_character(text.slice!(0, 1), text, pos) until text.empty?
  end
  #--------------------------------------------------------------------------
  # * Wait After Output of One Character
  #--------------------------------------------------------------------------
  def wait_for_one_character
  end
  #--------------------------------------------------------------------------
  # * Word Wrapping
  #--------------------------------------------------------------------------
  def word_wrapping(text, pos = 0)
    
    # Current Text Position
    current_text_position = 0    
    
    for i in 0..(text.length - 1)
      if text[i] == "\n"
        current_text_position = 0
        next
      end
      
      # Current Position += character width
      current_text_position += contents.text_size(text[i]).width
      
      # If Current Position > Window Width
      if (pos + current_text_position) >= (contents.width)
        # Then Format the Sentence to fit Line
        current_element = i
        while(text[current_element] != " ")
          break if current_element == 0
          current_element -= 1
        end
        
        temp_text = ""
        for j in 0..(text.length - 1)
          temp_text += text[j]
          temp_text += "\n" if j == current_element
        end
        text = temp_text
        i = current_element
        current_text_position = 0
      end
    end
    return text
  end
end



#==============================================================================
# ** Window_NumberInput
#------------------------------------------------------------------------------
#  This window is used for the event command [Input Number].
#==============================================================================

class Window_SoundTest_NumberInput < Window_NumberInput
  #--------------------------------------------------------------------------
  # * Public Instance Variables
  #--------------------------------------------------------------------------
  attr_reader :result       # The Result of User Input
  attr_reader :completed    # User Finished Input Processing?
  attr_reader :processed_ok # User Did not Cancel User Input?
  #--------------------------------------------------------------------------
  # * Initialize
  #--------------------------------------------------------------------------
  def initialize()
    super( self )
    @result       = 0
    @completed    = true
    @processed_ok = false
  end
  #--------------------------------------------------------------------------
  # * Start Input Processing
  #--------------------------------------------------------------------------
  def start( number, digits )
    @digits_max = digits
    @number = number
    @index = 0
    @completed = false
    update_placement
    create_contents
    refresh
    open
    activate
  end
  #--------------------------------------------------------------------------
  # * Update Window Position
  #--------------------------------------------------------------------------
  def update_placement
    self.width = @digits_max * 20 + padding * 2
    self.height = fitting_height(1)
    self.x = (Graphics.width - width) / 2
    self.y = 192
  end
  #--------------------------------------------------------------------------
  # * Processing When OK Button Is Pressed
  #--------------------------------------------------------------------------
  def process_ok
    Sound.play_ok
    @result = @number
    @completed = true
    @processed_ok = true
    deactivate
    close
  end
  #--------------------------------------------------------------------------
  # * Processing When Cancel Button Is Pressed
  #--------------------------------------------------------------------------
  def process_cancel
    Sound.play_cancel
    @completed    = true
    @processed_ok = false
    deactivate
    close
  end
end