#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
#             Play SE on Critical Hit
#             Author: DiamondandPlatinum3
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#  Description:
#
#    This script will allow you to play a Sound Effect when any active battler
#    Scores a critical hit.
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~



class Game_Battler
  #==================================================
  #           EDITABLE REGION
  #==================================================
  CRITICAL_HIT_SE     = "Applause1"
  CRITICAL_HIT_VOLUME = 80
  CRITICAL_HIT_PITCH  = 100
  #==================================================
 
 
  #--------------------------------------------------------------------------
  # * Apply Critical
  #--------------------------------------------------------------------------
  alias playsound_oncritical      apply_critical
  #--------------------------------------------------------------------------
  def apply_critical(*args)
    RPG::SE.new(CRITICAL_HIT_SE, CRITICAL_HIT_VOLUME, CRITICAL_HIT_PITCH).play
    return playsound_oncritical(*args)
  end
end