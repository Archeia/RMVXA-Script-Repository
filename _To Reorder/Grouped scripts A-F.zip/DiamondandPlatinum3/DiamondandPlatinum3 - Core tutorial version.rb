#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
#             DP Core
#             Version: 1.0
#             Author: DiamondandPlatinum3
#             Date: October 2, 2013
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#  Description:
#
#    This Core Script adds extra classes and additions to existing classes for 
#    use by future DiamondandPlatinum3 scripts and/or any other scripter who
#    finds these additions useful.
#
#   New Additions Include:
#     Module:   DPCore:               A Module which houses the new Classes.
#     Class:    ScreenFilledSprite:   A Sprite which automatically fits to screen.
#     Class:    TimeTracker:          A Class Which Keeps Track of Real-Time once Activated.
#     Edited:   Window_MenuCommand:   Now Allows for quicker menu option creation.
#     Module:   GameEvents:           A Module to Contain Code for interaction with GameEvents.
#
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
($diamondandplatinum3_scripts ||= {})[:DPCore] = true
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=




#=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=
# **  New Class:   Screen Filled Sprite
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Creates a sprite which automatically fills the screen and can be disposed
# without needing to dispose of the included bitmap. 
# Everything beyond initialisation is still accessed the way a normal 
# Sprite is accessed.
#~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~
module DPCore
  class ScreenFilledSprite < Sprite
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # * New Method:   Object Initialisation
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # Filename:   Filename of the Sprite Image, includes path if necessary.
    # Visible:    Will be visible? : true by default
    # Z:          The Z Value of this sprite on initialisation : 1 by default
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def initialize(filename, visible = true, z = 1)
      super()
      self.bitmap   = Bitmap.new(filename)
      self.x        = 0
      self.y        = 0
      self.z        = z
      self.zoom_x   = (Graphics.width.to_f / self.bitmap.width)
      self.zoom_y   = (Graphics.height.to_f / self.bitmap.height)
      self.visible  = visible
    end
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # * New Method:   Dispose
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def dispose()
      self.bitmap.dispose()       unless self.bitmap.disposed?
      super()
    end
  end
end







#=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=
# **  New Class:   Time Tracker
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Once initialised, this class keeps track of time in seconds.
# All instances of the TimeTracker class are updated automatically if you
# have chosen to allow themselves to be added to the list (true by default).
#
# Once initialised, simply call the ' time_up? ' method to see if the time
# is up for this TimeTracker.
# Call ' dispose ' once finished.
#~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~
module DPCore
  class TimeTracker
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # *+ Public Instance Variables
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    attr_reader :current_frame  # Current Frame the Tracker is on: Use to Reset Tracker.
    attr_reader :seconds        # Seconds until TimeUp: Change to Increase/Decrease the Wait Time.
    attr_reader :scenetype      # Scenetype: If not nil, this TimeTracker will only Update if SceneManager is in that Specified Scene.
    
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # *- Private Static Variables
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @@timetracker_list = []     # Static Variable List/Array containing active instances of TimeTrackers
    
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # * New Method:   Object Initialisation
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # Time:             How long (in seconds) until this TimeTracker has been successful
    # Scene Class:      Which Scene Can this TimeTracker be updated in : nil by default, which means it can always be updated no matter what scene it is.
    # Add Self To List: Add Self to the Automatic Update List? : true by default. If not true, you need to update the TimeTracker manually
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def initialize(time, scene_class = nil, add_self_to_list = true)
      @current_frame  = 0.0
      @seconds        = time.to_f
      @scenetype      = scene_class
      
      @@timetracker_list.push(self) if add_self_to_list
    end
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # * New Method:   Dispose
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def dispose()
      @@timetracker_list.reject! { |tracker| tracker == self }
    end
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # * New Method:   Update
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def update()
      @current_frame += 1.0
    end
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # * New Method:   Reset
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def reset()
      @current_frame = 0.0
    end
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # * New Method:   Get Current Time (in seconds)
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def get_current_time()
      return (@current_frame / Graphics.frame_rate)
    end
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # * New Method:   Is Time Up?
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def time_up?()
      return (get_current_time() > @seconds)
    end
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # * New Method:   Get TimeTracker List
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def self.get_timetracker_list()
      return @@timetracker_list
    end
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # * New Method:   Update TimeTrackers
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def self.update_timetrackers()
      @@timetracker_list.each do |tracker|
        if tracker.scenetype
          if SceneManager.scene_is?(tracker.scenetype)
            tracker.update()
          end
        else
          tracker.update()
        end
      end
    end
  end
end


class Scene_Base
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * Aliased Method:   Update
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  alias dp3_dpcore_scenebase_update_axxz                          update
  def update(*args)
    dp3_dpcore_scenebase_update_axxz(*args)
    DPCore::TimeTracker.update_timetrackers()
  end
end






#=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=
# **  Edited Classes:   Scene Menu Quick Option Creation
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# This edit allows for quick Scene Menu Command Creation.
# alias ' dp3_dpcore_get_original_commands ' and follow the instructions 
# of that method.
#~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~
class Window_MenuCommand < Window_Command
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * Aliased Listings
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  alias dp3_dpcore_addorigcomnd_axxz               add_original_commands
  alias dp3_dpcore_activate_axxz                   activate
  
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * New Method:   Get Original Commands
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  #   hash = alias
  #   hash[ "label" ] = {
  #     :enabled    => true/false,
  #     :method_ref => method(:method_name),
  #   }
  #   return hash
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def dp3_dpcore_get_original_commands()
    return {}
  end
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * Aliased Method: For Adding Original Commands
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def add_original_commands(*args)
    dp3_dpcore_addorigcomnd_axxz(*args) # Call Original Method
    
    original_commands = dp3_dpcore_get_original_commands()
    original_commands.each_key do |key|
      add_command(key, key.to_sym, original_commands[key][:enabled])
    end
  end
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * Aliased Method: Activate
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def activate(*args)
    dp3_dpcore_activate_axxz(*args) # Call Original Command
    
    original_commands = dp3_dpcore_get_original_commands()
    original_commands.each_key do |key|
      set_handler(key.to_sym, original_commands[key][:method_ref])
    end
  end
end





#=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=
# **  New Module:   GameEvents
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# This Module Will interact with GameEvents. For now the only code here is:
#     * Get First Comment in Event Page
#     * Get All Comments in Event Page
#~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~
module DPCore
  module GameEvents
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # * New Method: Get Event First Comment
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def self.get_event_first_comment( event_id )
      comments = get_event_all_comments( event_id )
      return comments[0]  unless comments.empty?
      return ""
    end
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # * New Method: Get Event All Comments
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def self.get_event_all_comments( event_id )
      comments = []
      event = $game_map.events[ event_id ]
      if event.list
        event.list.each do |command|
          if command.code == 108
            comments.push( command.parameters[0] )
          end
        end
      end
      return comments
    end
  end
end