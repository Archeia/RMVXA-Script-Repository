#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
#             Check If An Actor has Nothing Equipped
#             Author: DiamondandPlatinum3
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#  Description:
#
#    This script allows you to check if any actor currently has nothing equipped
#    or if any actor currently has no weapons equipped
#
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#------------------------------------------------------------------------------
#  Instructions:
#  
#     Use the Following in a Conditional Branch Script Call
#
#       check_if_nothing_equipped( actor_id )
#       check_if_no_weapon_equipped( actor_id )
#
#   Replacing Actor_ID with the actor you want to use this check on.
#   Actor 1 would be Eric and Actor 2 would be Natalie, etc.
#
#     Example ScreenShot Here:
#       http://img4host.net/upload/270438415104a141368c1.png
#
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
class Game_Interpreter
  def check_if_nothing_equipped( actor_id )
    return false unless actor_id.is_a?(Integer)
    actor = $game_actors[actor_id]
    return false unless actor
    for i in 0..(actor.equip_slots.size - 1)
      return false if actor.equips[i]
    end
    return true
  end
  def check_if_no_weapon_equipped( actor_id )
    return false unless actor_id.is_a?(Integer)
    return false if $game_actors[actor_id].equips[0]
    return false if $game_actors[actor_id].equips[1] && $game_actors[actor_id].equips[1].is_a?(RPG::Weapon)
    return true
  end
end