#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
#             Play BGM on loading menu
#             Author: DiamondandPlatinum3
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#  Description:
#
#    This script allows you to play BGM on the Loading menu.
#    When you select 'Continue' from the title screen and are taken to the
#    file selection screen, new BGM will play instead of the same title screen
#    music. Similar to Pokemon Gold, Silver, Crystal.
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
class Scene_Load < Scene_File
  #======================================
  #       Editable Region
  #======================================
  BGM_MUSIC_FOR_LOAD_SCREEN  = "Scene6"
  BGM_VOLUME                 = 100
  BGM_PITCH                  = 100
  #======================================
 
 
 
 
  alias play_music_onloadscreen first_savefile_index
  def first_savefile_index
    RPG::BGM.new(BGM_MUSIC_FOR_LOAD_SCREEN, BGM_VOLUME, BGM_PITCH).play
    play_music_onloadscreen
  end
end