#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
#             DP Core
#             Version: 1.0
#             Author: DiamondandPlatinum3
#             Date: December 23, 2013
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#  Description:
#
#    This Core Script adds extra classes and additions to existing classes for 
#    use by future DiamondandPlatinum3 scripts and/or any other scripter who
#    finds these additions useful.
#
#    Included is an Improved Input System which allows for Mapping Input to 
#    all PC Keyboard Keys and complete Mapping abilities over Xbox360 & PS3
#    Controllers.
#       Additionally you can vibrate an Xbox360 Controller.
#   
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#  Instructions:
#
#  ~  Check the Editable Region and Modify things to your liking.
#
#  ~  A Video Tutorial for the Improved Input System can be seen here:
#         http://www.youtube.com/watch?v=vp1lB-09K5w
#
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#  Compatibility:
#
#   ~ Module DPCore:                        (New Module)
#
#       ~ Class ScreenFilledSprite:           (New Class) < Sprite
#           initialize                          (Derived Instance Method)
#           dispose                             (Derived Instance Method)
#
#       ~ Class TimeTracker:                  (New Class)
#           initialize                          (Derived Instance Method)
#           dispose                             (New Instance Method)
#           update                              (New Instance Method)
#           reset                               (New Instance Method)
#           set_current_time                    (New Instance Method)
#           set_finish_time                     (New Instance Method)
#           get_current_time                    (New Instance Method)
#           time_up?                            (New Instance Method)
#           get_completion_percentage           (New Instance Method)
#           get_timetracker_list                (New Class Method)
#           update_timetrackers                 (New Class Method)
#
#       ~ Module GameEvents:                  (New Module)
#           get_event_first_comment             (New Module Method)
#           get_event_all_comments              (New Module Method)
#
#       ~ Module InputHandler:                (New Module)
#           New Editable Constants              (Constant Variables)
#
#
#   ~ Class Scene_Base:                     (Inbuilt Class)
#       update                                (Aliased Method)
#
#
#   ~ Class Window_MenuCommand:             (Inbuilt Class) < Window_Command
#       add_original_commands                 (Aliased Instance Method)
#       activate                              (Aliased Instance Method)
#       dp3_dpcore_get_original_commands      (New Instance Method)
#
#
#
#
#   ~ if InputHandler::UseInputSystem:      (Definition)
#
#       ~ Class Game_Interpreter:             (Inbuilt Class)
#           vibrate_controller                  (New Instance Method)
#
#
#       ~ Module Input:                       (Inbuilt Module)
#           Module InputInfo                    (New Module)
#             Class Repeated                      (New Class)
#             Class VibrationTimer                (New Class)
#           Class InputMapping                  (New Class) < Hash
#           Class Input_Base                    (New Class)
#           Class Controller_Base               (New Class) < Input::Input_Base
#           Class Xbox360Controller             (New Class) < Input::Controller_Base
#           Class PS3Controller                 (New Class) < Input::Controller_Base
#           Class PCKeyboardInput               (New Class) < Input::Input_Base
#
#
#       ~ Module Input:                       (Inbuilt Module)
#           New Constant Variables              (Constant Variables)
#           New Class Variables                 (Class Variables)
#           update                              (Overwritten Module Method)
#           trigger?                            (Overwritten Module Method)
#           press?                              (Overwritten Module Method)
#           repeat?                             (Overwritten Module Method)
#           dir4                                (Overwritten Module Method)
#           dir8                                (Overwritten Module Method)
#           triggered?                          (New Module Method)
#           pressed?                            (New Module Method)
#           repeated?                           (New Module Method)
#           release?                            (New Module Method)
#           released?                           (New Module Method)
#           xbox360_controller_connected?       (New Module Method)
#           ps3_controller_connected?           (New Module Method)
#           xbox360_input                       (New Module Method)
#           ps3_input                           (New Module Method)
#           pc_keyboard_input                   (New Module Method)
#           get_input_instance                  (New Module Method)
#           input_mapping                       (New Module Method)
#           get_currently_triggered_keys        (New Module Method)
#           get_currently_pressed_keys          (New Module Method)
#           get_currently_repeated_keys         (New Module Method)
#           get_currently_released_keys         (New Module Method)
#
#
#       ~ Class Input::InputMapping:        (New Class) < Hash
#           initialize                        (Derived Instance Method)
#           get_input_symbols                 (New Instance Method)
#           create_sym_info                   (New Instance Method)
#           assign_pc_keyboard_input          (New Instance Method)
#           assign_xbox360_controller_input   (New Instance Method)
#           assign_ps3_controller_input       (New Instance Method)
#           assign_additional_input           (New Instance Method)
#         
#
#       ~ Class Input::InputInfo::Repeated: (New Class)
#           initialize                        (Derived Instance Method)
#           reset                             (New Instance Method)
#           update                            (New Instance Method)
#           activate                          (New Instance Method)
#           active?                           (New Instance Method)
#
#
#       ~ Class Input::InputInfo::VibrationTimer: (New Class)
#           initialize                        (Derived Instance Method)
#           reset                             (New Instance Method)
#           update                            (New Instance Method)
#           set_active                        (New Instance Method)
#           set_finish                        (New Instance Method)
#           active?                           (New Instance Method)
#           complete?                         (New Instance Method)
#
#
#       ~ Class Input::Input_Base:          (New Class)
#           initialize                        (Derived Instance Method)
#           reset                             (New Instance Method)
#           new_key_info                      (New Instance Method)
#           set_key_status                    (New Instance Method)
#           update_key                        (New Instance Method)
#           update_key_repeat                 (New Instance Method)
#           reset_key                         (New Instance Method)
#           trigger?                          (New Instance Method)
#           triggered?                        (New Instance Method)
#           press?                            (New Instance Method)
#           pressed?                          (New Instance Method)
#           repeat?                           (New Instance Method)
#           repeated?                         (New Instance Method)
#           release?                          (New Instance Method)
#           released?                         (New Instance Method)
#           currently_triggered_keys          (New Instance Method)
#           currently_pressed_keys            (New Instance Method)
#           currently_repeated_keys           (New Instance Method)
#           currently_released_keys           (New Instance Method)
#           get_rep_symbols                   (New Instance Method)
#
#
#       ~ Class Input::Controller_Base:     (New Class) < Input::Input_Base
#           reset                             (Derived Instance Method)
#           connected?                        (New Instance Method)
#
#
#       ~ if DPCore::InputHandler::UseXbox360ControllerInput  (Definition)
#         ~ Class Input::Xbox360Controller:   (New Class) < Input::Controller_Base
#             New Constant Variables            (Constant Variables)
#             DLL Required Constants            (Constant Variables Referencing DLLs)
#             reset                             (Derived Instance Method)
#             get_rep_symbols                   (Derived Instance Method)
#             update                            (New Instance Method)
#             update_connection                 (New Instance Method)
#             update_buttons                    (New Instance Method)
#             update_axes                       (New Instance Method)
#             update_lstick_movement            (New Instance Method)
#             update_rstick_movement            (New Instance Method)
#             update_vibration                  (New Instance Method)
#             vibrate_controller                (New Instance Method)
#             axis                              (New Instance Method)
#
#
#       ~ if DPCore::InputHandler::UsePS3ControllerInput      (Definition)
#         ~ Class Input::PS3Controller:       (New Class) < Input::Controller_Base
#             New Constant Variables            (Constant Variables)
#             DLL Required Constants            (Constant Variables Referencing DLLs)
#             reset                             (Derived Instance Method)
#             get_rep_symbols                   (Derived Instance Method)
#             update                            (New Instance Method)
#             update_connection                 (New Instance Method)
#             update_buttons                    (New Instance Method)
#
#
#       ~ Class Input::KeyboardInput:       (New Class) < Input::Input_Base
#           New Constant Variables            (Constant Variables)
#           DLL Required Constants            (Constant Variables Referencing DLLs)
#           reset                             (Derived Instance Method)
#           get_rep_symbols                   (Derived Instance Method)
#           update                            (New Instance Method)
#
#
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
($diamondandplatinum3_scripts ||= {})[:DPCore] = true
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
module DPCore
  module InputHandler
    #=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
    #                                                        -= 
    #                 Editable Region        ////            ==
    #                                                        =-
    #-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    
    #=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=
    # Input Scheme |                  What it does!
    #~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~
    #     :A       | Dash When Moving; Warps to OK during Input; Increases Text Speed; 
    #     :B       | The Cancel Button; Opens the Main Menu; 
    #     :C       | The Confrim Button; Interacts with Events; Increases Text Speed;
    #     :X       | Nothing by Default; Can be used in your events;
    #     :Y       | Nothing by Default; Can be used in your events;
    #     :Z       | Nothing by Default; Can be used in your events;
    #     :L       | The PageUp Button;
    #     :R       | The PageDown Button;
    #     :SHIFT   | Nothing by Default; May be used in a custom script;
    #     :CTRL    | Allows you to walk through walls during debug mode;
    #     :ALT     | Nothing by Default; May be used in a custom script;
    #     :F5      | Nothing by Default; May be used in a custom script;
    #     :F6      | Nothing by Default; May be used in a custom script;
    #     :F7      | Nothing by Default; May be used in a custom script;
    #     :F8      | Nothing by Default; May be used in a custom script;
    #     :F9      | Calls the Debug Menu;
    #     :LEFT    | Moves the Player/Cursor to the Left.
    #     :DOWN    | Moves the Player/Cursor Downwards.
    #     :RIGHT   | Moves the Player/Cursor to the Right.
    #     :UP      | Moves the Player/Cursor Upwards.
    #=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=
    
    
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # *{} System Options
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    UseInputSystem = true     # Use the Improved Input System Included With DP Core?
                              # If not using 'Improved Input System', Leave Editable
                              # Region. You are finished here.
    
    RepeatWaitTime = 0.15     # Wait Time (in Seconds) before a Repeat is Initiated.
                              # A Repeat: is when the cursor moves inside of a 
                              # command window once again if you're holding 
                              # down a corresponding button
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # *{} PC Keyboard Options
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    PCKeyboardKeysMapping =
    {                
    #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    # PC Keyboard Buttons               => Representing Input Scheme(s)
    #
    #   If you don't want a key to represent any Input Scheme, make it an
    #   empty array ( [], ).
    #
    #   One the other hand, if you want a PC Keyboard button to represent
    #   more than one Input Scheme, you can insert multiple Input Schemes:
    #   Example:       [:CTRL, :B, ],
    #>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    
      # Letter Keys
      :A                                => [:X, ], 
      :B                                => [], 
      :C                                => [], 
      :D                                => [:Z, ], 
      :E                                => [], 
      :F                                => [], 
      :G                                => [], 
      :H                                => [], 
      :I                                => [], 
      :J                                => [], 
      :K                                => [], 
      :L                                => [], 
      :M                                => [], 
      :N                                => [], 
      :O                                => [], 
      :P                                => [], 
      :Q                                => [:L, ], 
      :R                                => [], 
      :S                                => [:Y, ], 
      :T                                => [], 
      :U                                => [], 
      :V                                => [], 
      :W                                => [:R, ], 
      :X                                => [:B, ], 
      :Y                                => [], 
      :Z                                => [:C, ],

      # Number/Symbol Keys
      :Num0                             => [], 
      :Num1                             => [], 
      :Num2                             => [], 
      :Num3                             => [], 
      :Num4                             => [],
      :Num5                             => [], 
      :Num6                             => [], 
      :Num7                             => [], 
      :Num8                             => [], 
      :Num9                             => [],

      # Qwerty Symbol Keys
      :Comma                            => [], 
      :Period                           => [], 
      :ForwardSlash                     => [],
      :SemiColon                        => [], 
      :Quote                            => [],
      :LSqrBracket                      => [],
      :RSqrBracket                      => [], 
      :BackSlash                        => [],
      :Tilde                            => [], 
      :Dash                             => [], 
      :Equals                           => [],

      # Arrow Keys
      :Left                             => [:LEFT, ], 
      :Down                             => [:DOWN, ], 
      :Right                            => [:RIGHT, ], 
      :Up                               => [:UP, ],  

      # NumPad Numbers
      :Numpad0                          => [:B, ],  
      :Numpad1                          => [],  
      :Numpad2                          => [:DOWN, ],  
      :Numpad3                          => [], 
      :Numpad4                          => [:LEFT, ], 
      :Numpad5                          => [], 
      :Numpad6                          => [:RIGHT, ], 
      :Numpad7                          => [], 
      :Numpad8                          => [:UP, ], 
      :Numpad9                          => [],

      # NumPad Math Symbols
      :Multiply                         => [], 
      :Divide                           => [],
      :Subtract                         => [], 
      :Add                              => [], 
      :Decimal                          => [],

      # Function Keys
      :F1                               => [], 
      :F2                               => [], 
      :F3                               => [], 
      :F4                               => [], 
      :F5                               => [:F5, ], 
      :F6                               => [:F6, ], 
      :F7                               => [:F7, ], 
      :F8                               => [:F8, ], 
      :F9                               => [:F9, ], 
      :F10                              => [], 
      :F11                              => [], 
      :F12                              => [],

      :LCtrl                            => [:CTRL, ], 
      :RCtrl                            => [:CTRL, ],
      :LShift                           => [:SHIFT, :A, ], 
      :RShift                           => [:SHIFT, :A, ],
      :LAlt                             => [:ALT, ], 
      :RAlt                             => [:ALT, ],
      :Enter                            => [:C, ],  
      :Backspace                        => [],
      :Spacebar                         => [:C, ],  
      :Tab                              => [],
      :Escape                           => [:B, ], 

      :Capslock                         => [],  
      :ScrollLock                       => [], 
      :NumLock                          => [],
      :PrintScreen                      => [],  
      :Pause                            => [],
      :Insert                           => [:B, ],
      :Delete                           => [], 
      :Home                             => [],
      :End                              => [],
      :PageUp                           => [:L, ],
      :PageDown                         => [:R, ],
    }
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # *{} Xbox 360 Controller Options
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    UseXbox360ControllerInput     = true   # Allow the Xbox 360 Controller to be used as an Input Device? (Only if Using New Input System)
    
    UseLeftStickAxisForMovement   = true   # Use the Left Stick for Directional Movement? ie. Move Up, Down, Left Right 
    UseRightStickAxisForMovement  = true   # Same as above but for the Right Stick
    
    AxisPowerRegister             = 30     # How Far Must an Axis Stick be Moved Before it Registers as Moved?            Default: 30% 
    TriggerPowerRegister          = 30     # How Far Must the Triggers be Pulled Before They Register as Being Pressed?;  Default: 30%
    
    
    # Control Mapping for the Xbox360 Controller
    Xbox360ControllerMapping =
    {
      :A                                => [:C, ],    
      :B                                => [:X, ],    
      :X                                => [:B, ],   
      :Y                                => [:Y, ],   
      :Start                            => [:Z, ],   
      :Back                             => [:C, ],               
      :LB                               => [:L, ],   
      :RB                               => [:R, ],                           
      :LStick                           => [:Z, ],            # Left-Stick Click 
      :RStick                           => [:Z, ],            # Right-Stick Click
      :DPadUp                           => [:UP, ],  
      :DPadDown                         => [:DOWN, ],  
      :DPadLeft                         => [:LEFT, ], 
      :DPadRight                        => [:RIGHT, ],
      :LT                               => [],                # Left Trigger
      :RT                               => [],                # Right Trigger
    }
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # *{} PS3 Controller Options
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    UsePS3ControllerInput = true      # Allow the PS3 Contoller to be used as an Input Device?       (Only if Using New Input System)
    
    # Control Mapping for the PS3 Controller
    PS3ControllerMapping =
    { 
      :Cross                            => [:B, ],  
      :Square                           => [:Y, ],
      :Circle                           => [:X, ],   
      :Triangle                         => [:C, ],  
      :Start                            => [:Z, ], 
      :Select                           => [:Z, ],                                      
      :L1                               => [:L, ],  
      :R1                               => [:R, ],                                       
      :L2                               => [:C, ],  
      :R2                               => [:Z, ],                                       
      :DPadUp                           => [:UP, ], 
      :DPadDown                         => [:DOWN, ],  
      :DPadLeft                         => [:LEFT, ],  
      :DPadRight                        => [:RIGHT, ], 
    }
    #-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= 
    #                                           \/
    #               End of Editable Region      /\
    #                                           \/
    #-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
  end
end








#=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=
# **  New Class:   Screen Filled Sprite
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Creates a sprite which automatically fills the screen and can be disposed
# without needing to dispose of the included bitmap. 
# Everything beyond initialisation is still accessed the way a normal 
# Sprite is accessed.
#~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~
module DPCore
  class ScreenFilledSprite < Sprite
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # * Derived Method:   Object Initialisation
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # Filename:   Filename of the Sprite Image, includes path if necessary.
    # Visible:    Will be visible? : true by default
    # Z:          The Z Value of this sprite on initialisation : 1 by default
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def initialize(filename, visible = true, z = 1)
      super()
      self.bitmap   = Bitmap.new(filename)
      self.x        = 0
      self.y        = 0
      self.z        = z
      self.zoom_x   = (Graphics.width.to_f / self.bitmap.width)
      self.zoom_y   = (Graphics.height.to_f / self.bitmap.height)
      self.visible  = visible
    end
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # * Derived Method:   Dispose
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def dispose()
      self.bitmap.dispose()     unless self.bitmap.nil? || self.bitmap.disposed?
      super()
    end
  end
end







#=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=
# **  New Class:   Time Tracker
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Once initialised, this class keeps track of time in seconds.
# All instances of the TimeTracker class are updated automatically if you
# have chosen to allow themselves to be added to the list (true by default).
#
# Once initialised, simply call the ' time_up? ' method to see if the time
# is up for this TimeTracker.
# Call ' dispose ' once finished.
#~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~
module DPCore
  class TimeTracker
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # *+ Public Instance Variables
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    attr_reader :current_frame  # Current Frame the Tracker is on: Use to Reset Tracker.
    attr_reader :seconds        # Seconds until TimeUp: Change to Increase/Decrease the Wait Time.
    attr_reader :scenetype      # Scenetype: If not nil, this TimeTracker will only Update if SceneManager is in that Specified Scene.
    
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # *- Private Static Variables
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @@timetracker_list = []     # Static Variable List/Array containing active instances of TimeTrackers

    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # * New Method:   Object Initialisation
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # Time:             How long (in seconds) until this TimeTracker has been successful
    # Scene Class:      Which Scene Can this TimeTracker be updated in : nil by default, which means it can always be updated no matter what scene it is.
    # Add Self To List: Add Self to the Automatic Update List? : false by default. If not true, you need to update the TimeTracker manually
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def initialize(time, scene_class = nil, add_self_to_list = false)
      @current_time   = 0.0
      @finish_time    = time.to_f
      @scenetype      = scene_class
      @time_up        = false
      
      @@timetracker_list.push(self) if add_self_to_list
    end
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # * New Method:   Dispose
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def dispose()
      @@timetracker_list.reject! { |tracker| tracker == self }
    end
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # * New Method:   Update
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def update()
      if !@time_up
        @current_time  += (1.0 / Graphics.frame_rate)
        @time_up        = (@current_time > @finish_time)
        @current_time   =  @finish_time if @time_up
      end
    end
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # * New Method:   Reset
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def reset()
      @current_time = 0.0
      @time_up      = false
    end
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # * New Method:   Set Current Time
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def set_current_time(time)
      @current_time = time
      @time_up      = (@current_time > @finish_time)
      @current_time =  @finish_time if @time_up
    end
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # * New Method:   Set Finish Time
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def set_finish_time(time)
      @finish_time  = time
      @time_up      = (@current_time > @finish_time)
      @current_time =  @finish_time if @time_up
    end
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # * New Method:   Get Current Time (in seconds)
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def get_current_time()
      return @current_time
    end
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # * New Method:   Is Time Up?
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def time_up?()
      return @time_up
    end
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # * New Method:   Get Total Completion Percentage
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def get_completion_percentage()
      return (@current_time / @finish_time)
    end
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # * New Method:   Get TimeTracker List
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def self.get_timetracker_list()
      return @@timetracker_list
    end
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # * New Method:   Update TimeTrackers
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def self.update_timetrackers()
      @@timetracker_list.each do |tracker|
        tracker.update() unless !tracker.scenetype.nil? && 
                                  !SceneManager.scene_is?(tracker.scenetype)
      end
    end
  end
end


class Scene_Base
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # *= Alias Listings
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  alias_method(:dp3_dpcore_scenebase_update_axxz,                  :update)
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * Aliased Method:   Update
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def update(*args)
    dp3_dpcore_scenebase_update_axxz(*args)
    DPCore::TimeTracker.update_timetrackers()
  end
end







#=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=
# **  Edited Classes:   Scene Menu Quick Option Creation
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# This edit allows for quick Scene Menu Command Creation.
# alias ' dp3_dpcore_get_original_commands ' and follow the instructions 
# of that method.
#~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~
class Window_MenuCommand < Window_Command
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # *= Alias Listings
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  alias_method(:dp3_dpcore_addorigcomnd_axxz,       :add_original_commands)
  alias_method(:dp3_dpcore_activate_axxz,           :activate             )
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * New Method:   Get Original Commands
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  #   hash = alias
  #   hash[ "label" ] = {
  #     :enabled    => true/false,
  #     :method_ref => method(:method_name),
  #   }
  #   return hash
  #
  #--------------------OR-------------------------------------------------
  #   hash = { 
  #             "label" => {
  #                           :enabled    =>  true/false,
  #                           :method_ref =>  method(:method_name),
  #                        }
  #          }
  #   return hash.merge( alias )
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def dp3_dpcore_get_original_commands()
    return {}
  end
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * Aliased Method: For Adding Original Commands
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def add_original_commands(*args)
    dp3_dpcore_addorigcomnd_axxz(*args) # Call Original Method
    
    original_commands = dp3_dpcore_get_original_commands()
    original_commands.each_key do |key|
      add_command(key, key.to_sym, original_commands[key][:enabled])
    end
  end
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * Aliased Method: Activate
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def activate(*args)
    dp3_dpcore_activate_axxz(*args) # Call Original Command
    
    original_commands = dp3_dpcore_get_original_commands()
    original_commands.each_key do |key|
      set_handler(key.to_sym, original_commands[key][:method_ref])
    end
  end
end





#=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=
# **  New Module:   GameEvents
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# This Module Will interact with GameEvents. For now the only code here is:
#     * Get First Comment in Event Page
#     * Get All Comments in Event Page
#~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~
module DPCore
  module GameEvents
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # * New Method: Get Event First Comment
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def self.get_event_first_comment( event_id )
      comments = get_event_all_comments( event_id )
      return comments[0]  unless comments.empty?
      return ""
    end
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # * New Method: Get Event All Comments
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def self.get_event_all_comments( event_id )
      comments = []
      event = $game_map.events[ event_id ]
      if event.list
        event.list.each do |command|
          case command.code
          when 108
            comments.push( command.parameters[0] )
          when 408
            comments.last += command.parameters[0]
          end
        end
      end
      return comments
    end
  end
end





#=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=
# *****  :L2         Improved                                  :R2   *****
# *****  :LT                  Input                            :RT   *****
# *****  :Q                         System                     :R    *****
#=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=
if DPCore::InputHandler::UseInputSystem # Only Define the System if it's going to be used
#=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=


  #=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=
  # **  New Module:   Input Info
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # This Module grants information used for the newfound input systems
  #~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~
  module Input
    module InputInfo
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      # *^ Data Information
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      RepeatWaitTime = DPCore::InputHandler::RepeatWaitTime.to_f
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      # *^ Repeat System ~ All Input Systems
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      class Repeated
        def initialize;   @timer = DPCore::TimeTracker.new(RepeatWaitTime); end
        def reset;        @timer.reset();                                   end
        def update;       @timer.update();                                  end
        def activate;     @timer.set_current_time(RepeatWaitTime + 1.0);    end
        def active?;      return @timer.time_up?();                         end
      end
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      # *^ Vibration Timer ~ Only Xbox360 Controller
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      class VibrationTimer
        def initialize;    @timer,@active = DPCore::TimeTracker.new(0), false; end
        def reset;         @timer.reset();                                     end
        def update;        @timer.update() if active?();                       end
        def set_active(b); @active = b;                                        end
        def set_finish(f); @timer.set_finish_time(f);                          end
        def active?;       return @active;                                     end
        def complete?;     return @timer.time_up?();                           end
      end
    end
  end

  
  #=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=
  # **  New Class:   Input Base
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # This Class defines the Base Code for the new Input System. This is used
  # for all controller Input and the PC Keyboard
  #~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~
  module Input
    class Input_Base
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      # * New Method: Object Initialisation
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      def initialize
        reset()
      end
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      # * New Method: Reset
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      def reset
        @input = Hash.new()
      end
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      # * New Method: Get New Key Info Hash
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      def new_key_info
        return { :triggered => false, :pressed => false, :repeated => Input::InputInfo::Repeated.new }
      end
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      # * New Method: Set Key/Button Status
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      def set_key_status(index, active)
        if active        
          update_key(@input[index])
        elsif @input[index][:pressed]
          reset_key(@input[index])
        end
      end
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      # * New Method: Update Key
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      def update_key(input)
        input[:triggered] = !input[:pressed]
        input[:pressed]   = true
        update_key_repeat(input)
      end
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      # * New Method: Update Key Repeat
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      def update_key_repeat(input)
        if input[:triggered]
          input[:repeated].activate()
        else
          input[:repeated].reset()     if input[:repeated].active?()
          input[:repeated].update()
        end
      end
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      # * New Method: Reset Key
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      def reset_key(input)
        input[:triggered] = false
        input[:pressed]   = false
        input[:repeated].reset()
      end
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      # * New Methods: Key Was Triggered?
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      def trigger?(rep)
        return @input[ get_rep_symbols()[rep] ][:triggered] rescue false
      end
      
      def triggered?(rep)
        return trigger?(rep)
      end
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      # * New Methods: Key Is Pressed?
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      def press?(rep)
        return @input[ get_rep_symbols()[rep] ][:pressed] rescue false
      end
      
      def pressed?(rep)
        return press?(rep)
      end
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      # * New Methods: Key Is on Repeat?
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      def repeat?(rep)
        return @input[ get_rep_symbols()[rep] ][:repeated].active?() rescue false
      end
      
      def repeated?(rep)
        return repeat?(rep)
      end
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      # * New Methods: Key Is Released?
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      def release?(rep)
        return !press?(rep)
      end
      
      def released?(rep)
        return release?(rep)
      end 
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      # * New Methods: Get Currently Triggered Keys
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      def currently_triggered_keys
        return @input.select { |k, v| v[:triggered] }.collect{ |k| get_rep_symbols().key(k[0]) }
      end
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      # * New Methods: Get Currently Pressed Keys
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      def currently_pressed_keys
        return @input.select { |k, v| v[:pressed] }.collect{ |k| get_rep_symbols().key(k[0]) }
      end
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      # * New Methods: Get Currently Repeated Keys
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      def currently_repeated_keys
        return @input.select { |k, v| v[:repeated].active?() }.collect{ |k| get_rep_symbols().key(k[0]) }
      end
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      # * New Methods: Get Currently Released Keys
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      def currently_released_keys
        return @input.select { |k, v| !v[:pressed] }.collect{ |k| get_rep_symbols().key(k[0]) }
      end
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      # * New Method: Get The Respective Input Devices's Representing Symbols
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      def get_rep_symbols
        return {}
      end
    end
  end

  
  #=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=
  # **  New Class:   Controller Base
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # This Class defines the Base Code for the Xbox360/PS3/Etc controllers
  #~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~
  module Input
    class Controller_Base < Input::Input_Base
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      # * New Method: Reset
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      def reset
        super()
        @connected = false
      end
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      # * New Method: Controller Is Connected?
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      def connected?
        return @connected
      end
    end
  end


  #=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=
  # **  New Class:   Xbox360 Controller Input
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # This Class interacts with an Xbox360 Controller connected to the PC,
  # reading and passing information to/from the controller.
  #~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~
  if DPCore::InputHandler::UseXbox360ControllerInput # Allow Xbox360 Controller Input?
  #~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~
    module Input
      class Xbox360Controller < Input::Controller_Base
        begin
          #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
          # *^ Controller Representing Symbols
          #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
          Representatives =
          {
            :A      => 0,  :B        => 1,   :X => 2,          :Y => 3,          # Main Buttons
            :Start  => 4,  :Back     => 5,                                       # Operation Buttons
            :LB     => 6,  :RB       => 7,                                       # Shoulder Buttons
            :LStick => 8,  :RStick   => 9,                                       # Thumbstick Clicks
            :DPadUp => 10, :DPadDown => 11,  :DPadLeft => 12,  :DPadRight => 13, # DPad Directions
            :LT     => 14, :RT       => 15,                                      # Triggers
            :LSHorz => 16, :LSVert   => 17,                                      # Left-Stick Axis (Returns between -127 and +127)
            :RSHorz => 18, :RSVert   => 19,                                      # Right-Stick Axis (Returns between -127 and +127)
          }
          #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
          # *^ Data Information
          #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
          MinButtonID           = Representatives.min_by{ |k, v| v }[1]              # Lowest Button ID
          MaxButtonID           = Representatives.max_by{ |k, v| v }[1]              # Highest Button ID
          ButtonIterationRange  = Representatives[:A]..Representatives[:DPadRight]   # Iteration for Buttons
          TriggerIterationRange = Representatives[:LT]..Representatives[:RT]         # Trigger Iteration Range
          HashPressIterRange    = Representatives[:A]..Representatives[:RT]          # Total Press Iteration Range (For Hash Size)
          AxesIterationRange    = Representatives[:LSHorz]..Representatives[:RSVert] # Iteration for Axes
          TriggerPowerRegister  = DPCore::InputHandler::TriggerPowerRegister
          AxisPowerRegister     = (127.0 * (DPCore::InputHandler::AxisPowerRegister.to_f / 100)).to_i
          #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
          # *^ DLL Information
          #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
          IsConnected = Win32API.new('System/Xbox360 Controller Input', 'ControllerConnected', '', 'n')
          GetInput    = Win32API.new('System/Xbox360 Controller Input', 'GetControllerInput', 'n', 'n')
          Vibration   = Win32API.new('System/Xbox360 Controller Input', 'VibrateController', 'nn', '')
          #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
          # * Derived Method: Reset
          #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
          def reset
            super()
            @vib_timer = Input::InputInfo::VibrationTimer.new()
            
            for i in HashPressIterRange
              @input[i] = new_key_info()
            end
            for i in AxesIterationRange
              @input[i] = 0
            end 
          end
          #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
          # * New Method: Update Xbox 360 Controller
          #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
          def update
            update_connection()
            if @connected
              update_buttons()
              update_axes()
              update_vibration()
            end
          end
          #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
          # * New Method: Update Xbox 360 Controller Connection Status
          #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
          def update_connection
            if @connected    != (IsConnected.call() == 1) # If Connection Status is not equal to Actual Connection Status
              @connected      = !@connected               # Reverse Connection Status
              reset()        if !@connected               # If no longer Connected to the Controller, Reset Controller Input
            end
          end
          #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
          # * New Method: Update Xbox 360 Controller Buttons
          #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
          def update_buttons
            for i in ButtonIterationRange
              set_key_status(i, GetInput.call(i) != 0)
            end
            for i in TriggerIterationRange
              set_key_status(i, GetInput.call(i) > TriggerPowerRegister)
            end
          end
          #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
          # * New Method: Update Xbox 360 Controller Axes
          #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
          def update_axes
            for i in AxesIterationRange
              @input[ i ] = GetInput.call(i)
            end
            
            update_lstick_movement() if DPCore::InputHandler::UseLeftStickAxisForMovement
            update_rstick_movement() if DPCore::InputHandler::UseRightStickAxisForMovement
          end
          #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
          # * New Method: Update Xbox 360 LStick Movement
          #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
          def update_lstick_movement
            if axis(:LSHorz) > AxisPowerRegister
              set_key_status(get_rep_symbols()[:DPadRight], true)
            elsif axis(:LSHorz) < -AxisPowerRegister
              set_key_status(get_rep_symbols()[:DPadLeft], true)
            end
            
            if axis(:LSVert) > AxisPowerRegister
              set_key_status(get_rep_symbols()[:DPadUp], true)
            elsif axis(:LSVert) < -AxisPowerRegister
              set_key_status(get_rep_symbols()[:DPadDown], true)
            end
          end
          #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
          # * New Method: Update Xbox 360 RStick Movement
          #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
          def update_rstick_movement
            if axis(:RSHorz) > AxisPowerRegister
              set_key_status(get_rep_symbols()[:DPadRight], true)
            elsif axis(:RSHorz) < -AxisPowerRegister
              set_key_status(get_rep_symbols()[:DPadLeft], true)
            end
            
            if axis(:RSVert) > AxisPowerRegister
              set_key_status(get_rep_symbols()[:DPadUp], true)
            elsif axis(:RSVert) < -AxisPowerRegister
              set_key_status(get_rep_symbols()[:DPadDown], true)
            end
          end
          #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
          # * New Method: Update Xbox 360 Controller Vibration
          #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
          def update_vibration
            @vib_timer.update()                                      # Update Vibration Timer if it Exists
            vibrate_controller(0, 0, 0.0) if @vib_timer.complete?()  # Turn off Vibration if Timer Finished
          end
          #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
          # * New Method: Vibrate Xbox 360 Controller
          #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
          def vibrate_controller(lpower, rpower, duration)
            return unless connected?()
            lpower = [0, [lpower, 100].min].max
            rpower = [0, [rpower, 100].min].max
            Vibration.call(lpower, rpower)
            
            @vib_timer.set_finish(duration)
            @vib_timer.set_active(duration > 0.0)
            @vib_timer.reset()
          end
          #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
          # * New Method: Get an Xbox 360 Controller Axis
          #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
          def axis(rep)
            return @input[ get_rep_symbols()[rep] ]  rescue 0
          end
          #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
          # * Derived Method: Get The Xbox360 Controller's Representing Symbols
          #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
          def get_rep_symbols
            return Representatives
          end
          #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
          # * New Method: Xbox360 Controller Available
          #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
          def self.available?
            return true
          end
          
        rescue
          #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
          # * New Method: Xbox360 Controller Available
          #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
          def self.available?
            return false
          end
          error_text = "Warning:\nAn error occurred while attempting to connect with the Xbox360 Controller.\n\n\n" +
                       "Causes:\n* You may not have the Xbox360 Input dll provided.\n* DirectX may not be installed on this PC. \n* Your Operating System may not be compatible with the software attempting to interact with the controller.\n\n\n" +
                       "Result:\nThe Xbox360 Controller will not be used in this session."
          Win32API.new('user32.dll', 'MessageBox', 'pppi', '').call(0, error_text, "Warning", 48) 
        end
      end
    end
  #~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~
  end # if DPCore::InputHandler::UseXbox360ControllerInput
  #~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~
  
  
  #=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=
  # **  New Class:   PS3 Controller Input
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # This Class interacts with a PS3 Controller connected to the PC,
  # reading and passing information to/from the controller.
  #~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~
  if DPCore::InputHandler::UsePS3ControllerInput # Allow PS3 Controller Input?
  #~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~
    module Input
      class PS3Controller < Input::Controller_Base
        begin
          #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
          # *^ Controller Representing Symbols
          #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
          Representatives =
          {
            :Cross  => 3,  :Circle   => 2,   :Square => 4,     :Triangle => 1,   # Main Buttons
            :Start  => 10, :Select   => 9,                                       # Operation Buttons
            :L1     => 5,  :R1       => 6,                                       # Shoulder Buttons
            :L2     => 7,  :R2       => 8,                                       # Triggers
            :DPadUp => 13, :DPadDown => 14,  :DPadLeft => 11,  :DPadRight => 12, # DPad Directions
          }
          #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
          # *^ Data Information
          #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
          MinButtonID           = Representatives.min_by{ |k, v| v }[1]         # Lowest Button ID
          MaxButtonID           = Representatives.max_by{ |k, v| v }[1]         # Highest Button ID
          ButtonIterationRange  = MinButtonID..MaxButtonID                      # Iteration for Buttons
          #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
          # *^ DLL Information
          #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
          IsConnected = Win32API.new('System/PS3 Controller Input', 'ConnectedController', '', 'n')
          GetInput    = Win32API.new('System/PS3 Controller Input', 'GetControllerInput', 'n', 'n')
          #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
          # * Derived Method: Reset
          #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
          def reset
            super()
            
            for i in ButtonIterationRange
              @input[i] = new_key_info()
            end
          end
          #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
          # * New Method: Update PS3 Controller
          #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
          def update
            update_connection()
            update_buttons()      if @connected
          end
          #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
          # * New Method: Update PS3 Controller Connection Status
          #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
          def update_connection
            if @connected    != (IsConnected.call() == 1) # If Connection Status is not equal to Actual Connection Status
              @connected      = !@connected               # Reverse Connection Status
              reset()        if !@connected               # If no longer Connected to the Controller, Reset Controller Input
            end
          end
          #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
          # * New Method: Update PS3 Controller Buttons
          #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
          def update_buttons
            for i in ButtonIterationRange
              set_key_status(i, GetInput.call(i) != 0)
            end
          end
          #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
          # * Derived Method: Get The PS3 Controller's Representing Symbols
          #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
          def get_rep_symbols
            return Representatives
          end
          #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
          # * New Method: PS3 Controller Available
          #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
          def self.available?
            return true
          end
          
        rescue
          #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
          # * New Method: PS3 Controller Available
          #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
          def self.available?
            return false
          end
          error_text = "Warning:\nAn error occurred while attempting to connect with the PS3 Controller.\n\n\n" +
                       "Causes:\n* You may not have the PS3 Input dll provided. \n* DirectX may not be installed on this PC. \n* Your Operating System may not be compatible with the software attempting to interact with the controller\n\n\n" +
                       "Result:\nThe PS3 Controller will not be used in this session."
          Win32API.new('user32.dll', 'MessageBox', 'pppi', '').call(0, error_text, "Warning", 48) 
        end
      end
    end
  #~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~
  end # if DPCore::InputHandler::UsePS3ControllerInput
  #~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~
  
  
  #=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=
  # **  New Module:   Keyboard Input
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # This Module interacts with PC Keyboard, updating which keys have been
  # pressed and triggering appropriate responses.
  #~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~
  module Input
    class PCKeyboardInput < Input::Input_Base
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      # *^ Keyboard Representing Symbols
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      Representatives =
      {                
        # Letter Keys
        :A => 65, :B => 66, :C => 67, :D => 68, :E => 69, :F => 70, 
        :G => 71, :H => 72, :I => 73, :J => 74, :K => 75, :L => 76, 
        :M => 77, :N => 78, :O => 79, :P => 80, :Q => 81, :R => 82, 
        :S => 83, :T => 84, :U => 85, :V => 86, :W => 87, :X => 88, 
        :Y => 89, :Z => 90,
        
        # Number/Symbol Keys
        :Num0 => 48, :Num1 => 49, :Num2 => 50, :Num3 => 51, :Num4 => 52,
        :Num5 => 53, :Num6 => 54, :Num7 => 55, :Num8 => 56, :Num9 => 57,
        
        # Qwerty Symbol Keys
        :Comma        => 188, :Period       => 190, :ForwardSlash => 191,
        :SemiColon    => 186, :Quote        => 222,
        :LSqrBracket  => 219, :RSqrBracket  => 221, :BackSlash    => 220,
        :Tilde        => 192, :Dash         => 189, :Equals       => 187,
        
        # Arrow Keys
        :Left => 37, :Down => 40, :Right => 39, :Up => 38,  
        
        # NumPad Numbers
        :Numpad0 => 96,  :Numpad1 => 97,  :Numpad2 => 98,  :Numpad3 => 99, 
        :Numpad4 => 100, :Numpad5 => 101, :Numpad6 => 102, :Numpad7 => 103, 
        :Numpad8 => 104, :Numpad9 => 105,
        
        # NumPad Math Symbols
        :Multiply => 106, :Divide => 111,
        :Subtract => 109, :Add    => 107, 
        :Decimal  => 110,
        
        # Function Keys
        :F1  => 112, :F2  => 113, :F3 => 114, :F4 => 115, :F5  => 116, 
        :F6  => 117, :F7  => 118, :F8 => 119, :F9 => 120, :F10 => 121, 
        :F11 => 122, :F12 => 123,
        
        :LCtrl        => 162, :RCtrl        => 163,
        :LShift       => 160, :RShift       => 161,
        :LAlt         => 164, :RAlt         => 165,
        :Enter        => 13,  :Backspace    => 8,
        :Spacebar     => 32,  :Tab          => 9,
        
        :Capslock     => 20,  :ScrollLock   => 145, :NumLock    => 144,
        :Escape       => 27,  :PrintScreen  => 44,  :Pause      => 19,
        :Insert       => 45,  :Home         => 36,  :PageUp     => 33,
        :Delete       => 46,  :End          => 35,  :PageDown   => 34,
      }
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      # *^ Data Information
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      KeysIteration = Representatives.values.sort
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      # *^ DLL Information
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      KeyState = Win32API.new('user32', 'GetAsyncKeyState', 'n', 'n')
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      # * Derived Method: Reset
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      def reset
        super() 
        for i in KeysIteration
          @input[i] = new_key_info()
        end
      end
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      # * New Method: Update PC Keyboard Input
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      def update
        for i in KeysIteration
          set_key_status(i, KeyState.call(i) != 0)
        end
      end
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      # * Derived Method: Get The PC Keyboard's Representing Symbols
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      def get_rep_symbols
        return Representatives
      end
    end
  end
  
  
  #=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=
  # **  New Class:   InputMapping
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # This Class populates itself with information on which buttons/keys for
  # each input device represents which RPGMaker Input Scheme.
  # This allows for much faster access when querying if an Input Scheme has
  # been triggered, pressed, etc
  #~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~
  module Input
    class InputMapping < Hash
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      # * Derived Method: Object Initialisation
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      def initialize
        super()
        
        get_input_symbols().each do |sym|
          create_sym_info(sym)
          assign_pc_keyboard_input(sym)
          assign_xbox360_controller_input(sym)
          assign_ps3_controller_input(sym)
          assign_additional_input(sym)
        end
      end
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      # * New Method: Get Input Symbols
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      def get_input_symbols
        return [:LEFT, :UP, :RIGHT, :DOWN, :A, :B, :C, :X, :Y, :Z, :L, :R, 
                :SHIFT, :CTRL, :ALT, :F5, :F6, :F7, :F8, :F9 ]
      end
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      # * New Method: Create Info for Symbol
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      def create_sym_info(sym)
        self[sym] = Hash.new()
      end
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      # * New Method: Assign PC Keyboard Input
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      def assign_pc_keyboard_input(sym)
        self[sym][:pc_keyboard] = DPCore::InputHandler::PCKeyboardKeysMapping.select{|k,v| v.include?(sym)}.keys
      end
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      # * New Method: Assign Xbox 360 Controller Input
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      def assign_xbox360_controller_input(sym)
        if DPCore::InputHandler::UseXbox360ControllerInput
          self[sym][:xbox360] = DPCore::InputHandler::Xbox360ControllerMapping.select{|k,v| v.include?(sym)}.keys
        end
      end
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      # * New Method: Assign PS3 Controller Input
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      def assign_ps3_controller_input(sym)
        if DPCore::InputHandler::UsePS3ControllerInput
          self[sym][:ps3] = DPCore::InputHandler::PS3ControllerMapping.select{|k,v| v.include?(sym)}.keys
        end
      end
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      # * New Method: Assign Additional Input
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      def assign_additional_input(sym)
      end
    end
  end
  
  
  #=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=
  # **  Redefined Module:   Input
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # This Module processes the User Input for the Game
  #~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~
  module Input
    class << self
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      # *^ New Constant Variables
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      UseXboxCont = DPCore::InputHandler::UseXbox360ControllerInput && Input::Xbox360Controller.available?
      UsePS3Cont  = DPCore::InputHandler::UsePS3ControllerInput     && Input::PS3Controller.available?
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      # *^ New Static Variables
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      @@xbox360_controller  = Input::Xbox360Controller.new()    if UseXboxCont
      @@ps3_controller      = Input::PS3Controller.new()        if UsePS3Cont
      @@keyboard_keys       = Input::PCKeyboardInput.new()
      @@input_mapping       = Input::InputMapping.new()
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      # * New Method: Xbox 360 Controller Connected?
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      def xbox360_controller_connected?
        return UseXboxCont && @@xbox360_controller.connected?()
      end
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      # * New Method: PS3 Controller Connected?
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      def ps3_controller_connected?
        return UsePS3Cont && !xbox360_controller_connected?() && @@ps3_controller.connected?()
      end
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      # * New Method: Get Xbox 360 Controller Instance
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      def xbox360_input
        return @@xbox360_controller
      end
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      # * New Method: Get PS3 Controller Instance
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      def ps3_input
        return @@ps3_controller
      end
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      # * New Method: Get PC Keyboard Instance
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      def pc_keyboard_input
        return @@keyboard_keys
      end
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      # * New Method: Get Input Instance
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      def get_input_instance(input_type = :pc_keyboard)
        return xbox360_input()          if input_type == :xbox360
        return ps3_input()              if input_type == :ps3
        return pc_keyboard_input()
      end
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      # * New Method: Get Input Mapping Hash Value
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      def input_mapping(sym)
        return @@input_mapping[sym]
      end
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      # * Overwritten Method: Update
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      def update
        @@xbox360_controller.update()   if UseXboxCont
        @@ps3_controller.update()       if UsePS3Cont && !xbox360_controller_connected?()
        @@keyboard_keys.update()
      end
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      # * Overwritten Method: Triggered Key?
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      def trigger?(sym)
        return true if xbox360_controller_connected?() && @@input_mapping[sym][:xbox360].any?{|k| @@xbox360_controller.trigger?(k)}
        return true if ps3_controller_connected?() && @@input_mapping[sym][:ps3].any?{|k| @@ps3_controller.trigger?(k)}
        return @@input_mapping[sym][:pc_keyboard].any?{|k| @@keyboard_keys.trigger?(k)}
      end
      
      def triggered?(sym)
        return trigger?(sym)
      end
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      # * Overwritten Method: Pressed Key?
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      def press?(sym)
        return true if xbox360_controller_connected?() && @@input_mapping[sym][:xbox360].any?{|k| @@xbox360_controller.press?(k)}
        return true if ps3_controller_connected?() && @@input_mapping[sym][:ps3].any?{|k| @@ps3_controller.press?(k)}
        return @@input_mapping[sym][:pc_keyboard].any?{|k| @@keyboard_keys.press?(k)}
      end
      
      def pressed?(sym)
        return press?(sym)
      end
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      # * Overwritten Method: Repeated Key?
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      def repeat?(sym)
        return true if xbox360_controller_connected?() && @@input_mapping[sym][:xbox360].any?{|k| @@xbox360_controller.repeat?(k)}
        return true if ps3_controller_connected?() && @@input_mapping[sym][:ps3].any?{|k| @@ps3_controller.repeat?(k)}
        return @@input_mapping[sym][:pc_keyboard].any?{|k| @@keyboard_keys.repeat?(k)}
      end
      
      def repeated?(sym)
        return repeat?(sym)
      end
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      # * New Method: Released Key?
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      def release?(sym)
        return !press?(sym)
      end
      
      def released?(sym)
        return release?(sym)
      end
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      # * New Method: Get Currently Triggered Keys           (Returns Array)
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      def get_currently_triggered_keys(input_type = :pc_keyboard)
        return get_input_instance(input_type).currently_triggered_keys()
      end
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      # * New Method: Get Currently Pressed Keys             (Returns Array)
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      def get_currently_pressed_keys(input_type = :pc_keyboard)
        return get_input_instance(input_type).currently_pressed_keys()
      end
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      # * New Method: Get Currently Repeated Keys            (Returns Array)
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      def get_currently_repeated_keys(input_type = :pc_keyboard)
        return get_input_instance(input_type).currently_repeated_keys()
      end
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      # * New Method: Get Currently Released Keys            (Returns Array)
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      def get_currently_released_keys(input_type = :pc_keyboard)
        return get_input_instance(input_type).currently_released_keys()
      end
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      # * Overwritten Method: Dir4
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      def dir4
        return 2 if press?(:DOWN)
        return 8 if press?(:UP)
        return 4 if press?(:LEFT)
        return 6 if press?(:RIGHT)
        return 0
      end
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      # * Overwritten Method: Dir8
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      def dir8
        if press?(:DOWN)
          return 1 if press?(:LEFT)
          return 3 if press?(:RIGHT)
          return 2
        elsif press?(:UP)
          return 7 if press?(:LEFT)
          return 9 if press?(:RIGHT)
          return 8
        else
          return 4 if press?(:LEFT)
          return 6 if press?(:RIGHT)
          return 0
        end
      end
    end
  end
  
  
  
  
  #=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=
  # ** Game_Interpreter
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  #  An interpreter for executing event commands. This class is used within 
  #  the Game_Map, Game_Troop, and Game_Event classes.
  #~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~
  class Game_Interpreter
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # * New Method: Vibrate Controller
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def vibrate_controller(lpower, rpower = nil, duration = nil)
      return unless Input.xbox360_controller_connected?()
      if !duration.nil?     # Duration Used?
        Input.xbox360_input.vibrate_controller(lpower.to_i, rpower.to_i, duration.to_f)
      elsif !rpower.nil?    # If Duration not Used, perhaps it was defined as the RightPower
        Input.xbox360_input.vibrate_controller(lpower.to_i, lpower.to_i, rpower.to_f)
      else                  # Otherwise, Screw it! Forever Vibrate
        Input.xbox360_input.vibrate_controller(lpower.to_i, lpower.to_i, 0.0)
      end
    end
  end


#=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=
end # if DPCore::InputHandler::UseInputSystem
#=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=