#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
#             Metronome Skill in Battle
#             Author: DiamondandPlatinum3
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#  Description:
#
#    This script puts in a skill similar to pokemon's metronome, in the sense
#    that skills will be chosen at random to be used if this skill is used.
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#------------------------------------------------------------------------------
#  Instructions:
#  
#     Simply create a new skill in the database and call it whatever you want,
#     set the scope to random enemies (so you don't actually have to choose an 
#     enemy in battle when trying to use this skill) then set the skill ID below.
#
#
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
module DiamondandPlatinum3
  module MetronomeSkill
    
    # Skill ID for Metronome
    METRONOME_SKILL_ID = 127
    
    # Skill IDs that you do not wish to be selected with Metronome.
    # If you want all skills to be available, simply make the below empty
    # Skills 1-7 are already accounted for, so you do not need to insert them.
    NON_USABLE_SKILLS = [ 25, 75, 79, ]
    
  end
end





#==============================================================================
# ** Scene_Battle
#------------------------------------------------------------------------------
#  This class performs battle screen processing.
#==============================================================================
class Scene_Battle  
  #--------------------------------------------------------------------------
  # * Aliased Method: Use Skill/Item
  #--------------------------------------------------------------------------
  alias dp3_scn_battle_useitem_18j      use_item
  #--------------------------------------------------------------------------
  def use_item
    if @subject.current_action.item.is_a?(RPG::Skill) && @subject.current_action.item.id == DiamondandPlatinum3::MetronomeSkill::METRONOME_SKILL_ID
      @subject.dp3_set_metronome_skill_used(true)
      @subject.dp3_metronome_set_current_action(rand($data_skills.size - 1) + 1) while( !dp3_metronome_can_use_skill?() )
      @log_window.display_use_item(@subject, $data_skills[DiamondandPlatinum3::MetronomeSkill::METRONOME_SKILL_ID])
    end
    dp3_scn_battle_useitem_18j() # Call Original Method
  end
  #--------------------------------------------------------------------------
  # * Can Use Skill?
  #--------------------------------------------------------------------------
  def dp3_metronome_can_use_skill?()
    return false if @subject.current_action.item.id < 8 
    return false if @subject.current_action.item.id == DiamondandPlatinum3::MetronomeSkill::METRONOME_SKILL_ID
    for id in DiamondandPlatinum3::MetronomeSkill::NON_USABLE_SKILLS
      return false if @subject.current_action.item.id == id
    end
    return true
  end
end


#==============================================================================
# ** Game_Battler
#------------------------------------------------------------------------------
#  A battler class with methods for sprites and actions added. This class 
# is used as a super class of the Game_Actor class and Game_Enemy class.
#==============================================================================

class Game_Battler < Game_BattlerBase
  #--------------------------------------------------------------------------
  # * Aliased Method: Pay Cost of Using Skill
  #--------------------------------------------------------------------------
  alias dp3_metronome_gamebattler_payskillcost    pay_skill_cost
  #--------------------------------------------------------------------------
  def pay_skill_cost(skill)
    skill = $data_skills[DiamondandPlatinum3::MetronomeSkill::METRONOME_SKILL_ID] if @dp3_metronome_skill_used
    dp3_set_metronome_skill_used(false)
    dp3_metronome_gamebattler_payskillcost(skill) # Call Original Method
  end
  #--------------------------------------------------------------------------
  # * Get Current Action
  #--------------------------------------------------------------------------
  def dp3_metronome_set_current_action( skill_id )
    @actions[0].set_skill(skill_id)
  end
  #--------------------------------------------------------------------------
  # * Set Metronome Used? Instance Variable
  #--------------------------------------------------------------------------
  def dp3_set_metronome_skill_used( set )
    @dp3_metronome_skill_used = set
  end
end