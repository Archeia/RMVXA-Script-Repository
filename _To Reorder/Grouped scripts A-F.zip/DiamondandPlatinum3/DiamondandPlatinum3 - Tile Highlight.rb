#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
#             Tile Highlight
#             Version: 1.0
#             Authors: DiamondandPlatinum3
#             Date: January 10, 2013
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#  Description:
#
#    This script allows you to highlight tiles on your map, by doing so that
#    tile will also start flashing.
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#------------------------------------------------------------------------------
#  Instructions:
#
#   Use the Following Script Calls:
#
#   Script Call:  highlight_player_tile(red, green, blue)
#   This Script Call WIll Highlight the Player Tile, pass in RGB values in place
#   of the Red, Green, Blue.
#
#
#   Script Call:  highlight_event_tile(event_id, red, green, blue)
#   This Script Call will highlight the tile an event is standing on.
#   Replace event_id with the ID of the event.
#
#
#   Script Call:  highlight_map_tile(x, y, red, green, blue)
#   This Script Call will Highlight a Map Tile at a specific positon.
#   Replace X & Y with the posiion you want this to be.
#
#
#
#   Script Call:  unhighlight_player_tile()
#   This Script Call simply unhighlights the actors tile.
#
#  
#   Script Call:  unhighlight_event_tile(event_id)
#   This Script Call Simply unhighlights the tile the event is standing on.
#
#
#   Script Call:  unhighlight_map_tile(x, y)
#   This Script Call Simply unhighlights a specific Map Tile.
#
#
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
 
 
 
 
 
 
 
 
 
#==============================================================================
# ** Game_Interpreter
#------------------------------------------------------------------------------
#  An interpreter for executing event commands. This class is used within the
# Game_Map, Game_Troop, and Game_Event classes.
#==============================================================================
 
class Game_Interpreter
  #--------------------------------------------------------------------------
  # * Highlight Player Tile
  #--------------------------------------------------------------------------
  def highlight_player_tile(red, green, blue)
    return unless SceneManager.scene_is?(Scene_Map)
    return unless red.is_a?(Integer) && green.is_a?(Integer) && blue.is_a?(Integer)
    SceneManager.scene.dp3_add_tile_highlight($game_player.x, $game_player.y, [red, green, blue])    
  end
  #--------------------------------------------------------------------------
  # * Highlight Event Tile
  #--------------------------------------------------------------------------
  def highlight_event_tile(event_id, red, green, blue)
    return unless SceneManager.scene_is?(Scene_Map)
    return unless event_id > 0 && $game_map.events[event_id]
    return unless red.is_a?(Integer) && green.is_a?(Integer) && blue.is_a?(Integer)
    args = [$game_map.events[event_id].x, $game_map.events[event_id].y, [red, green, blue]]
    SceneManager.scene.dp3_add_tile_highlight( *args )    
  end
  #--------------------------------------------------------------------------
  # * Highlight Map Tile
  #--------------------------------------------------------------------------
  def highlight_map_tile(x, y, red, green, blue)
    return unless SceneManager.scene_is?(Scene_Map)
    return unless $game_map.valid?(x, y)
    return unless red.is_a?(Integer) && green.is_a?(Integer) && blue.is_a?(Integer)
    SceneManager.scene.dp3_add_tile_highlight(x, y, [red, green, blue])    
  end
  #--------------------------------------------------------------------------
  # * Unhighlight Event Tile
  #--------------------------------------------------------------------------
  def unhighlight_player_tile()
    highlight_player_tile(255, 255, 255)
  end
  #--------------------------------------------------------------------------
  # * Unhighlight Event Tile
  #--------------------------------------------------------------------------
  def unhighlight_event_tile(event_id)
    highlight_event_tile(event_id, 255, 255, 255)
  end
  #--------------------------------------------------------------------------
  # * UnHighlight Map Tile
  #--------------------------------------------------------------------------
  def unhighlight_map_tile(x, y)
    highlight_map_tile(x, y, 255, 255, 255)    
  end
end
 
 
 
 
 
#==============================================================================
# ** Scene_Map
#------------------------------------------------------------------------------
#  This class performs the map screen processing.
#==============================================================================
 
class Scene_Map < Scene_Base
  #--------------------------------------------------------------------------
  # * Add Tile Highlight
  #--------------------------------------------------------------------------
  def dp3_add_tile_highlight( x, y, colour )
    @spriteset.dp3_set_flash_tile( x, y, colour ) if @spriteset
  end
end
 
 
 
 
#==============================================================================
# ** Spriteset_Map
#------------------------------------------------------------------------------
#  This class brings together map screen sprites, tilemaps, etc. It's used
# within the Scene_Map class.
#==============================================================================
 
class Spriteset_Map
  #--------------------------------------------------------------------------
  # * Set Flash Tile
  #--------------------------------------------------------------------------
  def dp3_set_flash_tile( x, y, colour )
    if @tilemap
      if @tilemap.flash_data == nil
        @tilemap.flash_data = Table.new($game_map.width, $game_map.height)
      end
      @tilemap.flash_data[x, y] = dp3_convert_rgb_to_hex( *colour )
    end
  end
  #--------------------------------------------------------------------------
  # * Convert RGB to Hex
  #--------------------------------------------------------------------------
  def dp3_convert_rgb_to_hex( red, green, blue )
    if red    > 255; red    = 255; elsif red    < 0; red    = 0; end
    if green  > 255; green  = 255; elsif green  < 0; green  = 0; end
    if blue   > 255; blue   = 255; elsif blue   < 0; blue   = 0; end
    return ((red & 0xF0) << 4) | (green & 0xF0) | ((blue & 0xF0) >> 4)
  end
end