#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
#             Skit System
#             Version: 1.3
#             Author: DiamondandPlatinum3
#             Date: March 25, 2013    (Created)
#                   June 23, 2014 (Updated)
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#  Description:
#
#    This script recreates a 'Tales' Skit System for use in RPG Maker VXA.
#    With this script skits can be accessed anywhere if conditions are met.
#    Skits are made in event themselves with a separate event per skit, thus 
#    allowing non-scripters to make a Skit Event in a comfortable environment (events).
#
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#------------------------------------------------------------------------------
#  Instructions:
#
#  ~  A video has been made to explain how to use this script.
#     It can be seen here:    http://www.youtube.com/watch?v=uZhW5nAdods
#
#
#
#  ~  Edit the option in the Editable Region to suit your preferences.
#
#
#           --------------------Skit Event--------------------
#  ~  The first thing you need to do is to create an event with two pages.
#     one with no page conditions and the second with a Self-Switch "A" condition.
#     Page one needs an AUTORUN trigger associated with it. 
#     This Skit Event will NOT be added to the Skit list
#     until you have entered the map where this event is located.
#     
#    
#   ~ With that now done use the Script Call Command and Enter:
#         start_skit("Skit Name")
#     This lets the script know that you intend for this Event to be a Skit_Event.
#     Replace "Skit Name" with whatever you want your skit to be called.
#       ScreenShot can be found here:   http://goo.gl/5idbb
#
#
#  ~  Now below that you insert conditional branches that you require to be true
#     before the skit can be viewed
#       ScreenShot can be found here:   http://goo.gl/1YLmQ
#       
#
#  ~  This step is not necessary, but if you wish to have a 'logical or' condition
#     for your skit, you can insert the following script call:
#           skit_conditional_or
#     after your initial conditional Statements are complete
#       ScreenShot can be found here:   http://goo.gl/Hwypk
#
#
#
#  ~  Once you have finished setting up your Skit Conditions and are ready to 
#     start the eventing Phase, you must enter this script call:
#           start_skit_conversation
#     And you can now enter a complete event for your skit, including 'Show_Text',
#     'Show_Picture', the whole lot.
#       ScreenShot can be found here:   http://goo.gl/sz2Zi
#
#
#  ~  Once the Entire Eventing portion of the Skit is Completed, you have the 
#     option of setting up unavailability conditions. These are NOT necessary to
#     include, but if you want conditions where a Skit will no longer be available
#     (Seriously, once a Skit is no longer available, you can't make it available again)
#     you can use this script call:
#           start_unavailable_skit_conditions
#     And Enter Conditional Branches, same as above. You can also use the 
#     'Logical_Or' script call if you want to set multiple conditions as well.
#       ScreenShot can be found here:   http://goo.gl/qjVpV
#
#
#  ~  And you're done!
#     You do not need to include a self-switch command as the script automatically 
#     activates Self-Switch "A" for you.
#     The event is also temporarily erased from the map 'Erase Event Command'.
#     Be sure that this Skit Event has a second page with Self-Switch "A" so that
#     the skit is not called in a second time.
#
#
#
#
#         --------------------Setting Up Images--------------------
#  ~  You set up the specifics in the Editable Region, though the following 
#     screenshots can help you visualise the procedure.
#               http://goo.gl/Cxv6i
#               http://goo.gl/LlkZQ
#
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
($diamondandplatinum3_scripts ||= {})[:SkitSystem] = true
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
module DiamondandPlatinum3
  module SkitSystem
    #=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
    #                                                        -= 
    #                 Editable Region        ////            ==
    #                                                        =-
    #-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    #==========================================================
    #                     Skit Images
    #==========================================================
    Skit_Background_Image            = "Skit_Background_Image"   # Skit Background Image
    
    Skit_Animation_Button_Directory  = "Skit Button Animation"   # Folder Name of Animated Button Images
    Number_of_Images                 = 3                         # Number of Relevant Images contained in said folder?
    Animation_Wait_Timer             = 15                        # Wait Timer (in frames) before proceeding to the next animated image
    Skit_Animation_Button_Specs      = [ 20, 10, 100, 75, 75 ]   # [ X Position, Y Position, Z Position, Image Width, Image Height ]
    #==========================================================
    #                     Skit Mechanics
    #==========================================================
    Font_Size                        = 18                        # Size of Font which displays the name of Skit
    Font_Colour                      = [ 255, 255, 0 ]           # [R,G,B] Values for the Text Colour
    Font_Style                       = "(Default)"               # If Using Custom Font Style, put the Style Name here. Else leave as "(Default)"
    
    Skit_Notifications_Max_Opacity   = 150                       # Opacity of the Skit Notifications (Images and Text)
    Skit_Notifications_Fadein_Speed  = 1                         # Fade in Speed for Skit Notifications
    Skit_Notifications_Fadeout_Speed = 3                         # Fadeout Speed of Skit Notification
    
    Skit_Key                         = :Y                        # Which Key will activate Skits? (See Table Below)
                              #------------------------------------
                              # Symbol | Representing Key(s)      |
                              #------------------------------------
                              # :DOWN  | Down Arrow Key           |
                              # :LEFT  | Left Arrow Key           |
                              # :RIGHT | Right Arrow Key          |
                              # :UP    | Up Arrow Key             |
                              # :A     | Shift Key                |
                              # :B     | X & Escape Keys          | - - -> Not Recommended
                              # :C     | Z, Return & Space Keys   | - ->/
                              # :X     | A Key                    | - - >\
                              # :Y     | S Key                    | - - ->\ 
                              # :Z     | D Key                    | - - - -> Gotta Wonder how Enterbrain thought this was a good idea?
                              # :L     | Q Key                    | - - ->/
                              # :R     | W Key                    | - - >/
                              # :SHIFT | Shift Key                |
                              # :CTRL  | CTRL Key                 |
                              # :ALT   | ALT Key                  |
                              # :F5    | F5 Key                   |
                              # :F6    | F6 Key                   |
                              # :F7    | F7 Key                   |
                              # :F8    | F8 Key                   |
                              # :F9    | F9 Key                   |
                              #------------------------------------
    #-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= 
    #                                           \/
    #               End of Editable Region      /\
    #                                           \/
    #-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    #---------------------------------------------------------
    # No touchie past here unless you know what you are 
    # doing. Failure to heed this warning could cause your 
    # computer to yell and scream at you. 
    #
    # Edit at your own risk.
    #--------------------------------------------------------
    
    
    
    
    
    
    
    
    
    
    #--------------------------------------------------------------------------
    # * Word Wrapping
    #--------------------------------------------------------------------------
    def self.word_wrapping(bitmap, text, pos = 0)
      bitmap.font.bold            = true
      bitmap.font.shadow          = true
      bitmap.font.size            = Font_Size
      
      # Current Text Position
      current_text_position = 0    
      
      for i in 0..(text.length - 1)
        if text[i] == "\n"
          current_text_position = 0
          next
        end
        
        # Current Position += character width
        current_text_position += bitmap.text_size(text[i]).width
        
        # If Current Position > Window Width
        if (pos + current_text_position) >= (Graphics.width - 32)
          # Then Format the Sentence to fit Line
          current_element = i
          while(text[current_element] != " ")
            break if current_element == 0
            current_element -= 1
          end
          
          temp_text = ""
          for j in 0..(text.length - 1)
            temp_text += text[j]
            temp_text += "\n" if j == current_element
          end
          text = temp_text
          i = current_element
          current_text_position = 0
        end
      end
      return text
    end
    #--------------------------------------------------------------------------
    # * Draw Skit Text
    #--------------------------------------------------------------------------
    def self.draw_skit_text(bitmap, text)
      x = y = h = 0
      for i in 0..(text.length - 1)
        if text[i] == "\n"
          x  = 0
          y += h
          next
        end
        w = bitmap.text_size(text[i]).width
        h = bitmap.text_size(text[i]).height
        bitmap.draw_text(x, y, w * 2, h, text[i], 1)
        x += w
      end
    end
    #--------------------------------------------------------------------------
    # * Get Bitmap Dimensions Based on Text
    #--------------------------------------------------------------------------
    def self.getbitmapdimensionsbasedontext(bitmap, text)
      rwidth  = 0
      height = 0
      x = w = h = 0
      hei = 0
      for i in 0..(text.length - 1)
        if text[i] == "\n"
          rwidth = x if x > rwidth
          height += hei
          x = hei = 0
          next
        end
        w = bitmap.text_size(text[i]).width
        h = bitmap.text_size(text[i]).height
        x += w
        hei = h if h > hei
      end
      rwidth = x if x > rwidth
      height += hei 
      return Rect.new(0, 0, rwidth, height)
    end
    #--------------------------------------------------------------------------
    # * Condition Met?
    #--------------------------------------------------------------------------
    def self.condition_met?(info_array)
      case info_array[0]
      when :switch
        return $game_switches[info_array[1]] == info_array[2]
      when :variable
        value = info_array[2] ? info_array[3] : $game_variables[info_array[3]]
        return $game_variables[info_array[1]] == value    if info_array[4] == 0 # ==
        return $game_variables[info_array[1]] >= value    if info_array[4] == 1 # >=
        return $game_variables[info_array[1]] <= value    if info_array[4] == 2 # <=
        return $game_variables[info_array[1]] >  value    if info_array[4] == 3 # >
        return $game_variables[info_array[1]] <  value    if info_array[4] == 4 # <
        return $game_variables[info_array[1]] != value                          # !=
      when :timer
        return false unless $game_timer.working?
        return $game_timer.sec >= info_array[1] if info_array[2]
        return $game_timer.sec <= info_array[1]
      when :actor
        return false unless $game_actors[info_array[1]]
        return $game_party.members.include?($game_actors[info_array[1]])                  if info_array[2] == 0 # In Party
        return $game_actors[info_array[1]].name == info_array[3]                          if info_array[2] == 1 # Name
        return $game_actors[info_array[1]].class_id == info_array[3]                      if info_array[2] == 2 # Class
        return $game_actors[info_array[1]].skill_learn?($data_skills[info_array[3]])      if info_array[2] == 3 # Skill
        return $game_actors[info_array[1]].weapons.include?($data_weapons[info_array[3]]) if info_array[2] == 4 # Weapon
        return $game_actors[info_array[1]].armors.include?($data_armors[info_array[3]])   if info_array[2] == 5 # Armour
        return $game_actors[info_array[1]].state?(info_array[3])                                                # State
      when :character
        character = $game_map.interpreter.dp3_skitsystem_get_event_character(info_array[3], info_array[1])
        return false unless character
        return character.direction == info_array[2]
      when :gold
        return $game_party.gold >= info_array[1] if info_array[2] == 0 # >=
        return $game_party.gold <= info_array[1] if info_array[2] == 1 # <=
        return $game_party.gold <  info_array[1] if info_array[2] == 2 # <
      when :item
        return $game_party.has_item?($data_items[info_array[1]])
      when :weapon
        return $game_party.has_item?($data_weapons[info_array[1]], info_array[2])
      when :armour 
        return $game_party.has_item?($data_armors[info_array[1]], info_array[2])
      when :button
        return Input.press?(info_array[1])
      when :script
        return $game_map.interpreter.dp3_skitsystem_get_script_call(info_array[1])
      when :vehicle
        return $game_player.vehicle == $game_map.vehicles[info_array[1]]
      else
        return false
      end
    end
    #--------------------------------------------------------------------------
    # * Unique Skit Name?
    #--------------------------------------------------------------------------
    def self.unique_skit_name?(name)
      $game_system.dp3_skit_system_event_unseen_skit_hash.each_key do |key|
        skit = $game_system.dp3_skit_system_event_unseen_skit_hash[key]
        return false if name == skit.name
      end
      $game_system.dp3_skit_system_event_seen_skit_hash.each_key do |key|
        skit = $game_system.dp3_skit_system_event_seen_skit_hash[key]
        return false if name == skit.name
      end
      $game_system.dp3_skit_system_event_unavailable_hash.each_key do |key|
        skit = $game_system.dp3_skit_system_event_unavailable_hash[key]
        return false if name == skit.name
      end
      return true
    end
    #--------------------------------------------------------------------------
    # * Unique Skit ID?
    #--------------------------------------------------------------------------
    def self.unique_skit_id?(id)
      $game_system.dp3_skit_system_event_unseen_skit_hash.each_key do |key|
        skit = $game_system.dp3_skit_system_event_unseen_skit_hash[key]
        return false if id == skit.id
      end
      $game_system.dp3_skit_system_event_seen_skit_hash.each_key do |key|
        skit = $game_system.dp3_skit_system_event_seen_skit_hash[key]
        return false if id == skit.id
      end
      $game_system.dp3_skit_system_event_unavailable_hash.each_key do |key|
        skit = $game_system.dp3_skit_system_event_unavailable_hash[key]
        return false if id == skit.id
      end
      return true
    end
    #--------------------------------------------------------------------------
    # * Get Available Skits
    #--------------------------------------------------------------------------
    def self.get_available_skits()
      skits = []
      $game_system.dp3_skit_system_event_unseen_skit_hash.each_key do |key|
        skit = $game_system.dp3_skit_system_event_unseen_skit_hash[key]
        skits[skits.size] = skit if skit.skit_available?()
      end
      return skits
    end
    #--------------------------------------------------------------------------
    # * Get Unavailable Skits
    #--------------------------------------------------------------------------
    def self.get_unavailable_skits()
      skits = []
      $game_system.dp3_skit_system_event_unseen_skit_hash.each_key do |key|
        skit = $game_system.dp3_skit_system_event_unseen_skit_hash[key]
        skits[skits.size] = skit if skit.skit_unavailable?()
      end
      return skits
    end
  end
end



#==============================================================================
# ** Skit_Event
#------------------------------------------------------------------------------
#  A class which holds the relative information for the various user made Skits
#  including conditions for availability and unavailability and conversation.
#  Holds one Skit per class instance
#==============================================================================

class DP3_Skit_Event
  #--------------------------------------------------------------------------
  # * Public Instance Variables
  #--------------------------------------------------------------------------
  attr_reader :name                     # Skit Name
  attr_reader :id                       # Skit ID (Used for Hash Identity)
  attr_reader :conditions               # Conditions to View Skit
  attr_reader :unavailable_conditions   # Conditions to stop Skit Availability
  attr_reader :event_commands           # Event Commands
  #--------------------------------------------------------------------------
  # * Object Initialization
  #--------------------------------------------------------------------------
  def initialize()
    @name = "Skit"
    @id = 1
    @conditions = {}
    @unavailable_conditions = {}
    @event_commands = {}
  end
  #--------------------------------------------------------------------------
  # * Name=
  #--------------------------------------------------------------------------
  def name=(string)
    @name = string if string.is_a?(String)
  end
  #--------------------------------------------------------------------------
  # * ID=
  #--------------------------------------------------------------------------
  def id=(integer)
    @id = integer if integer.is_a?(Integer)
  end
  #--------------------------------------------------------------------------
  # * Conditions=
  #--------------------------------------------------------------------------
  def conditions=(conditions_array)
    return if conditions_array.empty?
    @conditions = conditions_array
  end
  #--------------------------------------------------------------------------
  # * Unavailable_Conditions=
  #--------------------------------------------------------------------------
  def unavailable_conditions=(conditions_array)
    return if conditions_array.empty?
    @unavailable_conditions = conditions_array
  end
  #--------------------------------------------------------------------------
  # * Event_Commands=
  #--------------------------------------------------------------------------
  def event_commands=(commands_hash)
    return if commands_hash.empty?
    @event_commands = commands_hash
  end
  #--------------------------------------------------------------------------
  # * Skit Available?
  #--------------------------------------------------------------------------
  def skit_available?()
    @conditions.each_key do |key|
      available = false
      @conditions[key].each do |info_array|
        available = DiamondandPlatinum3::SkitSystem::condition_met?(info_array)
        break unless available
      end
      return true if available
    end
    return false
  end
  #--------------------------------------------------------------------------
  # * Skit Unavailable?
  #--------------------------------------------------------------------------
  def skit_unavailable?()
    @unavailable_conditions.each_key do |key|
      unavailable = false
      @unavailable_conditions[key].each do |info_array|
        unavailable = DiamondandPlatinum3::SkitSystem::condition_met?(info_array)
        break unless unavailable
      end
      return true if unavailable
    end
    return false
  end
end









#==============================================================================
# ** Game_Temp
#------------------------------------------------------------------------------
#  This class handles temporary data that is not included with save data.
# The instance of this class is referenced by $game_temp.
#==============================================================================

class Game_Temp
  #--------------------------------------------------------------------------
  # * Public Instance Variables
  #--------------------------------------------------------------------------
  attr_accessor :dp3_skit_instance                # Instance of a Skit Class
  #--------------------------------------------------------------------------
  # * Object Initialization
  #--------------------------------------------------------------------------
  alias dp3_skitsystem_gametemp_initialize_wi36                    initialize
  #--------------------------------------------------------------------------
  def initialize
    @dp3_skit_instance = nil
    dp3_skitsystem_gametemp_initialize_wi36() # Call Original Method
  end
end









#==============================================================================
# ** Game_System
#------------------------------------------------------------------------------
#  This class handles system data. It saves the disable state of saving and 
# menus. Instances of this class are referenced by $game_system.
#==============================================================================

class Game_System
  #--------------------------------------------------------------------------
  # * Public Instance Variables
  #--------------------------------------------------------------------------
  attr_accessor :dp3_skit_system_event_unseen_skit_hash  # Skits That Can Be Seen, but have not yet met conditions
  attr_accessor :dp3_skit_system_event_seen_skit_hash    # Skits that have been Viewed
  attr_accessor :dp3_skit_system_event_unavailable_hash  # Skits that were not viewed and have reached the missable skit condition
  #--------------------------------------------------------------------------
  # * Alias Listings
  #--------------------------------------------------------------------------
  alias dp3_skitsystem_gamesystem_initialize_wi36                  initialize
  #--------------------------------------------------------------------------
  # * Object Initialization
  #--------------------------------------------------------------------------
  def initialize()
    @dp3_skit_system_event_unseen_skit_hash = {}
    @dp3_skit_system_event_seen_skit_hash   = {}
    @dp3_skit_system_event_unavailable_hash = {}
    
    dp3_skitsystem_gamesystem_initialize_wi36() # Call Original Method
  end
end









#==============================================================================
# ** Game_Map
#------------------------------------------------------------------------------
#  This class handles maps. It includes scrolling and passage determination
# functions. The instance of this class is referenced by $game_map.
#==============================================================================

class Game_Map
  #--------------------------------------------------------------------------
  # * Setup New Skit Event
  #--------------------------------------------------------------------------
  def dp3_skitsystem_setupnewskit
    event_page         = RPG::Event::Page.new()   # New Event Page
    event_page.trigger = 3                        # Autorun Trigger
    
    # Add in EventCommands from OriginalSkitEvent
    $game_temp.dp3_skit_instance.event_commands.each_key do |key|
      slot                             = event_page.list.size
      event_page.list[slot]            = RPG::EventCommand.new()
      event_page.list[slot].parameters = $game_temp.dp3_skit_instance.event_commands[key][0]
      event_page.list[slot].indent     = $game_temp.dp3_skit_instance.event_commands[key][1]
      event_page.list[slot].code       = $game_temp.dp3_skit_instance.event_commands[key][2]
    end
    
    # At the End of the EventCommandList, Add in an Erase_Event_Command
    slot                             = event_page.list.size
    event_page.list[slot]            = RPG::EventCommand.new()
    event_page.list[slot].parameters = []
    event_page.list[slot].indent     = 0
    event_page.list[slot].code       = 214

    
    # Make the Skit Event
    event           = RPG::Event.new(0, 0)    # X,Y Coords
    event.name      = "Skit Event"            # Name
    event.id        = self.events.size + 1    # ID is completely last event on Map
    event.pages[0]  = event_page              # Pass in Page made above
    
    # Make Game_Event
    game_event = Game_Event.new(self.map_id, event)

    # Finally Add Event in the Hash
    self.events[event.id] = game_event   
  end
end









#==============================================================================
# ** Game_Interpreter
#------------------------------------------------------------------------------
#  An interpreter for executing event commands. This class is used within the
# Game_Map, Game_Troop, and Game_Event classes.
#==============================================================================

class Game_Interpreter
  #--------------------------------------------------------------------------
  # * New Method: Get Event Character
  #--------------------------------------------------------------------------
  def dp3_skitsystem_get_event_character(map_id, event_id)
    curr_map_id = @map_id
    @map_id     = map_id
    event       = get_character(event_id)
    @map_id     = curr_map_id
    return event
  end
  #--------------------------------------------------------------------------
  # * New Method: Get Event Character
  #--------------------------------------------------------------------------
  def dp3_skitsystem_get_script_call(string)
    return eval(string)
  end
  #--------------------------------------------------------------------------
  # * Get Conditional Branch Params
  #--------------------------------------------------------------------------
  def dp3_skitsystem_getconditionbranchparams()
    array = []
    case @params[0]
      when 0;  array = [:switch,     @params[1], @params[2] == 0]
      when 1;  array = [:variable,   @params[1], @params[2] == 0,  @params[3], @params[4]]
      when 3;  array = [:timer,      @params[1], @params[2] == 0]
      when 4;  array = [:actor,      @params[1], @params[2],       @params[3]]
      when 6;  array = [:character,  @params[1], @params[2],       @map_id]
      when 7;  array = [:gold,       @params[1], @params[2]]
      when 8;  array = [:item,       @params[1]]
      when 9;  array = [:weapon,     @params[1], @params[2]]
      when 10; array = [:armour,     @params[1], @params[2]]
      when 11; array = [:button,     @params[1]]
      when 12; array = [:script,     @params[1]]
      when 13; array = [:vehicle,    @params[1]]
    end
    return array
  end
  #--------------------------------------------------------------------------
  # * New Method: Get Skit Conditions
  #--------------------------------------------------------------------------
  def dp3_skitsystem_getskitconditions()
    skit_conditions_hash = {}
    condition_key = 1
    
    # While not EOF
    while(@list[@index])
      # Add Skit Conditions
      if @list[@index].code == 111
        @params = @list[@index].parameters
        skit_conditions_hash[condition_key] = [] if skit_conditions_hash[condition_key].nil?
        i = skit_conditions_hash[condition_key].size
        skit_conditions_hash[condition_key][i] = dp3_skitsystem_getconditionbranchparams()
      end
      
      # Check to See if Conditional Else Branching or Entering Conversation Phase
      if @list[@index].code == 355 || @list[@index].code == 655
        if @list[@index].parameters[0].include?("skit_conditional_or")
          skit_conditional_or()
          condition_key += 1
        elsif @list[@index].parameters[0].include?("start_skit_conversation")
          start_skit_conversation()
          @index += 1
          break
        end
      end
      @index += 1
    end
    return skit_conditions_hash
  end
  #--------------------------------------------------------------------------
  # * New Method: Get Skit Conversation Commands
  #--------------------------------------------------------------------------
  def dp3_skitsystem_getskitconversationcommands()
    event_lines = {}
    event_key = 1
    
    # While not EOF
    while(@list[@index])
      # Check Script Calls For Next Phase
      if @list[@index].code == 355 || @list[@index].code == 655
        if @list[@index].parameters[0].include?("start_unavailable_skit_conditions")
          start_unavailable_skit_conditions()
          @index += 1
          break
        end
      end
      # Add Event Command to List
      event_lines[event_key]    = []
      event_lines[event_key][0] = @list[@index].parameters
      event_lines[event_key][1] = @list[@index].indent
      event_lines[event_key][2] = @list[@index].code
      event_key += 1
      @index += 1
    end
    return event_lines
  end
  #--------------------------------------------------------------------------
  # * New Method: Get Skit Unavailable Conditions
  #--------------------------------------------------------------------------
  def dp3_skitsystem_getskitunavailableconditions()
    skit_conditions_hash = {}
    return skit_conditions_hash unless @list[@index] # Not EOF
    command_key = 1
    
    # While not EOF
    while(@list[@index])
      # Check if Conditional Else Branching is being Made
      if @list[@index].code == 355 || @list[@index].code == 655
        if @list[@index].parameters[0].include?("skit_conditional_or")
          skit_conditional_or()
          command_key += 1
        end
      end
      
      # Add Skit Conditions
      if @list[@index].code == 111
        @params = @list[@index].parameters
        skit_conditions_hash[command_key] = [] if skit_conditions_hash[command_key].nil?
        i = skit_conditions_hash[command_key].size
        skit_conditions_hash[command_key][i] = dp3_skitsystem_getconditionbranchparams()
      end
      @index += 1
    end
    return skit_conditions_hash
  end
  #--------------------------------------------------------------------------
  # * New Method: Start Skit
  #--------------------------------------------------------------------------
  def start_skit(skit_name)
    # Set up Skit Name & ID
    skit_name = skit_name.is_a?(String) ? skit_name.gsub(/[\n\r]+/, "") : "Skit"
    skit_id   = 1
    
    # Move Past this Script Call
    @index += 1
    
    # We're looking for a Conditional Branch to use for the skit
    while(@list[@index].code != 111)    # Conditional Branch
      return unless @list[@index]       # Exit if EOF is Reached
      execute_command()
      @index += 1
    end
    
    # Skit Available Conditions
    skit_conditions_hash = dp3_skitsystem_getskitconditions()
    
    # Return Error if EOF is Reached
    return -1 unless @list[@index]
    
    # Skit Conversation
    event_commands = dp3_skitsystem_getskitconversationcommands()
    
    # Skit Unavailable Conditions
    skit_unavailable_conditions_hash = dp3_skitsystem_getskitunavailableconditions()
    
    # Unique Skit Name?
    temp_name   = skit_name
    temp_number = 1
    while(!DiamondandPlatinum3::SkitSystem::unique_skit_name?(temp_name))
      temp_number += 1
      temp_name = skit_name + "_" +
                  (temp_number < 1000 ? "0" : "") +
                  (temp_number < 100  ? "0" : "") +
                  (temp_number < 10   ? "0" : "") +
                  temp_number.to_s
    end
    skit_name = temp_name
    
    # Unique Skit ID?
    skit_id += 1 while(!DiamondandPlatinum3::SkitSystem::unique_skit_id?(skit_id))
    
    # Add Skit
    skit                        = DP3_Skit_Event.new()
    skit.name                   = skit_name
    skit.id                     = skit_id
    skit.conditions             = skit_conditions_hash
    skit.unavailable_conditions = skit_unavailable_conditions_hash
    skit.event_commands         = event_commands
    
    $game_system.dp3_skit_system_event_unseen_skit_hash[skit_id] = skit
    
    
    # Call Self_Switch "A" && Erase Event on Skit PlaceHolder Event
    @params[0] = "A"
    @params[1] = 0
    command_123()
    command_214()    
  end
  #--------------------------------------------------------------------------
  # * New Method: Start Skit Conversation
  #--------------------------------------------------------------------------
  def start_skit_conversation()
    # Only Exists just in case User Calls Method by Mistake in an unrelated Event.
    # Skit EventCommands use this method call to detect which phase it should 
    # enter, the method itself is not actually necessary.
  end
  #--------------------------------------------------------------------------
  # * New Method: Start Unavailable Skit Conditions
  #--------------------------------------------------------------------------
  def start_unavailable_skit_conditions()
  end
  #--------------------------------------------------------------------------
  # * New Method: Skit Condition 'OR'
  #--------------------------------------------------------------------------
  def skit_conditional_or()
  end
end









#==============================================================================
# ** Scene_Map
#------------------------------------------------------------------------------
#  This class performs the map screen processing.
#==============================================================================

class Scene_Map < Scene_Base
  #--------------------------------------------------------------------------
  # * Alias Listings
  #--------------------------------------------------------------------------
  alias dp3_skitsystem_scenemap_start_wi36                          start
  alias dp3_skitsystem_scenemap_terminate_wi36                      terminate
  alias dp3_skitsystem_scenemap_update_wi36                         update
  #--------------------------------------------------------------------------
  # * Aliased Method: Start
  #--------------------------------------------------------------------------
  def start
    @dp3_skit_system = DP3_Skit_System.new()
    dp3_skitsystem_scenemap_start_wi36()      # Call Original Method
  end
  #--------------------------------------------------------------------------
  # * Aliased Method: Dispose
  #--------------------------------------------------------------------------
  def terminate()
    @dp3_skit_system.dispose()
    dp3_skitsystem_scenemap_terminate_wi36()  # Call Original Method
  end
  #--------------------------------------------------------------------------
  # * Aliased Method: Frame Update
  #--------------------------------------------------------------------------
  def update
    @dp3_skit_system.update()
    dp3_skitsystem_scenemap_update_wi36()     # Call Original Method
  end
end









#==============================================================================
# ** DP3_Skit_Sytem
#------------------------------------------------------------------------------
#  This class manages the Skit System Display on the Map.
#==============================================================================

class DP3_Skit_System
  include DiamondandPlatinum3::SkitSystem
  #--------------------------------------------------------------------------
  # * Skit Instance (Getter|Setter)
  #--------------------------------------------------------------------------
  def skit_instance;       return $game_temp.dp3_skit_instance;  end
  def skit_instance=(obj); $game_temp.dp3_skit_instance = obj;   end
  #--------------------------------------------------------------------------
  # * New Method: Object Initialization
  #--------------------------------------------------------------------------
  def initialize()
    initialise_instance_variables()
    create_button_animation_sprites()
    create_background_sprite()
  end
  #--------------------------------------------------------------------------
  # * New Method: Dispose
  #--------------------------------------------------------------------------
  def dispose()
    dispose_button_animation_sprites()
    dispose_background_sprites() 
    self.skit_instance = nil
  end
  #--------------------------------------------------------------------------
  # * New Method: Update
  #--------------------------------------------------------------------------
  def update()    
    
    # If No Skit Instance is available or Game Is Busy, Fadeout Images
    if $game_message.busy?
      fadeout_skit_images()
      return
    elsif self.skit_instance.nil?
      fadeout_skit_images()
    end
    

    remove_unavailable_skits()    # Find any unavailable Skits and remove them
    
    if !self.skit_instance.nil?                 # If Game_Temp is holding a Skit For Us
      if skit_instance.skit_available?()
        update_skit_images()                        # Update Button Animation
        fadein_skit_images()                        # Show Skit Images
        play_skit() if Input.trigger?(Skit_Key)     # And if SkitButton is Triggered, Play Skit
      else
        self.skit_instance = nil
      end
    else
      check_for_available_skit()    # Look for any Available Skit
    end
  end
  #--------------------------------------------------------------------------
  # * New Method: Initialise Skit System Instance Variables
  #--------------------------------------------------------------------------
  def initialise_instance_variables()
    @skitanimatedbuttonspriteshash  = {}
    @skitbackgroundspritearray      = []
  end
  #--------------------------------------------------------------------------
  # * New Method: Create Skit Button Animation Sprites
  #--------------------------------------------------------------------------
  def create_button_animation_sprites()
    path = Skit_Animation_Button_Directory + "/"
    for i in 1..Number_of_Images
      sprite          = Sprite.new()
      sprite.bitmap   = Cache.picture(path + i.to_s)
      sprite.x        = Skit_Animation_Button_Specs[0]
      sprite.y        = Skit_Animation_Button_Specs[1]
      sprite.z        = Skit_Animation_Button_Specs[2]
      sprite.zoom_x   = Skit_Animation_Button_Specs[3].to_f / sprite.bitmap.width
      sprite.zoom_y   = Skit_Animation_Button_Specs[4].to_f / sprite.bitmap.height
      sprite.opacity  = 0
      sprite.visible  = false
      @skitanimatedbuttonspriteshash[i] = sprite
    end
    @skitanimatedbuttonspriteshash[:current_frame]     = 1
    @skitanimatedbuttonspriteshash[:current_frametime] = 1000
  end
  #--------------------------------------------------------------------------
  # * New Method: Create Skit Background Sprite
  #--------------------------------------------------------------------------
  def create_background_sprite()
    sprite          = Sprite.new()
    sprite.bitmap   = Cache.picture(Skit_Background_Image)
    sprite.opacity  = 0
    @skitbackgroundspritearray[0] = sprite      #[1] Becomes Another Sprite Defined Later
  end
  #--------------------------------------------------------------------------
  # * New Method: Create Skit Notification
  #--------------------------------------------------------------------------
  def create_skit_notification()
    anim_pos                    = *Skit_Animation_Button_Specs      
    bitmap                      = @skitbackgroundspritearray[0].bitmap
    text                        = self.skit_instance.name
    text                        = DiamondandPlatinum3::SkitSystem::word_wrapping(bitmap, text, anim_pos[0] + anim_pos[3] + 5)
    rect                        = DiamondandPlatinum3::SkitSystem::getbitmapdimensionsbasedontext(bitmap, text)
    
    # Setup Skit Background Sprite
    sprite                      = @skitbackgroundspritearray[0]
    sprite.x                    = anim_pos[0]
    sprite.y                    = anim_pos[1] + ((anim_pos[4] * 0.5) - ((rect.height + 10) * 0.5))
    sprite.y                    = sprite.y < 1 ? 1 : sprite.y 
    sprite.z                    = anim_pos[2] - 1
    sprite.zoom_x               = (anim_pos[3] + (rect.width + 50)).to_f / sprite.bitmap.width
    sprite.zoom_y               = (rect.height + 10).to_f / sprite.bitmap.height
   
    # Setup Skit Text
    sprite                      = Sprite.new()
    sprite.bitmap               = Bitmap.new(Graphics.width, rect.height)
    sprite.bitmap.font.size     = Font_Size
    sprite.bitmap.font.bold     = true
    sprite.bitmap.font.shadow   = true
    sprite.bitmap.font.color    = Color.new(*Font_Colour)
    sprite.bitmap.font.name     = Font_Style  if Font_Style && Font_Style.upcase != "(DEFAULT)"
    sprite.x                    = anim_pos[0] + anim_pos[3] + 5
    sprite.y                    = @skitbackgroundspritearray[0].y + 5
    sprite.y                    = sprite.y < 1 ? 1 : sprite.y 
    sprite.z                    = anim_pos[2] + 1
    sprite.opacity              = 0
    
    # Dispose Old Notification if it Exists
    if @skitbackgroundspritearray[1]
      @skitbackgroundspritearray[1].bitmap.dispose()
      @skitbackgroundspritearray[1].dispose()
    end
    
    # Assign New Notification
    @skitbackgroundspritearray[1] = sprite
    DiamondandPlatinum3::SkitSystem::draw_skit_text(sprite.bitmap, text)
  end
  #--------------------------------------------------------------------------
  # * New Method: Dispose Animation Sprites
  #--------------------------------------------------------------------------
  def dispose_button_animation_sprites()
    for i in 1..Number_of_Images
      @skitanimatedbuttonspriteshash[i].bitmap.dispose()
      @skitanimatedbuttonspriteshash[i].dispose()
    end
  end
  #--------------------------------------------------------------------------
  # * New Method: Dispose Background Sprites
  #--------------------------------------------------------------------------
  def dispose_background_sprites()
    if @skitbackgroundspritearray[1]
      @skitbackgroundspritearray[1].bitmap.dispose()
      @skitbackgroundspritearray[1].dispose()
    end
    @skitbackgroundspritearray[0].bitmap.dispose()
    @skitbackgroundspritearray[0].dispose()
  end
  #--------------------------------------------------------------------------
  # * New Method: Update GameTemp Skit
  #--------------------------------------------------------------------------
  def update_gametemp_skit()
    # Get Random Available Skit
    skits = DiamondandPlatinum3::SkitSystem::get_available_skits()
    self.skit_instance = skits[rand(skits.size)] unless skits.empty?
  end
  #--------------------------------------------------------------------------
  # * New Method: Update GameTemp Skit
  #--------------------------------------------------------------------------
  def remove_unavailable_skits()
    skits = DiamondandPlatinum3::SkitSystem::get_unavailable_skits()
    skits.each do |skit|
      self.skit_instance = nil if !skit_instance.nil? && skit_instance.id == skit.id
      $game_system.dp3_skit_system_event_unavailable_hash[skit.id] = skit
      $game_system.dp3_skit_system_event_unseen_skit_hash.delete(skit.id)
    end
  end
  #--------------------------------------------------------------------------
  # * New Method: Update Skit Images
  #--------------------------------------------------------------------------
  def update_skit_images()
    @skitanimatedbuttonspriteshash[:current_frametime] += 1
    if @skitanimatedbuttonspriteshash[:current_frametime] >= Animation_Wait_Timer
      @skitanimatedbuttonspriteshash[:current_frametime] = 0
      
      frame = @skitanimatedbuttonspriteshash[:current_frame]
      @skitanimatedbuttonspriteshash[frame].visible = false
      
      @skitanimatedbuttonspriteshash[:current_frame] += 1
      if @skitanimatedbuttonspriteshash[:current_frame] > Number_of_Images
        @skitanimatedbuttonspriteshash[:current_frame] = 1
      end
      
      frame = @skitanimatedbuttonspriteshash[:current_frame]
      @skitanimatedbuttonspriteshash[frame].visible = true
    end
  end
  #--------------------------------------------------------------------------
  # * New Method: Show Skit Images
  #--------------------------------------------------------------------------
  def fadein_skit_images()
    return if @skitbackgroundspritearray[0].opacity > Skit_Notifications_Max_Opacity
    
    for i in 1..Number_of_Images
      @skitanimatedbuttonspriteshash[i].opacity += Skit_Notifications_Fadein_Speed
    end
    @skitbackgroundspritearray[0].opacity += Skit_Notifications_Fadein_Speed
    @skitbackgroundspritearray[1].opacity += Skit_Notifications_Fadein_Speed if @skitbackgroundspritearray[1]
  end
  #--------------------------------------------------------------------------
  # * New Method: Fadeout Skit Images
  #--------------------------------------------------------------------------
  def fadeout_skit_images()
    return if @skitbackgroundspritearray[0].opacity == 0
    
    for i in 1..Number_of_Images
      @skitanimatedbuttonspriteshash[i].opacity -= Skit_Notifications_Fadeout_Speed
    end
    @skitbackgroundspritearray[0].opacity -= Skit_Notifications_Fadeout_Speed
    @skitbackgroundspritearray[1].opacity -= Skit_Notifications_Fadeout_Speed if @skitbackgroundspritearray[1]
  end
  #--------------------------------------------------------------------------
  # * New Method: Check For Available Skit
  #--------------------------------------------------------------------------
  def check_for_available_skit()    
    # Find Available Skits if there are none currently available
    if self.skit_instance.nil?
      update_gametemp_skit()
      
      # If Game_Temp now has a Skit for us, draw it's name and rearrange the 
      # Skit Background Sprite to accomodate for its size/length
      if !self.skit_instance.nil?
        create_skit_notification()
      end
    end
  end
  #--------------------------------------------------------------------------
  # * New Method: Play Skit
  #--------------------------------------------------------------------------
  def play_skit()
    # Copy Skit Event into Game_Event
    $game_map.dp3_skitsystem_setupnewskit()
    
    # Add Skit to the 'Seen Skits' Hash & Remove from 'Unseen Skits' Hash
    $game_system.dp3_skit_system_event_seen_skit_hash[self.skit_instance.id] = skit_instance
    $game_system.dp3_skit_system_event_unseen_skit_hash.delete(self.skit_instance.id)
    self.skit_instance = nil
  end
end