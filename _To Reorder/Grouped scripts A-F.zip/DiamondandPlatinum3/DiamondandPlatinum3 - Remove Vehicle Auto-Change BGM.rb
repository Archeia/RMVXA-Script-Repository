#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
#             Remove Vehicle Auto-change BGM
#             Author: DiamondandPlatinum3
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#  Description:
#
#    This script will allow you to stop vehicles from changing the bgm that is
#    currently playing via the use of an event switch.
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


#///////////////////////////////////////
module DP3_Vehicle_Sound_Options #//////
#///////////////////////////////////////

# The ID of the switch which turns off changing the BGM on all vehicles
Event_Switch_ID = 10    

#//////////////////////////////////////
end #   ..  //    //    //  ..  ..  ///
#//////////////////////////////////////


class Game_Vehicle < Game_Character
  alias dp3_nobgm_during_travel get_on
  def get_on
    if $game_switches[DP3_Vehicle_Sound_Options::Event_Switch_ID]
      @driving = true
      @walk_anime = true
      @step_anime = true
      @walking_bgm = RPG::BGM.last
    else
      dp3_nobgm_during_travel
    end
  end
end