#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
#             Help Window for Choices
#             Version: 2.0
#             Authors: DiamondandPlatinum3
#             Date: December 4, 2012  (Original)
#                   December 14, 2013 (Updated)
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#  Description:
#
#    This script adds on to the default choice system, allowing you to have a 
#    help window at the top of the screen to assist players in the choices they
#    have to make
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#------------------------------------------------------------------------------
#  Instructions:
#  
#   {Note to previous users of this script: This script has updated the way you
#    Insert data. Fear not, for the old way to insert data is still available;
#    so you will not have to redo anything, however read up on the new way to
#    insert data}
#   
#
#
#   ~ To use this script, just before using a choice event, use the following 
#     script call to begin adding text to the help window:
#             add_command_list_help_text
#
#     Now using Show Text Windows, insert the text to be displayed.
#     Once the desired information is inserted, close the link with 
#     the following script call:
#             end_command_list_help_text
#
#     Continue using that same pattern until all of your choices have 
#     descriptions.
#
#   
#   ~ The Position of the Help Window depends on what position you gave the 
#     Show Text window.
#
#
#     # Example Screen Can Be Found Here:
#           http://i.imgur.com/XAkhNEf.png
#
#
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
#                  THERE IS NO EDITABLE REGION TO THIS SCRIPT
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=





#==============================================================================
# ** Game_Message
#------------------------------------------------------------------------------
#  This class handles the state of the message window that displays text or
# selections, etc. The instance of this class is referenced by $game_message.
#==============================================================================

class Game_Message
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # *= Alias Listings
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  alias_method(:dp3_gamemessage_initialize_235ufnh,               :initialize)
  alias_method(:dp3_gamemessage_clear_235ufnh,                    :clear     )
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * New Public Instance Variables
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  attr_accessor :choice_help_text              # Help Text for choices (Hash)
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * Aliased Method: Object Initialization
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def initialize()
    dp3_gamemessage_initialize_235ufnh() # Call Original Method
    @choice_help_text = Hash.new()
  end
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * Aliased Method: Clear
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def clear()
    dp3_gamemessage_clear_235ufnh() # Call Original Method
    @choice_help_text = Hash.new()
  end
end
  
  
  
  
  
  
  
  
#==============================================================================
# ** DP3_Choice_Window_Help
#------------------------------------------------------------------------------
#  This window displays help text for the choices inside of a choice window
#==============================================================================

class DP3_Choice_Window_Help < Window_Help
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * New Method: Object Initialization
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def initialize(text, position)
    super( [text.split("\n").size, 2].max )
    self.y = position * (Graphics.height - self.height) / 2
    self.openness = 0
    set_text(text)
  end
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * New Method: Immediately Open
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def immediately_open()
    self.openness = 255
  end
end








#==============================================================================
# ** Window_ChoiceList
#------------------------------------------------------------------------------
#  This window is used for the event command [Show Choices].
#==============================================================================

class Window_ChoiceList < Window_Command
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # *= Alias Listings
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  alias_method(:dp3_windowchoicelist_update_235ufnh,            :update     )
  alias_method(:dp3_windowchoicelist_select_235ufnh,            :select     )
  alias_method(:dp3_windowchoicelist_cursordown_235ufnh,        :cursor_down)
  alias_method(:dp3_windowchoicelist_cursorup_235ufnh,          :cursor_up  )
  alias_method(:dp3_windowchoicelist_open_235ufnh,              :open       )
  alias_method(:dp3_windowchoicelist_close_235ufnh,             :close      )
  alias_method(:dp3_windowchoicelist_dispose_235ufnh,           :dispose    )
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * Aliased Method: Update
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def update(*args)
    dp3_windowchoicelist_update_235ufnh(*args)
    @choicehelp_helpwindow.update() unless @choicehelp_helpwindow.nil?
  end
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * Aliased Method: Select Item
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def select(*args)
    dp3_windowchoicelist_select_235ufnh(*args)
    dp3_dispose_choicehelp_window()
    unless dp3_get_current_choice_windowinfo[0].nil?
      @choicehelp_helpwindow = DP3_Choice_Window_Help.new(*dp3_get_current_choice_windowinfo)
    end
  end
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * Aliased Method: Move Cursor Down
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def cursor_down(*args)
    dp3_windowchoicelist_cursordown_235ufnh(*args)
    @choicehelp_helpwindow.immediately_open() unless @choicehelp_helpwindow.nil?
  end
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * Aliased Method: Move Cursor Up
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def cursor_up(*args)
    dp3_windowchoicelist_cursorup_235ufnh(*args)
    @choicehelp_helpwindow.immediately_open() unless @choicehelp_helpwindow.nil?
  end
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * Aliased Method: Open
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def open(*args)
    dp3_windowchoicelist_open_235ufnh(*args) # Call Original Method
    @choicehelp_helpwindow.open() unless @choicehelp_helpwindow.nil?
  end
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * Aliased Method: Close
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def close(*args)
    @choicehelp_helpwindow.close() unless @choicehelp_helpwindow.nil?
    dp3_windowchoicelist_close_235ufnh(*args) # Call Original Method
  end
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * Aliased Method: Dispose
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def dispose(*args)
    dp3_windowchoicelist_dispose_235ufnh(*args) # Call Original Method
    dp3_dispose_choicehelp_window()
  end
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * New Method: Dispose ChoiceHelp Window
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def dp3_dispose_choicehelp_window()
    @choicehelp_helpwindow.dispose unless @choicehelp_helpwindow.nil? || @choicehelp_helpwindow.disposed?
    @choicehelp_helpwindow = nil
  end
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * New Method: Get Required Info for the Window Choice
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def dp3_get_current_choice_windowinfo()
    return [nil] if $game_message.choice_help_text[self.index].nil?
    return [$game_message.choice_help_text[self.index][:text],
            $game_message.choice_help_text[self.index][:position] ]
  end
end








#==============================================================================
# ** Game_Interpreter
#------------------------------------------------------------------------------
#  An interpreter for executing event commands. This class is used within the
# Game_Map, Game_Troop, and Game_Event classes.
#==============================================================================

class Game_Interpreter
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * New Method: Add Command List Help Text
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def add_command_list_help_text( text = nil )
    position = 0
    
    # Add Text Argument
    unless text.nil?
      text = text.gsub(/[\n\r]+/, "")
      text = text.gsub(/\\endl/, "\n")
      
    # Add Show Text Command Text Paramters
    else
      text = ""
      while( !@list[@index].nil? )
        @index += 1
        case @list[@index].code
        when 101 # Show Text Window Command
          position = @list[@index].parameters[3]
        when 401 # Show Text Line
          text += @list[@index].parameters[0] + "\n"
        when 355 # Script Command
          script = @list[@index].parameters[0] + "\n"
          while next_event_code == 655
            @index += 1
            script += @list[@index].parameters[0] + "\n"
          end
          break if script.include?("end_command_list_help_text")
        end
      end
    end
    
    # Add to List
    index = $game_message.choice_help_text.size
    $game_message.choice_help_text[index]             = Hash.new()
    $game_message.choice_help_text[index][:position]  = position
    $game_message.choice_help_text[index][:text]      = text
  end
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * New Method: End Command List Help Text
  #--------------------------------------------------------------------------
  # Method only exists in case the user actually tries to call it outside of
  # bounds.
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def end_command_list_help_text()
  end
end