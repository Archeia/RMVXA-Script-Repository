#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
#             Battle Menu At Top of Screen
#             Author: DiamondandPlatinum3
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#  Description:
#
#    This script puts the battle menu at the top of the screen rather than
#    at the bottom where it normally is. It also moves the skill and items
#    box below the battle menu, looks nicer in my opinion.
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 
 
 
#==============================================================================
# ** Scene_Battle
#------------------------------------------------------------------------------
#  This class performs battle screen processing.
#==============================================================================
 
class Scene_Battle < Scene_Base
  #--------------------------------------------------------------------------
  # * Create Information Display Viewport
  #--------------------------------------------------------------------------
  alias putwindowabove_civ_fjshr3 create_info_viewport
  def create_info_viewport
    # Call Original Method
    putwindowabove_civ_fjshr3
   
    @info_viewport.rect.y = 0
    @status_window.viewport = @info_viewport
  end
end
 
 
#==============================================================================
# ** Window_BattleSkill
#------------------------------------------------------------------------------
#  This window is for selecting skills to use in the battle window.
#==============================================================================
 
class Window_BattleSkill < Window_SkillList
  #--------------------------------------------------------------------------
  # * Object Initialization
  #     info_viewport : Viewport for displaying information
  #--------------------------------------------------------------------------
  def initialize(help_window, info_viewport)
    y = (info_viewport.rect.height + help_window.height)
    super(0, y, Graphics.width, (((info_viewport.rect.height + y) - (help_window.height + 16))))
    self.visible = false
    @help_window = help_window
    @info_viewport = info_viewport
  end
end
 
 
 
#==============================================================================
# ** Window_BattleItem
#------------------------------------------------------------------------------
#  This window is for selecting items to use in the battle window.
#==============================================================================
 
class Window_BattleItem < Window_ItemList
  #--------------------------------------------------------------------------
  # * Object Initialization
  #     info_viewport : Viewport for displaying information
  #--------------------------------------------------------------------------
  def initialize(help_window, info_viewport)
    y = (info_viewport.rect.height + help_window.height)
    super(0, y, Graphics.width, (((info_viewport.rect.height + y) - (help_window.height + 16))))
    self.visible = false
    @help_window = help_window
    @info_viewport = info_viewport
  end
end
 
 
 
#==============================================================================
# ** Window_Help
#------------------------------------------------------------------------------
#  This window shows skill and item explanations along with actor status.
#==============================================================================
 
class Window_Help < Window_Base
  #--------------------------------------------------------------------------
  # * Object Initialization
  #--------------------------------------------------------------------------
  def initialize(line_number = 2)
    if SceneManager.scene_is?(Scene_Battle)
      super(0, 120, Graphics.width, fitting_height(line_number))
    else
      super(0, 0, Graphics.width, fitting_height(line_number))
    end
  end
end


#==============================================================================
# ** Window_BattleLog
#------------------------------------------------------------------------------
#  This window is for displaying battle progress. No frame is displayed, but it
# is handled as a window for convenience.
#==============================================================================

class Window_BattleLog < Window_Selectable
  #--------------------------------------------------------------------------
  # * Object Initialization
  #--------------------------------------------------------------------------
  def initialize
    super(0, Graphics.height - window_height, window_width, window_height)
    self.z = 200
    self.opacity = 0
    @lines = []
    @num_wait = 0
    create_back_bitmap
    create_back_sprite
    refresh
  end
  #--------------------------------------------------------------------------
  # * Get Maximum Number of Lines
  #--------------------------------------------------------------------------
  def max_line_number
    return 4
  end
end