#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
#             Morality Metre for Menu
#             Version: 2.0
#             Authors: DiamondandPlatinum3
#             Date: December 8, 2012
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#  Description:
#
#    This script puts a morality bar inside of your menu, allowing you to have 
#    different colours and titles along with it.
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#------------------------------------------------------------------------------
#  Instructions:
#  
#     In the editable region below you can set up what is necessary
#
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
module DiamondandPlatinum3
  module MoralityMetre
    #===========================================
    #   Editable Region
    #===========================================
    WINDOW_X_POSITION = 0
    WINDOW_Y_POSITION = 240
    WINDOW_WIDTH      = 160
    WINDOW_HEIGHT     = 80
    WINDOW_VISIBLE    = true # Even if the window is not visible, the gauge and 
                             # name will be. They are still located inside of the 
                             # window however, so you still need to position it properly
                         
                             
    GAUGE_WIDTH   = 144  # Gauge Width in Pixels (Keep it less than the window width)
    GAUGE_HEIGHT  = 30   # Gauge Height in Pixels (Keep it less than the window height) 
    
    
    MORALITY_VARIABLE_ID    = 2     # Which Variable is holding your morality?
                                    # This is an Event Variable.
                                    
    MORALITY_VARIABLE_RANGE = 200   # The Number you put in here is the highest amount of morality
                                    # you can possibly obtain, this represents good morality
    
                                    
    NEUTRAL_RANGE = 25 # This is actually a percentage out of 100, basically by default 
                       # you can be 25% Good or Evil and still have the Neutral 
                       # Colours be shown for the gauge (albeit either darker or
                       # lighter). Once you're more good or evil than that, your
                       # other morality colours will be displayed.
                                  
                       
                                      #   Red,    Green,  Blue
    MORALITY_EVIL_COLOUR              = [ 255,    0,      0   ]
    MORALITY_EVIL_COLOUR_GRADIENT     = [ 200,    75,     25  ]
    MORALITY_NEUTRAL_COLOUR           = [ 255,    255,    255 ]
    MORALITY_NEUTRAL_COLOUR_GRADIENT  = [ 0,      127,    127 ]
    MORALITY_GOOD_COLOUR              = [ 0,      55,     200 ]
    MORALITY_GOOD_COLOUR_GRADIENT     = [ 75,     75,     200 ]
    
    
    BLUR_TEXT                   = true  # Blur Text if Evil Enough?
    MORALITY_EVIL_BLUR_POINT    = 50    # What "Percentage" of Evil do you need to 
                                        # be before the text title becomes blured?
       
    OUTLINE_TEXT                = true  # Outline Text if Good Enough?
    MORALITY_GOOD_OUTLINE_POINT = 50    # What Percentage of good do you have to 
                                        # be before the text title has a holy outline?
    
                                     
    # In this section: If your Morality variable is equal to or higher than that 
    # number, the Line of text next to it will be your title.
    # You can add or remove lines by copy-paste / removing lines
    #-------------------------------------------
    MORALITY_NAME = [ # No touching this line
    #-------------------------------------------
    [ 0,    "Lucifer"     ],
    [ 15,   "Evil"        ],
    [ 45,   "Terrible"    ],
    [ 70,   "Jerk"        ],
    [ 90,   "Neutral"     ],
    [ 110,  "Kind"        ],
    [ 140,  "Hero"        ],
    [ 170,  "Angel"       ],
    [ 190,  "Benevolent"  ],
    #===========================================
    ]     # End of Editable Region
    #===========================================
  end
end


#==============================================================================
# ** Import
#------------------------------------------------------------------------------
#  Just used so that the patches can complain if this script doesn't exist or 
#  is not placed above them.
#==============================================================================
($diamondandplatinum3_scripts ||= {})[:MoralityMetre_Ver20] = true


#==============================================================================
# ** Scene_Menu
#------------------------------------------------------------------------------
#  This class performs the menu screen processing.
#==============================================================================

class Scene_Menu < Scene_MenuBase
  #--------------------------------------------------------------------------
  # * Start Processing
  #--------------------------------------------------------------------------
  alias dp3_scenemenu_start_18dyb09     start
  #--------------------------------------------------------------------------
  def start( *args )
    @moralitymetre_window = Window_MoralityMetre.new
    
    # Call Orginal Method
    dp3_scenemenu_start_18dyb09( *args )
  end
  #--------------------------------------------------------------------------
  # * Dispose
  #--------------------------------------------------------------------------
  alias dp3_scenemenu_terminate_18dyb09     terminate
  #--------------------------------------------------------------------------
  def terminate
    # Call Original Method
    dp3_scenemenu_terminate_18dyb09()
    
    @moralitymetre_window.dispose unless @moralitymetre_window.disposed?
  end
end




#==============================================================================
# ** Window_MoralityMetre
#------------------------------------------------------------------------------
#  Defines the window and its contents
#==============================================================================
class Window_MoralityMetre < Window_Base
  include DiamondandPlatinum3::MoralityMetre
  #--------------------------------------------------------------------------
  # * Object Initialization
  #--------------------------------------------------------------------------
  def initialize()
    super(WINDOW_X_POSITION, WINDOW_Y_POSITION, WINDOW_WIDTH, WINDOW_HEIGHT)
    self.opacity = 0 if !WINDOW_VISIBLE
    contents.font.size = 25
    refresh
  end
  #--------------------------------------------------------------------------
  # * Refresh
  #--------------------------------------------------------------------------
  def refresh
    contents.clear
    colour1 = self.get_colour1()
    colour2 = self.get_colour2()
    gauge_y_pos = (contents.height - GAUGE_HEIGHT)
    
    # Change Text Colour if 50% Good
    contents.font.out_color = colour2 if OUTLINE_TEXT && get_should_text_be_outlined?()
    
    # Draw Text
    contents.draw_text( 0, 0, contents.width, 25, self.get_title(), 1 )
    
    # Blur Text if 50% Evil
    contents.blur if BLUR_TEXT && get_should_text_be_blured?()

    # Draw Morality Gauge
    draw_gauge(0, gauge_y_pos, contents.width, 1.0, colour1, colour2)
  end
  #--------------------------------------------------------------------------
  # * Draw Gauge
  #--------------------------------------------------------------------------
  def draw_gauge(x, y, width, rate, color1, color2)
    fill_w = (width * rate).to_i
    gauge_y = y
    contents.fill_rect(x, gauge_y, GAUGE_WIDTH, GAUGE_HEIGHT, gauge_back_color)
    contents.gradient_fill_rect(x, gauge_y, fill_w, GAUGE_HEIGHT, color1, color2, true)
  end
  #--------------------------------------------------------------------------
  # * Get Gauge Colour 1
  #--------------------------------------------------------------------------
  def get_colour1
    var = $game_variables[MORALITY_VARIABLE_ID].to_f
    neutral = (MORALITY_VARIABLE_RANGE * 0.5).to_f
    
    red = green = blue = 0
    # Neutral ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    if (var < get_neutral_range_plus(neutral) && var > get_neutral_range_minus( neutral ))
      var  /= get_neutral_range_plus(neutral)
      red   = var * MORALITY_NEUTRAL_COLOUR[0]
      green = var * MORALITY_NEUTRAL_COLOUR[1]
      blue  = var * MORALITY_NEUTRAL_COLOUR[2]
    # Evil ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    elsif var < neutral 
      var   = get_evil_morality_variable_percentage( var, neutral )
      red   = var * MORALITY_EVIL_COLOUR[0]
      green = var * MORALITY_EVIL_COLOUR[1]
      blue  = var * MORALITY_EVIL_COLOUR[2]
    # Good ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  
    else 
      var   = get_good_morality_variable_percentage( var, neutral )
      red   = var * MORALITY_GOOD_COLOUR[0]
      green = var * MORALITY_GOOD_COLOUR[1]
      blue  = var * MORALITY_GOOD_COLOUR[2]
    end
    return Color.new( red, green, blue )
  end
  #--------------------------------------------------------------------------
  # * Get Gauge Colour 2
  #--------------------------------------------------------------------------
  def get_colour2
    var = $game_variables[MORALITY_VARIABLE_ID].to_f
    neutral = (MORALITY_VARIABLE_RANGE * 0.5).to_f
    
    
    red = green = blue = 0
    # Neutral ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    if (var < get_neutral_range_plus(neutral) && var > get_neutral_range_minus( neutral ))
      var  /= get_neutral_range_plus(neutral)
      red   = var * MORALITY_NEUTRAL_COLOUR_GRADIENT[0]
      green = var * MORALITY_NEUTRAL_COLOUR_GRADIENT[1]
      blue  = var * MORALITY_NEUTRAL_COLOUR_GRADIENT[2]
    # Evil ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    elsif var < neutral 
      var   = get_evil_morality_variable_percentage( var, neutral )
      red   = var * MORALITY_EVIL_COLOUR_GRADIENT[0]
      green = var * MORALITY_EVIL_COLOUR_GRADIENT[1]
      blue  = var * MORALITY_EVIL_COLOUR_GRADIENT[2]
    # Good ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  
    else 
      var   = get_good_morality_variable_percentage( var, neutral )
      red   = var * MORALITY_GOOD_COLOUR_GRADIENT[0]
      green = var * MORALITY_GOOD_COLOUR_GRADIENT[1]
      blue  = var * MORALITY_GOOD_COLOUR_GRADIENT[2]
    end
    return Color.new( red, green, blue )
  end
  #--------------------------------------------------------------------------
  # * Get "Should Text be Blured?"
  #--------------------------------------------------------------------------
  def get_should_text_be_blured?()
    threshhold = ((MORALITY_VARIABLE_RANGE * 0.5) * (MORALITY_EVIL_BLUR_POINT * 0.01))
    return $game_variables[MORALITY_VARIABLE_ID] <= threshhold
  end
  #--------------------------------------------------------------------------
  # * Get "Should Text be Outlined?"
  #--------------------------------------------------------------------------
  def get_should_text_be_outlined?()
    threshhold = ((MORALITY_VARIABLE_RANGE * 0.5) * (1.0 + (MORALITY_GOOD_OUTLINE_POINT * 0.01)))
    return $game_variables[MORALITY_VARIABLE_ID] >= threshhold
  end
  #--------------------------------------------------------------------------
  # * Get Neutral Range
  #--------------------------------------------------------------------------
  def get_neutral_range
    return NEUTRAL_RANGE.to_f * 0.01
  end
  #--------------------------------------------------------------------------
  # * Get Neutral Range +
  #--------------------------------------------------------------------------
  def get_neutral_range_plus( number )
    return number * ( 1.0 + get_neutral_range())
  end
  #--------------------------------------------------------------------------
  # * Get Neutral Range -
  #--------------------------------------------------------------------------
  def get_neutral_range_minus( number )
    return number * get_neutral_range()
  end
  #--------------------------------------------------------------------------
  # * Get Evil Morality Variable Percentage
  #--------------------------------------------------------------------------
  def get_evil_morality_variable_percentage( var, neutral )
    return ((var - neutral) * -1) / neutral
  end
  #--------------------------------------------------------------------------
  # * Get Good Morality Variable Percentage
  #--------------------------------------------------------------------------
  def get_good_morality_variable_percentage( var, neutral )
    return (var - neutral) / neutral
  end
  #--------------------------------------------------------------------------
  # * Get Title
  #--------------------------------------------------------------------------
  def get_title
    title = "Unknown"
    MORALITY_NAME.each do |innerarray|
      title = innerarray[1] if $game_variables[MORALITY_VARIABLE_ID] >= innerarray[0]
    end
    return title
  end
end