#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
#             Block Areas From View
#             Author: DiamondandPlatinum3
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#  Description:
#
#    This script simply allows you to input stop points for the camera on maps.
#    ie. if you don't want to have the map scroll to a certain area on the map
#    because that's a blank space filled with events or if you just purely don't 
#    wish the player to know that area is there yet, you can use this script to 
#    stop the player from seeing it.
#
#    This script only affects the camera, if you don't want the player to travel 
#    into the unseen area, you'll need to block it off somehow with other things.
#
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#------------------------------------------------------------------------------
#  Instructions:
#
#  ~  Just below you wish find an editable option allowing you to set up a 
#     switch id. By turning this event switch on you can disable the camera
#     barriers and allow your players to see the earlier unseen area(s).
#
#  ~  To set up block points, go into the note boxes for you maps and insert:
#
#                   ~SCROLL_LEFT<?>         <= To Block a Left Area
#                   ~SCROLL_RIGHT<?>        <= To Block a Right Area
#                   ~SCROLL_UP<?>           <= To Block an Upwards Area 
#                   ~SCROLL_DOWN<?>         <= To Block an Downwards Area
#
#       Replace the ? with an id of one of the map tiles.
#       
#     Screenshots here:
#            http://i.imgur.com/36luHYZ.png
#            http://i.imgur.com/O47sPWv.png
#
#
#
#  ~  One more thing to note is that the camera starts off wherever the player 
#     is. If you spawn the player in an area that is supposed to be blocked to 
#     viewing. The camera will get jerky once you start moving it.
#      *   The event switch is there, don't forget.
#
#
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=



class Game_Map
  #=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  #                                                        -= 
  #                 Editable Region        ////            ==
  #                                                        =-
  #-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
  
  CAMERA_BLOCK_DEACTIVATION_EVENT_SWITCH_ID = 10
  
  #-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= 
  #                                           \/
  #               End of Editable Region      /\
  #                                           \/
  #-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=    
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * Alias Listings
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  alias dp3_stopscroll_gamemap_setupscroll_90j4y7                setup_scroll
  alias dp3_stopscroll_gamemap_scrolldown_90j4y7                  scroll_down
  alias dp3_stopscroll_gamemap_scrollleft_90j4y7                  scroll_left
  alias dp3_stopscroll_gamemap_scrollright_90j4y7                scroll_right
  alias dp3_stopscroll_gamemap_scrollup_90j4y7                      scroll_up
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * Scroll Setup
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def setup_scroll(*args)
    dp3_stopscroll_gamemap_setupscroll_90j4y7(*args)
    
    @dp3_scroll_stop_points = []
    @dp3_scroll_stop_points[0] = (@map.note =~ /~SCROLL_LEFT<(\d+)>/i)  ? $1.to_f : 0.0
    @dp3_scroll_stop_points[1] = (@map.note =~ /~SCROLL_RIGHT<(\d+)>/i) ? $1.to_f : width.to_f
    @dp3_scroll_stop_points[2] = (@map.note =~ /~SCROLL_UP<(\d+)>/i)    ? $1.to_f : 0.0
    @dp3_scroll_stop_points[3] = (@map.note =~ /~SCROLL_DOWN<(\d+)>/i)  ? $1.to_f : height.to_f
  end
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * Scroll Down
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def scroll_down(*args)
    if $game_switches[CAMERA_BLOCK_DEACTIVATION_EVENT_SWITCH_ID] || loop_vertical? || @dp3_scroll_stop_points[3] == height
      dp3_stopscroll_gamemap_scrolldown_90j4y7(*args)
    else
      last_y = @display_x
      @display_y = [@display_y + args[0], @dp3_scroll_stop_points[3] - screen_tile_y].min
      @parallax_y += @display_y - last_y
    end
  end
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * Scroll Left
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def scroll_left(*args)
    if $game_switches[CAMERA_BLOCK_DEACTIVATION_EVENT_SWITCH_ID] || loop_horizontal? || @dp3_scroll_stop_points[0] == 0
      dp3_stopscroll_gamemap_scrollleft_90j4y7(*args)
    else
      last_x = @display_x
      @display_x = [@display_x - args[0], @dp3_scroll_stop_points[0]].max
      @parallax_x += @display_x - last_x
    end
  end
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * Scroll Right
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def scroll_right(*args)
    if $game_switches[CAMERA_BLOCK_DEACTIVATION_EVENT_SWITCH_ID] || loop_horizontal? || @dp3_scroll_stop_points[1] == width
      dp3_stopscroll_gamemap_scrollright_90j4y7(*args)
    else
      last_x = @display_x
      @display_x = [@display_x + args[0], (@dp3_scroll_stop_points[1] - screen_tile_x)].min
      @parallax_x += @display_x - last_x
    end
  end
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * Scroll Up
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def scroll_up(*args)
    if $game_switches[CAMERA_BLOCK_DEACTIVATION_EVENT_SWITCH_ID] || loop_vertical? || @dp3_scroll_stop_points[2] == 0
      dp3_stopscroll_gamemap_scrollup_90j4y7(*args)
    else
      last_y = @display_y
      @display_y = [@display_y - args[0], @dp3_scroll_stop_points[2]].max
      @parallax_y += @display_y - last_y
    end
  end
end