#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
#             Map does not scroll with Player
#             Author: DiamondandPlatinum3
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#  Description:
#
#    This script stops the map from scrolling with the player. Its only use
#    is to mimic old Zelda style games where the map would scroll when you
#    would change rooms, otherwise staying still.
#
#    Using the Map's NoteTag box, insert the following comment:
#           ~<DO_NOT_SCROLL>
#
#    The Map will still scroll if this notetage does not exist in the Map's
#    NoteBox.
#
#    To scroll a map in this case, you will have to use the Scroll Map event.
#
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 
 
 
 
#==============================================================================
# ** Game_Player
#------------------------------------------------------------------------------
#  This class handles the player. It includes event starting determinants and
# map scrolling functions. The instance of this class is referenced by
# $game_player.
#==============================================================================
 
class Game_Player < Game_Character
  #--------------------------------------------------------------------------
  # * Aliased Method: Scroll Processing
  #--------------------------------------------------------------------------
  alias dp3_mdnswp_gameplayer_updatescroll_038r0   update_scroll
  def update_scroll(*args)
    dp3_mdnswp_gameplayer_updatescroll_038r0(*args) if $game_map.scroll_map
  end
end
 
 
 
#==============================================================================
# ** Game_Map
#------------------------------------------------------------------------------
#  This class handles maps. It includes scrolling and passage determination
# functions. The instance of this class is referenced by $game_map.
#==============================================================================
 
class Game_Map
  #--------------------------------------------------------------------------
  # * New Public Instance Variables
  #--------------------------------------------------------------------------
  attr_reader :scroll_map             # Scroll Map Boolean
  #--------------------------------------------------------------------------
  # * Aliased Method: Object Initialization
  #--------------------------------------------------------------------------
  alias dp3_mdnswp_gamemap_initialize_84fh0j   initialize
  def initialize(*args)
    # Call Original Method
    dp3_mdnswp_gamemap_initialize_84fh0j(*args)
   
    @scroll_map = true
  end
  #--------------------------------------------------------------------------
  # * Aliased Method: Setup
  #--------------------------------------------------------------------------
  alias dp3_mdnswp_gamemap_setup_84fh0j    setup
  def setup( *args )
    # Call Original Method
    dp3_mdnswp_gamemap_setup_84fh0j( *args )
   
    # Set Scroll Map
    @scroll_map = @map.note.upcase.include?( "~<DO_NOT_SCROLL>" ) ? false : true
  end
end