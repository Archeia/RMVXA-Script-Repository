#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# DP3's Actor Voices in Battle Script Patch for Yanfly's Victory Aftermath
# This patch simply makes sure that the same actor who gets a Text Box after
# Battle with the Victory Aftermath is also the Actor who says something in 
# the Voices Scripts during Victory.
#
# The Actor Voices script chooses an Actor at Random to speak normally, so this
# patch just sets that random actor to be the same actor as the one with the 
# victory speech.
#
# It also allows for voices to be heard when your party receives spoils from 
# battle
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
module DiamondandPlatinum3
  module BattleVoices
    #=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
    #                                                        -=
    #                 Editable Region        ////            ==
    #                                                        =-
    #-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # * Item Drop Voices
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    ITEM_DROP_VOICES = {  # <= Do Not Touch This Line
     
      # What Actor One Will Say when receiving item drops after battle
      1 => [
             "Received New Items 1", 80, 100, 0,
           ],


      # What Actor Two Will Say
      2 => [
             "Received New Items 1", 80, 100, 0,
           ],
           
           
           
    #=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
    #                                                        -=
    };    # End Of Editable Region           ////            ==
    #                                                        =-
    #-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    
    
    #------------------------------------------------------------------------
    # * New Method: Play "Receieved Spoils" Voice
    #------------------------------------------------------------------------
    def self.play_spoilsreceived_voice(actor_id = 0)
      return true if !allowed_to_play_voice?()
      actor_id = actor_id != 0 ? actor_id : get_battle_actor_id()
      return play_voice(ITEM_DROP_VOICES[actor_id], actor_id)
    end
  end
end





#==============================================================================
# ** BattleManager
#------------------------------------------------------------------------------
#  This module manages battle progress.
#==============================================================================

module BattleManager
  if ($imported ||= {})["YEA-VictoryAftermath"] && ($diamondandplatinum3_scripts ||= {})[:BattleVoices]
    class << self
      #------------------------------------------------------------------------
      # Aliased Method: Set Victory Text
      #------------------------------------------------------------------------
      alias dp3_avib_yanflyvictoryaftermath_2ljas             set_victory_text
      def set_victory_text(*args)
        dp3_play_victory_voice() if args[1] == :win
        DiamondandPlatinum3::BattleVoices::play_spoilsreceived_voice(@victory_actor ? @victory_actor.id : 0) if args[1] == :drops
        dp3_avib_yanflyvictoryaftermath_2ljas(*args)
      end
      #------------------------------------------------------------------------
      # * Overwritten Aliased Method: Victory Processing
      #------------------------------------------------------------------------
      def process_victory
        dp3_battlemanager_processvictory_1s098yu9j()
      end
      #------------------------------------------------------------------------
      # * Overwritten Method: Play Victory Voice
      #------------------------------------------------------------------------
      def dp3_play_victory_voice
        actor_id = @victory_actor ? @victory_actor.id : 0
        #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        # Battle Took Ages?
        #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        if $game_troop.turn_count >= DiamondandPlatinum3::BattleVoices::BATTLE_TOOK_AGES[:ratio]
          return if DiamondandPlatinum3::BattleVoices::play_very_long_battle_voice(actor_id)
        end
        #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        # Party Was Badly Injured?
        #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        party_current_hp = 0
        $game_party.battle_members.each {|ally| party_current_hp += ally.hp }
        if party_current_hp < @dp3_party_start_total_hp * (DiamondandPlatinum3::BattleVoices::THAT_WAS_TOUGH[:ratio] * 0.01)
          return if DiamondandPlatinum3::BattleVoices::play_party_was_badly_injured_voice(actor_id)
        end
        #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        # Battle Was Easy?
        #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        if $game_troop.turn_count <= DiamondandPlatinum3::BattleVoices::THAT_WAS_EASY[:ratio]
          return if DiamondandPlatinum3::BattleVoices::play_battle_was_easy_voice(actor_id)
        end
        #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        # Default Victory Speech
        #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        DiamondandPlatinum3::BattleVoices::play_default_victory_voice(actor_id)
      end      
    end
  else
    msgbox_p("You either do not have the Latest Version of DiamondandPlatinum3's 'Actor Voice in Battle' Script or do not have Yanfly's 'Victory Aftermath installed'.",
             "Please make sure that you have the latest versions of both these scripts and that the Victory Aftermath is located ABOVE the Battle Voices script.",
             "This patch must also be below BOTH of those script in the script editor.")
  end
end