#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
#             Don't Play Battle BGM on Battle Test
#             Author: DiamondandPlatinum3
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#  Description:
#
#    This script simply stops Battle BGM from playing when you are battle 
#    testing
#
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
module BattleManager
  class << self
    alias dontplaybattlebgmonbattletest_playbattlebgm   play_battle_bgm
    def play_battle_bgm
      dontplaybattlebgmonbattletest_playbattlebgm unless $BTEST
    end
  end
end