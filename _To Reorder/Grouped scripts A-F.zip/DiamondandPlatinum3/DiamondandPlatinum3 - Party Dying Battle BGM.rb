#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
#             Party Dying Battle BGM
#             Version: 1.0
#             Author: DiamondandPlatinum3
#             Date: September 5, 2012
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#  Description:
#
#    This script allows you to play an in-danger BGM when your party HP or 
#    singular actor hp is below a certain point.
#    Similar to Pokemon Black and White when your lead pokemon is in danger
#    of fainting.
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#------------------------------------------------------------------------------
#  Instructions:
#  
#     -  All you have to do is go into the editable region and change the 
#        appropriate settings to suit your needs. 
#
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
module DP3_PartyDyingBGM
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
#                                                        -= 
#                 Editable Region        ////            ==
#                                                        =-
#-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=


  # BGM, Volume, Pitch
  # if you want the Battle BGM to play at a different volume or pitch
  # Set the DyingBGM Filename value to nil

                    #   Filename,           Volume   Pitch ]
  DyingBGM        = [ "Dying Battle BGM",    100,     100  ]



  # Should the check be for the total party hp or for single actors
  # true = Entire Party, false = singular actor
  EntirePartyHP   = false



  # This is the Percentage of Total Health (or below) that your party or actor
  # must have left in order for the Dying BGM to play, this is a perentage out of
  # 100.
  # Play around with it to achieve your desired amount
  HP_Percentage   = 25
    


  # Do you want to see a messagebox teling you when your breaking point
  # will be?
  # This is for debug purposes, set it to false after finished.
  PrintBreakingPoint = false



#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
end # of Editable Region
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
#---------------------------------------------------------
# No touchie past here unless you know what you are 
# doing. Failure to heed this warning could cause your 
# computer to yell and scream at you. 
#
# Edit at your own risk.
#--------------------------------------------------------










class Scene_Battle < Scene_Base
  #--------------------------------------------------------------------------
  # * Start Processing
  #--------------------------------------------------------------------------
  alias playpartydyingbgm_start start
  def start
    playpartydyingbgm_start
    @partytotalhp       = checkpartytotalhp
    @current_battle_bgm = RPG::BGM.last
    @current_death_bgm  = RPG::BGM.new(*DP3_PartyDyingBGM::DyingBGM)
    @playing_death_bgm  = false
  end
  #--------------------------------------------------------------------------
  # * Frame Update
  #--------------------------------------------------------------------------
  alias playpartydyingbgm_update update
  def update
    #////////////////////////////////////////////
    if checkifindanger
      playdyingbgm
    else
      partydyingbgm_replaybattletheme
    end
     #////////////////////////////////////////////
    playpartydyingbgm_update
  end
  #--------------------------------------------------------------------------
  # * Check if in danger
  #--------------------------------------------------------------------------
  def checkifindanger
    return checkpartyremaininghp if DP3_PartyDyingBGM::EntirePartyHP
    return checkactorremaininghp
  end
  #--------------------------------------------------------------------------
  # * Check Party Total HP
  #--------------------------------------------------------------------------
  def checkpartytotalhp
    partytotalhp = 0
    $game_party.battle_members.each do |actor|
      partytotalhp += actor.mhp
      msgbox_p(actor.name + "'s Breaking Point is: " + ((actor.mhp * (DP3_PartyDyingBGM::HP_Percentage.to_f * 0.01)).to_i).to_s) if DP3_PartyDyingBGM::PrintBreakingPoint
    end
    msgbox_p("Entire Party Breaking Point is: " + ((partytotalhp * (DP3_PartyDyingBGM::HP_Percentage.to_f * 0.01)).to_i).to_s) if DP3_PartyDyingBGM::PrintBreakingPoint
    return partytotalhp
  end
  #--------------------------------------------------------------------------
  # * Check Party Remaining HP
  #--------------------------------------------------------------------------
  def checkpartyremaininghp
    partycurrenthp = 0
    $game_party.battle_members.each do |actor|
      partycurrenthp += actor.hp
    end
    return (partycurrenthp < (@partytotalhp * (DP3_PartyDyingBGM::HP_Percentage.to_f * 0.01)).to_i)
  end
  #--------------------------------------------------------------------------
  # * Check Actor Remaining HP
  #--------------------------------------------------------------------------
  def checkactorremaininghp
    $game_party.battle_members.each do |actor|
      return true if ((actor.hp < (actor.mhp * (DP3_PartyDyingBGM::HP_Percentage.to_f * 0.01)).to_i) && actor.hp != 0)
    end
    return false
  end
  #--------------------------------------------------------------------------
  # * Play "Dying BGM"
  #--------------------------------------------------------------------------
  def playdyingbgm
    if !@playing_death_bgm
      @current_battle_bgm = RPG::BGM.last
      @playing_death_bgm = true
      
      if samenormalanddyingbgm?
        switchtodyingbgmparams
      else
        @current_death_bgm.play(@current_death_bgm.pos)
      end
    end
  end
  #--------------------------------------------------------------------------
  # * Same Normal and Dying BGM?
  #--------------------------------------------------------------------------
  def samenormalanddyingbgm?
    return true unless DP3_PartyDyingBGM::DyingBGM[0]
    return @current_battle_bgm.name == @current_death_bgm.name
  end
  #--------------------------------------------------------------------------
  # * Switch to Dying BGM Params
  #--------------------------------------------------------------------------
  def switchtodyingbgmparams
    RPG::BGM.new(@current_battle_bgm.name, 
                 DP3_PartyDyingBGM::DyingBGM[1], 
                 DP3_PartyDyingBGM::DyingBGM[2]).play(@current_battle_bgm.pos)
  end
  #--------------------------------------------------------------------------
  # * Replay Battle BGM
  #--------------------------------------------------------------------------
  def partydyingbgm_replaybattletheme
    if @playing_death_bgm
      @playing_death_bgm = false
      @current_death_bgm = RPG::BGM.last
      @current_battle_bgm.play(samenormalanddyingbgm? ? @current_death_bgm.pos : @current_battle_bgm.pos)
    end
  end
end