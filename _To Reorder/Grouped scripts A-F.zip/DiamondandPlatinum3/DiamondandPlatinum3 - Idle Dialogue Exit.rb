#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
#             Idle Dialogue Exit
#             Version: 1.1
#             Author: DiamondandPlatinum3
#             Date: July 23, 2013
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#  Description:
#
#    This script allows you to set an automatic continuation when your 
#    player is not being responsive.
#    Basically if your player has not read the text in the textbox before a 
#    specified amount of time, you can allow it so that the NPC talking to them 
#    can do one of two things.
#       1) Move on to the Next Event Command (this is just the next command 
#          in the list; so it may be another text box or a battle)
#       2) Exit event processing entirely. This NPC will start doing all the 
#          things they were doing before you bothered them and act like you 
#          never spoke to them
#
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#------------------------------------------------------------------------------
#  Instructions:
#
#  ~  Just before a Textbox you wish Idle Dialogue Rules to apply, you must
#     insert the following script call:
#               begin_idle_dialogue_exit(seconds)
#     Replacing 'seconds' with the time you will allow. This is done with decimals
#     ie: Five seconds would be inputted as 5.0, or you can have it wait for 5.3 
#     seconds, etc.
#
#
#  ~  By default the NPCs will just skip to their next event command when being 
#     ignored. If you'd like them to quit event processing, you must add 'true' 
#     inside that script call:
#               begin_idle_dialogue_exit(seconds, true)
#     Now whenever you ignore an NPC, they will quit event processing.
#
#
#  ~  Additionally you may also set a Self-Switch or Event-Switch to activate
#     once you have ignored an NPC. To do so you must insert a third parameter 
#     after the previous two so that it looks like so.
#               begin_idle_dialogue_exit(seconds, true, ???)
#     Replacing the question marks with either one of two things:
#
#       1) For Self-Switches, you must insert the Self_Switch inside of Quotation
#          Marks. ie "A", "B", "C", "D".
#
#       2) For Event-Switches, you must insert a whole number value to represent
#          the event switch id you wish to turn on.
#
#
#
#  ~  Example Screenshots of the above can be found here:
#           http://i.imgur.com/D4iAwHk.png
#           http://i.imgur.com/Nhr5gwt.png
#           http://i.imgur.com/1WbX01M.png
#           http://i.imgur.com/WtBlDE6.png
#
#------------------------------------------------------------------------------
#  Engine Modifications:
#
#   ~ class Window_Message:
#       input_choice        (overwritten)
#       input_number        (overwritten)
#       input_item          (overwritten)   
#       input_pause         (overwritten)
#                                       Needed to overwrite the Fiber.yield in 
#                                       all these methods.
#
#   ~ class Window_NumberInput:
#       process_cursor_move (aliased)
#
#   ~ class Window_ChoiceList:
#       process_cursor_move (aliased)
#
#   ~ class Window_ItemList:
#       process_cursor_move (aliased)
#
#
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
#
#               THERE IS NO EDITABLE REGION TO THIS SCRIPT
#
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=



#==============================================================================
# ** Game_Temp
#------------------------------------------------------------------------------
#  This class handles temporary data that is not included with save data.
# The instance of this class is referenced by $game_temp.
#==============================================================================

class Game_Temp
  #--------------------------------------------------------------------------
  # * Struct.new
  #--------------------------------------------------------------------------
  DialogueIdleCancel = Struct.new(:active, :event_id, :start_time, :idle_time, :exit_event_processing, :event_control) do
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # * New Method: Start
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def start(seconds, evnt_id, exit_processing, event_control_switch)
      self.event_id               = evnt_id
      self.exit_event_processing  = exit_processing
      self.idle_time              = seconds
      self.event_control          = event_control_switch
      enable()
      reset_start_timer()
    end
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # * New Method: Total Game Time
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def total_game_time()
      return (Graphics.frame_count.to_f / Graphics.frame_rate)
    end
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # * New Method: Current Time
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def current_time()
      return (total_game_time() - self.start_time)
    end
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # * New Method: Time is Up?
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def time_up?()
      return (active?() && (current_time() > self.idle_time))
    end
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # * New Method: Enable
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def enable()
      self.active = true
    end
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # * New Method: Disable
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def disable()
      self.active = false
    end
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # * New Method: Reset Event
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def reset_event()
      $game_message.clear()
      $game_map.events[self.event_id].dp3_get_local_interpreter_instance().dp3_cleareventcommandslist() if self.exit_event_processing
    
      $game_switches[self.event_control] = true if self.event_control.is_a?(Integer)
      $game_map.events[self.event_id].dp3_get_local_interpreter_instance().dp3_activateeventselfswitch(self.event_control) if self.event_control.is_a?(String)
    end
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # * New Method: Reset All
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def reset()
      reset_event()
      disable()
    end
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # * New Method: Reset Start Timer
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def reset_start_timer()
      self.start_time = total_game_time()
    end
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # * New Method: Am I Active?
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def active?()
      return self.active
    end
  end
  #--------------------------------------------------------------------------
  # * Public Instance Variables
  #--------------------------------------------------------------------------
  attr_reader   :dp3_idledialoguecancel_instance    # Instance of DialogueIdleCancel
  #--------------------------------------------------------------------------
  # * Object Initialization
  #--------------------------------------------------------------------------
  alias dp3_dialogueidlecancel_gametemp_init_qpf7         initialize
  def initialize(*args)
    @dp3_idledialoguecancel_instance = DialogueIdleCancel.new(false, 0, 0.0, 0.0, false)
    dp3_dialogueidlecancel_gametemp_init_qpf7(*args) # Call Original Method
  end
end



#==============================================================================
# ** Window_Message
#------------------------------------------------------------------------------
#  This message window is used to display text.
#==============================================================================

class Window_Message < Window_Base
  #--------------------------------------------------------------------------
  # * Overwritten Method: Choice Input Processing
  #--------------------------------------------------------------------------
  def input_choice
    $game_temp.dp3_idledialoguecancel_instance.reset_start_timer()
    
    @choice_window.start
    Fiber.yield while @choice_window.active && !$game_temp.dp3_idledialoguecancel_instance.time_up?()
    
    if $game_temp.dp3_idledialoguecancel_instance.time_up?()
      @choice_window.active = false
      @choice_window.close
      $game_temp.dp3_idledialoguecancel_instance.reset()
    end
  end
  #--------------------------------------------------------------------------
  # * Overwritten Method: Number Input Processing
  #--------------------------------------------------------------------------
  def input_number
    $game_temp.dp3_idledialoguecancel_instance.reset_start_timer()
    
    @number_window.start
    Fiber.yield while @number_window.active && !$game_temp.dp3_idledialoguecancel_instance.time_up?()
    
    if $game_temp.dp3_idledialoguecancel_instance.time_up?()
      @number_window.active = false
      @number_window.close
      $game_temp.dp3_idledialoguecancel_instance.reset()
    end
  end
  #--------------------------------------------------------------------------
  # * Overwritten Method: Item Selection Processing
  #--------------------------------------------------------------------------
  def input_item
    $game_temp.dp3_idledialoguecancel_instance.reset_start_timer()
    
    @item_window.start
    Fiber.yield while @item_window.active && !$game_temp.dp3_idledialoguecancel_instance.time_up?()
    
    if $game_temp.dp3_idledialoguecancel_instance.time_up?()
      @item_window.active = false
      @item_window.close
      $game_temp.dp3_idledialoguecancel_instance.reset()
    end
  end
  #--------------------------------------------------------------------------
  # * Overwritten Method: Input Pause Processing
  #--------------------------------------------------------------------------
  def input_pause
    $game_temp.dp3_idledialoguecancel_instance.reset_start_timer()

    self.pause = true
    wait(10)
    Fiber.yield until Input.trigger?(:B) || Input.trigger?(:C) || $game_temp.dp3_idledialoguecancel_instance.time_up?()
    Input.update
    self.pause = false
    
    if $game_temp.dp3_idledialoguecancel_instance.time_up?()
      $game_temp.dp3_idledialoguecancel_instance.reset()
    end
  end
end



#==============================================================================
# ** Window_NumberInput
#------------------------------------------------------------------------------
#  This window is used for the event command [Input Number].
#==============================================================================

class Window_NumberInput < Window_Base
  #--------------------------------------------------------------------------
  # * Aliased Method: Cursor Movement Processing
  #--------------------------------------------------------------------------
  alias dp3_idledialogueexit_windownumberinput_processcursormove_wof    process_cursor_move
  def process_cursor_move(*args)
    if self.active
      $game_temp.dp3_idledialoguecancel_instance.reset_start_timer() if Input.press?(:RIGHT) || Input.press?(:LEFT) || Input.press?(:UP) || Input.press?(:DOWN)
    end
    dp3_idledialogueexit_windownumberinput_processcursormove_wof(*args)
  end
end



#==============================================================================
# ** Window_ChoiceList
#------------------------------------------------------------------------------
#  This window is used for the event command [Show Choices].
#==============================================================================

class Window_ChoiceList < Window_Command
  #--------------------------------------------------------------------------
  # * Aliased Method: Cursor Movement Processing
  #--------------------------------------------------------------------------
  alias dp3_idledialogueexit_windowchoicelist_processcursormove_wof    process_cursor_move
  def process_cursor_move(*args)
    if self.active
      $game_temp.dp3_idledialoguecancel_instance.reset_start_timer() if Input.press?(:RIGHT) || Input.press?(:LEFT) || Input.press?(:UP) || Input.press?(:DOWN)
    end
    dp3_idledialogueexit_windowchoicelist_processcursormove_wof(*args)
  end
end



#==============================================================================
# ** Window_ItemList
#------------------------------------------------------------------------------
#  This window displays a list of party items on the item screen.
#==============================================================================

class Window_ItemList < Window_Selectable
  #--------------------------------------------------------------------------
  # * Aliased Method: Cursor Movement Processing
  #--------------------------------------------------------------------------
  alias dp3_idledialogueexit_windowitemlist_processcursormove_wof    process_cursor_move
  def process_cursor_move(*args)
    if self.active
      $game_temp.dp3_idledialoguecancel_instance.reset_start_timer() if Input.press?(:RIGHT) || Input.press?(:LEFT) || Input.press?(:UP) || Input.press?(:DOWN)
    end
    dp3_idledialogueexit_windowitemlist_processcursormove_wof(*args)
  end
end



#==============================================================================
# ** Game_Event
#------------------------------------------------------------------------------
#  This class handles events. Functions include event page switching via
# condition determinants and running parallel process events. Used within the
# Game_Map class.
#==============================================================================

class Game_Event < Game_Character
  #--------------------------------------------------------------------------
  # * Get Local Interpreter Instance
  #--------------------------------------------------------------------------
  def dp3_get_local_interpreter_instance
    return @intepreter if @interpreter
    return $game_map.interpreter
  end
end
  
  
  
  
#==============================================================================
# ** Game_Interpreter
#------------------------------------------------------------------------------
#  An interpreter for executing event commands. This class is used within the
# Game_Map, Game_Troop, and Game_Event classes.
#==============================================================================

class Game_Interpreter
  #--------------------------------------------------------------------------
  # * Begin Idle Dialogue Cancel
  #--------------------------------------------------------------------------
  def begin_idle_dialogue_exit(seconds, exit_event_processing = false, switch_control = nil)
    switch_control        = switch_control[0].upcase  if switch_control.is_a?(String)
    switch_control        = nil                       unless switch_control.is_a?(Integer) || switch_control.is_a?(String)
    exit_event_processing = false                     unless !!exit_event_processing == exit_event_processing
    $game_temp.dp3_idledialoguecancel_instance.start(seconds.to_f, @event_id, exit_event_processing, switch_control)
  end
  #--------------------------------------------------------------------------
  # * Clear Event Commands List
  #--------------------------------------------------------------------------
  def dp3_cleareventcommandslist()
    @list = []
  end
  #--------------------------------------------------------------------------
  # * Activate Self-Switch
  #--------------------------------------------------------------------------
  def dp3_activateeventselfswitch(selfswitchid)
    @params[0] = selfswitchid
    @params[1] = 0
    command_123()
  end
end