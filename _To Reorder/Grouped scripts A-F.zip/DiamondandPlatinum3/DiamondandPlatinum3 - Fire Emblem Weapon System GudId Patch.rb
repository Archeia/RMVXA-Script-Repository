#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Fire Emblem / Disgaea Weapon System 'Attack Patch' for GubiD's Tactical Battle System
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
class Scene_Battle_TBS
  #---------------------------------------------------------------------------
  #* process_action_4 || Clean_Up Process Action
  #---------------------------------------------------------------------------
  alias dp3_firemblemdisgaeaweaponsystem_cleanupprocessaction       clean_up_process_action
  #---------------------------------------------------------------------------
  def clean_up_process_action(*args)
    if @active_battler.actor? && @active_battler.current_action.attack?
      DiamondandPlatinum3::WeaponLevels::increment_weapon_skill_points( @active_battler.id )
    end
   
    # Call Original Method
    dp3_firemblemdisgaeaweaponsystem_cleanupprocessaction(*args)
  end
end