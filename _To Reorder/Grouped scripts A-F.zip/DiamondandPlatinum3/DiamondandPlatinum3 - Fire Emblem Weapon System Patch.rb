#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#
# Patch for DP3's "Fire Emblem / Disgaea" Weapon System.
#
#   This Patch allows you to apply the '  ~DoNotEquip  ' NoteTag
#    to actor classes rather than the Actors themselves.
#
# *~ Place this Patch in a script slot below the original Script
#
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~





#==============================================================================
# ** Game_Actor
#------------------------------------------------------------------------------
#  This class handles actors. It is used within the Game_Actors class
# ($game_actors) and is also referenced from the Game_Party class ($game_party).
#==============================================================================
 
class Game_Actor < Game_Battler
  #--------------------------------------------------------------------------
  # * Determine if Weapon Level is Sufficient
  #--------------------------------------------------------------------------
  def dp3_is_weapon_level_sufficient(weapon)
    # Do Not Equip Weapon Type Notetag
    if $data_classes[self.class_id].note =~ /~DoNotEquip\[\s*(.+?)\]/im
      do_not_equip_types = $1.scan(/\d+/).collect {|i| i.to_i }
      return false if do_not_equip_types.include?(weapon.wtype_id)
    end
    #~~~~~
    return true if weapon.wtype_id == 0
    $data_weapons[weapon.id].note[/~WeaponLevel:\s*(.+)/i]
    return true unless $1 && $1 != ""
    method_args = [ weapon.wtype_id, self.id, @dp3_weapon_level[weapon.wtype_id - 1] ]
    curr_skill = DiamondandPlatinum3::WeaponLevels::get_current_weapon_level( *method_args )
    return DiamondandPlatinum3::WeaponLevels::get_skilllevel_and_weapon_compatible( curr_skill, $1.upcase )  
  end
end

#==============================================================================
# ** Window_WeaponLevelStatus
#------------------------------------------------------------------------------
#  This window displays full status specs on the Weapon Ranks.
#==============================================================================
 
class Window_WeaponLevelStatus < Window_Selectable
  #--------------------------------------------------------------------------
  # * Draw Weapon Level Info
  #--------------------------------------------------------------------------
  def draw_weapon_level_info()
    $data_classes[@actor.class_id].note[/~DoNotEquip\[\s*(.+?)\]/im]
    do_not_equip_types = $1 ? $1.scan(/\d+/).collect {|i| i.to_i } : []
    yPos_Correction = 25
    while((yPos_Correction * (WeaponAccumulation.size - do_not_equip_types.size)) >= ((@yPos + self.height) - 20))
      yPos_Correction -= 1
      break if yPos_Correction <= 10
    end
    for i in 1..WeaponAccumulation.size
      # Skip this Weapon Type?
      next if do_not_equip_types.include?(i)
      # Get Current Weapon Skill
      curr_skill = get_current_weapon_skill(i)
      # Draw Icon
      draw_icon(WeaponStatusMenuInfo[:weapon_icon_id][i][0], @xPos, @yPos, 24, yPos_Correction)
      @xPos += 25
      # Draw Gauge
      rate = get_next_level_up_rate(i, curr_skill)
      draw_gauge(@xPos, @yPos - 5, 150, rate, get_gaugecolour1, get_gaugecolour2)
      @xPos += 175 # Gauge Width Plus 25 Offset
      # Draw Weapon Level
      self.change_color(get_weapon_level_colour( curr_skill ))
      draw_text(@xPos, @yPos, 25, 25, curr_skill)
      self.change_color(normal_color)
      @xPos += 25
      # Draw Weapon Bonuses
      for j in 0..4
        draw_icon(WeaponStatusMenuInfo[:bonusparam_icon_id][j + 1][0], @xPos, @yPos, 24, yPos_Correction)
        @xPos += 29
        bonus = self.get_actor_bonus_param( i, j, curr_skill )
        text = bonus.to_s
        self.change_color(get_weapon_bonus_colour( bonus, i ))
        draw_text(@xPos, @yPos, 23, yPos_Correction, text)
        self.change_color(normal_color)
        @xPos += 26
      end
      @xPos = 20
      @yPos += yPos_Correction
    end
  end
end