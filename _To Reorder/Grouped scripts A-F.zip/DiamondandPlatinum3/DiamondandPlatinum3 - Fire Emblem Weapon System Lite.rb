#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
#             Fire Emblem/Disgaea Weapon System (Lite Version)
#             Version: 1.1
#             Authors: DiamondandPlatinum3
#             Date: January 12, 2013
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#  Description:
#
#    This script introduces a mixture of both Fire Emblem's and Disgaea's 
#    weapon system to your game.
#    With this script you can allow your actors to have access to any weapon
#    (unless you don't want them to, of course), so long as the actor has a 
#    high enough weapon skill level to wield it, this is the script mimicking 
#    Fire Emblem's weapon system.
#    When improving a weapon rank, you'll also earn parameter bonuses for that 
#    weapon type, which can be further improved as your weapon rank increases, 
#    mimicking Disgaea's weapon system.
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#------------------------------------------------------------------------------
#  Instructions:
#
#   ~ I have made a video tutorial for this script, it's advised that you take a 
#     look at it in case you get confused on what things do.
#     You can find the Video Here: https://www.youtube.com/watch?v=REZyKy900fc
#
#
#   ~ The first thing you need to do is remove all weapon types from any and all actor 
#     classes in the database. Due to the way I've made this script, all other weapon
#     take priority, including the default weapon system. Therefore it is important
#     to remove all weapon types from actor classes, so that this script can do it's
#     task without conflicting with the default weapon system.
#       ScreenShot Can Be Found Here:   goo.gl/eXq3X
#     
#    
#
#   ~ With the above done, your actors can now equip absolutely every single weapon
#     type. However you may not want certain actors to be able to use certain 
#     weapon types. Example, you may not want actor 1 (Eric) to equip any Bows or 
#     Guns, but every other weapon type is just fine. If that's the case, simply
#     add the following notetag to his actor notebox.
#         ~DoNotEquip[ ?, ?, ?, ]
#     Now you can replace the Question Marks with the ID's of the weapon types you
#     do not wish for him to be able to equip. You can have as many or as little as
#     you want.
#       ScreenShots Can Be Found Here:
#             goo.gl/t5IzQ
#   	        goo.gl/uZZ4X
#             goo.gl/KwxUh	
#             goo.gl/g4WNw	
#             goo.gl/xfYxL
#
#
#  ~  You can restrict some weapons from being equipped until your actor has 
#     acquired a specific weapon skill. So your more powerful axes may be 
#     be restricted to only being equipped if your actor is a master at 
#     wielding axes. To do so you insert the following notetag in a weapon notebox.
#         ~WeaponLevel: ?
#     Now you can replace the Question Mark with a letter corresponding to a 
#     Weapon Rank, so a Letter like "D", "C", "B", "A", "S" will restrict
#     that weapon until a certain weapon rank.
#     If you do not use this tag on a weapon or insert any letter besides those, 
#     the weapon rank will default to "E".
#       ScreenShot Can Be Found Here:   goo.gl/PWKTl
#       
#
#  ~  If you want skills to help increase your weapon rank when they're used.
#     You can add a notetag in their notebox which will allow this. It is the following:
#         ~EarnWeaponSkillPoints: ?
#     Now you can replace the Question Mark with a number which will add on to 
#     your actor's currently equipped weapon type (types if dual wielding).
#       ScreenShot Can Be Found Here:   goo.gl/8z6Gt
#
#
#
#  ~  If you wish to temporarily turn on or off the Level Up Message Display for 
#     your weapons, you can do so via a script call:
#         toggle_weapon_level_message_display( on_or_off )
#     Replacing on_or_off with 'true' if you want the box to be displayed or 
#     'false' if you wish to temporarily disable it.
#     This is handy for secretly increasing actor weapon ranks in your game.
#
#
#  ~  You can add weapon points to any actor for the weapon they're currently 
#     holding by using the following script call:
#         add_weapon_skill_points( actor_id, points )
#     Replacing actor_id with the ID of actor you are giving points to and 
#     replacing points with the amount of points you are giving to them.
#
#
#  ~  You can also increase specific weapon types for a player even when they're
#     not equipping that type. Using the following script call:
#         add_specific_weapon_type_skill_points( actor_id, wType, points )
#     Replacing actor_id with the ID of the actor you wish to give points to,
#     wType with the Weapon Type you are assigning points to (ie Sword is weapon type 4),
#     and points with the amount of points you are giving them.
#       This script call is especially useful if you wantto let NPCs give your 
#     Actors training in using weapons, because why would an archer help you learn
#     how to use an axe?
#
#
#     A ScreenShot Showing the use of the Above Three ScriptCalls Can Be Found 
#     Here:   goo.gl/ETywg
#
#
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
module DiamondandPlatinum3
  module WeaponLevels
    #=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
    #                                                        -= 
    #                 Editable Region        ////            ==
    #                                                        =-
    #-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    
    
    #----------------------------------------------------------------------
    # * Menu Option Information
    #----------------------------------------------------------------------
    # For this Script, a menu option is added to allow players to view their
    # weapon levels. This option allows you to edit what the menu option is 
    # called when looking at the menu.
    Menu_Option_Title = "Weapon Level Status" 
                                                
    
    
    
    
    #----------------------------------------------------------------------
    # * Message Box Information
    #----------------------------------------------------------------------
    Show_Message_Box = true   # Do you want a message box to be displayed when
                              # Your current weapon rank goes up?
                              
    Rank_Up_SE = "Applause1"  # Sound Effect To Be Played when weapon rank 
    SE_Volume  = 80           # increases. If you don't want an SE to play,
    SE_Pitch   = 100          # set to "NO_SOUNDEFFECT".
                              # SE will only play when a MessageBox is displayed.
                        
                              
    # Here You Get To Choose What the Message Box Says.
    # Param Quotes will only be used if that param actually increased.
    # Same for Skills
    Increased_Weapon_Rank_Text    = "has increased their weapon rank!"
    Increased_Attack_Power        = "Attack Power has been increased!"
    Increased_Defence_Power       = "Weapon Defence has been increased!"
    Increased_Magic_Attack_Power  = "Magic Attack Power has been increased!"
    Increased_Magic_Defence_Power = "Magic Defence has been increased!"
    Increased_Agility_Power       = "Agility has been improved!" 
    Acquired_New_Skill            = "has aquired a new skill!"
                              
                              
    
    
                              
    #----------------------------------------------------------------------
    # * Weapon Accumulation Information
    #----------------------------------------------------------------------
    # How Many Points do you want to gain for your weapon when you attack 
    # with it in battle. 1 by default.
    Attack_Points_Gain = 1
    
    
    # Since we will always start at level E, modify how many times a 
    # weapon must be used before you go up to the Next Weapon Level
    #
    # So Basically everytime you attack with that weapon type, your count
    # will increase by one, and once it hits one of the numbers you specified below,
    # your weapon level will go up a rank.
    WeaponAccumulation = {
            #  D,   C,   B,   A,    S,
      1  => [ 100, 250, 550, 1000, 1500, ], # Weapon Type 1,  By Default is 'Weapon Type: Axe'
      2  => [ 100, 250, 550, 1000, 1500, ], # Weapon Type 2,  By Default is 'Weapon Type: Claw'
      3  => [ 100, 250, 550, 1000, 1500, ], # Weapon Type 3,  By Default is 'Weapon Type: Spear'
      4  => [ 100, 250, 550, 1000, 1500, ], # Weapon Type 4,  By Default is 'Weapon Type: Sword'
      5  => [ 100, 250, 550, 1000, 1500, ], # Weapon Type 5,  By Default is 'Weapon Type: Katana'
      6  => [ 100, 250, 550, 1000, 1500, ], # Weapon Type 6,  By Default is 'Weapon Type: Bow'
      7  => [ 100, 250, 550, 1000, 1500, ], # Weapon Type 7,  By Default is 'Weapon Type: Dagger'
      8  => [ 100, 250, 550, 1000, 1500, ], # Weapon Type 8,  By Default is 'Weapon Type: Hammer'
      9  => [ 100, 250, 550, 1000, 1500, ], # Weapon Type 9,  By Default is 'Weapon Type: Staff'
      10 => [ 100, 250, 550, 1000, 1500, ], # Weapon Type 10, By Default is 'Weapon Type: Gun'
     
    
      # If you have more weapon types than these, you'll need to add them just above.
    # Copy-Paste the above, and I'll leave it to your common sense to change things
    # accordingly. Paste ABOVE this comment
    }
    
    
    
    
    
    
    #----------------------------------------------------------------------
    # * Weapon Bonus Params Information
    #----------------------------------------------------------------------
    # Here You get to decide what bonuses your actors get when they have leveled
    # up a weapon and remain having it equipped. The Abbreviations are as followed:
              # ATK  ATtacK power
              # DEF  DEFense power
              # MAT  Magic ATtack power
              # MDF  Magic DeFense power
              # AGI  AGIlity
    # These are percentages out of 100, meaning that if I had a stat boost of 10%,
    # The actor will receive a 10% bonus of their current stat.
    # In other words, if ATK stat is 90 and weapon bonus for ATK is 10%, the actor
    # will receive 9 extra stat points for their ATK.
    #
    # Effects do not carry on into further levels. So if an actor was to receive
    # a param stat boost of 10% in weapon level "D", and 15% in weapon level "C",
    # The actor will only get 15% during weapon level "C" instead of 25%. 
    # Keep this in mind while editing.
    WeaponParamBonuses = {
           # ATK, DEF, MAT, MDF, AGI,
      1 => [                          # Weapon Type 1, By Default is 'Weapon Type: Axe' 
              5,   2,   0,   0,   1,  # Bonuses for Axe Level "D"
              7,   2,   0,   0,   2,  # Bonuses for Axe Level "C"
              9,   4,   0,   0,   3,  # Bonuses for Axe Level "B"
              10,  5,   0,   0,   4,  # Bonuses for Axe Level "A"
              13,  6,   0,   0,   6,  # Bonuses for Axe Level "S"
           ],
         
           
      2 => [                          # Weapon Type 2, By Default is 'Weapon Type: Claw'
              5,   3,   0,   0,   1,  # Bonuses for Claw Level "D"
              7,   4,   0,   0,   2,  # Bonuses for Claw Level "C"
              8,   6,   0,   0,   3,  # Bonuses for Claw Level "B"
              10,  8,   0,   0,   4,  # Bonuses for Claw Level "A"
              13,  11,  0,   0,   6,  # Bonuses for Claw Level "S"
           ],
      
           
      3 => [                          # Weapon Type 3, By Default is 'Weapon Type: Spear'
              5,   3,   0,   0,   1,  # Bonuses for Spear Level "D"
              7,   4,   0,   0,   2,  # Bonuses for Spear Level "C"
              8,   6,   0,   0,   3,  # Bonuses for Spear Level "B"
              10,  8,   0,   0,   4,  # Bonuses for Spear Level "A"
              13,  11,  0,   0,   6,  # Bonuses for Spear Level "S"
           ],
      
           
           # ATK, DEF, MAT, MDF, AGI,
      4 => [                          # Weapon Type 4, By Default is 'Weapon Type: Sword'
              5,   3,   0,   0,   1,  # Bonuses for Sword Level "D"
              7,   4,   0,   0,   2,  # Bonuses for Sword Level "C"
              8,   6,   0,   0,   3,  # Bonuses for Sword Level "B"
              10,  8,   0,   0,   4,  # Bonuses for Sword Level "A"
              13,  11,  0,   0,   6,  # Bonuses for Sword Level "S"
           ],
           
           
      5 => [                          # Weapon Type 5, By Default is 'Weapon Type: Katana'
              5,   3,   0,   0,   1,  # Bonuses for Katana Level "D"
              7,   4,   0,   0,   2,  # Bonuses for Katana Level "C"
              8,   6,   0,   0,   3,  # Bonuses for Katana Level "B"
              10,  8,   0,   0,   4,  # Bonuses for Katana Level "A"
              13,  11,  0,   0,   6,  # Bonuses for Katana Level "S"
           ],
           
           
      6 => [                          # Weapon Type 6, By Default is 'Weapon Type: Bow'
              5,   3,   0,   0,   1,  # Bonuses for Bow Level "D"
              7,   4,   0,   0,   2,  # Bonuses for Bow Level "C"
              8,   6,   0,   0,   3,  # Bonuses for Bow Level "B"
              10,  8,   0,   0,   4,  # Bonuses for Bow Level "A"
              13,  11,  0,   0,   6,  # Bonuses for Bow Level "S"
           ],
           
           
           # ATK, DEF, MAT, MDF, AGI,
     7  => [                          # Weapon Type 7, By Default is 'Weapon Type: Dagger'
              5,   3,   0,   0,   1,  # Bonuses for Dagger Level "D"
              7,   4,   0,   0,   2,  # Bonuses for Dagger Level "C"
              8,   6,   0,   0,   3,  # Bonuses for Dagger Level "B"
              10,  8,   0,   0,   4,  # Bonuses for Dagger Level "A"
              13,  11,  0,   0,   6,  # Bonuses for Dagger Level "S"
           ],
           
           
           
      8 => [                          # Weapon Type 8, By Default is 'Weapon Type: Hammer'
              5,   3,   0,   0,   1,  # Bonuses for Hammer Level "D"
              7,   4,   0,   0,   2,  # Bonuses for Hammer Level "C"
              8,   6,   0,   0,   3,  # Bonuses for Hammer Level "B"
              10,  8,   0,   0,   4,  # Bonuses for Hammer Level "A"
              13,  11,  0,   0,   6,  # Bonuses for Hammer Level "S"
           ],
           
           
           
      9 => [                          # Weapon Type 9, By Default is 'Weapon Type: Staff'
              5,   3,   0,   0,   1,  # Bonuses for Staff Level "D"
              7,   4,   0,   0,   2,  # Bonuses for Staff Level "C"
              8,   6,   0,   0,   3,  # Bonuses for Staff Level "B"
              10,  8,   0,   0,   4,  # Bonuses for Staff Level "A"
              13,  11,  0,   0,   6,  # Bonuses for Staff Level "S"
           ],
           
           
           # ATK, DEF, MAT, MDF, AGI,
     10 => [                          # Weapon Type 10, By Default is 'Weapon Type: Gun'
              5,   3,   0,   0,   1,  # Bonuses for Gun Level "D"
              7,   4,   0,   0,   2,  # Bonuses for Gun Level "C"
              8,   6,   0,   0,   3,  # Bonuses for Gun Level "B"
              10,  8,   0,   0,   4,  # Bonuses for Gun Level "A"
              13,  11,  0,   0,   6,  # Bonuses for Gun Level "S"
           ],
      
      
      
      
      # If you have more than 10 weapon types, you can add them by copying the 
      # above and changing the weapon type id to the appropriate number.
      # Paste ABOVE this comment
    }
    
    
    
    
    
    
    #----------------------------------------------------------------------
    # * Weapon Bonus Skills Information
    #----------------------------------------------------------------------
    # You can select specific skills that your actor can learn once they have 
    # achieved a high enough weapon rank. This skill will only be available 
    # whilst the actor has this weapon type equipped and has the required
    # skill level. Therefore if this weapon type is removed, so too are the 
    # acquired skills until the conditions for learning those skills are once 
    # again satisfied.
    # Basically you can have the same skill be learned by different weapon 
    # types and it'll work just fine.
    #
    # Skill Bonuses DO NOT carry over to higher levels. If you have a weapon 
    # type that gives you a skill at Rank "D", you must also include that skill
    # in the next rank.
    #
    # If you do not want any skill for a specific rank, remove all skill IDs in 
    # that Rank.
    WeaponSkillBonuses = {
    
      # Weapon Type 1, By Default is 'Weapon Type: Axe'
      1 => {    #   Skill IDs 
                1 => [ 3, ],            # Bonus Skills for: Axe Level "D"
                2 => [ 3, ],            # Bonus Skills for: Axe Level "C"
                3 => [ 3, 4, ],         # Bonus Skills for: Axe Level "B"
                4 => [ 3, 4, ],         # Bonus Skills for: Axe Level "A"
                5 => [ 3, 4, 5, ],      # Bonus Skills for: Axe Level "S"
            },
            
            
            
      # Weapon Type 2, By Default is 'Weapon Type: Claw'
      2 => {    
                1 => [ 3, ],            # Bonus Skills for: Claw Level "D"
                2 => [ 3, ],            # Bonus Skills for: Claw Level "C"
                3 => [ 3, 4, ],         # Bonus Skills for: Claw Level "B"
                4 => [ 3, 4, ],         # Bonus Skills for: Claw Level "A"
                5 => [ 3, 4, 5, ],      # Bonus Skills for: Claw Level "S"
            },
            
            
            
      # Weapon Type 3, By Default is 'Weapon Type: Spear'
      3 => {    
                1 => [ 3, ],            # Bonus Skills for: Spear Level "D"
                2 => [ 3, ],            # Bonus Skills for: Spear Level "C"
                3 => [ 3, 4, ],         # Bonus Skills for: Spear Level "B"
                4 => [ 3, 4, ],         # Bonus Skills for: Spear Level "A"
                5 => [ 3, 4, 5, ],      # Bonus Skills for: Spear Level "S"
            },
            
            
            
      # Weapon Type 4, By Default is 'Weapon Type: Sword'
      4 => {    #   Skill IDs 
                1 => [ 3, ],            # Bonus Skills for: Sword Level "D"
                2 => [ 3, ],            # Bonus Skills for: Sword Level "C"
                3 => [ 3, 4, ],         # Bonus Skills for: Sword Level "B"
                4 => [ 3, 4, ],         # Bonus Skills for: Sword Level "A"
                5 => [ 3, 4, 5, ],      # Bonus Skills for: Sword Level "S"
            },
            
            
            
      # Weapon Type 5, By Default is 'Weapon Type: Katana'
      5 => {    
                1 => [ 3, ],            # Bonus Skills for: Katana Level "D"
                2 => [ 3, ],            # Bonus Skills for: Katana Level "C"
                3 => [ 3, 4, ],         # Bonus Skills for: Katana Level "B"
                4 => [ 3, 4, ],         # Bonus Skills for: Katana Level "A"
                5 => [ 3, 4, 5, ],      # Bonus Skills for: Katana Level "S"
            },
            
            
            
      # Weapon Type 6, By Default is 'Weapon Type: Bow'
      6 => {    
                1 => [ 3, ],            # Bonus Skills for: Bow Level "D"
                2 => [ 3, ],            # Bonus Skills for: Bow Level "C"
                3 => [ 3, 4, ],         # Bonus Skills for: Bow Level "B"
                4 => [ 3, 4, ],         # Bonus Skills for: Bow Level "A"
                5 => [ 3, 4, 5, ],      # Bonus Skills for: Bow Level "S"
            },
            
            
            
      # Weapon Type 7, By Default is 'Weapon Type: Dagger'
      7 => {    #   Skill IDs 
                1 => [ 3, ],            # Bonus Skills for: Dagger Level "D"
                2 => [ 3, ],            # Bonus Skills for: Dagger Level "C"
                3 => [ 3, 4, ],         # Bonus Skills for: Dagger Level "B"
                4 => [ 3, 4, ],         # Bonus Skills for: Dagger Level "A"
                5 => [ 3, 4, 5, ],      # Bonus Skills for: Dagger Level "S"
            },
            
            
            
      # Weapon Type 8, By Default is 'Weapon Type: Hammer'
      8 => {    
                1 => [ 3, ],            # Bonus Skills for: Hammer Level "D"
                2 => [ 3, ],            # Bonus Skills for: Hammer Level "C"
                3 => [ 3, 4, ],         # Bonus Skills for: Hammer Level "B"
                4 => [ 3, 4, ],         # Bonus Skills for: Hammer Level "A"
                5 => [ 3, 4, 5, ],      # Bonus Skills for: Hammer Level "S"
            },
            
            
            
      # Weapon Type 9, By Default is 'Weapon Type: Staff'
      9 => {    
                1 => [ 3, ],            # Bonus Skills for: Staff Level "D"
                2 => [ 3, ],            # Bonus Skills for: Staff Level "C"
                3 => [ 3, 4, ],         # Bonus Skills for: Staff Level "B"
                4 => [ 3, 4, ],         # Bonus Skills for: Staff Level "A"
                5 => [ 3, 4, 5, ],      # Bonus Skills for: Staff Level "S"
            },
            
            
            
      # Weapon Type 10, By Default is 'Weapon Type: Gun'
      10 => {   #   Skill IDs 
                1 => [ 3, ],            # Bonus Skills for: Gun Level "D"
                2 => [ 3, ],            # Bonus Skills for: Gun Level "C"
                3 => [ 3, 4, ],         # Bonus Skills for: Gun Level "B"
                4 => [ 3, 4, ],         # Bonus Skills for: Gun Level "A"
                5 => [ 3, 4, 5, ],      # Bonus Skills for: Gun Level "S"
             },
      
      
      # Same as before, if you have any more weapon types, add them above this 
      # comment
    }
    
    
    
    
    
    #----------------------------------------------------------------------
    # * Weapon Status Menu Information
    #----------------------------------------------------------------------
    WeaponStatusMenuInfo = {
      :weapon_level_colour => {
        # Colour:  Red,  Green,  Blue  
        1  => [    150,   150,    60  ], # Colour For: Actor's Name
        2  => [    255,   200,   255  ], # Colour For: "Weapon Level" Label
        3  => [    200,   255,   255  ], # Colour For: "Weapon Level Bonuses" Label
        4  => [    255,    50,   255  ], # Colour For: Weapon Level "S"
        5  => [    170,   135,   170  ], # Colour For: Weapon Level "A"
        6  => [    140,   165,   140  ], # Colour For: Weapon Level "B"
        7  => [    110,   195,   110  ], # Colour For: Weapon Level "C"
        8  => [     80,   225,    80  ], # Colour For: Weapon Level "D"
        9  => [     50,   255,    50  ], # Colour For: Weapon Level "E"
        10 => [    255,   255,   255  ], # Colour For: No Weapon Param Bonus
        11 => [     50,   255,    50  ], # Colour For: Weapon Param Bonus
        12 => [    255,   216,     0  ], # Colour For: Equipped Weapon Param Bonus
        13 => [    127,   100,    36  ], # Colour For: Weapon Gauge Primary Colour
        14 => [     63,    50,    18  ], # Colour For: Weapon Gauge Gradient Colour
      },
      
      :weapon_icon_id => {
        #     Icon_ID,   
        1  => [ 144 ],       # Weapon Type: Axe
        2  => [ 145 ],       # Weapon Type: Claw
        3  => [ 146 ],       # Weapon Type: Spear
        4  => [ 147 ],       # Weapon Type: Sword
        5  => [ 148 ],       # Weapon Type: Katana
        6  => [ 149 ],       # Weapon Type: Bow
        7  => [ 150 ],       # Weapon Type: Dagger 
        8  => [ 151 ],       # Weapon Type: Hammer
        9  => [ 152 ],       # Weapon Type: Staff
        10 => [ 153 ],       # Weapon Type: Gun
                             # More Weapon Types? No Worries, Insert Them Here.
      },
      
    :bonusparam_icon_id => {
        #    Icon_ID,   
        1  => [ 66 ],       # Icon for Bonus Param: ATK
        2  => [ 67 ],       # Icon for Bonus Param: DEF
        3  => [ 68 ],       # Icon for Bonus Param: MAT
        4  => [ 69 ],       # Icon for Bonus Param: MDF
        5  => [ 70 ],       # Icon for Bonus Param: AGI
      },
    }
    #=========================================================== 
    #                                           \/
    #               End of Editable Region      /\
    #                                           \/
    #===========================================================
    #---------------------------------------------------------
    # No touchie past here unless you know what you are 
    # doing. Failure to heed this warning could cause your 
    # computer to yell and scream at you. 
    #
    # Edit at your own risk.
    #--------------------------------------------------------
    
    
    
    
    
    
    
    
    
    
    #------------------------------------------------------------------------
    # * Toggle Weapon Level Message Box
    #------------------------------------------------------------------------
    def self.toggle_weapon_level_message_display( on_or_off )
      self.const_set(:Show_Message_Box, on_or_off) if !!on_or_off == on_or_off
    end
    #------------------------------------------------------------------------
    # * Get Current Weapon Skill
    #------------------------------------------------------------------------
    def self.get_current_weapon_level( wType, actor_id, wCurrentSkill )
      return "E" if wType <= 0 || wCurrentSkill == nil
      return "S" if wCurrentSkill >= WeaponAccumulation[wType][4]
      return "A" if wCurrentSkill >= WeaponAccumulation[wType][3]
      return "B" if wCurrentSkill >= WeaponAccumulation[wType][2]
      return "C" if wCurrentSkill >= WeaponAccumulation[wType][1]
      return "D" if wCurrentSkill >= WeaponAccumulation[wType][0]
      return "E"
    end
    #------------------------------------------------------------------------
    # * Convert Skill String To Index
    #------------------------------------------------------------------------
    def self.convert_skill_string_to_index( skill_string )
      case skill_string
        when "S" then return 4
        when "A" then return 3
        when "B" then return 2
        when "C" then return 1
        when "D" then return 0
      end
      return -1
    end
    #------------------------------------------------------------------------
    # * Increment Weapon Skill Points
    #------------------------------------------------------------------------
    def self.increment_weapon_skill_points( actor_id, skillpoints = -1 )
      skillpoints = Attack_Points_Gain if skillpoints < 0
      actor = $game_actors[actor_id]
      
      # Get Weapon Types and Skill Levels
      weapontype1 = actor.equips[0] && actor.equips[0].is_a?(RPG::Weapon) ? actor.equips[0].wtype_id : 0
      weapontype2 = actor.equips[1] && actor.equips[1].is_a?(RPG::Weapon) ? actor.equips[1].wtype_id : 0
            
      # Increment Weapon Skill Points, Add Bonus Params, Show Level Up Message Box
      if weapontype1 && weapontype1 > 0
        weapon_skill = get_current_weapon_level( weapontype1, actor.id, actor.dp3_weapon_level[weapontype1 - 1] )
        actor.dp3_weapon_level[weapontype1 - 1] += skillpoints 
        show_weapon_level_up_message_box(weapontype1, actor_id, weapon_skill)
        remove_and_add_bonus_params(weapontype1, actor_id, weapon_skill)
        remove_and_add_bonus_skills(weapontype1, actor_id, weapon_skill)
      end
      
      if weapontype2 && weapontype2 > 0
        weapon_skill = get_current_weapon_level( weapontype2, actor.id, actor.dp3_weapon_level[weapontype2 - 1] )
        actor.dp3_weapon_level[weapontype2 - 1] += skillpoints
        if weapontype1 != weapontype2
          show_weapon_level_up_message_box(weapontype2, actor_id, weapon_skill)
          remove_and_add_bonus_params(weapontype2, actor_id, weapon_skill)
          remove_and_add_bonus_skills(weapontype2, actor_id, weapon_skill)
        end
      end
    end
    #------------------------------------------------------------------------
    # * Increment Specific Weapon Skill Points
    #------------------------------------------------------------------------
    def self.increment_specific_weapon_skill_points( actor_id, wType, skillpoints = 1 )
      actor = $game_actors[actor_id]
      
      # Get Weapon Types and Skill Levels
      weapon_skill = get_current_weapon_level( wType, actor_id, actor.dp3_weapon_level[wType - 1] )
        
      # Increase Weapon Skill Points
      actor.dp3_weapon_level[wType - 1] += skillpoints
      
      # Show Weapon Level Up Message Box if Weapon Rank Increased
      show_weapon_level_up_message_box(wType, actor_id, weapon_skill)
      
      # Modify Bonus Params if Weapon Rank Increased
      remove_and_add_bonus_params(wType, actor_id, weapon_skill)
      
      # Modify Bonus Skills if Weapon Rank Increased
      remove_and_add_bonus_skills(wType, actor_id, weapon_skill)
    end
    #------------------------------------------------------------------------
    # * Add Bonus Params
    #------------------------------------------------------------------------
    def self.add_bonus_params( wType, actor_id, slot_id, skip_weapon_check = false, curr_skill = nil)
      unless !skip_weapon_check && get_opposing_weapon_slot_weapon_type( actor_id, slot_id ) == wType
        actor = $game_actors[actor_id]
        unless curr_skill
          method_args = [wType, actor_id, actor.dp3_weapon_level[wType - 1]]
          curr_skill = get_current_weapon_level( *method_args )
        end
        for i in 0..4
          actor.dp3_increment_param(i + 2, get_bonus_param( wType, actor_id, i, curr_skill ))
        end
      end
    end
    #------------------------------------------------------------------------
    # * Remove Bonus Params
    #------------------------------------------------------------------------
    def self.remove_bonus_params( wType, actor_id, slot_id, skip_weapon_check = false, curr_skill = nil)
      unless !skip_weapon_check && get_opposing_weapon_slot_weapon_type( actor_id, slot_id ) == wType
        actor = $game_actors[actor_id]
        unless curr_skill
          method_args = [wType, actor_id, actor.dp3_weapon_level[wType - 1]]
          curr_skill = get_current_weapon_level( *method_args )
        end
        for i in 0..4
          actor.dp3_decrement_param(i + 2, get_bonus_param( wType, actor_id, i, curr_skill ))
        end
      end
    end
    #------------------------------------------------------------------------
    # * Add and Remove Bonus Params
    #------------------------------------------------------------------------
    def self.remove_and_add_bonus_params(wType, actor_id, skill_before)
      curr_skill = get_current_weapon_level( wType, actor_id, $game_actors[actor_id].dp3_weapon_level[wType - 1] )
      
      if convert_skill_string_to_index(curr_skill) > convert_skill_string_to_index(skill_before)
        if get_currently_equipping_this_weapon_type( wType, actor_id )
          remove_bonus_params( wType, actor_id, nil, true)
          add_bonus_params( wType, actor_id, nil, true)
        end
      end
    end
    #------------------------------------------------------------------------
    # * Add Weapon Bonus Skills
    #------------------------------------------------------------------------
    def self.add_weapon_bonus_skills( wType, actor_id, slot_id, skip_weapon_check = false, curr_skill = nil)
     unless !skip_weapon_check && get_opposing_weapon_slot_weapon_type( actor_id, slot_id ) == wType
       unless curr_skill
          method_args = [wType, actor_id, $game_actors[actor_id].dp3_weapon_level[wType - 1]]
          curr_skill = get_current_weapon_level( *method_args )
        end
        curr_skill = convert_skill_string_to_index( curr_skill )
        return if curr_skill < 0
        
        # Now Apply Learning the Skills
        WeaponSkillBonuses[wType][curr_skill + 1].each do |skill_id|
          $game_actors[actor_id].learn_skill(skill_id)
        end
      end
    end
    #------------------------------------------------------------------------
    # * Remove Weapon Bonus Skills
    #------------------------------------------------------------------------
    def self.remove_weapon_bonus_skills( wType, actor_id, slot_id, skip_weapon_check = false, curr_skill = nil)
      unless !skip_weapon_check && get_opposing_weapon_slot_weapon_type( actor_id, slot_id ) == wType
        unless curr_skill
          method_args = [wType, actor_id, $game_actors[actor_id].dp3_weapon_level[wType - 1]]
          curr_skill = get_current_weapon_level( *method_args )
        end
        curr_skill = convert_skill_string_to_index( curr_skill )
        return if curr_skill < 0
        
        # Now Apply Forgetting the Skills
        WeaponSkillBonuses[wType][curr_skill + 1].each do |skill_id|
          $game_actors[actor_id].forget_skill(skill_id)
        end
        
        # Incase of Dual Wielding Weapons, the other Weapon May Contain Skills We 
        # Just Removed, So Relearn them if Necessary
        return if skip_weapon_check
        wType = get_opposing_weapon_slot_weapon_type( actor_id, slot_id )
        return if wType == 0
        method_args = [wType, actor_id, $game_actors[actor_id].dp3_weapon_level[wType - 1]]
        curr_skill = get_current_weapon_level( *method_args )
        add_weapon_bonus_skills( wType, actor_id, nil, true, curr_skill)
      end
    end
    #------------------------------------------------------------------------
    # * Add and Remove Bonus Skills
    #------------------------------------------------------------------------
    def self.remove_and_add_bonus_skills(wType, actor_id, skill_before)
      curr_skill = get_current_weapon_level( wType, actor_id, $game_actors[actor_id].dp3_weapon_level[wType - 1] )
      
      if convert_skill_string_to_index(curr_skill) > convert_skill_string_to_index(skill_before)
        if get_currently_equipping_this_weapon_type( wType, actor_id )
          remove_weapon_bonus_skills( wType, actor_id, nil, true, skill_before)
          add_weapon_bonus_skills( wType, actor_id, nil, true, curr_skill)
        end
      end
    end
    #------------------------------------------------------------------------
    # * Weapon Compatible With Current Skill?
    #------------------------------------------------------------------------
    def self.get_skilllevel_and_weapon_compatible( current_skill, wskill )
      current_skill         = convert_skill_string_to_index(current_skill) 
      wskill                = convert_skill_string_to_index(wskill)
      return current_skill >= wskill
    end  
    #------------------------------------------------------------------------
    # * Get Currently Equipped This Weapon Type?
    #------------------------------------------------------------------------
    def self.get_currently_equipping_this_weapon_type( wType, actor_id )
      weapon1 = $game_actors[actor_id].equips[0]
      weapon1 = weapon1 && weapon1.is_a?(RPG::Weapon) ? weapon1.wtype_id : 0
      weapon2 = $game_actors[actor_id].equips[1]
      weapon2 = weapon2 && weapon2.is_a?(RPG::Weapon) ? weapon2.wtype_id : 0
      return weapon1 == wType || weapon2 == wType
    end 
    #------------------------------------------------------------------------
    # * Get Opposing Weapon Slot Type ~ Dual Wielding
    #------------------------------------------------------------------------
    def self.get_opposing_weapon_slot_weapon_type( actor_id, slot_id )
      # We're Checking the opposite Weapon Slot
      if slot_id == 0
        slot_id = 1 
      else
        slot_id = 0
      end
      weapontype = $game_actors[actor_id].equips[slot_id]
      weapontype = weapontype && weapontype.is_a?(RPG::Weapon) ? weapontype.wtype_id : 0
      return weapontype
    end 
    #------------------------------------------------------------------------
    # * Get Next Level Up Rate
    #------------------------------------------------------------------------
    def self.get_next_level_up_rate( wType, actor_id, current_skill, current_skill_points )
      return 0.0 if wType <= 0
      case current_skill
        when "S" 
          return 1.0
        when "A" 
          return current_skill_points.to_f / WeaponAccumulation[wType][4]
        when "B" 
          return current_skill_points.to_f / WeaponAccumulation[wType][3]
        when "C" 
          return current_skill_points.to_f / WeaponAccumulation[wType][2]
        when "D" 
          return current_skill_points.to_f / WeaponAccumulation[wType][1]
      end
      return current_skill_points.to_f / WeaponAccumulation[wType][0]
    end
    #------------------------------------------------------------------------
    # * Get Bonus Param
    #------------------------------------------------------------------------
    def self.get_bonus_param( wType, actor_id, param, curr_skill, return_float = false )
      return 0 if curr_skill == "E" || wType <= 0
      index = 5 * convert_skill_string_to_index(curr_skill)
      actor_param = $game_actors[actor_id].class.params[param + 2, $game_actors[actor_id].level]
      actor_param = (actor_param.to_f * (WeaponParamBonuses[wType][param + index].to_f * 0.01)).to_f
      actor_param = 1.0 if actor_param < 1.0 && WeaponParamBonuses[wType][param + index] > 0
      return actor_param if return_float
      return actor_param.to_i
    end
    #--------------------------------------------------------------------------
    # * Show Weapon Level Up Message Box
    #--------------------------------------------------------------------------
    def self.show_weapon_level_up_message_box(wType, actor_id, skill_before)
      return unless actor_id && Show_Message_Box && wType > 0
      curr_skill = get_current_weapon_level( wType, actor_id, $game_actors[actor_id].dp3_weapon_level[wType - 1] )
      
      if convert_skill_string_to_index(curr_skill) > convert_skill_string_to_index(skill_before)
        RPG::SE.new(Rank_Up_SE, SE_Volume, SE_Pitch).play if Rank_Up_SE && Rank_Up_SE != "NO_SOUNDEFFECT"
        actor_name = $game_actors[actor_id].name + "'s "
        $game_message.add('\.' + $game_actors[actor_id].name + " " + Increased_Weapon_Rank_Text)
        
        # Attack
        old_bonus_param = get_bonus_param( wType, actor_id, 0, skill_before, true )
        new_bonus_param = get_bonus_param( wType, actor_id, 0, curr_skill, true )
        $game_message.add('\.' + actor_name + Increased_Attack_Power) if new_bonus_param > old_bonus_param
        
        # Defence
        old_bonus_param = get_bonus_param( wType, actor_id, 1, skill_before, true )
        new_bonus_param = get_bonus_param( wType, actor_id, 1, curr_skill, true )
        $game_message.add('\.' + actor_name + Increased_Defence_Power) if new_bonus_param > old_bonus_param
        
        # Magic Attack
        old_bonus_param = get_bonus_param( wType, actor_id, 2, skill_before, true )
        new_bonus_param = get_bonus_param( wType, actor_id, 2, curr_skill, true )
        $game_message.add('\.' + actor_name + Increased_Magic_Attack_Power) if new_bonus_param > old_bonus_param
        
        # Magic Defense
        old_bonus_param = get_bonus_param( wType, actor_id, 3, skill_before, true )
        new_bonus_param = get_bonus_param( wType, actor_id, 3, curr_skill, true )
        $game_message.add('\.' + actor_name + Increased_Magic_Defence_Power) if new_bonus_param > old_bonus_param
        
        # Agility
        old_bonus_param = get_bonus_param( wType, actor_id, 4, skill_before, true )
        new_bonus_param = get_bonus_param( wType, actor_id, 4, curr_skill, true )
        $game_message.add('\.' + actor_name + Increased_Agility_Power) if new_bonus_param > old_bonus_param
        
        # Learned new Skill?
        curr_skill = convert_skill_string_to_index( curr_skill )
        WeaponSkillBonuses[wType][curr_skill + 1].each do |skill_id|
          unless $game_actors[actor_id].skill_learn?($data_skills[skill_id])
            $game_actors[actor_id].learn_skill(skill_id)
            $game_message.add('\.' + $game_actors[actor_id].name + " " + Acquired_New_Skill)
            break
          end
        end
      end
    end
  end # Weapon Levels Module
end # DiamondandPlatinum3 Module



#==============================================================================
# ** Game_Actor
#------------------------------------------------------------------------------
#  This class handles actors. It is used within the Game_Actors class
# ($game_actors) and is also referenced from the Game_Party class ($game_party).
#==============================================================================

class Game_Actor < Game_Battler
  #--------------------------------------------------------------------------
  # * Public Instance Variables
  #--------------------------------------------------------------------------
  attr_accessor :dp3_weapon_level                 # Weapon Level Array
  attr_accessor :dp3_normal_params                # Regular Parameters Array
  attr_accessor :dp3_actor_param_weapon_bonus     # Bonus Parameters Array
  #--------------------------------------------------------------------------
  # * Alias Listings
  #--------------------------------------------------------------------------
  alias dp3_weaplev_gameactor_init_0edku                  initialize
  alias dp3_weaplev_gameactor_equippable_0edku            equippable?
  alias dp3_weaplev_gameactor_changeequip_0edku           change_equip
  alias dp3_weaplev_gameactor_skillconditionsmet_0edku    skill_conditions_met?
  #--------------------------------------------------------------------------
  # * Object Initialization
  #--------------------------------------------------------------------------
  def initialize( *args )
    @dp3_weapon_level             = []
    @dp3_normal_params            = [ 0, 0, 0, 0, 0  ] # ATK, DEF, MAT, MDF, AGI
    @dp3_actor_param_weapon_bonus = [ 0, 0, 0, 0, 0,   # ATK, DEF, MAT, MDF, AGI
                                      0, 0, 0, 0, 0, ] # In Case Of Dual Wielding
    highest_weapon_id = 0
    for weapon in $data_weapons
      highest_weapon_id = weapon.wtype_id if weapon && weapon.wtype_id > highest_weapon_id
    end
    while(@dp3_weapon_level.size < highest_weapon_id)
      @dp3_weapon_level[@dp3_weapon_level.size] = 0
    end
    
    
    # Call Original Method
    dp3_weaplev_gameactor_init_0edku( *args )
  end
  #--------------------------------------------------------------------------
  # * Determine if Equippable
  #--------------------------------------------------------------------------
  def equippable?(item)
    can_equip = dp3_weaplev_gameactor_equippable_0edku(item) # Call Original Method
    return can_equip || item.is_a?(RPG::Weapon) && dp3_is_weapon_level_sufficient(item)
  end
  #--------------------------------------------------------------------------
  # * Change Equipment
  #--------------------------------------------------------------------------
  def change_equip(slot_id, item)
    # Remove the Bonus Params For the Weapon Type Being Removed
    if self.equips[slot_id] && self.equips[slot_id].is_a?(RPG::Weapon)
      removed_weapon_type = self.equips[slot_id].wtype_id
      if removed_weapon_type > 0
        DiamondandPlatinum3::WeaponLevels::remove_bonus_params(removed_weapon_type, self.id, slot_id)
        DiamondandPlatinum3::WeaponLevels::remove_weapon_bonus_skills(removed_weapon_type, self.id, slot_id)
      end
    end
       
    # Add the Bonus Params For the Weapon Type Being Equipped
    if item && item.is_a?(RPG::Weapon)
      new_weapon_type = item.wtype_id
      if new_weapon_type > 0
        DiamondandPlatinum3::WeaponLevels::add_bonus_params(new_weapon_type, self.id, slot_id)
        DiamondandPlatinum3::WeaponLevels::add_weapon_bonus_skills(new_weapon_type, self.id, slot_id)
      end
    end
   
    # Call Original Method
    dp3_weaplev_gameactor_changeequip_0edku(slot_id, item)
  end

  #--------------------------------------------------------------------------
  # * Determine if Weapon Level is Sufficient
  #--------------------------------------------------------------------------
  def dp3_is_weapon_level_sufficient(weapon)
    # Do Not Equip Weapon Type Notetag
    $data_actors[self.id].note[/~DoNotEquip\[\s*(.+?)\]/im]
    if $1
      do_not_equip_types = $1.scan(/\d+/).collect {|i| i.to_i }
      return false if do_not_equip_types.include?(weapon.wtype_id)
    end
    #~~~~~
    return true if weapon.wtype_id == 0
    $data_weapons[weapon.id].note[/~WeaponLevel:\s*(.+)/i]
    return true unless $1 && $1 != ""
    method_args = [ weapon.wtype_id, self.id, @dp3_weapon_level[weapon.wtype_id - 1] ]
    curr_skill = DiamondandPlatinum3::WeaponLevels::get_current_weapon_level( *method_args )
    return DiamondandPlatinum3::WeaponLevels::get_skilllevel_and_weapon_compatible( curr_skill, $1.upcase )   
  end
  #--------------------------------------------------------------------------
  # * Increment Param
  #--------------------------------------------------------------------------
  def dp3_increment_param(param_id, incrementation)
    @param_plus[param_id] += incrementation
  end
  #--------------------------------------------------------------------------
  # * Decrement Param
  #--------------------------------------------------------------------------
  def dp3_decrement_param(param_id, decrementation)
    @param_plus[param_id] -= decrementation
  end
  #--------------------------------------------------------------------------
  # * Check Usability Conditions for Skill
  #--------------------------------------------------------------------------
  def skill_conditions_met?(skill)
    return true if dp3_weaplev_gameactor_skillconditionsmet_0edku(skill)
    return false unless usable_item_conditions_met?(skill)
    
    # Check Weapon Types and Skills for Usability
    weapontype = self.equips[0] && self.equips[0].is_a?(RPG::Weapon) ? self.equips[0].wtype_id : 0
    if weapontype > 0
      method_args = [ weapontype, self.id, @dp3_weapon_level[weapontype - 1] ]
      curr_skill = DiamondandPlatinum3::WeaponLevels::get_current_weapon_level( *method_args )
      if curr_skill != "E"
        curr_skill = DiamondandPlatinum3::WeaponLevels::convert_skill_string_to_index( curr_skill ) + 1
        return true if DiamondandPlatinum3::WeaponLevels::WeaponSkillBonuses[weapontype][curr_skill].include?(skill.id)
      end
    end
    # Weapon 2
    weapontype = self.equips[1] && self.equips[1].is_a?(RPG::Weapon) ? self.equips[1].wtype_id : 0
    return false if weapontype <= 0
    method_args = [ weapontype, self.id, @dp3_weapon_level[weapontype - 1] ]
    curr_skill = DiamondandPlatinum3::WeaponLevels::get_current_weapon_level( *method_args )
    return false if curr_skill == "E"
    curr_skill = DiamondandPlatinum3::WeaponLevels::convert_skill_string_to_index( curr_skill ) + 1
    return DiamondandPlatinum3::WeaponLevels::WeaponSkillBonuses[weapontype][curr_skill].include?(skill.id)
  end
end







#==============================================================================
# ** Game_Battler
#------------------------------------------------------------------------------
#  A battler class with methods for sprites and actions added. This class 
# is used as a super class of the Game_Actor class and Game_Enemy class.
#==============================================================================

class Game_Battler < Game_BattlerBase
  #--------------------------------------------------------------------------
  # * Alias Listings
  #--------------------------------------------------------------------------
  alias dp3_weaplev_gamebattler_useitem_0edku                 use_item  
  #--------------------------------------------------------------------------
  # * Aliased Method: Use Skill/Item
  #--------------------------------------------------------------------------
  def use_item(item)
    if @actor_id && item.is_a?(RPG::Skill)
      #///// Increment Skill Points if Necessary /////#
      if item.id == 1 # Attack
        DiamondandPlatinum3::WeaponLevels::increment_weapon_skill_points( @actor_id )
      else
        $data_skills[item.id].note[/~EarnWeaponSkillPoints:\s*(\d+)/im]
        if $1 && $1 != ""
          DiamondandPlatinum3::WeaponLevels::increment_weapon_skill_points( @actor_id, $1.to_i )
        end
      end
    end
    
    # Call Original Method
    dp3_weaplev_gamebattler_useitem_0edku(item)
  end
end








#==============================================================================
# ** Window_WeaponLevelStatus
#------------------------------------------------------------------------------
#  This window displays full status specs on the Weapon Ranks.
#==============================================================================

class Window_WeaponLevelStatus < Window_Selectable
  include DiamondandPlatinum3::WeaponLevels
  #--------------------------------------------------------------------------
  # * Object Initialization
  #--------------------------------------------------------------------------
  def initialize(actor)
    @actor = actor
    create_oy_params
    super(0, 0, Graphics.width, Graphics.height)
    refresh
    activate
  end
  #--------------------------------------------------------------------------
  # * Create OY Params
  #--------------------------------------------------------------------------
  def create_oy_params
    $data_actors[@actor.id].note[/~DoNotEquip\[\s*(.+?)\]/im]
    do_not_equip_types = $1 ? $1.scan(/\d+/).collect {|i| i.to_i } : []
    @oy_finish = (90 + (25 * (WeaponAccumulation.size - do_not_equip_types.size)))
  end
  #--------------------------------------------------------------------------
  # * Set Contents Height
  #--------------------------------------------------------------------------
  def contents_height
    return @oy_finish
  end
  #--------------------------------------------------------------------------
  # * Set Actor
  #--------------------------------------------------------------------------
  def actor=(actor)
    return if @actor == actor
    @actor = actor
    create_oy_params
    create_contents
    self.oy = 0
    refresh
  end
  #--------------------------------------------------------------------------
  # * Update
  #--------------------------------------------------------------------------
  def update(*args)
    super(*args)
    self.oy += 1 if Input.press?(:DOWN) && self.oy <= (@oy_finish - self.height)
    self.oy -= 1 if Input.press?(:UP)   && self.oy > 0
  end
  #--------------------------------------------------------------------------
  # * Refresh
  #--------------------------------------------------------------------------
  def refresh
    contents.clear
    @xPos = 20; @yPos = 5
    # Draw Top
    draw_actor_name()
    draw_horz_line(@yPos)
    @yPos += 20
    
    # Draw Lower
    draw_labels()
    draw_weapon_level_info()
  end
  #--------------------------------------------------------------------------
  # * Draw Horizontal Line
  #--------------------------------------------------------------------------
  def draw_horz_line(y)
    line_colour = normal_color
    line_colour.alpha = 48
    line_y = y + line_height / 2 - 1
    contents.fill_rect(0, line_y, contents_width, 2, line_colour)
  end
  #--------------------------------------------------------------------------
  # * Draw Icon
  #--------------------------------------------------------------------------
  def draw_icon(icon_index, x, y, w = 24, h = 24, enabled = true)
    bitmap = Cache.system("Iconset")
    blit_x = ((icon_index % 16) * 24) + (24 - w)
    blit_y = ((icon_index / 16) * 24) + (24 - h)
    rect = Rect.new(blit_x, blit_y, w, h)
    y += (24 - h)
    contents.blt(x, y, bitmap, rect, enabled ? 255 : translucent_alpha)
  end
  #--------------------------------------------------------------------------
  # * Draw Name
  #--------------------------------------------------------------------------
  def draw_actor_name()
    contents.font.size = 30
    w = (@actor.name.length * contents.font.size)
    x = ((self.width * 0.5) - ((@actor.name.length * 13) * 0.5))
    self.change_color(Color.new(*WeaponStatusMenuInfo[:weapon_level_colour][1]))
    self.draw_text(x, @yPos, w, contents.font.size, @actor.name)
    
    
    change_color(normal_color)
    contents.font.size = Font.default_size
    
    @yPos += 30
  end
  #--------------------------------------------------------------------------
  # * Draw Labels
  #--------------------------------------------------------------------------
  def draw_labels()
    contents.font.size = 30
    @xPos += 30
    self.change_color(Color.new(*WeaponStatusMenuInfo[:weapon_level_colour][2]))
    self.draw_text(@xPos, @yPos, 180, contents.font.size, "Weapon Level")
    @xPos += 210
    self.draw_text(@xPos, @yPos, 250, contents.font.size, "Current Weapon Bonuses")
    change_color(normal_color)
    contents.font.size = Font.default_size
    @xPos = 20
    @yPos += 35
  end
  #--------------------------------------------------------------------------
  # * Draw Weapon Level Info
  #--------------------------------------------------------------------------
  def draw_weapon_level_info()
    $data_actors[@actor.id].note[/~DoNotEquip\[\s*(.+?)\]/im]
    do_not_equip_types = $1 ? $1.scan(/\d+/).collect {|i| i.to_i } : []
    yPos_Correction = 25
    for i in 1..WeaponAccumulation.size
      # Skip this Weapon Type?
      next if do_not_equip_types.include?(i)
      # Get Current Weapon Skill
      curr_skill = get_current_weapon_skill(i)
      # Draw Icon
      draw_icon(WeaponStatusMenuInfo[:weapon_icon_id][i][0], @xPos, @yPos, 24, yPos_Correction)
      @xPos += 25
      # Draw Gauge
      rate = get_next_level_up_rate(i, curr_skill)
      draw_gauge(@xPos, @yPos - 5, 150, rate, get_gaugecolour1, get_gaugecolour2)
      @xPos += 175 # Gauge Width Plus 25 Offset
      # Draw Weapon Level
      self.change_color(get_weapon_level_colour( curr_skill ))
      draw_text(@xPos, @yPos, 25, 25, curr_skill)
      self.change_color(normal_color)
      @xPos += 25
      # Draw Weapon Bonuses
      for j in 0..4
        draw_icon(WeaponStatusMenuInfo[:bonusparam_icon_id][j + 1][0], @xPos, @yPos, 24, yPos_Correction)
        @xPos += 29
        bonus = self.get_actor_bonus_param( i, j, curr_skill )
        text = bonus.to_s
        self.change_color(get_weapon_bonus_colour( bonus, i ))
        draw_text(@xPos, @yPos, 23, yPos_Correction, text)
        self.change_color(normal_color)
        @xPos += 26
      end
      @xPos = 20
      @yPos += yPos_Correction
    end
  end
  #--------------------------------------------------------------------------
  # * Get Current Weapon Skill
  #--------------------------------------------------------------------------
  def get_current_weapon_skill( wType )
    return DiamondandPlatinum3::WeaponLevels::get_current_weapon_level( 
            wType, @actor.id, @actor.dp3_weapon_level[wType - 1] )
  end
  #--------------------------------------------------------------------------
  # * Get Current Weapon Skill
  #--------------------------------------------------------------------------
  def get_next_level_up_rate( wType, curr_skill )
    return DiamondandPlatinum3::WeaponLevels::get_next_level_up_rate( 
            wType, @actor.id, curr_skill, @actor.dp3_weapon_level[wType - 1] )
  end
  #--------------------------------------------------------------------------
  # * Get Current Weapon Skill
  #--------------------------------------------------------------------------
  def get_actor_bonus_param( wType, param, curr_skill )
    return DiamondandPlatinum3::WeaponLevels::get_bonus_param( 
            wType, @actor.id, param, curr_skill )
  end        
  #--------------------------------------------------------------------------
  # * Get Gauge Colours
  #--------------------------------------------------------------------------
  def get_gaugecolour1
    return Color.new(*WeaponStatusMenuInfo[:weapon_level_colour][13])
  end
  def get_gaugecolour2
    return Color.new(*WeaponStatusMenuInfo[:weapon_level_colour][14])
  end
  #--------------------------------------------------------------------------
  # * Get Weapon Level Colours
  #--------------------------------------------------------------------------
  def get_weapon_level_colour( curr_skill )
    case curr_skill
      when "S"; return Color.new(*WeaponStatusMenuInfo[:weapon_level_colour][4])
      when "A"; return Color.new(*WeaponStatusMenuInfo[:weapon_level_colour][5])
      when "B"; return Color.new(*WeaponStatusMenuInfo[:weapon_level_colour][6])
      when "C"; return Color.new(*WeaponStatusMenuInfo[:weapon_level_colour][7])
      when "D"; return Color.new(*WeaponStatusMenuInfo[:weapon_level_colour][8])
    end
    return Color.new(*WeaponStatusMenuInfo[:weapon_level_colour][9])
  end
  #--------------------------------------------------------------------------
  # * Get Weapon Bonus Colour
  #--------------------------------------------------------------------------
  def get_weapon_bonus_colour( bonus, wType )
    if @actor.equips[0] && @actor.equips[0].wtype_id == wType || @actor.equips[1] && @actor.equips[1].is_a?(RPG::Weapon) && @actor.equips[1].wtype_id == wType
      return Color.new(*WeaponStatusMenuInfo[:weapon_level_colour][12])
    end
    return Color.new(*WeaponStatusMenuInfo[:weapon_level_colour][11]) if bonus > 0
    return Color.new(*WeaponStatusMenuInfo[:weapon_level_colour][10])
  end
end





#==============================================================================
# ** Scene_WeaponLevelStatus
#------------------------------------------------------------------------------
#  This class performs the WeaponLevelStatus screen processing.
#==============================================================================

class Scene_WeaponLevelStatus < Scene_MenuBase
  #--------------------------------------------------------------------------
  # * Start Processing
  #--------------------------------------------------------------------------
  def start
    super
    @status_window = Window_WeaponLevelStatus.new(@actor)
    @status_window.set_handler(:cancel,   method(:return_scene))
    @status_window.set_handler(:pagedown, method(:next_actor))
    @status_window.set_handler(:pageup,   method(:prev_actor))
  end
  #--------------------------------------------------------------------------
  # * Change Actors
  #--------------------------------------------------------------------------
  def on_actor_change
    @status_window.actor = @actor
    @status_window.activate
  end
end






#==============================================================================
# ** Window_MenuCommand
#------------------------------------------------------------------------------
#  This command window appears on the menu screen.
#==============================================================================

class Window_MenuCommand < Window_Command
  #--------------------------------------------------------------------------
  # * For Adding Original Commands
  #--------------------------------------------------------------------------
  alias dp3_weaplev_winmenucommand_addorigcommd_0edku   add_original_commands
  #--------------------------------------------------------------------------
  def add_original_commands
    add_command(DiamondandPlatinum3::WeaponLevels::Menu_Option_Title, :weapon_level_status_command, main_commands_enabled)
    dp3_weaplev_winmenucommand_addorigcommd_0edku()
  end
end







#==============================================================================
# ** Window_EquipStatus
#------------------------------------------------------------------------------
#  This window displays actor parameter changes on the equipment screen.
#==============================================================================

class Window_EquipStatus < Window_Base
  #--------------------------------------------------------------------------
  # * Alias Listings
  #--------------------------------------------------------------------------
  alias dp3_weaplev_windowequipstatus_initialize_0edku            initialize
  alias dp3_weaplev_windowequipstatus_drawnewparam_0edku          draw_new_param
  #--------------------------------------------------------------------------
  # * Object Initialization
  #--------------------------------------------------------------------------
  def initialize(x, y)
    @dp3_slot_id = 0
    dp3_weaplev_windowequipstatus_initialize_0edku(x, y) # Call Original Method
  end
  #--------------------------------------------------------------------------
  # * Draw Post-Equipment Change Parameter
  #--------------------------------------------------------------------------
  def draw_new_param(x, y, param_id)
    bool1 = @temp_actor && @temp_actor.equips[@dp3_slot_id].is_a?(RPG::Weapon)
    bool2 = param_id > 1 && param_id < 7
    if bool1 && bool2 
      # Get Weapon Types
      wType  = @actor.equips[@dp3_slot_id] && @actor.equips[@dp3_slot_id].is_a?(RPG::Weapon) ? @actor.equips[@dp3_slot_id].wtype_id : 0
      wType2 = @temp_actor.equips[@dp3_slot_id].wtype_id
      weapon_bonus_param = 0
      
      unless wType2 == wType || wType2 == DiamondandPlatinum3::WeaponLevels::get_opposing_weapon_slot_weapon_type( @actor.id, @dp3_slot_id )
        # Remove Negative Bonus Param from Temp Actor (AKA Current Actor Equipped Weapon)
        curr_skill = DiamondandPlatinum3::WeaponLevels::get_current_weapon_level( wType, @actor.id, @actor.dp3_weapon_level[wType - 1] )
        @temp_actor.dp3_decrement_param(param_id, DiamondandPlatinum3::WeaponLevels::get_bonus_param( wType, @actor.id, param_id - 2, curr_skill ))
        
        # Get Bonus Param (AKA New Weapon)
        curr_skill = DiamondandPlatinum3::WeaponLevels::get_current_weapon_level( wType2, @temp_actor.id, @temp_actor.dp3_weapon_level[wType2 - 1] )
        weapon_bonus_param = DiamondandPlatinum3::WeaponLevels::get_bonus_param( wType2, @temp_actor.id, param_id - 2, curr_skill ) 
      end
      
      # Apply Param
      new_value = (@temp_actor.param(param_id) + weapon_bonus_param)
      change_color(param_change_color(new_value - @actor.param(param_id)))
      draw_text(x, y, 32, line_height, new_value, 2)
      
    else
      # Call Original Method
      dp3_weaplev_windowequipstatus_drawnewparam_0edku(x, y, param_id)
    end
  end
  #--------------------------------------------------------------------------
  # * Set Slot ID
  #--------------------------------------------------------------------------
  def dp3_add_slot_id( slot_id )
    @dp3_slot_id = slot_id
  end
  #--------------------------------------------------------------------------
  # * Get Temp Actor
  #--------------------------------------------------------------------------
  def dp3_get_temp_actor()
    return @temp_actor
  end
end






#==============================================================================
# ** Window_EquipItem
#------------------------------------------------------------------------------
#  This window displays choices when opting to change equipment on the
# equipment screen.
#==============================================================================

class Window_EquipItem < Window_ItemList
  #--------------------------------------------------------------------------
  # * Update Help Text
  #--------------------------------------------------------------------------
  alias dp3_weaplev_windowequipitem_updatehelp_0edku   update_help
  #--------------------------------------------------------------------------
  def update_help
    dp3_weaplev_windowequipitem_updatehelp_0edku() # Call Original Method
    @status_window.dp3_add_slot_id(@slot_id) 
  end
end




#==============================================================================
# ** Window_SkillList
#------------------------------------------------------------------------------
#  This window is for displaying a list of available skills on the skill window.
#==============================================================================

class Window_SkillList < Window_Selectable
  #--------------------------------------------------------------------------
  # * Include in Skill List? 
  #--------------------------------------------------------------------------
  alias dp3_weaplev_windowskilllist_include_0edku   include?
  #--------------------------------------------------------------------------
  def include?(*args)
    bool = dp3_weaplev_windowskilllist_include_0edku(args[0]) || enable?(args[0])
    return bool && args[0].stype_id == @stype_id
  end
end
  
  


#==============================================================================
# ** Scene_Menu
#------------------------------------------------------------------------------
#  This class performs the menu screen processing.
#==============================================================================

class Scene_Menu < Scene_MenuBase
  #--------------------------------------------------------------------------
  # * Alias Listings
  #--------------------------------------------------------------------------
  alias dp3_weaplev_scenemenu_createcommdwindow_0edku   create_command_window
  alias dp3_weaplev_scenemenu_onpersonalok_0edku        on_personal_ok
  #--------------------------------------------------------------------------
  # * Create Command Window
  #--------------------------------------------------------------------------
  def create_command_window
    dp3_weaplev_scenemenu_createcommdwindow_0edku()
    @command_window.set_handler(:weapon_level_status_command, method(:command_personal))
  end
  #--------------------------------------------------------------------------
  # * [OK] Personal Command
  #--------------------------------------------------------------------------
  def on_personal_ok
    case @command_window.current_symbol
    when :weapon_level_status_command
      SceneManager.call(Scene_WeaponLevelStatus)
    else
      dp3_weaplev_scenemenu_onpersonalok_0edku()
    end
  end
end









#==============================================================================
# ** Game_Interpreter
#------------------------------------------------------------------------------
#  An interpreter for executing event commands. This class is used within the
# Game_Map, Game_Troop, and Game_Event classes.
#==============================================================================

class Game_Interpreter
  #--------------------------------------------------------------------------
  # * Add Weapon Skill Points
  #--------------------------------------------------------------------------
  def add_weapon_skill_points( actor_id, points )
    return unless actor_id.is_a?(Integer) && points.is_a?(Integer)
    if actor_id > 0     
      # Increase Current Weapon(s) points
      DiamondandPlatinum3::WeaponLevels::increment_weapon_skill_points(actor_id, points)    
    end
  end
  #--------------------------------------------------------------------------
  # * Add Weapon Skill Points to Specific Weapon Type
  #--------------------------------------------------------------------------
  def add_specific_weapon_type_skill_points( actor_id, wType, points )
    return unless actor_id.is_a?(Integer) && wType.is_a?(Integer) && points.is_a?(Integer)
    if actor_id > 0 && wType > 0
      # Increment Points
      DiamondandPlatinum3::WeaponLevels::increment_specific_weapon_skill_points( actor_id, wType, points )
    end
  end
  #--------------------------------------------------------------------------
  # * Add Weapon Skill Points to Specific Weapon Type
  #--------------------------------------------------------------------------
  def toggle_weapon_level_message_display( on_or_off )
    DiamondandPlatinum3::WeaponLevels::toggle_weapon_level_message_display( on_or_off )
  end
end