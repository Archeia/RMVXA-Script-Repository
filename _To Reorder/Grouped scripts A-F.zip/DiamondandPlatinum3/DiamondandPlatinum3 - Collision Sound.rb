#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
#             Collision Sound
#             Author: DiamondandPlatinum3
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#  Description:
#
#    This script plays a collision sound when you try walking on to an 
#    non-passable space. This is not used if you have 'through' checked on your
#    player on the other hand.
#    Collision sound only works for the Player, it does not play for other 
#    events if they try to walk into something they shouldn't.
#
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#------------------------------------------------------------------------------
#  Instructions:
#  
#     Editable Region, simply replace the Filename, VOlume & Pitch for the 
#     Collision_SE. You must also set a wait timer until it can be heard again.
#     This is because the collision sound can play many many times if you keep
#     attempting to walk into a wall, so this option sets the cooldown time until
#     it can be heard again.
#
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

class Game_Player < Game_Character
  
  #----------------------------------------
  #     Editable Region
  #----------------------------------------
  Collision_SE          = [ "Bite", 80, 100 ]   # The Collision Sound you wish to play, volume, pitch.
  Collision_Wait_Timer  = 60                    # Wait Timer (in frames) until next collision sound.
  #----------------------------------------
  
  
  
  #--------------------------------------------------------------------------
  # * Frame Update
  #--------------------------------------------------------------------------
  alias dp3_collisionsound_gameplayer_update_sevt       update
  def update
    dp3_collisionsound_gameplayer_update_sevt()
    @collision_sound_timer  = 0 unless @collision_sound_timer != nil
    @collision_sound_timer -= 1 unless @collision_sound_timer == 0
  end
  #--------------------------------------------------------------------------
  # * Determine if Passable
  #--------------------------------------------------------------------------
  alias dp3_collisionsound_gameplayer_passable_sevt       passable?
  def passable?( *args )
    passable = dp3_collisionsound_gameplayer_passable_sevt( *args )
    unless passable == true || @collision_sound_timer > 0
      RPG::SE.new(*Collision_SE).play
      @collision_sound_timer = Collision_Wait_Timer
    end
    return passable
  end
end