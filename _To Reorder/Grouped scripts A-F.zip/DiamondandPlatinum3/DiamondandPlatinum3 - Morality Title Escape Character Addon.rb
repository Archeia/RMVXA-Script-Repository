#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
#             Morality Title Escape Character ~ Add-On
#             Authors: DiamondandPlatinum3
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#  Description:
#
#    This Add-On makes it so that in any of your events, when you display a 
#    variable with the same ID as the Morality Variable, it will convert the
#    display into your current morality title.
#
#    For Example, if the Morality Variable is Variable ID 2 and I use:
#       \v[2]
#    in a show text event, it will end up as "Evil" or "Neutral", etc
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#------------------------------------------------------------------------------
#  Instructions:
#  
#     Plug and Play, nothing required. Just make sure that the latest version 
#     of the Morality script is being used and that it is placed anywhere above 
#     this add-on.
#
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=


#==============================================================================
# ** Window_Base
#------------------------------------------------------------------------------
#  This is a super class of all windows within the game.
#==============================================================================

class Window_Base < Window
  #--------------------------------------------------------------------------
  # * Alias Listings
  #--------------------------------------------------------------------------
  alias dp3_windowsbase_convertescapecharacter_6s5d4g7     convert_escape_characters
  #--------------------------------------------------------------------------
  # * Preconvert Control Characters
  #--------------------------------------------------------------------------
  def convert_escape_characters(text)
    result = text.to_s.clone
    result.gsub!(/\\/)            { "\e" }
    result.gsub!(/\eV\[#{DiamondandPlatinum3::MoralityMetre::MORALITY_VARIABLE_ID.to_s}\]/i) { dp3_get_morality_title() }
    
    
    # Call Original Method
    return dp3_windowsbase_convertescapecharacter_6s5d4g7( result )
  end # Function
  
  #--------------------------------------------------------------------------
  # * Get Morality Title
  #--------------------------------------------------------------------------
  def dp3_get_morality_title()
    title = "Unknown"
    DiamondandPlatinum3::MoralityMetre::MORALITY_NAME.each do |innerarray|
      if $game_variables[DiamondandPlatinum3::MoralityMetre::MORALITY_VARIABLE_ID] >= innerarray[0]
        title = innerarray[1] 
      end
    end
    return title
  end
end # Class




#--------------------------------------------------------------------------
# * Inform User of Non-working Script
#--------------------------------------------------------------------------
msgbox_p("This script has not detected an active version of DiamondandPlatinum3's Morality Metre.",
         "It's possible you are using an outdated version or you have placed this add-on above that script.",
         "If the latter is the case, please put this script in a slot below the Morality Metre Script"
        ) unless ($diamondandplatinum3_scripts ||= {})[:MoralityMetre_Ver20]