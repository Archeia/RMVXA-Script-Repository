#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
#             Idle Title Screen Cutscene
#             Version: 1.0
#             Author: DiamondandPlatinum3
#             Date: June 7, 2014
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#  Description:
#
#    This script adds a timer on the title screen that, when reached, transfers
#    to a Game Map. On this game map, you can use events to show cutscenes or a
#    "story so far" demo.
#
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#------------------------------------------------------------------------------
#  Instructions:
#
#  ~  Modify Editable Region to your liking.
#
#  ~  When Transferring to the Map, the map begins in a screen_fadeout state.
#       This is to allow you to set up the map behind the scenes.
#       When the map is ready to view, use the "Fadein Screen" Event.
#
#  ~  When finished with the Map Cutscene, be sure to use the 
#       "Return to Title Screen" event to return to the title screen.
#
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
module DiamondandPlatinum3
  module IdleTitleScreenCutscene
    #=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
    #                                                        -= 
    #                 Editable Region        ////            ==
    #                                                        =-
    #-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    
    # How long does the Title Screen have to be waiting before
    # skipping to the map?
    #
    # Note: this is done with seconds. So 30.5 would quite literally
    #       mean "30 and a half seconds"
    SkipTimer = 30.0
    
    # If the player presses any button. Should the Timer be reset?
    # Note: If set to false, then the title screen will skip to the map
    #       when the timer has been reached regardles of what the player 
    #       was doing
    InputCancel = true
    
    
    # This is the map the Title Screen will skip to. Use this map to display an 
    # cutscene or whatever you'd like. Be sure that when finished you use the
    # "Return to Title Screen" event.
    MapID = 1
    
    #-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= 
    #                                           \/
    #               End of Editable Region      /\
    #                                           \/
    #-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
  end
end




#==============================================================================
# ** Scene_Title
#------------------------------------------------------------------------------
#  This class performs the title screen processing.
#==============================================================================

class Scene_Title < Scene_Base
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # *= Alias Listings
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  alias_method(:dp3_itss_scntitle_start_qw90y,              :start)
  alias_method(:dp3_itss_scntitle_update_qw90y,             :update)
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * Aliased Method: Start Processing
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def start(*args)
    dp3_itss_scntitle_start_qw90y(*args)
    @dp3_titlescreenskipmanager = DiamondandPlatinum3::IdleTitleScreenCutscene::SceneTitleSkipManager.new()
  end
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * Aliased Method: Update
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def update(*args)
    dp3_itss_scntitle_update_qw90y(*args)
    @dp3_titlescreenskipmanager.update()
  end
end




#=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=
# **  New Class:   Scene Title Skip Manager
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# This class Manages the Skip Option for the Title Screen
#~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~
module DiamondandPlatinum3
  module IdleTitleScreenCutscene
    class SceneTitleSkipManager
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      # * Derived Method: Object Initialisation
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      def initialize()
        @skip_timer = DPCore::TimeTracker.new(SkipTimer)
      end
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      # * New Method: Update
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      def update
        if InputCancel && has_input?()
          @skip_timer.reset()
        else
          @skip_timer.update()
          if @skip_timer.time_up?()
            SceneManager.scene.fadeout_all()
            DataManager.create_game_objects()
            $game_map.setup(MapID)
            $game_player.moveto(0, 0)
            $game_map.autoplay()
            $game_map.screen.start_fadeout(1)
            SceneManager.goto(Scene_Map)
          end
        end
      end
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      # * New Method: Has Input?
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      def has_input?
        return [:LEFT, :UP, :RIGHT, :DOWN, :A, :B, :C, :X, :Y, :Z, :L, :R, 
                :SHIFT, :CTRL, :ALT, :F5, :F6, :F7, :F8, :F9 ].any? { |sym| Input.press?(sym) }
      end
    end
  end
end




unless ($diamondandplatinum3scripts ||= {})[:TimeTracker]
  
#=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=
# **  New Class:   Time Tracker
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Once initialised, this class keeps track of time in seconds.
# All instances of the TimeTracker class are updated automatically if you
# have chosen to allow themselves to be added to the list (true by default).
#
# Once initialised, simply call the ' time_up? ' method to see if the time
# is up for this TimeTracker.
# Call ' dispose ' once finished.
#~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~
($diamondandplatinum3scripts ||= {})[:TimeTracker] = true
#~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~
module DPCore
  class TimeTracker
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # *+ Public Instance Variables
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    attr_reader :current_frame  # Current Frame the Tracker is on: Use to Reset Tracker.
    attr_reader :seconds        # Seconds until TimeUp: Change to Increase/Decrease the Wait Time.
    attr_reader :scenetype      # Scenetype: If not nil, this TimeTracker will only Update if SceneManager is in that Specified Scene.
    
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # *- Private Static Variables
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @@timetracker_list = []     # Static Variable List/Array containing active instances of TimeTrackers

    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # * New Method:   Object Initialisation
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # Time:             How long (in seconds) until this TimeTracker has been successful
    # Scene Class:      Which Scene Can this TimeTracker be updated in : nil by default, which means it can always be updated no matter what scene it is.
    # Add Self To List: Add Self to the Automatic Update List? : false by default. If not true, you need to update the TimeTracker manually
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def initialize(time, scene_class = nil, add_self_to_list = false)
      @current_time   = 0.0
      @finish_time    = time.to_f
      @scenetype      = scene_class
      @time_up        = false
      
      @@timetracker_list.push(self) if add_self_to_list
    end
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # * New Method:   Dispose
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def dispose()
      @@timetracker_list.reject! { |tracker| tracker == self }
    end
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # * New Method:   Update
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def update()
      if !@time_up
        @current_time  += (1.0 / Graphics.frame_rate)
        @time_up        = (@current_time > @finish_time)
        @current_time   =  @finish_time if @time_up
      end
    end
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # * New Method:   Reset
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def reset()
      @current_time = 0.0
      @time_up      = false
    end
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # * New Method:   Set Current Time
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def set_current_time(time)
      @current_time = time
      @time_up      = (@current_time > @finish_time)
      @current_time =  @finish_time if @time_up
    end
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # * New Method:   Set Finish Time
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def set_finish_time(time)
      @finish_time  = time
      @time_up      = (@current_time > @finish_time)
      @current_time =  @finish_time if @time_up
    end
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # * New Method:   Get Current Time (in seconds)
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def get_current_time()
      return @current_time
    end
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # * New Method:   Is Time Up?
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def time_up?()
      return @time_up
    end
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # * New Method:   Get Total Completion Percentage
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def get_completion_percentage()
      return (@current_time / @finish_time)
    end
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # * New Method:   Get TimeTracker List
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def self.get_timetracker_list()
      return @@timetracker_list
    end
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # * New Method:   Update TimeTrackers
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def self.update_timetrackers()
      @@timetracker_list.each do |tracker|
        tracker.update() unless !tracker.scenetype.nil? && 
                                  !SceneManager.scene_is?(tracker.scenetype)
      end
    end
  end
end

end