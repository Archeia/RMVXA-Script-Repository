#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
#             Common Event: Menu Options
#             Author: DiamondandPlatinum3
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#  Description:
#
#    This script will allow you to put options in the menu that will run a
#    common event if selected, it also has the option of being disabled with
#    an event switch.
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
module DiamondandPlatinum3
  module Common_Event_Menu_Option
    #=======================================================
    #     Editable Region
    #=======================================================
   
    # Option Label    : The Custom Text that will appear for your menu option
    # Event Switch ID : Only if this Event Switch is Activated will the option be enabled,
    #                   You may keep the option always enabled by setting this to zero,
    # Common Event ID : The Common Event to Call when this option is selected
    
    CUSTOM_OPTIONS = 
    {
    
    # "Option Label"  => [ Event Switch ID, Common Event ID ],
    
      "World Map"     => [    10,                   2       ],
      "Party Chat"    => [    0,                   12       ],
      
    # You can add more options above this line be sure it looks the same as the others
    }
 
  #=======================================================
  end # of Editable region
  #=======================================================
end
 
 
 
#==============================================================================
# ** Window_MenuCommand
#------------------------------------------------------------------------------
#  This command window appears on the menu screen.
#==============================================================================
 
class Window_MenuCommand < Window_Command
  #--------------------------------------------------------------------------
  # * Aliased Method: For Adding Original Commands
  #--------------------------------------------------------------------------
  alias dp3_windowmenucommand_addoriginalcommands_134hfn      add_original_commands
  #--------------------------------------------------------------------------
  def add_original_commands
    # Call Original Method
    dp3_windowmenucommand_addoriginalcommands_134hfn()
   
    DiamondandPlatinum3::Common_Event_Menu_Option::CUSTOM_OPTIONS.each_key do |label|
      switch_id = DiamondandPlatinum3::Common_Event_Menu_Option::CUSTOM_OPTIONS[label][0]
      enabled   = (switch_id > 0) ? $game_switches[switch_id] : true
      add_command(label, label.to_sym, enabled)
    end
  end
end
 
 
 
 
#==============================================================================
# ** Scene_Menu
#------------------------------------------------------------------------------
#  This class performs the menu screen processing.
#==============================================================================
 
class Scene_Menu < Scene_MenuBase
  #--------------------------------------------------------------------------
  # * Create Command Window
  #--------------------------------------------------------------------------
  alias dp3_scenemenu_createcommandwindow_134hfn      create_command_window
  #--------------------------------------------------------------------------
  def create_command_window
    # Run Original Method
    dp3_scenemenu_createcommandwindow_134hfn()
    
    DiamondandPlatinum3::Common_Event_Menu_Option::CUSTOM_OPTIONS.each_key do |label|
      @command_window.set_handler(label.to_sym, method(:dp3_common_event_menu_option))
    end
  end
  #--------------------------------------------------------------------------
  # * New Method: Common Event Menu Option
  #--------------------------------------------------------------------------
  def dp3_common_event_menu_option
    key = @command_window.current_symbol.to_s
    $game_temp.reserve_common_event( DiamondandPlatinum3::Common_Event_Menu_Option::CUSTOM_OPTIONS[key][1] )
    SceneManager.call(Scene_Map)
  end
end