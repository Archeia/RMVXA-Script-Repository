#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
#             Determine if "in battle"
#             Author: DiamondandPlatinum3
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#  Description:
#
#    This script will allow you to set an event switch that will turn on if
#    you are in battle, and turn off if you are not.
#    It's useful for changing what an item does if battling compared to if
#    not battling.
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~



class Scene_Battle < Scene_Base
  #------------------------
  # Editable Part
  #------------------------
 
  # Event Switch to turn on if in battle
  ITEM_EVENT_SWITCH_ID = 10
 
  #------------------------
 
  #--------------------------------------------------------------------------
  # * Start processing
  #--------------------------------------------------------------------------
  alias evntswitchbtlstart_1g5s start
  def start
    evntswitchbtlstart_1g5s
    $game_switches[ITEM_EVENT_SWITCH_ID] = true
  end
  #--------------------------------------------------------------------------
  # * Termination Processing
  #--------------------------------------------------------------------------
  alias evntswitchbtlterminate_1g5s terminate
  def terminate
    evntswitchbtlterminate_1g5s
    $game_switches[ITEM_EVENT_SWITCH_ID] = false
  end
end