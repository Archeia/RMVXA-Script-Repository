#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
#             Enemy Voices in Battle
#             Version: 1.0
#             Author: DiamondandPlatinum3
#             Date: October 2, 2012
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#  Description:
#
#    This script grants you the ability to have your enemies talk throughout
#    battle.
#
#    Enemies will say things when attacking/using skills/getting damaged/etc
#
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#------------------------------------------------------------------------------
#  Instructions:
#  
#   ~ This script was built off the Actor Voices in Battle Script.
#     As such, most of the setup process of this script is similar.
#       There is a Video Tutorial explaining the Actor Voices in Battle Script. 
#       You may watch it here:      http://www.youtube.com/watch?v=CaQhoZg_FgI
#       Script Available Here:      http://diamondandplatinum3.net/rpg-maker-scripts/rgss3-vxa/battle-scripts/actor-voices-in-battle/
#
#
#   ~ In the Editable Region Below, you must set a folder to which will contain
#     all of your new voices. 
#     In addition, inside of THAT folder, you must also create a new folder for 
#     each enemy and name the folder by that enemy name.
#     Example: Slime, Jellyfish, Angel
#
#
#   ~ You can set up most of this script in the editable region below; you can
#     set up battle voices for specific skills manually however.
#     You do this by inserting the following code into the notetag of the
#     Skill/Item:
#
#       ~EnemyVoice: ID, "Voice_Filename"
#
#               or
#
#       ~EnemyVoice: ID, "Voice_Filename", Volume, Pitch, Wait Frames
#
#
#     Replace the ID with the id of the enemy that you are using this tag with.
#     Replace the "Voice_Filename" with the filename of the SE you will be playing
#
#     You do not need to insert Volume, Pitch or Wait Frames afterwards, but you
#     can if you wish to specify them.
#     You may use this same tag on a skill twice to allow for more than one voice
#     per skill or for different enemies.
#
#
#   ~ A Screenshot example of the above may be found here:
#             http://i.imgur.com/MhKFood.png    <= Notetag Example
#             http://i.imgur.com/eooTs6y.png    <= Actor Voices and Enemy Voices (only if Actor Voices in Battle is imported)
#
#             http://i.imgur.com/Oqc9BGA.png    <= Voices Folder
#             http://i.imgur.com/cq1JPBc.png    <= Individual Folders
#
#
#
#   ~ In the editable region section your enemies can have more than one thing to
#     say. It the same pattern of: "filename", volume, pitch, frames_to_wait, repeat;
#     until you finish it, I trust your common sense to figure out how :)
#
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#------------------------------------------------------------------------------
#  Engine Modifications:
#
#   ~ class Scene_Battle:
#       apply_item_effects        (aliased)
#
#
#   ~ class Game_Enemy:
#       use_item                  (aliased)
#       die                       (aliased)
#       change_exp                (aliased)
#       execute_damage            (aliased)
#       on_damage                 (aliased)
#
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
($diamondandplatinum3_scripts ||= {})[:EnemyBattleVoices] = true
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
module DiamondandPlatinum3
module EnemyBattleVoices
  #=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  #                                                        -=
  #                 Editable Region        ////            ==
  #                                                        =-
  #-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
 
  # You must create a new folder inside of your SE Audio folder and name it
  # Whatever you decided to call it just below
  FOLDER_DIRECTORY_NAME = "Battle_Voices" 
 
 
 
  # This Event Switch when turned on will mute the voices from being played.
  # They will still play, you just won't hear them
  #
  # If you leave the event switch id as zero, that means you can NEVER turn off the
  # Enemy Battle Voices
  EVENT_SWITCH_ID = 0
 
 
  # If the enemy has been inflicted with any of these states, they will have their
  # voices muted until it is cured.
  # State No.4 by default is the Silence state, which is a reasonable state for muting
  # someone. you can add more states after it by adding another ID number and a comma
  #
  # If you do not want any state to mute you, simply erase everything inside the square brackets
  SILENCE_STATES = [ 4, ]
  
  
  # Here you can choose the Skills which your Enemy Voices will not play for.
  # By default, Skills 1-7 are skills which are used with certain commands.
  # Some of those commands have their own specific Enemy Voice, such as Attacking.
  # As such it is advisable to input the Skill ID referring to those
  # commands in this option.
  # If you are using the Default Skillset, you can leave this option as is.
  # However if you're using custom skills, please make sure they're not being
  # omitted inside of this option.
  #
  # You may also use this option to stop custom skills from having voices if you'd
  # prefer.
  SKILLS_NOT_TO_PLAY_VOICE_FOR = [ 1, 2, 3, 4, 5, 6, 7, ]
 
 
  # If you've been playing and noticed that battle voices tend to happen a bit too often
  # for your liking, you may use this Option to decrease the frequency in which they will
  # say general things (like attacking, using skills, etc). Non-general voices (such as
  # specific skills) will still play whenever they are used.
  #
  #
  # This works as a percentage out of 100.
  VOICE_FREQUENCY = 100
 

  # If an attack has multiple hits, do you want the actor in question to keep
  # screaming battle cries for each hit?
  PLAY_MULTIPLE_VOICES_FOR_MULTIPLE_HITS = true
  
  
  
  #=============================================================================
  #    Battle Voices
  #-----------------------------------------------------------------------------
  #   These voices are heard throughout the battle, such as when attacking,
  #   using a skill or taking damage, etc
  #=============================================================================
 
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * WHEN ENEMY IS ATTACKING
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  ENEMY_ATTACKING = { # <= Do Not Touch This Line
 
    # What Enemy One (Default: Slime) Will Say when Normal Attacking
    1 => [
           "Attack01", 80, 100, 0,
           "Attack02", 80, 100, 0,
         ],
 
     
    # What Enemy Two (Default: Bat) Will Say when Normal Attacking
    2 => [
           "Attack01", 80, 100, 0,
           "Attack02", 80, 100, 0,
           "Attack03", 80, 100, 0,
         ],
         
    
    # What Enemy Nine (Default: Jellyfish) Will Say when Normal Attacking
    9 => [
           "Attack01", 80, 100, 0,
         ],
         
         
    # What Enemy Twenty-Nine (Default: Demon King) Will Say when Normal Attacking
    29 =>[
           "Attack01", 80, 100, 0,
         ],
         
 
 
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * WHEN USING A SKILL
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  }; USING_SKILLS = { # <= Do Not Touch This Line
 
    # What Enemy Twenty-Nine (Default: Demon King) Will Say when using a generic skill
    29 =>[
           "Using Generic Skill01", 80, 100, 0,
         ],  
         
         
         
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * WHEN ENEMY MISSED THE ACTOR
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  }; MISSED_ACTOR_TARGET = { # <= Do Not Touch This Line
 
    # What Enemy Twenty-Nine (Default: Demon King) Will Say
    29 =>[
           "Missed Enemy01", 80, 100, 0,
         ],
 
 
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * WHEN ENEMY EVADED ACTOR'S ATTACK
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  }; DODGED_ACTOR_ATTACK = { # <= Do Not Touch This Line
 
    # What Enemy Twenty-Nine (Default: Demon King) Will Say
    29 =>[
           "Dodged Enemy Attack01", 80, 100, 0,
         ],
       
       
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * WHEN ENEMY TAKES LITTLE DAMAGE FROM ACTOR ATTACK
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  }; LITTLE_DAMAGE = { # <= Do Not Touch This Line
 
    # Percentage of Health that must be lost from an individual attack for these
    # to be played
    :ratio => 15 ,
 
    # What Enemy One (Default: Slime) Will Say When Hurt This Much
    1 => [
           "Little Damage1", 80, 100, 0,
         ],
 
     
    # What Enemy Two (Default: Bat) Will Say When Hurt This Much
    2 => [
           "Little Damage1", 80, 100, 0,
         ],

         
    # What Enemy Twenty-Nine (Default: Demon King) Will Say When Hurt This Much
    29 =>[
           "Little Damage1", 80, 100, 0,
         ],
         
         
         
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * WHEN ENEMY TAKES SIGNIFICANT DAMAGE FROM ACTOR ATTCK
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  }; SIGNIFICANT_DAMAGE = { # <= Do Not Touch This Line
 
    # Percentage of Health that must be lost from an individual attack for these
    # to be played
    :ratio => 35 ,
 
    # What Enemy One (Default: Slime) Will Say When Hurt This Much
    1 => [
           "Significant Damage1", 80, 100, 0,
         ],
 
     
    # What Enemy Two (Default: Bat) Will Say When Hurt This Much
    2 => [
           "Significant Damage1", 80, 100, 0,
         ],

         
    # What Enemy Twenty-Nine (Default: Demon King) Will Say When Hurt This Much
    29 =>[
           "Significant Damage1", 80, 100, 0,
         ],
         
     
         
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * WHEN ENEMY TAKES HEAVY DAMAGE FROM ACTOR ATTACK
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  }; HEAVY_DAMAGE = { # <= Do Not Touch This Line
 
    # Percentage of Health that must be lost from an individual attack for these
    # to be played
    :ratio => 50 ,
 
    # What Enemy One (Default: Slime) Will Say When Hurt This Much
    1 => [
           "Heavy Damage1", 80, 100, 0,
         ],
 
     
    # What Enemy Two (Default: Bat) Will Say When Hurt This Much
    2 => [
           "Heavy Damage1", 80, 100, 0,
         ],

         
    # What Enemy Twenty-Nine (Default: Demon King) Will Say When Hurt This Much
    29 =>[
           "Heavy Damage1", 80, 100, 0,
         ],
         
         
         
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * WHEN ENEMY TAKES MASSIVE DAMAGE FROM ACTOR ATTACK
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  }; MASSIVE_DAMAGE = { # <= Do Not Touch This Line
 
    # Percentage of Health that must be lost from an individual attack for these
    # to be played
    :ratio => 65 ,
 
 
    # What Enemy One (Default: Slime) Will Say When Hurt This Much
    1 => [
           "Massive Damage1", 80, 100, 0,
         ],
 
     
    # What Enemy Two (Default: Bat) Will Say When Hurt This Much
    2 => [
           "Massive Damage1", 80, 100, 0,
         ],

         
    # What Enemy Twenty-Nine (Default: Demon King) Will Say When Hurt This Much
    29 =>[
           "Massive Damage1", 80, 100, 0,
         ],
         
 
         
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * WHEN ENEMY TAKES DAMAGE, BUT NOTHING THEY CAN'T SHRUG OFF
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  }; DEFAULT_DAMAGE = { # <= Do Not Touch This Line
 
 
    # What Enemy One (Default: Slime) Will Say When Hurt This Much
    1 => [
           "Default Damage1", 80, 100, 0,
         ],
 
     
    # What Enemy Two (Default: Bat) Will Say When Hurt This Much
    2 => [
           "Default Damage1", 80, 100, 0,
         ],

         
    # What Enemy Twenty-Nine (Default: Demon King) Will Say When Hurt This Much
    29 =>[
           "Default Damage1", 80, 100, 0,
         ],
 
         
 
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * WHEN ENEMY HAS THEIR HP OR MP RESTORED, EITHER BY ITEMS OR MAGIC
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  }; HP_MP_RESTORE = { # <= Do Not Touch This Line
 
    # Allowed to speak if this enemy healed itself?
    :self_heal_speak  =>  true ,
    
    
    # What Enemy Twenty-Nine (Default: Demon King) Will Say When HP/MP is Restored
    29 =>[
           "HP_MP Restored1", 80, 100, 0,
         ],
 
 
         
         
         
  #=============================================================================
  #    Death & Revive Voices
  #-----------------------------------------------------------------------------
  #   These voices are heard when an enemy is defeated in battle
  #=============================================================================
 
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * WHEN ACTOR HAS JUST BEEN KO'D IN BATTLE
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # Voices to play when an actor dies
  }; DEATH_VOICE = { # <= Do Not Touch This Line
 
 
    # What Enemy One (Default: Slime) Will Say When They Die
    1 => [
           "Death Cry1", 80, 100, 0,
         ],
 
     
    # What Enemy Two (Default: Bat) Will Say When They Die
    2 => [
           "Death Cry1", 80, 100, 0,
         ],

         
    # What Enemy Twenty-Nine (Default: Demon King) Will Say When They Die
    29 =>[
           "Death Cry1", 80, 100, 0,
         ],
                                                 
         
         
         
          
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
#                                                        -=
};    # End Of Editable Region           ////            ==
#                                                        =-
#-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
 
 
 
 
 
 
  CURRENT_VERSION = 1.0
  ACTOR_VOICES_IMPORTED = !$diamondandplatinum3_scripts[:BattleVoices].nil?
  #------------------------------------------------------------------------
  # * New Method: Check Version Compatibility
  #------------------------------------------------------------------------
  def self.check_version_compatibility( version )
    return :outdated_version if version > CURRENT_VERSION
    return :outdated_patch   if version < CURRENT_VERSION
    return :compatible
  end
  #------------------------------------------------------------------------
  # * New Method: Play Voice
  #------------------------------------------------------------------------
  def self.play_voice( voice_hash, enemy_troopmember_index )
    return true if !allowed_to_speak?(enemy_troopmember_index)
    
    # Get Voice Array
    if voice_hash.is_a?(Hash)
      voice_array = voice_hash[$game_troop.members[enemy_troopmember_index].enemy_id]
    elsif voice_hash.is_a?(Array)
      voice_array = voice_hash
    end
    
    # If voice_array is not empty
    unless voice_array.nil? || voice_array.empty?
      index = rand(voice_array.size / 4) * 4
      if voice_array[index].is_a?(String) && voice_array[index + 1].is_a?(Integer) && voice_array[index + 2].is_a?(Integer)
       
        # Get the Enemy Folder Name
        folder_name = $game_troop.members[enemy_troopmember_index].enemy.name
       
        # Get Path to File
        pathtofile = "/" + FOLDER_DIRECTORY_NAME + "/" + folder_name + "/" + voice_array[index]
       
        # Play Voice
        RPG::SE.new(pathtofile, voice_array[index + 1], voice_array[index + 2]).play
       
        # Wait if necessary
        SceneManager.scene.wait(voice_array[index + 3]) unless !voice_array[index + 3].is_a?(Integer) || !SceneManager.scene_is?(Scene_Battle)
        return true
      end
    end
    # We return true and false to determine whether a voice play was successful or not
    return false
  end
  #------------------------------------------------------------------------
  # * New Method: Allowed to Speak?
  #------------------------------------------------------------------------
  def self.allowed_to_speak?(enemy_troopmember_index)
    return false if check_if_enemy_muted(enemy_troopmember_index)
    return rand(100) < VOICE_FREQUENCY
  end
  #------------------------------------------------------------------------
  # * New Method: Check For Muted Enemy
  #------------------------------------------------------------------------
  def self.check_if_enemy_muted(enemy_troopmember_index)
    return true if $game_switches[EVENT_SWITCH_ID]
    return $game_troop.members[enemy_troopmember_index].states.any? { |state| SILENCE_STATES.include?(state.id) }
  end
  #------------------------------------------------------------------------
  # * New Method: Play "I Missed Enemy" Voice
  #------------------------------------------------------------------------
  def self.play_missed_enemies_voice(enemy_troopmember_index)
    return play_voice(MISSED_ACTOR_TARGET, enemy_troopmember_index)
  end
  #------------------------------------------------------------------------
  # * New Method: Play "I Evaded Enemy" Voice
  #------------------------------------------------------------------------
  def self.play_evaded_enemy_voice(enemy_troopmember_index)
    return play_voice(DODGED_ACTOR_ATTACK, enemy_troopmember_index)
  end
  #------------------------------------------------------------------------
  # * New Method: Play "Normal Attack" Voice
  #------------------------------------------------------------------------
  def self.play_normal_attack_voice(enemy_troopmember_index)
    return play_voice(ENEMY_ATTACKING, enemy_troopmember_index)
  end
  #------------------------------------------------------------------------
  # * New Method: Play "Using Skill" Voice
  #------------------------------------------------------------------------
  def self.play_skill_voice(enemy_troopmember_index, skill_id)
    voice = []
    enemy_id = $game_troop.members[enemy_troopmember_index].enemy_id
    $data_skills[skill_id].note.scan(/~EnemyVoice:\s*#{enemy_id.to_s}\,*\s*\"(.+?)\"\,*\s*(\d*)\,*\s*(\d*)\,*\s*(\d*)/im).collect{ |voice_info|
      unless voice_info.empty?
        voice.push(voice_info[0])
        voice.push(voice_info[1] != "" ? voice_info[1].to_i : 80)
        voice.push(voice_info[2] != "" ? voice_info[2].to_i : 100)
        voice.push(voice_info[3] != "" ? voice_info[3].to_i : 0)
      end
    }
   
    # Modify Skill Voice to Generic Skill Voice if there is no specific voice for this Skill
    if voice.empty?
      return true if SKILLS_NOT_TO_PLAY_VOICE_FOR.include?(skill_id)
      voice = USING_SKILLS
    end
    
    return play_voice( voice, enemy_troopmember_index )
  end
  #------------------------------------------------------------------------
  # * New Method: Play "Death" Voice
  #------------------------------------------------------------------------
  def self.play_death_voice(enemy_troopmember_index)
    return play_voice(DEATH_VOICE, enemy_troopmember_index)
  end
  #------------------------------------------------------------------------
  # * New Method: Play "Restored HP/MP" Voice
  #------------------------------------------------------------------------
  def self.play_healed_voice(enemy_troopmember_index)
    return play_voice(HP_MP_RESTORE, enemy_troopmember_index)
  end
  #------------------------------------------------------------------------
  # * New Method: Play "Default Damage" Voice
  #------------------------------------------------------------------------
  def self.play_default_damage_voice(enemy_troopmember_index)
    return play_voice(DEFAULT_DAMAGE, enemy_troopmember_index)
  end
  #------------------------------------------------------------------------
  # * New Method: Play "Little Damage" Voice
  #------------------------------------------------------------------------
  def self.play_little_damage_voice(enemy_troopmember_index)
    return play_voice(LITTLE_DAMAGE, enemy_troopmember_index)
  end
  #------------------------------------------------------------------------
  # * New Method: Play "Significant Damage" Voice
  #------------------------------------------------------------------------
  def self.play_significant_damage_voice(enemy_troopmember_index)
    return play_voice(SIGNIFICANT_DAMAGE, enemy_troopmember_index)
  end
  #------------------------------------------------------------------------
  # * New Method: Play "Heavy Damage" Voice
  #------------------------------------------------------------------------
  def self.play_heavy_damage_voice(enemy_troopmember_index)
    return play_voice(HEAVY_DAMAGE, enemy_troopmember_index)
  end
  #------------------------------------------------------------------------
  # * New Method: Play "Massive Damage" Voice
  #------------------------------------------------------------------------
  def self.play_massive_damage_voice(enemy_troopmember_index)
    return play_voice(MASSIVE_DAMAGE, enemy_troopmember_index)
  end
  
 
end # BattleVoices Module
end # DiamondandPlatinum3 Module
 
 
 
 
#==============================================================================
# ** Scene_Battle
#------------------------------------------------------------------------------
#  This class performs battle screen processing.
#==============================================================================
 
class Scene_Battle < Scene_Base
  #--------------------------------------------------------------------------
  # * Alias Listings
  #--------------------------------------------------------------------------
  alias dp3_ebv_scenebattle_applyitemeffects_1s098yu9j    apply_item_effects

  #--------------------------------------------------------------------------
  # * Aliased Method: Apply Skill/Item Effect
  #--------------------------------------------------------------------------
  def apply_item_effects(*args)
    # Call Original Method
    dp3_ebv_scenebattle_applyitemeffects_1s098yu9j(*args)
   
    # If Result was a Miss, and an enemy was not targeting an enemy
    if !args[0].result.hit?
      if !args[0].enemy? && @subject.enemy?
        DiamondandPlatinum3::EnemyBattleVoices::play_missed_enemies_voice(@subject.index)
      elsif args[0].enemy? && !@subject.enemy?
        DiamondandPlatinum3::EnemyBattleVoices::play_evaded_enemy_voice(args[0].index)
      end
    end
  end
end # Class

 
 
#==============================================================================
# ** Game_Enemy
#------------------------------------------------------------------------------
#  This class handles enemies. It used within the Game_Troop class 
# ($game_troop).
#==============================================================================

class Game_Enemy < Game_Battler
  #--------------------------------------------------------------------------
  # * Alias Listings
  #--------------------------------------------------------------------------
  alias dp3_gameenemy_die_1s098yu9j                     die
  alias dp3_gameenemy_useitem_1s098yu9j                 use_item
  alias dp3_gameenemy_executedamage_1s098yu9j           execute_damage
  alias dp3_gameenemy_ondamage_1s098yu9j                on_damage
 
  #--------------------------------------------------------------------------
  # * Aliased Method: Use Skill/Item
  #--------------------------------------------------------------------------
  def use_item(*args)
    if args[0].is_a?(RPG::Skill)
      if args[0].id == attack_skill_id
        DiamondandPlatinum3::EnemyBattleVoices::play_normal_attack_voice(@index)
      else
        DiamondandPlatinum3::EnemyBattleVoices::play_skill_voice(@index, args[0].id)
      end
    end
    
    # Call Original Method
    dp3_gameenemy_useitem_1s098yu9j(*args)
  end
  
  #--------------------------------------------------------------------------
  # * Aliased Method: Knock Out
  #--------------------------------------------------------------------------
  def die( *args )
    DiamondandPlatinum3::EnemyBattleVoices::play_death_voice(@index)
   
    # Call Original Method
    dp3_gameenemy_die_1s098yu9j( *args )
  end 
  
  #--------------------------------------------------------------------------
  # * Aliased Method: Execute Damage
  #--------------------------------------------------------------------------
  def execute_damage(*args)
    current_hp = self.hp
    current_mp = self.mp
    dp3_gameenemy_executedamage_1s098yu9j(*args)
   
    
    # Play Healed Voice if Healed and Allowed
    if current_hp < self.hp || current_mp < self.mp
      if args[0].enemy?
        if args[0] == self
          if DiamondandPlatinum3::EnemyBattleVoices::HP_MP_RESTORE[:self_heal_speak]
            DiamondandPlatinum3::EnemyBattleVoices::play_healed_voice(@index)
          end
        else
          DiamondandPlatinum3::EnemyBattleVoices::play_healed_voice(@index)
        end
      end
    end
  end
 
  #--------------------------------------------------------------------------
  # * Aliased Method: Processing When Suffering Damage
  #--------------------------------------------------------------------------
  def on_damage(*args)
    dp3_play_appropriate_enemy_damage_voice( args[0] ) if args[0] > 0 && (self.hp - args[0]) > 0
   
    # Call Original Method
    dp3_gameenemy_ondamage_1s098yu9j( *args )
  end
 
  #--------------------------------------------------------------------------
  # * New Method: Get Enemy Damage Voice Array
  #--------------------------------------------------------------------------
  def dp3_play_appropriate_enemy_damage_voice( value )
    #~~~~~ Play Massive Damage Voice ~~~~~#
    if value > self.mhp * (DiamondandPlatinum3::EnemyBattleVoices::MASSIVE_DAMAGE[:ratio] * 0.01)
      DiamondandPlatinum3::EnemyBattleVoices::play_massive_damage_voice(@index)
    #~~~~~ Play Heavy Damage Voice ~~~~~#
    elsif value > self.mhp * (DiamondandPlatinum3::EnemyBattleVoices::HEAVY_DAMAGE[:ratio] * 0.01)
      DiamondandPlatinum3::EnemyBattleVoices::play_heavy_damage_voice(@index)
    #~~~~~ Play Significant Damage Voice ~~~~~#
    elsif value > self.mhp * (DiamondandPlatinum3::EnemyBattleVoices::SIGNIFICANT_DAMAGE[:ratio] * 0.01)
      DiamondandPlatinum3::EnemyBattleVoices::play_significant_damage_voice(@index)
    #~~~~~ Play Little Damage Voice ~~~~~#
    elsif value > self.mhp * (DiamondandPlatinum3::EnemyBattleVoices::LITTLE_DAMAGE[:ratio] * 0.01)
      DiamondandPlatinum3::EnemyBattleVoices::play_little_damage_voice(@index)
    #~~~~~ Play Pitance Damage Voice ~~~~~#
    else
      DiamondandPlatinum3::EnemyBattleVoices::play_default_damage_voice(@index)
    end
  end
end