#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
#             Actor Voices in Battle
#             Version: 2.6
#             Author: DiamondandPlatinum3
#             Date: December 11, 2012     (Original)
#                   October 1, 2013    (Most Recent Update)
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#  Description:
#
#    This script grants you the ability to have your actors talk throughout
#    battle; it will pick an actor at random at the start of battle to say
#    something relevant about what they expect from this battle.
#    
#    After that, the actors will get voices when attacking and when getting
#    damaged, also when using a skill.
#
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#------------------------------------------------------------------------------
#  Instructions:
#  
#   ~ There is a Video Tutorial explaining a lot of this script. You may watch
#     it here:      http://www.youtube.com/watch?v=CaQhoZg_FgI
#
#
#   ~ In the Editable Region Below, you must set a folder to which will contain
#     all of your new voices. 
#     In addition, inside of THAT folder, you must also create a new folder for 
#     each enemy and name the folder by that enemy name.
#     Example: Eric, Terence, Natalie
#
#
#   ~ You can set up most of this script in the editable region below; you can
#     set up battle voices for specific skills & items manually however.
#     You do this by inserting the following code into the notetag of the
#     Skill/Item:
#
#       ~ActorVoice: ID, "Voice_Filename"
#
#               or
#
#       ~ActorVoice: ID, "Voice_Filename", Volume, Pitch, Wait Frames
#
#
#     Replace the ID with the id of the actor who you are using this tag with.
#     Replace the "Voice_Filename" with the filename of the SE you will be playing
#
#     You do not need to insert Volume, Pitch or Wait Frames afterwards, but you
#     can if you wish to specify them.
#     You may use this same tag on a skill twice to allow for more than one voice
#     per skill or for different actors.
#
#
#
#   ~ In case your game allows for actors to be given custom names by the player,
#      you may additionally set up a hardcoded name for them, so as to keep 
#      voices in one folder where they can be accessed.
#         To do so, you only simply need to use the following in a script call:
#
#             set_actor_voice_name(id, name)
# 
#         Where (ID = Actor_ID) and (name = "Folder Name")
#
#      From now on, the script will check this folder for this specific actor's
#      voices rather than elsewhere.
#       Also note that this can be changed at anytime, so if for whatever reason
#       your Actor changes gender throughout your game, you can always change 
#       the folder to a more feminine sounding actor.
#
#
#
#   ~ A Screenshot example of the above may be found here:
#       http://goo.gl/HO7n0   ~ Showing the usage of the notetag for skills
#       http://goo.gl/zH0aO   ~ Setting up Multiple Voices
#       http://goo.gl/EP0Nf   ~ Showing the usage of the notetag for items
#
#       http://i.imgur.com/Oqc9BGA.png  ~ Voices Folder
#       http://i.imgur.com/cq1JPBc.png  ~ Individual Folders
#
#
#
#   ~ In the editable region section your actors can have more than one thing to
#     say. It's the same pattern of: "filename", volume, pitch, frames_to_wait, repeat;
#     until you finish it, I trust your common sense to figure out how :)
#
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#------------------------------------------------------------------------------
#  Engine Modifications:
#
#   ~ class Scene_Battle:
#       post_start                (aliased)
#       apply_item_effects        (aliased)
#       show_normal_animation     (overwritten)
#
#
#   ~ class Game_Actor:
#       use_item                  (aliased)
#       die                       (aliased)
#       change_exp                (aliased)
#       item_effect_recover_hp    (aliased)
#       item_effect_recover_mp    (aliased)
#       execute_damage            (aliased)
#       remove_state              (aliased)
#       on_damage                 (aliased)
#
#
#   ~ module BattleManager
#       setup                     (aliased)
#       process_escape            (aliased)
#       process_victory           (aliased)
#       process_defeat            (aliased)
#
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
($diamondandplatinum3_scripts ||= {})[:BattleVoices] = true
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
module DiamondandPlatinum3
module BattleVoices
  #=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  #                                                        -=
  #                 Editable Region        ////            ==
  #                                                        =-
  #-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
 
  # You must create a new folder inside of your SE Audio folder and name it
  # Whatever you decided to call it just below
  FOLDER_DIRECTORY_NAME = "Battle_Voices" 
 
 
  # This Event Switch when turned on will mute the voice being played.
  # They will still play, you just won't hear them
  #
  # If you leave the event switch id as zero, that means you can NEVER turn off the
  # Battle Voices
  EVENT_SWITCH_ID = 0
 
 
  # If your actor has been inflicted with any of these states, they will have their
  # voices muted until it is cured.
  # State No.4 by default is the Silence state, which is a reasonable for muting
  # you. you can add more states after it by adding another ID number and a comma
  #
  # If you do not want any state to mute you, simply erase everything inside the square brackets
  SILENCE_STATES = [ 4, ]
 
 
  # Here you can choose the Skills which your Actor Voices will not play for.
  # By default, Skills 1-7 are skills which are used with certain commands.
  # Some of those commands have their own specific Actor Voice, such as Attacking
  # or Escaping, as such it is advisable to input the Skill ID referring to those
  # commands in this option.
  # If you are using the Default Skillset, you can leave this option as is.
  # However if you're using custom skills, please make sure they're not being
  # omitted inside of this option.
  #
  # You may also use this option to stop custom skills from having voices if you'd
  # prefer.
  SKILLS_NOT_TO_PLAY_VOICE_FOR = [ 1, 2, 3, 4, 5, 6, 7, ]
 
 
  # If you've been playing and noticed that battle voices tend to happen a bit too often
  # for your liking, you may use this Option to decrease the frequency in which they will
  # say general things (like attacking, using items, etc). Non-general voices (such as
  # specific skills) will still play whenever they are used.
  #
  # This works as a percentage out of 100.
  VOICE_FREQUENCY = 100
 
 
  # If an attack has multiple hits, do you want the actor in question to keep
  # screaming battle cries for each hit?
  PLAY_MULTIPLE_VOICES_FOR_MULTIPLE_HITS = true
 
 
  #=============================================================================
  #    Battle Start Voices
  #-----------------------------------------------------------------------------
  #   The Editable Parts Below will only be said when a battle starts
  #=============================================================================
 
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * TOO MANY ENEMIES?
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  TOO_MANY_ENEMIES = {  # <= Do Not Touch This Line
 
    # If The enemy troop in battle has this many MORE members than you do,
    # an actor will say something about how you are outnumbered
    :ratio => 2 ,
 
   
    # "SE Filename", Volume, Pitch, Frames_to_Wait,
    #       Repeat if you want more voices
   
    # What Actor One Will Say
    1 => [
           "Encounter Too Many Enemies1", 80, 100, 0,
           "Encounter Too Many Enemies2", 80, 100, 0,
         ],
 
 
    # What Actor Two Will Say
    2 => [
           "Encounter Too Many Enemies1", 80, 100, 0,
           "Encounter Too Many Enemies2", 80, 100, 0,
         ],
   
   
         
    # You Add more voices for actors by doing the same as the above and modifying
    # the number to match the actor id (ie. Terence by default is Actor 3).
    # If you skip an actor, then no voice will be played for them.
 
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * PARTY NEEDS HEALING?
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  }; PARTY_NEEDS_HEALING = { # <= Do Not Touch This Line
 
    # If party total HP is below this Ratio, an Actor will say something about it
    # This Ratio is a percentage, so by default if your total party hp is below
    # 40%, then an actor may mention that everyone is hurt
    :ratio => 40 ,
 
   
    # What Actor Two Will Say
    2 => [
           "Encounter Party Needs Healing1", 80, 100, 0,
         ],
       
       
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * VERY WEAK ENEMIES?
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                    
  }; VERY_WEAK_ENEMIES = { # <= Do Not Touch This Line
 
    # Your stats are always 100%, so if the enemy troop stats are below
    # the editable ratio below; that means they are considered VERY WEAK.
    # By default this is 40%.
    :ratio => 40 ,
 
   
    # What Actor One Will Say
    1 => [
           "Encounter Very Weak Enemies1", 80, 100, 0,
         ],    
 
 
    # What Actor Two Will Say
    2 => [
           "Encounter Very Weak Enemies1", 80, 100, 0,
         ],
 
         
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * WEAK ENEMIES?
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  }; WEAK_ENEMIES = { # <= Do Not Touch This Line
 
    # Same as Very Weak Enemies, but should be higher
    :ratio => 80 ,
 
   
    # What Actor One Will Say
    1 => [
           "Encounter Weak Enemies1", 80, 100, 0,
         ],
 
 
    # What Actor Two Will Say
    2 => [
           "Encounter Weak Enemies1", 80, 100, 0,
           "Encounter Weak Enemies2", 80, 100, 0,
         ],
         
         
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * EQUAL ENEMIES?
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  }; EQUAL_ENEMIES = { # <= Do Not Touch This Line
 
  # There is no Ratio for Equal Enemies
 
  # What Actor One Will Say
  1 => [
         "Encounter Equal Enemies1", 80, 100, 0,
         "Encounter Equal Enemies2", 80, 100, 0,
         "Encounter Equal Enemies3", 80, 100, 0,
       ],
   
 
  # What Actor Two Will Say
  2 => [
         "Encounter Equal Enemies1", 80, 100, 0,
         "Encounter Equal Enemies2", 80, 100, 0,
       ],
       
       
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * STRONG ENEMIES?
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  }; STRONG_ENEMIES = { # <= Do Not Touch This Line
 
    # If your stats are 100% and the enemy is 120%, they are 20% stronger than you
    :ratio => 120 ,
   
 
    # What Actor One Will Say
    1 => [
           "Encounter Strong Enemies1", 80, 100, 0,
           "Encounter Strong Enemies2", 80, 100, 0,
         ],  
     
         
    # What Actor Two Will Say
    2 => [
           "Encounter Strong Enemies1", 80, 100, 0,
           "Encounter Strong Enemies2", 80, 100, 0,
         ],
 
         
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * VERY STRONG ENEMIES?
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  }; VERY_STRONG_ENEMIES = { # <= Do Not Touch This Line
 
    # Same as Strong Enemies, but should be higher
    :ratio => 160 ,
 
 
    # What Actor One Will Say
    1 => [
           "Encounter Very Strong Enemies1", 80, 100, 0,
           "Encounter Very Strong Enemies2", 80, 100, 0,
         ],
 
     
    # What Actor Two Will Say
    2 => [
           "Encounter Very Strong Enemies1", 80, 100, 0,
           "Encounter Very Strong Enemies2", 80, 100, 0,
         ],
         
         
         
         
 
 
  #=============================================================================
  #    Battle Skills/Items Voices
  #-----------------------------------------------------------------------------
  #   These are generic things that your actors will say when using an skill/item
  #   in battle. You can use note tags on specific skills/items, this is
  #   just for the more generic skill/items (meaning your actor will always say something).
  #=============================================================================
 
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * WHEN USING AN ITEM
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  }; USING_ITEMS = { # <= Do Not Touch This Line
 
    # What Actor One Will Say when using an generic item
    1 => [
           "Using Item1", 80, 100, 10,      # Waits 10 frames before applying item effects
         ],  
 
 
    # What Actor Two Will Say when using an generic item
    2 => [
           "Using Item1", 80, 100, 10,
         ],
         
         
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * WHEN USING A SKILL
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  }; USING_SKILLS = { # <= Do Not Touch This Line
 
    # What Actor One Will Say when using a generic skill
    1 => [
           #"Using Generic Skill01", 80, 100, 0,
         ],  
 
 
    # What Actor Two Will Say when using a generic skill
    2 => [
           #"Using Generic Skill01", 80, 100, 0,
         ],
 
       
       
 
 
 
  #=============================================================================
  #    Battle Voices
  #-----------------------------------------------------------------------------
  #   These voices are heard throughout the battle, such as when attacking,
  #   using a skill or taking damage, etc
  #=============================================================================
 
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * WHEN ACTOR IS ATTACKING
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  }; ACTOR_ATTACKING = { # <= Do Not Touch This Line
 
    # What Actor One Will Say when Normal Attacking
    1 => [
           "Attack01", 80, 100, 0,
           "Attack02", 80, 100, 0,
           "Attack03", 80, 100, 0,
           "Attack04", 80, 100, 0,
           "Attack05", 80, 100, 0,
           "Attack06", 80, 100, 0,
           "Attack07", 80, 100, 0,
           "Attack08", 80, 100, 0,
           "Attack09", 80, 100, 0,
           "Attack10", 80, 100, 0,
         ],
 
     
    # What Actor Two Will Say when Normal Attacking
    2 => [
           "Attack01", 80, 100, 0,
           "Attack02", 80, 100, 0,
           "Attack03", 80, 100, 0,
         ],
         
         
    12 =>[
           "attack", 80, 100, 0,
         ],
         
 
 
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * WHEN ACTOR MISSED THE ENEMY
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  }; MISSED_ENEMY = { # <= Do Not Touch This Line
 
    # What Actor One Will Say when they missed the enemy
    1 => [
           #"Missed Enemy01", 80, 100, 0,
         ],
 
 
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * WHEN ACTOR EVADED ENEMY ATTACK
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  }; DODGED_ENEMY = { # <= Do Not Touch This Line
 
    # What Actor One Will Say when they evaded an enemy attack
    1 => [
           #"Dodged Enemy Attack01", 80, 100, 0,
         ],
       
       
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * WHEN ACTOR TAKES LITTLE DAMAGE
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  }; LITTLE_DAMAGE = { # <= Do Not Touch This Line
 
    # Percentage of Health that must be lost from an individual attack for these
    # to be played
    :ratio => 15 ,
 
   
    # What Actor One Will Say when Hurt this much
    1 => [
           "Little Damage1", 80, 100, 10,
           "Little Damage2", 80, 100, 10,
           "Little Damage3", 80, 100, 10,
         ],
     
     
    # What Actor Two Will Say when Hurt this much
    2 => [
           "Little Damage1", 80, 100, 10,
           "Little Damage2", 80, 100, 10,
         ],
         
         
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * WHEN ACTOR TAKES SIGNIFICANT DAMAGE
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  }; SIGNIFICANT_DAMAGE = { # <= Do Not Touch This Line
 
    # Percentage of Health that must be lost from an individual attack for these
    # to be played
    :ratio => 35 ,
 
    # What Actor One Will Say when Hurt this much
    1 => [
           "Significant Damage1", 80, 100, 10,
           "Significant Damage2", 80, 100, 10,
           "Significant Damage3", 80, 100, 10,
         ],  
     
 
    # What Actor Two Will Say when Hurt this much
    2 => [
           "Significant Damage1", 80, 100, 10,
         ],
         
     
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * WHEN ACTOR TAKES HEAVY DAMAGE
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  }; HEAVY_DAMAGE = { # <= Do Not Touch This Line
 
    # Percentage of Health that must be lost from an individual attack for these
    # to be played
    :ratio => 50 ,
 
    # What Actor One Will Say when Hurt this much
    1 => [
           "Heavy Damage1", 80, 100, 10,
           "Heavy Damage2", 80, 100, 10,
           "Heavy Damage3", 80, 100, 10,
         ],
     
 
    # What Actor Two Will Say when Hurt this much
    2 => [
           "Heavy Damage1", 80, 100, 10,
           "Heavy Damage2", 80, 100, 10,
         ],
         
         
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * WHEN ACTOR TAKES MASSIVE DAMAGE
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  }; MASSIVE_DAMAGE = { # <= Do Not Touch This Line
 
    # Percentage of Health that must be lost from an individual attack for these
    # to be played
    :ratio => 65 ,
 
 
    # What Actor One Will Say when Hurt this much
    1 => [
           "Massive Damage1", 80, 100, 10,
         ],  
 
 
    # What Actor Two Will Say when Hurt this much
    2 => [
           "Massive Damage1", 80, 100, 10,
         ],  
 
         
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * WHEN ACTOR TAKES DAMAGE, BUT NOTHING THEY CAN'T SHRUG OFF
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  }; DEFAULT_DAMAGE = { # <= Do Not Touch This Line
 
 
    # What Actor One Will Say when Hurt in battle
    1 => [
           "Default Damage1", 80, 100, 10,
         ],  
 
 
    # What Actor Two Will Say when Hurt in battle
    2 => [
           "Default Damage1", 80, 100, 10,
         ],
 
 
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * WHEN ACTOR HAS THEIR HP OR MP RESTORED, EITHER BY ITEMS OR MAGIC
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  }; HP_MP_RESTORE = { # <= Do Not Touch This Line
    
    # Allowed to speak if this actor healed themself?
    :self_heal_speak  =>  true ,
    
 
    # What Actor One Will Say when Healed in battle
    1 => [
           "HP_MP Restore1", 80, 100, 10,
         ],
 
 
    # What Actor Two Will Say when Healed in battle
    2 => [
           "HP_MP Restore1", 80, 100, 10,
         ],
 
 
         
         
         
  #=============================================================================
  #    Death & Revive Voices
  #-----------------------------------------------------------------------------
  #   These voices are heard when an actor is knockout in battle or when they
  #   are revived in battle either via magic or items
  #=============================================================================
 
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * WHEN ACTOR HAS JUST BEEN KO'D IN BATTLE
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # Voices to play when an actor dies
  }; DEATH_VOICE = { # <= Do Not Touch This Line
 
 
    # What Actor One Will Say when they die
    1 => [
           "Death Cry1", 80, 100, 10,
         ],
 
 
    # What Actor Two Will Say when they die
    2 => [
           "Death Cry1", 80, 100, 10,
           "Death Cry2", 80, 100, 10,
         ],
 
 
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * WHEN ACTOR HAS JUST BEEN REVIVED IN BATTLE
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  }; REVIVED_VOICE = { # <= Do Not Touch This Line
 
 
    # What Actor One Will Say when Revived in battle
    1 => [
           "HP_MP Restore1", 80, 100, 10,
         ],
                                                 
         
         
         
         
  #=============================================================================
  #    Escape Voices
  #-----------------------------------------------------------------------------
  #   These voices are heard when you are attempting to escape from battle and
  #   includes: Escape Attempt Voices, Escape Success Voices & Escape Failure Voices.
  #   An Actor will be chosen at random to speak when an Escape Attempt is performed
  #=============================================================================
 
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * WHEN ATTEMPTING TO ESCAPE FROM BATTLE
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  }; ESCAPE_ATTEMPT_VOICE = { # <= Do Not Touch This Line
 
 
    # What Actor One Will Say when they attempt to escape battle
    1 => [
           "Escape Attempt1", 80, 100, 10,
           "Escape Attempt2", 80, 100, 10,
           "Escape Attempt3", 80, 100, 10,
         ],      
     
 
    # What Actor Two Will Say when they attempt to escape battle
    2 => [
           "Escape Attempt1", 80, 100, 10,
         ],
 
 
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * WHEN ESCAPE IS SUCCESSFUL
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  }; SUCCESSFUL_ESCAPE = { # <= Do Not Touch This Line
 
 
    # What Actor One Will Say when they successfully escape from battle
    1 => [
           "Successful Escape1", 80, 100, 0,
           "Successful Escape2", 80, 100, 0,
         ],  
 
 
    # What Actor Two Will Say when they successfully escape from battle
    2 => [
           "Successful Escape1", 80, 100, 0,
         ],
 
 
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * WHEN ESCAPE WAS A FAILURE
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  }; FAILED_ESCAPE = { # <= Do Not Touch This Line
 
 
    # What Actor One Will Say when they fail to escape from battle
    1 => [
           "Failed Escape1", 80, 100, 0,
           "Failed Escape2", 80, 100, 0,
         ],  
 
 
    # What Actor Two Will Say when they fail to escape from battle
    2 => [
           "Failed Escape1", 80, 100, 0,
         ],
         
         
         
         
         
  #=============================================================================
  #    Battle Victory Voices
  #-----------------------------------------------------------------------------
  #   These voices are heard when you are victorious in battle, this includes:
  #   Tough Battle Voices, Long Battle Voices, Quick Battle Voices, Level Up Voices
  #=============================================================================
 
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * WHEN BATTLE TOOK ITS TOLL ON YOUR PARTY
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  }; THAT_WAS_TOUGH = { # <= Do Not Touch This Line
 
    # By default this is 50%, so if you win a battle with 50% LESS HP than what
    # you went in with, these voices will play
    :ratio => 50 ,
 
 
    # What Actor One Will Say when this occurs
    1 => [
           "That Was Tough Victory1", 80, 100, 0,
           "That Was Tough Victory2", 80, 100, 0,
         ],
 
 
    # What Actor Two Will Say when this occurs
    2 => [
           "That Was Tough Victory1", 80, 100, 0,
         ],
         
         
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * WHEN BATTLE DIDN'T TAKE VERY LONG
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  }; THAT_WAS_EASY = { # <= Do Not Touch This Line
 
 
    # By default this is 3, so if a battle took three turns or less,
    # the following voices will play
    :ratio => 3 ,
 
 
    # What Actor One Will Say when a battle didn't take too long
    1 => [
           "That Was Easy Victory1", 80, 100, 0,
           "That Was Easy Victory2", 80, 100, 0,
           "That Was Easy Victory3", 80, 100, 0,
           "That Was Easy Victory4", 80, 100, 0,
         ],
     
     
    # What Actor Two Will Say when a battle didn't take too long
    2 => [
           "That Was Easy Victory1", 80, 100, 0,
           "That Was Easy Victory2", 80, 100, 0,
           "That Was Easy Victory3", 80, 100, 0,
         ],
         
         
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * WHEN BATTLE TOOK A VERY LONG TIME
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  }; BATTLE_TOOK_AGES = { # <= Do Not Touch This Line
 
    # By default this is 15, so it means the battle needs to have
    # taken 15 turns or more for the following voices to be played
    :ratio => 15 ,
 
 
    # What Actor Two Will Say when battle took a long time
    2 => [
           "Battle Took Ages Victory1", 80, 100, 0,
         ],
         
     
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * WHEN VICTORY LEADS TO LEVEL UP
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  }; LEVELUP_VICTORY = { # <= Do Not Touch This Line
 
    # You MUST use the wait frame timer (last number per voice) per voice as
    # appropriate. Due to RPGMaker liking to make everyone level up at the same
    # time, the wait timer is the only way to stop everyone who just leveled up
    # from talking at once.
 
 
    # What Actor One Will Say when LevelUp Occurs
    1 => [
           "Normal Victory1", 80, 100, 120,
         ],
         
    # What Actor Two Will Say when LevelUp Occurs
    2 => [
           "Normal Victory1", 80, 100, 120,
         ],
 
         
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * NORMAL VICTORY
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  }; NORMAL_VICTORY = { # <= Do Not Touch This Line
 
  # This is what your actors will say normally if the aboves are not met
 
 
    # What Actor One Will Say when a battle resulted in victory
    1 => [
           "Normal Victory1", 80, 100, 0,
           "Normal Victory2", 80, 100, 0,
           "Normal Victory3", 80, 100, 0,
           "Normal Victory4", 80, 100, 0,
           "Normal Victory5", 80, 100, 0,
           "Normal Victory6", 80, 100, 0,
         ],
     
     
    # What Actor Two Will Say when a battle resulted in victory
    2 => [
           "Normal Victory1", 80, 100, 0,
           "Normal Victory2", 80, 100, 0,
           "Normal Victory3", 80, 100, 0,
           "Normal Victory4", 80, 100, 0,
           "Normal Victory5", 80, 100, 0,
           "Normal Victory6", 80, 100, 0,
         ],
         
         
         
         
         
         
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
#                                                        -=
};    # End Of Editable Region           ////            ==
#                                                        =-
#-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
 
 
 
 
 
 
  CURRENT_VERSION = 2.6
  ENEMY_VOICES_IMPORTED = !$diamondandplatinum3_scripts[:EnemyBattleVoices].nil?
  #------------------------------------------------------------------------
  # * New Method: Check Version Compatibility
  #------------------------------------------------------------------------
  def self.check_version_compatibility( version )
    return :outdated_version if version > CURRENT_VERSION
    return :outdated_patch   if version < CURRENT_VERSION
    return :compatible
  end
  #------------------------------------------------------------------------
  # * New Method: Play Voice
  #------------------------------------------------------------------------
  def self.play_voice( voice_array, actor_id )
    return true if check_if_actor_muted(actor_id)
   
    # If voice_array is not nil AND not empty
    if voice_array && !voice_array.empty?
      index = rand(voice_array.size / 4) * 4
      if voice_array[index].is_a?(String) && voice_array[index + 1].is_a?(Integer) && voice_array[index + 2].is_a?(Integer)
       
        # Get the Actor Folder Name
        if !$game_system.actor_voices_names.nil? && $game_system.actor_voices_names.size > actor_id && $game_system.actor_voices_names[actor_id].is_a?(String) && $game_system.actor_voices_names[actor_id] != ""
          actor_folder_name = $game_system.actor_voices_names[actor_id]
        else
          actor_folder_name = $game_actors[actor_id].name
        end
        
        # Get Path to File
        pathtofile = "/" + FOLDER_DIRECTORY_NAME + "/" + actor_folder_name + "/" + voice_array[index]
       
        # Play Voice
        RPG::SE.new(pathtofile, voice_array[index + 1], voice_array[index + 2]).play
       
        # Wait if necessary
        SceneManager.scene.wait(voice_array[index + 3]) unless !voice_array[index + 3].is_a?(Integer) || !SceneManager.scene_is?(Scene_Battle)
        return true
      end
    end
    # We return true and false because during battle start and victory, if an actor
    # doesn't have a voice clip for one condition, we'll try to find another met
    # condition in which the actor DOES have a voice.
    return false
  end
  #------------------------------------------------------------------------
  # * New Method: Allowed to Play Voice?
  #------------------------------------------------------------------------
  def self.allowed_to_play_voice?()
    return SceneManager.scene_is?(Scene_Battle)
  end
  #------------------------------------------------------------------------
  # * New Method: Allowed to Speak?
  #------------------------------------------------------------------------
  def self.allowed_to_speak?()
    return rand(100) < VOICE_FREQUENCY
  end
  #------------------------------------------------------------------------
  # * New Method: Check For Mute Actor
  #------------------------------------------------------------------------
  def self.check_if_actor_muted(actor_id)
    # Don't Play Sound if Muted
    return true if $game_switches[EVENT_SWITCH_ID]
    return $game_actors[actor_id].states.any? { |state| SILENCE_STATES.include?(state.id) }
  end
  #------------------------------------------------------------------------
  # * New Method: Get Random Battle Actor ID
  #------------------------------------------------------------------------
  def self.get_battle_actor_id()
    # Get a Battle Actor ID, who is to speak
    actor_ids = []
    $game_party.battle_members.each do |ally|
      actor_ids.push(ally.id) if ally.alive?
    end
    return actor_ids[rand(actor_ids.size)]
  end
  #------------------------------------------------------------------------
  # * New Method: Play "Party Needs Healing" Voice
  #------------------------------------------------------------------------
  def self.play_party_needs_healing_voice(actor_id = 0)
    return true if !allowed_to_play_voice?()
    actor_id = actor_id != 0 ? actor_id : get_battle_actor_id()
    return play_voice(PARTY_NEEDS_HEALING[actor_id], actor_id)
  end
  #------------------------------------------------------------------------
  # * New Method: Play "Too Many Enemies" Voice
  #------------------------------------------------------------------------
  def self.play_too_many_enemies_voice(actor_id = 0)
    return true if !allowed_to_play_voice?()
    actor_id = actor_id != 0 ? actor_id : get_battle_actor_id()
    return play_voice(TOO_MANY_ENEMIES[actor_id], actor_id)
  end
  #------------------------------------------------------------------------
  # * New Method: Play "Very Weak Enemies" Voice
  #------------------------------------------------------------------------
  def self.play_very_weak_enemies_voice(actor_id = 0)
    return true if !allowed_to_play_voice?()
    actor_id = actor_id != 0 ? actor_id : get_battle_actor_id()
    return play_voice(VERY_WEAK_ENEMIES[actor_id], actor_id)
  end
  #------------------------------------------------------------------------
  # * New Method: Play "Weak Enemies" Voice
  #------------------------------------------------------------------------
  def self.play_weak_enemies_voice(actor_id = 0)
    return true if !allowed_to_play_voice?()
    actor_id = actor_id != 0 ? actor_id : get_battle_actor_id()
    return play_voice(WEAK_ENEMIES[actor_id], actor_id)
  end
  #------------------------------------------------------------------------
  # * New Method: Play "Equal Enemies" Voice
  #------------------------------------------------------------------------
  def self.play_equal_enemies_voice(actor_id = 0)
    return true if !allowed_to_play_voice?()
    actor_id = actor_id != 0 ? actor_id : get_battle_actor_id()
    return play_voice(EQUAL_ENEMIES[actor_id], actor_id)
  end
  #------------------------------------------------------------------------
  # * New Method: Play "Strong Enemies" Voice
  #------------------------------------------------------------------------
  def self.play_strong_enemies_voice(actor_id = 0)
    return true if !allowed_to_play_voice?()
    actor_id = actor_id != 0 ? actor_id : get_battle_actor_id()
    return play_voice(STRONG_ENEMIES[actor_id], actor_id)
  end
  #------------------------------------------------------------------------
  # * New Method: Play "Very Strong Enemies" Voice
  #------------------------------------------------------------------------
  def self.play_very_strong_enemies_voice(actor_id = 0)
    return true if !allowed_to_play_voice?()
    actor_id = actor_id != 0 ? actor_id : get_battle_actor_id()
    return play_voice(VERY_STRONG_ENEMIES[actor_id], actor_id)
  end
  #------------------------------------------------------------------------
  # * New Method: Play "I Missed Enemy" Voice
  #------------------------------------------------------------------------
  def self.play_missed_enemies_voice(actor_id)
    return true if !allowed_to_play_voice?() || !allowed_to_speak?()
    return play_voice(MISSED_ENEMY[actor_id], actor_id)
  end
  #------------------------------------------------------------------------
  # * New Method: Play "I Evaded Enemy" Voice
  #------------------------------------------------------------------------
  def self.play_evaded_enemy_voice(actor_id)
    return true if !allowed_to_play_voice?() || !allowed_to_speak?()
    return play_voice(DODGED_ENEMY[actor_id], actor_id)
  end
  #------------------------------------------------------------------------
  # * New Method: Play "Normal Attack" Voice
  #------------------------------------------------------------------------
  def self.play_normal_attack_voice(actor_id)
    return true if !allowed_to_play_voice?() || !allowed_to_speak?()
    return play_voice(ACTOR_ATTACKING[actor_id], actor_id)
  end
  #------------------------------------------------------------------------
  # * New Method: Play "Using Skill" Voice
  #------------------------------------------------------------------------
  def self.play_skill_voice(actor_id, skill_id)
    return true if !allowed_to_play_voice?()
    voice = []
    $data_skills[skill_id].note.scan(/~ActorVoice:\s*#{actor_id.to_s}\,*\s*\"(.+?)\"\,*\s*(\d*)\,*\s*(\d*)\,*\s*(\d*)/im).collect{ |voice_info|
      unless voice_info.empty?
        voice.push(voice_info[0])
        voice.push(voice_info[1] != "" ? voice_info[1].to_i : 80)
        voice.push(voice_info[2] != "" ? voice_info[2].to_i : 100)
        voice.push(voice_info[3] != "" ? voice_info[3].to_i : 0)
      end
    }
   
    # Modify Skill Voice to Generic Skill Voice if there is no specific voice for this Skill
    if voice.empty?
      return true if SKILLS_NOT_TO_PLAY_VOICE_FOR.include?(skill_id) || !allowed_to_speak?()
      voice = USING_SKILLS[actor_id]
    end
   
    return play_voice( voice, actor_id )
  end
  #------------------------------------------------------------------------
  # * New Method: Play "Using Item" Voice
  #------------------------------------------------------------------------
  def self.play_item_voice(actor_id, item_id)
    return true if !allowed_to_play_voice?()
    voice = []
    $data_items[item_id].note.scan(/~ActorVoice:\s*#{actor_id.to_s}\,*\s*\"(.+?)\"\,*\s*(\d*)\,*\s*(\d*)\,*\s*(\d*)/im).collect{ |voice_info|
      unless voice_info.empty?
        voice.push(voice_info[0])
        voice.push(voice_info[1] != "" ? voice_info[1].to_i : 80)
        voice.push(voice_info[2] != "" ? voice_info[2].to_i : 100)
        voice.push(voice_info[3] != "" ? voice_info[3].to_i : 0)
      end
    }
   
    # Modify Item Voice to Generic Item Voice if there is no specific voice for this item
    if voice.empty?
      return true if !allowed_to_speak?()
      voice = USING_ITEMS[actor_id]
    end
   
    return play_voice( voice, actor_id )
  end
  #------------------------------------------------------------------------
  # * New Method: Play "Using Skill/Item" Voice
  #------------------------------------------------------------------------
  def self.play_skill_or_item_voice(actor_id, item)
    #~~~~~ Using A Skill ~~~~~#
    if item.is_a?(RPG::Skill)
      if item.id == 1 # Attack
        play_normal_attack_voice(actor_id)
      else # Another skill besides Attack
        play_skill_voice(actor_id, item.id)
      end
 
    #~~~~~ Using An Item ~~~~~#
    else
      play_item_voice(actor_id, item.id)
    end
  end
  #------------------------------------------------------------------------
  # * New Method: Play "Death" Voice
  #------------------------------------------------------------------------
  def self.play_death_voice(actor_id)
    return true if !allowed_to_play_voice?()
    return play_voice(DEATH_VOICE[actor_id], actor_id)
  end
  #------------------------------------------------------------------------
  # * New Method: Play "I Leveled Up" Voice
  #------------------------------------------------------------------------
  def self.play_leveledup_voice(actor_id)
    return true if !allowed_to_play_voice?()
    return false unless LEVELUP_VICTORY[actor_id] # Array is not nil
    # Wait For Actor To Finish Talking
    index = rand(LEVELUP_VICTORY[actor_id].size / 4) * 4
    voice = [LEVELUP_VICTORY[actor_id][index],      LEVELUP_VICTORY[actor_id][index + 1],
             LEVELUP_VICTORY[actor_id][index + 2],  LEVELUP_VICTORY[actor_id][index + 3]]
    # Return False if Failed to Play Voice
    return false unless play_voice(voice, actor_id)
    # Wait for Voice to Quell if Necessary
    if voice[3].is_a?(Integer)
      voice[3].times{ |i| SceneManager.scene.update_basic() }
    end
    return true
  end
  #------------------------------------------------------------------------
  # * New Method: Play "Restored HP/MP" Voice
  #------------------------------------------------------------------------
  def self.play_healed_voice(actor_id)
    return true if !allowed_to_play_voice?() || !allowed_to_speak?()
    return play_voice(HP_MP_RESTORE[actor_id], actor_id)
  end
  #------------------------------------------------------------------------
  # * New Method: Play "Revived" Voice
  #------------------------------------------------------------------------
  def self.play_revived_voice(actor_id)
    return true if !allowed_to_play_voice?()
    return play_voice(REVIVED_VOICE[actor_id], actor_id)
  end
  #------------------------------------------------------------------------
  # * New Method: Play "Default Damage" Voice
  #------------------------------------------------------------------------
  def self.play_default_damage_voice(actor_id)
    return true if !allowed_to_play_voice?() || !allowed_to_speak?()
    return play_voice(DEFAULT_DAMAGE[actor_id], actor_id)
  end
  #------------------------------------------------------------------------
  # * New Method: Play "Little Damage" Voice
  #------------------------------------------------------------------------
  def self.play_little_damage_voice(actor_id)
    return true if !allowed_to_play_voice?() || !allowed_to_speak?()
    return play_voice(LITTLE_DAMAGE[actor_id], actor_id)
  end
  #------------------------------------------------------------------------
  # * New Method: Play "Significant Damage" Voice
  #------------------------------------------------------------------------
  def self.play_significant_damage_voice(actor_id)
    return true if !allowed_to_play_voice?() || !allowed_to_speak?()
    return play_voice(SIGNIFICANT_DAMAGE[actor_id], actor_id)
  end
  #------------------------------------------------------------------------
  # * New Method: Play "Heavy Damage" Voice
  #------------------------------------------------------------------------
  def self.play_heavy_damage_voice(actor_id)
    return true if !allowed_to_play_voice?() || !allowed_to_speak?()
    return play_voice(HEAVY_DAMAGE[actor_id], actor_id)
  end
  #------------------------------------------------------------------------
  # * New Method: Play "Massive Damage" Voice
  #------------------------------------------------------------------------
  def self.play_massive_damage_voice(actor_id)
    return true if !allowed_to_play_voice?() || !allowed_to_speak?()
    return play_voice(MASSIVE_DAMAGE[actor_id], actor_id)
  end
  #------------------------------------------------------------------------
  # * New Method: Play "Escape Attempt" Voice
  #------------------------------------------------------------------------
  def self.play_escape_attempt_voice(actor_id)
    return true if !allowed_to_play_voice?()
    return play_voice(ESCAPE_ATTEMPT_VOICE[actor_id], actor_id)
  end
  #------------------------------------------------------------------------
  # * New Method: Play "Escape Successful" Voice
  #------------------------------------------------------------------------
  def self.play_escape_successful_voice(actor_id, force_allow = false)
    # When You Escape, you are now on Scene_Map instead of Scene_Battle
    # So force_allow will let you play the voice if you did infact just escape from battle
    return true if !allowed_to_play_voice?() && !force_allow
    return play_voice(SUCCESSFUL_ESCAPE[actor_id], actor_id)
  end
  #------------------------------------------------------------------------
  # * New Method: Play "Escape Failed" Voice
  #------------------------------------------------------------------------
  def self.play_escape_failed_voice(actor_id)
    return true if !allowed_to_play_voice?()
    return play_voice(FAILED_ESCAPE[actor_id], actor_id)
  end
  #------------------------------------------------------------------------
  # * New Method: Play "Default Victory" Voice
  #------------------------------------------------------------------------
  def self.play_default_victory_voice(actor_id = 0)
    return true if !allowed_to_play_voice?()
    actor_id = actor_id != 0 ? actor_id : get_battle_actor_id()
    return play_voice(NORMAL_VICTORY[actor_id], actor_id)
  end
  #------------------------------------------------------------------------
  # * New Method: Play "Battle Was Easy" Voice
  #------------------------------------------------------------------------
  def self.play_battle_was_easy_voice(actor_id = 0)
    return true if !allowed_to_play_voice?()
    actor_id = actor_id != 0 ? actor_id : get_battle_actor_id()
    return play_voice(THAT_WAS_EASY[actor_id], actor_id)
  end
  #------------------------------------------------------------------------
  # * New Method: Play "Very Long Battle" Voice
  #------------------------------------------------------------------------
  def self.play_very_long_battle_voice(actor_id = 0)
    return true if !allowed_to_play_voice?()
    actor_id = actor_id != 0 ? actor_id : get_battle_actor_id()
    return play_voice(BATTLE_TOOK_AGES[actor_id], actor_id)
  end
  #------------------------------------------------------------------------
  # * New Method: Play "Party Was Badly Injured" Voice
  #------------------------------------------------------------------------
  def self.play_party_was_badly_injured_voice(actor_id = 0)
    return true if !allowed_to_play_voice?()
    actor_id = actor_id != 0 ? actor_id : get_battle_actor_id()
    return play_voice(THAT_WAS_TOUGH[actor_id], actor_id)
  end
 
end # BattleVoices Module
end # DiamondandPlatinum3 Module
 
 
 
 
#==============================================================================
# ** Game_System
#------------------------------------------------------------------------------
#  This class handles system data. It saves the disable state of saving and 
# menus. Instances of this class are referenced by $game_system.
#==============================================================================

class Game_System
  #--------------------------------------------------------------------------
  # * Alias Listings
  #--------------------------------------------------------------------------
  alias dp3_gamesys_init_1s098yu9j                                 initialize
  #--------------------------------------------------------------------------
  # * Public Instance Variables
  #--------------------------------------------------------------------------
  attr_accessor :actor_voices_names
  #--------------------------------------------------------------------------
  # * Object Initialization
  #--------------------------------------------------------------------------
  def initialize(*args)
    dp3_gamesys_init_1s098yu9j(*args) # Call Original Method
    actor_voices_names = Array.new()
  end
end


#==============================================================================
# ** Game_Interpreter
#------------------------------------------------------------------------------
#  An interpreter for executing event commands. This class is used within the
# Game_Map, Game_Troop, and Game_Event classes.
#==============================================================================

class Game_Interpreter
  #--------------------------------------------------------------------------
  # * Set Actor Voice Name
  #--------------------------------------------------------------------------
  def set_actor_voice_name(id, name)
    unless id.is_a?(Integer); msgbox_p("You did not insert a Valid ID for the Actor"); return; end
    unless name.is_a?(String); msgbox_p("You did not insert a Valid Name for the Actor"); return; end
    
    $game_system.actor_voices_names = Array.new() if $game_system.actor_voices_names.nil?
    $game_system.actor_voices_names[id] = name
  end
end


#==============================================================================
# ** Scene_Battle
#------------------------------------------------------------------------------
#  This class performs battle screen processing.
#==============================================================================
 
class Scene_Battle < Scene_Base
  #--------------------------------------------------------------------------
  # * Alias Listings
  #--------------------------------------------------------------------------
  alias dp3_scenebattle_poststart_1s098yu9j               post_start
  alias dp3_scenebattle_applyitemeffects_1s098yu9j        apply_item_effects
 
  #--------------------------------------------------------------------------
  # * Aliased Method: Post-Start Processing
  #--------------------------------------------------------------------------
  def post_start(*args)
    dp3_play_battle_start_voice()    
    dp3_scenebattle_poststart_1s098yu9j()
  end
 
  #--------------------------------------------------------------------------
  # * New Method: Play Battle Start Voice
  #--------------------------------------------------------------------------
  def dp3_play_battle_start_voice
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # Party Needs Healing?
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    party_total_hp = party_current_hp = 0
    $game_party.battle_members.each {|ally| party_total_hp += ally.mhp }
    party_current_hp = party_total_hp
    $game_party.battle_members.each {|ally| party_current_hp -= (ally.mhp - ally.hp) }
   
    if party_current_hp < party_total_hp * (DiamondandPlatinum3::BattleVoices::PARTY_NEEDS_HEALING[:ratio] * 0.01)
      return if DiamondandPlatinum3::BattleVoices::play_party_needs_healing_voice()
    end
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # Too many enemies?
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    if $game_troop.members.size > $game_party.members.size + DiamondandPlatinum3::BattleVoices::TOO_MANY_ENEMIES[:ratio]
      return if DiamondandPlatinum3::BattleVoices::play_too_many_enemies_voice()
    end
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # Which side is stronger?
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    strongest_enemy_stats   = [ 0, 0, 0, 0 ]
    strongest_party_stats   = [ 0, 0, 0, 0 ]
   
    $game_troop.members.each do |enemy|
      strongest_enemy_stats[0] = enemy.atk if enemy.atk > strongest_enemy_stats[0]
      strongest_enemy_stats[1] = enemy.def if enemy.def > strongest_enemy_stats[1]
      strongest_enemy_stats[2] = enemy.mat if enemy.mat > strongest_enemy_stats[2]
      strongest_enemy_stats[3] = enemy.mdf if enemy.mdf > strongest_enemy_stats[3]
    end
   
    $game_party.battle_members.each do |ally|
      strongest_party_stats[0] = ally.atk if ally.atk > strongest_party_stats[0]
      strongest_party_stats[1] = ally.def if ally.def > strongest_party_stats[1]
      strongest_party_stats[2] = ally.mat if ally.mat > strongest_party_stats[2]
      strongest_party_stats[3] = ally.mdf if ally.mdf > strongest_party_stats[3]
    end
   
   
    enemy_power = strongest_enemy_stats[0] + strongest_enemy_stats[1] + strongest_enemy_stats[2] + strongest_enemy_stats[3]
    party_power = strongest_party_stats[0] + strongest_party_stats[1] + strongest_party_stats[2] + strongest_party_stats[3]
   
   
    return DiamondandPlatinum3::BattleVoices::play_very_weak_enemies_voice()     if enemy_power < party_power * (DiamondandPlatinum3::BattleVoices::VERY_WEAK_ENEMIES[:ratio] * 0.01)
    return DiamondandPlatinum3::BattleVoices::play_weak_enemies_voice()          if enemy_power < party_power * (DiamondandPlatinum3::BattleVoices::WEAK_ENEMIES[:ratio] * 0.01)
    return DiamondandPlatinum3::BattleVoices::play_very_strong_enemies_voice()   if enemy_power > party_power * (DiamondandPlatinum3::BattleVoices::VERY_STRONG_ENEMIES[:ratio] * 0.01)
    return DiamondandPlatinum3::BattleVoices::play_strong_enemies_voice()        if enemy_power > party_power * (DiamondandPlatinum3::BattleVoices::STRONG_ENEMIES[:ratio] * 0.01)
    return DiamondandPlatinum3::BattleVoices::play_equal_enemies_voice()
  end # def dp3_play_battle_start_voice
 
 
  #--------------------------------------------------------------------------
  # * Aliased Method: Apply Skill/Item Effect
  #--------------------------------------------------------------------------
  def apply_item_effects(*args)
    # Call Original Method
    dp3_scenebattle_applyitemeffects_1s098yu9j(*args)
    args[0].dp3_set_actor_said_thank_you_already() if args[0].actor?
   
    # If Result was a Miss, and an actor was not targeting an actor
    if !args[0].result.hit?
      if !args[0].actor? && @subject.actor?
        DiamondandPlatinum3::BattleVoices::play_missed_enemies_voice(@subject.id)
      elsif args[0].actor? && !@subject.actor?
        DiamondandPlatinum3::BattleVoices::play_evaded_enemy_voice(args[0].id)
      end
    end
  end

  #--------------------------------------------------------------------------
  # * Overwritten Method: Show Normal Animation
  #--------------------------------------------------------------------------
  def show_normal_animation(*args)
    @dp3_speak_for_multiple_hits = true             # New Line
    animation = $data_animations[args[1]]
    if animation
      args[0].each do |target|
        dp3_on_animation_begin(target)              # New Line
        target.animation_id = args[1]
        target.animation_mirror = args[2]
        abs_wait_short unless animation.to_screen?
        dp3_on_animation_end(target)                # New Line
      end
      abs_wait_short if animation.to_screen?
    end
  end
  
  #--------------------------------------------------------------------------
  # * New Method: On Animation Begin (Multihit Included)
  #--------------------------------------------------------------------------
  def dp3_on_animation_begin(target)
    if @dp3_speak_for_multiple_hits
      if @subject.actor? && !target.actor?
        @dp3_speak_for_multiple_hits = DiamondandPlatinum3::BattleVoices::PLAY_MULTIPLE_VOICES_FOR_MULTIPLE_HITS
        DiamondandPlatinum3::BattleVoices::play_skill_or_item_voice(@subject.id, @subject.current_action.item)
      end
    end
  end
  
  #--------------------------------------------------------------------------
  # * New Method: On Animation End (Multihit Included)
  #--------------------------------------------------------------------------
  def dp3_on_animation_end(target)
  end
 
end # Class
 
 
#==============================================================================
# ** Game_Actor
#------------------------------------------------------------------------------
#  This class handles actors. It is used within the Game_Actors class
# ($game_actors) and is also referenced from the Game_Party class ($game_party).
#==============================================================================
 
class Game_Actor < Game_Battler
  #--------------------------------------------------------------------------
  # * Alias Listings
  #--------------------------------------------------------------------------
  alias dp3_gameactor_useitem_1s098yu9j                 use_item
  alias dp3_gameactor_die_1s098yu9j                     die
  alias dp3_gameactor_changeexp_1s098yu9j               change_exp
  alias dp3_gameactor_itemeffectrecoverhp_1s098yu9j     item_effect_recover_hp
  alias dp3_gameactor_itemeffectrecovermp_1s098yu9j     item_effect_recover_mp
  alias dp3_gameactor_executedamage_1s098yu9j           execute_damage
  alias dp3_gameactor_removestate_1s098yu9j             remove_state
  alias dp3_gameactor_ondamage_1s098yu9j                on_damage
 
  #--------------------------------------------------------------------------
  # * Aliased Method: Use Skill/Item
  #--------------------------------------------------------------------------
  def use_item( *args )
    DiamondandPlatinum3::BattleVoices::play_item_voice(@actor_id, args[0].id) if args[0].is_a?(RPG::Item)
   
    # Call Original Method
    dp3_gameactor_useitem_1s098yu9j( *args )
  end
 
  #--------------------------------------------------------------------------
  # * Aliased Method: Knock Out
  #--------------------------------------------------------------------------
  def die( *args )
    DiamondandPlatinum3::BattleVoices::play_death_voice(@actor_id)
   
    # Call Original Method
    dp3_gameactor_die_1s098yu9j( *args )
  end
 
  #--------------------------------------------------------------------------
  # * Aliased Method: Change Experience
  #--------------------------------------------------------------------------
  def change_exp(*args)
    last_level = @level
    dp3_gameactor_changeexp_1s098yu9j(*args) # Call Original Method
    if @level > last_level
      DiamondandPlatinum3::BattleVoices::play_leveledup_voice(@actor_id)
    end
  end  
 
  #--------------------------------------------------------------------------
  # * Aliased Method: [HP Recovery] Effect
  #--------------------------------------------------------------------------
  def item_effect_recover_hp( *args )
    if args[0] != self && !@dp3__actor_said_thank_you
      DiamondandPlatinum3::BattleVoices::play_healed_voice(@actor_id)
      @dp3__actor_said_thank_you = true
    end
   
    # Call Original Method
    dp3_gameactor_itemeffectrecoverhp_1s098yu9j( *args )
  end
 
  #--------------------------------------------------------------------------
  # * Aliased Method: [MP Recovery] Effect
  #--------------------------------------------------------------------------
  def item_effect_recover_mp( *args )
    if args[0] != self && !@dp3__actor_said_thank_you
      DiamondandPlatinum3::BattleVoices::play_healed_voice(@actor_id)
      @dp3__actor_said_thank_you = true
    end
    # Call Original Method
    dp3_gameactor_itemeffectrecovermp_1s098yu9j( *args )
  end
 
 
  #--------------------------------------------------------------------------
  # * Aliased Method: Execute Damage
  #--------------------------------------------------------------------------
  def execute_damage(*args)
    current_hp = self.hp
    current_mp = self.mp
    dp3_gameactor_executedamage_1s098yu9j(*args)

    # Play Healed Voice if Healed and Allowed
    if current_hp < self.hp || current_mp < self.mp
      if args[0].enemy?
        if args[0] == self
          if DiamondandPlatinum3::BattleVoices::HP_MP_RESTORE[:self_heal_speak]
            DiamondandPlatinum3::BattleVoices::play_healed_voice(@actor_id)
          end
        else
          DiamondandPlatinum3::BattleVoices::play_healed_voice(@actor_id)
        end
      end
    end
  end
 
 
  #--------------------------------------------------------------------------
  # * Aliased Method: [Remove Debuff] Effect
  #--------------------------------------------------------------------------
  def remove_state(*args)
    play_voice = state?(death_state_id) && args[0] == death_state_id
    dp3_gameactor_removestate_1s098yu9j(*args) # Call Original Method
    DiamondandPlatinum3::BattleVoices::play_revived_voice(@actor_id) if play_voice
  end
 
 
 
  #--------------------------------------------------------------------------
  # * Aliased Method: Processing When Suffering Damage
  #--------------------------------------------------------------------------
  def on_damage(*args)
    dp3_play_appropriate_actor_damage_voice( args[0] ) if args[0] > 0 && (self.hp - args[0]) > 0
   
    # Call Original Method
    dp3_gameactor_ondamage_1s098yu9j( *args )
  end
 
  #--------------------------------------------------------------------------
  # * New Method: Get Actor Damage Voice Array
  #--------------------------------------------------------------------------
  def dp3_play_appropriate_actor_damage_voice( value )
    #~~~~~ Play Massive Damage Voice ~~~~~#
    if value > self.mhp * (DiamondandPlatinum3::BattleVoices::MASSIVE_DAMAGE[:ratio] * 0.01)
      return true if DiamondandPlatinum3::BattleVoices::play_massive_damage_voice(@actor_id)
    end
    #~~~~~ Play Heavy Damage Voice ~~~~~#
    if value > self.mhp * (DiamondandPlatinum3::BattleVoices::HEAVY_DAMAGE[:ratio] * 0.01)
      return true if DiamondandPlatinum3::BattleVoices::play_heavy_damage_voice(@actor_id)
    end
    #~~~~~ Play Significant Damage Voice ~~~~~#
    if value > self.mhp * (DiamondandPlatinum3::BattleVoices::SIGNIFICANT_DAMAGE[:ratio] * 0.01)
      return true if DiamondandPlatinum3::BattleVoices::play_significant_damage_voice(@actor_id)
    end
    #~~~~~ Play Little Damage Voice ~~~~~#
    if value > self.mhp * (DiamondandPlatinum3::BattleVoices::LITTLE_DAMAGE[:ratio] * 0.01)
      return true if DiamondandPlatinum3::BattleVoices::play_little_damage_voice(@actor_id)
    end
    #~~~~~ Play Pitance Damage Voice ~~~~~#
    return DiamondandPlatinum3::BattleVoices::play_default_damage_voice(@actor_id)
  end
 
  #--------------------------------------------------------------------------
  # * New Method: Set "Thank You" Voice Availability
  #--------------------------------------------------------------------------
  def dp3_set_actor_said_thank_you_already()
    @dp3__actor_said_thank_you = false
  end
end
 
 
 
 
 
 
 
 
 
#==============================================================================
# ** BattleManager
#------------------------------------------------------------------------------
#  This module manages battle progress.
#==============================================================================
 
module BattleManager
  class << self
    #------------------------------------------------------------------------
    # * Alias Listings
    #------------------------------------------------------------------------
    alias dp3_battlemanager_setup_1s098yu9j               setup
    alias dp3_battlemanager_processescape_1s098yu9j       process_escape
    alias dp3_battlemanager_processvictory_1s098yu9j      process_victory
    alias dp3_battlemanager_processdefeat_1s098yu9j       process_defeat
   
    #------------------------------------------------------------------------
    # * Aliased Method: Setup
    #------------------------------------------------------------------------
    def setup( *args )
      @dp3_party_start_total_hp = 0
      $game_party.battle_members.each { |ally| @dp3_party_start_total_hp += ally.hp }
   
     
      # Call Original Method
      dp3_battlemanager_setup_1s098yu9j( *args )
    end
   
    #------------------------------------------------------------------------
    # * Aliased Method: Escape Processing
    #------------------------------------------------------------------------
    def process_escape( *args )
      # Play Begin Escape Voice
      actor_to_speak = DiamondandPlatinum3::BattleVoices::get_battle_actor_id()
      DiamondandPlatinum3::BattleVoices::play_escape_attempt_voice(actor_to_speak)
     
      # Call Original Method
      escaped = dp3_battlemanager_processescape_1s098yu9j( *args )
     
      # Play Voice for either successful or unsucessful escape
      if escaped
        DiamondandPlatinum3::BattleVoices::play_escape_successful_voice(actor_to_speak, true)
      else
        DiamondandPlatinum3::BattleVoices::play_escape_failed_voice(actor_to_speak)
      end
     
      # Finish Up
      return escaped
    end
    #------------------------------------------------------------------------
    # * Aliased Method: Victory Processing
    #------------------------------------------------------------------------
    def process_victory(*args)
      dp3_play_victory_voice()
     
      # Call Original Method
      return dp3_battlemanager_processvictory_1s098yu9j(*args)
    end
   
    #--------------------------------------------------------------------------
    # * Aliased Method: Defeat Processing
    #--------------------------------------------------------------------------
    def process_defeat(*args)
      # This method is merely here in case the @can_lose instance variable is on.
      # Actors will say thank you when being revived after defeat. So to counteract
      # this we set the mute event_switch on
      es_id                   = DiamondandPlatinum3::BattleVoices::EVENT_SWITCH_ID
      es_on                   = ($game_switches[es_id] ||= false)
      $game_switches[es_id]   = true
      defeated                = dp3_battlemanager_processdefeat_1s098yu9j(*args)
      $game_switches[es_id]   = es_on
      return defeated
    end
 
    #------------------------------------------------------------------------
    # * New Method: Play Victory Voice
    #------------------------------------------------------------------------
    def dp3_play_victory_voice
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      # Battle Took Ages?
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      if $game_troop.turn_count >= DiamondandPlatinum3::BattleVoices::BATTLE_TOOK_AGES[:ratio]
        return if DiamondandPlatinum3::BattleVoices::play_very_long_battle_voice()
      end
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      # Party Was Badly Injured?
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      party_current_hp = 0
      $game_party.battle_members.each {|ally| party_current_hp += ally.hp }
      if party_current_hp < @dp3_party_start_total_hp * (DiamondandPlatinum3::BattleVoices::THAT_WAS_TOUGH[:ratio] * 0.01)
        return if DiamondandPlatinum3::BattleVoices::play_party_was_badly_injured_voice()
      end
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      # Battle Was Easy?
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      if $game_troop.turn_count <= DiamondandPlatinum3::BattleVoices::THAT_WAS_EASY[:ratio]
        return if DiamondandPlatinum3::BattleVoices::play_battle_was_easy_voice()
      end
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      # Default Victory Speech
      #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      DiamondandPlatinum3::BattleVoices::play_default_victory_voice()
    end # def
  end # class
end # module