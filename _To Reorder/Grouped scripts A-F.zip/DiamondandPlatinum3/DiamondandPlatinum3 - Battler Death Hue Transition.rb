#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
#             Battler Death Hue Transition
#             Version: 1.0
#             Author: DiamondandPlatinum3
#             Date: June 7, 2014
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#  Description:
#
#    This script grants enemy battlers with a Target Hue to reach upon death.
#     What this means is that the more you attack and hurt the Battler, the 
#     closer their hue colour effect gets to the target.
#
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#------------------------------------------------------------------------------
#  Instructions:
#
#  ~  Modify The Default Target Hue in the Editable Region to suit your liking.
#
#
#  ~  If you wish to set up individual hue targets for an enemy. 
#       Inside the Enemy Database, enter the following as a notetag:
#               <~TargetHue: ???>
#
#       Replacing the ??? to a valid Hue Colour. Doing so will give the 
#       enemy an individual hue target compared to other enemy types in
#       the enemy troop.
#
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
module DiamondandPlatinum3
  module BattlerHue
    #=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
    #                                                        -= 
    #                 Editable Region        ////            ==
    #                                                        =-
    #-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    
    # What HUE should the Enemy have when close to death?
    # As the enemy HP goes down, they will slowly head towards this hue.
    #
    # This value is used if the Enemy does NOT have a notetag to specify
    # the Tarhet Hue.
    # By default, the value is 160; which is a Red Hue.
    TargetHue = 160
    
    #-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= 
    #                                           \/
    #               End of Editable Region      /\
    #                                           \/
    #-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
  end
end



#==============================================================================
# ** Game_Enemy
#------------------------------------------------------------------------------
#  This class handles enemies. It used within the Game_Troop class 
# ($game_troop).
#==============================================================================

class Game_Enemy < Game_Battler
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # *= Alias Listings
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  alias_method(:dp3_bht_gameenemy_pdamgeff_093tv,     :perform_damage_effect)
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * Aliased Method: Execute Damage Effect
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def perform_damage_effect(*args)
    dp3_bht_gameenemy_pdamgeff_093tv(*args) # Call Original Method
    @battler_hue = (((mhp() - @hp).to_f / mhp())* dp3_target_battler_hue()) if @hp > 0
  end
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * New Method: Get Target Hue
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def dp3_target_battler_hue
    if enemy.note =~ /<~Target\s?Hue:?\s?(\d+)>/i
      return $1.to_i
    else
      return DiamondandPlatinum3::BattlerHue::TargetHue
    end
  end
end