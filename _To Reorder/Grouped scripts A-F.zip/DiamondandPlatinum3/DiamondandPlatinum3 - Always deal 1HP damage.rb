#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
#             Always Deal At Least 1HP Damage
#             Author: DiamondandPlatinum3
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#  Description:
#
#    This script simply makes it so that damage is always at least 1.
#    No longer will enemies and yourself deal no damage.
#
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

class Game_ActionResult
  #--------------------------------------------------------------------------
  # * Create Damage
  #--------------------------------------------------------------------------
  alias dp3_dto_gameactionresult_makedamage     make_damage
  def make_damage(value, item)
    value = 1 if value == 0
    dp3_dto_gameactionresult_makedamage(value, item)
  end
end