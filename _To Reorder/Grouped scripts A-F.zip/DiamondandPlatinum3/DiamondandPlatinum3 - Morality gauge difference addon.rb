#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
#             Morality Gauge Difference ~ Add-On
#             Author: DiamondandPlatinum3
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#  Description:
#
#    This Add-On makes it so that your morality metre now shows the offset
#    between good and evil. The more you align yourself to one type of 
#    morality, the further the gauge goes in a certain direction.
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#------------------------------------------------------------------------------
#  Instructions:
#  
#     In the editable region below you can set up what is necessary.
#     Make sure the main morality script is placed anywhere above this 
#     Add-On.
#
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
module DiamondandPlatinum3
  module MoralityMetre
    #===========================================
    #   Editable Region
    #===========================================
    
    # The GAUGE_WIDTH option in the main morality metre editable region
    # is now obsolete and is no longer used, however the rest of the 
    # editable options are still used, so be sure to set them up.
    
    # Values for the colour of the lines that are in between the 
    # Good and Evil Gauges
                                # [ Red,    Green,   Blue,   Opacity  ]
    GAUGE_CENTRE_LINE_COLOUR    = [ 0,       255,     0,       255    ]
    GAUGE_MAX_EVIL_LINE_COLOUR  = [ 100,     0,       0,       255    ]
    GAUGE_MAX_GOOD_LINE_COLOUR  = [ 0,       0,       255,     255    ]
    
    #===========================================
    #   End of Editable Region
    #===========================================
  end
end







#==============================================================================
# ** Window_MoralityMetre
#------------------------------------------------------------------------------
#  Defines the window and its contents
#==============================================================================
class Window_MoralityMetre < Window_Base
  include DiamondandPlatinum3::MoralityMetre
  #--------------------------------------------------------------------------
  # * Refresh
  #--------------------------------------------------------------------------
  def refresh
    contents.clear
    gauge_y_pos = (contents.height - GAUGE_HEIGHT)
    
    # Change Text Colour if 50% Good
    contents.font.out_color = self.get_colour2() if get_should_text_be_outlined?()
    
    # Draw Text
    contents.draw_text( 0, 0, contents.width, 25, self.get_title(), 1 )
    
    # Blur Text if 50% Evil
    contents.blur if get_should_text_be_blured?()

    # Draw Morality Gauge
    draw_evil_gauge(gauge_y_pos)
    draw_good_gauge(gauge_y_pos)
    
    # Fix the Alpha channels
    fix_evil_gauge(gauge_y_pos)
    fix_good_gauge(gauge_y_pos)
    
    # Draw Lines
    draw_left_line(gauge_y_pos)
    draw_centre_line(gauge_y_pos)
    draw_right_line(gauge_y_pos)
  end
  #--------------------------------------------------------------------------
  # * Draw Gauge
  #--------------------------------------------------------------------------
  def draw_gauge(x, y, width, rate, color1, color2)
    fill_w = (width * rate).to_i
    gauge_y = y
    contents.fill_rect(x, gauge_y, width, GAUGE_HEIGHT, gauge_back_color)
    contents.gradient_fill_rect(x, gauge_y, fill_w, GAUGE_HEIGHT, color1, color2, true)
  end
  #--------------------------------------------------------------------------
  # * Draw Evil Gauge
  #--------------------------------------------------------------------------
  def draw_evil_gauge(y)
    width = (contents.width * 0.5)
    draw_gauge(0, y, width, 1.0, self.get_colour1(), self.get_colour2())
  end
  #--------------------------------------------------------------------------
  # * Draw Good Gauge
  #--------------------------------------------------------------------------
  def draw_good_gauge(y)
    width = (contents.width * 0.5)
    x = (contents.width * 0.5)
    draw_gauge(x, y, width, 1.0, self.get_colour1(), self.get_colour2())
  end
  #--------------------------------------------------------------------------
  # * Fix Evil Gauge
  #--------------------------------------------------------------------------
  def fix_evil_gauge(yPos)
    evilness  = $game_variables[MORALITY_VARIABLE_ID].to_f / (MORALITY_VARIABLE_RANGE * 0.5).to_f
    start     = 0
    fin       = (contents.width * 0.5).to_i
    
    for x in 0..fin
      if (x.to_f / fin < evilness)
        for y in yPos..(contents.height)
          # if Pixel is not in range of players evilness level
          # set the alpha of that pixel to zero
          contents.set_pixel(x, y, Color.new(0, 0, 0, 0)) 
        end
      end
    end
  end
  #--------------------------------------------------------------------------
  # * Fix Good Gauge
  #--------------------------------------------------------------------------
  def fix_good_gauge(yPos)
    goodness  = $game_variables[MORALITY_VARIABLE_ID].to_f / (MORALITY_VARIABLE_RANGE * 0.5).to_f
    start     = (contents.width * 0.5).to_i
    fin       = (contents.width).to_i
    
    
    for x in start..fin
      if (x.to_f / start > goodness)
        for y in yPos..(contents.height)
          contents.set_pixel(x, y, Color.new(0, 0, 0, 0)) 
        end
      end
    end
  end
  #--------------------------------------------------------------------------
  # * Draw Centre Line
  #--------------------------------------------------------------------------
  def draw_left_line(yPos)    
    for x in 0..1
      for y in yPos..(contents.height)
        contents.set_pixel(x, y, Color.new(*GAUGE_MAX_EVIL_LINE_COLOUR)) 
      end
    end
  end
  #--------------------------------------------------------------------------
  # * Draw Centre Line
  #--------------------------------------------------------------------------
  def draw_centre_line(yPos)
    xPos = (contents.width * 0.5).to_i
    
    for x in (xPos - 1)..(xPos + 1)
      for y in yPos..(contents.height)
        contents.set_pixel(x, y, Color.new(*GAUGE_CENTRE_LINE_COLOUR)) 
      end
    end
  end
  #--------------------------------------------------------------------------
  # * Draw Centre Line
  #--------------------------------------------------------------------------
  def draw_right_line(yPos)    
    for x in (contents.width - 2)..(contents.width - 1)
      for y in yPos..(contents.height)
        contents.set_pixel(x, y, Color.new(*GAUGE_MAX_GOOD_LINE_COLOUR)) 
      end
    end
  end
end



#--------------------------------------------------------------------------
# * Inform User of Non-working Script
#--------------------------------------------------------------------------
msgbox_p("This script has not detected an active version of DiamondandPlatinum3's Morality Metre.",
         "It's possible you are using an outdated version or you have placed this add-on above that script.",
         "If the latter is the case, please put this script in a slot below the Morality Metre Script"
        ) unless ($diamondandplatinum3_scripts ||= {})[:MoralityMetre_Ver20]