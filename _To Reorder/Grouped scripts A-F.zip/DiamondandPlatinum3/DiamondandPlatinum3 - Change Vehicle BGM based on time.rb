#==============================================================================
#  Change Vehicle BGM based on Time
#  Version: 1.0
#  Author: DiamondandPlatinum3
#  Date: September 1, 2012
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#  Description:
#    This script will allow you to stop the vehicle BGM from playing based on 
#    an event switch, but will also allow you to change the BGM that is played
#    depending on the time of day
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#------------------------------------------------------------------------------
#  Instructions:
#  
#     - Just take a look at the editable region and modify the settings to 
#       suit your needs
#
#       Also Please note that this script was designed to change BGM based on a 
#       24-hour clock, it probably won't work the way you intended if this is 
#       not your case.
#==============================================================================
module DP3_Vehicle_Sound_Options
  #===========================================
  #     Editable Region
  #===========================================
  
  # The ID of the switch which turns off changing the BGM on all vehicles
  Event_Switch_ID     = 10    
  
  # Switch BGM Based on Time?
  SwitchBGMOnTime     = true
  
  # Which Variable is keeping track of your time? 
  TimeTrackVariableID = 10 # This is the same variable you are using to keep track of time
                           
                           
  # If you are switching the BGM based on time, what are you switching them to?   
  
                      #  Name of BGM,  Volume, Pitch
  Midnight_BGMTheme   = [ "Battle1",    100,    100 ]
  OneAM_BGMTheme      = [ "Battle1",    100,    100 ]
  TwoAM_BGMTheme      = [ "Battle1",    100,    100 ]
  ThreeAM_BGMTheme    = [ "Battle1",    100,    100 ]
  FourAM_BGMTheme     = [ "Battle2",    100,    100 ]
  FiveAM_BGMTheme     = [ "Battle2",    100,    100 ]
  SixAM_BGMTheme      = [ "Battle2",    100,    100 ]
  SevenAM_BGMTheme    = [ "Battle2",    100,    100 ]
  EightAM_BGMTheme    = [ "Battle3",    100,    100 ]
  NineAM_BGMTheme     = [ "Battle3",    100,    100 ]
  TenAM_BGMTheme      = [ "Battle3",    100,    100 ]
  ElevenAM_BGMTheme   = [ "Battle3",    100,    100 ]
  Midday_BGMTheme     = [ "Battle4",    100,    100 ]
  OnePM_BGMTheme      = [ "Battle4",    100,    100 ]
  TwoPM_BGMTheme      = [ "Battle4",    100,    100 ]
  ThreePM_BGMTheme    = [ "Battle4",    100,    100 ]
  FourPM_BGMTheme     = [ "Battle5",    100,    100 ]
  FivePM_BGMTheme     = [ "Battle5",    100,    100 ]
  SixPM_BGMTheme      = [ "Battle5",    100,    100 ]
  SevenPM_BGMTheme    = [ "Battle5",    100,    100 ]
  EightPM_BGMTheme    = [ "Battle6",    100,    100 ]
  NinePM_BGMTheme     = [ "Battle6",    100,    100 ]
  TenPM_BGMTheme      = [ "Battle6",    100,    100 ]
  ElevenPM_BGMTheme   = [ "Battle6",    100,    100 ]



#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
 end # of editable region          ////                  ||
#-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=








include DP3_Vehicle_Sound_Options

class Game_Vehicle < Game_Character
  alias dp3_nobgm_during_travel get_on
  def get_on
    if $game_switches[Event_Switch_ID]
      @driving = true
      @walk_anime = true
      @step_anime = true
      @walking_bgm = RPG::BGM.last
    elsif SwitchBGMOnTime
      @driving = true
      @walk_anime = true
      @step_anime = true
      @walking_bgm = RPG::BGM.last
      changevehiclebgmontime
    else
      dp3_nobgm_during_travel
    end
  end
  
  
  
  
  
  def changevehiclebgmontime
    case $game_variables[TimeTrackVariableID]
    when 0 # Midnight
      RPG::BGM.new(Midnight_BGMTheme[0], Midnight_BGMTheme[1], Midnight_BGMTheme[2]).play
    when 1 # One AM
      RPG::BGM.new(OneAM_BGMTheme[0], OneAM_BGMTheme[1], OneAM_BGMTheme[2]).play
    when 2 # Two AM
      RPG::BGM.new(TwoAM_BGMTheme[0], TwoAM_BGMTheme[1], TwoAM_BGMTheme[2]).play
    when 3 # Three AM
      RPG::BGM.new(ThreeAM_BGMTheme[0], ThreeAM_BGMTheme[1], ThreeAM_BGMTheme[2]).play
    when 4 # Four AM
      RPG::BGM.new(FourAM_BGMTheme[0], FourAM_BGMTheme[1], FourAM_BGMTheme[2]).play
    when 5 # Five AM
      RPG::BGM.new(FiveAM_BGMTheme[0], FiveAM_BGMTheme[1], FiveAM_BGMTheme[2]).play
    when 6 # Six AM
      RPG::BGM.new(SixAM_BGMTheme[0], SixAM_BGMTheme[1], SixAM_BGMTheme[2]).play
    when 7 # Seven AM
      RPG::BGM.new(SevenAM_BGMTheme[0], SevenAM_BGMTheme[1], SevenAM_BGMTheme[2]).play
    when 8 # Eight AM
      RPG::BGM.new(EightAM_BGMTheme[0], EightAM_BGMTheme[1], EightAM_BGMTheme[2]).play
    when 9 # Nine AM
      RPG::BGM.new(NineAM_BGMTheme[0], NineAM_BGMTheme[1], NineAM_BGMTheme[2]).play
    when 10 # Ten AM
      RPG::BGM.new(TenAM_BGMTheme[0], TenAM_BGMTheme[1], TenAM_BGMTheme[2]).play
    when 11 # Eleven AM
      RPG::BGM.new(ElevenAM_BGMTheme[0], ElevenAM_BGMTheme[1], ElevenAM_BGMTheme[2]).play
    when 12 # Midday
      RPG::BGM.new(Midday_BGMTheme[0], Midday_BGMTheme[1], Midday_BGMTheme[2]).play
    when 13 # One PM
      RPG::BGM.new(OnePM_BGMTheme[0], OnePM_BGMTheme[1], OnePM_BGMTheme[2]).play
    when 14 # Two PM
      RPG::BGM.new(TwoPM_BGMTheme[0], TwoPM_BGMTheme[1], TwoPM_BGMTheme[2]).play
    when 15 # Three PM
      RPG::BGM.new(ThreePM_BGMTheme[0], ThreePM_BGMTheme[1], ThreePM_BGMTheme[2]).play
    when 16 # Four PM
      RPG::BGM.new(FourPM_BGMTheme[0], FourPM_BGMTheme[1], FourPM_BGMTheme[2]).play
    when 17 # Five PM
      RPG::BGM.new(FivePM_BGMTheme[0], FivePM_BGMTheme[1], FivePM_BGMTheme[2]).play
    when 18 # Six PM
      RPG::BGM.new(SixPM_BGMTheme[0], SixPM_BGMTheme[1], SixPM_BGMTheme[2]).play
    when 19 # Seven PM
      RPG::BGM.new(SevenPM_BGMTheme[0], SevenPM_BGMTheme[1], SevenPM_BGMTheme[2]).play
    when 20 # Eight PM
      RPG::BGM.new(EightPM_BGMTheme[0], EightPM_BGMTheme[1], EightPM_BGMTheme[2]).play
    when 21 # Nine PM
      RPG::BGM.new(NinePM_BGMTheme[0], NinePM_BGMTheme[1], NinePM_BGMTheme[2]).play
    when 22 # Ten PM
      RPG::BGM.new(TenPM_BGMTheme[0], TenPM_BGMTheme[1], TenPM_BGMTheme[2]).play
    when 23 # Eleven PM
      RPG::BGM.new(ElevenPM_BGMTheme[0], ElevenPM_BGMTheme[1], ElevenPM_BGMTheme[2]).play
    else
      system_vehicle.bgm.play
    end
  end
end