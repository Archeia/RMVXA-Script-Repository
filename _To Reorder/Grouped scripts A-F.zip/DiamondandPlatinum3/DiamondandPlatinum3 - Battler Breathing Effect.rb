#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
#             Battler Breathing Effect
#             Version: 1.0
#             Author: DiamondandPlatinum3
#             Date: June 7, 2014
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#  Description:
#
#    This script adds a breathing effect to battlers.
#    This means that enemies will change size when battling in accordance
#    to their breathing.
#
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#------------------------------------------------------------------------------
#  Instructions:
#
#  ~  Modify Editable Region to your liking.
#
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
module DiamondandPlatinum3
  module BattlerBreathe
    #=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
    #                                                        -= 
    #                 Editable Region        ////            ==
    #                                                        =-
    #-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    
    # How long does it take to Breath In/Out? How many Seconds?
    # Note: Inserting a value such as 2.5 quite literally means
    #         two and half seconds
    BreatheTime = 2.0
    
    # How long will the battler stay at a particular size before 
    # breathing in/out again
    BreatheHoldTime = 1.0
    
    
    # The Size of the Battler when they have "Breathed Out" Completely.
    # Note: The Battler by default is size 100. So by putting this value
    #       lower than 100, you are allowing the battler to become smaller
    #       when breathing
    BreatheOutSize = 90
    
    
    # The Size of the Battler when they have "Breathed In" Completely
    BreatheInSize = 105
    
    #-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= 
    #                                           \/
    #               End of Editable Region      /\
    #                                           \/
    #-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
  end
end



#==============================================================================
# ** Sprite_Battler
#------------------------------------------------------------------------------
#  This sprite is used to display battlers. It observes an instance of the
# Game_Battler class and automatically changes sprite states.
#==============================================================================

class Sprite_Battler < Sprite_Base
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # *= Alias Listings 
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  alias_method(:dp3_enemybattlerbreathe_sprbattler_init_kajsbk,   :initialize)
  alias_method(:dp3_enemybattlerbreathe_sprbattler_update_kajsbk, :update)
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * Aliased Method: Object Initialization
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def initialize(*args)
    dp3_enemybattlerbreathe_sprbattler_init_kajsbk(*args)
    
    @dp3_breathing_stage    = rand(4)
    @dp3_breathe_timer      = DPCore::TimeTracker.new(DiamondandPlatinum3::BattlerBreathe::BreatheTime)
    @dp3_breathe_wait_timer = DPCore::TimeTracker.new(DiamondandPlatinum3::BattlerBreathe::BreatheHoldTime)
    @dp3_min_battler_size   = DiamondandPlatinum3::BattlerBreathe::BreatheOutSize.to_f / 100.0
    @dp3_max_battler_size   = DiamondandPlatinum3::BattlerBreathe::BreatheInSize.to_f / 100.0
    
    
    self.zoom_x = @dp3_min_battler_size
    self.zoom_y = @dp3_min_battler_size
  end
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * Aliased Method: Frame Update
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def update(*args)
    dp3_enemybattlerbreathe_sprbattler_update_kajsbk(*args)
    dp3_update_breathing_effect() if @battler && @use_sprite
  end
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * New Method: Update Breathing Effect
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def dp3_update_breathing_effect
    if @dp3_breathing_stage == 1 # Breathing in
      @dp3_breathe_timer.update()
      if @dp3_breathe_timer.time_up?()
        @dp3_breathe_timer.reset()
        self.zoom_x = @dp3_max_battler_size
        self.zoom_y = @dp3_max_battler_size
        @dp3_breathing_stage = 2
      else
        self.zoom_x = (@dp3_min_battler_size + ((@dp3_max_battler_size - @dp3_min_battler_size) * @dp3_breathe_timer.get_completion_percentage()))
        self.zoom_y = self.zoom_x
      end
      
    elsif @dp3_breathing_stage == 2 # Hold in Breath
      @dp3_breathe_wait_timer.update()
      if @dp3_breathe_wait_timer.time_up?()
        @dp3_breathe_wait_timer.reset()
        @dp3_breathing_stage = 3
      end
      
    elsif @dp3_breathing_stage == 3 # Breathing Out
      @dp3_breathe_timer.update()
      if @dp3_breathe_timer.time_up?()
        @dp3_breathe_timer.reset()
        self.zoom_x = @dp3_min_battler_size
        self.zoom_y = @dp3_min_battler_size
        @dp3_breathing_stage = 4
      else
        self.zoom_x = (@dp3_max_battler_size - ((@dp3_max_battler_size - @dp3_min_battler_size) * @dp3_breathe_timer.get_completion_percentage()))
        self.zoom_y = self.zoom_x
      end
      
    else  # Hold Out Breathe
      @dp3_breathe_wait_timer.update()
      if @dp3_breathe_wait_timer.time_up?()
        @dp3_breathe_wait_timer.reset()
        @dp3_breathing_stage = 1
      end
    end
  end
end



unless ($diamondandplatinum3scripts ||= {})[:TimeTracker]
  
#=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=
# **  New Class:   Time Tracker
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Once initialised, this class keeps track of time in seconds.
# All instances of the TimeTracker class are updated automatically if you
# have chosen to allow themselves to be added to the list (true by default).
#
# Once initialised, simply call the ' time_up? ' method to see if the time
# is up for this TimeTracker.
# Call ' dispose ' once finished.
#~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~
($diamondandplatinum3scripts ||= {})[:TimeTracker] = true
#~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~
module DPCore
  class TimeTracker
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # *+ Public Instance Variables
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    attr_reader :current_frame  # Current Frame the Tracker is on: Use to Reset Tracker.
    attr_reader :seconds        # Seconds until TimeUp: Change to Increase/Decrease the Wait Time.
    attr_reader :scenetype      # Scenetype: If not nil, this TimeTracker will only Update if SceneManager is in that Specified Scene.
    
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # *- Private Static Variables
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @@timetracker_list = []     # Static Variable List/Array containing active instances of TimeTrackers

    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # * New Method:   Object Initialisation
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # Time:             How long (in seconds) until this TimeTracker has been successful
    # Scene Class:      Which Scene Can this TimeTracker be updated in : nil by default, which means it can always be updated no matter what scene it is.
    # Add Self To List: Add Self to the Automatic Update List? : false by default. If not true, you need to update the TimeTracker manually
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def initialize(time, scene_class = nil, add_self_to_list = false)
      @current_time   = 0.0
      @finish_time    = time.to_f
      @scenetype      = scene_class
      @time_up        = false
      
      @@timetracker_list.push(self) if add_self_to_list
    end
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # * New Method:   Dispose
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def dispose()
      @@timetracker_list.reject! { |tracker| tracker == self }
    end
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # * New Method:   Update
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def update()
      if !@time_up
        @current_time  += (1.0 / Graphics.frame_rate)
        @time_up        = (@current_time > @finish_time)
        @current_time   =  @finish_time if @time_up
      end
    end
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # * New Method:   Reset
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def reset()
      @current_time = 0.0
      @time_up      = false
    end
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # * New Method:   Set Current Time
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def set_current_time(time)
      @current_time = time
      @time_up      = (@current_time > @finish_time)
      @current_time =  @finish_time if @time_up
    end
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # * New Method:   Set Finish Time
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def set_finish_time(time)
      @finish_time  = time
      @time_up      = (@current_time > @finish_time)
      @current_time =  @finish_time if @time_up
    end
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # * New Method:   Get Current Time (in seconds)
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def get_current_time()
      return @current_time
    end
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # * New Method:   Is Time Up?
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def time_up?()
      return @time_up
    end
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # * New Method:   Get Total Completion Percentage
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def get_completion_percentage()
      return (@current_time / @finish_time)
    end
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # * New Method:   Get TimeTracker List
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def self.get_timetracker_list()
      return @@timetracker_list
    end
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # * New Method:   Update TimeTrackers
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def self.update_timetrackers()
      @@timetracker_list.each do |tracker|
        tracker.update() unless !tracker.scenetype.nil? && 
                                  !SceneManager.scene_is?(tracker.scenetype)
      end
    end
  end
end

end