#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
#             Character's Name Window
#             Version: 1.0
#             Authors: DiamondandPlatinum3
#             Date: January 19, 2013
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#  Description:
#
#    This script creates a character name window for when someone is talking.
#    Using a script call or an Escape Character is your ticket to changing
#    the displayed name.
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#------------------------------------------------------------------------------
#  Instructions:
#  
#     Edit the two options in the editable region below. Once done, to display a
#     name in your game you simply either have to use the following script call:
#         change_charactername( name )
#     Replacing 'name' with the "Name' you wish to be displayed.
#
#     The other way is to use an escape character when you show a message box
#         \n{NAME}
#
#
#     Screenshot Example can be found here: http://goo.gl/PRpo5
#
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
module DiamondandPlatinum3
  module CharacterNamesForWindows
    #=======================================
    #     Editable Region
    #=======================================
   
    # Turning on this event switch turns off the name window
    EventSwitchID = 10
   
    # RGB Values for the colour of the text in the window.
    Colour = [ 255, 214, 104 ]
   
    #=======================================
    #   End Editable Region
    #=======================================
   
   
   
   
   
   
   
   
   
   
   
    CharacterName = "???"
    ShowWindow    = true    
    def self.change_character_name( name )
      self.const_set(:CharacterName, name) if name.is_a?(String)
    end
    def self.change_show_window( bool )
      self.const_set(:ShowWindow, bool)
    end
  end
end
 
 
 
 
 
#==============================================================================
# ** Window_Message
#------------------------------------------------------------------------------
#  This message window is used to display text.
#==============================================================================
 
class Window_Message < Window_Base
  #--------------------------------------------------------------------------
  # * Alias Listings
  #--------------------------------------------------------------------------
  alias dp3_characternames_windowmessage_fibermain_02isk0u                   fiber_main
  alias dp3_characternames_windowmessage_convertescapecharacter_02isk0u      convert_escape_characters
  #--------------------------------------------------------------------------
  # * Main Processing of Fiber
  #--------------------------------------------------------------------------
  def fiber_main
    dp3_characternames_windowmessage_fibermain_02isk0u() # Call Original Method
    @dp3_charaname_window.dispose() if @dp3_charaname_window && !@dp3_charaname_window.disposed?
  end
  #--------------------------------------------------------------------------
  # * Preconvert Control Characters
  #--------------------------------------------------------------------------
  def convert_escape_characters( *args )
    result = dp3_characternames_windowmessage_convertescapecharacter_02isk0u( *args )
    result.gsub!(/\eN{(.+)}/i, "")
   
    DiamondandPlatinum3::CharacterNamesForWindows::change_character_name( $1 ) if $1 && $1 != ""
    @dp3_charaname_window.dispose() if @dp3_charaname_window && !@dp3_charaname_window.disposed?
    @dp3_charaname_window = Window_DP3_CharacterNames.new( self.x, self.y, self.height, @position )
   
    return result
  end
end
 
 
 
 
#==============================================================================
# ** Window_DP3_CharacterNames
#------------------------------------------------------------------------------
#  This Window is used to display character names where they are to be located
#==============================================================================
 
class Window_DP3_CharacterNames < Window_Base
  include DiamondandPlatinum3::CharacterNamesForWindows
  #--------------------------------------------------------------------------
  # * Initialize
  #--------------------------------------------------------------------------
  def initialize( x, y, h, position )
    appropriate_scene = SceneManager.scene_is?(Scene_Map) || SceneManager.scene_is?(Scene_Battle)
    if $game_switches[EventSwitchID] || !ShowWindow || !appropriate_scene
      self.dispose()
      return
    end
    @text = " " + CharacterName
    self_width  = (@text.length * 11) + 32
    self_height = 45
    if position == 0
      super(x, h, self_width, self_height)
    else
      super(x, y - self_height, self_width, self_height)
    end
    self.z = 201
    self.opacity = $game_message.background == 0 ? 255 : 0
    create_back_sprite()
    self.refresh
  end
  #--------------------------------------------------------------------------
  # * Dispose
  #--------------------------------------------------------------------------
  def dispose()
    if @back_sprite
      @back_sprite.bitmap.dispose
      @back_sprite.dispose
    end
    super()
  end
  #--------------------------------------------------------------------------
  # * Refresh
  #--------------------------------------------------------------------------
  def refresh()
    self.contents.clear
    self.change_color(Color.new(*Colour))
    self.draw_text(0, 0, self.width - 32, line_height, @text)
  end
  #--------------------------------------------------------------------------
  # * Create Background Sprite
  #--------------------------------------------------------------------------
  def create_back_sprite()
    if $game_message.background == 1
      
      back_bitmap = Bitmap.new(width, height)
      rect1 = Rect.new(0, 0, width, 12)
      rect2 = Rect.new(0, 12, width, height - 24)
      rect3 = Rect.new(0, height - 12, width, 12)
      back_bitmap.gradient_fill_rect(rect1, back_color2, back_color1, true)
      back_bitmap.fill_rect(rect2, back_color1)
      back_bitmap.gradient_fill_rect(rect3, back_color1, back_color2, true)
      
      @back_sprite          = Sprite.new
      @back_sprite.bitmap   = back_bitmap
      @back_sprite.visible  = true
      @back_sprite.y        = y
      @back_sprite.z        = z - 1
      @back_sprite.opacity  = openness
    end
  end
  #--------------------------------------------------------------------------
  # * Get Background Colours
  #--------------------------------------------------------------------------
  def back_color1();  Color.new(0, 0, 0, 160);  end
  def back_color2();  Color.new(0, 0, 0, 0);    end
end
 
 
 
 
 
#==============================================================================
# ** Scene_Battle
#------------------------------------------------------------------------------
#  This class performs battle screen processing.
#==============================================================================
 
class Scene_Battle < Scene_Base
  #--------------------------------------------------------------------------
  # * Alias Listings
  #--------------------------------------------------------------------------
  alias dp3_characternames_scenebattle_start_02isk0u                start
  alias dp3_characternames_scenebattle_terminate_02isk0u            terminate
  #--------------------------------------------------------------------------
  # * Start Processing
  #--------------------------------------------------------------------------
  def start
    DiamondandPlatinum3::CharacterNamesForWindows::change_show_window(false)
    dp3_characternames_scenebattle_start_02isk0u() # Call Original Method
  end
  #--------------------------------------------------------------------------
  # * Termination Processing
  #--------------------------------------------------------------------------
  def terminate
    DiamondandPlatinum3::CharacterNamesForWindows::change_show_window(true)
    dp3_characternames_scenebattle_terminate_02isk0u() # Call Original Method
  end
end
 
 
 
 
 
#==============================================================================
# ** Scene_Title
#------------------------------------------------------------------------------
#  This class performs the title screen processing.
#==============================================================================
 
class Scene_Title < Scene_Base
  #--------------------------------------------------------------------------
  # * Alias Listings
  #--------------------------------------------------------------------------
  alias dp3_characternames_scenetitle_cmdnewgame_02isk0u     command_new_game
  alias dp3_characternames_scenetitle_cmdcontinue_02isk0u    command_continue
  #--------------------------------------------------------------------------
  # * [New Game] Command
  #--------------------------------------------------------------------------
  def command_new_game
    DiamondandPlatinum3::CharacterNamesForWindows::change_character_name( "???" )
    DiamondandPlatinum3::CharacterNamesForWindows::change_show_window( true )
    dp3_characternames_scenetitle_cmdnewgame_02isk0u() # Call Original Method
  end
  #--------------------------------------------------------------------------
  # * [Continue] Command
  #--------------------------------------------------------------------------
  def command_continue
    DiamondandPlatinum3::CharacterNamesForWindows::change_character_name( "???" )
    DiamondandPlatinum3::CharacterNamesForWindows::change_show_window( true )
    dp3_characternames_scenetitle_cmdcontinue_02isk0u() # Call Original Method
  end
end
 
 
 
 
 
#==============================================================================
# ** Game_Interpreter
#------------------------------------------------------------------------------
#  An interpreter for executing event commands. This class is used within the
# Game_Map, Game_Troop, and Game_Event classes.
#==============================================================================
 
class Game_Interpreter
  #--------------------------------------------------------------------------
  # * Aliased Method: Show Text
  #--------------------------------------------------------------------------
  alias dp3_characternames_gameinterpreter_command101_02isk0u     command_101
  def command_101()
    DiamondandPlatinum3::CharacterNamesForWindows::change_show_window(true) if SceneManager.scene_is?(Scene_Battle)
    dp3_characternames_gameinterpreter_command101_02isk0u() # Call Original Method
    DiamondandPlatinum3::CharacterNamesForWindows::change_show_window(false) if SceneManager.scene_is?(Scene_Battle)
  end
  #--------------------------------------------------------------------------
  # * New Method: Change Character Name
  #--------------------------------------------------------------------------
  def change_charactername( text )
    DiamondandPlatinum3::CharacterNamesForWindows::change_character_name( text )
  end
end