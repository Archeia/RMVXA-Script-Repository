$imported["AE-CatNip"] = true
#===============================================================================
# AE - Alistair Engine
#===============================================================================
# Cat Nip
# Version: 1.2
#
# Changelog:
# 1.0 - First Version
# 1.1 - You may now set the damage of Cat Nip individually for each tag
# 1.2 - Notetag can now work with skills
#     - The damage increase may now be percental
#===============================================================================
# Instructions:
# Insert this script above Main and below Materials.
# Place it below all Yanfly Scripts. If it doesn't work, try placing it
# at the very end.
# 
# Adjust the settings in the script to your liking. Then use the stated
# Notetag to activate the script.
#
#===NOTETAGS===================================================================
#---> Items, Skills, Weapons, Armours, States <---
#
# <catnip>
# This notetag enables catnip capability. If you use this tag, it will
# take the value stored in CATNIP_DAMAGE below.
#
# <catnip: x>
# This notetag enables catnip capability.
# x = damage dealt.
#
# <catnip: %x>
# This notetag enables catnip capability. It will increase the final damage
# by x%.
#
#===SCRIPT=CALLS================================================================
#
# | NONE
#
#===============================================================================
module AE
  module CN
    
    CATNIP_DAMAGE = 9999
    # Damage dealt if catnip is active and no damage was specified.
    
    HP_CRISIS = 0.25
    # From this value downwards HP is considered critical.
    # 1    = 100%
    # 0.5  = 50%
    # 0.25 = 25%
    # 0.1  = 10%
    # ..........
    
  end # CN
end # AE
#===============================================================================
# Editting anything past this point may result in a crash. So only go on if you
# know what you are doing.
#===============================================================================
class RPG::Skill
  
  attr_accessor :catnip
  attr_accessor :catnip_percental
  
  def catnip
    @catnip = [false, 0]
    if @note =~ /<catnip>/
      @catnip = [true, AE::CN::CATNIP_DAMAGE]
    end # if
    if @note =~ /<catnip:[ ](\d+)>/
      @catnip = [true, $1.to_i]
    end # if
    @catnip
  end # def
  
  def catnip_percental
    @catnip_percental = [false, 0]
    if @note =~ /<catnip:[ ]%(\d+)>/i
      @catnip_percental = [true, $1.to_i]
    end # if
    @catnip_percental
  end # def
  
end # class
#===============================================================================
class RPG::Item
  
  attr_accessor :catnip
  attr_accessor :catnip_percental
  
  def catnip
    @catnip = [false, 0]
    if @note =~ /<catnip>/
      @catnip = [true, AE::CN::CATNIP_DAMAGE]
    end # if
    if @note =~ /<catnip:[ ](\d+)>/
      @catnip = [true, $1.to_i]
    end # if
    @catnip
  end # def
  
  def catnip_percental
    @catnip_percental = [false, 0]
    if @note =~ /<catnip:[ ][%](\d+)>/i
      @catnip_percental = [true, $1.to_i]
    end # if
    @catnip_percental
  end # def
  
end # class
#===============================================================================
class RPG::EquipItem
  
  attr_accessor :catnip
  attr_accessor :catnip_percental
  
  def catnip
    @catnip = [false, 0]
    if @note =~ /<catnip>/
      @catnip = [true, AE::CN::CATNIP_DAMAGE]
    end # if
    if @note =~ /<catnip:[ ](\d+)>/
      @catnip = [true, $1.to_i]
    end # if
    @catnip
  end # def
  
  def catnip_percental
    @catnip_percental = [false, 0]
    if @note =~ /<catnip:[ ][%](\d+)>/i
      @catnip_percental = [true, $1.to_i]
    end # if
    @catnip_percental
  end # def
  
end # class
#===============================================================================
class RPG::State
  
  attr_accessor :catnip
  attr_accessor :catnip_percental
  
   def catnip
    @catnip = [false, 0]
    if @note =~ /<catnip>/
      @catnip = [true, AE::CN::CATNIP_DAMAGE]
    end # if
    if @note =~ /<catnip:[ ](\d+)>/
      @catnip = [true, $1.to_i]
    end # if
    @catnip
  end # def
  
  def catnip_percental
    @catnip_percental = [false, 0]
    if @note =~ /<catnip:[ ][%](\d+)>/i
      @catnip_percental = [true, $1.to_i]
    end # if
    @catnip_percental
  end # def
  
end # class
#===============================================================================
class Game_Battler
  
  def crisis?(user)
    return true if user.hp < user.mhp * AE::CN::HP_CRISIS
    return false
  end # def
  
  def make_damage_value(user, item)
    @catnip = [false, 0]
    @catnip_percental = 100
    a_ae = []
    a_ae.push(item.catnip[1])
    @catnip_percental += item.catnip_percental[1]
    for equip in user.equips
      next if equip.nil?
      a_ae.push(equip.catnip[1])
      @catnip[1] = a_ae.max
      @catnip_percental += equip.catnip_percental[1]
      if @catnip[1] != 0
        @catnip[0] = true
      end # if
    end # for
    for state in user.states
      next if state.nil?
      a_ae.push(state.catnip[1])
      @catnip[1] = a_ae.max
      @catnip_percental += state.catnip_percental[1]
      if @catnip[1] != 0
        @catnip[0] = true
      end # if
    end # for
    value = item.damage.eval(user, self, $game_variables)
    value *= item_element_rate(user, item)
    value *= pdr if item.physical?
    value *= mdr if item.magical?
    value *= rec if item.damage.recover?
    value = apply_critical(value) if @result.critical
    value = apply_variance(value, item.damage.variance)
    value = apply_guard(value)
    if crisis?(user) && @catnip[0]
      if value < 0
        value = -@catnip[1]
      end # if
      if value > 0
        value = @catnip[1]
      end # if
      if value == 0
        return
      end # def
    end # if
    value *= (@catnip_percental * 0.01) if crisis?(user)
    if $imported["YEA-BattleEngine"]
    @result.make_damage(value.to_i, item)
    rate = item_element_rate(user, item)
    make_rate_popup(rate) unless $game_temp.evaluating
    end # if
  end # def
  
end # class
#===============================================================================
# End of Script@
#===============================================================================