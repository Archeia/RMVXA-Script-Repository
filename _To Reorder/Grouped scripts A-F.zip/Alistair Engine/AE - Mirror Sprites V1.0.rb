$imported["AE-MirrorSprites"] = true
#===============================================================================
# AE - Alistair Engine
#===============================================================================
# Mirror Sprites
# Version: 1.0
# Changelog:
# 1.0 - First version
#===============================================================================
# Instructions:
# This script allows you to mirror enemy sprites.
#
#===NOTETAGS===================================================================
#---> For Enemies <---
#
# <mirror>
# Sprite of this enemy will be mirrored.
#
#===SCRIPT CALLS================================================================
# | NONE
#===TERMS OF USE================================================================
# Please make sure to read my Terms of Use if you plan to use this script
# in a public project of yours, be it commercial or not.
#
# https://www.dropbox.com/s/0e9d1eo62lgxbip/Terms%20of%20Use.txt?dl=0
#
#===============================================================================
module AE
  module MS
  end # MS
end # AE
#===============================================================================
# Editting anything past this point may result in a crash. So only go on if you
# know what you are doing.
#===============================================================================
class RPG::Enemy
  
  attr_accessor :mirror
  
  def mirror
    @mirror = false
    if @note =~ /<mirror>/i
      @mirror = true
    end # if
    @mirror
  end # def
  
end # class
#===============================================================================
class Game_Enemy < Game_Battler
  
  def mirror
    return enemy.mirror
  end # def
  
end # class
#===============================================================================
class Sprite_Battler < Sprite_Base
  
  alias initialize_ae initialize
  def initialize(viewport, battler = nil)
    initialize_ae(viewport, battler)
    self.mirror = @battler.mirror if @battler != nil
  end # def
  
end # class
#===============================================================================
# End of Script@
#===============================================================================