#===============================================================================
# AE - Alistair Engine
#===============================================================================
# Code Snippet: Heal Stat
# Version: 1.0
#
# Changelog:
# 1.0 - First Version
#===============================================================================
# Instructions:
# Place the code snippet into YEA - Lunatic Damage above the part where it says
# "Stop editing past this point". That's somewhere around line 143 by default.
#
#===NOTETAGS===================================================================
#---> Skills <---
#
# <heal x: user: y%, target: z%, else: a%, b>
# Will use the user's x (x = MHP, MMP, HP, MP, ATK, DEF, MAT, MDF, AGI or LUK)
# as the base to heal everyone in the party for the specified percentage of x.
# The user will heal y% of x, unless he's the target. In that case he will heal z%.
# The target will heal z%. Any other hero not directly targeted will heal a%.
#
# Please take note: The last part of the note tag (, b) is optional. Anything
# you put in there will be evaluated and be used as the healing. If you don't
# want to use an eval, just close the notetag with ">" after a%.
#
# Example Notetag:
# <custom damage: heal atk: user: 100%, target: 50%, else: 0%>
# This skill will heal the user for 100% of his atk. Unaffected party members will heal
# 0% (nothing). The target will heal 50% of the user's atk.
#===SCRIPT=CALLS================================================================
#
# | NONE
#
#===============================================================================


#  You should copy everything that's below this line! Don't copy my header, it will just unneccesarily bloat
#  your script!

   when /HEAL (.*):[ ]USER:[ ](\d+)%,[ ]TARGET:[ ](\d+)%,[ ]ELSE:[ ](\d+)%(?:,(.*))*/i
        value += item.damage.eval(user, self, $game_variables)
        case $1.to_s.upcase
        when "MHP"
          heal = user.mhp
        when "MMP"
          heal = user.mmp
        when "HP"
          heal = user.hp
        when "MP"
          heal = user.mp
        when "ATK"
          heal = user.atk
        when "DEF"
          heal = user.def
        when "MAT"
          heal = user.mat
        when "MDF"
          heal = user.mdf
        when "AGI"
          heal = user.agi
        when "LUK"
          heal = user.luk
        end # case
        unless $5.to_s.empty?
          heal = eval($5.to_s)
        end # unless
        user_heal = (heal * ($2.to_i * 0.01)).round
        target_heal = (heal * ($3.to_i * 0.01)).round
        else_heal = (heal * ($4.to_i * 0.01)).round
        party = []
        party = $game_party.battle_members
        user_actor, target = a, b
        party.delete(user_actor)
        party.delete(target)
        else_hero = party
        # Heal user
        if user == target
        user_actor.hp += target_heal
        txt_heal = target_heal
        else
        user_actor.hp += user_heal
        txt_heal = user_heal
        end # if
        if $imported["YEA-BattleEngine"] && user_heal > 0
        text = sprintf(YEA::BATTLE::POPUP_SETTINGS[:hp_heal], txt_heal.group)
        user_actor.create_popup(text, "HP_HEAL")
        end # if
        # Heal target
        unless target == user
        target.hp += target_heal
        if $imported["YEA-BattleEngine"] && target_heal > 0
        text = sprintf(YEA::BATTLE::POPUP_SETTINGS[:hp_heal], target_heal.group)
        target.create_popup(text, "HP_HEAL")
        end # if
        end # unless
        # Heal everyone else
        else_hero.each do |hero|
          hero.hp += else_heal
          if $imported["YEA-BattleEngine"] && else_heal > 0
          text = sprintf(YEA::BATTLE::POPUP_SETTINGS[:hp_heal], else_heal.group)
          hero.create_popup(text, "HP_HEAL")
          end # if
        end # do