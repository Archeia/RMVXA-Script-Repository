$imported["AE-CustomPrices"] = true
#===============================================================================
# AE - Alistair Engine
#===============================================================================
# AE - Custom Prices
# Version: 1.1.1
# Changelog:
# 1.0 - First version
# 1.1 - You may now use note tags to change the default purchase price
# 1.1.1 - You may now stop a "rand" formula from changing the price all the time
#       - Fixed wrong module name crash (D'oh...)
#===============================================================================
# Instructions:
#
# Use the stated notetags for the script to show an effect.
#
# This script allows you to set your own sale prices.
# If you don't like the default formula "purchase_price / 2" you can easily 
# change it below. 
#
# If you like you can use discounts as well by changing the variables
# below accordingly in game.
#
#
#
#*IMPORTANT:********************************************************************
# Don't forget to set SELL_DISCOUNT_VARIABLE and BUY_DISCOUNT_VARIABLE
# to a value of your liking in game! If these variables equal 0 in the game, all
# your items will be free!!!
#
#
#
#===NOTE-TAGS===================================================================
#---> Items, Weapons, Armours <---
# <sale: x>
# Replace x with the sale price. Whatever you put in will run through an eval, so
# you might as well replace x with a formula.
# Example:
# <sale: $game_variables[25] * 4>
#
# <buy: x>
# Replace x with the purchase price. 
# Whatever you put in will run through an eval, so you might as well 
# replace x with a formula.
# Example:
# <buy: $game_actors[12].atk * 4>
#
#===SCRIPT-CALLS================================================================
#
# | NONE
#
#===TERMS OF USE================================================================
# Please make sure to read my Terms of Use if you plan to use this script
# in a public project of yours, be it commercial or not.
#
# https://www.dropbox.com/s/0e9d1eo62lgxbip/Terms%20of%20Use.txt?dl=0
#
#===============================================================================
module AE
  module CP
    
    DEFAULT_SALE_PRICE = "purchase_price / 2"
    # Every object without a notetag will use this sale price.
    # RPG VX Ace uses this by default: "price / 2"
    
    SELL_DISCOUNT_VARIABLE = 6
    # This determines the percentage that's applied to each sale price.
    # Example:
    # Variable 6 = 50
    # Since it is treated as a percentage, that'll mean the sale price will
    # be halved.
    # Variable 6 = 150
    # This means every item that you sell will be worth 50% more.
    
    BUY_DISCOUNT_VARIABLE = 5
    # This determines the percentage that's applied to each price when you buy
    # something from a vendor.
    # Example:
    # Variable 5 = 50
    # Since it is treated as a percentage, that'll mean the price will
    # be halved.
    # Variable 5 = 150
    # This means every item that you buy will cost 50% more.
    
    PREVENT_REROLL = false
    # If one of your items uses a "rand" in their price formula, its price
    # will be rerolled everytime the game gets the item's price. If you want
    # to prevent the game from rerolling the price set this to true.
    
  end # CP
end # AE
#===============================================================================
# Editting anything past this point may result in a crash. So only go on if you
# know what you are doing.
#===============================================================================
class RPG::EquipItem
  
  # public instance variables
  attr_accessor :custom_price
  attr_accessor :purchase_price
  
  # new method: custom_price
  def custom_price
    @custom_price = nil unless defined? @custom_price
    if @note =~ /<sale: (.*)>/i
      @custom_price = eval($1.to_s) unless $1.to_s.include?("rand") && AE::CP::PREVENT_REROLL && @custom_price != nil
      if AE::CP::SELL_DISCOUNT_VARIABLE > 0
      @discount_eq = ($game_variables[AE::CP::SELL_DISCOUNT_VARIABLE] * 0.01).round
      @custom_price *= @discount_eq
      end # if
    else
      @custom_price = eval(AE::CP::DEFAULT_SALE_PRICE)
      if AE::CP::SELL_DISCOUNT_VARIABLE > 0
      @discount_eq = ($game_variables[AE::CP::SELL_DISCOUNT_VARIABLE] * 0.01).round
      @custom_price *= @discount_eq
      end # if
    end # if
    @custom_price
  end # def
  
  # new method: purchase_price
  def purchase_price
    @purchase_price = nil unless defined? @purchase_price
    if @note =~ /<buy: (.*)>/i
      @purchase_price = eval($1.to_s) unless $1.to_s.include?("rand") && AE::CP::PREVENT_REROLL && @purchase_price != nil
      if AE::CP::BUY_DISCOUNT_VARIABLE > 0
      @discount_eqp = ($game_variables[AE::CP::BUY_DISCOUNT_VARIABLE] * 0.01).round
      @purchase_price *= @discount_eqp
      end # if
    else
      @purchase_price = self.price
      if AE::CP::BUY_DISCOUNT_VARIABLE > 0
      @discount_eqp = ($game_variables[AE::CP::BUY_DISCOUNT_VARIABLE] * 0.01).round
      @purchase_price *= @discount_eqp
      end # if
    end # if
    @purchase_price
  end # def
  
end # class
#===============================================================================
class RPG::Item
  
  # public instance variables
  attr_accessor :custom_price
  attr_accessor :purchase_price
  
  # new method: custom_price
  def custom_price
    @custom_price = nil unless defined? @custom_price
    if @note =~ /<sale: (.*)>/i
      @custom_price = eval($1.to_s) unless $1.to_s.include?("rand") && AE::CP::PREVENT_REROLL && @custom_price != nil
    else
      @custom_price = eval(AE::CP::DEFAULT_SALE_PRICE)
    end # if
    if AE::CP::SELL_DISCOUNT_VARIABLE > 0
      @custom_price *= $game_variables[AE::CP::SELL_DISCOUNT_VARIABLE] * 0.01
    end # if
    @custom_price.round
  end # def    
  
  def purchase_price
    @purchase_price = nil unless defined? @purchase_price
    if @note =~ /<buy: (.*)>/i
      @purchase_price = eval($1.to_s) unless $1.to_s.include?("rand") && AE::CP::PREVENT_REROLL && @purchase_price != nil
      if AE::CP::BUY_DISCOUNT_VARIABLE > 0
      @discount_eqp = ($game_variables[AE::CP::BUY_DISCOUNT_VARIABLE] * 0.01).round
      @purchase_price *= @discount_eqp
      end # if
    else
      @purchase_price = self.price
      if AE::CP::BUY_DISCOUNT_VARIABLE > 0
      @discount_eqp = ($game_variables[AE::CP::BUY_DISCOUNT_VARIABLE] * 0.01).round
      @purchase_price *= @discount_eqp
      end # if
    end # if
    @purchase_price
  end # def
  
end # class
#===============================================================================
class Scene_Shop
  
  # overwrite method: selling_price
  def selling_price
    @item.custom_price
  end # def
  
end # class
#===============================================================================
class Window_ShopBuy < Window_Selectable
  
  # overwrite method: price
  def price(item)
    n = item.purchase_price
    return n
  end # def
  
end # class
#===============================================================================
class Window_ShopSell
  
  def enable?(item)
    item && item.custom_price > 0
  end # def
  
end # class
#===============================================================================
# End of Script
#===============================================================================