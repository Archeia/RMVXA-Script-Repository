#===============================================================================
# AE - Alistair Engine
#===============================================================================
# Code Snippet: Lose MP
# Version: 1.0
#
# Changelog:
# 1.0 - First Version
#===============================================================================
# Instructions:
# Place the code snippet into YEA - Lunatic States above the part where it says
# "Stop editing past this point". That's somewhere around line 188 by default.
#
#===NOTETAGS===================================================================
#---> States <---
#
# <lose_mp +x> or <lose_mp -x>
# This will either increase or decrease the battler's MP by x.
#
#===SCRIPT=CALLS================================================================
#
# | NONE
#
#===============================================================================


#  You should copy everything that's below this line! Don't copy my header, it will just unneccesarily bloat
#  your script!

    when /LOSE_MP[ ]([\+\-]\d+)/i
      self.mp += $1.to_i
      if $1.to_i < 0 && $imported["YEA-BattleEngine"]
        text = sprintf(YEA::BATTLE::POPUP_SETTINGS[:mp_dmg], $1.to_i.abs.group)
        self.create_popup(text, "MP_DMG")
      else
        text = sprintf(YEA::BATTLE::POPUP_SETTINGS[:mp_heal], $1.to_i.abs.group)
        self.create_popup(text, "MP_HEAL")
      end # if