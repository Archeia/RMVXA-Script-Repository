#===============================================================================
# AE - Alistair Engine
#===============================================================================
# Code Snippet: Attacker State
# Version: 1.0
#
# Changelog:
# 1.0 - First Version
#===============================================================================
# Instructions:
# Place the code snippet into YEA - Lunatic States above the part where it says
# "Stop editing past this point". That's somewhere around line 188 by default.
#
#===NOTETAGS===================================================================
#---> States <---
#
# <attacker_state: x y%>
# The attacking battler will have state x added with a probability of y%.
#
# Example Notetag:
# <react effect: attacker_state: 3 100%>
# The attacking battler will have state 3 added with a probability of 100%.
#===SCRIPT=CALLS================================================================
#
# | NONE
#
#===============================================================================


#  You should copy everything that's below this line! Don't copy my header, it will just unneccesarily bloat
#  your script!

   when /ATTACKER_STATE:[ ](\d+)[ ](\d+)%/i
      return unless @result.hp_damage > 0
      subject = SceneManager.scene.subject
      if subject.actor?
        target = subject
      end # if
      if subject.enemy?
        target = $game_troop.members[subject.index]
      end # if
      if rand < $2.to_i * 0.01
        target.add_state($1.to_i)
        remove_state(state.id)
      end # if