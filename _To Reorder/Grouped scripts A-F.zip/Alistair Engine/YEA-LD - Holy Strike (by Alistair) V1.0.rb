#===============================================================================
# AE - Alistair Engine
#===============================================================================
# Code Snippet: Holy Strike
# Version: 1.0
#
# Changelog:
# 1.0 - First Version
#===============================================================================
# Instructions:
# Place the code snippet into YEA - Lunatic Damage above the part where it says
# "Stop editing past this point". That's somewhere around line 143 by default.
#
#===NOTETAGS===================================================================
#---> Skills <---
#
# <holy_strike: x%>
# The battler with the lowest HP will be healed for x% of the damage.
#
# Example Notetag:
# <custom damage: holy_strike: 50%>
# The attack will heal the hero with the lowest HP for 50% of the damage done.
#===SCRIPT=CALLS================================================================
#
# | NONE
#
#===============================================================================


#  You should copy everything that's below this line! Don't copy my header, it will just unneccesarily bloat
#  your script!

   when /HOLY_STRIKE:[ ](\d+)%/i
        value += item.damage.eval(user, self, $game_variables)
        @lowest_hp = []
        $game_party.battle_members.each do |actor|
        @lowest_hp.push(actor.hp_rate) if actor.hp > 0
        end # do
        for actor in $game_party.battle_members
          next if actor.nil?
          if actor.hp_rate == @lowest_hp.min
            @healing = value * $1.to_i / 100
            actor.hp += @healing
            if $imported["YEA-BattleEngine"]
              text = sprintf(YEA::BATTLE::POPUP_SETTINGS[:hp_heal], @healing.group)
              actor.create_popup(text, "HP_HEAL")
            end # if
            break
          else
          next
        end # if
      end # for