#===============================================================================
# AE - Alistair Engine
#===============================================================================
# Code Snippet: Transfer damage to hero
# Version: 1.0
#
# Changelog:
# 1.0 - First Version
#===============================================================================
# Instructions:
# Place the code snippet into YEA - Lunatic States above the part where it says
# "Stop editing past this point". That's somewhere around line 188 by default.
#
#===NOTETAGS===================================================================
#---> States <---
#
# <transfer x to_hero y>
# <transfer x% to_hero y>
#
# This will make hero y receive x (or x%) damage while the initial target
# will only take a fraction of the damage. This is similar to the default
# substitute.
#
#
# PLEASE NOTE: Instead of an integer you can use "rand" (without "") for y.
#              Then the script will choose a random actor instead of a fixed
#              one.
#
#
# Example Notetags:
# <react effect: transfer 80% to_hero rand>
# A random hero will take 80% of the damage. The initial target will
# receive 20%.
#
# <react effect: transfer 900 to_hero 4>
# Hero 4 will take 900 damage. The initial target's damage will be reduced
# by 900 (obviously).
#===SCRIPT=CALLS================================================================
#
# | NONE
#
#===============================================================================


#  You should copy everything that's below this line! Don't copy my header, it will just unneccesarily bloat
#  your script!

    when /TRANSFER[ ](\d+)[ ]TO_HERO[ ](.+)/i
      @pool = $game_party.battle_members
      @pool.delete(user)
      @pool = @pool.sample
      if $2.to_s.upcase == "RAND"
        @hero = @pool
      else
        @hero = $game_actors[$2.to_i]
      end # if
      return unless $game_party.battle_members.include?(@hero)
      return if @result.hp_damage <= 0
      dmg = [@result.hp_damage, $1.to_i].min
      @result.hp_damage = [@result.hp_damage - $1.to_i, 0].max
      @hero.hp -= dmg
      if $imported["YEA-BattleEngine"]
      text = sprintf(YEA::BATTLE::POPUP_SETTINGS[:hp_dmg], dmg.group)
      @hero.create_popup(text, "HP_DMG")
      end # if
      @hero.perform_collapse_effect if @hero.hp <= 0
    
    when /TRANSFER[ ](\d+)%[ ]TO_HERO[ ](\d+)/i
      @pool = $game_party.battle_members
      @pool.delete(user)
      @pool = @pool.sample
      if $2.to_s.upcase == "RAND"
        @hero = @pool
      else
        @hero = $game_actors[$2.to_i]
      end # if
      return unless $game_party.battle_members.include?(@hero)
      return if @result.hp_damage <= 0
      return if @hero.dead?
      dmg = (@result.hp_damage * $1.to_i * 0.01).round
      @result.hp_damage = (@result.hp_damage * (100 - $1.to_i) * 0.01).round
      @hero.hp -= dmg
      if $imported["YEA-BattleEngine"]
      text = sprintf(YEA::BATTLE::POPUP_SETTINGS[:hp_dmg], dmg.group)
      @hero.create_popup(text, "HP_DMG")
      end # if
      @hero.perform_collapse_effect if @hero.hp <= 0