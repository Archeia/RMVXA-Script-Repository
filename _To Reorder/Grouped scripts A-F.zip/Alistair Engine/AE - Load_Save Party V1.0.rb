$imported["AE-LSP"] = true
#===============================================================================
# AE - Alistair Engine
#===============================================================================
# Load/Save Parties
# Version: 1.0
# Changelog:
# 1.0 - First version
#===============================================================================
# Instructions:
# Place this script above Main but below Materials.
# Use the given script calls.
#
#===NOTETAGS===================================================================
#
# | NONE
#
#===SCRIPT CALLS================================================================
#
# $game_party.save_party(x)
# -> Saves the current party formation with the index x.
# Replace x with any positive integer. Note that using the same number
# twice will overwrite the first save.
#
# $game_party.load_party(x)
# -> Loads the party formation that's saved in index x.
# Replace x with any positive integer.
#
# $game_system.change_display(#)
# -> This will change the way the party members are displayed mid-game.
# Replace # with either :face or :char
#
# $game_system.toggle_display
# -> This will toggle the display mode, meaning that :face will turn into
# :char and :char will turn into :face.
#
#===TERMS OF USE================================================================
# Please make sure to read my Terms of Use if you plan to use this script
# in a public project of yours, be it commercial or not.
#
# https://www.dropbox.com/s/0e9d1eo62lgxbip/Terms%20of%20Use.txt?dl=0
#
#===============================================================================
module AE
  module LSP
    
    CLEAR_AFTER_SAVE = false
    # Whether or not to clear the whole party after saving it (using the script
    # call).
    
    RETURN_MAP_AFTER_LOAD = true
    # Whether or not to return to the map after loading a party from the menu.
    
    PARTY_MEMBERS_VOCAB = "Party Members"
    # Vocabulary for 'Party Members'
    
    PARTY_VOCAB = "Party"
    # Vocabulary for 'Party'
    
    HELP_WINDOW_TEXT = "Choose a saved party to overwrite the current one."
    # The text displayed in the help window.
    
    DISPLAY_MODE = :face
    # Display actor faces or characters? You can change this in game.
    # :face or :char
    
  end # LSP
end # AE
#===============================================================================
# Editting anything past this point may result in a crash. So only go on if you
# know what you are doing.
#===============================================================================
class Game_System
  
  attr_accessor :display_mode_lsp
  
  alias initialize_lsp_ae initialize
  def initialize
    initialize_lsp_ae
    @display_mode_lsp = AE::LSP::DISPLAY_MODE
  end # def
  
  def change_display(x)
    @display_mode_lsp = x
  end # def
  
  def toggle_display
    @display_mode_lsp == :face ? @display_mode_lsp = :char : @display_mode_lsp = :face
  end # def
  
end # class
#===============================================================================
class Game_Party < Game_Unit
  
  attr_reader :party_saves
  
  alias initialize_ae_lsp initialize
  def initialize
    initialize_ae_lsp
    @party_saves = {}
  end # def
  
  def save_party(save_id_ae)
    @party_saves[save_id_ae] = all_members.collect {|actor| actor.id}
    @actors = [] if AE::LSP::CLEAR_AFTER_SAVE
  end # def
  
  def load_party(save_id_ae2)
    @actors = []
    @party_saves[save_id_ae2].each {|hero| add_actor(hero)}
    $game_player.refresh
    $game_map.need_refresh = true
  end # def
  
end # class
#===============================================================================
class Scene_LSP < Scene_MenuBase
  
  alias start_ae_lsp start
  def start
    start_ae_lsp
    create_help_window
    create_info_window
    create_party_choice_window
  end # def
  
  def create_help_window
    @help_window = Window_Help.new(2)
    @help_window.set_text(AE::LSP::HELP_WINDOW_TEXT)
  end # def
  
  def create_party_choice_window
    @pcw = Window_LSP.new(0, @help_window.height + 1)
    @pcw.help_window = @iw
    @pcw.set_handler(:cancel, method(:return_scene))
    @pcw.set_handler(:load_party_cm, method(:load_party_c))
  end # def
  
  def create_info_window
    @iw = Window_LSP_Info.new(160 + 1, @help_window.height + 1, Graphics.width - 160, Graphics.height - @help_window.height)
  end # def
  
  def load_party_c
    @z = @pcw.command_name(@pcw.index).slice(/\d+/)
    $game_party.load_party(@z.to_i)
    AE::LSP::RETURN_MAP_AFTER_LOAD ? SceneManager.goto(Scene_Map) : @pcw.activate
  end # def
  
end # class
#===============================================================================
class Window_LSP < Window_Command
  
  def initialize(x, y)
    clear_command_list
    make_command_list
    super(x, y)
    refresh
  end # def
  
  def visible_line_number; return 16; end
  
  def make_command_list
    $game_party.party_saves.keys.sort.each do |integer| 
    add_command(AE::LSP::PARTY_VOCAB + " " + integer.to_s, :load_party_cm)
  end # do
  end # def
  
  def update_help
      for x in $game_party.party_saves.keys
      case command_name(index)
      when AE::LSP::PARTY_VOCAB + " " + x.to_s
        @help_window.draw_info(x)
      end # for
      end # case
  end # def
  
end # class
#===============================================================================
class Window_LSP_Info < Window_Base
  
  def initialize(x, y, width, height)
    super
    refresh
  end # def
  
  def refresh
    self.contents.clear
  end # def
  
  def draw_info(x)
    refresh
    contents.font.size = 32
    change_color(text_color(9))
    draw_text(160, 0, self.width, line_height * 2, AE::LSP::PARTY_MEMBERS_VOCAB)
    reset_font_settings
    @y = 0
    @x = 0
    $game_party.party_saves[x].each {|y| draw_hero_info(y)}
  end # def
    
  def draw_hero_info(x)
    case $game_system.display_mode_lsp
    when :face
      draw_actor_face($game_actors[x], 20 + @x, 50 + @y)
    when :char
      draw_actor_graphic($game_actors[x], 20 + @x, 70 + @y)
    end # case
    draw_actor_name($game_actors[x], 20 + @x, 50 + @y)
    draw_actor_level($game_actors[x], 160 + @x, 50 + @y)
    @y += 96
    new_column
  end # def
  
  def new_column
    if $game_system.display_mode_lsp == :face
    if 50 + @y > self.height || @y >= 288
      @y = 0
      @x = self.width / 2
    end # if
  end # if
    
    if $game_system.display_mode_lsp == :char
    if 50 + @y > self.height || @y >= 384
      @y = 0
      @x = self.width / 2
    end # if
  end # if
  end # def
  
end # class
#===============================================================================
# End of Script@
#===============================================================================