#===============================================================================
# AE - Alistair Engine
#===============================================================================
# Code Snippet: Recover all
# Version: 1.0
#
# Changelog:
# 1.0 - First Version
#===============================================================================
# Instructions:
# Place the code snippet into YEA - Lunatic States above the part where it says
# "Stop editing past this point". That's somewhere around line 188 by default.
#
#===NOTETAGS===================================================================
#---> States <---
#
# <recover_all: x%>
# All party members (except the one afflicted with the state) will heal x%
# of the damage done to the battler with the state.
#
# Example Notetag:
# <react effect: recover_all: 25%>
# All heroes will heal 25% of damage.
#===SCRIPT=CALLS================================================================
#
# | NONE
#
#===============================================================================


#  You should copy everything that's below this line! Don't copy my header, it will just unneccesarily bloat
#  your script!

   when /RECOVER_ALL:[ ](\d+)%/i
      return unless @result.hp_damage > 0
      @healing = @result.hp_damage * $1.to_i / 100
      @pool = $game_party.battle_members
      @pool.delete(user)
      @pool.each do |actor|
        actor.hp += @healing
        if $imported["YEA-BattleEngine"]
        text = sprintf(YEA::BATTLE::POPUP_SETTINGS[:hp_heal], @healing.group)
        actor.create_popup(text, "HP_HEAL")
        end # if
      end # do