#===============================================================================
# AE - Alistair Engine
#===============================================================================
# Code Snippet: State increase Damage
# Version: 1.0
#
# Changelog:
# 1.0 - First Version
#===============================================================================
# Instructions:
# Place the code snippet into YEA - Lunatic Damage above the part where it says
# "Stop editing past this point". That's somewhere around line 143 by default.
#
#===NOTETAGS===================================================================
#---> Skills <---
#
# <state x, x: dmg +-y%>
# If the target is inflicted with any state x the skill's damage will increase/decrease by
# y%
#
# Example Notetag:
# <custom damage: state 3, 4: dmg +50%>
# If the target of this attack happens to have state 3 or 4, it will take 50% increased damage.
#===SCRIPT=CALLS================================================================
#
# | NONE
#
#===============================================================================


#  You should copy everything that's below this line! Don't copy my header, it will just unneccesarily bloat
#  your script!

   when /STATE (\d+(?:\s*,\s*\d+)*):[ ]DMG[ ]([\+\-]\d+)%/i
        @dmg_inc = $2.to_i * 0.01
        value += item.damage.eval(user, self, $game_variables)
        @dmgstates = []
        $1.scan(/\d+/).each { |x| @dmgstates.push(x.to_i) if x.to_i > 0}
        for int in @dmgstates
          if b.state?(int)
            value = value * (1.0 + @dmg_inc)
            break
          else
            next
          end # if
        end # for