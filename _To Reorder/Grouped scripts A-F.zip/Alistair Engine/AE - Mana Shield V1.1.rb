$imported = {} if $imported.nil?
$imported["AE-ManaShield"] = true
#===============================================================================
# AE - Alistair Engine
#===============================================================================
# Mana Shield
# Version: 1.1
# Changelog:
# 1.0 - First version
# 1.1 - Completely changed the way mana shields work
#===============================================================================
# Instructions:
# Insert this script above Main and below Materials.
# Place it below all Yanfly Scripts. If it doesn't work, try placing it
# at the very end.
#
# Adjust the settings in the script to your liking. Then use the stated
# Notetag to activate the script.
#
#===NOTE-TAGS===================================================================
#---> Weapons, Armours, States <---
#
# <absorb_damage: x%> or optional <absorb_damage_x: y%>
#
# Will reduce incoming damage by x%.
# The optional version will allow you to reduce x (= HP or MP) damage only.
#
# <reduce_damage: x> or optional <reduce_damage_x: y>
#
# Will reduce incoming damage by x.
# The optional version will allow you to reduce x (= HP or MP) damage only.
#
# <split_damage: x%>
#
# Will split incoming damage by x% between HP and MP.
#
# <replenish_x: y%>
#
# Will replenish x by y% of the damage.
# Replace x with either HP or MP.
#
# <ignore_damage: y%> or optional <ignore_damage_x: y%>
#
# Will ignore (nullify) all the damage with a probability of y%
# The optional version will allow you to nullify x (= HP or MP) damage only.
#
#===SCRIPT-CALLS================================================================
#
# | NONE
#
#===============================================================================
=begin
﻿■───────────────────────────────────────────────────────────────────────────────
■ AE - Alistair Engine
■───────────────────────────────────────────────────────────────────────────────
■ 
■ 
■ 	  THESE TERMS OF USE APPLY TO ALL OF MY SCRIPTS, UNLESS 
■ 	THE INDIVIDUAL SCRIPT ITSELF STATES OTHERWISE IN ITS HEADER!
■ 
■ 
■────NON-COMMERCIAL USE─────────────────────────────────────────────────────────
■ 
■ → All of my scripts can be freely used in non-commercial Projects.
■   I do not ask to be credited but it would show that you are actually
■   grateful for the script I provided for you.
■ 
■
■────COMMERCIAL USE─────────────────────────────────────────────────────────────
■
■ → If you plan to use my scripts in a commercial Project I request 
■   the following of you:
■
■   ■ I do not charge money for any of my scripts. You are free to use
■     my scripts but it would be nice if you gave me a free copy of your game.
■
■   ■ Similar to non-commercial use, I do not ask to be credited. You can
■     do it but I do not demand it. 
■
■
■────ALTERATION OF MY SCRIPTS───────────────────────────────────────────────────
■
■ → Generally speaking, I have nothing against people altering my scripts.
■   Feel free to change and reupload them as long as you abide by the following
■   terms:
■
■   ■ You may alter my scripts but do not claim they are yours.
■
■   ■ You may reupload my scripts as long as you link to my Profile over at
■     forums.rpgmakerweb.com or to my dropbox. You can find the two links
■     just below this part.
■
■────LINKS──────────────────────────────────────────────────────────────────────
■
■ → My Dropbox
■   ■ https://www.dropbox.com/sh/vrfd3f2f4lytjfi/AADpk7qmXIhY8v_MJEDJ1JJ2a?dl=0
■
■ → My Profile at forums.rpgmakerweb.com
■   ■ http://forums.rpgmakerweb.com/index.php?/user/39955-alistair/
■───────────────────────────────────────────────────────────────────────────────
■
■ → As a general rule: Just don't do anything that could cause drama.
■   It's tiring for you and for me. Let's just all be happy.
■
■───────────────────────────────────────────────────────────────────────────────
=end
module AE
  module MS
    
    DISALLOW_REPLENISH = true
    # If the suffered damage becomes positive because of a mana shield, should
    # this be prevented?
    
    CAP = true
    # Will cap every note tag value at 100%.
    
  end # MS
end # AE
#===============================================================================
# Editting anything past this point may result in a crash. So only go on if you
# know what you are doing.
#===============================================================================
class RPG::State
  
  attr_accessor :absorb
  attr_accessor :split
  attr_accessor :replenish
  attr_accessor :ignore
  attr_accessor :reduce
  
  def absorb
    @absorb = [-1, 0]
    if @note =~ /<absorb[_ ]damage[_ ]*(.*)?:[ ]+(\d+)\%>/i
      @absorb = [-1, $2.to_i]
      unless $1.nil?
        case $1.to_s.upcase
        when "HP", "H"
        @absorb = [0, $2.to_i]
        when "MP", "M"
        @absorb = [1, $2.to_i]
        end # case
      end # unless
    end # if
    @absorb
  end # def
  
  def split
    @split = 0
    if @note =~ /<split[_ ]damage:[ ](\d+)%>/i
      @split = $1.to_i
    end # if
    @split
  end # def
  
  def replenish
    @replenish = [0, 0]
    if @note =~ /<replenish[_ ](.*):[ ](\d+)%>/i
      case $1.to_s.upcase
      when "HP", "H"
      @replenish = [0, $2.to_i]
      when "MP", "M"
      @replenish = [1, $2.to_i]
      end # case
    end # if
    @replenish
  end # def
  
  def ignore
    @ignore = [-1, 0]
    if @note =~ /<ignore[_ ]damage[_ ]*(.*)?:[ ](\d+)%>/i
      @ignore = [-1, $2.to_i]
      unless $1.nil?
        case $1.to_s.upcase
        when "HP", "H"
          @ignore = [0, $2.to_i]
        when "MP", "M"
          @ignore = [1, $2.to_i]
        end # case
      end # unless
    end # if
    @ignore
  end # def
  
  def reduce
    @reduce = [-1, 0]
    if @note =~ /<reduce[_ ]damage[_ ]*(.*)?:[ ](\d+)>/i
      @reduce = [-1, $2.to_i]
      unless $1.nil?
        case $1.to_s.upcase
        when "HP", "H"
          @reduce = [0, $2.to_i]
        when "MP", "M"
          @reduce = [1, $2.to_i]
        end # case
      end # unless
    end # if
    @reduce
  end # def
  
end # class
#===============================================================================
class RPG::EquipItem
  
  attr_accessor :absorb
  attr_accessor :split
  attr_accessor :replenish
  attr_accessor :ignore
  attr_accessor :reduce
  
  def absorb
    @absorb = [-1, 0]
    if @note =~ /<absorb[_ ]damage[_ ]*(.*)?:[ ]+(\d+)\%>/i
      @absorb = [-1, $2.to_i]
      unless $1.nil?
        case $1.to_s.upcase
        when "HP", "H"
        @absorb = [0, $2.to_i]
        when "MP", "M"
        @absorb = [1, $2.to_i]
        end # case
      end # unless
    end # if
    @absorb
  end # def
  
  def split
    @split = 0
    if @note =~ /<split[_ ]damage:[ ](\d+)%>/i
      @split = $1.to_i
    end # if
    @split
  end # def
  
  def replenish
    @replenish = [0, 0]
    if @note =~ /<replenish[_ ](.*):[ ](\d+)%>/i
      case $1.to_s.upcase
      when "HP", "H"
      @replenish = [0, $2.to_i]
      when "MP", "M"
      @replenish = [1, $2.to_i]
      end # case
    end # if
    @replenish
  end # def
  
  def ignore
    @ignore = [-1, 0]
    if @note =~ /<ignore[_ ]damage[_ ]*(.*)?:[ ](\d+)%>/i
      @ignore = [-1, $2.to_i]
      unless $1.nil?
        case $1.to_s.upcase
        when "HP", "H"
          @ignore = [0, $2.to_i]
        when "MP", "M"
          @ignore = [1, $2.to_i]
        end # case
      end # unless
    end # if
    @ignore
  end # def
  
  def reduce
    @reduce = [-1, 0]
    if @note =~ /<reduce[_ ]damage[_ ]*(.*)?:[ ](\d+)>/i
      @reduce = [-1, $2.to_i]
      unless $1.nil?
        case $1.to_s.upcase
        when "HP", "H"
          @reduce = [0, $2.to_i]
        when "MP", "M"
          @reduce = [1, $2.to_i]
        end # case
      end # unless
    end # if
    @reduce
  end # def
  
end # class
#===============================================================================
class Game_Enemy
  
  attr_accessor :equips
  
  alias initialize_ms initialize
  def initialize(index, enemy_id)
    initialize_ms(index, enemy_id)
    @equips = []
  end # def
  
end # class
#===============================================================================
class Game_ActionResult
  
    def make_damage(value, item)
      @absorb = [-1, 0]
      @split = 0
      @replenish = [0, 0]
      @ignore = [-1, 0]
      @reduce = [-1, 0]
      @shield = false
      @critical = false if value == 0
  
    for state in @battler.states
      next if state.nil?
      @absorb[0] = state.absorb[0] unless state.absorb[0] == -1
      @absorb[1] += state.absorb[1]
      @split += state.split
      @replenish[0] = state.replenish[0]
      @replenish[1] += state.replenish[1]
      @ignore[0] = state.ignore[0] unless state.ignore[0] == -1
      @ignore[1] += state.ignore[1]
      @reduce[0] = state.reduce[0] unless state.reduce[0] == -1
      @reduce[1] += state.reduce[1]
    end # for
    
    for equip in @battler.equips
      next if equip.nil?
      @absorb[0] = equip.absorb[0] unless equip.absorb[0] == -1
      @absorb[1] += equip.absorb[1]
      @split += equip.split
      @replenish[0] = equip.replenish[0]
      @replenish[1] += equip.replenish[1]
      @ignore[0] = equip.ignore[0] unless equip.ignore[0] == -1
      @ignore[1] += equip.ignore[1]
      @reduce[0] = equip.reduce[0] unless equip.reduce[0] == -1
      @reduce[1] += equip.reduce[1]
    end # for
    
    @absorb[1] > 100 && AE::MS::CAP ? @absorb[1] = 100 : @absorb[1]
    @split     > 100 && AE::MS::CAP ? @split  = 100 : @split
    @replenish[1] > 100 && AE::MS::CAP ? @replenish[1] = 100 : @replenish[1]
    @ignore[1] > 100 && AE::MS::CAP ? @ignore[1] = 100 : @ignore[1]
    @reduce[1] > 100 && AE::MS::CAP ? @reduce[1] = 100 : @reduce[1]
  
  if @absorb[1] > 0 || @split > 0 || @replenish[1] > 0 || @ignore[1] > 0 || @reduce[1] > 0
    @shield = true
  end # if
    
   if @shield && value > 0
     # absorb
     value = value * (100 - @absorb[1]) / 100 if @absorb[0] == -1
     @hp_damage = value if item.damage.to_hp?
     @mp_damage = value if item.damage.to_mp?
     # reduce
     if @reduce[0] == -1 && @reduce[1] > 0
       @hp_damage = value - @reduce[1]
       if value < 0 && AE::MS::DISALLOW_REPLENISH
       value = 0
       @hp_damage = 0
       end # if
     end # if
     # reduce optional
     unless @reduce[0] == -1
       case @reduce[0]
       when 0
         @hp_damage -= @reduce[1]
       when 1
         @mp_damage -= @reduce[1]
       end # case
     end # unless
     # split
     if @split > 0
     @hp_damage = value * @split / 100
     @mp_damage = value * (100 - @split) / 100
     end # if
     # absorb optional
     unless @absorb[0] == -1
       case @absorb[0]
       when 0
         @hp_damage = @hp_damage * (100 - @absorb[1]) / 100
       when 1
         @mp_damage = @mp_damage * (100 - @absorb[1]) / 100
       end # case
     end # unless
     # replenish
     if @replenish[1] > 0
       case @replenish[0]
       when 0
         @hp_heal = value * @replenish[1] / 100
         @hp_damage = @hp_damage - @hp_heal
       when 1
         @mp_heal = value * @replenish[1] / 100
         @mp_damage = @mp_damage - @mp_heal
       end # case
     end # if
     # ignore
     if @ignore[1] * 0.01 > rand && @ignore[0] == -1
       @hp_damage = 0
       @mp_damage = 0
     end # if
     # ignore optional
     if @ignore[1] * 0.01 > rand && @ignore[0] != -1
       case @ignore[0]
       when 0
         @hp_damage = 0
       when 1
         @mp_damage = 0
       end # case
     end # if
     
     # if MP_damage > MP
     if @mp_damage > @battler.mp
       @hp_damage = @hp_damage + (@battler.mp - @mp_damage).abs
       @mp_damage = @battler.mp
     end # if

   end # if
    if !@shield || value < 0
    @hp_damage = value if item.damage.to_hp?
    @mp_damage = value if item.damage.to_mp?
    @mp_damage = [@battler.mp, @mp_damage].min
    @hp_drain = @hp_damage if item.damage.drain?
    @mp_drain = @mp_damage if item.damage.drain?
    @hp_drain = [@battler.hp, @hp_drain].min
    end # if
    @success = true if item.damage.to_hp? || @mp_damage != 0
  end # def
  
end # class
#===============================================================================
# End of Script@
#===============================================================================