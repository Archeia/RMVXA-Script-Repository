=begin
CSCA Vehicle Encounters!
Created by: Casper Gaming (http://www.caspergaming.com/)

Compatibility:
Made for RPGVXAce
IMPORTANT: ALL CSCA Scripts should be compatible with each other unless
otherwise noted.

FFEATURES:
This script will allow you to have encounters on the Boat, Ship, or Airship.
It also allows you to change the encounter rate while on each vehicle, and allows
you to create a seperate encounter list for each vehicle. All of the features
are toggleable.

How to use these features is explained below in the setup section.
SETUP BELOW IS REQUIRED!

CREDIT:
Free to use in noncommercial games if credit is given to:
Casper Gaming (http://www.caspergaming.com/)

To use in a commercial game, please purchase a license here:
http://www.caspergaming.com/licenses.html

TERMS:
http://www.caspergaming.com/terms_of_use.html
=end

module CSCA_VEHICLE_ENCOUNTERS # Don't Touch
  
  #########
  # SETUP #
  #########
  
  BOAT = 1     # Switch ID. When ON, allows encounters in the boat.
  SHIP = 2     # Switch ID. When ON, allows encounters in the ship.
  AIRSHIP = 3  # Switch ID. When ON, allows encounters in the airship.
  
  # The following switch needs to be ON if you wish to have different troops
  # encountered while on a vehicle. If OFF, troops encountered while on a vehicle
  # will not be any different than troops encountered while not on a vehicle.
  ALLOWCUSTOMENCOUNTER = 5 # Switch ID
  
  # The following arrays control the Troop ID's to be encounetred when on the
  # corresponding vehicle. For example, BOATENCOUNTERS = [1, 2] will enable ONLY
  # troops 1 and 2 in the database able to be fought while on the Boat. Of course,
  # You'll need to make sure the switch that enables encounters for that vehicle
  # is also ON. Vehicles ignore area encounter lists.
  BOATENCOUNTERS = [1, 2]    # These troop ID's can be fought in the boat.
  SHIPENCOUNTERS = [3, 4]    # These troop ID's can be fought in the ship.
  AIRSHIPENCOUNTERS = [5, 6] # These troop ID's can be fought in the airship.
  
  # The following switch needs to be ON if you wish to have different encounter
  # rates while in each vehicle. If OFF, vehicle encounter rate is set to the
  # map encounter rate.
  ALLOWCUSTOMRATE = 4 # Switch ID
  
  # The following numbers control how many steps on average before an encounter
  # happens in the current vehicle. Faster vehicles like the airship and ship
  # should be set higher because their step counter increases much faster.
  BOATSTEP = 25    # Average amount of steps before encounter in boat.
  SHIPSTEP = 50    # Average amount of steps before encounter in ship.
  AIRSHIPSTEP = 150 # Average amount of steps before encounter in  airship.
  
  # The following designate which battleback floor you want to use for each
  # vehicle.
  BOAT_BATTLEBACK1 = "Ship" # Boat battle floor.
  SHIP_BATTLEBACK1 = "Ship" # Ship battle floor.
  AIRSHIP_BATTLEBACK1 = "Clouds" # Airship battle floor.
  
  # The following designate  which battleback wall you want to use for each
  # vehicle.
  BOAT_BATTLEBACK2 = "Ship" # Boat battle wall.
  SHIP_BATTLEBACK2 = "Ship" # Ship battle wall.
  AIRSHIP_BATTLEBACK2 = "Clouds" # Airship battle wall.
  
  #############
  # SETUP END #
  #############
  
end # Don't Touch this or anything below.
class Spriteset_Battle
  include CSCA_VEHICLE_ENCOUNTERS
  
  def battleback1_name
    if $BTEST
      $data_system.battleback1_name
    elsif $game_player.vehicle
      if $game_player.in_boat?
        BOAT_BATTLEBACK1
      elsif $game_player.in_ship?
        SHIP_BATTLEBACK1
      elsif $game_player.in_airship?
        AIRSHIP_BATTLEBACK1
      end
    else
      if $game_map.battleback1_name
        $game_map.battleback1_name
      elsif $game_map.overworld?
        overworld_battleback1_name
      end
    end
  end

  def battleback2_name
    if $BTEST
      $data_system.battleback2_name
    elsif $game_player.vehicle
      if $game_player.in_boat?
        BOAT_BATTLEBACK2
      elsif $game_player.in_ship?
        SHIP_BATTLEBACK2
      elsif $game_player.in_airship?
        AIRSHIP_BATTLEBACK2
      end
    else
      if $game_map.battleback2_name
        $game_map.battleback2_name
      elsif $game_map.overworld?
        overworld_battleback2_name
      end
    end
  end
  
end


class Game_Player < Game_Character
  include CSCA_VEHICLE_ENCOUNTERS

  def make_encounter_count
    if $game_map.map_id != 0
      if in_boat? && $game_switches[ALLOWCUSTOMRATE]
        n = BOATSTEP
      elsif in_ship? && $game_switches[ALLOWCUSTOMRATE]
        n = SHIPSTEP
      elsif in_airship? && $game_switches[ALLOWCUSTOMRATE]
        n = AIRSHIPSTEP
      else
        n = $game_map.encounter_step
      end
      @encounter_count = rand(n) + rand(n) + 1
    end
  end

  def make_encounter_troop_id
    if $game_switches[ALLOWCUSTOMENCOUNTER]
      if in_boat?
        encounter_list = BOATENCOUNTERS
        return encounter_list[rand(encounter_list.size)]
      elsif in_ship?
        encounter_list = SHIPENCOUNTERS
        return encounter_list[rand(encounter_list.size)]
      elsif in_airship?
        encounter_list = AIRSHIPENCOUNTERS
        return encounter_list[rand(encounter_list.size)]
      else
        encounter_list = []
        weight_sum = 0
        $game_map.encounter_list.each do |encounter|
        next unless encounter_ok?(encounter)
          encounter_list.push(encounter)
          weight_sum += encounter.weight
        end
        if weight_sum > 0
        value = rand(weight_sum)
        encounter_list.each do |encounter|
          value -= encounter.weight
          return encounter.troop_id if value < 0
          end
        end
        return 0
      end
    else
      encounter_list = []
        weight_sum = 0
        $game_map.encounter_list.each do |encounter|
        next unless encounter_ok?(encounter)
          encounter_list.push(encounter)
          weight_sum += encounter.weight
        end
        if weight_sum > 0
          value = rand(weight_sum)
          encounter_list.each do |encounter|
          value -= encounter.weight
          return encounter.troop_id if value < 0
        end
      end
      return 0
    end
  end
  
  def update_encounter
    return if $TEST && Input.press?(:CTRL)
    return if $game_party.encounter_none?
    return if @move_route_forcing
    return if @cscavehicleinterior
    return if $game_map.encounter_list == [] && !(in_boat? || in_ship? || in_airship?)
    if in_boat? && $game_switches[BOAT] == false
      return
    end
    if in_ship? && $game_switches[SHIP] == false
      return
    end
    if in_airship? && $game_switches[AIRSHIP] == false
      return
    end
    @encounter_count -= encounter_progress_value
  end
  
  def encounter_progress_value
    value = $game_map.bush?(@x, @y) ? 2 : 1
    value *= 0.5 if $game_party.encounter_half?
    value
  end

end