=begin
CSCA Vehicle System
version: 1.0.0 (Released: October 6, 2012)
Created by: Casper Gaming (http://www.caspergaming.com/)

Compatibility:
Made for RPGVXAce
IMPORTANT: ALL CSCA Scripts should be compatible with each other unless
otherwise noted.
NOT COMPATIBLE WITH: CSCA Vehicle Encounters & CSCA Vehicle Interiors

Requires CSCA Core Script v1.0.3+
Get it here: http://www.rpgmakervxace.net/topic/6879-csca-core-script/

FFEATURES:
This script will add:
-customizable vehicle encounters
-vehicle interiors for all 3 vehicles
-docking restrictions
-fishing in the boat/ship.

SETUP
Setup required. Instructions below.

To call return from an interior map, make the following script call:
$game_player.csca_return

CREDIT:
Free to use in noncommercial games if credit is given to:
Casper Gaming (http://www.caspergaming.com/)

To use in a commercial game, please purchase a license here:
http://www.caspergaming.com/licenses.html

TERMS:
http://www.caspergaming.com/terms_of_use.html
=end
module CSCA
  module VEHICLE
    #===========================================================================
    # Vehicle Encounter Options
    BOAT_ENCOUNTERS    = [1, 2] # Troop ID's to be encountered in boat.
    SHIP_ENCOUNTERS    = [3, 4] # Troop ID's to be encountered in ship.
    AIRSHIP_ENCOUNTERS = [5, 6] # Troop ID's to be encountered in airship.
    
    BOAT_STEP    = 30 # Amount of steps avg. before boat encounter.
    SHIP_STEP    = 60 # Amount of steps avg. before ship encounter.
    AIRSHIP_STEP = 90 # Amount of steps avg. before airship encounter.
    
    DISABLE_ENC = 1 # Switch ID. When ON, vehicle encounters are disabled.
    
    BOAT_BB    = ["Ship", "Ship"] # Battleback to use in a boat battle.
    SHIP_BB    = ["Ship", "Ship"] # Battleback to use in a ship battle.
    AIRSHIP_BB = ["Clouds", "Clouds"] # Battleback to use in an airship battle.
    #===========================================================================
    # Vehicle Interior Options
    # Trigger name        Key on keyboard
    # :A             =    Shift
    # :B             =    X
    # :C             =    Z
    # :X             =    A
    # :Y             =    S
    # :Z             =    D
    # :L             =    Q
    # :R             =    W
    TRIGGER = :Y # Button press to transfer player inside vehicle.
    
    # Transfer settings, the values in the array stand for:
    # [Map Id, X-Coordinate, Y-Coordinate, Direction]
    # To disable a vehicle's interior, set the first value to nil.
    SHIP_TRANSFER    = [2, 16, 10, 4]
    AIRSHIP_TRANSFER = [3, 13,  0, 2]
    BOAT_TRANSFER    = [5,  0,  8, 6]
    
    FADE = 0 # 0 = black fade, 1 = white fade, 2 = no fade
    #===========================================================================
    # Vehicle Docking Options
    DOCK_REGION = 1 # Player can only dock boat/ship if in this region. Set to
                    # 0 to allow the player to dock anywhere they normally could.
    LAND_REGION = 1 # Player can only land airship on this region. Set to 0 to
                    # allow the player to land anywhere they normally could.
    #===========================================================================
    # Fishing Settings
    FISH = [] # Don't Touch
    #FISH[x] = CSCA_FISH.new(item id, water type, weight[, region])
    # Valid water types are :shallow, :deep, and :both
    # Use the optional region command to restrict certain fish to regions.
    FISH[0] = CSCA_Fish.new(1, :shallow,  5)
    FISH[1] = CSCA_Fish.new(2, :shallow, 10, 63)
    FISH[2] = CSCA_Fish.new(3, :deep, 10, 63)
    FISH[3] = CSCA_Fish.new(4, :deep, 5)
    
    FISH_TRIGGER = :X # Trigger to start fishing in the boat/ship.
    NO_CATCH_WEIGHT = 10 # Weight value representing no fish caught.
    FISHING_ENABLED = 1 # Switch ID. When ON, fishing is enabled.
    CATCH_TIME = 600 # Max amount of frames to spend on fishing. 60frames = 1sec
    FISH_COLOR1 = 10 # Color1 to use on the fishing gauge.
    FISH_COLOR2 = 11 # Color2 to use on the fishing gauge.
    CAST_SOUND = "Key" # SE to play when casting. Set to nil to disable.
    CATCH_SOUND = "Water2" # SE to play when fish caught. Set to nil to disable.
    #===========================================================================
  end # End Setup. Don't touch this or anything below.
end
$imported = {} if $imported.nil?
$imported["CSCA-VehicleSystem"] = true
msgbox('Missing Script: CSCA Core Script! CSCA Vehicle System requires this
script to work properly.') if !$imported["CSCA-Core"]
#==============================================================================
# ** Spriteset_Battle
#------------------------------------------------------------------------------
# Change battlebacks based on vehicle.
# Aliases: battleback1_name, battleback2_name
#==============================================================================
class Spriteset_Battle
  #--------------------------------------------------------------------------#
  # Alias Method; Show vehicle battleback 1                                  #
  #--------------------------------------------------------------------------#
  alias :csca_vehicle_battleback1 :battleback1_name
  def battleback1_name
    if $game_player.in_boat?
      CSCA::VEHICLE::BOAT_BB[0]
    elsif $game_player.in_ship?
      CSCA::VEHICLE::SHIP_BB[0]
    elsif $game_player.in_airship?
      CSCA::VEHICLE::AIRSHIP_BB[0]
    else
      csca_vehicle_battleback1
    end
  end
  #--------------------------------------------------------------------------#
  # Alias Method; Show vehicle battleback 2                                  #
  #--------------------------------------------------------------------------#
  alias :csca_vehicle_battleback2 :battleback2_name
  def battleback2_name
    if $game_player.in_boat?
      CSCA::VEHICLE::BOAT_BB[1]
    elsif $game_player.in_ship?
      CSCA::VEHICLE::SHIP_BB[1]
    elsif $game_player.in_airship?
      CSCA::VEHICLE::AIRSHIP_BB[1]
    else
      csca_vehicle_battleback2
    end
  end
end
#==============================================================================
# ** Game_Player
#------------------------------------------------------------------------------
# Change encounter lists and step count based on vehicle, provides methods for
# entering vehicles.
# Aliases: make_encounter_count, make_encounter_troop_id, update_encounter,
# encounter_progress_value, update, get_on_vehicle
#==============================================================================
class Game_Player < Game_Character
  attr_accessor :bgm_no_play
  #--------------------------------------------------------------------------#
  # Alias Method; Make avg. encounter step                                   #
  #--------------------------------------------------------------------------#
  alias :csca_vehicle_encounter_count :make_encounter_count
  def make_encounter_count
    if in_boat?
      n = CSCA::VEHICLE::BOAT_STEP
      @encounter_count = rand(n) + rand(n) + 1
    elsif in_ship?
      n = CSCA::VEHICLE::SHIP_STEP
      @encounter_count = rand(n) + rand(n) + 1
    elsif in_airship?
      n = CSCA::VEHICLE::AIRSHIP_STEP
      @encounter_count = rand(n) + rand(n) + 1
    else
      csca_vehicle_encounter_count
    end
  end
  #--------------------------------------------------------------------------#
  # Alias Method; Get troop                                                  #
  #--------------------------------------------------------------------------#
  alias :csca_vehicle_make_troop :make_encounter_troop_id
  def make_encounter_troop_id
    if in_boat?
      encounter_list = CSCA::VEHICLE::BOAT_ENCOUNTERS
      return encounter_list[rand(encounter_list.size)]
    elsif in_ship?
      encounter_list = CSCA::VEHICLE::SHIP_ENCOUNTERS
      return encounter_list[rand(encounter_list.size)]
    elsif in_airship?
      encounter_list = CSCA::VEHICLE::AIRSHIP_ENCOUNTERS
      return encounter_list[rand(encounter_list.size)]
    else
      csca_vehicle_make_troop
    end
  end
  #--------------------------------------------------------------------------#
  # Alias Method; Update encounter count                                     #
  #--------------------------------------------------------------------------#
  alias :csca_vehicle_update_encounter :update_encounter
  def update_encounter
    return if @cscavehicleinterior
    return if $game_map.encounter_list == [] && !(in_boat? || in_ship? || in_airship?)
    return if in_boat? && $game_switches[CSCA::VEHICLE::DISABLE_ENC]
    return if in_ship? && $game_switches[CSCA::VEHICLE::DISABLE_ENC]
    return if in_airship? && $game_switches[CSCA::VEHICLE::DISABLE_ENC]
    @encounter_count -= encounter_progress_value if in_airship?
    csca_vehicle_update_encounter
  end
  #--------------------------------------------------------------------------#
  # Alias Method; Show vehicle battleback 2                                  #
  #--------------------------------------------------------------------------#
  alias :csca_vehicle_encounter_value :encounter_progress_value
  def encounter_progress_value
    value = csca_vehicle_encounter_value
    value *= 2 if in_ship?
    value
  end
  #--------------------------------------------------------------------------#
  # Alias Method; Vehicle enter input?                                       #
  #--------------------------------------------------------------------------#
  alias :csca_gp_update :update
  def update
    csca_gp_update
    csca_vehicle_transfer_input
  end
  #--------------------------------------------------------------------------#
  # Alias Method; Vehicle enter ok?                                          #
  #--------------------------------------------------------------------------#
  alias :csca_vs_enter_ok? :get_on_vehicle
  def get_on_vehicle
    front_x = $game_map.round_x_with_direction(@x, @direction)
    front_y = $game_map.round_y_with_direction(@y, @direction)
    @vehicle_type = :boat    if $game_map.boat.pos?(front_x, front_y)
    @vehicle_type = :ship    if $game_map.ship.pos?(front_x, front_y)
    @vehicle_type = :airship if $game_map.airship.pos?(@x, @y)
    x = $game_player.x
    y = $game_player.y
    if vehicle
      vehicle.csca_enter_ok?(x, y) ? csca_vs_enter_ok? : @vehicle_type = :walk
    end
  end
  #--------------------------------------------------------------------------#
  # Transfer to interior if button pressed                                   #
  #--------------------------------------------------------------------------#
  def csca_vehicle_transfer_input
    if Input.trigger?(CSCA::VEHICLE::TRIGGER) && csca_in_vehicle? &&
      !$game_map.csca_fishing
      case @vehicle_type
      when :boat
        return if CSCA::VEHICLE::BOAT_TRANSFER[0].nil?
        map = CSCA::VEHICLE::BOAT_TRANSFER[0]
        x = CSCA::VEHICLE::BOAT_TRANSFER[1]
        y = CSCA::VEHICLE::BOAT_TRANSFER[2]
        d = CSCA::VEHICLE::BOAT_TRANSFER[3]
      when :ship
        return if CSCA::VEHICLE::SHIP_TRANSFER[0].nil?
        map = CSCA::VEHICLE::SHIP_TRANSFER[0]
        x = CSCA::VEHICLE::SHIP_TRANSFER[1]
        y = CSCA::VEHICLE::SHIP_TRANSFER[2]
        d = CSCA::VEHICLE::SHIP_TRANSFER[3]
      when :airship
        return if CSCA::VEHICLE::AIRSHIP_TRANSFER[0].nil?
        map = CSCA::VEHICLE::AIRSHIP_TRANSFER[0]
        x = CSCA::VEHICLE::AIRSHIP_TRANSFER[1]
        y = CSCA::VEHICLE::AIRSHIP_TRANSFER[2]
        d = CSCA::VEHICLE::AIRSHIP_TRANSFER[3]
      end
      reserve_transfer(map, x, y, d)
      @cscavehiclereturn = @vehicle_type
      $game_temp.fade_type = CSCA::VEHICLE::FADE
      csca_vehicle_remove
    end
  end
  #--------------------------------------------------------------------------#
  # Player is in vehicle?                                                    #
  #--------------------------------------------------------------------------#
  def csca_in_vehicle?
    return in_ship? || in_boat? || in_airship?
  end
  #--------------------------------------------------------------------------#
  # Remove vehicle & save transfer info                                      #
  #--------------------------------------------------------------------------#
  def csca_vehicle_remove
    @cscavehicletransfermap = $game_map.map_id
    @cscavehicletransferx = @x
    @cscavehicletransfery = @y
    @cscavehicleinterior = true
    @followers.synchronize(@x, @y, @direction)
    @vehicle_getting_off = true
    vehicle.get_off
    @move_speed = 4
    @through = false
    @followers.gather
    @vehicle_getting_off
    @bgm_no_play = true
    make_encounter_count
  end
  #--------------------------------------------------------------------------#
  # Return from interior                                                     #
  #--------------------------------------------------------------------------#
  def csca_return
    map_id = @cscavehicletransfermap
    x = @cscavehicletransferx
    y = @cscavehicletransfery
    @transparent = true
    reserve_transfer(map_id, x, y)
    $game_temp.fade_type = CSCA::VEHICLE::FADE
    @vehicle_type = @cscavehiclereturn
    @vehicle_getting_on = true
    @followers.gather
    @cscavehicleinterior = false
  end
  #--------------------------------------------------------------------------#
  # Inside vehicle?                                                          #
  #--------------------------------------------------------------------------#
  def csca_vehicle_transfer?
    @cscavehicleinterior
  end
  #--------------------------------------------------------------------------#
  # Inside fishing vehicle?                                                  #
  #--------------------------------------------------------------------------#
  def csca_fishing_ok?
    return false if !$game_switches[CSCA::VEHICLE::FISHING_ENABLED]
    in_boat? || in_ship?
  end
  #--------------------------------------------------------------------------#
  # Alias Method; disallow movement during fish                              #
  #--------------------------------------------------------------------------#
  alias :csca_fish_movable :movable?
  def movable?
    return false if $game_map.csca_fishing
    csca_fish_movable
  end
end
#==============================================================================
# ** Game_Map
#------------------------------------------------------------------------------
# Don't allow map BGM to play if transferring between vehicle interiors.
# Aliases: autoplay, initialize, update
#==============================================================================
class Game_Map
  attr_accessor :csca_fishing
  attr_reader   :caught_fish
  attr_reader   :fish_time
  #--------------------------------------------------------------------------#
  # Alias Method; Initialize                                                 #
  #--------------------------------------------------------------------------#
  alias :csca_vs_init :initialize
  def initialize
    @fish_type = :shallow
    @caught_fish = nil
    @csca_fishing = false
    @fish_time = 0
    @fish = []
    csca_vs_init
  end
  #--------------------------------------------------------------------------#
  # Alias Method; Frame Update                                               #
  #--------------------------------------------------------------------------#
  alias :csca_vs_update :update
  def update(main)
    csca_vs_update(main)
    csca_fishing_start if $game_player.csca_fishing_ok? &&
      Input.press?(CSCA::VEHICLE::FISH_TRIGGER) && @csca_fishing == false
  end
  #--------------------------------------------------------------------------#
  # Alias Method; determine autoplay                                         #
  #--------------------------------------------------------------------------#
  alias :csca_vehicle_autoplay :autoplay
  def autoplay
    if !$game_player.bgm_no_play || map_id == CSCA::VEHICLE::AIRSHIP_TRANSFER[0] ||
      map_id == CSCA::VEHICLE::SHIP_TRANSFER[0] || map_id == CSCA::VEHICLE::BOAT_TRANSFER[0]
      csca_vehicle_autoplay
    else
      $game_player.bgm_no_play = false
    end
  end
  #--------------------------------------------------------------------------#
  # Start Fishing                                                            #
  #--------------------------------------------------------------------------#
  def csca_fishing_start
    csca_get_fish_type
    csca_get_fish_array
    csca_determine_fish_catch
    csca_determine_fish_time
    Audio.se_play("Audio/SE/"+CSCA::VEHICLE::CAST_SOUND,80)  unless CSCA::VEHICLE::CAST_SOUND.nil?
    @csca_fishing = true
  end
  #--------------------------------------------------------------------------#
  # Get Fish Type                                                            #
  #--------------------------------------------------------------------------#
  def csca_get_fish_type
    boat_passable?($game_player.x, $game_player.y) ? @fish_type = :shallow :
      @fish_type = :deep
  end
  #--------------------------------------------------------------------------#
  # Get Fish Array                                                           #
  #--------------------------------------------------------------------------#
  def csca_get_fish_array
    @fish = []
    number = 0
    for i in 0..CSCA::VEHICLE::FISH.size
      next if CSCA::VEHICLE::FISH[i].nil?
      if CSCA::VEHICLE::FISH[i].water_type == @fish_type || CSCA::VEHICLE::FISH[i].water_type == :both
        if csca_fish_region_okay(CSCA::VEHICLE::FISH[i].region)
          @fish[number] = CSCA::VEHICLE::FISH[i] 
          number += 1
        end
      end
    end
  end
  #--------------------------------------------------------------------------#
  # Determine Fish Catch                                                     #
  #--------------------------------------------------------------------------#
  def csca_determine_fish_catch
    total_weight = 0
    @fish.each do |fish|
      total_weight += fish.weight
    end
    caught_fish_weight = rand(total_weight+CSCA::VEHICLE::NO_CATCH_WEIGHT) + 1
    catch_weight = 0
    @fish.each do |fish|
      catch_weight += fish.weight
      if catch_weight >= caught_fish_weight
        @caught_fish = fish.item_id
        break
      else
        @caught_fish = nil
      end
    end
  end
  #--------------------------------------------------------------------------#
  # Determine Time before catch                                              #
  #--------------------------------------------------------------------------#
  def csca_determine_fish_time
    @caught_fish.nil? ? @fish_time = CSCA::VEHICLE::CATCH_TIME : @fish_time = rand(CSCA::VEHICLE::CATCH_TIME)
  end
  #--------------------------------------------------------------------------#
  # Determine if in proper region                                            #
  #--------------------------------------------------------------------------#
  def csca_fish_region_okay(region)
    return true if region == 0
    return true if region_id($game_player.x,$game_player.y) == region
    return false
  end
end
#==============================================================================
# ** Scene_Map
#------------------------------------------------------------------------------
# Handles fishing window.
# Aliases: scene_change_ok?, create_all_windows
#==============================================================================
class Scene_Map < Scene_Base
  #--------------------------------------------------------------------------#
  # Alias method; Frame Update                                               #
  #--------------------------------------------------------------------------#
  alias :csca_vs_update :update
  def update
    csca_vs_update
    if @fish_window
      @fish_window.open if !@fish_window.opened && $game_map.csca_fishing
      @fish_window.close if @fish_window.opened && !$game_map.csca_fishing
    end
  end
  #--------------------------------------------------------------------------#
  # Alias method; disallow scene change while fishing                        #
  #--------------------------------------------------------------------------#
  alias :csca_vs_fish_req :scene_change_ok?
  def scene_change_ok?
    !$game_map.csca_fishing && csca_vs_fish_req
  end
  #--------------------------------------------------------------------------#
  # Alias method; create fish window                                         #
  #--------------------------------------------------------------------------#
  alias :csca_vs_fish_window :create_all_windows
  def create_all_windows
    csca_vs_fish_window
    create_fish_window unless !$game_switches[CSCA::VEHICLE::FISHING_ENABLED]
  end
  #--------------------------------------------------------------------------#
  # Fish Window                                                              #
  #--------------------------------------------------------------------------#
  def create_fish_window
    @fish_window = CSCA_Window_Fishing.new(Graphics.width/4,Graphics.height/3)
    @fish_window.close
  end
end
#==============================================================================
# ** CSCA_Window_Fishing
#------------------------------------------------------------------------------
# Displays time bar and catch.
#==============================================================================
class CSCA_Window_Fishing < Window_Base
  attr_reader :opened
  #--------------------------------------------------------------------------#
  # Initialize                                                               #
  #--------------------------------------------------------------------------#
  def initialize(x,y,w = Graphics.width/2,h = line_height*3)
    super(x,y,w,h)
    self.opacity = 0
    self.contents_opacity = 0
    @time_left = 0
    @opened = false
    @display_catch = false
    refresh
  end
  #--------------------------------------------------------------------------#
  # Refresh                                                                  #
  #--------------------------------------------------------------------------#
  def refresh
    contents.clear
    contents.font.bold = true
    draw_text(0,0,contents.width,line_height,"Fishing",1)
    contents.font.bold = false
    update_gauge if $game_map.csca_fishing
  end
  #--------------------------------------------------------------------------#
  # Update Gauge                                                             #
  #--------------------------------------------------------------------------#
  def update_gauge
    if @display_catch
      $game_map.caught_fish.nil? ? fish = "No Catch!" : fish = $data_items[$game_map.caught_fish].name
      draw_text(0,line_height,contents.width,line_height,fish,1)
      check_input
    else
      draw_gauge(0,line_height,contents.width,get_rate,
        text_color(CSCA::VEHICLE::FISH_COLOR1),text_color(CSCA::VEHICLE::FISH_COLOR2))
      draw_text(0,line_height,contents.width,line_height,sprintf("%1.2f seconds",@time_left.to_f/60))
      if @time_left <= CSCA::VEHICLE::CATCH_TIME - $game_map.fish_time
        Audio.se_play("Audio/SE/"+CSCA::VEHICLE::CATCH_SOUND,80) unless CSCA::VEHICLE::CATCH_SOUND.nil?
        $game_party.gain_item($data_items[$game_map.caught_fish], 1) unless $game_map.caught_fish.nil?
        @display_catch = true
        @time_left = 0
      end
    end
  end
  #--------------------------------------------------------------------------#
  # get Gauge Rate                                                           #
  #--------------------------------------------------------------------------#
  def get_rate
    @time_left.to_f/CSCA::VEHICLE::CATCH_TIME
  end
  #--------------------------------------------------------------------------#
  # Frame Update                                                             #
  #--------------------------------------------------------------------------#
  def update
    refresh if $game_map.csca_fishing
    @time_left -= 1 if @time_left > 0
  end
  #--------------------------------------------------------------------------#
  # Open Window                                                              #
  #--------------------------------------------------------------------------#
  def open
    @time_left = CSCA::VEHICLE::CATCH_TIME
    self.opacity = 255
    self.contents_opacity = 255
    @opened = true
  end
  #--------------------------------------------------------------------------#
  # Close Window                                                             #
  #--------------------------------------------------------------------------#
  def close
    @time_left = 0
    self.opacity = 0
    self.contents_opacity = 0
    @opened = false
  end
  #--------------------------------------------------------------------------#
  # Input for closing fishing window                                         #
  #--------------------------------------------------------------------------#
  def check_input
    if Input.press?(:C)
      close
      @display_catch = false
      $game_map.csca_fishing = false
    end
  end
end
#==============================================================================
# ** Game_Vehicle
#------------------------------------------------------------------------------
# Don't allow map BGM to play if transferring between vehicle interiors, restrict
# landing ability to a region.
# Aliases: get_off, land_ok?
#==============================================================================
class Game_Vehicle < Game_Character
  #--------------------------------------------------------------------------#
  # Alias Method                                                             #
  #--------------------------------------------------------------------------#
  alias :csca_vehicle_get_off :get_off
  def get_off
    if $game_player.csca_vehicle_transfer?
      @driving = false
      @walk_anime = false
      @step_anime = false
      @direction = 4
    else
      csca_vehicle_get_off
      $game_map.autoplay
    end
  end
  #--------------------------------------------------------------------------#
  # Alias Method; Only land if in region                                     #
  #--------------------------------------------------------------------------#
  alias :csca_vehicle_land_req :land_ok?
  def land_ok?(x, y, d)
    return false if $game_map.csca_fishing
    if @type != :airship && CSCA::VEHICLE::DOCK_REGION != 0
      return false unless $game_map.region_id(x, y) == CSCA::VEHICLE::DOCK_REGION
    end
    if @type == :airship && CSCA::VEHICLE::LAND_REGION != 0
      return false unless $game_map.region_id(x, y) == CSCA::VEHICLE::LAND_REGION
    end
    csca_vehicle_land_req(x, y, d)
  end
  #--------------------------------------------------------------------------#
  # Enter vehicle possible?                                                  #
  #--------------------------------------------------------------------------#
  def csca_enter_ok?(x, y)
    return true if @type == :airship
    return true if $game_map.region_id(x, y) == CSCA::VEHICLE::DOCK_REGION
    return false
  end
end