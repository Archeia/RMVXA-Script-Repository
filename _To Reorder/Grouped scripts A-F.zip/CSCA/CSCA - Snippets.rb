=begin
CSCA Snippets
Created by: Casper Gaming (http://www.caspergaming.com/)

Compatibility:
Made for RPGVXAce
IMPORTANT: ALL CSCA Scripts should be compatible with each other unless
otherwise noted.

FFEATURES:
-Adds TP bar to the main menu for each actor.
-Recovers all on level up.
-Disallow changing formation of first actor
-Allow events to move through followers
-Show animation by skill ID(Set with variable).
-Run Common Event by skill ID(set with variable).

This script is Plug and play. Instructions further down above each snippet.

CREDIT:
Free to use in noncommercial games if credit is given to:
Casper Gaming (http://www.caspergaming.com/)

To use in a commercial game, please purchase a license here:
http://www.caspergaming.com/licenses.html

TERMS:
http://www.caspergaming.com/terms_of_use.html
=end

# Draws TP #
# Plug n Play #
class Window_Base
  alias csca_snippets_simple_status draw_actor_simple_status
  def draw_actor_simple_status(actor, x, y)
    csca_snippets_simple_status(actor,x,y)
    draw_actor_tp(actor,x,y+line_height*2,100)
  end
end

# Recovers all on level up #
# Plug n Play #
class Game_Actor < Game_Battler
  alias csca_snippets_lvlup level_up
  def level_up
    csca_snippets_lvlup
    recover_all
  end
end

# Disallows changing formation of first actor #
# Plug n Play #
class Scene_Menu < Scene_MenuBase
  alias csca_snippets_on_formation_ok on_formation_ok
  def on_formation_ok
    if @status_window.index != 0
      csca_snippets_on_formation_ok
    else
      Sound.play_buzzer
      @status_window.activate
    end
  end
end

# Make events able to pass through followers #
# Plug n Play #
class Game_Player < Game_Character
  def collide?(x, y)
    !@through && pos?(x, y)
  end
end

# Show Animation ID based on variable #
# Plug n Play #
# Use script call:
# csca_animation_variable(variable_id, target_event_id, true/false, true/false)
# The first true/false determines whether to wait for completion or not.
# The second determines whether to use skill ID to determine animation ID or
# just use animation id
class Game_Interpreter
  def csca_animation_variable(variable_id, target, wait = false, skill = true)
    character = get_character(target)
    if character
      skill ? character.animation_id=$data_skills[$game_variables[variable_id]].animation_id :
      character.animation_id = $game_variables[variable_id]
      Fiber.yield while character.animation_id > 0 if wait
    end
  end
end

# State resists death once, if target is knockout revives target to 1hp.
class Game_Battler < Game_BattlerBase
  alias csca_snippets_die die
  def die
    if state?(26) # Change the number to any state ID.
      @hp = 1
      remove_state(26) # Change the number to any state ID.
    else
      csca_snippets_die
    end
  end
end

# Runs Common Event based on variable #
# Plug n Play #
# Use script call:
# csca_skill_commonev(variable_id)
class Game_Interpreter
  def csca_skill_commonev(variable_id)
    skill = $data_skills[$game_variables[variable_id]]
    for effect in skill.effects
      if effect.code == 44
        common_event = $data_common_events[effect.data_id]
        break
      end
    end
    if common_event
      child = Game_Interpreter.new(@depth + 1)
      child.setup(common_event.list, same_map? ? @event_id : 0)
      child.run
    end
  end
end