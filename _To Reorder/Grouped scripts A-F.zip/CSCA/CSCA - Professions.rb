=begin
CSCA Professions
version: 1.0.3 (Released: June 9, 2013)
Created by: Casper Gaming (http://www.caspergaming.com/)

Compatibility:
Made for RPGVXAce
IMPORTANT: ALL CSCA Scripts should be compatible with each other unless
otherwise noted.
Requires CSCA Core Script v1.0.6+
For levelup/down toast message, get the CSCA Toast Manager v1.1.0+
LINK: http://www.rpgmakervxace.net/topic/13960-csca-toast-manager/

FFEATURES
Creates a profession system that allows you to easily set up many
different professions.

SETUP
Set up required. Instructions below.
================================================================================
UPDATES
version 1.0.1
- Cleaned code up a bit.
- Can now disable toasts for this script.
- Added toast for profession discovery.

version 1.0.2
- Profession icons should draw at the correct y coordinate now.

version 1.0.3
- Added faster access to profession level for achievement system.
================================================================================
CREDIT:
Free to use in noncommercial games if credit is given to:
Casper Gaming (http://www.caspergaming.com/)

To use in a commercial game, please purchase a license here:
http://www.caspergaming.com/licenses.html

TERMS:
http://www.caspergaming.com/terms_of_use.html
=end
module CSCA
  module PROFESSIONS
#==============================================================================
# ** Important Script Calls
#==============================================================================
# All script calls use the profession symbol to reference a [profession].
#------------------------------------------------------------------------------
# change_prof_exp(profession, amount)
# Used to change the [profession]'s exp by [amount]. Can be negative.
#
# change_prof_lv(profession, amount)
# Adds [amount] to the [profession]'s level. Sets EXP to base exp amount for the
# new level. Can be negative.
#
# change_prof_name(profession, name)
# Sets [profession]'s name to [name].
#
# discover_prof(profession [, boolean])
# Sets the [profession]'s discovered status to [boolean] (aka true or false).
# Including the boolean parameter is optional; if not specified, true is assumed.
#==============================================================================
# ** Begin Setup
#==============================================================================
    PROFESSION = [] # Don't Touch
    
    TOTAL = "Total Level: " # Text used for the total window.
    HEADER = "Professions"  # Text used in the header window.
    UNKNOWN = "? ? ? ? ?"   # Text used for undiscovered professions in selection window.
    UNDISCOVERED = "This profession has not been discovered." # Text used in information window if undiscovered.
    USE_ICONS = true # Use icons before profession name in selection window?
    SHOW_UNDISCOVERED = true # Show unknown professions in selection window?
    LVLUP_TEXT = "skill increased!" # Text shown in toast window on lvlup.
    LVLDOWN_TEXT = "skill decreased!" # Text shown in toast window on lvldown.
    SHOW_TOASTS = true # Allow toast messages to display?
    TOAST_DISCOVERED = "profession" # For use when new profession is discovered.
    
    #SKILL[0] = {
    #:name => "Cooking",    # The name of the profession.
    #:symbol => :cooking,   # The symbol is used to identify the profession.
    #:discovered => true,   # Discovery state of the profession. If false, will not show up in the menu.
    #:level => 1,           # Starting level
    #:max => 99,            # Max level
    #:exp = 0,              # Starting experience
    #:exp_curve => [10, 0, 10, 10],         # Exp curve (uses same formula as actors). Set to nil if not using.
    #:exp_array => [0,1,2,3,4,5,6,7,8,etc.],# Array containing the required exp for each level. Must be the size of the max level value. Set to nil if not using.
    #:image => "Skills/Cooking.png",        # Image path used to represent the profession. 72x72. Set to nil if not using.
    #:icon => 0,                            # Icon used to represent the profession.
    #:color => Color.new(210,105,30),       # RGB with optional 4th Alpha value. Used in determining the color of the profession name whenever applicable.
    #:desc => ["Allows you to cook."]       # Descriptive text shown below all other info. Supports multiple lines.
    
    #:show_recipes => false, # if using CSCA Crafting System, set to true to show discovered recipe total.
    #:recipe_type => :cooking, # if using CSCA Crafting System, set to the recipe type associated with this profession.
    #}
    
    PROFESSION[0] = {
    :name => "Cooking",
    :symbol => :cooking,
    :discovered => true,
    :level => 1,
    :max => 99,
    :exp => 0,
    :exp_curve => [10, 0, 10, 10],
    :exp_array => nil,
    :image => "Pictures/Cooking.png",
    :icon => 238,
    :color => Color.new(210,105,30),
    :show_recipes => true,
    :recipe_type => :cooking,
    :desc => ["Allows you to cook food items.",
              " ",
              "Speak to any chef to train."]
    }
    
    PROFESSION[1] = {
    :name => "Fishing",
    :symbol => :fishing,
    :discovered => true,
    :level => 1,
    :max => 99,
    :exp => 0,
    :exp_curve => [10, 0, 10, 10],
    :exp_array => nil,
    :image => nil,
    :icon => 292,
    :color => Color.new(65,105,225),
    :show_recipes => false,
    :recipe_type => :fishing,
    :desc => ["Allows you to catch fish."]
    }
    
    PROFESSION[2] = {
    :name => "Mining",
    :symbol => :mining,
    :discovered => true,
    :level => 1,
    :max => 99,
    :exp => 0,
    :exp_curve => [10, 0, 10, 10],
    :exp_array => nil,
    :image => nil,
    :icon => 276,
    :color => Color.new(159,182,205),
    :show_recipes => false,
    :recipe_type => :mining,
    :desc => ["Allows you to prospect and","mine ore."]
    }
#==============================================================================
# ** End Setup
#==============================================================================
  end
end
$imported = {} if $imported.nil?
$imported["CSCA-Professions"] = true
msgbox('Missing Script: CSCA Core Script! CSCA Professions requires this
script to work properly.') if !$imported["CSCA-Core"]
#==============================================================================
# ** Game_Interpreter
#------------------------------------------------------------------------------
#  Addition of commands related to managing professions.
#==============================================================================
class Game_Interpreter
  #--------------------------------------------------------------------------
  # Change profession exp (add / subtract)
  #--------------------------------------------------------------------------
  def change_prof_exp(sym, amount)
    $csca.change_profession_exp(sym, amount)
  end
  #--------------------------------------------------------------------------
  # Discover profession
  #--------------------------------------------------------------------------
  def discover_prof(sym, discovered = true)
    $csca.change_profession_discovery(sym, discovered)
  end
  #--------------------------------------------------------------------------
  # Change Profession Level
  #--------------------------------------------------------------------------
  def change_prof_lv(sym, level)
    $csca.change_profession_level(sym, level)
  end
  #--------------------------------------------------------------------------
  # Change Profession Name
  #--------------------------------------------------------------------------
  def change_prof_name(sym, name)
    $csca.change_profession_name(sym, name)
  end
end
#==============================================================================
# ** CSCA_Core
#------------------------------------------------------------------------------
# Added profession handling.
#==============================================================================
class CSCA_Core
  attr_reader :professions
  attr_reader :profession_ach_cache
  #--------------------------------------------------------------------------
  # Alias Method; Object Initialization
  #--------------------------------------------------------------------------
  alias :csca_profession_initialize :initialize
  def initialize
    csca_profession_initialize
    initialize_professions
  end
  #--------------------------------------------------------------------------
  # Create profession data
  #--------------------------------------------------------------------------
  def initialize_professions
    @professions = []
    @profession_ach_cache = {}
    CSCA::PROFESSIONS::PROFESSION.each do |profession|
      @professions.push(CSCA_Professions.new(profession))
      @profession_ach_cache[profession[:symbol]] = profession[:level]
    end
  end
  #--------------------------------------------------------------------------
  # Get profession
  #--------------------------------------------------------------------------
  def get_profession(symbol)
    @professions.each do |profession|
      return profession if profession.symbol == symbol
    end
  end
  #--------------------------------------------------------------------------
  # Change Profession Discovered status
  #--------------------------------------------------------------------------
  def change_profession_discovery(sym, discovered)
    profession = get_profession(sym)
    profession.discovered = discovered
    $csca.reserve_toast([:profession_discovery, profession]) if $imported["CSCA-ToastManager"] && CSCA::PROFESSIONS::SHOW_TOASTS && discovered
  end
  #--------------------------------------------------------------------------
  # Change Profession Level
  #--------------------------------------------------------------------------
  def change_profession_level(sym, level)
    profession = get_profession(sym)
    profession.level += level
    profession.exp = current_level_exp(profession)
    @profession_ach_cache[profession.symbol] = profession.level
  end
  #--------------------------------------------------------------------------
  # Change Profession Name
  #--------------------------------------------------------------------------
  def change_profession_name(sym, name)
    profession = get_profession(sym)
    profession.name = name
  end
  #--------------------------------------------------------------------------
  # Add/Remove profession EXP
  #--------------------------------------------------------------------------
  def change_profession_exp(sym, amount)
    profession = get_profession(sym)
    profession.exp += amount
    profession.exp = 0 if profession.exp < 0
    check_level(profession)
  end
  #--------------------------------------------------------------------------
  # Automatic Level Up/Down
  #--------------------------------------------------------------------------
  def check_level(profession)
    prof_level_up(profession) while profession.level < profession.max_level && profession.exp >= next_level_exp(profession)
    prof_level_down(profession) while profession.exp < current_level_exp(profession)
  end
  #--------------------------------------------------------------------------
  # Check exp required for specific level
  #--------------------------------------------------------------------------
  def exp_for_level(sym, level)
    profession = get_profession(sym)
    return profession.level_exp_curve(level) if profession.use_exp_curve?
    return profession.exp_array[level - 1]
  end
  #--------------------------------------------------------------------------
  # Get exp required for next level
  #--------------------------------------------------------------------------
  def next_level_exp(profession)
    return profession.level_exp_curve(profession.level + 1) if profession.use_exp_curve?
    return profession.exp_array[profession.level]
  end
  #--------------------------------------------------------------------------
  # Get exp required for current level
  #--------------------------------------------------------------------------
  def current_level_exp(profession)
    return profession.level_exp_curve(profession.level) if profession.use_exp_curve?
    return profession.exp_array[profession.level - 1]
  end
  #--------------------------------------------------------------------------
  # Calculate total / earned levels of all professions
  #--------------------------------------------------------------------------
  def calculate_levels(param)
    total = 0
    @professions.each do |profession|
      param == :earned ? total += profession.level : total += profession.max_level
    end
    return total
  end
  #--------------------------------------------------------------------------
  # Level Up
  #--------------------------------------------------------------------------
  def prof_level_up(profession)
    profession.level += 1
    $csca.reserve_toast([:profession_lvlup, profession]) if $imported["CSCA-ToastManager"] && CSCA::PROFESSIONS::SHOW_TOASTS
    @profession_ach_cache[profession.symbol] = profession.level
  end
  #--------------------------------------------------------------------------
  # Level Down
  #--------------------------------------------------------------------------
  def prof_level_down(profession)
    profession.level -= 1
    $csca.reserve_toast([:profession_lvldown, profession]) if $imported["CSCA-ToastManager"] && CSCA::PROFESSIONS::SHOW_TOASTS
    @profession_ach_cache[profession.symbol] = profession.level
  end
end
#==============================================================================
# ** CSCA_Professions
#------------------------------------------------------------------------------
# Provides profession data and methods.
#==============================================================================
class CSCA_Professions
  attr_accessor :name
  attr_accessor :exp
  attr_accessor :discovered
  attr_accessor :level
  attr_accessor :recipes
  attr_reader :color
  attr_reader :image
  attr_reader :icon
  attr_reader :desc
  attr_reader :max_level
  attr_reader :symbol
  attr_reader :exp_curve
  attr_reader :exp_array
  attr_reader :show_recipes
  #--------------------------------------------------------------------------
  # Object Initialization
  #--------------------------------------------------------------------------
  def initialize(profession)
    @name = profession[:name]
    @symbol = profession[:symbol]
    @discovered = profession[:discovered]
    @level = profession[:level]
    @max_level = profession[:max]
    @exp = profession[:exp]
    @exp_curve = profession[:exp_curve]
    @exp_array = profession[:exp_array]
    @icon = profession[:icon]
    @image = profession[:image]
    @desc = profession[:desc]
    @recipe_type = profession[:recipe_type]
    @show_recipes = profession[:show_recipes]
    @color = profession[:color]
    @recipes = []
  end
  #--------------------------------------------------------------------------
  # Get experience type
  #--------------------------------------------------------------------------
  def use_exp_curve?
    !@exp_curve.nil?
  end
  #--------------------------------------------------------------------------
  # Formula used to calculate experience for a level (if using curve)
  #--------------------------------------------------------------------------
  def level_exp_curve(level)
    lv = level.to_f
    basis = @exp_curve[0].to_f
    extra = @exp_curve[1].to_f
    acc_a = @exp_curve[2].to_f
    acc_b = @exp_curve[3].to_f
    return (basis*((lv-1)**(0.9+acc_a/250))*lv*(lv+1)/
      (6+lv**2/50/acc_b)+(lv-1)*extra).round.to_i
    end
end
#==============================================================================
# ** CSCA_Scene_Professions
#------------------------------------------------------------------------------
# Handles the profession scene
#==============================================================================
class CSCA_Scene_Professions < Scene_MenuBase
  #--------------------------------------------------------------------------
  # Start Processing
  #--------------------------------------------------------------------------
  def start
    super
    create_head_window
    create_selection_window
    create_info_window
    create_totals_window
  end
  #--------------------------------------------------------------------------
  # Create header window
  #--------------------------------------------------------------------------
  def create_head_window
    @head_window = CSCA_Window_Header.new(0,0,CSCA::PROFESSIONS::HEADER)
  end
  #--------------------------------------------------------------------------
  # Create selection window
  #--------------------------------------------------------------------------
  def create_selection_window
    @select_window = CSCA_Window_ProfessionSelect.new(0,@head_window.height,Graphics.width/3,Graphics.height-@head_window.height*2)
    @select_window.set_handler(:cancel, method(:return_scene))
    @select_window.activate
  end
  #--------------------------------------------------------------------------
  # Create info window
  #--------------------------------------------------------------------------
  def create_info_window
    x = @select_window.width
    @info_window = CSCA_Window_ProfessionInfo.new(x,@head_window.height,Graphics.width-x,@select_window.height)
    @select_window.help_window = @info_window
  end
  #--------------------------------------------------------------------------
  # Create totals window
  #--------------------------------------------------------------------------
  def create_totals_window
    @totals_window = CSCA_Window_ProfessionTotals.new(0,@select_window.height+@head_window.height,Graphics.width,@head_window.height)
  end
end
#==============================================================================
# ** CSCA_Window_ProfessionSelect
#------------------------------------------------------------------------------
# Selection window for the various professions
#==============================================================================
class CSCA_Window_ProfessionSelect < Window_Selectable
  #--------------------------------------------------------------------------
  # Object Initialization
  #--------------------------------------------------------------------------
  def initialize(x, y, w, h)
    super(x, y, w, h)
    @data = []
    refresh
    select(0)
  end
  #--------------------------------------------------------------------------
  # Get Item Max
  #--------------------------------------------------------------------------
  def item_max
    @data ? @data.size : 1
  end
  #--------------------------------------------------------------------------
  # Get Item
  #--------------------------------------------------------------------------
  def item
    @data && index >= 0 ? @data[index] : nil
  end
  #--------------------------------------------------------------------------
  # Populate item list
  #--------------------------------------------------------------------------
  def make_item_list
    @data = $csca.professions.select {|item| include?(item)}
  end
  #--------------------------------------------------------------------------
  # Show item in list?
  #--------------------------------------------------------------------------
  def include?(item)
    return CSCA::PROFESSIONS::SHOW_UNDISCOVERED || item.discovered
  end
  #--------------------------------------------------------------------------
  # Draw Items
  #--------------------------------------------------------------------------
  def draw_item(index)
    item = @data[index]
    if item
      rect = item_rect(index)
      name = item.discovered ? item.name : CSCA::PROFESSIONS::UNKNOWN
      x = rect.x
      if CSCA::PROFESSIONS::USE_ICONS
        draw_icon(item.icon, x, rect.y) 
        x += 24
      end
      draw_text(x, rect.y, contents.width-x, line_height, name)
    end
  end
  #--------------------------------------------------------------------------
  # Refresh
  #--------------------------------------------------------------------------
  def refresh
    make_item_list
    create_contents
    draw_all_items
  end
  #--------------------------------------------------------------------------
  # Update Help Window
  #--------------------------------------------------------------------------
  def update_help
    @help_window.set_item(item) if @help_window
  end
end
#==============================================================================
# ** CSCA_Window_ProfessionInfo
#------------------------------------------------------------------------------
# Shows data on each profession
#==============================================================================
class CSCA_Window_ProfessionInfo < Window_Base
  #--------------------------------------------------------------------------
  # Object Initialization
  #--------------------------------------------------------------------------
  def initialize(x, y, w, h)
    super(x, y, w, h)
  end
  #--------------------------------------------------------------------------
  # Set Item
  #--------------------------------------------------------------------------
  def set_item(profession)
    contents.clear
    contents.font.size = 24
    @profession = profession
    @profession.discovered ? draw_profession_information : draw_unknown_text
  end
  #--------------------------------------------------------------------------
  # Draw profession information
  #--------------------------------------------------------------------------
  def draw_profession_information
    draw_profession_image
    draw_profession_name
    contents.font.size = 20
    draw_profession_level(line_height)
    draw_profession_exp(line_height*2-4, "Experience: ", 72, :current)
    draw_profession_exp(line_height*3, "Experience to Next Level: ", 0, :next)
    draw_profession_exp(line_height*4-4, "Experience to Max Level: ", 0, :max)
    draw_profession_desc(line_height*6-12)
  end
  #--------------------------------------------------------------------------
  # Draw unknown text
  #--------------------------------------------------------------------------
  def draw_unknown_text
    draw_text_ex(0,0,CSCA::PROFESSIONS::UNDISCOVERED)
  end
  #--------------------------------------------------------------------------
  # Draw icon/image
  #--------------------------------------------------------------------------
  def draw_profession_image
    if @profession.image.nil?
      icon_index = @profession.icon
      bitmap = Cache.system("Iconset")
      rect = Rect.new(icon_index % 16 * 24, icon_index / 16 * 24, 24, 24)
      target = Rect.new(0,0,72,72)
      contents.stretch_blt(target, bitmap, rect)
    else
      bitmap = Bitmap.new("Graphics/"+@profession.image)
      target = Rect.new(0,0,72,72)
      contents.stretch_blt(target, bitmap, bitmap.rect, 255)
    end
  end
  #--------------------------------------------------------------------------
  # Draw name
  #--------------------------------------------------------------------------
  def draw_profession_name
    contents.font.bold = true
    change_color(@profession.color)
    draw_text(72, 0, contents.width-72, line_height+8, @profession.name, 1)
    change_color(normal_color)
    contents.font.bold = false
  end
  #--------------------------------------------------------------------------
  # Draw level
  #--------------------------------------------------------------------------
  def draw_profession_level(height)
    s1 = "Level: "
    s2 = @profession.level.to_s + " / " + @profession.max_level.to_s
    x = 72 + text_size(s1).width
    change_color(system_color)
    draw_text(72, height, contents.width-72, line_height, s1)
    change_color(normal_color)
    draw_text(x, height, contents.width-72, line_height,s2)
  end
  #--------------------------------------------------------------------------
  # Draw experience
  #--------------------------------------------------------------------------
  def draw_profession_exp(height, s1, ox, lv_sym)
    if lv_sym == :next
      exp = $csca.split_number($csca.next_level_exp(@profession) - @profession.exp)
      exp = 0 if @profession.level == @profession.max_level
    end
    if lv_sym == :max
      exp = $csca.split_number($csca.exp_for_level(@profession.symbol, @profession.max_level) - @profession.exp) 
      exp = 0 if @profession.level == @profession.max_level
    end
    exp = $csca.split_number(@profession.exp) if lv_sym == :current
    x = ox + text_size(s1).width
    change_color(system_color)
    draw_text(ox, height, contents.width-ox, line_height, s1)
    change_color(normal_color)
    if exp[0] >= 1
      draw_text(x,height,contents.width-x,line_height,sprintf("%d,%03d,%03d", exp[0], exp[1], exp[2]))
    elsif exp[0] == 0 && exp[1] >= 1
      draw_text(x,height,contents.width-x,line_height,sprintf("%d,%03d", exp[1], exp[2]))
    else
      draw_text(x,height,contents.width-x,line_height,sprintf("%d", exp[2]))
    end
  end
  #--------------------------------------------------------------------------
  # Draw description
  #--------------------------------------------------------------------------
  def draw_profession_desc(height)
    s1 = "Note: "
    x =  text_size(s1).width
    change_color(system_color)
    draw_text(0, height, contents.width, line_height, s1)
    change_color(normal_color)
    @profession.desc.each do |string|
      draw_text(x, height, contents.width, line_height, string)
      x = 0
      height += (line_height-4)
    end
  end
end
#==============================================================================
# ** CSCA_Window_ProfessionTotals
#------------------------------------------------------------------------------
# Shows the total level
#==============================================================================
class CSCA_Window_ProfessionTotals < Window_Base
  #--------------------------------------------------------------------------
  # Object Initialization
  #--------------------------------------------------------------------------
  def initialize(x, y, w, h)
    super(x, y, w, h)
    refresh
  end
  #--------------------------------------------------------------------------
  # Refresh
  #--------------------------------------------------------------------------
  def refresh
    contents.clear
    x = text_size(CSCA::PROFESSIONS::TOTAL).width
    s1 = $csca.calculate_levels(:earned)
    s2 = $csca.calculate_levels(:total)
    change_color(system_color)
    draw_text(0, 0, contents.width, line_height, CSCA::PROFESSIONS::TOTAL)
    change_color(normal_color)
    draw_text(x, 0, contents.width-x, line_height, s1.to_s + " / " + s2.to_s)
  end
end
#==============================================================================
# ** CSCA_Window_Toast
#------------------------------------------------------------------------------
# Show toasts for level up/down
#==============================================================================
class CSCA_Window_Toast < Window_Base
  alias :csca_prof_refresh :refresh
  def refresh(params)
    csca_prof_refresh(params)
    if params[0] == :profession_lvlup || params[0] == :profession_lvldown
      contents.font.size = 20
      profession = params[1]
      draw_icon(profession.icon, 0, 0)
      change_color(profession.color)
      draw_text(24, 0, contents.width-24, line_height, profession.name)
      change_color(normal_color)
      x = 24 + text_size(profession.name + " ").width
      draw_text(x, 0, contents.width-x, line_height, params[0] == :profession_lvlup ? CSCA::PROFESSIONS::LVLUP_TEXT : CSCA::PROFESSIONS::LVLDOWN_TEXT)
      draw_text(0, line_height, contents.width, line_height, sprintf("Level: %s/%s", profession.level.to_s, profession.max_level.to_s), 1)
      contents.font.size = 24
    end
    if params[0] == :profession_discovery
      draw_text(0, 0, contents.width, line_height, sprintf("New %s discovered!", CSCA::PROFESSIONS::TOAST_DISCOVERED), 1)
      ix = (contents.width/2) - (text_size(params[1].name).width/2) - 16
      draw_icon(params[1].icon, ix, line_height)
      change_color(params[1].color)
      draw_text(12, line_height, contents.width, line_height, params[1].name, 1)
      change_color(normal_color)
    end
  end
end