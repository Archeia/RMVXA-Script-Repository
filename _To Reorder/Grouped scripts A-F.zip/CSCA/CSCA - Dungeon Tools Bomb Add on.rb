=begin
CSCA Dungeon Tools Bomb addon
version: 1.4b
Created by: Casper Gaming (http://www.caspergaming.com/)
Mod by: Roninator2
Compatibility:
Made for RPGVXAce
IMPORTANT: ALL CSCA Scripts should be compatible with each other unless
otherwise noted.
REQUIRES CSCA Core Script
Place below CSCA Dungeon Tools script
=end

module CSCA_DUNGEON_TOOLS # Don't touch this.
   # Value 1-5
  BOMB_DISTANCE = 3 # how many squares away from bomb rounded into a circle
end

class Game_Map
  include CSCA_DUNGEON_TOOLS
  def do_bomb_effect(bomb)
    x = bomb.x
    y = bomb.y
    @csca_bomb_event_id5 = event_id_xy(x, y)
    x += 1
    @csca_bomb_event_id1 = event_id_xy(x, y)
    x -= 2
    @csca_bomb_event_id2 = event_id_xy(x, y)
    x = bomb.x
    y += 1
    @csca_bomb_event_id3 = event_id_xy(x, y)
    y -= 2
    @csca_bomb_event_id4 = event_id_xy(x, y)
    # BOMB distance greater than 1
    if CSCA_DUNGEON_TOOLS::BOMB_DISTANCE >= 2
    x += 1
    @csca_bomb_event_id6 = event_id_xy(x, y)
    y += 2
    @csca_bomb_event_id7 = event_id_xy(x, y)
    x -= 2
    @csca_bomb_event_id8 = event_id_xy(x, y)
    y -= 2
    @csca_bomb_event_id9 = event_id_xy(x, y)
    y -= 1
    x += 1
    @csca_bomb_event_id10 = event_id_xy(x, y)
    x += 2
    y += 2
    @csca_bomb_event_id11 = event_id_xy(x, y)
    x -= 2
    y += 2
    @csca_bomb_event_id12 = event_id_xy(x, y)
    x -= 2
    y -= 2
    @csca_bomb_event_id13 = event_id_xy(x, y)
    end
    # BOMB distance greater than 2
    if CSCA_DUNGEON_TOOLS::BOMB_DISTANCE >= 3
    x -= 1
    @csca_bomb_event_id14 = event_id_xy(x, y)
    y -= 1
    x += 1
    @csca_bomb_event_id15 = event_id_xy(x, y)
    y -= 1
    x += 1
    @csca_bomb_event_id16 = event_id_xy(x, y)
    y -= 1
    x += 1
    @csca_bomb_event_id17 = event_id_xy(x, y)
    y += 1
    x += 1
    @csca_bomb_event_id18 = event_id_xy(x, y)
    y += 1
    x += 1
    @csca_bomb_event_id19 = event_id_xy(x, y)
    y += 1
    x += 1
    @csca_bomb_event_id20 = event_id_xy(x, y)
    x -= 1
    y += 1
    @csca_bomb_event_id21 = event_id_xy(x, y)
    x -= 1
    y += 1
    @csca_bomb_event_id22 = event_id_xy(x, y)
    x -= 1
    y += 1
    @csca_bomb_event_id23 = event_id_xy(x, y)
    y -= 1
    x -= 1
    @csca_bomb_event_id24 = event_id_xy(x, y)
    y -= 1
    x -= 1
    @csca_bomb_event_id25 = event_id_xy(x, y)
    end
    # BOMB distance greater than 3
    if CSCA_DUNGEON_TOOLS::BOMB_DISTANCE >= 4
    y -= 1
    x -= 2
    @csca_bomb_event_id26 = event_id_xy(x, y)
    y -= 1
    x += 1
    @csca_bomb_event_id27 = event_id_xy(x, y)
    y -= 1
    x += 1
    @csca_bomb_event_id28 = event_id_xy(x, y)
    y -= 1
    x += 1
    @csca_bomb_event_id29 = event_id_xy(x, y)
    y -= 1
    x += 1
    @csca_bomb_event_id30 = event_id_xy(x, y)
    x += 1
    y += 1
    @csca_bomb_event_id31 = event_id_xy(x, y)
    x += 1
    y += 1
    @csca_bomb_event_id32 = event_id_xy(x, y)
    x += 1
    y += 1
    @csca_bomb_event_id33 = event_id_xy(x, y)
    x += 1
    y += 1
    @csca_bomb_event_id34 = event_id_xy(x, y)
    x -= 1
    y += 1
    @csca_bomb_event_id35 = event_id_xy(x, y)
    x -= 1
    y += 1
    @csca_bomb_event_id36 = event_id_xy(x, y)
    x -= 1
    y += 1
    @csca_bomb_event_id37 = event_id_xy(x, y)
    x -= 1
    y += 1
    @csca_bomb_event_id38 = event_id_xy(x, y)
    x -= 1
    y -= 1
    @csca_bomb_event_id39 = event_id_xy(x, y)
    x -= 1
    y -= 1
    @csca_bomb_event_id40 = event_id_xy(x, y)
    x -= 1
    y -= 1
    @csca_bomb_event_id41 = event_id_xy(x, y)
    end
    # BOMB distance greater than 4
    if CSCA_DUNGEON_TOOLS::BOMB_DISTANCE >= 5
    y -= 1
    x -= 2
    @csca_bomb_event_id42 = event_id_xy(x, y)
    y -= 1
    x += 1
    @csca_bomb_event_id43 = event_id_xy(x, y)
    y -= 1
    x += 1
    @csca_bomb_event_id44 = event_id_xy(x, y)
    y -= 1
    x += 1
    @csca_bomb_event_id45 = event_id_xy(x, y)
    y -= 1
    x += 1
    @csca_bomb_event_id46 = event_id_xy(x, y)
    y -= 1
    x += 1
    @csca_bomb_event_id47 = event_id_xy(x, y)
    y += 1
    x += 1
    @csca_bomb_event_id48 = event_id_xy(x, y)
    y += 1
    x += 1
    @csca_bomb_event_id49 = event_id_xy(x, y)
    y += 1
    x += 1
    @csca_bomb_event_id50 = event_id_xy(x, y)
    y += 1
    x += 1
    @csca_bomb_event_id51 = event_id_xy(x, y)
    y += 1
    x += 1
    @csca_bomb_event_id52 = event_id_xy(x, y)
    y += 1
    x -= 1
    @csca_bomb_event_id53 = event_id_xy(x, y)
    y += 1
    x -= 1
    @csca_bomb_event_id54 = event_id_xy(x, y)
    y += 1
    x -= 1
    @csca_bomb_event_id55 = event_id_xy(x, y)
    y += 1
    x -= 1
    @csca_bomb_event_id56 = event_id_xy(x, y)
    y += 1
    x -= 1
    @csca_bomb_event_id57 = event_id_xy(x, y)
    y -= 1
    x -= 1
    @csca_bomb_event_id58 = event_id_xy(x, y)
    y -= 1
    x -= 1
    @csca_bomb_event_id59 = event_id_xy(x, y)
    y -= 1
    x -= 1
    @csca_bomb_event_id60 = event_id_xy(x, y)
    y -= 1
    x -= 1
    @csca_bomb_event_id61 = event_id_xy(x, y)
    end
    
    if @csca_bomb_event_id1 != 0
      get_bomb_explode_event(@csca_bomb_event_id1)
      csca_check_comment(@csca_bomb_explode_event, 5, 1)
    end
    if @csca_bomb_event_id2 != 0
      get_bomb_explode_event(@csca_bomb_event_id2)
      csca_check_comment(@csca_bomb_explode_event, 5, 2)
    end
    if @csca_bomb_event_id3 != 0
      get_bomb_explode_event(@csca_bomb_event_id3)
      csca_check_comment(@csca_bomb_explode_event, 5, 3)
    end
    if @csca_bomb_event_id4 != 0
      get_bomb_explode_event(@csca_bomb_event_id4)
      csca_check_comment(@csca_bomb_explode_event, 5, 4)
    end
    if @csca_bomb_event_id5 != 0
      get_bomb_explode_event(@csca_bomb_event_id5)
      csca_check_comment(@csca_bomb_explode_event, 5, 5)
    end
    if @csca_bomb_event_id6 != 0
      get_bomb_explode_event(@csca_bomb_event_id6)
      csca_check_comment(@csca_bomb_explode_event, 5, 6)
    end
    if @csca_bomb_event_id7 != 0
      get_bomb_explode_event(@csca_bomb_event_id7)
      csca_check_comment(@csca_bomb_explode_event, 5, 7)
    end
    if @csca_bomb_event_id8 != 0
      get_bomb_explode_event(@csca_bomb_event_id8)
      csca_check_comment(@csca_bomb_explode_event, 5, 8)
    end
    if @csca_bomb_event_id9 != 0
      get_bomb_explode_event(@csca_bomb_event_id9)
      csca_check_comment(@csca_bomb_explode_event, 5, 9)
    end
    if @csca_bomb_event_id10 != 0
      get_bomb_explode_event(@csca_bomb_event_id10)
      csca_check_comment(@csca_bomb_explode_event, 5, 10)
    end
    if @csca_bomb_event_id11 != 0
      get_bomb_explode_event(@csca_bomb_event_id11)
      csca_check_comment(@csca_bomb_explode_event, 5, 11)
    end
    if @csca_bomb_event_id12 != 0
      get_bomb_explode_event(@csca_bomb_event_id12)
      csca_check_comment(@csca_bomb_explode_event, 5, 12)
    end
    if @csca_bomb_event_id13 != 0
      get_bomb_explode_event(@csca_bomb_event_id13)
      csca_check_comment(@csca_bomb_explode_event, 5, 13)
    end
    if @csca_bomb_event_id14 != 0
      get_bomb_explode_event(@csca_bomb_event_id14)
      csca_check_comment(@csca_bomb_explode_event, 5, 14)
    end
    if @csca_bomb_event_id15 != 0
      get_bomb_explode_event(@csca_bomb_event_id15)
      csca_check_comment(@csca_bomb_explode_event, 5, 15)
    end
    if @csca_bomb_event_id16 != 0
      get_bomb_explode_event(@csca_bomb_event_id16)
      csca_check_comment(@csca_bomb_explode_event, 5, 16)
    end
    if @csca_bomb_event_id17 != 0
      get_bomb_explode_event(@csca_bomb_event_id17)
      csca_check_comment(@csca_bomb_explode_event, 5, 17)
    end
    if @csca_bomb_event_id18 != 0
      get_bomb_explode_event(@csca_bomb_event_id18)
      csca_check_comment(@csca_bomb_explode_event, 5, 18)
    end
    if @csca_bomb_event_id19 != 0
      get_bomb_explode_event(@csca_bomb_event_id19)
      csca_check_comment(@csca_bomb_explode_event, 5, 19)
    end
    if @csca_bomb_event_id20 != 0
      get_bomb_explode_event(@csca_bomb_event_id20)
      csca_check_comment(@csca_bomb_explode_event, 5, 20)
    end
    if @csca_bomb_event_id21 != 0
      get_bomb_explode_event(@csca_bomb_event_id21)
      csca_check_comment(@csca_bomb_explode_event, 5, 21)
    end
    if @csca_bomb_event_id22 != 0
      get_bomb_explode_event(@csca_bomb_event_id22)
      csca_check_comment(@csca_bomb_explode_event, 5, 22)
    end
    if @csca_bomb_event_id23 != 0
      get_bomb_explode_event(@csca_bomb_event_id23)
      csca_check_comment(@csca_bomb_explode_event, 5, 23)
    end
    if @csca_bomb_event_id24 != 0
      get_bomb_explode_event(@csca_bomb_event_id24)
      csca_check_comment(@csca_bomb_explode_event, 5, 24)
    end
    if @csca_bomb_event_id25 != 0
      get_bomb_explode_event(@csca_bomb_event_id25)
      csca_check_comment(@csca_bomb_explode_event, 5, 25)
    end
    if @csca_bomb_event_id26 != 0
      get_bomb_explode_event(@csca_bomb_event_id26)
      csca_check_comment(@csca_bomb_explode_event, 5, 26)
    end
    if @csca_bomb_event_id27 != 0
      get_bomb_explode_event(@csca_bomb_event_id27)
      csca_check_comment(@csca_bomb_explode_event, 5, 27)
    end
    if @csca_bomb_event_id28 != 0
      get_bomb_explode_event(@csca_bomb_event_id28)
      csca_check_comment(@csca_bomb_explode_event, 5, 28)
    end
    if @csca_bomb_event_id29 != 0
      get_bomb_explode_event(@csca_bomb_event_id29)
      csca_check_comment(@csca_bomb_explode_event, 5, 29)
    end
    if @csca_bomb_event_id30 != 0
      get_bomb_explode_event(@csca_bomb_event_id30)
      csca_check_comment(@csca_bomb_explode_event, 5, 30)
    end
    if @csca_bomb_event_id31 != 0
      get_bomb_explode_event(@csca_bomb_event_id31)
      csca_check_comment(@csca_bomb_explode_event, 5, 31)
    end
    if @csca_bomb_event_id32 != 0
      get_bomb_explode_event(@csca_bomb_event_id32)
      csca_check_comment(@csca_bomb_explode_event, 5, 32)
    end
    if @csca_bomb_event_id33 != 0
      get_bomb_explode_event(@csca_bomb_event_id33)
      csca_check_comment(@csca_bomb_explode_event, 5, 33)
    end
    if @csca_bomb_event_id34 != 0
      get_bomb_explode_event(@csca_bomb_event_id34)
      csca_check_comment(@csca_bomb_explode_event, 5, 34)
    end
    if @csca_bomb_event_id35 != 0
      get_bomb_explode_event(@csca_bomb_event_id35)
      csca_check_comment(@csca_bomb_explode_event, 5, 35)
    end
    if @csca_bomb_event_id36 != 0
      get_bomb_explode_event(@csca_bomb_event_id36)
      csca_check_comment(@csca_bomb_explode_event, 5, 36)
    end
    if @csca_bomb_event_id37 != 0
      get_bomb_explode_event(@csca_bomb_event_id37)
      csca_check_comment(@csca_bomb_explode_event, 5, 37)
    end
    if @csca_bomb_event_id38 != 0
      get_bomb_explode_event(@csca_bomb_event_id38)
      csca_check_comment(@csca_bomb_explode_event, 5, 38)
    end
    if @csca_bomb_event_id39 != 0
      get_bomb_explode_event(@csca_bomb_event_id39)
      csca_check_comment(@csca_bomb_explode_event, 5, 39)
    end
    if @csca_bomb_event_id40 != 0
      get_bomb_explode_event(@csca_bomb_event_id40)
      csca_check_comment(@csca_bomb_explode_event, 5, 40)
    end
    if @csca_bomb_event_id41 != 0
      get_bomb_explode_event(@csca_bomb_event_id41)
      csca_check_comment(@csca_bomb_explode_event, 5, 41)
    end
    if @csca_bomb_event_id42 != 0
      get_bomb_explode_event(@csca_bomb_event_id42)
      csca_check_comment(@csca_bomb_explode_event, 5, 42)
    end
    if @csca_bomb_event_id43 != 0
      get_bomb_explode_event(@csca_bomb_event_id43)
      csca_check_comment(@csca_bomb_explode_event, 5, 43)
    end
    if @csca_bomb_event_id44 != 0
      get_bomb_explode_event(@csca_bomb_event_id44)
      csca_check_comment(@csca_bomb_explode_event, 5, 44)
    end
    if @csca_bomb_event_id45 != 0
      get_bomb_explode_event(@csca_bomb_event_id45)
      csca_check_comment(@csca_bomb_explode_event, 5, 45)
    end
    if @csca_bomb_event_id46 != 0
      get_bomb_explode_event(@csca_bomb_event_id46)
      csca_check_comment(@csca_bomb_explode_event, 5, 46)
    end
    if @csca_bomb_event_id47 != 0
      get_bomb_explode_event(@csca_bomb_event_id47)
      csca_check_comment(@csca_bomb_explode_event, 5, 47)
    end
    if @csca_bomb_event_id48 != 0
      get_bomb_explode_event(@csca_bomb_event_id48)
      csca_check_comment(@csca_bomb_explode_event, 5, 48)
    end
    if @csca_bomb_event_id49 != 0
      get_bomb_explode_event(@csca_bomb_event_id49)
      csca_check_comment(@csca_bomb_explode_event, 5, 49)
    end
    if @csca_bomb_event_id50 != 0
      get_bomb_explode_event(@csca_bomb_event_id50)
      csca_check_comment(@csca_bomb_explode_event, 5, 50)
    end
    if @csca_bomb_event_id51 != 0
      get_bomb_explode_event(@csca_bomb_event_id51)
      csca_check_comment(@csca_bomb_explode_event, 5, 51)
    end
    if @csca_bomb_event_id52 != 0
      get_bomb_explode_event(@csca_bomb_event_id52)
      csca_check_comment(@csca_bomb_explode_event, 5, 52)
    end
    if @csca_bomb_event_id53 != 0
      get_bomb_explode_event(@csca_bomb_event_id53)
      csca_check_comment(@csca_bomb_explode_event, 5, 53)
    end
    if @csca_bomb_event_id54 != 0
      get_bomb_explode_event(@csca_bomb_event_id54)
      csca_check_comment(@csca_bomb_explode_event, 5, 54)
    end
    if @csca_bomb_event_id55 != 0
      get_bomb_explode_event(@csca_bomb_event_id55)
      csca_check_comment(@csca_bomb_explode_event, 5, 55)
    end
    if @csca_bomb_event_id56 != 0
      get_bomb_explode_event(@csca_bomb_event_id56)
      csca_check_comment(@csca_bomb_explode_event, 5, 56)
    end
    if @csca_bomb_event_id57 != 0
      get_bomb_explode_event(@csca_bomb_event_id57)
      csca_check_comment(@csca_bomb_explode_event, 5, 57)
    end
    if @csca_bomb_event_id58 != 0
      get_bomb_explode_event(@csca_bomb_event_id58)
      csca_check_comment(@csca_bomb_explode_event, 5, 58)
    end
    if @csca_bomb_event_id59 != 0
      get_bomb_explode_event(@csca_bomb_event_id59)
      csca_check_comment(@csca_bomb_explode_event, 5, 59)
    end
    if @csca_bomb_event_id60 != 0
      get_bomb_explode_event(@csca_bomb_event_id60)
      csca_check_comment(@csca_bomb_explode_event, 5, 60)
    end
    if @csca_bomb_event_id61 != 0
      get_bomb_explode_event(@csca_bomb_event_id61)
      csca_check_comment(@csca_bomb_explode_event, 5, 61)
    end
  end
  
  def csca_check_comment(event, tool, bombvar = 0)
    unless event == nil
    for i in 0...event.list.size
      case tool
      when 1
        if event.list[i].code == 108 && event.list[i].parameters == ["ARROW_ACTIVATE"]
          Audio.se_play("Audio/SE/" + ARROW_HIT_SOUND1, 80, 100) if ARROW_SOUND2
          turn_on_next_ss(@csca_event_id)
        else
          Audio.se_play("Audio/SE/" + ARROW_HIT_SOUND2, 80, 100) if ARROW_SOUND3
        end
      when 2
        if event.list[i].code == 108 && event.list[i].parameters == ["BOOMERANG_ACTIVATE"] && !pickup?
          turn_on_next_ss(@csca_event_id)
          @pickedup = true
        end
      when 3
        if event.list[i].code == 108 && event.list[i].parameters == ["HOOKSHOT_ENABLED"]
          csca_hookshot_success($game_player)
          return
        else
          hookshot_move_back(@csca_event)
        end
      when 4
        if event.list[i].code == 108 && event.list[i].parameters == ["RESET_EXEMPT"]
          return false
        else
          return true
        end
      when 5
        if event.list[i].code == 108 && event.list[i].parameters == ["BOMB_ACTIVATE"]
          turn_on_next_ss(@csca_bomb_event_id1) if bombvar == 1
          turn_on_next_ss(@csca_bomb_event_id2) if bombvar == 2
          turn_on_next_ss(@csca_bomb_event_id3) if bombvar == 3
          turn_on_next_ss(@csca_bomb_event_id4) if bombvar == 4
          turn_on_next_ss(@csca_bomb_event_id5) if bombvar == 5
          turn_on_next_ss(@csca_bomb_event_id6) if bombvar == 6
          turn_on_next_ss(@csca_bomb_event_id7) if bombvar == 7
          turn_on_next_ss(@csca_bomb_event_id8) if bombvar == 8
          turn_on_next_ss(@csca_bomb_event_id9) if bombvar == 9
          turn_on_next_ss(@csca_bomb_event_id10) if bombvar == 10
          turn_on_next_ss(@csca_bomb_event_id11) if bombvar == 11
          turn_on_next_ss(@csca_bomb_event_id12) if bombvar == 12
          turn_on_next_ss(@csca_bomb_event_id13) if bombvar == 13
          turn_on_next_ss(@csca_bomb_event_id14) if bombvar == 14
          turn_on_next_ss(@csca_bomb_event_id15) if bombvar == 15
          turn_on_next_ss(@csca_bomb_event_id16) if bombvar == 16
          turn_on_next_ss(@csca_bomb_event_id17) if bombvar == 17
          turn_on_next_ss(@csca_bomb_event_id18) if bombvar == 18
          turn_on_next_ss(@csca_bomb_event_id19) if bombvar == 19
          turn_on_next_ss(@csca_bomb_event_id20) if bombvar == 20
          turn_on_next_ss(@csca_bomb_event_id21) if bombvar == 21
          turn_on_next_ss(@csca_bomb_event_id22) if bombvar == 22
          turn_on_next_ss(@csca_bomb_event_id23) if bombvar == 23
          turn_on_next_ss(@csca_bomb_event_id24) if bombvar == 24
          turn_on_next_ss(@csca_bomb_event_id25) if bombvar == 25
          turn_on_next_ss(@csca_bomb_event_id26) if bombvar == 26
          turn_on_next_ss(@csca_bomb_event_id27) if bombvar == 27
          turn_on_next_ss(@csca_bomb_event_id28) if bombvar == 28
          turn_on_next_ss(@csca_bomb_event_id29) if bombvar == 29
          turn_on_next_ss(@csca_bomb_event_id30) if bombvar == 30
          turn_on_next_ss(@csca_bomb_event_id31) if bombvar == 31
          turn_on_next_ss(@csca_bomb_event_id32) if bombvar == 32
          turn_on_next_ss(@csca_bomb_event_id33) if bombvar == 33
          turn_on_next_ss(@csca_bomb_event_id34) if bombvar == 34
          turn_on_next_ss(@csca_bomb_event_id35) if bombvar == 35
          turn_on_next_ss(@csca_bomb_event_id36) if bombvar == 36
          turn_on_next_ss(@csca_bomb_event_id37) if bombvar == 37
          turn_on_next_ss(@csca_bomb_event_id38) if bombvar == 38
          turn_on_next_ss(@csca_bomb_event_id39) if bombvar == 39
          turn_on_next_ss(@csca_bomb_event_id40) if bombvar == 40
          turn_on_next_ss(@csca_bomb_event_id41) if bombvar == 41
          turn_on_next_ss(@csca_bomb_event_id42) if bombvar == 42
          turn_on_next_ss(@csca_bomb_event_id43) if bombvar == 43
          turn_on_next_ss(@csca_bomb_event_id44) if bombvar == 44
          turn_on_next_ss(@csca_bomb_event_id45) if bombvar == 45
          turn_on_next_ss(@csca_bomb_event_id46) if bombvar == 46
          turn_on_next_ss(@csca_bomb_event_id47) if bombvar == 47
          turn_on_next_ss(@csca_bomb_event_id48) if bombvar == 48
          turn_on_next_ss(@csca_bomb_event_id49) if bombvar == 49
          turn_on_next_ss(@csca_bomb_event_id50) if bombvar == 50
          turn_on_next_ss(@csca_bomb_event_id51) if bombvar == 51
          turn_on_next_ss(@csca_bomb_event_id52) if bombvar == 52
          turn_on_next_ss(@csca_bomb_event_id53) if bombvar == 53
          turn_on_next_ss(@csca_bomb_event_id54) if bombvar == 54
          turn_on_next_ss(@csca_bomb_event_id55) if bombvar == 55
          turn_on_next_ss(@csca_bomb_event_id56) if bombvar == 56
          turn_on_next_ss(@csca_bomb_event_id57) if bombvar == 57
          turn_on_next_ss(@csca_bomb_event_id58) if bombvar == 58
          turn_on_next_ss(@csca_bomb_event_id59) if bombvar == 59
          turn_on_next_ss(@csca_bomb_event_id60) if bombvar == 60
          turn_on_next_ss(@csca_bomb_event_id61) if bombvar == 61
        end
      end
    end
    end # unless event == nil
  end
  
end