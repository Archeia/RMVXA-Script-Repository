=begin
CSCA Skill Shop
version: 1.0 (Released: May 24, 2012)
Created by: Casper Gaming (http://www.caspergaming.com/)

Compatibility:
Made for RPGVXAce
IMPORTANT: ALL CSCA Scripts should be compatible with each other unless
otherwise noted.

UPDATES:
Version 1.0
-Original Script

FFEATURES:
This script allows you to easily create shops which sell skills to actors.

SETUP
This script is Plug n Play. Please read instructions below.

CREDIT:
Free to use in noncommercial games if credit is given to:
Casper Gaming (http://www.caspergaming.com/)

To use in a commercial game, please purchase a license here:
http://www.caspergaming.com/licenses.html

TERMS:
http://www.caspergaming.com/terms_of_use.html
================================INSTRUCTIONS===================================

INITIATING A SKILL SHOP FROM AN EVENT:
To create a skill shop, you'll need to make a few script calls.
Step 1. Under the event commands, choose tab 3, then under advanced choose Script.
Step 2. In the script window, you'll need to enter 3 lines:

goods = [1,2,3,4]
SceneManager.call(CSCA_Scene_Skill_Shop)
SceneManager.scene.prepare(goods)

The first line you can change the numbers. The numbers correspond to skill ID's.
In this example, skills #1, #2, #3, and #4 will be sold.
The last 2 lines will always be the same.



HOW TO SET SKILL PRICES
The skill's price is set through notetags. In the skill notetag box, enter this
notetag:

<cscaprice: x>

Where x will be the price of the skill. For example,
<cscaprice: 100>
will make the skill cost 100 gold. Do not put commas in this number.



HOW TO SET WHICH SKILLS AN ACTOR CAN LEARN
By default, actors cannot learn any skills through the shop. This needs to be
set through notetags in the actor's notebox. To do this, enter a notetag like
this:

<csca_ss_skills: x>

Where x will be the skill ID the actor can learn. You can enter many skill ID's
by separating them with commas such as

<csca_ss_skills: x,y,z>

Where x will be a skill ID, y will be another skill ID, z will be another skill
ID and so on. For example,
<csca_ss_skills: 1,2,3>
will allow the actor to learn skills #1, #2, and #3.

Actors will never be able to learn skills which they already know.

============================= END INSTRUCTIONS=================================
=end

$imported = {} if $imported.nil?
$imported["CSCA-SkillShop"] = true
class CSCA_Scene_Skill_Shop < Scene_MenuBase

  def prepare(goods)
    @goods = goods
  end

  def start
    super
    create_help_window
    create_gold_window
    create_command_window
    create_dummy_window
    create_status_window
    create_buy_window
  end

  def create_gold_window
    @gold_window = Window_Gold.new
    @gold_window.viewport = @viewport
    @gold_window.x = Graphics.width - @gold_window.width
    @gold_window.y = @help_window.height
  end

  def create_command_window
    @command_window = CSCA_Window_SkillShopCommand.new(@gold_window.x)
    @command_window.viewport = @viewport
    @command_window.y = @help_window.height
    @command_window.set_handler(:buy,    method(:command_buy))
    @command_window.set_handler(:cancel, method(:return_scene))
  end

  def create_dummy_window
    wy = @command_window.y + @command_window.height
    wh = Graphics.height - wy
    @dummy_window = Window_Base.new(0, wy, Graphics.width, wh)
    @dummy_window.viewport = @viewport
  end

  def create_buy_window
    wy = @dummy_window.y
    wh = @dummy_window.height
    @buy_window = CSCA_Window_SkillShopBuy.new(0, wy, wh, @goods)
    @buy_window.viewport = @viewport
    @buy_window.help_window = @help_window
    @buy_window.status_window = @status_window
    @buy_window.hide
    @buy_window.set_handler(:ok,     method(:on_buy_ok))
    @buy_window.set_handler(:cancel, method(:on_buy_cancel))
  end
  
  def create_status_window
    wx = 304
    wy = @dummy_window.y
    ww = Graphics.width - wx
    wh = @dummy_window.height
    @status_window = CSCA_Window_SkillShopStatus.new(wx, wy, ww, wh)
    @status_window.viewport = @viewport
    @status_window.hide
    @status_window.set_handler(:ok,     method(:on_number_ok))
    @status_window.set_handler(:cancel, method(:on_number_cancel))
  end

  def activate_buy_window
    @buy_window.money = money
    @buy_window.show.activate
    @status_window.show.unselect
  end

  def command_buy
    @dummy_window.hide
    activate_buy_window
  end

  def on_buy_ok
    @item = @buy_window.item
    @buy_window.deactivate
    @status_window.set(@item, buying_price)
    @status_window.show.activate.select(0)
  end

  def on_buy_cancel
    @command_window.activate
    @dummy_window.show
    @buy_window.hide
    @status_window.hide
    @help_window.clear
  end

  def on_number_ok
    Sound.play_shop
    do_buy(@status_window.item,@buy_window.item)
    end_input
    @gold_window.refresh
    @status_window.refresh
  end

  def on_number_cancel
    Sound.play_cancel
    end_input
  end

  def do_buy(actor, skill)
    $game_party.lose_gold(buying_price)
    $game_actors[actor.id].learn_skill(skill.id)
  end

  def end_input
    @status_window.unselect
    activate_buy_window
  end

  def money
    @gold_window.value
  end

  def currency_unit
    @gold_window.currency_unit
  end

  def buying_price
    @buy_window.price(@item)
  end
end
class CSCA_Window_SkillShopCommand < Window_HorzCommand

  def initialize(window_width)
    @window_width = window_width
    super(0, 0)
  end

  def window_width
    @window_width
  end

  def col_max
    return 2
  end

  def make_command_list
    add_command(Vocab::ShopBuy,    :buy)
    add_command(Vocab::ShopCancel, :cancel)
  end
end
class CSCA_Window_SkillShopBuy < Window_Selectable

  attr_reader   :status_window

  def initialize(x, y, height, shop_goods)
    super(x, y, window_width, height)
    @shop_goods = shop_goods
    @money = 0
    refresh
    select(0)
  end

  def window_width
    return 304
  end

  def item_max
    @data ? @data.size : 1
  end

  def item
    @data[index]
  end

  def money=(money)
    @money = money
    refresh
  end

  def current_item_enabled?
    enable?(@data[index])
  end

  def price(item)
    @price[item]
  end

  def enable?(item)
    item && item.skill_price <= @money
  end

  def refresh
    make_item_list
    create_contents
    draw_all_items
  end

  def make_item_list
    @data = []
    @price = {}
    for i in 0...@shop_goods.size
      item = $data_skills[@shop_goods[i]]
      if item
        @data.push(item)
        @price[item] = item.skill_price
      end
    end
  end

  def draw_item(index)
    item = @data[index]
    rect = item_rect(index)
    draw_item_name(item, rect.x, rect.y, enable?(item))
    rect.width -= 4
    draw_text(rect, price(item), 2)
  end

  def status_window=(status_window)
    @status_window = status_window
    call_update_help
  end

  def update_help
    @help_window.set_item(item) if @help_window
    @status_window.item = item if @status_window
  end
end
class CSCA_Window_SkillShopStatus < Window_Selectable
  
  def set(skill, price)
    @skill = skill
    @price = price
    refresh
  end

  def initialize(x, y, width, height)
    super(x, y, width, height)
    @skill = nil
    @page_index = 0
    refresh
    select(0)
  end
  
  def item_max
    @data ? @data.size : 1
  end
  
  def item
    @data[index]
  end
  
  def item=(item)
    @skill = item
    refresh
  end

  def current_item_enabled?
    enable?(@data[index])
  end

  def enable?(actor)
    for i in 0...actor.skills.size
      if actor.skills[i] == @skill
        return false
      end
    end
    for i in 0...actor.csca_learnable_skills.size
      unless @skill.nil?
        if actor.csca_learnable_skills[i] == @skill.id
          return true
        end
      end
    end
    return false
  end

  def refresh
    make_item_list
    create_contents
    draw_all_items
  end

  def make_item_list
    @data = []
    $game_party.members.each do |actor|
      item = actor
      if !item.nil?
        @data.push(item)
      end
    end
  end

  def draw_item(index)
    item = @data[index]
    rect = item_rect(index)
    change_color(normal_color, enable?(item))
    draw_text(rect.x, rect.y, contents.width, line_height, item.name)
    change_color(normal_color)
  end
end
class RPG::Skill < RPG::UsableItem
  def skill_price
    if @note =~ /<cscaprice: (.*)>/i
      return $1.to_i
    else
      return 0
    end
  end
end
class RPG::Actor < RPG::BaseItem
  def learnable_skills
    if @note =~ /<csca_ss_skills: (.*)>/i
      ints = []
      for x in $1.split(",")
        ints.push(x.to_i)
      end
      return ints
    else
      return []
    end
  end
end
class Game_Actor < Game_Battler
  def csca_learnable_skills
    actor.learnable_skills
  end
end