=begin
CSCA Title System
version: 1.0.0 (Released: January 11, 2013)
Created by: Casper Gaming (http://www.caspergaming.com/)

Compatibility:
Made for RPGVXAce
IMPORTANT: ALL CSCA Scripts should be compatible with each other unless
otherwise noted.

WHAT IT DOES:
Modifies the title screen to cycle through maps as well as the title image. The
maps are actual map files and can use events to tint screen and show weatehr
effects/aniamtions. You can also use CSCA Light Effects in the title maps (other
light effect scripts may work, but are not tested).

SETUP
Set up required. Instructions below.

CREDIT:
Free to use in noncommercial games if credit is given to:
Casper Gaming (http://www.caspergaming.com/)

To use in a commercial game, please purchase a license here:
http://www.caspergaming.com/licenses.html

TERMS:
http://www.caspergaming.com/terms_of_use.html
=end
module CSCA
  module TS
    MAPS = [2,3,4,5,6] # Array of map ID's to cycle through.
    
    CONTINUOUS = false # Skip title image showing after complete map cycle?
    IDLE_TIME = 600 # Time in frames to wait before fading to maps from title image.
    MAP_TIME = 600 # Time in frames to wait before cycling to next map.
    
    TRANSITION_SPEED = 5 # Speed of the title image fade in/out
    FADE_SPEED = 20 # Speed of the map fade in/out
  end
end
$imported = {} if $imported.nil?
$imported["CSCA-TitleSystem"] = true
#==============================================================================
# ** Scene_Title
#------------------------------------------------------------------------------
# This class performs the title screen processing.
#Aliases: start, terminate, command_new_game
#==============================================================================
class Scene_Title < Scene_Base
  #--------------------------------------------------------------------------
  # Alias Method; start
  #--------------------------------------------------------------------------
  alias :csca_ts_start :start
  def start
    csca_ts_start
    @map_number.nil? ? @map_number = 0 : hide_image
    @image_timer = 0 if @image_timer.nil?
    @map_timer = 0 if @map_timer.nil?
    csca_create_map(CSCA::TS::MAPS[@map_number]) if @map_timer == 0
    create_spriteset
    set_z_values
  end
  #--------------------------------------------------------------------------
  # Alias Method; terminate
  #--------------------------------------------------------------------------
  alias :csca_ts_terminate :terminate
  def terminate
    csca_ts_terminate
    dispose_spriteset
  end
  #--------------------------------------------------------------------------
  # Alias Method; command_new_game
  #--------------------------------------------------------------------------
  alias :csca_ts_new_game :command_new_game
  def command_new_game
    close_command_window
    fadeout_all
    csca_ts_new_game
  end
  #--------------------------------------------------------------------------
  # Update
  #--------------------------------------------------------------------------
  def update
    super
    update_timers
    update_image
    update_map_cycle
    $game_map.update(true)
    @spriteset.update
  end
  #--------------------------------------------------------------------------
  # Update timers
  #--------------------------------------------------------------------------
  def update_timers
    @image_timer += 1
    @map_timer += 1 if @image_timer > CSCA::TS::IDLE_TIME
  end
  #--------------------------------------------------------------------------
  # Update image opacity
  #--------------------------------------------------------------------------
  def update_image
    if @image_timer >= CSCA::TS::IDLE_TIME && !image_opacity(0)
      update_hide_image
    elsif @image_timer <= CSCA::TS::IDLE_TIME && !image_opacity(255)
      update_show_image
    end
  end
  #--------------------------------------------------------------------------
  # Update map cycle
  #--------------------------------------------------------------------------
  def update_map_cycle
    do_fade
    if @map_timer == CSCA::TS::MAP_TIME
      @map_timer = 0
      if @map_number == CSCA::TS::MAPS.size - 1
        @image_timer = 0 unless CSCA::TS::CONTINUOUS
        @map_number = 0
        @map_made = false
        @cycle_done = true if CSCA::TS::CONTINUOUS
      else
        @map_number += 1
      end
      csca_create_map(CSCA::TS::MAPS[@map_number]) unless @image_timer == 0
    end
    if image_opacity(255) && @map_number == 0 && @map_made == false
      csca_create_map(CSCA::TS::MAPS[@map_number])
    end
  end
  #--------------------------------------------------------------------------
  # Hide title image
  #--------------------------------------------------------------------------
  def update_hide_image
    @sprite1.opacity -= CSCA::TS::TRANSITION_SPEED
    @sprite2.opacity -= CSCA::TS::TRANSITION_SPEED
    @foreground_sprite.opacity -= CSCA::TS::TRANSITION_SPEED
  end
  #--------------------------------------------------------------------------
  # Hide title image
  #--------------------------------------------------------------------------
  def update_show_image
    @sprite1.opacity += CSCA::TS::TRANSITION_SPEED
    @sprite2.opacity += CSCA::TS::TRANSITION_SPEED
    @foreground_sprite.opacity += CSCA::TS::TRANSITION_SPEED
  end
  #--------------------------------------------------------------------------
  # Compare image opacity
  #--------------------------------------------------------------------------
  def image_opacity(opacity)
    @sprite1.opacity == opacity && @sprite2.opacity == opacity && @foreground_sprite.opacity == opacity
  end
  #--------------------------------------------------------------------------
  # Load map
  #--------------------------------------------------------------------------
  def csca_create_map(map)
    $game_map.setup(map)
    @map_made = true
  end
  #--------------------------------------------------------------------------
  # Create Sprite Set
  #--------------------------------------------------------------------------
  def create_spriteset
    @spriteset = Spriteset_Map.new
  end
  #--------------------------------------------------------------------------
  # Free Sprite Set
  #--------------------------------------------------------------------------
  def dispose_spriteset
    @spriteset.dispose
  end
  #--------------------------------------------------------------------------
  # Set sprite z values
  #--------------------------------------------------------------------------
  def set_z_values
    @sprite1.z = 6
    @sprite2.z = 6
    @foreground_sprite.z = 7
  end
  #--------------------------------------------------------------------------
  # Immediately hide image
  #--------------------------------------------------------------------------
  def hide_image
    return if @image_timer < CSCA::TS::IDLE_TIME
    @sprite1.opacity = 0
    @sprite2.opacity = 0
    @foreground_sprite.opacity = 0
  end
  #--------------------------------------------------------------------------
  # Handle when to fade in/out
  #--------------------------------------------------------------------------
  def do_fade
    return if CSCA::TS::MAPS.size == 1
    if @map_timer == 1 && @map_number > 0 || @cycle_done
      Graphics.wait(CSCA::TS::FADE_SPEED / 2)
      fadein(CSCA::TS::FADE_SPEED)
      @cycle_done = false
    elsif @map_timer == CSCA::TS::MAP_TIME - CSCA::TS::FADE_SPEED && (@map_number != CSCA::TS::MAPS.size - 1 || CSCA::TS::CONTINUOUS)
      fadeout(CSCA::TS::FADE_SPEED)
    end
  end
  #--------------------------------------------------------------------------
  # General-Purpose Fade Processing
  #--------------------------------------------------------------------------
  def fade_loop(duration)
    duration.times do |i|
      yield 255 * (i + 1) / duration
      update_for_fade
    end
  end
  #--------------------------------------------------------------------------
  # Fadein Screen
  #--------------------------------------------------------------------------
  def fadein(duration)
    fade_loop(duration) {|v| Graphics.brightness = v }
  end
  #--------------------------------------------------------------------------
  # Fadeout Screen
  #--------------------------------------------------------------------------
  def fadeout(duration)
    fade_loop(duration) {|v| Graphics.brightness = 255 - v }
  end
  #--------------------------------------------------------------------------
  # Update Frame (for Fade In)
  #--------------------------------------------------------------------------
  def update_for_fade
    update_basic
    $game_map.update(false)
    @spriteset.update
  end
end