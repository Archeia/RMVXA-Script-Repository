=begin
CSCA AutoSave Plus
version: 1.1 (Released: August 20th, 2012)
Created by: Casper Gaming (http://www.caspergaming.com/)
------------------------------------------------
Compatibility:
Made for RPGVXAce
IMPORTANT: ALL CSCA Scripts should be compatible with each other unless
otherwise noted.

NOT COMPATIBLE WITH: CSCA Game Over Options
(This script retains all functionality of that script though).
------------------------------------------------
UPDATE HISTORY:
version 1.0
-original script

version 1.1
-Autosaving text popup on map after autosave.
-Autosave after certain amount of steps
------------------------------------------------
INTRODUCTION:
This script introduces an autosave feature, where the game will automatically
save if the player: transfers map, finishes a battle, gains
gold/armor/item/weapons(event command only), all options are toggleable.
Does not overwrite standard save files.
------------------------------------------------
FEATURES:
-Saves the game automatically under a few conditions set by you
-Can load autosave file from title, scene end, or gameover
-Can change gameover music/image ingame with a variable
------------------------------------------------
SETUP
Script requires setup below.

Script calls:
================================================================================
To make an autosave, use this script call:
DataManager.csca_autosave(:save)

To load an autosave, use this script call:
DataManager.csca_autosave(:load)
Note: Use with caution, will error if no autosave exists!
================================================================================

CREDIT:
Free to use in noncommercial games if credit is given to:
Casper Gaming (http://www.caspergaming.com/)

To use in a commercial game, please purchase a license here:
http://www.caspergaming.com/licenses.html

TERMS:
http://www.caspergaming.com/terms_of_use.html
=end
module CSCA # Don't Touch
  module AUTOSAVE # Don't Touch
    #============================ Autosave Options ============================#
    TRANSFER = true # Autosave every transfer?
    BATTLE = true   # Autosave after every battle?
    GOLD = true     # Autosave on gold change?(event command only)
    ITEM = true     # Autosave on item change?(event command only)
    WEAPON = true   # Autosave on weapon change?(event command only)
    ARMOR = true    # Autosave on armor change?(event command only)
    STEPS = false   # Autosave after a certain amount of steps?
    
    DISABLE_SWITCH = 1 # Switch ID. When this switch is ON, autosave will not
                       # save unless the script call is made. Use this to temp.
                       # disable automatic autosaves, such as on transfer.
    
    STEP_COUNT = 50 # Amount of steps to autosave after
    #======================== Game Over Scene Options =========================#
    # Variable Setup
    IMAGEVAR = 1 # Variable ID that chooses which gameover image to use. Ex: If
                 # the variable is set to 1, the gameover graphic displayed will
                 # be Graphics/System/GameOver1
    MUSICVAR = 2 # Variable ID that chooses which gameover ME to use. Ex: If the
                 # variable is set to 1, the gameover ME played will be
                 # Audio/ME/GameOver1
    
    # Text Setup
    CONTINUE = "Load Autosave" # Text for the load autosave option.
    LOAD = "Load Saved Game" # Text for the load savefile option.
    TITLE = "Title" # Text for the Title option.
    SHUTDOWN = "Shutdown" # Text for the Shutdown option.
    AUTOSAVING = "Autosaving..." # Text shown on map when autosave takes place.
  end # AUTOSAVE
end # CSCA
#############
# END SETUP #
#############
$imported = {} if $imported.nil?
$imported["CSCA-Autosave"] = true
#==============================================================================
# ** DataManager
#------------------------------------------------------------------------------
#  Used to create and delete autosaves.
# Aliases: setup_new_game
#==============================================================================
module DataManager
  #--------------------------------------------------------------------------
  # * Load or Save?
  #--------------------------------------------------------------------------
  def self.csca_autosave(symbol)
    case symbol
    when :save; make_autosave
    when :load; load_autosave
    end
  end
  #--------------------------------------------------------------------------
  # * Autosave Exists?
  #--------------------------------------------------------------------------
  def self.autosave_exists?
    !Dir.glob('Autosave.rvdata2').empty?
  end
  #--------------------------------------------------------------------------
  # * Delete Autosave
  #--------------------------------------------------------------------------
  def self.delete_autosave
    File.delete('Autosave.rvdata2') rescue nil
  end
  #--------------------------------------------------------------------------
  # * Execute Autosave
  #--------------------------------------------------------------------------
  def self.make_autosave
    begin
      autosave_without_rescue
    rescue
      delete_autosave
      false
    end
    $game_map.autosaving = true
  end
  #--------------------------------------------------------------------------
  # * Execute Load of Autosave File
  #--------------------------------------------------------------------------
  def self.load_autosave
    load_autosave_without_rescue rescue false
  end
  #--------------------------------------------------------------------------
  # * Execute Save (No Exception Processing)
  #--------------------------------------------------------------------------
  def self.autosave_without_rescue
    File.open('Autosave.rvdata2', "wb") do |file|
      $game_system.on_before_autosave
      Marshal.dump(make_save_header, file)
      Marshal.dump(make_save_contents, file)
    end
    return true
  end
  #--------------------------------------------------------------------------
  # * Execute Load (No Exception Processing)
  #--------------------------------------------------------------------------
  def self.load_autosave_without_rescue
    File.open('Autosave.rvdata2', "rb") do |file|
      Marshal.load(file)
      extract_save_contents(Marshal.load(file))
      reload_map_if_updated
    end
    return true
  end
  #--------------------------------------------------------------------------
  # * Alias Method
  #--------------------------------------------------------------------------
  class << self; alias csca_autosave_new_game setup_new_game; end
  def self.setup_new_game
    csca_autosave_new_game
    delete_autosave if autosave_exists?
  end
end # DataManager
#==============================================================================
# ** Game_System
#------------------------------------------------------------------------------
#  Preforms processing before autosave and after autosave load.
#==============================================================================
class Game_System
  #--------------------------------------------------------------------------
  # * Pre-Autosave Processing
  #--------------------------------------------------------------------------
  def on_before_autosave
    @version_id = $data_system.version_id
    @frames_on_autosave = Graphics.frame_count
    @bgm_on_autosave = RPG::BGM.last
    @bgs_on_autosave = RPG::BGS.last
  end
  #--------------------------------------------------------------------------
  # * Post-Autosave Load Processing
  #--------------------------------------------------------------------------
  def on_after_autosave_load
    Graphics.frame_count = @frames_on_autosave
    @bgm_on_autosave.play
    @bgs_on_autosave.play
  end
  #--------------------------------------------------------------------------
  # * Autosave forbidden?
  #--------------------------------------------------------------------------
  def csca_autosave_allowed?(situation)
    return false if $game_switches[CSCA::AUTOSAVE::DISABLE_SWITCH] || $BTEST ||
      $game_party.in_battle
    case situation
    when :transfer; CSCA::AUTOSAVE::TRANSFER
    when :battle; CSCA::AUTOSAVE::BATTLE
    when :gold; CSCA::AUTOSAVE::GOLD
    when :item; CSCA::AUTOSAVE::ITEM
    when :weapon; CSCA::AUTOSAVE::WEAPON
    when :armor; CSCA::AUTOSAVE::ARMOR
    when :steps; CSCA::AUTOSAVE::STEPS
    end
  end
end # Game_System
#==============================================================================
# ** Scene_Load
#------------------------------------------------------------------------------
#  Deletes old autosave data when new file is loaded.
# Aliases: on_load_success
#==============================================================================
class Scene_Load < Scene_File
  #--------------------------------------------------------------------------
  # * Alias Method
  #--------------------------------------------------------------------------
  alias csca_delete_autosave on_load_success
  def on_load_success
    csca_delete_autosave
    DataManager.delete_autosave if DataManager.autosave_exists?
  end
end # Scene_Load
#==============================================================================
# ** Scene_Gameover
#------------------------------------------------------------------------------
#  Adds command window and custom graphics/music to gameover scene.
# Aliases: start, play_gameover_music, create_background
# Overwrites: update
#==============================================================================
class Scene_Gameover < Scene_Base
  #--------------------------------------------------------------------------
  # * Alias Method
  #--------------------------------------------------------------------------
  alias csca_gameover_start start
  def start
    csca_gameover_start
    create_command_window
  end
  #--------------------------------------------------------------------------
  # * Overwrite Method
  #--------------------------------------------------------------------------
  def update
    super
  end
  #--------------------------------------------------------------------------
  # * Alias Method
  #--------------------------------------------------------------------------
  alias csca_gameover_music play_gameover_music
  def play_gameover_music
    RPG::BGM.stop
    RPG::BGS.stop
    $game_variables[CSCA::AUTOSAVE::MUSICVAR] == 0 ? csca_gameover_music :
      Audio.me_play("Audio/ME/Gameover"+$game_variables[CSCA::AUTOSAVE::MUSICVAR].to_s,100,100)
  end
  #--------------------------------------------------------------------------
  # * Alias Method
  #--------------------------------------------------------------------------
  alias csca_gameover_background create_background
  def create_background
    @sprite = Sprite.new
    $game_variables[CSCA::AUTOSAVE::IMAGEVAR] == 0 ? csca_gameover_background :
      @sprite.bitmap = Cache.system("GameOver" + $game_variables[CSCA::AUTOSAVE::IMAGEVAR].to_s)
  end
  #--------------------------------------------------------------------------
  # * Command handlers
  #--------------------------------------------------------------------------
  def create_command_window
    @command_window = CSCA_Window_GameoverCommand.new
    @command_window.set_handler(:continue, method(:load_autosave))
    @command_window.set_handler(:load, method(:goto_file_selection))
    @command_window.set_handler(:title, method(:goto_title))
    @command_window.set_handler(:shutdown, method(:goto_shutdown))
  end
  #--------------------------------------------------------------------------
  # * Shutdown Game
  #--------------------------------------------------------------------------
  def goto_shutdown
    close_command_window
    fadeout_all
    SceneManager.exit
  end
  #--------------------------------------------------------------------------
  # * Load Saved Game
  #--------------------------------------------------------------------------
  def goto_file_selection
    close_command_window
    SceneManager.call(Scene_Load)
  end
  #--------------------------------------------------------------------------
  # * Continue
  #--------------------------------------------------------------------------
  def load_autosave
    DataManager.csca_autosave(:load)
    fadeout_all
    $game_system.on_after_autosave_load
    SceneManager.goto(Scene_Map)
  end
  #--------------------------------------------------------------------------
  # * Closes Command Window
  #--------------------------------------------------------------------------
  def close_command_window
    @command_window.close
    update until @command_window.close?
  end
end # Scene_Gameover
#==============================================================================
# ** CSCA_Window_GameoverCommand
#------------------------------------------------------------------------------
#  This window is for selecting commands on the gameover screen.
#==============================================================================
class CSCA_Window_GameoverCommand < Window_Command
  #--------------------------------------------------------------------------
  # * Initialization
  #--------------------------------------------------------------------------
  def initialize
    super(0,0)
    self.x = (Graphics.width - width) / 2
    self.y = (Graphics.height * 1.6 - height) / 2
    self.openness = 0
    open
  end
  #--------------------------------------------------------------------------
  # * Make Commands
  #--------------------------------------------------------------------------
  def make_command_list
    add_command(CSCA::AUTOSAVE::CONTINUE, :continue, continue_enabled)
    add_command(CSCA::AUTOSAVE::LOAD, :load, load_enabled)
    add_command(CSCA::AUTOSAVE::TITLE, :title)
    add_command(CSCA::AUTOSAVE::SHUTDOWN, :shutdown)
  end
  #--------------------------------------------------------------------------
  # * Autosave Exists?
  #--------------------------------------------------------------------------
  def continue_enabled
    DataManager.autosave_exists?
  end
  #--------------------------------------------------------------------------
  # * Save File Exists?
  #--------------------------------------------------------------------------
  def load_enabled
    DataManager.save_file_exists?
  end
end # CSCA_Window_GameoverCommand
#==============================================================================
# ** Window_GameEnd
#------------------------------------------------------------------------------
#  Adds ability to load autosave.
# Aliases: make_command_list
#==============================================================================
class Window_GameEnd < Window_Command
  #--------------------------------------------------------------------------
  # * Alias Method
  #--------------------------------------------------------------------------
  alias csca_autosave make_command_list
  def make_command_list
    add_command(CSCA::AUTOSAVE::CONTINUE, :autosave, autosave_enabled)
    csca_autosave
  end
  #--------------------------------------------------------------------------
  # * Autosave Exists?
  #--------------------------------------------------------------------------
  def autosave_enabled
    DataManager.autosave_exists?
  end
end # Window_GameEnd
#==============================================================================
# ** Scene_End
#------------------------------------------------------------------------------
#  Adds ability to load last checkpoint from Scene_End
# Aliases: create_command_window
#==============================================================================
class Scene_End < Scene_MenuBase
  #--------------------------------------------------------------------------
  # * Alias Method
  #--------------------------------------------------------------------------
  alias csca_autosave_option create_command_window
  def create_command_window
    csca_autosave_option
    @command_window.set_handler(:autosave, method(:load_autosave))
  end
  #--------------------------------------------------------------------------
  # * Load Autosave
  #--------------------------------------------------------------------------
  def load_autosave
    DataManager.csca_autosave(:load)
    fadeout_all
    $game_system.on_after_autosave_load
    SceneManager.goto(Scene_Map)
  end
end # Scene_End
#==============================================================================
# ** Window_TitleCommand
#------------------------------------------------------------------------------
#  Adds ability to load autosave from title.
# Overwrites: make_command_list
#==============================================================================
class Window_TitleCommand < Window_Command
  #--------------------------------------------------------------------------
  # * Overwrite Method
  #--------------------------------------------------------------------------
  def make_command_list
    add_command(Vocab::new_game, :new_game)
    add_command(Vocab::continue, :continue, continue_enabled)
    add_command(CSCA::AUTOSAVE::CONTINUE, :autosave, autosave_enabled)
    add_command(Vocab::shutdown, :shutdown)
  end
  #--------------------------------------------------------------------------
  # * Autosave Exists?
  #--------------------------------------------------------------------------
  def autosave_enabled
    DataManager.autosave_exists?
  end
end # Window_TitleCommand
#==============================================================================
# ** Scene_Title
#------------------------------------------------------------------------------
#  Adds ability to load autosave from title.
# Aliases: create_command_window
#==============================================================================
class Scene_Title < Scene_Base
  #--------------------------------------------------------------------------
  # * Alias Method
  #--------------------------------------------------------------------------
  alias csca_autosave_add create_command_window
  def create_command_window
    csca_autosave_add
    @command_window.set_handler(:autosave, method(:command_autosave))
  end
  #--------------------------------------------------------------------------
  # * Load Autosave
  #--------------------------------------------------------------------------
  def command_autosave
    DataManager.csca_autosave(:load)
    close_command_window
    fadeout_all
    $game_system.on_after_autosave_load
    SceneManager.goto(Scene_Map)
  end
end # Scene_Title
#==============================================================================
# ** Scene_Map
#------------------------------------------------------------------------------
#  Autosaves on: transfer (optional). Also creates Autosaving window.
# Aliases: post_transfer, create_all_windows, pre_transfer, update
#==============================================================================
class Scene_Map < Scene_Base
  #--------------------------------------------------------------------------
  # * Alias Method
  #--------------------------------------------------------------------------
  alias csca_autosave_transfer post_transfer
  def post_transfer
    csca_autosave_transfer
    DataManager.csca_autosave(:save) if $game_system.csca_autosave_allowed?(:transfer)
  end
  #--------------------------------------------------------------------------
  # * Alias Method
  #--------------------------------------------------------------------------
  alias csca_autosave_create_windows create_all_windows
  def create_all_windows
    csca_autosave_create_windows
    csca_create_autosave_window
  end
  #--------------------------------------------------------------------------
  # * Create Autosave Window
  #--------------------------------------------------------------------------
  def csca_create_autosave_window
    @autosave_window = CSCA_Window_Autosaving.new
  end
  #--------------------------------------------------------------------------
  # * Alias Method
  #--------------------------------------------------------------------------
  alias csca_autosave_pre_transfer pre_transfer
  def pre_transfer
    @autosave_window.close
    csca_autosave_pre_transfer
  end
  #--------------------------------------------------------------------------
  # * Alias Method
  #--------------------------------------------------------------------------
  alias csca_autosave_update update
  def update
    csca_autosave_update
    @autosave_window.open if $game_map.autosaving
  end
end # Game_Map
#==============================================================================
# ** Battle Manager
#------------------------------------------------------------------------------
#  Autosaves on: battle end (optional)
# Aliases: battle_end
#==============================================================================
module BattleManager
  class <<self; alias csca_autosave_battle battle_end; end
  def self.battle_end(result)
    csca_autosave_battle(result)
    DataManager.csca_autosave(:save) if $game_system.csca_autosave_allowed?(:battle)
  end
end # BattleManager
#==============================================================================
# ** Game_Interpreter
#------------------------------------------------------------------------------
#  Autosaves on: item, armor, weapon, gold, party member change (optional).
# Aliases: command_125, command_126, command_127, command_128, command_129
#==============================================================================
class Game_Interpreter
  #--------------------------------------------------------------------------
  # * Alias Method
  #--------------------------------------------------------------------------
  alias csca_autosave_125 command_125
  def command_125
    csca_autosave_125
    DataManager.csca_autosave(:save) if $game_system.csca_autosave_allowed?(:gold)
  end
  #--------------------------------------------------------------------------
  # * Alias Method
  #--------------------------------------------------------------------------
  alias csca_autosave_126 command_126
  def command_126
    csca_autosave_126
    DataManager.csca_autosave(:save) if $game_system.csca_autosave_allowed?(:item)
  end
  #--------------------------------------------------------------------------
  # * Alias Method
  #--------------------------------------------------------------------------
  alias csca_autosave_127 command_127
  def command_127
    csca_autosave_127
    DataManager.csca_autosave(:save) if $game_system.csca_autosave_allowed?(:weapon)
  end
  #--------------------------------------------------------------------------
  # * Alias Method
  #--------------------------------------------------------------------------
  alias csca_autosave_128 command_128
  def command_128
    csca_autosave_128
    DataManager.csca_autosave(:save) if $game_system.csca_autosave_allowed?(:armor)
  end
end
#==============================================================================
# ** Game_Player
#------------------------------------------------------------------------------
#  Autosave after a certain amount of steps(optional).
# Aliases: update, initialize
#==============================================================================
class Game_Player < Game_Character
  #--------------------------------------------------------------------------
  # * Alias Method
  #--------------------------------------------------------------------------
  alias csca_autosave_init initialize
  def initialize
    csca_autosave_init
    @csca_autosave_steps = 0
  end
  #--------------------------------------------------------------------------
  # * Alias Method
  #--------------------------------------------------------------------------
  alias csca_autosave_steps update
  def update
    csca_autosave_steps
    csca_check_autosave_step_count
  end
  #--------------------------------------------------------------------------
  # * Check autosave step count
  #--------------------------------------------------------------------------
  def csca_check_autosave_step_count
    if $game_party.steps % CSCA::AUTOSAVE::STEP_COUNT == 0 && $game_system.csca_autosave_allowed?(:steps) &&
        @steps != $game_party.steps
      DataManager.csca_autosave(:save)
      @csca_autosave_steps = $game_party.steps
    end
  end
end
#==============================================================================
# ** CSCA_Window_Autosaving
#------------------------------------------------------------------------------
#  The window with the "autosaving" text.
#==============================================================================
class CSCA_Window_Autosaving < Window_Base
  #--------------------------------------------------------------------------
  # * Object Initialization
  #--------------------------------------------------------------------------
  def initialize
    super(0,Graphics.height-fitting_height(1),window_width,fitting_height(1))
    self.opacity = 0
    self.contents_opacity = 0
    @show_count = 0
    refresh
  end
  #--------------------------------------------------------------------------
  # * Get Window Width
  #--------------------------------------------------------------------------
  def window_width
    return 240
  end
  #--------------------------------------------------------------------------
  # * Frame Update
  #--------------------------------------------------------------------------
  def update
    super
    if @show_count > 0
      update_fadein
      @show_count -= 1
    else
      update_fadeout
    end
  end
  #--------------------------------------------------------------------------
  # * Update Fadein
  #--------------------------------------------------------------------------
  def update_fadein
    self.contents_opacity += 16
  end
  #--------------------------------------------------------------------------
  # * Update Fadeout
  #--------------------------------------------------------------------------
  def update_fadeout
    self.contents_opacity -= 16
  end
  #--------------------------------------------------------------------------
  # * Open Window
  #--------------------------------------------------------------------------
  def open
    $game_map.autosaving = false
    @show_count = 60
    self.contents_opacity = 0
    self
  end
  #--------------------------------------------------------------------------
  # * Close Window
  #--------------------------------------------------------------------------
  def close
    @show_count = 0
    self
  end
  #--------------------------------------------------------------------------
  # * Refresh
  #--------------------------------------------------------------------------
  def refresh
    contents.clear
    contents.font.size = 18
    draw_text(0,0,contents.width,line_height,CSCA::AUTOSAVE::AUTOSAVING)
    contents.font.size = 24
  end
end
#==============================================================================
# ** Game_Map
#------------------------------------------------------------------------------
# Autosaving?
#==============================================================================
class Game_Map
  attr_accessor :autosaving
end