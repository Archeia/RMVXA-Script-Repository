=begin
Addon: CSCA Colosseum Wagers
version: 1.0.0(September 11, 2012)
Created by: Casper Gaming (http://www.caspergaming.com/)

Compatibility:
Made for RPGVXAce
IMPORTANT: ALL CSCA Scripts should be compatible with each other unless
otherwise noted.
REQUIRES CSCA Colosseum. Place this BELOW the main CSCA Colosseum script.

FFEATURES:
This script will add a wager system to the CSCA Colosseum script.

SETUP
Setup required. Instructions below.

CREDIT:
Free to use in noncommercial games if credit is given to:
Casper Gaming (http://www.caspergaming.com/)

To use in a commercial game, please purchase a license here:
http://www.caspergaming.com/licenses.html

TERMS:
http://www.caspergaming.com/terms_of_use.html
=end
module CSCA
  module COLOSSEUM
    WAGER_TEXT = "Wager"
    #===========================================================================
    WAGERS = [] # Don't Touch
    
    #WAGERS[x] = [CSCA_Item.new(amount, id, type)]
    # The type can be either:
    # :item = amount of $data_items[id]
    # :weapon = amount of $data_weapons[id]
    # :armor = amount of $data_armors[id]
    # :gold = amount of gold, ignores id value
    # Supports a size of up to 4.
    WAGERS[0] = [CSCA_Item.new(10, 0, :gold), CSCA_Item.new(2, 1, :item),
                 CSCA_Item.new(2, 1, :armor), CSCA_Item.new(2, 1, :weapon)]
    WAGERS[1] = [CSCA_Item.new(1000, 0, :gold)]
    
    #TROOP[x]["wagers"] = WAGERS[x]
    #TROOP[x] is the TROOP[x] setup in the main Colosseum Script.
    TROOP[0]["wagers"] = WAGERS[0]
    TROOP[1]["wagers"] = WAGERS[1]
    
    #End Setup
  end
end
$imported = {} if $imported.nil?
$imported["CSCA-ColosseumWager"] = true
msgbox('Missing Script: CSCA Colosseum! CSCA Colosseum Wager requires this
script to work properly.') if !$imported["CSCA-Colosseum"]
#==============================================================================
# ** CSCA_Scene_Colosseum
#------------------------------------------------------------------------------
# Add wager window, shorten selection window.
#==============================================================================
class CSCA_Scene_Colosseum < Scene_MenuBase
  #--------------------------------------------------------------------------#
  # Alias Method; Start Processing                                           #
  #--------------------------------------------------------------------------#
  alias wager_window create_addon_windows
  def create_addon_windows
    create_wager_window
    wager_window
  end
  #--------------------------------------------------------------------------#
  # Alias Method; Create Selection Window                                    #
  #--------------------------------------------------------------------------#
  alias wager_window_help set_help_windows
  def set_help_windows
    wager_window_help
    @command_window.wager_window = @wager_window
  end
  #--------------------------------------------------------------------------#
  # Overwrite Method; Selection Window Height                                #
  #--------------------------------------------------------------------------#
  def selection_window_height
    @troop_window.height-@instruction_window.height
  end
  #--------------------------------------------------------------------------#
  # Overwrite Method; Info Window Width                                      #
  #--------------------------------------------------------------------------#
  def info_window_width
    Graphics.width/2
  end
  #--------------------------------------------------------------------------#
  # Overwrite Method; Info Window Width                                      #
  #--------------------------------------------------------------------------#
  def info_window_x
    Graphics.width/2
  end
  #--------------------------------------------------------------------------#
  # Create Wager Window                                                      #
  #--------------------------------------------------------------------------#
  def create_wager_window
    @wager_window = CSCA_Window_ColosseumInfo.new(0,
      @head_window.height+@troop_window.height,Graphics.width/2,
      @head_window.height*3)
    @wager_window.set_wager
    @wager_window.viewport = @viewport
  end
  #--------------------------------------------------------------------------#
  # Alias Method; Remove Wager Items                                         #
  #--------------------------------------------------------------------------#
  alias wager_deduct start_battle
  def start_battle
    troop = CSCA::COLOSSEUM::TROOP[@command_window.index]
    $game_party.csca_col_remove_wager(troop) if $data_troops[troop["id"]]
    wager_deduct
  end
end
#==============================================================================
# ** CSCA_Window_ColosseumSelect
#------------------------------------------------------------------------------
# Adds Wager Window.
# Aliases: update_help
#==============================================================================
class CSCA_Window_ColosseumSelect < Window_Selectable
  attr_accessor :wager_window
  #--------------------------------------------------------------------------
  # Get Activation State of Selection Item
  #--------------------------------------------------------------------------
  def current_item_enabled?
    enable?(@data[index])
  end
  #--------------------------------------------------------------------------
  # Display in Enabled State?
  #--------------------------------------------------------------------------
  def enable?(troop)
    for wager in troop["wagers"].each
      case wager.type
      when :gold; return false if $game_party.gold < wager.amount
      when :tem; return false if $game_party.item_number($data_items[wager.id]) < wager.amount
      when :weapon; return false if $game_party.item_number($data_weapons[wager.id]) < wager.amount
      when :armor; return false if $game_party.item_number($data_armors[wager.id]) < wager.amount
      end
    end
    return true
  end
  #--------------------------------------------------------------------------#
  # Alias Method; Draw Items                                                 #
  #--------------------------------------------------------------------------#
  alias wager_enable draw_item
  def draw_item(index)
    change_color(normal_color, enable?(@data[index])) if @data[index]
    wager_enable(index)
  end
  #--------------------------------------------------------------------------#
  # Alias Method; Update Wager Window                                        #
  #--------------------------------------------------------------------------#
  alias wager_update update_help
  def update_help
    wager_update
    @wager_window.set_item(index)
  end
end
#==============================================================================
# ** CSCA_Window_ColosseumInfo
#------------------------------------------------------------------------------
# Displays reward and other configurable settings.
#==============================================================================
class CSCA_Window_ColosseumInfo < Window_Base
  #--------------------------------------------------------------------------#
  # Set Wager                                                                #
  #--------------------------------------------------------------------------#
  def set_wager
    @wager = true
  end
  #--------------------------------------------------------------------------#
  # Overwrite Method; Set Item                                               #
  #--------------------------------------------------------------------------#
  def set_item(index)
    contents.clear
    @wager ? draw_wager_text(index) : draw_reward_text(index)
  end
  #--------------------------------------------------------------------------#
  # Draw Wager Text                                                          #
  #--------------------------------------------------------------------------#
  def draw_wager_text(index)
    contents.font.bold = true
    draw_text(0,0,contents.width,line_height,CSCA::COLOSSEUM::WAGER_TEXT,1)
    contents.font.bold = false
    draw_wagers(index)
  end
  #--------------------------------------------------------------------------#
  # Draw Wagers                                                              #
  #--------------------------------------------------------------------------#
  def draw_wagers(index)
    troop = CSCA::COLOSSEUM::TROOP[index]
    number = 0
    for wager in troop["wagers"].each
      number += 1
      number_text = number.to_s + "."
      y = number*line_height
      draw_text(0,y,contents.width,line_height,number_text)
      wager.type == :gold ? draw_gold(y, wager.amount) : draw_other(y, wager)
    end
  end
end
#==============================================================================
# ** Game_Party
#------------------------------------------------------------------------------
# Remove Wager Items
#==============================================================================
class Game_Party < Game_Unit
  #--------------------------------------------------------------------------#
  # Remove Wager Items                                                       #
  #--------------------------------------------------------------------------#
  def csca_col_remove_wager(troop)
    for wager in troop["wagers"].each
      case wager.type
      when :item; lose_item($data_items[wager.id],wager.amount)
      when :armor; lose_item($data_armors[wager.id],wager.amount)
      when :weapon; lose_item($data_weapons[wager.id],wager.amount)
      when :gold; lose_gold(wager.amount)
      end
    end
  end
end