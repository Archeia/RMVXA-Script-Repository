=begin
CSCA Colosseum
version: 1.1.0 (Released: September 11, 2012)
Created by: Casper Gaming (http://www.caspergaming.com/)

Compatibility:
Made for RPGVXAce
IMPORTANT: ALL CSCA Scripts should be compatible with each other unless
otherwise noted.
REQUIRES CSCA Core Script v1.0.1+
================================================================================
UPDATES:
version 1.1.0:
-Rewrote sections of code to make addons easier to create.
================================================================================
FFEATURES:
This script will add a colosseum scene to your game, where players can fight
troops to win items.

SETUP
Setup required. Instructions below.

To call the colosseum scene in game, make this script call:
SceneManager.call(CSCA_Scene_Colosseum)

CREDIT:
Free to use in noncommercial games if credit is given to:
Casper Gaming (http://www.caspergaming.com/)

To use in a commercial game, please purchase a license here:
http://www.caspergaming.com/licenses.html

TERMS:
http://www.caspergaming.com/terms_of_use.html
=end
module CSCA
  module COLOSSEUM
    TROOP = [] # Don't Touch
    REWARDS = [] # Don't Touch
    
    #REWARDS[x] = [CSCA_Item.new(amount, id, type)]
    # The type can be either:
    # :item = amount of $data_items[id]
    # :weapon = amount of $data_weapons[id]
    # :armor = amount of $data_armors[id]
    # :gold = amount of gold, ignores id value
    # Supports a size of up to 4.
    REWARDS[0] = [CSCA_Item.new(100, 0, :gold), CSCA_Item.new(10, 1, :item),
                  CSCA_Item.new(1, 2, :armor), CSCA_Item.new(1, 2, :weapon)]
    REWARDS[1] = [CSCA_Item.new(1, 30, :weapon)]
    
    #TROOP[x] = {"id" => troop ID, "rewards" => reward array]
    TROOP[0] = {"id" => 2, "rewards" => REWARDS[0]}
    TROOP[1] = {"id" => 3, "rewards" => REWARDS[1]}
    
    HEADER = "Colosseum" # Header window text.
    PREVIEW = "Enemy Preview" # Troop window text.
    REWARD_TEXT = "Rewards" # Reward Window text.
    GOLD_ICON = 262 # Icon shown next to gold rewards.
  end # END SETUP
end
$imported = {} if $imported.nil?
$imported["CSCA-Colosseum"] = true
msgbox('Missing Script: CSCA Core Script! CSCA Colosseum requires this
script to work properly.') if !$imported["CSCA-Core"]
#==============================================================================
# ** CSCA_Scene_Colosseum
#------------------------------------------------------------------------------
# Handles Colosseum scene processing.
#==============================================================================
class CSCA_Scene_Colosseum < Scene_MenuBase
  #--------------------------------------------------------------------------#
  # Start Processing                                                         #
  #--------------------------------------------------------------------------#
  def start
    super
    create_head_window
    create_troop_window
    create_info_window
    create_instruction_window
    create_addon_windows
    create_selection_window
    create_result_window if $game_party.csca_battle_complete
  end
  #--------------------------------------------------------------------------#
  # Create Background                                                        #
  #--------------------------------------------------------------------------#
  def create_background
    super
    @background_sprite.tone.set(0, 0, 0, 128)
  end
  #--------------------------------------------------------------------------#
  # Create Header Window                                                     #
  #--------------------------------------------------------------------------#
  def create_head_window
    @head_window = CSCA_Window_Header.new(0, 0, CSCA::COLOSSEUM::HEADER)
    @head_window.viewport = @viewport
  end
  #--------------------------------------------------------------------------#
  # Create Troop Window                                                      #
  #--------------------------------------------------------------------------#
  def create_troop_window
    @troop_window = CSCA_Window_ColosseumTroop.new(Graphics.width/3,
      @head_window.height,Graphics.width/1.5,Graphics.height-@head_window.height*4)
    @troop_window.viewport = @viewport
  end
  #--------------------------------------------------------------------------#
  # Create Info Window                                                       #
  #--------------------------------------------------------------------------#
  def create_info_window
    @info_window = CSCA_Window_ColosseumInfo.new(info_window_x,
      @head_window.height+@troop_window.height,info_window_width,@head_window.height*3)
    @info_window.viewport = @viewport
  end
  #--------------------------------------------------------------------------#
  # Create Instruction Window                                                #
  #--------------------------------------------------------------------------#
  def create_instruction_window
    @instruction_window = CSCA_Window_Header.new(0,
      @head_window.height,Graphics.width/3,"Select Enemy")
    @instruction_window.viewport = @viewport
  end
  #--------------------------------------------------------------------------#
  # Create Addon Windows                                                     #
  #--------------------------------------------------------------------------#
  def create_addon_windows
  end
  #--------------------------------------------------------------------------#
  # Create Selection Window                                                  #
  #--------------------------------------------------------------------------#
  def create_selection_window
    @command_window = CSCA_Window_ColosseumSelect.new(0,@instruction_window.height*2,
      Graphics.width/3,selection_window_height,
      $game_party.csca_battle_complete ? @select : 0)
    @command_window.viewport = @viewport
    set_help_windows
    @command_window.set_handler(:cancel, method(:return_scene))
    @command_window.set_handler(:ok, method(:start_battle))
    @command_window.activate unless $game_party.csca_battle_complete
  end
  #--------------------------------------------------------------------------#
  # Create Battle Result Window                                              #
  #--------------------------------------------------------------------------#
  def create_result_window
    $game_party.csca_battle_complete = false
    @result_window = CSCA_Window_ColosseumResult.new(Graphics.width/4,Graphics.height/4,
      Graphics.width/2)
    @result_window.viewport = @viewport
    @result_window.set_handler(:cancel, method(:result_close))
    @result_window.set_handler(:ok, method(:result_close))
    @result_window.activate
  end
  #--------------------------------------------------------------------------#
  # Selection Window Height                                                  #
  #--------------------------------------------------------------------------#
  def selection_window_height
    Graphics.height-@head_window.height*2
  end
  #--------------------------------------------------------------------------#
  # Info Window Width                                                        #
  #--------------------------------------------------------------------------#
  def info_window_width
    Graphics.width/1.5
  end
  #--------------------------------------------------------------------------#
  # Info Window X                                                            #
  #--------------------------------------------------------------------------#
  def info_window_x
    Graphics.width/3
  end
  #--------------------------------------------------------------------------#
  # Set Selection Window Help Windows                                        #
  #--------------------------------------------------------------------------#
  def set_help_windows
    @command_window.help_window = @troop_window
    @command_window.help_window2 = @info_window
  end
  #--------------------------------------------------------------------------#
  # Start Battle                                                             #
  #--------------------------------------------------------------------------#
  def start_battle
    troop_id = CSCA::COLOSSEUM::TROOP[@command_window.index]["id"]
    @select = @command_window.index
    if $data_troops[troop_id]
      $game_party.csca_col_index = @command_window.index
      BattleManager.setup(troop_id, true, true)
      BattleManager.csca_colosseum(true)
      $game_player.make_encounter_count
      BattleManager.save_bgm_and_bgs
      BattleManager.play_battle_bgm
      SceneManager.call(Scene_Battle)
    end
  end
  #--------------------------------------------------------------------------#
  # Close Result Window                                                      #
  #--------------------------------------------------------------------------#
  def result_close
    @result_window.unselect
    @result_window.hide
    @command_window.activate
  end
end
#==============================================================================
# ** CSCA_Window_ColosseumTroop
#------------------------------------------------------------------------------
# Shows the troop graphic.
#==============================================================================
class CSCA_Window_ColosseumTroop < Window_Base
  #--------------------------------------------------------------------------#
  # Object Initialization                                                    #
  #--------------------------------------------------------------------------#
  def initialize(x, y, width, height)
    super(x, y, width, height)
  end
  #--------------------------------------------------------------------------#
  # Set Item                                                                 #
  #--------------------------------------------------------------------------#
  def set_item(index)
    contents.clear
    draw_troop(index)
  end
  #--------------------------------------------------------------------------#
  # Draw Troop                                                               #
  #--------------------------------------------------------------------------#
  def draw_troop(index)
    troop = $data_troops[CSCA::COLOSSEUM::TROOP[index]["id"]]
    bitmap = Bitmap.new(Graphics.width,Graphics.height*0.711)
    for member in troop.members
      name = $data_enemies[member.enemy_id].battler_name
      hue = $data_enemies[member.enemy_id].battler_hue
      troop_bitmap = Cache.battler(name, hue)
      bitmap.blt(member.x-troop_bitmap.width/2,member.y-troop_bitmap.height,troop_bitmap,troop_bitmap.rect)
    end
    contents.stretch_blt(contents.rect,bitmap,bitmap.rect)
    contents.font.bold = true
    draw_text(0,0,contents.width,line_height,CSCA::COLOSSEUM::PREVIEW,1)
    contents.font.bold = false
  end
end
#==============================================================================
# ** CSCA_Window_ColosseumInfo
#------------------------------------------------------------------------------
# Displays reward and other configurable settings.
#==============================================================================
class CSCA_Window_ColosseumInfo < Window_Base
  #--------------------------------------------------------------------------#
  # Object Initialization                                                    #
  #--------------------------------------------------------------------------#
  def initialize(x, y, width, height)
    super(x, y, width, height)
  end
  #--------------------------------------------------------------------------#
  # Set Item                                                                 #
  #--------------------------------------------------------------------------#
  def set_item(index)
    contents.clear
    draw_reward_text(index)
  end
  #--------------------------------------------------------------------------#
  # Draw Reward Text                                                         #
  #--------------------------------------------------------------------------#
  def draw_reward_text(index)
    contents.font.bold = true
    draw_text(0,0,contents.width,line_height,CSCA::COLOSSEUM::REWARD_TEXT,1)
    contents.font.bold = false
    draw_rewards(index)
  end
  #--------------------------------------------------------------------------#
  # Draw Rewards                                                             #
  #--------------------------------------------------------------------------#
  def draw_rewards(index)
    troop = CSCA::COLOSSEUM::TROOP[index]
    number = 0
    for reward in troop["rewards"].each
      number += 1
      number_text = number.to_s + "."
      y = number*line_height
      draw_text(0,y,contents.width,line_height,number_text)
      reward.type == :gold ? draw_gold(y, reward.amount) : draw_other(y, reward)
    end
  end
  #--------------------------------------------------------------------------#
  # Draw Gold Rewards                                                        #
  #--------------------------------------------------------------------------#
  def draw_gold(y,reward)
    draw_icon(CSCA::COLOSSEUM::GOLD_ICON,25,y)
    draw_text(49,y,contents.width-44,line_height,reward.to_s + Vocab::currency_unit)
  end
  #--------------------------------------------------------------------------#
  # Draw Other Rewards                                                       #
  #--------------------------------------------------------------------------#
  def draw_other(y, reward)
    draw_text(25,y,contents.width-20,line_height,reward.amount.to_s + "x")
    case reward.type
    when :item; item = $data_items[reward.id]
    when :weapon; item = $data_weapons[reward.id]
    when :armor; item = $data_armors[reward.id]
    end
    reward.amount > 9 ? x = 55 : x = 45
    draw_item_name(item,x,y,true,contents.width-20)
  end
end
#==============================================================================
# ** CSCA_Window_ColosseumSelect
#------------------------------------------------------------------------------
# Handles selection of troops, and updates Troop & Info windows.
#==============================================================================
class CSCA_Window_ColosseumSelect < Window_Selectable
  attr_accessor :help_window2
  #--------------------------------------------------------------------------#
  # Object Initialization                                                    #
  #--------------------------------------------------------------------------#
  def initialize(x,y,width,height,selection=0)
    super(x,y,width,height)
    @data = []
    refresh
    select(selection)
  end
  #--------------------------------------------------------------------------#
  # Get Item Max                                                             #
  #--------------------------------------------------------------------------#
  def item_max
    @data ? @data.size : 1
  end
  #--------------------------------------------------------------------------#
  # Get Item                                                                 #
  #--------------------------------------------------------------------------#
  def item
    @data && index >= 0 ? @data[index] : nil
  end
  #--------------------------------------------------------------------------#
  # Populate item list                                                       #
  #--------------------------------------------------------------------------#
  def make_item_list
    @data = CSCA::COLOSSEUM::TROOP
  end
  #--------------------------------------------------------------------------#
  # Draw Items                                                               #
  #--------------------------------------------------------------------------#
  def draw_item(index)
    item = @data[index]
    if item
      rect = item_rect(index)
      name = $data_troops[CSCA::COLOSSEUM::TROOP[index]["id"]].name
      draw_text(rect.x+6, rect.y, contents.width-6, line_height, name)
    end
  end
  #--------------------------------------------------------------------------#
  # Refresh                                                                  #
  #--------------------------------------------------------------------------#
  def refresh
    make_item_list
    create_contents
    draw_all_items
  end
  #--------------------------------------------------------------------------#
  # Update Help Window                                                       #
  #--------------------------------------------------------------------------#
  def update_help
    @help_window.set_item(index)
    @help_window2.set_item(index)
  end
end
#==============================================================================
# ** BattleManager
#------------------------------------------------------------------------------
# Passes battle data to Game_Party
# Aliased: battle_end, init_members
#==============================================================================
module BattleManager
  #--------------------------------------------------------------------------#
  # Initialize                                                               #
  #--------------------------------------------------------------------------#
  class <<self; alias csca_col_init init_members; end
  def self.init_members
    @csca_colosseum = false
    csca_col_init
  end
  #--------------------------------------------------------------------------#
  # Pass Result                                                              #
  #--------------------------------------------------------------------------#
  class <<self; alias csca_col_battle_end battle_end; end
  def self.battle_end(result)
    if @csca_colosseum
      $game_party.csca_set_battle_result(result) unless $BTEST
      csca_colosseum(false)
    end
    csca_col_battle_end(result)
  end
  #--------------------------------------------------------------------------#
  # Colosseum Battle?                                                        #
  #--------------------------------------------------------------------------#
  def self.csca_colosseum(b)
    @csca_colosseum = b
  end
end
#==============================================================================
# ** Game_Party
#------------------------------------------------------------------------------
# Passes data to Colosseum Scene
# Aliases: Initialize
#==============================================================================
class Game_Party < Game_Unit
  attr_reader :csca_battle_result
  attr_accessor :csca_battle_complete
  attr_accessor :csca_col_index
  #--------------------------------------------------------------------------#
  # Initialize                                                               #
  #--------------------------------------------------------------------------#
  alias csca_col_init initialize
  def initialize
    csca_col_init
    @csca_battle_result = 0
    @csca_battle_complete = false
    @csca_col_index = 0
  end
  #--------------------------------------------------------------------------#
  # Battle result(0: Win 1: Escape 2: Lose)                                  #
  #--------------------------------------------------------------------------#
  def csca_set_battle_result(result)
    @csca_battle_result = result
    @csca_battle_complete = true
    csca_award_col_rewards if result == 0
  end
  #--------------------------------------------------------------------------#
  # Give Colosseum Rewards                                                   #
  #--------------------------------------------------------------------------#
  def csca_award_col_rewards
    rewards = CSCA::COLOSSEUM::TROOP[csca_col_index]
    for reward in rewards["rewards"].each
      case reward.type
      when :item; gain_item($data_items[reward.id],reward.amount)
      when :armor; gain_item($data_armors[reward.id],reward.amount)
      when :weapon; gain_item($data_weapons[reward.id],reward.amount)
      when :gold; gain_gold(reward.amount)
      end
    end
  end
end
#==============================================================================
# ** CSCA_Window_ColosseumResult
#------------------------------------------------------------------------------
# Shows the troop graphic.
#==============================================================================
class CSCA_Window_ColosseumResult < Window_Selectable
  #--------------------------------------------------------------------------#
  # Object Initialization                                                    #
  #--------------------------------------------------------------------------#
  def initialize(x, y, width, height=line_height*9)
    super(x, y, width, height)
    refresh
  end
  #--------------------------------------------------------------------------#
  # Disallow Cursor Movement                                                 #
  #--------------------------------------------------------------------------#
  def cursor_movable?
    return false
  end
  #--------------------------------------------------------------------------#
  # Refresh                                                                  #
  #--------------------------------------------------------------------------#
  def refresh
    contents.clear
    contents.font.bold = true
    draw_text(0,0,contents.width,line_height,"Result",1)
    contents.font.bold = false
    result = $game_party.csca_battle_result
    result == 0 ? draw_winnings : draw_text(0,line_height*3,contents.width,line_height,"No Winnings!",1)
  end
  #--------------------------------------------------------------------------#
  # Draw Winnings                                                            #
  #--------------------------------------------------------------------------#
  def draw_winnings
    rewards = CSCA::COLOSSEUM::TROOP[$game_party.csca_col_index]
    number = 0
    defeated = 'You defeated %s!'
    draw_text(0,line_height,contents.width,line_height,sprintf(defeated, $data_troops[rewards["id"]].name))
    draw_text(0,line_height*3,contents.width,line_height,"Your Winnings:")
    for reward in rewards["rewards"].each
      number += 1
      number_text = number.to_s + "."
      y = number*line_height+(line_height*3)
      draw_text(0,y,contents.width,line_height,number_text)
      reward.type == :gold ? draw_gold(y, reward.amount) : draw_other(y, reward)
    end
  end
  #--------------------------------------------------------------------------#
  # Draw Gold Rewards                                                        #
  #--------------------------------------------------------------------------#
  def draw_gold(y,reward)
    draw_icon(CSCA::COLOSSEUM::GOLD_ICON,25,y)
    draw_text(49,y,contents.width-44,line_height,reward.to_s + Vocab::currency_unit)
  end
  #--------------------------------------------------------------------------#
  # Draw Other Rewards                                                       #
  #--------------------------------------------------------------------------#
  def draw_other(y, reward)
    draw_text(25,y,contents.width-20,line_height,reward.amount.to_s + "x")
    case reward.type
    when :item; item = $data_items[reward.id]
    when :weapon; item = $data_weapons[reward.id]
    when :armor; item = $data_armors[reward.id]
    end
    reward.amount > 9 ? x = 55 : x = 45
    draw_item_name(item,x,y,true,contents.width-20)
  end
end