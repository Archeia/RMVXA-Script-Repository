=begin
CSCA Game Over Options!
Version: 1.0
Created by: Casper Gaming (http://www.caspergaming.com/)

Compatibility:
Made for RPGVXAce
IMPORTANT: ALL CSCA Scripts should be compatible with each other unless
otherwise noted.

NOT COMPATIBLE WITH CSCA Autosave Plus!

FFEATURES:
This script adds a command window similar to the title screen on the gameover
screen. The options are Title, Load, and Shutdown. You can also change the
gameover music and image displayed by changing the value of a variable in-game.

SETUP
Setup below is required for some features to work properly.

CREDIT:
Free to use in noncommercial games if credit is given to:
Casper Gaming (http://www.caspergaming.com/)

To use in a commercial game, please purchase a license here:
http://www.caspergaming.com/licenses.html

TERMS:
http://www.caspergaming.com/terms_of_use.html
=end
module CSCA_GAMEOVER_OPTIONS
  
  GAMEOVER_MUSIC = 1 # Variable ID. When the value stored in this variable is set
                     # to 0, the gameover music specified in the database will
                     # play. When the value stored in this variable is greater
                     # than 0, the gameover music will be Audio/ME/GameoverX 
                     # where X is the number stored in this variable. For example, 
                     # if the variable is set to 5 using an event, the music file
                     # that will be played is Audio/ME/Gameover5. If you do not
                     # have a file named that in your ME folder, you'll get an
                     # error. Capitalization must match.
                     
  GAMEOVER_IMAGE = 2 # Variable ID. When the value stored in this variable is set
                     # to 0, the default gameover image will display. When the
                     # value stored in this variable is greater than 0, the
                     # gameover image will be Graphics/System/GameOverX, where
                     # X is the number stored in this variable. For example, 
                     # if the variable is set to 7 using an event, the music file
                     # that will be played is Audio/ME/GameOver7. If you do not
                     # have a file named that in your System folder, you'll get
                     # an error. Capitalization must match.
                     
  TITLE = "Title" # Text shown for the command that brings you back to the title.
  LOAD = "Load Saved Game" # Text shown for load command.
  QUIT = "Quit" # Text shown for command that exits the game.
  
end # Don't touch this or anything below.
class Scene_Gameover < Scene_Base
  include CSCA_GAMEOVER_OPTIONS
  
  alias csca_gameover_start start
  def start
    csca_gameover_start
    create_command_window
  end
  
  def update
    super
  end
  
  alias csca_gameover_music play_gameover_music
  def play_gameover_music
    csca_gameover_music
    if $game_variables[GAMEOVER_MUSIC] == 0
      $data_system.gameover_me.play
    elsif $game_variables[GAMEOVER_MUSIC] >= 1
      Audio.me_play("Audio/ME/Gameover" + $game_variables[GAMEOVER_MUSIC].to_s, 100, 100)
    end
  end
  
  alias csca_gameover_background create_background
  def create_background
    csca_gameover_background
    if $game_variables[GAMEOVER_IMAGE] == 0
      @sprite.bitmap = Cache.system("GameOver")
    elsif $game_variables[GAMEOVER_IMAGE] >= 0
      @sprite.bitmap = Cache.system("GameOver" + $game_variables[GAMEOVER_IMAGE].to_s)
    end
  end
  
  def create_command_window
    @command_window = Window_CSCA_GameoverCommand.new
    @command_window.set_handler(:title, method(:goto_title))
    @command_window.set_handler(:load, method(:goto_file_selection))
    @command_window.set_handler(:shutdown, method(:goto_shutdown))
  end
  
  def goto_shutdown
    close_command_window
    fadeout_all
    SceneManager.exit
  end
  
  def goto_file_selection
    close_command_window
    SceneManager.call(Scene_Load)
  end
  
  def close_command_window
    @command_window.close
    update until @command_window.close?
  end
end

class Window_CSCA_GameoverCommand < Window_Command
  include CSCA_GAMEOVER_OPTIONS
  
  def initialize
    super(0, 0)
    update_placement
    self.openness = 0
    open
  end
  
  def window_width
    return 160
  end
  
  def update_placement
    self.x = (Graphics.width - width) / 2
    self.y = (Graphics.height * 1.6 - height) / 2
  end

  def make_command_list
    add_command(TITLE, :title)
    add_command(LOAD, :load, continue_enabled)
    add_command(QUIT, :shutdown)
  end
  
  def continue_enabled
    DataManager.save_file_exists?
  end
end