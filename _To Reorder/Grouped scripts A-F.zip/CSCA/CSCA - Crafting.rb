=begin
CSCA Crafting
version: 1.0.4 (Released: May 17, 2013)
Created by: Casper Gaming (http://www.caspergaming.com/)
================================================================================
Compatibility:
Made for RPGVXAce
IMPORTANT: ALL CSCA Scripts should be compatible with each other unless
otherwise noted.

Requires CSCA Core Script v1.0.6+
LINK: http://www.rpgmakervxace.net/topic/6879-csca-core-script/

Does not require, but for all features/best results use with CSCA Professions.
LINK: http://www.rpgmakervxace.net/topic/14734-csca-professions/

For toast messages, get the CSCA Toast Manager v1.1.0+
LINK: http://www.rpgmakervxace.net/topic/13960-csca-toast-manager/
================================================================================
FFEATURES
Creates a crafting system in your game. Can differentiate between recipes, such
as a separate scene for cooking recipes and blacksmithing recipes. Includes some
equips to alter recipe data as well.
================================================================================
UPDATES
version 1.0.1
- Bug fix: ingredients should now display properly.

version 1.0.2
- Bug Fix: Required Items/Products can now be weapons, armors, and gold too.

version 1.0.3
- Bug Fix: Errors dealing with required items should now be fixed. (finally)
- CSCA Currency System colors now show in the crafting info window.

version 1.0.4
- Bug Fix: All errors dealing with gold and CSCA Currency System should now be fixed.
================================================================================
SETUP
Set up required. Instructions below.
================================================================================
CREDIT:
Free to use in noncommercial games if credit is given to:
Casper Gaming (http://www.caspergaming.com/)

To use in a commercial game, please purchase a license here:
http://www.caspergaming.com/licenses.html
================================================================================
TERMS:
http://www.caspergaming.com/terms_of_use.html
================================================================================
=end
module CSCA
  module CRAFT
    RECIPE = []
#==============================================================================
# ** Important Script Calls
#==============================================================================
# All script calls use the recipe's :symbol to reference a [recipe].
#------------------------------------------------------------------------------
# discover_recipe(recipe[, discovered])
# Changes the discovery of the [recipe]. the [discovered] parameter is optional
# and only required if setting the discovery status to false.
#
# recipe_times_crafted(recipe[, amount])
# Allows you to manually change the times crafted for the [recipe] specified. The
# [amount] is an optional parameter, that will increase the [recipe]'s times crafted
# value by [amount]. If [amount] is not specified, it is assmumed to be 1.
#==============================================================================
# ** Setting up Note Tags
#==============================================================================
# The following note tags go in the 'Item' note box.
#------------------------------------------------------------------------------
# <csca_recipe: RECIPE_SYMBOL_HERE>
#
# Creates an item that, when used, will set the discovery status of the recipe
# specified to true. DO NOT include the colon (':') in the parameter.
#------------------------------------------------------------------------------
# The following note tags go in the 'Weapon' or 'Armor' note box.
#------------------------------------------------------------------------------
# <csca_craft_lvl: x>
#
# Reduces the level requirement for all recipe's by [x] amount. Requires
# CSCA Professions to function.
#
# <csca_craft_perc: x>
#
# Increases the success rate of all recipe's by [x] amount.
#==============================================================================
# ** Calling the Crafting Scene
#==============================================================================
# You must call the recipe scene, as well as prepare it for a certain recipe type
# or all recipe types. To do so, make the following script call:
#
# SceneManager.call(CSCA_Scene_Crafting)
# SceneManager.scene.prepare(SCENE_NAME_SYMBOL_HERE)
#
# Where the preparation parameter will be a symbol, such as :all or :cooking,
# specified in the SCENE_NAMES hash below.
#==============================================================================
# ** Advanced things you can do
#==============================================================================
# To set a variable to the recipe's discovered/total, use this script call inside a
# "control variables" event command:
#
# $csca.recipe_types[key][index]
#
# where the [key] parameter is a recipe type, such as :cooking . This will tell
# the variable to only include recipe's of that type in the calculations. If you
# need to set the variable to the total recipes or recipe's discovered, you can
# use the key :all
#
# The [index] parameter can be either 0 or 1. When 0, it will set the variable
# to the total amount of recipe's of the specified type. When 1, it will set the
# variable to the amount of recipe's discovered of the specified type.
#==============================================================================
# ** Begin Setup
#==============================================================================
    SHOW_TOASTS = true # Display toast messages?
    RECIPE_TEXT = "Recipe" # Text to call recipes by
    USE_ICONS = true # Show icons next to recipe name?
    COLOR1 = 20 # Progress Gauge color 1
    COLOR2 = 21 # Progress Gauge color 2
    SHOW_SUCCESS_RATE = true # Show the success chance in crafting window?
    SUCCESS_TEXT = "Crafting Success!" # Toast text upon successful craft
    FAIL_TEXT = "Crafting Failed!"     # Toast text upon failed craft
    FAIL_TEXT2 = "No item was crafted."# Toast text upon failed craft (line 2)
    GAIN_EXP_IF_FAIL = false # Still gain EXP if crafting is unsuccessful?
    
    # The SCENE_NAMES hash controls a few parts of the script. When calling a
    # crafting scene, you also need to specify a scene name (Script call to do so
    # explained above). This determines which recipe type to include in the scene,
    # such as all recipes with the 'type' of :cooking. In case you want the crafting
    # scene to include all recipes, use the :all symbol. The text value belonging
    # to each key will be the text shown in the header window.
    #
    #SCENE_NAMES = {
    #:all => "Crafting",   # :all is a special key used to specify all recipes.
    #:cooking => "Cooking" # Tells the scene to only use :cooking recipes.
    #}
    
    SCENE_NAMES = {
    :all => "Crafting",
    :cooking => "Cooking"
    }
    
    #RECIPE[x] = {    # the value inside the brackets should start at 0 and ascend in order.
    #:name => "Apple Pie",    # The name of the recipe.
    #:ingredients => [[:item, 1, 5], [:item, 2, 3]],  # The consumed ingredients for the recipe. Explained more below.
    #:required => [:item, 3, 1], # The required item for the recipe. Explained more below.
    #:product => [:item, 4, 1],  # The item the recipe produces if successful. Explained more below.
    #:scrap => [:item, 5, 1],    # The item the recipe produces if unsuccessful. Explained more below.
    #:type => :cooking,          # The recipe type. All recipes of the same type will be shown in the crafting list determined by the SCENE_NAME specified.
    #:discovered => false,       # Determines if the player has unlocked the recipe or not. Undiscovered recipe's will not show in the recipe list.
    #:time => 120,               # The time, in frames (60f = 1sec) the recipe takes to create. Recommended to set above 2.
    #:success_rate => 100,       # The chance a recipe has at successfuully producing its :product rather than its :scrap . Range 0 - 100
    #:symbol => :applepie,       # The recipe's symbol. Used in script calls to specify the individual recipe.
    # * :experience => 10,       # The experience granted by the recipe.
    # * :level_req => 1,         # The required skill level to be able to craft the recipe.
    #:icon => 559,               # The icon associated with the recipe.
    #:image => nil,              # The image associated with the recipe. 72x72, located in the "Graphics" folder. Set to nil if not using.
    #:color => 2,                # The text color of the recipe name.
    #:start_sound => "Hammer",   # The SE played when starting to craft the recipe. Located in "Audio/SE" folder.
    #:fail_sound => nil,         # The SE played when recipe is unsuccessfully completed. Located in "Audio/SE" folder.
    #:complete_sound => nil,     # The SE played when recipe is successfully completed. Located in "Audio/SE" folder.
    #:desc => ["Delicious Apple Pie.","HP Restoration item."] # The descriptive text displayed in the recipe information window. Each block of text is 1 line.
    #}
    # * Requires CSCA Professions to function.
    #
    # HOW TO SET UP THE INGREDIENTS/REQUIRED/PRODUCT/SCRAP ITEMS.
    # Items are set up like this: [symbol, id, amount]
    # where [symbol] is either :item, :weapon, :armor, or :gold.
    # the [id] is the ID of the item/weapon/armor. Gold does not use an id, so leave it as 0. EXCEPTION: If using CSCA Currency System, set the id to the currency symbol when using :gold.
    # the [amount] is how much of the specified object is required.
    # the :ingredients support unlimited items, however :required, :product, and :scrap only support 1 item each. The :required parameter is optional; set to nil if not using.
    
    RECIPE[0] = {
    :name => "Apple Pie",
    :ingredients => [[:gold, :g, 5]],#, [:item, 2, 3]],
    :required => [:gold, :g, 100],
    :product => [:gold, :g, 10],
    :scrap => [:item, 5, 1],
    :type => :cooking,
    :discovered => false,
    :time => 120,
    :success_rate => 100,
    :symbol => :applepie,
    :experience => 10,
    :level_req => 1,
    :icon => 559,
    :image => nil,
    :color => 2,
    :start_sound => "Hammer",
    :fail_sound => nil,
    :complete_sound => nil,
    :desc => ["Delicious Apple Pie.","HP Restoration item."]
    }
    
    RECIPE[1] = {
    :name => "Cheese Mushroom",
    :ingredients => [[:item, 21, 1], [:item, 20, 1]],
    :required => nil,
    :product => [:item, 22, 1],
    :scrap => [:item, 4, 1],
    :type => :cooking,
    :discovered => false,
    :time => 160,
    :success_rate => 0,
    :symbol => :cheesemush,
    :experience => 5,
    :level_req => 1,
    :icon => 660,
    :image => nil,
    :color => 2,
    :start_sound => "Hammer",
    :fail_sound => nil,
    :complete_sound => nil,
    :desc => ["A cheese covered mushroom.","HP Restoration item."]
    }
#==============================================================================
# ** End Setup
#==============================================================================
  end
end
$imported = {} if $imported.nil?
$imported["CSCA-Crafting"] = true
#==============================================================================
# ** CSCA_CraftingRecipe
#------------------------------------------------------------------------------
# Handles recipe data and methods
#==============================================================================
class CSCA_CraftingRecipe
  attr_accessor :discovered
  attr_accessor :times_crafted
  attr_reader :name
  attr_reader :symbol
  attr_reader :type
  attr_reader :exp
  attr_reader :level_req
  attr_reader :success_rate
  attr_reader :time
  attr_reader :icon
  attr_reader :image
  attr_reader :color
  attr_reader :start_sound
  attr_reader :fail_sound
  attr_reader :complete_sound
  attr_reader :desc
  attr_reader :ingredients
  attr_reader :required
  attr_reader :product
  attr_reader :scrap
  #--------------------------------------------------------------------------
  # Object Initialization
  #--------------------------------------------------------------------------
  def initialize(recipe)
    @times_crafted = 0
    @name = recipe[:name]
    @symbol = recipe[:symbol]
    @type = recipe[:type]
    @discovered = recipe[:discovered]
    @exp = recipe[:experience]
    @level_req = recipe[:level_req]
    @success_rate = (recipe[:success_rate].to_f/100.0)
    @time = recipe[:time]
    @icon = recipe[:icon]
    @image = recipe[:image]
    @color = recipe[:color]
    @start_sound = get_sound(recipe[:start_sound])
    @fail_sound = get_sound(recipe[:fail_sound])
    @complete_sound = get_sound(recipe[:complete_sound])
    @desc = recipe[:desc]
    setup_ingredients(recipe)
    setup_required_items(recipe)
    setup_product(recipe)
    setup_scrap(recipe)
  end
  #--------------------------------------------------------------------------
  # Setup ingredients
  #--------------------------------------------------------------------------
  def setup_ingredients(recipe)
    @ingredients = []
    recipe[:ingredients].each do |ingredient|
      @ingredients.push(CSCA_Item.new(ingredient[2], ingredient[1], ingredient[0]))
    end
  end
  #--------------------------------------------------------------------------
  # Setup Required Item
  #--------------------------------------------------------------------------
  def setup_required_items(recipe)
    if recipe[:required].nil?
      @required = nil
      return
    end
    @required = CSCA_Item.new(recipe[:required][2], recipe[:required][1], recipe[:required][0])
  end
  #--------------------------------------------------------------------------
  # Setup Scrap Item
  #--------------------------------------------------------------------------
  def setup_scrap(recipe)
    if recipe[:scrap].nil?
      @scrap = nil
      return
    end
    @scrap = CSCA_Item.new(recipe[:scrap][2], recipe[:scrap][1], recipe[:scrap][0])
  end
  #--------------------------------------------------------------------------
  # Setup Product
  #--------------------------------------------------------------------------
  def setup_product(recipe)
    @product = CSCA_Item.new(recipe[:product][2], recipe[:product][1], recipe[:product][0])
  end
  #--------------------------------------------------------------------------
  # Setup sound files
  #--------------------------------------------------------------------------
  def get_sound(filename)
    return nil if filename.nil?
    return "Audio/SE/" + filename
  end
  #--------------------------------------------------------------------------
  # Check if crafting recipe uses special "required" items
  #--------------------------------------------------------------------------
  def has_required_items?
    !@required.nil?
  end
  #--------------------------------------------------------------------------
  # Check if crafting recipe awards a scrap item upon crafting failure
  #--------------------------------------------------------------------------
  def has_scrap_item?
    !@scrap.nil?
  end
end
#==============================================================================
# ** RPG::Item
#------------------------------------------------------------------------------
#  Checks for recipe note tag.
#==============================================================================
class RPG::Item < RPG::UsableItem
  #--------------------------------------------------------------------------
  # Item is recipe?
  #--------------------------------------------------------------------------
  def csca_recipe?
    @note =~ /<csca_recipe: (.*)>/i
  end
  #--------------------------------------------------------------------------
  # Get recipe from note tag
  #--------------------------------------------------------------------------
  def csca_get_recipe
    @note =~ /<csca_recipe: (.*)>/i ? $1.to_sym : ""
  end
end
#==============================================================================
# ** RPG::EquipItem
#------------------------------------------------------------------------------
#  Tags for equips that effect recipes.
#==============================================================================
class RPG::EquipItem < RPG::BaseItem
  #--------------------------------------------------------------------------
  # Crafting level modification
  #--------------------------------------------------------------------------
  def csca_craft_lvmod
    @note =~ /<csca_craft_lvl: (.*)>/i ? $1.to_i : 0
  end
  #--------------------------------------------------------------------------
  # Crafting time modification
  #--------------------------------------------------------------------------
  def csca_craft_successmod
    @note =~ /<csca_craft_perc: (.*)>/i ? ($1.to_f/100.0) : 0
  end
end
#==============================================================================
# ** Game_Interpreter
#------------------------------------------------------------------------------
#  Addition of commands related to managing recipes.
#==============================================================================
class Game_Interpreter
  #--------------------------------------------------------------------------
  # Change Recipe Discovered status
  #--------------------------------------------------------------------------
  def discover_recipe(recipe, discovered = true)
    $csca.change_recipe_discovery(recipe, discovered)
  end
  #--------------------------------------------------------------------------
  # Change Recipe Times Crafted
  #--------------------------------------------------------------------------
  def recipe_times_crafted(recipe, amount = 1)
    $csca.change_recipe_times_crafted(recipe, amount)
  end
end
#==============================================================================
# ** CSCA_Core
#------------------------------------------------------------------------------
# Added recipe handling.
#==============================================================================
class CSCA_Core
  attr_reader :recipes
  attr_reader :recipe_types
  #--------------------------------------------------------------------------
  # Alias Method; Object Initialization
  #--------------------------------------------------------------------------
  alias :csca_crafting_initialize :initialize
  def initialize
    csca_crafting_initialize
    initialize_recipes
  end
  #--------------------------------------------------------------------------
  # Initialize Recipes
  #--------------------------------------------------------------------------
  def initialize_recipes
    @recipes = []
    @recipe_types = {:all => [0,0]}
    CSCA::CRAFT::RECIPE.each do |recipe|
      @recipes.push(CSCA_CraftingRecipe.new(recipe))
      next if @recipe_types.has_key?(recipe[:type])
      @recipe_types[recipe[:type]] = [0, 0]
    end
    @recipe_types.each_key do |key|
      set_recipe_totals(key, 0)
      set_recipe_totals(key, 1)
    end
  end
  #--------------------------------------------------------------------------
  # Set Recipe Total (by type)
  #--------------------------------------------------------------------------
  def set_recipe_totals(type, index)
    return if @recipe_types[type].nil?
    rt = @recipe_types[type]
    rt[index] = 0
    @recipes.each do |recipe|
      rt[index] += 1 if (recipe.type == type || type == :all) && (recipe.discovered || index == 0)
    end
  end
  #--------------------------------------------------------------------------
  # Get recipe
  #--------------------------------------------------------------------------
  def get_recipe(symbol)
    @recipes.each do |recipe|
      return recipe if recipe.symbol == symbol
    end
  end
  #--------------------------------------------------------------------------
  # Change Recipe Discovered status
  #--------------------------------------------------------------------------
  def change_recipe_discovery(sym, discovered = true)
    recipe = get_recipe(sym)
    recipe.discovered = discovered
    $csca.reserve_toast([:recipe_discovery, recipe]) if $imported["CSCA-ToastManager"] && CSCA::CRAFT::SHOW_TOASTS && discovered
    set_recipe_totals(recipe.type, 1)
    set_recipe_totals(:all, 1)
  end
  #--------------------------------------------------------------------------
  # Change Recipe Times Crafted
  #--------------------------------------------------------------------------
  def change_recipe_times_crafted(sym, amount = 1)
    recipe = get_recipe(sym)
    recipe.times_crafted += amount
  end
  #--------------------------------------------------------------------------
  # Calculate recipes success rate after modifications
  #--------------------------------------------------------------------------
  def calculate_recipe_success_rate(recipe)
    base = recipe.success_rate
    $game_party.battle_members.each do |member|
      member.equips.each do |equip|
        next if equip.nil?
        base += equip.csca_craft_successmod
      end
    end
    base = 1 if base > 1
    base = 0 if base < 0
    return base
  end
  #--------------------------------------------------------------------------
  # Calculate recipes success rate after modifications
  #--------------------------------------------------------------------------
  def calculate_recipe_level_req(recipe)
    base = recipe.level_req
    $game_party.battle_members.each do |member|
      member.equips.each do |equip|
        next if equip.nil?
        base -= equip.csca_craft_lvmod
      end
    end
    base = 1 if base < 1
    return base
  end
end
#==============================================================================
# ** Scene_ItemBase
#------------------------------------------------------------------------------
# Special handling for recipe item.
#Aliases: use_item
#==============================================================================
class Scene_ItemBase < Scene_MenuBase
  #--------------------------------------------------------------------------
  # Alias Method; Use Item
  #--------------------------------------------------------------------------
  alias :csca_crafting_use_item :use_item
  def use_item
    csca_crafting_use_item
    check_recipe if item.is_a?(RPG::Item)
  end
  #--------------------------------------------------------------------------
  # Check if item is a recipe
  #--------------------------------------------------------------------------
  def check_recipe
    if item.csca_recipe?
      $csca.change_recipe_discovery(item.csca_get_recipe)
    end
  end
end
#==============================================================================
# ** CSCA_Window_Toast
#------------------------------------------------------------------------------
# Show toasts for recipe discovery.
#==============================================================================
class CSCA_Window_Toast < Window_Base
  #--------------------------------------------------------------------------
  # Alias method; refresh
  #--------------------------------------------------------------------------
  alias :csca_craft_refresh :refresh
  def refresh(params)
    csca_craft_refresh(params)
    if params[0] == :recipe_discovery
      draw_text(0, 0, contents.width, line_height, sprintf("New %s discovered!", CSCA::CRAFT::RECIPE_TEXT), 1)
      ix = (contents.width/2) - (text_size(params[1].name).width/2) - 16
      draw_icon(params[1].icon, ix, line_height)
      draw_text(12, line_height, contents.width, line_height, params[1].name, 1)
    end
    if params[0] == :recipe_crafted
      recipe = params[1]
      result = params[2]
      s1 = result == :success ? CSCA::CRAFT::SUCCESS_TEXT : CSCA::CRAFT::FAIL_TEXT
      draw_text(0, 0, contents.width, line_height, s1, 1)
      if recipe.scrap.nil? && result == :failure
        draw_text(0, line_height, contents.width, line_height, CSCA::CRAFT::FAIL_TEXT2, 1)
      else
        s2 = "Gained: "
        if result == :success
          s3 = recipe.product.type == :gold ? "" : "x" 
          s3 += recipe.product.amount.to_s + " "
          currency = $game_party.get_csca_cs_currency(recipe.product.id) if $imported["CSCA-CurrencySystem"] && recipe.product.type == :gold
          item = case recipe.product.type
          when :gold; $imported["CSCA-CurrencySystem"] ? currency[:name] : Vocab::currency_unit
          when :item; $data_items[recipe.product.id]
          when :armor; $data_armors[recipe.product.id]
          when :weapon; $data_weapons[recipe.product.id]
          end
        else
          s3 = recipe.scrap.type == :gold ? "" : "x" 
          s3 += recipe.scrap.amount.to_s + " "
          currency = $game_party.get_csca_cs_currency(recipe.scrap.id) if $imported["CSCA-CurrencySystem"] && recipe.scrap.type == :gold
          item = case recipe.scrap.type
          when :gold; $imported["CSCA-CurrencySystem"] ? currency[:name] : Vocab::currency_unit
          when :item; $data_items[recipe.scrap.id]
          when :armor; $data_armors[recipe.scrap.id]
          when :weapon; $data_weapons[recipe.scrap.id]
          end
        end
        x = text_size(s2).width
        x2 = text_size(s3).width
        draw_text(0, line_height, contents.width, line_height, s2)
        if (result == :success && recipe.product.type == :gold) || (result == :failure && recipe.scrap.type == :gold) && $imported["CSCA-CurrencySystem"]
          change_color(currency[:color])
          draw_icon(currency[:icon], x, line_height)
          draw_text(x + 24, line_height, contents.width-x-24, line_height, s3)
          change_color(system_color)
          draw_text(x + 24 + x2, line_height, contents.width-x-24-x2, line_height, item)
        else
          draw_text(x, line_height, contents.width-x, line_height, s3)
          draw_icon(item.icon_index, x+x2, line_height)
          change_color(text_color(recipe.color))
          draw_text(x + 24 + x2, line_height, contents.width - x - 24 - x2, line_height, item.name)
        end
      end
      change_color(normal_color)
    end
  end
end
#==============================================================================
# ** CSCA_Scene_Crafting
#------------------------------------------------------------------------------
# Handles the crafting scene. Changes based on profession needs.
#==============================================================================
class CSCA_Scene_Crafting < Scene_MenuBase
  #--------------------------------------------------------------------------
  # Prepare scene
  #--------------------------------------------------------------------------
  def prepare(profession)
    @profession = profession
  end
  #--------------------------------------------------------------------------
  # Start Processing
  #--------------------------------------------------------------------------
  def start
    super
    if @profession.nil?
      SceneManager.goto(Scene_Map)
      $csca.report_error("Scene not prepared.", "CSCA Crafting", "Use SceneManager.scene.prepare(profession_symbol_here)\nimmediately after calling the scene..")
    end
    create_head_window
    create_recipestext_window
    create_select_window
    create_info_window
    create_progress_window
  end
  #--------------------------------------------------------------------------
  # Terminate
  #--------------------------------------------------------------------------
  def terminate
    super
    @profession = nil
  end
  #--------------------------------------------------------------------------
  # Create Header Window
  #--------------------------------------------------------------------------
  def create_head_window
    @head_window = CSCA_Window_Header.new(0,0,CSCA::CRAFT::SCENE_NAMES[@profession])
  end
  #--------------------------------------------------------------------------
  # Create "Recipes" Text Window
  #--------------------------------------------------------------------------
  def create_recipestext_window
    @rt_window = CSCA_Window_Header.new(0,@head_window.height,Graphics.width/3,"Recipes")
  end
  #--------------------------------------------------------------------------
  # Create Select Window
  #--------------------------------------------------------------------------
  def create_select_window
    @select_window = CSCA_Window_CraftingSelect.new(0,@head_window.height*2,Graphics.width/3,Graphics.height-(@head_window.height*2),@profession)
    @select_window.set_handler(:cancel, method(:return_scene))
    @select_window.set_handler(:ok, method(:craft_recipe))
    @select_window.activate
  end
  #--------------------------------------------------------------------------
  # Create Info Window
  #--------------------------------------------------------------------------
  def create_info_window
    @info_window = CSCA_Window_CraftingInfo.new(@select_window.width,@head_window.height,Graphics.width-@select_window.width,Graphics.height-@head_window.height*2)
    @select_window.help_window = @info_window
  end
  #--------------------------------------------------------------------------
  # Create Progress Window
  #--------------------------------------------------------------------------
  def create_progress_window
    @progress_window = CSCA_Window_CraftingProgress.new(@select_window.width,@head_window.height+@info_window.height,Graphics.width-@select_window.width,@head_window.height)
  end
  #--------------------------------------------------------------------------
  # Return Scene
  #--------------------------------------------------------------------------
  def return_scene
    if @progress_window.crafting
      Sound.play_buzzer
      @select_window.activate
      return
    end
    super
  end
  #--------------------------------------------------------------------------
  # Craft Recipe
  #--------------------------------------------------------------------------
  def craft_recipe
    if @progress_window.crafting
      Sound.play_buzzer
      @select_window.activate
      return
    end
    @progress_window.set_item(@select_window.item)
    @progress_window.lose_ingredients
    @select_window.refresh
    @select_window.activate
  end
end
#==============================================================================
# ** CSCA_Window_CraftingSelect
#------------------------------------------------------------------------------
# Selection window for the crafting scene.
#==============================================================================
class CSCA_Window_CraftingSelect < Window_Selectable
  #--------------------------------------------------------------------------
  # Object Initialization
  #--------------------------------------------------------------------------
  def initialize(x, y, w, h, p)
    super(x, y, w, h)
    @data = []
    @profession = p
    refresh
    select(0)
  end
  #--------------------------------------------------------------------------
  # Get Item Max
  #--------------------------------------------------------------------------
  def item_max
    @data ? @data.size : 1
  end
  #--------------------------------------------------------------------------
  # Get Item
  #--------------------------------------------------------------------------
  def item
    @data && index >= 0 ? @data[index] : nil
  end
  #--------------------------------------------------------------------------
  # Populate item list
  #--------------------------------------------------------------------------
  def make_item_list
    @data = $csca.recipes.select {|item| include?(item)}
  end
  #--------------------------------------------------------------------------
  # Get Activation State of Selection Item
  #--------------------------------------------------------------------------
  def current_item_enabled?
    enable?(@data[index])
  end
  #--------------------------------------------------------------------------
  # Display in Enabled State?
  #--------------------------------------------------------------------------
  def enable?(recipe)
    return false if recipe.nil?
    recipe.ingredients.each do |item|
      return false unless has_item(item)
    end
    unless recipe.required.nil?
      return false unless has_item(recipe.required)
    end
    if $imported["CSCA-Professions"]
      return false if $csca.calculate_recipe_level_req(recipe) > $csca.get_profession(recipe.type).level
    end
    return true
  end
  #--------------------------------------------------------------------------
  # Party has required items?
  #--------------------------------------------------------------------------
  def has_item(item)
    return case item.type
    when :gold; $game_party.gold >= item.amount
    when :armor; $game_party.item_number($data_armors[item.id]) >= item.amount
    when :weapon; $game_party.item_number($data_weapons[item.id]) >= item.amount
    when :item; $game_party.item_number($data_items[item.id]) >= item.amount
    end
  end
  #--------------------------------------------------------------------------
  # Show item in list?
  #--------------------------------------------------------------------------
  def include?(item)
    return true if @profession == :all && item.discovered
    return item.type == @profession && item.discovered
  end
  #--------------------------------------------------------------------------
  # Draw Items
  #--------------------------------------------------------------------------
  def draw_item(index)
    item = @data[index]
    if item
      rect = item_rect(index)
      x = rect.x
      if CSCA::CRAFT::USE_ICONS
        draw_icon(item.icon, x, rect.y)
        x += 24
      end
      change_color(normal_color, enable?(item))
      draw_text(x, rect.y, contents.width-x, line_height, item.name)
      change_color(normal_color)
    end
  end
  #--------------------------------------------------------------------------
  # Refresh
  #--------------------------------------------------------------------------
  def refresh
    make_item_list
    create_contents
    draw_all_items
  end
  #--------------------------------------------------------------------------
  # Update Help Window
  #--------------------------------------------------------------------------
  def update_help
    @help_window.set_item(item) if @help_window
  end
end
#==============================================================================
# ** CSCA_Window_CraftingInfo
#------------------------------------------------------------------------------
# Displays information for selected recipe.
#==============================================================================
class CSCA_Window_CraftingInfo < Window_Base
  #--------------------------------------------------------------------------
  # Object Initialization
  #--------------------------------------------------------------------------
  def initialize(x, y, w, h)
    super(x, y, w, h)
  end
  #--------------------------------------------------------------------------
  # Set recipe
  #--------------------------------------------------------------------------
  def set_item(recipe)
    return if recipe.nil?
    contents.clear
    contents.font.size = 24
    @recipe = recipe
    draw_recipe_information
  end
  #--------------------------------------------------------------------------
  # Order to draw recipe information
  #--------------------------------------------------------------------------
  def draw_recipe_information
    draw_recipe_image
    draw_recipe_name
    oy = line_height
    @y_add = 0
    contents.font.size = 20
    draw_product(oy)
    draw_success_rate(oy*2) if CSCA::CRAFT::SHOW_SUCCESS_RATE
    if $imported["CSCA-Professions"]
      draw_exp_gain(oy*3)
      draw_level_requirement(oy*4)
      @y_add += line_height*2
    end
    draw_times_crafted(oy*3 + @y_add)
    unless @recipe.required.nil?
      @y_add += line_height
      draw_required_item(oy*3 + @y_add)
    end
    draw_ingredients(oy*4 + @y_add)
    draw_recipe_desc(oy*4 + @y_add)
  end
  #--------------------------------------------------------------------------
  # Draw icon/image
  #--------------------------------------------------------------------------
  def draw_recipe_image
    if @recipe.image.nil?
      icon_index = @recipe.icon
      bitmap = Cache.system("Iconset")
      rect = Rect.new(icon_index % 16 * 24, icon_index / 16 * 24, 24, 24)
      target = Rect.new(0,0,72,72)
      contents.stretch_blt(target, bitmap, rect)
    else
      bitmap = Bitmap.new("Graphics/"+@recipe.image)
      target = Rect.new(0,0,72,72)
      contents.stretch_blt(target, bitmap, bitmap.rect, 255)
    end
  end
  #--------------------------------------------------------------------------
  # Draw name
  #--------------------------------------------------------------------------
  def draw_recipe_name
    contents.font.bold = true
    draw_text(72, 0, contents.width-72, line_height+8, @recipe.name, 1)
    contents.font.bold = false
  end
  #--------------------------------------------------------------------------
  # Draw product
  #--------------------------------------------------------------------------
  def draw_product(y)
    s1 = "Produces: "
    x = 72
    produce = case @recipe.product.type
    when :item; $data_items[@recipe.product.id]
    when :weapon; $data_weapons[@recipe.product.id]
    when :armor; $data_armors[@recipe.product.id]
    when :gold; $imported["CSCA-CurrencySystem"] ? $game_party.get_csca_cs_currency(@recipe.product.id)[:currency_unit] : Vocab::currency_unit
    end
    change_color(system_color)
    draw_text(x, y, contents.width-x, line_height, s1)
    change_color(normal_color)
    x += text_size(s1).width
    unless @recipe.product.type == :gold
      draw_icon(produce.icon_index, x, y) 
      x += 24
    end
    if @recipe.product.type == :gold
      change_color($game_party.get_csca_cs_currency(@recipe.product.id)[:color]) if $imported["CSCA-CurrencySystem"]
      draw_text(x, y, contents.width-x, line_height, sprintf("%d%s", @recipe.product.amount, produce))
    else
      draw_text(x, y, contents.width-x, line_height, sprintf("%dx %s", @recipe.product.amount, produce.name))
    end
    change_color(normal_color)
  end
  #--------------------------------------------------------------------------
  # Draw success rate
  #--------------------------------------------------------------------------
  def draw_success_rate(y)
    s1 = "Success Rate: "
    x = 72
    change_color(system_color)
    draw_text(x, y, contents.width-x, line_height, s1)
    change_color(normal_color)
    x += text_size(s1).width
    draw_text(x, y, contents.width-x, line_height, ($csca.calculate_recipe_success_rate(@recipe)*100).to_i.to_s + "%")
  end
  #--------------------------------------------------------------------------
  # Draw exp gain
  #--------------------------------------------------------------------------
  def draw_exp_gain(y)
    s1 = "Experience Gain: "
    x = 0
    exp = $csca.split_number(@recipe.exp)
    change_color(system_color)
    draw_text(x, y, contents.width-x, line_height, s1)
    change_color(normal_color)
    x += text_size(s1).width
    if exp[0] >= 1
      draw_text(x, y, contents.width-x, line_height, sprintf("%d,%03d,%03d", exp[0], exp[1], exp[2]))
    elsif exp[0] == 0 && exp[1] >= 1
      draw_text(x, y, contents.width-x, line_height, sprintf("%d,%03d", exp[1], exp[2]))
    else
      draw_text(x, y, contents.width-x, line_height, sprintf("%d", exp[2]))
    end
  end
  #--------------------------------------------------------------------------
  # Draw level requirement
  #--------------------------------------------------------------------------
  def draw_level_requirement(y)
    s1 = "Level Req: "
    x = 0
    change_color(system_color)
    draw_text(x, y, contents.width-x, line_height, s1)
    change_color(normal_color)
    x += text_size(s1).width
    profession_name = $csca.get_profession(@recipe.type).name
    draw_text(x, y, contents.width-x, line_height, sprintf("%s lv. %d", profession_name, $csca.calculate_recipe_level_req(@recipe)))
  end
  #--------------------------------------------------------------------------
  # Draw times crafted
  #--------------------------------------------------------------------------
  def draw_times_crafted(y)
    s1 = "Times Crafted: "
    x = 0
    change_color(system_color)
    draw_text(x, y, contents.width-x, line_height, s1)
    change_color(normal_color)
    x += text_size(s1).width
    draw_text(x, y, contents.width-x, line_height, @recipe.times_crafted.to_s)
  end
  #--------------------------------------------------------------------------
  # Draw required item
  #--------------------------------------------------------------------------
  def draw_required_item(y)
    s1 = "Required Item: "
    x = 0
    item = case @recipe.required.type
    when :item; $data_items[@recipe.required.id]
    when :weapon; $data_weapons[@recipe.required.id]
    when :armor; $data_armors[@recipe.required.id]
    when :gold; $imported["CSCA-CurrencySystem"] ? $game_party.get_csca_cs_currency(@recipe.required.id)[:currency_unit] : Vocab::currency_unit
    end
    change_color(system_color)
    draw_text(x, y, contents.width-x, line_height, s1)
    change_color(normal_color)
    x += text_size(s1).width
    unless @recipe.required.type == :gold
      draw_icon(item.icon_index, x, y)
      x += 24
    end
    if @recipe.required.type == :gold
      change_color($game_party.get_csca_cs_currency(@recipe.required.id)[:color]) if $imported["CSCA-CurrencySystem"]
      draw_text(x, y, contents.width-x, line_height, sprintf("%d%s", @recipe.required.amount, item))
    else
      draw_text(x, y, contents.width-x, line_height, sprintf("%dx %s", @recipe.required.amount, item.name))
    end
    change_color(normal_color)
  end
  #--------------------------------------------------------------------------
  # Draw ingredients
  #--------------------------------------------------------------------------
  def draw_ingredients(y)
    s1 = "Ingredients: "
    x = 0
    ny = 0
    change_color(system_color)
    draw_text(x, y, contents.width-x, line_height, s1)
    change_color(normal_color)
    x += text_size(s1).width
    @recipe.ingredients.each do |ingredient|
      @y_add += line_height
      item = case ingredient.type
      when :item; $data_items[ingredient.id]
      when :weapon; $data_weapons[ingredient.id]
      when :armor; $data_armors[ingredient.id]
      when :gold; $imported["CSCA-CurrencySystem"] ? $game_party.get_csca_cs_currency(ingredient.id)[:currency_unit] : Vocab::currency_unit
      end
      if ingredient.type == :gold
        change_color($game_party.get_csca_cs_currency(ingredient.id)[:color]) if $imported["CSCA-CurrencySystem"]
        draw_text(x, y + ny, contents.width-x, line_height, sprintf("%d%s", ingredient.amount, item))
        change_color(normal_color)
      else
        draw_icon(item.icon_index, x, y + ny)
        x += 24
        draw_text(x, y + ny, contents.width-x, line_height, sprintf("%dx %s", ingredient.amount, item.name))
      end
      ny += line_height
      x -= 24
    end
  end
  #--------------------------------------------------------------------------
  # Draw recipe description
  #--------------------------------------------------------------------------
  def draw_recipe_desc(y)
    s1 = "Description: "
    x = 0
    ny = 0
    change_color(system_color)
    draw_text(x, y, contents.width-x, line_height, s1)
    change_color(normal_color)
    x += text_size(s1).width
    @recipe.desc.each do |line|
      @y_add += line_height
      draw_text(x, y + ny, contents.width-x, line_height, line)
      ny += line_height
      x = 0
    end
  end
end
#==============================================================================
# ** CSCA_Window_CraftingProgress
#------------------------------------------------------------------------------
# Displays the progress bar of creating an item.
#==============================================================================
class CSCA_Window_CraftingProgress < Window_Base
  attr_reader :crafting
  #--------------------------------------------------------------------------
  # Object Initialization
  #--------------------------------------------------------------------------
  def initialize(x, y, w, h)
    super(x, y, w, h)
    set_variables
    refresh
  end
  #--------------------------------------------------------------------------
  # Used for resetting variables after crafting
  #--------------------------------------------------------------------------
  def set_variables
    @frames = @success_rate = @fail_time = 0
    @total_frames = 1
    @crafting = false
    @recipe = @result = @fail_sound = @item = nil
  end
  #--------------------------------------------------------------------------
  # Refresh
  #--------------------------------------------------------------------------
  def refresh
    contents.clear
    s1 = "Progress: "
    x = text_size(s1).width
    c1 = text_color(CSCA::CRAFT::COLOR1)
    c2 = text_color(CSCA::CRAFT::COLOR2)
    change_color(system_color)
    draw_text(0, 0, contents.width, line_height, s1)
    change_color(normal_color)
    draw_gauge(x+25, -5, contents.width-x-50, @frames.to_f/@total_frames, c1, c2)
    draw_percentage
  end
  #--------------------------------------------------------------------------
  # Frame Update
  #--------------------------------------------------------------------------
  def update
    super
    return unless @crafting
    @frames += 1
    refresh
    if crafting_complete?
      @crafting = false
      end_craft
    end
  end
  #--------------------------------------------------------------------------
  # Check for Craft Completion
  #--------------------------------------------------------------------------
  def crafting_complete?
    return (@result == :failure && @fail_time <= @frames) || (@result == :success && @frames >= @total_frames)
  end
  #--------------------------------------------------------------------------
  # End Craft
  #--------------------------------------------------------------------------
  def end_craft
    Audio.se_stop
    sound = @result == :success ? @recipe.complete_sound : @recipe.fail_sound
    Audio.se_play(sound) unless sound.nil?
    $csca.reserve_toast([:recipe_crafted, @recipe, @result]) if $imported["CSCA-ToastManager"] && CSCA::CRAFT::SHOW_TOASTS
    @recipe.times_crafted += 1 if @result == :success
    unless @item.nil?
      item = get_item(@item)
      if not_gold?(item)
        $game_party.gain_item(item, @item.amount)
      else
        $imported["CSCA-CurrencySystem"] ? $game_party.gain_currency($game_party.get_csca_cs_currency(@item.id), @item.amount) : $game_party.gain_gold(@item.amount)
      end
    end
    if $imported["CSCA-Professions"]
      $csca.change_profession_exp(@recipe.type, @recipe.exp) if @result == :success || CSCA::CRAFT::GAIN_EXP_IF_FAIL
    end
    set_variables
    refresh
  end
  #--------------------------------------------------------------------------
  # Start Crafting
  #--------------------------------------------------------------------------
  def set_item(recipe)
    @total_frames = recipe.time
    @success_rate = $csca.calculate_recipe_success_rate(recipe)
    @recipe = recipe
    calculate_result
    Audio.se_play(recipe.start_sound)
    @crafting = true
  end
  #--------------------------------------------------------------------------
  # Draw Gauge Percentage
  #--------------------------------------------------------------------------
  def draw_percentage
    x = text_size("Progress: ").width
    draw_text(((contents.width-25)/2)+(x/2), 0, contents.width, line_height, sprintf("%1.2f%%", (@frames.to_f/@total_frames)*100))
  end
  #--------------------------------------------------------------------------
  # Calculate Result
  #--------------------------------------------------------------------------
  def calculate_result
    odds = rand(0)
    if @success_rate > odds
      @item = @recipe.product
      @result = :success
    else
      @item = @recipe.scrap
      @result = :failure
      @fail_time = rand(@total_frames/2).to_i
      @fail_time += (@total_frames/2).to_i
    end
  end
  #--------------------------------------------------------------------------
  # Lose ingredients
  #--------------------------------------------------------------------------
  def lose_ingredients
    @recipe.ingredients.each do |ingredient|
      item = get_item(ingredient)
      if not_gold?(item)
        $game_party.lose_item(item, ingredient.amount)
      else
        $imported["CSCA-CurrencySystem"] ? $game_party.lose_currency($game_party.get_csca_cs_currency(ingredient.id), ingredient.amount) : $game_party.lose_gold(ingredient.amount)
      end
    end
  end
  #--------------------------------------------------------------------------
  # Determine if item is gold or not.
  #--------------------------------------------------------------------------
  def not_gold?(item)
    item.is_a?(RPG::Item) || item.is_a?(RPG::Weapon) || item.is_a?(RPG::Armor)
  end
  #--------------------------------------------------------------------------
  # Determine Item gained.
  #--------------------------------------------------------------------------
  def get_item(item)
    return case item.type
    when :item; $data_items[item.id]
    when :weapon; $data_weapons[item.id]
    when :armor; $data_armors[item.id]
    else; nil
    end
  end
end
if $imported["CSCA-Professions"]
#==============================================================================
# ** CSCA_Professions
#------------------------------------------------------------------------------
# Adds recipe type data
#Aliases: initialize
#==============================================================================
class CSCA_Professions
  attr_reader :recipe_type
  attr_reader :show_recipes
  #--------------------------------------------------------------------------
  # Alias Method; Object Initialization
  #--------------------------------------------------------------------------
  alias :craft_init :initialize
  def initialize(profession)
    craft_init(profession)
    @recipe_type = profession[:recipe_type]
    @show_recipes = profession[:show_recipes]
  end
end
#==============================================================================
# ** CSCA_Window_ProfessionInfo
#------------------------------------------------------------------------------
# Adds recipe known amount to profession window.
#Aliases: draw_profession_information
#==============================================================================
class CSCA_Window_ProfessionInfo < Window_Base
  #--------------------------------------------------------------------------
  # Alias Method; Draw profession information
  #--------------------------------------------------------------------------
  alias :craft_draw_profession_information :draw_profession_information
  def draw_profession_information
    craft_draw_profession_information
    draw_profession_recipes(line_height*5-8) if @profession.show_recipes
  end
  #--------------------------------------------------------------------------
  # Draw Recipes Discovered Amount
  #--------------------------------------------------------------------------
  def draw_profession_recipes(y)
    s1 = "Recipes Discovered: "
    x = text_size(s1).width
    change_color(system_color)
    draw_text(0, y, contents.width, line_height, s1)
    change_color(normal_color)
    draw_text(x, y, contents.width-x, line_height, sprintf("%d/%d", $csca.recipe_types[@profession.recipe_type][1], $csca.recipe_types[@profession.recipe_type][0]))
  end
end
end # $imported["CSCA-Professions"]