=begin
CSCA Sidequests
version: 1.1.0 (Released: October 19, 2012)
Created by: Casper Gaming (http://www.caspergaming.com/)

Compatibility:
Made for RPGVXAce
IMPORTANT: ALL CSCA Scripts should be compatible with each other unless
otherwise noted.
Requires CSCA Core script v1.0.4 +

FFEATURES
Allows you to have a sort of message board/task list with side quests the
player can accept if conditions are met.

SETUP
Setup below required. Intructions below.
================================================================================
UPDATE HISTORY
version 1.0.0
-original script

version 1.1.0
-Added ability to hide items with unmet conditions.
-Added completed sidequest icon in list.
-Added ability to change completion status of sidequests.
-Added ability to require a sidequest to be completed for another sidequest
to activate.
-Fixed bug when a sidequest ahd both a switch and a variable condition.
================================================================================
CREDIT:
Free to use in noncommercial games if credit is given to:
Casper Gaming (http://www.caspergaming.com/)

To use in a commercial game, please purchase a license here:
http://www.caspergaming.com/licenses.html

TERMS:
http://www.caspergaming.com/terms_of_use.html
=end
module CSCA
  module SIDEQUEST
    SIDEQUESTS = [] # Don't Touch
    TASKS      = [] # Don't Touch
    
    ###########################################################################
    # SCRIPT CALLS
    #
    # To change the completion status of a sidequest, make this script call:
    # $csca.complete_sidequest(x[, false])
    #
    # For example, $csca.complete_sidequest(0) will set the first sidequest as
    # compelte. $csca.complete_sidequest(0, false) will set it to incomplete.
    #
    ###########################################################################
    
    HEADER = "Message Board" # Text displayed in header window.
    HEADER2 = "Current Mission" # Text displayed when accessed from menu.
    TASK_TEXT = "Objectives" # Text displayed above objectives.
    VAR = 1 # Variable that stores id of task selected.
    ON_MISSION = 1 # Switch to turn on when mission is accepted.
    NUMBER = true # Number the objectives list?
    HIDE = false # Hide sidequests with unmet conditions or show greyed out?
    ICON = 621 # Index of icon shown next to complete sidequests.
    
    #TASK[x] = ["Task array.","Separate tasks with commas!"]
    TASKS[0] = ["Objective one","Objective two","Objective three"]
    TASKS[1] = ["Do this","Then do this","And finally do this"]
    TASKS[2] = ["This","Is","A","Lot","Of","Tasks","For","A","Tutorial"]
    
    #SIDEQUESTS[x] = {"tasks" => TASK ARRAY VALUE, "name" => "Mission Name",
    #"switch" => [switch_id, true/false](leave nil to not use a switch)
    #"variable" => [variable_id, value](leave nil to not use a variable)
    SIDEQUESTS[0] = {"tasks" => TASKS[0], "name" => "Tutorial", "switch" => nil,
    "variable" => nil, "sidequest" => nil}
    SIDEQUESTS[1] = {"tasks" => TASKS[1], "name" => "Tutorial 2", "switch" => [1, true],
    "variable" => nil, "sidequest" => 0}
    SIDEQUESTS[2] = {"tasks" => TASKS[2], "name" => "Tutorial 3", "switch" => nil,
    "variable" => [2, 10], "sidequest" => 1}
  end # End Setup. Don't touch this or anything below.
end
$imported = {} if $imported.nil?
$imported["CSCA-SideQuests"] = true
msgbox('Missing Script: CSCA Core Script! CSCA SideQuests requires this
script to work properly.') if !$imported["CSCA-Core"]
#==============================================================================
# ** CSCA_Scene_Sidequest
#------------------------------------------------------------------------------
# Handles Sidequest scene processing.
#==============================================================================
class CSCA_Scene_Sidequest < Scene_MenuBase
  #--------------------------------------------------------------------------#
  # Start Processing                                                         #
  #--------------------------------------------------------------------------#
  def start
    super
    create_head_window
    create_task_window
    create_addon_windows
    create_select_window
    set_help_windows
  end
  #--------------------------------------------------------------------------#
  # Create Background                                                        #
  #--------------------------------------------------------------------------#
  def create_background
    super
    @background_sprite.tone.set(0, 0, 0, 128)
  end
  #--------------------------------------------------------------------------#
  # Create Header Window                                                     #
  #--------------------------------------------------------------------------#
  def create_head_window
    @head_window = CSCA_Window_Header.new(0, 0, CSCA::SIDEQUEST::HEADER)
    @head_window.viewport = @viewport
  end
  #--------------------------------------------------------------------------#
  # Create Select Window                                                     #
  #--------------------------------------------------------------------------#
  def create_select_window
    @select_window = CSCA_Window_SidequestSelect.new(0,@head_window.height,
      Graphics.width/3,select_window_height)
    @select_window.set_handler(:cancel, method(:return_scene))
    @select_window.set_handler(:ok, method(:task_accept))
    @select_window.viewport = @viewport
    @select_window.activate
  end
  #--------------------------------------------------------------------------#
  # Create Task Window                                                       #
  #--------------------------------------------------------------------------#
  def create_task_window
    @task_window = CSCA_Window_SidequestTask.new(Graphics.width/3,
      task_window_y,Graphics.width-Graphics.width/3,task_window_height)
    @task_window.viewport = @viewport
  end
  #--------------------------------------------------------------------------#
  # Accept Task                                                              #
  #--------------------------------------------------------------------------#
  def task_accept
    $game_variables[CSCA::SIDEQUEST::VAR] = @select_window.index + 1
    $game_switches[CSCA::SIDEQUEST::ON_MISSION] = true
    return_scene
  end
  #--------------------------------------------------------------------------#
  # Select Window Height                                                     #
  #--------------------------------------------------------------------------#
  def select_window_height
    return Graphics.height-@head_window.height
  end
  #--------------------------------------------------------------------------#
  # Task Window Y                                                            #
  #--------------------------------------------------------------------------#
  def task_window_y
    return @head_window.height
  end
  #--------------------------------------------------------------------------#
  # Task Window Height                                                       #
  #--------------------------------------------------------------------------#
  def task_window_height
    return Graphics.height-@head_window.height
  end
  #--------------------------------------------------------------------------#
  # Sets help windows                                                        #
  #--------------------------------------------------------------------------#
  def set_help_windows
    @select_window.help_window = @task_window
  end
  #--------------------------------------------------------------------------#
  # Used by addons                                                           #
  #--------------------------------------------------------------------------#
  def create_addon_windows
  end
end
#==============================================================================
# ** CSCA_Scene_SidequestMenu
#------------------------------------------------------------------------------
# Handles Sidequest scene processing.
#==============================================================================
class CSCA_Scene_SidequestMenu < Scene_MenuBase
  #--------------------------------------------------------------------------#
  # Start Processing                                                         #
  #--------------------------------------------------------------------------#
  def start
    super
    create_head_window
    create_task_window
  end
  #--------------------------------------------------------------------------#
  # Create Background                                                        #
  #--------------------------------------------------------------------------#
  def create_background
    super
    @background_sprite.tone.set(0, 0, 0, 128)
  end
  #--------------------------------------------------------------------------#
  # Create Header Window                                                     #
  #--------------------------------------------------------------------------#
  def create_head_window
    @head_window = CSCA_Window_Header.new(0, 0, CSCA::SIDEQUEST::HEADER2)
    @head_window.viewport = @viewport
  end
  #--------------------------------------------------------------------------#
  # Create Task Window                                                       #
  #--------------------------------------------------------------------------#
  def create_task_window
    @task_window = CSCA_Window_SidequestTask.new(0,@head_window.height,
      @head_window.width,task_window_height,1)
    @task_window.viewport = @viewport
  end
  #--------------------------------------------------------------------------#
  # Task Window Height                                                       #
  #--------------------------------------------------------------------------#
  def task_window_height
    return Graphics.height-@head_window.height
  end
end
#==============================================================================
# ** CSCA_Window_SidequestSelect
#------------------------------------------------------------------------------
# Handles selection of sidequests, and updates objectives info.
#==============================================================================
class CSCA_Window_SidequestSelect < Window_Selectable
  #--------------------------------------------------------------------------#
  # Object Initialization                                                    #
  #--------------------------------------------------------------------------#
  def initialize(x,y,width,height)
    super(x,y,width,height)
    @data = []
    refresh
    select(0)
  end
  #--------------------------------------------------------------------------#
  # Get Item Max                                                             #
  #--------------------------------------------------------------------------#
  def item_max
    @data ? @data.size : 1
  end
  #--------------------------------------------------------------------------#
  # Get Item                                                                 #
  #--------------------------------------------------------------------------#
  def item
    @data && index >= 0 ? @data[index] : nil
  end
  #--------------------------------------------------------------------------#
  # Get Activation State of Selection Item                                   #
  #--------------------------------------------------------------------------#
  def current_item_enabled?
    enable?(@data[index])
  end
  #--------------------------------------------------------------------------#
  # Current Item Enabled                                                     #
  #--------------------------------------------------------------------------#
  def enable?(item)
    if item["switch"] != nil
      return false if $game_switches[item["switch"][0]] != item["switch"][1]
    end
    if item["variable"] != nil
      return false if $game_variables[item["variable"][0]] != item["variable"][1]
    end
    if item["sidequest"] != nil
      return $csca.sidequests[item["sidequest"]]
    end
    return true
  end
  #--------------------------------------------------------------------------#
  # Include Item in list?                                                    #
  #--------------------------------------------------------------------------#
  def include?(item)
    return true unless CSCA::SIDEQUEST::HIDE
    return enable?(item)
  end
  #--------------------------------------------------------------------------#
  # Populate item list                                                       #
  #--------------------------------------------------------------------------#
  def make_item_list
    @data = CSCA::SIDEQUEST::SIDEQUESTS.select {|item| include?(item)}
  end
  #--------------------------------------------------------------------------#
  # Draw Items                                                               #
  #--------------------------------------------------------------------------#
  def draw_item(index)
    item = @data[index]
    if item
      rect = item_rect(index)
      name = CSCA::SIDEQUEST::SIDEQUESTS[index]["name"]
      change_color(normal_color, enable?(CSCA::SIDEQUEST::SIDEQUESTS[index]))
      draw_text(rect.x, rect.y, contents.width, line_height, name)
      draw_icon(CSCA::SIDEQUEST::ICON,contents.width-24,rect.y) if $csca.sidequests[index] == true
    end
  end
  #--------------------------------------------------------------------------#
  # Refresh                                                                  #
  #--------------------------------------------------------------------------#
  def refresh
    make_item_list
    create_contents
    draw_all_items
  end
  #--------------------------------------------------------------------------#
  # Update Help Window                                                       #
  #--------------------------------------------------------------------------#
  def update_help
    @help_window.set_item(index)
  end
end
#==============================================================================
# ** CSCA_Window_SidequestTask
#------------------------------------------------------------------------------
# Displays tasks for each mission.
#==============================================================================
class CSCA_Window_SidequestTask < Window_Base
  #--------------------------------------------------------------------------#
  # Object Initialization                                                    #
  #--------------------------------------------------------------------------#
  def initialize(x, y, width, height, from_menu = 0)
    super(x, y, width, height)
    set_item($game_variables[CSCA::SIDEQUEST::VAR] - 1) if from_menu == 1
    @from_menu = from_menu
  end
  #--------------------------------------------------------------------------#
  # Set Item                                                                 #
  #--------------------------------------------------------------------------#
  def set_item(index)
    contents.clear
    draw_task_text
    draw_tasks(index)
  end
  #--------------------------------------------------------------------------#
  # Draw Task Text                                                           #
  #--------------------------------------------------------------------------#
  def draw_task_text
    contents.font.bold = true
    draw_text(0,0,contents.width,line_height,CSCA::SIDEQUEST::TASK_TEXT,1)
    contents.font.bold = false
  end
  #--------------------------------------------------------------------------#
  # Draw Tasks                                                               #
  #--------------------------------------------------------------------------#
  def draw_tasks(index)
    task = CSCA::SIDEQUEST::SIDEQUESTS[index]["tasks"]
    number = 0
    for i in 0...task.size
      task_text = task[i]
      number += 1
      CSCA::SIDEQUEST::NUMBER == true ? number_text = number.to_s + ". " : number_text = ""
      y = number*line_height
      draw_text(0,y,contents.width,line_height,number_text + task_text)
    end
  end
  #--------------------------------------------------------------------------#
  # Frame Update                                                             #
  #--------------------------------------------------------------------------#
  def update
    super
    if @from_menu == 1 && Input.press?(:B)
      SceneManager.return
    end
  end
end
#==============================================================================
# ** CSCA
#------------------------------------------------------------------------------
# Adds methods for storing and changing sidequest completion status.
#Aliases: initialize
#==============================================================================
class CSCA_Core
  attr_reader :sidequests
  #--------------------------------------------------------------------------#
  # Alias Method; Object Initialization                                      #
  #--------------------------------------------------------------------------#
  alias :sidequest_init :initialize
  def initialize
    sidequest_init
    @sidequests = []
    for i in 0...CSCA::SIDEQUEST::SIDEQUESTS.size
      @sidequests[i] = false
    end
  end
  #--------------------------------------------------------------------------#
  # Change completion status                                                 #
  #--------------------------------------------------------------------------#
  def complete_sidequest(sidequest, b = true)
    @sidequests[sidequest] = b
  end
end