=begin
CSCA SaveFile +
version: 1.0.0
Created by: Casper Gaming (http://www.caspergaming.com/)

Compatibility:
Made for RPGVXAce
IMPORTANT: ALL CSCA Scripts should be compatible with each other unless
otherwise noted.
REQUIRES CSCA Core Script!

FFEATURES:
This script changes the look of the File Selection window. It adds the actor's
level next to the character sprite, and the actor's name below the character
sprite. It also adds the amount of gold and the save count aligned right. Below
the character sprite section is the Map Name and Playtime.

SETUP + How To Use
This script is plug 'n play, however the New Game + Option requires setup
if you wish to use it.
To "name" a map, type this code in the map's notebox on a new line:<CSCA MAPNAME>
For example, <CSCA Overworld> would display "Overworld" on the file selection
screen.

If using the new game + option, there are some built in script calls to make
resetting things easier. They are as follows:

$game_system.csca_clear_self_switches
^ This sets all self switches on every map to false. <Still in testing>

$game_system.csca_clear_items
^ This removes all items and key items from the inventory.

$game_system.csca_clear_weapons
^ This removes all weapons from the inventory and equipment.

$game_system.csca_clear_armors
^ This removes all armors from the inventory and equipment.

CREDIT:
Free to use in noncommercial games if credit is given to:
Casper Gaming (http://www.caspergaming.com/)

To use in a commercial game, please purchase a license here:
http://www.caspergaming.com/licenses.html

TERMS:
http://www.caspergaming.com/terms_of_use.html
=end

module CSCA
  module NGP
  
  ENABLE_NGP = true # Set to true if you want to enable New Game Plus.
  
  NGSWITCH = 6 # Switch to turn ON at the end of your game. Next save will put
               # text that says New Game + on the savefile.
               
  MAP_AMOUNT = 4 # The total amount of maps you have in your project.
  end
end # END SETUP. DON'T TOUCH ANYTHING BELOW UNLESS YOU KNOW WHAT TO DO
$imported = {} if $imported.nil?
$imported["CSCA-SaveFilePlus"] = true
msgbox('Missing Script: CSCA Core Script! CSCA SaveFile Plus requires this
script to work properly.') if !$imported["CSCA-Core"]
#==============================================================================
# ** DataManager
#------------------------------------------------------------------------------
# Saves additional data used by savefile window.
# Aliases: make_save_header
#==============================================================================
module DataManager
  #--------------------------------------------------------------------------#
  # Alias Method; make save header                                           #
  #--------------------------------------------------------------------------#
  class <<self; alias csca_save_header make_save_header; end
  def self.make_save_header
    header = csca_save_header
    header[:csca] = $game_party.csca_misc_info_for_savefile
    header
  end
end
#==============================================================================
# ** Game_Party
#------------------------------------------------------------------------------
# Method for collecting additional save data.
#==============================================================================
class Game_Party < Game_Unit
  #--------------------------------------------------------------------------#
  # Collect additional save info                                             #
  #--------------------------------------------------------------------------#
  def csca_misc_info_for_savefile
    battle_members.collect do |actor|
      [actor.level, $imported["CSCA-CurrencySystem"] ? $game_party.current_currency : $game_party.gold,
        actor.name, $game_system.save_count, $game_map.csca_map_note, $game_switches[CSCA::NGP::NGSWITCH]]
    end
  end
end
#==============================================================================
# ** Window_SaveFile
#------------------------------------------------------------------------------
# Displays the save window.
# Overwrites: refresh, draw_party,characters
#==============================================================================
class Window_SaveFile < Window_Base
  #--------------------------------------------------------------------------#
  # Overwrite Method; Refresh                                                #
  #--------------------------------------------------------------------------#
  def refresh
    contents.clear
    csca_draw_info(0, contents.height - line_height, contents.width - 4, 2)
    contents.font.size = 16
    change_color(normal_color)
    name = Vocab::File + " #{@file_index + 1}"
    draw_text(4, 0, 200, line_height, name)
    @name_width = text_size(name).width
    draw_party_characters(30, 60)
    csca_draw_small_info(45, 30)
  end
  #--------------------------------------------------------------------------#
  # Overwrite Method; Draw Characters                                        #
  #--------------------------------------------------------------------------#
  def draw_party_characters(x, y)
    header = DataManager.load_header(@file_index)
    return unless header
    header[:characters].each_with_index do |data, i|
      draw_character(data[0], data[1], x + i * 85, y)
    end
  end
  #--------------------------------------------------------------------------#
  # Draw new save info                                                       #
  #--------------------------------------------------------------------------#
  def csca_draw_info(x, y, width, align)
    header = DataManager.load_header(@file_index)
    return unless header
    draw_text(x, y, width, line_height, "Playtime: " + header[:playtime_s], 2)
    header[:csca].each_with_index do |data, i|
    currency = data[1]
    unit = $imported["CSCA-CurrencySystem"] ? currency[:currency_unit] : Vocab::currency_unit
    @cscagoldsplit = $imported["CSCA-CurrencySystem"] ? data[1][:amount] : data[1]
    million = @cscagoldsplit / 1000 / 1000
    thousand = @cscagoldsplit / 1000 % 1000
    hundred = @cscagoldsplit % 1000
    change_color(currency[:color]) if $imported["CSCA-CurrencySystem"]
    if million >= 1
      draw_text(x, y - line_height, width, line_height, sprintf(unit + ": %d,%03d,%03d", million, thousand, hundred), 2)
    elsif million == 0 && thousand >= 1
      draw_text(x, y - line_height, width, line_height, sprintf(unit + ": %d,%03d", thousand, hundred), 2)
    else
      draw_text(x, y - line_height, width, line_height, sprintf(unit + ": %d", hundred), 2)
    end
    change_color(normal_color)
    draw_text(x, y - line_height * 2, width, line_height, "Save Count: " + data[3].to_s, 2)
    csca_map_string = data[4]
    csca_map_string.scan(/<CSCA .*>/).each { |csca_map_name|
      @csca_map_name = csca_map_name[6,csca_map_name.length-7]}
      draw_text(x,y,width, line_height, "Location: " + @csca_map_name.to_s)
    end
  end
  #--------------------------------------------------------------------------#
  # Draw new save info; Small text size                                      #
  #--------------------------------------------------------------------------#
  def csca_draw_small_info(x, y)
    header = DataManager.load_header(@file_index)
    return unless header
    header[:csca].each_with_index do |data, i|
      draw_text(x + i * 85, y, contents.width, line_height, Vocab.level_a + " " + data[0].to_s)
      draw_text(x - 30 + i * 85, y + 25, contents.width, line_height, data[2].to_s)
      if data[5] && CSCA::NGP::ENABLE_NGP
        draw_text(x - 20, y - 30, contents.width, line_height, "New Game +", 1)
      end
    end
  end
end
#==============================================================================
# ** Scene_File
#------------------------------------------------------------------------------
# Changes amount of visible files at one time.
# Overwrites: visible_max
#==============================================================================
class Scene_File < Scene_MenuBase
  #--------------------------------------------------------------------------#
  # Overwrite Method; Visible Save Files                                     #
  #--------------------------------------------------------------------------#
  def visible_max
    return 3
  end
end
#==============================================================================
# ** Game_System
#------------------------------------------------------------------------------
# Provides easy ways to clear inventory/self switches for a New Game Plus.
#==============================================================================
class Game_System
  #--------------------------------------------------------------------------#
  # Clear all Self Switches                                                  #
  #--------------------------------------------------------------------------#
  def csca_clear_self_switches
    map_amount = CSCA::NGP::MAP_AMOUNT
    event_amount = $game_map.events.size
    for i in 1..map_amount
      map_id = i
      for i in 0..event_amount
        event_id = i
        switches = ["A","B","C","D"]
        for i in switches
          key = [map_id, event_id, i]
          $game_self_switches[key] = false
        end
      end
    end
  end
  #--------------------------------------------------------------------------#
  # Clear items                                                              #
  #--------------------------------------------------------------------------#
  def csca_clear_items
    for i in 0..$data_items.size
      $game_party.gain_item($data_items[i], -99)
    end
  end
  #--------------------------------------------------------------------------#
  # Clear Weapons                                                            #
  #--------------------------------------------------------------------------#
  def csca_clear_weapons
    for i in 0..$data_weapons.size
      $game_party.gain_item($data_weapons[i], -99, 1)
    end
  end
  #--------------------------------------------------------------------------#
  # Clear Armors                                                             #
  #--------------------------------------------------------------------------#
  def csca_clear_armors
    for i in 0..$data_armors.size
      $game_party.gain_item($data_armors[i], -99, 1)
    end
  end
end