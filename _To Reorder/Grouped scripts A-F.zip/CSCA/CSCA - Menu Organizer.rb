=begin
CSCA Menu Organizer
version: 1.0.6 (Released: July 20, 2013)
Created by: Casper Gaming (http://www.caspergaming.com/)

This version supports:
CSCA Encyclopedia w/ Bestiary (all versions)
CSCA Dungeon Tools (v1.3b +)
CSCA Treasure Maps (all versions)
CSCA Achievements (all versions)
CSCA SideQuests (all versions)
CSCA Professions (all versions)
CSCA Quest System (all versions)

COMPATIBILITY
Note: If you are using a version of any CSCA script that adds itself to the menu,
you'll need to turn that option off to be compatible with this script.

Should be compatible with almost any script. Compatible only for VXAce.
IMPORTANT: ALL CSCA Scripts should be compatible with each other unless
otherwise noted.

FFEATURES
This script will allow you to easily add any CSCA Scripts to your main menu. It
also allows you to change the default commands easily, as well as add an option
to open the debug menu from the main menu during playtest mode.

SETUP
Setup options below.

CREDIT:
Free to use in noncommercial games if credit is given to:
Casper Gaming (http://www.caspergaming.com/)

To use in a commercial game, please purchase a license here:
http://www.caspergaming.com/licenses.html

TERMS:
http://www.caspergaming.com/terms_of_use.html
=end
module CSCA
  module MENU
    
    #Main Menu Options - changing these to true may increase compatibility with
    #custom menu scripts
    MAIN_COMMANDS = true     # Add item, skill, equip, status to the menu?
    FORMATION_COMMAND = true # Add the formation command to the menu?
    ORIGINAL_COMMANDS = true # Add custom script commands to the menu?
    SAVE_COMMAND = true      # Add the save command to the menu?
    END_COMMAND = true       # Add the game end command to the menu?
    
    # Leaving these as true may increase compatibility with custom menu scripts.
    # These only have an effect if MAIN_COMMANDS above is set to true.
    ITEM_ENABLED = true     # Add Item to the menu?
    SKILL_ENABLED = true    # Add Skill to the menu?
    EQUIP_ENABLED = true    # Add Equip to the menu?
    STATUS_ENABLED = true   # Add Status to the menu?
    
    DEBUG = true # Add debug option to menu in playtest mode?
    
    #Setting this to 0 may increase compatibility with custom menu scripts.
    LINES = 10  #Amount of commands to show before scrolling to show.
               #If set to 0, the window will show all commands without scrolling.
    
    
    #CSCA Script Setup
    
    #The following commands require CSCA Encyclopedia
    #http://www.rpgmakervxace.net/topic/2775-csca-encyclopedia-w-bestiary-v20/
    ENCYCLOPEDIA = "Encyclopedia"
    INCLUDE_ENC = true # Include the CSCA Encyclopedia in the menu?
    ENC_SWITCH = 0 # Switch that shows/hides Encyclopedia in menu. 0 = always show
    
    #The following commands require CSCA Dungeon Tools
    #http://www.rpgmakervxace.net/topic/2275-csca-dungeon-tools/
    DUNGEON_TOOLS = "Dungeon Tools"
    INCLUDE_DUN = true # Include the CSCA Dungeon Tools in the menu?
    DT_SWITCH = 0 # Switch that shows/hides Dungeon Tools in menu. 0 = always show
    
    #The following commands require CSCA Treasure Maps
    #http://www.rpgmakervxace.net/topic/5388-csca-treasure-maps/
    TREASURE_MAPS = "Treasure Maps"
    INCLUDE_MAP = true # Include the CSCA Treasure Maps in the menu?
    MAP_SWITCH = 0 # Switch that shows/hides Treasure Maps in menu. 0 = always show
    
    #The following commands require CSCA Achievements
    #http://www.rpgmakervxace.net/topic/5554-csca-achievements/
    ACHIEVEMENTS = "Achievements"
    INCLUDE_ACH = true # Include the CSCA Achievements in the menu?
    ACH_SWITCH = 0 # Switch that shows/hides Achievements in menu. 0 = always show
    
    # The following commands require CSCA SideQuests
    #http://www.rpgmakervxace.net/topic/7837-csca-sidequestbulletin-board-system/
    SIDEQUESTS = "Sidequests"
    INCLUDE_SQ = true # Include CSCA SideQuests in the menu?
    SQ_SWITCH = 1 # Switch that shows/hides Sidequess in menu. 0 = always show
    
    # The following commands require CSCA Professions
    #http://www.rpgmakervxace.net/topic/14734-csca-professions/
    PROFESSIONS = "Professions"
    INCLUDE_PRF = true # Include CSCA Professions in the menu?
    PRF_SWITCH = 0 # Switch that shows/hides Professions in menu. 0 = always show
    
    # The following commands require CSCA Quest System
    #coming soon
    QUESTS = "Quests"
    INCLUDE_QSY = true # Include CSCA Quest System in the menu?
    QSY_SWITCH = 0 # Switch that shows/hides Quest System in menu. 0 = always show
    
    # NOTE:
    #
    # This script will be updated consistently to include future CSCA scripts
    # that can go in the menu, however support for all custom scripts is not
    # planned. Yanfly already has a script for that, if that's what you want:
    # http://yanflychannel.wordpress.com/rmvxa/menu-scripts/ace-menu-engine/
    #
    # This script is just meant for those who just want to easily add CSCA
    # Scripts to the menu without all of the other features.
    
  end
end
$imported = {} if $imported.nil?
$imported["CSCA-MenuOrganizer"] = true
#==============================================================================
# ** Scene_Menu
#------------------------------------------------------------------------------
# Adds commands for CSCA Scripts.
#==============================================================================
class Scene_Menu < Scene_MenuBase
  #--------------------------------------------------------------------------
  # Alias Method; create command window
  #--------------------------------------------------------------------------
  alias :csca_create_command_window :create_command_window
  def create_command_window
    csca_create_command_window
    @command_window.set_handler(:cscadebug, method(:csca_debug_select)) if $TEST && CSCA::MENU::DEBUG
    @command_window.set_handler(:encyclopedia, method(:csca_encyclopedia_select))  if $imported["CSCA-Encyclopedia"] &&
    CSCA::MENU::INCLUDE_ENC
    @command_window.set_handler(:dungeontools, method(:csca_dt_select)) if $imported["CSCA-DungeonTools"] &&
    CSCA::MENU::INCLUDE_DUN
    @command_window.set_handler(:treasuremaps, method(:csca_tmap_select)) if $imported["CSCA-TreasureMaps"] &&
    CSCA::MENU::INCLUDE_MAP
    @command_window.set_handler(:achievements, method(:csca_ach_select)) if $imported["CSCA-Achievements"] &&
    CSCA::MENU::INCLUDE_ACH
    @command_window.set_handler(:sidequests, method(:csca_sq_select)) if $imported["CSCA-SideQuests"] &&
    CSCA::MENU::INCLUDE_SQ
    @command_window.set_handler(:professions, method(:csca_prf_select)) if $imported["CSCA-Professions"] &&
    CSCA::MENU::INCLUDE_PRF
    @command_window.set_handler(:quests, method(:csca_qsys_select)) if $imported["CSCA-QuestSystem"] &&
    CSCA::MENU::INCLUDE_QSY
  end
  #--------------------------------------------------------------------------
  # Processing when Encyclopedia is selected
  #--------------------------------------------------------------------------
  def csca_encyclopedia_select
    SceneManager.call(Scene_CSCA_Encyclopedia)
  end
  #--------------------------------------------------------------------------
  # Processing when Dungeon Tools is selected
  #--------------------------------------------------------------------------
  def csca_dt_select
    SceneManager.call(CSCA_Scene_DungeonToolSelect)
  end
  #--------------------------------------------------------------------------
  # Processing when Treasure Maps is selected
  #--------------------------------------------------------------------------
  def csca_tmap_select
    SceneManager.call(Scene_CSCA_TreasureMaps)
  end
  #--------------------------------------------------------------------------
  # Processing when Debug is selected
  #--------------------------------------------------------------------------
  def csca_debug_select
    SceneManager.call(Scene_Debug)
  end
  #--------------------------------------------------------------------------
  # Processing when Achievements is selected
  #--------------------------------------------------------------------------
  def csca_ach_select
    SceneManager.call(CSCA_Scene_Achievements)
  end
  #--------------------------------------------------------------------------
  # Processing when Side Quests is selected
  #--------------------------------------------------------------------------
  def csca_sq_select
    SceneManager.call(CSCA_Scene_SidequestMenu)
  end
  #--------------------------------------------------------------------------
  # Processing when Professions is selected
  #--------------------------------------------------------------------------
  def csca_prf_select
    SceneManager.call(CSCA_Scene_Professions)
  end
  #--------------------------------------------------------------------------
  # Processing when Quest System is selected
  #--------------------------------------------------------------------------
  def csca_qsys_select
    SceneManager.call(CSCA_Scene_Quest)
  end
end
#==============================================================================
# ** Window_MenuCommand
#------------------------------------------------------------------------------
# Displays commands for CSCA Scripts.
#==============================================================================
class Window_MenuCommand < Window_Command
  #--------------------------------------------------------------------------
  # Alias Method; make command list
  #--------------------------------------------------------------------------
  alias :csca_make_command_list :make_command_list
  def make_command_list
    if CSCA::MENU::MAIN_COMMANDS && CSCA::MENU::FORMATION_COMMAND &&
      CSCA::MENU::ORIGINAL_COMMANDS && CSCA::MENU::SAVE_COMMAND &&
      CSCA::MENU::END_COMMAND
      csca_make_command_list
    else
      add_main_commands if CSCA::MENU::MAIN_COMMANDS
      add_formation_command if CSCA::MENU::FORMATION_COMMAND
      add_original_commands if CSCA::MENU::ORIGINAL_COMMANDS
      add_save_command if CSCA::MENU::SAVE_COMMAND
      add_game_end_command if CSCA::MENU::END_COMMAND
    end
  end
  #--------------------------------------------------------------------------
  # Alias Method; add main commands
  #--------------------------------------------------------------------------
  alias :csca_main_commands :add_main_commands
  def add_main_commands
    if CSCA::MENU::ITEM_ENABLED && CSCA::MENU::SKILL_ENABLED && CSCA::MENU::EQUIP_ENABLED &&
      CSCA::MENU::STATUS_ENABLED
      csca_main_commands
    else
      add_command(Vocab::item,   :item,   main_commands_enabled) if CSCA::MENU::ITEM_ENABLED
      add_command(Vocab::skill,  :skill,  main_commands_enabled) if CSCA::MENU::SKILL_ENABLED
      add_command(Vocab::equip,  :equip,  main_commands_enabled) if CSCA::MENU::EQUIP_ENABLED
      add_command(Vocab::status, :status, main_commands_enabled) if CSCA::MENU::STATUS_ENABLED
    end
  end
  #--------------------------------------------------------------------------
  # Alias Method; add original commands
  #--------------------------------------------------------------------------
  alias :csca_commands :add_original_commands
  def add_original_commands
    add_command("Debug", :cscadebug) if $TEST && CSCA::MENU::DEBUG
    add_command(CSCA::MENU::ENCYCLOPEDIA, :encyclopedia) if $imported["CSCA-Encyclopedia"] &&
      CSCA::MENU::INCLUDE_ENC && csca_check_switch(CSCA::MENU::ENC_SWITCH)
    add_command(CSCA::MENU::DUNGEON_TOOLS, :dungeontools, csca_dt_enabled) if $imported["CSCA-DungeonTools"] &&
      CSCA::MENU::INCLUDE_DUN && csca_check_switch(CSCA::MENU::DT_SWITCH)
    add_command(CSCA::MENU::TREASURE_MAPS, :treasuremaps) if $imported["CSCA-TreasureMaps"] &&
      CSCA::MENU::INCLUDE_MAP && csca_check_switch(CSCA::MENU::MAP_SWITCH)
    add_command(CSCA::MENU::ACHIEVEMENTS, :achievements) if $imported["CSCA-Achievements"] &&
      CSCA::MENU::INCLUDE_ACH && csca_check_switch(CSCA::MENU::ACH_SWITCH)
    add_command(CSCA::MENU::SIDEQUESTS, :sidequests) if $imported["CSCA-SideQuests"] &&
      CSCA::MENU::INCLUDE_SQ && csca_check_switch(CSCA::MENU::SQ_SWITCH)
    add_command(CSCA::MENU::PROFESSIONS, :professions) if $imported["CSCA-Professions"] &&
      CSCA::MENU::INCLUDE_PRF && csca_check_switch(CSCA::MENU::PRF_SWITCH)
    add_command(CSCA::MENU::QUESTS, :quests) if $imported["CSCA-QuestSystem"] &&
      CSCA::MENU::INCLUDE_QSY && csca_check_switch(CSCA::MENU::QSY_SWITCH)
    csca_commands
  end
  #--------------------------------------------------------------------------
  # Alias Method; visible line number
  #--------------------------------------------------------------------------
  alias :csca_line_number :visible_line_number
  def visible_line_number
    if CSCA::MENU::LINES > 0
      CSCA::MENU::LINES
    else
      csca_line_number
    end
  end
  #--------------------------------------------------------------------------
  # Check if command's switch is on (or 0)
  #--------------------------------------------------------------------------
  def csca_check_switch(switch_id)
    switch_id == 0 ? true : $game_switches[switch_id]
  end
  #--------------------------------------------------------------------------
  # check if Dungeon Tools are enabled
  #--------------------------------------------------------------------------
  def csca_dt_enabled
    $game_switches[CSCA_DUNGEON_TOOLS::ON_OFF] && csca_check_tools
  end
  #--------------------------------------------------------------------------
  # Check if player has at least one Dungeon Tool
  #--------------------------------------------------------------------------
  def csca_check_tools
    return $game_switches[CSCA_DUNGEON_TOOLS::ARROW] ||
    $game_switches[CSCA_DUNGEON_TOOLS::BOMB] ||
    $game_switches[CSCA_DUNGEON_TOOLS::HOOKSHOT] ||
    $game_switches[CSCA_DUNGEON_TOOLS::BOOMERANG] ||
    $game_switches[CSCA_DUNGEON_TOOLS::RESET]
  end
end