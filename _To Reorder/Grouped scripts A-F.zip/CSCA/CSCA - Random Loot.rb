=begin
CSCA Random Loot
version: 1.0.1
Created by: Casper Gaming (http://www.caspergaming.com/)

Compatibility:
Made for RPGVXAce
IMPORTANT: ALL CSCA Scripts should be compatible with each other unless
otherwise noted.
Requires CSCA Core Script

FFEATURES
Easily generate random loot in treasure chests.

SETUP
Set up required. Instructions below.
================================================================================
UPDATES
version 1.0.1
- Added support for CSCA Currency System
================================================================================
Requires CSCA Core Script to work properly, get it here:
http://www.rpgmakervxace.net/topic/6879-csca-core-script/

CREDIT:
Free to use in noncommercial games if credit is given to:
Casper Gaming (http://www.caspergaming.com/)

To use in a commercial game, please purchase a license here:
http://www.caspergaming.com/licenses.html

TERMS:
http://www.caspergaming.com/terms_of_use.html
=end
module CSCA
  module RANDOM_LOOT
    LOOT = [] # Don't Touch
#--------------------------------Script Calls----------------------------------#
# Use the following script call to generate random loot:
# csca_rl(loot_level)
# where loot_level is the quality of the loot
# Example: csca_rl(1)
#
# You can also include the optional multiplier and operation specifications
# csca_rl(loot_level, multiplier, operation)
# the multiplier is a value used to calculate a modified amount of treasure.
# the operation is a symbol used to specify addition, subtraction, division, etc.
# Example: csca_rl(1, 5, :a)
#
# Valid operation values are:
# :m = multiplication
# :d = division
# :a = addition
# :s = subtraction
# :mod = mod. division
#------------------------------End Script Calls--------------------------------#
    #LOOT.push [CSCA_Item.new(amount, id, type), level, rarity]
    # amount is the amount of the item.
    # id is the id of the item (set 0 if using gold type
    # The type can be either:
    # :item = amount of $data_items[id]
    # :weapon = amount of $data_weapons[id]
    # :armor = amount of $data_armors[id]
    # * :gold = amount of gold, ignores id value
    #
    # * if using CSCA Currency System, use the ID value as the currency symbol.
    #
    # level is the quality of the loot. When generating treasure, only loot with
    # the same level will be included.
    #
    # the rarity determines how frequently an item will come up. The lower the
    # rarity, the less common an item will be chosen.
    LOOT.push [CSCA_Item.new(1, 1, :item), 1, 1]
    LOOT.push [CSCA_Item.new(500, 0, :gold), 1, 2]
    LOOT.push [CSCA_Item.new(1, 1, :weapon), 2, 2]
    LOOT.push [CSCA_Item.new(5000, 0, :gold), 2, 1]
    
    MESSAGE = 'Found \c[4]%dx \i[%d]%s\c[0]!' # Message text shown for items.
    GOLD_MESSAGE = 'Found \c[17]%d Gold\c[0]!' # Message text shown for gold.
    
    #Recommended Gold Message ONLY if using CSCA Currency System
    #GOLD_MESSAGE = 'Found \i[%d]%d %s!' # Message text shown for gold.
  end
end
#----------------------------------End Setup----------------------------------#
$imported = {} if $imported.nil?
$imported["CSCA-RandomLoot"] = true
msgbox('Missing Script: CSCA Core Script! CSCA Random Loot requires this
script to work properly.') if !$imported["CSCA-Core"]
#==============================================================================
# ** Game_Interpreter
#------------------------------------------------------------------------------
# Processes csca_rl script call
#==============================================================================
class Game_Interpreter
  #--------------------------------------------------------------------------#
  # Handle random loot script call                                           #
  #--------------------------------------------------------------------------#
  def csca_rl(level, multiplier = 1, operation = :m)
    loot_array = $csca.get_random_loot_array(level)
    amount = $csca.random_loot_amount(loot_array, multiplier, operation)
    loot = $csca.determine_loot_object(loot_array)
    $game_message.position = 2
    if loot_array[0].type == :gold
      if $imported["CSCA-CurrencySystem"]
        $game_party.gain_currency(loot, amount)
        $game_message.add(sprintf(CSCA::RANDOM_LOOT::GOLD_MESSAGE, loot[:icon], amount, loot[:currency_unit]))
      else
        $game_party.gain_gold(amount)
        $game_message.add(sprintf(CSCA::RANDOM_LOOT::GOLD_MESSAGE, amount, loot))
      end
    else
      $game_party.gain_item(loot, amount)
      $game_message.add(sprintf(CSCA::RANDOM_LOOT::MESSAGE, amount, loot.icon_index, loot.name))
    end
    wait_for_message
  end
end
#==============================================================================
# ** CSCA_Core
#------------------------------------------------------------------------------
# Handles Random Loot Arrays
#==============================================================================
class CSCA_Core
  #--------------------------------------------------------------------------#
  # make random loot array                                                   #
  #--------------------------------------------------------------------------#
  def get_random_loot_array(level)
    loot_array = []
    CSCA::RANDOM_LOOT::LOOT.each do |loot|
      next if loot.nil? || loot[0].amount == 0
      loot_array.push loot if loot[1] == level
    end
    return determine_rl_item(loot_array)
  end
  #--------------------------------------------------------------------------#
  # Determine item array                                                     #
  #--------------------------------------------------------------------------#
  def determine_rl_item(loot_array)
    total_chance = item_chance = 0
    loot_array.each do |loot|
      total_chance += loot[2]
    end
    item_weight = rand(total_chance) + 1
    loot_array.each do |loot|
      item_chance += loot[2]
      if item_chance >= item_weight
        return loot
      end
    end
  end
  #--------------------------------------------------------------------------#
  # Determine amount                                                         #
  #--------------------------------------------------------------------------#
  def random_loot_amount(loot, mult, op)
    return case op
    when :m; loot[0].amount * mult
    when :d; loot[0].amount / mult
    when :a; loot[0].amount + mult
    when :s; loot[0].amount - mult
    when :mod; loot[0].amount % mult
    else loot[0].amount
    end
  end
  #--------------------------------------------------------------------------#
  # Determine actual item                                                    #
  #--------------------------------------------------------------------------#
  def determine_loot_object(array)
    item = array[0]
    id = item.id
    return case item.type
    when :item; $data_items[id]
    when :weapon; $data_weapons[id]
    when :armor; $data_armors[id]
    when :gold; $imported["CSCA-CurrencySystem"] ? $game_party.get_csca_cs_currency(id) : Vocab::currency_unit
    end
  end
end