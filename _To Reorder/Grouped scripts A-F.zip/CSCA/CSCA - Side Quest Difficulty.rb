=begin
CSCA Sidequests Difficulty
version: 1.0.0 (Released: October 19, 2012)
Created by: Casper Gaming (http://www.caspergaming.com/)

Compatibility:
Made for RPGVXAce
IMPORTANT: ALL CSCA Scripts should be compatible with each other unless
otherwise noted.
Requires CSCA SideQuests

FFEATURES:
Adds a difficulty window to each sidequest.

SETUP
Setup below required. Intructions below.

CREDIT:
Free to use in noncommercial games if credit is given to:
Casper Gaming (http://www.caspergaming.com/)

To use in a commercial game, please purchase a license here:
http://www.caspergaming.com/licenses.html

TERMS:
http://www.caspergaming.com/terms_of_use.html
=end
module CSCA
  module SIDEQUEST
    DIFFICULTY = "Difficulty: " # Difficulty text
    
    #SIDEQUESTS[x]["difficulty"] = "Difficulty"
    SIDEQUESTS[0]["difficulty"] = "Easy"
    SIDEQUESTS[1]["difficulty"] = "Medium"
    SIDEQUESTS[2]["difficulty"] = "Hard"
  end
end
$imported = {} if $imported.nil?
$imported["SideQuests-Difficulty"] = true
msgbox('Missing Script: CSCA Sidequests Script! Sidequest Difficulty requires this
script to work properly.') if !$imported["CSCA-SideQuests"]
#==============================================================================
# ** CSCA_Scene_Sidequest
#------------------------------------------------------------------------------
# Creates difficulty window.
#Aliases: create_addon_windows, set_help_windows
#Overwrites: select_window_height
#==============================================================================
class CSCA_Scene_Sidequest < Scene_MenuBase
  #--------------------------------------------------------------------------#
  # Alias Method; Start Processing                                           #
  #--------------------------------------------------------------------------#
  alias :csca_sqd_addon :create_addon_windows
  def create_addon_windows
    create_difficulty_window
    csca_sqd_addon
  end
  #--------------------------------------------------------------------------#
  # Create difficulty window                                                 #
  #--------------------------------------------------------------------------#
  def create_difficulty_window
    @difficulty_window = CSCA_Window_SidequestDifficulty.new(0,
      @head_window.height+select_window_height,Graphics.width/3,@head_window.height)
    @difficulty_window.viewport = @viewport
  end
  #--------------------------------------------------------------------------#
  # Overwrite method; Select Window Height                                   #
  #--------------------------------------------------------------------------#
  def select_window_height
    return Graphics.height-@head_window.height*2
  end
  #--------------------------------------------------------------------------#
  # Alias Method; Sets help windows                                          #
  #--------------------------------------------------------------------------#
  alias :csca_sqd_help_window :set_help_windows
  def set_help_windows
    csca_sqd_help_window
    @select_window.difficulty_window = @difficulty_window
  end
end
#==============================================================================
# ** CSCA_Window_SidequestDifficulty
#------------------------------------------------------------------------------
# Handles the difficulty window.
#==============================================================================
class CSCA_Window_SidequestDifficulty < Window_Base
  #--------------------------------------------------------------------------#
  # Object Initialization                                                    #
  #--------------------------------------------------------------------------#
  def initialize(x, y, width, height)
    super(x, y, width, height)
    set_item(0)
  end
  #--------------------------------------------------------------------------#
  # Set Item                                                                 #
  #--------------------------------------------------------------------------#
  def set_item(index)
    contents.clear
    text = CSCA::SIDEQUEST::DIFFICULTY
    difficulty = CSCA::SIDEQUEST::SIDEQUESTS[index]["difficulty"]
    draw_text(0,0,contents.width,line_height,text+difficulty)
  end
end
#==============================================================================
# ** CSCA_Window_SidequestSelect
#------------------------------------------------------------------------------
# Additional methods for updating difficulty window.
#Aliases: update_help
#==============================================================================
class CSCA_Window_SidequestSelect < Window_Selectable
  attr_accessor :difficulty_window
  #--------------------------------------------------------------------------#
  # Alias Method; Update Help Window                                         #
  #--------------------------------------------------------------------------#
  alias :csca_sqd_update :update_help
  def update_help
    csca_sqd_update
    @difficulty_window.set_item(index) if @difficulty_window
  end
end