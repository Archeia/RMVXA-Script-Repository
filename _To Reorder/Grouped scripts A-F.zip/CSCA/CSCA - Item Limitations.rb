=begin
CSCA Item Limitations
version: 1.0 (Released: June 18, 2012)
Created by: Casper Gaming (http://www.caspergaming.com/)

Compatibility:
Made for RPGVXAce
IMPORTANT: ALL CSCA Scripts should be compatible with each other unless
otherwise noted.

FFEATURES:
This script will allow you to restrict certain items and skills to certain maps,
such as an escape skill for dungeons or a tent item for the overworld.

SETUP
Setup required. Instructions below.
#=======================================================================#
# Notetags                                                              #
#=======================================================================#
To limit an item/skill, this script looks for notetags in the item/skills notebox.

To limit an item/skill to the overworld, use this notetag:
<cscalimited: overworld>

To limit an item/skill to dungeons, use this notetag:
<cscalimited: dungeon>

To limit an item/skill to towns, use this notetag:
<cscalimited: town>

To limit an item/skill to special maps, use this notetag:
<cscalimited: special>

To limit an item/skill to an "other" map, use this notetag:
<cscalimited: other>
#=======================================================================#
# End Notetags                                                          #
#=======================================================================#

CREDIT:
Free to use in noncommercial games if credit is given to:
Casper Gaming (http://www.caspergaming.com/)

To use in a commercial game, please purchase a license here:
http://www.caspergaming.com/licenses.html

TERMS:
http://www.caspergaming.com/terms_of_use.html
=end
module CSCA # Don't touch
  module LIMIT # Don't touch
    #=======================================================================#
    # Declaring arrays, do not touch                                        #
    #=======================================================================#
    ITEM_OVERWORLD_MAPS = [] # Don't touch
    SKILL_OVERWORLD_MAPS = []# Don't touch
    ITEM_DUNGEON_MAPS = []   # Don't touch
    SKILL_DUNGEON_MAPS = []  # Don't touch
    ITEM_TOWN_MAPS = []      # Don't touch
    SKILL_TOWN_MAPS = []     # Don't touch
    ITEM_SPECIAL_MAPS = []   # Don't touch
    SKILL_SPECIAL_MAPS = []  # Don't touch
    ITEM_OTHER_MAPS = []     # Don't touch
    SKILL_OTHER_MAPS = []    # Don't touch
    #=======================================================================#
    # Setup Start. Remember to separate each number with a comma!           #
    #=======================================================================#
    ITEM_OVERWORLD_MAPS[0] = [1,2] # Maps that allow overworld items to be used.
    SKILL_OVERWORLD_MAPS[0] = [1,2]# Maps that allow overworld skills to be used.
    ITEM_DUNGEON_MAPS[0] = [3,4]   # Mapsthat allow dungeon items to be used.
    SKILL_DUNGEON_MAPS[0] = [3,4]  # Maps that allow dungeon skills to be used.
    ITEM_TOWN_MAPS[0] = [3,4]      # Maps that allow town items to be used.
    SKILL_TOWN_MAPS[0] = [3,4]     # Maps that allow town skills to be used.
    ITEM_SPECIAL_MAPS[0] = [2,3,4] # Maps that allow special items to be used.
    SKILL_SPECIAL_MAPS[0] = [2,3,4]# Maps that allow special skills to be used.
    ITEM_OTHER_MAPS[0] = [2,3,4]   # Maps that allow "other" items to be used.
    SKILL_OTHER_MAPS[0] = [2,3,4]  # Maps that allow "other" skills to be used.
    #=======================================================================#
    # End setup, don't touch anything below unless you know what you are    #
    # doing.                                                                #
    #=======================================================================#
  end
end

$imported = {} if $imported.nil?
$imported["CSCA-ItemLimitations"] = true

class Game_BattlerBase
  #=======================================================================#
  # alias method.                                                         #
  #=======================================================================#
  alias csca_item_limit_conditions item_conditions_met?
  def item_conditions_met?(item)
    csca_usable?(item) && csca_item_limit_conditions(item)
  end
  #=======================================================================#
  # alias method.                                                         #
  #=======================================================================#
  alias csca_skill_limit_conditions skill_conditions_met?
  def skill_conditions_met?(skill)
    csca_usable?(skill) && csca_skill_limit_conditions(skill)
  end
  #=======================================================================#
  # check limitations if limit notetag exists                             #
  #=======================================================================#
  def csca_usable?(item)
    return csca_check_limitations(item) if item.csca_limited? && !$game_party.in_battle 
    return true
  end
  #=======================================================================#
  # compare map id with limit notetag map ID's                            #
  #=======================================================================#
  def csca_check_limitations(item)
    limitation = item.csca_limitation_name
    case limitation.downcase
    when "overworld"
      item.is_a?(RPG::Item) ? maplim = CSCA::LIMIT::ITEM_OVERWORLD_MAPS : maplim = CSCA::LIMIT::SKILL_OVERWORLD_MAPS
    when "dungeon"
      item.is_a?(RPG::Item) ? maplim = CSCA::LIMIT::ITEM_DUNGEON_MAPS : maplim = CSCA::LIMIT::SKILL_DUNGEON_MAPS
    when "town"
      item.is_a?(RPG::Item) ? maplim = CSCA::LIMIT::ITEM_TOWN_MAPS : maplim = CSCA::LIMIT::SKILL_TOWN_MAPS
    when "special"
      item.is_a?(RPG::Item) ? maplim = CSCA::LIMIT::ITEM_SPECIAL_MAPS : maplim = CSCA::LIMIT::SKILL_SPECIAL_MAPS
    else
      item.is_a?(RPG::Item) ? maplim = CSCA::LIMIT::ITEM_OTHER_MAPS : maplim = CSCA::LIMIT::SKILL_OTHER_MAPS
    end
    for i in 0...maplim[0].size
      return true if $game_map.map_id == maplim[0][i]
    end
    return false
  end
end # Game_BattlerBase
class RPG::UsableItem < RPG::BaseItem
  #=======================================================================#
  # check if limit notetag exists                                         #
  #=======================================================================#
  def csca_limited?
    @note =~ /<cscalimited: (.*)>/i
  end
  #=======================================================================#
  # get type of limit                                                     #
  #=======================================================================#
  def csca_limitation_name
    @note =~ /<cscalimited: (.*)>/i
    return $1.to_s
  end
end # RPG::UsableItem