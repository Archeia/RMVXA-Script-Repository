=begin
CSCA Quest System
version: 1.0.0 (Released: July 20, 2013)
Created by: Casper Gaming (http://www.caspergaming.com/)
================================================================================
Compatibility:
Made for RPGVXAce
IMPORTANT: ALL CSCA Scripts should be compatible with each other unless
otherwise noted.

Requires CSCA Core Script v1.0.8+
LINK: http://www.rpgmakervxace.net/topic/6879-csca-core-script/

Optional toast windows require CSCA Toast Manager(v1.1.1+)
LINK: http://www.rpgmakervxace.net/topic/13960-csca-toast-manager/

To easily add a menu command for the quest system, please get the CSCA Menu Organizer(v1.0.6+)
LINK: http://www.rpgmakervxace.net/topic/4742-csca-menu-organizer/
================================================================================
FFEATURES
Creates a powerful but easy to use quest system in your game.
- Separate quest lists show only quests in progress, completed, or all quests!
- Each quest list can be sorted by alphabetical order, difficulty, or location!
- Unlimited rewards for each quest, automatically earned (or not) on quest completion!
- Unlimited amount of objectives per quest.
- Easy to manage quests and use quest data in conditional branches.
================================================================================
SETUP
Set up required. Instructions below.
================================================================================
CREDIT:
Free to use in noncommercial games if credit is given to:
Casper Gaming (http://www.caspergaming.com/)

To use in a commercial game, please purchase a license here:
http://www.caspergaming.com/licenses.html
================================================================================
TERMS:
http://www.caspergaming.com/terms_of_use.html
================================================================================
=end
module CSCA
  module QUESTS
    DESCRIPTION, STEP, QUEST, REWARD = [], [], [], []
#==============================================================================
# ** Begin Script Instructions (Setup farther down)
#==============================================================================
#==============================================================================
# ** Script Calls
#==============================================================================
# IMPORTANT! Refer to quests by their symbol in your script calls!
#------------------------------------------------------------------------------
# SceneManager.call(CSCA_Scene_Quest)
#
# Opens the quest scene.
#------------------------------------------------------------------------------
# start_quest(symbol)
#
# Starts the quest referred to by the symbol parameter.
#------------------------------------------------------------------------------
# advance_quest(symbol)
#
# Advances the quest referred to by the symbol parameter's progress by 1.
#------------------------------------------------------------------------------
# set_quest_progress(symbol, progress)
#
# Sets the quest referred to by the symbol parameter's progress to the progress
# parameter.
#------------------------------------------------------------------------------
# complete_quest(symbol)
#
# Sets the quest referred to by the symbol parameter as complete.
#------------------------------------------------------------------------------
# quest_complete?(symbol)
#
# Returns true if the quest referred to by the symbol parameter is completed,
# else it returns false. For use in conditional branches.
#------------------------------------------------------------------------------
# quest_started?(symbol)
#
# Returns true if the quest referred to by the symbol parameter is started,
# else it returns false. For use in conditional branches.
#------------------------------------------------------------------------------
# quest_progress(symbol)
#
# Returns the progress integer of the quest referred to by the symbol parameter.
# For use in conditional branches.
#==============================================================================
# ** Understanding How Quest Progress is Handled Internally
#==============================================================================
# Quest progress is determined with 3 separate variables. "Started", "Completed",
# and "Progress".
#
# "Started" determines whether or not the quest has been started. "Started" can
# be either true or false. Only "Started" quests will appear in the quest list.
# "Started" is automatically set to true if the "Progress" has been advanced.
#
# "Progress" determines which objective the player is currently on. "Progress"
# starts at 0. A "Progress" of 0 refers to the first value in the STEP array, a
# "Progress" of 1 refers to the second value in the STEP array, etc. If the
# "Progress" value is ever set higher than the amount of objectives in the
# STEP array, the quest's "Completed" variable will be automatically set to true.
#
# "Completed" determines whether or not the quest has been completed. "Completed"
# can be either true or false. Only "Completed" quests will appear in the
# completed quest list. Only non-"Completed" quests will appear in the in progress
# quest list. Both in progress and completed quests appear in the all quest list.
# Quest rewards are automatically earned upon quest completion (can be disabled
# on a per-quest basis).
#==============================================================================
# ** End Script Instructions
#==============================================================================
#==============================================================================
# ** Begin Setup
#==============================================================================
#==============================================================================
# ** Description Setup
#==============================================================================
    #DESCRIPTION[x] = ["Description. Separate multiple", "lines with commas!"]
    DESCRIPTION[0] = ["Annoy the villagers!"]
    DESCRIPTION[1] = ["Example!"]
    DESCRIPTION[2] = ["A legendary quest that will", "test your abilities."]
#==============================================================================
# ** Reward Setup
#==============================================================================
    #REWARD[x] = [amount, id, type]
    # The type can be either:
    # :item = amount of $data_items[id]
    # :weapon = amount of $data_weapons[id]
    # :armor = amount of $data_armors[id]
    # :gold = amount of gold, ignores id value *
    # :exp = amount of exp, ignores id value
    # :string = "Enter a string for the id and amount value" **
    # * If using CSCA Currency System(http://www.rpgmakervxace.net/topic/13153-csca-currency-system/)
    # the ID value for gold will be the currency symbol.
    # ** String rewards are NOT automatically earned upon quest completion.
    REWARD[0] = [100, 0, :gold] # 100 gold.
    REWARD[1] = [5, 1, :item] # 5 of item ID 1.
    REWARD[2] = [1, 2, :weapon] # 1 of weapon ID 2.
    REWARD[3] = [1, 2, :armor] # 1 of armor ID 2.
    REWARD[4] = [1000, 0, :exp] # 1,000 Experience.
    REWARD[5] = ["x1", "Legendary Armor Set", :string] # Custom string. Will appear as "Legendary Armor Set     x1"
    REWARD[6] = ["", "Access to the Collosseum", :string] # Custom string. Will appear as "Access to the Collosseum"
#==============================================================================
# ** Quest Step Setup
#==============================================================================
    #STEP[x] = ["Step 1", "Step 2", "Use \n for a new line"]
    STEP[0] = ["Step 1\nMultiple Line Test", "Step 2", "Multiple Line\nStep 3",
              "Step 4\nis a long\none.","Step 5\nMultiple Lines"]
#==============================================================================
# ** Quest Setup
#==============================================================================
    #QUEST[x] = {
    #:symbol => :annoy_the_villagers, # Symbol used to refer to this quest in script calls.
    #:name => "Annoy the Villagers!", # Name of the quest.
    #:description => DESCRIPTION[0],  # Description for the quest.
    #:location => "Test Town",        # Location the quest is assigned.
    #:questgiver => "Example Man",    # NPC who assigned the quest.
    #:difficulty => "Easy",           # Difficulty of the quest.
    #:steps => STEP[0],               # Objective list for the quest.
    #:rewards => [REWARD[0], REWARD[1]], # Rewards for the quest.
    #:auto_earn_reward => true        # Automatically earn rewards upon quest completion?
    #}
    
    QUEST[0] = {
    :symbol => :annoy_the_villagers,
    :name => "Annoy the Villagers!",
    :description => DESCRIPTION[0],
    :location => "Test Town",
    :questgiver => "Example Man",
    :difficulty => "Easy",
    :steps => STEP[0],
    :rewards => [REWARD[1], REWARD[2], REWARD[3]],
    :auto_earn_reward => true
    }
    
    QUEST[1] = {
    :symbol => :example_quest,
    :name => "Just an example",
    :description => DESCRIPTION[1],
    :location => "Example Location",
    :questgiver => "Example Woman",
    :difficulty => "Very Easy",
    :steps => STEP[0],
    :rewards => [REWARD[0], REWARD[4]],
    :auto_earn_reward => true
    }
    
    QUEST[2] = {
    :symbol => :sort_test,
    :name => "Sorting Test",
    :description => DESCRIPTION[1],
    :location => "Test Town",
    :questgiver => "Example Man",
    :difficulty => "Hard",
    :steps => STEP[0],
    :rewards => [REWARD[0], REWARD[1], REWARD[2], REWARD[3], REWARD[3]],
    :auto_earn_reward => true
    }
    QUEST[3] = {
    :symbol => :legendary_quest,
    :name => "Legendary Quest",
    :description => DESCRIPTION[2],
    :location => "Legendaria",
    :questgiver => "Legendary Man",
    :difficulty => "Legendary",
    :steps => STEP[0],
    :rewards => [REWARD[5], REWARD[6]],
    :auto_earn_reward => true
    }
#==============================================================================
# ** Misc. Setup
#==============================================================================
    HEADER = "Quests" # Text displayed in the header window of the quest scene.
    CURRENCY_NAME = "Gold" # Currency name. Ignore if using CSCA Currency System.
    DIFFICULTIES = ["Very Easy", "Easy", "Hard", "Legendary"] # Sorting order of difficulties.
    SYSTEM_TEXT_COLOR = 4 # Text color used for data identifier text.
    FADE_AMOUNT = 15 # Amount text fades between objective in objective history.
    QUEST_COMPLETE_SOUND = "Powerup" # Sound played on quest completion. Set to nil if not using. Requires CSCA Toast Manager
    SHOW_COMPLETE_TOAST = true # Show toast window upon quest completion? Requires CSCA Toast Manager
    SHOW_LEVELUP = true # Show level up message if actor levels up from quest exp?
#==============================================================================
# ** End Setup
#==============================================================================
  end
end
$imported ||= {}
$imported["CSCA-QuestSystem"] = true
#==============================================================================
# ** CSCA_Quest
#------------------------------------------------------------------------------
# Stores quest data.
#==============================================================================
class CSCA_Quest
  attr_reader :symbol, :name, :difficulty, :location, :description
  attr_reader :rewards, :steps, :completed, :started, :giver, :progress
  attr_reader :auto_earn_reward
  #--------------------------------------------------------------------------
  # Object Initialization
  #--------------------------------------------------------------------------
  def initialize(quest)
    @symbol = quest[:symbol]
    @name = quest[:name]
    @difficulty = quest[:difficulty]
    @location = quest[:location]
    @giver = quest[:questgiver]
    @description = quest[:description]
    @steps = quest[:steps]
    @auto_earn_reward = quest[:auto_earn_reward]
    @progress = 0
    @completed = false
    @started = false
    setup_rewards(quest)
  end
  #--------------------------------------------------------------------------
  # Initialize Rewards
  #--------------------------------------------------------------------------
  def setup_rewards(quest)
    @rewards = []
    quest[:rewards].each do |reward|
      @rewards.push(CSCA_Item.new(*reward))
    end
  end
  #--------------------------------------------------------------------------
  # Start Quest
  #--------------------------------------------------------------------------
  def start_quest
    @started = true
  end
  #--------------------------------------------------------------------------
  # Advance Quest
  #--------------------------------------------------------------------------
  def advance_quest
    @progress += 1
    @started = true if !@started
    complete_quest if @progress >= @steps.size && !@completed
  end
  #--------------------------------------------------------------------------
  # Complete Quest
  #--------------------------------------------------------------------------
  def complete_quest
    return if @completed
    @completed = true
    $csca.reserve_toast([:quest_complete, self]) if $imported["CSCA-ToastManager"] && CSCA::QUESTS::SHOW_COMPLETE_TOAST
    $csca.quest_info.completed += 1
    $csca.quest_info.list[@symbol] = true
    reward_items if @auto_earn_reward
  end
  #--------------------------------------------------------------------------
  # Give rewards
  #--------------------------------------------------------------------------
  def reward_items
    @rewards.each do |reward|
      case reward.type
      when :item; $game_party.gain_item($data_items[reward.id], reward.amount)
      when :armor; $game_party.gain_item($data_armors[reward.id], reward.amount)
      when :weapon; $game_party.gain_item($data_weapons[reward.id], reward.amount)
      when :gold; $imported["CSCA-CurrencySystem"] ? $game_party.gain_currency(reward.id, reward.amount) : $game_party.gain_gold(reward.amount)
      when :exp
        $game_party.members.each do |actor|
          actor.change_exp(actor.exp + reward.amount, CSCA::QUESTS::SHOW_LEVELUP)
        end
      end
    end
  end
end
#==============================================================================
# ** CSCA_QuestInfo
#------------------------------------------------------------------------------
# Stores overall quest data.
#==============================================================================
class CSCA_QuestInfo
  attr_accessor :completed, :list
  #--------------------------------------------------------------------------
  # Object Initialization
  #--------------------------------------------------------------------------
  def initialize
    @completed = 0
    @list = {}
  end
end
#==============================================================================
# ** CSCA_Core
#------------------------------------------------------------------------------
# Added quest handling.
#==============================================================================
class CSCA_Core
  attr_reader :quest_info
  attr_reader :quests
  #--------------------------------------------------------------------------
  # Alias Method; Object Initialization
  #--------------------------------------------------------------------------
  alias :csca_qsys_initialize :initialize
  def initialize
    csca_qsys_initialize
    initialize_quests
  end
  #--------------------------------------------------------------------------
  # Initialize Quests
  #--------------------------------------------------------------------------
  def initialize_quests
    @quests = []
    @quest_info = CSCA_QuestInfo.new
    CSCA::QUESTS::QUEST.each do |quest|
      @quests.push(CSCA_Quest.new(quest))
    end
  end
  #--------------------------------------------------------------------------
  # Get quest
  #--------------------------------------------------------------------------
  def get_quest(symbol)
    @quests.each do |quest|
      return quest if quest.symbol == symbol
    end
  end
end
#==============================================================================
# ** Game_Interpreter
#------------------------------------------------------------------------------
#  Addition of commands related to managing quests
#==============================================================================
class Game_Interpreter
  #--------------------------------------------------------------------------
  # Start quest
  #--------------------------------------------------------------------------
  def start_quest(symbol)
    $csca.get_quest(symbol).start_quest
  end
  #--------------------------------------------------------------------------
  # Advance quest
  #--------------------------------------------------------------------------
  def advance_quest(symbol)
    $csca.get_quest(symbol).advance_quest
  end
  #--------------------------------------------------------------------------
  # Complete quest
  #--------------------------------------------------------------------------
  def complete_quest(symbol)
    $csca.get_quest(symbol).complete_quest
  end
  #--------------------------------------------------------------------------
  # Set quest progress
  #--------------------------------------------------------------------------
  def set_quest_progress(symbol, progress)
    quest = $csca.get_quest(symbol)
    advance_quest(symbol) until quest.progress == progress
  end
  #--------------------------------------------------------------------------
  # Check if quest is completed
  #--------------------------------------------------------------------------
  def quest_complete?(symbol)
    return $csca.quest_info.list[symbol]
  end
  #--------------------------------------------------------------------------
  # Check if quest is started
  #--------------------------------------------------------------------------
  def quest_started?(symbol)
    return $csca.get_quest(symbol).started
  end
  #--------------------------------------------------------------------------
  # Check if quest is completed
  #--------------------------------------------------------------------------
  def quest_progress(symbol)
    return $csca.get_quest(symbol).progress
  end
end
#==============================================================================
# ** CSCA_Scene_Quest
#------------------------------------------------------------------------------
#  Handles the quest scene.
#==============================================================================
class CSCA_Scene_Quest < Scene_MenuBase
  #--------------------------------------------------------------------------
  # Start Processing
  #--------------------------------------------------------------------------
  def start
    super
    @sort_type = :alphabetical
    create_head_window
    create_command_window
    create_list_window
    create_dummy_window
    create_info_window
    create_sort_window
    create_detail_window
  end
  #--------------------------------------------------------------------------
  # Create Header Window
  #--------------------------------------------------------------------------
  def create_head_window
    @head_window = CSCA_Window_Header.new(0,0,CSCA::QUESTS::HEADER)
  end
  #--------------------------------------------------------------------------
  # Create Command Window
  #--------------------------------------------------------------------------
  def create_command_window
    @command_window = CSCA_Window_QuestCommand.new(0, @head_window.height)
    @command_window.viewport = @viewport
    @command_window.set_handler(:cancel, method(:return_scene))
    @command_window.set_handler(:sort, method(:command_sort))
    @command_window.set_handler(:all, method(:on_category_ok))
    @command_window.set_handler(:in_progress, method(:on_category_ok))
    @command_window.set_handler(:complete, method(:on_category_ok))
  end
  #--------------------------------------------------------------------------
  # Create Sort Window
  #--------------------------------------------------------------------------
  def create_sort_window
    x = Graphics.width - Graphics.width/4
    y = @command_window.y
    @sort_window = CSCA_Window_QuestSort.new(x, y)
    @sort_window.viewport = @viewport
    @sort_window.set_handler(:cancel, method(:on_sort_cancel))
    @sort_window.set_handler(:ok, method(:on_sort_ok))
    @sort_window.deactivate
    @sort_window.hide
  end
  #--------------------------------------------------------------------------
  # Create Quest List Window
  #--------------------------------------------------------------------------
  def create_list_window
    y = @head_window.height + @command_window.height
    width = Graphics.width/3
    height = Graphics.height - y
    @list_window = CSCA_Window_QuestList.new(0, y, width, height, @sort_type)
    @list_window.viewport = @viewport
    @list_window.set_handler(:cancel, method(:on_list_cancel))
    @list_window.set_handler(:ok, method(:on_list_ok))
    @command_window.list_window = @list_window
  end
  #--------------------------------------------------------------------------
  # Create Dummy Window
  #--------------------------------------------------------------------------
  def create_info_window
    x, y = @dummy_window.x, @dummy_window.y
    width, height = @dummy_window.width, @dummy_window.height
    @info_window = CSCA_Window_QuestInfo.new(x, y, width, height)
    @info_window.viewport = @viewport
    @info_window.hide
    @list_window.help_window = @info_window
  end
  #--------------------------------------------------------------------------
  # Create Dummy Window
  #--------------------------------------------------------------------------
  def create_dummy_window
    x = @list_window.width
    y = @list_window.y
    width = Graphics.width - x
    height = Graphics.height - y
    @dummy_window = Window_Base.new(x, y, width, height)
    @dummy_window.viewport = @viewport
  end
  #--------------------------------------------------------------------------
  # Create Detail Window
  #--------------------------------------------------------------------------
  def create_detail_window
    x = (Graphics.width-@info_window.width)/2
    width = @info_window.width
    height = Graphics.height - 50
    @detail_window = CSCA_Window_QuestDetail.new(x, 25, width, height)
    @detail_window.set_handler(:cancel, method(:detail_back))
    @detail_window.set_handler(:ok, method(:detail_back))
    @detail_window.viewport = @viewport
    @detail_window.hide
    @list_window.detail_window = @detail_window
  end
  #--------------------------------------------------------------------------
  # Processing on Category OK
  #--------------------------------------------------------------------------
  def on_category_ok
    @list_window.activate
    @list_window.select(0)
    @command_window.deactivate
    @dummy_window.hide
    @info_window.show
  end
  #--------------------------------------------------------------------------
  # Processing on Quest List Cancel
  #--------------------------------------------------------------------------
  def on_list_cancel
    @list_window.deactivate
    @list_window.unselect
    @command_window.activate
    @dummy_window.show
    @info_window.hide
  end
  #--------------------------------------------------------------------------
  # Processing on Quest List OK
  #--------------------------------------------------------------------------
  def on_list_ok
    @list_window.deactivate
    @detail_window.activate
    @detail_window.show
  end
  #--------------------------------------------------------------------------
  # Processing on Command Sort
  #--------------------------------------------------------------------------
  def command_sort
    @sort_window.show
    @sort_window.activate
    @command_window.deactivate
  end
  #--------------------------------------------------------------------------
  # Processing on Sort Window cancel
  #--------------------------------------------------------------------------
  def on_sort_cancel
    @sort_window.hide
    @sort_window.deactivate
    @command_window.activate
  end
  #--------------------------------------------------------------------------
  # Processing on Sort Window OK
  #--------------------------------------------------------------------------
  def on_sort_ok
    @sort_type = @sort_window.current_symbol
    @sort_window.hide
    @sort_window.deactivate
    @command_window.activate
    @list_window.sort_type = @sort_type
  end
  #--------------------------------------------------------------------------
  # Exit Detail Window
  #--------------------------------------------------------------------------
  def detail_back
    @detail_window.deactivate
    @detail_window.hide
    @list_window.activate
  end
end
#==============================================================================
# ** CSCA_Window_QuestCommand
#------------------------------------------------------------------------------
#  Basic Quest list Commands
#==============================================================================
class CSCA_Window_QuestCommand < Window_HorzCommand
  attr_reader :list_window
  #--------------------------------------------------------------------------
  # Object Initialization
  #--------------------------------------------------------------------------
  def initialize(x, y)
    super(x, y)
  end
  #--------------------------------------------------------------------------
  # Get Window Width
  #--------------------------------------------------------------------------
  def window_width
    return Graphics.width
  end
  #--------------------------------------------------------------------------
  # Frame update
  #--------------------------------------------------------------------------
  def update
    super
    @list_window.category = current_symbol if @list_window 
  end
  #--------------------------------------------------------------------------
  # Populate Command List
  #--------------------------------------------------------------------------
  def make_command_list
    add_command("All", :all)
    add_command("In Progress", :in_progress, any_current_quests?)
    add_command("Complete", :completed, any_complete_quests?)
    add_command("Sort", :sort)
  end
  #--------------------------------------------------------------------------
  # Determine if there are any quests in progress
  #--------------------------------------------------------------------------
  def any_current_quests?
    $csca.quests.each do |quest|
      return true if quest.started && !quest.completed
    end
    return false
  end
  #--------------------------------------------------------------------------
  # Determine if there are any complete quests
  #--------------------------------------------------------------------------
  def any_complete_quests?
    $csca.quests.each do |quest|
      return true if quest.completed
    end
    return false
  end
  #--------------------------------------------------------------------------
  # Set List Window
  #--------------------------------------------------------------------------
  def list_window=(list_window)
    @list_window = list_window
    update
  end
end
#==============================================================================
# ** CSCA_Window_QuestCommand
#------------------------------------------------------------------------------
#  Choose sort type for quests.
#==============================================================================
class CSCA_Window_QuestSort < Window_Command
  #--------------------------------------------------------------------------
  # Object Initialization
  #--------------------------------------------------------------------------
  def initialize(x, y)
    super(x, y)
    select(0)
  end
  #--------------------------------------------------------------------------
  # Get Window Width
  #--------------------------------------------------------------------------
  def window_width
    return Graphics.width/4
  end
  #--------------------------------------------------------------------------
  # Populate Command List
  #--------------------------------------------------------------------------
  def make_command_list
    add_command("Alphabetical", :alphabetical)
    add_command("Difficulty", :difficulty)
    add_command("Location", :location)
  end
end
#==============================================================================
# ** CSCA_Window_QuestList
#------------------------------------------------------------------------------
#  List of quest names.
#==============================================================================
class CSCA_Window_QuestList < Window_Selectable
  #--------------------------------------------------------------------------
  # Object Initialization
  #--------------------------------------------------------------------------
  def initialize(x, y, width, height, sort_type)
    super(x, y, width, height)
    @sort_type = sort_type
    @category = :all
    @data = []
    refresh
  end
  #--------------------------------------------------------------------------
  # Category writer method
  #--------------------------------------------------------------------------
  def category=(category)
    need_refresh = true if @category != category
    @category = category
    refresh if need_refresh
  end
  #--------------------------------------------------------------------------
  # Sort Type writer method
  #--------------------------------------------------------------------------
  def sort_type=(sort_type)
    @sort_type = sort_type
    refresh
  end
  #--------------------------------------------------------------------------
  # Get total amount of quests in list
  #--------------------------------------------------------------------------
  def item_max
    @data ? @data.size : 1
  end
  #--------------------------------------------------------------------------
  # Get selected quest
  #--------------------------------------------------------------------------
  def item
    @data && index >= 0 ? @data[index] : nil
  end
  #--------------------------------------------------------------------------
  # Refresh
  #--------------------------------------------------------------------------
  def refresh
    make_item_list
    create_contents
    draw_all_items
  end
  #--------------------------------------------------------------------------
  # Determine if quest is included in list
  #--------------------------------------------------------------------------
  def include?(quest)
    case @category
    when :all; return true if quest.started
    when :sort; return true if quest.started
    when :completed; return true if quest.completed
    when :in_progress; return true if quest.started && !quest.completed
    end
    return false
  end
  #--------------------------------------------------------------------------
  # Populate Quest List
  #--------------------------------------------------------------------------
  def make_item_list
    data = $csca.quests.select {|quest| include?(quest)}
    @data = data.sort {|quest1, quest2|
      case @sort_type
      when :alphabetical; quest1.name <=> quest2.name
      when :location; quest1.location <=> quest2.location
      when :difficulty; get_difficulty(quest1) <=> get_difficulty(quest2)
      end
    }
    @data
  end
  #--------------------------------------------------------------------------
  # Determine proper difficulty order
  #--------------------------------------------------------------------------
  def get_difficulty(quest)
    if CSCA::QUESTS::DIFFICULTIES.index(quest.difficulty).nil?
      error = "Difficulty not found in Difficulty array."
      script = "CSCA Quest System"
      suggestion = "Make sure all quest difficulties are in order in the Difficulty array."
      $csca.report_error(error, script, suggestion, true)
    end
    return CSCA::QUESTS::DIFFICULTIES.index(quest.difficulty)
  end
  #--------------------------------------------------------------------------
  # Draw Item
  #--------------------------------------------------------------------------
  def draw_item(index)
    quest = @data[index]
    if quest
      rect = item_rect(index)
      contents.font.size = 20
      draw_text(rect.x, rect.y, contents.width, line_height, quest.name)
    end
  end
  #--------------------------------------------------------------------------
  # Detail Window Writer Method
  #--------------------------------------------------------------------------
  def detail_window=(detail_window)
    @detail_window = detail_window
  end
  #--------------------------------------------------------------------------
  # Update Quest Info/Detail Window
  #--------------------------------------------------------------------------
  def update_help
    @help_window.set_item(item)
    @detail_window.set_item(item) if @detail_window
  end
end
#==============================================================================
# ** CSCA_Window_QuestInfo
#------------------------------------------------------------------------------
#  Draws Quest Information
#==============================================================================
class CSCA_Window_QuestInfo < Window_Base
  #--------------------------------------------------------------------------
  # Object Initialization
  #--------------------------------------------------------------------------
  def initialize(x, y, width, height)
    super(x, y, width, height)
    @quest = nil
    refresh
  end
  #--------------------------------------------------------------------------
  # Set Item
  #--------------------------------------------------------------------------
  def set_item(quest)
    @quest = quest
    refresh
  end
  #--------------------------------------------------------------------------
  # Font Size 20 line height
  #--------------------------------------------------------------------------
  def small_line_height
    line_height - 4
  end
  #--------------------------------------------------------------------------
  # Refresh
  #--------------------------------------------------------------------------
  def refresh
    contents.clear
    return unless @quest
    draw_quest_name
    contents.font.size = 20
    draw_basic_info(small_line_height, "Assigned By: ", @quest.giver)
    draw_basic_info(small_line_height*2, "Location: ", @quest.location)
    draw_basic_info(small_line_height*3, "Difficulty: ", @quest.difficulty)
    draw_quest_step(small_line_height*4)
    draw_quest_rewards(small_line_height*5 + small_line_height*get_current_objective.size)
    draw_tutorial_text(height - line_height*2)
    contents.font.size = 24
  end
  #--------------------------------------------------------------------------
  # Draw Quest Name
  #--------------------------------------------------------------------------
  def draw_quest_name
    contents.font.bold = true
    draw_text(0, 0, contents.width, line_height, @quest.name, 1)
    contents.font.bold = false
  end
  #--------------------------------------------------------------------------
  # Draw Basic Info
  #--------------------------------------------------------------------------
  def draw_basic_info(y, system_text, quest_text)
    change_color(text_color(CSCA::QUESTS::SYSTEM_TEXT_COLOR))
    contents.font.bold = true
    x = text_size(system_text).width
    draw_text(0, y, contents.width, line_height, system_text)
    contents.font.bold = false
    change_color(normal_color)
    draw_text(x, y, contents.width, line_height, quest_text)
  end
  #--------------------------------------------------------------------------
  # Draw Current Step of the quest
  #--------------------------------------------------------------------------
  def draw_quest_step(y)
    s1 = "Current Objective:"
    steps = get_current_objective
    change_color(text_color(CSCA::QUESTS::SYSTEM_TEXT_COLOR))
    contents.font.bold = true
    draw_text(0, y, contents.width, line_height, s1, 1)
    contents.font.bold = false
    change_color(normal_color)
    steps.each do |step|
      y += small_line_height
      draw_text(0, y, contents.width, line_height, step)
    end
  end
  #--------------------------------------------------------------------------
  # Draw Quest Rewards
  #--------------------------------------------------------------------------
  def draw_quest_rewards(y)
    s1 = "Rewards:"
    change_color(text_color(CSCA::QUESTS::SYSTEM_TEXT_COLOR))
    contents.font.bold = true
    draw_text(0, y, contents.width, line_height, s1, 1)
    contents.font.bold = false
    change_color(normal_color)
    y += small_line_height
    @quest.rewards.each do |reward|
      icon = nil
      name = ""
      amount = ""
      case reward.type
      when :string
        name = reward.id
        amount = reward.amount
      when :exp
        amount = "x" + reward.amount.to_s
        name = "Experience"
      when :item
        icon = $data_items[reward.id].icon_index
        name = $data_items[reward.id].name
        amount = "x" + reward.amount.to_s
      when :armor
        icon = $data_armors[reward.id].icon_index
        name = $data_armors[reward.id].name
        amount = "x" + reward.amount.to_s
      when :weapon
        icon = $data_weapons[reward.id].icon_index
        name = $data_weapons[reward.id].name
        amount = "x" + reward.amount.to_s
      when :gold
        icon = $game_party.get_csca_cs_currency(reward.id)[:icon] if $imported["CSCA-CurrencySystem"]
        name = $imported["CSCA-CurrencySystem"] ? $game_party.get_csca_cs_currency(reward.id)[:name] : CSCA::QUESTS::CURRENCY_NAME
        amount = "x" + reward.amount.to_s
      end
      contents.fill_rect(0, y, contents.width, line_height-2, Color.new(0,0,0,50))
      draw_icon(icon, 0, y) unless icon.nil?
      x = icon.nil? ? 0 : 24
      draw_text(x, y, contents.width, line_height, name)
      draw_text(0, y, contents.width, line_height, amount, 2)
      y += line_height
    end
  end
  def draw_tutorial_text(y)
    draw_text(0, y, contents.width, line_height, "Select to view more information.", 1)
  end
  #--------------------------------------------------------------------------
  # Get current Objective
  #--------------------------------------------------------------------------
  def get_current_objective
    return ["Quest Completed!"] if @quest.completed
    steps = []
    string = @quest.steps[@quest.progress]
    for x in string.split("\n")
      steps.push(x)
    end
    return steps
  end
end
#==============================================================================
# ** CSCA_Window_QuestDetail
#------------------------------------------------------------------------------
#  Shows description and last 10 objectives.
#==============================================================================
class CSCA_Window_QuestDetail < Window_Selectable
  #--------------------------------------------------------------------------
  # Object Initialization
  #--------------------------------------------------------------------------
  def initialize(x, y, w, h)
    super(x, y, w, h)
    @quest = nil
    @y = 0
    self.back_opacity = 255
    refresh
  end
  #--------------------------------------------------------------------------
  # Disable cursor
  #--------------------------------------------------------------------------
  def cursor_movable?
    return false
  end
  #--------------------------------------------------------------------------
  # Font Size 20 line height
  #--------------------------------------------------------------------------
  def small_line_height
    line_height - 4
  end
  #--------------------------------------------------------------------------
  # Set Quest Data
  #--------------------------------------------------------------------------
  def set_item(quest)
    @quest = quest
    refresh
  end
  #--------------------------------------------------------------------------
  # Refresh
  #--------------------------------------------------------------------------
  def refresh
    contents.clear
    return if @quest.nil?
    contents.font.size = 20
    @y = 0
    draw_description
    draw_objectives
    contents.font.size = 24
  end
  #--------------------------------------------------------------------------
  # Draw Description
  #--------------------------------------------------------------------------
  def draw_description
    change_color(text_color(CSCA::QUESTS::SYSTEM_TEXT_COLOR))
    contents.font.bold = true
    draw_text(0, @y, contents.width, line_height, "Description:", 1)
    @y += small_line_height
    contents.font.bold = false
    change_color(normal_color)
    @quest.description.each do |line|
      draw_text(0, @y, contents.width, line_height, line, 1)
      @y += small_line_height
    end
  end
  #--------------------------------------------------------------------------
  # Draw Objectives
  #--------------------------------------------------------------------------
  def draw_objectives
    change_color(text_color(CSCA::QUESTS::SYSTEM_TEXT_COLOR))
    contents.font.bold = true
    draw_text(0, @y, contents.width, line_height, "Objective History:", 1)
    @y += small_line_height
    contents.font.bold = false
    change_color(normal_color)
    objectives = get_objectives
    fade = 255
    fade_amount = CSCA::QUESTS::FADE_AMOUNT
    objectives.each do |obj|
      split_obj = get_obj_lines(obj)
      break unless @y + (small_line_height * split_obj.size) <= contents_height
      split_obj.each do |line|
        draw_text(0, @y, contents.width, line_height, line, 1)
        @y += small_line_height
      end
      fade -= fade_amount
      contents.font.color = Color.new(fade, fade, fade, fade)
      @y += small_line_height/2
    end
  end
  #--------------------------------------------------------------------------
  # Get Objectives
  #--------------------------------------------------------------------------
  def get_objectives
    objectives = []
    for i in 0..@quest.progress
      break if @quest.steps[i].nil?
      objectives.push(@quest.steps[i])
    end
    reversed_objectives = objectives.reverse
    return reversed_objectives
  end
  #--------------------------------------------------------------------------
  # Get Objective Lines
  #--------------------------------------------------------------------------
  def get_obj_lines(obj)
    steps = []
    for x in obj.split("\n")
      steps.push(x)
    end
    return steps
  end
end
if $imported["CSCA-ToastManager"]
#==============================================================================
# ** CSCA_Window_Toast
#------------------------------------------------------------------------------
# Show toasts for quest completion.
#==============================================================================
class CSCA_Window_Toast < Window_Base
  #--------------------------------------------------------------------------
  # Alias Method; refresh
  #--------------------------------------------------------------------------
  alias :csca_qsys_refresh :refresh
  def refresh(params)
    csca_qsys_refresh(params)
    if params[0] == :quest_complete
      Audio.se_play("Audio/SE/" + CSCA::QUESTS::QUEST_COMPLETE_SOUND) if CSCA::QUESTS::QUEST_COMPLETE_SOUND
      quest = params[1]
      contents.font.bold = true
      change_color(text_color(CSCA::QUESTS::SYSTEM_TEXT_COLOR))
      draw_text(0, 0, contents.width, line_height, "Quest Complete!", 1)
      change_color(normal_color)
      contents.font.bold = false
      draw_text(0, line_height, contents.width, line_height, quest.name, 1)
    end
  end
end
end # $imported["CSCA-ToastManager"]