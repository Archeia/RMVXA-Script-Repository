=begin
CSCA Extra Stats
version: 1.1.1
Created by: Casper Gaming (http://www.caspergaming.com/)

Compatibility:
Made for RPGVXAce
IMPORTANT: ALL CSCA Scripts should be compatible with each other unless
otherwise noted.
================================================================================
UPDATES:
Version 1.0
-Original Script

Version 1.1
-Added tracking for gold looted from battle
-Aliased everything
-Added support for CSCA Skill Shop

Version 1.1.1
-Added support for CSCA Currency System
-Added comments
================================================================================
FFEATURES:
This script will track a few things not tracked by default. Currently, it tracks
the amount of damage taken and dealt during battle, the amount of items bought
and sold at shops, the amount of gold spent/made from buying/selling to shops,
the amount of items used, and the amount of gold looted from battles.

Stats Tracked:
Gold spent at shops
Gold earned at shops
Items bought from shops
Items sold to shops
Damage taken
Damage dealt
Items used
Gold looted from battle

How to use these features is explained below in the setup section.
SETUP BELOW IS REQUIRED!

CREDIT:
Free to use in noncommercial games if credit is given to:
Casper Gaming (http://www.caspergaming.com/)

To use in a commercial game, please purchase a license here:
http://www.caspergaming.com/licenses.html

TERMS:
http://www.caspergaming.com/terms_of_use.html
=end
module CSCA_EXTRA_STATS
#==============================================================================
# ** Begin Setup
#==============================================================================
  GOLDSPENT = 20 # Variable ID. Stores the amount of gold spent on items at shops.
  GOLDGAINED = 21 # Variable ID. Stores amount of gold made from selling to shops.
  
  ITEMSBOUGHT = 22 # Variable ID. Stores amount of items bought from shops.
  ITEMSSOLD = 23 # Variable ID. Stores amount of items sold to shops.
  
  DAMAGE_TAKEN = 24 # Variable ID. Stores damage dealt to actors.
  DAMAGE_DEALT = 25 # Variable ID. Stores damage dealt to enemies.
  
  ITEMS_USED = 26 # Variable ID. Stores amount of items used.
  
  LOOTED = 27 # Variable ID. Stores amount of gold looted from enemies.
#==============================================================================
# ** End Setup
#==============================================================================
end
$imported = {} if $imported.nil?
$imported["CSCA-ExtraStats"] = true
#==============================================================================
# ** Scene_Shop
#------------------------------------------------------------------------------
#  Tracking for items bought/sold, and gold spent/gained
#Aliases: do_buy, do_sell
#==============================================================================
class Scene_Shop < Scene_MenuBase
  #--------------------------------------------------------------------------
  # Alias Method; execute purchase
  #--------------------------------------------------------------------------
  alias :csca_buy :do_buy
  def do_buy(number)
    csca_buy(number)
    csca_es_adjust_stats(:buy, number)
  end
  #--------------------------------------------------------------------------
  # Alias Method; execute sale
  #--------------------------------------------------------------------------
  alias :csca_sell :do_sell
  def do_sell(number)
    csca_sell(number)
    csca_es_adjust_stats(:sell, number)
  end
  #--------------------------------------------------------------------------
  # Adjust tracking variables
  #--------------------------------------------------------------------------
  def csca_es_adjust_stats(op, number)
    case op
    when :buy
      $game_variables[CSCA_EXTRA_STATS::ITEMSBOUGHT] += number
      $game_variables[CSCA_EXTRA_STATS::GOLDSPENT] += (number * buying_price)
    when :sell
      $game_variables[CSCA_EXTRA_STATS::ITEMSSOLD] += number
      $game_variables[CSCA_EXTRA_STATS::GOLDGAINED] += (number * selling_price)
    end
  end
end
#==============================================================================
# ** Game_Battler
#------------------------------------------------------------------------------
#  Tracking for damage dealt/taken.
#Aliases: execute_damage
#==============================================================================
class Game_Battler < Game_BattlerBase
  #--------------------------------------------------------------------------
  # Alias Method; execute damage
  #--------------------------------------------------------------------------
  alias :csca_stat_execute_damage :execute_damage
  def execute_damage(*args)
    actor? ? $game_variables[CSCA_EXTRA_STATS::DAMAGE_TAKEN] += @result.hp_damage :
      $game_variables[CSCA_EXTRA_STATS::DAMAGE_DEALT] += @result.hp_damage
    csca_stat_execute_damage(*args)
  end
end
#==============================================================================
# ** Scene_Battle
#------------------------------------------------------------------------------
#  Tracking for items used (in battle).
#Aliases: use_item
#==============================================================================
class Scene_Battle < Scene_Base
  #--------------------------------------------------------------------------
  # Alias Method; use item
  #--------------------------------------------------------------------------
  alias :csca_stat_use_item :use_item
  def use_item
    item = @subject.current_action.item
    if item.is_a?(RPG::Item)
      $game_variables[CSCA_EXTRA_STATS::ITEMS_USED] += 1
    end
    csca_stat_use_item
  end
end
#==============================================================================
# ** Scene_Item
#------------------------------------------------------------------------------
#  Tracking for items used (in menu).
#Aliases: use_item
#==============================================================================
class Scene_Item < Scene_ItemBase
  #--------------------------------------------------------------------------
  # Alias Method; use item
  #--------------------------------------------------------------------------
  alias :csca_use_item :use_item
  def use_item
    csca_use_item
    $game_variables[CSCA_EXTRA_STATS::ITEMS_USED] += 1
  end
end
#==============================================================================
# ** BattleManager
#------------------------------------------------------------------------------
#  Tracking for currency gained from enemy drops.
#Aliases: gain_gold
#==============================================================================
module BattleManager
  #--------------------------------------------------------------------------
  # Alias Method; gain currency
  #--------------------------------------------------------------------------
  class <<self; alias :csca_gold_looted :gain_gold; end
  def self.gain_gold
    if $imported["CSCA-CurrencySystem"]
      $game_troop.gold_total.each do |currency_symbol, amount|
        $game_variables[CSCA_EXTRA_STATS::LOOTED] += amount
      end
    end
    $game_variables[CSCA_EXTRA_STATS::LOOTED] += $game_troop.gold_total unless $imported["CSCA-CurrencySystem"]
    csca_gold_looted
  end
end
#==============================================================================
# ** CSCA Skill Shop compatibility code below.
#------------------------------------------------------------------------------
#  Tracking for gold spent at the skill shop.
#Aliases: do_buy
#==============================================================================
if $imported["CSCA-SkillShop"]
  class CSCA_Scene_Skill_Shop < Scene_MenuBase
  #--------------------------------------------------------------------------
  # Alias Method; execute purchase
  #--------------------------------------------------------------------------
    alias :sca_stat_do_buy :do_buy
    def do_buy(actor, skill)
      $game_variables[CSCA_EXTRA_STATS::GOLDSPENT] += buying_price
      csca_stat_do_buy(actor, skill)
    end
  end
end # $imported["CSCA-SkillShop"]