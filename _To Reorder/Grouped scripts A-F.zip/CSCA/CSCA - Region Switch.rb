=begin
CSCA RegionSwitch
version: 1.1
Created by: Casper Gaming (http://www.caspergaming.com/)

Compatibility:
Made for RPGVXAce
IMPORTANT: ALL CSCA Scripts should be compatible with each other unless
otherwise noted.

INTRODUCTION:
This script automatically turns a switch on if the player is inside a region.

FEATURES:
-Turns a switch ON if player is in a region.

SETUP
Script is Plug and Play.

To set up regions and switches affected, insert these notetags in the map's
notebox:
===============================================================================
<csca_r: x>
The X will be the regions affected, more than 1 region is acceptable.
For example, <csca_r: 1,2> will turn switches on if the player is in region 1 or
region 2.
===============================================================================
<csca_s: x>
The X will be the switches affected, more than 1 switch is acceptable.
For example, <csca_s: 1,2) will turn switches 1 and 2 on if the player is in
regions that affect switches. The second switch corresponds with the second region
===============================================================================
<csca_tt: x>
The X will be the terrain tags affected, more than 1 terrain tag is acceptable.
For example, <csca_tt: 1,2> will turn switches on if the player is standing on a
tile with terrain tag 1 or 2.
===============================================================================
<csca_ts: x>
The X will be the switches affected, more than 1 switch is acceptable.
For example, <csca_ts: 1,2) will turn switches 1 and 2 on if the player standing
on tiles with terrain tags that affect switches. The second switch corresponds
with the second terrain tag.
===============================================================================
Example:
<csca_r: 1,2>
<csca_s: 3,4>
Will turn switch 3 ON if player is in region 1, and switch 4 ON if in region 2.
===============================================================================
Example:
<csca_tt: 1,2>
<csca_ts: 3,4>
Will turn switch 3 ON if player is standing on a tile with terrain tag 1, and
switch 4 ON if standing on a tile with terrain tag 2.
================================================================================

================================================================================
UPDATES
version 1.1
- Added ability to turn switches on by terrain tags.
- Made code more compatible (Now works well with CSCA Event Movement).
================================================================================
CREDIT:
Free to use in noncommercial games if credit is given to:
Casper Gaming (http://www.caspergaming.com/)

To use in a commercial game, please purchase a license here:
http://www.caspergaming.com/licenses.html

TERMS:
http://www.caspergaming.com/terms_of_use.html
=end
$imported = {} if $imported.nil?
$imported["CSCA-RegionSwitch"] = true
class Game_Map
  #--------------------------------------------------------------------------#
  # alias method.                                                            #
  #--------------------------------------------------------------------------#
  alias :csca_rs_update :update
  def update(main)
    csca_update_region_switch if @map.note =~ /<csca_r: (.*)>/i
    csca_update_tag_switch if @map.note =~ /<csca_tt: (.*)>/i
    csca_rs_update(main)
  end
  #--------------------------------------------------------------------------#
  # Turn switches On/Off with regions                                        #
  #--------------------------------------------------------------------------#
  def csca_update_region_switch
    regions = csca_get_rs_note(:region)
    switches = csca_get_rs_note(:switch)
    for i in 0...regions.size
      region_id($game_player.x, $game_player.y) == regions[i] ?
      csca_toggle_switch(switches[i], true) : csca_toggle_switch(switches[i], false)
    end
  end
  #--------------------------------------------------------------------------#
  # Turn switches On/Off with tags                                           #
  #--------------------------------------------------------------------------#
  def csca_update_tag_switch
    tags = csca_get_rs_note(:tag_terrain)
    tag_switches = csca_get_rs_note(:tag_switch)
    for i in 0...tags.size
      terrain_tag($game_player.x, $game_player.y) == tags[i] ?
      csca_toggle_switch(tag_switches[i], true) : csca_toggle_switch(tag_switches[i], false)
    end
  end
  #--------------------------------------------------------------------------#
  # Get region tag, and switch arrays                                        #
  #--------------------------------------------------------------------------#
  def csca_get_rs_note(type)
    case type
    when :region; @map.note =~ /<csca_r: (.*)>/i
    when :switch; @map.note =~ /<csca_s: (.*)>/i
    when :tag_terrain; @map.note =~ /<csca_tt: (.*)>/i
    when :tag_switch; @map.note =~ /<csca_ts: (.*)>/i
    end
    ids = []
    for x in $1.split(",")
      ids.push(x.to_i)
    end
    return ids
  end
  #--------------------------------------------------------------------------#
  # Toggle                                                                   #
  #--------------------------------------------------------------------------#
  def csca_toggle_switch(switch, b)
    $game_switches[switch] = b unless $game_switches[switch] == b
  end
end