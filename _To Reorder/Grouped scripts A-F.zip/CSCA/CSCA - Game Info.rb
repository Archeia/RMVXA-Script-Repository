=begin
CSCA GameInfo
version: 1.0.1(August 26, 2012)
Created by: Casper Gaming (http://www.caspergaming.com/)

Compatibility:
Made for RPGVXAce
IMPORTANT: ALL CSCA Scripts should be compatible with each other unless
otherwise noted.

UPDATE HISTORY:
version 1.0
-original script

version 1.0.1
-Bugfix, gameinfo no longer appears above load window.

INTRODUCTION:
This script draws some additional information on the title screen, as well as
opening a file at game start/exit(commercial games may use this feature in
demo's to prompt the player to buy the full version).

FEATURES:
-Can draw a version number on title screen.
-Can draw copyright info on the title screen.
-Can open a file at game start and game exit.

SETUP
Script requires set up below.

CREDIT
Free to use in noncommercial and commercial games if credit is given to:
Casper Gaming (http://www.caspergaming.com/)
NOTE: THIS IS THE ONLY CASPER GAMING SCRIPT THAT IS FREE FOR USE IN COMMERCIAL
GAMES.

TERMS:
http://www.caspergaming.com/terms_of_use.html
=end
module CSCA
  module GAMEINFO
    # SETUP BEGIN #
    #Text Setup
    #If not using a text option, set it to ""
    VERSION = "Version: " # Version text.
    VERSION_ID = "1.0" # Version number, is using custom version.
    COPYRIGHT = "©CasperGaming" # Copyright text. © ® ™
    WEBSITE = "www.caspergaming.com" # Website text.
    
    #Popup Setup - set all to false if not using this feature.
    FILE = "demoscreen.html" # File name (Same directory as Game.exe)
    DEBUG = false # Open file even during game test?
    STARTUP = true # Open file on game start?
    GAMEEND = true # Open file on game end?
    
    #Misc Setup
    FONT_SIZE = 20 # Size of the font.
    ONE_STRING = true # Treat all text as one string? (Alignment difference)
    SPACING = "     " # Spacing between texts. Only valid if ONE_STRING is true.
    CUSTOM_VERSION = true # Use custom version number(true)
                          # or use a generated version number(false)
    # END SETUP #
  end
end
$imported = {} if $imported.nil?
$imported["CSCA-GameInfo"] = true
#==============================================================================
# ** SceneManager
#------------------------------------------------------------------------------
#  Opens a file on exit(optional).
# Aliases: exit
#==============================================================================
module SceneManager
  #--------------------------------------------------------------------------
  # * Alias Method
  #--------------------------------------------------------------------------
  class <<self; alias csca_gameinfo_exit exit; end
  def self.exit
    $game_system.csca_open_file(CSCA::GAMEINFO::FILE) if csca_openfile_on_exit?
    csca_gameinfo_exit
  end
  #--------------------------------------------------------------------------
  # * Open file on exit?
  #--------------------------------------------------------------------------
  def self.csca_openfile_on_exit?
    return false if $BTEST
    CSCA::GAMEINFO::GAMEEND ? $TEST ? CSCA::GAMEINFO::DEBUG : true : false
  end
end # SceneManager
#==============================================================================
# ** Scene_Title
#------------------------------------------------------------------------------
#  Draws game info to title screen
# Aliases: start, dispose foreground
#==============================================================================
class Scene_Title < Scene_Base
  #--------------------------------------------------------------------------
  # * Alias Method
  #--------------------------------------------------------------------------
  alias csca_gameinfo_start start
  def start
    csca_gameinfo_start
    csca_draw_game_info
    $game_system.csca_open_file(CSCA::GAMEINFO::FILE) if csca_openfile_on_start?
  end
  #--------------------------------------------------------------------------
  # * Open file on start?
  #--------------------------------------------------------------------------
  def csca_openfile_on_start?
    CSCA::GAMEINFO::STARTUP ? $TEST ? CSCA::GAMEINFO::DEBUG : true : false
  end
  #--------------------------------------------------------------------------
  # * Draw version and copyright info
  #--------------------------------------------------------------------------
  def csca_draw_game_info
    @gameinfo_sprite = Sprite.new
    @gameinfo_sprite.bitmap = Bitmap.new(Graphics.width, Graphics.height)
    @gameinfo_sprite.z = 100
    @gameinfo_sprite.bitmap.font.size = CSCA::GAMEINFO::FONT_SIZE
    rect = Rect.new(2,(Graphics.height/2)-10,Graphics.width,Graphics.height)
    version_id = CSCA::GAMEINFO::CUSTOM_VERSION ? CSCA::GAMEINFO::VERSION_ID : $data_system.version_id.to_s
    version = CSCA::GAMEINFO::VERSION+version_id
    if CSCA::GAMEINFO::ONE_STRING
      @gameinfo_sprite.bitmap.draw_text(rect,version+CSCA::GAMEINFO::SPACING+
        CSCA::GAMEINFO::COPYRIGHT+CSCA::GAMEINFO::SPACING+CSCA::GAMEINFO::WEBSITE,1)
    else
      @gameinfo_sprite.bitmap.draw_text(rect,version)
      @gameinfo_sprite.bitmap.draw_text(rect,CSCA::GAMEINFO::COPYRIGHT,1)
      @gameinfo_sprite.bitmap.draw_text(rect,CSCA::GAMEINFO::WEBSITE,2)
    end
  end
  #--------------------------------------------------------------------------
  # * Alias method
  #--------------------------------------------------------------------------
  alias csca_dispose_gameinfo dispose_foreground
  def dispose_foreground
    csca_dispose_gameinfo
    @gameinfo_sprite.bitmap.dispose
    @gameinfo_sprite.dispose
  end
end # Scene_Title
#==============================================================================
# ** Game_System
#------------------------------------------------------------------------------
#  Added ability to open a file.
#==============================================================================
class Game_System
  #--------------------------------------------------------------------------
  # * Open File
  #--------------------------------------------------------------------------
  def csca_open_file(filename)
    shell = Win32API.new("shell32","ShellExecute",'LPPL','L')
    shell.Call(0,"open",filename,0)
  end
end #Game_System