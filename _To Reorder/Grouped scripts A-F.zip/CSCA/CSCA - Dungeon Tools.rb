=begin
CSCA Dungeon Tools
version: 1.4b
Created by: Casper Gaming (http://www.caspergaming.com/)

Compatibility:
Made for RPGVXAce
IMPORTANT: ALL CSCA Scripts should be compatible with each other unless
otherwise noted.
REQUIRES CSCA Core Script
================================================================================
UPDATE HISTORY:

Version 1.1
-Fixed boomerang misspelling
-Aliased a few more things
-Bomb is now seperate from other tools, as in you can use other tools while a
bomb is planted. However, you're still limited to 1 arrow/hookshot/boomerang
at one time.
-Tool events are now designated by comments rather than entering a predefined
event id in the module.

Version 1.2
-Fixed bug that occured if a map didn't have dungeon tool events set up.
-Fixed bug that caused a crash if any event on the map had no event pages with
met conditions.

Version 1.3
-Added ability to hold a button down to turn in the direction pressed instead
of moving. This is able to be done at all times.
-Fixed reset bug
-Added ability to require the player has items to use some tools. For example,
the player might need an arrow in their inventory to use the arrow tool.
-Increased compatibility by aliasing more stuff.

Version 1.3b
- Changed some stuff for compatibility with CSCA Menu Organizer.

Version 1.4
- Damage floor now doesn't damage the player when hookshotting over it.
- Added a new region, similar to region 1 but only functions if a switch is ON.

Version 1.4b
- Region ID 1 will no longer allow tools to go through events. Use the other
regions for this effect. (Toggleable).
================================================================================

FFEATURES:
This script allows you to enable/disable use of pre-made "dungeon tools" easily
with switches. The pre-made tools include: Reset, Arrow, Bomb, Hookshot, Boomarang.
Each tool behaves slightly differently, and it is recommended to download
the demo to get a better understanding of how each tool works.

RESET: Resets the map to how it was when you entered. This option will NOT turn
switches/variables back to their original value, but it will turn self
switches to false unless RESET_EXEMPT is put in the event page of an event. It
also transfers the player to where they were originally after the previous
transfer.

ARROW: Shoots an arrow in the direction you're facing. When it hits an event, if
the event has ARROW_ACTIVATE in a comment event command, it will activate the
next self switch. If no self switch is on, it will turn A on. If A is on, B will
be turned on, etc.

BOMB: Sets a bomb down where the player is standing. When the player steps a
specified amount of times, the bomb blows up, activating the next self switche of
events underneath it, as well as directly above/below, and to the right/left.
The self switches are only turned on if BOMB_ACTIVATE is in their event page in
a comment command.

HOOKSHOT: Shoots a hookshot in the direction of the player. If it connects with
an event that has HOOKSHOT_ENABLED in a comment event command, it will move the
player to that event, even if there are impassable tiles in between. If no
event is hit, or the event does not have the comment command, the hookshot
returns to the player.

BOOMARANG: Shoots a boomarang, which can collect one item at a time(requires
some eventing, shown in demo). If the boomarang flies over an event with the
comment command BOOMARANG_ACTIVATE, it will turn on that event's next self switch.

SETUP
This script requires setup further down. It is important that you do not allow
the player to reset the map before they have transferred once(by using the Transfer
event command), as this script assumes a transfer has already happened.

SETTING UP YOUR EVENTS:
Each map where you plan to use these tools MUST have an event with the comment
BOMB_TOOL inside, as well as an event with the comment DUNGEON_TOOL inside. The
BOMB_TOOL event will act as the bomb, and the DUNGEON_TOOL will act as all other
tools. Case Matters. Make sure you set the through/priority/stepping animation
settings in the event page how you want them, as this script does not
automatically do that. If you get a undefined method error, chances are you have
set your events up incorrectly.

On maps that do not have these events(any map that you do not want to use these
tools on), it is very important to turn the ON_OFF switch OFF. Remember to turn
it back ON for maps where these tools will be used, though!

IMPORTANT! If you do not understand how to do some things, please download the
demo to see each item properly used.

CREDIT:
Free to use in noncommercial games if credit is given to:
Casper Gaming (http://www.caspergaming.com/)

To use in a commercial game, please purchase a license here:
http://www.caspergaming.com/licenses.html

TERMS:
http://www.caspergaming.com/terms_of_use.html
=end
module CSCA_DUNGEON_TOOLS # Don't touch this.
  
  ON_OFF = 21 # Switch ID. Turns this whole script on/off.
  
  # Trigger name        Key on keyboard
  # :A             =    Shift
  # :B             =    X
  # :C             =    Z
  # :X             =    A
  # :Y             =    S
  # :Z             =    D
  # :L             =    Q
  # :R             =    W
  TRIGGER = :R # Which button do you want to bring up the tool select menu?
  USETOOL = :X # Which button do you want to use a tool?
  
  STILL_TRIGGER = :B # Which button do you want the player to hold to turn
                     # without moving?
  ENABLE_STILL = true # Allow the player to hold a button to turn without moving?
  
  # Dungeon Tools. If you don't want to use one, simply leave it's switch OFF.
  ARROW = 22 # Switch ID. Turn ON to allow selection of the arrow.
  BOMB = 23 # Switch ID. Turn ON to allow selection of the bomb.
  HOOKSHOT = 24 # Switch ID. Turn ON to allow selection of the hookshot.
  BOOMERANG = 25 # Switch ID. Turn ON to allow selection of the boomarang.
  RESET = 26 # Switch ID. Turn ON to allow selection of the reset option.
  
  # Names. This is all text shown in game in the selection window.
  ARROW_NAME = "Arrow" # Name of the Arrow tool.
  BOMB_NAME = "Bomb" # Name of the Bomb tool.
  HOOKSHOT_NAME = "Hookshot" # Name of the Hookshot tool.
  BOOMERANG_NAME = "Boomerang" # Name of the Boomarang tool.
  RESET_NAME = "Reset" # Name of the Reset tool.
  HEADER = "Dungeon Tools" # Name of the selection window.
  
  # Icons. These icons will be shown next to the similarly named tools.
  ARROW_ICON = 529 # Icon displayed next to the Arrow text.
  BOMB_ICON = 528 # Icon displayed next to the Bomb text.
  HOOKSHOT_ICON = 530 # Icon displayed next to the Hookshot text.
  BOOMERANG_ICON = 154 # Icon displayed next to the Boomarang text.
  RESET_ICON = 280 # Icon displayed next to the Reset text.
  
  CSCADGT = 1 # Variable ID. By setting this in-game you can force use of some
              # tools. 1 sets to arrow, 2 to bomb, 3 to hookshot, 4 to boomarang.
              # If set to 5, the map will automatically reset and set this to 0,
              # so setting this variable's value to 5 requires some caution.
               
  REGION_ID1 = 1 # Region ID. Arrow/hookshot/boomarang can always move when in
                 # this region, no matter if the map tile is passable or not.
                 # However, the arrow/hookshot will not be able to activate
                 # events while in this region ID either.
  REGION_ID2 = 2 # Region ID. Arrow/hookshot/boomarang can always move when in
                 # this region IF it is facing down.
  REGION_ID3 = 3 # Region ID. Arrow/hookshot/boomarang can always move when in
                 # this region IF it is facing left.
  REGION_ID4 = 4 # Region ID. Arrow/hookshot/boomarang can always move when in
                 # this region IF it is facing right.
  REGION_ID5 = 5 # Region ID. Arrow/hookshot/boomarang can always move when in
                 # this region IF it is facing up.
  REGION_ID6 = 6 # Region ID. Arrow/hookshot/boomarang can always move when in
                 # this region IF it is facing up OR left
  REGION_ID7 = 7 # Region ID. Arrow/hookshot/boomarang can always move when in
                 # this region IF it is facing up OR right
  REGION_ID8 = 8 # Region ID. Arrow/hookshot/boomarang can always move when in
                 # this region IF it is facing down OR left
  REGION_ID9 = 9 # Region ID. Arrow/hookshot/boomarang can always move when in
                 # this region IF it is facing down OR right
  REGION_ID10 = 10 # Region ID. Arrow/hookshot/boomarang can always move when in
                   # this region IF it is facing up OR down.
  REGION_ID11 = 11 # Region ID. Arrow/hookshot/boomarang can always move when in
                   # this region IF it is facing left OR right
  REGION_ID12 = 12 # Region ID. Arrow/hookshot/boomarang can always move when in
                   # this region IF it is facing left OR right OR up
  REGION_ID13 = 13 # Region ID. Arrow/hookshot/boomarang can always move when in
                   # this region IF it is facing left OR right OR down
  REGION_ID14 = 14 # Region ID. Arrow/hookshot/boomarang can always move when in
                   # this region IF it is facing up OR down OR left
  REGION_ID15 = 15 # Region ID. Arrow/hookshot/boomarang can always move when in
                   # this region IF it is facing up OR down OR right
                   
                   
  REGION_ID16 = 16 # Region ID. Arrow/hookshot/boomarang can always move when in
                   # this region IF REGION_SWITCH is ON. Useful for multi-level
                   # areas.
                   
  REGION_SWITCH = 7 # Turns region ID 16 on.
  
  R1_EVENTS = false # Allow region ID 1 to move through events?
               
  FILENAME = "CSCA_DT" # Filename of the character sheet containing your bomb,
                       # arrow, hookshot, and boomarang graphics. This should
                       # be placed in Graphics/Characters.
                       
  # File indexes. Character graphic files are laid out like so:
  # [0,1,2,3]
  # [4,5,6,7]
  # Where each number corresponds to the spot on the character sheet.
  ARROW_INDEX = 1 # Index of the arrow graphic in the previously specified file.
  BOMB_INDEX = 0 # Index of the bomb graphic in the previously specified file.
  HOOKSHOT_INDEX = 3 # Index of the hookshot graphic in the previously specified
                     # file.
  BOOMERANG_INDEX = 2 # Index of the boomarang graphic in the previously
                      # specified file.
                      
  ARROW_DIST = 8 # Amount of spaces you want the arrow to travel.
  BOOMERANG_DIST = 7 # Amount of spaces the boomarang will travel before returning
                     # to you.
  HOOKSHOT_DIST = 6 # Amount of spaces the hookshot will travel before returning
                    # to you.
  STEP_AMOUNT = 6 # Amount of steps required for bomb to explode.
  
  BOMB_ANIMATION_ID = 111 # Bomb explosion animation id.
  BOMB_ANIMATION_TIME = 36 # Bomb explosion animation length in frames. To get
                           # this, multiply the highest number in the animation's
                           # frame list by 4.
  
  # All sound files are located in your Audio/SE/ folder.
  ARROW_SHOOT_SOUND = "Bow1" # Plays when arrow shoots, if enabled.
  ARROW_HIT_SOUND1 = "Damage1" # Plays when arrow hits event, if enabled.
  ARROW_HIT_SOUND2 = "Shot2" # Plays when arrow hits non-event, if enabled.
  BOMB_PLACEMENT_SOUND = "Cursor1" # Sound file to play when bomb is planted.
  HOOKSHOT_USE_SOUND = "Saint3" # Sound file to play when hookshot is used.
  BOOMERANG_USE_SOUND = "Darkness2" # Sound file to play when boomarang thrown.
  
  # Choose whether or not each sound file plays.
  ARROW_SOUND1 = true # Play ARROW_SHOOT_SOUND ?
  ARROW_SOUND2 = true # Play sound when arrow collides with event ?
  ARROW_SOUND3 = true # Play sound when arrow collides with non-event ?
  BOMB_SOUND1 = true # Play BOMB_PLACEMENT_SOUND ?
  HOOKSHOT_SOUND1 = true # Play hookshot use sound ?
  BOOMERANG_SOUND1 = true # Play boomarang throw sound ?
  
  
  # Setting this to true will require the player to have the items specified
  # below in thier inventory or else the tool will not be used. This will also
  # subtract one of that item upon use of that tool.
  REQUIRE_ITEMS_B = false # Require an item to use bombs?
  REQUIRE_ITEMS_A = false # Require an item to use arrows?
  
  # The following item ID's are the items that determine whether a tool is usable.
  # For example, if the palyer know how to use bombs, but has no bombs in their
  # inventory, the bomb tool will be unusable. Only works if REQUIRE_ITEMS is true.
  BOMB_ITEM_ID = 1 # Item ID. This item will be used when the Bomb Tool is used.
  ARROW_ITEM_ID = 2 # Item ID. This item will be used when the Arrow Tool is used.
  
  # Text displayed when a tool is used, but the player doesn't have the required
  # item specified above in their inventory. This feature only happens if
  # REQUIRE_ITEMS is set to true.
  NO_ITEM_TEXT = "You don't have any %ss!"
  
end # END SETUP. Don't touch this or anything below.
$imported = {} if $imported.nil?
$imported["CSCA-DungeonTools"] = true
msgbox('Missing Script: CSCA Core Script! CSCA Dungeon Tools requires this
script to work properly.') if !$imported["CSCA-Core"]
class Game_CharacterBase
  include CSCA_DUNGEON_TOOLS
  
  def csca_change_graphic(character, type)
    case type
    when 1
      character.set_graphic(FILENAME, ARROW_INDEX)
    when 2
      character.set_graphic(FILENAME, BOMB_INDEX)
    when 3
      character.set_graphic(FILENAME, HOOKSHOT_INDEX)
    when 4
      character.set_graphic(FILENAME, BOOMERANG_INDEX)
    else
      character.set_graphic("", 0)
    end
  end
  
  def csca_change_move_speed(speed)
    @move_speed = speed
  end
  
  def csca_change_through(t_f)
    @through = t_f
  end
  
end
class Scene_Map < Scene_Base
  include CSCA_DUNGEON_TOOLS
  
  alias csca_update update_scene
  def update_scene
    csca_update
    csca_update_dt unless $game_map.interpreter.running?
    csca_call_dts unless scene_changing? || $game_map.interpreter.running?
  end
  
  def csca_call_dts
    if Input.press?(TRIGGER) && $game_switches[ON_OFF] && csca_check_tools
      Sound.play_ok
      SceneManager.call(CSCA_Scene_DungeonToolSelect)
    end
  end
  
  def csca_check_tools
    return $game_switches[ARROW] || $game_switches[BOMB] ||
    $game_switches[HOOKSHOT] || $game_switches[BOOMERANG] ||
    $game_switches[RESET]
  end
  
  def csca_update_dt
    if Input.press?(USETOOL) && $game_switches[ON_OFF]
      use_arrow if $game_variables[CSCADGT] == 1
      use_bomb if $game_variables[CSCADGT] == 2
      use_hookshot if $game_variables[CSCADGT] == 3
      use_boomarang if $game_variables[CSCADGT] == 4
    end
  end
  
  def use_arrow
    $game_map.use_arrow unless $game_map.using_tool?
  end
  
  def use_bomb
    $game_map.use_bomb unless $game_map.using_bomb? || $game_map.anime_playing?
  end
  
  def use_hookshot
    $game_map.use_hookshot unless $game_map.using_tool?
  end
  
  def use_boomarang
    $game_map.use_boomarang unless $game_map.using_tool?
  end
  
end
class Game_Map
  include CSCA_DUNGEON_TOOLS

  alias csca_map_update update
  def update(main)
    csca_map_update(main)
    csca_reset if $game_variables[CSCADGT] == 5
    csca_update if using_tool? || using_bomb?
    csca_arrow_finish if done_moving? && @tooltype == :arrow
    csca_boomarang_finish if done_moving? && @tooltype == :boomarang
    csca_hookshot_finish if done_moving? && @tooltype == :hookshot
  end
  
  def csca_update
    csca_check_through if @tooltype == :arrow || @tooltype == :boomarang || @tooltype == :hookshot
    csca_check_steps if using_bomb?
    csca_check_pickup if @tooltype == :boomarang && !pickup?
  end
  
  def csca_check_through
    csca_get_event
    d = @csca_event.direction
    x = @csca_event.x
    y = @csca_event.y
    case d
    when 2; y += 1
    when 4; x -= 1
    when 6; x += 1
    when 8; y -= 1
    end
    block_event = events_xy_nt(x, y)
    if ((region_id(@csca_event.x, @csca_event.y) == REGION_ID1) && (block_event == [] || R1_EVENTS))  ||
    (d == 2 && region_id(@csca_event.x, @csca_event.y) == REGION_ID2) ||
    (d == 4 && region_id(@csca_event.x, @csca_event.y) == REGION_ID3) ||
    (d == 6 && region_id(@csca_event.x, @csca_event.y) == REGION_ID4) ||
    (d == 8 && region_id(@csca_event.x, @csca_event.y) == REGION_ID5) ||
    ((d == 8 || d == 4) && region_id(@csca_event.x, @csca_event.y) == REGION_ID6) ||
    ((d == 8 || d == 6) && region_id(@csca_event.x, @csca_event.y) == REGION_ID7) ||
    ((d == 2 || d == 4) && region_id(@csca_event.x, @csca_event.y) == REGION_ID8) ||
    ((d == 2 || d == 6) && region_id(@csca_event.x, @csca_event.y) == REGION_ID9) ||
    ((d == 2 || d == 8) && region_id(@csca_event.x, @csca_event.y) == REGION_ID10) ||
    ((d == 4 || d == 6) && region_id(@csca_event.x, @csca_event.y) == REGION_ID11) ||
    ((d == 4 || d == 6 || d == 8) && region_id(@csca_event.x, @csca_event.y) == REGION_ID12) ||
    ((d == 4 || d == 6 || d == 2) && region_id(@csca_event.x, @csca_event.y) == REGION_ID13) ||
    ((d == 2 || d == 8 || d == 4) && region_id(@csca_event.x, @csca_event.y) == REGION_ID14) ||
    ((d == 2 || d == 8 || d == 6) && region_id(@csca_event.x, @csca_event.y) == REGION_ID15) ||
    ($game_switches[REGION_SWITCH] && region_id(@csca_event.x, @csca_event.y) == REGION_ID16) ||
    @hookshot_reverse_dir == true
      @csca_event.csca_change_through(true)
    else
      @csca_event.csca_change_through(false)
    end
  end
  
  def csca_check_steps
    @bombsteps2 = $game_party.steps
    @bombsteps1 = @bombsteps
    @bombsteps2 -= @bombsteps1
    if @bombsteps2 >= STEP_AMOUNT
      bomb_explode(@csca_bomb_event)
    end
  end
  
  def csca_check_pickup
    x = @csca_event.x
    y = @csca_event.y
    d = @csca_event.direction
    case d
    when 2; y -= 1
    when 4; x += 1
    when 6; x -= 1
    when 8; y += 1
    end
    @csca_event_id = event_id_xy(x, y)
    if @csca_event_id != 0
      csca_get_collision_event(@csca_event_id)
      csca_check_comment(@csca_collision_event, 2)
    end
  end
  
  def bomb_explode(event)
    @waitforanimation = true
    @bombplanted = false
    event.animation_id = BOMB_ANIMATION_ID
    do_bomb_effect(event)
    csca_clear_ok?(event)
  end
  
  def do_bomb_effect(bomb)
    x = bomb.x
    y = bomb.y
    @csca_bomb_event_id5 = event_id_xy(x, y)
    x += 1
    @csca_bomb_event_id1 = event_id_xy(x, y)
    x -= 2
    @csca_bomb_event_id2 = event_id_xy(x, y)
    x = bomb.x
    y += 1
    @csca_bomb_event_id3 = event_id_xy(x, y)
    y -= 2
    @csca_bomb_event_id4 = event_id_xy(x, y)
    if @csca_bomb_event_id1 != 0
      get_bomb_explode_event(@csca_bomb_event_id1)
      csca_check_comment(@csca_bomb_explode_event, 5, 1)
    end
    if @csca_bomb_event_id2 != 0
      get_bomb_explode_event(@csca_bomb_event_id2)
      csca_check_comment(@csca_bomb_explode_event, 5, 2)
    end
    if @csca_bomb_event_id3 != 0
      get_bomb_explode_event(@csca_bomb_event_id3)
      csca_check_comment(@csca_bomb_explode_event, 5, 3)
    end
    if @csca_bomb_event_id4 != 0
      get_bomb_explode_event(@csca_bomb_event_id4)
      csca_check_comment(@csca_bomb_explode_event, 5, 4)
    end
    if @csca_bomb_event_id5 != 0
      get_bomb_explode_event(@csca_bomb_event_id5)
      csca_check_comment(@csca_bomb_explode_event, 5, 5)
    end
  end
  
  def get_arrow_success_coords(event)
    x = event.x
    y = event.y
    d = event.direction
    case d
    when 2; y += ARROW_DIST
    when 4; x -= ARROW_DIST
    when 6; x += ARROW_DIST
    when 8; y -= ARROW_DIST
    end
    @csca_success_x = x
    @csca_success_y = y
  end

  def csca_finish_move_route
    @csca_dt_done_moving = true
  end
  
  def csca_arrow_finish
    csca_get_event
    if @csca_event.x == @csca_success_x && @csca_event.y == @csca_success_y
      csca_clear_event
    else
      csca_check_collision(@csca_event)
    end
  end
  
  def csca_boomarang_finish
    $game_party.leader.hp -= 1
    csca_clear_event
  end
  
  def csca_hookshot_finish
    csca_clear_event
  end
  
  def csca_hookshot_check
    csca_check_collision(@csca_event)
  end
  
  def use_arrow
    if $game_party.has_item?($data_items[ARROW_ITEM_ID]) || !REQUIRE_ITEMS_A
      @tooltype = :arrow
      csca_get_event
      csca_event_setup(@csca_event)
      @csca_event.csca_change_graphic(@csca_event, 1)
      @csca_event.csca_change_move_speed(6)
      Audio.se_play("Audio/SE/" + ARROW_SHOOT_SOUND, 80, 100) if ARROW_SOUND1
      get_arrow_success_coords(@csca_event)
      arrow_move_route(@csca_event, ARROW_DIST)
      $game_party.lose_item($data_items[ARROW_ITEM_ID], 1) if REQUIRE_ITEMS_A
    else
      $game_message.add(sprintf(NO_ITEM_TEXT, ARROW_NAME))
    end
  end
  
  def use_bomb
    if $game_party.has_item?($data_items[BOMB_ITEM_ID]) || !REQUIRE_ITEMS_B
      @tooltype = :bomb
      csca_get_bomb_event
      @csca_bomb_event.moveto($game_player.x, $game_player.y)
      @csca_bomb_event.csca_change_graphic(@csca_bomb_event, 2)
      Audio.se_play("Audio/SE/" + BOMB_PLACEMENT_SOUND, 80, 100) if BOMB_SOUND1
      @bombplanted = true
      @bombsteps = $game_party.steps
      $game_party.lose_item($data_items[BOMB_ITEM_ID], 1) if REQUIRE_ITEMS_B
    else
      $game_message.add(sprintf(NO_ITEM_TEXT, BOMB_NAME))
    end
  end
  
  def use_hookshot
    @tooltype = :hookshot
    csca_get_event
    csca_event_setup(@csca_event)
    @csca_event.csca_change_graphic(@csca_event, 3)
    @csca_event.csca_change_move_speed(5)
    Audio.se_play("Audio/SE/" + HOOKSHOT_USE_SOUND, 80, 100) if HOOKSHOT_SOUND1
    hookshot_move_route(@csca_event, HOOKSHOT_DIST)
  end
  
  def use_boomarang
    @tooltype = :boomarang
    csca_get_event
    csca_event_setup(@csca_event)
    @csca_event.csca_change_graphic(@csca_event, 4)
    @csca_event.csca_change_move_speed(5)
    Audio.se_play("Audio/SE/" + BOOMERANG_USE_SOUND, 80, 100) if BOOMERANG_SOUND1
    boomarang_move_route(@csca_event, BOOMERANG_DIST)
  end
  
  def csca_get_event
    events.each do |i, event|
      if event.list != nil
        for i in 0...event.list.size
          if event.list[i].code == 108 && event.list[i].parameters == ["DUNGEON_TOOL"]
            @csca_event = event
          end
        end
      end
    end
  end
  
  def csca_get_bomb_event
    events.each do |i, event|
      if event.list != nil
        for i in 0...event.list.size
          if event.list[i].code == 108 && event.list[i].parameters == ["BOMB_TOOL"]
            @csca_bomb_event = event
          end
        end
      end
    end
  end
  
  def csca_event_setup(event)
    @usingtool = true
    event.moveto($game_player.x, $game_player.y)
    event.set_direction($game_player.direction)
    event.csca_change_through(false)
  end
  
  def using_tool?
    @usingtool
  end
  
  def using_bomb?
    @bombplanted
  end
  
  def anime_playing?
    @waitforanimation
  end
  
  def tooltype?
    @tooltype
  end
  
  def done_moving?
    @csca_dt_done_moving
  end
  
  def pickup?
    @pickedup
  end
  
  def moving_back?
    @movingback
  end
  
  def csca_clear_event
    @usingtool = @csca_dt_done_moving = @pickedup = @movingback = @hookshot_reverse_dir = false
    csca_get_event
    if @csca_event != nil
      @csca_event.moveto(0,0)
      @csca_event.csca_change_graphic(@csca_event, 5)
    end
  end
  
  def csca_clear_bomb_event
    @bombplanted = @waitforanimation = false
    csca_get_bomb_event
    if @csca_bomb_event != nil
      @csca_bomb_event.moveto(1,0)
      @csca_bomb_event.csca_change_graphic(@csca_bomb_event, 5)
    end
  end
  
  def arrow_move_route(event, dist)
    mr = RPG::MoveRoute.new
    mr.repeat = false
    mr.wait = true
    mr.skippable = true
    mc = RPG::MoveCommand.new
    mc.code = 12
    mc.parameters = []
    mc2 = RPG::MoveCommand.new
    mc2.code = 45
    mc2.parameters = ["$game_map.csca_finish_move_route"]
    for i in 0...dist
      mr.list[i] = mc
    end
    mr.list[dist] = mc2
    event.force_move_route(mr)
  end
  
  def boomarang_move_route(event, dist)
    mr = RPG::MoveRoute.new
    mr.repeat = false
    mr.wait = true
    mr.skippable = true
    mc = RPG::MoveCommand.new
    mc.code = 12
    mc.parameters = []
    mc2 = RPG::MoveCommand.new
    mc2.code = 45
    if moving_back?
      mc2.parameters = ["$game_map.csca_finish_move_route"]
    else
      mc2.parameters = ["$game_map.csca_move_back"]
    end
    mc3 = RPG::MoveCommand.new
    mc3.code = 22
    mc3.parameters = []
    for i in 0...dist
      mr.list[i] = mc
    end
    mr.list[dist] = mc3
    mr.list[dist + 1] = mc2
    event.force_move_route(mr)
  end
  
  def hookshot_move_route(event, dist)
    mr = RPG::MoveRoute.new
    mr.repeat = false
    mr.wait = true
    mr.skippable = true
    mc = RPG::MoveCommand.new
    mc.code = 12
    mc.parameters = []
    mc2 = RPG::MoveCommand.new
    mc2.code = 45
    mc2.parameters = ["$game_map.csca_hookshot_check"]
    for i in 0...dist
      mr.list[i] = mc
    end
    mr.list[dist] = mc2
    event.force_move_route(mr)
  end
  
  def hookshot_move_back(event)
    @hookshot_reverse_dir = true
    x1 = $game_player.x
    y1 = $game_player.y
    x2 = event.x
    y2 = event.y
    event.direction == 2 ? distance = (y1 - y2).abs :
    event.direction == 8 ? distance = (y1 - y2).abs : distance = (x1 - x2).abs
    if x1 == x2 && y1 == y2
      csca_clear_event
      return
    end
    mr = RPG::MoveRoute.new
    mr.repeat = false
    mr.wait = true
    mr.skippable = true
    mc = RPG::MoveCommand.new
    mc.code = 13
    mc.parameters = []
    mc2 = RPG::MoveCommand.new
    mc2.code = 45
    mc2.parameters = ["$game_map.csca_finish_move_route"]
    for i in 0...distance
      mr.list[i] = mc
    end
    mr.list[distance] = mc2
    event.force_move_route(mr)
  end
  
  def csca_hookshot_success(event)
    x1 = event.x
    y1 = event.y
    x2 = @csca_event.x
    y2 = @csca_event.y
    event.direction == 2 ? distance = (y1 - y2).abs :
    event.direction == 8 ? distance = (y1 - y2).abs : distance = (x1 - x2).abs
    mr = RPG::MoveRoute.new
    mr.repeat = false
    mr.wait = true
    mr.skippable = true
    mc = RPG::MoveCommand.new
    mc.code = 12
    mc.parameters = []
    mc2 = RPG::MoveCommand.new
    mc2.code = 45
    mc2.parameters = ["$game_map.csca_finish_move_route"]
    mc3 = RPG::MoveCommand.new
    mc3.code = 37
    mc3.parameters = []
    mc4 = RPG::MoveCommand.new
    mc4.code = 38
    mc4.parameters = []
    mc5 = RPG::MoveCommand.new
    mc5.code = 32
    mc5.parameters = []
    mc6 = RPG::MoveCommand.new
    mc6.code = 31
    mc6.parameters = []
    mc7 = RPG::MoveCommand.new
    mc7.code = 45
    mc7.parameters = ["$game_player.csca_move_route_over"]
    mr.list[0] = mc3
    mr.list[1] = mc5
    for i in 2..distance + 1
      mr.list[i] = mc
    end
    mr.list[distance + 2] = mc4
    mr.list[distance + 3] = mc6
    mr.list[distance + 4] = mc2
    mr.list[distance + 5] = mc7
    event.force_move_route(mr)
  end
  
  def csca_move_back
    @movingback = true
    csca_get_event
    x1 = $game_player.x
    y1 = $game_player.y
    x2 = @csca_event.x
    y2 = @csca_event.y
    @csca_event.direction == 2 ? distance = (y1 - y2).abs :
    @csca_event.direction == 8 ? distance = (y1 - y2).abs : distance = (x1 - x2).abs
    boomarang_move_route(@csca_event, distance)
  end
  
  def csca_clear_ok?(event)
    mr = RPG::MoveRoute.new
    mr.repeat = false
    mr.wait = true
    mr.skippable = true
    mc = RPG::MoveCommand.new
    mc.code = 15
    mc.parameters = [BOMB_ANIMATION_TIME]
    mc2 = RPG::MoveCommand.new
    mc2.code = 45
    mc2.parameters = ["$game_map.csca_clear_bomb_event"]
    mr.list[0] = mc
    mr.list[1] = mc2
    event.force_move_route(mr)
  end
  
  def turn_on_next_ss(event)
    csca_map_id = map_id
    csca_event_id = event
    switches = ["A","B","C","D"]
    for i in switches
      key = [csca_map_id, csca_event_id, i]
      if !$game_self_switches[key]
        $game_self_switches[key] = true
        return
      end
    end
  end
  
  def csca_check_collision(event)
    x = event.x
    y = event.y
    d = event.direction
    case d
    when 2; y += 1
    when 4; x -= 1
    when 6; x += 1
    when 8; y -= 1
    end
    @csca_event_id = event_id_xy(x, y)
    if @csca_event_id != 0 
      csca_get_collision_event(@csca_event_id)
      csca_check_comment(@csca_collision_event, 1) if @tooltype == :arrow
      if region_id(@csca_event.x, @csca_event.y) == REGION_ID1 && @tooltype == :hookshot
        hookshot_move_back(@csca_event)
      else
        csca_check_comment(@csca_collision_event, 3) if @tooltype == :hookshot
      end
    else
      Audio.se_play("Audio/SE/" + ARROW_HIT_SOUND2, 80, 100) if ARROW_SOUND3 && @tooltype == :arrow
      hookshot_move_back(@csca_event) if @tooltype == :hookshot
    end
    csca_clear_event if @tooltype == :arrow
  end
  
  def csca_get_collision_event(id)
    events.each do |i, event|
      @csca_collision_event = event if event.id == id
    end
  end
  
  def csca_check_comment(event, tool, bombvar = 0)
    unless event == nil
    for i in 0...event.list.size
      case tool
      when 1
        if event.list[i].code == 108 && event.list[i].parameters == ["ARROW_ACTIVATE"]
          Audio.se_play("Audio/SE/" + ARROW_HIT_SOUND1, 80, 100) if ARROW_SOUND2
          turn_on_next_ss(@csca_event_id)
        else
          Audio.se_play("Audio/SE/" + ARROW_HIT_SOUND2, 80, 100) if ARROW_SOUND3
        end
      when 2
        if event.list[i].code == 108 && event.list[i].parameters == ["BOOMERANG_ACTIVATE"] && !pickup?
          turn_on_next_ss(@csca_event_id)
          @pickedup = true
        end
      when 3
        if event.list[i].code == 108 && event.list[i].parameters == ["HOOKSHOT_ENABLED"]
          csca_hookshot_success($game_player)
          return
        else
          hookshot_move_back(@csca_event)
        end
      when 4
        if event.list[i].code == 108 && event.list[i].parameters == ["RESET_EXEMPT"]
          return false
        else
          return true
        end
      when 5
        if event.list[i].code == 108 && event.list[i].parameters == ["BOMB_ACTIVATE"]
          turn_on_next_ss(@csca_bomb_event_id1) if bombvar == 1
          turn_on_next_ss(@csca_bomb_event_id2) if bombvar == 2
          turn_on_next_ss(@csca_bomb_event_id3) if bombvar == 3
          turn_on_next_ss(@csca_bomb_event_id4) if bombvar == 4
          turn_on_next_ss(@csca_bomb_event_id5) if bombvar == 5
        end
      end
    end
    end # unless event == nil
  end
  
  def csca_reset
    $game_variables[CSCADGT] = 0
    map_id = $game_player.csca_transfer_map_id
    event_amount = events.size
    for i in 1..event_amount
      event_id = i
      get_exempt_event(event_id)
      if $game_map.csca_check_comment(@csca_exempt_event, 4)
        switches = ["A","B","C","D"]
        for i in switches
          key = [map_id, event_id, i]
          $game_self_switches[key] = false
        end
      end
    end
    x = $game_player.csca_transfer_x
    y = $game_player.csca_transfer_y
    d = $game_player.direction
    if x != nil && y != nil && d != nil
      $game_player.reserve_transfer(map_id, x, y, d)
      $game_temp.fade_type = 0
    end
  end
  
  def get_exempt_event(id)
    events.each do |i, event|
      @csca_exempt_event = event if event.id == id
    end
  end
  
  def get_bomb_explode_event(id)
    events.each do |i, event|
      @csca_bomb_explode_event = event if event.id == id
    end
  end
  
end
class Game_Player < Game_Character
  
  alias csca_save_transfer reserve_transfer
  def reserve_transfer(map_id, x, y, d = 2)
    csca_save_transfer(map_id, x, y, d)
    @csca_saved_map_id = map_id
    @csca_saved_x = x
    @csca_saved_y = y
    $game_map.csca_clear_event
    $game_map.csca_clear_bomb_event
  end
  
  def csca_transfer_map_id
    @csca_saved_map_id
  end
  
  def csca_transfer_x
    @csca_saved_x
  end
  
  def csca_transfer_y
    @csca_saved_y
  end
  
  def csca_move_route_over
    @move_route_forcing = false
  end
  
  alias csca_movable? movable?
  def movable?
    return false if $game_map.using_tool? && ($game_map.tooltype? == :hookshot || $game_map.tooltype? == :boomarang)
    csca_movable?
  end
  
  alias csca_dt_damage_floor? on_damage_floor?
  def on_damage_floor?
    !($game_map.tooltype? == :hookshot && $game_map.using_tool?) && csca_dt_damage_floor?
  end
  
  def move_by_input
    return if !movable? || $game_map.interpreter.running?
    if Input.press?(CSCA_DUNGEON_TOOLS::STILL_TRIGGER) && CSCA_DUNGEON_TOOLS::ENABLE_STILL
      set_direction(Input.dir4) if Input.dir4 > 0
    else
      move_straight(Input.dir4) if Input.dir4 > 0
    end
  end
  
end
class CSCA_Scene_DungeonToolSelect < Scene_MenuBase
  include CSCA_DUNGEON_TOOLS
  
  def start
    super
    create_command_window
    create_head_window
  end
  
  def update
    super
    update_cancel
  end
  
  def update_cancel
    if Input.press?(:B)
      Sound.play_cancel
      return_scene
    end
  end
  
  def create_command_window
    @command_window = CSCA_Window_DungeonToolSelect.new(200, 150)
    if $game_switches[ARROW]
      @command_window.set_handler(:arrow, method(:select_arrow))
    end
    if $game_switches[BOMB]
      @command_window.set_handler(:bomb, method(:select_bomb))
    end
    if $game_switches[HOOKSHOT]
      @command_window.set_handler(:hookshot, method(:select_hookshot))
    end
    if $game_switches[BOOMERANG]
      @command_window.set_handler(:boomarang, method(:select_boomarang))
    end
    if $game_switches[RESET]
      @command_window.set_handler(:reset, method(:select_reset))
    end
  end
  
  def create_head_window
    @head_window = CSCA_Window_Header.new(200, 100, 160, HEADER)
  end
  
  def select_arrow
    $game_variables[CSCADGT] = 1
    return_scene
  end
  
  def select_bomb
    $game_variables[CSCADGT] = 2
    return_scene
  end
  
  def select_hookshot
    $game_variables[CSCADGT] = 3
    return_scene
  end
  
  def select_boomarang
    $game_variables[CSCADGT] = 4
    return_scene
  end
  
  def select_reset
    $game_variables[CSCADGT] = 5
    return_scene
  end
  
end
class CSCA_Window_DungeonToolSelect < Window_Command
  include CSCA_DUNGEON_TOOLS
  
  def initialize(x, y)
    super(x, y)
    make_command_icons
  end
  
  def make_command_list
    add_command(ARROW_NAME, :arrow) if $game_switches[ARROW]
    add_command(BOMB_NAME, :bomb) if $game_switches[BOMB]
    add_command(HOOKSHOT_NAME, :hookshot) if $game_switches[HOOKSHOT]
    add_command(BOOMERANG_NAME, :boomarang) if $game_switches[BOOMERANG]
    add_command(RESET_NAME, :reset) if $game_switches[RESET]
  end
  
  def make_command_icons
    y = 0
    if $game_switches[ARROW]
      draw_icon(ARROW_ICON, 110, y)
      y += line_height
    end
    if $game_switches[BOMB]
      draw_icon(BOMB_ICON, 110, y)
      y += line_height
    end
    if $game_switches[HOOKSHOT]
      draw_icon(HOOKSHOT_ICON, 110, y)
      y += line_height
    end
    if $game_switches[BOOMERANG]
      draw_icon(BOOMERANG_ICON, 110, y)
      y += line_height
    end
    if $game_switches[RESET]
      draw_icon(RESET_ICON, 110, y)
    end
  end
end