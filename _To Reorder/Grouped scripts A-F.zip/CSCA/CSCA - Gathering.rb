=begin
CSCA Gathering
version: 1.0.0 (Released: June 2, 2013)
Created by: Casper Gaming (http://www.caspergaming.com/)
================================================================================
Compatibility:
Made for RPGVXAce
IMPORTANT: ALL CSCA Scripts should be compatible with each other unless
otherwise noted.

Requires CSCA Core Script v1.0.7+
LINK: http://www.rpgmakervxace.net/topic/6879-csca-core-script/

Does not require, but for all features/best results use with CSCA Professions.
LINK: http://www.rpgmakervxace.net/topic/14734-csca-professions/
================================================================================
FFEATURES
Creates a gathering system in your game. Many options, everything from respawn
time to gather animations and item tiers. Some options require additional scripts.
================================================================================
SETUP
Set up required. Instructions below.
================================================================================
CREDIT:
Free to use in noncommercial games if credit is given to:
Casper Gaming (http://www.caspergaming.com/)

To use in a commercial game, please purchase a license here:
http://www.caspergaming.com/licenses.html
================================================================================
TERMS:
http://www.caspergaming.com/terms_of_use.html
================================================================================
=end
module CSCA
  module GATHERING
    NODE_TYPES = []
    NODE = []
#==============================================================================
# ** IMPORTANT Setup information below!
#==============================================================================
#==============================================================================
# ** Setting up your gather events
#==============================================================================
# Setting up a gather event is easy. Certain settings are mandatory:
#
# Graphic should be blank
# Trigger should be action button
#
# After that is set up, you only require 1 event command. Make a "comment" event
# command with the following string:
#
# <gather_node: x>
# Where "x" would be the symbol of the node you want to spawn. Do not include the
# colon in this string, that is added automatically.
#==============================================================================
# ** Setting up item tiers
#==============================================================================
# item tiers are set up in the node_type in this line:
# :item_tiers => [tier1, tier2, etc],
#
# Each tier is an array with 2 values, for example:
# [:item, 1]
# The first value can either be :item, :weapon, or :armor.
# The second value is the ID of that item. So [:item, 1] tells the system to
# look for the item with the id of 1. [:weapon, 3] would tell the system to look
# for the weapon with the ID of 3.
#
# Equips are included when determining if the party is in possession of this item,
# but the item does not have to be equipped.
#
# A complete tier list might look something like this:
# :item_tiers => [[:weapon, 1], [:weapon, 2], [weapon, 3]],
#
# If you set the tier list to nil (:item_tiers => nil,), no item tier will be used
# for that nodetype and nodes belonging to that nodetype will not check for a
# required item. If not using the tier system, the node "min tier" setting has
# no effect, and can be set to anything (but not deleted).
#
# To limit higher level nodes to higher level tiers, use the nodes "min tier"
# setting. Each tier in the tier list should be listed in sequential order, so that
# having a min tier of "1" would allow the node to be gathered with every item in
# the tier list except the first.
#
# For example, with a min_tier setting of 1, the following tier list would
# allow the node to be gathered with every item in the list except the weapon
# with an id of 1:
# :item_tiers => [[:weapon, 1], [:weapon, 2], [weapon, 3]],
#==============================================================================
# ** Setting up gather items and rare gather items
#==============================================================================
# Gather items and rare gatehr items are set up the same way. If you don't want a
# node to have the possibility of dropping a rare item, set the rare item to nil.
#
# In the node settings, you'll find a line like this:
#:gather_item => [type, id, amount],
#
# Where the type is a symbol that can either be :item, :weapon, or :armor.
#
# The id parameter is the ID of the item/weapon/armor that can be gathered from
# the node.
#
# The amount is how much of that item/weapon/armor is collected each time the node
# is gathered (before variance and bonuses are applied).
#==============================================================================
# ** How to set node graphics
#==============================================================================
# Setting node graphics is easy. In the node settings, you'll find this line:
# :graphic => [file, index, direction],
#
# The first index, [file], is the filename of a charset. It MUST be a charset.
#
# The second index, [index], is the index in the charset of the event graphic.
# Charset indexes are set up like so:
# 0 1 2 3
# 4 5 6 7
# Where 0 is the upper left, and 7 is the bottom right graphic.
#
# The third index, [direction] is the number of the direction you want the graphic
# to be facing. 2 = down, 4 = left, 6 = right, 8 = up.
#==============================================================================
# ** Begin Setup
#==============================================================================
    # Message displayed when player does not have the required profession level to
    # gather the node. Requires CSCA Professions.
    LEVELREQ_TEXT = "You require level %d %s or better to\n%s this."
    # Message displayed when player does not have the required items to
    # gather the node.
    ITEMREQ_TEXT = "You require a%s %s or better to %s this."
    # Text above progress gauge during gathering. Expects one "%s" for node name.
    GATHER_TEXT = "Gathering: %s"
    # Text color to draw rare item information in when found.
    RARE_COLOR = 20
    # Determines whether to add or subtract/add the amount variance.
    ADD_VARIANCE_ONLY = false
    
    #NODE_TYPES[x] = {   #The "x" should be a sequential number starting at 0.
    #:type => :mining,   # Symbol associated with specific Nodes defined below.
    #:item_tiers => [[:item, 1]], # Item tiers, explained above.
    #:note => ""         # Nodetype note. May be used in future/3rd party scripts.
    #}
    
    NODE_TYPES[0] = {
    :type => :mining,
    :item_tiers => [[:item, 1]],
    :note => ""
    }
    
    #NODE[x] = {          #The "x" should be a sequential number starting at 0.
    #:type => :mining,    # The type is a Symbol that should match a node_types type.
    #:symbol => :stone,   # The symbol is a Symbol that is used to determine which node spawns on a gather event.
    #:name => "Stone",    # The name of the node.
    #:actiontext => "mine", # A string used in the item/level requirement messages, basically a more specific verb than 'gather'.
    #:level_req => 1,     # Profession level required to gather the node. Requires CSCA Professions.
    #:exp => 10,          # EXP gain after gathering the node. Requires CSCA Professions.
    #:min_tier => 0,      # Minimum item tier needed to gather this node. Explained more above.
    #:gather_item => [:item, 2, 1], # Item to be gathered, explained above.
    #:gather_item_rare => [:item, 3, 1], # Rare item to be gathered, explained above.
    #:rare_chance => 5,      # Percent chance (0-100) of finding the rare item along with the regular item.
    #:amount_variance => 1,  # Amount that the amount of the gather item can vary by. Whole number. Added/subtracted.
    #:rare_amount_variance => 1, # Amount that the amount of the rare gather item can vary by. Whole number. Added/subtracted.
    #:min_amount => 1,      # Minimum amount of the gather item that can be found. 
    #:rare_min_amount => 1, # Minimum amount of the rare gather item that can be found.
    #:profession_level_effect => 0.02, # Each profession level of the associated profession will add to the amount gathered by this amount.
    #:start_spawned => true,  # Determines if the node will start spawned when first discovering the map the node is on.
    #:spawn_time => 600,      # Amount of frames to wait before node spawns after gather (60f = 1sec)
    #:gather_time => 180,     # Amount of frames gathering this node takes. (60f = 1sec)
    #:gather_sound => nil,    # SE played at gather start.
    #:gather_end_sound => nil,# SE played at gather end.
    #:gather_anim => 7,       # Animation ID. Animation played at gatehr end over gather event.
    #:color1 => 29,       # Color 1 of the progress gauge. Text color.
    #:color2 => 29,       # Color 2 of the progress gauge. Text color.
    #graphic => ["MonsterOriginals3", 0, 2], # Event graphic of the node. Explained above.
    #:required_switch => nil, # Switch ID. Set to nil if not using. If this switch is OFF, these nodes will NOT spawn.
    #:note => ""      # Node note. May be used in future/3rd party scripts.
    #}
    
    NODE[0] = {
    :type => :mining,
    :symbol => :stone,
    :name => "Stone",
    :actiontext => "mine",
    :level_req => 1,
    :exp => 10,
    :min_tier => 0,
    :gather_item => [:item, 2, 1],
    :gather_item_rare => [:item, 3, 1],
    :rare_chance => 5,
    :amount_variance => 1,
    :rare_amount_variance => 1,
    :min_amount => 1,
    :rare_min_amount => 1,
    :profession_level_effect => 0.02,
    :start_spawned => true,
    :spawn_time => 600,
    :gather_time => 180,
    :gather_sound => nil,
    :gather_end_sound => nil,
    :gather_anim => 7,
    :color1 => 29,
    :color2 => 29,
    :graphic => ["MonsterOriginals3", 0, 2],
    :required_switch => nil,
    :note => ""
    }
#==============================================================================
# ** End Setup
#==============================================================================
  end
end
$imported = {} if $imported.nil?
$imported["CSCA-Gathering"] = true
#==============================================================================
# ** CSCA_GatheringNode
#------------------------------------------------------------------------------
# Handles single node data.
#==============================================================================
class CSCA_GatheringNode
  attr_accessor :times_gathered
  attr_reader :type
  attr_reader :symbol
  attr_reader :name
  attr_reader :actiontext
  attr_reader :level_req
  attr_reader :exp
  attr_reader :min_tier
  attr_reader :gather_item
  attr_reader :gather_item_rare
  attr_reader :rare_chance
  attr_reader :amount_variance
  attr_reader :rare_amount_variance
  attr_reader :min_amount
  attr_reader :rare_min_amount
  attr_reader :profession_level_effect
  attr_reader :start_spawned
  attr_reader :spawn_time
  attr_reader :gather_time
  attr_reader :gather_sound
  attr_reader :gather_end_sound
  attr_reader :gather_anim
  attr_reader :color1
  attr_reader :color2
  attr_reader :required_switch
  attr_reader :graphic
  attr_reader :nodetype
  attr_reader :note
  #--------------------------------------------------------------------------
  # Object Initialization
  #--------------------------------------------------------------------------
  def initialize(node, nodetype)
    @type = node[:type]
    @symbol = node[:symbol]
    @name = node[:name]
    @actiontext = node[:actiontext]
    @level_req = node[:level_req]
    @exp = node[:exp]
    @min_tier = node[:min_tier]
    @gather_item = CSCA_Item.new(node[:gather_item][2],node[:gather_item][1],node[:gather_item][0])
    @gather_item_rare = CSCA_Item.new(node[:gather_item_rare][2],node[:gather_item_rare][1],node[:gather_item_rare][0])
    @rare_chance = (node[:rare_chance].to_f/100.0)
    @amount_variance = node[:amount_variance]
    @rare_amount_variance = node[:rare_amount_variance]
    @min_amount = node[:min_amount]
    @rare_min_amount = node[:rare_min_amount]
    @profession_level_effect = node[:profession_level_effect]
    @start_spawned = node[:start_spawned]
    @spawn_time = node[:spawn_time]
    @gather_time = node[:gather_time]
    @gather_sound = node[:gather_sound]
    @gather_end_sound = node[:gather_end_sound]
    @gather_anim = node[:gather_anim]
    @color1 = node[:color1]
    @color2 = node[:color2]
    @times_gathered = 0
    @required_switch = node[:required_switch]
    @note = node[:note]
    @nodetype = nodetype
    setup_graphic(node[:graphic])
  end
  #--------------------------------------------------------------------------
  # Create Graphic Hash
  #--------------------------------------------------------------------------
  def setup_graphic(graphic)
    @graphic = {:file => graphic[0], :index => graphic[1], :dir => graphic[2]}
  end
  #--------------------------------------------------------------------------
  # Increase node times gathered
  #--------------------------------------------------------------------------
  def gather_node
    @times_gathered += 1
    @nodetype.times_gathered += 1
    $csca.refresh_node_gathered_amount(@symbol)
    $csca.refresh_nodetype_gathered_amount(@type)
  end
  #--------------------------------------------------------------------------
  # Get minimum item from tier list
  #--------------------------------------------------------------------------
  def get_minimum_item
    for i in @min_tier...@nodetype.item_tiers.size
      return case @nodetype.item_tiers[i][0]
      when :item; $data_items[@nodetype.item_tiers[i][1]]
      when :weapon; $data_weapons[@nodetype.item_tiers[i][1]]
      when :armor; $data_armors[@nodetype.item_tiers[i][1]]
      end
    end
  end
end
#==============================================================================
# ** CSCA_GatheringNodeType
#------------------------------------------------------------------------------
# Handles node type data.
#==============================================================================
class CSCA_GatheringNodeType
  attr_accessor :times_gathered
  attr_reader :type
  attr_reader :item_tiers
  attr_reader :show_item_toast
  attr_reader :note
  #--------------------------------------------------------------------------
  # Object Initialization
  #--------------------------------------------------------------------------
  def initialize(node_type)
    @type = node_type[:type]
    @item_tiers = node_type[:item_tiers]
    @show_item_toast = node_type[:show_item_toast]
    @times_gathered = 0
    @note = node_type[:note]
  end
end
#==============================================================================
# ** CSCA_Core
#------------------------------------------------------------------------------
# Added recipe handling.
#Aliases: initialize
#==============================================================================
class CSCA_Core
  attr_accessor :gather_information
  attr_reader :gather_nodes
  attr_reader :gather_nodetypes
  attr_reader :gathered_nodes
  attr_reader :gathered_nodetypes
  #--------------------------------------------------------------------------
  # Alias Method; Object Initialization
  #--------------------------------------------------------------------------
  alias :csca_gathering_initialize :initialize
  def initialize
    csca_gathering_initialize
    initialize_gathering_nodes
  end
  #--------------------------------------------------------------------------
  # Initialize Gathering Variables
  #--------------------------------------------------------------------------
  def initialize_gathering_nodes
    @gather_nodes = []
    @gather_nodetypes = []
    @gather_information = {}
    @gathered_nodes = {}
    @gathered_nodetypes = {}
    init_gather_nodetypes
    init_gather_nodes
  end
  #--------------------------------------------------------------------------
  # Initialize Nodetypes
  #--------------------------------------------------------------------------
  def init_gather_nodetypes
    CSCA::GATHERING::NODE_TYPES.each do |nodetype|
      @gather_nodetypes.push(CSCA_GatheringNodeType.new(nodetype))
      @gathered_nodetypes[nodetype[:type]] = 0
    end
  end
  #--------------------------------------------------------------------------
  # Initialize Nodes
  #--------------------------------------------------------------------------
  def init_gather_nodes
    CSCA::GATHERING::NODE.each do |node|
      @gather_nodes.push(CSCA_GatheringNode.new(node, get_nodetype(node[:type])))
      @gathered_nodes[node[:symbol]] = 0
    end
  end
  #--------------------------------------------------------------------------
  # Fast access to singular node times gathered data
  #--------------------------------------------------------------------------
  def refresh_node_gathered_amount(symbol)
    node = get_node(symbol)
    @gathered_nodes[node.symbol] = node.times_gathered
  end
  #--------------------------------------------------------------------------
  # Fast access to node type times gathered data
  #--------------------------------------------------------------------------
  def refresh_nodetype_gathered_amount(type)
    node_type = get_nodetype(type)
    @gathered_nodetypes[node_type.type] = node_type.times_gathered
  end
  #--------------------------------------------------------------------------
  # Get node
  #--------------------------------------------------------------------------
  def get_node(symbol)
    @gather_nodes.each do |node|
      return node if node.symbol == symbol
    end
  end
  #--------------------------------------------------------------------------
  # Get nodetype
  #--------------------------------------------------------------------------
  def get_nodetype(type)
    @gather_nodetypes.each do |nodetype|
      return nodetype if nodetype.type == type
    end
  end
end
#==============================================================================
# ** Game_Map
#------------------------------------------------------------------------------
#  Added handling for gathering events.
#Aliases: initialize, setup
#==============================================================================
class Game_Map
  attr_accessor :gathering
  attr_reader :gathering_node
  attr_reader :rare_gather_item
  attr_reader :rare_gather_item_amount
  attr_reader :gather_item
  attr_reader :gather_item_amount
  #--------------------------------------------------------------------------
  # Alias Method; Object Initialization
  #--------------------------------------------------------------------------
  alias :csca_gather_init :initialize
  def initialize
    csca_gather_init
    @gathering = false
  end
  #--------------------------------------------------------------------------
  # Alias method; Setup
  #--------------------------------------------------------------------------
  alias :csca_gather_setup :setup
  def setup(*args)
    csca_gather_setup(*args)
    csca_cache_gather_events
    csca_setup_gather_events
  end
  #--------------------------------------------------------------------------
  # Cache gather events for fast access.
  #--------------------------------------------------------------------------
  def csca_cache_gather_events
    @gather_events = []
    @events.each_value do |event|
      @gather_events.push(event) if event.gather_event?
    end
  end
  #--------------------------------------------------------------------------
  # Set up gather events
  #--------------------------------------------------------------------------
  def csca_setup_gather_events
    return if @gather_events == []
    @gather_events.each do |event|
      event.csca_gather_check_spawn
    end
  end
  #--------------------------------------------------------------------------
  # Alias Method; Detect/Set Up Starting Map Event
  #--------------------------------------------------------------------------
  alias :csca_gather_event_start :setup_starting_map_event
  def setup_starting_map_event
    event = @events.values.find {|event| event.starting }
    return if event.nil?
    event.gather_event? ? event.csca_gather_pre : csca_gather_event_start
  end
  #--------------------------------------------------------------------------
  # Gathering Processing start
  #--------------------------------------------------------------------------
  def csca_gather_start(event, node)
    @gathering_event = event
    @gathering_node = node
    @rare_gather_item = nil
    @gather_item = get_gather_item(node.gather_item)
    @gather_item_amount = csca_gather_calculate_item_amount
    if csca_gather_rare_find?
      @rare_gather_item = get_gather_item(node.gather_item_rare)
      @rare_gather_item_amount = csca_gather_calculate_rare_item_amount
    end
    @gathering = true
    Audio.se_play(node.gather_sound) unless node.gather_sound.nil?
  end
  #--------------------------------------------------------------------------
  # Gathering Processing end
  #--------------------------------------------------------------------------
  def csca_gather_end
    @gathering_node.gather_node
    $csca.change_profession_exp(@gathering_node.type, @gathering_node.exp) if $imported["CSCA-Professions"]
    @gathering_event.animation_id = @gathering_node.gather_anim unless @gathering_node.gather_anim.nil?
    @gathering_event.csca_gather_post
  end
  #--------------------------------------------------------------------------
  # Get item from node item array
  #--------------------------------------------------------------------------
  def get_gather_item(item)
    return case item.type
    when :item; $data_items[item.id]
    when :weapon; $data_weapons[item.id]
    when :armor; $data_armors[item.id]
    end
  end
  #--------------------------------------------------------------------------
  # Calculate gather item amount
  #--------------------------------------------------------------------------
  def csca_gather_calculate_item_amount
    node = @gathering_node
    base = node.gather_item.amount
    add = CSCA::GATHERING::ADD_VARIANCE_ONLY ? true : rand(2) == 0
    add ? base += rand(1 + node.amount_variance) : base -= rand(1 + node.amount_variance)
    if $imported["CSCA-Professions"]
      profession = $csca.get_profession(node.type)
      base += (profession.level * node.profession_level_effect).to_i
    end
    base = node.min_amount if base < node.min_amount
    return base
  end
  #--------------------------------------------------------------------------
  # Calculate rare gather item amount
  #--------------------------------------------------------------------------
  def csca_gather_calculate_rare_item_amount
    node = @gathering_node
    base = node.gather_item_rare.amount
    add = CSCA::GATHERING::ADD_VARIANCE_ONLY ? true : rand(2) == 0
    add ? base += rand(1 + node.rare_amount_variance) : base -= rand(1 + node.rare_amount_variance)
    base = node.rare_min_amount if base < node.rare_min_amount
    return base
  end
  #--------------------------------------------------------------------------
  # Determine if rare item drops
  #--------------------------------------------------------------------------
  def csca_gather_rare_find?
    return false if @gathering_node.gather_item_rare.nil?
    @gathering_node.rare_chance > rand(100)
  end
end
#==============================================================================
# ** Game_Event
#------------------------------------------------------------------------------
# Added Gathering Event data
#==============================================================================
class Game_Event < Game_Character
  #--------------------------------------------------------------------------
  # Alias Method; Object Initialization
  #--------------------------------------------------------------------------
  alias :csca_gather_init :initialize
  def initialize(*args)
    csca_gather_init(*args)
    @gather_event = false
    @node = nil
    @spawned = false
    csca_gather_get_node
  end
  #--------------------------------------------------------------------------
  # Determine event's node
  #--------------------------------------------------------------------------
  def csca_gather_get_node
    @list.each do |command|
      if command.code == 108 && command.parameters[0] =~ /<gather_node: (.*)>/i
        @gather_event = true
        @through = true
        @node = $csca.get_node($1.to_sym)
        @last_gather_time = csca_gather_get_last_gather_time(@map_id, @id)
        break
      end
    end
  end
  #--------------------------------------------------------------------------
  # Determine event's last gather time
  #--------------------------------------------------------------------------
  def csca_gather_get_last_gather_time(map_id, event_id)
    key = [map_id, event_id]
    if $csca.gather_information[key].nil?
      $csca.gather_information[key] = {:last_gather_time => 0, :times_gathered => 0}
    end
    return $csca.gather_information[key][:last_gather_time]
  end
  #--------------------------------------------------------------------------
  # Event can be gathered?
  #--------------------------------------------------------------------------
  def gather_event?
    @gather_event
  end
  #--------------------------------------------------------------------------
  # Event is spawned?
  #--------------------------------------------------------------------------
  def spawned?
    @spawned
  end
  #--------------------------------------------------------------------------
  # Event can spawn?
  #--------------------------------------------------------------------------
  def csca_gather_spawn_requirements_met?
    return false unless @node.required_switch.nil? || $game_switches[@node.required_switch]
    return true if @last_gather_time == 0 && @node.start_spawned
    return Graphics.frame_count - @last_gather_time >= @node.spawn_time
  end
  #--------------------------------------------------------------------------
  # Spawn event?
  #--------------------------------------------------------------------------
  def csca_gather_check_spawn
    csca_gather_spawn if csca_gather_spawn_requirements_met?
  end
  #--------------------------------------------------------------------------
  # Party has required profession level?
  #--------------------------------------------------------------------------
  def csca_gather_levelreq_met?
    $csca.get_profession(@node.type).level >= @node.level_req
  end
  #--------------------------------------------------------------------------
  # Party has required item to gather event?
  #--------------------------------------------------------------------------
  def csca_gather_item_tier_req_met?
    tier_list = @node.nodetype.item_tiers
    return true if tier_list.nil?
    min_tier = @node.min_tier
    for tier in min_tier...tier_list.size
      item = case tier_list[tier][0]
      when :item; $data_items[tier_list[tier][1]]
      when :armor; $data_armors[tier_list[tier][1]]
      when :weapon; $data_weapons[tier_list[tier][1]]
      end
      return true if $game_party.has_item?(item, true)
    end
    return false
  end
  #--------------------------------------------------------------------------
  # Spawn Gather Event
  #--------------------------------------------------------------------------
  def csca_gather_spawn
    @through = false
    set_graphic(@node.graphic[:file], @node.graphic[:index])
    set_direction(@node.graphic[:dir])
    @spawned = true
  end
  #--------------------------------------------------------------------------
  # Pre Gather processing, checks requirements
  #--------------------------------------------------------------------------
  def csca_gather_pre
    clear_starting_flag
    return unless spawned?
    if $imported["CSCA-Professions"] && !csca_gather_levelreq_met?
      csca_gather_display_levelreq_text
      return
    end
    unless csca_gather_item_tier_req_met?
      csca_gather_display_itemreq_text
      return
    end
    $game_map.csca_gather_start(self, @node)
  end
  #--------------------------------------------------------------------------
  # Post Gather processing
  #--------------------------------------------------------------------------
  def csca_gather_post
    @through = true
    set_graphic("", 0)
    $csca.gather_information[[@map_id, @id]][:last_gather_time] = Graphics.frame_count
    @spawned = false
  end
  #--------------------------------------------------------------------------
  # Display level requirement text
  #--------------------------------------------------------------------------
  def csca_gather_display_levelreq_text
    s1, s2, s3 = @node.level_req, $csca.get_profession(@node.type).name, @node.actiontext
    $game_message.add(sprintf(CSCA::GATHERING::LEVELREQ_TEXT, s1, s2, s3))
  end
  #--------------------------------------------------------------------------
  # Display item tier requirement text
  #--------------------------------------------------------------------------
  def csca_gather_display_itemreq_text
    s2, s3 = @node.get_minimum_item.name, @node.actiontext
    s1 = $csca.is_a_vowel(s2[0].upcase, s2[1] == " ") ? "n" : ""
    $game_message.add(sprintf(CSCA::GATHERING::ITEMREQ_TEXT, s1, s2, s3))
  end
end
#==============================================================================
# ** Game_Player
#------------------------------------------------------------------------------
# Disallow moving during gathering.
#Aliases: movable?
#==============================================================================
class Game_Player < Game_Character
  #--------------------------------------------------------------------------
  # Alias Method; Determine if Movement is Possible
  #--------------------------------------------------------------------------
  alias :csca_gather_movable? :movable?
  def movable?
    return false if $game_map.gathering
    csca_gather_movable?
  end
end
#==============================================================================
# ** Scene_Map
#------------------------------------------------------------------------------
# Handles gathering window.
# Aliases: scene_change_ok?, create_all_windows, update
#==============================================================================
class Scene_Map < Scene_Base
  #--------------------------------------------------------------------------#
  # Alias method; Frame Update                                               #
  #--------------------------------------------------------------------------#
  alias :csca_gather_update :update
  def update
    csca_gather_update
    @gather_window.open if !@gather_window.opened && $game_map.gathering
    @gather_window.close if @gather_window.opened && !$game_map.gathering
  end
  #--------------------------------------------------------------------------#
  # Alias method; disallow scene change while gathering                      #
  #--------------------------------------------------------------------------#
  alias :csca_gather_req :scene_change_ok?
  def scene_change_ok?
    !$game_map.gathering && csca_gather_req
  end
  #--------------------------------------------------------------------------#
  # Alias method; create all windows                                         #
  #--------------------------------------------------------------------------#
  alias :csca_create_gather_window :create_all_windows
  def create_all_windows
    csca_create_gather_window
    create_gather_window
  end
  #--------------------------------------------------------------------------#
  # Create Gather Window                                                              #
  #--------------------------------------------------------------------------#
  def create_gather_window
    @gather_window = CSCA_Window_Gathering.new(Graphics.width/4,0)
    @gather_window.close
  end
end
#==============================================================================
# ** CSCA_Window_Fishing
#------------------------------------------------------------------------------
# Displays time bar and catch.
#==============================================================================
class CSCA_Window_Gathering < Window_Base
  attr_reader :opened
  #--------------------------------------------------------------------------#
  # Initialize                                                               #
  #--------------------------------------------------------------------------#
  def initialize(x,y,w = Graphics.width/2,h = line_height*3)
    super(x,y,w,h)
    self.opacity = 0
    self.contents_opacity = 0
    @time_left = 0
    @opened = false
    @display_item = false
    refresh
  end
  #--------------------------------------------------------------------------#
  # Refresh                                                                  #
  #--------------------------------------------------------------------------#
  def refresh
    contents.clear
    update_gauge if $game_map.gathering
  end
  #--------------------------------------------------------------------------#
  # Update Gauge                                                             #
  #--------------------------------------------------------------------------#
  def update_gauge
    if @display_item
      s1 = "Received: "
      s2 = "Rare Item! "
      s3 = $game_map.gather_item_amount.to_s + "x"
      s4 = $game_map.rare_gather_item_amount.to_s + "x"
      x = text_size(s1).width
      x2 = text_size(s2).width
      x3 = x + text_size(s3).width
      x4 = x2 + text_size(s4).width
      change_color(system_color)
      draw_text(0,0,contents.width,line_height,s1)
      if $game_map.rare_gather_item
        change_color(text_color(CSCA::GATHERING::RARE_COLOR))
        draw_text(0,line_height,contents.width,line_height,s2)
      end
      change_color(normal_color)
      draw_text(x,0,contents.width-x,line_height,s3)
      draw_icon($game_map.gather_item.icon_index, x3, 0)
      draw_text(x3+24,0,contents.width-x3-24,line_height, $game_map.gather_item.name)
      if $game_map.rare_gather_item
        draw_text(x2,line_height,contents.width-x,line_height,s4)
        draw_icon($game_map.rare_gather_item.icon_index, x4, line_height)
        draw_text(x4+24,line_height,contents.width-x4-24,line_height, $game_map.rare_gather_item.name)
      end
      check_input
    else
      text = sprintf(CSCA::GATHERING::GATHER_TEXT, node.name)
      draw_text(0, 0, contents.width, line_height, text, 1)
      draw_gauge(0,line_height,contents.width,get_rate,
        text_color(node.color1),text_color(node.color2))
      draw_text(0,line_height,contents.width,line_height,sprintf("%1.2f%",get_rate*100), 1)
      if @time_left >= node.gather_time
        Audio.se_play(node.gather_end_sound) unless node.gather_end_sound.nil?
        $game_party.gain_item($game_map.gather_item, $game_map.gather_item_amount)
        unless $game_map.rare_gather_item.nil?
          $game_party.gain_item($game_map.rare_gather_item, $game_map.rare_gather_item_amount)
        end
        @display_item = true
        @time_left = node.gather_time
      end
    end
  end
  #--------------------------------------------------------------------------#
  # get Gauge Rate                                                           #
  #--------------------------------------------------------------------------#
  def get_rate
    @time_left.to_f/node.gather_time
  end
  #--------------------------------------------------------------------------#
  # Game map node                                                          #
  #--------------------------------------------------------------------------#
  def node
    $game_map.gathering_node
  end
  #--------------------------------------------------------------------------#
  # Frame Update                                                             #
  #--------------------------------------------------------------------------#
  def update
    return unless $game_map.gathering
    refresh
    @time_left += 1 if @time_left < node.gather_time
  end
  #--------------------------------------------------------------------------#
  # Open Window                                                              #
  #--------------------------------------------------------------------------#
  def open
    @time_left = 0
    self.opacity = 255
    self.contents_opacity = 255
    @opened = true
  end
  #--------------------------------------------------------------------------#
  # Close Window                                                             #
  #--------------------------------------------------------------------------#
  def close
    @time_left = 0
    self.opacity = 0
    self.contents_opacity = 0
    @opened = false
  end
  #--------------------------------------------------------------------------#
  # Input for closing fishing window                                         #
  #--------------------------------------------------------------------------#
  def check_input
    if Input.press?(:C)
      $game_map.gathering = false
      close
      @display_item = false
      $game_map.csca_gather_end
    end
  end
end