=begin
CSCA Light Effects
version: 1.1.0
Created by: Casper Gaming (http://www.caspergaming.com/)

Compatibility:
Made for RPGVXAce
IMPORTANT: ALL CSCA Scripts should be compatible with each other unless
otherwise noted.

FFEATURES
Easily customize and create light effects. 12 preset light effects.
Turn lights on/off in game.

SETUP
Set up required. Instructions below.
================================================================================
UPDATES
version 1.1.0
- Added ability to make lights not dependant on a switch.
- Added ability to alter light Z values
================================================================================
CREDIT:
Free to use in noncommercial games if credit is given to:
Casper Gaming (http://www.caspergaming.com/)

To use in a commercial game, please purchase a license here:
http://www.caspergaming.com/licenses.html

TERMS:
http://www.caspergaming.com/terms_of_use.html
=end
module CSCA
  module LIGHTS
    EFFECTS = [] # Don't Touch
    #
    #Set up your EFFECTS like this:
    #EFFECTS[x] = ["NAME", graphic, zoom_x, zoom_y, opacity, blend_type, tone,
    #              switch, rand_opacity, adjust_x, adjust_y, custom_z]
    #
    # "NAME" is the type of Light that you type into the comment of your event.
    # If the light has a name of "FIRE" your event comment will be: "LIGHT: FIRE"
    #
    # Graphic is the graphic to be used. Located in the Graphics/Pictures folder.
    #
    # zoom_x and zoom_y are the sprite's x and y-axis zoom levels. 1 is normal.
    #
    # opacity is how transparent the sprite is. (0-255)
    # blend type is how the sprite blends(0: normal, 1: addition, 2: subtraction)
    #
    # Tone is the color tone. For no tone change, use "Tone.new". Optional 4th
    # value can be added, this is the gray value.
    #
    # switch is a switch ID. When this switch is ON, lights of this type will
    # turn on. When the switch is OFF, lights of this type will turn off.
    #
    # rand_opacity is used to create a flicker. The opacity will randomize
    # itself from the original opacity by the numebr entered. Higher numbers
    # have more noticable flicker. Set to 0 for no effect(a steady light).
    #
    # adjust_x and adjust_y are values added to the x and y values to fine tune
    # how each light displays. In pixels. Set to 0 for no effect.
    #
    # custom_z is used tod efine the Z value of a light. The higher the Z value,
    # the closer to the screen it is.
    #
    # Effects have already been set up for you to be similar to Thomas Edison
    # VX. You can customize them or create new effects yourself, too!
    # The preset light effects are:
    # GROUND1 - Medium steady white light.
    # GROUND2 - Medium white light with slight flicker.
    # GROUND3 - Small steady red light.
    # GROUND4 - Medium steady green light.
    # GROUND5 - Medium steady blue light.
    # FIRE - Large red light with slight flicker.
    # LIGHT1 - Small steady white light.
    # LIGHT2 - X-Large steady white light.
    # LIGHT3 - Small white light with slight flicker.
    # TORCH1 - X-Large red light with heavy flicker.
    # TORCH2 - X-Large red light with slight flicker.
    # TORCH3 - Large white light with slight flicker.
    #
    # TITLEFIRE - Same as FIRE, but not dependant on a switch (always on) for
    # use in CSCA Title System (Get that script here: )
    #
    # TITLE_GROUND2 - Same as GROUND2, but not dependant on a switch.
    #
    EFFECTS[0] = ["FIRE", "Light", 3, 3, 100, 1, Tone.new(255,-100,-255), 1, 10, 0, 0, 1000]
    EFFECTS[1] = ["LIGHT1", "Light", 1, 1, 150, 1, Tone.new, 2, 0, 0, 0, 1000]
    EFFECTS[2] = ["LIGHT2", "Light", 6, 6, 150, 1, Tone.new, 3, 0, 0, 0, 1000]
    EFFECTS[3] = ["LIGHT3", "Light", 1, 1, 150, 1, Tone.new, 4, 10, 0, 0, 1000]
    EFFECTS[4] = ["TORCH1", "Light", 6, 6, 150, 1, Tone.new(255,-100,-255), 5, 30, 0, 0, 1000]
    EFFECTS[5] = ["TORCH2", "Light", 6, 6, 150, 1, Tone.new(255,-100,-255), 6, 10, 0, 0, 1000]
    EFFECTS[6] = ["TORCH3", "Light", 3, 3, 100, 1, Tone.new, 7, 10, 0, 0, 1000]
    EFFECTS[7] = ["GROUND1", "Light", 2, 2, 100, 1, Tone.new, 8, 0, 0, 0, 1000]
    EFFECTS[8] = ["GROUND2", "Light", 2, 2, 100, 1, Tone.new, 9, 10, 0, 0, 1000]
    EFFECTS[9] = ["GROUND3", "Light", 2, 2, 100, 1, Tone.new(255,-255,-255,255), 10, 0, 0, 0, 1000]
    EFFECTS[10] = ["GROUND4", "Light", 2, 2, 100, 1, Tone.new(-255,255,-255,100), 11, 0, 0, 0, 1000]
    EFFECTS[11] = ["GROUND5", "Light", 2, 2, 100, 1, Tone.new(-255,255,255,100), 12, 0, 0, 0, 1000]

    EFFECTS[12] = ["TITLE_FIRE", "Light", 3, 3, 100, 1, Tone.new(255,-100,-255), 0, 10, 0, 0, 5]
    EFFECTS[13] = ["TITLE_GROUND2", "Light", 1, 1, 150, 1, Tone.new, 0, 10, 0, 0, 5]
    #
    # Script Calls:
    #
    # To refresh lights(if an event was erased or changed pages and should no
    # longer be lit up), make the following script call:
    # $game_map.csca_light_need_refresh = true
    #
    # To dispose specific lights, use the following script call:
    # $game_map.csca_dispose_lights = [x,y,z,etc]
    # where x, y, and z would be the event id's of events showing light effects.
    #
  end
end
#----------------------------------End Setup----------------------------------#
$imported = {} if $imported.nil?
$imported["CSCA-LightEffects"] = true
#==============================================================================
# ** Game_Map
#------------------------------------------------------------------------------
# Handles Light Effects
#Aliases: initialize
#==============================================================================
class Game_Map
  attr_accessor :csca_light_need_refresh
  attr_accessor :csca_dispose_lights
  #--------------------------------------------------------------------------#
  # Alias Method; initialize                                                 #
  #--------------------------------------------------------------------------#
  alias :csca_le_init :initialize
  def initialize
    csca_le_init
    @csca_light_need_refresh = false
    @csca_dispose_lights = nil
  end
end
#==============================================================================
# ** Spriteset_Map
#------------------------------------------------------------------------------
# Displays Lights on the map screen.
#Aliases: initialize, dispose, update
#==============================================================================
class Spriteset_Map
  #--------------------------------------------------------------------------#
  # Alias Method; initialize                                                 #
  #--------------------------------------------------------------------------#
  alias :csca_le_init :initialize
  def initialize
    csca_init_light_effects
    csca_le_init
  end
  #--------------------------------------------------------------------------#
  # Alias Method; dispose                                                    #
  #--------------------------------------------------------------------------#
  alias :csca_le_dispose :dispose
  def dispose
    csca_dispose_light_effects
    csca_le_dispose
  end
  #--------------------------------------------------------------------------#
  # Alias Method; update                                                     #
  #--------------------------------------------------------------------------#
  alias :csca_le_update :update
  def update
    csca_update_light_effects
    csca_le_update
  end
  #--------------------------------------------------------------------------#
  # Dispose light effects                                                    #
  #--------------------------------------------------------------------------#
  def csca_dispose_light_effects
    for effect in @lights
      effect.light.dispose
    end
    @lights = nil
  end
  #--------------------------------------------------------------------------#
  # Determine type of effect                                                 #
  #--------------------------------------------------------------------------#
  def get_effect(type)
    CSCA::LIGHTS::EFFECTS.each do |effect|
      if effect[0] == type
        return effect
      end
    end
  end
  #--------------------------------------------------------------------------#
  # Initialize Light Effects                                                 #
  #--------------------------------------------------------------------------#
  def csca_init_light_effects
    @lights = []
    $game_map.events.values.each do |event|
      next if event.list.nil?
      for i in 0...event.list.size
        list = event.list[i]
        if list.code == 108 && list.parameters[0].include?("LIGHT: ")
          param = list.parameters[0]
          type = param[7, param.length]
          light = get_effect(type)
          light_effect = CSCA_Light.new(event, type, light[1])
          @lights.push(light_effect)
          next
        end
      end
    end
    csca_setup_light_effects
  end
  #--------------------------------------------------------------------------#
  # Setup Light Effect Properties                                            #
  #--------------------------------------------------------------------------#
  def csca_setup_light_effects
    for effect in @lights
      le = get_effect(effect.type)
      effect.light.zoom_x = le[2]
      effect.light.zoom_y = le[3]
      effect.light.opacity = le[4]
      effect.light.blend_type = le[5]
      effect.light.tone = le[6]
      effect.light.z = le[11]
      effect.save_effect = le
      width = (effect.light.width/2)*effect.light.zoom_x
      height = (effect.light.height/2)*effect.light.zoom_y
      effect.light.x = effect.event.screen_x - width + le[9]
      effect.light.y = effect.event.screen_y - height + le[10]
    end
  end
  #--------------------------------------------------------------------------#
  # Update Light Effects                                                     #
  #--------------------------------------------------------------------------#
  def csca_update_light_effects
    for effect in @lights
      next if effect.light.disposed?
      le = effect.save_effect
      effect.light.visible = le[7] == 0 ? true : $game_switches[le[7]]
      width = (effect.light.width/2)*effect.light.zoom_x
      height = (effect.light.height/2)*effect.light.zoom_y
      effect.light.x = effect.event.screen_x - width + le[9]
      effect.light.y = effect.event.screen_y - height + le[10]
      effect.light.opacity = rand(le[8]) + (le[4] - le[8])
    end
    csca_refresh_light_effects if @map_id != $game_map.map_id
    if $game_map.csca_light_need_refresh
      $game_map.csca_light_need_refresh = false
      csca_refresh_light_effects
    end
    if !$game_map.csca_dispose_lights.nil?
      csca_dispose_select_lights($game_map.csca_dispose_lights)
    end
  end
  #--------------------------------------------------------------------------#
  # Refresh Lights                                                           #
  #--------------------------------------------------------------------------#
  def csca_refresh_light_effects
    csca_dispose_light_effects
    csca_init_light_effects
  end
  #--------------------------------------------------------------------------#
  # Dispose Select Lights                                                    #
  #--------------------------------------------------------------------------#
  def csca_dispose_select_lights(ids)
    ids.each do |id|
      for effect in @lights
        if effect.event.id == id
          le = effect 
          break
        end
      end
      le.light.dispose
    end
    $game_map.csca_dispose_lights = nil
  end
end
#==============================================================================
# ** CSCA_Light
#------------------------------------------------------------------------------
# Light class. Handles lights.
#==============================================================================
class CSCA_Light
  attr_accessor :light
  attr_accessor :event
  attr_accessor :type
  attr_accessor :save_effect
  #--------------------------------------------------------------------------#
  # Object Initialization                                                    #
  #--------------------------------------------------------------------------#
  def initialize(event, type, graphic = "Light")
    @light = Sprite.new
    @light.bitmap = Cache.picture(graphic)
    @light.visible = true
    @event = event
    @type = type
    @save_effect = []
  end
end