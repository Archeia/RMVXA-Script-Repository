=begin
CSCA Splash Screen
version: 1.1.0 (Released: January 09, 2013)
Created by: Casper Gaming (http://www.caspergaming.com/)

Compatibility:
Made for RPGVXAce
IMPORTANT: ALL CSCA Scripts should be compatible with each other unless
otherwise noted.

FFEATURES
Easy splash screen before title scene.

SETUP
Set up required. Instructions below.
================================================================================
UPDATES
version 1.1.0
- Added handling for multiple images.
================================================================================
CREDIT:
Free to use in noncommercial games if credit is given to:
Casper Gaming (http://www.caspergaming.com/)

To use in a commercial game, please purchase a license here:
http://www.caspergaming.com/licenses.html

TERMS:
http://www.caspergaming.com/terms_of_use.html
=end
module CSCA
  module SPLASH
    IMAGES = ["Graphics/System/Splash.png"]
    # Images shown in splash screen.
    
    TRANSITION_SPEED = 5 # Speed images fade in/out if more than 1.
    AUTO = true # Automatically go to next image after a certain amount of time?
    TIME = 300 # Time in frames (60f = 1sec) to wait before auto continue
  end
end
$imported = {} if $imported.nil?
$imported["CSCA-SplashScreen"] = true
#==============================================================================
# ** CSCA_Scene_Splash
#------------------------------------------------------------------------------
# This class performs the splash screen processing.
#==============================================================================
class CSCA_Scene_Splash < Scene_Base
  #--------------------------------------------------------------------------
  # Start Processing
  #--------------------------------------------------------------------------
  def start
    super
    SceneManager.clear
    Graphics.freeze
    RPG::BGS.stop
    RPG::BGM.stop
    @time = 0
    @order = 0
    @image_need_change = false
    @fade = :in
    create_image(@order)
  end
  #--------------------------------------------------------------------------
  # Get Transition Speed
  #--------------------------------------------------------------------------
  def transition_speed
    return 20
  end
  #--------------------------------------------------------------------------
  # Termination Processing
  #--------------------------------------------------------------------------
  def terminate
    super
    dispose_image
  end
  #--------------------------------------------------------------------------
  # Create Sprite
  #--------------------------------------------------------------------------
  def create_image(image)
    @sprite = Sprite.new
    @sprite.opacity = 0 if @order > 0
    @sprite.bitmap = Bitmap.new(CSCA::SPLASH::IMAGES[image])
    center_sprite(@sprite)
  end
  #--------------------------------------------------------------------------
  # Free Sprite
  #--------------------------------------------------------------------------
  def dispose_image
    @sprite.bitmap.dispose
    @sprite.dispose
  end
  #--------------------------------------------------------------------------
  # Move Sprite to Screen Center
  #--------------------------------------------------------------------------
  def center_sprite(sprite)
    sprite.ox = sprite.bitmap.width / 2
    sprite.oy = sprite.bitmap.height / 2
    sprite.x = Graphics.width / 2
    sprite.y = Graphics.height / 2
  end
  #--------------------------------------------------------------------------
  # Update
  #--------------------------------------------------------------------------
  def update
    super
    @time += 1 unless @image_need_change
    if continue?
      @order += 1 unless @image_need_change
      if @order >= CSCA::SPLASH::IMAGES.length
        fadeout_all
        SceneManager.goto(Scene_Title)
      else
        unless @image_need_change
          @fade = :out
          @time = 0
          @image_need_change = true
        end
      end
    end
    change_image if @image_need_change
  end
  #--------------------------------------------------------------------------
  # Fade In/Out
  #--------------------------------------------------------------------------
  def change_image
    if @sprite.opacity <= 0
      change_sprite
      @fade = :in
    end
    case @fade
    when :out; @sprite.opacity -= CSCA::SPLASH::TRANSITION_SPEED
    when :in; @sprite.opacity += CSCA::SPLASH::TRANSITION_SPEED
    end
    @image_need_change = false if @fade == :in && @sprite.opacity >= 255
  end
  #--------------------------------------------------------------------------
  # Change Sprite
  #--------------------------------------------------------------------------
  def change_sprite
    dispose_image
    create_image(@order)
  end
  #--------------------------------------------------------------------------
  # OK to continue to title?
  #--------------------------------------------------------------------------
  def continue?
    Input.press?(:C) || Input.press?(:A) || Input.press?(:B) || time_up?
  end
  #--------------------------------------------------------------------------
  # OK to continue to title?
  #--------------------------------------------------------------------------
  def time_up?
    CSCA::SPLASH::AUTO && @time >= CSCA::SPLASH::TIME
  end
end
#==============================================================================
# ** SceneManager
#------------------------------------------------------------------------------
# Changed the first scene class.
#Overwrites: first_scene_class
#==============================================================================
module SceneManager
  #--------------------------------------------------------------------------
  # Overwrite method; Get First Scene Class
  #--------------------------------------------------------------------------
  def self.first_scene_class
    $BTEST ? Scene_Battle : CSCA_Scene_Splash
  end
end