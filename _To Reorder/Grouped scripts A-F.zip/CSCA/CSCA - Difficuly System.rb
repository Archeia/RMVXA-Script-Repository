=begin
CSCA Difficulty System
version: 1.0.3 (Released: April 6, 2013)
Created by: Casper Gaming (http://www.caspergaming.com/)

Compatibility:
Made for RPGVXAce
IMPORTANT: ALL CSCA Scripts should be compatible with each other unless
otherwise noted.
Requires CSCA Core script v1.0.4 +

FFEATURES
Allows you to have a difficulty selection, which alters the difficulty of the
game by changing encoutner rates, enemy stats, and exp & gold gains.

SETUP
Setup below required. Intructions below.
================================================================================
UPDATES
version 1.0.1
- Aliased param_base
- Changed hash keys to symbols

version 1.0.2
-Difficulty array is now 0 based for all script calls

version 1.0.3
- Proeprly aliased initialize in CSCA_Core... *facepalm*
================================================================================
CREDIT:
Free to use in noncommercial games if credit is given to:
Casper Gaming (http://www.caspergaming.com/)

To use in a commercial game, please purchase a license here:
http://www.caspergaming.com/licenses.html

TERMS:
http://www.caspergaming.com/terms_of_use.html
=end
module CSCA
  module DIFFICULTY
    #===========================================================================
    # Script Calls
    #
    # Difficulty acts as a variable. To use it in a conditional branch, use
    # the following syntax: $csca.difficulty == x
    # where x is the difficulty. Difficulty values start at 1. It is set to
    # 0 before selection.
    #
    # To call the Difficulty Select Scene, use the following script call:
    # scene = CSCA_Scene_DifficultySelect
    # SceneManager.call(scene)
    #===========================================================================
    DIFFICULTIES = [] # Don't Touch
    HEADER = "Difficulty Select" # Header window text.
    
    ENCRATE = "Encounter Rate: " # Text for each modified value shown in window.
    ENEMYEXP = "Enemy EXP: "     # Text for each modified value shown in window.
    ENEMYGOLD = "Enemy Gold: "   # Text for each modified value shown in window.
    ENEMYSTATS = "Enemy Stats: " # Text for each modified value shown in window.
    MODIFY_HPMP = false # Allow "enemystats" to modify HP and MP too?
    
    #Define difficulties the following way:
    #DIFFICULTIES[x] = {
    #"name" => "Easy",   # The name of the difficulty.
    #"enemyexp" => 110,  # The experience modifier. This number is a percentage.
    #"enemygold" => 120, # The gold modifier. This number is a percentage.
    #"encrate" => 50,    # Encoutner rate modifier. This number is a percentage.
    #"enemystats" => 80, # Base stat modifier. This number is a percentage.
    #                    # MP/HP are NOT modified by this unless changed above.
    #"descr" => ["Line One", # Description text. Make sure the proper format
    #            "Line Two", # followed.
    #            "Line Three"] # Default resolutions support up to 6 lines of
    #}                         # Descriptive text.
    #
    # A modifier with a percent value of 100 represents no change(normal).
    # Greater than 100% is an increase; lower than 100% is a decrease.
    
    DIFFICULTIES[0] = {
    :name => "Story",
    :enemyexp => 120,
    :enemygold => 150,
    :encrate => 0,
    :enemystats => 50,
    :descr => ["Line One",
                "Line Two",
                "Line Three"]
    }
    
    DIFFICULTIES[1] = {
    :name => "Easy",
    :enemyexp => 110,
    :enemygold => 120,
    :encrate => 50,
    :enemystats => 80,
    :descr => ["Line One",
                "Line Two",
                "Line Three"]
    }
    
    DIFFICULTIES[2] = {
    :name => "Normal",
    :enemyexp => 100,
    :enemygold => 100,
    :encrate => 100,
    :enemystats => 100,
    :descr => ["Line One",
                "Line Two",
                "Line Three"]
    }
    
    DIFFICULTIES[3] = {
    :name => "Hard",
    :enemyexp => 95,
    :enemygold => 90,
    :encrate => 110,
    :enemystats => 120,
    :descr => ["Line One",
                "Line Two",
                "Line Three",
                "Line Four"]
    }
    
    DIFFICULTIES[4] = {
    :name => "Insane",
    :enemyexp => 90,
    :enemygold => 80,
    :encrate => 120,
    :enemystats => 150,
    :descr => ["Line One",
                "Line Two",
                "Line Three"]
    }
  end # End Setup.
end
$imported = {} if $imported.nil?
$imported["CSCA-Difficulty"] = true
msgbox('Missing Script: CSCA Core Script! CSCA Difficulty System requires this
script to work properly.') if !$imported["CSCA-Core"]
#==============================================================================
# ** CSCA_Scene_DifficultySelect
#------------------------------------------------------------------------------
# Handles Difficulty Select Screen processing.
#==============================================================================
class CSCA_Scene_DifficultySelect < Scene_MenuBase
  #--------------------------------------------------------------------------#
  # Start Processing                                                         #
  #--------------------------------------------------------------------------#
  def start
    super
    create_head_window
    create_info_window
    create_select_window
  end
  #--------------------------------------------------------------------------#
  # Create Background                                                        #
  #--------------------------------------------------------------------------#
  def create_background
    super
    @background_sprite.tone.set(0, 0, 0, 128)
  end
  #--------------------------------------------------------------------------#
  # Create Header Window                                                     #
  #--------------------------------------------------------------------------#
  def create_head_window
    @head_window = CSCA_Window_Header.new(Graphics.width/6,50,Graphics.width/1.5,
      CSCA::DIFFICULTY::HEADER)
    @head_window.viewport = @viewport
  end
  #--------------------------------------------------------------------------#
  # Create Select Window                                                     #
  #--------------------------------------------------------------------------#
  def create_select_window
    x = Graphics.width/6
    y = @head_window.height + @head_window.y
    w = Graphics.width/4
    h = Graphics.height-148
    @select_window = CSCA_Window_DifficultySelect.new(x, y, w, h)
    @select_window.set_handler(:ok, method(:on_difficulty_select))
    @select_window.viewport = @viewport
    @select_window.help_window = @info_window
    @select_window.activate
  end
  #--------------------------------------------------------------------------#
  # Create Info Window                                                       #
  #--------------------------------------------------------------------------#
  def create_info_window
    x = Graphics.width/6 + Graphics.width/4
    y = @head_window.height + @head_window.y
    w = @head_window.width - Graphics.width/4
    h = Graphics.height-148
    @info_window = CSCA_Window_DifficultyInfo.new(x, y, w, h)
    @info_window.viewport = @viewport
  end
  #--------------------------------------------------------------------------#
  # Select Difficulty                                                        #
  #--------------------------------------------------------------------------#
  def on_difficulty_select
    $csca.difficulty = @select_window.index
    return_scene
  end
end
#==============================================================================
# ** CSCA_Window_SidequestSelect
#------------------------------------------------------------------------------
# Handles selection of sidequests, and updates objectives info.
#==============================================================================
class CSCA_Window_DifficultySelect < Window_Selectable
  #--------------------------------------------------------------------------#
  # Object Initialization                                                    #
  #--------------------------------------------------------------------------#
  def initialize(x,y,width,height)
    super(x,y,width,height)
    @data = []
    refresh
    select(0)
  end
  #--------------------------------------------------------------------------#
  # Get Item Max                                                             #
  #--------------------------------------------------------------------------#
  def item_max
    @data ? @data.size : 1
  end
  #--------------------------------------------------------------------------#
  # Get Item                                                                 #
  #--------------------------------------------------------------------------#
  def item
    @data && index >= 0 ? @data[index] : nil
  end
  #--------------------------------------------------------------------------#
  # Populate item list                                                       #
  #--------------------------------------------------------------------------#
  def make_item_list
    @data = CSCA::DIFFICULTY::DIFFICULTIES
  end
  #--------------------------------------------------------------------------#
  # Draw Items                                                               #
  #--------------------------------------------------------------------------#
  def draw_item(index)
    item = @data[index]
    if item
      rect = item_rect(index)
      name = CSCA::DIFFICULTY::DIFFICULTIES[index][:name]
      draw_text(rect.x, rect.y, contents.width, line_height, name)
    end
  end
  #--------------------------------------------------------------------------#
  # Refresh                                                                  #
  #--------------------------------------------------------------------------#
  def refresh
    make_item_list
    create_contents
    draw_all_items
  end
  #--------------------------------------------------------------------------#
  # Update Help Window                                                       #
  #--------------------------------------------------------------------------#
  def update_help
    @help_window.set_item(index)
  end
end
#==============================================================================
# ** CSCA_Window_SidequestTask
#------------------------------------------------------------------------------
# Displays tasks for each mission.
#==============================================================================
class CSCA_Window_DifficultyInfo < Window_Base
  #--------------------------------------------------------------------------#
  # Object Initialization                                                    #
  #--------------------------------------------------------------------------#
  def initialize(x, y, width, height)
    super(x, y, width, height)
  end
  #--------------------------------------------------------------------------#
  # Set Item                                                                 #
  #--------------------------------------------------------------------------#
  def set_item(index)
    contents.clear
    draw_info(CSCA::DIFFICULTY::DIFFICULTIES[index])
  end
  #--------------------------------------------------------------------------#
  # Draw Tasks                                                               #
  #--------------------------------------------------------------------------#
  def draw_info(difficulty)
    w = contents.width
    h = line_height
    contents.font.bold = true
    draw_text(0,0,w,h,difficulty["name"],1)
    contents.font.bold = false
    contents.font.size = 20
    change_color(system_color)
    draw_text(0,h,w,h,CSCA::DIFFICULTY::ENCRATE)
    draw_text(0,h*2-4,w,h,CSCA::DIFFICULTY::ENEMYSTATS)
    draw_text(0,h*3-8,w,h,CSCA::DIFFICULTY::ENEMYEXP)
    draw_text(0,h*4-12,w,h,CSCA::DIFFICULTY::ENEMYGOLD)
    change_color(normal_color)
    x1 = text_size(CSCA::DIFFICULTY::ENCRATE).width
    x2 = text_size(CSCA::DIFFICULTY::ENEMYSTATS).width
    x3 = text_size(CSCA::DIFFICULTY::ENEMYEXP).width
    x4 = text_size(CSCA::DIFFICULTY::ENEMYGOLD).width
    draw_text(x1,h,w-x1,h,difference(difficulty[:encrate]))
    draw_text(x2,h*2-4,w-x2,h,difference(difficulty[:enemystats]))
    draw_text(x3,h*3-8,w-x3,h,difference(difficulty[:enemyexp]))
    draw_text(x4,h*4-12,w-x4,h,difference(difficulty[:enemygold]))
    y = h*6-20
    difficulty[:descr].each do |text|
      draw_text(0,y,w,h,text)
      y += h-4
    end
  end
  #--------------------------------------------------------------------------#
  # Calculate Value                                                          #
  #--------------------------------------------------------------------------#
  def difference(value)
    value -= 100
    value >= 0 ? pos = "+" : pos = ""
    return pos + value.to_s + "%"
  end
end
#==============================================================================
# ** CSCA_Core
#------------------------------------------------------------------------------
# Adds difficulty information.
#Aliases: initialize
#==============================================================================
class CSCA_Core
  attr_reader :difficulty
  attr_reader :d_enemyexp
  attr_reader :d_enemygold
  attr_reader :d_encrate
  attr_reader :d_enemystats
  #--------------------------------------------------------------------------#
  # Initialize                                                               #
  #--------------------------------------------------------------------------#
  alias :difficulty_init :initialize
  def initialize
    difficulty_init
    @difficulty = 0
    @d_enemyexp = 100
    @d_enemygold = 100
    @d_encrate = 100
    @d_enemystats = 100
  end
  #--------------------------------------------------------------------------#
  # Writer Method                                                            #
  #--------------------------------------------------------------------------#
  def difficulty=(difficulty)
    @difficulty = difficulty
    on_change(difficulty)
  end
  #--------------------------------------------------------------------------#
  # Modify values on difficulty change                                       #
  #--------------------------------------------------------------------------#
  def on_change(difficulty)
    modifier = CSCA::DIFFICULTY::DIFFICULTIES[difficulty]
    @d_enemyexp = modifier[:enemyexp]
    @d_enemygold = modifier[:enemygold]
    @d_encrate = modifier[:encrate]
    @d_enemystats = modifier[:enemystats]
    $game_system.encounter_disabled == (@d_encrate == 0)
    $game_player.make_encounter_count
  end
end
#==============================================================================
# ** Game_Troop
#------------------------------------------------------------------------------
# Modifies enemy drops such as EXP and GOLD
#Aliases: exp_total, gold_total
#==============================================================================
class Game_Troop < Game_Unit
  #--------------------------------------------------------------------------#
  # Alias Method; Calculate Total Experience                                 #
  #--------------------------------------------------------------------------#
  alias :csca_difficulty_exp_total :exp_total
  def exp_total
    (csca_difficulty_exp_total * ($csca.d_enemyexp.to_f/100)).to_i
  end
  #--------------------------------------------------------------------------#
  # Alias Method; Calculate Total Gold                                       #
  #--------------------------------------------------------------------------#
  alias :csca_difficulty_gold_total :gold_total
  def gold_total
    (csca_difficulty_gold_total * ($csca.d_enemygold.to_f/100)).to_i
  end
end
#==============================================================================
# ** Game_Player
#------------------------------------------------------------------------------
# Modifies encounter rate.
#Aliases: make_encounter_count
#==============================================================================
class Game_Player < Game_Character
  alias :csca_difficulty_make_encounter_count :make_encounter_count
  def make_encounter_count
    encrate = $csca.d_encrate
    encrate += 1 if encrate == 0
    nom = csca_difficulty_make_encounter_count
    c = (nom / (encrate.to_f/100)).to_i
    return c
  end
end
#==============================================================================
# ** Game_Enemy
#------------------------------------------------------------------------------
# Modifies base parameters such as ATK and DEF.
#Aliases: param_base
#==============================================================================
class Game_Enemy < Game_Battler
  #--------------------------------------------------------------------------#
  # Alias Method; Get Base Value of Parameter                                #
  #--------------------------------------------------------------------------#
  alias :csca_ds_param_base :param_base
  def param_base(param_id)
    return enemy.params[param_id] if (param_id == 1 || param_id == 0) &&
      !CSCA::DIFFICULTY::MODIFY_HPMP
    (csca_ds_param_base(param_id) * ($csca.d_enemystats.to_f/100)).to_i
  end
end