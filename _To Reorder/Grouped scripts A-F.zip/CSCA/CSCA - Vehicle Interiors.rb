=begin
CSCA Vehicle Interiors!
Created by: Casper Gaming (http://www.caspergaming.com/)

Compatibility:
Made for RPGVXAce
IMPORTANT: ALL CSCA Scripts should be compatible with each other unless
otherwise noted.

UPDATES
Version 1.1
-Fixed bug of map bgm playing very briefly before and after vehicle transfer.
-Fixed bug of CSCA Menu Theme conflicting with map bgm playing after off vehicle.

FFEATURES:
This script will allow you to press a button and be transferred to the interior
of a vehicle if you're currently riding that vehicle. Only Ship & Airship are
supported. To return to the exterior of the vehicle, all you need to do is
call the following script in an event: $game_player.csca_return

How to use these features is explained below in the setup section.
SETUP BELOW IS REQUIRED!

CREDIT:
Free to use in noncommercial games if credit is given to:
Casper Gaming (http://www.caspergaming.com/)

To use in a commercial game, please purchase a license here:
http://www.caspergaming.com/licenses.html

TERMS:
http://www.caspergaming.com/terms_of_use.html
=end
module CSCA_VEHICLE_TRANSFERS # Don't Touch
  
  #########
  # SETUP #
  #########
  
  SMAPID = 2 # Map ID of the map that contains the interior of the ship.
  SXCOORD = 16 # X coordinate you want the player to appear on the Ship Interior.
  SYCOORD = 10 # Y coordinate you want the player to appear on the Ship Interior.
  SDIRECTION = 4 # Direction you want the player facing after transfer to the
                 # Ship Interior. 2 = down, 4 = left, 6 = right, 8 = up
  SFADE = 0 # 0 = black fade, 1 = white fade, 2 = no fade
  
  AMAPID = 3 # Map ID of the map that contains the interior of the airship.
  AXCOORD = 13 # X coordinate you want the player to appear on the Airship
               # Interior.
  AYCOORD = 0 # Y coordinate you want the player to appear on the Airship
              # Interior.
  ADIRECTION = 2 # Direction you want the player facing after transfer to the
                 # Airship Interior. 2 = down, 4 = left, 6 = right, 8 = up
  AFADE = 0 # 0 = black fade, 1 = white fade, 2 = no fade
  
  TRIGGER = :L # Button you wish to start the transfer to the interior map of a
               # vehicle. Keep in mind the default "L" button is actually "Q" on
               # the keyboard.
  
  #############
  # SETUP END #
  #############
  
end # Don't touch this or anything below
class Game_Player < Game_Character
  include CSCA_VEHICLE_TRANSFERS
  
  attr_reader         :bgm_no_play
  
  alias csca_gp_update update
  def update
    csca_gp_update
    csca_vehicle_transfer_input
  end

  def csca_vehicle_transfer_input
    if Input.trigger?(TRIGGER)
      if in_ship?
        @cscavehiclereturn = :ship
        reserve_transfer(SMAPID, SXCOORD, SYCOORD, SDIRECTION)
        $game_temp.fade_type = SFADE
        csca_vehicle_remove
      elsif in_airship?
        @cscavehiclereturn = :airship
        reserve_transfer(AMAPID, AXCOORD, AYCOORD, ADIRECTION)
        $game_temp.fade_type = AFADE
        csca_vehicle_remove
      end
    end
  end
  
  def csca_vehicle_remove
    @cscavehicletransfermap = $game_map.map_id
    @cscavehicletransferx = @x
    @cscavehicletransfery = @y
    @cscavehicletransferdirection = @direction
    @cscavehicleinterior = true
    @followers.synchronize(@x, @y, @direction)
    @vehicle_getting_off = true
    vehicle.get_off
    @move_speed = 4
    @through = false
    @followers.gather
    @vehicle_getting_off
    set_bgm_no_play(true)
    make_encounter_count
  end

  def csca_return
    map_id = @cscavehicletransfermap
    x = @cscavehicletransferx
    y = @cscavehicletransfery
    direction = @cscavehicletransferdirection
    @transparent = true
    reserve_transfer(map_id, x, y, direction)
    $game_temp.fade_type = 0
    @vehicle_type = :ship    if @cscavehiclereturn == :ship
    @vehicle_type = :airship if @cscavehiclereturn == :airship
    @vehicle_getting_on = true
    @followers.gather
    @vehicle_getting_on
    @cscavehicleinterior = false
  end
  
  def csca_vehicle_transfer?
    @cscavehicleinterior
  end
  
  def set_bgm_no_play(tf)
    @bgm_no_play = tf
  end
  
end
class Game_Map
  alias csca_vi_autoplay autoplay
  def autoplay
    if !$game_player.bgm_no_play || map_id == CSCA_VEHICLE_TRANSFERS::AMAPID ||
      map_id == CSCA_VEHICLE_TRANSFERS::SMAPID
      csca_vi_autoplay
    else
      $game_player.set_bgm_no_play(false)
    end
  end
end
class Game_Vehicle < Game_Character
  alias csca_vi_get_off get_off
  def get_off
    if $game_player.csca_vehicle_transfer?
      @driving = false
      @walk_anime = false
      @step_anime = false
      @direction = 4
    else
      csca_vi_get_off
      $game_map.autoplay
    end
  end
end