=begin
CSCA Event Conditions
version: 1.0.0 (Released: November 12, 2012)
Created by: Casper Gaming (http://www.caspergaming.com/)

Compatibility:
Made for RPGVXAce
IMPORTANT: ALL CSCA Scripts should be compatible with each other unless
otherwise noted.

FFEATURES
Allows you to have unlimited event conditions, 

SETUP
Plug and Play. Read below for how to set up your extra event conditions.

CREDIT:
Free to use in noncommercial games if credit is given to:
Casper Gaming (http://www.caspergaming.com/)

To use in a commercial game, please purchase a license here:
http://www.caspergaming.com/licenses.html

TERMS:
http://www.caspergaming.com/terms_of_use.html
=end
#==============================================================================
# SETTING UP EVENTS
#------------------------------------------------------------------------------
# To set up your events to use additional conditions, the FIRST Event Command
# MUST be a comment with the text "EXTRA_CONDITIONS"
#------------------------------------------------------------------------------
# To make a condition, create a new comment Event Command with the text:
# "CONDITON: insert_condition_here"
#
# where you can use any valid ruby expression such as:
# $game_switches[1] == off
# $game_variables[1] != 10
# $game_party.has_item?($data_items[1])
#
# EACH condition should be a separate comment Event Command.
#------------------------------------------------------------------------------
# When you are done listing additional conditions, insert a comment Event
# Command with the text "END_CONDITIONS"
# Note: This is optional, but it will help performance.
#==============================================================================
$imported = {} if $imported.nil?
$imported["CSCA-EventConditions"] = true
#==============================================================================
# ** Game_Event
#------------------------------------------------------------------------------
# Adds extra conditions through comments.
#Aliases: conditons_met?
#==============================================================================
class Game_Event < Game_Character
  #--------------------------------------------------------------------------#
  # Alias Method; default conditions                                         #
  #--------------------------------------------------------------------------#
  alias :csca_ec_conditions_met? :conditions_met?
  def conditions_met?(page)
    return false unless csca_extra_conditions_met(page)
    csca_ec_conditions_met?(page)
  end
  #--------------------------------------------------------------------------#
  # Process extra conditions                                                 #
  #--------------------------------------------------------------------------#
  def csca_extra_conditions_met(page)
    return true unless page.list[0].code == 108
    return true unless page.list[0].parameters == ["EXTRA_CONDITIONS"]
    c = page.list
    params = []
    c.each do |param|
      next if param.code != 108
      break if param.parameters == ["END_CONDITIONS"]
      next unless param.parameters[0].include?("CONDITION: ")
      params.push(param.parameters[0])
    end
    return true if params.empty?
    params.each do |param|
      return false unless eval(param[11, param.length])
    end
    return true
  end
end