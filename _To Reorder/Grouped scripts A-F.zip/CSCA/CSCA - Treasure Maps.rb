=begin
CSCA Treasure Maps
version: 1.0.2 (Released: March 14, 2013)
Created by: Casper Gaming (http://www.caspergaming.com/)

Compatibility:
Made for RPGVXAce
IMPORTANT: ALL CSCA Scripts should be compatible with each other unless
otherwise noted.
REQUIRES CSCA Core Script.

FFEATURES:
This script will add a treasure map scene where the player can view pictures
located in Graphics/Pictures/TreasureMaps (case sensitive) after they have the
item that corresponds with that picture. Example: Player gains item Treasure
Map 1, they can then go to this menu and view a screenshot of where some hidden
treasure is.

SETUP
Setup required. Instructions below.

CREDIT:
Free to use in noncommercial games if credit is given to:
Casper Gaming (http://www.caspergaming.com/)

To use in a commercial game, please purchase a license here:
http://www.caspergaming.com/licenses.html

TERMS:
http://www.caspergaming.com/terms_of_use.html
=end
module CSCA # Don't Touch this.
  module TREASURE # Don't Touch this.
    
    SCENE_NAME = "Treasure Maps" # Text shown in the header window.
    UNKNOWN = "???" # Text shown when player doesn't own a map
    
    
    TREASURE_LIST = [] # Don't Touch this
    # The treasure List is set up like this:
    # TREASURE_LIST[0] = ["TreasureName",ItemID,IconID,"Graphic_Filename"]
    # TREASURE_LIST[1] = ["Example",25,2,"Map1"]
    #
    # Note: Map images MUST be located in Graphics/Pictures/TreasureMaps
    # !!!Case sensitive!!! This means MAP1 is NOT the same file as map1 or mAp1
    TREASURE_LIST[0] = ["Test",1,231,"GameOver2"]
    TREASURE_LIST[1] = ["Buried Treasure",2,231,"GameOver2"]
    TREASURE_LIST[2] = ["Secret Treasure",3,231,"DarkSpace1"]
    
    #=======================================================================#
    # End setup, don't touch anything below unless you know what you are    #
    # doing.                                                                #
    #=======================================================================#
  end
end
$imported = {} if $imported.nil?
$imported["CSCA-TreasureMaps"] = true
msgbox('Missing Script: CSCA Core Script! CSCA Treasure Maps requires this
script to work properly.') if !$imported["CSCA-Core"]
class Scene_CSCA_TreasureMaps < Scene_MenuBase
  
  def start
    super
    create_head_window
    create_map_window
    create_selection_window
  end
  
  def create_background
    super
    @background_sprite.tone.set(0, 0, 0, 128)
  end
  
  def create_head_window
    @head_window = CSCA_Window_Header.new(0,0,CSCA::TREASURE::SCENE_NAME)
    @head_window.viewport = @viewport
  end
  
  def create_selection_window
    @command_window = CSCA_Window_TreasureMapsSelect.new(Graphics.width/4,@head_window.height,Graphics.width/2,224)
    @command_window.viewport = @viewport
    @command_window.help_window = @map_window
    @command_window.set_handler(:ok,     method(:on_category_ok))
    @command_window.set_handler(:cancel, method(:return_scene))
    @command_window.activate
  end
  
  def create_map_window
    @map_window = CSCA_Window_TreasureMap.new(0,@head_window.height,Graphics.width,Graphics.height-@head_window.height)
    @map_window.viewport = @viewport
    @map_window.set_handler(:cancel, method(:on_map_cancel))
    @map_window.hide
  end
  
  def on_category_ok
    @command_window.deactivate
    @command_window.hide
    @map_window.show
    @map_window.activate
  end
  
  def on_map_cancel
    @map_window.deactivate
    @command_window.activate
    @command_window.show
    @map_window.hide
  end
  
end
class CSCA_Window_TreasureMap < Window_Selectable
  
  def initialize(x,y,width,height)
    super
    refresh
  end
  
  def cursor_movable?
    return false
  end
  
  def set_item(index)
    bitmap = Bitmap.new("Graphics/Pictures/TreasureMaps/"+CSCA::TREASURE::TREASURE_LIST[index][3])
    rect = Rect.new(0,0,bitmap.width,bitmap.height)
    x = (contents.width / 2) - (bitmap.width / 2)
    y = (contents.height / 2) - (bitmap.height / 2)
    if bitmap.width > contents.width && bitmap.height > contents.height
      target = Rect.new(0, 0, contents.width, contents.height)
    elsif bitmap.width > contents.width
      target = Rect.new(0, y, contents.width, bitmap.height)
    elsif bitmap.height > contents.height
      target = Rect.new(x, 0, bitmap.width, contents.height)
    else
      target = Rect.new(x,y,bitmap.width,bitmap.height)
    end
    contents.stretch_blt(target, bitmap, rect, 255)
  end
  
end
class CSCA_Window_TreasureMapsSelect < Window_Selectable
  
  def initialize(x,y,width,height)
    super
    refresh
    select(0)
  end
  
  def item_max
    @data ? @data.size : 1
  end

  def item
    @data && index >= 0 ? @data[index] : nil
  end
  
  def current_item_enabled?
    enable?(index)
  end
  
  def enable?(index)
    $game_party.has_item?($data_items[CSCA::TREASURE::TREASURE_LIST[index][1]])
  end
  
  def make_item_list
    @data = CSCA::TREASURE::TREASURE_LIST
  end
  
  def draw_item(index)
    item = @data[index]
    if item
      rect = item_rect(index)
      draw_map_icon(rect, index)
      change_color(normal_color, enable?(index))
      if $game_party.has_item?($data_items[CSCA::TREASURE::TREASURE_LIST[index][1]])
        name = CSCA::TREASURE::TREASURE_LIST[index][0]
        draw_text(rect.x + 28, rect.y, contents.width - 40, line_height, name)
      else
        draw_unknown_text(rect)
      end
    end
  end
  
  def draw_map_icon(rect, index)
    draw_icon(CSCA::TREASURE::TREASURE_LIST[index][2], rect.x, rect.y, true)
  end
  
  def draw_unknown_text(rect)
    draw_text(rect, sprintf("   %s", CSCA::TREASURE::UNKNOWN))
  end
  
  def refresh
    make_item_list
    create_contents
    draw_all_items
  end
  
  def update_help
    @help_window.set_item(index)
  end
  
end