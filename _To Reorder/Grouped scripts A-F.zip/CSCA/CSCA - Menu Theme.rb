=begin
CSCA Menu Theme
version: 1.2 (Released: July 24, 2012)
Created by: Casper Gaming (http://www.caspergaming.com/)

Compatibility:
Made for RPGVXAce
IMPORTANT: ALL CSCA Scripts should be compatible with each other unless
otherwise noted.

Version History:
Version 1.0
-Original Script

Version 1.1
-Fixed menu theme not going away after common event attached to item/skill used.

Version 1.2
-Fixed wrong music playback after menu close.

FFEATURES:
This script will play a specific BGM in the main menu and other scenes called
from the main menu.

SETUP
This script requires setup further down.
Instructions included below.

CREDIT:
Free to use in noncommercial games if credit is given to:
Casper Gaming (http://www.caspergaming.com/)

To use in a commercial game, please purchase a license here:
http://www.caspergaming.com/licenses.html

TERMS:
http://www.caspergaming.com/terms_of_use.html
=end
module CSCA_MENUTHEME
  
  MUSIC = "Field2" # BGM track that is played during the menu screens.
  
end # END SETUP. Don't touch this or anything below.
class Scene_Menu < Scene_MenuBase
  
  alias csca_menutheme_start start
  def start
    csca_menutheme_start
    csca_save_map_music
  end
  
  alias csca_menutheme_terminate terminate
  def terminate
    csca_menutheme_terminate
    $game_map.csca_replay_bgm_and_bgs if SceneManager.scene_is?(Scene_Map)
  end
  
  def csca_save_map_music
    $game_map.csca_save_music
    csca_play_menu_theme
  end

  def csca_play_menu_theme
    Audio.bgm_play("Audio/BGM/" + CSCA_MENUTHEME::MUSIC, 100, 100)
    RPG::BGS.stop
  end
  
end
class Game_Map
  
  def csca_save_music
    @csca_map_bgm = RPG::BGM.last
    @csca_map_bgs = RPG::BGS.last
  end
  
  def csca_replay_bgm_and_bgs
    @csca_map_bgm.replay if !@csca_map_bgm.nil?
    @csca_map_bgs.replay if !@csca_map_bgs.nil?
  end
  
end
class Scene_ItemBase < Scene_MenuBase
  alias csca_music_stop check_common_event
  def check_common_event
    $game_map.csca_replay_bgm_and_bgs if $game_temp.common_event_reserved?
    csca_music_stop
  end
end