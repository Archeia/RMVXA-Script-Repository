=begin
CSCA Menu MOD
version: 1.1.1
Created by: Casper Gaming (http://www.caspergaming.com/)

Compatibility:
Made for RPGVXAce
IMPORTANT: ALL CSCA Scripts should be compatible with each other unless
otherwise noted.
REQUIRES CSCA Core Script v1.0.5 or greater!
================================================================================
UPDATES:
Version 1.1
-Faster, more optimized
-Commented Code.

Version 1.1.1
-Made compatible with CSCA Currency System
================================================================================

FFEATURES:
This script will enhance the small gold window in the main menu to also show
playtime and location. Gold in the main menu is now sperated by
commas (ex. 1024839 becomes 1,024,839).

SETUP
Location uses the map notebox to get the location. Set up your map noteboxes
with this tag:
<CSCA x>

So, for example:
<CSCA Overworld>
Would become "Overworld" without the quotes.
Case sensitive.

CREDIT:
Free to use in noncommercial games if credit is given to:
Casper Gaming (http://www.caspergaming.com/)

To use in a commercial game, please purchase a license here:
http://www.caspergaming.com/licenses.html

TERMS:
http://www.caspergaming.com/terms_of_use.html
=end

$imported = {} if $imported.nil?
$imported["CSCA-SmallMenuMod"] = true
msgbox('Missing Script: CSCA Core Script! CSCA Menu MOD requires this
script to work properly.') if !$imported["CSCA-Core"]
#==============================================================================
# ** Scene_Menu
#------------------------------------------------------------------------------
# Replace Gold window with new menu window.
# Overwrites: create_gold_window
#==============================================================================
class Scene_Menu < Scene_MenuBase
  #--------------------------------------------------------------------------
  # * Overwrite Method; Create modified Gold Window
  #--------------------------------------------------------------------------
  def create_gold_window
    @gold_window = CSCA_Window_MenuMOD.new
    @gold_window.x = 0
    @gold_window.y = Graphics.height - @gold_window.height
  end
end
#==============================================================================
# ** CSCA_Window_MenuMOD
#------------------------------------------------------------------------------
# Shows gold, playtime, and location.
#==============================================================================
class CSCA_Window_MenuMOD < Window_Base
  #--------------------------------------------------------------------------
  # * Initialize
  #--------------------------------------------------------------------------
  def initialize
    super(0, 0, window_width, line_height * 4)
    refresh(true)
  end
  #--------------------------------------------------------------------------
  # * Width
  #--------------------------------------------------------------------------
  def window_width
    return 160
  end
  #--------------------------------------------------------------------------
  # * Refresh
  #--------------------------------------------------------------------------
  def refresh(open = false)
    contents.clear
    gold_amount = $game_party.gold
    gold_unit = Vocab::currency_unit
    cx = text_size(gold_unit).width + 6
    iw = $imported["CSCA-CurrencySystem"] ? 24 : 0
    number = $csca.split_number(gold_amount)
    location = $game_map.csca_map_note
    location.scan(/<CSCA .*>/).each { |csca_map_name|
      @csca_location = csca_map_name[6,csca_map_name.length-7]}
    @csca_location = "Unknown" if @csca_location.nil?
    change_color(normal_color)
    draw_text(0,0,contents.width,line_height,@csca_location.to_s)
    change_color(system_color)
    draw_text(0,line_height * 2, contents.width, line_height, Vocab::currency_unit)
    change_color($imported["CSCA-CurrencySystem"] ? $game_party.current_currency[:color] : normal_color)
    if number[0] >= 1
      draw_text(cx,line_height*2,contents.width-iw,line_height,sprintf("%d,%03d,%03d", number[0], number[1], number[2]))
    elsif number[0] == 0 && number[1] >= 1
      draw_text(cx,line_height*2,contents.width-iw,line_height,sprintf("%d,%03d", number[1], number[2]))
    else
      draw_text(cx,line_height*2,contents.width-iw,line_height,sprintf("%d", number[2]))
    end
    change_color(normal_color)
    draw_icon($game_party.current_currency[:icon],contents.width-24,line_height*2) if $imported["CSCA-CurrencySystem"]
    refresh_playtime
  end
  #--------------------------------------------------------------------------
  # * Refresh Playtime
  #--------------------------------------------------------------------------
  def refresh_playtime
    playtime = Graphics.frame_count / Graphics.frame_rate
    number = $csca.split_playtime(playtime)
    draw_text(0, line_height, contents.width, line_height,
      sprintf("Playtime: %02d:%02d:%02d", number[0], number[1], number[2]))
    end
  #--------------------------------------------------------------------------
  # * Frame Update
  #--------------------------------------------------------------------------
  def update
    refresh
  end
end