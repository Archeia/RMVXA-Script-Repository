=begin
CSCA Sidequests Image
version: 1.0.0 (Released: October 19, 2012)
Created by: Casper Gaming (http://www.caspergaming.com/)

Compatibility:
Made for RPGVXAce
IMPORTANT: ALL CSCA Scripts should be compatible with each other unless
otherwise noted.
Requires CSCA SideQuests

FFEATURES:
Adds a difficulty window to each sidequest.

SETUP
Setup below required. Intructions below.

CREDIT:
Free to use in noncommercial games if credit is given to:
Casper Gaming (http://www.caspergaming.com/)

To use in a commercial game, please purchase a license here:
http://www.caspergaming.com/licenses.html

TERMS:
http://www.caspergaming.com/terms_of_use.html
=end
module CSCA
  module SIDEQUEST
    #SIDEQUESTS[x]["difficulty"] = "Difficulty"
    SIDEQUESTS[0]["image"] = "Sidequests/Quest1.png"
    SIDEQUESTS[1]["image"] = "Sidequests/Quest2.png"
    SIDEQUESTS[2]["image"] = "Sidequests/Quest3.png"
  end
end
$imported = {} if $imported.nil?
$imported["SideQuests-Image"] = true
msgbox('Missing Script: CSCA Sidequests Script! Sidequest Image requires this
script to work properly.') if !$imported["CSCA-SideQuests"]
#==============================================================================
# ** CSCA_Scene_Sidequest
#------------------------------------------------------------------------------
# Creates image window.
#Aliases: create_addon_windows,set_help_windows,task_window_y,task_window_height
#==============================================================================
class CSCA_Scene_Sidequest < Scene_MenuBase
  #--------------------------------------------------------------------------#
  # Alias Method; Start Processing                                           #
  #--------------------------------------------------------------------------#
  alias :csca_sqi_addon :create_addon_windows
  def create_addon_windows
    create_image_window
    csca_sqi_addon
  end
  #--------------------------------------------------------------------------#
  # Create difficulty window                                                 #
  #--------------------------------------------------------------------------#
  def create_image_window
    @image_window = CSCA_Window_SidequestImage.new(Graphics.width/3,
      @head_window.height,@task_window.width,@head_window.height*2)
    @image_window.viewport = @viewport
  end
  #--------------------------------------------------------------------------#
  # Alias Method; Sets help windows                                          #
  #--------------------------------------------------------------------------#
  alias :csca_sqi_help_window :set_help_windows
  def set_help_windows
    csca_sqi_help_window
    @select_window.image_window = @image_window
  end
  #--------------------------------------------------------------------------#
  # Alias Method; Task Window Y                                              #
  #--------------------------------------------------------------------------#
  alias :csca_sqi_task_y :task_window_y
  def task_window_y
    return csca_sqi_task_y*3
  end
  #--------------------------------------------------------------------------#
  # Alias Method; Task Window Height                                         #
  #--------------------------------------------------------------------------#
  alias :csca_sqi_task_height :task_window_height
  def task_window_height
    return csca_sqi_task_height - @head_window.height*2
  end
end
#==============================================================================
# ** CSCA_Window_SidequestImage
#------------------------------------------------------------------------------
# Handles the image window.
#==============================================================================
class CSCA_Window_SidequestImage < Window_Base
  #--------------------------------------------------------------------------#
  # Object Initialization                                                    #
  #--------------------------------------------------------------------------#
  def initialize(x, y, width, height)
    super(x, y, width, height)
    set_item(0)
  end
  #--------------------------------------------------------------------------#
  # Set Item                                                                 #
  #--------------------------------------------------------------------------#
  def set_item(index)
    contents.clear
    image = "Graphics/" + CSCA::SIDEQUEST::SIDEQUESTS[index]["image"]
    bitmap = Bitmap.new(image)
    target = Rect.new(0,0,338,72)
    contents.stretch_blt(target, bitmap, bitmap.rect, 255)
  end
end
#==============================================================================
# ** CSCA_Window_SidequestSelect
#------------------------------------------------------------------------------
# Additional methods for updating image window.
#Aliases: update_help
#==============================================================================
class CSCA_Window_SidequestSelect < Window_Selectable
  attr_accessor :image_window
  #--------------------------------------------------------------------------#
  # Alias Method; Update Help Window                                         #
  #--------------------------------------------------------------------------#
  alias :csca_sqi_update :update_help
  def update_help
    csca_sqi_update
    @image_window.set_item(index) if @image_window
  end
end