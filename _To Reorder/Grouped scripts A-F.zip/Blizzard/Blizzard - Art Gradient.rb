#==============================================================================
#    Blizz-Art Gradient Styler [Port from XP v. 4.51b]
#    Version: 1.0 [VXA]
#    Author: Blizzard (forum.chaos-project.com)
#    Date: January 29, 2012
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#  Description:
#
#    This script lets you choose from a variety of new gradient styles.
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#  Instructions: 
# 
#    Paste this script into its own slot in the Script Editor, above Main but
#   below Materials.
#
#    You can change style and opacity by using the "Call script" event command.
#   Use one of of these syntaxes:
# 
#     $game_system.bar_style = X
#     $game_system.bar_opacity = Y
# 
#   X - number from 0 to 7 and is the ID number of the style. 0 is VXA default
#   Y - number from 0 to 255 and indicates the opacity. Values out of range 
#      will be corrected.
#
#  Go to line 35 and 36 to set the default values for those variables.
#==============================================================================

$imported ||= {}
$imported[:BlizzArt_GradientStyler]

#\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
#  BEGIN  Editable Region
#||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
BAGS_BAR_STYLE = 2     # The bar's default style. Must be between 0 and 7
BAGS_BAR_OPACITY = 255 # The bar's default opacity. Must be between 0 and 255
#||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
#  END    Editable Region
#//////////////////////////////////////////////////////////////////////////////

#==============================================================================
# *** DataManager
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#  Summary of Changes:
#    aliased method - self.extract_save_contents
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#  Preserve save files made before the script is installed
#==============================================================================

class << DataManager
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * Extract Save Contents
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  alias bags_extractsave_3hr7 extract_save_contents
  def extract_save_contents(*args, &block)
    bags_extractsave_3hr7(*args, &block) # Run Original Method
    # Preserve old save files
    $game_system.reset_gradient_style if !$game_system.bar_style
  end
end

#==============================================================================
# ** Game_System
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#  Summary of Changes:
#    new public instance variables - bar_style; bar_opacity
#    aliased method - initialize
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#  New variables to control the gradient style and opacity
#==============================================================================

class Game_System
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * Public Instance Variables
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  attr_accessor :bar_style
  attr_reader   :bar_opacity
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 
  # * Object Initialization
  #     Added bar style variables.
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 
  alias init_blizzart_later initialize
  def initialize(*args, &block)
    init_blizzart_later(*args, &block) # Call Original Method
    reset_gradient_style
  end
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * Reset Gradient
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def reset_gradient_style
    @bar_style = BAGS_BAR_STYLE
    self.bar_opacity = BAGS_BAR_OPACITY
  end
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * Set Bar Opacity
  #     alpha - opacity
  #     Encapsulation and range limitation of opacity.
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def bar_opacity=(alpha)
    @bar_opacity = [[alpha, 0].max, 255].min
  end
end

#==============================================================================
# ** Bitmap
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#  Summary of Changes:
#    new method - blizz_gradient_bar
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#  Adds a new method to draw special gradient styles
#==============================================================================

class Bitmap
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * Blizzard's Gradient Bar
  #  x      - x coordinate
  #  y      - y coordinate
  #  w      - width of the bar to be drawn
  #  color1 - primary color
  #  color2 - secondary color
  #  color3 - back color
  #  rate   - fill rate
  #  This special method is able to draw one out of 7 styles.
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 
  def blizz_gradient_bar(x, y, w, color1, color2, color3, rate)
    rate = 1.0 if rate > 1.0
    # stop if not active or out of range
    return if !$game_system.bar_style.between?(0, 6)
    # styles with "vertical" black borders
    styles = [1, 3, 4, 5, 6]
    # setup of coordinates and offsets depending on style
    offs = 5
    x += offs
    if styles.include?($game_system.bar_style)
      offs += 2
      y -= 1
      [5, 6].include?($game_system.bar_style) ? y -= 2 :  x += 1
      # quantizes the width so it looks better (remove it and see what happens)
      w = w / 8 * 8
    end
    # temporary variable
    a = $game_system.bar_opacity
    if $game_system.bar_style < 5
      # draw black slanted back
      (0...(offs+3)).each {|i| fill_rect(x-i, y+i-2, w+3, 1, Color.new(0, 0, 0))}
      # draw white slanted back onto black, but let black borders stay
      (0...(offs+1)).each {|i| fill_rect(x-i, y+i-1, w+1, 1, Color.new(255, 255, 255))}
      if $game_system.bar_style < 2
        # iterate through each vertical bar
        (0...w+offs).each {|i|
            # calculate color
            r = color3.red * i / (w+offs)
            g = color3.green * i / (w+offs)
            b = color3.blue * i / (w+offs)
            # special offset calculation
            oy = i < offs ? offs-i : 0
            off = i < offs ? i : i > w ? w+offs-i : offs
            # draw this part of the bar
            fill_rect(x+i-offs+1, y+oy-1, 1, off, Color.new(r, g, b, a))}
        # if slanted bar is out of critical area
        if (w*rate).to_i >= offs
          # draw the little triangular part on the left
          (0...((w*rate).to_i+offs)).each {|i|
              r = color1.red + (color2.red-color1.red)*i / ((w+offs)*rate)
              g = color1.green + (color2.green-color1.green)*i / ((w+offs)*rate)
              b = color1.blue + (color2.blue-color1.blue)*i / ((w+offs)*rate)
              oy = i < offs ? offs-i : 0
              off = i < offs ? i : i > w*rate ? (w*rate).to_i+offs-i : offs
              fill_rect(x+i-offs+1, y+oy-1, 1, off, Color.new(r, g, b, a))}
        else
          # draw the little triangular part on the left using special method
          (0...(w * rate).to_i).each {|i| (0...offs).each {|j|
              r = color1.red + (color2.red-color1.red)*i / (w*rate)
              g = color1.green + (color2.green-color1.green)*i / (w*rate)
              b = color1.blue + (color2.blue-color1.blue)*i / (w*rate)
              set_pixel(x+i-j+1, y+j-1, Color.new(r, g, b, a))}}
        end
      else
        # iterate through all horizontal lines
        (0...offs).each {|i|
            # calculate colors
            r = color3.red * i / offs
            g = color3.green * i / offs
            b = color3.blue * i / offs
            # draw background line
            fill_rect(x-i+1, y+i-1, w, 1, Color.new(r, g, b, a))}
        if $game_system.bar_style == 4
          # iterate through half of all horizontal lines
          (0...offs/2+1).each {|i|
              # calculate colors
              r = color2.red * (i+1) / (offs/2)
              g = color2.green * (i+1) / (offs/2)
              b = color2.blue * (i+1) / (offs/2)
              # draw bar line
              fill_rect(x-i+1, y+i-1, w*rate, 1, Color.new(r, g, b, a))
              # draw bar line mirrored vertically
              fill_rect(x-offs+i+2, y+offs-i-2, w*rate, 1, Color.new(r, g, b, a))}
        else
          # iterate through all horizontal lines
          (0...offs).each {|i|
              # calculate colors
              r = color1.red + (color2.red-color1.red)*i / offs
              g = color1.green + (color2.green-color1.green)*i / offs
              b = color1.blue + (color2.blue-color1.blue)*i / offs
              # draw bar line
              fill_rect(x-i+1, y+i-1, w*rate, 1, Color.new(r, g, b, a))}
        end
      end
      # if style with black vertical slanted intersections
      if styles.include?($game_system.bar_style)
        # add black bars on 1st and 8th column every 8 pixels
        (0...w).each {|i| (0...offs).each {|j|
            if styles.include?($game_system.bar_style) && i % 8 < 2
              set_pixel(x+i-j+1, y+j-1, Color.new(0, 0, 0, a))
            end}}
      end
    else
      # fill white background
      fill_rect(x+1, y-3, w+2, 12, Color.new(255, 255, 255, a))
      # iterate through each of 6 lines
      (1...6).each {|i|
          # calculate background color
          color = Color.new(color3.red*i/5, color3.green*i/5, color3.blue*i/5, a)
          # draw background
          fill_rect(x+2, y+i-3, w, 12-i*2, color)
          # calculate bar color
          color = Color.new(color2.red*i/5, color2.green*i/5, color2.blue*i/5, a)
          # draw bar
          fill_rect(x+2, y+i-3, w*rate, 12-i*2, color)}
      # if style 5 (with vertical borders)
      if $game_system.bar_style == 5
        # add black bars on 1st and 8th column every 8 pixels
        (0...w/8).each {|i|
            fill_rect(x+2+i*8, y-2, 1, 10, Color.new(0, 0, 0, a))
            fill_rect(x+2+(i+1)*8-1, y-2, 1, 10, Color.new(0, 0, 0, a))}
      end
    end
  end
end

#==============================================================================
# ** Window_Base
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#  Summary of Changes:
#    aliased method - draw_gauge
#==============================================================================

class Window_Base
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * Draw Gauge
  #  x      - x coordinate
  #  y      - y coordinate
  #  width  - width of the bar to be drawn
  #  rate   - fill rate
  #  color1 - primary color
  #  color2 - secondary color
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  alias bags_drwgauge_3jy6 draw_gauge
  def draw_gauge(x, y, width, rate, color1, color2, *args, &block)
    if $game_system.bar_style.between?(1, 7)
      $game_system.bar_style -= 1
      gauge_y = y + line_height - 6
      contents.blizz_gradient_bar(x, gauge_y, width, color1, color2, gauge_back_color, rate)
      $game_system.bar_style += 1
    else
      # Call Original Method
      bags_drwgauge_3jy6(x, y, width, rate, color1, color2, *args, &block)
    end
  end
end