#==============================================================================
# ** Main
#------------------------------------------------------------------------------
#  Runs the entire system.
#==============================================================================

ERROR_LOG_FILE = 'Error.log' # leave empty for no log

def mod_error(error)
  # load scripts
  scripts = load_data('Data/Scripts.rvdata2')
  bt = error.backtrace.clone
  # change backtrace display to show script names
  bt.each_index {|i| bt[i] = bt[i].sub(/\ASection(\d+)/) {scripts[$1.to_i][1]} + "\n"}
  # new error message
  message = error.message + "\n" + bt.join('')
  # write to file if file defined
  if ERROR_LOG_FILE != ''
    File.open(ERROR_LOG_FILE, 'a') {|f| f.write("#{Time.now.to_s}:\n#{message}\n")}
  end
  return message
end

begin
  # prepare for transition
  Graphics.freeze
  # activate the network
  $network = RMXOS::Network.new
  # call main for active scene
  begin
    rgss_main { SceneManager.run }
  rescue Exception => ex
    puts ex.backtrace
    raise
  end
  # disconnection
  $network.disconnect
  # fade out
  Graphics.transition(20)
  Graphics.update
rescue SyntaxError
  $!.message.sub!($!.message, mod_error($!))
  raise
rescue
  $!.message.sub!($!.message, mod_error($!))
  raise
ensure
  # disconnection
  $network.disconnect
end