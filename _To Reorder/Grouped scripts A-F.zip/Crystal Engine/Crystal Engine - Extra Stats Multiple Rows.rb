#==============================================================================
# Crystal Engine - Extra Stats
#------------------------------------------------------------------------------
# Current Version: 1.06 - NREdit
#==============================================================================
$imported ||= {}
$imported["CE-ExtraStats"] = true
=begin
This script allows for you to have additional stats for your battler. Those are
viewable on the default status screen for your convinece. To use them in damage
formulas use xstat.(stat abriviation).
Edited by Night_Runner to allow extra rows (4/Jan/2014)
 @> http://www.rpgmakervxace.net/topic/20850-extra-stats-multiple-rows/
-------------------------------------------------------------------------------
Notetags:
Actor Notes
<xstat> # Sets the xstat formulas up. This takes precidence over the class formula
stat => formula, # Be sure to put a collon on the stats.
</xstat_end> # The formula can be any valid ruby exprssion that returns a number.
<state_xstat: stat x%> # Sets the specified stat to be multiplied by x%
Class Notes
<xstat> # Sets the xstat formulas up.
stat => formula, # Be sure to put a collon on the stats.
</xstat_end> # The formula can be any valid ruby exprssion that returns a number.
<state_xstat: stat x%> # Sets the specified stat to be multiplied by x%
Skill Notes
<xstat growth: stat x> # Changes the specified stat by x
Item Notes
<xstat growth: stat x> # Changes the specified stat by x
Weapon Notes
<weapon_xstat: stat +x> # Sets the specified stat to be modified by x
<state_xstat: stat x%> # Sets the specified stat to be multiplied by x%
Armor Notes
<weapon_xstat: stat +x> # Sets the specified stat to be modified by x
<state_xstat: stat x%> # Sets the specified stat to be multiplied by x%
Enemy Notes
<xstat> # Sets the xstat formulas up. This takes precidence over the class formula
stat => formula, # Be sure to put a collon on the stats.
</xstat_end> # The formula can be any valid ruby exprssion that returns a number.
<state_xstat: stat x%> # Sets the specified stat to be multiplied by x%
State Notes
<state_xstat: stat x%> # Sets the specified stat to be multiplied by x%
-------------------------------------------------------------------------------
Script Calls:
change_xstat(actor_id, stat, value) # Alter the specified stat by the specifed 
# value. Can be either positive or negative.
=end
module CRYSTAL
  module XSTAT
    
    STATS = [:str,:sta,:spi]
    
    #Default xstat formulas for ACTORS
    DEFAULT_LEVEL_FORMULA = {
      :str => '23 + ((level * 70) / 128)',
      :sta => '24 + ((level * 48) / 128)',
      :spi => '20 + ((level * 57) / 128)',
      }
    
    #Default xstat formulas for ENEMIES	  
    DEFAULT_FOR_ENEMIES = {
    :str => 'database_param(2)',
    :sta => 'param(3) * 2',
    :spi => 'mat',
    }
    
    TERMS = {
    :str => "STR",
    :sta => "STA",
    :spi => "SPI", 
    }
    
    STAT_MIN = {
    :str => 1,
    :sta => 1,
    :spi => 1,
    }
    
    STAT_MAX = {
    :str => 99,
    :sta => 99,
    :spi => 99,
    }
    
  end
end
#==============================================================================
# Editing beyond this point may cause stone, zombie, mist frenzy, and/or toad,
# so edit at your own risk.
#==============================================================================
#==============================================================================
# ** RPG::BaseItem
#------------------------------------------------------------------------------
#  Superclass of actor, class, skill, item, weapon, armor, enemy, and state.
#==============================================================================

class RPG::BaseItem
  #--------------------------------------------------------------------------
  # * Extra Stat Formula
  #--------------------------------------------------------------------------
  def xstat_formula(stat)
    return @xstat[stat] if @xstat && @xstat[stat]
    @xstat ||= {}
    xstats_defining = false
    @note.split(/[\r\n]+/).each do |line|
      case line
      when /<XSTAT>/i
        xstats_defining = true
      when /<\/XSTAT_END>/i
        xstats_defining = false
      when /#{stat} => '(.*)',/i
        next unless xstats_defining
        @xstat[stat] = $1.to_s
      end
    end
    if is_a?(RPG::Actor) || is_a?(RPG::Class)
      @xstat[stat] ||= CRYSTAL::XSTAT::DEFAULT_LEVEL_FORMULA[stat]
    else
      @xstat[stat] ||= CRYSTAL::XSTAT::DEFAULT_FOR_ENEMIES[stat]
    end
    return @xstat[stat]
  end
  #--------------------------------------------------------------------------
  # * Extra Stat Modifier
  #--------------------------------------------------------------------------
  def xstat_modifier(stat)
    @note =~ /<STATE_XSTAT: #{stat} (\d+)([%％])>/i ? $1.to_i * 0.01 : 1.00
  end
end
#==============================================================================
# ** RPG::UsableItem
#------------------------------------------------------------------------------
#  The Superclass of Skill and Item.
#==============================================================================

class RPG::UsableItem < RPG::BaseItem
  #--------------------------------------------------------------------------
  # * Extra Stat Growth
  #--------------------------------------------------------------------------
  def xstat_growth(stat)
    @note =~ /<XSTAT GROWTH: #{stat} (\d+)>/i ? $1.to_i : 0
  end
end
#==============================================================================
# ** RPG::EquipItem
#------------------------------------------------------------------------------
#  A superclass of weapons and armor.
#==============================================================================

class RPG::EquipItem < RPG::BaseItem
  #--------------------------------------------------------------------------
  # * Extra Stat Change
  #--------------------------------------------------------------------------
  def xstat_change(stat)
    @note =~ /<WEAPON_XSTAT: #{stat} ([\+\-]\d+)>/i ? $1.to_i : 0
  end
end
#==============================================================================
# ** Xstats
#------------------------------------------------------------------------------
#  This class handles the player's extra stats.
#==============================================================================

class Xstats
  #--------------------------------------------------------------------------
  # * Object Initialization
  #--------------------------------------------------------------------------
  def initialize(battler)
    @battler = battler
  end
  #--------------------------------------------------------------------------
  # * Define the Stats
  #--------------------------------------------------------------------------
  CRYSTAL::XSTAT::STATS.each do |sym|
    define_method(:"#{sym}") do
      @battler.eval_stat(sym)
    end
  end
end
#==============================================================================
# ** Game_BattlerBase
#------------------------------------------------------------------------------
#  This base class handles battlers. It mainly contains methods for calculating
# parameters. It is used as a super class of the Game_Battler class.
#==============================================================================

class Game_BattlerBase
  #--------------------------------------------------------------------------
  # * Public Instance Variables
  #--------------------------------------------------------------------------
  attr_accessor :xstat_plus               # Additions to the xstats
  #--------------------------------------------------------------------------
  # * Object Initialization
  #--------------------------------------------------------------------------
  alias init_ce_extra_stats initialize
  def initialize
    init_ce_extra_stats
    @xstat_plus = {}
    CRYSTAL::XSTAT::STATS.each do |stat|
      @xstat_plus[stat] = 0
    end
  end
  #--------------------------------------------------------------------------
  # * Extra Stats Object
  #--------------------------------------------------------------------------
  def xstat
    Xstats.new(self)
  end
  #--------------------------------------------------------------------------
  # * Extra Stats Object
  #--------------------------------------------------------------------------
  def eval_stat(sym)
    if actor?
      if actor.xstat_formula(sym) == CRYSTAL::XSTAT::DEFAULT_LEVEL_FORMULA[sym]
        stat = eval(self.class.xstat_formula(sym))
      else
        stat = eval(actor.xstat_formula(sym))
      end
      equips.compact.each do |equip|
        stat += equip.xstat_change(sym)
      end
      stat += @xstat_plus[sym]
      equips.compact.each do |equip|
        stat *= equip.xstat_modifier(sym)
      end
      stat *= actor.xstat_modifier(sym)
      stat *= self.class.xstat_modifier(sym)
    elsif enemy?
      if $imported["CE-EnemyClasses"]
        if enemy.xstat_formula(sym) == CRYSTAL::XSTAT::DEFAULT_FOR_ENEMIES[sym]
          stat = eval(self.class.xstat_formula(sym))
        end
      end
      stat ||= eval(enemy.xstat_formula(sym))
      if $imported["CE-EnemyEquips"]
        equips.compact.each do |equip|
          stat += equip.xstat_change(sym)
        end
        stat += @xstat_plus[sym]
        equips.compact.each do |equip|
          stat *= equip.xstat_modifier(sym)
        end
      end
      stat *= enemy.xstat_modifier(sym)
      stat *= self.class.xstat_modifier(sym) if $imported["CE-EnemyClasses"]
    end
    states.each do |state|
      stat *= state.xstat_modifier(sym)
    end
    return [[CRYSTAL::XSTAT::STAT_MIN[sym], stat.round].max, CRYSTAL::XSTAT::STAT_MAX[sym]].min
  end
end
#==============================================================================
# ** Game_Battler
#------------------------------------------------------------------------------
#  A battler class with methods for sprites and actions added. This class 
# is used as a super class of the Game_Actor class and Game_Enemy class.
#==============================================================================

class Game_Battler < Game_BattlerBase
  #--------------------------------------------------------------------------
  # * Apply Effect of Skill/Item
  #--------------------------------------------------------------------------
  alias item_apply_ce_extra_stats item_apply
  def item_apply(user, item)
    item_apply_ce_extra_stats(user, item)
    if @result.hit?
      CRYSTAL::XSTAT::STATS.each do |stat|
        @xstat_plus[stat] += item.xstat_growth(stat)
      end
    end
  end
  #--------------------------------------------------------------------------
  # * Test Skill/Item Application
  #    Used to determine, for example, if a character is already fully healed
  #   and so cannot recover anymore.
  #--------------------------------------------------------------------------
  alias item_test_ce_extra_stats item_test
  def item_test(user, item)
    CRYSTAL::XSTAT::STATS.each do |stat|
      max = CRYSTAL::XSTAT::STAT_MAX[stat]
      return true if item.xstat_growth(stat) > 0 && eval_stat(stat) < max
    end
    return item_test_ce_extra_stats(user, item)
  end
end
#==============================================================================
# ** Game_Interpreter
#------------------------------------------------------------------------------
#  An interpreter for executing event commands. This class is used within the
# Game_Map, Game_Troop, and Game_Event classes.
#==============================================================================

class Game_Interpreter
  #--------------------------------------------------------------------------
  # * Modify an Extra Stat
  #--------------------------------------------------------------------------
  def change_xstat(id, stat, value)
    $game_actors[id].xstat_plus[stat] += value
  end
end
#==============================================================================
# ** Window_Base
#------------------------------------------------------------------------------
#  This is a super class of all windows within the game.
#==============================================================================

class Window_Base < Window
  def stat_widths
    wind_wid = self.contents.width
    xstat_cols = (CRYSTAL::XSTAT::STATS.length + 5) / 6
    return (((wind_wid - 172) / (xstat_cols + 1))*0.9).to_i
  end
  #--------------------------------------------------------------------------
  # * Draw Parameters
  #--------------------------------------------------------------------------
  def draw_actor_xstat(actor, x, y, stat)
    change_color(system_color)
    draw_text(x, y, stat_widths, line_height, CRYSTAL::XSTAT::TERMS[stat])
    change_color(normal_color)
    draw_text(x + stat_widths-36, y, 36, line_height, eval("actor.xstat.#{stat}"), 2)
  end
end
#==============================================================================
# ** Window_Status
#------------------------------------------------------------------------------
#  This window displays full status specs on the status screen.
#==============================================================================

class Window_Status < Window_Selectable
  #--------------------------------------------------------------------------
  # * Draw Block 3
  #--------------------------------------------------------------------------
  def draw_block3(y)
    draw_parameters(0, y)
    draw_equipments(self.contents.width-172, y)
    draw_xstat_parameters(stat_widths / 0.9, y)
  end
  #--------------------------------------------------------------------------
  # * Draw Parameters
  #--------------------------------------------------------------------------
  def draw_actor_param(actor, x, y, param_id)
    change_color(system_color)
    draw_text(x, y, stat_widths, line_height, Vocab::param(param_id))
    change_color(normal_color)
    draw_text(x + stat_widths-36, y, 36, line_height, actor.param(param_id), 2)
  end
  #--------------------------------------------------------------------------
  # * Draw Extra Stats
  #--------------------------------------------------------------------------
  def draw_xstat_parameters(x, y)
    dy = 0
    CRYSTAL::XSTAT::STATS.each do |stat|
      draw_actor_xstat(@actor, x, y + dy, stat)
      dy += line_height
      if dy > 120
        dy = 0
        x += stat_widths / 0.9
      end
    end
  end
end
#==============================================================================
# 
# ▼ End of File
# 
#==============================================================================