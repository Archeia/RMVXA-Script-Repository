# Status Display Change
# Requires: Crystal Engine - Extra Stats
# Made by: Sixth

module XStatDisplayM
  
  # Default parameter display settings.
  Params = {
    :displayed => [2,3,4,5,6,7], # Displayed parameters (0 = HP, 1 = MP, 2 = ATK, etc)
    :pos => [0, 168], # The X and Y position of the first displayed parameter.
    :width => 100, # The width reserved for one column.
    :rows => 6, # The maximum number of rows allowed for parameters.
    :spacing => 8, # The horizontal spacing between columns.
  }
    
  # Xstat display settings. Same settings as above.
  XStats = {
    :displayed => [:str,:sta,:spi,:cha,:wit,:vit,:blc,:res,:pow,:dex,:pro,:skl],
    :pos => [108, 168],
    :width => 100,
    :rows => 6,
    :spacing => 8,
  }

  # Equip display settings. Almost the same settings as above...
  Equips = {
    :empty => ["Empty", 185], # The word and icon displayed for empty equip slots.
    :pos => [334, 168],
    :width => 100,
    :rows => 6,
    :spacing => 8,
  }

end
# End of settings! No touchy-touchy below! o.o

class Window_Base < Window

  def draw_actor_xstat(actor, x, y, w, stat)
    change_color(system_color)
    draw_text(x, y, w, line_height, CRYSTAL::XSTAT::TERMS[stat])
    change_color(normal_color)
    draw_text(x, y, w, line_height, eval("actor.xstat.#{stat}"), 2)
  end
  
end

class Window_Status < Window_Selectable

  def draw_block3(y)
    prs = XStatDisplayM::Params; xst = XStatDisplayM::XStats; eqs = XStatDisplayM::Equips
    draw_parameters(prs[:pos][0],prs[:pos][1],prs[:width],prs[:rows],prs[:spacing])
    draw_equipments(eqs[:pos][0],eqs[:pos][1],eqs[:width],eqs[:rows],eqs[:spacing])
    draw_xstat_parameters(xst[:pos][0],xst[:pos][1],xst[:width],xst[:rows],xst[:spacing])
  end
    
  def draw_equipments(x, y, w, rows, spacing)
    @actor.equips.each_with_index do |item, i|
      yy = i % rows * line_height + y
      xx = (i / rows * (w + spacing)) + x
      if item.nil?
        draw_icon(XStatDisplayM::Equips[:empty][1], xx, yy)
        change_color(normal_color,false)
        draw_text(xx + 24, yy, w, line_height, XStatDisplayM::Equips[:empty][0])
      else
        draw_item_name(item, xx, yy, true, w)
      end
    end
  end

  def draw_parameters(x, y, w, rows, spacing)
    XStatDisplayM::Params[:displayed].each_with_index do |prm,i| 
      yy = i % rows * line_height + y
      xx = (i / rows * (w + spacing)) + x
      draw_actor_param(@actor, xx, yy, w, prm) 
    end
  end
  
  def draw_actor_param(actor, x, y, w, param_id)
    change_color(system_color)
    draw_text(x, y, w, line_height, Vocab::param(param_id))
    change_color(normal_color)
    draw_text(x, y, w, line_height, actor.param(param_id), 2)
  end

  def draw_xstat_parameters(x, y, w, rows, spacing)
    XStatDisplayM::XStats[:displayed].each_with_index do |st,i|
      yy = i % rows * line_height + y
      xx = (i / rows * (w + spacing)) + x
      draw_actor_xstat(@actor, xx, yy, w, st)
    end
  end
  
end