class Window_TextBox
  def update_keyboard
   if NoteInput.trigger?(NoteInput::ENTER)
     @real_text = @real_text.to_i if @type == :numeric
     $game_variables[@var] = @real_text
     @finished = true
     @text = ""
     @real_text = ""
   elsif NoteInput.trigger?(NoteInput::BACK)
     return if @real_text == ""
     @text = @text[0, @text.size - 1]
     @real_text = @real_text[0, @real_text.size - 1]
   else
     return if text_size(@text).width >= contents_width - 10 || @text.size >= @length
     k = ""
     case @type
     when :numeric
       k = NoteInput.key_numeric
       @text += k
       @real_text += k
     when :password
       k = NoteInput.key_type
       @text += BERK::PASSWORD_CHAR if k != ""
       @real_text += k
     when :normal
       k = NoteInput.key_type
       @text += k
       @real_text += k
     end
     RPG::SE.new('Cursor1',80,100).play unless k.empty?
   end
  end
end