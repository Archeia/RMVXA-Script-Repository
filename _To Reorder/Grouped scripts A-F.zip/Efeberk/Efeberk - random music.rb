=begin


   Random Battle & Vehicle BGM for RGSS3
   Developer : efeberk
   Created: 12/05/2013 16:47
   Updated : 27/07/2013 01.15
   Version: 1.1
   
   
   When battle starts or player gets on vehicle, system will play musics
   which you chose below.
   
   Note : set false AIRSHIP_ON, BOAT_ON or SHIP_ON if you don't wanna
   implement random bgm to the vehicle.
   
   Credit me or don't. It is your decision.
   
=end
module EFEBERK
 
  TURN_ON_SWITCH_ID = 0 # Set 0 to enable forever.
 
  MUSICS = [
  #[music name, volume, pitch]
  ["Battle6", 100,120],
  ["Battle8", 100,120],
  ["Battle3", 100,120],
  ["Battle2", 100,120]
  ]
 
  AIRSHIP_ON = false
 
  FOR_AIRSHIP = [
  #[music name, volume, pitch]
  ["Aegia", 100,120],
  ["Castle", 100,120]
  ]
 
  BOAT_ON = false
 
  FOR_BOAT = [
  #[music name, volume, pitch]
  ["Battle", 100,120],
  ["Paradise", 100,120]
  ]
 
  SHIP_ON = false
 
  FOR_SHIP = [
  #[music name, volume, pitch]
  ["Heaven", 100,120],
  ["Reborn", 100,120]
  ]
#---------------------------------------------------------------
#---------------------------------------------------------------
#---------------------------------------------------------------
#---------------------------------------------------------------
#---------------------------------------------------------------
#----------Don't edit below if you are not a coder.-------------
 
  def self.efe
    bgm = EFEBERK::MUSICS[rand(EFEBERK::MUSICS.size)]
    bgm2 = RPG::BGM.new(bgm[0], bgm[1], bgm[2])
    if EFEBERK::TURN_ON_SWITCH_ID != 0
      if !$game_switches[EFEBERK::TURN_ON_SWITCH_ID]
        $game_system.battle_bgm = $data_system.battle_bgm
      else
        $game_system.battle_bgm = bgm2
      end
    else
      $game_system.battle_bgm = bgm2
    end
  end
end

class Scene_Map < Scene_Base

  alias efeberk_scene_map_pre_battle_scene pre_battle_scene
  def pre_battle_scene
    EFEBERK::efe
    efeberk_scene_map_pre_battle_scene
  end
 
end




class Game_Vehicle < Game_Character
  alias efeberk_random_bgm__vehicle_get_on get_on
  def get_on
    efeberk_random_bgm__vehicle_get_on
    Audio.bgm_stop
    if @type == :airship
      if EFEBERK::AIRSHIP_ON
        bgm = EFEBERK::FOR_AIRSHIP[rand(EFEBERK::FOR_AIRSHIP.size)]
        bgm2 = RPG::BGM.new(bgm[0], bgm[1], bgm[2])
        Audio.bgm_play("Audio/BGM/" + bgm[0], bgm[1], bgm[2])
      else
        system_vehicle.bgm.play
      end
    end
    if @type == :boat
      if EFEBERK::BOAT_ON
        bgm = EFEBERK::FOR_BOAT[rand(EFEBERK::FOR_BOAT.size)]
        bgm2 = RPG::BGM.new(bgm[0], bgm[1], bgm[2])
        Audio.bgm_play("Audio/BGM/" + bgm[0], bgm[1], bgm[2])
      else
        system_vehicle.bgm.play
      end
    end
    if @type == :ship
      if EFEBERK::SHIP_ON
        bgm = EFEBERK::FOR_SHIP[rand(EFEBERK::FOR_SHIP.size)]
        bgm2 = RPG::BGM.new(bgm[0], bgm[1], bgm[2])
        Audio.bgm_play("Audio/BGM/" + bgm[0], bgm[1], bgm[2])
      else
        system_vehicle.bgm.play
      end
    end
  end
 
end