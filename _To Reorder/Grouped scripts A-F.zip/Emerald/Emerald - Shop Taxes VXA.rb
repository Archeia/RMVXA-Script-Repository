#============================================================================
# Shop Taxes v1.8 (VXA version)
# By Emerald
#----------------------------------------------------------------------------
# Originally made by Falcon for RMXP
# Edited by Emerald to fit the RMVX and now also RMVX Ace
# You're free to use the script for any game, as long as you give credits
#----------------------------------------------------------------------------
# Version History
# 0.5 -> Script ported to RMVX Ace with minor edits to avoid errors
# 1.0 -> Further edits due to problems with percentage taxes
#        Added possibility to easily configure x/y position of tax information
#        and a value to configure if it will even be shown at all.
# 1.5 -> Again, further edits due to slight problems. But aside from that,
#        you can use <tax key item> again. Also added possibility to create
#        items which alter taxes. DRASTICALLY changed Instructions, be sure to
#        read it thoroughly.
# 1.6 -> Added Sell taxes and item Sell Tax changes.
# 1.7 -> Small key item bug fix and standard key items don't require a tag.
# 1.8 -> Cleaned up a bit. Better functionality for item tax bonuses.
#----------------------------------------------------------------------------
# With this script, you can almost fully control prices for VX Ace. You can
# normally set prices and prices unique per shop, and this script adds the
# possibility to make taxes. With these taxes, you can easily change prices of
# all items in a shop, either higher or lower.
#
# Instructions:
#
# Just as always, put this script between �� Materials and �� Main. If the 
# information about the taxes is not shown correctly in shops, you can change
# it below. 
#
#
# TAXES
# 
# In order to add taxes, use the call script method within an event. Use
# the following codes codes:
#
# $game_system.tax.percent = x
# Where x > 100 results in a tax with x% the normal price
# Where x < 100 results in a discount with x% the normal price
#
# $game_systeme.tax.direct = y
# Where y > 0 results in a tax which adds y to every price
# Where y < 0 results in a discount which subtracts y to every price
#
# As described in the section Item Tags below, having certain items on hand
# can also change the taxes. If you want to access these bonuses outside of items
# (to clear the bonuses for example), use:
# $game_system.tax.perbon = x
# Where x gets added to $game_system.tax.percent
#
# $game_systeme.tax.dirbon = y
# Where x gets added to $game_system.tax_direct
#
# A 4 variables can be changed in multiple ways, so you can also add, substract,
# divide and multiply.
# Example:
# $game_system.tax.percent += 10 is also valid
# $game_system.tax.direct /= 5 is also valid
#
# WARNING 1
# For n = the price of an item,
# If n - y equals 0, the item becomes free
# If n - y < 0, the item becomes free AND you GET money (why doesn't that happen
# in real life)
# If x = a negative value then you'll GET money (x% the normal price)
# END WARNING
#
# WARNING 2
# When $game_system.tax.perbon or $game_system.tax.dirbon are not 0, the value
# you assign to respectively $game_system.tax.percent and $game_system.tax.direct
# will be different than if you try to check what these values are (by using
# for example "puts $game_system.tax.percent" and checking the result in the
# RGSS console). These reason for this is that the bonuses are added to the return
# values. If you want to know what the taxes are without bonuses, use the 
# following two variables instead:
# $game_system.tax.percent_without_bonus
# $game_system.tax_direct_without_bonus
# END WARNING
#
#
# SELL TAXES
#
# Exact same story as above, only these values are hidden and apply for the
# sell prices of items.
# $game_system.selltax.percent = x
# $game_system.selltax.direct = y
# $game_system.selltax.perbon = x
# $game_system.selltax.dirbon = y
# $game_system.selltax.percent_without_bonuses
# $game_system.selltax.direct_without_bonuses
#
#
# ITEM TAGS
#
# <tax key item>
# Use the above tag if you don't want that the price of that item can be changed
# by taxes. Useful for items which the player may not buy/sell.
#
# NOTE that items which are key items in the database don't require this tag.
#
#
# <tax +/-x>
# Use the above tag to make items which will alter direct taxes. Use + to make
# it higher, - to make it lower. Enter a value for x.
#
# <tax +/-x%>
# Use the above tag to make items which will alter percentage taxes. Use + to
# make it higher, - to make it lower. WARNING!! The value you enter for x will
# be ADDED or SUBSTRACTED from the current tax.percent!!
# Examples:
# $game_system.tax.percent = 150 and an item with <tax +20%> will result in a tax
# of 170%.
#
# $game_system.tax.percent = 100 (or no value set) & an item with <tax -42%> will
# result in a tax of 58%.
#
# NOTE that if the player gets any items with these tags, the amount he/she has
# of the item determines how many times the taxes will be altered! Two of the
# same items in Example 1 will result in a tax of 190% instead of 170%.
#
# <selltax +/-x>
# Exact same effect as <tax...> but this one changes the prices of sold items.
#
# <selltax +/-x%>
# Same story as above.
#
# WARNING
# If you have originally used Shop Taxes VXA since before it was in v1.8 and
# you had changed $game_system.tax_perbon or any similar bonuses variable,
# you no longer have to add this to $game_system.tax.percent or similar variables.
# If you do not remove these additions, the taxes will continue to increase, and
# this should not be happening!
# END WARNING
#----------------------------------------------------------------------------
# Special thanks from the creator:
# Falcon for the original script
# Blizard for the idea that triggered version 2.0 (Falcon's Credits)
# You, because you ate a cookie in your life =D (I hope... If not, I'll send
# Bennett to make you eat a cookie with his manliness...)
#----------------------------------------------------------------------------
# This script should be compatible with all shop systems. If not, alert me.
#============================================================================
#
# CONFIGURATION
#
#============================================================================
class Window_ShopStatus < Window_Base
  
  TAX             = "Tax"          # Word which stands before percent tax IF the percent tax > 100
  DISCOUNT        = "Discount"     # Word which stands before percent tax IF the percent tax < 100
  TAX_DIRECT      = "Tax (A)"      # Word which stands before direct tax IF the direct tax > 0
  DISCOUNT_DIRECT = "Discount (A)" # Word which stands before direct tax IF the direct tax < 0
  TAX_INFORMATION = true           # True = show information about taxes in shops, false = well... the opposite
  TAX_X           = 4              # x position of the information of the taxes. Usually, text has an x-value of 4
  TAX_Y           = 216            # y position of the information. Default = 216. Not that text starts on y = 0 and every line has a height of y = 24

end

module EME
  module REGEXP
    module ITEM

      # Only edit things past here if you know what you're doing
      KEY_ITEM_TAG = /<tax[\s_]?key[\s_]?item>/i                  # <tax key item>
      ITEM_TAX_PER = /<tax[\s_]?[ ]*([\+\-]\d+)([%��])>/i         # <tax +/-x%>
      ITEM_TAX_DIR = /<tax[\s_]?[ ]*([\+\-]\d+)>/i                # <tax +/-x>
      ITEM_SELLTAX_PER = /<selltax[\s_]?[ ]*([\+\-]\d+)([%��])>/i # <selltax +/-x%>
      ITEM_SELLTAX_DIR = /<selltax[\s_]?[ ]*([\+\-]\d+)>/i        # <selltax +/-x>
          
    end
  end
end

#============================================================================
#
# Game_System
# Defines all needed variables for taxes.
#============================================================================

class Game_System::Tax
  attr_writer :percent
  attr_accessor :perbon
  attr_writer :direct
  attr_accessor :dirbon
  
  def percent
    return @percent + @perbon
  end
  
  def percent_without_bonus
    return @percent
  end
  
  def direct
    return @direct + @dirbon
  end
  
  def direct_without_bonus
    return @direct
  end
  
  def initialize
    @percent = 100 
    @perbon  = 0
    @direct  = 0
    @dirbon  = 0
  end

end

class Game_System
  attr_reader :tax
  attr_reader :selltax

  alias eme_tax_initialize initialize
  def initialize
    eme_tax_initialize
    @tax = Tax.new
    @selltax = Tax.new
  end

end

#============================================================================
#
# Window_ShopBuy
# Handles effects of taxes and <tax key item>.
#============================================================================

class Window_ShopBuy
  
  def price(item)
    notetag_check(item)
    if !@key_item && ($game_system.tax.percent != 100 || $game_system.tax.direct != 0)
      return @price[item] + taxes(item)
    end
    return @price[item]
  end
  
  def taxes(item)
    return (@price[item] * ($game_system.tax.percent - 100.0) / 100.0 + $game_system.tax.direct).to_i
  end
  
  def notetag_check(item)
    @key_item = false
    item.note.split(/[\r\n]+/).each { |line|
    case line
      when EME::REGEXP::ITEM::KEY_ITEM_TAG
        @key_item = true
      end
    }
  end
  
end

#============================================================================
#
# Scene_Shop
# Handles prices of key items.
#============================================================================

class Scene_Shop
    
  def selling_price
    the_selling_price = @item.price / 2
    notetag_check(@item)
    unless @key_item or @item.key_item?
      if $game_system.selltax.percent != 100
        the_selling_price *= $game_system.selltax.percent / 100
      end
      if $game_system.selltax.direct != 0
        the_selling_price += $game_system.selltax.direct
      end
    end
    return the_selling_price
  end

  def notetag_check(item)
    @key_item = false
    item.note.split(/[\r\n]+/).each { |line|
    case line
      when EME::REGEXP::ITEM::KEY_ITEM_TAG
        @key_item = true
      end
    }
  end
 
end

#============================================================================
#
# Game_Party
# Handles items which alter taxes.
#============================================================================

class Game_Party

  alias eme_tax_gain_item gain_item
  def gain_item(item, amount, include_equip = false)
    eme_tax_gain_item(item, amount, include_equip = false)
    if amount != 0 and item != nil
      item.note.split(/[\r\n]+/).each { |line|
      case line
        when EME::REGEXP::ITEM::ITEM_TAX_PER
          $game_system.tax.perbon += $1.to_i * amount
        when EME::REGEXP::ITEM::ITEM_TAX_DIR
          $game_system.tax.dirbon += $1.to_i * amount
        when EME::REGEXP::ITEM::ITEM_SELLTAX_PER
          $game_system.selltax.perbon += $1.to_i * amount
        when EME::REGEXP::ITEM::ITEM_SELLTAX_PER
          $game_system.selltax.perbon += $1.to_i * amount
        end
      }
    end
  end
    
end

#============================================================================
#
# Window_ShopStatus
# Handles information of taxes shown in shops.
#============================================================================
class Window_ShopStatus < Window_Base

  alias eme_tax_refresh refresh
  def refresh
    eme_tax_refresh
    if TAX_INFORMATION
      draw_taxes(TAX_X, TAX_Y)
    end
  end

  def draw_taxes(x, y)
    if $game_system.tax.percent != 100
      rect = Rect.new(x, y, contents.width - 4 - x, line_height)
      change_color(system_color)
      if $game_system.tax.percent > 100
        draw_text(rect, TAX + ":")
      else
        draw_text(rect, DISCOUNT + ":")
      end
      change_color(normal_color)
      draw_text(rect, $game_system.tax.percent.to_s + "%", 2)
    end
    if $game_system.tax.direct != 0
      rect = Rect.new(x, y + 24, contents.width - 4 - x, line_height)
      change_color(system_color)
      if $game_system.tax.direct > 0
        draw_text(rect, TAX_DIRECT + ":")
      else
        draw_text(rect, DISCOUNT_DIRECT + ":")
      end
      change_color(normal_color)
      draw_text(rect, $game_system.tax.direct.to_s, 2)
    end
  end

end