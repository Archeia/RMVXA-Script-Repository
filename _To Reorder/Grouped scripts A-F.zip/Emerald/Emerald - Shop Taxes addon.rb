#============================================================================
# Shop Taxes VXA - Tax Count Add-On v1.0
# By Emerald
#
# Requires Shop Taxes VX Ace by Emerald
#----------------------------------------------------------------------------
# You're free to use the script for any game, as long as you give credits
#----------------------------------------------------------------------------
# Version History
# 1.0 -> Started add-on. All basic stuff added.
#----------------------------------------------------------------------------
# This is a simple add-on to Shop Taxes VX Ace. Therefore, it requires Shop
# Taxes VX Ace
#
# Instructions:
#
# Just as always, put this script between â–¼ Materials and â–¼ Main (you get a
# cookie if you knew that already). 
#
# If you want to know the total amount the player has payed in taxes, use a
# script command in an event list and write the following:
# $game_system.tax.total_taxes_paid
# 
# The same can be done for discounts with:
# $game_system.tax_total_discounts_received
#
# You can use (and manipulate) these values through scripting, or you could
# make a variable which sets itself to a script value.
#----------------------------------------------------------------------------
# Again, this script requires Shop Taxes VXA (by Emerald)
#============================================================================
 
class Game_System::Tax
  
  attr_accessor :total_taxes_paid
  attr_accessor :total_discounts_received
  
  alias eme_tax_addon_init initialize
  def initialize
    eme_tax_addon_init
    @total_taxes_paid = 0
    @total_discounts_received = 0
  end
 
end
 
class Scene_Shop
  
  alias  eme_tax_do_buy do_buy
  def do_buy(amount)
    eme_tax_do_buy(amount)
    taxes = @buy_window.taxes(@item)
    $game_system.tax.total_taxes_paid += taxes * amount if taxes > 0
    $game_system.tax.total_discounts_received -= taxes * amount if taxes < 0
  end
  
end