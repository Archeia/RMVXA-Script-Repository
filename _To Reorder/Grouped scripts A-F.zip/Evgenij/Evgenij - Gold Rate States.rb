#===============================================================================
# ** Gold Rate States **
#
# Author:   Evgenij
# Version:  1.1
# Date:     23.07.2014
#===============================================================================
#
# Changelog:
#   V. 1.0 - 23.07.2014 - Script Created
#   V. 1.1 - 23.07.2014 - Added options to choose where this script takes effect	
#
# Description
#   Usually you can only add a feature which will double the gold and the effect
#   is only for battle. 
#   With this script you can make custom rates for gold gaining, the rates also 
#   work for events and not only in battle.
#
# Notetags for States:
#   <gold_rate: factor>
#   
#   Example: <gold_rate: 1.5>   
#     When you normaly get 100 gold you would get 150 gold with active state.
#       old_gold * 1.5 = new_gold
#===============================================================================
module EVG
  module GoldRate
    #---------------------------------------------------------------------------
    # Should Goldrate States effect battle gold gaining?
    #---------------------------------------------------------------------------
    GOLDRATE_IN_BATTLE = true
    #---------------------------------------------------------------------------
    # Should Goldrate States effect shop gold gaining?
    # Let this false, but if you insinst you can turn it on.
    #---------------------------------------------------------------------------
    GOLDRATE_IN_SHOP   = false
    
    #---------------------------------------------------------------------------
    # Should Goldrate States effect event command gold gaining?
    #---------------------------------------------------------------------------
    GOLDRATE_IN_EVENT  = true

    #---------------------------------------------------------------------------
    # If more than one State with a gold rate is active, should they all be 
    # multiplicated?
    #     => then true
    #
    # Or should only the max value be taken?
    #     => then false
    #---------------------------------------------------------------------------
    Inject_All_Rates = true
    
    #---------------------------------------------------------------------------
  end
end
#===============================================================================
class RPG::State
  #-----------------------------------------------------------------------------
  def gold_rate
    return @gold_rate ||= if @note =~ /<gold_rate:\s*(.*)\s*>/i
                            $1.to_f
                          else
                            1
                          end
  end
  #-----------------------------------------------------------------------------                    
end
class Game_Troop
  #--------------------------------------------------------------------------
  alias :evg_gt_gt_goldbuff     :gold_total
  #--------------------------------------------------------------------------
  def gold_total
    if EVG::GoldRate::GOLDRATE_IN_BATTLE && evg_gt_gt_goldbuff > 0
      return (evg_gt_gt_goldbuff * $game_party.gold_rate).to_i
    else
      return evg_gt_gt_goldbuff
    end
  end
end
#===============================================================================
class Game_Party
  #-----------------------------------------------------------------------------
  def gold_rate
    rates = all_members.map(&:states).flatten.map(&:gold_rate)
    return 1 if rates.size < 1
    return rates.inject(&:*) if EVG::GoldRate::Inject_All_Rates
    return rates.max
  end
  #-----------------------------------------------------------------------------
end

class Game_Interpreter
  #-----------------------------------------------------------------------------
  alias :evg_gi_c125_goldbuff       :command_125
  def command_125
    if EVG::GoldRate::GOLDRATE_IN_EVENT
      value = operate_value(@params[0], @params[1], @params[2])
      value = (value * $game_party.gold_rate).to_i
      $game_party.gain_gold(value)
    else
      evg_gi_c125_goldbuff
    end
  end
  #-----------------------------------------------------------------------------
end
class Scene_Shop
  alias :evg_ss_ds_goldbuff           :do_sell
  def do_sell(number)
    if EVG::GoldRate::GOLDRATE_IN_SHOP
      $game_party.gain_gold(number * selling_price * $game_party.gold_rate)
      $game_party.lose_item(@item, number)
    else
      evg_ss_ds_goldbuff(number)
    end
  end
end
#===============================================================================
# SCRIPT END
#===============================================================================