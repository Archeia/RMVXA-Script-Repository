=begin
  "Do It Yourself"-Crafting-Advanced

  Author:  Evgenij
  Version: 1.0-beta3
  Date:    31.07.2015

  You can find the terms of use at my blog: evgenij-scripts.org

  Changelog:

    1.0-beta3  :  - Fixed a bug: fixed tool is the same for all types
                    when type list are used on script call
                  - Changed the way the item category window works to
                    make the scene more smooth
                  - Added new recipe list mode for faster crafting of
                    learned recipes

    1.0-beta2  :  - Renamed the script to "DIYC-Advanced" to prevent confusion
                    with my old "DIYC" Script
                  - Ingredient slot size is now controllable via a variable
                  - Crafting Types now switchable with L/R (Q/W on Keyboard)
                  - Switched item and ingredient window positions
                  - Removed the start/view results subwindow, now crafting is
                    started via a button and results can be viewed from
                    the general command menu
                  - Updated help window to support commands
                  - Confirmation window to start the crafting added(optional)

    1.0-beta   :  - added OWN_INGREDIENT_CONTROL Flag to Settings

    1.0-alpha3 :  - Added result amount multiplier to recipes
                  - Type leveling is now optional and
                    can be changed per type
                  - Tools can now be disabled per type and
                    not globally
                  - It is now possible to disable loosing
                    items when crafting fails
                  - It is now possible to disable loosing
                    items when crafting is impossible

    1.0-alpha2 :  - Added customization for exp gauge colors
                  - Added customization to cap ingredients
                  - Fixed clear command

    1.0-alpha  :  - Pre-Release

  Installation:
    Place this Script into the Materials Section in your
    Scripteditor.

  Scriptcalls:

    Opens the normal crafting scene:
      - EVG::CraftingManager.open(crafting_type)
      - EVG::CraftingManager.open(crafting_type => :tool, ...)

    You can use as much crafting types as you want, you will need to separate
    them with a comma.

    Examples:
      # Opens crafting scene with alchemy as type
        - EVG::CraftingManager.open(:Alchemy)

      # Opens crafting scene with alchemy as type and Item 10 as fixed tool
        - EVG::CraftingManager.open(:Alchemy => :i10)

      # Opens crafting scene with switchable types (L/R Buttons)
        - EVG::CraftingManager.open(:Alchemy, :Smithing)

      # Opens crafting scene with switchable types and fixed tools
        - EVG::CraftingManager.open(:Alchemy => i10, :Smithing => i11)


  Notetags:

    <no_ingredient>
      This will hide the item in the crafting
      scene.

    These notetags can be used multiple times on one item:

    <tool: :CraftingType>
      This will also hide the item from the ingredient window
      and will show the item in the tool window in the
      matching CraftingType Scene.

    <craft_type: :CraftingType>
      This will only show this item in the ingredient window
      of the correct crafting type.

  Defining new types:

    Before I will explain how to define new Types I want to
    explain you the word Module I will be using often.
    In Ruby a Module looks like this:

    module MODULE_NAME
    end

    You will need modules for almost everything in this script.

    Then if you see this: :item you will need to replace it with
    the item you want to use.
    Examples:
      Weapon 1  would look like this:   :w1
      Item 1    would look like this:   :i1
      Armor 1   would look like this:   :a1

    So lets start:

    1. Go into CRAFTING_TYPES Module below.
    2. Copy this Template into the module:

    module Your_Type_Name
      Vocab       = "Your Type Vocab"

      # Level Settings
      Enable_Leveling = true
      # Exp formula, type_level will be replaced
      # by your current type level
      Exp_Formula     = "100 * type_level"
      Max_Level       = 50
      # Exp Gauge Colors. Use windowskin indexes
      Gauge_Color1    = 24
      Gauge_Color2    = 24

      # Tool Settings
      Enable_Tool = true

      # Setup visible categories
      # :item, :armor and :weapon possible
      Possible_Categories = [:item, :armor, :weapon]

      # How many ingredient slots should be visible?
      # Control this via an ingame variable
      # Use nil if you don't want to control this (unlimited slots)
      Ingredient_Size_Variable = nil

      # Loose Items Settings
      Loose_On_Failure    = true
      Loose_On_Impossible = true

      #Sound Settings
      Success_Me        = "Item"
      Failure_Me        = "Gag"
      Impossible_Me     = "Mystery"

      module Recipes
      end
    end

    It should look like this:

    module CRAFTING_TYPES
      module Your_Type_Name
        #...

        module Recipes
        end
      end
    end


    3. Now you need to change all the variables to your liking
    4. Recipes are missing, so you need to copy this template
       into the Recipes module in your type module:

    module Your_Recipe_Name

      # Tool can be nil or :item
      Tool            = nil
      Ingredients     = {:item => amount, :item => amount}
      Results         = {:item => amount}
      Base_Level      = 1       # Used for exp and success formulas
      Success         = 100     # Base Success Percentage
      Success_Change  = 1       # Success-Change every level
      Exp             = 20      # Base Exp
      Exp_Change      = 1       # Exp Change every level

      # Result Multiplier Settings
      Result_Multiplier = 1
      Result_Proc_Level = 1     # First Level for more results
      Result_Proc_Rate  = 0     # Chance to multiply result amount
    end

    It should look like this now:

    module CRAFTING_TYPES
      module Your_Type_Name
        #...

        module Recipes

          module Your_Recipe_Name
            #...
          end

        end
      end
    end

    You can add as many types and recipes as you want.
    Its important that every Type has a unique< name.

    I have predefined two types with recipes. So take
    a look at them if you don't understand something.
=end
module EVG
  module CRAFTING_SETTINGS

    # This button needs to be pressed to start crafting
    CRAFTING_START_BUTTON = :X

    # For easier clearing
    CRAFTING_CLEAR_BUTTON = :SHIFT

    # Lets a confirmation window popup before the actual
    # crafting starts
    USE_CONFIRMATION_WINDOW = false


    # Here you can define which types will be
    # shown in your main menu.
    # Keep in mind that this was designed for the
    # vanilla menu, so any custom menu may need
    # a compatibility patch.
    #              :type_name => enable_switch_id,
    TYPES_IN_MENU = {:Alchemy => 1}

    # If you for example have more than one Type added to your
    # menu this flag will allow switching with L and R through
    # your menu types
    CAN_SWITCH_MENU_TYPES = true

    # Learned recipes can be directly crafted when the switch
    # mode is on.
    # The player just needs to press the X-Button (S on Keyboard)
    # to switch through the crafting modes
    CAN_SWITCH_TO_RECIPE_MODE = true

    # if this is set to true, you will need to specify
    # all items with <craft_type: :type> to mark them
    # as ingredient otherwise they will be handled as
    # no ingredient.
    OWN_INGREDIENT_CONTROL = false

    #These Settings should be self explanatory
    NO_TOOL_VOCAB      = "Hands"
    NO_TOOL_ICON_INDEX = 481

    COMMAND_VOCABS = {
        :Add          => "Add",
        :Remove       => "Remove",
        :Clear        => "Clear",
        :Tool         => "Tool",
        :View_Results => "Results",
    }

    COMMAND_DESCRIPTIONS  = {
        :Add          => "Add ingredients into the slot list",
        :Remove       => "Remove ingredients from the slot list",
        :Clear        => "Clear slot list and tool",
        :Tool         => "Choose a tool you want to use",
        :View_Results => "View results if your current recipe yields a\npossible result",
    }

    SUCCESS_VOCAB         = "Success:"
    EXP_VOCAB             = "EXP:"

    CRAFTING_START_VOCAB  = "Press \"A\" to start crafting"
    RECIPE_LEARNED_VOCAB  = "New recipe learned!"
    SUCCESS_CRAFT_VOCAB   = "Successful crafted:"
    EXP_GAIN_VOCAB        = "Got %d EXP"
    FAILED_CRAFT_VOCAB    = "Crafting failed!"
    IMPOSSIBLE_VOCAB      = "Impossible recipe!"

    PREV_CATEGORY_VOCAB = "<-Q"
    NEXT_CATEGORY_VOCAB = "W->"

    # Here you can define a switch id
    # When the switch with this switch id is
    # on, the player will only be able to add
    # items into the pool which lead to possible
    # recipes.
    PERFECT_CRAFTING_SWITCH_ID = 0
    # This feature may lead to long waiting times
    # when you have defined too many recipes, so
    # if you use it and have slowdowns, send me a
    # demo with your config.
    # When I get a demo with many recipes I will
    # try to optimize this feature.
  end
  # Here you will define all your crafting types
  module CRAFTING_TYPES
    # Smithing
    module Smithing

      Vocab       = "Smithing"

      # Level Settings
      Enable_Leveling = true
      # Exp formula, type_level will be replaced
      # by your current type level
      Exp_Formula     = "100 * type_level"
      Max_Level       = 50
      # Exp Gauge Colors. Use windowskin indexes
      Gauge_Color1    = 24
      Gauge_Color2    = 24

      # Tool Settings
      Enable_Tool = true

      # Setup visible categories
      # :item, :armor and :weapon possible
      Possible_Categories = [:item, :armor, :weapon]

      # How many ingredient slots should be visible?
      # Control this via an ingame variable
      # Use nil if you don't want to control this (unlimited slots)
      Ingredient_Size_Variable = nil

      # Loose Items Settings
      Loose_On_Failure    = true
      Loose_On_Impossible = true

      #Sound Settings
      Success_Me        = "Item"
      Failure_Me        = "Gag"
      Impossible_Me     = "Mystery"

      module Recipes
        # Normal Recipes:
        module Axe1
          Tool            = nil
          Ingredients     = {:i26 => 1, :w1 => 1}
          Results         = {:w2 => 1}
          Base_Level      = 1
          Success         = 90
          Success_Change  = 5
          Exp             = 25
          Exp_Change      = 5
          # Result Multiplier Settings
          Result_Multiplier = 1
          Result_Proc_Level = 1
          Result_Proc_Rate  = 0
        end

        module Axe2
          Tool            = nil
          Ingredients     = {:i26 => 1, :w2 => 1}
          Results         = {:w3 => 1}
          Base_Level      = 2
          Success         = 80
          Success_Change  = 5
          Exp             = 40
          Exp_Change      = 7
          # Result Multiplier Settings
          Result_Multiplier = 1
          Result_Proc_Level = 1
          Result_Proc_Rate  = 0
        end

        module Axe3
          Tool            = nil
          Ingredients     = {:i26 => 1, :w3 => 1}
          Results         = {:w4 => 1}
          Base_Level      = 5
          Success         = 75
          Success_Change  = 5
          Exp             = 60
          Exp_Change      = 10
          # Result Multiplier Settings
          Result_Multiplier = 1
          Result_Proc_Level = 1
          Result_Proc_Rate  = 0
        end
      end
    end # Smithing END

    # Alchemy
    module Alchemy

      Vocab       = "Alchemy"
      # Level Settings
      Enable_Leveling = true
      # Exp formula, type_level will be replaced
      # by your current type level
      Exp_Formula     = "100 * type_level"
      Max_Level       = 50
      # Exp Gauge Colors. Use windowskin indexes
      Gauge_Color1    = 24
      Gauge_Color2    = 24

      # Tool Settings
      Enable_Tool = true

      # Setup visible categories
      # :item, :armor and :weapon possible
      Possible_Categories = [:item]

      # How many ingredient slots should be visible?
      # Control this via an ingame variable
      # Use nil if you don't want to control this (unlimited slots)
      Ingredient_Size_Variable = nil

      # Loose Items Settings
      Loose_On_Failure    = true
      Loose_On_Impossible = true

      #Sound Settings
      Success_Me        = "Item"
      Failure_Me        = "Gag"
      Impossible_Me     = "Mystery"

      module Recipes

        # Extractor Recipes:
        module Life_Powder
          Tool            = :i21
          Ingredients     = {:i24 => 1}
          Results         = {:i22 => 1}
          Base_Level      = 1
          Success         = 90
          Success_Change  = 5
          Exp             = 20
          Exp_Change      = 5
          # Result Multiplier Settings
          Result_Multiplier = 1
          Result_Proc_Level = 1
          Result_Proc_Rate  = 0
        end

        # Normal Recipes:
        module Potion
          Tool            = nil
          Ingredients     = {:i22 => 2, :i23 => 1}
          Results         = {:i1 => 1}
          Base_Level      = 1
          Success         = 90
          Success_Change  = 5
          Exp             = 25
          Exp_Change      = 5
          # Result Multiplier Settings
          Result_Multiplier = 3
          Result_Proc_Level = 1
          Result_Proc_Rate  = 0
        end

        module Potion2
          Tool            = nil
          Ingredients     = {:i22 => 3, :i23 => 1}
          Results         = {:i2 => 1}
          Base_Level      = 2
          Success         = 80
          Success_Change  = 5
          Exp             = 40
          Exp_Change      = 7
          # Result Multiplier Settings
          Result_Multiplier = 1
          Result_Proc_Level = 1
          Result_Proc_Rate  = 0
        end

        module Potion3
          Tool            = nil
          Ingredients     = {:i22 => 4, :i23 => 1}
          Results         = {:i3 => 1}
          Base_Level      = 4
          Success         = 75
          Success_Change  = 5
          Exp             = 60
          Exp_Change      = 10
          # Result Multiplier Settings
          Result_Multiplier = 1
          Result_Proc_Level = 1
          Result_Proc_Rate  = 0
        end
      end
    end # Alchemy END
  end
  # Do not edit anything further here
end
class Window_MenuCommand
  alias_method(:evg_wmc_aoc_diyc2, :add_original_commands)
  def add_original_commands
    evg_wmc_aoc_diyc2
    EVG::CRAFTING_SETTINGS::TYPES_IN_MENU.each do |type_id, switch_id|
      vocab = EVG::CraftingTypes[type_id][:Vocab]
      add_command(vocab, type_id, $game_switches[switch_id])
    end
  end
end
class Scene_Menu
  alias_method(:evg_sm_start_diyc2, :start)
  def start
    evg_sm_start_diyc2
    EVG::CRAFTING_SETTINGS::TYPES_IN_MENU.each do |type_id, switch_id|
      @command_window.set_handler(type_id, method("on_command_#{type_id}".to_sym))
    end
  end
  EVG::CRAFTING_SETTINGS::TYPES_IN_MENU.each do |type_id, switch_id|
    class_eval(%Q{def on_command_#{type_id}
      if EVG::CRAFTING_SETTINGS::CAN_SWITCH_MENU_TYPES
       type_ids = EVG::CRAFTING_SETTINGS::TYPES_IN_MENU.keys
       return EVG::CraftingManager.open(*type_ids)
      end
      EVG::CraftingManager.open(:#{type_id})
    end})
  end
end
class RPG::BaseItem
  def ingredient?
    !@note.include?("<no_ingredient>")
  end

  def correct_type?(type_id)
    (!EVG::CRAFTING_SETTINGS::OWN_INGREDIENT_CONTROL && craft_type_ids.empty?) || craft_type_ids.include?(type_id)
  end

  def craft_type_ids
    @craft_type_ids ||= @note.scan(/<craft_type: *(\w+) *>/i).flatten.map(&:to_sym)
  end

  def tool_type_ids
    @tool_type_ids ||= @note.scan(/<tool: *(\w+) *>/i).flatten.map(&:to_sym)
  end

  def tool?
    !@tool_type_ids.empty?
  end
end
class RPG::Item
  def to_sym
    "i#{id}".to_sym
  end
end
class RPG::Weapon
  def to_sym
    "w#{id}".to_sym
  end
end
class RPG::Armor
  def to_sym
    "a#{id}".to_sym
  end
end
module EVG
  module Converter
    WEAPON_REGEX  = /^(w|weapon|waffe)-?_?(\d+)$/i
    ITEM_REGEX    = /^(i|item)-?_?(\d+)$/i
    ARMOR_REGEX   = /^(a|armor|r|rüstung)-?_?(\d+)$/i

    def self.sym_to_item(sym)
      case sym.to_s
        when WEAPON_REGEX
          $data_weapons[$2.to_i]
        when ITEM_REGEX
          $data_items[$2.to_i]
        when ARMOR_REGEX
          $data_armors[$2.to_i]
        else
          nil
      end
    end

    def self.module_to_hash(modul)
      module_hash = {}
      modul.constants.each do |const|
        module_hash[const.to_sym] = if modul.const_get(const).is_a?(Module)
                                      module_to_hash(modul.const_get(const))
                                    else
                                      modul.const_get(const)
                                    end
      end if modul.respond_to?(:constants)
      module_hash
    end
  end
end
module EVG
  CraftingTypes = Converter.module_to_hash(CRAFTING_TYPES)
end
module EVG
  module CraftingManager
    def self.open(*args)
      SceneManager.call(Scene_Crafting)
      types = args[0].is_a?(Hash) ? args[0] : Hash[args.map{|t| [t, nil]}]
      init(types)
    end

    def self.open_shop(*args)
      SceneManager.call(Scene_Crafting)
      types = args[0].is_a?(Hash) ? args[0] : Hash[args.map{|t| [t, nil]}]
      init(types, true)
    end

    def self.init(types, index = 0, shop = false, recipe_mode = false)
      current_recipe.clear
      @index       = index
      @types       = types
      @custom_tool = nil
      @shop        = shop
      @recipe_mode = recipe_mode
      calculate_recipes
    end

    def self.type_id
      @types.keys[@index]
    end

    def self.crafting_type
      $game_system.crafting_types[type_id]
    end

    def self.current_recipe
      @current_recipe ||= Pseudo_CraftingRecipe.new
    end

    def self.current_tool
      fixed_tool? && fixed_tool || custom_tool
    end

    def self.custom_tool
      @custom_tool
    end

    def self.fixed_tool
      @types[type_id]
    end

    def self.fixed_tool?
      !!fixed_tool
    end

    def self.shop?
      @shop
    end

    def self.matching_recipe
      @matching_recipes.first
    end

    def self.impossible_recipe?
      crafting_type.impossible_recipes.include?(current_recipe)
    end

    def self.can_switch_categories?
      @types.size > 1
    end

    def self.recipe_mode?
      @recipe_mode
    end

    def self.next_type
      id = @types.keys[(@index + 1) % @types.size]
      $game_system.crafting_types[id]
    end

    def self.previous_type
      id = @types.keys[(@index - 1) % @types.size]
      $game_system.crafting_types[id]
    end

    def self.next_category
      @index = (@index + 1) % @types.size
      init(@types, @index, @shop, @recipe_mode)
    end

    def self.previous_category
      @index = (@index - 1) % @types.size
      init(@types, @index, @shop, @recipe_mode)
    end

    def self.toggle_recipe_mode
      @recipe_mode = !@recipe_mode
      clear
    end

    def self.calc_possible_recipes(cur_recipe, recipe_list)
      recipe_list.select do |recipe|
        cur_recipe.tool == recipe.tool &&
            (cur_recipe.ingredients.keys - recipe.ingredients.keys).empty? &&
            cur_recipe.ingredients.keys.all? do |ingredient|
              recipe.ingredients[ingredient] - cur_recipe.ingredients[ingredient] >= 0
            end
      end
    end

    def self.calculate_recipes
      @possible_recipes = calc_possible_recipes(current_recipe, crafting_type.recipes)
      @matching_recipes = @possible_recipes.select{|recipe| recipe == current_recipe}
    end

    def self.rec_calculate_recipes
      @possible_recipes = calc_possible_recipes(current_recipe, @possible_recipes)
      @matching_recipes = @possible_recipes.select{|recipe| recipe == current_recipe}
    end

    def self.can_change?(ingredient, amount)
      next_recipe = Marshal.load(Marshal.dump(current_recipe))
      next_recipe.change_ingredient(ingredient, amount)
      !calc_possible_recipes(next_recipe, @possible_recipes).empty?
    end

    def self.can_craft?(recipe = nil)
      return false if $game_switches[CRAFTING_SETTINGS::PERFECT_CRAFTING_SWITCH_ID] && !matching_recipe
      recipe ||= current_recipe
      !recipe.ingredients.empty? && recipe.ingredients.all? do |ingredient, amount|
        $game_party.item_number(Converter.sym_to_item(ingredient)) >= amount
      end
    end

    def self.clear
      current_recipe.clear
      calculate_recipes
    end

    def self.set_tool(tool)
      @custom_tool = tool && tool.to_sym
      calculate_recipes
    end

    def self.add_ingredient(ingredient, amount)
      current_recipe.change_ingredient(ingredient, amount.abs)
      rec_calculate_recipes
    end

    def self.remove_ingredient(ingredient, amount)
      current_recipe.change_ingredient(ingredient, -(amount.abs))
      calculate_recipes
    end

    def self.set_recipe(recipe)
      current_recipe.set(recipe)
      calculate_recipes
    end
  end
end
module EVG
  module Comparable_Recipe
    def ==(other)
      return false unless (other.respond_to?(:ingredients) &&
          other.respond_to?(:tool))
      ingredients == other.ingredients && tool == other.tool
    end
    alias_method(:eql?, :==)
  end
  class Pseudo_CraftingRecipe
    include Comparable_Recipe
    attr_reader :ingredients
    def initialize(ingredients = {})
      @ingredients = ingredients
    end

    def set(recipe)
      return unless recipe
      clear
      recipe.ingredients.each{|i, a| change_ingredient(i, a)}
      CraftingManager.set_tool(recipe.tool)
    end

    def change_ingredient(ingredient, amount)
      return unless ingredient
      @ingredients[ingredient.to_sym] ||= 0
      @ingredients[ingredient.to_sym] += amount
      @ingredients.delete_if{|i, a| a <= 0}
    end

    def tool
      CraftingManager.current_tool
    end

    def clear
      @ingredients.clear
    end
  end
  class Impossible_CraftingRecipe
    include Comparable_Recipe
    attr_reader :ingredients, :tool
    def initialize(ingredients = {}, tool = nil)
      @ingredients = ingredients
      @tool        = tool
    end
  end
  class CraftingRecipe
    include Comparable_Recipe
    attr_reader :id, :type, :vocab

    def initialize(type, recipe_id)
      @type  = type
      @id    = recipe_id
      @vocab = @id.to_s.split("_").join(" ")
    end

    def recipe_data
      EVG::CraftingTypes[@type.id][:Recipes][@id]
    end

    def tool
      recipe_data[:Tool]
    end

    def ingredients
      recipe_data[:Ingredients]
    end

    def results
      recipe_data[:Results]
    end

    def success_rate
      [(recipe_data[:Success] + success_change + success_plus) * success_mult / 100.to_f, 1].min
    end

    def success_change
      return 0 unless @type.leveling_enabled?
      (@type.level - recipe_data[:Base_Level]) *
          recipe_data[:Success_Change]
    end

    def success_plus
      0
    end

    def success_mult
      1
    end

    def exp
      [((recipe_data[:Exp] +
          (recipe_data[:Base_Level] - @type.level) *
              recipe_data[:Exp_Change]) +
          exp_plus) * exp_mult, 0].max.to_i
    end

    def exp_plus
      0
    end

    def exp_mult
      1
    end

    def result_amount(result)
      amount = results[result]
      amount *= result_multiplier if more_results?
      amount
    end

    def result_multiplier
      recipe_data[:Result_Multiplier]
    end

    def result_proc_level
      recipe_data[:Result_Proc_Level]
    end

    def result_proc_rate
      recipe_data[:Result_Proc_Rate] / 100.to_f
    end

    def more_results?
      return false if @type.level < result_proc_level
      rand <= result_proc_rate
    end

    def gold_cost
      recipe_data[:Gold_Cost] || @type.default_gold_cost || 0
    end
  end
end
module EVG
  class CraftingType
    attr_reader :id, :level, :exp, :learned_recipes, :impossible_recipes

    def initialize(type_id)
      @id = type_id
      @exp = 0
      @level = 1
      @learned_recipes = []
      @impossible_recipes = []
      reload_data
    end

    def type_data
      EVG::CraftingTypes[@id]
    end

    def reload_data
      collect_tools
      create_recipe_objects
      correct_impossible_recipes
      create_exp_table
      change_exp(0)
    end

    def collect_tools
      @tools = ($data_items | $data_weapons | $data_armors).compact.select{|item| item.tool_type_ids.include?(@id)}
    end

    def create_recipe_objects
      @recipes = Hash[type_data[:Recipes].map do |recipe_id, settings|
        [recipe_id, CraftingRecipe.new(self, recipe_id)]
      end]
    end

    def correct_impossible_recipes
      @impossible_recipes.delete_if{|recipe| recipes.include?(recipe)}
    end

    def create_exp_table
      @exp_table = []
      max_level.times do |level|
        level_exp = eval(type_data[:Exp_Formula]
                             .gsub("type_level", level.to_s))
        level_exp += @exp_table[level] if level > 0
        @exp_table[level + 1] = level_exp
      end
    end

    def recipes_hash
      @recipes
    end

    def recipes
      recipes_hash.values
    end

    def vocab
      type_data[:Vocab]
    end

    def leveling_enabled?
      type_data[:Enable_Leveling]
    end

    def tool_enabled?
      type_data[:Enable_Tool]
    end

    def loose_on_failure?
      type_data[:Loose_On_Failure]
    end

    def loose_on_impossible?
      type_data[:Loose_On_Impossible]
    end

    def max_level
      type_data[:Max_Level]
    end

    def possible_categories
      type_data[:Possible_Categories]
    end

    def success_me
      type_data[:Success_Me]
    end

    def failure_me
      type_data[:Failure_Me]
    end

    def impossible_me
      type_data[:Impossible_Me]
    end

    def gauge_color1
      type_data[:Gauge_Color1]
    end

    def gauge_color2
      type_data[:Gauge_Color2]
    end

    def ingredient_cap
      id = type_data[:Ingredient_Size_Variable]
      id && $game_variables[id]
    end

    def result_cap
      type_data[:Result_Size]
    end

    def default_gold_cost
      type_data[:Default_Gold_Cost]
    end

    def impossible_gold_cost_min
      type_data[:Impossible_Gold_Cost_Min]
    end

    def impossible_gold_cost_max
      type_data[:Impossible_Gold_Cost_Max]
    end

    def max_level?
      @level == max_level
    end

    def tools
      @tools
    end

    def next_level_exp
      @exp_table[@level + 1]
    end

    def current_level_exp
      @exp_table[@level]
    end

    def exp_rate
      return 1 if max_level?
      cur_exp  = @exp - current_level_exp
      next_exp = next_level_exp - current_level_exp
      [cur_exp / next_exp.to_f, 1].min
    end

    def change_exp(exp)
      @exp = [@exp + exp, 0].max.to_i
      level_up    until max_level? || self.exp < next_level_exp
      level_down  while self.exp < current_level_exp
    end

    def level_up
      @level += 1
    end

    def level_down
      @level -= 1
    end

    def learn_recipe(recipe_id)
      return if @learned_recipes.include?(recipe_id)
      @learned_recipes.push(recipe_id)
    end

    def forget_recipe(recipe_id)
      @learned_recipes.delete(recipe_id)
    end

    def add_impossible_recipe(ingredients, tool)
      recipe = Impossible_CraftingRecipe.new(ingredients.dup, tool)
      return if @impossible_recipes.include?(recipe)
      @impossible_recipes.push(recipe)
    end
  end
end
class Game_System
  attr_reader :crafting_types

  alias_method(:evg_gs_initialize_diyc2, :initialize)
  def initialize
    evg_gs_initialize_diyc2
    @crafting_types = initialize_crafting_types
  end

  def initialize_crafting_types
    Hash[EVG::CraftingTypes.map do |type_id, settings|
           [type_id, EVG::CraftingType.new(type_id)]
         end]
  end
end

module DataManager
  class << self
    alias_method(:evg_dn_esc_diyc2, :extract_save_contents)
  end

  def self.extract_save_contents(contents)
    evg_dn_esc_diyc2(contents)
    $game_system.crafting_types.values.each(&:reload_data)
  end
end
class Game_Temp
  attr_reader :crafting_recipes

  alias_method(:evg_gt_initialize_diyc2, :initialize)
  def initialize
    evg_gt_initialize_diyc2
  end
end
module EVG
  class Window_CraftingList < Window_Selectable
    def initialize(x, y, width, height)
      @col_max = (width - standard_padding * 2) / (item_width + spacing)
      super(x, y, width, height)
      @list = []
      refresh
    end

    def col_max
      @col_max
    end

    def max_rows
      contents_height / (item_height + spacing)
    end

    def reset_font_settings
      super
      contents.font.size = 14
      contents.font.bold = true
    end

    def contents_height
      [height - standard_padding * 2, row_max * (item_height + spacing)].max
    end

    def update_padding
      super
      self.padding_bottom = padding
    end

    def top_row
      oy / (item_height + spacing)
    end

    def top_row=(row)
      row = 0 if row < 0
      row = row_max - 1 if row > row_max - 1
      self.oy = row * (item_height + spacing)
    end

    def page_row_max
      (height - padding - padding_bottom) / (item_height + spacing)
    end

    def item_width
      32
    end

    def item_height
      32
    end

    def spacing
      2
    end

    def item_max
      @list ? @list.size : 0
    end

    def item_rect(index)
      rect = Rect.new
      rect.width = item_width
      rect.height = item_height
      rect.x = index % col_max * (item_width + spacing)
      rect.y = index / col_max * (item_height + spacing)
      rect
    end

    def icon_rect(index)
      icon_rect = item_rect(index)
      icon_rect.x += (item_width - 24) / 2
      icon_rect.y += (item_height - 24) / 2
      icon_rect.width = 24
      icon_rect.height = 24
      icon_rect
    end

    def background_rect(index)
      bg_rect = item_rect(index)
      bg_rect.x += 2
      bg_rect.y += 2
      bg_rect.width -= 4
      bg_rect.height -= 4
      bg_rect
    end

    def amount_x(index)
      item_rect(index).x + 4
    end

    def amount_y(index)
      item_rect(index).y + item_rect(index).height - 18
    end

    def clear_list
      @list.clear
    end

    def add_item(item, amount)
      @list.push(item: Converter.sym_to_item(item.to_sym), amount: amount)
    end

    def item(index)
      @list[index] ? @list[index][:item] : nil
    end

    def amount(index)
      @list[index][:amount]
    end

    def amount_string(index)
      amount(index).to_s
    end

    def item_enabled?(index)
      true
    end

    def current_item
      item(@index)
    end

    def current_item_enabled?
      item_enabled?(@index)
    end

    def draw_item(index)
      draw_icon(item(index).icon_index, icon_rect(index).x, icon_rect(index).y, item_enabled?(index))
      draw_text_ex(amount_x(index), amount_y(index), amount_string(index)) if amount(index) > 1
    end

    def draw_background(index)
      contents.fill_rect(background_rect(index), background_color)
    end

    def draw_backgrounds
      background_times.times {|index| draw_background(index)}
    end

    def background_times
      item_max < (max_rows * col_max) ? (max_rows * col_max) : item_max
    end

    def draw_backgrounds?
      false
    end

    def background_color
      Color.new(0, 0, 0, 128)
    end

    def update_help
      @help_window.set_item(current_item)
    end

    def refresh
      clear_item_list
      make_item_list
      create_contents
      draw_backgrounds if draw_backgrounds?
      draw_all_items
    end

    def clear_item_list
      @list.clear
    end

    def make_item_list
    end
  end
end

class Window_Base
  def draw_underline(x, y, width)
    contents.fill_rect(x, y + line_height - 1, width, 1, underline_color)
  end

  def underline_color
    Color.new(0,0,0,128)
  end
end
module EVG
  class Scene_Crafting < Scene_MenuBase
    def start
      super
      create_help_window
      create_header_window
      create_command_window
      create_item_category_window
      create_item_window
      create_tool_window
      create_result_window
      create_ingredient_window
      create_result_list_window
      create_recipe_window
      create_confirmation_window
      create_notification_window
      collect_all_windows
      @sound = RPG::ME.new
    end

    def create_help_window
      @help_window = Window_CraftingHelp.new
    end

    def create_header_window
      @header_window = Window_CraftingHeader.new
    end

    def create_command_window
      @command_window = Window_CraftingCommand.new
      @command_window.set_handler(:cancel, method(:return_scene))
      @command_window.set_handler(:pageup, method(:on_command_pageup))
      @command_window.set_handler(:pagedown, method(:on_command_pagedown))
      @command_window.set_handler(:switch_mode, method(:on_command_switch))
      @command_window.set_handler(:Add, method(:on_command_add))
      @command_window.set_handler(:Remove, method(:on_command_remove))
      @command_window.set_handler(:Clear, method(:on_command_clear))
      @command_window.set_handler(:Tool, method(:on_command_tool))
      @command_window.set_handler(:View_Results, method(:on_command_view_results))
      @command_window.help_window = @help_window
    end

    def create_item_category_window
      y = @command_window.y + @command_window.height
      height = Graphics.height - y - @help_window.height
      @item_category_window = Window_CraftingItemCategory.new(0, y, Graphics.width / 2, height)
    end

    def create_item_window
      y = @item_category_window.y + @command_window.height
      height = Graphics.height - y - @help_window.height
      @item_window = Window_CraftingItemList.new(0, y, Graphics.width / 2, height)
      @item_window.set_handler(:cancel, method(:on_item_cancel))
      @item_window.set_handler(:ok, method(:on_item_ok))
      @item_window.help_window = @help_window
      @item_window.category_window = @item_category_window
    end

    def create_recipe_window
      y = @command_window.y + @command_window.height
      height = Graphics.height - y - @help_window.height
      @recipe_window = Window_CraftingRecipeList.new(0, y, Graphics.width / 2, height)
      @recipe_window.set_handler(:ok, method(:on_recipe_ok))
      @recipe_window.set_handler(:cancel, method(:on_recipe_cancel))
      @recipe_window.windows_to_refresh = [@result_list_window, @dummy_window, @ingredient_window, @command_window]
    end

    def create_tool_window
      y = @command_window.y + @command_window.height
      height = Graphics.height - y - @help_window.height
      @tool_window = Window_CraftingToolList.new(0, y, Graphics.width / 2, height)
      @tool_window.help_window = @help_window
      @tool_window.set_handler(:cancel, method(:on_tool_cancel))
      @tool_window.set_handler(:ok, method(:on_tool_ok))
    end

    def create_result_window
      x = Graphics.width / 2
      y = @command_window.y + @command_window.height
      height = Graphics.height - y - @help_window.height
      @dummy_window = Window_CraftingDummy.new(x, y, Graphics.width / 2, height)
      @dummy_window.set_handler(:Craft, method(:on_dummy_start))
      @dummy_window.set_handler(:Clear, method(:on_dummy_clear))
    end

    def create_ingredient_window
      x = Graphics.width / 2
      y = @dummy_window.y + @command_window.height
      @ingredient_window = Window_CraftingIngredientList.new(x, y)
      @ingredient_window.help_window = @help_window
      @ingredient_window.set_handler(:cancel, method(:on_ingredient_cancel))
      @ingredient_window.set_handler(:ok, method(:on_ingredient_ok))
    end

    def create_result_list_window
      x = Graphics.width / 2
      y = Graphics.height - @help_window.height - @ingredient_window.height
      @result_list_window = Window_CraftingResultList.new(x, y)
      @result_list_window.help_window = @help_window
      @result_list_window.set_handler(:cancel, method(:on_result_list_cancel))
    end

    def create_confirmation_window
      @confirmation_window = Window_CraftingConfirmation.new
      @confirmation_window.set_handler(:Yes, method(:on_confirmation_yes))
      @confirmation_window.set_handler(:No, method(:on_confirmation_no))
      @confirmation_window.set_handler(:cancel, method(:on_confirmation_no))
    end

    def create_notification_window
      @notification_window = Window_CraftingNotification.new
      @notification_window.set_handler(:ok, method(:on_notification_ok))
    end

    def collect_all_windows
      @windows = instance_variables.each.select{|v| instance_variable_get(v).is_a?(Window)}
      @windows.map!{|w| instance_variable_get(w)}
    end

    def on_command_pagedown
      CraftingManager.next_category
      refresh_windows
      @item_category_window.deactivate
      @item_category_window.select(0)
      @command_window.activate
    end

    def on_command_pageup
      CraftingManager.previous_category
      refresh_windows
      @item_category_window.deactivate
      @item_category_window.select(0)
      @command_window.activate
    end

    def on_command_switch
      if CraftingManager.recipe_mode?
        @recipe_window.close
        @item_category_window.open
        @item_window.open
        @command_window.activate
      else
        @item_category_window.close
        @item_window.close
        @recipe_window.open
        @command_window.activate
      end
      CraftingManager.toggle_recipe_mode
      refresh_windows
    end

    def on_command_add
      @command_window.deactivate
      if CraftingManager.recipe_mode?
        @recipe_window.activate
      else
        @item_category_window.activate
        @item_category_window.refresh
        @item_window.select(0)
        @item_window.activate
      end
    end

    def on_command_remove
      @command_window.deactivate
      @ingredient_window.activate
      @ingredient_window.select(0)
    end

    def on_command_clear
      CraftingManager.clear
      refresh_windows
      @command_window.activate
    end

    def on_command_tool
      if CraftingManager.recipe_mode?
        @recipe_window.close
      else
        @item_category_window.close
        @item_window.close
      end
      @tool_window.open
      @command_window.deactivate
      @tool_window.activate
      @tool_window.select(0)
    end

    def on_command_view_results
      @command_window.deactivate
      @result_list_window.activate
      @result_list_window.select(0)
    end


    def on_item_cancel
      @item_category_window.deactivate
      @item_category_window.refresh
      @item_window.deactivate
      @item_window.select(-1)
      @help_window.reset
      @command_window.activate
    end

    def on_item_ok
      CraftingManager.add_ingredient(@item_window.current_item, 1)
      refresh_windows
      @item_window.activate
    end

    def on_recipe_ok
      @recipe_window.activate
      on_dummy_start
    end

    def on_recipe_cancel
      @recipe_window.deactivate
      @command_window.activate
    end

    def on_tool_cancel
      if CraftingManager.recipe_mode?
        @recipe_window.open
      else
        @item_category_window.open
        @item_window.open
      end
      @tool_window.close
      @tool_window.deactivate
      @command_window.activate
      @help_window.set_item(nil)
    end

    def on_tool_ok
      new_tool = same_tool? ? nil : @tool_window.current_item
      CraftingManager.set_tool(new_tool)
      refresh_windows
      @tool_window.activate
    end

    def on_result_cancel
      @dummy_window.deactivate
      @command_window.activate
    end

    def on_dummy_start
      @active_windows = get_active_windows
      @active_windows.each(&:deactivate)
      if CRAFTING_SETTINGS::USE_CONFIRMATION_WINDOW
        @confirmation_window.open
        @confirmation_window.activate
      else
        start_crafting
        @notification_window.open
      end
    end

    def on_dummy_clear
      CraftingManager.clear unless @recipe_window.active
      refresh_windows
    end

    def on_ingredient_cancel
      @ingredient_window.deactivate
      @ingredient_window.select(-1)
      @command_window.activate
      @help_window.reset
    end

    def on_ingredient_ok
      CraftingManager.remove_ingredient(@ingredient_window.current_item, 1)
      refresh_windows
      if CraftingManager.current_recipe.ingredients.empty?
        on_ingredient_cancel
      else
        @ingredient_window.activate
      end
    end

    def on_result_list_cancel
      @result_list_window.deactivate
      @result_list_window.select(-1)
      @command_window.activate
      @help_window.reset
    end

    def on_confirmation_yes
      @confirmation_window.deactivate
      @confirmation_window.close
      start_crafting
      @notification_window.open
    end

    def on_confirmation_no
      @confirmation_window.deactivate
      @confirmation_window.close
      @active_windows.each(&:activate) if @active_windows
    end

    def on_notification_ok
      @notification_window.close
      @active_windows.each(&:activate) if @active_windows
      RPG::ME.stop
    end

    def refresh_windows
      @windows.each(&:refresh)
    end

    def get_active_windows
      @windows.select{|w| w.active }
    end

    def same_tool?
      old_tool = CraftingManager.current_recipe.tool
      new_tool = @tool_window.current_item
      (old_tool && old_tool.to_sym) == (new_tool && new_tool.to_sym)
    end

    def crafting_successful?
      r = rand
      r <= CraftingManager.matching_recipe.success_rate
    end

    def start_crafting
      if CraftingManager.matching_recipe
        crafting_successful? ? on_crafting_success : on_crafting_failure
      else
        on_crafting_impossible
      end
      refresh_windows
    end

    def on_crafting_success
      remove_items_from_party
      learn_recipe if first_time_crafted?
      claim_all_results
      add_exp if CraftingManager.crafting_type.leveling_enabled?
      play_sound(CraftingManager.crafting_type.success_me)
    end

    def on_crafting_failure
      remove_items_from_party if CraftingManager.crafting_type.loose_on_failure?
      @notification_window.add_line(CRAFTING_SETTINGS::FAILED_CRAFT_VOCAB)
      play_sound(CraftingManager.crafting_type.failure_me)
    end

    def on_crafting_impossible
      remove_items_from_party if CraftingManager.crafting_type.loose_on_impossible?
      ingredients = CraftingManager.current_recipe.ingredients
      tool = CraftingManager.current_recipe.tool
      CraftingManager.crafting_type.add_impossible_recipe(ingredients, tool)
      @notification_window.add_line(CRAFTING_SETTINGS::IMPOSSIBLE_VOCAB)
      play_sound(CraftingManager.crafting_type.impossible_me)
    end

    def remove_items_from_party
      CraftingManager.current_recipe.ingredients.each do |ingredient, amount|
        $game_party.lose_item(Converter.sym_to_item(ingredient), amount)
      end
    end

    def add_exp
      exp = CraftingManager.matching_recipe.exp
      CraftingManager.crafting_type.change_exp(exp)
      @notification_window.add_line("")
      @notification_window.add_line(CRAFTING_SETTINGS::EXP_GAIN_VOCAB % exp)
    end

    def learn_recipe
      recipe_id = CraftingManager.matching_recipe.id
      CraftingManager.crafting_type.learn_recipe(recipe_id)
      @notification_window.add_line(CRAFTING_SETTINGS::RECIPE_LEARNED_VOCAB)
    end

    def first_time_crafted?
      recipe_id = CraftingManager.matching_recipe.id
      !CraftingManager.crafting_type.learned_recipes.include?(recipe_id)
    end

    def claim_all_results
      @notification_window.add_line(CRAFTING_SETTINGS::SUCCESS_CRAFT_VOCAB)
      CraftingManager.matching_recipe.results.each do |result, amount|
        item = Converter.sym_to_item(result)
        amount = CraftingManager.matching_recipe.result_amount(result)
        $game_party.gain_item(item, amount)
        line = "[item=#{result}][amount=#{amount}]"
        @notification_window.add_line(line)
      end
    end

    def play_sound(name)
      RPG::ME.stop
      @sound.name = name || ""
      @sound.play
    end
  end
end
module EVG
  class Window_CraftingCommand < Window_HorzCommand
    def initialize
      super(0, fitting_height(1))
    end

    def col_max
      use_tool_feature? ? 5 : 4
    end

    def window_width
      Graphics.width
    end

    def type_id
      CraftingManager.crafting_type && CraftingManager.crafting_type.id
    end

    def make_command_list
      add_command(CRAFTING_SETTINGS::COMMAND_VOCABS[:Add], :Add)
      add_command(CRAFTING_SETTINGS::COMMAND_VOCABS[:Remove], :Remove, remove_enabled?)
      add_command(CRAFTING_SETTINGS::COMMAND_VOCABS[:Clear], :Clear,  clear_enabled?)
      add_command(CRAFTING_SETTINGS::COMMAND_VOCABS[:Tool], :Tool,   tool_enabled?) if use_tool_feature?
      add_command(CRAFTING_SETTINGS::COMMAND_VOCABS[:View_Results], :View_Results, view_results?)
    end

    def update_help
      @help_window.set_command(current_data)
    end

    def call_handler(current_symbol)
      super(current_symbol)
      @help_window.set_command(nil) if ![:pagedown, :pageup].include?(current_symbol)
    end

    def process_handling
      return unless open? && active
      return process_ok       if ok_enabled?        && Input.trigger?(:C)
      return process_cancel   if cancel_enabled?    && Input.trigger?(:B)
      cwc = CraftingManager.can_switch_categories?
      return process_pagedown if handle?(:pagedown) && Input.trigger?(:R) && cwc
      return process_pageup   if handle?(:pageup)   && Input.trigger?(:L) && cwc
      sm_on = CRAFTING_SETTINGS::CAN_SWITCH_TO_RECIPE_MODE
      return process_switch_mode if handle?(:switch_mode) && Input.trigger?(:Y) && sm_on
    end

    def process_switch_mode
      Input.update
      call_handler(:switch_mode)
    end

    def remove_enabled?
      !CraftingManager.current_recipe.ingredients.empty?
    end

    def clear_enabled?
      remove_enabled? || CraftingManager.fixed_tool != CraftingManager.current_recipe.tool
    end

    def tool_enabled?
      return false if CraftingManager.fixed_tool?
      $game_party.all_items.count{|item| item.tool_type_ids.include?(type_id)} > 0
    end

    def view_results?
      CraftingManager.matching_recipe && learned_recipe?
    end

    def craft_enabled?
      CraftingManager.can_craft?
    end

    def learned_recipe?
      CraftingManager.crafting_type.learned_recipes.include?(CraftingManager.matching_recipe.id)
    end

    def use_tool_feature?
      CraftingManager.crafting_type.tool_enabled?
    end
  end
end
module EVG
  class Window_CraftingConfirmation < Window_HorzCommand
    def initialize
      super(window_x, window_y)
      deactivate
      self.openness = 0
    end

    def window_x
      (Graphics.width - window_width) / 2
    end

    def window_y
      (Graphics.height - window_height) / 2
    end

    def window_width
      Graphics.width / 2
    end

    def window_height
      fitting_height(2)
    end

    def col_max
      2
    end

    def contents_height
      window_height - standard_padding * 2
    end


    def item_rect(index)
      rect = super(index)
      rect.y += line_height
      rect
    end

    def make_command_list
      add_command("Yes", :Yes)
      add_command("No", :No)
    end

    def refresh
      super
      draw_text(0, 0, contents.width, line_height, "Proceed with crafting?", 1)
    end

    def process_handling
      return unless open? && active
      ok_triggers = [:C, CRAFTING_SETTINGS::CRAFTING_START_BUTTON]
      return process_ok       if ok_enabled?        && ok_triggers.any?{|t| Input.trigger?(t)}
      return process_cancel   if cancel_enabled?    && Input.trigger?(:B)
      return process_pagedown if handle?(:pagedown) && Input.trigger?(:R)
      return process_pageup   if handle?(:pageup)   && Input.trigger?(:L)
    end
  end
end
module EVG
  class Window_CraftingDummy < Window_Selectable
    def initialize(x, y, width, height)
      super(x, y, width, height)
      activate
      refresh
    end

    def can_start?
      CraftingManager.can_craft?
    end

    def view?
      CraftingManager.matching_recipe && learned_recipe?
    end

    def learned_recipe?
      CraftingManager.crafting_type.learned_recipes.include?(CraftingManager.matching_recipe.id)
    end

    def process_handling
      return unless open? && active
      return process_ok       if ok_enabled?        && Input.trigger?(:C)
      return process_cancel   if cancel_enabled?    && Input.trigger?(:B)
      return process_pagedown if handle?(:pagedown) && Input.trigger?(:R)
      return process_pageup   if handle?(:pageup)   && Input.trigger?(:L)
      return process_crafting if handle?(:Craft)    && Input.trigger?(:X)
      return process_clearing if handle?(:Clear)    && Input.trigger?(CRAFTING_SETTINGS::CRAFTING_CLEAR_BUTTON)
    end

    def process_crafting
      Input.update
      call_handler(:Craft) if can_start?
    end

    def process_clearing
      Input.update
      call_handler(:Clear)
    end

    def refresh
      super
      change_color(normal_color, can_start?)
      draw_text(0,0, contents.width, line_height, CRAFTING_SETTINGS::CRAFTING_START_VOCAB, 1)
      draw_lines
      draw_result_info unless CraftingManager.current_recipe.ingredients.empty?
    end

    def draw_lines
      draw_underline(0, line_height / 2, contents.width)
      draw_underline(0, line_height * 2.7, contents.width)
      draw_underline(0, contents.height - line_height * 2.5, contents.width)
    end

    def draw_result_info
      change_color(normal_color)
      draw_text(0, line_height * 4, contents.width, line_height, CRAFTING_SETTINGS::SUCCESS_VOCAB)
      draw_text(0, line_height * 4, contents.width, line_height, success, 2)
      draw_text(0, line_height * 5, contents.width, line_height, CRAFTING_SETTINGS::EXP_VOCAB)
      draw_text(0, line_height * 5, contents.width, line_height, exp, 2)
    end

    def success
      rate = "???"
      rate = "0" if impossible_recipe?
      rate = success_rate.to_s if view?
      "%s%" % rate
    end

    def exp
      exp = "???"
      exp = "0" if impossible_recipe?
      exp = exp_amount.to_s if view?
      "%s" % exp
    end

    def impossible_recipe?
      return false if $game_switches[CRAFTING_SETTINGS::PERFECT_CRAFTING_SWITCH_ID]
      CraftingManager.impossible_recipe?
    end

    def success_rate
      (CraftingManager.matching_recipe.success_rate * 100).to_i
    end

    def exp_amount
      CraftingManager.matching_recipe.exp
    end
  end
end
module EVG
  class Window_CraftingHeader < Window_Base
    def initialize
      super(0,0, Graphics.width, fitting_height(1))
      @tool =
      refresh
    end

    def type
      CraftingManager.crafting_type
    end

    def type_id
      type && type.id
    end

    def tool
      Converter.sym_to_item(CraftingManager.current_recipe.tool)
    end

    def refresh
      contents.clear
      draw_exp_gauge(0, 0, Graphics.width / 2 - 12) if type.leveling_enabled?
      draw_type_name(0, 0, Graphics.width / 2 - 12, line_height)
      draw_item_text(Graphics.width / 2, 0, Graphics.width / 2) if type.tool_enabled?
    end

    def draw_exp_gauge(x, y, width)
      draw_gauge(x, y, width, type.exp_rate, color1, color2)
      change_color(system_color)
      draw_text(width - 56, y, 32, line_height, Vocab::level_a)
      change_color(normal_color)
      draw_text(width - 24, y, 24, line_height, type.level, 2)
    end

    def draw_type_name(x, y, width, height)
      draw_text(x, y, width, height, type.vocab)
    end

    def draw_item_text(x, y, width)
      draw_underline(x, y, width)
      draw_icon(tool_icon, x + 4, y)
      draw_text(x + 28, y, width, line_height, tool_name)
    end

    def tool_icon
      tool ? tool.icon_index : EVG::CRAFTING_SETTINGS::NO_TOOL_ICON_INDEX
    end

    def tool_name
      tool ? tool.name : EVG::CRAFTING_SETTINGS::NO_TOOL_VOCAB
    end

    def color1
      text_color(CraftingManager.crafting_type.gauge_color1 || default_color1)
    end

    def color2
      text_color(CraftingManager.crafting_type.gauge_color2 || default_color2)
    end

    def default_color1
      24
    end

    def default_color2
      24
    end
  end
end
module EVG
  class Window_CraftingHelp < Window_Base
    def initialize
      super(0, Graphics.height - fitting_height(3), Graphics.width, fitting_height(3))
      refresh
    end

    def set_item(item)
      @item = item
      refresh
    end

    def set_command(command)
      @command = command
      refresh
    end

    def reset
      @command = nil
      @item = nil
      refresh
    end

    def refresh
      contents.clear
      change_color(normal_color)
      draw_underline(0, 1, contents.width)
      draw_item_info if @item
      draw_command_info if @command
    end

    def draw_item_info
      draw_item_name(0, 0)
      draw_text_ex(0, line_height, item_description)
    end

    def draw_item_name(x, y)
      draw_icon(icon_index, x, y)
      draw_text_ex(x + 26, y,  item_name)
    end

    def icon_index
      @item.icon_index
    end

    def item_name
      @item.name
    end

    def item_description
      @item.description
    end

    def draw_command_info
      draw_categories if CraftingManager.can_switch_categories?
      draw_text(0, 0, contents.width, line_height, @command[:name], 1)
      draw_text_ex(x, line_height,  CRAFTING_SETTINGS::COMMAND_DESCRIPTIONS[@command[:symbol]])
    end

    def draw_categories
      prev_text = "#{CRAFTING_SETTINGS::PREV_CATEGORY_VOCAB} #{CraftingManager.previous_type.vocab}"
      next_text = "#{CraftingManager.next_type.vocab} #{CRAFTING_SETTINGS::NEXT_CATEGORY_VOCAB}"
      draw_text(0, 0, contents.width, line_height, prev_text)
      draw_text(0, 0, contents.width, line_height, next_text, 2)
    end
  end
end
module EVG
  class Window_CraftingIngredientList < Window_CraftingList

    def initialize(x, y)
      super(x, y, window_width, window_height)
      self.opacity = 0
    end

    def window_width
      Graphics.width / 2
    end

    def window_height
      item_height + standard_padding * 2 + spacing
    end

    def type_id
      CraftingManager.crafting_type && CraftingManager.crafting_type.id
    end

    def amount_string(index)
      amount = amount(index)
      c_id = $game_party.item_number(item(index)) < amount ? 25 : 0
      "\\c[#{c_id}]#{amount}"
    end

    def draw_item(index)
      draw_icon(item(index).icon_index, icon_rect(index).x, icon_rect(index).y, item_enabled?(index))
      draw_text_ex(amount_x(index), amount_y(index), amount_string(index)) if draw_amount?(index)
    end

    def draw_amount?(index)
      amount(index) > 1 || $game_party.item_number(item(index)) < amount(index)
    end

    def make_item_list
      CraftingManager.current_recipe.ingredients.each{|ingredient, amount| add_item(ingredient, amount)}
    end

    def background_times
      return super unless CraftingManager.crafting_type.ingredient_cap
      CraftingManager.crafting_type.ingredient_cap
    end

    def draw_backgrounds?
      true
    end
  end
end
module EVG
  class Window_CraftingItemCategory < Window_Base
    def initialize(x, y, width, height)
      super(x, y, width, height)
      @index = 0
      deactivate
      refresh
    end

    def categories
      CraftingManager.crafting_type.possible_categories
    end

    def category
      categories[@index]
    end

    def next_category
      @index = (@index + 1) % categories.size
      refresh
    end

    def prev_category
      @index = (@index - 1) % categories.size
      refresh
    end

    def select(index)
      @index = [index, categories.size].min
      refresh
    end

    def draw_symbols
      prev_text = CRAFTING_SETTINGS::PREV_CATEGORY_VOCAB
      next_text = CRAFTING_SETTINGS::NEXT_CATEGORY_VOCAB
      draw_text(0, 0, contents.width, line_height, prev_text)
      draw_text(0, 0, contents.width, line_height, next_text, 2)
    end

    def refresh
      contents.clear
      return unless category
      change_color(normal_color, active)
      draw_symbols if categories.size > 1
      change_color(normal_color)
      draw_text(0,0, contents.width, line_height, Vocab.send(category), 1)
      draw_underline(0, line_height / 2, contents.width)
    end
  end
end
module EVG
  class Window_CraftingItemList < Window_CraftingList
    attr_accessor :category_window

    def initialize(x, y, width, height)
      super(x, y, width, height)
      self.opacity = 0
    end

    def item_height
      34
    end

    def spacing
      3
    end

    def type_id
      CraftingManager.crafting_type && CraftingManager.crafting_type.id
    end

    def category
      @category_window && @category_window.category
    end

    def category_window=(window)
      @category_window = window
      refresh
    end

    def include?(item)
      item.ingredient? && correct_category?(item) && !item.tool? && item.correct_type?(type_id)
    end

    def correct_category?(item)
      case category
        when :item
          item.is_a?(RPG::Item) && !item.key_item?
        when :weapon
          item.is_a?(RPG::Weapon)
        when :armor
          item.is_a?(RPG::Armor)
        else
          false
      end
    end

    def item_enabled?(index)
      return false if ingredients_full?(index)
      return true  if force_item_enabled?
      CraftingManager.can_change?(item(index), 1)
    end

    def force_item_enabled?
      !$game_switches[CRAFTING_SETTINGS::PERFECT_CRAFTING_SWITCH_ID]
    end

    def ingredients_full?(index)
      return false unless CraftingManager.crafting_type.ingredient_cap
      return false if CraftingManager.current_recipe.ingredients[item(index).to_sym]
      CraftingManager.current_recipe.ingredients.size >= CraftingManager.crafting_type.ingredient_cap
    end

    def make_item_list
      $game_party.all_items.each {|item| add_item(item, $game_party.item_number(item)) if include?(item)}
    end

    def cursor_movable?
      active && open? && !@cursor_fix && !@cursor_all
    end

    def process_cursor_move
      return unless cursor_movable?
      if item_max > 0
        last_index = @index
        cursor_down (Input.trigger?(:DOWN))  if Input.repeat?(:DOWN)
        cursor_up   (Input.trigger?(:UP))    if Input.repeat?(:UP)
        cursor_right(Input.trigger?(:RIGHT)) if Input.repeat?(:RIGHT)
        cursor_left (Input.trigger?(:LEFT))  if Input.repeat?(:LEFT)
        Sound.play_cursor if @index != last_index
      end
      cursor_pagedown   if !handle?(:pagedown) && Input.trigger?(:R)
      cursor_pageup     if !handle?(:pageup)   && Input.trigger?(:L)
    end
    def cursor_pagedown
      @category_window && @category_window.next_category
      select(0)
      refresh
      Sound.play_cursor
    end

    def cursor_pageup
      @category_window && @category_window.prev_category
      select(0)
      refresh
      Sound.play_cursor
    end
  end
end
module EVG
  class Window_CraftingNotification < Window_Selectable
    def initialize
      super(0, 0, Graphics.width / 2, 0)
      self.openness = 0
      @lines = []
    end

    def add_line(line)
      @lines.push(line)
    end

    def open
      activate
      refresh
      super
    end

    def close
      @lines.clear
      super
    end

    def refresh
      correct_position
      create_contents
      draw_lines
    end

    def correct_position
      self.height = standard_padding * 2 + line_height * @lines.size
      self.x = (Graphics.width - self.width) / 2
      self.y = (Graphics.height - self.height) / 2
    end

    def draw_lines
      @lines.each_with_index do |line, i|
        line.include?("item=") ? draw_item(line, i) : draw_line(line, i)
      end
    end

    def draw_item(line, i)
      regex = /\[item=(.+)\]\[amount=(\d+)\]/i
      matches = regex.match(line)
      return unless matches
      item = Converter.sym_to_item(matches[1].to_sym)
      amount = matches[2].to_i
      draw_icon(item.icon_index, 0, line_height * i)
      draw_text(24, line_height * i, contents.width, line_height, item.name)
      if amount != CraftingManager.matching_recipe.results[item.to_sym]
        change_color(power_up_color)
      end
      draw_text(0, line_height * i, contents.width, line_height, "x%d" % amount, 2)
      change_color(normal_color)
    end

    def draw_line(line, i)
      draw_text(0, i * line_height, contents.width, line_height, line, 1)
    end

    def process_ok
      Sound.play_ok
      Input.update
      deactivate
      call_ok_handler
    end

    def process_handling
      return unless open? && active
      inputs = [:C, :B, CRAFTING_SETTINGS::CRAFTING_START_BUTTON]
      process_ok if ok_enabled? && inputs.any?{|i| Input.trigger?(i)}
    end
  end
end
module EVG
  class Window_CraftingRecipeList < Window_Command
    attr_accessor :windows_to_refresh
    def initialize(x, y, width, height)
      @custom_width = width
      @custom_height = height
      super(x, y)
      self.openness = 0
      self.active = false
    end

    def window_width
      @custom_width
    end

    def window_height
      @custom_height
    end

    def type_id
      CraftingManager.crafting_type && CraftingManager.crafting_type.id
    end

    def include?(recipe)
      recipe.tool == CraftingManager.current_tool
    end

    def recipe(id)
      CraftingManager.crafting_type.recipes_hash[id]
    end

    def make_command_list
      CraftingManager.crafting_type.learned_recipes.each do |id|
        recipe = recipe(id)
        add_command(recipe.vocab, recipe.id, enabled?(id)) if include?(recipe)
      end
    end

    def enabled?(id)
      CraftingManager.can_craft?(recipe(id))
    end

    def call_update_help
      super
      if self.openness <= 0 && !active
        return CraftingManager.clear
      end
      CraftingManager.set_recipe(recipe(current_symbol))
      @windows_to_refresh.each(&:refresh) if @windows_to_refresh
      refresh
    end
  end
end
module EVG
  class Window_CraftingResultList < Window_CraftingList
    def initialize(x, y)
      super(x, y, window_width, window_height)
      self.opacity = 0
    end

    def window_width
      Graphics.width / 2
    end

    def window_height
      item_height + standard_padding * 2 + spacing
    end

    def draw_backgrounds?
      true
    end

    def make_item_list
      return unless CraftingManager.matching_recipe
      return unless learned_recipe?
      CraftingManager.matching_recipe.results.each do |item, amount|
        add_item(item, amount)
      end
    end

    def learned_recipe?
      CraftingManager.crafting_type.learned_recipes.include?(CraftingManager.matching_recipe.id)
    end

    def draw_item(index)
      draw_icon(item_icon_index(index), icon_rect(index).x, icon_rect(index).y, item_enabled?(index))
      draw_text_ex(amount_x(index), amount_y(index), amount_string(index)) if draw_amount?(index)
    end

    def item_icon_index(index)
      learned_recipe? ? item(index).icon_index : 16
    end

    def amount_string(index)
      learned_recipe? ? super(index) : "??"
    end

    def background_times
      return super unless CraftingManager.crafting_type.result_cap
      CraftingManager.crafting_type.result_cap
    end

    def draw_amount?(index)
      !learned_recipe? || amount(index) > 1
    end
  end
end
module EVG
  class Window_CraftingToolList < Window_CraftingList
    def initialize(x, y, width, height)
      super(x, y, width, height)
      self.openness = 0
    end

    def type_id
      CraftingManager.crafting_type && CraftingManager.crafting_type.id
    end

    def tool
      CraftingManager.current_recipe.tool
    end

    def include?(item)
      item.tool_type_ids.include?(type_id)
    end

    def enable_item?(item)
      true
    end

    def make_item_list
      $game_party.all_items.each {|item| add_item(item, 1) if include?(item)}
    end

    def draw_item(index)
      draw_background(index) if tool && tool.to_sym == item(index).to_sym
      super
    end
  end
end