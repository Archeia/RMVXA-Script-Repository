#==============================================================================
# ** Mail System **
#
# Author:     Evgenij
# Date:       30.09.2014
# Version:    1.1b
# ToF:        evgenij-scripts.org
#
# Thanks to: MHRob for requesting this script
#==============================================================================
#
# Changelog:
# 30.09.2014 - V. 1.1b:
#   - bugfix
#   - new format for SENDER Configuration 
#
# 28.09.2014 - V. 1.1a:
#   - bugfixes
#
# 25.09.2014 - V. 1.1:
#   - bugfixes
#   - added gold to attachments
#   - new feature: custom windowskin
#   - new feature: run common_event when reading mail
#   - new scriptcall: $game_system.attachments_claimed?(:symbol)
#
# 24.09.2014 - V. 1.0:
#   - script created
#
#==============================================================================
#
# Description:
#
#   This script adds an email scene to your game, you need to predefine senders
#   and emails in the script and after that you can send them to the player via
#   a script call.
#
# Script Calls:
#
# SceneManager.call(Scene_Mail)  # to call the scene
#  
# $game_system.add_mail(:symbol)
# $game_system.remove_email(:symbol)
# $game_system.has_mail?(:symbol)            # checks if player has email
# $game_system.attachments_claimed?(:symbol)  # checks if the attachments were
#                                             # claimed
#
#==============================================================================
module EVG
  module MAIL
    #--------------------------------------------------------------------------
    # Some Escape Codes which can be used almost everywhere:
    # \n           => new line
    # \\c[index]   => change color (windowskin index)
    # \\b          => toogle bold on or off
    # \\i[index]   => show icon
    #--------------------------------------------------------------------------
   
    #--------------------------------------------------------------------------
    # Cosmetic and Vocab Config:
    #--------------------------------------------------------------------------
    ALL_VOCAB = "ALL"
    UNREAD_VOCAB = "Unread"
    READ_VOCAB = "Read"
    DELETED_VOCAB = "Deleted"
   
    ACTION_READ_VOCAB = "Read"
    ACTION_MARK_READ_VOCAB = "Mark read"
    ACTION_MARK_UNREAD_VOCAB = "Mark unread"
    ACTION_DELETE_VOCAB = "Delete"
    ACTION_GET_ATTACHMENTS_VOCAB = "Get Attach."
    # %s and %s get replaced by the sender name and the sender address
    HEADER_FROM_VOCAB = "\\b\\c[5]FROM\\c[0]: \\c[6]%s <%s>\\b"
    # %s gets replaced by the mail name
    HEADER_SUBJECT_VOCAB = "\\b\\c[5]SUBJECT\\c[0]: \\c[6]%s\\b"
    ATTACHMENTS_VOCAB = "\\b\\c[13]Attachments\\c[0]\\b"
    CLAIMED_VOCAB = "Claimed"
   
    # Use windowskin colors only
    CLAIMED_COLOR = 25
    SENDER_COLOR = 2
   
    ATTACHMENT_ICON = 258
    READ_ICON = 236
    UNREAD_ICON = 235
    NEW_MAIL_ICON = 235
    GOLD_ICON = 361
   
    # You can use custom windowskin, put the file in Graphics/System
    # if the file dont exist, the window skin wont change, you also get no
    # error.
    WINDOWSKIN = "mailwindow"
    WINDOWTONE = Tone.new(0, 0, 0, 0)
   
    #--------------------------------------------------------------------------
    # Settings:
    #--------------------------------------------------------------------------
    GET_ATTACHMENTS_WHEN_MARKREAD = true
    GET_ATTACHMENTS_WHEN_DELETE = true
    SHOW_DELETED_CATEGORY = true
    # If this switch will be on, no notification will be shown when the player
    # is on map and have unread emails
    NOTIFICATION_ON_MAP_OFF_SWITCH = 5
   
    ADD_EMAIL_COMMMAND_TO_MENU = true
    COMMAND_VOCAB = "View Mails"
    COMMAND_SWITCH = 10   # For enabling or disabling the command in menu
   
    #--------------------------------------------------------------------------
    # Configure possible senders:
    #--------------------------------------------------------------------------
    SENDERS = { # Do not edit this line
    #--------------------------------------------------------------------------
      :eric => {:name => "Eric", :address => "eric@rpgmaker.rm"},
      :natalie => {:name => "Natalie", :address => "natalie@rpgmaker.rm"},
      :me => {:name => "Me, the king", :address => "me@rpgmaker.rm"},
    #--------------------------------------------------------------------------
    } # Do not edit this line
    #--------------------------------------------------------------------------
    EMAILS = { # do not edit this line
    #--------------------------------------------------------------------------
    # Configure e-mails
    # Template:
    #
    # :symbol => {  # the symbol has to be unique
    #
    #   :sender => :eric,  # take a sender from above SENDERS
    #
    #   :name   => "Email Name",
    #
    #   :text   => "Email Text",   # You can use escape codes
    #
    #   :attachments => [w1, i12, a13], # would give the player weapon 1, item 12
    #                                   # and armor 13 as attachment.
    #                                   # attachments are optional
    #
    #   # Optional you can run common events when the player claims an attachment
    #   # or reads the mail:
    #
    #   :attach_ce => id,               # only works when attachments are used
    #                                   # starts the common event with id when
    #                                   # attachments are claimed, also optional
    #   :read_ce => id,                 # starts common event with id when email
    #                                     gets read
    # },
    #--------------------------------------------------------------------------
 
     :mail1 => {
       :sender => :eric,
       :name => "Hey whats up",
       :text => "Blab\\c[2]albab\\c[0]la",
     },
   
     :mail2 => {
       :sender => :natalie,
       :name => "Welcome",
       :text => "Hello, \n"+
                "I want to welcome you in our guild. If you have questions\n"+
                "feel free to ask me or another member.\n\n"+
                "Best Regards!\n"+
                "\\b\\c[10]Natalie\\c[0]\\b",
   
       :attachments => [:g30000, :w1, :i1, :a12],
     },
   
     :mail3 => {
       :sender => :me,
       :name => "Some rewards for ya!",
       :text => "Blabalbabla",
       :attachments => [:w2, :i2, :a13, :i4, :i6],
     },
   
    #--------------------------------------------------------------------------
    } # Do not edit this line
    #--------------------------------------------------------------------------
    #============================================================================
    # CONFIG END
    #============================================================================
    def initialize(*args)
      super(*args)
      skin = Cache.system(WINDOWSKIN) rescue nil
      self.windowskin = skin if skin
    end
    def update_tone
      self.tone.set(WINDOWTONE)
    end
  end
#============================================================================
class EMail
  #--------------------------------------------------------------------------
  attr_reader :symbol
  attr_reader :name
  attr_reader :address
  attr_reader :title
  attr_reader :text
  attr_reader :sender
  attr_reader :date
  attr_reader :attachments
  attr_reader :common_event_attach
  attr_reader :common_event_read
  attr_writer :read_ce
  #--------------------------------------------------------------------------
  def initialize(symbol, properties)
    @symbol = symbol
    @sender =  EVG::MAIL::SENDERS[properties[:sender]][:name]
    @address = EVG::MAIL::SENDERS[properties[:sender]][:address]
    @name = properties[:name]
    @text = properties[:text]
    @attachments = properties[:attachments]
    @title = properties[:title]
    @common_event_attach = properties[:attach_ce]
    @common_event_read   = properties[:read_ce]
    @read_ce = false
    @deleted = false
    @date = Time.now
    @state = :unread
  end
  #--------------------------------------------------------------------------
  def all?
    !deleted?
  end
  #--------------------------------------------------------------------------
  def read
    @state = :read
    $game_system.calc_unread_mail_count
    #@read_ce = true
  end
  #--------------------------------------------------------------------------
  def read?
    @state == :read
  end
  #--------------------------------------------------------------------------
  def unread
    @state = :unread
    $game_system.calc_unread_mail_count
  end
  #--------------------------------------------------------------------------
  def unread?
    @state != :read
  end
  #--------------------------------------------------------------------------
  def delete
    @deleted = true
    $game_system.calc_unread_mail_count
  end
  #--------------------------------------------------------------------------
  def undelete
    @deleted = false
    $game_system.calc_unread_mail_count
  end
  #--------------------------------------------------------------------------
  def deleted?
    @deleted
  end
  #--------------------------------------------------------------------------
  def attachments?
    @attachments && !@attachments.empty?
  end
  #--------------------------------------------------------------------------
  def claim_attachments
    return if @attachments_claimed
    @attachments_claimed = true
  end
  #--------------------------------------------------------------------------
  def attachments_claimed?
    @attachments_claimed || !attachments?
  end
  #--------------------------------------------------------------------------
  def attach_common_event?
    !@common_event_attach.nil? && @common_event_attach != 0
  end
  #--------------------------------------------------------------------------
  def read_common_event?
    !@common_event_read.nil? && @common_event_read != 0
  end
  #--------------------------------------------------------------------------
  def read_common_event_ran?
    return @read_ce
  end
end
#--------------------------------------------------------------------------
module AttachmentManager
  def self.get_item(code)
    if /([a, w, i, g])(\d+)/i =~ code.to_s
      case $1.upcase
      when 'W'
        $data_weapons[$2.to_i]
      when 'A'
        $data_armors[$2.to_i]
      when 'I'
        $data_items[$2.to_i]
      when 'G'
        $2.to_i
      end    
    end  
  end
end
#--------------------------------------------------------------------------
end
#==============================================================================
class Game_System
#--------------------------------------------------------------------------
attr_reader :mails
attr_reader :unread_mails_count
#--------------------------------------------------------------------------
alias :evg_gs_initialze_mail    :initialize
def initialize
 evg_gs_initialze_mail
 @mails = {}
 @unread_mails_count = 0
end
#--------------------------------------------------------------------------
def add_mail(symbol)
 @mails ||= {}
 return if @mails[symbol]
 @mails[symbol] = EVG::EMail.new(symbol, EVG::MAIL::EMAILS[symbol])
 @mails = Hash[@mails.sort_by{|sym, mail| mail.date}.reverse]
 calc_unread_mail_count
end
#--------------------------------------------------------------------------
def remove_mail(symbol)
 @mails.delete(symbol)
 calc_unread_mail_count
end
#--------------------------------------------------------------------------
def attachments_claimed?(symbol)
 @mails[symbol].attachments_claimed?
end
#--------------------------------------------------------------------------
def has_email?(symbol)
 !!@mails[symbol]
end
#--------------------------------------------------------------------------
def calc_unread_mail_count
 @unread_mails_count = @mails.select{|sym, mail| mail.unread?}.size
end
#--------------------------------------------------------------------------
end
#==============================================================================
class Sprite_New_Mail < Sprite
#--------------------------------------------------------------------------
def initialize(viewport = nil, x, y)
 super(viewport)
 self.x = 4
 self.y = y
 reset_counter
 create_bitmap
 create_fiber
 update
end
#--------------------------------------------------------------------------
def max_time
 return 60
end
#--------------------------------------------------------------------------
def create_bitmap
 self.bitmap = Bitmap.new(Graphics.width, 24)
 draw_info
end
#--------------------------------------------------------------------------
def draw_info
 @old_count = $game_system.unread_mails_count
 self.bitmap.clear
 self.bitmap.draw_text(0, 0, Graphics.width - 32, 24, $game_system.unread_mails_count, 2)
 draw_icon(EVG::MAIL::NEW_MAIL_ICON, Graphics.width - 32, 0)
end
#--------------------------------------------------------------------------
def draw_icon(icon_index, x, y, enabled = true)
 bitmap = Cache.system("Iconset")
 rect = Rect.new(icon_index % 16 * 24, icon_index / 16 * 24, 24, 24)
 self.bitmap.blt(x, y, bitmap, rect, enabled ? 255 : 128)
end
#--------------------------------------------------------------------------
def create_fiber
 @fiber = Fiber.new { fiber_main }
end
#--------------------------------------------------------------------------
def fiber_main
 loop do
   update_visibility
   @counter += 1
   Fiber.yield
   reset_counter if @counter >= max_time
 end
 @fiber = nil
end
#--------------------------------------------------------------------------
def reset_counter
 @counter = 0
end
#--------------------------------------------------------------------------
def update_visibility
 self.opacity = (-((@counter - 30.0)**2 * 0.28) + 255).to_i
end
#--------------------------------------------------------------------------
def update
 draw_info if @old_count != $game_system.unread_mails_count
 self.visible = set_visible?
 update_fiber if self.visible
end
#--------------------------------------------------------------------------
def update_fiber
 @fiber.resume if @fiber
end
#--------------------------------------------------------------------------
def set_visible?
 return false if $game_switches[EVG::MAIL::NOTIFICATION_ON_MAP_OFF_SWITCH]
 return $game_system.unread_mails_count > 0
end
#--------------------------------------------------------------------------
def dispose
 self.bitmap.dispose if self.bitmap
 self.bitmap = nil
 super
end
#--------------------------------------------------------------------------
end
#==============================================================================
class Spriteset_Map
#--------------------------------------------------------------------------
alias :evg_ssm_cp_mail    :create_pictures
def create_pictures
 evg_ssm_cp_mail
 x = Graphics.width - 28
 y = 4
 @new_mail_sprite = Sprite_New_Mail.new(@viewport3, x, y)
end
#--------------------------------------------------------------------------
alias :evg_ssm_dp_mail    :dispose_pictures
def dispose_pictures
 evg_ssm_dp_mail
 @new_mail_sprite.dispose
 @new_mail_sprite = nil
end
#--------------------------------------------------------------------------
alias :evg_ssm_up_mail    :update_pictures
def update_pictures
 evg_ssm_up_mail
 @new_mail_sprite.update
end
#--------------------------------------------------------------------------
end
#==============================================================================
class Window_MailCategory < Window_HorzCommand
#--------------------------------------------------------------------------
include EVG::MAIL
attr_reader   :selection_window
#--------------------------------------------------------------------------
def initialize(selection_window)
 @selection_window = selection_window
 super(window_x, window_y)
end
#--------------------------------------------------------------------------
def window_x
 @selection_window.window_x
end
#--------------------------------------------------------------------------
def window_y
 @selection_window.window_y - window_height
end
#--------------------------------------------------------------------------
def window_width
 @selection_window.window_width
end
#--------------------------------------------------------------------------
def col_max
 return 4
end
#--------------------------------------------------------------------------
def update
 super
 @selection_window.category = current_symbol if @selection_window
end
#--------------------------------------------------------------------------
def make_command_list
 add_command(ALL_VOCAB,     :all)
 add_command(UNREAD_VOCAB,  :unread)
 add_command(READ_VOCAB,    :read)
 add_command(DELETED_VOCAB, :deleted) if SHOW_DELETED_CATEGORY
end
#--------------------------------------------------------------------------
def selection_window=(window)
 @selection_window = window
 update
end
#--------------------------------------------------------------------------
end
#==============================================================================
class Window_MailSelection  < Window_Selectable
#--------------------------------------------------------------------------
include EVG::MAIL
attr_reader :mails
#--------------------------------------------------------------------------
def initialize
 create_mails
 super(window_x, window_y, window_width, window_height)
 refresh
end
#--------------------------------------------------------------------------
def real_mails
 $game_system.mails.values
end
#--------------------------------------------------------------------------
def create_mails
 @mails = case @category
          when :read
            real_mails.compact.select{|mail| mail.read? && !mail.deleted?}
          when :unread
            real_mails.compact.select{|mail| mail.unread? && !mail.deleted?}
          when :deleted
            real_mails.compact.select(&:deleted?)
          else
            real_mails.compact.select(&:all?)
          end
end
#--------------------------------------------------------------------------
def item_max
 return @mails.size
end
#--------------------------------------------------------------------------
def window_x
 (Graphics.width - window_width) / 2
end
#--------------------------------------------------------------------------
def window_y
 (Graphics.height- window_height) / 2
end
#--------------------------------------------------------------------------
def window_width
 return 420
end
#--------------------------------------------------------------------------
def window_height
 fitting_height(10)
end
#--------------------------------------------------------------------------
def sender_width
 96
end
#--------------------------------------------------------------------------
def name_width
 contents.width - sender_width - 28 - 24
end
#--------------------------------------------------------------------------
def category=(category)
 return if @category == category
 @category = category
 refresh
 self.oy = 0
end
#--------------------------------------------------------------------------
def current_symbol
 @mails[@index].symbol
end
#--------------------------------------------------------------------------
def current_mail
 @mails[@index]
end
#--------------------------------------------------------------------------
def draw_item(index)
 draw_mail_name(index)
end
#--------------------------------------------------------------------------
def draw_mail_name(index)
 mail = mails[index]
 y = index * line_height
 contents.font.size = 20
 contents.font.bold = !mail.read?
 change_color(sender_color(mail))
 draw_read_unread_icon(mail, 2, y)
 draw_text(26, y, sender_width, line_height, mail.sender)
 change_color(text_color1(mail))
 draw_text(sender_width + 26, y, name_width, line_height, mail.name)
 draw_attachment_icon(mail, contents.width - 26, y) if mail.attachments?
end
#--------------------------------------------------------------------------
def draw_read_unread_icon(mail, x, y)
 icon_id = mail.read? ? READ_ICON : UNREAD_ICON
 draw_icon(icon_id, x, y, !mail.read?)
end
#--------------------------------------------------------------------------
def draw_attachment_icon(mail, x, y)
 draw_icon(ATTACHMENT_ICON, x, y, !mail.attachments_claimed?)
end
#--------------------------------------------------------------------------
def sender_color(mail)
 color = Color.new.set(text_color(SENDER_COLOR))
 color.set(color.red, color.green, color.blue, mail.read? ? 220 : color.alpha)
 color
end
#--------------------------------------------------------------------------
def text_color1(mail)
 color = Color.new.set(normal_color)
 color.set(color.red, color.green, color.blue, mail.read? ? 220 : color.alpha)
 color
end
#--------------------------------------------------------------------------
def refresh
 create_mails
 create_contents
 draw_all_items
 correct_index
end
#--------------------------------------------------------------------------
def correct_index
 if @index > @mails.size - 1 && @mails.size > 0
   select(@mails.size - 1)
 end
end
#--------------------------------------------------------------------------
def current_item_enabled?
 return @mails[@index]
end
#--------------------------------------------------------------------------
end
#==============================================================================
class Window_MailConfirm < Window_Command
#--------------------------------------------------------------------------
include EVG::MAIL
#--------------------------------------------------------------------------
def initialize(selection_window)
 @selection_window = selection_window
 super(0, 0)
 self.openness = 0
 set_center
 deactivate
end
#--------------------------------------------------------------------------
def make_command_list
 add_command(ACTION_READ_VOCAB, :read)
 add_command(ACTION_MARK_READ_VOCAB, :mark_read, read?)
 add_command(ACTION_MARK_UNREAD_VOCAB, :mark_unread, mark_unread?)
 add_command(ACTION_GET_ATTACHMENTS_VOCAB, :claim_attach, claim_attach?)
 add_command(ACTION_DELETE_VOCAB, :delete, delete?)
end
#--------------------------------------------------------------------------
def read?
 @selection_window.current_mail && @selection_window.current_mail.unread?
end
#--------------------------------------------------------------------------
def mark_unread?
 @selection_window.current_mail && @selection_window.current_mail.read?
end
#--------------------------------------------------------------------------
def claim_attach?
 @selection_window.current_mail && !@selection_window.current_mail.attachments_claimed?
end
#--------------------------------------------------------------------------
def delete?
 @selection_window.current_mail && !@selection_window.current_mail.deleted?
end
#--------------------------------------------------------------------------
def set_center
 self.x = (Graphics.width - window_width) / 2
 self.y = (Graphics.height - window_height) - 12
end
#--------------------------------------------------------------------------
def open
 refresh
 select(0)
 super
end
#--------------------------------------------------------------------------
end
#==============================================================================
class Window_MailMessage < Window_Selectable
#--------------------------------------------------------------------------
include EVG::MAIL
#--------------------------------------------------------------------------
attr_reader :mail
#--------------------------------------------------------------------------
def initialize
 super(window_x, window_y, window_width, window_height)
 self.openness = 0
 deactivate
end
#--------------------------------------------------------------------------
def window_x
 (Graphics.width - window_width) / 2
end
#--------------------------------------------------------------------------
def window_y
 (Graphics.height - window_height) / 2
end
#--------------------------------------------------------------------------
def window_width
 Graphics.width - 24
end
#--------------------------------------------------------------------------
def window_height
 ((Graphics.height - 24) / 24) * 24
end
#--------------------------------------------------------------------------
def mail=(mail)
 @mail = mail
 refresh
end
#--------------------------------------------------------------------------
def reset_font_settings
 super
 contents.font.size = 20
end
#--------------------------------------------------------------------------
def refresh
 contents.clear
 select(-1)
 draw_header
 draw_text_ex(4, 48, mail.text)
 draw_attachments(contents.height - line_height * 2) if mail.attachments?
end
#--------------------------------------------------------------------------
def draw_header_frame(y, height = 22)
 contents.fill_rect(0, y, contents.width, height, Color.new(0,0,0,255))
 contents.clear_rect(1, y + 1, contents.width - 2, height - 2)
end
#--------------------------------------------------------------------------
def draw_header
 draw_header_frame(0)
 draw_header_frame(24)    
 draw_text_ex(4, 0, sprintf(HEADER_FROM_VOCAB, mail.sender, mail.address))
 draw_text_ex(4, 24, sprintf(HEADER_SUBJECT_VOCAB, mail.name) )
end
#--------------------------------------------------------------------------
def draw_attachments(y)
 draw_header_frame(y, line_height * 2 - 2)
 draw_text_ex(4, y - line_height * 0.5, ATTACHMENTS_VOCAB)
 if !mail.attachments_claimed?
   select(0)
   draw_text(item_rect_for_text(0), ACTION_GET_ATTACHMENTS_VOCAB, 1)
   draw_text_ex(4, y + line_height * 0.5, attachment_text)
 else
   change_color(text_color(EVG::MAIL::CLAIMED_COLOR))
   contents.font.bold = true
   draw_text(4, y + line_height * 0.5, contents.width - 8, line_height, CLAIMED_VOCAB, 1)
   #draw_text(item_rect_for_text(0), "Claimed!", 2)
   change_color(normal_color)
   #contents.fill_rect(3, y + line_height, contents.width - 6, 1, Color.new(0, 0, 0, 255))
 end
end
#--------------------------------------------------------------------------
def draw_text_ex(x, y, text)
 reset_font_settings
 text = convert_escape_characters(text)
 pos = {:x => x, :y => y, :new_x => x, :height => calc_line_height(text)}
 process_character(text.slice!(0, 1), text, pos) until text.empty?
end
#--------------------------------------------------------------------------
def process_escape_character(code, text, pos)
 case code.upcase
 when 'B'
   contents.font.bold = !contents.font.bold
 else
   super
 end
end
#--------------------------------------------------------------------------
def attachment_text
mail.attachments.inject("") {|res, attach| "#{item_name(attach)} #{res}"}
  end
  #--------------------------------------------------------------------------
  def item_name(code)
    item = EVG::AttachmentManager.get_item(code)
    return "Invalid itemcode" if item.nil?
    if item.is_a?(Fixnum)
      return "\\i[#{GOLD_ICON}]#{item}"
    else
      return "\\i[#{item.icon_index}]#{item.name}"
    end
   
  end
  #--------------------------------------------------------------------------
  def item_rect(index)
    rect = Rect.new
    rect.width = 128
    rect.height = line_height
    rect.x = contents.width - 128 - 4
    rect.y = contents.height - line_height * 2.5
    rect
  end
  #--------------------------------------------------------------------------
  def ok_enabled?
    handle?(:ok) && @index == 0 && mail.attachments && !mail.attachments_claimed?
  end
  #--------------------------------------------------------------------------
end
#==============================================================================
class Window_MailReward < Window_Base
  #--------------------------------------------------------------------------
  include EVG::MAIL
  #--------------------------------------------------------------------------
  def initialize
    super(0,0,196,0)
    @counter = 0
    self.openness = 0
  end
  #--------------------------------------------------------------------------
  def start(attachments)
    @attachments = attachments
    refresh
    open
    @counter = 60
  end
  #--------------------------------------------------------------------------
  def update
    super
    if busy?
      @counter -= 1
    end
    if @counter == 0 && open?
      close
    end
  end
  #--------------------------------------------------------------------------
  def busy?
    @counter > 0
  end
  #--------------------------------------------------------------------------
  def refresh
    recreate_window(fitting_height(@attachments.size + 1))
    draw_text(0, 0, contents.width, line_height, "#{CLAIMED_VOCAB}:")
    @attachments.each_with_index do |code, i|
      y = line_height * (i+1)
      item = EVG::AttachmentManager.get_item(code)
      if item.is_a?(Fixnum)
        draw_gold(item, 0, y)
      else
        draw_item_name(item, 0, y)
      end
    end
  end
 
  def draw_gold(number, x, y)
    draw_icon(GOLD_ICON, x, y)
    draw_text(x + 26, y, contents.width - 26, line_height, number)
  end
  #--------------------------------------------------------------------------
  def recreate_window(height)
    self.height = height
    self.x = (Graphics.width - self.width) / 2
    self.y = (Graphics.height - self.height) / 2
    create_contents
  end
  #--------------------------------------------------------------------------
end
#==============================================================================
class Scene_Mail < Scene_MenuBase
  #--------------------------------------------------------------------------
  def start
    super
    create_selection_window
    create_category_window
    create_confirm_window
    create_mail_window
    create_reward_window
    create_interpreter
  end
  #--------------------------------------------------------------------------
  def create_selection_window
    @selection_window = Window_MailSelection.new
    @selection_window.set_handler(:ok, method(:on_selection_ok))
    @selection_window.set_handler(:cancel, method(:on_selection_cancel))
  end
  #--------------------------------------------------------------------------
  def create_category_window
    @category_window = Window_MailCategory.new(@selection_window)
    @category_window.set_handler(:ok, method(:on_category_ok))
    @category_window.set_handler(:cancel, method(:return_scene))
  end
  #--------------------------------------------------------------------------
  def create_confirm_window
    @confirm_window = Window_MailConfirm.new(@selection_window)
    @confirm_window.set_handler(:read, method(:read_mail))
    @confirm_window.set_handler(:mark_read, method(:mark_mail_read))
    @confirm_window.set_handler(:mark_unread, method(:mark_mail_unread))
    @confirm_window.set_handler(:claim_attach, method(:claim_mail_attach))
    @confirm_window.set_handler(:delete, method(:delete_mail))
    @confirm_window.set_handler(:cancel, method(:on_confirm_cancel))
  end
  #--------------------------------------------------------------------------
  def create_mail_window
    @mail_window = Window_MailMessage.new
    @mail_window.set_handler(:cancel, method(:on_mail_cancel))
    @mail_window.set_handler(:ok, method(:on_mail_ok))
  end
  #--------------------------------------------------------------------------
  def create_reward_window
    @reward_window = Window_MailReward.new
  end
  #--------------------------------------------------------------------------
  def on_category_ok
    @category_window.deactivate
    @selection_window.activate
    @selection_window.select(0)
  end
  #--------------------------------------------------------------------------
  def on_selection_ok
    @selection_window.deactivate
    @confirm_window.refresh
    @confirm_window.open
    @confirm_window.activate
  end
  #--------------------------------------------------------------------------
  def on_selection_cancel
    @selection_window.deactivate
    @category_window.activate
    @selection_window.unselect
  end
  #--------------------------------------------------------------------------
  def read_mail
    @confirm_window.close
    @confirm_window.deactivate
    @category_window.close
    @selection_window.close
    @mail_window.mail = current_mail
    @mail_window.activate
    @mail_window.open
  end
  #--------------------------------------------------------------------------
  def mark_mail_read
    current_mail.read
    if EVG::MAIL::GET_ATTACHMENTS_WHEN_MARKREAD
      get_attachments
    end
    on_confirm_cancel
    run_read_common_event
    @selection_window.refresh
  end
  #--------------------------------------------------------------------------
  def mark_mail_unread
    current_mail.unread
    @selection_window.refresh
    on_confirm_cancel
  end
  #--------------------------------------------------------------------------
  def claim_mail_attach
    get_attachments
    @selection_window.refresh
    on_confirm_cancel
  end
  #--------------------------------------------------------------------------
  def get_attachments
    if !current_mail.attachments_claimed?
      current_mail.claim_attachments
      current_mail.attachments.each do |code|
        item = EVG::AttachmentManager.get_item(code)
        if item.is_a?(Fixnum)
          $game_party.gain_gold(item)
        else
          $game_party.gain_item(item, 1)
        end
      end
      @reward_window.start(current_mail.attachments)
      if current_mail.attach_common_event?
        run_common_event(current_mail.common_event_attach)
      end
    end
  end
  #--------------------------------------------------------------------------
  def run_read_common_event
    if !current_mail.read_common_event_ran? && current_mail.read_common_event?
      run_common_event(current_mail.common_event_read)
      current_mail.read_ce = true
    end
  end
  #--------------------------------------------------------------------------
  def delete_mail
    current_mail.delete
    if EVG::MAIL::GET_ATTACHMENTS_WHEN_DELETE
      get_attachments
    end
    @selection_window.refresh
    on_confirm_cancel
  end
  #--------------------------------------------------------------------------
  def on_confirm_cancel
    @confirm_window.close
    @confirm_window.deactivate
    @selection_window.activate
  end
  #--------------------------------------------------------------------------
  def on_mail_ok
    get_attachments
    @mail_window.refresh
    @mail_window.activate
  end
  #--------------------------------------------------------------------------
  def on_mail_cancel
    current_mail.read
    run_read_common_event
    @mail_window.close
    @mail_window.deactivate
    @selection_window.refresh
    @selection_window.activate
    @selection_window.open
    @category_window.open
  end
  #--------------------------------------------------------------------------
  def current_mail
    $game_system.mails[@selection_window.current_symbol]
  end
  #--------------------------------------------------------------------------
  def create_interpreter
    @interpreter = Game_Interpreter.new
  end
  #--------------------------------------------------------------------------
  def run_common_event(event_id)
    $game_temp.reserve_common_event(event_id)
    @interpreter.setup_reserved_common_event
    update_interpreter while @interpreter.running?
  end
  #--------------------------------------------------------------------------
  def update_interpreter
    update_basic
    @interpreter.update
  end
  #--------------------------------------------------------------------------
  def update_basic
    Graphics.update
    Input.update
    @reward_window.update if @reward_window.busy?
    update_all_windows unless @reward_window.busy?
  end
  #--------------------------------------------------------------------------
end
#==============================================================================
class Scene_Menu
  #--------------------------------------------------------------------------
  alias :evg_sm_ccw_mail      :create_command_window
  def create_command_window
    evg_sm_ccw_mail
    @command_window.set_handler(:evg_mail, method(:command_evg_mail))
  end
  #--------------------------------------------------------------------------
  def command_evg_mail
    SceneManager.call(Scene_Mail)
  end
  #--------------------------------------------------------------------------
end
#==============================================================================
class Window_MenuCommand
  #--------------------------------------------------------------------------
  alias :evg_wmc_aoc_mail     :add_original_commands
  def add_original_commands
    evg_wmc_aoc_mail
    return unless EVG::MAIL::ADD_EMAIL_COMMMAND_TO_MENU
    add_command(EVG::MAIL::COMMAND_VOCAB, :evg_mail, evg_mail_command_enabled?)
  end
  #--------------------------------------------------------------------------
  def evg_mail_command_enabled?
    return $game_switches[EVG::MAIL::COMMAND_SWITCH]
  end
  #--------------------------------------------------------------------------
end
#==============================================================================
# SCRIPT END
#==============================================================================