#===============================================================================
# ** Mouse Hud **
#
# Author:   Evgenij
# Version:  1.0
# Date:     24.07.2014
# 
# Required: SUPER SIMPLE MOUSE SCRIPT V. 1.10 by Shaz
#           http://forums.rpgmakerweb.com/index.php?/topic/17829-amaranths-super-simple-mouse-system-for-ace/
#
# Thanks To: Shaz for the Script
#            kevin25081998 for requesting this script
#
# My Terms of Use: http://evgenij-scripts.org/?page_id=34
#===============================================================================
#
# Description:
#
#  With this script you can make map icon commands which will call an common
#  event if you press it.
#  Look below at the examples to understand how it works.
#
#===============================================================================
module EVG
  module MouseHud
    #--------------------------------------------------------------------------
    Huds = { # Dont touch this line
    #--------------------------------------------------------------------------
    
      #------------------------------------------------------------------------
      :test1 => {
      
        pos_x:        Graphics.width - 2,
        pos_y:        Graphics.height - 26,
        icon:         22,
        hower_text:   "Common Event 2",
        
        
        # take the right corner as reference for the x placing.
        # set this true if you want to place commands at the right site
        invert_x:     true, 
        
        # Position of the hower text
        # :right or :left
        hower_pos:    :left,
        
        # Common Event which will be started when you press this Command
        ce_on_click:  2,
      },
      
      #------------------------------------------------------------------------
      :test2 => {
      
        pos_x:        Graphics.width - 2,
        pos_y:        Graphics.height - 52,
        icon:         23,
        hower_text:   "Common Event 1",
        
        
        # take the right corner as reference for the x placing.
        # set this true if you want to place commands at the right site
        invert_x:     true, 
        
        # Position of the hower text
        # :right or :left
        hower_pos:    :left,
        
        # Common Event which will be started when you press this Command
        ce_on_click:  1,
      },
      #------------------------------------------------------------------------
      
    #-------------------------------------------------------------------------- 
    } # Dont touch this line !
    #--------------------------------------------------------------------------
  end
end
#===============================================================================
class Spriteset_Map
  #--------------------------------------------------------------------------
  alias :evg_sm_cp_mhuds        :create_pictures
  #--------------------------------------------------------------------------
  def create_pictures
    evg_sm_cp_mhuds
    @mouse_huds = {}
    EVG::MouseHud::Huds.each do |sym, properties|
      @mouse_huds[sym] = HudSpriteMouse.new(properties, @viewport3)
    end
  end
  #--------------------------------------------------------------------------
  alias :evg_sm_up_mhuds        :update_pictures
  #--------------------------------------------------------------------------
  def update_pictures
    evg_sm_up_mhuds
    @mouse_huds.values.compact.each(&:update) if @mouse_huds
  end
  #--------------------------------------------------------------------------
end
#===============================================================================
class HudSpriteMouse < Sprite
  #--------------------------------------------------------------------------
  def initialize(command, viewport = nil)
    super(viewport)
    self.x = command[:pos_x]
    self.y = command[:pos_y]
    @icon_index = command[:icon]
    @hower_text = command[:hower_text]
    @common_event_id = command[:ce_on_click]
    @pos    = command[:hower_pos]
    @need_clean = true
    create_bitmap
    adjust_position if command[:invert_x]
    refresh
  end
  def adjust_position
    self.x -= self.bitmap.width
  end
  #--------------------------------------------------------------------------
  def create_bitmap
    self.bitmap = Bitmap.new(24, 24) 
    width_plus = self.bitmap.text_size(@hower_text).width
    self.bitmap.dispose
    self.bitmap = Bitmap.new(24 + width_plus + 4, 24)
  end
  #--------------------------------------------------------------------------
  def refresh
    self.bitmap.clear
    draw_icon(@icon_index, icon_x, 0)
  end
  #--------------------------------------------------------------------------
  def update
    if mouse_hower?
      proccess_common_event if Mouse.trigger?(0)
      return if @need_clean
      $mouse.ignored = true
      refresh
      self.bitmap.draw_text(text_x, 0, self.bitmap.width - 26, 24, @hower_text)
      @need_clean = true
    elsif @need_clean
      $mouse.ignored = false
      refresh
      @need_clean = false
    end
  end
  #--------------------------------------------------------------------------
  def icon_x
    @pos == :right ? 0 : self.bitmap.width - 24
  end
  #--------------------------------------------------------------------------
  def text_x
    @pos == :right ? 26 : 0
  end
  #--------------------------------------------------------------------------
  def proccess_common_event
    $game_temp.reserve_common_event(@common_event_id)
  end
  #--------------------------------------------------------------------------
  def mouse_hower?
    return false if $game_message.visible
    (hower_x..(hower_x + 24)).include?(Mouse.pos[0]) &&
    (self.y..(self.y + 24)).include?(Mouse.pos[1]) 
  end
  #--------------------------------------------------------------------------
  def hower_x
    @pos == :right ? self.x : self.x + self.bitmap.width - 24
  end
  #--------------------------------------------------------------------------
  def draw_icon(icon_index, x, y)
    bitmap = Cache.system("Iconset")
    rect = Rect.new(icon_index % 16 * 24, icon_index / 16 * 24, 24, 24)
    self.bitmap.blt(x, y, bitmap, rect)
  end
  #--------------------------------------------------------------------------
end
#===============================================================================
# SCRIPT END
#===============================================================================