# Script:   Draw Animated Characters In Windows
# Author:   Evgenij
# Date:     07.01.2015
# Version:  1.0a
#
# Description: With this script you can add a new method to windows
#              which will draw animated characters
#
#              You need to include the EVG::AnimatedDrawCharacter Module
#              into a Window class.
#              Then you can use this methods:
#                draw_animated_character(character_name, character_index, x, y, direction = 2)
#                clear_animated_characters # clears all the characters from windows content
#					   # and stops drawing them
module EVG
  # Adds a new method to a window when included:
  #   draw_animated_character(character_name, character_index, x, y, direction = 2)
  module AnimatedDrawCharacter
    # wait between each character frame (in frames)
    WAIT_BETWEEN_FRAMES = 10

    def initialize(*args)
      super(*args)
      create_animation_state_machine
    end

    def create_animation_state_machine
      @anim_state_machine = AnimationStateMachine.new
      @animated_characters = []
    end

    def draw_animated_character(character_name, character_index, x, y, direction = 2)
      return unless character_name
      bitmap = Cache.character(character_name)
      sign = character_name[/^[\!\$]./]
      if sign && sign.include?('$')
        cw = bitmap.width / 3
        ch = bitmap.height / 4
      else
        cw = bitmap.width / 12
        ch = bitmap.height / 8
      end
      @animated_characters << [character_name, character_index, x, y, cw, ch, direction]
      @animated_characters.uniq!
      update_animated_characters
    end

    def clear_animated_characters
      @animated_characters.each do |arr|
        contents.clear_rect(arr[2] - arr[4] / 2, arr[3] - arr[5], arr[4], arr[5])
      end
      @animated_characters = []
    end

    def update
      super
      @anim_state_machine.update
      update_animated_characters if @anim_state_machine.changed?
    end

    def update_animated_characters
      @animated_characters.each{|arr| update_animated_character(arr)}
    end

    # Param looks like this: [character_name, character_index, x, y, ch, cw, direction]
    def update_animated_character(arr)
      contents.clear_rect(arr[2] - arr[4] / 2, arr[3] - arr[5], arr[4], arr[5])
      bitmap = Cache.character(arr[0])
      src_rect = @anim_state_machine.get_rect(arr[1], arr[4], arr[5], arr[6])
      contents.blt(arr[2] - arr[4] / 2, arr[3] - arr[5], bitmap, src_rect)
    end
  end

  class AnimationStateMachine
    def initialize
      super
      @anime_count = 0
      @pattern = 1
      @frame_count = AnimatedDrawCharacter::WAIT_BETWEEN_FRAMES
    end

    def get_rect(char_index, cw, ch, d)
      pattern = @pattern < 3 ? @pattern : 1
      sx = (char_index % 4 * 3 + pattern) * cw
      sy = (char_index / 4 * 4 + (d - 2) / 2) * ch
      Rect.new(sx, sy, cw, ch)
    end

    def update
      update_pattern
    end

    def update_pattern
      @anime_count += 1
      if @anime_count > @frame_count
        @pattern = (@pattern + 1) % 4
        @anime_count = 0
      end
    end

    def changed?
      @anime_count == 0
    end
  end
end