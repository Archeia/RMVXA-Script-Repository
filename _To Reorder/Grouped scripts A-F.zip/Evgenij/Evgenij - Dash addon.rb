#===============================================================================
# ** Dash Addon **
# 
# Author:   Evgenij
# Version:  1.0
# Date:     20.07.2014
#
#===============================================================================
# Description:
#  With this small script it is possible to turn the dashing on and off with a
#  scriptcall. You can also make no dash states. This means if an actor in the
#  party have a no dash state the dashing will be also deactivated.
#
# Scriptcalls:
#
#  - dash_on                  # Turn on dashing
#  - dash_off                 # Turn off dashing
#
#  - $game_player.real_dash?  # Returns true if the player is really dashing.
#                             # The method .dash? returns already true when
#                             # the player just hits the dash button.
#                             # This new method checks if the player is moving
#                             # also before returning true
# State Notetags:
# 
# <block_dash>   # blocks dash if any of the actors have this state.
#
#===============================================================================
class RPG::State
  #-----------------------------------------------------------------------------
  def dash_blocked?
    return @note.include?("<block_dash>")
  end
  #-----------------------------------------------------------------------------
end
#===============================================================================
class Game_Actors
  #-----------------------------------------------------------------------------
  def any?(*args, &block)
    @data.compact.any?(*args, &block)
  end
  #-----------------------------------------------------------------------------
end
#===============================================================================
class Game_Player
  attr_accessor   :dash_flag
  #-----------------------------------------------------------------------------
  alias :evg_gp_initialize_dash_addon   :initialize
  #-----------------------------------------------------------------------------
  def initialize
    @dash_flag = true
    evg_gp_initialize_dash_addon
  end
  #-----------------------------------------------------------------------------
  alias :evg_gp_dash_addon        :dash?
  #-----------------------------------------------------------------------------
  def dash?
    return evg_gp_dash_addon && @dash_flag && !no_dash_state?
  end
  #-----------------------------------------------------------------------------
  def no_dash_state?
    return $game_actors.any?(&:dash_blocked?)
  end
  #-----------------------------------------------------------------------------
  def real_dash?
    dash? && moving?
  end
  #-----------------------------------------------------------------------------
end
#===============================================================================
class Game_Actor
  #-----------------------------------------------------------------------------
  def dash_blocked?
    states.any?(&:dash_blocked?)
  end
  #-----------------------------------------------------------------------------
end
#===============================================================================
class Game_Interpreter
  #-----------------------------------------------------------------------------
  def dash_on
    $game_player.dash_flag = true
  end
  #-----------------------------------------------------------------------------
  def dash_off
    $game_player.dash_flag = false
  end
  #-----------------------------------------------------------------------------
end
#===============================================================================
# SCRIPT END
#===============================================================================