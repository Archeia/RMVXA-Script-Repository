#===============================================================================
# ** "Do It Yourself" - Crafting **
# 
# Author:   Evgenij
# Version:  1.1a
# Date:     08.08.2014
#
# Terms of Use: http://evgenij-scripts.org/?page_id=34
#
#===============================================================================
# Changelog:
#
# V. 1.0 - 24.07.2014   - Script created
# V. 1.1 - 25.07.2014   - fixed some bugs, added new recipe scene
# V. 1.1a- 08.08.2014	- fixed small bug
#
#===============================================================================
# Description:
#   This script adds a crafting scene to your game.
#   It is a bit different from the other crafting scripts, cause with this script
#   the player dont choose the recipes but need to choose the ingredients.
#
# Instruction:
#
#   To call the crafting scene make this scriptcall:
#   SceneManager.call(Scene_ICrafting)
#
#   To call the recipe scene make this scriptcall:
#   SceneManager.call(Scene_ICRecipes)
#
#
#   These calls are only relevant if SHOW_RECIPES_ONLY_WHEN_LEARNED = true:
#
#     To make recipes visible to the player:
#     CraftingHandler.add_recipe(:recipe_name)
#   
#
#     to make all recipes visible to the player:
#     CraftingHandler.add_all_recipes
#===============================================================================
module EVG
  module CRAFTING
    module CONFIG
      #-------------------------------------------------------------------------
      # Here you can define your recipes.
      # The template looks like this: 
      #   :recipe_name => {:recipe => [:item_codes], :result => :item_code},
      # The item codes look like this:
      #   For weapon:
      #     :w+database_id
      #   For armor:
      #     :a+database_id
      #   For item:
      #     :i+database_id
      #
      # Example:
      #   w21 - This would be a weapon with the database_id 21
      #
      # Look at the predefined recipes for more examples
      #
      # You dont need to care for the ingredient order.
      #-------------------------------------------------------------------------
      RECIPES = {
        
        :potion2 => {:recipe => [:i1, :i1, :i1], :result => :i2},
        :potion3 => {:recipe => [:i2, :i2],      :result => :i3},
        :cool_weapon => {:recipe => [:w1, :w2, :i17], :result => :w61},
        :cool_armor => {:recipe => [:a1, :i3], :result => :a61}
        
      }
      
      #-------------------------------------------------------------------------
      # Welche Kategorien sollen angezeigt werden?
      # Standartkategorien:  :item, :weapon, :armor, :key_item
      #-------------------------------------------------------------------------
      CATEGORIES = [:item, :weapon, :armor]

      #-------------------------------------------------------------------------
      # If this is set to true the player wont be able to see the result item
      # before he have crafted it once
      #-------------------------------------------------------------------------
      SHOW_RESULT_ONLY_WHEN_LEARNED = false
      
      #-------------------------------------------------------------------------
      # Give items back when crafting fails ?
      #-------------------------------------------------------------------------
      GIVE_ITEMS_BACK_WHEN_FAILURE = true
      
      #-------------------------------------------------------------------------
      # Show the crafting command in the main menu ?
      # This may only work for the vanilla menu.
      #-------------------------------------------------------------------------
      MAIN_MENU_COMMAND = true

  #-----------------------------------------------------------------------------
  # Recipe Scene:
  #-----------------------------------------------------------------------------
      SHOW_RECIPES_ONLY_WHEN_LEARNED = false
      
      #-------------------------------------------------------------------------
      # If the the option above is true, you can choose if you want to show icons
      # only or show nothing.
      #-------------------------------------------------------------------------
      SHOW_ICONS = true
      
      #-------------------------------------------------------------------------
      # Show the recipe command in the main menu ?
      # This may only work for the vanilla menu.
      #-------------------------------------------------------------------------
      RECIPE_MAIN_MENU_COMMAND = true
      #-------------------------------------------------------------------------
    end
    module VOCAB
      #-------------------------------------------------------------------------
      # Main Menu Command
      #-------------------------------------------------------------------------
      COMMAND = "Crafting"
      
      UNKNOWN_OUTPUT = "???"
      ALREADY_FAILED = "This won't work!"
      FAILED = "This has gone wrong!"
      CRAFT = "Start Crafting!"
      RESULT = "Result:"

      #-------------------------------------------------------------------------
      # Rezept Scene Vokabular:
      #-------------------------------------------------------------------------
      RECIPE_COMMAND = "Recipes" 
      RECIPE = "Recipe:"
      NOT_LEARNED = "You haven't learned the recipe yet!"
    end
  end
end
#===============================================================================
module CraftingHandler
  #--------------------------------------------------------------------------
  def self.get_recipe_for_list(list)
    return if list.compact.size < 2
    converted_list = code_array(list).compact.sort
    EVG::CRAFTING::CONFIG::RECIPES.each_with_index do |(name, setting), i|
      next if setting[:recipe].compact.size != list.compact.size
      if setting[:recipe].compact.sort == converted_list
        return name
      end
    end
    return nil
  end
  #--------------------------------------------------------------------------
  def self.add_failed_recipe(list)
    converted_list = code_array(list).compact.sort
    $game_system.add_failed_recipe(converted_list) 
  end
  #--------------------------------------------------------------------------
  def self.already_failed?(list)
    return false unless $game_system.failed_recipes
    converted_list = code_array(list).compact.sort
    $game_system.failed_recipes.each do |recipe_list|
      if recipe_list == converted_list
        return true
      end
    end
    return false
  end
  #--------------------------------------------------------------------------
  def self.get_object_for_code(code)
    case code.to_s[0]
    when "w"
      $data_weapons[code.to_s.delete("w").to_i]
    when "a"
      $data_armors[code.to_s.delete("a").to_i]
    when "i"
      $data_items[code.to_s.delete("i").to_i]
    else
      return nil
    end
  end
  #--------------------------------------------------------------------------
  def self.get_code_for_object(object)
    return "w#{object.id}".to_sym if object.is_a?(RPG::Weapon)
    return "i#{object.id}".to_sym if object.is_a?(RPG::Item)
    return "a#{object.id}".to_sym if object.is_a?(RPG::Armor)
  end
  #--------------------------------------------------------------------------
  def self.code_array(object_array)
    object_array.map{|obj| get_code_for_object(obj)}
  end
  #--------------------------------------------------------------------------
  def self.get_object_for_recipe(recipe)
    return nil unless recipe
    return get_object_for_code(EVG::CRAFTING::CONFIG::RECIPES[recipe][:result])
  end
  #--------------------------------------------------------------------------
  def self.recipes
    return @recipes if @recipes
    @recipes = {}
    recipe_codes.each do |recipe_name, recipes|
      @recipes[recipe_name] = recipes.map {|code| get_object_for_code(code)}
    end
    return @recipes
  end
  #--------------------------------------------------------------------------
  def self.recipe_codes
    return @recipe_codes if @recipe_codes
    @recipe_codes = {}
    EVG::CRAFTING::CONFIG::RECIPES.each do |(recipe, setting)|
      @recipe_codes[recipe] = setting[:recipe]
    end
    return @recipe_codes
  end
  #--------------------------------------------------------------------------
  def self.results
    return @results if @results
    @results = {}
    result_codes.each do |recipe, code| 
      @results[recipe] = get_object_for_code(code)
    end
    return @results
  end
  #--------------------------------------------------------------------------
  def self.result_codes
    return @result_codes if @result_codes
    @result_codes = {}
    EVG::CRAFTING::CONFIG::RECIPES.each do |(recipe, setting)|
      @result_codes[recipe] = setting[:result]
    end
    return @result_codes
  end
  #--------------------------------------------------------------------------
  def self.add_recipe(key)
    $game_system.add_crafting_recipe(key)
  end
  #--------------------------------------------------------------------------
  def self.add_all_recipes
    $game_system.crafting_recipes = recipes.keys
  end
  #--------------------------------------------------------------------------
end
#===============================================================================
class RPG::BaseItem
  def hide_craft?
    @note.include?("<hide_craft>")
  end
end
#===============================================================================
class Game_System
  #--------------------------------------------------------------------------
  attr_accessor     :crafting_recipes
  attr_reader       :failed_recipes
  #--------------------------------------------------------------------------
  alias :evg_gs_initialize_ic   :initialize
  def initialize
    evg_gs_initialize_ic
    @crafting_recipes = []
  end
  #--------------------------------------------------------------------------
   def add_crafting_recipe(recipe)
    return if @crafting_recipes && @crafting_recipes.include?(recipe)
    @crafting_recipes.push(recipe)
  end
  #--------------------------------------------------------------------------
  def remove_crafting_recipe(recipe)
    return if @crafting_recipes && !@crafting_recipes.include?(recipe)
    @crafting_recipes.delete(recipe)
  end
  
  def add_failed_recipe(list)
    @failed_recipes ||= []
    return if @failed_recipes.include?(list)
    @failed_recipes.push(list)
  end
  #--------------------------------------------------------------------------
end
#===============================================================================
class Window_ICCategory < Window_ItemCategory
  #--------------------------------------------------------------------------
  def col_max
    return [@list.size, 4].min
  end
  #--------------------------------------------------------------------------
  def make_command_list
    EVG::CRAFTING::CONFIG::CATEGORIES.each do |cat|
      add_command(Vocab.send(cat),     cat)
    end
  end
  #--------------------------------------------------------------------------
  def ok_enabled?
    return false
  end
  #--------------------------------------------------------------------------
end
#===============================================================================
class Window_ICraftingList < Window_Selectable
  include EVG::CRAFTING::VOCAB
  #--------------------------------------------------------------------------
  attr_reader   :items
  #--------------------------------------------------------------------------
  def initialize
    @crafting_slots = 4
    @items = [nil] * @crafting_slots
    super(window_x, window_y, window_width, window_height)
    activate
    select(0)
    refresh
  end
  #--------------------------------------------------------------------------
  def window_x
    Graphics.width / 2
  end
  #--------------------------------------------------------------------------
  def window_y
    fitting_height(4)
  end
  #--------------------------------------------------------------------------
  def window_width
    return Graphics.width / 2 
  end
  #--------------------------------------------------------------------------
  def window_height
    return Graphics.height - fitting_height(4)
  end
  #--------------------------------------------------------------------------
  def item_max
    return @crafting_slots + 1
  end
  #--------------------------------------------------------------------------
  def current_slot
    return @items[@index]
  end
  #--------------------------------------------------------------------------
  def current_slot=(item)
    @items[@index] = item
  end
  #--------------------------------------------------------------------------
  def result=(result)
    @result = result
    refresh
  end
  #--------------------------------------------------------------------------
  def recipe=(recipe)
    @recipe = recipe
  end
  #--------------------------------------------------------------------------
  def current_item_enabled?
    return true if index < 4
    return true if @items.compact.size > 1
    return false
  end
  #--------------------------------------------------------------------------
  def craft_command?(index)
    return index >= @crafting_slots
  end
  #--------------------------------------------------------------------------
  def current_craft_command?
    return craft_command?(@index)
  end
  #--------------------------------------------------------------------------
  def text_enabled?
    return @items.compact.size > 1
  end
  #--------------------------------------------------------------------------
  def recipe_learned?
    return true unless recipe_need_to_learn?
    return $game_system.crafting_recipes.include?(@recipe)
  end
  
  def recipe_need_to_learn?
    EVG::CRAFTING::CONFIG::SHOW_RESULT_ONLY_WHEN_LEARNED
  end
  #--------------------------------------------------------------------------
  def item_rect(index) 
    rect = super(index)
    rect.y += line_height * top_lines
    rect.y += line_height if craft_command?(index)
    rect
  end
  #--------------------------------------------------------------------------
  def top_lines
    return 4
  end
  #--------------------------------------------------------------------------
  def draw_item(index)
    if !craft_command?(index)
      draw_bg(index, item_rect(index), Color.new(0,0,0, 128))
      draw_item_name(index) if @items[index]
    else
      draw_craft_command(index)
    end
  end
  #--------------------------------------------------------------------------
  def draw_bg(index, rect, color)
    contents.fill_rect(rect.x+1, rect.y+1, rect.width-2, rect.height-2, color)
  end
  #--------------------------------------------------------------------------
  def draw_item_name(index)
    change_color(normal_color)
    draw_icon(@items[index].icon_index, item_rect(index).x + 2, item_rect(index).y)
    x = item_rect(index).x + 28
    y = item_rect(index).y
    width = item_rect(index).width - 28
    draw_text(x, y, width, line_height, @items[index].name)
  end
  #--------------------------------------------------------------------------
  def draw_craft_command(index)
    change_color(normal_color, text_enabled?)
    draw_text(item_rect(index), CRAFT, 1)
  end
  #--------------------------------------------------------------------------
  def draw_horz_line(y)
    line_y = y + line_height / 2 - 1
    contents.fill_rect(0, line_y, contents_width, 2, line_color)
  end
  #--------------------------------------------------------------------------
  def refresh
    super
    draw_result
    draw_result_item
    draw_horizontal_lines
  end
  #--------------------------------------------------------------------------
  def draw_result
    change_color(system_color)
    draw_text(0,0,contents.width, line_height, RESULT, 1)
  end
  #--------------------------------------------------------------------------
  def draw_result_item
    return unless items.compact.size > 1
    change_color(normal_color)
    if @result && recipe_learned? && @recipe != :failed
      draw_icon(@result.icon_index, 0, line_height * 2)
      draw_text(24, line_height * 2, contents.width, line_height, @result.name)
      @result = nil
    elsif @recipe == :failed || !recipe_need_to_learn? && recipe_learned?
      draw_text(0,line_height * 2,contents.width, line_height, ALREADY_FAILED, 1)
    else
      draw_text(0,line_height * 2,contents.width, line_height, UNKNOWN_OUTPUT, 1)
    end
  end
  #--------------------------------------------------------------------------
  def draw_horizontal_lines
    draw_horz_line(line_height)
    draw_horz_line(line_height * (top_lines - 1))
    draw_horz_line(line_height * (top_lines + @crafting_slots))
    draw_horz_line(line_height * (top_lines + @crafting_slots + 2))
  end
  #--------------------------------------------------------------------------
  def clear
    @items = [nil] * @crafting_slots
    refresh
  end
  #--------------------------------------------------------------------------
  def update_help
    @help_window.set_item(current_slot)
  end
  #--------------------------------------------------------------------------
  def line_color
    color = normal_color
    color.alpha = 48
    color
  end
  #--------------------------------------------------------------------------
  def process_handling
    return unless open? && active
    return process_ok       if ok_enabled?        && Input.trigger?(:C)
    return process_cancel   if cancel_enabled?    && Input.trigger?(:B)
    return process_pagedown if handle?(:pagedown) && Input.trigger?(:R)
    return process_pageup   if handle?(:pageup)   && Input.trigger?(:L)
    return process_shift    if handle?(:shift)    && Input.trigger?(:A)
  end
  #--------------------------------------------------------------------------
  def process_shift
    Sound.play_cursor
    Input.update
    call_handler(:shift)
  end
  #--------------------------------------------------------------------------
end
#===============================================================================
class Window_ICItemList < Window_Selectable
  #--------------------------------------------------------------------------
  def initialize(x, y)
    super(x, y, window_width, window_height)
    @data = []
    @category = :none
    select(0)
  end
  #--------------------------------------------------------------------------
  def category=(category)
    return if @category == category
    @category = category
    select(0)
    refresh
    self.oy = 0
  end
  #--------------------------------------------------------------------------
  def col_max
    return 1
  end
  #--------------------------------------------------------------------------
  def window_width
    return Graphics.width  / 2
  end
  #--------------------------------------------------------------------------
  def window_height
    Graphics.height - fitting_height(4)
  end
  #--------------------------------------------------------------------------
  def item_max
    @data ? @data.size : 1
  end
  #--------------------------------------------------------------------------
  def item
    @data && index >= 0 ? @data[index] : nil
  end
  def current_item
    return @data[@index]
  end
  #--------------------------------------------------------------------------
  def current_item_enabled?
    return true
  end
  #--------------------------------------------------------------------------
  def enable?(item)
    return true
  end
  #--------------------------------------------------------------------------
  def include?(item)
    return false if item.hide_craft?
    case @category
    when :item
      item.is_a?(RPG::Item)
    when :weapon
      item.is_a?(RPG::Weapon)
    when :armor
      item.is_a?(RPG::Armor)
    else
      false
    end
  end
  #--------------------------------------------------------------------------
  def make_item_list
    @data = $game_party.all_items.select {|item| include?(item) }
    @data.push(nil)
  end
  #--------------------------------------------------------------------------
  def draw_item(index)
    item = @data[index]
    if item
      rect = item_rect(index)
      rect.width -= 4
      draw_item_name(item, rect.x, rect.y, enable?(item))
      draw_item_number(rect, item)
    end
  end
  #--------------------------------------------------------------------------
  def draw_item_number(rect, item)
    draw_text(rect, sprintf(":%2d", $game_party.item_number(item)), 2)
  end
  #--------------------------------------------------------------------------
  def update_help
    @help_window.set_item(item)
  end
  #--------------------------------------------------------------------------
  def refresh
    make_item_list
    create_contents
    draw_all_items
  end
  #--------------------------------------------------------------------------
end
#===============================================================================
class Window_ICResult < Window_Base
  include EVG::CRAFTING::VOCAB
  #--------------------------------------------------------------------------
  def initialize
    super(window_x, window_y, window_width, window_height)
    self.visible = false
    self.opacity = 0
    @frame_counter = 0
  end
  #--------------------------------------------------------------------------
  def window_x
    window_width
  end
  #--------------------------------------------------------------------------
  def window_y
    fitting_height(6)
  end
  #--------------------------------------------------------------------------
  def window_width
    Graphics.width / 2
  end
  #--------------------------------------------------------------------------
  def window_height
    fitting_height(1)
  end
  #--------------------------------------------------------------------------
  def open(item)
    self.visible = true
    if item
      draw_result(item)
    else
      draw_no_result
    end
    @frame_counter = 60
  end
  #--------------------------------------------------------------------------
  def draw_result(item)
    change_color(power_up_color)
    draw_icon(item.icon_index, 0, 0)
    draw_text(24, 0, contents.width - 26, line_height, "#{item.name} +", 0)
  end
  #--------------------------------------------------------------------------
  def draw_no_result
    change_color(power_down_color)
    draw_text(4, 0, contents.width - 4, contents.height, FAILED, 1)
  end
  #--------------------------------------------------------------------------
  def update
    super
    if @frame_counter > 0
      @frame_counter -= 1
      if @frame_counter <= 0
        contents.clear
        self.visible = false
      end
    end
  end
  #--------------------------------------------------------------------------
end
#===============================================================================
class Scene_ICrafting < Scene_MenuBase
  #--------------------------------------------------------------------------
  def start
    super
    @items_back = {}
    @current_recipe = nil
    create_help_window
    create_crafting_window
    create_category_window
    create_item_window
    create_result_window
  end
  #--------------------------------------------------------------------------
  def create_crafting_window
    @crafting_window = Window_ICraftingList.new
    @crafting_window.set_handler(:cancel, method(:return_scene))
    @crafting_window.set_handler(:ok, method(:on_crafting_ok))
    @crafting_window.set_handler(:shift, method(:on_crafting_shift))
    @crafting_window.help_window = @help_window
  end
  #--------------------------------------------------------------------------
  def create_category_window
    @category_window = Window_ICCategory.new
    @category_window.y = @help_window.height
  end
  #--------------------------------------------------------------------------
  def create_item_window
    y = @help_window.height + @category_window.height
    @item_window = Window_ICItemList.new(0, y)
    @item_window.help_window = @help_window
    @item_window.set_handler(:cancel, method(:on_item_cancel))
    @item_window.set_handler(:ok, method(:on_item_ok))
    @category_window.item_window = @item_window
  end
  #--------------------------------------------------------------------------
  def create_result_window
    @result_window = Window_ICResult.new
  end
  #--------------------------------------------------------------------------
  def on_crafting_ok
    if !@crafting_window.current_craft_command?
      @crafting_window.deactivate
      @item_window.activate
    else
      @result_window.open(item)
      process_old_items
      gain_item if item
      CraftingHandler.add_failed_recipe(@crafting_window.items) unless item
      @crafting_window.clear
      @crafting_window.activate
      @crafting_window.select(0)
      @item_window.refresh
    end
  end
  #--------------------------------------------------------------------------
  def on_crafting_shift
    switch_items(@crafting_window.current_slot, nil)
    #check_recipe
  end
  #--------------------------------------------------------------------------
  def on_item_cancel
    @item_window.deactivate
    @crafting_window.activate
  end
  #--------------------------------------------------------------------------
  def on_item_ok
    switch_items(@crafting_window.current_slot, @item_window.current_item)
    on_item_cancel
    @crafting_window.select(@crafting_window.index + 1)
    #check_recipe
  end
  #--------------------------------------------------------------------------
  def check_recipe
    @current_recipe = CraftingHandler.get_recipe_for_list(@crafting_window.items)
    if !@current_recipe
      @crafting_window.recipe = :failed if failed?
    else
      @crafting_window.recipe = @current_recipe
    end
    @crafting_window.result = item
  end
  #--------------------------------------------------------------------------
  def failed?
    CraftingHandler.already_failed?(@crafting_window.items)
  end
  #--------------------------------------------------------------------------
  def switch_items(old_item, new_item)
    @crafting_window.current_slot = new_item
    @items_back[@crafting_window.index] = new_item
    $game_party.lose_item(new_item, 1)
    $game_party.gain_item(old_item, 1) if old_item
    @item_window.refresh
    check_recipe
  end
  #--------------------------------------------------------------------------
  def gain_item
    $game_party.gain_item(item, 1) 
    $game_system.add_crafting_recipe(@current_recipe)
  end
  #--------------------------------------------------------------------------
  def process_old_items
    return_items if return_items? 
    @items_back = {}
  end
  #--------------------------------------------------------------------------
  def return_items?
    EVG::CRAFTING::CONFIG::GIVE_ITEMS_BACK_WHEN_FAILURE && !item
  end
  #--------------------------------------------------------------------------
  def item
    CraftingHandler.get_object_for_recipe(@current_recipe)
  end
  #--------------------------------------------------------------------------
  def return_scene
    return_items
    super
  end
  #--------------------------------------------------------------------------
  def return_items
    @items_back.values.compact.each{|item| $game_party.gain_item(item, 1)}
  end
  #--------------------------------------------------------------------------
end
#===============================================================================
# RECIPE SCENE
#===============================================================================
if EVG::CRAFTING::CONFIG::MAIN_MENU_COMMAND
  class Window_MenuCommand
    #--------------------------------------------------------------------------
    alias :evg_wmc_aoc_ic   :add_original_commands
    def add_original_commands
      evg_wmc_aoc_ic
      add_command(EVG::CRAFTING::VOCAB::COMMAND, :ic_crafting)
    end
  end
  class Scene_Menu
  #--------------------------------------------------------------------------
  alias :evg_sm_ccw_ic      :create_command_window
    def create_command_window
      evg_sm_ccw_ic
      @command_window.set_handler(:ic_crafting, method(:command_ic_crafting))
    end
    def command_ic_crafting
      SceneManager.call(Scene_ICrafting)
    end
  end
  #--------------------------------------------------------------------------
end
#===============================================================================
class Window_ICRCategory  < Window_ItemCategory
  #--------------------------------------------------------------------------
  def window_width
    Graphics.width - 24
  end
  #--------------------------------------------------------------------------
  def col_max
    return [@list.size, 4].min
  end
  #--------------------------------------------------------------------------
  def make_command_list
    EVG::CRAFTING::CONFIG::CATEGORIES.each do |cat|
      add_command(Vocab.send(cat.to_s),     cat)
    end
  end
  #--------------------------------------------------------------------------
end
#===============================================================================
class Window_ICRecipe_Recipe < Window_Base
  #--------------------------------------------------------------------------
  def initialize(x, y)
    super(x, y, window_width, window_height)
  end
  #--------------------------------------------------------------------------
  def window_width
    Graphics.width / 2 - 18
  end
  #--------------------------------------------------------------------------
  def window_height
    Graphics.height - fitting_height(5) - 24
  end
  #--------------------------------------------------------------------------
  def set_recipe(recipe)
    @recipe = recipe
    refresh
  end
  #--------------------------------------------------------------------------
  def clear
    @recipe = nil
    refresh
  end
  #--------------------------------------------------------------------------
  def refresh
    contents.clear
    return unless @recipe
    change_color(system_color)
    draw_text(0,0, contents.width, line_height, EVG::CRAFTING::VOCAB::RECIPE, 1)
    draw_horz_line(line_height)
    draw_horz_line(line_height * (5 + top_lines))
    draw_backgrounds
    draw_ingredients
  end
  #--------------------------------------------------------------------------
  def draw_horz_line(y)
    line_y = y + line_height / 2 - 1
    contents.fill_rect(0, line_y, contents_width, 2, line_color)
  end
  #--------------------------------------------------------------------------
  def draw_bg(x, y, color)
    contents.fill_rect(x+1, y+1, contents.width-2, line_height-2, color)
  end
  #--------------------------------------------------------------------------
  def draw_backgrounds
    color = Color.new(0,0,0, 128)
    4.times do |i|
      y = (i + top_lines) * line_height
      draw_bg(0, y, color)
    end
  end
  #--------------------------------------------------------------------------
  def draw_ingredients
    return unless @recipe
    change_color(normal_color)
    CraftingHandler.recipes[@recipe].compact.each_with_index do |ingredient, i|
      y = (i + top_lines) * line_height
      draw_icon(ingredient.icon_index, 2, y) if show_icon?
      text = learned? ? ingredient.name : EVG::CRAFTING::VOCAB::UNKNOWN_OUTPUT
      draw_text(28, y, contents.width - 28, line_height, text)
    end
  end
  #--------------------------------------------------------------------------
  def learned?
    return true unless EVG::CRAFTING::CONFIG::SHOW_RECIPES_ONLY_WHEN_LEARNED
    return $game_system.crafting_recipes.include?(@recipe)
  end
  #--------------------------------------------------------------------------
  def show_icon?
    return (learned? || EVG::CRAFTING::CONFIG::SHOW_ICONS)
  end
  #--------------------------------------------------------------------------
  def top_lines
    return 3
  end
  #--------------------------------------------------------------------------
  def line_color
    color = normal_color
    color.alpha = 48
    color
  end
  #--------------------------------------------------------------------------
end
#===============================================================================
class Window_ICR_Help < Window_Base
  #--------------------------------------------------------------------------
  def initialize(line_number = 2)
    super(0, 0, Graphics.width - 24, fitting_height(line_number))
  end
  #--------------------------------------------------------------------------
  def set_text(text)
    if text != @text
      @text = text
      refresh
    end
  end
  #--------------------------------------------------------------------------
  def clear
    set_text("")
  end
  #--------------------------------------------------------------------------
  def set_item(item)
    set_text(item ? item.description : "")
  end
  #--------------------------------------------------------------------------
  def refresh
    contents.clear
    draw_text_ex(4, 0, @text)
  end
  #--------------------------------------------------------------------------
end
#===============================================================================
class Window_ICRecipe_List < Window_Selectable
  #--------------------------------------------------------------------------
  attr_reader     :recipe_window
  #--------------------------------------------------------------------------
  def initialize
    super
  end
  #--------------------------------------------------------------------------
  def initialize(x, y)
    super(x, y, window_width, window_height)
    @category = :none
    @data = []
  end
  #--------------------------------------------------------------------------
  def recipe_window=(window)
    @recipe_window = window
    @recipe_window.set_recipe(current_key)
  end
  #--------------------------------------------------------------------------
  def window_width
    Graphics.width / 2 - 18
  end
  #--------------------------------------------------------------------------
  def window_height
    Graphics.height - fitting_height(5) - 24
  end
  #--------------------------------------------------------------------------
  def category=(category)
    return if @category == category
    @category = category
    refresh
    self.oy = 0
  end
  #--------------------------------------------------------------------------
  def col_max
    return 1
  end
  #--------------------------------------------------------------------------
  def item_max
    @data ? @data.size : 1
  end
  #--------------------------------------------------------------------------
  def item
    @data && index >= 0 ? @data[index] : nil
  end
  #--------------------------------------------------------------------------
  def current_item_enabled?
    return true
  end
  #--------------------------------------------------------------------------
  def include?(recipe, item)
    case @category
    when :item
      item.is_a?(RPG::Item) && !item.key_item?
    when :weapon
      item.is_a?(RPG::Weapon)
    when :armor
      item.is_a?(RPG::Armor)
    when :key_item
      item.is_a?(RPG::Item) && item.key_item?
    else
      false
    end
  end
  #--------------------------------------------------------------------------
  def enable?(item)
    return true
  end
  #--------------------------------------------------------------------------
  def make_item_list
    results = CraftingHandler.results
    @keys = results.map {|recipe, item| recipe if include?(recipe, item) }.compact
    @data = results.map {|recipe, item| item if include?(recipe, item) }.compact
  end
  #--------------------------------------------------------------------------
  def current_key
    @keys[@index] if @keys && @index >= 0
  end
  #--------------------------------------------------------------------------
  def draw_item_name(item, x, y, index)
    return unless item
    draw_icon(item.icon_index, x, y) if show_icon?(index)
    change_color(normal_color)
    text = learned?(index) ? item.name : EVG::CRAFTING::VOCAB::UNKNOWN_OUTPUT
    draw_text(x + 24, y, width, line_height, text)
  end
  #--------------------------------------------------------------------------
  def draw_item(index)
    item = @data[index]
    if item
      rect = item_rect(index)
      rect.width -= 4
      draw_item_name(item, rect.x, rect.y, index)
    end
  end
  #--------------------------------------------------------------------------
  def update_help
    if learned?(@index) 
      @help_window.set_item(item)
    else
      @help_window.set_text(EVG::CRAFTING::VOCAB::NOT_LEARNED) if item
    end
    return unless @recipe_window
    @recipe_window.set_recipe(current_key)
  end
  #--------------------------------------------------------------------------
  def refresh
    make_item_list
    create_contents
    draw_all_items
    @recipe_window.refresh if @recipe_window
  end
  #--------------------------------------------------------------------------
  def learned?(index)
    return true unless EVG::CRAFTING::CONFIG::SHOW_RECIPES_ONLY_WHEN_LEARNED
    return $game_system.crafting_recipes.include?(@keys[index])
  end
  #--------------------------------------------------------------------------
  def show_icon?(index)
    return (learned?(index) || EVG::CRAFTING::CONFIG::SHOW_ICONS)
  end
  #--------------------------------------------------------------------------
end
#===============================================================================
class Scene_ICRecipes < Scene_MenuBase
  #--------------------------------------------------------------------------
  def start
    super
    create_help_window
    create_category_window
    create_item_window
    create_recipe_window
    @help_window.y = 36 + @category_window.height + @item_window.height
    @help_window.x = 12
  end
  #--------------------------------------------------------------------------
  def create_help_window
    @help_window = Window_ICR_Help.new
  end
  #--------------------------------------------------------------------------
  def create_category_window
    @category_window = Window_ICRCategory.new
    @category_window.x = 12
    @category_window.y = 12
    @category_window.set_handler(:ok,     method(:on_category_ok))
    @category_window.set_handler(:cancel, method(:return_scene))
  end
  #--------------------------------------------------------------------------
  def create_item_window
    @item_window = Window_ICRecipe_List.new(12, @category_window.height + 24)
    @item_window.help_window = @help_window
    @item_window.set_handler(:cancel, method(:on_item_cancel))
    @category_window.item_window = @item_window
  end
  #--------------------------------------------------------------------------
  def create_recipe_window
    y = @category_window.height + 24
    @recipe_window = Window_ICRecipe_Recipe.new(@item_window.width + 24, y)
    @item_window.recipe_window = @recipe_window
  end
  #--------------------------------------------------------------------------
  def on_category_ok
    @item_window.activate
    @item_window.select(0)
  end
  #--------------------------------------------------------------------------
  def on_item_cancel
    @item_window.unselect
    @recipe_window.clear
    @help_window.clear
    @category_window.activate
  end
  #--------------------------------------------------------------------------
end
#===============================================================================
if EVG::CRAFTING::CONFIG::RECIPE_MAIN_MENU_COMMAND
  class Window_MenuCommand
    #--------------------------------------------------------------------------
    alias :evg_wmc_aoc_icr   :add_original_commands
    def add_original_commands
      evg_wmc_aoc_icr
      add_command(EVG::CRAFTING::VOCAB::RECIPE_COMMAND, :ic_recipes)
    end
    #--------------------------------------------------------------------------
  end
  class Scene_Menu
  #--------------------------------------------------------------------------
    alias :evg_sm_ccw_icr      :create_command_window
    #--------------------------------------------------------------------------
    def create_command_window
      evg_sm_ccw_icr
      @command_window.set_handler(:ic_recipes, method(:command_ic_recipes))
    end
    def command_ic_recipes
      SceneManager.call(Scene_ICRecipes)
    end
    #--------------------------------------------------------------------------
  end
  #--------------------------------------------------------------------------
end
#===============================================================================
# SCRIPT END
#===============================================================================