#=============================================================================== 
# ** FF 9 File Scene **
#   
# Author:       Evgenij
# Version:      1.0
# Date:         23.07.2014
#
# Terms of Use: http://evgenij-scripts.org/?page_id=34
#
# Thanks: 	Perusa 		- for the request
#		BigEd781 	- for the VX Script, I have used his pictures
#				  as reference for this script.
#===============================================================================
# Description:
#   This script tries to mimick the Final Fantasy 9 Save Menu.
#   It is plug and play, but you need to delete your old savefiles first.
#   
#   I
#===============================================================================
module EVG
  #=============================================================================
  # CONFIG START
  #=============================================================================
  module FileConfig
    
    SAVE_SLOTS = 16
    
    LOCATION_ICON = 231
    TIME_ICON = 280
    GOLD_ICON = 361
    
    EMPTY_TEXT = "--- EMPTY ---"
    SELECT_TEXT = "Choose A Slot"
    SLOT_TEXT = "Slot"
    SAVE_TEXT = "Save"
    LOAD_TEXT = "Load"
  end
  #=============================================================================
  # CONFIG END
  #=============================================================================
  module FileTopWindows
    #--------------------------------------------------------------------------
    V_SPACING = 12
    H_SPACING = 12
    SWINDOW_WIDTH = 96
    SWINDOW_PADDING = 6
    #--------------------------------------------------------------------------
    def description_window_width
      Graphics.width - (H_SPACING * 2) - SWINDOW_WIDTH * 2 - SWINDOW_PADDING
    end
    #--------------------------------------------------------------------------
    def standard_padding 
      return 6
    end
    #--------------------------------------------------------------------------
    def window_height
      return fitting_height(1)
    end
    #--------------------------------------------------------------------------
  end
  #=============================================================================
end
#===============================================================================
module DataManager
  #--------------------------------------------------------------------------
  class << self
    alias :evg_dm_msh_sff9      :make_save_header
  end
  #--------------------------------------------------------------------------
  def self.savefile_max
    return EVG::FileConfig::SAVE_SLOTS
  end
  #--------------------------------------------------------------------------
  def self.make_save_header
    header = evg_dm_msh_sff9
    header[:faces] = $game_party.faces_for_savefile
    header[:location] = $game_map.display_name
    header[:leader_name] = $game_party.leader.name
    header[:leader_level] = $game_party.leader.level
    header[:gold] = $game_party.gold
    header
  end
  #--------------------------------------------------------------------------
end
#===============================================================================
class Game_Party
  #--------------------------------------------------------------------------
  def faces_for_savefile
    battle_members.collect do |actor|
      [actor.face_name, actor.face_index]
    end
  end
  #--------------------------------------------------------------------------
end
#===============================================================================
class Window_FileDescription < Window_Base
  #--------------------------------------------------------------------------
  include EVG::FileTopWindows
  #--------------------------------------------------------------------------
  def initialize
    super(H_SPACING, V_SPACING, description_window_width, window_height)
    refresh
  end
  #--------------------------------------------------------------------------
  def window_height
    return fitting_height(1)
  end
  #--------------------------------------------------------------------------
  def refresh
    contents.clear
    draw_text_ex(12, 0, EVG::FileConfig::SELECT_TEXT)
  end
  #--------------------------------------------------------------------------
end
#===============================================================================
class Window_FileSlot < Window_Base
  #--------------------------------------------------------------------------
  include EVG::FileTopWindows
  #--------------------------------------------------------------------------
  def initialize
    super(window_x, V_SPACING, window_width, window_height)
    @slot = "1"
    refresh
  end
  #--------------------------------------------------------------------------
  def window_x
    return H_SPACING + description_window_width
  end
  #--------------------------------------------------------------------------
  def window_width
    return SWINDOW_WIDTH
  end
  #--------------------------------------------------------------------------
  def window_height
    fitting_height(1)
  end
  #--------------------------------------------------------------------------
  def slot=(slot)
    @slot = slot
    refresh
  end
  #--------------------------------------------------------------------------
  def refresh
    contents.clear
    draw_text(0, 0, contents.width, line_height, "#{EVG::FileConfig::SLOT_TEXT} #{@slot}", 1)
  end
  #--------------------------------------------------------------------------
end
#===============================================================================
class Window_FileInfo < Window_Base
  #--------------------------------------------------------------------------
  include EVG::FileTopWindows
  #--------------------------------------------------------------------------
  def initialize(type = "")
    super(window_x, V_SPACING, window_width, window_height)
    refresh(type)
  end
  #--------------------------------------------------------------------------
  def window_x
    H_SPACING + description_window_width + SWINDOW_WIDTH + SWINDOW_PADDING
  end
  #--------------------------------------------------------------------------
  def window_width
    return SWINDOW_WIDTH
  end
  #--------------------------------------------------------------------------
  def window_height
    return fitting_height(1)
  end
  #--------------------------------------------------------------------------
  def refresh(type)
    contents.clear
    draw_text(0, 0, contents.width, line_height, type, 1)
  end
end
#===============================================================================
class Window_SaveFile < Window_Base
  #--------------------------------------------------------------------------
  def initialize(height, index)
    super(window_x, index * height, window_width, height)
    @file_index = index
    get_header
    refresh
    @selected = false
  end
  #--------------------------------------------------------------------------
  def get_header
    @header = DataManager.load_header(@file_index)
  end
  #--------------------------------------------------------------------------
  def header
    return @header
  end
  #--------------------------------------------------------------------------
  def window_x
    return EVG::FileTopWindows::H_SPACING
  end
  #--------------------------------------------------------------------------
  def window_width
    return Graphics.width - EVG::FileTopWindows::H_SPACING * 2
  end
  #--------------------------------------------------------------------------
  def text_x
    return 72 * 4 + 6
  end
  #--------------------------------------------------------------------------
  def text_width
    (contents.width - text_x) / 2
  end
  #--------------------------------------------------------------------------
  def draw_face(face_name, face_index, x, y)
    bitmap = Cache.face(face_name)
    rect = Rect.new(face_index % 4 * 96 + 12, face_index / 4 * 96 + 12, 70, 71)
    contents.blt(x, y, bitmap, rect)
    bitmap.dispose
  end
  #--------------------------------------------------------------------------
  def refresh
    contents.clear
    change_color(normal_color)
    if header
      draw_party_faces(72, 0)
      draw_leader_name(text_x, 3)
      draw_leader_level(text_x, line_height + 2)
      draw_location(text_x, line_height * 2)
      draw_playtime(text_x + text_width, 3)
      draw_gold(text_x + text_width, line_height + 2)
    else
      draw_text(0,0, contents.width, contents.height, EVG::FileConfig::EMPTY_TEXT, 1)
    end
  end
  #--------------------------------------------------------------------------
  def draw_party_faces(x, y)
    header[:faces].each_with_index do |data, i|
      draw_face(data[0], data[1], x * i + 2, y + 2)
    end
  end
  #--------------------------------------------------------------------------
  def draw_leader_name(x, y, width = 112)
    draw_text(x, y, width, line_height, header[:leader_name])
  end
  #--------------------------------------------------------------------------
  def draw_leader_level(x, y)
    change_color(system_color)
    draw_text(x, y, 32, line_height, Vocab::level_a)
    change_color(normal_color)
    draw_text(x + 32, y, 24, line_height, header[:leader_level], 2)
  end
  #--------------------------------------------------------------------------
  def draw_location(x, y)
    return if header[:location].empty?
    draw_icon(EVG::FileConfig::LOCATION_ICON, x, y)
    draw_text(x + 28, y, text_width * 2 - 28, line_height, header[:location])
  end
  #--------------------------------------------------------------------------
  def draw_playtime(x, y)
    draw_icon(EVG::FileConfig::TIME_ICON, x - 12, y)
    draw_text(x, y, text_width - 6, line_height, header[:playtime_s], 2)
  end
  #--------------------------------------------------------------------------
  def draw_gold(x, y)
    draw_icon(EVG::FileConfig::GOLD_ICON, x - 12, y)
    draw_text(x, y, text_width - 6, line_height, header[:gold], 2)
  end
  #--------------------------------------------------------------------------
  def update_cursor
    if @selected
      cursor_rect.set(contents.rect)
    else
      cursor_rect.empty
    end
  end
  #--------------------------------------------------------------------------
  def standard_padding
    return 6
  end
  #--------------------------------------------------------------------------
end
#===============================================================================
class Scene_File < Scene_MenuBase
  #--------------------------------------------------------------------------
  def start
    super
    create_help_window
    create_info_window
    create_slot_window
    create_savefile_viewport
    create_savefile_windows
    init_selection
  end
  #--------------------------------------------------------------------------
  def create_help_window
    @help_window = Window_FileDescription.new
  end
  #--------------------------------------------------------------------------
  def create_slot_window
    @slot_window = Window_FileSlot.new
  end
  #--------------------------------------------------------------------------
  def create_info_window
    return
  end
  #--------------------------------------------------------------------------
  def terminate
    super
    @savefile_viewport.dispose
    @savefile_windows.each {|window| window.dispose }
  end
  #--------------------------------------------------------------------------
  def create_savefile_viewport
    @savefile_viewport = Viewport.new
    @savefile_viewport.rect.y = @help_window.height + EVG::FileTopWindows::V_SPACING + 6
    @savefile_viewport.rect.height -= @help_window.height + 6 + (EVG::FileTopWindows::V_SPACING * 2) + 1
  end
  #--------------------------------------------------------------------------
  def update_cursor
    last_index = @index
    cursor_down (Input.trigger?(:DOWN))  if Input.repeat?(:DOWN)
    cursor_up   (Input.trigger?(:UP))    if Input.repeat?(:UP)
    cursor_pagedown   if Input.trigger?(:R)
    cursor_pageup     if Input.trigger?(:L)
    if @index != last_index
      Sound.play_cursor
      @savefile_windows[last_index].selected = false
      @savefile_windows[@index].selected = true
      @slot_window.slot = @index + 1 if @slot_window
    end
  end
  #--------------------------------------------------------------------------
end
#===============================================================================
class Scene_Save
  #--------------------------------------------------------------------------
  def create_info_window
    @info_window = Window_FileInfo.new(EVG::FileConfig::SAVE_TEXT)
  end
  #--------------------------------------------------------------------------
end
#===============================================================================
class Scene_Load
  #--------------------------------------------------------------------------
  def create_info_window
    @info_window = Window_FileInfo.new(EVG::FileConfig::LOAD_TEXT)
  end
  #--------------------------------------------------------------------------
end
#===============================================================================
# SCRIPT END
#===============================================================================