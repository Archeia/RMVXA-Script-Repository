#===============================================================================
# ***Class Change Equipment***
#
# Author:     Evgenij (eugene222)
# Version:    1.2
# Date:       11.07.2014
# Requires:   ---
#===============================================================================
# Changelog:
#
#   11.07.2014 - V. 1.0 - script created
#   16.09.2014 - V. 1.1 - added armors
#   16.09.2014 - V. 1.2 - fixed some bugs, changed how script works
#
#===============================================================================
# Terms of Use:
#   You can use this script for free and commercial projects as long as you give
#   credits.
#===============================================================================
# Description:
#   With this Script you can define weapons or armors which will force a class change on
#   equip. You need to take care, that the new class can carry the equip type
#   or you will equip yourself with the item change the class and the item
#   will be unequipped again, because the class cant handle the type.
#  
#   Weapon Notetag:
#   <classchange: class_id>
#
#   Armor Notetag:
#   <classchange: class_id>
#
#===============================================================================
module EVG
  module EquipClassChange
    #---------------------------------------------------------------------------
    # Keep EXP on Class Change?
    #---------------------------------------------------------------------------
    KEEP_EXP = true
 
    #---------------------------------------------------------------------------
    # Should the actor recover when he changes to a new class?
    #---------------------------------------------------------------------------
    HEAL_ON_CLASS_CHANGE = false
    #---------------------------------------------------------------------------
    # Define the slot which will have class change items 
    # 0 = Righthand
    # 1 = Lefthand / Shield
    # 2 = Head
    # 3 = Body
    # 4 = Accessory
    #---------------------------------------------------------------------------
    CLASS_CHANGE_SLOT = 3

    #---------------------------------------------------------------------------	
    # Change to this class if actor unequips a class item
    #---------------------------------------------------------------------------
    DEFAULT_CLASS_ID = 1

    #---------------------------------------------------------------------------
  end
end
#===============================================================================
class << DataManager
  #---------------------------------------------------------------------------
  alias :evg_dm_ld_wc     :load_database
  #---------------------------------------------------------------------------
  def load_database
    evg_dm_ld_wc
    $data_weapons.compact.each(&:load_wc_notetags)
    $data_armors.compact.each(&:load_wc_notetags)
  end
  #---------------------------------------------------------------------------
end
#===============================================================================
class RPG::EquipItem
  #---------------------------------------------------------------------------
  def load_wc_notetags
    @class_change_item = false
    @class_change_id     = 0
    info = /<classchange:\s*(?<id>\d+)\s*>/i.match(@note)
    return unless info
    @class_change_item = true
    @class_change_id = info[:id].to_i
  end
  #---------------------------------------------------------------------------
  def class_change_item?
    return @class_change_item
  end
  #---------------------------------------------------------------------------
  def class_change_id
    return @class_change_id
  end
  #---------------------------------------------------------------------------
end
#===============================================================================
class Game_Actor
  #---------------------------------------------------------------------------
  alias :evg_ga_ce_wc               :change_equip
  #---------------------------------------------------------------------------
  def change_equip(slot_id, item)
    evg_ga_ce_wc(slot_id, item)
    process_class_change(item, slot_id)
  end
  #---------------------------------------------------------------------------
  alias :evg_ga_fce_wc              :force_change_equip
  #---------------------------------------------------------------------------
  def force_change_equip(slot_id, item)
    evg_ga_fce_wc(slot_id, item)
    process_class_change(item, slot_id)
  end
  #---------------------------------------------------------------------------
  def process_class_change(item, slot_id)
    return if slot_id != EVG::EquipClassChange::CLASS_CHANGE_SLOT
    if class_change_item?(item)
      return if item.class_change_id == self.class_id
      self.change_class(item.class_change_id, EVG::EquipClassChange::KEEP_EXP)
    else
      self.change_class(EVG::EquipClassChange::DEFAULT_CLASS_ID, EVG::EquipClassChange::KEEP_EXP)
    end
    recover_all if EVG::EquipClassChange::HEAL_ON_CLASS_CHANGE
  end
  #---------------------------------------------------------------------------
  def class_change_item?(item)
    return false if item.nil?
    return item.class_change_item?
  end
  #---------------------------------------------------------------------------
end
#===============================================================================