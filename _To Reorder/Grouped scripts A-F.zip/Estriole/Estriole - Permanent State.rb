$imported = {} if $imported.nil?
$imported["EST-PERMANENT STATE"] = true
=begin
==============================================================================
** EST - PERMANENT STATE v1.0
(ENEMY POSITION ADD ON)(BUT CAN BE USED WITHOUT IT)
------------------------------------------------------------------------------
Author : ESTRIOLE
level : Easy
------------------------------------------------------------------------------
This script is to make certain states to permanent to actor / enemy
when the actor / enemy dies the states disappear but will added again
when the actor / enemy revive
==============================================================================
licences:
Free to use in all project (except the one containing pornography)
as long as i credited (ESTRIOLE).
 
modification for your own usage is permitted just don't claim this is yours
just add below the author: Modded by : ....
 
v 1.0 - 2012.09.08 > - finish the script
 
Feature
- can make the state permanent (remove when die but back when alive)
- the permanent state can be removed or added ingame (see instruction)
 
Instructions:
To instal the script, open you script editor and paste this script on
a new section on bellow the Materials section.
go to configuration part and add the state you want permanent.
the permanent state also could be modified ingame.
example : you want entering a poison swamp area. you will poisoned with:
state [swamp poison]. you add the state to all party member. but the problem
is the state will disappear when actor dies. to solve that you need to make
the [swamp poison] permanent state
just use script call:
 
add_permanent_state_list(state_id)
 
if you want to add lots of states to permanent states list
just use script call:
 
add_batch_permanent_state_list([state_id1,state_id2,state_id3])
 
note: basicly inside the () is any array
 
now you have new problem. what if the actor exiting the poison swamp area?
you wouldn't want the states still permanent don't you? (especially when there
is enemy that can give you that state).
upon exiting the poison swamp just use this script call:
remove_permanent_state_list(state_id)
 
or if you want ro remove a lot of them in one time use this:
remove_batch_permanent_state_list([state_id1,state_id2,state_id3])
 
note: basicly inside the () is any array
 
just use your imagination. especially when combined with my enemy position script
ex: gravity field area that make the flying cannot fly again after death since
it need to use the flap wings hard skill to fly again.
 
=end
 
#####CONFIGURATION PART ########################################################
module ESTRIOLE
 
if $imported["EST-ENEMY POSITION"] == true
#make all position permanent state for the sake of realism
START_PERMANENT_STATE_ID = ALLMOD_STATE +
[] #<ADD MORE START PERMANENT HERE
else
START_PERMANENT_STATE_ID = [49,50,51,52,53,54,55,56] #<if use independent
#without est enemy position script
end
 
#put all the states you want it to permanent
#the states will not removed upon death. it still can be removed like usual
#using skill/item/event
end
#####CONFIGURATION PART ########################################################
##############do not touch below this line #####################################
class Game_Party < Game_Unit
attr_accessor :permanent_state_id
alias game_party_initialize_est_permanent initialize
def initialize
game_party_initialize_est_permanent
@permanent_state_id = ESTRIOLE::START_PERMANENT_STATE_ID
end
end
 
class Game_Interpreter
def add_permanent_state_list(id)
$game_party.permanent_state_id.push(id)
$game_party.permanent_state_id.uniq
end
def add_batch_permanent_state_list(id)
for i in 0..id.size
$game_party.permanent_state_id.push(id)
end
$game_party.permanent_state_id.uniq
end
def remove_permanent_state_list(id)
$game_party.permanent_state_id - [id]
$game_party.permanent_state_id.uniq
end
def remove_batch_permanent_state_list(id)
$game_party.permanent_state_id - id
$game_party.permanent_state_id.uniq
end
end
 
 
class Game_Battler < Game_BattlerBase
attr_accessor :permanent_state
 
alias init_game_bb_est initialize
def initialize
init_game_bb_est
@permanent_state = []
end
 
alias add_new_state_est add_new_state
def add_new_state(state_id)
add_new_state_est(state_id)
return if $game_party.permanent_state_id == nil
temp = $game_party.permanent_state_id
if temp != nil
for i in 0..temp.size
@permanent_state.push(temp) if state_id == temp &&
!@permanent_state.include?(state_id)
end
end
end
 
alias revive_est revive
def revive
revive_est
return if @permanent_state == nil
return if @permanent_state == []
temp = @permanent_state
for i in 0..temp.size-1#@permanent_state.size
add_permanent_state(temp) if temp != nil
end
@permanent_state = temp
end
 
def add_permanent_state(state_id)
if state_addable?(state_id)
add_new_state_est(state_id) unless state?(state_id)
reset_state_counts(state_id)
@result.added_states.push(state_id).uniq!
end
end
 
alias remove_state_est remove_state
def remove_state(state_id)
remove_state_est(state_id)
return if @permanent_state == nil
return if @permanent_state == []
@permanent_state - [state_id]
end
 
alias state_addable_est? state_addable?
def state_addable?(state_id)
return true if @permanent_state.include?(state_id) && @permanent_state != nil
state_addable_est?(state_id)
end
 
end