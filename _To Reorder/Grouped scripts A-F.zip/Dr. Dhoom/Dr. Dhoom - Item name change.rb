#===============================================================================
# Item Name Change
# By: DrDhoom
#-------------------------------------------------------------------------------
# Want to change item names? This is your solution
#===============================================================================
# Usage would be in script call, write
# $game_party.weapon_names[WEAPONID] = $game_actors[ACTORID].name
# $game_party.load_item_names
# 
# Do this after calling a rename character command for an actor that you have 
# in the database which will only be used for name changes.
# A good method would be to set the name to nothing before name input
# Change $game_party.weapon_names to $game_party.item_names or 
# $game_party.armor_names depending on what you need
# e.g.
# $game_party.weapon_names[5] = $game_actors[11].name
#===============================================================================

module DataManager
  class << self
  alias :dhoom_itemname_dataman_load_game_without_rescue :load_game_without_rescue
  end

  def self.load_game_without_rescue(index)
    result = dhoom_itemname_dataman_load_game_without_rescue(index)
    $game_party.load_item_names if result 
	return result
  end
end

class Game_Party
  attr_accessor :item_names, :weapon_names, :armor_names
  alias :dhoom_itemname_gmparty_initialize :initialize
  def initialize
    dhoom_itemname_gmparty_initialize
    load_item_names
  end

  def load_item_names
    @item_names ||= {}
    @weapon_names ||= {}
    @armor_names ||= {}
    @item_names.each do |i, name|
    $data_items[i].name = name
    end
    @weapon_names.each do |i, name|
    $data_weapons[i].name = name
    end
    @armor_names.each do |i, name|
    $data_armors[i].name = name
    end
  end
end