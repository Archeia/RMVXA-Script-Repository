#==============================================================================
# ** Earthbound-Ish Sprite Display
#------------------------------------------------------------------------------
# Version: 1.0
# Author: cozziekuns 
# Date: February 17, 2013
#==============================================================================
# Description:
#------------------------------------------------------------------------------
# This script attempts to emulate the battle system of the Earthbound/Mother 
# series; most notably Earthbound and Earthbound 2 (Mother 2 and 3). This 
# certain addon addresses the character sprite movements found in Mother 3, 
# where active actors bobbed up and down the screen.
#==============================================================================
# Instructions:
#------------------------------------------------------------------------------
# Paste this script into its own slot in the Script Editor, above Main but 
# below Materials. 
#==============================================================================

#==============================================================================
# ** BattleManager
#==============================================================================

class << BattleManager
  
  alias coz_ebishspd_btlmngr_init_members init_members
  def init_members(*args)
    coz_ebishspd_btlmngr_init_members(*args)
    @dummy_battler = nil
  end
  
  def dummy_battler
    @dummy_battler
  end
  
  def next_subject
    loop do
      battler = @action_battlers.shift
      unless battler
        @dummy_battler = nil
        return nil
      end
      next unless battler.index && battler.alive?
      @dummy_battler = battler
      return battler
    end
  end
  
end

#==============================================================================
# ** Game_Actor
#==============================================================================

class Game_Actor
  
  def use_sprite?
    true
  end
  
end

#==============================================================================
# ** Sprite_BattlerCharacter
#==============================================================================

class Sprite_BattlerCharacter < Sprite_Battler
  
  def initialize(viewport, battler = nil)
    super(viewport, battler)
    @y_offset = 0
  end
  
  def make_animation_sprites
    @ani_sprites = []
    @ani_duplicated = @@ani_checker.include?(@animation)
    if !@ani_duplicated && @animation.position == 3
      @@ani_checker.push(@animation)
    end
  end
  
  def update
    super
    update_position
    update_zoom
    update_y_offset
  end
  
  def update_bitmap
    new_bitmap = set_character_bitmap
    if bitmap != new_bitmap
      self.bitmap = new_bitmap
      init_visibility
    end
    update_src_rect
  end
  
  def set_character_bitmap
    bitmap = Cache.character(@battler.character_name)
    sign = @battler.character_name[/^[\!\$]./]
    if sign && sign.include?('$')
      @cw = bitmap.width / 3
      @ch = bitmap.height / 4
    else
      @cw = bitmap.width / 12
      @ch = bitmap.height / 8
    end
    self.ox = @cw / 2
    self.oy = @ch
    bitmap
  end
  
  def update_origin
    if bitmap
      self.ox = @cw / 2
      self.oy = 0
    end
  end
  
  def update_src_rect
    index = @battler.character_index
    sx = (index % 4 * 3 + 1) * @cw
    sy = (index / 4 * 4) * @ch 
    self.src_rect.set(sx, sy, @cw, @y_offset)
  end
  
  def update_position
    width = Graphics.width / ( 4 / $game_party.members.size.to_f )
    sx = (Graphics.width - width) / 2 + 128
    self.x = @battler.index * 128 + sx / 2 + 12 + 32 * (4 - $game_party.members.size)
    self.y = 296 - @y_offset * 2 
  end
  
  def update_zoom
    self.zoom_x = 2.0
    self.zoom_y = 2.0
  end
  
  def update_y_offset
    if BattleManager.actor == @battler or BattleManager.dummy_battler == @battler
      @y_offset = [@y_offset + 4, 32].min
    else
      @y_offset = [@y_offset - 4, 0].max
    end
  end
  
end

#==============================================================================
# ** Spriteset_Battle
#==============================================================================

class Spriteset_Battle
  
  def create_actors
    @actor_sprites = $game_party.members.collect { |actor|
      Sprite_BattlerCharacter.new(@viewport3, actor) 
    }
  end
  
end