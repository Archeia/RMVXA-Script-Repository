#===============================================================================
# [VXA] Random Shop Generator
#-------------------------------------------------------------------------------
# Version: 1.0
# Author: cozziekuns (rmrk)
# Last Date Updated: 1/22/2012 (MM/DD/YYYY)
#===============================================================================
# Description:
#-------------------------------------------------------------------------------
# Made for Roguelike-type games, this script enables you to easily create a 
# random shop.
#===============================================================================
# Updates
# ------------------------------------------------------------------------------
# o 1/22/2012 - Started Script 
#===============================================================================
# Instructions
#-------------------------------------------------------------------------------
# To create a random shop, insert a comment where the random shop is needed 
# containing:
# 
# \random_shop[[item_type, item_id, special_price?, price],...]
# 
# item_type: 
#   0 => Item,
#   1 => Weapon,
#   2 => Armour
#
# item_id: This can be found in the Database, at the left of the name value. For
#          example, the item_id of Potion is 001.
# 
# special_price?: 
#   0 => No special price,
#   1 => Special price (price override)
# 
# price: Price overriding the regular price of the item.
#
# CACHE_SHOP: If false, the events' shop will randomize each time the map is 
#             loaded. If true, throughout the game, the events' shop will be 
#             the same in the same save file.
#===============================================================================
# Example
#-------------------------------------------------------------------------------
# @>Display Text: -, -, Normal, Down
# :             : Hello. How may I help you?
# @>Comment: \random_shop[[0, 1, 0, 0], [0, 2, 1, 100]]
# @>Display Text: -, -, Normal, Down
# :             : Thank you for your patronage?
#
# Would result in an event that would first say "Hello. How may I help you?", 
# create a shop that could contain either a regular-priced Potion or a 
# High Potion priced at 100 gold, or the shop could contain both. The shop will
# never contain no items, and the minimum amount of items is half of the size of
# the shop items (e.g. if you set the random shop to have a pick of 6 items, it 
# could have anywhere from 3 to 6 items).
#===============================================================================

#==============================================================================
# ** Cozziekuns
#==============================================================================

module COZZIEKUNS
  
  module RANDOM_SHOP
    
    CACHE_SHOP = false 
    
  end
  
end

include COZZIEKUNS

#==============================================================================
# ** Game_System
#==============================================================================

class Game_System
  
  attr_accessor :events_cache
  
  alias coz_rds_vxa_gs_initialize initialize
  def initialize(*args)
    coz_rds_vxa_gs_initialize(*args)
    @events_cache = {}
  end
  
end


#==============================================================================
# ** Game_Event
#==============================================================================

class Game_Event
  
  alias coz_rds_vxa_ge_setup_page_settings setup_page_settings
  def setup_page_settings(*args)
    coz_rds_vxa_ge_setup_page_settings(*args)
    check_for_random_shop
  end
  
  def check_for_random_shop
    @page.list.each { |i|
      next unless [108, 408].include?(i.code)
      comment = i.parameters.to_s 
      index = @page.list.index(i)
      if comment[/\\random_shop\[[(\[\d+,\s+\d+,\s+\d+,\s+\d+\])]+\]/i]
        base_comment = comment[/\\random_shop\[[(\[\d+,\s+\d+,\s+\d+,\s+\d+\])]+\]/i]
        string = base_comment[/(\[\d+,\s+\d+\,\s+\d+,\s+\d+],?\s?)+/i]
        base_array = string.split(/,\s+/i)
        string_array = []
        for i in 0...base_array.size / 4
          val = base_array[i * 4][/\d+/]
          string_array.push([val.to_i, base_array[i * 4 + 1].to_i, base_array[i * 4 + 2].to_i, base_array[i * 4 + 3].to_i])
        end
        create_random_shop(string_array, index)
      end
    }
  end
  
  def create_random_shop(array, index)
    key = [@map_id, @event.id]
    if not $game_system.events_cache[key] or not RANDOM_SHOP::CACHE_SHOP
      commands = []
      shop_items = []
      item_shopnum = rand(array.size) + 1
      while item_shopnum > 0
        item_shopnum -= 1
        new_item = array[rand(array.size)]
        shop_items.push(new_item)
        array.delete(new_item)
      end
      for i in 0...shop_items.size
        item = shop_items[i]
        if i == 0
          commands.push(RPG::EventCommand.new(302, 1, item + [false]))
        else
          commands.push(RPG::EventCommand.new(605, 1, item))
        end
      end
      commands.reverse!
      $game_system.events_cache[key] = commands
    end
    @page.list.delete_at(index)
    $game_system.events_cache[key].each { |i| @page.list.insert(index, i) }
    @list = @page.list
  end  

end