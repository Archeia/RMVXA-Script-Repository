# Batle log on bottom of screen

class Window_BattleLog < Window_Selectable
  def initialize
    y = Graphics.height - fitting_height(4.5 + max_line_number)
    super(0, y, window_width, window_height)
    self.z = 200
    self.opacity = 0
    @lines = []
    @num_wait = 0
    create_back_bitmap
    create_back_sprite
    refresh
  end
 
  def max_line_number
    return 3    # change this as necessary
  end
 
  def message_speed
    return 30
  end
 
  def add_text(text)
    if @lines.size >= max_line_number
      replace_text(text)
    else
      @lines.push(text)
      refresh
    end
  end
  
  # centered text
  def draw_line(line_number)
    rect = item_rect_for_text(line_number)
    contents.clear_rect(rect)
    draw_text(rect, @lines[line_number], 1)
  end
end