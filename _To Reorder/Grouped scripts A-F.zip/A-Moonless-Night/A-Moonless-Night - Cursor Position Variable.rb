=begin
#==============================================================================#
#   Cursor Position Variable
#   Version 1.01
#   Original Script: Jupiter Penguin (Option Extension ver.3.4)
#   URL: http://woodpenguin.blog.fc2.com/
#------------------------------------------------------------------------------#
#   Edited by: AMoonlessNight
#   Date: 20 Jul 2018
#   Latest: 20 Jul 2018
#==============================================================================#
#   UPDATE LOG
#------------------------------------------------------------------------------#
# 20 Jul 2018 - created the script based on Jupiter Penguin's Option Extension
#               script
#==============================================================================#
#   TERMS OF USE
#------------------------------------------------------------------------------#
# - As according to the original script by Jupiter Penguin:
#   http://woodpenguin.blog.fc2.com/blog-category-4.html
#==============================================================================#
    INSTRUCTIONS

 ** Use the following notetag in your event's comment box:
 
  　　<cursor_storage: n>
    
  Where n is the variable ID. The cursor will initially set to the value of
  the specified variable.

 ** For details on the original script, please see the following website:
    http://woodpenguin.web.fc2.com/rgss3/choice_ex.html
 
=end

#==============================================================================
#  Please do not edit below this point unless you know what you are doing.
#==============================================================================

class Game_Message
  attr_accessor :choice_var_id
  alias amn_choices_gamemessage_clear clear
  def clear
    amn_choices_gamemessage_clear
    @choice_var_id = 0
  end
end

class Game_Interpreter
 
  alias amn_choices_gameinterpreter_command_108 command_108
  def command_108
    amn_choices_gameinterpreter_command_108
    @comments.each do |comment|
      case comment
      when /<cursor_storage:\s*(\d+)>/i
        $game_message.choice_var_id = $1.to_i
      end
    end
  end

end

class Window_ChoiceList

  alias amn_choices_windowchoicelist_start  start
  def start
    amn_choices_windowchoicelist_start
    if $game_message.choice_var_id > 0
      select($game_variables[$game_message.choice_var_id])
    end
  end
 
end 
