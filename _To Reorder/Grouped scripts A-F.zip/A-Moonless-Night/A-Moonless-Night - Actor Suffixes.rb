=begin
#============================================================================
#   AMN Actor Suffixes
#   Version 1.0
#   Author: AMoonlessNight
#   Date: 12 May 2018
#   Latest: 12 May 2018
#===========================================================================#
#   UPDATE LOG
#---------------------------------------------------------------------------#
# 12 May 2018 - created the script
#===========================================================================#

This script makes it so that actors can have suffixes to their names. You can
also set it so that they are generated randomly. Certain levels may have
specific suffixes.

Set up the suffixes in the editable region below.


To generate a random suffix for someone, use the script call:
create_actor_suffix(actor_id)

To remove an actor's suffix, use the script call:
remove_actor_suffix(actor_id)

To give an actor your own suffix, use the script call:
set_actor_suffix(actor_id, suffix)

suffix can be anything, as long as it's a string (i.e. enclosed in "",
e.g. "sun" or " the champ")

Replace actor_id with the number of the actor, e.g. 1 for Eric.


Turn automatically generated suffixes on and off using:
$game_system.auto_actorsuffix = true/false

=end

module AMN_Random_Actor_Suffixes
  Suffixes = [
#==============================================================================
# ** EDITABLE REGION BELOW
#------------------------------------------------------------------------------
#  Change the values in the area below to suit your needs.
#==============================================================================

# Set the suffixes below. Make sure each one is a string (i.e. enclosed in "")
# followed by a ,
# Suffixes can be anything, so long as they're enclosed in speech marks
# e.g. " the swift", "paw", "100",

  "claw", "foot", "step", "fang", "sight", "eye", "blossom", "breeze", "light",
  "spot", "leap", "dream", "sun", "stride", "flash", "cloud", "ear", "sky",
  "scar", "runner", "fleck", "fluff", "dust", "mist", "whisker", "pelt",
 
 
  ] # <-- DO NOT REMOVE ]
 
 
# If you would like actors to have suffixes generated automatically, set this to
# true

  Auto_Suffixes = true
 
# You can change this at any time using
# $game_system.auto_actorsuffix = true/false


 
# BELOW ARE OPTIONS UNIQUE TO WARRIOR CATS

# If you would like actors to be named according to Warrior Cats naming
# conventions, set this to true

  Warrior_Cats_Naming = true

  Warrior_Cats_Names = {
  :kitten       => {:suffix   =>  "kit",  # kitten suffix
                    :maxlvl   =>  5,      # max level for the :kitten suffix
                    :include  =>  false,  # include in random generator
                    :minlvl   =>  0,      # min level for the :kitten suffix
                    },
  :apprentice   => {:suffix   =>  "paw",  # apprentice suffix
                    :maxlvl   =>  10,     # max level for the :apprentice suffix
                    :include  =>  false,  # include in random generator
                    :minlvl   =>  6,      # min level for the :kitten suffix
                    },
  :clanleader   => {:suffix   =>  "star", # clan leader suffix
                    :maxlvl   =>  99,     # max level for the :clanleader suffix
                    :include  =>  false,  # include in random generator
                    :minlvl   =>  50,     # min level for the :clanleader suffix
                    },
 
#==============================================================================
# ** END OF EDITABLE REGION
#------------------------------------------------------------------------------
#  Please do not edit below this point unless you know what you are doing.
#==============================================================================

} # <= DO NOT REMOVE

end

AMN_Random_Actor_Suffixes::Warrior_Cats_Names.each_key do |name|
  if AMN_Random_Actor_Suffixes::Warrior_Cats_Names[name][:include]
    AMN_Random_Actor_Suffixes::Suffixes.push(AMN_Random_Actor_Suffixes::Warrior_Cats_Names[name][:suffix])
  end
end

#==============================================================================
# ** Game_System
#------------------------------------------------------------------------------
#  This class handles system data. It saves the disable state of saving and
# menus. Instances of this class are referenced by $game_system.
#==============================================================================

class Game_System
  #--------------------------------------------------------------------------
  # * Public Instance Variables
  #--------------------------------------------------------------------------
  attr_accessor :auto_actorsuffix            # actor suffixes
  #--------------------------------------------------------------------------
  # * Object Initialization
  #--------------------------------------------------------------------------
  alias amn_randactorsuffix_gamesystem_init   initialize
  def initialize
    amn_randactorsuffix_gamesystem_init
    @auto_actorsuffix = AMN_Random_Actor_Suffixes::Auto_Suffixes
  end
end

#==============================================================================
# ** Game_Actor
#------------------------------------------------------------------------------
#  This class handles actors. It is used within the Game_Actors class
# ($game_actors) and is also referenced from the Game_Party class ($game_party).
#==============================================================================

class Game_Actor < Game_Battler
  #--------------------------------------------------------------------------
  # * Public Instance Variables
  #--------------------------------------------------------------------------
  attr_accessor   :suffix
  attr_writer     :suffix_given

  alias amn_randactorsuffix_gameactor_init  initialize
  def initialize(actor_id)
    amn_randactorsuffix_gameactor_init(actor_id)
    @suffix_given = false
    if $game_system.auto_actorsuffix
      create_random_suffix
    else
      remove_suffix
    end
    check_actor_details if AMN_Random_Actor_Suffixes::Warrior_Cats_Naming
  end
 
  def name
    @name + @suffix
  end
 
  def create_random_suffix
    @suffix = AMN_Random_Actor_Suffixes::Suffixes.sample
  end
 
  def remove_suffix
    @suffix = ""
    @suffix_given = false
  end
 
  def check_actor_details
    suffix_array = []
    wcnames = AMN_Random_Actor_Suffixes::Warrior_Cats_Names
    wcnames.each_key do |a|
      if @level >= wcnames[a][:minlvl] && @level <= wcnames[a][:maxlvl]
        suffix_array.push(wcnames[a][:suffix])
      end
    end
    if suffix_array.empty?
      create_random_suffix unless @suffix_given
      @suffix_given = true
    else
      @suffix = suffix_array[0]
    end
  end
    
  alias amn_randactorsuffix_gameactor_levelup   level_up
  def level_up
    amn_randactorsuffix_gameactor_levelup
    if AMN_Random_Actor_Suffixes::Warrior_Cats_Naming
      check_actor_details
    end
  end
 
end

#==============================================================================
# ** Game_Interpreter
#------------------------------------------------------------------------------
#  An interpreter for executing event commands. This class is used within the
# Game_Map, Game_Troop, and Game_Event classes.
#==============================================================================

class Game_Interpreter
 
  def create_actor_suffix(actor_id)
    $game_actors[actor_id].create_random_suffix
  end
 
  def remove_actor_suffix(actor_id)
    $game_actors[actor_id].remove_suffix
  end
 
  def set_actor_suffix(actor_id, new_suffix)
    $game_actors[actor_id].suffix = new_suffix
    $game_actors[actor_id].suffix_given = true
  end
 
end
 
#==============================================================================
# ** Scene_Name
#------------------------------------------------------------------------------
#  This class performs name input screen processing.
#==============================================================================

class Scene_Name < Scene_MenuBase

  #--------------------------------------------------------------------------
  # * Start Processing
  #--------------------------------------------------------------------------
  alias amn_randactorsuffix_scenename_start start
  def start
    @actor = $game_actors[@actor_id]
    @orig_suffix = @actor.suffix
    @actor.suffix = ""
    amn_randactorsuffix_scenename_start
  end
 
  #--------------------------------------------------------------------------
  # * Input [OK]
  #--------------------------------------------------------------------------
  alias amn_randactorsuffix_scenename_oninputok on_input_ok
  def on_input_ok
    @actor.suffix = @orig_suffix
    amn_randactorsuffix_scenename_oninputok
  end
 
end