=begin
#==============================================================================#
#   AMN YEA Class System addon
#   Version 1.02
#   Author: AMoonlessNight
#   Date: 20 Jul 2018
#   Latest: 21 Jul 2018
#==============================================================================#
#   UPDATE LOG
#------------------------------------------------------------------------------#
# 20 Jul 2018 - created the script
# 21 Jul 2018 - changed symbol used for Galv's Menu Themes Engine
#==============================================================================#
#   TERMS OF USE
#------------------------------------------------------------------------------#
# - Please credit AMoonlessNight or A-Moonless-Night
# - Free for non-commercial use
# - Please follow Yanfly's terms and conditions for the original script
# - I'd love to see your game if you end up using one of my scripts
#==============================================================================#

Requested by FAGC54

This script makes it so that you can set certain armours to not let the actor
access the Class Change scene.

Use the following in a weapon or armour's notes:

<no_class_change>

This will make it so that if an actor has that item equipped, they will not be
able to access the Class Change scene in the menu.
 
If you are using Galv's Menu Themes Engine, use the symbol :class_scene, e.g.:
# ["Menu Text", :command_type, :Scene, switch1, switch2, help txt, icon]
  ["Class",     :sel, :class_scene,  0, 0, "Change your character's class",121],
 
If you have other scripts that overwrite the following methods, place them before
this script.

class Scene_Menu < Scene_MenuBase
def custom_symbol(symbol)
def custom_on_command_ok(symbol)
def custom_on_personal_ok(symbol)
def custom_on_personal_cancel(symbol)
 
=end

#==============================================================================
#  Please do not edit below this point unless you know what you are doing.
#==============================================================================

if !$imported["YEA-ClassSystem"]
  msg = "                                      IMPORTANT:\n"
  msg += "            YEA Class System script add-on by A-Moonless-Night\n"
  msg += " \n"
  msg += "This script requires Yanfly's Class System script.\n"
  msg += "Please download it from https://yanflychannel.wordpress.com/rmvxa/"
  msgbox(msg)
  exit
end

class RPG::EquipItem < RPG::BaseItem
  attr_reader :class_change
 
  def amn_loadnotetag_no_class_change
    @class_change = true
    self.note.split(/[\r\n]+/).each { |line|
    case line
    when /<no[-_ ]+class[-_ ]+change>/i
      @class_change = false
    end
    }
  end
 
  def class_change?
    return @class_change
  end

end

class << DataManager

  alias amn_classsystem_datamanager_loaddatabase load_database
  def load_database
    amn_classsystem_datamanager_loaddatabase
    load_notetags_classchange_addon
  end

  def load_notetags_classchange_addon
    groups = [$data_weapons, $data_armors]
    for group in groups
      for obj in group
        next if obj.nil?
        obj.amn_loadnotetag_no_class_change
      end
    end
  end
 
end

class Game_Actor < Game_Battler
 
  def has_no_class_change_equips?
    equips.each { |eq| next if eq.nil?; return false if !eq.class_change? }
    return true
  end
 
end

class Game_Party < Game_Unit
 
  def menu_members
    members.select {|member| member.has_no_class_change_equips? }
  end
 
  def menu_member_actor
    $game_actors[@menu_actor_id] || menu_members[0]
  end

  def menu_member_actor_next
    index = menu_members.index(menu_member_actor) || -1
    index = (index + 1) % menu_members.size
    self.menu_actor = menu_members[index]
  end

  def menu_member_actor_prev
    index = menu_members.index(menu_member_actor) || 1
    index = (index + menu_members.size - 1) % menu_members.size
    self.menu_actor = menu_members[index]
  end
end

class Window_ClassCommand < Window_Command

    def make_command_list
    return if @actor.nil?
    return if !$game_party.menu_actor.has_no_class_change_equips?
    for command in YEA::CLASS_SYSTEM::COMMANDS
      case command[0]
      when :primary
        next unless Switch.primary_show
        add_command(command[1], command[0], Switch.primary_enable)
      when :subclass
        next unless Switch.subclass_show
        add_command(command[1], command[0], Switch.subclass_enable)
      when :learn_skill
        next unless $imported["YEA-LearnSkillEngine"]
        add_learn_skill_command
      else
        process_custom_command(command)
      end
    end
    if !$game_temp.scene_class_index.nil?
      select($game_temp.scene_class_index)
      self.oy = $game_temp.scene_class_oy
    end
    $game_temp.scene_class_index = nil
    $game_temp.scene_class_oy = nil
  end
end

