# CDR Guide Manager add on for saving guides when saving game

module DataManager
  class << self
    alias :amn_guides_datamanager_makesavecontents :make_save_contents
    alias :amn_guides_datamanager_extractsavecontents :extract_save_contents
  end
 
  def self.make_save_contents
    contents = amn_guides_datamanager_makesavecontents
    contents[:guides] = {}
    contents[:guides][:memory] = GuideManager.get_memory
    contents[:guides][:read] = GuideManager.get_read
    contents
  end

  def self.extract_save_contents(contents)
    amn_guides_datamanager_extractsavecontents(contents)
    GuideManager.set_memory(contents[:guides][:memory])
    GuideManager.set_read(contents[:guides][:read])
  end

end

module GuideManager
  def self.get_read
    @read
  end
 
  def self.get_memory
    @memory
  end 
 
  def self.set_read(data)
    @read = data
  end
 
  def self.set_memory(data)
    @memory = data
  end
end