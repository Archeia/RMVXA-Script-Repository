=begin
#=====================================================================
#   AMN Event Passability Checks - Free Movement patch
#   Version 1.0
#   Author: AMoonlessNight
#   Date: 18 Mar 2018
#   Latest: 18 Mar 2018
#=====================================================================#
#   UPDATE LOG
#---------------------------------------------------------------------#
# 18 Mar 2018 - wrote add-on patch for GaryCXJk's Free Movement script
#=====================================================================#

This script aliases methods written in A-Moonless-Night's Event Passability
Checks script and makes it compatible with GaryCXJk's Free Movement script.
It will not work without them.

GaryCXJk's Free Movement script checks for passability, etc., based on
a character's collision_rect, so this patch does the same.

Requested by Robert-Character-Creator

#=====================================================================#
          SCRIPT CALLS
#=====================================================================#

You can use the following script calls in conditional branches:

    * xyclear?(x, y)  or  xyclear?(x, y, rect)
  #----------------------------------------------------------------#
  # Checks if the tile at coordinates x and y is clear based on
  # collision_rect.
  # For example:  xyclear?(1, 2)   will check coordinates 1, 2 (based
  # on the default collision rect set in GaryCXJ's script.
  # For example:  xyclear?(3, 1, $game_map.events[4].collision_rect)
  # will check coordinates 3, 1 based on event 4's collision_rect.
  #----------------------------------------------------------------#

 
  The following script calls can be used with event IDs:
 
  Bear in the mind that event can be replaced with the following:
  -1 = player
  0 = current event
  everything else corresponds to the event ID
 
 
  * a_equal_b_rect?(eventa, eventb)
  #----------------------------------------------------------------#
  # Checks to see if event A's position is equal to event B's
  # position, based on their collision rectangles.
  # For example:  a_equal_b_pos?(-1, 2)   will check if the player's
  #               position is equal to event 2's position, based on
  # their collision_rect.
  #----------------------------------------------------------------#

 
  All other script calls are used same as in the original script.
 
=end

if !$imported["AMN_EventPassChecks"]
  msg = "                                      IMPORTANT:\n"
  msg += "            Event Passability Check script add-on by A-Moonless-Night\n"
  msg += " \n"
  msg += "This script requires A-Moonless-Night's Event Passability Check script.\n"
  msgbox(msg)
  exit
end
if !$imported["CXJ-FreeMovement"]
  msg = "                                      IMPORTANT:\n"
  msg += "            Event Passability Check script add-on by A-Moonless-Night\n"
  msg += " \n"
  msg += "This script requires GaryCXJk's Free Movement script.\n"
  msg += "Please download it from http://area91.multiverseworks.com"
  msgbox(msg)
  exit
end

#==============================================================================
# ** Game_Map
#------------------------------------------------------------------------------
#  This class handles maps. It includes scrolling and passage determination
# functions. The instance of this class is referenced by $game_map.
#==============================================================================

class Game_Map

  #--------------------------------------------------------------------------
  # * Event ID XY Rect                                         # NEW METHOD #
  #--------------------------------------------------------------------------
  # Get ID of Events at Designated Coordinates (One Only).
  #--------------------------------------------------------------------------
  def event_id_xy_rect(x, y, rect)
    list = events_xy_rect(x, y, rect)
    list.empty? ? 0 : list[0].id
  end
 
  #--------------------------------------------------------------------------
  # * Default Collision Rectangle                              # NEW METHOD #
  #--------------------------------------------------------------------------
  # Gets the default collision rectangle set in the Free Movement Script.
  #--------------------------------------------------------------------------
  def default_collision_rect
    collision = CXJ::FREE_MOVEMENT::COLLISION["DEFAULT"]
    return Rect.new(collision[0], collision[1], collision[2], collision[3])
  end
 
  #--------------------------------------------------------------------------
  # * Get Blockev?                                           # ALIAS METHOD #
  #--------------------------------------------------------------------------
  # Checks the X and Y coordinates and gets the value of the blocking event.
  #--------------------------------------------------------------------------
  alias amn_eventpos_getblockev   get_blockev
  def get_blockev(x, y, rect)
    if $game_map.free_movement_enabled?
      if !collision_map_passable?((x * 32), (y * 32))
        @blockev = -2
      elsif !collision_map_enabled? && check_passage(x, y, 1) == false
        @blockev = -3
      elsif $game_player.pos_rect?(x, y, rect)
        @blockev = -1
      elsif event_id_xy_rect(x, y, rect) > 0
        ev = event_id_xy_rect(x, y, rect)
        @blockev = @events[ev].id
      else
        @blockev = 0
      end
    else
      amn_eventpos_getblockev(x, y)
    end
  end
    
  #--------------------------------------------------------------------------
  # * XY Passability Rectangle Clear?                          # NEW METHOD #
  #--------------------------------------------------------------------------
  # Checks the X and Y coordinates and sees if they are clear for collision
  # rectangle. Doesn't consider direction.
  #--------------------------------------------------------------------------
  def amn_xy_rect_pass_clear?(x, y, rect)
    get_blockev(x, y, rect = default_collision_rect)
    return false if !collision_map_passable?((x * 32), (y * 32)) || !collision_map_enabled? && check_passage(x, y, 1) == false
    return false if $game_player.pos_rect?(x, y, default_collision_rect)
    if event_id_xy_rect(x, y, default_collision_rect) > 0
      ev = event_id_xy_rect(x, y, default_collision_rect)
      return false if @events[ev].normal_priority? && !@events[ev].through
      return true
    end
    return true
  end
 
end

#==============================================================================
# ** Game_Interpreter
#------------------------------------------------------------------------------
#  An interpreter for executing event commands. This class is used within the
# Game_Map, Game_Troop, and Game_Event classes.
#==============================================================================

class Game_Interpreter

  #--------------------------------------------------------------------------
  # * XY Rect Clear?                                           # NEW METHOD #
  #--------------------------------------------------------------------------
  # Check if the coordinates x & y are clear based on event's rect. Returns
  # false if there is an event or player there. Rect is the default collision
  # rect unless specified otherwise.
  #--------------------------------------------------------------------------
  def xy_rect_clear?(x, y, rect = $game_map.default_collision_rect)
    $game_map.amn_xy_rect_pass_clear?(x, y, rect)
  end
    
  #--------------------------------------------------------------------------
  # * Left Clear?                                            # ALIAS METHOD #
  #--------------------------------------------------------------------------
  # Check if the tile to the event's left is clear. Based on event's
  # direction.
  #--------------------------------------------------------------------------
  alias amn_rect_leftclear?   leftclear?
  def leftclear?(event, dist = 0)
    if $game_map.free_movement_enabled?
      event = get_character(event)
      dist -= 1 unless dist == 0  # minus 1 from dist so it doesn't include event
      case event.direction
      when 2; left_dir = 6; evx = (event.x + dist); evy = event.y; bevx = evx + 1; bevy = evy
      when 4; left_dir = 2; evy = (event.y + dist); evx = event.x; bevy = evy + 1; bevx = evx
      when 6; left_dir = 8; evy = (event.y - dist); evx = event.x; bevy = evy - 1; bevx = evx
      when 8; left_dir = 4; evx = (event.x - dist); evy = event.y; bevx = evx - 1; bevy = evy
      end
      $game_map.get_blockev(bevx, bevy, event.collision_rect)
      return false unless xy_rect_clear?(bevx, bevy, event.collision_rect)
      event.passable?(evx, evy, left_dir)
    else
      amn_rect_leftclear?(event, dist)
    end
  end
 
  #--------------------------------------------------------------------------
  # * Right Clear?                                           # ALIAS METHOD #
  #--------------------------------------------------------------------------
  # Check if the tile to the event's right is clear. Based on event's
  # direction.
  #--------------------------------------------------------------------------
  alias amn_rect_rightclear?   rightclear?
  def rightclear?(event, dist = 0)
    if $game_map.free_movement_enabled?
      event = get_character(event)
      dist -= 1 unless dist == 0  # minus 1 from dist so it doesn't include event
      case event.direction
      when 2;  right_dir = 4; evx = (event.x - dist); evy = event.y; bevx = evx - 1; bevy = evy
      when 4;  right_dir = 8; evy = (event.y - dist); evx = event.x; bevy = evy - 1; bevx = evx
      when 6;  right_dir = 2; evy = (event.y + dist); evx = event.x; bevy = evy + 1; bevx = evx
      when 8;  right_dir = 6; evx = (event.x + dist); evy = event.y; bevx = evx + 1; bevy = evy
      end
      $game_map.get_blockev(bevx, bevy, event.collision_rect)
      return false unless xy_rect_clear?(bevx, bevy, event.collision_rect)
      event.passable?(evx, evy, right_dir)
    else
      amn_rect_rightclear?(event, dist)
    end
  end
 
  #--------------------------------------------------------------------------
  # * Back Clear?                                            # ALIAS METHOD #
  #--------------------------------------------------------------------------
  # Check if the tile behind the event is clear. Based on event's direction.
  #--------------------------------------------------------------------------
  alias amn_rect_backclear?   backclear?
  def backclear?(event, dist = 0)
    if $game_map.free_movement_enabled?
      event = get_character(event)
      revdir = event.reverse_dir(event.direction)
      dist -= 1 unless dist == 0  # minus 1 from dist so it doesn't include event
      case event.direction
      when 2;  evy = (event.y - dist); evx = event.x; bevy = evy - 1; bevx = evx
      when 4;  evx = (event.x + dist); evy = event.y; bevx = evx + 1; bevy = evy
      when 6; evx = (event.x - dist); evy = event.y; bevx = evx - 1; bevy = evy
      when 8; evy = (event.y + dist); evx = event.x; bevy = evy + 1; bevx = evx
      end
      $game_map.get_blockev(bevx, bevy, event.collision_rect)
      return false unless xy_rect_clear?(bevx, bevy, event.collision_rect)
      event.passable?(evx, evy, revdir)
    else
      amn_rect_backclear?(event, dist)
    end
  end
 
  #--------------------------------------------------------------------------
  # * Front Clear?                                           # ALIAS METHOD #
  #--------------------------------------------------------------------------
  # Check if the tile in front of the event is clear. Based on event's
  # direction.
  #--------------------------------------------------------------------------
  alias amn_rect_frontclear?   frontclear?
  def frontclear?(event, dist = 0)
    if $game_map.free_movement_enabled?
      event = get_character(event)
      dist -= 1 unless dist == 0  # minus 1 from dist so it doesn't include event
      case event.direction
      when 2;  evy = (event.y + dist); evx = event.x; bevy = evy + 1; bevx = evx
      when 4;  evx = (event.x - dist); evy = event.y; bevx = evx - 1; bevy = evy
      when 6; evx = (event.x + dist); evy = event.y; bevx = evx + 1; bevy = evy
      when 8; evy = (event.y - dist); evx = event.x; bevy = evy - 1; bevx = evx
      end
      $game_map.get_blockev(bevx, bevy, event.collision_rect)
      return false unless xy_rect_clear?(bevx, bevy, event.collision_rect)
      event.passable?(evx, evy, event.direction)
    else
      amn_rect_frontclear?(event, dist)
    end
  end
 
  #--------------------------------------------------------------------------
  # * North Clear?                                           # ALIAS METHOD #
  #--------------------------------------------------------------------------
  # Check if the tile above the event (the north) is clear.
  #--------------------------------------------------------------------------
  alias amn_rect_northclear?   northclear?
  def northclear?(event, dist = 0)
    if $game_map.free_movement_enabled?
      event = get_character(event)
      dist -= 1 unless dist == 0  # minus 1 from dist so it doesn't include event
      $game_map.get_blockev(event.x, (event.y - dist) - 1, event.collision_rect)
      return false unless xy_rect_clear?(event.x, (event.y - dist) - 1, event.collision_rect)
      event.passable?(event.x, (event.y - dist), 8)
    else
      amn_rect_northclear?(event, dist)
    end
  end
 
  #--------------------------------------------------------------------------
  # * South Clear?                                           # ALIAS METHOD #
  #--------------------------------------------------------------------------
  # Check if the tile below the event (the south) is clear.
  #--------------------------------------------------------------------------
  alias amn_rect_southclear?   southclear?
  def southclear?(event, dist = 0)
    if $game_map.free_movement_enabled?
      event = get_character(event)
      dist -= 1 unless dist == 0  # minus 1 from dist so it doesn't include event
      $game_map.get_blockev(event.x, (event.y + dist) + 1, event.collision_rect)
      return false unless xy_rect_clear?(event.x, (event.y + dist) + 1, event.collision_rect)
      event.passable?(event.x, (event.y + dist), 2)
    else
      amn_rect_southclear?(event, dist)
    end
  end
 
  #--------------------------------------------------------------------------
  # * East Clear?                                            # ALIAS METHOD #
  #--------------------------------------------------------------------------
  # Check if the tile right of the event (the east) is clear.
  #--------------------------------------------------------------------------
  alias amn_rect_eastclear?   eastclear?
  def eastclear?(event, dist = 0)
    if $game_map.free_movement_enabled?
      event = get_character(event)
      dist -= 1 unless dist == 0  # minus 1 from dist so it doesn't include event
      $game_map.get_blockev((event.x + dist) + 1, event.y, event.collision_rect)
      return false unless xy_rect_clear?((event.x + dist) + 1, event.y, event.collision_rect)
      event.passable?((event.x - dist), event.y, 6)
    else
      amn_rect_eastclear?(event, dist)
    end
  end
 
  #--------------------------------------------------------------------------
  # * West Clear?                                            # ALIAS METHOD #
  #--------------------------------------------------------------------------
  # Check if the tile left of the event (the west) is clear.
  #--------------------------------------------------------------------------
  alias amn_rect_westclear?   westclear?
  def westclear?(event, dist = 0)
    if $game_map.free_movement_enabled?
      event = get_character(event)
      dist -= 1 unless dist == 0  # minus 1 from dist so it doesn't include event
      $game_map.get_blockev((event.x - dist) - 1, event.y, event.collision_rect)
      return false unless xy_rect_clear?((event.x - dist) - 1, event.y, event.collision_rect)
      event.passable?((event.x + dist), event.y, 4)
    else
      amn_rect_westclear?(event, dist)
    end
  end

  #--------------------------------------------------------------------------
  # * A Rect Equals B Rect?                                    # NEW METHOD #
  #--------------------------------------------------------------------------
  # Check if event A's position is the same as event B using their collision
  # rectangles.
  #--------------------------------------------------------------------------
  def a_equal_b_rect?(eventa, eventb)
    eventa = get_character(eventa)
    eventb = get_character(eventb)
    eventa.pos_rect?(eventb.x, eventb.y, eventa.collision_rect)
  end
end