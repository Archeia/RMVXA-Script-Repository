=begin
#=====================================================================
#   AMN Field Objects
#   Version 1.0
#   Author: AMoonlessNight
#   Date: 18 Feb 2018
#   Latest: 18 Feb 2018
#=====================================================================#
#   UPDATE LOG
#---------------------------------------------------------------------#
# 18 Feb 2018 - created the original script
#=====================================================================#

This script has a number of convenience script calls to check if the
tile in front of the player has a field object.

Use the notetag <field_object> in an event's comments to denote it as
a Field Object.

This script also contains some convenience script calls for moving Field
Object events.

Requested by Prellmarc

#=====================================================================#
          SCRIPT CALLS
#=====================================================================#

You can use the following script calls in conditional branches:

    * player_fieldobj?(distance) or player_fieldobj?
  #----------------------------------------------------------------#
  # Checks if the event in front of the player is a Field Object.
  # For example:  player_fieldobj?(2)   will check 2 tiles away.
  # For example:  player_fieldobj?   will check the tile next to
  #               the player.
  #----------------------------------------------------------------#
 
 
  The following script calls can be used to move events:
 
 
    * movefieldobj_toplayer or movefieldobj_toplayer(distance)
  #----------------------------------------------------------------#
  # Moves the Field Object event randomly the specified amount of
  # steps.
  # For example: movefieldobj_toplayer   will move the event one
  #              step toward the player.
  # For example: movefieldobj_toplayer(2)  will move the event 2
  #              steps toward the player.
  #----------------------------------------------------------------#
 
    * movefieldobj_rand or movefieldobj_rand(distance)
  #----------------------------------------------------------------#
  # Moves the Field Object event randomly the specified amount of
  # steps.
  # For example: moveev_rand   will move the event one random step.
  # For example: moveev_rand(2)  will move the event 2 random steps.
  #----------------------------------------------------------------#
 
    * movefieldobj_left or movefieldobj_left(distance)
  #----------------------------------------------------------------#
  # Moves the event left the specified amount of times.
  # For example: movefieldobj_left   will move event left one step.
  # For example: movefieldobj_left(2)  will move the event left 2
  #               steps.
  #----------------------------------------------------------------#
 
    * movefieldobj_right or movefieldobj_right(distance)
  #----------------------------------------------------------------#
  # Moves the event right the specified amount of times.
  # For example: movefieldobj_right   will move the event right
  #              one step.
  # For example: movefieldobj_right(2)  will move the event
  #              right 2 steps.
  #----------------------------------------------------------------#
 
    * movefieldobj_down or movefieldobj_down(distance)
  #----------------------------------------------------------------#
  # Moves the event down the specified amount of times.
  # For example: movefieldobj_down   will move event down one step.
  # For example: movefieldobj_down(2)  will move the event down 2
  #               steps.
  #----------------------------------------------------------------#
 
    * movefieldobj_up or movefieldobj_up(distance)
  #----------------------------------------------------------------#
  # Moves the event up the specified amount of times.
  # For example: movefieldobj_up   will move event up one step.
  # For example: movefieldobj_up(2)  will move the event up 2 steps.
  #----------------------------------------------------------------# 

=end

#==============================================================================
#
# ** Please do not edit below this point unless you know what you are doing.
#
#==============================================================================

module AMN_fieldobject_setup
 
Field_Object_Regex = /<field_object>/i

end

#==============================================================================
# ** Game_Map
#------------------------------------------------------------------------------
#  This class handles maps. It includes scrolling and passage determination
# functions. The instance of this class is referenced by $game_map.
#==============================================================================

class Game_Map
  #--------------------------------------------------------------------------
  # * Public Instance Variables
  #--------------------------------------------------------------------------
  attr_reader   :fieldobj                    # ID of field object

  #--------------------------------------------------------------------------
  # * Object Initialization                                  # ALIAS METHOD #
  #--------------------------------------------------------------------------
  alias amn_fieldobj_gamemap_init   initialize
  def initialize
    @fieldobj = 0
    amn_fieldobj_gamemap_init
  end
 
  #--------------------------------------------------------------------------
  # * Field Object Event Comments                              # NEW METHOD #
  #--------------------------------------------------------------------------
  # Parses the event's comments and checks for Field Object regex.
  #--------------------------------------------------------------------------
  def fieldobj_event_comments(event_id)
    event = @events[event_id]
    if event.list
      event.list.each do |cmd|
        if cmd.code == 108
          if cmd.parameters[0] =~ AMN_fieldobject_setup::Field_Object_Regex
            return true
          else
            return false
          end
        else
          return false
        end
      end
    end
  end
 
  #--------------------------------------------------------------------------
  # * Check if Field Object?                                   # NEW METHOD #
  #--------------------------------------------------------------------------
  # Checks the X and Y coordinates and sees if they contain a field object.
  #--------------------------------------------------------------------------
  def check_if_field_object?(x, y)
    if event_id_xy(x, y) > 0
      ev = event_id_xy(x, y)
      if fieldobj_event_comments(ev)
        @fieldobj = ev
        return true
      else
        @fieldobj = 0
        return false
      end
    end
    return false
  end
 
end
 

#==============================================================================
# ** Game_Interpreter
#------------------------------------------------------------------------------
#  An interpreter for executing event commands. This class is used within the
# Game_Map, Game_Troop, and Game_Event classes.
#==============================================================================

class Game_Interpreter
 
  #--------------------------------------------------------------------------
  # * Player Field Object?                                     # NEW METHOD #
  #--------------------------------------------------------------------------
  # Check if the tile in front of the player has a Field Object.
  #--------------------------------------------------------------------------
  def player_fieldobj?(dist = 1)
    event = $game_player
    case event.direction
    when 2;  evy = (event.y + dist); evx = event.x
    when 4;  evx = (event.x - dist); evy = event.y
    when 6; evx = (event.x + dist); evy = event.y
    when 8; evy = (event.y - dist); evx = event.x
    end
    $game_map.check_if_field_object?(evx, evy)
  end
 
  #--------------------------------------------------------------------------
  # * Field Object                                             # NEW METHOD #
  #--------------------------------------------------------------------------
  # Returns the value of the instance variable fieldobj, or the event called
  # Field Object.
  #--------------------------------------------------------------------------
  def fieldobj
    return $game_map.fieldobj
  end
 
  #--------------------------------------------------------------------------
  # * Move Field Object Randomly                               # NEW METHOD #
  #--------------------------------------------------------------------------
  # Just a convenient way of making the event move in a random
  # direction.
  #--------------------------------------------------------------------------
  def movefieldobj_rand(dist = 1)
    mr = RPG::MoveRoute.new
    mr.repeat = false
    mr.skippable = true
    mr.wait = true
    mr.list = []
    dist.times do
      mr.list.push( RPG::MoveCommand.new(9, []) )
    end
    mr.list.push( RPG::MoveCommand.new )
    $game_map.events[fieldobj].force_move_route(mr) unless fieldobj == 0
  end
 
  #--------------------------------------------------------------------------
  # * Move Field Object Left                                   # NEW METHOD #
  #--------------------------------------------------------------------------
  # Just a convenient way of making the event move left.
  #--------------------------------------------------------------------------
  def movefieldobj_left(dist = 1)
    mr = RPG::MoveRoute.new
    mr.repeat = false
    mr.skippable = true
    mr.wait = true
    mr.list = []
    dist.times do
      mr.list.push( RPG::MoveCommand.new(2, []) )
    end
    mr.list.push( RPG::MoveCommand.new )
    $game_map.events[fieldobj].force_move_route(mr) unless fieldobj == 0
  end
 
  #--------------------------------------------------------------------------
  # * Move Field Object Right                                  # NEW METHOD #
  #--------------------------------------------------------------------------
  # Just a convenient way of making the event move left.
  #--------------------------------------------------------------------------
  def movefieldobj_right(dist = 1)
    mr = RPG::MoveRoute.new
    mr.repeat = false
    mr.skippable = true
    mr.wait = true
    mr.list = []
    dist.times do
      mr.list.push( RPG::MoveCommand.new(3, []) )
    end
    mr.list.push( RPG::MoveCommand.new )
    $game_map.events[fieldobj].force_move_route(mr) unless fieldobj == 0
  end
 
  #--------------------------------------------------------------------------
  # * Move Field Object Down                                   # NEW METHOD #
  #--------------------------------------------------------------------------
  # Just a convenient way of making the event move left.
  #--------------------------------------------------------------------------
  def movefieldobj_down(dist = 1)
    mr = RPG::MoveRoute.new
    mr.repeat = false
    mr.skippable = true
    mr.wait = true
    mr.list = []
    dist.times do
      mr.list.push( RPG::MoveCommand.new(1, []) )
    end
    mr.list.push( RPG::MoveCommand.new )
    $game_map.events[fieldobj].force_move_route(mr) unless fieldobj == 0
  end
 
  #--------------------------------------------------------------------------
  # * Move Field Object Up                                     # NEW METHOD #
  #--------------------------------------------------------------------------
  # Just a convenient way of making the event move left.
  #--------------------------------------------------------------------------
  def movefieldobj_up(dist = 1)
    mr = RPG::MoveRoute.new
    mr.repeat = false
    mr.skippable = true
    mr.wait = true
    mr.list = []
    dist.times do
      mr.list.push( RPG::MoveCommand.new(4, []) )
    end
    mr.list.push( RPG::MoveCommand.new )
    $game_map.events[fieldobj].force_move_route(mr) unless fieldobj == 0
  end
 
  #--------------------------------------------------------------------------
  # * Move Field Object Toward Player                          # NEW METHOD #
  #--------------------------------------------------------------------------
  # Just a convenient way of making the event move toward the player.
  #--------------------------------------------------------------------------
  def movefieldobj_toplayer(dist = 1)
    mr = RPG::MoveRoute.new
    mr.repeat = false
    mr.skippable = true
    mr.wait = true
    mr.list = []
    dist.times do
      mr.list.push( RPG::MoveCommand.new(10, []) )
    end
    mr.list.push( RPG::MoveCommand.new )
    $game_map.events[fieldobj].force_move_route(mr) unless fieldobj == 0
  end
 
end