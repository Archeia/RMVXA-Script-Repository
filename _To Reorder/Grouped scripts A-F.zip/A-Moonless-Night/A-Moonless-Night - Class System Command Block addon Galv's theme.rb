=begin
#==============================================================================#
#   AMN YEA Class System addon
#   Version 1.03
#   Author: AMoonlessNight
#   Date: 20 Jul 2018
#   Latest: 22 Jul 2018
#==============================================================================#
#   UPDATE LOG
#------------------------------------------------------------------------------#
# 20 Jul 2018 - created the script
# 21 Jul 2018 - changed symbol used for Galv's Menu Themes Engine
# 22 Jul 2018 - overwrote alias methods for Scene Menu from YEA Class System
#==============================================================================#
#   TERMS OF USE
#------------------------------------------------------------------------------#
# - Please credit AMoonlessNight or A-Moonless-Night
# - Free for non-commercial use
# - Please follow Yanfly's terms and conditions for the original script
# - I'd love to see your game if you end up using one of my scripts
#==============================================================================#

Requested by FAGC54

This script makes it so that you can set certain armours to not let the actor
access the Class Change scene.

Use the following in a weapon or armour's notes:

<no_class_change>

This will make it so that if an actor has that item equipped, they will not be
able to access the Class Change scene in the menu.

If you are using Galv's Menu Themes Engine, use the symbol :class_scene, e.g.:
# ["Menu Text", :command_type, :Scene, switch1, switch2, help txt, icon]
  ["Class",     :sel, :class_scene,  0, 0, "Change your character's class",121],
 
If you have other scripts that overwrite the following methods, place them before
this script.

class Scene_Menu < Scene_MenuBase
def custom_symbol(symbol)
def custom_on_command_ok(symbol)
def custom_on_personal_ok(symbol)
def custom_on_personal_cancel(symbol)

=end

#==============================================================================
#  Please do not edit below this point unless you know what you are doing.
#==============================================================================

if !$imported["YEA-ClassSystem"]
  msg = "                                      IMPORTANT:\n"
  msg += "            YEA Class System script add-on by A-Moonless-Night\n"
  msg += " \n"
  msg += "This script requires Yanfly's Class System script.\n"
  msg += "Please download it from https://yanflychannel.wordpress.com/rmvxa/"
  msgbox(msg)
  exit
end

class RPG::EquipItem < RPG::BaseItem
  attr_reader :class_change
 
  def amn_loadnotetag_no_class_change
    @class_change = true
    self.note.split(/[\r\n]+/).each { |line|
    case line
    when /<no[-_ ]+class[-_ ]+change>/i
      @class_change = false
    end
    } 
  end
 
  def class_change?
    return @class_change
  end

end

class << DataManager

  alias amn_classsystem_datamanager_loaddatabase load_database
  def load_database
    amn_classsystem_datamanager_loaddatabase
    load_notetags_classchange_addon
  end

  def load_notetags_classchange_addon
    groups = [$data_weapons, $data_armors]
    for group in groups
      for obj in group
        next if obj.nil?
        obj.amn_loadnotetag_no_class_change
      end
    end
  end
 
end

class Game_Actor < Game_Battler
 
  def has_no_class_change_equips?
    equips.each { |eq| next if eq.nil?; return false if !eq.class_change? }
    return true
  end
 
end

class Game_Party < Game_Unit
 
  def menu_members 
    members.select {|member| member.has_no_class_change_equips? } 
  end
 
  def menu_member_actor
    $game_actors[@menu_actor_id] || menu_members[0]
  end

  def menu_member_actor_next
    index = menu_members.index(menu_member_actor) || -1
    index = (index + 1) % menu_members.size
    self.menu_actor = menu_members[index]
  end

  def menu_member_actor_prev
    index = menu_members.index(menu_member_actor) || 1
    index = (index + menu_members.size - 1) % menu_members.size
    self.menu_actor = menu_members[index]
  end
end

class Scene_Menu < Scene_MenuBase

if !$imported["Galv_Menu_Themes"]
  alias amn_classsystem_scenemenu_onpersonalok on_personal_ok
  def on_personal_ok
    case @command_window.current_symbol
    when :class
      $game_party.menu_actor = $game_party.members[@status_window.index]
      if $game_party.menu_actor.has_no_class_change_equips?
        SceneManager.call(Scene_Class)
      else
        Sound.play_buzzer
        @status_window.activate
      end
    else
      scene_menu_on_personal_ok_cs
    end
  end
end

if $imported["Galv_Menu_Themes"]
 
  # Overwrite YEA create command window so the :class symbol is not made
  alias amn_yeaclass_scenemenu_createcommandwind  create_command_window
  def create_command_window
    scene_menu_create_command_window_cs
  end
 
  # Overwrite YEA on personal OK so everything functions as per original script
  alias amn_yeaclass_scenemenu_onpersonalok  on_personal_ok
  def on_personal_ok
    scene_menu_on_personal_ok_cs
  end


  alias amn_classsystem_galv_scenemenu_customsymbol custom_symbol
  def custom_symbol(symbol)
    case symbol 
    when :class_scene
      return true
    end
    amn_classsystem_galv_scenemenu_customsymbol(symbol)
  end
 
  alias amn_classsystem_galv_scenemenu_customonpersonalok custom_on_personal_ok
  def custom_on_personal_ok(symbol)
    if symbol == :class_scene
      $game_party.menu_actor = $game_party.members[@status_window.index]
      if $game_party.menu_actor.has_no_class_change_equips?
        SceneManager.call(Scene_Class)
      else
        Sound.play_buzzer
        @status_window.activate
      end
    else
      amn_classsystem_galv_scenemenu_customonpersonalok(symbol)
    end
  end
end

end

class Scene_Class < Scene_MenuBase
 
  def next_actor
    @actor = $game_party.menu_member_actor_next
    on_actor_change
  end

  def prev_actor
    @actor = $game_party.menu_member_actor_prev
    on_actor_change
  end
 
end