=begin
#===============================================================================
#   AMN Hime Map Drops / V.M. Field Abilities addon
#   Version 1.01
#   Author: AMoonlessNight
#   Date: 01 Jun 2018
#   Latest: 01 Jun 2018
#==============================================================================#
#   UPDATE LOG
#------------------------------------------------------------------------------#
# 01 Jun 2018 - created the script
# 01 Jun 2018 - added the ability to change the icon used for the item drop
#==============================================================================#
#   TERMS OF USE
#------------------------------------------------------------------------------#
# - Please credit AMoonlessNight or A-Moonless-Night
# - Free for non-commercial use
# - I'd love to see your game if you end up using one of my scripts
#==============================================================================#

This script makes it so that you can designate items as being 'grabbable' or
'throwable', to work with V.M.'s Field Abilities script.

Use the following in an item's notes:

<grab item> OR <grab_item>
To set an item as 'grabbable'. This means you can drag it around.

<throw item> OR <throw_item>
To set an item as 'throwable'. This means you can pick it up and throw it.

You can also give the item a different icon when it has been dropped:

<drop_icon: #>
where # is the icon number.

=end

#==============================================================================
#  Please do not edit below this point unless you know what you are doing.
#==============================================================================
$imported = {} if $imported.nil?
$imported[:AMN_TH_MapDrops_VM_Field_Abilities_Addon] = true

if !$imported["TH_MapDrops"]
  msg = "                                      IMPORTANT:\n"
  msg += "            HimeWorks Map Drops script add-on by A-Moonless-Night\n"
  msg += " \n"
  msg += "This script requires HimeWork's Map Drops script.\n"
  msg += "Please download it from http://himeworks.com/rmvxa-scripts/"
  msgbox(msg)
  exit
end

module TH
  module Map_Drops
   
    Throw_Item_Regex = /<throw[ _-]+item>/i
    Grab_Item_Regex = /<grab[ _-]+item>/i
    Drop_Icon_Regex = /<drop_icon:\s*(\d+)>/i

  end
end

module RPG
  class BaseItem
   
    attr_reader   :throw_item
    attr_reader   :grab_item
    attr_reader   :drop_icon
   
    def throw_item?
      return @throw_item unless @throw_item.nil?
      res = self.note.match(TH::Map_Drops::Throw_Item_Regex)
      return @throw_item = !res.nil?
    end
   
    def grab_item?
      return @grab_item unless @grab_item.nil?
      res = self.note.match(TH::Map_Drops::Grab_Item_Regex)
      return @grab_item = !res.nil?
    end
   
    def drop_icon
      self.note.split(/[\r\n]+/).each { |line|
      case line
      when TH::Map_Drops::Drop_Icon_Regex
        @drop_icon = $1
        return @drop_icon
      else
        @drop_icon = nil
      end
      }
      @drop_icon
    end
   
  end
end

class Game_MapDrop < Game_Drop

  alias amn_himemapdrop_vmfield_gamemapdrop_init  initialize
  def initialize(item, count=1, x=$game_player.x, y=$game_player.y, map_id=$game_map.map_id)
    amn_himemapdrop_vmfield_gamemapdrop_init(item, count=1, x=$game_player.x, y=$game_player.y, map_id=$game_map.map_id)
    if !item.drop_icon.nil?
      @icon_index = item.drop_icon.to_i
    end
  end
 
  alias amn_himemapdrop_vmfield_gamemapdrop_addeventcommands  add_event_commands
  def add_event_commands(list)
    if @item.throw_item?
      list << RPG::EventCommand.new(355, 0, ["pickup"])
      list << RPG::EventCommand.new
    elsif @item.grab_item?
      event.pages[0].priority_type = 1
      list << RPG::EventCommand.new(355, 0, ["grab"])
      list << RPG::EventCommand.new
    else
      amn_himemapdrop_vmfield_gamemapdrop_addeventcommands(list)
    end
  end
 
end

class Game_Character < Game_CharacterBase

  # OVERWRITE method
  def throw
    @carrying.moveto(@x,@y)
    @carrying.direction = @direction
    return unless @carrying.jump_forward_field
    @carrying.thrown
    @carrying.through = false
    if $imported["TH_MapDrops"] && self.is_a?(Game_DropEvent)
      @carrying.priority_type = 1
    else
      @carrying.priority_type = 0
    end
    @carrying.carried = nil
    @carrying = nil
  end
 
  alias amn_himemapdrop_vmfield_gamecharacter_jumpfwdfield  jump_forward_field
  def jump_forward_field
    if $imported["TH_MapDrops"] && self.is_a?(Game_DropEvent)
      return jump_straight(0,1)  if @direction == 2
      return jump_straight(-1,0) if @direction == 4
      return jump_straight(1,0)  if @direction == 6
      return jump_straight(0,-1) if @direction == 8
    else
      amn_himemapdrop_vmfield_gamecharacter_jumpfwdfield
    end
  end
 
end