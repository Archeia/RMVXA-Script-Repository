=begin
#=====================================================================
#   AMN Event Passability Checks - Advanced Version
#   Version 1.10
#   Author: AMoonlessNight
#   Date: 12 Feb 2018
#   Latest: 18 Mar 2018
#=====================================================================#
#   UPDATE LOG
#---------------------------------------------------------------------#
# 12 Feb 2018 - created the original script
# 12 Feb 2018 - fixed an error with calculating distance based on event
#               direction
# 14 Feb 2018 - created advanced version, including checks for blocking
#               events and event comments
# 16 Feb 2018 - fixed an error where blockev wasn't registering player
# 17 Feb 2018 - tidied up some superfluous code and made it so that
#               blockev registers non-'normal priority' events, added
#               some convenience methods for moving events
# 21 Feb 2018 - added compatibility with Hime Collision Maps
# 10 Mar 2018 - checked compatibility with GaryCXJk's Free Movement and
#               added another convenience method
# 14 Mar 2018 - fixed error with directions
# 15 Mar 2018 - added compatibility with GaryCXJk's Free Movement script
#=====================================================================#

This script has a number of convenience script calls for event position
checks.

The advanced version includes:
  - checks for seeing which event is blocking the way and sets to an
    instance variable
  - checks for if the event has a particular comment to designate whether
    it should be ignored (like a 'below-priority' or 'through' event) or
    used for other purposes.
    
You can use the instance variable blockev in a conditional branch to see
which event is blocking the way.
  -2  = a tile / collision map
  -1  = the player
  0   = no event
  1+  = every other number is the ID of the event
    
For example, events with the comment <small_ev> (which can be changed in
the editable region) can be accessed using a script call in a conditional
branch and told to move aside.

As another example, events with the comment <over_ev> (which can also be
changed in the editable region) can be accessed using a script call in a
conditional branch and set to 'through' while the other event moves.

This script also contains some convenience script calls for moving events.

Based on the MV plugin by SumRndmDde: http://sumrndm.site/collision-checker/

Requested by Robert-Character-Creator

#=====================================================================#
          SCRIPT CALLS
#=====================================================================#

You can use the following script calls in conditional branches:

    * xyclear?(x, y)
  #----------------------------------------------------------------#
  # Checks if the tile at coordinates x and y is clear.
  # For example:  xyclear?(1, 2)   will check coordinates 1, 2.
  #----------------------------------------------------------------#


 
  The following script calls can be used with event IDs:
 
  Bear in the mind that event can be replaced with the following:
  -1 = player
  0 = current event
  everything else corresponds to the event ID
 
 
    * leftclear?(event) or leftclear?(event, distance)
  #----------------------------------------------------------------#
  # Checks if the tile to the event's left is clear. This is based
  # on the direction the event is facing.
  # For example:  leftclear?(3)   will check for event 3.
  # For example:  leftclear?(-1, 5)   will check for the player
  # 5 tiles away to the left.
  #----------------------------------------------------------------#
 
 
    * rightclear?(event) or rightclear?(event, distance)
  #----------------------------------------------------------------#
  # Checks if the tile to the event's right is clear. This is based
  # on the direction the event is facing.
  # For example:  rightclear?(3)   will check for event 3.
  # For example:  rightclear?(-1, 5)   will check for the player
  # 5 tiles away to the right.
  #----------------------------------------------------------------#
 
 
    * backclear?(event) or backclear?(event, distance)
  #----------------------------------------------------------------#
  # Checks if the tile behind the event is clear. This is based
  # on the direction the event is facing.
  # For example:  backclear?(3)   will check for event 3.
  # For example:  backclear?(0, 5)   will check for this event
  # 5 tiles away behind.
  #----------------------------------------------------------------#
 
 
    * frontclear?(event) or frontclear?(event, distance)
  #----------------------------------------------------------------#
  # Checks if the tile in front of the event is clear. This is
  # based on the direction the event is facing.
  # For example:  frontclear?(3)   will check for event 3.
  # For example:  frontclear?(0, 5)   will check for this event
  # 5 tiles away in front.
  #----------------------------------------------------------------#
 
 
    * northclear?(event) or northclear?(event, distance)
  #----------------------------------------------------------------#
  # Checks if the tile north of (above) the event is clear.
  # For example:  northclear?(3)   will check for event 3.
  # For example:  northclear?(3, 5)   will check for event 3
  # 5 tiles away.
  #----------------------------------------------------------------#
 
 
    * southclear?(event) or southclear?(event, distance)
  #----------------------------------------------------------------#
  # Checks if the tile south of (below) the event is clear.
  # For example:  southclear?(3)   will check for event 3.
  # For example:  southclear?(3, 5)   will check for event 3
  # 5 tiles away.
  #----------------------------------------------------------------#
 
 
    * eastclear?(event) or eastclear?(event, distance)
  #----------------------------------------------------------------#
  # Checks if the tile east of (right) the event is clear.
  # For example:  eastclear?(3)   will check for event 3.
  # For example:  eastclear?(3, 5)   will check for event 3
  # 5 tiles away.
  #----------------------------------------------------------------#
 
 
    * westclear?(event) or westclear?(event, distance)
  #----------------------------------------------------------------#
  # Checks if the tile west of (left) the event is clear.
  # For example:  westclear?(3)   will check for event 3.
  # For example:  westclear?(3, 5)   will check for event 3
  # 5 tiles away.
  #----------------------------------------------------------------#

 
  * a_equal_b_pos?(eventa, eventb)
  #----------------------------------------------------------------#
  # Checks to see if event A's position is equal to event B's
  # position.
  # For example:  a_equal_b_pos?(-1, 2)   will check if the player's
  #               position is equal to event 2's position.
  #----------------------------------------------------------------#

 
  The following script calls can be used in conditional branches to
  gather information for the user:
 

  * blockev
  #----------------------------------------------------------------#
  # blockev is an instance variable that stores the ID of the event
  # that is blocking the path.
  #
  # You can use the instance variable blockev in a conditional branch
  # or script call to see which event is blocking the way.
  #     -2    = a tile / collision map
  #     -1    = the player
  #     0     = no event
  #     1+    = every other number is the ID of the event
  #
  # For example: blockev == -1   in a conditional branch will check to
  #              see if blockev is equal to -1 (the player).
  #
  # blockev is set every time you use one of these script calls.
  #----------------------------------------------------------------#
 
 
  * eventkind(event)
  #----------------------------------------------------------------#
  # Checks to see the kind of event, or 'eventkind'. Can be used in
  # a conditional branch.
  # For example: eventkind(5) == 1   will check if the eventkind of
  #              event 5 is equal to 1 (small events).
  # For example: eventkind(blockev) == 2  will check if the eventkind
  #              of the blocking event (blockev) is equal to 2 (over
  #              events).
  #
  #     1     = small events || events with the comment <small_ev>
  #                                                      (default)
  #     2     = 'over' events || events with the comment <over_ev>
  #                                                      (default)
  #
  #----------------------------------------------------------------#
 
 
  * check_priority?(event)
  #----------------------------------------------------------------#
  # Checks the priority of event. Can be used in a conditional branch.
  # For example: check_priority?(5) == 1   will check if the priority
  #              of event 5 is equal to 1 (normal priority).
  # For example: check_priority?(blockev) == 2  will check if the
  #              priority of the blocking event (blockev) is equal to 2
  #              (above character).
  #----------------------------------------------------------------# 

 
  The following script calls can be used to move events:
 
    * moveev_rand(event) or moveev_rand(event, dist)
  #----------------------------------------------------------------#
  # Moves the event randomly the specified amount of times.
  # For example: moveev_rand(5)   will move event 5 one random step.
  # For example: moveev_rand(blockev, 2)  will move the blocking
  #              event (blockev) 2 random steps.
  #----------------------------------------------------------------#
 
    * moveev_left(event) or moveev_left(event, dist)
  #----------------------------------------------------------------#
  # Moves the event left the specified amount of times.
  # For example: moveev_left(5)   will move event 5 left one step.
  # For example: moveev_left(blockev, 2)  will move the blocking
  #              event (blockev) left 2 steps.
  #----------------------------------------------------------------#
 
    * moveev_right(event) or moveev_right(event, dist)
  #----------------------------------------------------------------#
  # Moves the event right the specified amount of times.
  # For example: moveev_right(5)   will move event 5 right one step.
  # For example: moveev_right(blockev, 2)  will move the blocking
  #              event (blockev) right 2 steps.
  #----------------------------------------------------------------#
 
    * moveev_down(event) or moveev_down(event, dist)
  #----------------------------------------------------------------#
  # Moves the event down the specified amount of times.
  # For example: moveev_down(5)   will move event 5 down one step.
  # For example: moveev_down(blockev, 2)  will move the blocking
  #              event (blockev) down 2 steps.
  #----------------------------------------------------------------#
 
    * moveev_up(event) or moveev_up(event, dist)
  #----------------------------------------------------------------#
  # Moves the event up the specified amount of times.
  # For example: moveev_up(5)   will move event 5 up one step.
  # For example: moveev_up(blockev, 2)  will move the blocking
  #              event (blockev) up 2 steps.
  #----------------------------------------------------------------#
 
    * ev_move_to(event, x, y)
  #----------------------------------------------------------------#
  # Moves the event to the specified coordinates.
  # For example: ev_move_to(5, 1, 6)   will move event 5 to the
  #              coordinates 1,6.
  # For example: ev_move_to(blockev, $game_variables[1], $game_variables[2])
  #              will move the blocking event (blockev) to the
  #              coordinates set in variables 1 and 2.
  #----------------------------------------------------------------#
 
=end

module AMN_eventpass_setup
 
#==============================================================================
#                               | OPTIONAL |
# ** EDITABLE REGION BELOW
#------------------------------------------------------------------------------
#  Change the values in the area below to suit your needs.
#
#  NOTE: You should have an understanding of regular expression before you
#        change these fields. If you do not, then it is recommended that you
#        leave them as the default.
#==============================================================================


  #--------------------------------------------------------------------------
  Small_Ev_Regex =          /<small_ev>/i          # Default: /<small_ev>/i
  #                                                 DO NOT REMOVE THIS ^ ^ ^
  # Use the regex <small_ev> (default) as a comment in an event to designate
  # 'small' events.
  #
  # This corresponds to the eventkind 1.
  #--------------------------------------------------------------------------
 
  #--------------------------------------------------------------------------
  Over_Ev_Regex =          /<over_ev>/i            # Default: /<over_ev>/i
  #                                                 DO NOT REMOVE THIS ^ ^ ^
  # Use the regex <over_ev> (default) as a comment in an event to designate
  # events that can be ignored or set to 'through'.
  #
  # This corresponds to the eventkind 2.
  #--------------------------------------------------------------------------

 
#==============================================================================
# ** END OF EDITABLE REGION
#------------------------------------------------------------------------------
#  Please do not edit below this point unless you know what you are doing.
#==============================================================================

end

$imported = {} if $imported.nil?
$imported["AMN_EventPassChecks"] = true

#==============================================================================
# ** Game_Map
#------------------------------------------------------------------------------
#  This class handles maps. It includes scrolling and passage determination
# functions. The instance of this class is referenced by $game_map.
#==============================================================================

class Game_Map

  #--------------------------------------------------------------------------
  # * Public Instance Variables
  #--------------------------------------------------------------------------
  attr_accessor   :blockev                    # ID of event blocking path
  attr_accessor   :eventkind                  # Kind of event

  #--------------------------------------------------------------------------
  # * Object Initialization                                  # ALIAS METHOD #
  #--------------------------------------------------------------------------
  alias amn_eventpos_gamemap_init   initialize
  def initialize
    @blockev = 0
    amn_eventpos_gamemap_init
  end
 
  #--------------------------------------------------------------------------
  # * Parse Event Comments                                     # NEW METHOD #
  #--------------------------------------------------------------------------
  # Parses the event's comments and checks for event kind.
  #--------------------------------------------------------------------------
  def parse_event_comments(event_id)
    return if event_id < 1
    event = @events[event_id]
    @eventkind = 0
    if event.list
      event.list.each do |cmd|
        if cmd.code == 108
          if cmd.parameters[0] =~ AMN_eventpass_setup::Small_Ev_Regex
            @eventkind = 1      # number for 'small' events
          elsif cmd.parameters[0] =~ AMN_eventpass_setup::Over_Ev_Regex
            @eventkind = 2      # number for 'over' events
          else
            @eventkind = 0      # number for all other (impassable) events
          end
        end
      end
    end
  end
 
  #--------------------------------------------------------------------------
  # * XY Passability Clear?                                    # NEW METHOD #
  #--------------------------------------------------------------------------
  # Checks the X and Y coordinates and sees if they are clear. Doesn't
  # consider direction.
  #--------------------------------------------------------------------------
  def amn_xy_pass_clear?(x, y)
    get_blockev(x, y)
    return false if check_passage(x, y, 1) == false
    return false if $game_player.pos?(x, y)     # first checks the player's position
    if event_id_xy(x, y) > 0
      ev = event_id_xy(x, y)
      return false if @events[ev].normal_priority? && !@events[ev].through
      return true if !@events[ev].normal_priority? || @events[ev].through
    end
    return true
  end
 
  #--------------------------------------------------------------------------
  # * Get Blockev?                                             # NEW METHOD #
  #--------------------------------------------------------------------------
  # Checks the X and Y coordinates and gets the value of the blocking event.
  #--------------------------------------------------------------------------
  def get_blockev(x, y)
    if check_passage(x, y, 1) == false
      @blockev = -2
    end
    elsif $game_player.pos?(x, y)
      @blockev = -1
    elsif event_id_xy(x, y) > 0
      ev = event_id_xy(x, y)
      @blockev = @events[ev].id
    else
      @blockev = 0
    end
  end   
    
  #--------------------------------------------------------------------------
  # * Check Event Kind                                         # NEW METHOD #
  #--------------------------------------------------------------------------
  # Parses the event's comments for its event kind and returns it.
  #-------------------------------------------------------------------------- 
  def check_eventkind(event_id)
    parse_event_comments(event_id)
    return @eventkind
  end
 
 
end

#==============================================================================
# ** Game_CharacterBase
#------------------------------------------------------------------------------
#  This base class handles characters. It retains basic information, such as
# coordinates and graphics, shared by all characters.
#==============================================================================

#~ class Game_CharacterBase
#~   #--------------------------------------------------------------------------
#~   # * Detect Collision with Event                            # ALIAS METHOD #
#~   #--------------------------------------------------------------------------
#~   # Overwrites the method for checking if an event is colliding with another
#~   # event; now it only returns false if both events are normal priority.
#~   #--------------------------------------------------------------------------
#~   alias amn_gamechara_colwithevents?   collide_with_events?
#~   def collide_with_events?(x, y)
#~     $game_map.events_xy_nt(x, y).any? do |event|
#~       event.normal_priority? && self.normal_priority?
#~     end
#~     amn_gamechara_colwithevents?(x, y)
#~   end
#~   
#~ end

#==============================================================================
# ** Game_Interpreter
#------------------------------------------------------------------------------
#  An interpreter for executing event commands. This class is used within the
# Game_Map, Game_Troop, and Game_Event classes.
#==============================================================================

class Game_Interpreter

  #--------------------------------------------------------------------------
  # * XY Clear?                                                # NEW METHOD #
  #--------------------------------------------------------------------------
  # Check if the coordinates x & y are clear. Returns false if there is an
  # event or player there.
  #--------------------------------------------------------------------------
  def xyclear?(x, y)
    $game_map.amn_xy_pass_clear?(x, y)
  end
 
  #--------------------------------------------------------------------------
  # * Blockev                                                  # NEW METHOD #
  #--------------------------------------------------------------------------
  # Returns the value of the instance variable blockev, or the blocking event.
  #--------------------------------------------------------------------------
  def blockev
    return $game_map.blockev
  end
 
  #--------------------------------------------------------------------------
  # * Check Priority                                           # NEW METHOD #
  #--------------------------------------------------------------------------
  # Convenience method for checking the priority of an event.
  #--------------------------------------------------------------------------
  def check_priority?(event)
    return $game_map.events[event].priority_type
  end
 
  #--------------------------------------------------------------------------
  # * Move To                                                  # NEW METHOD #
  #--------------------------------------------------------------------------
  # Convenience method for moving an event to coordinates.
  #--------------------------------------------------------------------------
  def ev_move_to(event, x, y)
    event = get_character(event)
    event.moveto(x, y)
  end
 
  #--------------------------------------------------------------------------
  # * Eventkind                                                # NEW METHOD #
  #--------------------------------------------------------------------------
  # Returns the eventkind for the event.
  #--------------------------------------------------------------------------
  def eventkind(event)
    $game_map.check_eventkind(event)
  end

  #--------------------------------------------------------------------------
  # * Move Blockev Randomly                                    # NEW METHOD #
  #--------------------------------------------------------------------------
  # Just a convenient way of making the event move in a random
  # direction.
  #--------------------------------------------------------------------------
  def moveev_rand(event, dist = 1)
    event = get_character(event)
    mr = RPG::MoveRoute.new
    mr.repeat = false
    mr.skippable = true
    mr.wait = true
    mr.list = []
    dist.times do
      mr.list.push( RPG::MoveCommand.new(9, []) )
    end
    mr.list.push( RPG::MoveCommand.new )
    event.force_move_route(mr)
  end
 
  #--------------------------------------------------------------------------
  # * Move Blockev Left                                    # NEW METHOD #
  #--------------------------------------------------------------------------
  # Just a convenient way of making the event move left.
  #--------------------------------------------------------------------------
  def moveev_left(event, dist = 1)
    event = get_character(event)
    mr = RPG::MoveRoute.new
    mr.repeat = false
    mr.skippable = true
    mr.wait = true
    mr.list = []
    dist.times do
      mr.list.push( RPG::MoveCommand.new(2, []) )
    end
    mr.list.push( RPG::MoveCommand.new )
    event.force_move_route(mr)
  end
 
  #--------------------------------------------------------------------------
  # * Move Blockev Right                                       # NEW METHOD #
  #--------------------------------------------------------------------------
  # Just a convenient way of making the event move left.
  #--------------------------------------------------------------------------
  def moveev_right(event, dist = 1)
    event = get_character(event)
    mr = RPG::MoveRoute.new
    mr.repeat = false
    mr.skippable = true
    mr.wait = true
    mr.list = []
    dist.times do
      mr.list.push( RPG::MoveCommand.new(3, []) )
    end
    mr.list.push( RPG::MoveCommand.new )
    event.force_move_route(mr)
  end
 
  #--------------------------------------------------------------------------
  # * Move Blockev Down                                        # NEW METHOD #
  #--------------------------------------------------------------------------
  # Just a convenient way of making the event move left.
  #--------------------------------------------------------------------------
  def moveev_down(event, dist = 1)
    event = get_character(event)
    mr = RPG::MoveRoute.new
    mr.repeat = false
    mr.skippable = true
    mr.wait = true
    mr.list = []
    dist.times do
      mr.list.push( RPG::MoveCommand.new(1, []) )
    end
    mr.list.push( RPG::MoveCommand.new )
    event.force_move_route(mr)
  end
 
  #--------------------------------------------------------------------------
  # * Move Blockev Up                                          # NEW METHOD #
  #--------------------------------------------------------------------------
  # Just a convenient way of making the event move left.
  #--------------------------------------------------------------------------
  def moveev_up(event, dist = 1)
    event = get_character(event)
    mr = RPG::MoveRoute.new
    mr.repeat = false
    mr.skippable = true
    mr.wait = true
    mr.list = []
    dist.times do
      mr.list.push( RPG::MoveCommand.new(4, []) )
    end
    mr.list.push( RPG::MoveCommand.new )
    event.force_move_route(mr)
  end
    
  #--------------------------------------------------------------------------
  # * Left Clear?                                              # NEW METHOD #
  #--------------------------------------------------------------------------
  # Check if the tile to the event's left is clear. Based on event's
  # direction.
  #--------------------------------------------------------------------------
  def leftclear?(event, dist = 0)
    event = get_character(event)
    dist -= 1 unless dist == 0  # minus 1 from dist so it doesn't include event
    case event.direction
    when 2; left_dir = 6; evx = (event.x + dist); evy = event.y; bevx = evx + 1; bevy = evy
    when 4; left_dir = 2; evy = (event.y + dist); evx = event.x; bevy = evy + 1; bevx = evx
    when 6; left_dir = 8; evy = (event.y - dist); evx = event.x; bevy = evy - 1; bevx = evx
    when 8; left_dir = 4; evx = (event.x - dist); evy = event.y; bevx = evx - 1; bevy = evy
    end
    $game_map.get_blockev(bevx, bevy)
    return false unless xyclear?(bevx, bevy)
    event.passable?(evx, evy, left_dir)
  end
 
  #--------------------------------------------------------------------------
  # * Right Clear?                                             # NEW METHOD #
  #--------------------------------------------------------------------------
  # Check if the tile to the event's right is clear. Based on event's
  # direction.
  #--------------------------------------------------------------------------
  def rightclear?(event, dist = 0)
    event = get_character(event)
    dist -= 1 unless dist == 0  # minus 1 from dist so it doesn't include event
    case event.direction
    when 2;  right_dir = 4; evx = (event.x - dist); evy = event.y; bevx = evx - 1; bevy = evy
    when 4;  right_dir = 8; evy = (event.y - dist); evx = event.x; bevy = evy - 1; bevx = evx
    when 6;  right_dir = 2; evy = (event.y + dist); evx = event.x; bevy = evy + 1; bevx = evx
    when 8;  right_dir = 6; evx = (event.x + dist); evy = event.y; bevx = evx + 1; bevy = evy
    end
    $game_map.get_blockev(bevx, bevy)
    return false unless xyclear?(bevx, bevy)
    event.passable?(evx, evy, right_dir)
  end
 
  #--------------------------------------------------------------------------
  # * Back Clear?                                              # NEW METHOD #
  #--------------------------------------------------------------------------
  # Check if the tile behind the event is clear. Based on event's direction.
  #--------------------------------------------------------------------------
  def backclear?(event, dist = 0)
    event = get_character(event)
    revdir = event.reverse_dir(event.direction)
    dist -= 1 unless dist == 0  # minus 1 from dist so it doesn't include event
    case event.direction
    when 2;  evy = (event.y - dist); evx = event.x; bevy = evy - 1; bevx = evx
    when 4;  evx = (event.x + dist); evy = event.y; bevx = evx + 1; bevy = evy
    when 6; evx = (event.x - dist); evy = event.y; bevx = evx - 1; bevy = evy
    when 8; evy = (event.y + dist); evx = event.x; bevy = evy + 1; bevx = evx
    end
    $game_map.get_blockev(bevx, bevy)
    return false unless xyclear?(bevx, bevy)
    event.passable?(evx, evy, revdir)
  end
 
  #--------------------------------------------------------------------------
  # * Front Clear?                                             # NEW METHOD #
  #--------------------------------------------------------------------------
  # Check if the tile in front of the event is clear. Based on event's
  # direction.
  #--------------------------------------------------------------------------
  def frontclear?(event, dist = 0)
    event = get_character(event)
    dist -= 1 unless dist == 0  # minus 1 from dist so it doesn't include event
    case event.direction
    when 2;  evy = (event.y + dist); evx = event.x; bevy = evy + 1; bevx = evx
    when 4;  evx = (event.x - dist); evy = event.y; bevx = evx - 1; bevy = evy
    when 6; evx = (event.x + dist); evy = event.y; bevx = evx + 1; bevy = evy
    when 8; evy = (event.y - dist); evx = event.x; bevy = evy - 1; bevx = evx
    end
    $game_map.get_blockev(bevx, bevy)
    return false unless xyclear?(bevx, bevy)
    event.passable?(evx, evy, event.direction)
  end
 
  #--------------------------------------------------------------------------
  # * North Clear?                                             # NEW METHOD #
  #--------------------------------------------------------------------------
  # Check if the tile above the event (the north) is clear.
  #--------------------------------------------------------------------------
  def northclear?(event, dist = 0)
    event = get_character(event)
    dist -= 1 unless dist == 0  # minus 1 from dist so it doesn't include event
    $game_map.get_blockev(event.x, (event.y - dist) - 1)
    return false unless xyclear?(event.x, (event.y - dist) - 1)
    event.passable?(event.x, (event.y - dist), 8)
  end
 
  #--------------------------------------------------------------------------
  # * South Clear?                                             # NEW METHOD #
  #--------------------------------------------------------------------------
  # Check if the tile below the event (the south) is clear.
  #--------------------------------------------------------------------------
  def southclear?(event, dist = 0)
    event = get_character(event)
    dist -= 1 unless dist == 0  # minus 1 from dist so it doesn't include event
    $game_map.get_blockev(event.x, (event.y + dist) + 1)
    return false unless xyclear?(event.x, (event.y + dist) + 1)
    event.passable?(event.x, (event.y + dist), 2)
  end
 
  #--------------------------------------------------------------------------
  # * East Clear?                                              # NEW METHOD #
  #--------------------------------------------------------------------------
  # Check if the tile right of the event (the east) is clear.
  #--------------------------------------------------------------------------
  def eastclear?(event, dist = 0)
    event = get_character(event)
    dist -= 1 unless dist == 0  # minus 1 from dist so it doesn't include event
    $game_map.get_blockev((event.x + dist) + 1, event.y)
    return false unless xyclear?((event.x + dist) + 1, event.y)
    event.passable?((event.x - dist), event.y, 6)
  end
 
  #--------------------------------------------------------------------------
  # * West Clear?                                              # NEW METHOD #
  #--------------------------------------------------------------------------
  # Check if the tile left of the event (the west) is clear.
  #--------------------------------------------------------------------------
  def westclear?(event, dist = 0)
    event = get_character(event)
    dist -= 1 unless dist == 0  # minus 1 from dist so it doesn't include event
    $game_map.get_blockev((event.x - dist) - 1, event.y)
    return false unless xyclear?((event.x - dist) - 1, event.y)
    event.passable?((event.x + dist), event.y, 4)
  end

  #--------------------------------------------------------------------------
  # * A Equals B Pos?                                          # NEW METHOD #
  #--------------------------------------------------------------------------
  # Check if event A's position is the same as event B
  #--------------------------------------------------------------------------
  def a_equal_b_pos?(eventa, eventb)
    eventa = get_character(eventa)
    eventb = get_character(eventb)
    eventa.pos?(eventb.x, eventb.y)
  end
end