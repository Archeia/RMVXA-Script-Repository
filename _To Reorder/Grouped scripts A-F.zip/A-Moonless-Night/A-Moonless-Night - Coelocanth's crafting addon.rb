=begin
#==============================================================================#
#   AMN Coelocanth's Crafting System Addon
#   Version 1.01
#   Author: AMoonlessNight
#   Date: 16 Dec 2018
#   Latest: 16 Dec 2018
#==============================================================================#
#   UPDATE LOG
#------------------------------------------------------------------------------#
# 16 Dec 2018 - created the script
#==============================================================================#
#   TERMS OF USE
#------------------------------------------------------------------------------#
# - Please credit AMoonlessNight or A-Moonless-Night
# - Please credit Coelocanth
# - Free for non-commercial use
# - See Coelocanth for commercial use
# - I'd love to see your game if you end up using one of my scripts
#==============================================================================#

This script is an addon for Coelocanth's Item Crafting System. It allows you to
set other items, weapons and armours to be gained from crafting a particular
item. They will not appear in the ingredient or results lists.

Use the following in an item's notes:

  <craft extra: i7>           this would give 1x item 7
  <craft extra: w2:9>         this would give 9x weapon 2
 
  <craft break extra: w8:3>   this would give 3x weapon 8
  <craft break extra: a1>     this would give 1x armour 1
 
  where i is for item, w is for weapon and a is for armour.
 
=end

module AMN_Craft_Addon
  Regex =       /<craft\sextra:*\s([iwa])\s*(\d+|\d+:\d+)>/i
  Break_Regex = /<craft\sbreak\sextra:*\s([iwa])\s*(\d+|\d+:\d+)>/i
end

class RPG::BaseItem
  attr_reader :crafting_extra_items
  attr_reader :crafting_extra_weapons
  attr_reader :crafting_extra_armors

  attr_reader :craft_break_extra_items
  attr_reader :craft_break_extra_weapons
  attr_reader :craft_break_extra_armors
    
  alias amn_craftaddon_rpgbaseitem_loadnotetagscrafting load_notetags_crafting
  def load_notetags_crafting
    amn_craftaddon_rpgbaseitem_loadnotetagscrafting
    @crafting_extra_items = {}
    @crafting_extra_weapons = {}
    @crafting_extra_armors = {}

    @craft_break_extra_items = {}
    @craft_break_extra_weapons = {}
    @craft_break_extra_armors = {}
    #---
    self.note.split(/[\r\n]+/).each { |line|
    case line
    when AMN_Craft_Addon::Regex
      hash = $1 == "w" ? @crafting_extra_weapons : $1 == "a" ? @crafting_extra_armors : @crafting_extra_items
      res = $2.split(':')
      hash[res[0].to_i] = (res[1] ? res[1].to_i : 1)
    when AMN_Craft_Addon::Break_Regex
      hash = $1 == "w" ? @craft_break_extra_weapons : $1 == "a" ? @craft_break_extra_armors : @craft_break_extra_items
      res = $2.split(':')
      hash[res[0].to_i] = (res[1] ? res[1].to_i : 1)
    end
    }
  end
end

class Scene_Crafting < Scene_CraftBase

  alias amn_craftaddon_scenecrafting_onitemok on_item_ok
  def on_item_ok
    item.crafting_extra_items.each { |key, value|
      $game_party.gain_item($data_items[key], value) }
    item.crafting_extra_weapons.each { |key, value|
      $game_party.gain_item($data_weapons[key], value) }
    item.crafting_extra_armors.each { |key, value|
      $game_party.gain_item($data_armors[key], value) }
    amn_craftaddon_scenecrafting_onitemok
  end

end

class Scene_Craft_Breakdown < Scene_CraftBase

  alias amn_craftaddon_scenecraftbreakdown_onitemok on_item_ok
  def on_item_ok
    item.craft_break_extra_items.each { |key, value|
      $game_party.gain_item($data_items[key], value) }
    item.craft_break_extra_weapons.each { |key, value|
      $game_party.gain_item($data_weapons[key], value) }
    item.craft_break_extra_armors.each { |key, value|
      $game_party.gain_item($data_armors[key], value) }
    amn_craftaddon_scenecraftbreakdown_onitemok
  end

end