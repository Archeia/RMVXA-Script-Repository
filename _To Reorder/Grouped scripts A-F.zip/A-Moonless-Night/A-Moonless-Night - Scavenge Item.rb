=begin
#==============================================================================#
#   AMN Scavenge Item
#   Version 1.01
#   Author: AMoonlessNight
#   Date: 07 Jul 2018
#   Latest: 07 Jul 2018
#==============================================================================#
#   UPDATE LOG
#------------------------------------------------------------------------------#
# 07 Jul 2018 - created the script
#==============================================================================#
#   TERMS OF USE
#------------------------------------------------------------------------------#
# - Please credit AMoonlessNight or A-Moonless-Night
# - Free for non-commercial use
# - I'd love to see your game if you end up using one of my scripts
#==============================================================================#
 
This script makes it so that actors can have a random chance of receiving an
item back when they use it in battle.
 
Notetag actors, classes, skills and equippable items with the following:
 
<scavenger>
 
If you notetag a skill, the actor must have learnt that skill.
If you notetag a class, the actor must belong to that class.
If you notetag an equippable item, the actor must have that item equipped.
 
You can also notetag usable items with the following:
 
<s_chance: x>
 
Where x is the percentage chance of receiving the item back. E.g. <s_chance: 5>
would give a 5% chance of receiving the item back.
 
You can also use a variable to increase or decrease the chances. In game, set
the variable to a positive number or negative number accordingly.
 
 
=end
module AMN_Scavenger
#==============================================================================
# ** EDITABLE REGION BELOW
#------------------------------------------------------------------------------
#  Change the values in the area below to suit your needs.
#==============================================================================
 
  Default_Chance    = 15
  # % chance of receiving item back, e.g. 2 would be 2%, 50 would be 50%.
 
  Variable_Modifier = 4
  # ID of a variable that you can set to increase the chances of receiving the
  # item.
  # Put 0 to not use.
 
  Scavenge_Off = 3
  # ID of a switch that, if set to TRUE, will turn scavenging OFF.
  # Put 0 to not use.
 
  Refund_Message    = "%s recovered the %s!"
  # Message to be displayed in battle. Must be written as "%s xxxx %s xx", where
  # the first %s represents the actor's name and the second %s represents the
  # item name.
 
  Message_Style = :message
  # Whether to display the message in the battle log window or a regular message
  # box.
  #   :log      = log window
  #   :message  = message window
  #   :none     = no message
 
 
#==============================================================================
# ** END OF EDITABLE REGION
#------------------------------------------------------------------------------
#  Please do not edit below this point unless you know what you are doing.
#==============================================================================
 
  Scavenger_Regex   = /<scavenger>/i
 
  Chance_Regex      = /<s_chance:\s*(\d+)>/i
 
end
 
class RPG::UsableItem < RPG::BaseItem
  attr_reader   :scavenge_chance
 
  def check_scavenge_chance
    self.note.split(/[\r\n]+/).each { |line|
    case line
    when AMN_Scavenger::Chance_Regex
      @scavenge_chance = $1.to_i
    else
      @scavenge_chance = nil
    end
    }
  end
   
  def scavenge_chance?
    check_scavenge_chance if @scavenge_chance.nil?
    return @scavenge_chance
  end
 
end
 
class RPG::BaseItem
  attr_reader   :scavenger
 
  def scavenger?
    return @scavenger unless @scavenger.nil?
    res = self.note.match(AMN_Scavenger::Scavenger_Regex)
    return @scavenger = !res.nil?
  end
 
end
 
class Scene_Battle < Scene_Base
  attr_accessor:log_window
end
 
class Game_Actor < Game_Battler
 
  def scavenger?
    return true if actor.scavenger?
    return true if self.class.scavenger?
    return true if !(equips.select {|eq| eq.scavenger? rescue nil }).empty?
    return true if !(skills.select {|skill| skill.scavenger? }).empty?
    return false
  end
 
  def consume_item(item)
    $game_party.consume_item(item)
    return unless $game_party.in_battle && scavenger?
    return if $game_switches[AMN_Scavenger::Scavenge_Off] unless AMN_Scavenger::Scavenge_Off == 0
    chance = item.scavenge_chance? ? item.scavenge_chance : AMN_Scavenger::Default_Chance
    chance += $game_variables[AMN_Scavenger::Variable_Modifier] unless AMN_Scavenger::Variable_Modifier == 0
    return if chance.nil? || chance == 0
    return unless rand(100) < chance
    $game_party.gain_item(item, 1)
    if AMN_Scavenger::Message_Style == :log
      SceneManager.scene.log_window.wait
      SceneManager.scene.log_window.add_text(sprintf(AMN_Scavenger::Refund_Message, @name, item.name))
      SceneManager.scene.log_window.wait
    elsif AMN_Scavenger::Message_Style == :message
      $game_message.add(sprintf(AMN_Scavenger::Refund_Message, @name, item.name))
      SceneManager.scene.wait_for_message
    end
  end
 
end