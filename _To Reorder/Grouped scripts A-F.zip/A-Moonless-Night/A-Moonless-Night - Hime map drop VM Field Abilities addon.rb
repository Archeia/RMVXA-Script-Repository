=begin
#===============================================================================
#   AMN Hime Map Drops / V.M. Field Abilities addon
#   Version 1.02
#   Author: AMoonlessNight
#   Date: 01 Jun 2018
#   Latest: 02 Jun 2018
#==============================================================================#
#   UPDATE LOG
#------------------------------------------------------------------------------#
# 01 Jun 2018 - created the script
#             - added the ability to change the icon used for the item drop
# 02 Jun 2018 - added the ability to set the item's priority
#             - added the ability to collect items again once dropped if they're
#               'throwable' or 'grabbable'
#==============================================================================#
#   TERMS OF USE
#------------------------------------------------------------------------------#
# - Please credit AMoonlessNight or A-Moonless-Night
# - Free for non-commercial use
# - I'd love to see your game if you end up using one of my scripts
#==============================================================================#

This script makes it so that you can designate items as being 'grabbable' or
'throwable', to work with V.M.'s Field Abilities script.

Use the following in an item's notes:

<grab item> OR <grab_item>
To set an item as 'grabbable'. This means you can drag it around.

<throw item> OR <throw_item>
To set an item as 'throwable'. This means you can pick it up and throw it.
 
You can also give the item a different icon when it has been dropped:

<drop_icon: #>
where # is the icon number.

To set the priority for the item, use the following:

<priority: #>
where # is the priority number.
  0 = below priority
  1 = normal priority
  2 = above priority

 
To pick up the item again, press the Collect_Item_Button (designated below)


=end
module AMN_TH_VM_Field

#==============================================================================
# ** EDITABLE REGION BELOW
#------------------------------------------------------------------------------
#  Change the values in the area below to suit your needs.
#==============================================================================

  #--------------------------------------------------------------------
    Collect_Item_Button = :X  # button to press to collect item again
  #
  # Buttons:
  #   :A  - SHIFT key on the keyboard. I suggest you don't use this key,
  #         as it is also the Dash feature in RPG Maker.
  #   :X  - A key on the keyboard. Does nothing by default.
  #   :Y  - S key on the keyboard. Does nothing by default.
  #   :Z  - D key on the keyboard. Does nothing by default.
  #   :L  - Q / Page Up key on the keyboard. Does nothing by default.
  #   :R  - W / Page Down key on the keyboard. Does nothing by default.
  #   :F5, :F6, :F7, :F8, :ALT  - Do nothing by default.
  #--------------------------------------------------------------------
 
  #--------------------------------------------------------------------
    Obtain_Message = true  # the 'obtained item' message will pop up
  # if you collect an item that has been dropped and said item is
  # 'throwable' or 'grabbable'.
  #--------------------------------------------------------------------

#==============================================================================
#  Please do not edit below this point unless you know what you are doing.
#==============================================================================
end

$imported = {} if $imported.nil?
$imported[:AMN_TH_MapDrops_VM_Field_Abilities_Addon] = true

if !$imported["TH_MapDrops"]
  msg = "                                      IMPORTANT:\n"
  msg += "            HimeWorks Map Drops script add-on by A-Moonless-Night\n"
  msg += " \n"
  msg += "This script requires HimeWork's Map Drops script.\n"
  msg += "Please download it from http://himeworks.com/rmvxa-scripts/"
  msgbox(msg)
  exit
end

module TH
  module Map_Drops
    
    Throw_Item_Regex = /<throw[ _-]+item>/i
    Grab_Item_Regex = /<grab[ _-]+item>/i
    Drop_Icon_Regex = /<drop_icon:\s*(\d+)>/i
    Set_Priority_Regex = /<priority:\s*(\d)>/i

  end
end

module RPG
  class BaseItem
    
    attr_reader   :throw_item
    attr_reader   :grab_item
    attr_reader   :drop_icon
    attr_reader   :set_priority
    
    def throw_item?
      return @throw_item unless @throw_item.nil?
      res = self.note.match(TH::Map_Drops::Throw_Item_Regex)
      return @throw_item = !res.nil?
    end
    
    def grab_item?
      return @grab_item unless @grab_item.nil?
      res = self.note.match(TH::Map_Drops::Grab_Item_Regex)
      return @grab_item = !res.nil?
    end
    
    def drop_icon
      self.note.split(/[\r\n]+/).each { |line|
      case line
      when TH::Map_Drops::Drop_Icon_Regex
        @drop_icon = $1
        return @drop_icon
      else
        @drop_icon = nil
      end
      }
      @drop_icon
    end
    
     def set_priority
      self.note.split(/[\r\n]+/).each { |line|
      case line
      when TH::Map_Drops::Set_Priority_Regex
        @set_priority = $1
        return @set_priority
      else
        @set_priority = nil
      end
      }
      @set_priority
    end
    
  end
end

class Game_MapDrop < Game_Drop

  alias amn_himemapdrop_vmfield_gamemapdrop_init  initialize
  def initialize(item, count=1, x=$game_player.x, y=$game_player.y, map_id=$game_map.map_id)
    amn_himemapdrop_vmfield_gamemapdrop_init(item, count=1, x=$game_player.x, y=$game_player.y, map_id=$game_map.map_id)
    if !item.drop_icon.nil?
      @icon_index = item.drop_icon.to_i
    end
  end
 
  alias amn_himemapdrop_vmfield_gamemapdrop_setupevent  setup_event
  def setup_event(x, y)
    @set_priority = item.set_priority.to_i
    amn_himemapdrop_vmfield_gamemapdrop_setupevent(x, y)
    if @set_priority != nil && @set_priority <= 2
      event.pages[0].priority_type = @set_priority
    end
  end
 
  alias amn_himemapdrop_vmfield_gamemapdrop_addeventcommands  add_event_commands
  def add_event_commands(list)
    if @item.throw_item?
      list << RPG::EventCommand.new(355, 0, ["pickup"])
      list << RPG::EventCommand.new
    elsif @item.grab_item?
      event.pages[0].priority_type = 1
      list << RPG::EventCommand.new(355, 0, ["grab"])
      list << RPG::EventCommand.new
    else
      amn_himemapdrop_vmfield_gamemapdrop_addeventcommands(list)
    end
  end
 
end

class Game_Character < Game_CharacterBase

  alias amn_himemapdrop_vmfield_gamecharacter_pickup  pick_up
  def pick_up(event_id)
    @carrying = event_id
    @carrying = $game_map.events[event_id] if $game_map.events[event_id]
    @orig_priority = @carrying.priority_type
    amn_himemapdrop_vmfield_gamecharacter_pickup(event_id)
  end
 
  # OVERWRITE method
  def throw
    @carrying.moveto(@x,@y)
    @carrying.direction = @direction
    return unless @carrying.jump_forward_field
    @carrying.thrown
    @carrying.through = false
    @carrying.priority_type = @orig_priority
    @carrying.carried = nil
    @carrying = nil
  end
 
  # OVERWRITE method
  def screen_y
    @carried ? @carried.screen_y - 12 : env_screen_y
  end
 
  alias amn_himemapdrop_vmfield_gamecharacter_jumpfwdfield  jump_forward_field
  def jump_forward_field
    if $imported["TH_MapDrops"] && self.is_a?(Game_DropEvent)
      return jump_straight(0,1)  if @direction == 2
      return jump_straight(-1,0) if @direction == 4
      return jump_straight(1,0)  if @direction == 6
      return jump_straight(0,-1) if @direction == 8
    else
      amn_himemapdrop_vmfield_gamecharacter_jumpfwdfield
    end
  end
 
end

class Game_Player < Game_Character

  alias amn_himemapdrop_vmfield_gameplayer_update update
  def update
    amn_himemapdrop_vmfield_gameplayer_update
    if Input.trigger?(AMN_TH_VM_Field::Collect_Item_Button)
      if @grabbed
        return unless $imported["TH_MapDrops"] && @grabbed.is_a?(Game_DropEvent)
        item = @grabbed.drop.item
        @direction_fix = false
        @move_speed += 1
        @move_frequency += 1
        $game_map.delete_event(@grabbed.id)
        $game_party.gain_item(item, 1)
        RPG::SE.new(TH::Map_Drops::Obtain_SE, 100, 80).play
        if AMN_TH_VM_Field::Obtain_Message
          @count = 1
          Fiber.yield while $game_message.busy?
          $game_message.add(sprintf(TH::Map_Drops::Found_Message, "%d %s" %[@count, item.name]))
        end
        @grabbed = nil
      elsif @carrying
        return unless $imported["TH_MapDrops"] && @carrying.is_a?(Game_DropEvent)
        item = @carrying.drop.item
        @carrying.through = false
        @carrying.priority_type = @orig_priority
        $game_map.delete_event(@carrying.id)
        $game_party.gain_item(item, 1)
        RPG::SE.new(TH::Map_Drops::Obtain_SE, 100, 80).play
        if AMN_TH_VM_Field::Obtain_Message
          @count = 1
          Fiber.yield while $game_message.busy?
          $game_message.add(sprintf(TH::Map_Drops::Found_Message, "%d %s" %[@count, item.name]))
        end
        @carrying.carried = nil
        @carrying = nil
      end
    end
  end
 
end