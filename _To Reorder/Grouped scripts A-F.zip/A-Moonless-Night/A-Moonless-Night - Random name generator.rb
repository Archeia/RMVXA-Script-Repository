=begin
#============================================================================
#   AMN Name Generator
#   Version 1.0
#   Author: AMoonlessNight
#   Date: 12 May 2018
#   Latest: 12 May 2018
#===========================================================================#
#   UPDATE LOG
#---------------------------------------------------------------------------#
# 12 May 2018 - created the script
#===========================================================================#

This script makes it so that actors can have a randomly generated name. You
can set it so that only certain actors have randomly generated names, if you
wish, or all of them.

Set up the names in the editable region below.


You can use the notetag   <random name>   in the actor notes

  - If Auto_Names is set to false, this actor WILL be given a random name.
  - If Auto_Names is set to true, this actor WILL NOT be given a random name.

You can use the script call:  random_name(actor_id)
where actor_id is the ID of the actor whose name you want to change.


=end

module AMN_Random_Name_Generator
  Names = [
#==============================================================================
# ** EDITABLE REGION BELOW
#------------------------------------------------------------------------------
#  Change the values in the area below to suit your needs.
#==============================================================================

# Set the random names below. Make sure each one is a string (i.e. enclosed in "")
# followed by a ,
# Names can be anything, so long as they're enclosed in speech marks
# e.g. "N00B 1", "Terry", "100"

  "Hare", "Black", "Ferret", "Kestrel", "Leap", "Stream", "Little", "Prickle",
  "Snail", "Swan", "Spotted", "Ivy", "Crooked", "Pale", "Red", "Clover", "Lion",
  "Tall", "Blizzard", "Running", "Plum", "Ashen", "White", "Ebony", "Nettle",
  "Sand", "Cypress",
 
  ] # <-- DO NOT REMOVE ]
 
 
# If you would like actors to have names generated automatically, set this to
# true

  Auto_Names = true

 
#==============================================================================
# ** END OF EDITABLE REGION
#------------------------------------------------------------------------------
#  Please do not edit below this point unless you know what you are doing.
#==============================================================================

  AutoNameRegex   = /<random\s+name>/i
 
end

class RPG::Actor < RPG::BaseItem
  attr_reader :auto_name
 
  def auto_name?
    return @auto_name unless @auto_name.nil?
    res = self.note.match(AMN_Random_Name_Generator::AutoNameRegex)
    return @auto_name = !res.nil?
  end
 
end

#==============================================================================
# ** Game_Actor
#------------------------------------------------------------------------------
#  This class handles actors. It is used within the Game_Actors class
# ($game_actors) and is also referenced from the Game_Party class ($game_party).
#==============================================================================

class Game_Actor < Game_Battler
 
  alias amn_randnamegen_gameactor_init  initialize
  def initialize(actor_id)
    amn_randnamegen_gameactor_init(actor_id)
    if AMN_Random_Name_Generator::Auto_Names
      create_random_name unless $data_actors[@actor_id].auto_name?
    else
      create_random_name if $data_actors[@actor_id].auto_name?
    end
  end
 
  def create_random_name
    @name = AMN_Random_Name_Generator::Names.sample
  end
 
end

#==============================================================================
# ** Game_Interpreter
#------------------------------------------------------------------------------
#  An interpreter for executing event commands. This class is used within the
# Game_Map, Game_Troop, and Game_Event classes.
#==============================================================================

class Game_Interpreter
 
  def random_name(actor_id)
    $game_actors[actor_id].create_random_name
  end
 
end