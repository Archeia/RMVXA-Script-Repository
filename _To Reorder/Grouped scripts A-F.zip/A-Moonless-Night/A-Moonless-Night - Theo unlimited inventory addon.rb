=begin
#=====================================================================
#   AMN Theo Limited Inventory - Add-on
#   Version 1.0
#   Author: AMoonlessNight
#   Date: 21 Feb 2018
#   Latest: 21 Feb 2018
#=====================================================================#
#   UPDATE LOG
#---------------------------------------------------------------------#
# 21 Feb 2018 - created the add-on script for Theo's Limited Inventory
#=====================================================================#

This script was requested as an add-on to Theo's Limited Inventory script.
It will not work without it. It adds compatibility with Efeberk's
Combine Items script and will also not work without that.
Map Drop compatibility for Hime Map Drop 

Requested by Robert-Character-Creator
 
=end

if !$imported[:Theo_LimInventory]
  msg = "                                      IMPORTANT:\n"
  msg += "            Theo Limited Inventory script add-on by A-Moonless-Night\n"
  msg += " \n"
  msg += "This script requires Theo's Limited Inventory script.\n"
  msg += "Please download it from https://www.rpgmakercentral.com/topic/24050-theo-limited-inventory/"
  msgbox(msg)
  exit
end

# =============================================================================
# ▼ Window_ItemList
# =============================================================================
class Window_ItemListe < Window_Selectable # Window_ItemList
  attr_reader :item_size_window
 
  def item_size_window=(window)
    @item_size_window = window
    @item_size_window.set_item(item)
  end
 
  alias theo_liminv_update_help update_help
  def update_help
    theo_liminv_update_help
    @item_size_window.set_item(item) if @item_size_window
  end
 
  alias theo_liminv_height= height=
  def height=(height)
    self.theo_liminv_height = height
    refresh
  end
 
  def enable?(item)
    return !item.nil?
  end
 
end

# =============================================================================
# ▼ Scene_Item
# =============================================================================
class Scene_Combine < Scene_ItemBase # Scene_Item
 
  alias theo_liminv_start start
  def start
    theo_liminv_start
    resize_item_window
    create_freeslot_window
    create_itemsize_window
    create_usecommand_window
    create_discard_amount
  end
 
  def resize_item_window
    @item_window.height -= @item_window.line_height * 2
  end
 
  def create_freeslot_window
    wy = @item_window.y + @item_window.height
    wh = Theo::LimInv::Display_ItemSize ? Graphics.width/2 : Graphics.width
    @freeslot = Window_FreeSlot.new(0,wy,wh)
    @freeslot.viewport = @viewport
  end
 
  def create_itemsize_window
    return unless Theo::LimInv::Display_ItemSize
    wx = @freeslot.width
    wy = @freeslot.y
    ww = wx
    @itemsize = Window_ItemSize.new(wx,wy,ww)
    @itemsize.viewport = @viewport
    @item_window.item_size_window = @itemsize
  end
 
  def create_usecommand_window
    @use_command = Window_ItemUseCommand.new
    @use_command.to_center
    @use_command.set_handler(:use, method(:use_command_ok))
    @use_command.set_handler(:discard, method(:on_discard_ok))
    @use_command.set_handler(:cancel, method(:on_usecmd_cancel))
    @use_command.viewport = @viewport
  end
 
  def create_discard_amount
    wx = @use_command.x
    wy = @use_command.y + @use_command.height
    ww = @use_command.width
    @discard_window = Window_DiscardAmount.new(wx,wy,ww)
    @discard_window.cmn_window = @use_command
    @discard_window.itemlist = @item_window
    @discard_window.freeslot = @freeslot
    @discard_window.viewport = @viewport
  end

  def combine_ok
    @item_window.combining = true
    @combine = true
    @category_window.item_window = @item_window
    @options_window.deactivate.unselect
    @category_window.activate.select(0)
  end
 
  def use_ok
    @item_window.combining = false
    @category_window.item_window = @item_window
    @options_window.deactivate.unselect
    @category_window.activate.select(0)
  end
 
  alias theo_liminv_use_item use_item
  def use_item
    @use_command.close
    theo_liminv_use_item
    @freeslot.refresh
  end
 
  def on_item_ok
    k = [@item_window.item.id, :item] if @item_window.item.is_a?(RPG::Item)
    k = [@item_window.item.id, :weapon] if @item_window.item.is_a?(RPG::Weapon)
    k = [@item_window.item.id, :armor] if @item_window.item.is_a?(RPG::Armor)
    if !@item_window.combining
      @options_window.deactivate
      @use_command.set_item(item)
      @use_command.open
      @use_command.activate
      @use_command.select(0)
    else
      if @item_window.accepted_items.include?(k)
        @item_window.accepted_items.delete(k)
      else
        @item_window.accepted_items.push(k)
      end
      if @item_window.accepted_items.size == 2
        check_combinations(@item_window.accepted_items[0], @item_window.accepted_items[1])
        @item_window.refresh
      else
        @item_window.refresh
        @item_window.activate
      end
    end
  end
 
  def theo_liminv_item_ok
    @options_window.deactivate
    $game_party.last_item.object = item
    determine_item
  end
 
  def use_command_ok
    theo_liminv_item_ok
    @use_command.close
  end
 
  def on_discard_ok
    @discard_window.set_item(item)
    @discard_window.open
  end
 
  def on_usecmd_cancel
    @item_window.activate
    @use_command.close
    @use_command.deactivate
  end
 
end