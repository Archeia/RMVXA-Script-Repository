=begin
#=====================================================================
#   AMN Hime Map Drops - Add-on
#   Version 1.2
#   Author: AMoonlessNight
#   Date: 18 Feb 2018
#   Latest: 13 Mar 2018
#=====================================================================#
#   UPDATE LOG
#---------------------------------------------------------------------#
# 18 Feb 2018 - created the add-on script for HimeWorks' Map Drops
# 21 Feb 2018 - added compatibility for Efeberk's Combine Scene script
#               and Theo's Limited Inventory
# 13 Mar 2018 - added additional functionality, such as setting events'
#               direction, speed and frequency
#=====================================================================#

This script was requested as an add-on to HimeWorks' Map Drops script.
It will not work without it.

The original script sets the character graphic to the item's icon in the
database. There is now the ability to set whether the script uses icons
or character graphics.

Set the default character graphics in the editable region below and use
the following notetag: <dropsprite: graphic index>
where graphic is the name of the character graphic (e.g. !Chest) and
index is the index number (e.g. 4).
NOTE: Do not use quotation marks! (so !Chest rather than "!Chest")

Row 1
0 is the first character, 1 is the second, 2 is the third, 3 is the fourth
Row 2
4 is the first character, 5 is the second, 6 is the third, 7 is the fourth

This script also works in conjunction with A-Moonless-Night's Advanced
Event Passability Checks script. If an item has the notetag <small_item>
then when it is discarded onto the map, it will act as a 'small event'.
See the Advanced Event Passability Checks script for more info.

Use the following notetags to change the drop item event:

<stepping_anim>   = Makes the event have stepping animation on
<norm_priority>   = Makes the event normal priority / same as character
<front_of_chara>  = Drops the item in front of the character
<dir_fix>         = Makes the event have direction fix on
<same_dir>        = Makes the event face the same direction as player when placed
<set_dir: #>      = Sets the event's direction to # (either 2, 4, 6 or 8)
                    2 = down, 4 = left, 6 = right, 8 = up
<set_speed: #>    = Sets the event's speed to # (single digit number)
<set_freq: #>     = Sets the event's frequency to # (single digit number)


Requested by Robert-Character-Creator

#=====================================================================#
          SCRIPT CALLS
#=====================================================================#

You can use the following script calls:

    * mapdrop_useicons(true | false)
  #----------------------------------------------------------------#
  # Sets whether to use icons for map drops or sprites.
  # For example:  mapdrop_useicons(false)   will make it so map drops
  # use character sprites.
  #----------------------------------------------------------------#

 
=end

if !$imported["TH_MapDrops"]
  msg = "                                      IMPORTANT:\n"
  msg += "            HimeWorks Map Drops script add-on by A-Moonless-Night\n"
  msg += " \n"
  msg += "This script requires HimeWork's Map Drops script.\n"
  msg += "Please download it from http://himeworks.com/rmvxa-scripts/"
  msgbox(msg)
  exit
end

module TH
  module Map_Drops

#==============================================================================
# ** EDITABLE REGION BELOW
#------------------------------------------------------------------------------
#  Change the values in the area below to suit your needs.
#==============================================================================


  #--------------------------------------------------------------------------
    Use_Icon    =   false                   # set to true or false
  # Whether to use the item's icon for map drops. If false, will use character
  # sprites.
  #--------------------------------------------------------------------------
 
  #--------------------------------------------------------------------------
    Default_Sheet = "!Flame"                # default character sheet
    Default_Index = 4                       # default index
  # The default character sheet and index to use for map drops (if Use_Icon
  # is set to false. This is unless you specify them in the item's notetags.
  #--------------------------------------------------------------------------

  #--------------------------------------------------------------------------
    Deny_Message = "My hands are too full to carry this."
  # Message displayed if the player cannot pick the item up (uses Theo's
  # Limited Inventory script).
  #--------------------------------------------------------------------------
 
 
#==============================================================================
# ** END OF EDITABLE REGION
#------------------------------------------------------------------------------
#  Please do not edit below this point unless you know what you are doing.
#==============================================================================

    Small_Item_Regex = /<small_item>/i
    Sprite_Name_Index_Regex = /<(?:drop_sprite):[ ](.*)[ ](\d+)>/i
    Stepping_Anim_Ev_Regex =  /<stepping_anim>/i
    Normal_Priority_Ev_Regex = /<norm_priority>/i
    Front_Chara_Ev_Regex = /<front_of_chara>/i
    Dir_Fix_Regex = /<dir_fix>/i
    Same_Dir_Regex = /<same_dir>/i
    Set_Dir_Regex = /<(?:set_dir): ([\d])>/i
    Set_Ev_Speed_Regex = /<(?:set_speed): ([\d])>/i
    Set_Ev_Freq_Regex = /<(?:set_freq): ([\d])>/i
    
  end
end

module RPG
  class EquipItem < BaseItem
    
    def small_item?
      return @small_item unless @small_item.nil?
      res = self.note.match(TH::Map_Drops::Small_Item_Regex)
      return @small_item = !res.nil?
    end
    
    def amn_chosensprite
      self.note.split(/[\r\n]+/).each { |line|
      case line
      when TH::Map_Drops::Sprite_Name_Index_Regex
        @chosen_sprite = true
        @chosen_sprite_name = $1.to_s
        @chosen_sprite_index = $2.to_i
      else
        @chosen_sprite = nil
      end
      }
    end
  
    def has_chosen_sprite?
      amn_chosensprite if @chosen_sprite.nil?
      return @chosen_sprite
    end
    
    def stepping_ev_anim?
      return @stepping__anim unless @stepping__anim.nil?
      res = self.note.match(TH::Map_Drops::Stepping_Anim_Ev_Regex)
      return @stepping__anim = !res.nil?
    end
    
    def normal_ev_priority?
      return @normal__priority unless @normal__priority.nil?
      res = self.note.match(TH::Map_Drops::Normal_Priority_Ev_Regex)
      return @normal__priority = !res.nil?
    end
    
    def front_of_chara?
      return @front__chara unless @front__chara.nil?
      res = self.note.match(TH::Map_Drops::Front_Chara_Ev_Regex)
      return @front__chara = !res.nil?
    end
    
    def dir_fix_event?
      return @dir_fix_event unless @dir_fix_event.nil?
      res = self.note.match(TH::Map_Drops::Dir_Fix_Regex)
      return @dir_fix_event = !res.nil?
    end
    
    def same_dir_event?
      return @same_dir_event unless @same_dir_event.nil?
      res = self.note.match(TH::Map_Drops::Same_Dir_Regex)
      return @same_dir_event = !res.nil?
    end
    
    def amn_setspritedir
      self.note.split(/[\r\n]+/).each { |line|
      case line
      when TH::Map_Drops::Set_Dir_Regex
        @sprite_dir = true
        @set_sprite_dir = $1
      else
        @sprite_dir = nil
      end
      }
    end
  
    def has_setspritedir?
      amn_setspritedir if @sprite_dir.nil?
      return @set_sprite_dir
    end
    
    def amn_setspritespeed
      self.note.split(/[\r\n]+/).each { |line|
      case line
      when TH::Map_Drops::Set_Ev_Speed_Regex
        @sprite_spd = true
        @set_sprite_spd = $1
      else
        @sprite_spd = nil
      end
      }
    end
  
    def has_setspritespeed?
      amn_setspritespeed if @sprite_spd.nil?
      return @set_sprite_spd
    end
    
    def amn_setspritefreq
      self.note.split(/[\r\n]+/).each { |line|
      case line
      when TH::Map_Drops::Set_Ev_Freq_Regex
        @sprite_freq = true
        @set_sprite_freq = $1
      else
        @sprite_freq = nil
      end
      }
    end
  
    def has_setspritefreq?
      amn_setspritefreq if @sprite_freq.nil?
      return @set_sprite_freq
    end
    
  end
 
  class Item < UsableItem
    attr_reader   :chosen_sprite_name
    attr_reader   :chosen_sprite_index
    attr_reader   :chosen_sprite
    attr_reader   :stepping__anim
    attr_reader   :normal__priority
    attr_reader   :front__chara
    attr_reader   :dir_fix_event
    attr_reader   :same_dir_event
    attr_reader   :sprite_dir
    attr_reader   :set_sprite_dir
    attr_reader   :sprite_spd
    attr_reader   :set_sprite_spd
    attr_reader   :sprite_freq
    attr_reader   :set_sprite_freq
    
    def small_item?
      return @small_item unless @small_item.nil?
      res = self.note.match(TH::Map_Drops::Small_Item_Regex)
      return @small_item = !res.nil?
    end
    
    def amn_chosensprite
      self.note.split(/[\r\n]+/).each { |line|
      case line
      when TH::Map_Drops::Sprite_Name_Index_Regex
        @chosen_sprite = true
        @chosen_sprite_name = $1
        @chosen_sprite_index = $2
      end
      }
    end
  
    def has_chosen_sprite?
      amn_chosensprite if @chosen_sprite.nil?
      return @chosen_sprite
    end
    
    def stepping_ev_anim?
      return @stepping__anim unless @stepping__anim.nil?
      res = self.note.match(TH::Map_Drops::Stepping_Anim_Ev_Regex)
      return @stepping__anim = !res.nil?
    end
    
    def normal_ev_priority?
      return @normal__priority unless @normal__priority.nil?
      res = self.note.match(TH::Map_Drops::Normal_Priority_Ev_Regex)
      return @normal__priority = !res.nil?
    end
    
    def front_of_chara?
      return @front__chara unless @front__chara.nil?
      res = self.note.match(TH::Map_Drops::Front_Chara_Ev_Regex)
      return @front__chara = !res.nil?
    end
    
    def dir_fix_event?
      return @dir_fix_event unless @dir_fix_event.nil?
      res = self.note.match(TH::Map_Drops::Dir_Fix_Regex)
      return @dir_fix_event = !res.nil?
    end
    
    def same_dir_event?
      return @same_dir_event unless @same_dir_event.nil?
      res = self.note.match(TH::Map_Drops::Same_Dir_Regex)
      return @same_dir_event = !res.nil?
    end
    
    def amn_setspritedir
      self.note.split(/[\r\n]+/).each { |line|
      case line
      when TH::Map_Drops::Set_Dir_Regex
        @sprite_dir = true
        @set_sprite_dir = $1
      else
        @sprite_dir = nil
      end
      }
    end
  
    def has_setspritedir?
      amn_setspritedir if @sprite_dir.nil?
      return @set_sprite_dir
    end
    
    def amn_setspritespeed
      self.note.split(/[\r\n]+/).each { |line|
      case line
      when TH::Map_Drops::Set_Ev_Speed_Regex
        @sprite_spd = true
        @set_sprite_spd = $1
      else
        @sprite_spd = nil
      end
      }
    end
  
    def has_setspritespeed?
      amn_setspritespeed if @sprite_spd.nil?
      return @set_sprite_spd
    end
    
    def amn_setspritefreq
      self.note.split(/[\r\n]+/).each { |line|
      case line
      when TH::Map_Drops::Set_Ev_Freq_Regex
        @sprite_freq = true
        @set_sprite_freq = $1
      else
        @sprite_freq = nil
      end
      }
    end
  
    def has_setspritefreq?
      amn_setspritefreq if @sprite_freq.nil?
      return @set_sprite_freq
    end
    
  end

end

class Game_System
 
  attr_accessor :mapdrop_useicons
 
  alias :amn_mapdrop_gamesystem_init :initialize
  def initialize
    amn_mapdrop_gamesystem_init
    @mapdrop_useicons = TH::Map_Drops::Use_Icon
  end
 
end


class Game_MapDrop < Game_Drop
 
  def setup_event(x, y)
    if @item.front_of_chara?
      case $game_player.direction
      when 2;  y = ($game_player.y + 1); x = $game_player.x
      when 4;  x = ($game_player.x - 1); y = $game_player.y
      when 6; x = ($game_player.x + 1); y = $game_player.y
      when 8; y = ($game_player.y - 1); x = $game_player.x
      end
    end
    @event = RPG::Event.new(x, y)
    event.pages[0].trigger = 0
    if @item.dir_fix_event?
      event.pages[0].direction_fix = true
    else
      event.pages[0].direction_fix = false
    end
    if @item.stepping_ev_anim?
      event.pages[0].step_anime = 1
    end
    if @item.normal_ev_priority?
      event.pages[0].priority_type = 1
    else
      event.pages[0].priority_type = 0
    end
    if $game_system.mapdrop_useicons == false
      if @item.has_chosen_sprite?
        event.pages[0].graphic.character_name = @item.chosen_sprite_name.to_s
        event.pages[0].graphic.character_index = @item.chosen_sprite_index.to_i
      else
        event.pages[0].graphic.character_name = TH::Map_Drops::Default_Sheet
        event.pages[0].graphic.character_index = TH::Map_Drops::Default_Index
      end
      if @item.same_dir_event?
        event.pages[0].graphic.direction = $game_player.direction
      elsif @item.has_setspritedir?
        event.pages[0].graphic.direction = @item.set_sprite_dir.to_i
      end
      if @item.has_setspritespeed?
        event.pages[0].move_speed = @item.set_sprite_spd.to_i
      end
      if @item.has_setspritefreq?
        event.pages[0].move_frequency = @item.set_sprite_freq.to_i
      end
    end
    event.pages[0].list = []
    add_event_commands(event.pages[0].list)
  end
 

  alias amn_hime_gamemapdrop_addeventcommands   add_event_commands
  def add_event_commands(list)
    if @item.small_item?
      list << RPG::EventCommand.new(108, 0, ["<small_ev>"])
    end
    if $imported[:Theo_LimInventory]
      if @item.is_a?(RPG::Item)
        cmd = 126
      elsif @item.is_a?(RPG::Weapon)
        cmd = 127
      elsif @item.is_a?(RPG::Armor)
        cmd = 128
      end
      case @item.inv_size
      when 0
        list << RPG::EventCommand.new(111, 0, [12, "$game_party.free_slot >= 0"])
      when 1
        list << RPG::EventCommand.new(111, 0, [12, "$game_party.free_slot >= 1"])
      when 2
        list << RPG::EventCommand.new(111, 0, [12, "$game_party.free_slot >= 2"])
      when 3
        list << RPG::EventCommand.new(111, 0, [12, "$game_party.free_slot >= 3"])
      when 4
        list << RPG::EventCommand.new(111, 0, [12, "$game_party.free_slot >= 4"])
      when 5
        list << RPG::EventCommand.new(111, 0, [12, "$game_party.free_slot >= 5"])
      when 6
        list << RPG::EventCommand.new(111, 0, [12, "$game_party.free_slot >= 6"])
      when 7
        list << RPG::EventCommand.new(111, 0, [12, "$game_party.free_slot >= 7"])
      when 8
        list << RPG::EventCommand.new(111, 0, [12, "$game_party.free_slot >= 8"])
      when 9
        list << RPG::EventCommand.new(111, 0, [12, "$game_party.free_slot >= 9"])
      when 10
        list << RPG::EventCommand.new(111, 0, [12, "$game_party.free_slot >= 10"])
      end
      list << RPG::EventCommand.new(250, 1, [RPG::SE.new(TH::Map_Drops::Obtain_SE, 100, 80)])
      list << RPG::EventCommand.new(cmd, 1, [@item.id, 0, 0, @count, false])
      list << RPG::EventCommand.new(101, 1, ["", 0, 0, 2])
      list << RPG::EventCommand.new(401, 1, [sprintf(TH::Map_Drops::Found_Message, display)])
      list << RPG::EventCommand.new(215, 1, [])
      list << RPG::EventCommand.new(411, 0, [])
      list << RPG::EventCommand.new(101, 1, ["", 0, 0, 2])
      list << RPG::EventCommand.new(401, 1, [sprintf(TH::Map_Drops::Deny_Message, display)])
      list << RPG::EventCommand.new
    else
      amn_hime_gamemapdrop_addeventcommands(list)
    end
  end
 
end

class Window_ItemListe < Window_Selectable # Window_ItemList
 
  alias :th_map_drops_process_handling :process_handling
  def process_handling
    return unless open? && active
    return process_drop_item if handle?(:drop) && Input.trigger?(TH::Map_Drops::Drop_Item_Key)
    th_map_drops_process_handling
  end
 
  def process_drop_item
    Sound.play_cursor
    Input.update
    deactivate
    call_handler(:drop)
  end
end

class Scene_Combine < Scene_ItemBase # Scene_Item
 
  alias :th_map_drops_item_window :create_item_window
  def create_item_window
    th_map_drops_item_window
    @item_window.set_handler(:drop, method(:on_item_drop))
  end
 
  def on_item_drop
    # should give confirmation and input
    drop_item
  end
 
  def playerfrontclear?
    event = $game_player
    case event.direction
    when 2;  evy = (event.y + 1); evx = event.x;
    when 4;  evx = (event.x - 1); evy = event.y;
    when 6; evx = (event.x + 1); evy = event.y;
    when 8; evy = (event.y - 1); evx = event.x;
    end
    return true if $game_map.amn_xy_rect_pass_clear?(evx, evy, event.collision_rect)
  end
 
  def drop_item
    item = @item_window.item
    if $game_party.can_drop?(item) && @item_window.combining == false
      if playerfrontclear?
        $game_party.drop_item(item)
        @item_window.refresh
        @freeslot.refresh if $imported[:Theo_LimInventory]
      else
        Sound.play_buzzer
      end
    else
      Sound.play_buzzer
    end
    @item_window.activate
  end
 
end

#==============================================================================
# ** Game_Interpreter
#------------------------------------------------------------------------------
#  An interpreter for executing event commands. This class is used within the
# Game_Map, Game_Troop, and Game_Event classes.
#==============================================================================

class Game_Interpreter

  def mapdrop_useicons(toggle = true)
    $game_system.mapdrop_useicons = toggle
    $game_map.need_refresh = true
  end
 
end


class Sprite_Character < Sprite_Base
    
  alias :amn_th_map_drop_update_char_bitmap :update_bitmap
  def update_bitmap
    
    if $game_system.mapdrop_useicons
      if @character.is_a?(Game_DropEvent)
        set_drop_item_bitmap
      else
        th_map_drop_update_char_bitmap
      end
    else
      th_map_drop_update_char_bitmap
    end
  end
 
 
end