=begin
I'm trying to make it so that if you have a certain kind of item equipped in one 
of your accessory slots, you cannot equip another in the other. 
I'm using Yanfly's Equip Engine to give multiple slots. 
I like the idea of the items still being in the list, just disabled, 
which is why I decided to edit the 'enable?' method. 
I've aliased it because Yanfly edits it in his Equip Engine.
=end
class RPG::BaseItem
 
  #--------------------------------------------------------------------------
  # * Cache - Load Variables                                   # NEW METHOD #
  #--------------------------------------------------------------------------
  def amn_loadnotetag_equiptype
    self.note.split(/[\r\n]+/).each { |line|
    case line
    when /<equiptype:\s+(\w+)>/i
      @equiptype = $1
    else
      @equiptype = nil
    end
    }
  end
 
  #--------------------------------------------------------------------------
  # * Equip Type                                               # NEW METHOD #
  #--------------------------------------------------------------------------
  def equiptype
    amn_loadnotetag_equiptype if @equiptype.nil?
    return @equiptype
  end

end

#==============================================================================
# ** Window_EquipItem
#------------------------------------------------------------------------------
#  This window displays choices when opting to change equipment on the
# equipment screen.
#==============================================================================

class Window_EquipItem < Window_ItemList
  #--------------------------------------------------------------------------
  # * Display in Enabled State?
  #--------------------------------------------------------------------------
  alias amn_windowequipitem_enable?   enable?
  def enable?(item)
    @current_slot = @slot_id
    @other_slot = 11 - @current_slot
    return false if (@current_slot == 5 || @current_slot == 6) && doubleup?(item)
    return amn_windowequipitem_enable?(item)
  end
 
  def doubleup?(item)
    p(@current_slot)
    p(@other_slot)
    return false if item == nil
    return false if item.equiptype == nil
    return false if @actor.equips[@other_slot].nil?
    return false if @actor.equips[@other_slot].equiptype == nil
    return true if item.equiptype == @actor.equips[@other_slot].equiptype
  end
  
end