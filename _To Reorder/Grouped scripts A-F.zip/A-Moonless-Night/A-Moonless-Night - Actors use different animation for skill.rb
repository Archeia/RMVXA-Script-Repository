=begin
#==============================================================================#
#   AMN Actor Animations
#   Version 1.01
#   Author: AMoonlessNight
#   Date: 24 Dec 2018
#   Latest: 24 Dec 2018
#==============================================================================#
#   UPDATE LOG
#------------------------------------------------------------------------------#
# 24 Dec 2018 - created the script
#==============================================================================#
#   TERMS OF USE
#------------------------------------------------------------------------------#
# - Please credit AMoonlessNight or A-Moonless-Night
# - Free for non-commercial use
# - Contact for commercial use
# - I'd love to see your game if you end up using one of my scripts
#==============================================================================#

This script makes it so that you can give items and skills different animation
IDs for different actors.

Use the following notetag in skills and items:

<actor ani: X Y>

where X is the ID of the actor and Y is the ID of the animation.

=end

#==============================================================================
#  Please do not edit below this point unless you know what you are doing.
#==============================================================================

class RPG::UsableItem
  attr_reader   :actor_ani
 
  def load_notetags_actor_ani
    @actor_ani = {}
    self.note.split(/[\r\n]+/).each { |line|
    case line
    when /<actor[ -_]+ani:*\s+(\d+)\s+(\d+)>/i
      @actor_ani[$1.to_i] = $2.to_i
    end
    }
  end
 
end

module DataManager
  class << self; alias :amn_ani_datamanager_loaddatabase :load_database; end

  def self.load_database
    amn_ani_datamanager_loaddatabase
    load_notetags_actor_ani
  end

  def self.load_notetags_actor_ani
    for group in [$data_skills, $data_items]
      for obj in group
        next if obj.nil?
        obj.load_notetags_actor_ani
      end
    end
  end
end

class Scene_Battle < Scene_Base
  alias amn_ani_scenebattle_shownormalanimation show_normal_animation
  def show_normal_animation(targets, animation_id, mirror = false)
    if @subject && @subject.is_a?(Game_Actor) && @subject.current_action && @subject.current_action.item
      if @subject.current_action.item.actor_ani.key?(@subject.id)
        animation_id = @subject.current_action.item.actor_ani[@subject.id]
      end
    end
    amn_ani_scenebattle_shownormalanimation(targets, animation_id, mirror)
  end
end