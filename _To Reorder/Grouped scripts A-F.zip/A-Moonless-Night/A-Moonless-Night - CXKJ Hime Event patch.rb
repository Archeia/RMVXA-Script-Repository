=begin 
Conflict Between Tsukihime's Event Trigger Labels and Gary CXJk's Free Movement
This is the patch
=end 
#==============================================================================
# ** Game_Player
#------------------------------------------------------------------------------
#  This class handles the player. It includes event starting determinants and
# map scrolling functions. The instance of this class is referenced by
# $game_player.
#==============================================================================

class Game_Player < Game_Character
  #-----------------------------------------------------------------------------
  # ALIAS. Check for any valid events in the area
  #-----------------------------------------------------------------------------
  alias amn_eventtriggerlabels_checkevlabtrig check_event_label_trigger
  def check_event_label_trigger
    if $imported["CXJ-FreeMovement"]
      
      positions_to_check_for_event.each do |x, y|
        $game_map.events_xy_rect(x, y, collision_rect).each do |event|
          label = event.check_trigger_label
          
          # If no label was found, check next event
          next unless label
          
          # If the event can run, insert a jump to label command at
          # the beginning before running it
          if check_action_event
            text = [label]
            command = RPG::EventCommand.new(119, 0, text)
            event.list.insert(0, command)
            return true
          end
        end
      end
      return false
    else
      amn_eventtriggerlabels_checkevlabtrig
    end
  end
 
end