if $imported["YEA-LunaticObjects"]
class Scene_Battle < Scene_Base

  alias amn_scenebattle_lunaticobjext lunatic_object_extension
  def lunatic_object_extension(effect, item, user, target, line_number)
    case effect.upcase
    #----------------------------------------------------------------------
    # A skill that checks if the enemy has one of three states, and if
    # they do, write a value to a variable BEFORE the skill damage is
    # calculated
    #
    # Recommended notetag:
    #   <prepare effect: var states x>  where x is the ID of the variable
    #----------------------------------------------------------------------
    when /VAR\s*STATES\s*(\d+)/i
      p(target.states)
      if [1, 2, 3].any?{|s| target.states.include?($data_states[s]) }
      #^alter the array to include as many state IDs as you want
        $game_variables[$1.to_i] += 1
        p($game_variables[$1.to_i])
      end
    #----------------------------------------------------------------------
    # A skill that, after the damage is delt, checks if the target has been
    # killed. If so, than give the user a state. If not, kill the user.
    #
    # Recommended notetag:
    #   <during effect: kamikaze x>   where x is the ID of the state
    #----------------------------------------------------------------------
    when /KAMIKAZE\s*(\d+)\s*/i
      if target.hp == 0
        user.add_state($1.to_i)
      else
        user.hp = 0
        user.perform_collapse_effect
      end
    #----------------------------------------------------------------------
    # A skill that checks both if the attacker is a certain actor, and if
    # the target is weak (over 100% elemental damage) to the skill's element,
    # and if so, inflict them with a state
    #
    # Recommended notetag:
    #   <prepare effect: user element x y>  where x is the ID of the actor
    #   and y is the ID of the state
    #----------------------------------------------------------------------
    when /USER\s*ELEMENT\s*(\d+)\s+(\d+)/i
      if user == $data_actors[$1.to_i] && target.element_rate(item.damage.element_id) < 1.0
        target.add_state($2.to_i)
      end
    else
      amn_scenebattle_lunaticobjext(effect, item, user, target, line_number)
    end
  end
end

class Game_Battler < Game_BattlerBase
  alias amn_userstate_scenebattle_itemapply item_apply
  def item_apply(user, item)
    #----------------------------------------------------------------------
    # A skill that checks if the user has one of a few states, and if not,
    # the skill fails
    #
    # Recommended notetag:
    #   <prepare effect: user states>
    #----------------------------------------------------------------------
    if !item.prepare_effects.select{ |p| p.match(/USER\s*STATES\s*/i)}.empty? &&
      ![1, 2, 3].any?{|s| user.states.include?($data_states[s]) }
      #^alter the array to include as many state IDs as you want
      @result.clear
      @result.used = item_test(user, item)
      @result.missed = true
    else
      amn_userstate_scenebattle_itemapply(user, item)
    end
  end
end
end