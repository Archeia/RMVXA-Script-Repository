# I need something that makes the text fit into the ''box'', 
# by automatically reducing the font size till it fits or something, 
# not for the text to go outside the ''box''.

class Window_BattleEnemy < Window_Selectable
  def draw_item(index)
    change_color(normal_color)
    name = $game_troop.alive_members[index].name
    while text_size(name).width >= item_rect_for_text(index).width do
      contents.font.size -= 1
    end
    draw_text(item_rect_for_text(index), name)
    reset_font_settings
  end
end