=begin
#==============================================================================#
# AMN YEA Class Unlock Levels - Parameter Check addon
# Version 1.03
# Author: AMoonlessNight
# Date: 23 Jul 2018
# Latest: 23 Jul 2018
#==============================================================================#
# UPDATE LOG
#------------------------------------------------------------------------------#
# 23 Jul 2018 - created the script
#==============================================================================#
# TERMS OF USE
#------------------------------------------------------------------------------#
# - Please credit AMoonlessNight or A-Moonless-Night
# - Free for non-commercial use
# - Please follow Yanfly's terms and conditions for the original script
# - I'd love to see your game if you end up using one of my scripts
#==============================================================================#

Requested by FAGC54

This script makes it so that certain classes require actor parameters to be at
a certain amount compared to another parameter.

#------------------------------------------------------------------------------
# Class Notetags - These notetags go in the class notebox in the database.
#------------------------------------------------------------------------------
<param unlock requirements>
class X: level Y: param1 OP param2
</param unlock requirements>
X should be the ID of the class. Y should be the level.

param1 and param2 should be the abbreviated name for the actor's parameters:
MHP Maximum Hit Points
MMP Maximum Magic Points
ATK ATtacK power
DEF DEFense power
MAT Magic ATtack power
MDF Magic DeFense power
AGI AGIlity
LUK LUcK

OP should be the operator you want to use to compare the two parameters:
== is equal to
!= does not equal
< less than
<= less than or equal to
> greater than
>= greater than or equal to

Insert multiple of the strings in between the two opening and closing notetags
to require all of the class levels/parameters to be met.

For example:

<param unlock requirements>
class 2: level 5: atk > def
</param unlock requirements>
will check that class 2's level is greater than 5 and that the actor's attack is
greater than the actor's defense.

#==============================================================================
# Please do not edit below this point unless you know what you are doing.
#==============================================================================
=end
if $imported["YEA-ClassSystem"] && !YEA::CLASS_SYSTEM::MAINTAIN_LEVELS

module YEA
  module REGEXP
    module CLASS

	PARAM_REQ_REGEX =
	/<param[-_ ]*unlock[-_ ]*requirements>(.*?)<\/param[-_ ]*unlock[-_ ]*requirements>/im
	PARAM_UNLOCK_STR =
	/\s*class\s*(\d+):\s*level\s*(\d+):\s*(\w{3})\s*(\<|\>|\<\=|\>\=|\=\=)\s*(\w{3})/i

	end
  end
end

module AMN_Core
  def self.actor_param_string(actor, string)
	par = string.downcase
	case par
	when 'mhp'; actor.param(0)
	when 'mmp'; actor.param(1)
	when 'atk'; actor.param(2)
	when 'def'; actor.param(3)
	when 'mat'; actor.param(4)
	when 'mdf'; actor.param(5)
	when 'agi'; actor.param(6)
	when 'luk'; actor.param(7); end
  end
end

class << DataManager

  alias amn_classparams_datamanager_load_database load_database
  def load_database
	amn_classparams_datamanager_load_database
	load_notetags_class_params
  end

  def load_notetags_class_params
	for obj in $data_classes
	next if obj.nil?
	  obj.load_notetags_class_params
	end
  end
end

class RPG::Class < RPG::BaseItem

  def load_notetags_class_params
	results = self.note.scan(YEA::REGEXP::CLASS::pARAM_REQ_REGEX)
	results.each do |res|
	res[0].strip.split("\r\n").each do |line|
	next unless line =~ YEA::REGEXP::CLASS::pARAM_UNLOCK_STR
	class_id = $1
	level = $2
	param1 = $3
	operator = $4
	param2 = $5
	array = [level.to_i, param1.to_s, operator.to_s, param2.to_s]
	@level_unlock[class_id.to_i] = array
    end
    end
	p("Class: #{@name}, #{@level_unlock}")
  end
end

class Game_Actor < Game_Battler

  def class_unlock_level_requirements_met?(item)
	for key in item.level_unlock
	class_id = key[0]
	if key[1].is_a?(Array)
	  level_req = key[1][0]
	  param1 = AMN_Core.actor_param_string(self, key[1][1])
	  op = key[1][2]
	  param2 = AMN_Core.actor_param_string(self, key[1][3])
	  return false if class_level(class_id) < level_req
	  return false unless eval("#{param1}" + op + "#{param2}")
	else
	  level_req = key[1]
	  return false if class_level(class_id) < level_req
	end
	end
    return true
    end

end
# end