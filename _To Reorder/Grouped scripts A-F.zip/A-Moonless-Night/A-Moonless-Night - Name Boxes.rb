=begin
#============================================================================
#   AMN Auto Nameboxes
#   Version 1.0
#   Author: AMoonlessNight
#   Requires: Yanfly Engine Ace - Ace Message System
#   Date: 27 Apr 2018
#   Latest: 27 Apr 2018
#===========================================================================#
#   UPDATE LOG
#---------------------------------------------------------------------------#
# 27 Apr 2018 - created the script
#===========================================================================#

This script makes it so that a namebox will automatically appear for each
actor in the database, based on their face image.

You can also set up other automatic nameboxes in the editable region below.


To turn off automatic nameboxes, use the script call:
$game_system.autonameboxes = false

To turn them back on, use the script call:
$game_system.autonameboxes = true

They are set to true by default.

Nameboxes set in the message text will take priority over the names set below.


Based on an MV Plugin by SumRndmDde: http://sumrndm.site/automatic-name-boxes/

=end

module AMN_Auto_Nameboxes
  Autonameboxes = {

#==============================================================================
# ** EDITABLE REGION BELOW
#------------------------------------------------------------------------------
#  Change the values in the area below to suit your needs.
#==============================================================================

# Please note that these names take priority over any actor names

  :autoname_1   => {
              :name       =>  "Ralph",
              :facename   =>  "Actor1",
              :index      =>  0,
              },

  :autoname_2   => {
              :name       =>  "Ulrika",
              :facename   =>  "Actor1",
              :index      =>  3,
              },

  :autoname_3   => {
              :name       =>  "Bennett",
              :facename   =>  "Actor2",
              :index      =>  2,
              },
                  
  :autoname_4   => {
              :name       =>  "Ylva",
              :facename   =>  "Actor2",
              :index      =>  5,
              },

  # Copy and paste as needed
  :autoname_5   => {       #   <-- Make sure to give each one a unique number
              :name       =>  "Vera",  # The name you want in the namebox
              :facename   =>  "Actor3", # The name of the face file in Graphics/Faces
              :index      =>  1,        # The index of the face file:
                                          # 0–3 top row, left–right
                                          # 4–7 bottom row, left–right
              },  # <= DO NOT REMOVE

#==============================================================================
# ** END OF EDITABLE REGION
#------------------------------------------------------------------------------
#  Please do not edit below this point unless you know what you are doing.
#==============================================================================

  } # <= DO NOT REMOVE
 
end

$imported = {} if $imported.nil?
if !$imported["YEA-MessageSystem"]
  msg = "                                           IMPORTANT:\n"
  msg += "                 Auto Nameboxes by A-Moonless-Night\n"
  msg += " \n"
  msg += "This script requires Yanfly's Yanfly Engine Ace - Ace Message System.\n"
  msg += "Please download it from https://yanflychannel.wordpress.com/rmvxa/"
  msgbox(msg)
  exit
end

#==============================================================================
# ** Game_System
#------------------------------------------------------------------------------
#  This class handles system data. It saves the disable state of saving and
# menus. Instances of this class are referenced by $game_system.
#==============================================================================

class Game_System
  #--------------------------------------------------------------------------
  # * Public Instance Variables
  #--------------------------------------------------------------------------
  attr_accessor :autonameboxes            # use auto nameboxes
  #--------------------------------------------------------------------------
  # * Object Initialization
  #--------------------------------------------------------------------------
  alias amn_autonamebox_gamesystem_init   initialize
  def initialize
    amn_autonamebox_gamesystem_init
    @autonameboxes = true
  end
 
end

class Game_Interpreter
 
  #--------------------------------------------------------------------------
  # overwrite method: command_101
  #--------------------------------------------------------------------------
  def command_101
    wait_for_message
    $game_message.face_name = @params[0]
    $game_message.face_index = @params[1]
    $game_message.background = @params[2]
    $game_message.position = @params[3]
    while continue_message_string?
      @index += 1
      if @list[@index].code == 401
        #
        namebox = ""
        if $game_system.autonameboxes
          size = $data_actors.size - 1
          actors = (1..size).to_a
          actors.each do |act|
            if $game_message.face_name == $game_actors[act].face_name && $game_message.face_index == $game_actors[act].face_index
              namebox = '\n<' + $game_actors[act].name.to_s + '>'
            end
          end
          auto_nb = AMN_Auto_Nameboxes::Autonameboxes
          auto_nb.each_key do |actor|
            if $game_message.face_name == auto_nb[actor][:facename] && $game_message.face_index == auto_nb[actor][:index]
              namebox = '\n<' + auto_nb[actor][:name].to_s + '>'
            end
          end
        end
        #
        $game_message.add(namebox + @list[@index].parameters[0])
      end
      break if $game_message.texts.size >= Variable.message_rows
    end
    case next_event_code
    when 102
      @index += 1
      setup_choices(@list[@index].parameters)
    when 103
      @index += 1
      setup_num_input(@list[@index].parameters)
    when 104
      @index += 1
      setup_item_choice(@list[@index].parameters)
    end
    wait_for_message
  end

end