=begin
#===============================================================================
#   AMN Item Battlelog Text
#   Version 1.00
#   Author: AMoonlessNight
#   Date: 23 May 2018
#   Latest: 23 May 2018
#==============================================================================#
#   UPDATE LOG
#------------------------------------------------------------------------------#
# 23 May 2018 - created the script
#==============================================================================#
#   TERMS OF USE
#------------------------------------------------------------------------------#
# - Please credit AMoonlessNight or A-Moonless-Night
# - Free for non-commercial use
# - Free for commercial use
# - I'd love to see your game if you end up using one of my scripts
#==============================================================================#

This script makes it so that you can change the text that pops up in the
battlelog when you use an item.

Use the following in an item's notes:

<battle text>
your text goes here
</battle text>

=end

#==============================================================================
#  Please do not edit below this point unless you know what you are doing.
#==============================================================================

module AMN_BattleLogText

  BattleText_Regex = /<battle[-_ ]text>(.*?)<\/battle[-_ ]text>/im

end

class RPG::BaseItem
   attr_reader  :battle_text

   def battle_text
      load_notetag_battletext unless @battle_text
      return @battle_text
    end
   
    def load_notetag_battletext
      battle_text = ""
      results = self.note.scan(AMN_BattleLogText::BattleText_Regex)
      results.each do |res|
        res[0].strip.split("\r\n").each do |line|
          battle_text += line.to_s
        end
      end
      if battle_text != ""
        @battle_text = "%s " + battle_text.to_s + " %s"
      else
        @battle_text = nil
      end
    end
end

class Window_BattleLog < Window_Selectable

  alias amn_itemtext_windowbattlelog_displayuseitem display_use_item
  def display_use_item(subject, item)
    if item.battle_text != nil
      add_text(sprintf(item.battle_text, subject.name, item.name))
    else
      amn_itemtext_windowbattlelog_displayuseitem(subject, item)
    end
  end
end