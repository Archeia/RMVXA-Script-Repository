=begin
================================================================================
 ** Monster Fusion System v1.10
 Diffuculty: Advanced - Crazy
 Author: AwesomeCool
 Date: Jan 19, 2014
 
--------------------------------------------------------------------------------
 ** Change log
  1.10: Jan 20, 2014
    -Fixed game breaking bug
  1.06: Jan 20, 2014
    -added an import set
  1.05: Jan 19, 2014
    -Fixed some lag issues
  1.0: Jan 19, 2014
    -Initial Release
    
--------------------------------------------------------------------------------
 *Requirements

 -Tsukihime Script: Custom Database
 -Some script to change resolution to 640 x 480 (like Yanfly's Ace Core Engine)
 
 -Recommend:
    Some script to lock an actor into party leader spot
    
--------------------------------------------------------------------------------
 * Description
 
  A script that allows the user to fuse together party members to form new party
  members.
  
--------------------------------------------------------------------------------
  *Terms
  
  Free to use for non-commercial work as long as credit is given to AwesomeCool
  
--------------------------------------------------------------------------------
 * How to Use

  -First, set up the monsters to be formed from fusion in the configuration 
  options below.
  -Second, place the approriate note tags in the appropriate actor noteboxes
  -Third, test fusions out.
  
--------------------------------------------------------------------------------
 * Tags
 
    -Actor:
      <fuseable: *>
        Explanation: Makes the actor able to be fused to another actor.
          Replace * with a unique code to the actor that is not shared with any
          other actor.
          
--------------------------------------------------------------------------------
 *Script Calls
 
    -change_fusion_amount_max(number)
      Explanation: Allows you to change the amount of monsters possible to fuse
      together into one monster.  Change number to a value between 2 and 5
      (includes 2 and 5).
      
     - SceneManager.call(Scene_MonsterFuse)
      Explanation: Calls the menus to select which monsters to fuse.

--------------------------------------------------------------------------------
=end

module AwesomeCool #Do not touch this line.
  module FusionSystem #Do not touch this line.
    
#-------------------------------------------------------------------------------
# *Options
    
      #Change the number to any number from 2 to 5.  Represents the maximum
      #monsters that can fuse together into one monster in the game.
      FusionAmountMax = 5
      
      #Change the number to any number from 2 to 5.  Represents the current 
      #maximum monsters that can fuse together into one monster in the game.
      #Can be change during game and cannot exceed FusionAmountMax.
      FusionAmountCurrent = 2
      
#-------------------------------------------------------------------------------
#-------------------------------------------------------------------------------

# *List of monsters that can be formed during fusion (refer to examples below
#  for guideance)

  #Required Options:
    #Id representing the entire monster (for your reference) 
    # Ex: "Brenda" => [
    
    #"name" -> The default name of the actor 
    
    # Ex: ["name", "Brenda"],
    #"Description" -> The short brief about he actor 
      #Ex: ["description", "A girl who's brought up by forest spirits. She loves\n" +
#                          "nature and protects the forest from disturbance."],

    #"note" -> Represents the note box for the actor (this is for note tags).
      #Use \n to represent going to the next line
      #Ex: ["note", "<fuseable: Brenda>"],
      
    #"nickname" -> the nickname of the actor Ex: ["nickname", "Dark Green Aim"],
    #"class_id" -> the id of the class to use for the actor
      #Ex: ["class_id", 6],
    
    #"required_level" -> Level required from party leader to make the monster
    # Ex: ["required_level", 2],
    
    #"initial_level" -> level you get the actor at
    # Ex: ["initial_level", 2],
    
    #"Max_level" -> max level actor can reach
    # Ex: ["max_level", 99],
    
    #"character_name" -> name of image file used for image of actor when on a 
    # map.
    # Ex: ["character_name", "Actor5"],
    
    #"character_index" -> Index of which sprite set to use on the image.
    
    #Reference:
      #[ 0 1 2 3 ]
      #[ 4 5 6 7 }
    
    # Ex: ["character_index", 1],
    
    #"face_name" -> name of image file for the face of actor used in menues and
    # messages.
    # Ex: ["face_name", "Actor5"],
    
    #"face_index" -> index in image of which face image to use.
    
    #Reference:
      #[ 0 1 2 3 ]
      #[ 4 5 6 7 }
    
    # Ex: ["face_index", 1],
    
    #"Features" -> Do not modify but use this line:
    # ["features", []],
    #Note: currently not used
    
    #"Equips" -> [x,y,b,c,d],
      #x = weapon slot (use weapon slot id)
      #y = sheild slot (use a shield slot id)
      #b = chest slot  (use a chest slot id)
      #c = helment slot (use a helmet slot id)
      #d = accsessory slot (use an accsessory slot id)
    # Ex: ["equips", [31,0,0,1,0]],
    #NOTE: duel weiled is currently not supported
    #NOTE: use only equips that teh actor can use
    #NOTE: if using yanfly's equip engine apply rules to this
    
    ###Required Monster###
    #Example:    ["required_monsters",
    #               2, "Natalie", "Terence",
    #               3, "Natalie", "Ernest", "Brenda"
    #            ],
    
    #Figure
    # x, u1, ... ux
    # x, u1, u2, ... ux
    # ...
    
    #Explanation: 
    # x = amount of monsters required to use for the fusion
    #u1 - ux = unique code associated to a actor via notetag.
    #NOTE: you can only have x number of unique codes.
    
#-------------------------------------------------------------------------------
#-------------------------------------------------------------------------------
      
      FusionedMonsters = { #Do not touch this line.
      
        #List Start
      
        "Brenda" => [
          ["name", "Brenda"],
          ["description", "A girl who's brought up by forest spirits. She loves\n" +
                          "nature and protects the forest from disturbance."],
          ["note", "<fuseable: Brenda> \n awesome"],
          ["nickname", "Dark Green Aim"],
          ["class_id", 6],
          ["required_level", 2],
          ["initial_level", 2],
          ["max_level", 99],
          ["character_name", "Actor5"],
          ["character_index", 1],
          ["face_name", "Actor5"],
          ["face_index", 1],
          ["features", []],
          ["equips", [31,0,0,1,0]],
          ["required_monsters",
            2, "Natalie", "Terence",
            2, "Natalie", "Ernest",
          ],
        ], 
        
        "Isabella" => [
          ["name", "Isabella"],
          ["description", "A awesome lady"],
          ["note", "<fuseable: Isabella>"],
          ["nickname", "Awesome"],
          ["class_id", 9],
          ["required_level", 3],
          ["initial_level", 10],
          ["max_level", 99],
          ["character_name", "Actor5"],
          ["character_index", 7],
          ["face_name", "Actor5"],
          ["face_index", 7],
          ["features", []],
          ["equips", [49,0,0,1,0]],
          ["required_monsters",
            2, "Natalie", "Ryoma",
            3, "Terence", "Ernest", "Ryoma",
          ],
        ],
        
      "Noah" => [
          ["name", "Noah"],
          ["description", "A awesome Man"],
          ["note", "<fuseable: Noah>"],
          ["nickname", "Awesome and Manly"],
          ["class_id", 10],
          ["required_level", 1],
          ["initial_level", 1],
          ["max_level", 99],
          ["character_name", "Actor5"],
          ["character_index", 6],
          ["face_name", "Actor5"],
          ["face_index", 6],
          ["features", []],
          ["equips", [0,0,0,0,0]],
          ["required_monsters",
            2, "Ernest", "Terence",
            4, "Terence", "Ernest", "Ryoma", "Alice"
          ],
        ],
        
        "Monster Boss" => [
          ["name", "Monster Boss"],
          ["description", "A awesome Evil Man"],
          ["note", "<fuseable: Noah>"],
          ["nickname", "Awesome, Manly and Evil"],
          ["class_id", 1],
          ["required_level", 1],
          ["initial_level", 99],
          ["max_level", 99],
          ["character_name", "Monster1"],
          ["character_index", 7],
          ["face_name", "Monster1"],
          ["face_index", 7],
          ["features", []],
          ["equips", [0,0,0,0,0]],
          ["required_monsters",
            2, "Noah", "Isabella",
          ],
        ], 
        
        "The Reap" => [
          ["name", "The Reap"],
          ["description", "A awesome Evil Thing"],
          ["note", "<fuseable: Noah>"],
          ["nickname", "Awesome, Thingy and Evil"],
          ["class_id", 1],
          ["required_level", 1],
          ["initial_level", 99],
          ["max_level", 99],
          ["character_name", "Monster1"],
          ["character_index", 6],
          ["face_name", "Monster1"],
          ["face_index", 6],
          ["features", []],
          ["equips", [0,0,0,0,0]],
          ["required_monsters",
            5, "Terence", "Ernest", "Ryoma", "Alice", "Natalie"
          ],
        ],
        
      #End List
        
      } #Do not touch this line.
  end #Do not touch this line.
end #Do not touch this line.

#-------------------------------------------------------------------------------
#-------------------------------------------------------------------------------
#-------------------------------------------------------------------------------
#-------------------------------------------------------------------------------
### DO NOT EDIT BEYOND THIS POINT ###
#-------------------------------------------------------------------------------
#-------------------------------------------------------------------------------
#-------------------------------------------------------------------------------
#-------------------------------------------------------------------------------

$imported = {} if $imported.nil?
$imported["AwesomeCool-FusionSystem"] = true

class Game_Interpreter
  def change_fusion_amount_max(number)
    FusionSystem.set_maxcurrent(number)
  end
end

module DataManager
  
  #--------------------------------------------------------------------------
  # alias method: load_database
  #--------------------------------------------------------------------------
  class <<self; alias load_database_fusionsystem load_database; end
  def self.load_database
    load_database_fusionsystem
    load_notetags_fusion
  end
  
  #--------------------------------------------------------------------------
  # new method: load_notetags_abe
  #--------------------------------------------------------------------------
  def self.load_notetags_fusion
    groups = [$data_actors]
    for group in groups
      for obj in group
        next if obj.nil?
        obj.load_notetags_fusion
      end
    end
  end
  
  def self.reloadnotetags
    load_notetags_fusion
  end
  
end # DataManager

class RPG::Actor < RPG::BaseItem
    
  attr_accessor :fuseable
  attr_accessor :selectable
  attr_accessor :identification
  
  def load_notetags_fusion
    @fuseable = false
    @selectable = false
    @identification = ""
    #---
    self.note.split(/[\r\n]+/).each { |line|
      case line
      #---
      when /<(?:fuseable):[ ](.*)>/i
        @identification = $1.to_s
        @fuseable = true
        @selectable = true
      end
    } # self.note.split
    #---
  end
  
  def fuseable?
    return fuseable
  end
  
  def selected?
    return selectable
  end
  
  def select_time
    selectable = false
  end
  
  def unselect
    selectable = true
  end
#~   
end

class Game_Actor < Game_Battler
    
  attr_accessor :identification
  
  alias fusion_setup setup
  def setup(actor_id)
    if actor_id != $data_actors.length+1
      fusion_setup(actor_id)
      @selectable = $data_actors[actor_id].selectable
      @fuseable = actor.fuseable
      @identification = actor.identification
    else
      actor_id = $data_actors.length - 1
      fusion_setup(actor_id)
      @selectable = $data_actors[actor_id].selectable
      @fuseable = actor.fuseable
      @identification = actor.identification
    end
  end
  
  def fuseable?
    return @fuseable
  end
  
  def selectable?
    return @selectable
  end
  
  def select_time
    @selectable = false
  end
  
  def unselect
    @selectable = true
  end
  
  def create_temp(temp)
    @name = temp.name
    @nickname = temp.nickname
    set_graphic(temp.character_name, temp.character_index, temp.face_name, temp.face_index)
    @class_id = temp.class_id
    @level = temp.initial_level
    @exp = {}
    @equips = []
    init_exp
    init_skills
    init_equips(temp.equips)
    clear_param_plus
    recover_all
  end
  
end


module FusionSystem
  
  def self.init
    @fusionsystem = FusionTime.new
    if @maxcurrent.nil?
      @maxcurrent = AwesomeCool::FusionSystem::FusionAmountCurrent
    end
    @able = false
    @max = 0
  end
  
  def self.set_maxcurrent(number)
    @maxcurrent = number
  end
  
  def self.get_maxcurrent
    return @maxcurrent
  end
  
  def self.reset_selection
    $game_party.members.each do |actor|
      if actor.fuseable?
        actor.unselect
      end
    end
  end
  
  def self.get_list_of_fuseable_inital(maxchoices = 2, choiceone = nil, choicetwo = nil, choicethree = nil, choicefour = nil)
    list_of_monsters = []
    $game_party.members.each do |actor|
       if actor.selectable?
        if @fusionsystem.check_fuseable(maxchoices, choiceone, choicetwo, choicethree, choicefour, actor)
          list_of_monsters.push(actor)
        end
       end
    end
    return list_of_monsters
  end

  def self.getCurrentSelection
    list_of_monsters = []
    $game_party.members.each do |actor|
      if !actor.selectable? and actor.fuseable?
        list_of_monsters.push(actor)
      end
    end
    return list_of_monsters
  end
  
  def self.find_best_match(list)
    return @fusionsystem.find_best_match(list)
  end
  
  def self.able_set(temp)
    @able = temp
  end
  
  def self.setmax(max)
    @max = max
  end
  
  def self.able?
    return @able
  end
  
  def self.getmax
    return @max
  end
  
  def self.fuse(actor)
    id = CustomData.add_actor(actor)
    
    list = getCurrentSelection
    
    list.each do |member|
      $game_party.remove_actor(member.id)
    end
    
     DataManager.reloadnotetags
    
    $game_party.add_actor(id)
    
  end
  
end

class Fusion
  
  attr_accessor :name
  attr_accessor :description
  attr_accessor :note
  attr_accessor :nickname
  attr_accessor :class_id
  attr_accessor :required_level
  attr_accessor :initial_level
  attr_accessor :max_level
  attr_accessor :character_name
  attr_accessor :character_index
  attr_accessor :face_name
  attr_accessor :face_index
  attr_accessor :features
  attr_accessor :equips
  attr_accessor :required_monsters
  
  def initialize
    @name = ""
    @description = ""
    @note = ""
    @nickname = ""
    @class_id = 0
    @required_level = 0
    @initial_level = 0
    @max_level = 0
    @character_name = ""
    @character_index = 0
    @face_name = ""
    @face_index = 0
    @featuers = []
    @equips = []
    @required_monsters = []
  end
  
  def set_name(temp)
    @name = temp
  end
  
  def set_description(temp)
    @description = temp
  end
  
  def set_note(temp)
    @note = sprintf(temp)
  end
  
  def set_nickname(temp)
    @nickname = temp
  end
  
  def set_class_id(temp)
    @class_id = temp
  end
  
  def set_required_level(temp)
    @required_level = temp
  end
  
  def set_initial_level(temp)
    @initial_level = temp
  end
  
  def set_max_level(temp)
    @max_level = temp
  end
  
  def set_character_name(temp)
    @character_name = temp
  end
  
  def set_character_index(temp)
    @character_index = temp
  end
  
  def set_face_name(temp)
    @face_name = temp
  end
  
  def set_face_index(temp)
    @face_index = temp
  end
  
  def set_features(temp)
    @features = temp
  end
  
  def set_equips(temp)
    @equips = temp
  end
  
  def set_required_monsters(temp)
    maximum = 0
    count = 0
    monster_list = []
    temp.each do |arraytime|
      if count >= maximum
        count = 0
        if monster_list == []
          monster_list = []
          monster_list.push(arraytime)
          maximum = arraytime
        else
          required_monsters.push(monster_list)
          monster_list = []
          monster_list.push(arraytime)
          maximum = arraytime
        end
      else
        count = count + 1
        monster_list.push(arraytime)
      end
    end
  end
  
  def able_to_fuse?(maxchoice, choiceone, choicetwo, choicethree, choicefour, option)
    correct = false
    onefound = false
    twofound = false
    threefound = false
    fourfound = false
    check = false
    required_monsters.each do |monster|
      maxchoice = monster[0]
      
      correct = false
      onefound = false
      twofound = false
      threefound = false
      fourfound = false
      check = false
      
      if maxchoice == FusionSystem.getmax
        count = 1
        while count <= maxchoice
          if choiceone != nil
            if monster[count] == choiceone.identification
              onefound = true
            end
          else
            onefound = true
          end
        
          if choicetwo != nil
            if monster[count] == choicetwo.identification
              twofound = true
            end
          else
            twofound = true
          end
        
          if choicethree != nil
            if monster[count] == choicethree.identification
              threefound = true
            end
          else
            threefound = true
          end
        
          if choicefour != nil
            if monster[count] == choicefour.identification
              fourfound = true
            end
          else
            fourfound = true
          end 
          
          count = count + 1
          
        end
        
        if onefound and twofound and threefound and fourfound
          check = true
        end
        
        count = 1
        
        if choiceone != nil
          if choicetwo != nil
            if choicethree != nil
              if choicefour != nil
                while count <= maxchoice
                  if monster[count] != choiceone.identification and monster[count] != choicetwo.identification and monster[count] != choicethree.identification and monster[count] != choicefour.identification and monster[count] == option.identification
                    correct = true
                  end
                  count = count + 1
                end
              else
                while count <= maxchoice
                  if monster[count] != choiceone.identification and monster[count] != choicetwo.identification and monster[count] != choicethree.identification and monster[count] == option.identification
                    correct = true
                  end
                  count = count + 1
                end
              end
            else
              while count <= maxchoice
                if monster[count] != choiceone.identification and monster[count] != choicetwo.identification and monster[count] == option.identification
                  correct = true
                end
                count = count + 1
              end
            end
          else
            while count <= maxchoice
              if monster[count] != choiceone.identification and monster[count] == option.identification
                correct = true
              end
              count = count + 1
            end
          end
        else
          correct = true
        end
      end
      
      if correct and check
        return true
      end
      
    end
  return false
  end
  
  def match?(list)
    match = true
    required_monsters.each do |monster|
      match = true
      maxchoice = monster[0]
      if maxchoice == FusionSystem.getmax
        list.each do |member|
          tempmatch = false
          count = 1
          while count <= maxchoice
            if monster[count] == member.identification
              tempmatch = true
            end
            count = count + 1
          end
          if tempmatch == false
            match = false
          end
        end
      else
        match = false
      end
    
      if match      
        return match
      end
      
    end
    
    return match
    
  end
  
end

class FusionTime
  
  def initialize 
    @fusion_list = []
    fusion_object = nil
    AwesomeCool::FusionSystem::FusionedMonsters.each { |id, value|
      fusion_object = Fusion.new
      value.each {  |valuetemp|
        identification = valuetemp[0]
        valuetwo = valuetemp[1]
        if identification == "name"
          fusion_object.set_name(valuetwo)
        end
        if identification == "description"
          fusion_object.set_description(valuetwo)
        end
        if identification == "note"
          fusion_object.set_note(valuetwo)
        end
        if identification == "nickname"
          fusion_object.set_nickname(valuetwo)
        end
        if identification == "class_id"
          fusion_object.set_class_id(valuetwo)
        end
        if identification == "required_level"
          fusion_object.set_required_level(valuetwo)
        end
        if identification == "initial_level"
          fusion_object.set_initial_level(valuetwo)
        end
        if identification == "max_level"
          fusion_object.set_max_level(valuetwo)
        end
        if identification == "character_name"
          fusion_object.set_character_name(valuetwo)
        end
        if identification == "character_index"
          fusion_object.set_character_index(valuetwo)
        end
        if identification == "face_name"
          fusion_object.set_face_name(valuetwo)
        end
        if identification == "face_index"
          fusion_object.set_face_index(valuetwo)
        end
        if identification == "features"
          fusion_object.set_features(valuetwo)
        end
        if identification == "equips"
          fusion_object.set_equips(valuetwo)
        end
        if identification == "required_monsters"
          count = 2
          valuetwo = []
          valuetwo.push(valuetemp[1])
          while count <= valuetemp.length
            valuetwo.push(valuetemp[count])
            count = count + 1
          end
          fusion_object.set_required_monsters(valuetwo)
        end
      }
      @fusion_list.push(fusion_object)
    }
  end
  
  def check_fuseable(maxchoice, choiceone, choicetwo, choicethree, choicefour, option)
    @fusion_list.each do |fusion_object|
      if fusion_object.able_to_fuse?(maxchoice, choiceone, choicetwo, choicethree, choicefour, option)
        return true
      end
    end
    
    return false
  end
  
  def find_best_match(list)
    @fusion_list.each do |member|
      if member.match?(list)
        return member
      end
    end
    return nil
  end
  
end

class Window_MonsterFuseAmount < Window_Command
  
    
  def make_command_list
    add_command("two" , :fusetwo)
    if FusionSystem.get_maxcurrent > 2
      add_command("three" , :fusethree)
    end
    if FusionSystem.get_maxcurrent > 3
      add_command("four" , :fusefour)
    end
    if FusionSystem.get_maxcurrent > 4
      add_command("Five" , :fusefive)
    end
  end
  
  def set_help(window)
    @help_window = window
    update_help
  end
  
  def update_help
    if self.active == true
      if @index == 0
        @help_window.set_text("Fuse two monsters together.")
      elsif @index == 1
        @help_window.set_text("Fuse three monsters together.")
      elsif @index == 2
        @help_window.set_text("Fuse four monsters together.")
      else
        @help_window.set_text("Fuse five monsters together.")
     end
   end
 end
 
  def visible_line_number
    return 2
  end
  
end

class Window_Help < Window_Base
  def initialize(line_number = 2, x = 0, y = 0)
    super(x, y, Graphics.width - x, fitting_height(line_number))
  end
end


class Monster_Fuse_List < Window_Selectable
  
  def initialize(x, y, width, height)
    super(x, y, width, height)
    @Choiceone = nil
    @Choicetwo = nil
    @Choicethree = nil
    @Choicefour = nil
    @Choicefive = nil
    @numberneeded = 0
    draw_all_items
  end
  
  def set_numberneeded(numberneeded)
    @numberneeded = numberneeded
  end
  
  def set_next_choice
    list = FusionSystem.get_list_of_fuseable_inital(@numberneeded, @Choiceone, @Choicetwo, @Choicethree, @Choicefour)
    choice = list[@index]
    set_next_choice_time(choice)
  end
  
  def set_previous_choice
    if @Choicefive != nil
      @Choicefive.unselect
      @Choicefive = nil
    elsif @Choicefour != nil
      @Choicefour.unselect
      @Choicefour = nil
    elsif @Choicethree != nil
      @Choicethree.unselect
      @Choicethree = nil
    elsif @Choicetwo != nil
      @Choicetwo.unselect
      @Choicetwo = nil
    elsif @Choiceone != nil
      @Choiceone.unselect
      @Choiceone = nil
    end 
  end
  
  def set_next_choice_time(choice)
    if @Choiceone == nil
      @Choiceone = choice
      choice.select_time
    elsif @Choicetwo == nil
      @Choicetwo = choice
      choice.select_time
    elsif @Choicethree == nil
      @Choicethree = choice
      choice.select_time
    elsif @Choicefour == nil
      @Choicefour = choice
      choice.select_time
    elsif @Choicefive == nil
      @Choicefive = choice
      choice.select_time
    end
  end
  
  def process_ok
    if current_item_enabled?
      list = FusionSystem.get_list_of_fuseable_inital(@numberused, @Choiceone, @Choicetwo, @Choicethree, @Choicefour)
      if list.length == 0
        Sound.play_buzzer
      else
        Sound.play_ok
        Input.update
        deactivate
        call_ok_handler
      end
    else
      Sound.play_buzzer
    end
  end
  
  def reset_time
    @Choiceone = nil
    @Choicetwo = nil
    @Choicethree = nil
    @Choicefour = nil
    @Choicefive = nil
    @numberneeded = 0
    contents.clear
  end

  def item_max
     list = FusionSystem.get_list_of_fuseable_inital(@numberused, @Choiceone, @Choicetwo, @Choicethree, @Choicefour)
     return list.length
  end
  
  def redraw
    contents.clear
    @index = 0
    draw_all_items
  end
  
  def draw_item(index)
    list = FusionSystem.get_list_of_fuseable_inital(@numberused, @Choiceone, @Choicetwo, @Choicethree, @Choicefour)
    
    actor = list[index]
    
    rect = item_rect(index)
    draw_item_background(index)
    draw_face(actor.character_name, actor.character_index, rect.x, rect.y)
    draw_actor_simple_status(actor, rect.x, rect.y)
  end
  
  def draw_item_background(index)
    if index == @pending_index
      contents.fill_rect(item_rect(index), pending_color)
    end
  end
  
  def draw_actor_simple_status(actor, x, y)
    draw_actor_name(actor, x, y)
    draw_actor_level(actor, x, y + line_height * 1)
    draw_actor_class(actor, x, y + line_height * 2)
  end
  
  def item_height
    return line_height * 4
  end
  
  def row_max
     list = FusionSystem.get_list_of_fuseable_inital(@numberused, @Choiceone, @Choicetwo, @Choicethree, @Choicefour)
    return list.length+ 2#$game_party.members.length
  end
  
end

class Selected_display_Window < Window_Help
  
  def initialize(line_height, x, y)
    super
    create_text
  end
  
  def update
    return
  end
  
  def create_text
    set_text("Current Selection: ")
  end
  
end
  
class Sample_display_Window < Window_Help
  
  def initialize(line_height, x, y)
    super
    create_text
  end
  
  def update
    return
  end
  
  def create_text
    set_text("Result: ")
  end
  
end

class Selected_List < Window_Base
  
  def initialize(x, y, width)
    super(x,y,width,item_height+25)
    @selected_list = FusionSystem.getCurrentSelection
    draw_all_items
  end
  
  def redraw
    @selected_list = FusionSystem.getCurrentSelection
    contents.clear
    draw_all_items
  end
  
  def spacing
    return 32
  end
  
  def draw_all_items
    item_max.times {|i| draw_item(i) }
  end
  
  def item_width
    (width - standard_padding * 2 + spacing) / col_max - spacing
  end
  
  def item_rect(index)
    rect = Rect.new
    rect.width = item_width
    rect.height = item_height
    rect.x = index % col_max * (item_width + spacing)
    rect.y = index / col_max * item_height
    rect
  end
  
  def item_max
    #list = FusionSystem.get_list_of_fuseable_inital(@numberused, @Choiceone, @Choicetwo, @Choicethree, @Choicefour)
    return 0 if @selected_list.nil?
    return @selected_list.length
  end
  
  def draw_item(index)
    actor = @selected_list[index]
    
    rect = item_rect(index)
    draw_face(actor.character_name, actor.character_index, rect.x, rect.y)
    draw_actor_simple_status(actor,  rect.x, rect.y)
  end
  
  def draw_actor_simple_status(actor, x, y)
    draw_actor_name(actor, x, y)
    draw_actor_level(actor, x, y + line_height * 1)
    draw_actor_class(actor, x, y + line_height * 2)
  end
  
  def item_height
    return line_height * 4
  end
  
  def col_max
    return 5
  end
  
end


class Monster_Sample_Window < Window_Selectable
  
  def initialize(x, y, width)
    super(x,y,width,(line_height * 4) + 25)
    @best_match = nil
    @match_actor = nil
  end
#~   
#~   def update
#~     return
#~   end
  
  def make_temp_actor
    contents.clear
    @selected_list = []
    @selected_list = FusionSystem.getCurrentSelection
    @best_match = FusionSystem.find_best_match(@selected_list)
    @match_temp = create_temp
    if !@match_temp.nil?
      @match_actor = Game_Actor.new($data_actors.length+1)
      @match_actor.create_temp(@match_temp)
      draw_match
    end
  end
  
  def create_temp
    if @best_match.nil?
      return nil
    end
    
    temp_actor = RPG::Actor.new
    
    temp_actor.name = @best_match.name
    
    temp_actor.description = @best_match.description
    
    temp_actor.features = @best_match.features
    
    temp_actor.note = @best_match.note
    
    temp_actor.class_id = @best_match.class_id
    
    temp_actor.nickname = @best_match.nickname
    
    temp_actor.initial_level = @best_match.initial_level
    
    temp_actor.max_level = @best_match.max_level
    
    temp_actor.character_name = @best_match.character_name
    
    temp_actor.character_index = @best_match.character_index
    
    
    temp_actor.face_name = @best_match.face_name
    
    temp_actor.face_index = @best_match.face_index
    
    temp_actor.equips = @best_match.equips
    
    return temp_actor
    
  end
  
  def draw_match
    if !@match_actor.nil?
      draw_item
      draw_stats
    end
  end
  
  def draw_item
    actor = @match_actor

    rect = item_rect(0)
    draw_face(actor.character_name, actor.character_index, rect.x, rect.y)
    draw_actor_simple_status(actor,  rect.x, rect.y)
  end
  
  def draw_actor_simple_status(actor, x, y)
    draw_actor_name(actor, x, y)
    draw_actor_level(actor, x, y + line_height * 1)
    draw_actor_class(actor, x, y + line_height * 2)
  end
  
  def draw_stats
    
    if $game_party.leader.level < @best_match.required_level
      FusionSystem.able_set(false)
    else
      FusionSystem.able_set(true)
    end
    
    rect = item_rect(1)
    
    draw_parameters(rect.x-10, rect.y, 0, 4)
    rect = item_rect(2)
    draw_parameters(rect.x-20, rect.y, 4, 8)
    
  end
  
  def draw_parameters(x, y, amount, max)
    init = amount
    while amount < max
      draw_actor_param(@match_actor, x, y + line_height * (amount - init), amount)
      amount = amount  + 1
    end
  end
  
  def cleardata
    contents.clear
  end
  
  def item_height
    return line_height * 4
  end
  
  def col_max
    return 3
  end
  
  def get_actor
    return @match_temp
  end
  
end

class Fusion_Status_Window < Window_Base
  
  def initialize(x, y, width, height)
    super
  end
  
  def update
    return
  end
  
  def able_check(able)
    list = FusionSystem.getCurrentSelection
    if able and FusionSystem.getmax == list.length
      create_text("Fusion is good to go!", text_color(24))
    elsif FusionSystem.getmax != list.length
      create_text("Monsters needed " + (FusionSystem.getmax - list.length).to_s, text_color(25))
    else
      create_text("Not high enough level!", text_color(25))
    end
    change_color(text_color(0))
  end
  
  def redraw
    contents.clear
    able_check(FusionSystem.able?)
  end
  
  def clear
    contents.clear
  end
  
  def create_text(text,color)
    if text != @text
      @text = text
    end
    change_color(color)
    draw_text_ex(0, 0, @text)
    
  end
  
  def line_height
    return 24
  end
  
  def draw_text_ex(x, y, text)
    text = convert_escape_characters(text)
    pos = {:x => x, :y => y, :new_x => x, :height => calc_line_height(text)}
    process_character(text.slice!(0, 1), text, pos) until text.empty?
    reset_font_settings
  end
  
end

class Fusion_Confirm_Window < Window_Selectable
  def initialize(x, y, width, height)
    super
    create_text(false, "Fuse!")
    @index = 0
  end
  
  def create_text(able, text)
    change_color(text_color(0), able)
    if text != @text
      @text = text
    end
    
    draw_item(0)
    
    contents.font.size = 35
    
    draw_text_ex(40, 0, @text)
  end
   
  def draw_item(index)
    rect = item_rect(index)
  end
  
  def item_rect(index)
    rect = Rect.new
    rect.width = 146
    rect.height = 40
    rect.x = 0
    rect.y = 0
    rect
  end
  
  def line_height
    return 40
  end

  def draw_text_ex(x, y, text)
    text = convert_escape_characters(text)
    pos = {:x => x, :y => y, :new_x => x, :height => calc_line_height(text)}
    process_character(text.slice!(0, 1), text, pos) until text.empty?
    reset_font_settings
  end
  
  def redraw
    contents.clear
    create_text(FusionSystem.able?, @text)
  end
  
  def clear
    contents.clear
    create_text(false, @text)
  end
  
  def process_ok
    if current_item_enabled?
      if !FusionSystem.able?
        Sound.play_buzzer
      else
        Sound.play_ok
        Input.update
        deactivate
        call_ok_handler
      end
    else
      Sound.play_buzzer
    end
  end
  
end

class Popup_Confim_Window < Window_Selectable
  def initialize(x, y, width, height)
    super
    create_text("Are you sure?", "Yes", "No")
    @index = 0
  end
  
  def create_text(text, texttwo, textthree)
    
    rect = item_rect(0)
    
    draw_text_ex(0, 0, text)
    
    draw_text_ex(rect.x+1, rect.y, texttwo)
    
    rect = item_rect(1)

    draw_text_ex(rect.x+1, rect.y, textthree)
    
  end
  
  def item_rect(index)
    rect = Rect.new
    rect.width = 31 - 10 * index
    rect.height = line_height * 1
    rect.x = 0 + 40 * index
    rect.y = line_height * 1
    rect
  end
  
  def col_max
    return 2
  end
  
  def item_max
    return 2
  end
  
  def get_index
    return @index
  end
  
end

class Scene_MonsterFuse < Scene_MenuBase
  def start
    super
    FusionSystem.init
    create_background
    create_windows
  end

  def create_windows
    create_help_window
    create_command_window
    create_monster_list
    create_selected_list
    create_sample_window
    create_confirmation_window
  end
  
  def create_help_window
    @help_window = Window_Help.new(2,160)
  end
  
  def create_command_window
    @myCmd = Window_MonsterFuseAmount.new(0,0)
     @myCmd.set_help(@help_window)
    create_mycmd_handlers
  end
  
  def create_monster_list
    @monster_window = Monster_Fuse_List.new(0, @help_window.height, Graphics.width/5, Graphics.height - @help_window.height)
    create_monster_window_handlers
  end
  
  def create_selected_list
    @selected_display = Selected_display_Window.new(1, @monster_window.width, @help_window.height)
    @selected_window =  Selected_List.new(@monster_window.width, @help_window.height+@selected_display.height , Graphics.width - @monster_window.width)
  end
  
  def create_sample_window
    @sample_display = Sample_display_Window.new(1, @monster_window.width, @help_window.height + @selected_window.height + @selected_display.height)
    @sample_window = Monster_Sample_Window.new(@monster_window.width, @help_window.height + @selected_window.height + @selected_display.height + @sample_display.height, Graphics.width - @monster_window.width)
  end 
  
  def create_confirmation_window
    @able_window = Fusion_Status_Window.new(@monster_window.width,@help_window.height + @selected_window.height + @selected_display.height + @sample_display.height + @sample_window.height, (Graphics.width - @monster_window.width) * 2 / 3, Graphics.height - (@help_window.height + @selected_window.height + @selected_display.height + @sample_display.height + @sample_window.height))
    @confirmation_window = Fusion_Confirm_Window.new(@monster_window.width+@able_window.width,@help_window.height + @selected_window.height + @selected_display.height + @sample_display.height + @sample_window.height, (Graphics.width - @monster_window.width) / 3, Graphics.height - (@help_window.height + @selected_window.height + @selected_display.height + @sample_display.height + @sample_window.height))
    create_confirmation_window_hadlers
  end

  def create_mycmd_handlers
    @myCmd.set_handler(:fusetwo , method(:fusetwotime))
    
    if FusionSystem.get_maxcurrent > 2
      @myCmd.set_handler(:fusethree, method(:fusethreetime))
    end
    
    if FusionSystem.get_maxcurrent > 3
      @myCmd.set_handler(:fusefour , method(:fusefourtime))
    end
    
    if FusionSystem.get_maxcurrent > 4
      @myCmd.set_handler(:fusefive , method(:fusefivetime))
    end
    
    @myCmd.set_handler(:cancel,    method(:return_scene))
  end
  
  def create_monster_window_handlers
    @monster_window.set_handler(:ok , method(:choosenext))
    @monster_window.set_handler(:cancel , method(:priorchoice))
  end
  
  def create_confirmation_window_hadlers
    @confirmation_window.set_handler(:ok , method(:fusion))
    @confirmation_window.set_handler(:cancel , method(:priorchoice))
  end
  
  def fusetwotime
    @numberneeded = 2
    FusionSystem.setmax(@numberneeded)
    @monster_window.set_numberneeded(@numberneeded)
    @monster_window.redraw
    @numbercurrentlyselected = 0
    @monster_window.activate
  end
  
  def fusethreetime
    @numberneeded = 3
    FusionSystem.setmax(@numberneeded)
    @monster_window.set_numberneeded(@numberneeded)
    @monster_window.redraw
    @numbercurrentlyselected = 0
    @monster_window.activate
  end
  
  def fusefourtime
    @numberneeded = 4
    FusionSystem.setmax(@numberneeded)
    @monster_window.set_numberneeded(@numberneeded)
    @monster_window.redraw
    @numbercurrentlyselected = 0
    @monster_window.activate
  end
  
  def fusefivetime
    @numberneeded = 5
    FusionSystem.setmax(@numberneeded)
    @monster_window.set_numberneeded(@numberneeded)
    @monster_window.redraw
    @numbercurrentlyselected = 0
    @monster_window.activate
  end
  
  def choosenext
    @numbercurrentlyselected = @numbercurrentlyselected + 1
    
    if @numbercurrentlyselected == @numberneeded
      @monster_window.set_next_choice
      @monster_window.redraw
      @selected_window.redraw
      @sample_window.make_temp_actor
      @able_window.redraw
      @confirmation_window.redraw
      @confirmation_window.activate
    elsif @numbercurrentlyselected < 2
      @monster_window.set_next_choice
      @selected_window.redraw
      @sample_window.cleardata
      @able_window.redraw
      @confirmation_window.redraw
      @monster_window.redraw
      @monster_window.activate
      @able_window.redraw
    else
      @monster_window.set_next_choice
      @selected_window.redraw
      @sample_window.make_temp_actor
      @able_window.redraw
      @confirmation_window.redraw
      @monster_window.redraw
      @monster_window.activate
    end
    
  end
  
  def priorchoice
    @numbercurrentlyselected = @numbercurrentlyselected - 1
    
    if @numbercurrentlyselected < 0
      @selected_window.update
      @sample_window.cleardata
      @able_window.clear
      @confirmation_window.clear
      @myCmd.activate
    elsif @numbercurrentlyselected < 2
      @monster_window.set_previous_choice
      @selected_window.redraw
      @sample_window.cleardata
      @able_window.redraw
      @confirmation_window.redraw
      @monster_window.redraw
      @monster_window.activate
    elsif @numbercurrentlyselected > 0
      @monster_window.set_previous_choice
      @selected_window.redraw
      @sample_window.make_temp_actor
      @able_window.redraw
      @confirmation_window.redraw
      @monster_window.redraw
      @monster_window.activate
      
    else
      @monster_window.set_previous_choice
      @selected_window.update
      @sample_window.cleardata
      @able_window.clear
      @confirmation_window.clear
      @monster_window.redraw
      @monster_window.activate
    end
  end
  
  def fusion
    @popup_window = Popup_Confim_Window.new(Graphics.width/2 - 160/2, Graphics.height/2 - 75/2, 160, 75)
    @popup_window.activate
    create_popup_window_handlers
  end
  
  def create_popup_window_handlers
    @popup_window.set_handler(:ok , method(:end_fusion))
    @popup_window.set_handler(:cancel, method(:back))
  end
  
  def back
    @popup_window.close
    @confirmation_window.activate
  end
  
  def end_fusion
    if @popup_window.get_index == 1
      back
    else
      FusionSystem.fuse(@sample_window.get_actor)
      process_end
    end
  end
  
  def process_end
    @help_window.close
    @myCmd.close
    @monster_window.close
    @selected_display.close
    @selected_window.close
    @sample_display.close
    @sample_window.close
    @able_window.close
    @confirmation_window.close
    @popup_window.close
    return_scene
  end
  
end