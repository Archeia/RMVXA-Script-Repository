#==============================================================================|
#  ** DoubleX RMVXA Buy Addon v1.00a to Galv's Pawn Shop                       |
#------------------------------------------------------------------------------|
#  * Changelog                                                                 |
#    v1.00a(GMT 0300 15-4-2014):                                               |
#    - 1st version of this script finished                                     |
#------------------------------------------------------------------------------|
#  * Author                                                                    |
#    DoubleX:                                                                  |
#    - This script                                                             |
#    Galv:                                                                     |
#    - Galv's Pawn Shop                                                        |
#------------------------------------------------------------------------------|
#  * Terms of use                                                              |
#    Same as that of Galv's Pawn Shop except that you must also give Galv      |
#    credits(you should do this anyway) if you give DoubleX or his alias credit|
#------------------------------------------------------------------------------|
#  * Prerequisites                                                             |
#    Scripts:                                                                  |
#    - Galv's Pawn Shop                                                        |
#    Knowledge:                                                                |
#    That of using the script Galv's Pawn Shop                                 |
#------------------------------------------------------------------------------|
#  * Functions                                                                 |
#    - Adds the 'buy' version of Galv's Pawn Shop                              |
#------------------------------------------------------------------------------|
#  * Manual                                                                    |
#    To use this script, open the script editor and put this script into an    |
#    open slot below the script Galv's Pawn Shop but above ▼ Main. Save to take|
#    effect.                                                                   |
#------------------------------------------------------------------------------|
#  * Compatibility                                                             |
#    Same as that of Galv's Pawn Shop                                          |
#==============================================================================|

$imported = {} if $imported.nil?
$imported["DoubleX RMVXA Buy Addon to Pawn_Shop"] = true

#==============================================================================|
#  ** You only need to edit this part as it's about what this script does      |
#------------------------------------------------------------------------------|

module DoubleX_RMVXA
  module Pawn_Shop_Buy_Addon

#------------------------------------------------------------------------------|
#  * BUY_SWITCH_ID, default = 0                                                |
#    If BUY_SWITCH_ID > 0, switch with id BUY_SWITCH_ID will set pawn shops to |
#    be buy and sell shops when that switch is flipped on and off respectively |
#------------------------------------------------------------------------------|
    BUY_SWITCH_ID = 0

#------------------------------------------------------------------------------|
#  * BUY_VALUE_VARIABLE_ID, default = 0                                        |
#    If BUY_VALUE_VARIABLE_ID > 0, variable with id BUY_VALUE_VARIABLE_ID will |
#    multiply the buying price in pawn shops by the value of that variable     |
#    divided by 100                                                            |
#------------------------------------------------------------------------------|
    BUY_VALUE_VARIABLE_ID = 0

#------------------------------------------------------------------------------|
#  * BUY_SE, default = ["", 80, 100]                                           |
#    BUY_SE is the SE with ["file name without extension", volume, pitch]      |
#    played upon buying items in pawn shops. ["", volume, pitch] means that the|
#    default shop sound will be played with volume volume and pitch pitch      |
#------------------------------------------------------------------------------|
    BUY_SE = ["", 80, 100]

  end # Pawn_Shop_Buy_Addon
end # DoubleX_RMVXA

#==============================================================================|

#==============================================================================|
#  ** You need not edit this part as it's about how this script works          |
#------------------------------------------------------------------------------|

if $imported["Pawn_Shop"]

class Window_PawnShopBuy < Window_ItemList

  #----------------------------------------------------------------------------|
  #  New method: initialize                                                    |
  #----------------------------------------------------------------------------|
  def initialize(x, y, width, height, shop_goods)
    super(x, y, width, height)
    @shop_goods = shop_goods
  end # initialize

  #----------------------------------------------------------------------------|
  #  New method: current_item_enabled?                                         |
  #----------------------------------------------------------------------------|
  def current_item_enabled?
    enable?(@data[index])
  end # current_item_enabled?

  #----------------------------------------------------------------------------|
  #  New method: enable?                                                       |
  #----------------------------------------------------------------------------|
  def enable?(item)
    item
  end # enable?

  #----------------------------------------------------------------------------|
  #  New method: make_item_list                                                |
  #----------------------------------------------------------------------------|
  def make_item_list
    @data = []
    @price = {}
    @shop_goods.each do |goods|
      case goods[0]
      when 0;  item = $data_items[goods[1]]
      when 1;  item = $data_weapons[goods[1]]
      when 2;  item = $data_armors[goods[1]]
      end
      if item
        @data.push(item)
      end
    end
  end # make_item_list

  #----------------------------------------------------------------------------|
  #  New method: draw_item_number                                              |
  #----------------------------------------------------------------------------|
  def draw_item_number(rect, item)
  end # draw_item_number

end # Window_PawnShopBuy

class Scene_PawnShop < Scene_MenuBase

  PawnShop_SE = ["DoubleX_RMVXA::Pawn_Shop_Buy_Addon::BUY_SE", "Pawn_Shop::SELL_SE"]
  #----------------------------------------------------------------------------|
  #  Rewrite method: start                                                     |
  #----------------------------------------------------------------------------|
  def start
    super
    create_help_window
    create_gold_window
    create_rate_window
    create_command_window
    create_dummy_window
    create_number_window
    create_status_window
    # This part is rewritten by this script to create buy or sell window according to pawnshop_buy?
    pawnshop_buy? ? create_buy_window : create_sell_window
    #
  end # start

  #----------------------------------------------------------------------------|
  #  Rewrite method: create_command_window                                     |
  #----------------------------------------------------------------------------|
  def create_command_window
    @command_window = Window_PawnCommand.new(@gold_window.x, @purchase_only)
    @command_window.viewport = @viewport
    @command_window.y = @help_window.height
    @command_window.width = Graphics.width - @gold_window.width - @rate_window.width
    # This part is rewritten by this script to set buy or sell handler according to pawnshop_buy?
    eval("@command_window.set_handler(" + (pawnshop_buy? ? ":buy, method(:command_buy))" : ":sell, method(:command_sell))"))
    #
    @command_window.set_handler(:cancel, method(:return_scene))
  end # create_command_window

  #----------------------------------------------------------------------------|
  #  Rewrite method: on_number_ok                                              |
  #----------------------------------------------------------------------------|
  def on_number_ok
    # This part is rewritten by this script to play buy or sell se and do buy or sell according to pawnshop_buy?
    pawn_shop_se = pawnshop_buy? ? PawnShop_SE[0] : PawnShop_SE[1]
    if eval(pawn_shop_se + "[0]") == ""
      Sound.play_shop
    else
      eval("RPG::SE.new(" + pawn_shop_se + "[0], " + pawn_shop_se + "[1], " + pawn_shop_se + "[2]).play")
    end
    pawnshop_buy? ? do_buy(@number_window.number) : do_sell(@number_window.number)
    #
    end_number_input
    @gold_window.refresh
    @status_window.refresh
  end # on_number_ok

  #----------------------------------------------------------------------------|
  #  Rewrite method: end_number_input                                          |
  #----------------------------------------------------------------------------|
  def end_number_input
    @number_window.hide
    # This part is rewritten by this script to activate buy or sell window according to pawnshop_buy?
    pawnshop_buy? ? activate_buy_window : activate_sell_window
    #
  end # end_number_input

  #----------------------------------------------------------------------------|
  #  New method: create_buy_window                                             |
  #----------------------------------------------------------------------------|
  def create_buy_window
    wy = @dummy_window.y
    wh = Graphics.height - wy
    @buy_window = Window_PawnShopBuy.new(0, wy, Graphics.width, wh, @goods)
    @buy_window.viewport = @viewport
    @buy_window.help_window = @help_window
    @buy_window.hide
    @buy_window.set_handler(:ok,     method(:on_buy_ok))
    @buy_window.set_handler(:cancel, method(:on_buy_cancel))
  end # create_buy_window

  #----------------------------------------------------------------------------|
  #  New method: activate_buy_window                                           |
  #----------------------------------------------------------------------------|
  def activate_buy_window
    @buy_window.refresh
    @buy_window.show.activate
    @status_window.hide
  end # activate_buy_window

  #----------------------------------------------------------------------------|
  #  New method: command_buy                                                   |
  #----------------------------------------------------------------------------|
  def command_buy
    @dummy_window.hide
    @buy_window.show
    activate_buy_window
    @buy_window.select(0)
    @buy_window.refresh
  end # command_buy

  #----------------------------------------------------------------------------|
  #  New method: on_buy_ok                                                     |
  #----------------------------------------------------------------------------|
  def on_buy_ok
    @item = @buy_window.item
    @status_window.item = @item
    @buy_window.hide
    @number_window.set(@item, max_buy, buying_price, currency_unit)
    @number_window.show.activate
    @status_window.show
  end # on_buy_ok

  #----------------------------------------------------------------------------|
  #  New method: on_buy_cancel                                                 |
  #----------------------------------------------------------------------------|
  def on_buy_cancel
    @command_window.activate
    @dummy_window.show
    @buy_window.hide
    @buy_window.unselect
    @status_window.item = nil
    @help_window.clear
  end # on_buy_cancel

  #----------------------------------------------------------------------------|
  #  New method: do_buy                                                        |
  #----------------------------------------------------------------------------|
  def do_buy(number)
    $game_party.lose_gold(number * buying_price)
    $game_party.gain_item(@item, number)
  end # do_buy

  #----------------------------------------------------------------------------|
  #  New method: max_buy                                                       |
  #----------------------------------------------------------------------------|
  def max_buy
    max = $game_party.max_item_number(@item) - $game_party.item_number(@item)
    buying_price == 0 ? max : [max, money / buying_price].min
  end # max_buy

  #----------------------------------------------------------------------------|
  #  New method: buying_price                                                  |
  #----------------------------------------------------------------------------|
  def buying_price
    ((@item.price * 0.01) * [(buy_price - equip_bonus - actor_bonus), 0].max).round
  end # buying_price

  #----------------------------------------------------------------------------|
  #  New method: buy_price                                                     |
  #----------------------------------------------------------------------------|
  def buy_price
    DoubleX_RMVXA::Pawn_Shop_Buy_Addon::BUY_VALUE_VARIABLE_ID > 0 ? $game_variables[DoubleX_RMVXA::Pawn_Shop_Buy_Addon::BUY_VALUE_VARIABLE_ID] : 100
  end # buy_price

  #----------------------------------------------------------------------------|
  #  New method: pawnshop_buy?                                                 |
  #----------------------------------------------------------------------------|
  def pawnshop_buy?
    DoubleX_RMVXA::Pawn_Shop_Buy_Addon::BUY_SWITCH_ID > 0 && $game_switches[DoubleX_RMVXA::Pawn_Shop_Buy_Addon::BUY_SWITCH_ID]
  end # pawnshop_buy?

end # Scene_PawnShop

class Window_Rate < Window_Base

  Buy_Sell_Value = ["DoubleX_RMVXA::Pawn_Shop_Buy_Addon::BUY_VALUE_VARIABLE_ID", "Pawn_Shop::SALE_VALUE_VAR"]
  #----------------------------------------------------------------------------|
  #  Rewrite method: value                                                     |
  #----------------------------------------------------------------------------|
  def value
    # This part is rewritten by this script to set value according to switch with id BUY_SWITCH_ID
    buysell_value = DoubleX_RMVXA::Pawn_Shop_Buy_Addon::BUY_SWITCH_ID > 0 && $game_switches[DoubleX_RMVXA::Pawn_Shop_Buy_Addon::BUY_SWITCH_ID] ? Buy_Sell_Value[0] : Buy_Sell_Value[1]
    eval("$game_variables[" + buysell_value + "] + equip_bonus + actor_bonus")
    #
  end # value

end # Window_Rate < Window_Base
 
class Window_PawnCommand < Window_HorzCommand

  #----------------------------------------------------------------------------|
  #  Rewrite method: value                                                     |
  #----------------------------------------------------------------------------|
  def make_command_list
    # This part is added by this script to add buy or sell command according to switch with id BUY_SWITCH_ID
    eval("add_command(" + (DoubleX_RMVXA::Pawn_Shop_Buy_Addon::BUY_SWITCH_ID > 0 && $game_switches[DoubleX_RMVXA::Pawn_Shop_Buy_Addon::BUY_SWITCH_ID] ? "Vocab::ShopBuy, :buy)" : "Vocab::ShopSell, :sell)"))
    #
    add_command(Vocab::ShopCancel, :cancel)
  end
   
end # Window_PawnCommand

#------------------------------------------------------------------------------|

end # if $imported["Pawn_Shop"]

#==============================================================================|