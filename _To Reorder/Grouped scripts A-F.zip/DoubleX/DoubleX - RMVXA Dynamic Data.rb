#==============================================================================|
#  ** Script Info                                                              |
#------------------------------------------------------------------------------|
#  * Script Name                                                               |
#    DoubleX RMVXA Dynamic Data                                                |
#------------------------------------------------------------------------------|
#  * Functions                                                                 |
#    Stores the changes to the database done by users during game executions   |
#    Can't be used with data having contents that can't be serialized          |
#    Can't be used with data read from the database files upon use             |
#------------------------------------------------------------------------------|
#  * Terms Of Use                                                              |
#    You shall keep this script's Script Info part's contents intact           |
#    You shalln't claim that this script is written by anyone other than       |
#    DoubleX or his aliases                                                    |
#    None of the above applies to DoubleX or his aliases                       |
#------------------------------------------------------------------------------|
#  * Prerequisites                                                             |
#    Abilities:                                                                |
#    1. Custom script comprehensions to edit that script's used data stored in |
#       RPG::BaseItem and/or its subclasses                                    |
#------------------------------------------------------------------------------|
#  * Instructions                                                              |
#    1. Open the script editor and put this script into an open slot between   |
#       Materials and Main, save to take effect.                               |
#------------------------------------------------------------------------------|
#  * Links                                                                     |
#    Script Usage 101:                                                         |
#    1. forums.rpgmakerweb.com/index.php?/topic/32752-rmvxa-script-usage-101/  |
#    2. rpgmakervxace.net/topic/27475-rmvxa-script-usage-101/                  |
#    This script:                                                              |
#    1. [url]http://pastebin.com/upEe5FZQ[/url]                                |
#------------------------------------------------------------------------------|
#  * Authors                                                                   |
#    DoubleX                                                                   |
#------------------------------------------------------------------------------|
#  * Changelog                                                                 |
#    v1.01a(GMT 0100 12-11-2015):                                              |
#    1. Lets users set which parts of the database changes will be saved       |
#    v1.00b(GMT 0600 8-8-2015):                                                |
#    1. Fixed using edited data bug when starting new game without closing it  |
#    2. Increased this script's compatibility, efficiency and readability      |
#    v1.00a(GMT 0400 16-5-2015):                                               |
#    1. 1st version of this script finished                                    |
#==============================================================================|

($doublex_rmvxa ||= {})[:Dynamic_Data] = "v1.01a"

module DoubleX_RMVXA

  module Dynamic_Data

    # Sets if this script will save the actor parts of the database changes in
    # savefiles as SAVE_ACTORS
    # It can't be changed once set
    # Example: To always reload the original actor parts of the database upon
    #          loading savefiles, set this as false
    SAVE_ACTORS = true

    # Sets if this script will save the class parts of the database changes in
    # savefiles as SAVE_CLASSES
    # It can't be changed once set
    # Example: To always reload the original class parts of the database upon
    #          loading savefiles, set this as false
    SAVE_CLASSES = true

    # Sets if this script will save the skill parts of the database changes in
    # savefiles as SAVE_SKILLS
    # It can't be changed once set
    # Example: To always reload the original skill parts of the database upon
    #          loading savefiles, set this as false
    SAVE_SKILLS = true

    # Sets if this script will save the item parts of the database changes in
    # savefiles as SAVE_ITEMS
    # It can't be changed once set
    # Example: To always reload the original item parts of the database upon
    #          loading savefiles, set this as false
    SAVE_ITEMS = true

    # Sets if this script will save the weapon parts of the database changes in
    # savefiles as SAVE_WEAPONS
    # It can't be changed once set
    # Example: To always reload the original weapon parts of the database upon
    #          loading savefiles, set this as false
    SAVE_WEAPONS = true

    # Sets if this script will save the armor parts of the database changes in
    # savefiles as SAVE_ARMORS
    # It can't be changed once set
    # Example: To always reload the original armor parts of the database upon
    #          loading savefiles, set this as false
    SAVE_ARMORS = true

    # Sets if this script will save the enemy parts of the database changes in
    # savefiles as SAVE_ENEMIES
    # It can't be changed once set
    # Example: To always reload the original enemy parts of the database upon
    #          loading savefiles, set this as false
    SAVE_ENEMIES = true

    # Sets if this script will save the troop parts of the database changes in
    # savefiles as SAVE_TROOPS
    # It can't be changed once set
    # Example: To always reload the original troop parts of the database upon
    #          loading savefiles, set this as false
    SAVE_TROOPS = true

    # Sets if this script will save the state parts of the database changes in
    # savefiles as SAVE_STATES
    # It can't be changed once set
    # Example: To always reload the original state parts of the database upon
    #          loading savefiles, set this as false
    SAVE_STATES = true

    # Sets if this script will save the animation parts of the database changes
    # in savefiles as SAVE_ANIMATIONS
    # It can't be changed once set
    # Example: To always reload the original animation parts of the database
    #          upon loading savefiles, set this as false
    SAVE_ANIMATIONS = true

    # Sets if this script will save the tileset parts of the database changes in
    # savefiles as SAVE_TILESETS
    # It can't be changed once set
    # Example: To always reload the original tileset parts of the database upon
    #          loading savefiles, set this as false
    SAVE_TILESETS = true

    # Sets if this script will save the common event parts of the database
    # changes in savefiles as SAVE_COMMON_EVENTS
    # It can't be changed once set
    # Example: To always reload the original common event parts of the database
    #          upon loading savefiles, set this as false
    SAVE_COMMON_EVENTS = true

    # Sets if this script will save the system parts of the database changes in
    # savefiles as SAVE_SYSTEM
    # It can't be changed once set
    # Example: To always reload the original system parts of the database upon
    #          loading savefiles, set this as false
    SAVE_SYSTEM = true

  end # Dynamic_Data
    
end # DoubleX_RMVXA

#==============================================================================|
#  ** Script Implementations                                                   |
#     You need not edit this part as it's about how this script works          |
#------------------------------------------------------------------------------|
#  * Script Support Info:                                                      |
#    1. Prerequisites                                                          |
#       - Some RGSS3 scripting proficiency to fully comprehend this script     |
#    2. Method documentation                                                   |
#       - The 1st part describes why this method's rewritten/aliased for       |
#         rewritten/aliased methods or what the method does for new methods    |
#       - The 2nd part describes what the arguments of the method are          |
#       - The 3rd part informs which version rewritten, aliased or created this|
#         method                                                               |
#       - The 4th part informs whether the method's rewritten or new           |
#       - The 5th part informs whether the method's a real or potential hotspot|
#       - The 6th part describes how this method works for new methods only,   |
#         and describes the parts added, removed or rewritten for rewritten or |
#         aliased methods only                                                 |
#       Example:                                                               |
# #--------------------------------------------------------------------------| |
# #  Why rewrite/alias/What this method does                                 | |
# #--------------------------------------------------------------------------| |
# # *argv: What these variables are                                            |
# # &argb: What this block is                                                  |
# def def_name(*argv, &argb) # Version X+; Rewrite/New; Hotspot                |
#   # Added/Removed/Rewritten to do something/How this method works            |
#   def_name_code                                                              |
#   #                                                                          |
# end # def_name                                                               |
#------------------------------------------------------------------------------|

class << DataManager # Edit

  #----------------------------------------------------------------------------|
  #  Stores the modified database parts to the save files as well              |
  #----------------------------------------------------------------------------|
  alias save_game_without_rescue_dynamic_data save_game_without_rescue
  def save_game_without_rescue(index, &argb)
    # Added
    ["actors", "classes", "skills", "items", "weapons", "armors", "enemies", 
     "troops", "states", "animations", "tilesets", "common_events", 
     "system"].each { |type|
      next unless eval("DoubleX_RMVXA::Dynamic_Data::SAVE_#{type.upcase}")
      $game_system.send(:"data_#{type}=", eval("$data_#{type}"))
    }
    #
    save_game_without_rescue_dynamic_data(index, &argb)
  end # save_game_without_rescue

  #----------------------------------------------------------------------------|
  #  Retrieves the modified database parts from the save files as well         |
  #----------------------------------------------------------------------------|
  alias extract_save_contents_dynamic_data extract_save_contents
  def extract_save_contents(contents, &argb)
    extract_save_contents_dynamic_data(contents, &argb)
    # Added
    ["actors", "classes", "skills", "items", "weapons", "armors", "enemies", 
     "troops", "states", "animations", "tilesets", "common_events", 
     "system"].each { |type|
      next unless eval("DoubleX_RMVXA::Dynamic_Data::SAVE_#{type.upcase}")
      eval("$data_#{type} = $game_system.data_#{type}")
    }
    #
  end # extract_save_contents

end # DataManager

class Game_System # Edit

  #----------------------------------------------------------------------------|
  #  New public instance variables                                             |
  #----------------------------------------------------------------------------|
  # The modified database parts to be stored to/retrieved from save files
  ["actors", "classes", "skills", "items", "weapons", "armors", "enemies", 
   "troops", "states", "animations", "tilesets", "common_events", 
   "system"].each { |type| attr_accessor eval(":data_#{type}") }

end # Game_System

class Scene_Title < Scene_Base # v1.00b+; Edit

  #----------------------------------------------------------------------------|
  #  Resets the database for starting a new game without closing it as well    |
  #----------------------------------------------------------------------------|
  alias start_dynamic_data start
  def start(*argv, &argb)
    start_dynamic_data(*argv, &argb)
    DataManager.load_database # Added
  end # start

end # Scene_Title

#==============================================================================|