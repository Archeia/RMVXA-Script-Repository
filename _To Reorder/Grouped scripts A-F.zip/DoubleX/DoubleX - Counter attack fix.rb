#------------------------------------------------------------------------------|
#  * (v1.01a+)Notetag <mev invoke cnt> for actors, classes, equips, enemies and|
#    states:                                                                   |
#    To set a battler having chance based on his/her/its CNT to invoke         |
#    counterattack upon successful magic evasion, put the above notetag into   |
#    the related actor's, class's, equip's, enemy's or state's notebox in the  |
#    database.                                                                 |
#------------------------------------------------------------------------------|
#  * Notetag <counterattack skill: x> for actors(1), classes(2), equips(3),    |
#    enemies(1) and states(4):(the larger the number, the higher the priority) |
#    To alter a battler's counterattack skill's id to x, put the above notetag |
#    into the related actor's, class's, equip's, enemy's or state's notebox in |
#    the database.                                                             |
#------------------------------------------------------------------------------|


#==============================================================================|
#  ** You only need to edit this part as it's about what this script does      |
#------------------------------------------------------------------------------|

module DoubleX_RMVXA
  module Counterattack_Edit

#------------------------------------------------------------------------------|
#  * (v1.05a+)Keep_Ani, default = false                                        |
#    If Keep_Ani is true, the counterattack skill's animations will be played  |
#    when the counterattack's invoked                                          |
#------------------------------------------------------------------------------|
    Keep_Ani = false

#------------------------------------------------------------------------------|
#  * (v1.05a+)Keep_Scope, default = false                                      |
#    If Keep_Scope is true, the counterattack skill's scope will stay intact,  |
#    otherwise it'll only target the one attacked that battler                 |
#------------------------------------------------------------------------------|
    Keep_Scope = false

#------------------------------------------------------------------------------|
#  * (v1.05a+)Keep_Times, default = false                                      |
#    If Keep_Scope is true, the counterattack skill's repeats will stay intact,|
#    otherwise it'll be 1                                                      |
#------------------------------------------------------------------------------|
    Keep_Times = false

#------------------------------------------------------------------------------|
#  * (v1.04a+)Actor_Learn_Counterattack_Skill, default = false                 |
#    If Actor_Learn_Counterattack_Skill is true and an actor hasn't learnt the |
#    counterattack skill, Default_Counterattack will be that actor's skill     |
#------------------------------------------------------------------------------|
    Actor_Learn_Counterattack_Skill = false

#------------------------------------------------------------------------------|
#  * (v1.03a+)CNT_Negate_Hit, default = true                                   |
#    Normal physical hit and damage determinations will take place before that |
#    of CNT if CNT_Negate_Hit is false                                         |
#------------------------------------------------------------------------------|
    CNT_Negate_Hit = true

#------------------------------------------------------------------------------|
#  * (v1.02a+)COUNTERATTACK_MESSAGE, default = true                            |
#    Counterattack messages won't be shown if COUNTERATTACK_MESSAGE is false   |
#------------------------------------------------------------------------------|
    COUNTERATTACK_MESSAGE = true

#------------------------------------------------------------------------------|
#  * (v1.01a+)MEV_Invoke_CNT, default = false                                  |
#    Successful magic evasion invokes counterattack with chance based on CNT if|
#    MEV_Invoke_CNT is true, even when <mev invoke cnt> notetags are absent    |
#------------------------------------------------------------------------------|
    MEV_Invoke_CNT = false

#------------------------------------------------------------------------------|
#  * Default_Counterattack, default = 1                                        |
#    The counterattack skill of a battler will be the one's id equal to        |
#    Default_Counterattack if he/she/it doesn't have any notetag               |
#------------------------------------------------------------------------------|
  Default_Counterattack = 1

  end # Counterattack_Edit
end # DoubleX_RMVXA

#==============================================================================|