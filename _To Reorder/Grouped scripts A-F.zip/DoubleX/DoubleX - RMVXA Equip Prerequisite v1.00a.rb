#==============================================================================|
#  ** DoubleX RMVXA Equip Prerequisite v1.00a                                  |
#------------------------------------------------------------------------------|
#  * Changelog                                                                 |
#    v1.00a(GMT 1200 25-5-2014):                                               |
#    - 1st version of this script finished                                     |
#------------------------------------------------------------------------------|
#  * Author                                                                    |
#    DoubleX                                                                   |
#------------------------------------------------------------------------------|
#  * Terms of use                                                              |
#    None other than not claiming this script as created by anyone except      |
#    DoubleX or his alias                                                      |
#------------------------------------------------------------------------------|
#  * Prerequisites                                                             |
#    Scripts:                                                                  |
#    - none                                                                    |
#    Knowledge:                                                                |
#    - Use of notetags                                                         |
#------------------------------------------------------------------------------|
#  * Functions                                                                 |
#    - Allows users to add prerequisites for equipments to actors              |
#------------------------------------------------------------------------------|
#  * Manual                                                                    |
#    To use this script, open the script editor and put this script into an    |
#    open slot between ▼ Materials and ▼ Main. Save to take effect.            |
#------------------------------------------------------------------------------|
#  * Compatibility                                                             |
#    Scripts aliasing or rewriting method:                                     |
#    - self.load_database under module DataManager                             |
#    - equippable? under class Game_BattlerBase                                |
#    may have compatibility issues with this script                            |
#    Place this script above those aliasing any of these methods if possible   |
#==============================================================================|

$imported = {} if $imported.nil?
$imported["DoubleX RMVXA Equip Prerequisite"] = true

#------------------------------------------------------------------------------|
#  * Notetag <armor req: id> for weapons/armors                                |
#    To make a weapon or armor requiring an equipped armor with id id to be    |
#    equipped, put the above notetag into its notebox in the database.         |
#------------------------------------------------------------------------------|
#  * Notetag <stat req: stat, operator, value> for weapons/armors              |
#    To make a weapon or armor requiring stat to fulfill the operator and value|
#    requirement to be equipped, put the above notetag into its notebox in the |
#    database.                                                                 |
#    stat can be Parameter, Ex-Parameter, Sp-Parameter, hp, mp, tp, level,     |
#    hp_rate, mp_rate, tp_rate, element_rate(element_id),                      |
#    debuff_rate(param_id) or state_rate(state_id).                            |
#    (Needs scripting knowledge)It also includes any other numerical method    |
#    under class Game_BattlerBase, Game_Battler, Game_Actor or Game_Enemy.     |
#    operator can be either l, le, e, ge, g or ne. They stand for <, <=, ==,   |
#    >=, > and != respectively.                                                |
#------------------------------------------------------------------------------|
#  * Notetag <var req: id, operator, value> for weapons/armors                 |
#    To make a weapon or armor requiring variable with id id to fulfill the    |
#    operator and value requirement to be equipped, put the above notetag into |
#    its notebox in the database.                                              |
#    operator can be either l, le, e, ge, g or n. They stand for <, <=, ==,    |
#    >=, > and != respectively.                                                |
#------------------------------------------------------------------------------|

#==============================================================================|
#  ** You need not edit this part as it's about how this script works          |
#------------------------------------------------------------------------------|

module DoubleX_RMVXA
  module REGEXP
    module EQUIPITEM

      ARMOR_REQ = /<(?:ARMOR_REQ|armor req):[ ]*(\d+)>/i
      STAT_REQ = /<(?:STAT_REQ|stat req):[ ](\w+(?:\s*,\s*\w+)*)>/i
      VAR_REQ = /<(?:VAR_REQ|var req):[ ](\w+(?:\s*,\s*\w+)*)>/i

    end # EQUIPITEM
  end # REGEXP
end # DoubleX_RMVXA

module DataManager

  EQUIP_PREREQUISITE = ["armor", "stat", "var"]

  #----------------------------------------------------------------------------|
  #  Alias method: self.load_database                                          |
  #----------------------------------------------------------------------------|
  class <<self; alias load_database_equip_prerequisite load_database; end
  def self.load_database
    load_database_equip_prerequisite
    # This part is added by this script to load equip prerequisite notetags
    load_notetags_equip_prerequisite
    #
  end # self.load_database

  #----------------------------------------------------------------------------|
  #  New method: self.load_notetags_equip_prerequisite                         |
  #----------------------------------------------------------------------------|
  def self.load_notetags_equip_prerequisite
    groups = [$data_armors, $data_weapons]
    for group in groups
      for obj in group
        next if obj.nil?
        obj.load_notetags_equip_prerequisite
      end
    end
  end # self.load_notetags_equip_prerequisite

end # DataManager

class RPG::EquipItem

  #----------------------------------------------------------------------------|
  #  New public instance variable                                              |
  #----------------------------------------------------------------------------|
    DataManager::EQUIP_PREREQUISITE.each { |note| eval("attr_accessor :" + note + "_req") }

  #----------------------------------------------------------------------------|
  #  New common cache: load_notetags_equip_prerequisite                        |
  #----------------------------------------------------------------------------|
  def load_notetags_equip_prerequisite
    DataManager::EQUIP_PREREQUISITE.each { |note| eval("@" + note + "_req = []") }
    self.note.split(/[\r\n]+/).each { |line|
      case line
      when DoubleX_RMVXA::REGEXP::EQUIPITEM::ARMOR_REQ
        @armor_req.push($1.to_i)
      when DoubleX_RMVXA::REGEXP::EQUIPITEM::STAT_REQ
        $1.scan(/\w+/).each_with_index { |input, index|
          @stat_req.push(index % 3 == 2 ? input.to_f : input.to_s)
        }
      when DoubleX_RMVXA::REGEXP::EQUIPITEM::VAR_REQ
        $1.scan(/\w+/).each_with_index { |input, index|
          @var_req.push(index % 3 == 1 ? input.to_s : input.to_i)
        }
      end
    }
  end # load_notetags_equip_prerequisite

end # RPG::EquipItem

class Game_BattlerBase

  #----------------------------------------------------------------------------|
  #  Alias method : equippable?                                                |
  #----------------------------------------------------------------------------|
  alias equip_prerequisite_equippable? equippable?
  def equippable?(item)
    # This part is added by this script to apply the equip prerequisites
    return false if !equip_req?(item)
    #
    equip_prerequisite_equippable?(item)
  end # equippable?

  #----------------------------------------------------------------------------|
  #  New method : equip_req?                                                   |
  #----------------------------------------------------------------------------|
  def equip_req?(item)
    return actor? && item.is_a?(RPG::EquipItem) && armor_req?(item) && stat_req?(item) && var_req?(item)
  end # equip_req?

  #----------------------------------------------------------------------------|
  #  New method : armor_req?                                                   |
  #----------------------------------------------------------------------------|
  def armor_req?(item)
    if item.armor_req.size > 0
      item.armor_req.each { |req|
        return false if !armors.include?($data_armors[req])
      }
    end
    return true
  end # armor_req?

  #----------------------------------------------------------------------------|
  #  New method : stat_req?                                                    |
  #----------------------------------------------------------------------------|
  def stat_req?(item)
    if item.stat_req.size > 0 && item.stat_req.size % 3 == 0
      stat = nil
      operator = nil
      item.stat_req.each_with_index { |req, i|
        if i % 3 == 0
          stat = req
        elsif i % 3 == 1
          operator = equip_req_operator(req)
        else
          return false if !eval(stat + " " + operator + " req")
        end
      }
    end
    return true
  end # stat_req?

  #----------------------------------------------------------------------------|
  #  New method : var_req?                                                     |
  #----------------------------------------------------------------------------|
  def var_req?(item)
    if item.var_req.size > 0 && item.var_req.size % 3 == 0
      var = 0
      operator = nil
      item.var_req.each_with_index { |req, i|
        if i % 3 == 0
          var = "$game_variables[req]"
        elsif i % 3 == 1
          operator = equip_req_operator(req)
        else
          return false if !eval(var + " " + operator + " req")
        end
      }
    end
    return true
  end # var_req?

  #----------------------------------------------------------------------------|
  #  New method : equip_req_operator                                           |
  #----------------------------------------------------------------------------|
  def equip_req_operator(operator)
    case operator
    when "l"
      return "<"
    when "le"
      return "<="
    when "e"
      return "=="
    when "ge"
      return ">="
    when "g"
      return ">"
    when "n"
      return "!="
    end
    return nil
  end # equip_req_operator

end # Game_BattlerBase

#==============================================================================|