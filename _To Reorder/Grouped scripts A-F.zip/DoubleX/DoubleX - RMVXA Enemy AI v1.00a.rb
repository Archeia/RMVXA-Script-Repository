#==============================================================================|
#  ** DoubleX RMVXA Enemy AI v1.00a                                            |
#------------------------------------------------------------------------------|
#  * Changelog                                                                 |
#    v1.00a(GMT 0700 9-2-2014):                                                |
#    - 1st version of this script finished                                     |
#------------------------------------------------------------------------------|
#  * Author                                                                    |
#    DoubleX                                                                   |
#------------------------------------------------------------------------------|
#  * Terms of use                                                              |
#    None other than not claiming this script as created by anyone except      |
#    DoubleX or his alias                                                      |
#------------------------------------------------------------------------------|
#  * Prerequisites                                                             |
#    Scripts:                                                                  |
#    - none                                                                    |
#    Knowledge:                                                                |
#    - Decent scripting knowledge                                              |
#------------------------------------------------------------------------------|
#  * Functions                                                                 |
#    - Allows users to set enemy actions triggered by game variables           |
#------------------------------------------------------------------------------|
#  * Manual                                                                    |
#    To use this script, open the script editor and put this script into an    |
#    open slot between ▼ Materials and ▼ Main. Save to take effect.            |
#------------------------------------------------------------------------------|
#  * Compatibility                                                             |
#    Scripts aliasing method make_actions under class Game_Enemy may have      |
#    compatibility issues with this script                                     |
#    Place this script above those aliasing any of these methods if possible   |
#==============================================================================|

$imported = {} if $imported.nil?
$imported["DoubleX RMVXA Enemy AI"] = true

#==============================================================================|
#  ** You only need to edit this part as it's about what this script does      |
#------------------------------------------------------------------------------|

#------------------------------------------------------------------------------|
#  * This script is designed to be a tool for users with decent scripting      |
#    knowledge to make custom enemy actions triggered by game variables.       |
#    Each enemy in each troop has an associated varaible deciding their actions|
#    to be used. Conditions should be written in battle events and actions     |
#    should be written in this script. Action patterns should be ignored also. |
#    In short, this script bridges the gap between conditions and actions.     |
#------------------------------------------------------------------------------|
#  * Some useful stuffs                                                        |
#    - $data_skills[x]                                                         |
#      Skill with id x                                                         |
#    - $game_switches[x]                                                       |
#      Switch with id x                                                        |
#    - $game_troop.members[x]                                                          |
#      Troop member with index x                                               |
#    - $game_variables[x]                                                      |
#      Variable with id x                                                      |
#------------------------------------------------------------------------------|

module DoubleX_RMVXA
  module Enemy_AI

  #----------------------------------------------------------------------------|
  #  Enemy and variable lists and method name settings                         |
  #----------------------------------------------------------------------------|

    # Game switch id getting rid of VARIABLE_VALUE_HASH and custom methods
    # Sets actions of $game_troop.members[x] as skill with skill id being the
    # value of $game_variables[VARIABLE_ID_LIST[x]] when
    # $game_switches[VARIABLE_SET_SKILL_ID_SWITCH_ID] is true
    VARIABLE_SET_SKILL_ID_SWITCH_ID = 0
    # Example:
    # VARIABLE_SET_SKILL_ID_SWITCH_ID = 1
    # VARIABLE_ID_LIST = [1, 2, 3, 4, 5, 6, 7, 8]
    # Sets actions of $game_troop.members[x] as skill with skill id being the
    # value of $game_variables[x + 1] when $game_switches[1] is true

    # Id list of variables associated with enemy indices
    # $game_troop.members[x] is associated with VARIABLE_ID_LIST[x]
    # The size of the troops must not be greater than that of VARIABLE_ID_LIST
    VARIABLE_ID_LIST = [0, 0, 0, 0, 0, 0, 0, 0]
    # Example:
    # VARIABLE_ID_LIST = [1, 2, 3, 4, 5, 6, 7, 8]
    # includes variable ids 1 to 8
    # $game_troop.members[x] is associated with $game_variables[x + 1]

    # Value hash of variables with their ids in VARIABLE_ID_LIST
    # Each value of a variable calls a method for its associated troop member
    # This hash won't be used if $game_switches[VARIABLE_SET_SKILL_ID_SWITCH_ID]
    # is true
    VARIABLE_VALUE_HASH = {
      VARIABLE_ID_LIST[0] => [],
      VARIABLE_ID_LIST[1] => [],
      VARIABLE_ID_LIST[2] => [],
      VARIABLE_ID_LIST[3] => [],
      VARIABLE_ID_LIST[4] => [],
      VARIABLE_ID_LIST[5] => [],
      VARIABLE_ID_LIST[6] => [],
      VARIABLE_ID_LIST[7] => [],
    }
    # Example:
    # VARIABLE_ID_LIST[0] => [1, 2],
    # VARIABLE_ID_LIST[1] => [3, 4],
    # VARIABLE_ID_LIST[2] => [5, 6],
    # VARIABLE_ID_LIST[3] => [7, 8],
    # VARIABLE_ID_LIST[4] => [9, 10],
    # VARIABLE_ID_LIST[5] => [11, 12],
    # VARIABLE_ID_LIST[6] => [13, 14],
    # VARIABLE_ID_LIST[7] => [15, 16],
    # Sets the values of $game_variables[VARIABLE_ID_LIST[x]] calling respective
    # methods for $game_troops.members[x] as x + 1 and x + 2 respectively

    # Method names associated with variable value hash in VARIABLE_VALUE_HASH
    # "self." + ENEMY_INDEX + "enemy index" + VARIABLE_VALUE + "variable value"
    # Default of ENEMY_INDEX and VARIABLE_VALUE are "enemy_index_" and
    # "_variable_value_" respectively
    # These methods won't be called if
    # $game_switches[VARIABLE_SET_SKILL_ID_SWITCH_ID] is true
    ENEMY_INDEX = "enemy_index_"
    VARIABLE_VALUE = "_variable_value_"
    # Example: self.enemy_index_8_variable_value_0
    # Method name associated with value 0 of variable associated with enemy
    # index 8

    # make_actions(enemy_index, skill_id) sets all actions of enemy with index
    # being enemy_index to be skill with id being skill_id
    # Example: make_actions(8, 0)
    # Sets all actions of enemy with index 8 to be skill with id 0

    # make_action_list(enemy_index, skill_id_list) sets all actions of enemy
    # with index being enemy_index to be skills with id in skill_id_list and
    # @actions[i] will be set as
    # $data_skills[skill_id_list[i % skill_id_list.size]]
    # Example: make_action_list(8, [0, 1000])
    # Sets all actions of enemy with index 8 to be skill with id 0 and 1000 and
    # @actions will be $data_skills[0], $data_skills[1000], $data_skills[0], ...

  #----------------------------------------------------------------------------|
  #  Example methods of values of variables associated with enemy indices      |
  #----------------------------------------------------------------------------|

    # ENEMY_INDEX = "enemy_index_" and VARIABLE_VALUE = "_variable_value_" are
    # used

    # Method of value 0 of variable associated with enemy index 8
    # This method sets all actions as skill with id 1
    def self.enemy_index_8_variable_value_0
      make_actions(8, 1)
    end # self.enemy_index_8_variable_value_0

    # Method of value 0 of variable associated with enemy index 9
    # This method sets all actions as skills with id 1 and 2 and @actions will
    # be $data_skills[1], $data_skills[2], $data_skills[1], ...
    def self.enemy_index_9_variable_value_0
      make_action_list(9, [1, 2])
    end # self.enemy_index_9_variable_value_0

#------------------------------------------------------------------------------|

  #----------------------------------------------------------------------------|
  #  Add custom action methods here                                            |
  #----------------------------------------------------------------------------|



#------------------------------------------------------------------------------|

  #----------------------------------------------------------------------------|
  #  Method calls of variable values of variables associated with enemy indices|
  #----------------------------------------------------------------------------|

    # Calls custom action methods for enemy with index being enemy_index
    # make_actions_enemy_ai is aliased from the original make_actions
    def self.enemy_id_list(enemy_index)
      if VARIABLE_SET_SKILL_ID_SWITCH_ID > 0 && $game_switches[VARIABLE_SET_SKILL_ID_SWITCH_ID]
        make_actions(enemy_index, $game_variables[VARIABLE_ID_LIST[enemy_index]])
      elsif VARIABLE_VALUE_HASH[VARIABLE_ID_LIST[enemy_index]] && VARIABLE_VALUE_HASH[VARIABLE_ID_LIST[enemy_index]].size > 0 && VARIABLE_VALUE_HASH[VARIABLE_ID_LIST[enemy_index]].find { |variable| variable == $game_variables[VARIABLE_ID_LIST[enemy_index]] }
        eval(ENEMY_INDEX + enemy_index.to_s + VARIABLE_VALUE + $game_variables[VARIABLE_ID_LIST[enemy_index]].to_s)
      else
        $game_troop.members[enemy_index].make_actions_enemy_ai
      end
    end # self.enemy_id_list

    # Sets actions of enemies with index being enemy_index as skill with id being skill_id
    # make_ai_actions is a clone method under class Game_Enemy of make_actions under class Game_Battler
    # current_action_list is a new method that returns @actions
    def self.make_actions(enemy_index, skill_id)
      $game_troop.members[enemy_index].make_ai_actions
      $game_troop.members[enemy_index].current_action_list.size.times do |i|
        $game_troop.members[enemy_index].current_action_list[i].set_skill(skill_id)
      end
    end # self.make_actions

    # Sets actions of enemies with index being enemy_index as skill with id in skill_id_list
    # make_ai_actions is a clone method under class Game_Enemy of make_actions under class Game_Battler
    # current_action_list is a new method that returns @actions
    def self.make_action_list(enemy_index, skill_id_list)
      $game_troop.members[enemy_index].make_ai_actions
      $game_troop.members[enemy_index].current_action_list.size.times do |i|
        $game_troop.members[enemy_index].current_action_list[i].set_skill(skill_id_list[i % skill_id_list.size])
      end
    end # self.make_action_list

  end # Enemy_AI
end # DoubleX_RMVXA

#==============================================================================|

#==============================================================================|
#  ** You need not edit this part as it's about how this script works          |
#------------------------------------------------------------------------------|

class Game_Enemy < Game_Battler

  #----------------------------------------------------------------------------|
  #  Alias method: make_actions                                                |
  #----------------------------------------------------------------------------|
  alias make_actions_enemy_ai make_actions
  def make_actions
    # This part is rewritten by this script to use custom action picking methods
    DoubleX_RMVXA::Enemy_AI.enemy_id_list(@index)
    #
  end # make_actions

  #----------------------------------------------------------------------------|
  #  New method: make_ai_actions                                               |
  #----------------------------------------------------------------------------|
  def make_ai_actions
    clear_actions
    return unless movable?
    @actions = Array.new(make_action_times) { Game_Action.new(self) }
  end # make_ai_actions

  #----------------------------------------------------------------------------|
  #  New method: current_action_list                                           |
  #----------------------------------------------------------------------------|
  def current_action_list
    @actions
  end # current_action_list

end # Game_Enemy

#==============================================================================|