#==============================================================================|
#  ** Script Info                                                              |
#------------------------------------------------------------------------------|
#  * Script Name                                                               |
#    DoubleX RMVXA Enhanced YSA Battle System: Classical ATB                   |
#------------------------------------------------------------------------------|
#  * Functions                                                                 |
#    Be an enhanced version of YSA-CATB with bug fixes and addons integrated   |
#    Features:                                                                 |
#    1. Action Input Events(Core)                                              |
#        You can set something to occur right before/after inputting actions   |
#    2. Action Input Speed(Speed)                                              |
#       You can set some enemys and/or actors with autobattle and/or confusion |
#       to have action input speeds set by you                                 |
#    3. ATB Bar Colors(Core)                                                   |
#       You can set some actors, classes, weapons, armors, enemies and/or      |
#       states to alter their owner's atb bar colors by ways set by you        |
#    4. ATB Clock Window(Clock)                                                |
#       You can set if and how the atb clock info will be shown in battle      |
#    5. ATB Fill Rate(Core)                                                    |
#       You can set some actors, classes, weapons, armors, enemies and/or      |
#       states to alter their owner's atb fill rate by ways set by you         |
#    6. ATB Force Run/Stop(Force)                                              |
#       You can set keys to force the atb clock to run or stop when pressed    |
#       You can also set if and how the atb force status will be shown         |
#    7. ATB Pool(Pool)                                                         |
#       You can set the atb and action points to be shared among the party or  |
#       troop                                                                  |
#       Right now it doesn't support toogling this feature in battles          |
#       (v0.05a+)Right now it doesn't work well with the Gradual Action Points |
#       Gain feature                                                           |
#    8. ATB Reset Events(Core)                                                 |
#       You can set something to occur right before and/or after an atb reset  |
#    9. ATB Reset Value(Core)                                                  |
#       You can set some skill or items to reset their users' atb value by     |
#       values set by You                                                      |
#    10. ATB Turn Type(Core)                                                   |
#        You can set if the turn is based on time, number of actions/battlers  |
#    11. ATB Update Events(Core)                                               |
#        You can set something to occur right before and/or after an atb update|
#    12. Battler Charging Cancellation/Setup/Target Selection Hotkeys(Hotkey)  |
#        You can set hotkeys to call actors/enemies that can input actions, be |
#        targeted or are charging skills/items                                 |
#    13. Battler Cool Down(Cooldown)                                           |
#        You can set some skills or items to cause their users to have to cool |
#        down for a while before their atb bar will be filled again            |
#    14. Battler Order Window(Order)                                           |
#        You can set if and how the battler orders will be shown in battle     |
#    15. Battler Ready SE(SE)                                                  |
#        You can set some battlers to play a se set by users when the battlers |
#        become able to act                                                    |
#    16. Battler Sprite ATB Bars(Bar)                                          |
#        You can set the contents and layouts of the battler sprite atb bars   |
#        and the conditions for them to be shown                               |
#    17. Changing battle systems(Core)                                         |
#        You can change the battle system to any of those supported by         |
#        Yanfly Engine Ace - Ace Battle Engine outside battles                 |
#    18. Cooldown Finish Events(Cooldown)                                      |
#        You can set something to occur right after finishing cooldown normally|
#    19. Countdown States(Countdown)                                           |
#        You can set some states having duration in seconds and conditions     |
#        that trigger actions when they're met                                 |
#    20. (v0.04a+)CTB Replication(Core)                                        |
#        You can set this script to replicate a CTB system by skipping the atb,|
#        charge and cooldown filling times, and the global atb tick clock      |
#    21. Dynamic configuration values(Core)                                    |
#        Almost all user configuration values can be changed by you on the fly |
#    22. Escape/ATB Wait Conditions(Core)                                      |
#        You can set the conditions for party escape and/or the atb clock to   |
#        stop running                                                          |
#    23. Failed Escape Attempt Action Cost(Core)                               |
#        You can set the action costed paid by all party members right after   |
#        a failed escape attempt                                               |
#    24. (v0.05a+)Gradual Action Points Gain(Action)                           |
#        You can set some battlers' action points to be gained 1 by 1 instead  |
#        of gaining all action points at once                                  |
#        Right now it doesn't work well with the ATB Pool feature              |
#    25. Skill/Item Action Cost(Core)                                          |
#        You can set some skills or items to have their own action point       |
#        demands                                                               |
#    26. Skill/Item Cancel(Cancel)                                             |
#        You can cancel party members' charging skill/items                    |
#    27. Skill/Item Charging(Charge)                                           |
#        You can set party escape, some skills or items to demand users to     |
#        charge for a while before executing them                              |
#        You can also set some skills or items requiring charging to demands   |
#        their users to pay the costs after started or finished charging       |
#    28. Start ATB Value(Core)                                                 |
#        You can set some battlers to have their own initial atb values at     |
#        the beginning of a battle under conditions set by you                 |
#    29. Unison Skills(Unison)                                                 |
#        You can set some skills/items to need more than 1 battler to use      |
#        Right now it only supports actor unison skills/items                  |
#    Possibly upcoming features:                                               |
#    1. Action Batch Execution                                                 |
#       You can set some battlers to input and execute more than 1 actions in a|
#       single action input and execution phase respectively                   |
#    2. Multiple ATB Types                                                     |
#       You can set some skills/items to use some ATB types and some other     |
#       skills/items to use some other ATB types                               |
#    3. Premature Discharge                                                    |
#       You can set some skills/items to be able to be prematurely executed    |
#       before it finishes charging under some conditions and trade offs       |
#------------------------------------------------------------------------------|
#  * Terms Of Use                                                              |
#    You shall:                                                                |
#    1. Follow the terms of use of YSA Battle System: Classical ATB            |
#    2. Let your published edits of this script be integrated as parts of it   |
#    3. Keep this script's Script Info part's contents intact                  |
#    You shalln't:                                                             |
#    1. Claim that this script's written by anyone other than DoubleX, his     |
#       aliases, Yami, or his/her aliases                                      |
#    2. Make an edit of this script while saying it isn't                      |
#    3. Make a RMVXA project based on this script's demo while saying it isn't |
#    None of the above applies to Yami or his/her aliases                      |
#------------------------------------------------------------------------------|
#  * Prerequisites                                                             |
#    Scripts:                                                                  |
#    1. Yanfly Engine Ace - Ace Battle Engine                                  |
#    Abilities:                                                                |
#    1. Solid understanding of the active time battle system concepts          |
#    2. Solid understanding of the RMVXA notetag and script call usages        |
#    3. Decent RGSS3 scripting proficiency to fully utilize this script        |
#------------------------------------------------------------------------------|
#  * Instructions                                                              |
#    1. Open the script editor and put this script into an open slot between   |
#       Yanfly Engine Ace - Ace Battle Engine and Main. Save to take effect.   |
#    2. This script can't be used with YSA Battle System: Classical ATB.       |
#    3. Set DEFAULT_BATTLE_SYSTEM in Yanfly Engine Ace - Ace Battle Engine as  |
#       :ecatb to set the default battle system as that of this script.        |
#------------------------------------------------------------------------------|
#  * Author's Notes                                                            |
#    1. Using Yanfly Engine Ace - Ace Core Engine is highly recommended as it  |
#       fixes the force action bug of this script and improve the atb percent  |
#       and action points display in the actor atb bars.                       |
#    2. Using Yanfly Engine Ace - Buff & State Manager is highly recommended as|
#       it displays the states' remaining turns.                               |
#    3. Using Yanfly Engine Ace - Skill Cost Manager is highly recommended as  |
#       it can display the skills/items' action point requirements by using    |
#       <custom cost: skill.ecatb_act_cost[@actor]>.                           |
#    4. Using Cidiomar's Input as well is highly recommended as it lets users  |
#       set custom keymaps, which is useful for features using keyboard inputs.|
#    5. Using DoubleX RMVXA Dynamic Data is highly recommemded as it lets you  |
#       change the notetag values on the fly.                                  |
#       - ecatb_note_strings[note] is an accessor letting you store your new   |
#         notetag values of notetag note.                                      |
#       - reset_ecatb_notes(note) applies the above changes.                   |
#    6. Using DoubleX RMVXA State Counters is highly recommended as it displays|
#       the enemy countdown states.                                            |
#    7. Using DoubleX RMVXA State Triggers is highly recommended as the CATB   |
#       Clear Addon and some features of the CATB Countdown Addon are          |
#       outsourced to that script.                                             |
#    8. This is an advanced complicated script, meaning testings are likely    |
#       needed to comprehend the use of every configuration of this script.    |
#    9. This script can run using the default settings, but you're still highly|
#       recommended to comprehend all user settings of this script.            |
#    10. This script checks and corrects most configuration(but not notetag)   |
#        values, but you're still highly recommended to validate every         |
#        configuration(and notetag) values themselves.                         |
#    11. Using too many and/or complicated notetags and/or configuration values|
#        can cause severe performance issues, especailly on less able machines.|
#------------------------------------------------------------------------------|
#  * FAQ                                                                       |
#    Q1. What's the main difference between ECATB and CATB?                    |
#    A1. 1. The former integrates everything except compatibility fix into 1   |
#           script while the addons and bug fix of the latter are all separate |
#           scripts.                                                           |
#        2. Almost all user settings of the former can be changed on the fly   |
#           easily while lots of the latter are always fixed once set by users |
#           or even just hardcoded.                                            |
#        3. Some notetags of the former lets users do more stuffs than some of |
#           those of the latter.                                               |
#        4. The code structures and documentations of the former are generally |
#           clearer, neater and more logical than those of the latter.         |
#        5. The codes of the former are generally more effective, efficient,   |
#           flexible, maintainable, reliable and robust than the latter.       |
#        6. The former does a more thorough user error checking and corrections|
#           than the latter for most user settings in most cases.              |
#        7. The former generally demands much more from both the users and     |
#           scripters than the latter.                                         |
#        8. Users can't disable addons in the former while they can add and/or |
#           remove the addon of the latter effortlessly.                       |
#        9. The latter outsources little features to other scripts while the   |
#           former does this significantly more heavily.                       |
#    Q2. Some settings need scripting knowledge to use. May you please teach me|
#        scripting?                                                            |
#    A2. You can ask me how to set specific settings to meet your specific     |
#        needs, but it seems to me that there are many good scripting teachers |
#        so you may want to ask them instead of me for learning scripting.     |
#    Q3. Why don't you implement the reverse atb bar feature in this script    |
#        like what Victor Sant did in his atb script?                          |
#    A3. It's implicitly implemented but the feature is still in this script:  |
#        1. Set :ecatb_bar_colors as %Q(Color.new(0, 0, 0, 0),                 |
#           Color.new(0, 0, 0, 0)).                                            |
#           It makes the atb bar invisible.                                    |
#        2. Set :ecatb_base_fill_t as %Q(1 / Graphics.frame_rate).             |
#           It sets the base atb fill rate to be 100% per frame.               |
#        3. Set the charge rate of each skill or item as "x".                  |
#           It makes the skill or item to charge x% atb per frame.             |
#    Q4. Why I'll have to credit Yami but not you when it's your work?         |
#    A4. It's because this script's an edit of CATB and is heavily based on it.|
#        Without Yami's CATB, this script won't exist; Without his term of use |
#        permitting editing his CATB, this script won't exist as well.         |
#    Q5. What's the point of making ECATB when we've CATB?                     |
#    A5. 1. Some users may prefer having everything bundled into a single      |
#           script and that's the main reason for me to make ECATB.            |
#        2. Lets advanced users have much more control and freedom over the    |
#           script settings. ECATB does that at the cost of significantly      |
#           raising the demand of user proficiency, while CATB keeps the       |
#           settings simple at the cost of obviously reducing the settting     |
#           flexibilities.                                                     |
#    Q6. Can you make this script easier for non-scripters to use?             |
#    A6. I tried to make it as easy as I can but right now that's my limit.    |
#    Q7. Why some settings aren't hardcoded when no users would change them?   |
#    A7. If that's really the case, I'll consider making them hardcoded.       |
#    Q8. Why the script configuration part needs to have 2400+ lines?          |
#    A8. That's because this script does need that many lines to let users set |
#        the configurations of this script. You may want to use CATB instead if|
#        you don't need most of this script's configurations.                  |
#    Q9. Why 'Let your published edits of this script be integrated as parts of|
#        it' is included in the terms of use?                                  |
#    A9. 1. It means I want to reserve that right but that doesn't mean I'll   |
#           always do so. I'll never do so without discussing that with you.   |
#           I'll even try to have your permissions beforehand.                 |
#        2. Integrating the edits into this script may perform better in some  |
#           cases. A case-by-case approach will be used for discussing that.   |
#        3. If I didn't reserve that right, things could be chaotic when some  |
#           edits done by some people did conflict with some of the others by  |
#           some other people. Reserving this right can indeed be an insurance.|
#        4. I'll credit you and clearly stating which parts are your work.     |
#------------------------------------------------------------------------------|
#  * Links                                                                     |
#    Script Usage 101:                                                         |
#    1. forums.rpgmakerweb.com/index.php?/topic/32752-rmvxa-script-usage-101/  |
#    2. rpgmakervxace.net/topic/27475-rmvxa-script-usage-101/                  |
#    This script:                                                              |
#    1. [url]http://rpgmaker.net/scripts/549/[/url]                                       |
#    (DoubleX)ECATB Base Formula:                                              |
#    1. [url]http://pastebin.com/PRwkrQKb[/url]                                           |
#    Compatibility Fix:                                                        |
#    1. [url]http://rpgmaker.net/scripts/551/[/url]                                       |
#    Video:                                                                    |
#    1. [url]https://www.youtube.com/watch?v=E692R6s8F0I[/url]                            |
#    2. [url]https://www.youtube.com/watch?v=6E0-X0wbLAM[/url]                            |
#    Demo:                                                                     |
#    - Coming Soon                                                             |
#    Tutorial:                                                                 |
#    - Link included in [url]http://rpgmaker.net/scripts/549/[/url]                       |
#------------------------------------------------------------------------------|
#  * Authors                                                                   |
#    DoubleX:                                                                  |
#    1. This script                                                            |
#    Yami:                                                                     |
#    1. YSA Battle System: Classical ATB                                       |
#------------------------------------------------------------------------------|
#  * Changelog                                                                 |
#    v0.05b(GMT 0200 7-11-2015):                                               |
#    1. Updated (DoubleX)ECATB Base Formula                                    |
#    2. Notetag values are now symbols of methods in the configuration regions |
#    3. Fixed battler order icon not placed correctly when atb >= 100.0 bug    |
#    4. Simplified the party/troop atb pool reset implementations              |
#    5. Updated some outdated documentations                                   |
#    6. Further improved this script's compatibility, efficiency and simplicity|
#    v0.05a(GMT 0400 21-10-2015):                                              |
#    1. Implemented the Gradual Action Points Gain feature                     |
#       - Right now it doesn't work well with the ATB Pool feature             |
#    2. Updated (DoubleX)ECATB Base Formula                                    |
#    3. Added configuration :ecatb_countdown_mib in the added feature COUNTDOWN|
#    4. ecatb_se_ready_act changed to take SE or nil instead of an array       |
#    5. Fixed battler order and se notetags falsely returning nil bug          |
#    6. Fixed undisposed battler atb order icons upon battle end bug           |
#    7. Fixed repeated actor sprite creation bug                               |
#    8. Fixed battler atb order icons not keeping updated upon icon change bug |
#    9. Fixed pre ecatb input act only triggering upon becoming able to act bug|
#    10. Fixed split second countdown interval never updating turns bug        |
#    11. Fixed active actor command window not showing in atb pool mode bug    |
#    12. Fixed enemy atb bar not showing for those having at least 1 state bug |
#    13. Fixed nil cooldown rate when the atb gain rate remain unchanged bug   |
#    14. Fixed false unison charging for non unison skills/items after using   |
#        unison ones bug                                                       |
#    15. Fixed corrupted battler's last skill/item cache bug                   |
#    16. Fixed running the atb frame update upon battle end bug                |
#    17. Fixed non-sync unison cooldown with party/troop atb pool mode bug     |
#    18. Fixed troop atb pool reset not resetting all enemies' atb values bug  |
#    19. Fixed party/troop atb pool reset falsely resetting other members'     |
#        actions bug                                                           |
#        Right now all members' actions will still be reset when the action    |
#        point pool's depleted                                                 |
#    21. Fixed battler ready se not playing when the battler's become able to  |
#        act bug                                                               |
#    22. Debugging this script becomes easier and simpler with the console open|
#    23. Removed some more redundant variables and methods                     |
#    24. Further boosted this script's compactness, correctness, effectiveness,|
#        efficiency, maintainability, readability, robustness and simplicity   |
#    v0.04f(GMT 0400 12-9-2015):                                               |
#    1. Added 3 script calls for notifying changes of new status window methods|
#    2. The battler sprite atb bar methods are now under ECATB_Bar             |
#    3. Fixed issues with clearing/resetting battler blocks twice consecutively|
#    4. Further improved this script's effectiveness, efficiency and robustness|
#    v0.04e(GMT 1500 11-8-2015):                                               |
#    1. Fixed crash upon changing equips outside battles bug                   |
#    2. Fixed triggering pre and post atb reset effects upon battle end bug    |
#    3. Fixed enemy ecatb bar show not working properly bug                    |
#    4. Fixed actors added during battles not properly initialized bug         |
#    5. Fixed disabling party escape if not all party members are movable bug  |
#    6. Fixed failed party escape attempts not cooling down properly bug       |
#    7. Updated the outdated configuration documentations                      |
#    8. Further improved this script's compactness, memory usage and robustness|
#    v0.04d(GMT 1400 1-8-2015):                                                |
#    1. Updated (DoubleX)ECATB Base Formula                                    |
#    2. Changed :color to :atb and %Q(%Q()) to %Q()                            |
#    3. Added configuration :ecatb_bar_multilayer in feature BAR               |
#    4. Changed configuration :ecatb_actor_hotkeys to :ecatb_battler_hotkeys   |
#    5. UNISON_DEFS doesn't have to include method arguments now               |
#    6. Battler bars displayed on their sprites can overlap with status window |
#    7. Added video [url]https://www.youtube.com/watch?v=6E0-X0wbLAM[/url]                |
#    8. Fixed complete freeze upon battle end in the ctb replication mode bug  |
#    9. Fixed actors being inputable without action points in the atb pool mode|
#    10. Fixed uncleared blocks for actors not in the party when saving bug    |
#    11. Fixed unison rules not being properly applied to user's methods bug   |
#    12. Fixed countdown freeze not freezing the countdown clock entirely bug  |
#    13. Fixed notetag value reevaluation not always correctly triggered bug   |
#    14. Further increased this script's compactness, compatibility,           |
#        correctness, effectiveness, efficiency, flexibility, maintainability, |
#        modularity, readability, robustness, simplicity and user-friendliness |
#    v0.04c(GMT 1600 5-7-2015):                                                |
#    1. Fixed duplicate actor sprite creations from other scripts doing so     |
#    2. Fixed executing and/or inputting actions from/to hidden battlers bug   |
#    3. Further increased this script's compactness and efficiency             |
#    4. Removed some more redundant variables and compatibility socket methods |
#    v0.04b(GMT 1600 29-6-2015):                                               |
#    1. Reduced lag right after executing actions with ctb replication         |
#    2. Fixed nil atb bar color bug upon party member change at battle end     |
#    3. Removed some redundant variables and compatibility socket methods      |
#    v0.04a(GMT 0300 27-6-2015):                                               |
#    1. Implemented the CTB Replication feature                                |
#    2. Lets users set if problematic configuration values will be reset       |
#    3. Fixed retrieving nil battler name bug in the help window               |
#    4. Increased this script's compactness and memory performance             |
#    v0.03a(GMT 0900 27-5-2015):                                               |
#    1. Implemented these features:                                            |
#       -  Action Input Events                                                 |
#       -  ATB Reset Events                                                    |
#       -  Cooldown Finish Events                                              |
#    2. Improved this script's efficiency and robustness                       |
#    v0.02d(GMT 0400 25-5-2015):                                               |
#    1. Fixed starting atb value not working bug                               |
#    2. Fixed some typos and outdated stuffs                                   |
#    v0.02c(GMT 1300 15-5-2015):                                               |
#    1. Fixed default atb starting value not working bug                       |
#    2. Fixed nil color upon victory and unexpected change equip results bug   |
#    3. Fixed not clearing battlers' lambdas before calling Marshal bug        |
#    4. Fixed failing to load saved games upon restarting the game bug         |
#    5. Fixed unison method rules not working bug                              |
#    6. Improved the battler cooldown and party escape implementations         |
#    7. Further improved this script's efficiency                              |
#    v0.02b(GMT 1500 12-5-2015):                                               |
#    1. Fixed some typos and outdated stuffs                                   |
#    2. Fixed order battler icon bugs upon adding/removing party members       |
#    v0.02a(GMT 0700 9-5-2015):                                                |
#    1. Implemented the Action Input Speed feature                             |
#    2. Further improved this script's efficiency                              |
#    v0.01b(GMT 1600 4-5-2015):                                                |
#    1. Improved this script's efficiency                                      |
#    v0.01a(GMT 1300 2-5-2015):                                                |
#    1. Implemented the Battler Order Window feature                           |
#    v0.00d(GMT 0800 22-4-2015):                                               |
#    1. Fixed actor auto battle and confusion action not executing properly bug|
#    2. Fixed compatibility methods not being called bug                       |
#    3. Fixed unison charging value reset bug(the charging finishes upon reset)|
#    v0.00c(GMT 1200 18-4-2015):                                               |
#    1. Fixed the atb bar y offset not working bug                             |
#    2. Fixed the faulty example notetag values of <ecatb color: type, num, CX>|
#    3. Found unison charging value reset bug(the charging finishes upon reset)|
#    v0.00b(GMT 0900 15-4-2015):                                               |
#    1. Outsourced the countdown state sprite display to                       |
#       DoubleX RMVXA State Counters                                           |
#    2. Actor atb bars can be displayed on their sprites                       |
#    v0.00a(GMT 1200 9-4-2015):                                                |
#    1. 1st testing version of this script finished                            |
#==============================================================================|

#==============================================================================|
#  ** Notetag Info                                                             |
#     Notetag settings override their corresponding configuration settings     |
#     Search the notetags themselves to navigate between their info and values |
#------------------------------------------------------------------------------|
#  * Actors/Classes/Weapons/Armors/Enemies/States Notetags(in their noteboxes):|
#    1. <ecatb color: type, num, cx>                                           |
#       Sets the color num of atb bar with type being atb, charge or cooldown, |
#       and num being 1or 2 as cx, which can be set in Color Notetag Values    |
#    2. (v0.05a+)<ecatb gradual action gain: gagx>                             |
#       Sets the battler to gradually gain action points instead of gaining its|
#       maximum instantly if gagx, which can be set in Gradual Action Gain     |
#       Notetag Values, returns true                                           |
#    3. <ecatb order battler icon: obix>                                       |
#       Sets the icon representing its battler's order as obix, which can be   |
#       set in Order Battler Icon Notetag Values                               |
#    4. <ecatb order battler opacity: obox>                                    |
#       Sets the opacity of the icon representing its battler's order as obox, |
#       which can be set in Order Battler Opacity Notetag Values               |
#    5. <ecatb order battler scale: obsx>                                      |
#       Sets the scale of the icon representing its battler's order as obsx,   |
#       which can be set in Order Battler Scale Notetag Values                 |
#    6. <ecatb order battler z: obzx>                                          |
#       Sets the z position of the icon representing its battler's order as    |
#       obzx, which can be awr in Order Battler Z Notetag Values               |
#    7. <ecatb rate: rx>                                                       |
#       Sets the atb fill rate of the battler as rx, which can be set in Rate  |
#       Notetag Values                                                         |
#       All rx of all data currently applied to the battler will be used, with |
#       the output of the ith rx being the input of the (i + 1)th rx           |
#    8. <ecatb se ready act: serax>                                            |
#       Sets the se to be played when a battler becomes able to act as serax,  |
#       which can be set in SE Ready Act Notetag Values                        |
#    9. <ecatb speed reduce: srx>                                              |
#       Sets the number of frames an enemy or actor with autobattle and/or     |
#       confusion needs when inputting actions as srx, which can be set in     |
#       Speed Reduce Notetag Values                                            |
#       All srx of all data currently applied to the battler will be used      |
#    10. <ecatb start val: start, svx>                                         |
#        Sets the atb value at the start of the battle as svx, which can be set|
#        in Start Value Notetag Values                                         |
#        start can be either 0, 1 or 2, meaning the notetag will be used in    |
#        normal, preemptive or surprise starts respectively                    |
#        All svx of all data currently applied to the battler will be used     |
#------------------------------------------------------------------------------|
#  * Skill/Item Notetags(in their noteboxes):                                  |
#    1. <ecatb act cost: acx>                                                  |
#       Sets the number of actions needed for the skill/item as acx, which can |
#       be set in Action Cost Notetag Values                                   |
#       Users can't use it if they don't have enough actions                   |
#       Setting acx as 0 means no action point is needed nor will be used      |
#       Setting acx as negative means users will have more actions afterwards  |
#    2. <ecatb charge prior act cost: cpacx>                                   |
#       The skill/item action cost will be paid before and after finished      |
#       charging if cpacx, which can be set in Charge Prior Act Cost Notetag   |
#       Values, returns false and true respectively                            |
#    3. <ecatb charge prior item cost: cpicx>                                  |
#       The skill/item non-action cost will be paid before and after finished  |
#       charging if cpicx, which can be set in Charge Prior Item Cost Notetag  |
#       Values, returns false and true respectively                            |
#    4. <ecatb charge rate: crx>                                               |
#       The skill/item will have to charge with atb fill rate being crx, which |
#       can be set in Charge Rate Notetag Values, before releasing if this     |
#       notetag's used                                                         |
#    5. <ecatb cooldown rate: cdrx>                                            |
#       The battler will have to cool down with atb fill rate being cdrx, which|
#       can be set in Cooldown Rate Notetag Values, after using the skill/item |
#       before the battler's atb will be filled again if this notetag's used   |
#    6. <ecatb force act cost: facx>                                           |
#       The battler will and won't pay the action cost after using the forced  |
#       action if facx, which can be set in Force Action Cost Notetag Values,  |
#       returns false and true respectively                                    |
#    7. <ecatb reset val: rvx>                                                 |
#       Sets the atb value after using the skill/item as rvx, which can be set |
#       in Reset Value Notetag Values                                          |
#       The atb value right after users have no more actions will be the sum of|
#       rvx of all skills/items used before users have no more actions if the  |
#       battler doesn't gain action points gradually                           |
#    8. <ecatb unison actor: uax>                                              |
#       Sets the ids of actors needed to use the skill/item as uax, which can  |
#       be set in Unison Actor Notetag Values                                  |
#       All those actors must be able to use the skill/item                    |
#       They'll charge it with the same charge rate, use it together and have  |
#       a cooldown with the same cooldown rate                                 |
#    9. <ecatb unison actor def: uadx>                                         |
#       Sets the ids of actors used to calculate the result of def as uadx,    |
#       which can be set in Unison Actor Method Notetag Values                 |
#       def must be the symbol of a battler method returning real numbers and  |
#       should be those used in the skill/item's damage formula                |
#       If a method's used in the skill/item's damage formula but doesn't use  |
#       this notetag, its value will be that of the battler inputting the      |
#       skill/item                                                             |
#       Only 1 uadx will be used per def                                       |
#    10. <ecatb unison def rule: udrx>                                         |
#        Sets the calculation rule of def as udrx, which can be set in Unison  |
#        Method Rule Notetag Values                                            |
#        def must be the symbol of a battler method returning real numbers and |
#        should be those used in the skill/item's damage formula               |
#        The rules are used when the skill/item's executing damage             |
#        Only 1 udrx will be used per def                                      |
#    11. <ecatb unison charge rule: ucrx>                                      |
#        Sets the charge rate calculation rule as ucrx, which can be set in    |
#        Unison Charge Rule Notetag Values                                     |
#        The rules are used when the skill/item's charging                     |
#    12. <ecatb unison cooldown rule: ucdrx>                                   |
#        Sets the calculation rule of def as ucdrx, which can be set in Unison |
#        Cooldown Rule Notetag Values                                          |
#        The rules are used when the skill/item's users are cooling down       |
#------------------------------------------------------------------------------|
#  * Enemy/State Notetags(in their noteboxes):                                 |
#    1. <enemy ecatb bar show: kill, bar, percent, act>                        |
#       Sets if the enemy atb bar should be shown with fill percent and action |
#       points                                                                 |
#       The bar won't be shown if kill is true and the enemy isn't killed first|
#       bar, act and percent will be ignored will be above condition is met    |
#       The bar will be shown if bar is true                                   |
#       act and percent will be ignored if bar is false                        |
#       Action points and fill percent will be shown if act and percent are    |
#       true respectively                                                      |
#       Setting the value of an entry as nil means that entry will be ignored  |
#       t, f and n represents true, false and nil values respectively          |
#       The entry with the highest priority will be used if it's not nil       |
#       Enemy's notetags are of the lowest priorities and will never be ignored|
#------------------------------------------------------------------------------|
#  * State Notetags(in their noteboxes):                                       |
#    1. <ecatb countdown interval: cix>                                        |
#       Sets the duration of the state as cix seconds, which  can be set in    |
#       Coundown Interval Notetag Values                                       |
#        All cix of all states currently applied to the battler will be used   |
#==============================================================================|

#==============================================================================|
#  ** Script Call Info                                                         |
#------------------------------------------------------------------------------|
#  * Configuration Settings                                                    |
#    1. $game_system.set_battle_system(system)                                 |
#       - Changes the battle system as system, which is one of those supported |
#         by Yanfly Engine Ace - Ace Battle Engine                             |
#       - It can only be used outside battles                                  |
#    2. $game_system.ecatb_config = val                                        |
#       - Sets the value of :ecatb_config as val                               |
#         Example: $game_system.ecatb_base_fill_t = "$game_variables[x]" sets  |
#                  the value of :ecatb_base_fill_t as that of variable with id |
#                  x                                                           |
#    3. create_ecatb_def(config, validate)                                     |
#       - Updates the corresponding method of configuration config             |
#         That method will be validated if validate is true                    |
#         Example: BattleManager.create_ecatb_def(:ecatb_base_fill_t, true)    |
#                  updates and validates the corresponding method of           |
#                  :ecatb_base_fill_t                                          |
#  * Battler manipulations                                                     |
#    1. ecatb_act_times                                                        |
#       - Returns the number of the current action points                      |
#    2. ecatb_act_times = val                                                  |
#       - Sets the number of the current action points as val                  |
#    3. ecatb_countdown_freeze[state_id]                                       |
#       - Returns if the countdown of state with id state_id is frozen         |
#    4. ecatb_countdown_freeze[state_id] = val                                 |
#       - Sets if the duration in turns of a countdown state with id state_id  |
#         will be frozen                                                       |
#    5. ecatb_note_change[note] = true                                         |
#       - Notifies at least a value of a notetag with type note of a data used |
#         by the battler has changed                                           |
#       - note can be :act, :atb, :charge, :cooldown, :order_icon,             |
#         :order_opacity,:order_scale, :order_z, :rate, :se, :speed, :start_0, |
#         :start_1, :start_2, meaning gradual action gain, charge rate,        |
#         bar color, cooldown rate, order icon, order opacity, order scale,    |
#         order z, atb gain rate, speed reduce, battler ready se and start     |
#         value notetags with normal, preemptive and surprise start types      |
#         respectively                                                         |
#       - This script call can also be used to change the charge, cooldown, atb|
#         gain rate and bar colors per frame when it's called per frame        |
#    6. ecatb_reset(reset)                                                     |
#       - Cancels the battler's charging actions                               |
#       - The battler's atb and action points will be reset as well if reset   |
#         is true                                                              |
#    7. ecatb_rate[type]                                                       |
#       Returns the atb gain rate with type type                               |
#       - type can be either :atb, :charge or :cooldown, meaning normal,       |
#         charge and cooldown atb types respectively                           |
#    8. ecatb_val[type]                                                        |
#       Returns the atb value with type type                                   |
#       - type can be either :atb, :charge or :cooldown, meaning normal,       |
#         charge and cooldown atb types respectively                           |
#    9. ecatb_val[type] = val                                                  |
#       - Sets the atb value with type type as val                             |
#       - type can be either :atb, :charge or :cooldown, meaning normal,       |
#         charge and cooldown atb types respectively                           |
#  * Party/Troop manipulations                                                 |
#    1. ecatb_pool = enable                                                    |
#       - Converts all actors/enemies' atb into a party/troop atb if enable is |
#         true and vice versa if enable is false                               |
#       - It can't be used in battles                                          |
#  * Hotkey manipulations                                                      |
#    1. SceneManager.scene.set_ecatb_battler_window_handlers                   |
#       - Creates all battler target selection hotkey handlers                 |
#       - It can only be used in battles                                       |
#    2. SceneManager.scene.set_ecatb_actor_command_window_handlers             |
#       - Creates all inputable actor setup hotkey handlers                    |
#       - It can only be used in battles                                       |
#    3. SceneManager.scene.create_ecatb_cancel_window                          |
#       - Creates all charging actor cancellation hotkey handlers              |
#       - It can only be used in battles                                       |
#  * Window manipulations                                                      |
#    1. SceneManager.scene.create_ecatb_clock_window                           |
#       - Creates the atb clock window if :show_ecatb_clock_window returns     |
#         true                                                                 |
#       - It can only be used in battles                                       |
#    2. SceneManager.scene_close_ecatb_clock_window                            |
#       - Closes the atb clock window                                          |
#       - It can only be used in battles with an atb clock window              |
#    3. SceneManager.scene.ecatb_clock_window.update_text_xy                   |
#       - Updates the atb clock window text x and y positions                  |
#       - It can only be used in battles having an atb clock window            |
#    4. SceneManager.scene.ecatb_clock_window.update_pos                       |
#       - Updates the atb clock window x, y and z positions                    |
#       - It can only be used in battles having an atb clock window            |
#    5. SceneManager.scene.ecatb_clock_window.update_wh                        |
#       - Updates the atb clock window width and height                        |
#       - It can only be used in battles having an atb clock window            |
#    6. SceneManager.scene.ecatb_clock_window.update_text_font                 |
#       - Updates the atb clock window text color and size                     |
#       - It can only be used in battles having an atb clock window            |
#    7. SceneManager.scene.ecatb_clock_window.clock_bar.update_bar_colors      |
#       - Updates the atb clock window bar colors                              |
#       - It can only be used in battles having an atb clock window            |
#    8. SceneManager.scene.ecatb_clock_window.clock_bar.update_bar_wh          |
#       - Updates the atb clock window bar width and height                    |
#       - It can only be used in battles having an atb clock window            |
#    9. SceneManager.scene.ecatb_clock_window.clock_bar.update_bar_xy          |
#       - Updates the atb clock window bar x and y positions                   |
#       - It can only be used in battles having an atb clock window            |
#    10. SceneManager.scene.ecatb_clock_window.refresh                         |
#        - Refreshes the atb clock window bar and text                         |
#        - It can only be used in battles having an atb clock window           |
#    11. SceneManager.scene.create_ecatb_force_window                          |
#        - Creates the atb force window if :show_ecatb_force_window returns    |
#          true                                                                |
#        - It can only be used in battles                                      |
#    12. SceneManager.scene.close_ecatb_force_window                           |
#        - Closes the atb force window                                         |
#        - It can only be used in battles with an atb force window             |
#    13. SceneManager.scene.ecatb_force_window.update_pos                      |
#        - Updates the atb force window x, y and z positions                   |
#        - It can only be used in battles having an atb force window           |
#    14. SceneManager.scene.ecatb_force_window.update_wh                       |
#        - Updates the atb force window width and height                       |
#        - It can only be used in battles having an atb force window           |
#    15. SceneManager.scene.ecatb_force_window.update_text_font                |
#        - Updates the atb force window text color and size                    |
#        - It can only be used in battles having an atb force window           |
#    16. SceneManager.scene.ecatb_force_window.update_text                     |
#        - Updates the atb force window text                                   |
#        - It can only be used in battles having an atb force window           |
#    17. SceneManager.scene.ecatb_force_window.update_text_xy                  |
#        - Updates the atb force window text x and y positions                 |
#        - It can only be used in battles having an atb force window           |
#    18. SceneManager.scene.ecatb_force_window.draw_text                       |
#        - Draws the atb force window text                                     |
#        - It can only be used in battles having an atb force window           |
#    19. SceneManager.scene.create_ecatb_order_window                          |
#        - Creates the atb pool window if :show_ecatb_order_window returns true|
#        - It can only be used in battles                                      |
#    20. SceneManager.scene.close_ecatb_order_window                           |
#        - Closes the atb order window                                         |
#        - It can only be used in battles with an atb order window             |
#    21. SceneManager.scene.ecatb_order_window.draw_bars                       |
#        - Draws the atb order bars and text                                   |
#        - It can only be used in battles with an atb order window             |
#    22. SceneManager.scene.ecatb_pool_window.update_pos                       |
#        - Updates the atb pool window x, y and z positions                    |
#        - It can only be used in battles having an atb pool window            |
#    23. SceneManager.scene.ecatb_pool_window.update_wh                        |
#        - Updates the atb pool window width and height                        |
#        - It can only be used in battles having an atb pool window            |
#    24. SceneManager.scene.ecatb_pool_window.update_text_font                 |
#        - Updates the atb pool window text color and size                     |
#        - It can only be used in battles having an atb pool window            |
#    25. SceneManager.scene.create_ecatb_pool_window                           |
#        - Creates the atb pool window if :show_ecatb_pool_window returns true |
#        - It can only be used in battles                                      |
#    26. SceneManager.scene.close_ecatb_pool_window                            |
#        - Closes the atb pool window                                          |
#        - It can only be used in battles with an atb pool window              |
#    27. SceneManager.scene.ecatb_pool_window.update_pos                       |
#        - Updates the atb pool window x, y and z positions                    |
#        - It can only be used in battles having an atb pool window            |
#    28. SceneManager.scene.ecatb_pool_window.update_wh                        |
#        - Updates the atb pool window width and height                        |
#        - It can only be used in battles having an atb pool window            |
#    29. SceneManager.scene.ecatb_pool_window.update_text_font                 |
#        - Updates the atb pool window text color and size                     |
#        - It can only be used in battles having an atb pool window            |
#    30. SceneManager.scene.ecatb_pool_window.update_text_xy                   |
#        - Updates the atb pool window text x and y positions                  |
#        - It can only be used in battles having an atb pool window            |
#    31. SceneManager.scene.ecatb_pool_window.draw_text                        |
#        - Draws the atb pool window text                                      |
#        - It can only be used in battles having an atb pool window            |
#    32. (v0.04f+)SceneManager.scene.status_window.ecatb_text_change = true    |
#        - Notifies that the atb bar text format's changed                     |
#        - It can only be used in battles                                      |
#    33. (v0.04f+)SceneManager.scene.status_window.ecatb_word_change = true    |
#        - Notifies that the atb bar description word's changed                |
#        - It can only be used in battles                                      |
#    34. (v0.04f+)SceneManager.scene.status_window.ecatb_y_add_change = true   |
#        - Notifies that the atb bar y offset's changed                        |
#        - It can only be used in battles                                      |
#==============================================================================|

($doublex_rmvxa ||= {})[:ECATB] = "v0.05b"

#==============================================================================|
#  ** Script Configurations                                                    |
#     You only need to edit this part as it's about what this script does      |
#------------------------------------------------------------------------------|

module DoubleX_RMVXA

  module ECATB

    # Sets if configuration values that can crash the game will be rescued
    # If it's set as true, players will be informed that the values of those
    # configurations are invalid and will be reset to their default ones
    # If it's set as false, the game will crash and the error log will be shown
    # It can't be changed once set
    # Example: To let invalid configuration values crash the game to have the
    #          error log, set this as false
    RESCUE_CONFIG_VAL = true

    # (v0.04a+)Sets if configuration values that are invalid or can crash the
    # game will be reset to their defaults
    # It can't be changed once set
    # Example: To reset invalid or faulty configuration values to their
    #          defaults, set this as true
    RESET_CONFIG_VAL = true

    # Sets if the text showing an invalid or faulty configuration value will be
    # displayed right after checking them
    # It can't be changed once set
    # Example: To silently reset invalid or faulty configuration values, set
    #          this as true
    SUPPRESS_RESET_CONFIG_VAL_TEXT = false

  #----------------------------------------------------------------------------|
  #  * Core                                                                    |
  #    Setups configurations and notetag values of the core features           |
  #----------------------------------------------------------------------------|

    #--------------------------------------------------------------------------|
    #  Color Notetag Values                                                    |
    #  - Setups cx used by <ecatb color: type, num, cx> notetags               |
    #--------------------------------------------------------------------------|
    # cx are read at:
    # 1. RPG::Actor, RPG::Class, RPG::EquipItem, RPG::Enemy, RPG::State
    #    - next @ecatb_notes[$1.downcase.to_sym][$2.to_i] ||= $3.downcase.to_sym
    #      in load_ecatb_notes
    # cx are used at:
    # 1. Game_BattlerBase
    #    - @ecatb_notes[note][0] ||= ecatb.send(n, self) if n and 
    #    - @ecatb_notes[note][1] ||= ecatb.send(n, self) in
    #      set_ecatb_bar_color_notes
    # cx are strings of names of methods under DoubleX_RMVXA::ECATB
    # cx must return an array of colors
    # cx names can only use alphanumeric characters and can't use uppercase
    # letters
    # battler is the battler calling the cx
    # The below cx are examples added to help you set your cx
    # You can freely use, rewrite and/or delete these examples

    # Sets the atb bar colors as text color c and r, g, b, a rgba values
    def self.c1(battler)
      Colour.text_colour(c)
    end

    # Sets the atb bar colors as r, g, b, a rgba values
    def self.c2(battler)
      Color.new(r, g, b, a)
    end

    # Adds new cx here
    

    #--------------------------------------------------------------------------|
    #  Rate Notetag Values                                                     |
    #  - Setups rx used by <ecatb rate: rx> notetags                           |
    #--------------------------------------------------------------------------|
    # rx are read at:
    # 1. RPG::Actor, RPG::Class, RPG::EquipItem, RPG::Enemy, RPG::State
    #    - next @ecatb_notes[:rate] << $1.downcase.to_sym in load_ecatb_notes
    # rx are used at:
    # 1. Game_BattlerBase
    #    - base[:val] = ecatb.send(note, self, base) in set_ecatb_gain_rate
    # rx are strings of names of methods under DoubleX_RMVXA::ECATB
    # rx must return a real number and should return a floating-point number
    # rx names can only use alphanumeric characters and can't use uppercase
    # letters
    # battler is the battler calling the rx
    # The base atb rate can be referenced by base[:val]
    # The number of battlers counted for method sums can be referenced by
    # base[:size]
    # The method sum of all battlers counted can be referneced by
    # base[:sum][method_name]
    # method_name must be included in :ecatb_battlers_def_sum
    # The below rx are examples to help you set your rx
    # You can freely use, rewrite and/or delete these examples

    # Mutliplies the atb fill rate by the battler's agi / all battlers'
    # average agi
    # all battlers is the value of :def_sum_battlers
    def self.r1(battler, base)
      base[:val] * battler.agi * base[:size] / base[:sum][:agi]
    end

    # Sets the atb fill rate as x% per frame
    def self.r2(battler, base)
      x
    end

    # Sets the atb fill rate as the value of variable with id x * 100% per frame
    def self.r3(battler, base)
      $game_variables[x]
    end

    # Adds new rx here
    

    #--------------------------------------------------------------------------|
    #  Start Value Notetag Values                                              |
    #  - Setups svx used by <ecatb start val: start, svx> notetags             |
    #--------------------------------------------------------------------------|
    # svx are read at:
    # 1. RPG::Actor, RPG::Class, RPG::EquipItem, RPG::Enemy, RPG::State
    #    - next @ecatb_notes[("start_" + $1).to_sym] << $2.downcase.to_sym in
    #      load_ecatb_notes
    # svx are used at:
    # 1. Game_BattlerBase
    #    - ecatb.send(note, self) in set_ecatb_start_val
    # svx are strings of names of methods under DoubleX_RMVXA::ECATB
    # svx must return a non-negative real number and should return a
    # non-negative floating-point number
    # svx names can only use alphanumeric characters and can't use uppercase
    # letters
    # battler is the battler calling the svx
    # The below svx are examples added to help you set your svx
    # You can freely use, rewrite and/or delete these examples

    # Sets the starting atb value as x%
    def self.sv1(battler)
      battler.ecatb_val[:atb] = x
    end

    # Sets the atb value as that of variable with id x * 100%
    def self.sv2(battler)
      battler.ecatb_val[:atb] = $game_variables[x]
    end

    # Adds the atb starting value by x%
    def self.sv3(battler)
      battler.ecatb_val[:atb] += x
    end

    # Adds new svx here
    

    #--------------------------------------------------------------------------|
    #  Action Cost Notetag Values                                              |
    #  - Setups acx used by <ecatb act cost: acx> notetags                     |
    #--------------------------------------------------------------------------|
    # acx are read at:
    # 1. RPG::UsableItem
    #    - send(:"#{note}=", send(:"#{note}") || val) in load_ecatb_notes
    # acx are used at:
    # 1. Game_BattlerBase
    #    - return false if @ecatb_val[:charge] <= 0.0 && @ecatb_act_times < 
    #      ecatb.send(item.ecatb_act_cost, self) in usable?
    # 2. Game_Battler
    #    - cost = DoubleX_RMVXA::ECATB.send(item.ecatb_act_cost, self) in
    #      pay_ecatb_act_cost
    #    - cost = (ecatb = DoubleX_RMVXA::ECATB).send(item.ecatb_act_cost, self)
    #      in ecatb_unison_actor?
    # 3. Window_ItemList
    #    - return battler.usable?(item) if (ecatb = DoubleX_RMVXA::ECATB).send(
    #      item.ecatb_act_cost, battler) > 1 || ecatb.send(
    #      item.ecatb_unison_actor, battler).size > 1 in enable?
    # acx are strings of names of methods under DoubleX_RMVXA::ECATB
    # acx must return a real number and should return a non-random integer
    # acx names can only use alphanumeric characters and can't use uppercase
    # letters
    # battler is the battler calling the acx
    # The below acx are examples added to help you set your acx
    # You can freely use, rewrite and/or delete these examples

    # Sets the action cost as x
    def self.ac1(battler)
      x
    end

    # Sets the action cost as the value of variable with id x
    def self.ac2(battler)
      $game_variables[x]
    end

    # Adds new acx here
    

    # Sets the number of action points needed to execute actions
    # It'll be used only if no acx are used
    # It must return a real number and should return a non-random integer
    # battler is the battler calling ecatb_act_cost
    # Example: To set the number of action points needed to execute actions as
    #          the value of variable with id x, set this as 
    #          %Q($game_variables[x])
    def self.ecatb_act_cost(battler)
      1
    end

    #--------------------------------------------------------------------------|
    #  Force Action Cost Notetags Values                                       |
    #  - Setups facx used by <ecatb force act cost: facx> notetags             |
    #--------------------------------------------------------------------------|
    # facx are read at:
    # 1. RPG::UsableItem
    #    - send(:"#{note}=", send(:"#{note}") || val) in load_ecatb_notes
    # facx are used at:
    # 1. Game_BattlerBase
    #    - if (force_act_cost = ecatb.send(item.ecatb_force_act_cost, self)) ||
    #      !forced in exec_ecatb_act_cost
    # facx are strings of names of methods under DoubleX_RMVXA::ECATB
    # facx names can only use alphanumeric characters and can't use uppercase
    # letters
    # battler is the battler calling the facx
    # The below facx are examples added to help you set your facx
    # You can freely use, rewrite and/or delete these examples

    # Sets the force action cost as true
    def self.fac1(battler)
      true
    end

    # Sets the force action cost as false
    def self.fac2(battler)
      false
    end

    # Sets the force action cost as the state of switch with id x
    def self.fac3(battler)
      $game_switches[x]
    end

    # Adds new facx here
    

    # Sets if force actions cost action points
    # It'll be used only if no facx are used
    # battler is the battler calling ecatb_force_act_cost
    # Example: To set force actions to cost action points if switch with id x is
    #          on, set this as %Q($game_switches[x])
    def self.ecatb_force_act_cost(battler)
      false
    end

    #--------------------------------------------------------------------------|
    #  Reset Value Notetags Values                                             |
    #  - Setups rvx used by <ecatb reset val: rvx> notetags                    |
    #--------------------------------------------------------------------------|
    # rvx are read at:
    # 1. RPG::UsableItem
    #    - send(:"#{note}=", send(:"#{note}") || val) in load_ecatb_notes
    # rvx are used at:
    # 1. Game_BattlerBase
    #    - @ecatb_reset_val = (ecatb = DoubleX_RMVXA::ECATB).send(val, self) in
    #      set_ecatb_reset_val
    # rvx are strings of names of methods under DoubleX_RMVXA::ECATB
    # rvx must return a real number and should return a floating-point number
    # rvx names can only use alphanumeric characters and can't use uppercase
    # letters
    # battler is the battler calling the rvx
    # The below rvx are examples added to help you set your rvx
    # You can freely use, rewrite and/or delete these examples

    # Sets the atb reset value as x%
    def self.rv1(battler)
      x
    end

    # Sets the atb reset value as the value of variable with id x * 100%
    def self.rv2(battler)
      $game_variables[x]
    end

    # Adds the atb reset value by x%
    def self.rv3(battler)
      battler.ecatb_reset_val + x
    end

    # Adds new rvx here
    

    # Sets the atb reset value after using a skill/item
    # It'll be used only if no rvx are used
    # It must return a real number and should return a floating-point number
    # battler is the battler calling ecatb_reset_val
    # Example: To set the atb reset value as x%, set this as %Q(x)
    def self.ecatb_reset_val(battler)
      battler.set_gradual_ecatb_act_gain ? battler.ecatb_val[:atb] : 0.0
    end

    #--------------------------------------------------------------------------|
    #  Escape Initialization Condition Configurations                          |
    #  - Setups EICX used by :ecatb_esc_init_cond                              |
    #--------------------------------------------------------------------------|
    # EICX are used at:
    # 1. BattleManager
    #    - init_ecatb_escape if @ecatb_can_esc && ecatb_esc_init_cond in
    #      process_escape
    # EICX are strings of RGSS3 codes
    # EICX names can only use alphanumeric characters
    # The below EICX are examples added to help you set your EICX
    # You can freely use, rewrite and/or delete these examples

    # Checks if the member can pay the escape action cost
    EIC1 = -> mem { mem.ecatb_act_times >= mem.ecatb_esc_act_cost }

    # Adds new EICX here
    

    #--------------------------------------------------------------------------|
    #  Escape Charge Condition Configurations                                  |
    #  - Setups ECCX used by :ecatb_esc_charge_cond                            |
    #--------------------------------------------------------------------------|
    # ECCX are used at:
    # 1. BattleManager
    #    - return pay_ecatb_esc_cost unless ecatb_esc_charge_cond in
    #      ecatb_update
    # ECCX are strings of RGSS3 codes
    # ECCX names can only use alphanumeric characters
    # The below ECCX are examples added to help you set your ECCX
    # You can freely use, rewrite and/or delete these examples

    # Checks if the member is charging the party escape
    ECC1 = -> mem { mem.ecatb_esc }

    # Adds new ECCX here
    

    #--------------------------------------------------------------------------|
    #  Escape Execution Condition Configurations                               |
    #  - Setups EECX used by :ecatb_esc_exec_cond                              |
    #--------------------------------------------------------------------------|
    # EECX are used at:
    # 1. BattleManager
    #    - ecatb_esc_suc if ecatb_esc_exec_cond in ecatb_update
    # EECX are strings of RGSS3 codes
    # EECX names can only use alphanumeric characters
    # The below EECX are examples added to help you set your EECX
    # You can freely use, rewrite and/or delete these examples

    # Checks if the member has fully charged a skill/item
    EEC1 = -> mem { mem.ecatb_val[:charge] >= 100.0 }

    # Adds new EECX here
    

    #--------------------------------------------------------------------------|
    #  Wait Condition Configurations                                           |
    #  - Setups WCX used by :ecatb_wait_cond                                   |
    #--------------------------------------------------------------------------|
    # WCX are used at:
    # 1. Scene_Battle
    #    - BattleManager.phase && !ecatb_wait_cond in ecatb_update?
    # WCX are strings of RGSS3 codes
    # WCX names can only use alphanumeric characters
    # The below WCX are examples added to help you set your WCX
    # Your can freely use, rewrite and/or delete these examples

    # Checks if the atb clock is forced to stop
    WC1 = %Q(@ecatb_force_clock == :stop)

    # Checks if the atb clock isn't forced to run
    WC2 = %Q(@ecatb_force_clock != :run)

    # Checks if an action's executing
    WC3 = %Q(!BattleManager.ecatb_can_esc)

    # Checks if the cancel window's active
    WC4 = %Q(@ecatb_cancel_window && @ecatb_cancel_window.active)

    # Checks if the party command window's active
    WC5 = %Q(@party_command_window.active)

    # Checks if the actor target window's active
    WC6 = %Q(@actor_window.active)

    # Checks if the enemy target window's active
    WC7 = %Q(@enemy_window.active)

    # Checks if the skill window's active
    WC8 = %Q(@skill_window.active)

    # Checks if the item window's active
    WC9 = %Q(@item_window.active)

    # Checks if the actor command window's active
    WC10 = %Q(@actor_command_window.active)

    # Checks if the combat log window's visible
    WCC1 = %Q(update_msg_open_ecatb_compatibility?)

    # Adds new WCX here
    

    #--------------------------------------------------------------------------|
    #  Core Configurations                                                     |
    #  - Setups the configurations of the core features                        |
    #  - The value of each configuration is the string of the content of its   |
    #    corresponding method                                                  |
    #--------------------------------------------------------------------------|

    CORE = {

      # Sets the conditions for initializing party escape
      # A party escape is first initialized, then charged, and finally executed
      # An executed party escape can either success or fail
      # Its corresponding method's created under BattleManager
      # Party Escape can't be initialized nor executed while executing an action
      # Example: To demand at least 1 inputable party member that can pay the
      #          party escape cost, set this as
      #          %Q(ecatb_input_list.any?(&DoubleX_RMVXA::ECATB::EIC1))
      :ecatb_esc_init_cond => %Q((list = ecatb_input_list).size >= $game_party.
                 battle_members.size && list.all?(&DoubleX_RMVXA::ECATB::EIC1)),

      # Sets the conditions for continuing to charge the party escape
      # A party escape is first initialized, then charged, and finally executed
      # An executed party escape can either success or fail
      # Its corresponding method's created under BattleManager
      # Example: To demand a key with mapping :KEY to be pressed and at least 1
      #          party member to continue charging the party escape, set this as
      #          %Q(Input.press?(:KEY) && 
      #             $game_party.members.any?(&DoubleX_RMVXA::ECATB::ECC1))
      :ecatb_esc_charge_cond => %Q($game_party.battle_members.all?(
                                   &DoubleX_RMVXA::ECATB::ECC1)),

      # Sets the conditions for executing party escape
      # A party escape is first initialized, then charged, and finally executed
      # An executed party escape can either success or fail
      # Its corresponding method's created under BattleManager
      # Example: To demand at least 1 party member to finish charging the party
      #          escape before executing it, set this as
      #          %Q($game_party.members.any?(&DoubleX_RMVXA::ECATB::EEC1))
      :ecatb_esc_exec_cond => %Q($game_party.alive_members.all?(
                                 &DoubleX_RMVXA::ECATB::EEC1)),

      # Sets the conditions for successful party escape
      # A party escape is first initialized, then charged, and finally executed
      # An executed party escape can either success or fail
      # Its corresponding method's created under BattleManager
      # Example: To check the preemptive status or use escape ratio as the 
      #          success probability and have at least 1 party member being able
      #          to pay the party escape cost, set this as
      #          %Q((@preemptive || rand < @escape_ratio) && 
      #             $game_party.alive_members.any?(&DoubleX_RMVXA::ECATB::EIC1))
      :ecatb_esc_suc_cond => %Q((@preemptive || rand < @escape_ratio) && 
                   $game_party.alive_members.all?(&DoubleX_RMVXA::ECATB::EIC1)),

      # Sets the atb clock wait condition
      # Its corresponding method's created under Scene_Battle
      # The atb clock will always wait if the game message is visible
      # Only 1 action can be executed at a time
      # Example: To run the atb clock if switch with id x is on, set this as
      #          %Q($game_switches[x])
      :ecatb_wait_cond => %Q(#{WC1} || #{WC2} && (#{WC3} || #{WC4} || #{WC5} || 
                             #{WC6} || #{WC7} || #{WC8} || #{WC9} || #{WC10} || 
                             #{WCC1})),

      # Sets the base atb fill time in seconds
      # Its corresponding method's created under BattleManager
      # It must return a positive real number
      # Example: To set the base atb fill time as 1 frame, set this as
      #          %Q(1 / Graphics.frame_rate)
      :ecatb_base_fill_t => %Q(10),

      # Sets the turn type
      # Its corresponding method's created under Scene_Battle
      # It must return either :tick, :battler or :act
      # :tick means turn length's controlled by the number of ticks
      # :battler means turn length is controlled by the number of battlers
      # :act means turn length's controlled by the number of actions executed
      # Example: To set the atb turn type as :act, set this as %Q(:act)
      :ecatb_turn_type => %Q(:tick),

      # Needs :ecatb_turn to be :tick to be used
      # Sets the turn length in seconds
      # Its corresponding method's created under Scene_Battle
      # It must return a positive real number
      # Example: To set the turn length as the base atb fill time, set this as
      #          %Q(BattleManager.ecatb_base_fill_t)
      :ecatb_tick_count => %Q(10),

      # Needs :ecatb_turn to be :act to be used
      # Sets the turn length in the number of actions counted
      # Its corresponding method's created under Scene_Battle
      # It must return a positive real number and should return a natural number
      # Example: To set the turn length as x actions, set this as %Q(x)
      :ecatb_after_act => %Q(10),

      # Needs :ecatb_turn to be :battler to be used
      # Sets the number of units per battler counted added to the turn length
      # The unit can either be :tick or :act
      # :tick means the unit is second
      # :act means the unit is the number of actions
      # Its corresponding method's created under Scene_Battle
      # It must return an array
      # Its 1st element must return a positive real number and should return a
      # natural number
      # Its 2nd element must return either :tick or :act
      # Example: To set the battler scale as x actions, set this as
      #          %Q([x, :act])
      :ecatb_battler_scale => %Q([1, :tick]),

      # Needs :ecatb_turn to be :battler to be used
      # Sets the battlers to be counted in the battler scale
      # Its corresponding method's created under Scene_Battle
      # It must return a positive real number and should return the size of
      # an array of battlers
      # Example: To include all battlers, set this as
      #          Q($game_party.members.size + $game_troop.members.size)
      :ecatb_battler_count => %Q($game_party.alive_members.size + 
                                 $game_troop.alive_members.size),

      # Needs :ecatb_turn to be :act or :battler to be used
      # Sets if force actions are counted as well
      # Its corresponding method's created under Scene_Battle
      # Example: To count the force actions as well if switch with id x is on,
      #          set this as %Q($game_switches[x])
      :ecatb_force_act_count => %Q(false),

      # (v0.04a+)Sets if battles will behave like a CTB by skipping the atb,
      # charge and cooldown filling times, and the global atb tick clock
      # Its corresponding method's created under BattleManager
      # Example: To replicate a CTB system if switch with id x is on, set this
      #          as %Q($game_switches[x])
      :ecatb_ctb => %Q(false),

      # Sets the priority of the ecatb rate notetags to be used
      # Its corresponding method's created under Game_Actor and Game_Enemy
      # It must return an array with elements being either :states, :enemies,
      # :armors, :weapons, :classes or :actors
      # Example: To set actors to have a higher priority than that of states,
      #          set this as %Q([:actors, :states])
      :ecatb_rate_ord => %Q([:actors, :classes, :weapons, :armors, :enemies, 
                             :states]),

      # Sets the 1st atb value of actors when battles start normally
      # Its corresponding method's created under Game_Actor and Game_Enemy
      # It must return a non-negative real number and should return a
      # non-negative floating-point number
      # Example: To set the 1st atb value of actors when battler start normally
      #          as x%, set this as %Q(@ecatb_val[:atb] = x)
      :normal_actor_1st_ecatb_val => %Q(@ecatb_val[:atb] = 0.0),

      # Sets the 1st atb value of enemies when battles start normally
      # Its corresponding method's created under Game_Actor and Game_Enemy
      # It must return a non-negative real number and should return a
      # non-negative floating-point number
      # Example: To set the 1st atb value of enemies when battler start normally
      #          as x%, set this as %Q(@ecatb_val[:atb] = x)
      :normal_enemy_1st_ecatb_val => %Q(@ecatb_val[:atb] = 0.0),

      # Sets the 1st atb value of actors when battles start with preemptive
      # Its corresponding method's created under Game_Actor and Game_Enemy
      # It must return a non-negative real number and should return a
      # non-negative floating-point number
      # Example: To set the 1st atb value of actors when battler start with
      #          preemptive as x%, set this as %Q(@ecatb_val[:atb] = x)
      :preemptive_actor_1st_ecatb_val => %Q(@ecatb_val[:atb] = 100.0),

      # Sets the 1st atb value of enemies when battles start with preemptive
      # Its corresponding method's created under Game_Actor and Game_Enemy
      # It must return a non-negative real number and should return a
      # non-negative floating-point number
      # Example: To set the 1st atb value of enemies when battler start with
      #          preemptive as x%, set this as %Q(@ecatb_val[:atb] = x)
      :preemptive_enemy_1st_ecatb_val => %Q(@ecatb_val[:atb] = 0.0),

      # Sets the 1st atb value of actors when battles start with surprise
      # Its corresponding method's created under Game_Actor and Game_Enemy
      # It must return a non-negative real number and should return a
      # non-negative floating-point number
      # Example: To set the 1st atb value of actors when battler start with
      #          surprise as x%, set this as %Q(@ecatb_val[:atb] = x)
      :surprise_actor_1st_ecatb_val => %Q(@ecatb_val[:atb] = 0.0),

      # Sets the 1st atb value of enemies when battles start with surprise
      # Its corresponding method's created under Game_Actor and Game_Enemy
      # It must return a non-negative real number and should return a
      # non-negative floating-point number
      # Example: To set the 1st atb value of enemies when battler start with
      #          surprise as x%, set this as %Q(@ecatb_val[:atb] = x)
      :surprise_enemy_1st_ecatb_val => %Q(@ecatb_val[:atb] = 100.0),

      # Sets the priority of the ecatb start value notetags to be used
      # Its corresponding method's created under Game_Actor and Game_Enemy
      # It must return an array with elements being either :states, :enemies,
      # :armors, :weapons, :classes or :actors
      # Example: To set actors to have a higher priority than that of states,
      #          set this as %Q([:actors, :states])
      :ecatb_start_val_ord => %Q([:actors, :classes, :weapons, :armors, 
                                  :enemies, :states]),

      # Sets the battler methods included to calculate the sum of each of those
      # methods of battlers in :ecatb_def_sum_battlers
      # Its corresponding method's created under BattleManager
      # It must return an array of symbols being defined battler methods
      # Example: To calculate the sum of luk of all battlers in 
      #          :ecatb_def_sum_battlers, set this as %Q([:luk])
      :ecatb_battlers_def_sum => %Q([:agi]),

      # Sets the battlers to be included to calculate each of their method sums
      # Its corresponding method's created under BattleManager
      # It must return an array of battlers
      # Example: To set all battlers to be included to calculate each of their
      #          method sums, set this as
      #          %Q($game_party.battle_members + $game_troop.members)
      :ecatb_def_sum_battlers => %Q($game_party.alive_members + 
                                    $game_troop.alive_members),

      # Sets if the sum of each battler method in :ecatb_battlers_def_sum of all
      # battlers in :ecatb_def_sum_battlers will be updated
      # Its corresponding method's created under BattleManager
      # Example: To update the sum of each battler method in
      #          :ecatb_battlers_def_sum of all battlers in
      #          :ecatb_def_sum_battlers if switch with id x is on, set this as
      #          %Q($game_switches[x])
      :update_ecatb_battlers_def_sums => %Q(ecatb_def_sum_battlers.any?(
                                            &DoubleX_RMVXA::ECATB::BLOCKS[
                                            :ecatb_refresh])),

      # Sets the action points reduced for all party members upon failed escapes
      # Its corresponding method's created under Game_Actor and Game_Enemy
      # It must return a real number and should return an integer
      # Example: To set the escape action cost as x, set this as %Q(x)
      :ecatb_esc_act_cost => %Q(1),

      # Sets the atb reset value upon each failed escape
      # Its corresponding method's created under Game_Actor and Game_Enemy
      # It must return a real number and should return a floating-point number
      # Example: To add the atb reset value upon a failed escape by x%, set this
      #          as %Q(@ecatb_reset_val + x)
      :ecatb_esc_reset_val => %Q(0.0),

      # It won't be used if :actor_sprite_ecatb_bar returns true
      # Sets the text to be displayed on actor atb bars showing its details
      # The atb bar fill rate and action points can be referneced by percent and
      # action respectively
      # Its corresponding method's created under Window_BattleStatus
      # It must return a string
      # Example: To set the text to be displayed on actor atb bars showing the
      #          actors' action points, set this as %Q(act)
      :actor_ecatb_bar_text => %Q(percent + "% " + act),

      # It won't be used if :actor_sprite_ecatb_bar returns true
      # Sets the word describing and displayed on actor atb bars
      # Its corresponding method's created under Window_BattleStatus
      # It must return a string
      # Example: To use the word "ATB" to describe and be displayed on actor atb
      #          bars, set this as %Q("ATB")
      :actor_ecatb_bar_word => %Q("AP"),

      # It won't be used if :actor_sprite_ecatb_bar returns true
      # Sets the actor atb bar y offset
      # Its corresponding method's created under Window_BattleStatus
      # It must return a real number and should return an integer
      # Example: To set the actor atb bar y offset as x, set this as %Q(x)
      :actor_ecatb_bar_y_add => %Q(12),

      # Sets the atb bar colors
      # It'll be used only if no corresponding color notetags are used
      # Its corresponding method's created under Game_Actor and Game_Enemy
      # It must return an array of colors
      # Example: To set the atb bar colors as text color c and r, g, b, a rgba
      #          values, set this as
      #          %Q([Colour.text_colour(c), Color.new(r, g, b, a)])
      :ecatb_bar_colors => %Q([Colour.text_colour(7), Colour.text_colour(8)]),

      # Sets the priority of the ecatb bar color notetags to be used
      # Its corresponding method's created under Game_Actor and Game_Enemy
      # It must return an array with elements being either :states, :enemies,
      # :armors, :weapons, :classes or :actors
      # Example: To set states to have a higher priority than that of actors,
      #          set this as %Q([:states, :actors])
      :ecatb_bar_color_ord => %Q([:states, :enemies, :armors, :weapons,
                                  :classes, :actors]),

      # (v0.03a+)Sets something to happen right before inputting actions by a
      # battler
      # Its corresponding method's created under Game_Actor and Game_Enemy
      # Example: To call a common event with id x right before inputting actions
      #          by a battler, set this as
      #          %Q($game_temp.reserve_common_event(x))
      :pre_ecatb_input_act => %Q(),

      # (v0.03a+)Sets something to happen right after inputting actions by a
      # battler
      # Its corresponding method's created under Game_Actor and Game_Enemy
      # Example: To call a common event with id x right after inputting actions
      #          by a battler, set this as
      #          %Q($game_temp.reserve_common_event(x))
      :post_ecatb_input_act => %Q(),

      # (v0.03a+)Sets something to happen right before resetting a battler's
      # atb
      # Its corresponding method's created under Game_Actor and Game_Enemy
      # Example: To call a common event with id x right before resetting a
      #          battler's atb, set this as
      #          %Q($game_temp.reserve_common_event(x))
      :pre_ecatb_reset => %Q(),

      # (v0.03a+)Sets something to happen right after resetting a battler's
      # atb
      # Its corresponding method's created under Game_Actor and Game_Enemy
      # Example: To call a common event with id x right after resetting a
      #          battler's atb, set this as
      #          %Q($game_temp.reserve_common_event(x))
      :post_ecatb_reset => %Q(),

      # Sets something to happen right before updating the atb clock
      # Its corresponding method's created under Scene_Battle
      # Example: To support changing atb, charge and cooldown bar colors of all
      #          battlers per frame, set this as
      #          %Q(all_battle_members.each { |mem|
      #               mem.ecatb_note_change[:atb] = 
      #               mem.ecatb_note_change[:charge] = 
      #               mem.ecatb_note_change[:cooldown] = true
      #             })
      :pre_ecatb_update => %Q(),

      # Sets something to happen right after updating the atb clock
      # Its corresponding method's created under Scene_Battle
      # Example: To call a common event with id x right after updating the atb
      #          clock, set this as %Q($game_temp.reserve_common_event(x))
      :post_ecatb_update => %Q()

    }

  #----------------------------------------------------------------------------|
  #  * (v0.05a+)Action                                                         |
  #    Setups configurations of the action features                            |
  #----------------------------------------------------------------------------|

    #--------------------------------------------------------------------------|
    #  Gradual Action Gain Notetag Values                                      |
    #  - Setups gagx used by <ecatb gradual action gain: gagx> notetags        |
    #--------------------------------------------------------------------------|
    # gagx are read at:
    # 1. RPG::Actor, RPG::Class, RPG::EquipItem, RPG::Enemy, RPG::State
    #    - next @ecatb_notes[:act] = $1.downcase.to_sym in load_ecatb_notes
    # gagx are used at:
    # 1. Game_BattlerBase
    #    - @ecatb_notes[note] = ecatb.send(n, self) in set_ecatb_notes
    # gagx are strings of names of methods under DoubleX_RMVXA::ECATB
    # gagx names can only use alphanumeric characters and can't use uppercase
    # letters
    # battler is the battler calling the gagx
    # The below gagx are examples added to help you set your gagx
    # You can freely use, rewrite and/or delete these examples

    # Sets gradual action gain as true
    def self.gag1(battler)
      true
    end

    # Sets gradual action gain as false
    def self.gag2(battler)
      false
    end

    # Sets gradual action gain as the state of switch with id x
    def self.gag3(battler)
      $game_switches[x]
    end

    # Adds new gagx here
    

    #--------------------------------------------------------------------------|
    #  Action Configurations                                                   |
    #  - Setups configurations of the action features                          |
    #  - The value of each configuration is the string of the content of its   |
    #    corresponding method                                                  |
    #--------------------------------------------------------------------------|

    ACTION = {

      # Sets whether a battler gains action points gradually instead of gaining
      # its maximum instantly
      # It'll be used only if no corresponding color notetags are used
      # Its corresponding method's created under Game_Actor and Game_Enemy
      # Example: To set a battler to gain the maximum action points instantly if
      #          switch with id x is on, set this as %Q($game_switches[x])
      :gradual_ecatb_action_gain => %Q(true),

      # Sets the priority of the ecatb gradual action gain notetags to be used
      # Its corresponding method's created under Game_Actor and Game_Enemy
      # It must return an array with elements being either :states, :enemies,
      # :armors, :weapons, :classes or :actors
      # Example: To set states to have a higher priority than that of actors,
      #          set this as %Q([:states, :actors])
      :gradual_ecatb_action_gain_ord => %Q([:states, :enemies, :armors, 
                                            :weapons, :classes, :actors])

    }

  #----------------------------------------------------------------------------|
  #  * Bar                                                                     |
  #    Setups configurations and default notetag values of the bar features    |
  #----------------------------------------------------------------------------|

    #--------------------------------------------------------------------------|
    #  Bar Configurations                                                      |
    #  - Setups configurations and default notetag values of the bar features  |
    #  - The value of each configuration is the string of the content of its   |
    #    corresponding method                                                  |
    #--------------------------------------------------------------------------|

    # Sets if only enemies being dead before are shown with the atb bar
    # It'll only be used if it's not set by
    # <enemy ecatb bar show: kill, bar, percent, act> notetags
    # It must be either true or false
    # Example: To sets only enemies being dead before to be shown with the atb
    # bar, set this as %Q(true)
    BAR_KILL_ENEMY_1ST = %Q(false)

    # Sets if enemy atb bars are shown
    # It'll only be used if it's not set by
    # <enemy ecatb bar show: kill, bar, percent, act> notetags
    # It must be either true or false
    # Example: To hide enemy atb bars, set this as %Q(false)
    ENEMY_BAR_SHOW = %Q(true)

    # Sets if enemy action point is shown on enemy atb bars
    # It'll only be used if it's not set by
    # <enemy ecatb bar show: kill, bar, percent, act> notetags
    # It must be either true or false
    # Example: To hide the enemy action points from the enemy atb bar, set this
    # as %Q(false)
    ENEMY_BAR_SHOW_ACT = %Q(true)

    # Sets if atb fill percent is shown on enemy atb bars
    # It'll only be used if it's not set by
    # <enemy ecatb bar show: kill, bar, percent, act> notetags
    # It must be either true or false
    # Example: To hide the enemy atb fill percent from the enemy atb bar, set
    # this as %Q(false)
    ENEMY_BAR_SHOW_PERCENT = %Q(true)

    BAR = {

      # Sets if the actor atb bars are displayed on their sprites instead
      # Its corresponding method's created under BattleManager
      # It must always return the same result during the same battle
      # Example: To display the actor atb bars on their sprites as well if
      #          switch with id x is on, set this as %Q($game_switches[x])
      :actor_sprite_ecatb_bar => %Q(false),

      # (v0.04d+)Sets if the atb and charge/cooldown bars are displayed
      # simultaneously
      # Its corresponding method's created under Game_Actor and Game_Enemy
      # It must return the same value during the same battle
      # Example: To stop displaying atb and charge/cooldown bars simultaneously,
      #          set this as %Q(false)
      :ecatb_bar_multilayer => %Q(true),

      # Sets if battler sprite atb bars are animated
      # Its corresponding method's created under ECATB_Bar
      # Example: To animate the battler sprite atb bars if switch with id x is
      #          on, set this as %Q($game_switches[x])
      :ecatb_bar_ani => %Q(true),

      # Sets the battler sprite atb bar to animate horizontally per frame
      # Its corresponding method's created under ECATB_Bar
      # It must return a real number and should return an integer
      # Example: To set the battler sprite atb bar to animate horizontally by
      #          number of pixels being the value of variable with id x per
      #          frame, set this as %Q($game_variables[x])
      :ecatb_bar_ani_ox => %Q(2),

      # Sets the battler sprite atb bar width and height
      # Its corresponding method's created under ECATB_Bar
      # It must return an array of positive real numbers and should return an
      # array of natural numbers
      # Example: To set the battler sprite atb bar width and height to be the
      #          values of variables with id x and y respectively, set this as
      #          %Q([$game_variables[x], $game_variables[y]])
      :ecatb_bar_wh => %Q([48, 12]),

      # Sets the battler sprite atb bar xy offsets from the host battler sprite
      # Its corresponding method's created under ECATB_Bar
      # It must return an array of real numbers and should return an array of
      # integers
      # Example: To set the battler sprite atb bar x and y offsets as the value
      #          of variables with id a and b respectively, set this as
      #          %Q([$game_variables[a], $game_variables[b]])
      :ecatb_bar_xy_offset => %Q([0, 0]),

      # Sets the battler sprite atb bar z position
      # Its corresponding method's created under ECATB_Bar
      # It must return a non-negative real number and should return a
      # non-negative integer
      # Example: To set the battler sprite atb bar z position as the value of
      #          variable with id x, set this as %Q($game_variables[x])
      :ecatb_bar_z => %Q(0),

      # Sets the text to be displayed on battler sprite atb bars showing its
      # details
      # The atb bar fill rate and action points can be referneced by percent and
      # action respectively
      # Its corresponding method's created under ECATB_Bar
      # It must return a string
      # Example: To set the text to be displayed on battler sprite atb bars
      #          showing the battlers' action points, set this as %Q(act)
      :ecatb_bar_text => %Q(percent + "% " + act),

      # Sets the battler sprite atb bar text color
      # Its corresponding method's created under ECATB_Bar
      # It must return a color
      # Example: To set the battler sprite atb bar text color as r, g, b, a rgba
      #          values, set this as %Q(Color.new(r, g ,b ,a))
      :ecatb_bar_text_color => %Q(Colour.text_colour(0)),

      # Sets the battler sprite atb bar text size
      # Its corresponding method's created under ECATB_Bar
      # It must return a positive real number and should return an integer
      # Example: To set the battler sprite atb bar text saize as the value of
      #          variable with id x, set this as %Q($game_variables[x])
      :ecatb_bar_text_size => %Q(16),

      # Sets the battler sprite atb bar text x and y offsets from the atb bars
      # Its corresponding method's created under ECATB_Bar
      # It must return an array of real numbers and should return an array of
      # integers
      # Example: To set the battler sprite atb bar text x and y offsets from the
      #          atb bars as the values of variables with id a and b
      #          respectively, set this as
      #          %Q([$game_variables[a], $game_variables[b]])
      :ecatb_bar_text_xy_offset => %Q([-1, -1]),

      # Sets the battler sprite atb bar back colors
      # Its corresponding method's created under ECATB_Bar
      # It must return an array of colors
      # Example: To set the battler sprite atb back bar colors as text color c
      #          and r, g, b, a rgba values, set this as
      #          %Q([Colour.text_colour(c), Color.new(r, g, b, a)])
      :ecatb_bar_back_colors => %Q([Colour.text_colour(15), 
                                    Colour.text_colour(15)])

    }

  #----------------------------------------------------------------------------|
  #  * Cancel                                                                  |
  #    Setups configurations of the cancel features                            |
  #----------------------------------------------------------------------------|

    #--------------------------------------------------------------------------|
    #  Cancel Configurations                                                   |
    #  - Setups configurations of the cancel features                          |
    #  - The value of each configuration is the string of the content of its   |
    #    corresponding method                                                  |
    #--------------------------------------------------------------------------|

    CANCEL = {

      # Sets the key opening the cancel window
      # Its corresponding method's created under Scene_Battle
      # It must return a symbol and should return an Input constant
      # Example: To set the cancel window opening key as X, set this as %Q(:X)
      :ecatb_cancel_key => %Q(:SHIFT),

      # Sets the description text of the cancel window
      # Its corresponding method's created under Scene_Battle
      # It must return a string
      # Example: To set the description text of the cancel window as
      #          "Actor name", set this as
      #          %Q($game_party.members[@ecatb_cancel_window.index].name)

      :ecatb_cancel_text => %Q("Select an actor without autobattle nor " +
                               "confusion to\ncancel his/her/its partially " +
                               "charging skill/item.")

    }

  #----------------------------------------------------------------------------|
  #  * Charge                                                                  |
  #    Setups configurations and notetag values of the charge features         |
  #----------------------------------------------------------------------------|

    #--------------------------------------------------------------------------|
    #  Charge Prior Action Cost Notetag Values                                 |
    #  - Setups cpacx used by <ecatb charge prior act cost: cpacx> notetags    |
    #--------------------------------------------------------------------------|
    # cpacx are read at:
    # 1. RPG::UsableItem
    #    - send(:"#{note}=", send(:"#{note}") || val) in load_ecatb_notes
    # cpacx are used at:
    # 1. Game_Battler
    #    - unless ecatb.send(@last_ecatb_item.ecatb_charge_prior_act_cost, self)
    #      in pay_prior_ecatb_charge
    #    - if ecatb.send(item.ecatb_charge_prior_act_cost, self) in
    #      exec_ecatb_act_cost
    #    - !ecatb.send(item.ecatb_charge_prior_act_cost, self) in
    #      ecatb_unison_actor?
    # cpacx shouldn't return random values
    # cpacx are strings of names of methods under DoubleX_RMVXA::ECATB
    # cpacx names can only use alphanumeric characters and can't use uppercase
    # letters
    # battler is the battler calling the cpacx
    # The below cpacx are examples to help you set your cpacx
    # You can freely use, rewrite and/or delete these examples

    # Sets charge prior action cost as true
    def self.cpac1(battler)
      true
    end

    # Sets charge prior action cost as false
    def self.cpac2(battler)
      false
    end

    # Sets charge prior action cost as the state of switch with id x
    def self.cpac3(battler)
      $game_switches[x]
    end

    # Adds new cpacx here
    

    # Sets if action cost is paid after finished charging
    # It'll be used only if no cpacx are used
    # battler is the battler calling the ecatb_charge_prior_act_cost
    # Example: To set the default action costs to be paid after charging if
    #          switch with id x is on, set this as %Q($game_switches[x])
    def self.ecatb_charge_prior_act_cost(battler)
      true
    end

    #--------------------------------------------------------------------------|
    #  Charge Prior Item Cost Notetag Values                                   |
    #  - Setups cpicx used by <ecatb charge prior item cost: cpicx> notetags   |
    #--------------------------------------------------------------------------|
    # cpicx are read at:
    # 1. RPG::UsableItem
    #    - send(:"#{note}=", send(:"#{note}") || val) in load_ecatb_notes
    # cpicx are used at:
    # 1. Game_Battler
    #    - !DoubleX_RMVXA::ECATB.send(skill.ecatb_charge_prior_item_cost, self)
    #      in skill_cost_payable?
    #    - unless DoubleX_RMVXA::ECATB.send(item.ecatb_charge_prior_item_cost,
    #      self)in use_item
    #    - return if ecatb.send(@last_ecatb_item.ecatb_charge_prior_item_cost,
    #      self) in pay_prior_ecatb_charge
    # cpicx shouldn't return random values
    # cpicx are strings of names of methods under DoubleX_RMVXA::ECATB
    # cpicx names can only use alphanumeric characters and can't use uppercase
    # letters
    # battler is the battler calling the cpicx
    # The below cpicx are examples to help you set your cpicx
    # You can freely use, rewrite and/or delete these examples

    # Sets charge prior item cost as true
    def self.cpic1(battler)
      true
    end

    # Sets charge prior item cost as false
    def self.cpic2(battler)
      false
    end

    # Sets charge prior item cost as the state of switch with id x
    def self.cpic3(battler)
      $game_switches[x]
    end

    # Adds new cpicx here
    

    # Sets if item costs are paid after finished charging
    # It'll be used only if no cpicx are used
    # battler is the battler calling ecatb_charge_prior_item_cost
    # Example: To set the default item costs to be paid after charging if switch
    #          with id x is on, set this as %Q($game_switches[x])
    def self.ecatb_charge_prior_item_cost(battler)
      true
    end

    #--------------------------------------------------------------------------|
    #  Charge Rate Notetag Values                                              |
    #  - Setups crx used by <ecatb charge rate: crx> notetags                  |
    #--------------------------------------------------------------------------|
    # crx are read at:
    # 1. RPG::UsableItem
    #    - send(:"#{note}=", send(:"#{note}") || val) in load_ecatb_notes
    # crx are used at:
    # 1. Game_BattlerBase
    #    - DoubleX_RMVXA::ECATB.send(@last_ecatb_item.ecatb_charge_rate, self, 
    #      @last_ecatb_rate[:charge]) in ecatb_charge_gain_rate
    # crx are strings of names of methods under DoubleX_RMVXA::ECATB
    # crx must return a real number and should return a floating-point number
    # crx names can only use alphanumeric characters and can't use uppercase
    # letters
    # battler is the battler calling the crx
    # rate is the atb gain rate of battler
    # The below crx are examples to help you set your crx
    # You can freely use, rewrite and/or delete these examples

    # Sets the charge rate as x% per frame
    def self.cr1(battler, rate)
      x
    end

    # Sets the charge rate as the value of variable with id x * 100% per frame
    def self.cr2(battler, rate)
      $game_variables[x]
    end

    # Sets the charge rate as x times the atb gain rate
    def self.cr3(battler, rate)
      rate * x
    end

    # Adds new crx here
    

    # Sets the default charge rate
    # It'll be used only if no crx are used
    # battler is the battler calling ecatb_charge_rate
    # rate is the atb gain rate of battler
    # Example: To disable charging, set this as %Q(100.0)
    def self.ecatb_charge_rate(battler, rate)
      100.0
    end

    #--------------------------------------------------------------------------|
    #  Charge Configurations                                                   |
    #  - Setups configurations of the charge features                          |
    #  - The value of each configuration is the string of the content of its   |
    #    corresponding method                                                  |
    #--------------------------------------------------------------------------|

    CHARGE = {

      # Sets the charge bar colors
      # It'll be used only if no corresponding color notetags are used
      # Its corresponding method's created under Game_Actor and Game_Enemy
      # It must return an array of colors
      # Example: To set the charge bar colors as text color c and r, g, b, a
      #          rgba values, set this as
      #          %Q([Colour.text_colour(c), Color.new(r, g, b, a)])
      :ecatb_charge_bar_colors => %Q([Colour.text_colour(30), 
                                      Colour.text_colour(31)]),

      # Sets the priority of the ecatb charge bar color notetags to be used
      # Its corresponding method's created under Game_Actor and Game_Enemy
      # It must return an array with elements being either :states, :enemies,
      # :armors, :weapons, :classes or :actors
      # Example: To set states to have a higher priority than that of actors,
      #          set this as %Q([:states, :actors])
      :ecatb_charge_bar_color_ord => %Q([:states, :enemies, :armors, :weapons, 
                                         :classes, :actors]),

      # Sets the party escape charge rate
      # The atb rate can be referneced by charge
      # Its corresponding method's created under Game_Actor
      # It must return a real number and should return a floating-point number
      # Example: To disable party escape charging, set this as %Q(100.0)
      :esc_ecatb_charge_rate => %Q(100.0)

    }

  #----------------------------------------------------------------------------|
  #  * Clock                                                                   |
  #    Setups configurations of the clock features                             |
  #----------------------------------------------------------------------------|

    #--------------------------------------------------------------------------|
    #  Clock Configurations                                                    |
    #--------------------------------------------------------------------------|

    CLOCK = {

      # Shows the atb clock window
      # It's used under Scene_Battle but it doesn't have any associated method
      # Example: To show the atb clock window if switch with id x is on, set
      #          this as %Q($game_switches[x])
      :show_ecatb_clock_window => %Q(true),

      # Sets the atb clock window width and height
      # Its corresponding method's created under ECATB_Clock_Window
      # It must return an array of positive real numbers and should return an
      # array of natural numbers
      # Example: To set the atb clock window width and height as the value of
      #          variables with id x and y respectively, set this as
      #          %Q([$game_variables[x], $game_variables[y]])
      :ecatb_clock_window_wh => %Q([128, 48]),

      # Sets the atb clock window x, y and z positions
      # Its corresponding method's created under ECATB_Clock_Window
      # It must return an array of real numbers and should return an array of
      # integers
      # Example: To set the atb clock window x, y and z positions as the value
      #          of variables with id a, b and c respectively, set this as
      #         %Q([$game_variables[a], $game_variables[b], $game_variables[c]])
      :ecatb_clock_window_xyz => %Q([0, 0, 0]),

      # Sets the turn portion bar colors
      # Its corresponding method's created under ECATB_Clock_Bar
      # It must return an array of colors
      # Example: To set the turn portion bar colors as text color c and r, g, b,
      #          a rgba values, set this as
      #          %Q([Colour.text_colour(c), Color.new(r, g, b, a)])
      :ecatb_clock_bar_colors => %Q([Colour.text_colour(7), 
                                     Colour.text_colour(8)]),

      # Sets the turn portion bar width and height
      # Its corresponding method's created under ECATB_Clock_Bar
      # It must return an array of positive real numbers and should return an
      # array of natural numbers
      # Example: To set the turn portion bar width and height as the value of
      #          variables with id x and y respectively, set this as
      #          %Q([$game_variables[x], $game_variables[y]])
      :ecatb_clock_bar_wh => %Q([104, 12]),

      # Sets the turn portion bar x and y positions
      # Its corresponding method's created under ECATB_Clock_Bar
      # It must return an array of real numbers and should return an array of
      # integers
      # Example: To set the turn portion bar x and y positions as the value of
      #          variables with id x and y respectively, set this as
      #          %Q([$game_variables[x], $game_variables[y]])
      :ecatb_clock_bar_xy => %Q([8, 8]),

      # Sets the way the turn portion and count text are shown
      # The current atb clcok can be referneced by cur_clock
      # The maximum atb clock can be referneced by max_clock
      # The turn count can be referenced by turn_count
      # Its corresponding method's created under ECATB_Clock_Window
      # It must return a string
      # Example: To set the way the turn portion and count text are shown as
      #          "cur_clock/max_clock", set this as
      #          %Q(cur_clock.to_s + "/" + max_clock.to_s)
      :ecatb_clock_text => %Q(cur_clock.to_s + "/" + max_clock.to_s + " " + 
                              turn_count.to_s),

      # Sets the turn portion and count text color
      # Its corresponding method's created under ECATB_Clock_Window
      # It must return a color
      # Example: To set the turn portion and count text color's rgba values as
      #          r, g, b and a, set this as %Q(Color.new(r, g, b, a))
      :ecatb_clock_text_color => %Q(Colour.text_colour(0)),

      # Sets the turn portion and count text size
      # Its corresponding method's created under ECATB_Clock_Window
      # It must return a positive real number and should return a natural number
      # Example: To set the turn portion and count text size as the value of
      #          variable with id x, set this as %Q($game_variables[x])
      :ecatb_clock_text_size => %Q(16),

      # Sets the turn portion and count text x and y positions
      # Its corresponding method's created under ECATB_Clock_Window
      # It must return an array of real numbers and should return an array of
      # integers
      # Example: To set the turn portion and count text x and y positions as the
      #          value of variables with id a and b respectively, set this as
      #          %Q([$game_variables[a], $game_variables[b]])
      :ecatb_clock_text_xy => %Q([0, 4])

    }

  #----------------------------------------------------------------------------|
  #  * Cooldown                                                                |
  #    Setups configurations and notetag values of the cooldown features       |
  #----------------------------------------------------------------------------|

    #--------------------------------------------------------------------------|
    #  Cooldown Rate Notetag Values                                            |
    #  - Setups cdrx used by <ecatb cooldown rate: cdrx> notetags              |
    #--------------------------------------------------------------------------|
    # cdrx are read at:
    # 1. RPG::UsableItem
    #    - send(:"#{note}=", send(:"#{note}") || val) in load_ecatb_notes
    # cdrx are used at:
    # 1. Game_BattlerBase
    #    - DoubleX_RMVXA::ECATB.send(@last_ecatb_item.ecatb_cooldown_rate, self,
    #      @last_ecatb_rate[:cooldown]) in ecatb_cooldown_loss_rate
    # The atb rate can be referenced by val
    # cdrx are strings of names of methods under DoubleX_RMVXA::ECATB
    # cdrx must return a real number and should return a floating-point number
    # cdrx names can only use alphanumeric characters and can't use uppercase
    # letters
    # battler is the battler calling the cdrx
    # rate is the atb gain rate of battler
    # The below cdrx are examples to help you set your cdrx
    # You can freely use, rewrite and/or delete these examples

    # Sets the cooldown rate as x% per frame
    def self.cdr1(battler, rate)
      x
    end

    # Sets the cooldown rate as the value of variable with id x* 100% per frame
    def self.cdr2(battler, rate)
      $game_variables[x]
    end

    # Sets the cooldown rate as x times the atb gain rate
    def self.cdr3(battler, rate)
      rate * x
    end

    # Adds new cdrx here
    

    # Sets the default cooldown rate
    # It'll be used only if no cdrx are used
    # battler is the battler calling ecatb_cooldown_rate
    # rate is the atb gain rate of battler
    # Example: To disable cooldown, set this as %Q(100.0)
    def self.ecatb_cooldown_rate(battler, rate)
      100.0
    end

    #--------------------------------------------------------------------------|
    #  Cooldown Configurations                                                 |
    #  - Setups configurations of the cooldown features                        |
    #  - The value of each configuration is the string of the content of its   |
    #    corresponding method                                                  |
    #--------------------------------------------------------------------------|

    COOLDOWN = {

      # Sets the cooldown bar colors
      # It'll be used only if no corresponding color notetags are used
      # Its corresponding method's created under Game_Actor and Game_Enemy
      # It must return an array of colors
      # Example: To set the cooldown bar colors as text color c and r, g, b, a
      #          rgba values, set this as
      #          %Q([Colour.text_colour(c), Color.new(r, g, b, a)])
      :ecatb_cooldown_bar_colors => %Q([Colour.text_colour(19), 
                                        Colour.text_colour(26)]),

      # Sets the priority of the ecatb cooldown bar color notetags to be used
      # Its corresponding method's created under Game_Actor and Game_Enemy
      # It must return an array with elements being either :states, :enemies,
      # :armors, :weapons, :classes or :actors
      # Example: To set states to have a higher priority than that of actors,
      #          set this as %Q([:states, :actors])
      :ecatb_cooldown_bar_color_ord => %Q([:states, :enemies, :armors, 
                                           :weapons, :classes, :actors]),

      # (v0.03a+)Sets something to happen right after finishing cooling down
      # normally
      # Its corresponding method's created under Game_Actor and Game_Enemy
      # Example: To call a common event with id x right after finishing cooling
      #          down normally, set this as
      #          %Q($game_temp.reserve_common_event(x))
      :ecatb_cooldown_finish => %Q(),

      # Sets the failed party escape cooldown rate
      # The atb rate can be referneced by cooldown
      # Its corresponding method's created under Game_Actor
      # It must return a real number and should return a floating-point number
      # Example: To disable failed party escape cooldown, set this as %Q(100.0)
      :esc_ecatb_cooldown_rate => %Q(100.0)

    }

  #----------------------------------------------------------------------------|
  #  * Countdown                                                               |
  #    Setups configurations and notetag values of the countdown features      |
  #----------------------------------------------------------------------------|

    #--------------------------------------------------------------------------|
    #  Countdown Interval Notetag Values                                       |
    #  - Setups cix used by <ecatb countdown interval: cix> notetags           |
    #--------------------------------------------------------------------------|
    # cix are read at:
    # 1. RPG::State
    #    - next @ecatb_countdown_interval = $1.downcase.to_sym in
    #      load_ecatb_notes
    # cix are used at:
    # 1. Game_Battler
    #    - return unless $data_states[state_id].ecatb_countdown_interval in
    #      reset_state_counts
    #    - @ecatb_countdown_clock.each_key(&@ecatb_countdown_updates) in
    #      ecatb_countdown_update
    # cix are strings of names of methods under DoubleX_RMVXA::ECATB
    # cix must return a positive real number and should return a natural number
    # cix names can only use alphanumeric characters and can't use uppercase
    # letters
    # battler is the battler calling the cix
    # The below cix are examples to help you set your cix
    # You can freely use, rewrite and/or delete these examples

    # Sets the countdown interval as x seconds
    def self.ci1(battler)
      x
    end

    # Sets the countdown interval as the number of seconds equal to the value of
    # variable with id x
    def self.ci2(battler)
      $game_variables[x]
    end

    # Adds new cix here
    

    #--------------------------------------------------------------------------|
    #  (v0.05a+)Countdown Configurations                                       |
    #  - Setups configurations of the countdown features                       |
    #  - The value of each configuration is the string of the content of its   |
    #    corresponding method                                                  |
    #--------------------------------------------------------------------------|

    COUNTDOWN = {

      # Sets the minimum countdown interval for all states in frames
      # Its corresponding method's created under Game_Actor and Game_Enemy
      # It must return a natural number
      # Example: To minimum countdown interval for all states in frames as the
      #          half of the number of frames per second, set this as
      #          %Q(Graphics.frame_rate / 2)
      :ecatb_countdown_min => %Q(Graphics.frame_rate)

    }

  #----------------------------------------------------------------------------|
  #  * Force                                                                   |
  #    Setups configurations of the force features                             |
  #----------------------------------------------------------------------------|

    #--------------------------------------------------------------------------|
    #  Force Configurations                                                    |
    #  - Setups configurations of the force features                           |
    #  - The value of each configuration is the string of the content of its   |
    #    corresponding method                                                  |
    #--------------------------------------------------------------------------|

    FORCE = {

      # Sets the key forcing the atb clock to run
      # Its corresponding method's created under Scene_Battle
      # It must return a symbol and should return an Input constant
      # If :ecatb_force_stop_key is pressed before pressing
      # :ecatb_force_run_key, the latter will cancel the former instead of
      # forcing the atb clock to run
      # Pressing :ecatb_force_run_key again will force the atb clock to run
      # Example: To disable this feature, set this as %Q(:unused), where :unused
      #          is an unused keymap
      :ecatb_force_run_key => %Q(:CTRL),

      # Sets the key forcing the atb clock to stop
      # Its corresponding method's created under Scene_Battle
      # It must return a symbol and should return an Input constant
      # If :ecatb_force_run_key is pressed before pressing
      # :ecatb_force_stop_key, the latter will cancel the former instead of
      # forcing the atb clock to stop
      # Example: To disable this feature, set this as %Q(:unused), where :unused
      #          is an unused keymap
      :ecatb_force_stop_key => %Q(:ALT),

      # Shows the atb force window displaying the atb force status
      # It's used under Scene_Battle but it doesn't have any associated method
      # Example: To show the atb force window if switch with id x is on, set
      #          this as %Q($game_switches[x])
      :show_ecatb_force_window => %Q(true),

      # Sets the atb force window width and height
      # Its corresponding method's created under ECATB_Force_Window
      # It must return an array of positive real numbers and should return an
      # array of natural numbers
      # Example: To set the atb force window width and height as the value of
      #          variables with id x and y respectively, set this as
      #          %Q([$game_variables[x], $game_variables[y]])
      :ecatb_force_window_wh => %Q([128, 40]),

      # Sets the atb force widnow x, y and z positions
      # Its corresponding method's created under ECATB_Force_Window
      # It must return an array of real numbers and should return an array of
      # integers
      # Example: To set the atb force window x, y and z positions as the value
      #          of variables with id a, b and c respectively, set this as
      #         %Q([$game_variables[a], $game_variables[b], $game_variables[c]])
      :ecatb_force_window_xyz => %Q([0, 48, 0]),

      # Sets the atb force window text to be displayed when the atb clock isn't
      # forced
      # Its corresponding method's created under ECATB_Force_Window
      # It must return a string
      # Example: To set the atb force window text to be displayed when the atb
      #          clock isn't forced as "nil", set this as %Q("nil")
      :ecatb_force_nil_text => %Q("No Force ATB"),

      # Sets the atb force window text to be displayed when the atb clock's
      # forced to run
      # Its corresponding method's created under ECATB_Force_Window
      # It must return a string
      # Example: To set the atb force window text to be displayed when the atb
      #          clock's force to run as "run", set this as %Q("run")
      :ecatb_force_run_text => %Q("ATB Force Run"),

      # Sets the atb force window text to be displayed when the atb clock's
      # forced to stop
      # Its corresponding method's created under ECATB_Force_Window
      # It must return a string
      # Example: To set the atb force window text to be displayed when the atb
      #          clock's force to run as "stop", set this as %Q("stop")
      :ecatb_force_stop_text => %Q("ATB Force Stop"),

      # Sets the atb force window text color
      # Its corresponding method's created under ECATB_Force_Window
      # It must return a color
      # Example: To set the atb force window text color's rgba values as r, g, b
      #          and a, set this as %Q(Color.new(r, g, b, a))
      :ecatb_force_text_color => %Q(Colour.text_colour(0)),

      # Sets the atb force window text size
      # Its corresponding method's created under ECATB_Force_Window
      # It must return a positive real number and should return a natural number
      # Example: To set the atb force window text size as the value of variable
      #          with id x, set this as %Q($game_variables[x])
      :ecatb_force_text_size => %Q(16),

      # Sets the atb force window text x and y positions
      # Its corresponding method's created under ECATB_Force_Window
      # It must return an array of real numbers and should return an array of
      # integers
      # Example: To set the atb force window text x and y positions as the value
      #          of variables with id a and b respectively, set this as
      #          %Q([$game_variables[a], $game_variables[b]])
      :ecatb_force_text_xy => %Q([0, 0])

    }

  #----------------------------------------------------------------------------|
  #  * Hotkey                                                                  |
  #    Setups configurations of the hotkey features                            |
  #----------------------------------------------------------------------------|

    #--------------------------------------------------------------------------|
    #  Hotkey Configurations                                                   |
    #  - Setups configurations of the hotkey features                          |
    #  - The value of each configuration is the string of the content of its   |
    #    corresponding method                                                  |
    #--------------------------------------------------------------------------|

    HOTKEY = {

      # Sets the hotkeys calling an actor in the status window that can input
      # actions or in the cancel window, or a battler in the target window
      # Its corresponding method's created under Scene_Battle
      # It must return an array of symbols and should return an array of
      # Input constants
      # The ith hotkey calls the actor with index i
      # Nothing will happen if the actor in the status window can't input
      # actions
      # Example: To disable this feature, set this as %Q([])
      :ecatb_battler_hotkeys => %Q([
        :NUMPAD1,
        :NUMPAD2,
        :NUMPAD3,
        :NUMPAD4,
        :NUMPAD5,
        :NUMPAD6,
        :NUMPAD7,
        :NUMPAD8,
        :NUMPAD9,
        :NUMPAD0
      ])

    }

  #----------------------------------------------------------------------------|
  #  * (v0.01a+)Order                                                          |
  #    Setups configurations of the order features                             |
  #----------------------------------------------------------------------------|

    #--------------------------------------------------------------------------|
    #  Order Battler Icon Notetag Values                                       |
    #  - Setups obix used by <ecatb order battler icon: obix> notetags         |
    #--------------------------------------------------------------------------|
    # obix are read at:
    # 1. RPG::Actor, RPG::Class, RPG::EquipItem, RPG::Enemy, RPG::State
    #    - next @ecatb_notes[:order_icon] = $1.downcase.to_sym in
    #      load_ecatb_notes
    # obix are used at:
    # 1. Game_BattlerBase
    #    - @ecatb_notes[note] = ecatb.send(n, self) in set_ecatb_notes
    # obix are strings of names of methods under DoubleX_RMVXA::ECATB
    # obix must return an array with its 1st and 2nd element being a bitmap and
    # a rect respectively
    # obix names can only use alphanumeric characters and can't use uppercase
    # letters
    # battler is the battler calling the obix
    # The below obix are examples added to help you set your obix
    # You can freely use, rewrite and/or delete these examples

    # Uses the actor character graphic with frame at 1st row and 2nd column
    def self.obi1(battler)
      bitmap = Cache.character(battler.actor.character_name)
      w = bitmap.width / 12
      h = bitmap.height / 8
      index = battler.actor.character_index
      [bitmap, Rect.new((index % 4 * 3 + 1) * w, (index / 4 * 4) * h, w, h)]
    end

    # Uses bitmap "Monsters2" in "Characters" with part at 1st row and 3rd
    # column and frame in that part at 1st row and 2nd column
    def self.obi2(battler)
      bitmap = Cache.character("Monster2")
      w = bitmap.width / 12
      h = bitmap.height / 8
      [bitmap, Rect.new((2 % 4 * 3 + 1) * w, (2 / 4 * 4) * h, w, h)]
    end

    # Adds new obix here
    

    #--------------------------------------------------------------------------|
    #  Order Battler Opacity Notetag Values                                    |
    #  - Setups obox used by <ecatb order battler opacity: obox> notetags      |
    #--------------------------------------------------------------------------|
    # obox are read at:
    # 1. RPG::Actor, RPG::Class, RPG::EquipItem, RPG::Enemy, RPG::State
    #    - next @ecatb_notes[:order_opacity] = $1.downcase.to_sym in
    #      load_ecatb_notes
    # obox are used at:
    # 1. Game_BattlerBase
    #    - @ecatb_notes[note] = ecatb.send(n, self) in set_ecatb_notes
    # obox are strings of names of methods under DoubleX_RMVXA::ECATB
    # obox must return a non-negative real number and should return a
    # non-negatve integer
    # obox names can only use alphanumeric characters and can't use uppercase
    # letters
    # battler is the battler calling the obox
    # The below obox are examples added to help you set your obox
    # You can freely use, rewrite and/or delete these examples

    # Sets the opacity of the icon representing its battler order as x
    def self.obo1(battler)
      x
    end

    # Sets the opacity of the icon representing its battler order as the value
    # of variable with id x
    def self.obo2(battler)
      $game_variables[x]
    end

    # Adds new obox here
    

    #--------------------------------------------------------------------------|
    #  Order Battler Scale Notetag Values                                      |
    #  - Setups obsx used by <ecatb order battler scale: obsx> notetags        |
    #--------------------------------------------------------------------------|
    # obsx are read at:
    # 1. RPG::Actor, RPG::Class, RPG::EquipItem, RPG::Enemy, RPG::State
    #    - next @ecatb_notes[:order_scale] = $1.downcase.to_sym in
    #      load_ecatb_notes
    # obsx are used at:
    # 1. Game_BattlerBase
    #    - @ecatb_notes[note] = ecatb.send(n, self) in set_ecatb_notes
    # obsx are strings of names of methods under DoubleX_RMVXA::ECATB
    # obsx must return a positive real number
    # obsx names can only use alphanumeric characters and can't use uppercase
    # letters
    # battler is the battler calling the obsx
    # The below obsx are examples added to help you set your obsx
    # You can freely use, rewrite and/or delete these examples

    # Sets the opacity of the icon representing its battler order as x
    def self.obs1(battler)
      x
    end

    # Sets the opacity of the icon representing its battler order as the value
    # of variable with id x
    def self.obs2(battler)
      $game_variables[x]
    end

    # Adds new obsx here
    

    #--------------------------------------------------------------------------|
    #  Order Battler Z Notetag Values                                          |
    #  - Setups obzx used by <ecatb order battler z: obzx> notetags            |
    #--------------------------------------------------------------------------|
    # obzx are read at:
    # 1. RPG::Actor, RPG::Class, RPG::EquipItem, RPG::Enemy, RPG::State
    #    - next @ecatb_notes[:order_z] = $1.downcase.to_sym in load_ecatb_notes
    # obzx are used at:
    # 1. Game_BattlerBase
    #    - @ecatb_notes[note] = ecatb.send(n, self) in set_ecatb_notes
    # obzx are strings of names of methods under DoubleX_RMVXA::ECATB
    # obzx must return a non-negative real number and should return a
    # non-negatve integer
    # obzx names can only use alphanumeric characters and can't use uppercase
    # letters
    # battler is the battler calling the obzx
    # The below obzx are examples added to help you set your obzx
    # You can freely use, rewrite and/or delete these examples

    # Sets the z position of the icon representing its battler order as x
    def self.obz1(battler)
      x
    end

    # Sets the z position of the icon representing its battler order as the
    # value of variable with id x
    def self.obz2(battler)
      $game_variables[x]
    end

    # Adds new obzx here
    

    #--------------------------------------------------------------------------|
    #  Order Configurations                                                    |
    #  - Setups configurations of the order features                           |
    #  - The value of each configuration is the string of the content of its   |
    #    corresponding method                                                  |
    #--------------------------------------------------------------------------|

    ORDER = {

      # Shows the battler order window
      # It's used under Scene_Battle but it doesn't have any associated method
      # Example: To show the battler atb window if switch with id x is on, set
      #          this as %Q($game_switches[x])
      :show_ecatb_order_window => %Q(true),

      # Sets the battler order window width and height
      # Its corresponding method's created under ECATB_Order_Window
      # It must return an array of positive real numbers and should return an
      # array of natural numbers
      # Example: To set the battler order window width and height as the value
      #          of variables with id x and y respectively, set this as
      #          %Q([$game_variables[x], $game_variables[y]])
      :ecatb_order_window_wh => %Q([128, 60]),

      # Sets the battler order window x, y and z positions
      # Its corresponding method's created under ECATB_Order_Window
      # It must return an array of real numbers and should return an array of
      # integers
      # Example: To set the battler order window x, y and z positions as the
      #          value of variables with id a, b and c respectively, set this as
      #     %Q([$game_variables[a], $game_variables[b], $game_variables[c]])
      :ecatb_order_window_xyz => %Q([0, 88, 0]),

      # Sets the battler order atb bar colors
      # Its corresponding method's created under ECATB_Order_Window
      # It must return an array of colors
      # Example: To set the battler order atb bar colors as text color c and r,
      #          g, b, a rgba values, set this as
      #          %Q([Colour.text_colour(c), Color.new(r, g, b, a)])
      :ecatb_order_bar_colors => %Q([Colour.text_colour(7), 
                                     Colour.text_colour(8)]),

      # Sets the battler order atb charge bar colors
      # Its corresponding method's created under ECATB_Order_Window
      # It must return an array of colors
      # Example: To set the battler order atb charge bar colors as text color c
      #          and r, g, b, a rgba values, set this as
      #          %Q([Colour.text_colour(c), Color.new(r, g, b, a)])
      :ecatb_order_charge_bar_colors => %Q([Colour.text_colour(30), 
                                            Colour.text_colour(31)]),

      # Sets the battler order atb cooldown bar colors
      # Its corresponding method's created under ECATB_Order_Window
      # It must return an array of colors
      # Example: To set the battler order atb cooldown bar colors as text color
      #          c and r, g, b, a rgba values, set this as
      #          %Q([Colour.text_colour(c), Color.new(r, g, b, a)])
      :ecatb_order_cooldown_bar_colors => %Q([Colour.text_colour(19), 
                                              Colour.text_colour(26)]),

      # Sets the battler order bars width and height
      # Its corresponding method's created under ECATB_Order_Window
      # It must return an array of positive real numbers and should return an
      # array of natural numbers
      # Example: To set the battler order bars width and height as the value of
      #          variables with id x and y respectively, set this as
      #          %Q([$game_variables[x], $game_variables[y]])
      :ecatb_order_bar_wh => %Q([108, 12]),

      # Sets the battler order bars x and y positions
      # Its corresponding method's created under ECATB_Order_Window
      # It must return an array of real numbers and should return an array of
      # integers
      # Example: To set the battler order bars x and y positions as the value of
      #          variables with id x and y respectively, set this as
      #          %Q([$game_variables[x], $game_variables[y]])
      :ecatb_order_bar_xy => %Q([0, 12]),

      # Sets the battler order atb bar text
      # Its corresponding method's created under ECATB_Order_Window
      # It must return a string
      # Example: To set the battler order atb bar text as "Norm", set this as
      #          %Q("Norm")
      :ecatb_order_bar_text => %Q("ATB"),

      # Sets the battler order atb charge bar text
      # Its corresponding method's created under ECATB_Order_Window
      # It must return a string
      # Example: To set the battler order atb charge bar text as "Charging", set
      #          this as %Q("Charging")
      :ecatb_order_charge_bar_text => %Q("Charge"),

      # Sets the battler order atb cooldown bar text
      # Its corresponding method's created under ECATB_Order_Window
      # It must return a string
      # Example: To set the battler order atb cooldown bar text as "Cooldown",
      #          set this as %Q("Cooldown")
      :ecatb_order_cooldown_bar_text => %Q("Cool"),

      # Sets the battler order bars text color
      # Its corresponding method's created under ECATB_Order_Window
      # It must return a color
      # Example: To set the battler order bars text color's rgba values as
      #          r, g, b and a, set this as %Q(Color.new(r, g, b, a))
      :ecatb_order_text_color => %Q(Colour.text_colour(0)),

      # Sets the battler order bars text size
      # Its corresponding method's created under ECATB_Order_Window
      # It must return a positive real number and should return a natural number
      # Example: To set the battler order bars text size as the value of
      #          variable with id x, set this as %Q($game_variables[x])
      :ecatb_order_text_size => %Q(12),

      # Sets the battler order bars text x and y positions
      # Its corresponding method's created under ECATB_Order_Window
      # It must return an array of real numbers and should return an array of
      # integers
      # Example: To set the battler order bars text x and y positions as the
      #          value of variables with id a and b respectively, set this as
      #          %Q([$game_variables[a], $game_variables[b]])
      :ecatb_order_text_xy => %Q([2, 14]),

      # Sets the icon representing the battlers in the battler order window
      # It'll be used only if no corresponding order battler icon notetags are
      # used
      # Its corresponding method's created under Game_Actor and Game_Enemy
      # It must return an array with its 1st and 2nd element being a bitmap and
      # a rect respectively
      # Example: To use the icon with index x in the iconset, set this as
      #          %Q(
      #    [Cache.system("Iconset"), Rect.new(x % 16 * 24, x / 16 * 24, 24, 24)]
      #    ),
      :ecatb_order_battler_icon => %Q(
       [Cache.system("Iconset"), Rect.new(121 % 16 * 24, 121 / 16 * 24, 24, 24)]
      ),

      # Sets the priority of the ecatb order battler icon notetags to be used
      # Its corresponding method's created under Game_Actor and Game_Enemy
      # It must return an array with elements being either :states, :enemies,
      # :armors, :weapons, :classes or :actors
      # Example: To set states to have a higher priority than that of actors,
      #          set this as %Q([:states, :actors])
      :ecatb_order_battler_icon_ord => %Q([:states, :enemies, :armors,
                                           :weapons, :classes, :actors]),

      # Sets the opacity of icons representing the battlers in the battler order
      # window
      # It'll be used only if no corresponding order battler icon notetags are
      # used
      # Its corresponding method's created under Game_Actor and Game_Enemy
      # It must return a non-negative real number and should return an integer
      # between 0 and 255
      # Example: To set the opacity of icons representing the actors as the
      #          value of variable with id x, set this as %Q($game_variables[x])
      :ecatb_order_battler_opacity => %Q(255),

      # Sets the priority of the ecatb order battler opacity notetags to be used
      # Its corresponding method's created under Game_Actor and Game_Enemy
      # It must return an array with elements being either :states, :enemies,
      # :armors, :weapons, :classes or :actors
      # Example: To set states to have a higher priority than that of actors,
      #          set this as %Q([:states, :actors])
      :ecatb_order_battler_opacity_ord => %Q([:states, :enemies, :armors, 
                                              :weapons, :classes, :actors]),

      # Sets the scale of icons representing the battlers in the battler order
      # window
      # It'll be used only if no corresponding order battler icon notetags are
      # used
      # Its corresponding method's created under Game_Actor and Game_Enemy
      # It must return a positive real number
      # Example: To set the scale of icons representing the actors as the
      #          value of variable with id x, set this as %Q($game_variables[x])
      :ecatb_order_battler_scale => %Q(0.5),

      # Sets the priority of the ecatb order battler scale notetags to be used
      # Its corresponding method's created under Game_Actor and Game_Enemy
      # It must return an array with elements being either :states, :enemies,
      # :armors, :weapons, :classes or :actors
      # Example: To set states to have a higher priority than that of actors,
      #          set this as %Q([:states, :actors])
      :ecatb_order_battler_scale_ord => %Q([:states, :enemies, :armors, 
                                            :weapons, :classes, :actors]),

      # Sets the z position of icons representing the battlers in the battler
      # order window
      # It'll be used only if no corresponding order battler icon notetags are
      # used
      # Its corresponding method's created under Game_Actor and Game_Enemy
      # It must return a non-negative real number and should return a
      # non-negatve integer
      # Example: To set the z position of icons representing the actors as the
      #          value of variable with id x, set this as %Q($game_variables[x])
      :ecatb_order_battler_z => %Q(500),

      # Sets the priority of the ecatb order battler z notetags to be used
      # Its corresponding method's created under Game_Actor and Game_Enemy
      # It must return an array with elements being either :states, :enemies,
      # :armors, :weapons, :classes or :actors
      # Example: To set states to have a higher priority than that of actors,
      #          set this as %Q([:states, :actors])
      :ecatb_order_battler_z_ord => %Q([:states, :enemies, :armors, :weapons, 
                                        :classes, :actors]),

      # Sets the x position of icons representing the battlers in the battler
      # order window
      # It must return a real number and should return an integer
      # Its corresponding method's created under Game_Actor and Game_Enemy
      # Example: To set the x position of icons representing the battlers as the
      #          value of variable with id x, set this as %Q($game_variables[x])
      :ecatb_order_battler_icon_x => %Q(4),

      # Sets the y position of icons representing the actors in the battler
      # order window
      # It must return a real number and should return an integer
      # Its corresponding method's created under Game_Actor and Game_Enemy
      # Example: To set the y position of icons representing the actors as the
      #          value of variable with id x, set this as %Q($game_variables[x])
      :ecatb_order_actor_icon_y => %Q(36),

      # Sets the y position of icons representing the enemies in the battler
      # order window
      # It must return a real number and should return an integer
      # Its corresponding method's created under Game_Actor and Game_Enemy
      # Example: To set the y position of icons representing the enemies as the
      #          value of variable with id x, set this as %Q($game_variables[x])
      :ecatb_order_enemy_icon_y => %Q(8)

    }

  #----------------------------------------------------------------------------|
  #  * Pool                                                                    |
  #    Setups configurations of the pool features                              |
  #----------------------------------------------------------------------------|

    #--------------------------------------------------------------------------|
    #  Pool Configurations                                                     |
    #  - Setups configurations of the pool features                            |
    #  - The value of each configuration is the string of the content of its   |
    #    corresponding method                                                  |
    #--------------------------------------------------------------------------|

    POOL = {

      # Evaluates the party/troop pool atb value from all actors/enemies' ones
      # The actors/enemies' atb values can be referenced by vals
      # Its corresponding method's created under Game_Party and Game_Troop
      # It must return a non-negative real number and should return a
      # non-negative integer
      # Example: To use the minimum atb value of all actors/enemies, set this as
      #          %Q(vals.empty? ? 0 : vals.min)
      :ecatb_pool_val => %Q(vals.empty? ? 0 : vals.inject(:+) / vals.size),

      # Shows the atb pool window displaying the atb mode
      # It's used under Scene_Battle but it doesn't have any associated method
      # Example: To show the atb pool window if switch with id x is on, set
      #          this as %Q($game_switches[x])
      :show_ecatb_pool_window => %Q(true),

      # Sets the atb pool window width and height
      # Its corresponding method's created under ECATB_Pool_Window
      # It must return an array of positive real numbers and should return an
      # array of natural numbers
      # Example: To set the atb pool window width and height as the value of
      #          variables with id x and y respectively, set this as
      # %Q([$game_variables[x], $game_variables[y]])
      :ecatb_pool_window_wh => %Q([128, 56]),

      # Sets the atb pool widnow x, y and z positions
      # Its corresponding method's created under ECATB_Pool_Window
      # It must return an array of real numbers and should return an array of
      # integers
      # Example: To set the atb pool window x, y and z positions as the value
      #          of variables with id a, b and c respectively, set this as
      # %Q([$game_variables[a], $game_variables[b], $game_variables[c]])
      :ecatb_pool_window_xyz => %Q([0, 148, 0]),

      # Sets the party atb pool window text to be displayed
      # Its corresponding method's created under ECATB_Pool_Window
      # It must return an array of strings
      # The 1st and 2nd element of the array is displayed when the atb pool
      # mode's on and off respectively
      # Example: To set the party atb pool window text to be displayed when the
      #          atb pool mode's on and off as "Party ATB Pool Mode On" and
      #          "Party ATB Pool Mode Off" respectively, set this as 
      #          %Q(["Party ATB Pool Mode On", "Party ATB Pool Mode Off"])
      :ecatb_pool_party_actor_text => %Q(["Party ATB", "Actor ATB"]),

      # Sets the troop atb pool window text to be displayed
      # Its corresponding method's created under ECATB_Pool_Window
      # It must return an array of strings
      # The 1st and 2nd element of the array is displayed when the atb pool
      # mode's on and off respectively
      # Example: To set the troop atb pool window text to be displayed when the
      #          atb pool mode's on and off as "Troop ATB Pool Mode On" and
      #          "Troop ATB Pool Mode Off" respectively, set this as 
      #          %Q(["Troop ATB Pool Mode On", "Troop ATB Pool Mode Off"])
      :ecatb_pool_troop_enemy_text => %Q(["Troop ATB", "Enemy ATB"]),

      # Sets the atb pool window text color
      # Its corresponding method's created under ECATB_Pool_Window
      # It must return a color
      # Example: To set the atb pool window text color's rgba values as r, g, b
      #          and a, set this as %Q(Color.new(r, g, b, a))
      :ecatb_pool_text_color => %Q(Colour.text_colour(0)),

      # Sets the atb pool window text size
      # Its corresponding method's created under ECATB_Pool_Window
      # It must return a positive real number and should return a natural number
      # Example: To set the atb pool window text size as the value of variable
      #          with id x, set this as %Q($game_variables[x])
      :ecatb_pool_text_size => %Q(16),

      # Sets the atb party pool window text x and y positions
      # Its corresponding method's created under ECATB_Pool_Window
      # It must return an array of real numbers and should return an array of
      # integers
      # Example: To set the atb party pool window text x and y positions as the
      #          value of variables with id a and b respectively, set this as
      #          %Q([$game_variables[a], $game_variables[b]])
      :ecatb_pool_party_text_xy => %Q([0, 8]),

      # Sets the atb troop pool window text x and y positions
      # Its corresponding method's created under ECATB_Pool_Window
      # It must return an array of real numbers and should return an array of
      # integers
      # Example: To set the atb troop pool window text x and y positions as the
      #          value of variables with id a and b respectively, set this as
      #          %Q([$game_variables[a], $game_variables[b]])
      :ecatb_pool_troop_text_xy => %Q([0, -8])

    }

  #----------------------------------------------------------------------------|
  #  * SE                                                                      |
  #    Setups configurations of the se features                                |
  #----------------------------------------------------------------------------|

    #--------------------------------------------------------------------------|
    #  SE Ready Act Notetag Values                                             |
    #  - Setups serax used by <ecatb se ready act: serax> notetags             |
    #--------------------------------------------------------------------------|
    # serax are read at:
    # 1. RPG::Actor, RPG::Class, RPG::EquipItem, RPG::Enemy, RPG::State
    #    - next @ecatb_notes[:se] = $1.downcase.to_sym in load_ecatb_notes
    # serax are used at:
    # 1. Game_BattlerBase
    #    - @ecatb_notes[note] = ecatb.send(n, self) in set_ecatb_notes
    # serax are strings of names of methods under DoubleX_RMVXA::ECATB
    # serax names can only use alphanumeric characters and can't use uppercase
    # letters
    # battler is the battler calling the serax
    # The below serax are examples added to help you set your serax
    # You can freely use, rewrite and/or delete these examples

    # Sets the battler ready se as se with name "name", volume volume and pitch
    # pitch
    def self.sera1(battler)
      RPG::SE.new("file", volume, pitch)
    end

    # Disables the use of the battler ready se
    def self.sera2(battler)
      nil
    end

    # Adds new serax here
    

    #--------------------------------------------------------------------------|
    #  SE Configurations                                                       |
    #  - Setups configurations of the se features                              |
    #  - The value of each configuration is the string of the content of its   |
    #    corresponding method                                                  |
    #--------------------------------------------------------------------------|

    SE = {

      # Sets the se to be played when a battler becomes able to act
      # It'll be used only if no corresponding color notetags are used
      # Its corresponding method's created under Game_Actor and Game_Enemy
      # Example: To set the se to be played when a battler becomes able to act
      #          as se with name "name", volume volume and pitch pitch, set this
      #          as %Q(RPG::SE.new("name", volume, pitch))
      :ecatb_se_ready_act => %Q(nil),

      # Sets the priority of the ecatb se ready act notetags to be used
      # Its corresponding method's created under Game_Actor and Game_Enemy
      # It must return an array with elements being either :states, :enemies,
      # :armors, :weapons, :classes or :actors
      # Example: To set states to have a higher priority than that of actors,
      #          set this as %Q([:states, :actors])
      :ecatb_se_ready_act_ord => %Q([:states, :enemies, :armors, :weapons, 
                                     :classes, :actors])

    }

  #----------------------------------------------------------------------------|
  #  * (v0.02a+)Speed                                                          |
  #    Setups configurations and notetag values of the speed features          |
  #----------------------------------------------------------------------------|

    #--------------------------------------------------------------------------|
    #  Speed Reduce Notetag Values                                             |
    #  - Setups srx used by <ecatb speed reduce: srx> notetags                 |
    #--------------------------------------------------------------------------|
    # srx are read at:
    # 1. RPG::Actor, RPG::Class, RPG::EquipItem, RPG::Enemy, RPG::State
    #    - next @ecatb_notes[:speed] << $1.downcase.to_sym in load_ecatb_notes
    # srx are used at:
    # 1. Game_BattlerBase
    #    - ecatb.send(note, self) in set_ecatb_speed_reduce
    # srx are strings of names of methods under DoubleX_RMVXA::ECATB
    # srx must return a non-negative integer
    # srx names can only use alphanumeric characters and can't use uppercase
    # letters
    # battler is the battler calling the srx
    # The below srx are examples to help you set your srx
    # You can freely use, rewrite and/or delete these examples

    # Sets the action input speed reduction as x frames
    def self.sr1(battler)
      battler.instance_exec { @last_ecatb_speed_reduce = x }
    end

    # Sets the action input speed reduction as the number of frames being the
    # value of variable with id x
    def self.sr2(battler)
      battler.instance_exec { @last_ecatb_speed_reduce = $game_variables[x] }
    end

    # Adds the action input speed reduction by x frames
    def self.sr3(battler)
      battler.instance_exec { @last_ecatb_speed_reduce += x }
    end

    # Adds new srx here
    

    #--------------------------------------------------------------------------|
    #  Speed Configurations                                                    |
    #  - Setups configurations of the speed features                           |
    #  - The value of each configuration is the string of the content of its   |
    #    corresponding method                                                  |
    #--------------------------------------------------------------------------|

    SPEED = {

      # Sets the action input speed reduction for enemies and/or actors with
      # autobattle and/or confusion
      # Its corresponding method's created under Game_Actor and Game_Enemy
      # It must return a non-negative integer
      # Example: To set the action input speed reduction for enemies and/or
      #          actors with autobattle and/or confusion as the value of
      #          variable with id x, set this as
      #          %Q(@last_ecatb_speed_reduce = $game_variables[x])
      :ecatb_speed_reduce => %Q(@last_ecatb_speed_reduce = 0),

      # Sets the priority of the ecatb speed reduce notetags to be used
      # Its corresponding method's created under Game_Actor and Game_Enemy
      # It must return an array with elements being either :states, :enemies,
      # :armors, :weapons, :classes or :actors
      # Example: To set actors to have a higher priority than that of states,
      #          set this as %Q([:actors, :states])
      :ecatb_speed_reduce_ord => %Q([:actors, :classes, :weapons, :armors, 
                                     :enemies, :states])

    }

  #----------------------------------------------------------------------------|
  #  * Unison                                                                  |
  #    Setups configurations of the unison features                            |
  #----------------------------------------------------------------------------|

    #--------------------------------------------------------------------------|
    #  Unison Actor Notetag Values                                             |
    #  - Setups uax used by <ecatb unison actor: uax> notetags                 |
    #--------------------------------------------------------------------------|
    # uax are read at:
    # 1. RPG::UsableItem
    #    - send(:"#{note}=", send(:"#{note}") || val) in load_ecatb_notes
    # uax are used at:
    # 1. Game_BattlerBase
    #    - actors = ecatb.send(item.ecatb_unison_actor, self).collect!(
    #      &ecatb::BLOCKS[:usable?]) in usable?
    # 2. Game_Actor
    #    - @ecatb_unison_actors = ecatb.send(
    #      @last_ecatb_item.ecatb_unison_actor, self) in confirm_ecatb_item
    # 3. Window_ItemList
    #    - return battler.usable?(item) if (ecatb = DoubleX_RMVXA::ECATB).send(
    #      item.ecatb_act_cost, battler) > 1 || ecatb.send(
    #      item.ecatb_unison_actor, battler).size > 1 in enable?
    # 4. Scene_Battle
    #    - actors = ecatb.send($data_skills[actor.attack_skill_id].
    #      ecatb_unison_actor, actor).collect!(&ecatb::BLOCKS[:usable?]) in
    #      command_attack
    #    - actors = ecatb.send($data_skills[actor.guard_skill_id].
    #      ecatb_unison_actor, actor).collect!(&ecatb::BLOCKS[:usable?]) in
    #      command_guard
    #    - actors = ecatb.send(window.item.ecatb_unison_actor,
    #      BattleManager.actor) in on_ecatb_unison_item_ok?
    #    - actors = ecatb.send(actor.input.item.ecatb_unison_actor, actor) in
    #      on_ecatb_unison?
    # uax are strings of names of methods under DoubleX_RMVXA::ECATB
    # uax shouldn't return random values
    # uax must return an array of actor ids and the array must have more
    # than 1 actor ids
    # uax names can only use alphanumeric characters and can't use uppercase
    # letters
    # battler is the battler calling the uax
    # The below uax are examples added to help you set your uax
    # You can freely use, rewrite and/or delete these examples

    # Sets the unison actors as those with id x, y and z respectively
    def self.ua1(battler)
      [x, y, z]
    end

    # Adds new uax here
    

    # Don't edit this unless you understand what it does and how it works
    def self.ecatb_unison_actor(battler)
      []
    end

    #--------------------------------------------------------------------------|
    #  Unison Charge Rule Notetag Values                                       |
    #  - Setups ucrx used by <ecatb unison charge rule: ucrx> notetags         |
    #--------------------------------------------------------------------------|
    # ucrx are read at:
    # 1. RPG::UsableItem
    #    - send(:"#{note}=", send(:"#{note}") || val) in load_ecatb_notes
    # ucrx are used at:
    # 1. Game_Actor
    #    - @ecatb_unison_rule[:charge] = ecatb.send(
    #      @last_ecatb_item.ecatb_unison_charge_rule, self) in
    #      confirm_ecatb_item
    # ucrx are strings of names of methods under DoubleX_RMVXA::ECATB
    # ucrx must return a symbol
    # You must implement the rule in ecatb_unison_rules
    # ucrx names can only use alphanumeric characters and can't use uppercase
    # letters
    # battler is the battler calling the ucrx
    # The below ucrx are examples added to help you set your ucrx
    # You can freely use, rewrite and/or delete these examples

    # Sets the unison charge rule as returning the maximum
    def self.ucr1(battler)
      :max
    end

    # Adds new ucrx here
    

    # Sets the default unison charge rule
    # It'll be used for def only if it's no ucrx to use
    # battler is the battler calling ecatb_unison_charge_rule
    # Example: To set the default unison charge rule as returning the minimum,
    # set this as %Q(:min)
    def self.ecatb_unison_charge_rule(battler)
      :avg
    end

    #--------------------------------------------------------------------------|
    #  Unison Cooldown Rule Notetag Values                                     |
    #  - Setups ucdrx used by <ecatb unison cooldown rule: ucdrx> notetags     |
    #--------------------------------------------------------------------------|
    # ucdrx are read at:
    # 1. RPG::UsableItem
    #    - send(:"#{note}=", send(:"#{note}") || val) in load_ecatb_notes
    # ucdrx are used at:
    # 1. Game_Actor
    #    - @ecatb_unison_rule[:cooldown] = ecatb.send(
    #      @last_ecatb_item.ecatb_unison_cooldown_rule, self) in
    #      confirm_ecatb_item
    # ucdrx are strings of names of methods under DoubleX_RMVXA::ECATB
    # ucdrx must return a symbol
    # You must implement the rule in ecatb_unison_rules
    # ucdrx names can only use alphanumeric characters and can't use uppercase
    # letters
    # battler is the battler calling the ucdrx
    # The below UCDRX are examples added to help you set your ucdrx
    # You can freely use, rewrite and/or delete these examples

    # Sets the unison cooldown rule as returning the maximum
    def self.ucdr1(battler)
      :max
    end

    # Adds new ucdrx here
    

    # Sets the default unison charge rule
    # It'll be used for def only if it's no ucdrx to use
    # battler is the battler calling ecatb_unison_cooldown_rule
    # Example: To set the default unison cooldown rule as returning the minimum,
    # set this as %Q(:min)
    def self.ecatb_unison_cooldown_rule(battler)
      :avg
    end

    #--------------------------------------------------------------------------|
    #  Unison Actor Method Notetag Values                                      |
    #  - Setups uadx used by <ecatb unison actor def: uadx> notetags           |
    #--------------------------------------------------------------------------|
    # uadx are read at:
    # 1. RPG::UsableItem
    #    - send(:"#{note}=", send(:"#{note}") || val) in load_ecatb_notes
    # uadx are used at methods included in UNISON_DEFS
    # uadx are strings of names of methods under DoubleX_RMVXA::ECATB
    # uadx must return an array of actor ids
    # uadx names can only use alphanumeric characters and can't use uppercase
    # letters
    # battler is the battler calling the uadx
    # The below uadx are examples added to help you set your uadx
    # You can freely use, rewrite and/or delete these examples

    # Sets the def used to be those of actors with id x, y and z respectively
    def self.uad1(battler)
      [x, y, z]
    end

    # Adds new uadx here
    

    # Don't edit this unless you understand what it does and how it works
    def self.ecatb_unison_actor_def(battler)
      []
    end

    #--------------------------------------------------------------------------|
    #  Unison Method Rule Notetag Values                                       |
    #  - Setups udrx used by <ecatb unison def rule: udrx> notetags            |
    #--------------------------------------------------------------------------|
    # udrx are read at:
    # 1. RPG::UsableItem
    #    - send(:"#{note}=", send(:"#{note}") || val) in load_ecatb_notes
    # udrx are used at methods included in UNISON_DEFS
    # udrx are strings of names of methods under DoubleX_RMVXA::ECATB
    # udrx must return a symbol
    # You must implement the rule in ecatb_unison_rules
    # udrx names can only use alphanumeric characters and can't use uppercase
    # letters
    # battler is the battler calling the udrx
    # The below udrx are examples added to help you set your udrx
    # You can freely use, rewrite and/or delete these examples

    # Sets the unison method rule as returning the maximum
    UDR1 = %Q(:max)
    def self.udr1(battler)
      :max
    end

    # Adds new udrx here
    

    # Sets the default unison method rule
    # It'll be used for def only if it's no udrx to use
    # battler is the battler calling ecatb_unison_def_rule
    # Example: To set the default unison mthod rule as returning the minimum,
    # set this as %Q(:min)
    def self.ecatb_unison_def_rule(battler)
      :avg
    end

    #--------------------------------------------------------------------------|
    #  Unison Configurations                                                   |
    #  - Setups configurations of the unison features                          |
    #  - The value of each configuration is the string of the content of its   |
    #    corresponding method                                                  |
    #--------------------------------------------------------------------------|

    # Sets the battler methods to use the unison method rules
    # It can't be chnaged once set
    # Its keys must be the battler method name symbols
    # Methods with name method_name will be aliased to method_name_ecatb
    UNISON_DEFS = {

      # General Form:
      # [:method_class, :super_class] => [
      #   :method_name
      # ]

      [:Game_BattlerBase] => [
        :hp,
        :mp,
        :tp,
        :mhp,
        :mmp,
        :atk,
        :def,
        :mat,
        :mdf,
        :agi
        # Adds new methods here
        
      ],

      [:Game_Actor, :Game_Battler] => [
        :level
        # Adds new methods here
        
      ]

      # Adds new classes here
      

    }

    UNISON = {

      # Sets if all battlers using the unison skill/item are shown in the
      # battle log window
      # Its corresponding method's created under Game_Actor and Game_Enemy
      # Example: To show all battlers using the unison skill/item if switch with
      #          id x is on, set this as %Q($game_switches[x])
      :show_ecatb_unison_battlers => %Q(true),

      # Implements the unison method rules
      # The unison method of all unison battlers can be referneced by vals
      # The unison method rule can be referenced by rule
      # Its corresponding method's created under Game_Actor and Game_Enemy
      # It must return a real number
      :ecatb_unison_rules => %Q(
        if rule == :min
          vals.min
        elsif rule == :avg
          vals.inject(:+) / vals.size
        elsif rule == :max
          vals.max
        else
          0
        end
      )

    }

#==============================================================================|

#==============================================================================|
#  ** Script Implementations                                                   |
#     You need not edit this part as it's about how this script works          |
#     You need to understand the related parts of a configuration/notetag value|
#     locally to fully utilize that configuration/notetag value                |
#------------------------------------------------------------------------------|
#  * Script Support Info:                                                      |
#    1. Prerequisites                                                          |
#       - Thorough comprehension of how this script works on the user level    |
#       - Thorough comprehension of how Yanfly Engine Ace - Ace Battle Engine  |
#         works                                                                |
#       - Advanced RGSS3 scripting proficiency to fully comprehend this script |
#    2. Method documentation                                                   |
#       - The 1st part describes why this method's rewritten/aliased for       |
#         rewritten/aliased methods or what the method does for new methods    |
#       - The 2nd part describes what the arguments of the method are          |
#       - The 3rd part informs which version rewritten, aliased or created this|
#         method                                                               |
#       - The 4th part informs whether the method's rewritten or new           |
#       - The 5th part informs whether the method's a real or potential hotspot|
#       - The 6th part describes how this method works for new methods only,   |
#         and describes the parts added, removed or rewritten for rewritten or |
#         aliased methods only                                                 |
#       Example:                                                               |
# #--------------------------------------------------------------------------| |
# #  Why rewrite/alias/What this method does                                 | |
# #--------------------------------------------------------------------------| |
# # *argv: What these variables are                                            |
# # &argb: What this block is                                                  |
# def def_name(*argv, &argb) # Version X+; Rewrite/New; Hotspot                |
#   # Added/Removed/Rewritten to do something/How this method works            |
#   def_name_code                                                              |
#   #                                                                          |
# end # def_name                                                               |
#------------------------------------------------------------------------------|

    # Stores all types of configurations
    CONFIG = [CORE, ACTION, BAR, CANCEL, CHARGE, CLOCK, COOLDOWN, COUNTDOWN, 
              FORCE, HOTKEY, ORDER, POOL, SE, SPEED, UNISON]

    # Stores all configurations having methods in BattleManager
    # General form: :config => [
    #                 %Q(arguments),
    #                 %Q(validation check),
    #                 %Q(default value)
    #               ]
    BATTLEMANAGER = {
      :ecatb_esc_init_cond => [
        %Q(),
        %Q(true),
        %Q((list = ecatb_input_list).size >= $game_party.battle_members.size && 
           list.all?(&DoubleX_RMVXA::ECATB::EIC1))
      ],
      :ecatb_esc_charge_cond => [
        %Q(),
        %Q(true),
        %Q($game_party.battle_members.all?(&DoubleX_RMVXA::ECATB::ECC1))
      ],
      :ecatb_esc_exec_cond => [
        %Q(),
        %Q(true),
        %Q($game_party.alive_members.all?(&DoubleX_RMVXA::ECATB::EEC1))
      ],
      :ecatb_esc_suc_cond => [
        %Q(),
        %Q(true),
        %Q((@preemptive || rand < @escape_ratio) && 
           $game_party.alive_members.all?(&DoubleX_RMVXA::ECATB::EIC1))
      ],
      :ecatb_base_fill_t => [
        %Q(),
        %Q(val.is_a?(Numeric) && val >= 0),
        %Q(10)
      ],
      :ecatb_ctb => [
        %Q(),
        %Q(true),
        %Q(false),
      ],
      :ecatb_battlers_def_sum => [
        %Q(),
        %Q(val.is_a?(Array) && 
           val.all?(&DoubleX_RMVXA::ECATB::BLOCKS[:check_sym])),
        %Q([:agi])
      ],
      :ecatb_def_sum_battlers => [
        %Q(),
        %Q(val.is_a?(Array) && 
           val.all?(&DoubleX_RMVXA::ECATB::BLOCKS[:check_game_battler])),
        %Q($game_party.alive_members + $game_troop.alive_members)
      ],
      :update_ecatb_battlers_def_sums => [
        %Q(),
        %Q(true),
        %Q(ecatb_def_sum_battlers.any?(
           &DoubleX_RMVXA::ECATB::BLOCKS[:ecatb_refresh]))
      ],
      :actor_sprite_ecatb_bar => [
        %Q(),
        %Q(true),
        %Q(false)
      ],
    }

    # Stores all configurations having methods in Game_Battler
    # General form: :config => [
    #                 %Q(arguments),
    #                 %Q(validation check),
    #                 %Q(default value)
    #               ]
    GAME_BATTLER = {
      :ecatb_rate_ord => [
        %Q(),
        %Q(val.is_a?(Array) && 
           val.all?(&DoubleX_RMVXA::ECATB::BLOCKS[:check_ord])),
        %Q([:actors, :classes, :weapons, :armors, :enemies, :states])
      ],
      :normal_actor_1st_ecatb_val => [
        %Q(),
        %Q(val.is_a?(Numeric) && val >= 0),
        %Q(0.0)
      ],
      :normal_enemy_1st_ecatb_val => [
        %Q(),
        %Q(val.is_a?(Numeric) && val >= 0),
        %Q(0.0)
      ],
      :preemptive_actor_1st_ecatb_val => [
        %Q(),
        %Q(val.is_a?(Numeric) && val >= 0),
        %Q(100.0)
      ],
      :preemptive_enemy_1st_ecatb_val => [
        %Q(),
        %Q(val.is_a?(Numeric) && val >= 0),
        %Q(0.0)
      ],
      :surprise_actor_1st_ecatb_val => [
        %Q(),
        %Q(val.is_a?(Numeric) && val >= 0),
        %Q(0.0)
      ],
      :surprise_enemy_1st_ecatb_val => [
        %Q(),
        %Q(val.is_a?(Numeric) && val >= 0),
        %Q(100.0)
      ],
      :ecatb_start_val_ord => [
        %Q(),
        %Q(val.is_a?(Array) && 
           val.all?(&DoubleX_RMVXA::ECATB::BLOCKS[:check_ord])),
        %Q([:actors, :classes, :weapons, :armors, :enemies, :states])
      ],
      :pre_ecatb_input_act => [
        %Q(),
        %Q(true),
        %Q()
      ],
      :post_ecatb_input_act => [
        %Q(),
        %Q(true),
        %Q()
      ],
      :pre_ecatb_reset => [
        %Q(),
        %Q(true),
        %Q()
      ],
      :post_ecatb_reset => [
        %Q(),
        %Q(true),
        %Q()
      ],
      :ecatb_bar_colors => [
        %Q(),
        %Q(val.is_a?(Array) && val[0].is_a?(Color) && val[1].is_a?(Color)),
        %Q([Colour.text_colour(7), Colour.text_colour(8)])
      ],
      :ecatb_bar_color_ord => [
        %Q(),
        %Q(val.is_a?(Array) && 
           val.all?(&DoubleX_RMVXA::ECATB::BLOCKS[:check_ord])),
        %Q([:states, :enemies, :armors, :weapons, :classes, :actors])
      ],
      :gradual_ecatb_action_gain => [
        %Q(),
        %Q(true),
        %Q(false),
      ],
      :gradual_ecatb_action_gain_ord => [
        %Q(),
        %Q(val.is_a?(Array) && 
           val.all?(&DoubleX_RMVXA::ECATB::BLOCKS[:check_ord])),
        %Q([:states, :enemies, :armors, :weapons, :classes, :actors])
      ],
      :ecatb_bar_multilayer => [
        %Q(),
        %Q(true),
        %Q(true)
      ],
      :ecatb_charge_bar_colors => [
        %Q(),
        %Q(val.is_a?(Array) && val[0].is_a?(Color) && val[1].is_a?(Color)),
        %Q([Colour.text_colour(30), Colour.text_colour(31)])
      ],
      :ecatb_charge_bar_color_ord => [
        %Q(),
        %Q(val.is_a?(Array) && 
           val.all?(&DoubleX_RMVXA::ECATB::BLOCKS[:check_ord])),
        %Q([:states, :enemies, :armors, :weapons, :classes, :actors])
      ],
      :ecatb_cooldown_bar_colors => [
        %Q(),
        %Q(val.is_a?(Array) && val[0].is_a?(Color) && val[1].is_a?(Color)),
        %Q([Colour.text_colour(19), Colour.text_colour(26)])
      ],
      :ecatb_cooldown_bar_color_ord => [
        %Q(),
        %Q(val.is_a?(Array) && 
           val.all?(&DoubleX_RMVXA::ECATB::BLOCKS[:check_ord])),
        %Q([:states, :enemies, :armors, :weapons, :classes, :actors])
      ],
      :ecatb_cooldown_finish => [
        %Q(),
        %Q(true),
        %Q()
      ],
      :ecatb_countdown_min => [
        %Q(),
        %Q(val.is_a?(Integer) && val >= 0),
        %Q(Graphics.frame_rate)
      ],
      :ecatb_order_battler_icon => [
        %Q(),
        %Q(val.is_a?(Array) && val[0].is_a?(Bitmap) && val[1].is_a?(Rect)),
        %Q(
       [Cache.system("Iconset"), Rect.new(121 % 16 * 24, 121 / 16 * 24, 24, 24)]
        )
      ],
      :ecatb_order_battler_icon_ord => [
        %Q(),
        %Q(val.is_a?(Array) && 
           val.all?(&DoubleX_RMVXA::ECATB::BLOCKS[:check_ord])),
        %Q([:states, :enemies, :armors, :weapons, :classes, :actors])
      ],
      :ecatb_order_battler_opacity => [
        %Q(),
        %Q(val.is_a?(Numeric) && val >= 0),
        %Q(255)
      ],
      :ecatb_order_battler_opacity_ord => [
        %Q(),
        %Q(val.is_a?(Array) && 
           val.all?(&DoubleX_RMVXA::ECATB::BLOCKS[:check_ord])),
        %Q([:states, :enemies, :armors, :weapons, :classes, :actors])
      ],
      :ecatb_order_battler_scale => [
        %Q(),
        %Q(val.is_a?(Numeric) && val >= 0),
        %Q(0.5)
      ],
      :ecatb_order_battler_scale_ord => [
        %Q(),
        %Q(val.is_a?(Array) && 
           val.all?(&DoubleX_RMVXA::ECATB::BLOCKS[:check_ord])),
        %Q([:states, :enemies, :armors, :weapons, :classes, :actors])
      ],
      :ecatb_order_battler_z => [
        %Q(),
        %Q(val.is_a?(Numeric) && val >= 0),
        %Q(500)
      ],
      :ecatb_order_battler_z_ord => [
        %Q(),
        %Q(val.is_a?(Array) && 
           val.all?(&DoubleX_RMVXA::ECATB::BLOCKS[:check_ord])),
        %Q([:states, :enemies, :armors, :weapons, :classes, :actors])
      ],
      :ecatb_order_battler_icon_x => [
        %Q(),
        %Q(val.is_a?(Numeric)),
        %Q(4)
      ],
      :ecatb_se_ready_act => [
        %Q(),
        %Q(true),
        %Q(nil)
      ],
      :ecatb_se_ready_act_ord => [
        %Q(),
        %Q(val.is_a?(Array) && 
           val.all?(&DoubleX_RMVXA::ECATB::BLOCKS[:check_ord])),
        %Q([:states, :enemies, :armors, :weapons, :classes, :actors])
      ],
      :ecatb_speed_reduce => [
        %Q(),
        %Q(val.is_a?(Numeric) && val >= 0),
        %Q(0)
      ],
      :ecatb_speed_reduce_ord => [
        %Q(),
        %Q(val.is_a?(Array) && 
           val.all?(&DoubleX_RMVXA::ECATB::BLOCKS[:check_ord])),
        %Q([:actors, :classes, :weapons, :armors, :enemies, :states])
      ],
      :show_ecatb_unison_battlers => [
        %Q(),
        %Q(true),
        %Q(true)
      ],
      :ecatb_unison_rules => [
        %Q((vals, rule)),
        %Q(val.is_a?(Numeric)),
        %Q(
    if rule == :min
      vals.min
    elsif rule == :avg
      vals.inject(:+) / vals.size
    elsif rule == :max
      vals.max
    end
        )
      ]
    }

    # Stores all configurations having methods in Game_Actor
    # General form: :config => [
    #                 %Q(arguments),
    #                 %Q(validation check),
    #                 %Q(default value)
    #               ]
    GAME_ACTOR = GAME_BATTLER.merge({
      :ecatb_esc_act_cost => [
        %Q(),
        %Q(val.is_a?(Numeric)),
        %Q(1)
      ],
      :ecatb_esc_reset_val => [
        %Q(),
        %Q(val.is_a?(Numeric)),
        %Q(0.0)
      ],
      :esc_ecatb_charge_rate => [
        %Q((charge)),
        %Q(val.is_a?(Numeric) && val >= 0),
        %Q(100.0)
      ],
      :esc_ecatb_cooldown_rate => [
        %Q((cooldown)),
        %Q(val.is_a?(Numeric) && val >= 0),
        %Q(100.0)
      ],
      :ecatb_order_actor_icon_y => [
        %Q(),
        %Q(val.is_a?(Numeric)),
        %Q(36)
      ]
    })

    # (v0.01a+)Stores all configurations having methods in Game_Enemy
    # General form: :config => [
    #                 %Q(arguments),
    #                 %Q(validation check),
    #                 %Q(default value)
    #               ]
    GAME_ENEMY = GAME_BATTLER.merge({
      :ecatb_order_enemy_icon_y => [
        %Q(),
        %Q(val.is_a?(Numeric)),
        %Q(8)
      ]
    })

    # Stores all configurations having methods in Game_Party and Game_Troop
    # General form: :config => [
    #                 %Q(arguments),
    #                 %Q(validation check),
    #                 %Q(default value)
    #               ]
    GAME_PARTY_TROOP = {
      :ecatb_pool_val => [
        %Q((vals)),
        %Q(val.is_a?(Numeric) && val >= 0),
        %Q(vals.empty? ? 0 : vals.inject(:+) / vals.size)
      ]
    }

    # Stores all configurations having methods in ECATB_Bar
    # General form: :config => [
    #                 %Q(arguments),
    #                 %Q(validation check),
    #                 %Q(default value)
    #               ]
    ECATB_BAR = {
      :ecatb_bar_ani => [
        %Q(),
        %Q(true),
        %Q(true)
      ],
      :ecatb_bar_ani_ox => [
        %Q(),
        %Q(val.is_a?(Numeric)),
        %Q(2)
      ],
      :ecatb_bar_wh => [
        %Q(),
        %Q(val.is_a?(Array) && val[0].is_a?(Numeric) && val[0] >= 0 && 
           val[1].is_a?(Numeric) && val[1] >= 0),
        %Q([48, 12])
      ],
      :ecatb_bar_xy_offset => [
        %Q(),
        %Q(val.is_a?(Array) && val[0].is_a?(Numeric) &&val[1].is_a?(Numeric)),
        %Q([0, 0])
      ],
      :ecatb_bar_z => [
        %Q(),
        %Q(val.is_a?(Numeric) && val >= 0),
        %Q(0)
      ],
      :ecatb_bar_text => [
        %Q((percent, act)),
        %Q("val.is_a?(String)"),
        %Q(percent + "% " + act)
      ],
      :ecatb_bar_text_color => [
        %Q(),
        %Q(val.is_a?(Color)),
        %Q(Colour.text_colour(0))
      ],
      :ecatb_bar_text_size => [
        %Q(),
        %Q(val.is_a?(Numeric) && val >= 0),
        %Q(16)
      ],
      :ecatb_bar_text_xy_offset => [
        %Q(),
        %Q(val.is_a?(Array) && val[0].is_a?(Numeric) && val[1].is_a?(Numeric)),
        %Q([-1, -1])
      ],
      :ecatb_bar_back_colors => [
        %Q(),
        %Q(val.is_a?(Array) && val[0].is_a?(Color) && val[1].is_a?(Color)),
        %Q([Colour.text_colour(15), Colour.text_colour(15)])
      ]
    }

    # Stores all configurations having methods in ECATB_Clock_Bar
    # General form: :config => [
    #                 %Q(arguments),
    #                 %Q(validation check),
    #                 %Q(default value)
    #               ]
    ECATB_CLOCK_BAR = {
      :ecatb_clock_bar_colors => [
        %Q(),
        %Q(val.is_a?(Array) && val[0].is_a?(Color) && val[1].is_a?(Color)),
        %Q([Colour.text_colour(7), Colour.text_colour(8)])
      ],
      :ecatb_clock_bar_wh => [
        %Q(),
        %Q(val.is_a?(Array) && val[0].is_a?(Numeric) && val[0] >= 0 && 
           val[1].is_a?(Numeric) && val[1] >= 0),
        %Q([112, 12])
      ],
      :ecatb_clock_bar_xy => [
        %Q(),
        %Q(val.is_a?(Array) && val[0].is_a?(Numeric) && val[1].is_a?(Numeric)),
        %Q([8, 8])
      ]
    }

    # Stores all configurations having methods in Window_BattleStatus
    # General form: :config => [
    #                 %Q(arguments),
    #                 %Q(validation check),
    #                 %Q(default value)
    #               ]
    WINDOW_BATTLESTATUS = {
      :actor_ecatb_bar_text => [
        %Q((percent, act)),
        %Q(val.is_a?(String)),
        %Q(percent + "% " + act)
      ],
      :actor_ecatb_bar_word => [
        %Q(),
        %Q(val.is_a?(String)),
        %Q("AP")
      ],
      :actor_ecatb_bar_y_add => [
        %Q(),
        %Q(val.is_a?(Numeric)),
        %Q(12)
      ]
    }

    # Stores all configurations having methods in ECATB_Clock_Window
    # General form: :config => [
    #                 %Q(arguments),
    #                 %Q(validation check),
    #                 %Q(default value)
    #               ]
    ECATB_CLOCK_WINDOW = {
      :ecatb_clock_window_wh => [
        %Q(),
        %Q(val.is_a?(Array) && val[0].is_a?(Numeric) && val[0] >= 0 && 
           val[1].is_a?(Numeric) && val[1] >= 0),
        %Q([128, 48])
      ],
      :ecatb_clock_window_xyz => [
        %Q(),
        %Q(val.is_a?(Array) && 
           val.all?(&DoubleX_RMVXA::ECATB::BLOCKS[:check_us_num])),
        %Q([0, 0, 0])
      ],
      :ecatb_clock_text => [
        %Q((cur_clock, max_clock, turn_count)),
        %Q(val.is_a?(String)),
        %Q(cur_clock.to_s + "/" + max_clock.to_s + " " + turn_count.to_s)
      ],
      :ecatb_clock_text_color => [
        %Q(),
        %Q(val.is_a?(Color)),
        %Q(Colour.text_colour(0))
      ],
      :ecatb_clock_text_size => [
        %Q(),
        %Q(val.is_a?(Numeric) && val >= 0),
        %Q(16)
      ],
      :ecatb_clock_text_xy => [
        %Q(),
        %Q(val.is_a?(Array) && val[0].is_a?(Numeric) && val[1].is_a?(Numeric)),
        %Q([0, 4])
      ]
    }

    # Stores all configurations having methods in ECATB_Force_Window
    # General form: :config => [
    #                 %Q(arguments),
    #                 %Q(validation check),
    #                 %Q(default value)
    #               ]
    ECATB_FORCE_WINDOW = {
      :ecatb_force_window_wh => [
        %Q(),
        %Q(val.is_a?(Array) && val[0].is_a?(Numeric) && val[0] >= 0 && 
           val[1].is_a?(Numeric) && val[1] >= 0),
        %Q([128, 40])
      ],
      :ecatb_force_window_xyz => [
        %Q(),
        %Q(val.is_a?(Array) && 
           val.all?(&DoubleX_RMVXA::ECATB::BLOCKS[:check_us_num])),
        %Q([0, 48, 0])
      ],
      :ecatb_force_nil_text => [
        %Q(),
        %Q(val.is_a?(String)),
        %Q("No Force ATB")
      ],
      :ecatb_force_run_text => [
        %Q(),
        %Q(val.is_a?(String)),
        %Q("ATB Force Run")
      ],
      :ecatb_force_stop_text => [
        %Q(),
        %Q(val.is_a?(String)),
        %Q("ATB Force Stop")
      ],
      :ecatb_force_text_color => [
        %Q(),
        %Q(val.is_a?(Color)),
        %Q(Colour.text_colour(0))
      ],
      :ecatb_force_text_size => [
        %Q(),
        %Q(val.is_a?(Numeric) && val >= 0),
        %Q(16)
      ],
      :ecatb_force_text_xy => [
        %Q(),
        %Q(val.is_a?(Array) && val[0].is_a?(Numeric) && val[1].is_a?(Numeric)),
        %Q([0, 0])
      ]
    }

    # (v0.01a+)Stores all configurations having methods in ECATB_Order_Window
    # General form: :config => [
    #                 %Q(arguments),
    #                 %Q(validation check),
    #                 %Q(default value)
    #               ]
    ECATB_ORDER_WINDOW = {
      :ecatb_order_window_wh => [
        %Q(),
        %Q(val.is_a?(Array) && val[0].is_a?(Numeric) && val[0] >= 0 && 
           val[1].is_a?(Numeric) && val[1] >= 0),
        %Q([128, 60])
      ],
      :ecatb_order_window_xyz => [
        %Q(),
        %Q(val.is_a?(Array) && 
           val.all?(&DoubleX_RMVXA::ECATB::BLOCKS[:check_us_num])),
        %Q([0, 88, 0])
      ],
      :ecatb_order_bar_colors => [
        %Q(),
        %Q(val.is_a?(Array) && val[0].is_a?(Color) && val[1].is_a?(Color)),
        %Q([Colour.text_colour(7), Colour.text_colour(8)])
      ],
      :ecatb_order_charge_bar_colors => [
        %Q(),
        %Q(val.is_a?(Array) && val[0].is_a?(Color) && val[1].is_a?(Color)),
        %Q([Colour.text_colour(30), Colour.text_colour(31)])
      ],
      :ecatb_order_cooldown_bar_colors => [
        %Q(),
        %Q(val.is_a?(Array) && val[0].is_a?(Color) && val[1].is_a?(Color)),
        %Q([Colour.text_colour(19), Colour.text_colour(26)])
      ],
      :ecatb_order_bar_wh => [
        %Q(),
        %Q(val.is_a?(Array) && val[0].is_a?(Numeric) && val[0] >= 0 && 
           val[1].is_a?(Numeric) && val[1] >= 0),
        %Q([108, 12])
      ],
      :ecatb_order_bar_xy => [
        %Q(),
        %Q(val.is_a?(Array) && val[0].is_a?(Numeric) && val[1].is_a?(Numeric)),
        %Q([0, 12])
      ],
      :ecatb_order_bar_text => [
        %Q(),
        %Q(val.is_a?(String)),
        %Q("ATB")
      ],
      :ecatb_order_charge_bar_text => [
        %Q(),
        %Q(val.is_a?(String)),
        %Q("Charge")
      ],
      :ecatb_order_cooldown_bar_text => [
        %Q(),
        %Q(val.is_a?(String)),
        %Q("Cool")
      ],
      :ecatb_order_text_color => [
        %Q(),
        %Q(val.is_a?(Color) || val.is_a?(Color)),
        %Q(Colour.text_colour(0))
      ],
      :ecatb_order_text_size => [
        %Q(),
        %Q(val.is_a?(Numeric) && val >= 0),
        %Q(12)
      ],
      :ecatb_order_text_xy => [
        %Q(),
        %Q(val.is_a?(Array) && val[0].is_a?(Numeric) && val[1].is_a?(Numeric)),
        %Q([2, 14])
      ]
    }

    # Stores all configurations having methods in ECATB_Pool_Window
    # General form: :config => [
    #                 %Q(arguments),
    #                 %Q(validation check),
    #                 %Q(default value)
    #               ]
    ECATB_POOL_WINDOW = {
      :ecatb_pool_window_wh => [
        %Q(),
        %Q(val.is_a?(Array) && val[0].is_a?(Numeric) && val[0] >= 0 && 
           val[1].is_a?(Numeric) && val[1] >= 0),
        %Q([128, 56])
      ],
      :ecatb_pool_window_xyz => [
        %Q(),
        %Q(val.is_a?(Array) && 
           val.all?(&DoubleX_RMVXA::ECATB::BLOCKS[:check_us_num])),
        %Q([0, 148, 0])
      ],
      :ecatb_pool_party_actor_text => [
        %Q(),
        %Q(val.is_a?(Array) && val[0].is_a?(String) && val[1].is_a?(String)),
        %Q(["Party ATB", "Actor ATB"])
      ],
      :ecatb_pool_troop_enemy_text => [
        %Q(),
        %Q(val.is_a?(Array) && val[0].is_a?(String) && val[1].is_a?(String)),
        %Q(["Troop ATB", "Enemy ATB"])
      ],
      :ecatb_pool_text_color => [
        %Q(),
        %Q(val.is_a?(Color)),
        %Q(Colour.text_colour(0))
      ],
      :ecatb_pool_text_size => [
        %Q(),
        %Q(val.is_a?(Numeric) && val >= 0),
        %Q(16)
      ],
      :ecatb_pool_party_text_xy => [
        %Q(),
        %Q(val.is_a?(Array) && val[0].is_a?(Numeric) && val[1].is_a?(Numeric)),
        %Q([0, 8])
      ],
      :ecatb_pool_troop_text_xy => [
        %Q(),
        %Q(val.is_a?(Array) && val[0].is_a?(Numeric) && val[1].is_a?(Numeric)),
        %Q([0, -8])
      ]
    }

    # Stores all configurations having methods in Scene_Battle
    # General form: :config => [
    #                 %Q(arguments),
    #                 %Q(validation check),
    #                 %Q(default value)
    #               ]
    SCENE_BATTLE = {
      :ecatb_wait_cond => [
        %Q(),
        %Q(true),
        %Q(#{WC1} || #{WC2} && (#{WC3} || #{WC4} || #{WC5} || #{WC6} || 
           #{WC7} || #{WC8} || #{WC9} || #{WC10} || #{WCC1}))
      ],
      :ecatb_turn_type => [
        %Q(),
        %Q(val == :tick || val == :act || val == :battler),
        %Q(:tick)
      ],
      :ecatb_tick_count => [
        %Q(),
        %Q(val.is_a?(Numeric) && val >= 0),
        %Q(10)
      ],
      :ecatb_after_act => [
        %Q(),
        %Q(val.is_a?(Numeric) && val >= 0),
        %Q(10)
      ],
      :ecatb_battler_scale => [
        %Q(),
        %Q(val.is_a?(Array) && val[0].is_a?(Numeric) && val[0] >= 0 && 
           (val[1] == :tick || val[1] == :act)),
        %Q([1, :tick])
      ],
      :ecatb_battler_count => [
        %Q(),
        %Q(val.is_a?(Numeric) && val >= 0),
        %Q($game_party.alive_members.size + $game_troop.alive_members.size)
      ],
      :ecatb_force_act_count => [
        %Q(),
        %Q(true),
        %Q(false)
      ],
      :pre_ecatb_update => [
        %Q(),
        %Q(true),
        %Q()
      ],
      :post_ecatb_update => [
        %Q(),
        %Q(true),
        %Q()
      ],
      :ecatb_cancel_key => [
        %Q(),
        %Q(val.is_a?(Symbol)),
        %Q(:SHIFT)
      ],
      :ecatb_cancel_text=> [
        %Q(),
        %Q(val.is_a?(String)),
        %Q("Select an actor without autobattle norconfusion to\ncancel " +
           "his/her/its partially charging skill/item.")
      ],
      :ecatb_force_run_key => [
        %Q(),
        %Q(val.is_a?(Symbol)),
        %Q(:CTRL)
      ],
      :ecatb_force_stop_key => [
        %Q(),
        %Q(val.is_a?(Symbol)),
        %Q(:ALT)
      ],
      :ecatb_battler_hotkeys => [
        %Q(),
        %Q(val.is_a?(Array) && 
           val.all?(&DoubleX_RMVXA::ECATB::BLOCKS[:check_sym])),
        %Q([:NUMPAD1, :NUMPAD2, :NUMPAD3, :NUMPAD4, :NUMPAD5, :NUMPAD6,
            :NUMPAD7, :NUMPAD8, :NUMPAD9, :NUMPAD0])
      ]
    }

    # Stores all iterator blocks
    # General form: :def_name => iterator_block
    BLOCKS = {
      :check_game_battler => -> v { v.is_a?(Game_Battler) },
      :check_ord => -> v { v == :states || v == :enemies || v == :armors || 
                           v == :weapons || v == :classes || v == :actors },
      :check_sym => -> v { v.is_a?(Symbol) },
      :check_us_num => -> v { v.is_a?(Numeric) && v >= 0 },
      :close_ecatb_windows => -> window { window.hide.deactivate.close },
      :clear_ecatb_blocks => -> mem { mem.clear_ecatb_blocks },
      :create_ecatb_defs => -> mem { mem.create_ecatb_defs },
      :dispose => -> obj { obj.dispose if obj && !obj.disposed? },
      :ecatb_ctb_break? => -> b { b.actor? && b.ecatb_inputable? || 
                                  b.exec_ecatb_act? },
      :ecatb_reset => -> mem { mem.ecatb_reset },
      :ecatb_input_list_1 => -> actor { actor.ecatb_inputable? },
      :ecatb_input_list_2 => -> actor { actor.index },
      :ecatb_on_turn_end => -> mem { mem.on_turn_end },
      :ecatb_refresh => -> battler { battler.ecatb_refresh },
      :ecatb_update_windows => -> w { w.hide.deactivate.close if w.active },
      :ecatb_updates => -> mem { mem.ecatb_updates },
      :init_ecatb_escape => -> mem { mem.init_ecatb_escape },
      :load_ecatb_notes => -> d { d.each(&BLOCKS[:load_ecatb_notes_each]) },
      :load_ecatb_notes_each => -> obj { obj.load_ecatb_notes if obj },
      :pay_ecatb_act_cost => -> actor { actor.pay_ecatb_act_cost },
      :pay_ecatb_esc_cost => -> mem { mem.pay_ecatb_esc_cost if mem.ecatb_esc },
      :refresh_ecatb_windows => ->  window { window.refresh if window.active },
      :reset_ecatb_blocks => -> mem { mem.reset_ecatb_blocks },
      :reset_ecatb_refresh => -> battler { battler.ecatb_refresh = false },
      :sort_screen_x => -> a, b { a.screen_x - b.screen_x },
      :update => -> obj { obj.update },
      :update_ecatb_pool => -> unit {
        next unless unit.ecatb_pool
        if (members = unit.alive_members).any?(&BLOCKS[:update_ecatb_pool_any])
          val = members.collect(&BLOCKS[:update_ecatb_pool_collect])
          max = val.max
          size = val.size
          val = unit.ecatb_pool_val(val)
          val = max if max - val <= Float::EPSILON * size * max
          members.each { |mem|
            mem.ecatb_val[:atb] = val
            mem.ecatb_val_change = false
          }
        end
        next unless members.all?(&BLOCKS[:update_ecatb_pool_all])
        act = 0
        members.each { |mem|
          next if mem.ecatb_act_times_cap
          mem.ecatb_act_times_cap = false
          act += mem.ecatb_act_times_add
          mem.ecatb_act_times -= mem.ecatb_act_times_add
          mem.ecatb_act_times_add = 0
        }
        members.each { |mem| mem.ecatb_act_times += act } if act > 0
      },
      :update_ecatb_pool_any => -> mem { mem.ecatb_val_change },
      :update_ecatb_pool_collect => -> mem { mem.ecatb_val[:atb] },
      :update_ecatb_pool_all => -> mem { mem.ecatb_act_times_add > 0 },
      :update_ecatb_unison => -> mem {
        next unless mem.ecatb_unison_invoker
        actors = mem.ecatb_unison_actors
        if actors.any?(&BLOCKS[:update_ecatb_unison_any_1])
          type = :charge
        elsif actors.any?(&BLOCKS[:update_ecatb_unison_any_2])
          actors &= $game_party.alive_members
          type = :cooldown
        else
          next
        end
        val = actors.collect { |actor| actor.ecatb_val[type] }
        val = mem.ecatb_unison_rules(val, mem.ecatb_unison_rule[type])
        actors.each { |actor| actor.ecatb_val[type] = val }
      },
      :update_ecatb_unison_any_1 => -> actor { actor.ecatb_val[:charge] > 0.0 },
      :update_ecatb_unison_any_2 => -> a { a.ecatb_val[:cooldown] > 0.0 },
      :usable? => -> actor_id { $game_actors[actor_id] },
      :window_battleenemy_update => -> m { m.sprite_effect_type = :whiten }
    }

    # Stores all regular expressions of the non-usableitem notetags
    REGEX = [
      /< *ecatb +color *: *(\w+) *, *(\d+) *, *(\w+) *>/i,
      /< *ecatb +gradual +action +gain *: *(\w+) *>/i,
      /< *ecatb +order +battler +icon *: *(\w+) *>/i,
      /< *ecatb +order +battler +opacity *: *(\w+) *>/i,
      /< *ecatb +order +battler +scale *: *(\w+) *>/i,
      /< *ecatb +order +battler +z *: *(\w+) *>/i,
      /< *ecatb +rate *: *(\w+) *>/i,
      /< *ecatb +se +ready +act *: *(\w+) *>/i,
      /< *ecatb +speed +reduce *: *(\w+) *>/i,
      /< *ecatb +start +val *: *(\d+) *, *(\w+) *>/i,
      /< *enemy +ecatb +bar +show *: *(\w+) *, *(\w+) *, *(\w+) *, *(\w+) *>/i,
      /< *ecatb +countdown +interval *: *(\w+) *>/i,
      /< *ecatb +act +cost *: *(\w+) *>/i,
      /< *ecatb +charge +prior +act +cost *: *(\w+) *>/i,
      /< *ecatb +charge +prior +item +cost *: *(\w+) *>/i, 
      /< *ecatb +charge +rate *: *(\w+) *>/i,
      /< *ecatb +cooldown +rate *: *(\w+) *>/i,
      /< *ecatb +force +act +cost *: *(\w+) *>/i,
      /< *ecatb +reset +val *: *(\w+) *>/i,
      /< *ecatb +unison +actor *: *(\w+) *>/i,
      /< *ecatb +unison +charge +rule *: *(\w+) *>/i,
      /< *ecatb +unison +cooldown +rule *: *(\w+) *>/i,
      /< *ecatb +unison +actor +(\w+) *: *(\w+) *>/i,
      /< *ecatb +unison +(\w+) +rule *: *(\w+) *>/
    ]

    # Stores all regular expressions of the usableitem notetags
    USABLEITEM_NOTES = [
      "ecatb_act_cost",
      "ecatb_charge_prior_act_cost",
      "ecatb_charge_prior_item_cost",
      "ecatb_charge_rate",
      "ecatb_cooldown_rate",
      "ecatb_force_act_cost",
      "ecatb_reset_val",
      "ecatb_unison_actor",
      "ecatb_unison_charge_rule",
      "ecatb_unison_cooldown_rule",
      "ecatb_unison_actor_def",
      "ecatb_unison_def_rule"
    ]

    #Stores all pieces of codes used for reading notetags in all database parts
    NOTE_START = %Q(
  attr_reader :ecatb_notes
  def load_ecatb_notes
    @ecatb_notes = {}
    ecatb = DoubleX_RMVXA::ECATB
    )
    NOTE_MID = %Q(
    [:atb, :charge, :cooldown, :rate, :speed, :start_0, :start_1, :start_2].
    each { |note| @ecatb_notes[note] = [] }
    @note.split(/[\r\n]+/).each { |line|
      if line =~ ecatb::REGEX[0]
        next @ecatb_notes[$1.downcase.to_sym][$2.to_i] ||= $3.downcase.to_sym
      elsif line =~ ecatb::REGEX[1]
        next @ecatb_notes[:act] = $1.downcase.to_sym
      elsif line =~ ecatb::REGEX[2]
        next @ecatb_notes[:order_icon] = $1.downcase.to_sym
      elsif line =~ ecatb::REGEX[3]
        next @ecatb_notes[:order_opacity] = $1.downcase.to_sym
      elsif line =~ ecatb::REGEX[4]
        next @ecatb_notes[:order_scale] = $1.downcase.to_sym
      elsif line =~ ecatb::REGEX[5]
        next @ecatb_notes[:order_z] = $1.downcase.to_sym
      elsif line =~ ecatb::REGEX[6]
        next @ecatb_notes[:rate] << $1.downcase.to_sym
      elsif line =~ ecatb::REGEX[7]
        next @ecatb_notes[:se] = $1.downcase.to_sym
      elsif line =~ ecatb::REGEX[8]
        next @ecatb_notes[:speed] << $1.downcase.to_sym
      elsif line =~ ecatb::REGEX[9]
        next @ecatb_notes[("start_" + $1).to_sym] << $2.downcase.to_sym
    )
    NOTE_QUARTER = %Q(
      end
    }
    )
    NOTE_END = %Q(
  end
    )
    BAR_NOTE_START = %Q(
  attr_accessor :enemy_ecatb_bar_show
    )
    BAR_NOTE_MID = %Q(
    @enemy_ecatb_bar_show = [
      eval(ecatb::BAR_KILL_ENEMY_1ST),
      eval(ecatb::ENEMY_BAR_SHOW),
      eval(ecatb::ENEMY_BAR_SHOW_PERCENT),
      eval(ecatb::ENEMY_BAR_SHOW_ACT),
    ]
    )
    BAR_NOTE_END = %Q(
      elsif line =~ ecatb::REGEX[10]
        next @enemy_ecatb_bar_show = [eval($1.downcase), eval($2.downcase), 
        eval($3.downcase), eval($4.downcase)]
    )
    COUNTDOWN_NOTE_START = %Q(
  attr_accessor :ecatb_countdown_interval
    )
    COUNTDOWN_NOTE_MID = %Q(
      elsif line =~ ecatb::REGEX[11]
        next @ecatb_countdown_interval = $1.downcase.to_sym
    )
    COUNTDOWN_NOTE_END = %Q(
    @auto_removal_timing = 3 if @ecatb_countdown_interval
    )

    # Stores the method load_ecatb_notes in actors, classes and equips
    CLASS_NOTES = EQUIP_NOTES = ACTOR_NOTES = NOTE_START + NOTE_MID + 
    NOTE_QUARTER + NOTE_END

    # Stores the method load_ecatb_notes in enemies
    ENEMY_NOTES = BAR_NOTE_START + NOTE_START + %Q(
    t, f, n = true, false, nil
    ) + BAR_NOTE_MID + NOTE_MID + BAR_NOTE_END + NOTE_QUARTER + NOTE_END

    # Stores the method load_ecatb_notes in states
    STATE_NOTES = BAR_NOTE_START + COUNTDOWN_NOTE_START + NOTE_START + 
                  BAR_NOTE_MID + NOTE_MID + COUNTDOWN_NOTE_MID + BAR_NOTE_END + 
                  NOTE_QUARTER + COUNTDOWN_NOTE_END + NOTE_END

    # Stores the abstract method creator and validator for all configurations
    CHECK_RESET_DEF = {}
    [:BATTLEMANAGER, :GAME_ACTOR, :GAME_ENEMY, :GAME_PARTY_TROOP, 
     :WINDOW_BATTLESTATUS, :ECATB_CLOCK_WINDOW, :ECATB_BAR, :ECATB_CLOCK_BAR, 
     :ECATB_FORCE_WINDOW, :ECATB_ORDER_WINDOW, :ECATB_POOL_WINDOW, 
     :SCENE_BATTLE].each { |key|
      CHECK_RESET_DEF[key] = %Q(
  def create_ecatb_defs
    DoubleX_RMVXA::ECATB::#{key.id2name}.each_key { |config|
      create_ecatb_def(config) unless respond_to?(config)
    }
  end

  def check_ecatb_def(config, check)
    percent = act = ""
    charge = cooldown = cur_clock = max_clock = turn_count = rule = -1
    vals = []
    #{RESCUE_CONFIG_VAL ? "begin" : ""}
    val = eval(config + check[0])
    reset_ecatb_def(config, check, "is invalid.") unless eval(check[1])
    #{RESCUE_CONFIG_VAL ? %Q(rescue Exception => error
    msgbox("This error message's raised:\n" + error.message)
    reset_ecatb_def(config, check, "could crash the game.")
    end) : ""}
  end

  def reset_ecatb_def(config, check, type)
    #{RESET_CONFIG_VAL ? "" : "return"}
    #{SUPPRESS_RESET_CONFIG_VAL_TEXT ? "" : %Q(msgbox("The validation code " + 
    "of " + config + " is\n" + check[1])
    msgbox("The value of " + 
    config + " is\n" + $game_system.send(config.to_sym) + "\nwhich " + type))}
    $game_system.send((config + "=").to_sym, check[2])
    create_ecatb_def(config.to_sym, false)
    #{SUPPRESS_RESET_CONFIG_VAL_TEXT ? "" : %Q(msgbox(
    "Its value is reset to its default:\n" + check[2]))}
  end
      )
    }

    # (v0.02c+)Returns the atb charge gain and cooldown loss rate
    CHARGE_COOLDOWN_RATE = {}
    [:charge, :cooldown].each { |key|
      CHARGE_COOLDOWN_RATE[key] = %Q(
  def ecatb_#{type = key.id2name}_#{key == :charge ? "gain" : "loss"}_rate
    return @ecatb_rate[:#{type}] unless (@last_ecatb_rate[:#{type}] != 
    @last_ecatb_rate[:#{type}] = ecatb_gain_rate) || 
    @ecatb_item_change[:#{type}]
    @ecatb_item_change[:#{type}] = false
    @ecatb_rate[:#{type}] = if @#{key == :charge ? "" : "fail_"}ecatb_esc
      esc_ecatb_#{type}_rate(@last_ecatb_rate[:#{type}])
    else
      DoubleX_RMVXA::ECATB.send(@last_ecatb_item.ecatb_#{type}_rate, self, 
      @last_ecatb_rate[:#{type}])
    end
  end
      )
    }

    # (v0.01a+)Reads all atb order battler icon, opacity, scale and z notetags
    ORDER = {}
    [:icon, :opacity, :scale, :z].each { |key|
      type = key.id2name
      ORDER[key] = %Q(
  def set_ecatb_order_battler_#{type}
    unless ecatb_battler_change?(:order_#{type})
      return @ecatb_notes[:order_#{type}]
    end
    @ecatb_notes[:order_#{type}] = nil
    ecatb_order_battler_#{type}_ord.each { |data|
      if send(@ecatb_item[data][0])
        set_ecatb_notes(send(@ecatb_item[data][1]), :order_#{type})
      end
      return @ecatb_notes[:order_#{type}] if @ecatb_notes[:order_#{type}]
    }
    @ecatb_notes[:order_#{type}] = ecatb_order_battler_#{type}
  end
      )
    }

    # Processes actor hotkeys used by Window_ActorCommand and Window_BattleActor
    ACTOR_HOTKEY = %Q(
  alias process_handling_ecatb process_handling
  def process_handling
    if BattleManager.btype?(:ecatb) && open? && active
      SceneManager.scene.ecatb_battler_hotkeys.each(&@ecatb_hotkey_block)
    end
    process_handling_ecatb
  end # process_handling
    )

    # Updates the positions, width and height and text font update methods
    WINDOW_DEFS = {}
    [:clock, :force, :order, :pool].each { |key|
      klass = key.id2name
      WINDOW_DEFS[key] = %Q(
  def update_pos
    xyz = ecatb_#{klass}_window_xyz
    self.x = xyz[0] if x != xyz[0]
    self.y = xyz[1] if y != xyz[1]
    self.z = xyz[2] if z != xyz[2]
  end

  def update_wh
    wh = ecatb_#{klass}_window_wh
    self.width = wh[0] if width != wh[0]
    self.height = wh[1] if height != wh[1]
  end

  def update_text_font
    if (font = contents.font).color != color = ecatb_#{klass}_text_color
      font.color = color
    end
    return if font.size == size = ecatb_#{klass}_text_size
    font.size = size
  end
      )
    }

    # (v0.04d+)Processes the skill/item target cancellation command
    ON_TARGET_CANCEL = {}
    [:actor, :enemy].each { |key|
      ON_TARGET_CANCEL[key] = %Q(
  alias on_#{key = key.id2name}_cancel_ecatb on_#{key}_cancel
  def on_#{key}_cancel(*argv, &argb)
    return unless actor = BattleManager.actor
    if BattleManager.btype?(:ecatb) && on_ecatb_unison?(:cancel, @#{key}_window)
      return
    end
    on_#{key}_cancel_ecatb(*argv, &argb)
    @status_window.draw_item(actor.index)
  end
      )
    }

    # (v0.04d+)Processes the skill/item selection confirmation command
    ON_SKILL_ITEM_OK = {}
    [:skill, :item].each { |key|
      ON_SKILL_ITEM_OK[key] = %Q(
  alias on_#{key = key.id2name}_ok_ecatb on_#{key}_ok
  def on_#{key}_ok(*argv, &argb)
    return unless actor = BattleManager.actor
    return if on_ecatb_unison_item_ok?(@#{key}_window)
    on_#{key}_ok_ecatb(*argv, &argb)
    @status_window.draw_item(actor.index)
  end
      )
    }

    # (v0.01b+)Creates the atb force, order and pool windows
    CREATE_WINDOW = {}
    [:Force, :Order, :Pool].each { |key|
      name1 = key.id2name
      CREATE_WINDOW[key] = %Q(
  def create_ecatb_#{name2 = name1.downcase}_window
    return if @ecatb_#{name2}_window
    return unless eval($game_system.show_ecatb_#{name2}_window)
    @ecatb_#{name2}_window = 
    ECATB_#{name1}_Window.new#{key == :Force ? "(@ecatb_force_clock)" : ""}
  end
      )
    }

    # (v0.01b+)Closes the atb clock, force, order and pool windows
    CLOSE_WINDOW = {}
    [:clock, :force, :order, :pool].each { |key|
      CLOSE_WINDOW[key] = %Q(
  def close_ecatb_#{name = key.id2name}_window
    @ecatb_#{name}_window.hide.deactivate.close
    @ecatb_#{name}_window.dispose unless @ecatb_#{name}_window.disposed?
    @ecatb_#{name}_window = nil
  end
      )
    }

  end # ECATB

end # DoubleX_RMVXA

if $imported["YEA-BattleEngine"] && !$imported["YSA-CATB"]

#------------------------------------------------------------------------------|

#------------------------------------------------------------------------------|
#  * Load all data's notetags and fixes bugs and edge cases                    |
#------------------------------------------------------------------------------|
class << DataManager # Edit

  #----------------------------------------------------------------------------|
  #  Loads all this script's notetags from the database as well                |
  #----------------------------------------------------------------------------|
  alias load_database_ecatb load_database
  def load_database(*argv, &argb)
    load_database_ecatb(*argv, &argb)
    load_ecatb_notes # Added
  end # load_database

  #----------------------------------------------------------------------------|
  #  Clears and resets all battlers' blocks before and after saving also       |
  #----------------------------------------------------------------------------|
  alias save_game_without_rescue_ecatb save_game_without_rescue
  def save_game_without_rescue(index, &argb)
    clear_ecatb_blocks # Added
    save_game_without_rescue_ecatb(index, &argb)
    init_ecatb_def_blocks # Added
  end # save_game_without_rescue

  #----------------------------------------------------------------------------|
  #  Resets all battlers' blocks and methods after loading as well             |
  #----------------------------------------------------------------------------|
  alias extract_save_contents_ecatb extract_save_contents
  def extract_save_contents(contents, &argb)
    extract_save_contents_ecatb(contents, &argb)
    init_ecatb_def_blocks(true) # Added
  end # extract_save_contents

  def load_ecatb_notes # New
    [$data_actors, $data_classes, $data_skills, $data_items, $data_weapons,
     $data_armors, $data_enemies, $data_states].each(
     &DoubleX_RMVXA::ECATB::BLOCKS[:load_ecatb_notes])
  end # load_ecatb_notes

  #----------------------------------------------------------------------------|
  #  Clears all blocks before serializations and after being unneeded          |
  #----------------------------------------------------------------------------|
  def clear_ecatb_blocks # New
    block = DoubleX_RMVXA::ECATB::BLOCKS[:clear_ecatb_blocks]
    $game_actors.instance_exec { @data.compact.each(&block) }
    $game_troop.members.each(&block)
  end # clear_ecatb_blocks

  #----------------------------------------------------------------------------|
  #  Resets all blocks after serializations and being needed                   |
  #----------------------------------------------------------------------------|
  def init_ecatb_def_blocks(create_def = false) # New
    block = DoubleX_RMVXA::ECATB::BLOCKS
    $game_party.all_members.each(&block[:create_ecatb_defs]) if create_def
    $game_party.all_members.each(&block[:reset_ecatb_blocks])
    $game_troop.members.each(&block[:reset_ecatb_blocks])
  end # init_ecatb_def_blocks

end # DataManager

#------------------------------------------------------------------------------|
#  * Loads all the actor's notetags                                            |
#------------------------------------------------------------------------------|
class RPG::Actor < RPG::BaseItem # Edit

  module_eval(DoubleX_RMVXA::ECATB::ACTOR_NOTES) # New

end # RPG::Actor

#------------------------------------------------------------------------------|
#  * Loads all the class's notetags                                            |
#------------------------------------------------------------------------------|
class RPG::Class < RPG::BaseItem # Edit

  module_eval(DoubleX_RMVXA::ECATB::CLASS_NOTES) # New

end # RPG::Class

#------------------------------------------------------------------------------|
#  * Loads all the enemy's notetags                                            |
#------------------------------------------------------------------------------|
class RPG::Enemy < RPG::BaseItem # Edit

  module_eval(DoubleX_RMVXA::ECATB::ENEMY_NOTES) # New

end # RPG::Enemy

#------------------------------------------------------------------------------|
#  * Loads all the equip's notetags                                            |
#------------------------------------------------------------------------------|
class RPG::EquipItem < RPG::BaseItem # Edit

  module_eval(DoubleX_RMVXA::ECATB::EQUIP_NOTES) # New

end # RPG::EquipItem

#------------------------------------------------------------------------------|
#  * Loads all the state's notetags                                            |
#------------------------------------------------------------------------------|
class RPG::State < RPG::BaseItem # Edit

  module_eval(DoubleX_RMVXA::ECATB::STATE_NOTES) # New

end # RPG::State

class RPG::UsableItem < RPG::BaseItem # Edit

  #----------------------------------------------------------------------------|
  #  New public instance variables                                             |
  #----------------------------------------------------------------------------|
  # The values of all the skill/item's notetags
  DoubleX_RMVXA::ECATB::USABLEITEM_NOTES.each { |note|
    attr_accessor eval(":#{note}")
  }
  #

  def load_ecatb_notes # New
    @ecatb_unison_actor_def = {}
    @ecatb_unison_def_rule = {}
    ecatb = DoubleX_RMVXA::ECATB
    @note.split(/[\r\n]+/).each { |line|
      ecatb::USABLEITEM_NOTES.each_with_index { |note, index|
        next unless line =~ ecatb::REGEX[index + 12]
        if index > 9
          note += "[:#{$1}]"
          val = $2.downcase.to_sym
        else
          val = $1.downcase.to_sym
        end
        send(:"#{note}=", send(:"#{note}") || val)
      }
    }
    ecatb::USABLEITEM_NOTES.each_with_index { |note, index|
      send(:"#{note}=", send(:"#{note}") || note.to_sym) if index < 10
    }
  end # load_ecatb_notes

end # RPG::UsableItem

#------------------------------------------------------------------------------|
#  * Reimplements the the whole battle flow to run the atb system              |
#------------------------------------------------------------------------------|
class << BattleManager # Edit

  #----------------------------------------------------------------------------|
  #  New public instance variables                                             |
  #----------------------------------------------------------------------------|
  attr_accessor :actor_index # Accessed by Scene_Battle to setup actors
  attr_accessor :ecatb_can_esc # The party escape permission flag
  attr_reader :ecatb_actor_act_list # The list of actors that can act
  attr_reader :ecatb_base # The base atb rate determinators
  attr_reader :ecatb_base_change # The base atb rate determinators change flag
  attr_reader :action_battlers # Read by Scene_Battle to execute actions
  attr_reader :phase # Read by Scene_Battle to get the battle phase

  #----------------------------------------------------------------------------|
  #  New private instance variables                                            |
  #----------------------------------------------------------------------------|
  # @ecatb_battlers_def_sums: All method sums of all battlers
  # @ecatb_def_sums: The iteraotr block running all method sums of all battlers
  # @ecatb_esc: The party escape attempt flag
  # @ecatb_pool_reset_lock: The party/troop atb pool reset lock

  alias setup_ecatb setup
  def setup(troop_id, can_escape = true, can_lose = false, &argb)
    setup_ecatb(troop_id, can_escape, can_lose, &argb)
    # Added
    init_ecatb_vars
    create_ecatb_defs
    #
  end # setup

  #----------------------------------------------------------------------------|
  #  Always let actions to be executed at any frame for ecatb battle system    |
  #----------------------------------------------------------------------------|
  alias in_turn_ecatb? in_turn?
  def in_turn? # Hotspot
    btype?(:ecatb) || in_turn_ecatb? # Rewritten
  end # in_turn?

  #----------------------------------------------------------------------------|
  #  Disables the next command for ecatb battle system                         |
  #----------------------------------------------------------------------------|
  alias next_command_ecatb next_command
  def next_command(*argv, &argb)
    # Rewritten
    return false if btype?(:ecatb)
    next_command_ecatb(*argv, &argb)
    #
  end # next_command

  #----------------------------------------------------------------------------|
  #  Disables the prior command for ecatb battle system                        |
  #----------------------------------------------------------------------------|
  alias prior_command_ecatb prior_command
  def prior_command(*argv, &argb)
    # Rewritten
    return false if btype?(:ecatb)
    prior_command_ecatb(*argv, &argb)
    #
  end # prior_command

  #----------------------------------------------------------------------------|
  #  Initializes all battlers' starting atb values and their method sums also  |
  #----------------------------------------------------------------------------|
  alias battle_start_ecatb battle_start
  def battle_start(*argv, &argb)
    battle_start_ecatb(*argv, &argb)
    ecatb_battle_start if btype?(:ecatb) # Added
  end # battle_start

  #----------------------------------------------------------------------------|
  #  Closes all windows that should be closed before ending the battle as well |
  #----------------------------------------------------------------------------|
  alias process_victory_ecatb process_victory
  def process_victory(*argv, &argb)
    # Added
    if btype?(:ecatb) && SceneManager.scene_is?(Scene_Battle)
      SceneManager.scene.close_ecatb_windows
    end
    #
    process_victory_ecatb(*argv, &argb)
  end # process_victory

  #----------------------------------------------------------------------------|
  #  Checks if escape's allowed, no such attempt exists and the conditions' met|
  #----------------------------------------------------------------------------|
  alias process_escape_ecatb process_escape
  def process_escape(*argv, &argb)
    return process_escape_ecatb(*argv, &argb) unless btype?(:ecatb) # Rewritten
    # Added to initializes the escape attempt if all the requirements are met
    return false if @ecatb_esc
    init_ecatb_escape if @ecatb_can_esc && ecatb_esc_init_cond
    false
    #
  end # process_escape

  #----------------------------------------------------------------------------|
  #  Closes all windows that should be closed before ending the battle as well |
  #----------------------------------------------------------------------------|
  alias process_defeat_ecatb process_defeat
  def process_defeat(*argv, &argb)
    # Added
    if btype?(:ecatb) && SceneManager.scene_is?(Scene_Battle)
      SceneManager.scene.close_ecatb_windows
    end
    #
    process_defeat_ecatb(*argv, &argb)
  end # process_defeat

  #----------------------------------------------------------------------------|
  #  Stops making actions for any battler and unselecting any inputable actor  |
  #----------------------------------------------------------------------------|
  alias input_start_ecatb input_start
  def input_start(*argv, &argb)
    # Added
    if btype?(:ecatb)
      @phase = :input
      @surprise = false
    end
    #
    input_start_ecatb(*argv, &argb)
  end # input_start

  #----------------------------------------------------------------------------|
  #  Clears all temporarily stored battlers' blocks as well                    |
  #----------------------------------------------------------------------------|
  alias battle_end_ecatb battle_end # v0.03b+
  def battle_end(result, &argb)
    battle_end_ecatb(result, &argb)
    clear_ecatb_blocks # Added
  end # battle_end

  def init_ecatb_vars # New
    $game_temp.init_ecatb_vars
    @ecatb_actor_act_list = []
    @ecatb_base = { size: -1, sum: -1, val: -1 }
    @ecatb_battlers_def_sums = {}
    @ecatb_can_esc = true
    @ecatb_pool_reset_lock = []
    init_ecatb_block
  end # init_ecatb_vars

  #----------------------------------------------------------------------------|
  #  Initializes the new block to trade memory usage for time performance      |
  #----------------------------------------------------------------------------|
  def init_ecatb_block # New
    # Calls this block instead of an anonymous function per enumerable iteration
    @ecatb_def_sums = -> method {
      @ecatb_battlers_def_sums[method] = ecatb_def_sum_battlers.inject(0) { 
      |sum, battler| sum + battler.send(method) }
    }
    #
  end # init_ecatb_block

  #----------------------------------------------------------------------------|
  #  Clears all temporarily stored battlers' blocks and frees memory as well   |
  #----------------------------------------------------------------------------|
  def clear_ecatb_blocks # v0.05a+; New
    $game_temp.clear_ecatb_vars
    @action_battlers = @ecatb_actor_act_list = @ecatb_base = nil
    @ecatb_battlers_def_sums = @ecatb_def_sums = @ecatb_pool_reset_lock = nil
  end # clear_ecatb_blocks

  #----------------------------------------------------------------------------|
  #  Creates and checks the associated method for each configuration used here |
  #----------------------------------------------------------------------------|
  # config: The configuration requesting its associated method
  # validate: The configuration value validation flag
  def create_ecatb_def(config, validate = true) # New
    # Uses the name and value of configuration as its method's name and contents
    method = config.id2name
    eval(%Q(
  def #{method}#{DoubleX_RMVXA::ECATB::BATTLEMANAGER[config][0]}
    #{$game_system.send(config)}
  end
    ))
    #
    return unless validate
    check_ecatb_def(method, DoubleX_RMVXA::ECATB::BATTLEMANAGER[config])
  end # create_ecatb_def

  #----------------------------------------------------------------------------|
  #  Checks all new methods and resets them to the defaults if they're invalid |
  #----------------------------------------------------------------------------|
  module_eval(DoubleX_RMVXA::ECATB::CHECK_RESET_DEF[:BATTLEMANAGER]) # New

  #----------------------------------------------------------------------------|
  #  Initializes all battlers' starting atb values and their method sums       |
  #----------------------------------------------------------------------------|
  def ecatb_battle_start # New
    type = @preemptive ? :start_1 : @surprise ? :start_2 : :start_0
    $game_party.battle_members.each { |mem| mem.set_ecatb_start_val(type) }
    $game_troop.members.each { |mem| mem.set_ecatb_start_val(type) }
    ecatb_battlers_def_sum.each(&@ecatb_def_sums)
  end # ecatb_battle_start

  #----------------------------------------------------------------------------|
  #  Updates all battlers' atb values and the party escape attempt status      |
  #----------------------------------------------------------------------------|
  def ecatb_update # New; Hotspot
    update_ecatb_base
    ecatb_block_update
    if update_ecatb_battlers_def_sums
      ecatb_battlers_def_sum.each(&@ecatb_def_sums)
    end
    return unless @ecatb_esc
    return pay_ecatb_esc_cost unless ecatb_esc_charge_cond
    ecatb_esc_suc if ecatb_esc_exec_cond
  end # ecatb_update

  def ecatb_block_update # v0.05a+; New; Hotspot
    block = DoubleX_RMVXA::ECATB::BLOCKS
    $game_party.battle_members.each(&block[:ecatb_updates])
    $game_troop.alive_members.each(&block[:ecatb_updates])
    [$game_party, $game_troop].each(&block[:update_ecatb_pool])
    $game_party.alive_members.each(&block[:update_ecatb_unison])
    $game_troop.alive_members.each(&block[:reset_ecatb_refresh])
  end # ecatb_block_update

  #----------------------------------------------------------------------------|
  #  Checks if the atb rate needs to be reevaluated                            |
  #----------------------------------------------------------------------------|
  def update_ecatb_base # New; Hotspot
    # Checks if the number of battlers, methods sums or the fill time's changed
    @ecatb_base_change = false
    base = {
      size: ecatb_def_sum_battlers.size,
      sum: @ecatb_battlers_def_sums,
      val: 100.0 / ecatb_base_fill_t / Graphics.frame_rate
    }
    base.each { |key, val|
      @ecatb_base_change = @ecatb_base[key] = val if @ecatb_base[key] != val
    }
    #
  end # update_ecatb_base

  #----------------------------------------------------------------------------|
  #  Initializes a party escape attempt                                        |
  #----------------------------------------------------------------------------|
  def init_ecatb_escape # New
    $game_message.add(sprintf(Vocab::EscapeStart, $game_party.name))
    @ecatb_esc = true
    # Resets all party members' charge rate and clears all unison data as well
    $game_party.battle_members.each(
    &DoubleX_RMVXA::ECATB::BLOCKS[:init_ecatb_escape])
    #
  end # init_ecatb_escape

  #----------------------------------------------------------------------------|
  #  Executes the fully charged party escape attempt                           |
  #----------------------------------------------------------------------------|
  def ecatb_esc_suc # New
    Sound.play_escape
    ecatb_esc_suc_cond ? process_abort : pay_ecatb_esc_cost
    wait_for_message
  end # ecatb_esc_suc

  #----------------------------------------------------------------------------|
  #  Asks all party members to pay the failed party escape attempt's costs     |
  #----------------------------------------------------------------------------|
  def pay_ecatb_esc_cost # New
    @escape_ratio += set_ecatb_esc_cost_compatibility
    $game_message.add('\.' + Vocab::EscapeFailure)
    block = DoubleX_RMVXA::ECATB::BLOCKS
    $game_party.battle_members.each(&block[:pay_ecatb_esc_cost])
    @ecatb_esc = false
    $game_party.alive_members.each(&block[:ecatb_reset])
  end # pay_ecatb_escape_cost

  #----------------------------------------------------------------------------|
  #  Triggers all battlers' turn end effects and collapses all collapsible ones|
  #----------------------------------------------------------------------------|
  def ecatb_on_turn_end # New
    $game_party.alive_members.each(
    &DoubleX_RMVXA::ECATB::BLOCKS[:ecatb_on_turn_end])
    esc_phase = @ecatb_can_esc || @phase
    $game_troop.alive_members.each { |m|
      m.on_turn_end
      m.perform_collapse_effect if esc_phase && m.enemy? && m.can_collapse?
    }
  end # ecatb_on_turn_end

  #----------------------------------------------------------------------------|
  #  Marks a battler to become able to act and plays that battler's ready se   |
  #----------------------------------------------------------------------------|
  def make_ecatb_act(battler) # New
    # Stores that battler in the actable battler list and actor list for actors
    return if @action_battlers.include?(battler)
    @action_battlers << battler
    @ecatb_actor_act_list << battler if battler.actor?
    battler.make_actions
    battler.pre_ecatb_input_act
    return unless (se = battler.set_ecatb_se_ready_act).is_a?(RPG::SE)
    se.play
    #
  end # make_ecatb_act

  #----------------------------------------------------------------------------|
  #  Marks a battler to become unable to act                                   |
  #----------------------------------------------------------------------------|
  def del_ecatb_act(battler) # New
    # Removes that battler from the actable battler and actor list for actors
    return unless @action_battlers.include?(battler)
    @action_battlers.delete(battler)
    battler.clear_actions
    return unless battler.actor? && @ecatb_actor_act_list.include?(battler)
    @ecatb_actor_act_list.delete(battler)
    clear_actor if actor == self
    #
  end # del_ecatb_act

  #----------------------------------------------------------------------------|
  #  Returns the list of all currently inputable actors                        |
  #----------------------------------------------------------------------------|
  # id : The inputable actor id list request flag
  def ecatb_input_list(id = false) # New; Hotspot
    block = DoubleX_RMVXA::ECATB::BLOCKS
    list = @ecatb_actor_act_list.select(&block[:ecatb_input_list_1])
    id ? list.collect!(&block[:ecatb_input_list_2]) : list
  end # ecatb_input_list

  # actors: The unison actors
  def ecatb_pool_reset(battler, actors) # v0.05a+; New
    # Ensures no repeated ecatb_reset call for any battler including unison ones
    if @ecatb_pool_reset_lock.include?(battler)
      return @ecatb_pool_reset_lock.delete(battler)
    end
    battlers = battler.actor? ? @ecatb_actor_act_list : 
    @action_battlers - @ecatb_actor_act_list
    @ecatb_pool_reset_lock = battlers - [battler]
    (battlers - actors - [battler]).each(
    &DoubleX_RMVXA::ECATB::BLOCKS[:ecatb_reset])
    #
  end # ecatb_pool_reset

  #----------------------------------------------------------------------------|
  #  Checks if the battler atb values should be continually updated            |
  #----------------------------------------------------------------------------|
  def ecatb_ctb_break? # v0.04d+; New; Hotspot
    return true if $game_message.visible
    # Checks if the battle ended, action's executing or command window's showing
    return true if $game_party.all_dead? || $game_troop.all_dead?
    return true unless @phase && @ecatb_can_esc && ecatb_ctb
    return true unless SceneManager.scene_is?(Scene_Battle)
    block = DoubleX_RMVXA::ECATB::BLOCKS
    return true if $game_party.alive_members.any?(&block[:ecatb_refresh])
    return true if $game_troop.alive_members.any?(&block[:ecatb_refresh])
    @action_battlers.any?(&block[:ecatb_ctb_break?])
    #
  end # ecatb_ctb_break?

  #----------------------------------------------------------------------------|
  #  Tries to pick an inputable actor and returns if the attempt succeeded     |
  #----------------------------------------------------------------------------|
  def ecatb_update_act_actor? # v0.04d+; New; Hotspot
    # Points the actor index to the 1st inputable actor if any
    return false if (act_list = ecatb_input_list(true)).empty?
    @actor_index = act_list[0]
    #
  end # ecatb_update_act_actor?

  #----------------------------------------------------------------------------|
  #  Picks the prior or next inputable actor and returns the result            |
  #----------------------------------------------------------------------------|
  # sign: Indicator of whether the prior or next actor is to be picked
  def change_ecatb_actor?(sign) # v0.04d+; New; Potential Hotspot
    # Points the actor index to the prior or next actor if any
    return false if (act_list = ecatb_input_list(true)).empty?
    act_list.sort! { |a, b| a * sign <=> b * sign }.each { |a_index|
      return @actor_index = a_index if @actor_index * sign < a_index * sign
    }
    @actor_index = act_list[0]
    #
  end # change_ecatb_actor?

  #----------------------------------------------------------------------------|
  #  Lets the compatibility fix deals with compatibility issues                |
  #----------------------------------------------------------------------------|
  def set_ecatb_esc_cost_compatibility # New
    0.1
  end # set_ecatb_esc_cost_compatibility

end # BattleManager

#------------------------------------------------------------------------------|
#  * Temporarily stores the blocks right before clearing them                  |
#------------------------------------------------------------------------------|
class Game_Temp # v0.02c+; Edit

  #----------------------------------------------------------------------------|
  #  New public instance variables                                             |
  #----------------------------------------------------------------------------|
  attr_accessor :ecatb_add_actors # The member adding flag
  attr_accessor :ecatb_remove_actors # The member removing flag
  attr_reader :ecatb_unison_actors # All battlers' cached unison actors
  attr_reader :last_ecatb_item # All battlers' cached last used item

  def init_ecatb_vars # v0.05a+; New
    @ecatb_add_actors = []
    @ecatb_remove_actors = []
    @ecatb_unison_actors = {}
    @last_ecatb_item = {}
  end # init_ecatb_vars

  def clear_ecatb_vars # v0.05a+; New
    @ecatb_add_actors = @ecatb_remove_actors = nil
    @ecatb_unison_actors = @last_ecatb_item = nil
  end # clear_ecatb_vars

end # Game_Temp

#------------------------------------------------------------------------------|
#  * Selects the battle system and stores all configuration values             |
#------------------------------------------------------------------------------|
class Game_System # Edit

  #----------------------------------------------------------------------------|
  #  New public instance variables                                             |
  #----------------------------------------------------------------------------|
  # Stores all configuration values
  DoubleX_RMVXA::ECATB::CONFIG.each { |configs|
    configs.each_key { |config| attr_accessor eval(":#{config.id2name}") }
  }
  #

  #----------------------------------------------------------------------------|
  #  Stores all configuration values as well                                   |
  #----------------------------------------------------------------------------|
  alias initialize_ecatb initialize
  def initialize(*argv, &argb)
    initialize_ecatb(*argv, &argb)
    init_ecatb_configs # Added
  end # initialize

  #----------------------------------------------------------------------------|
  #  Set the battle system as :ecatb for using the ecatb battle system         |
  #----------------------------------------------------------------------------|
  alias set_battle_system_ecatb set_battle_system
  def set_battle_system(type, &argb)
    return @battle_system = :ecatb if type == :ecatb # Added
    set_battle_system_ecatb(type, &argb)
  end # set_battle_system

  #----------------------------------------------------------------------------|
  #  Returns :ecatb if using the ecatb battle system                           |
  #----------------------------------------------------------------------------|
  alias battle_system_corrected_ecatb battle_system_corrected
  def battle_system_corrected(type, &argb)
    # Rewritten
    type == :ecatb ? :ecatb : battle_system_corrected_ecatb(type, &argb)
    #
  end # battle_system_corrected

  #----------------------------------------------------------------------------|
  #  Stores all configuration values into this class's new variables           |
  #----------------------------------------------------------------------------|
  def init_ecatb_configs # New
    DoubleX_RMVXA::ECATB::CONFIG.each { |configs|
      configs.each { |config, val| send(:"#{config}=", val) }
    }
  end # init_ecatb_configs

end # Game_System

#------------------------------------------------------------------------------|
#  * Adds the action input confirmation flag for action executions             |
#------------------------------------------------------------------------------|
class Game_Action # Edit

  #----------------------------------------------------------------------------|
  #  New public instance variables                                             |
  #----------------------------------------------------------------------------|
  attr_accessor :last_ecatb_confirm # The last action confirmation flag
  attr_writer :ecatb_confirm # The action confirmation flag

  #----------------------------------------------------------------------------|
  #  Cancel the input confirmation as well                                     |
  #----------------------------------------------------------------------------|
  alias clear_ecatb clear
  def clear(*argv, &argb)
    clear_ecatb(*argv, &argb)
    @ecatb_confirm = @last_ecatb_confirm = false # Added
  end # clear

  #----------------------------------------------------------------------------|
  #  Corrects the action confirmation flag before returning it                 |
  #----------------------------------------------------------------------------|
  def ecatb_confirm # New
    @ecatb_confirm ||= !@subject.inputable?
  end # ecatb_confirm

end # Game_Action

#------------------------------------------------------------------------------|
#  * Implements the battler's calculations and decision making criteria        |
#------------------------------------------------------------------------------|
class Game_BattlerBase # Edit

  #----------------------------------------------------------------------------|
  #  Raises the display redraw and cached notetag value reevaluation flags also|
  #----------------------------------------------------------------------------|
  alias erase_state_ecatb erase_state
  def erase_state(state_id, &argb)
    # Added
    if @states.include?(state_id)
      @ecatb_countdown_clock.delete(state_id)
      @ecatb_countdown_freeze.delete(state_id)
    end
    #
    erase_state_ecatb(state_id, &argb)
    set_ecatb_battler_change # Added
  end # erase_state

  #----------------------------------------------------------------------------|
  #  Raises the display redraw and cached notetag value reevaluation flags also|
  #----------------------------------------------------------------------------|
  alias tp_equal_ecatb tp=
  def tp=(tp, &argb)
    tp_equal_ecatb(tp, &argb)
    set_ecatb_battler_change # Added
  end # tp=

  #----------------------------------------------------------------------------|
  #  Raises the display redraw and cached notetag value reevaluation flags also|
  #----------------------------------------------------------------------------|
  alias refresh_ecatb refresh
  def refresh(*argv, &argb)
    refresh_ecatb(*argv, &argb)
    set_ecatb_battler_change # Added
  end # refresh

  #----------------------------------------------------------------------------|
  #  Resets the battler's atb values and clear all actions as well             |
  #----------------------------------------------------------------------------|
  alias hide_ecatb hide # v0.04c+
  def hide(*argv, &argb)
    hide_ecatb(*argv, &argb)
    ecatb_reset(true) # Added
  end # hide

  #----------------------------------------------------------------------------|
  #  Checks if the user's charging and the costs need to be paid now as well   |
  #----------------------------------------------------------------------------|
  alias skill_cost_payable_ecatb? skill_cost_payable?
  def skill_cost_payable?(skill, &argb)
    return true if skill_cost_payable_ecatb?(skill, &argb) # Rewritten
    # Added
    return false unless BattleManager.btype?(:ecatb)
    return false if @ecatb_val[:charge] <= 0.0
    !DoubleX_RMVXA::ECATB.send(skill.ecatb_charge_prior_item_cost, self)
    #
  end # skill_cost_payable?

  #----------------------------------------------------------------------------|
  #  Checks if all unison battlers have enough action points as well           |
  #----------------------------------------------------------------------------|
  alias usable_ecatb? usable?
  def usable?(item, &argb)
    # Added
    if BattleManager.btype?(:ecatb) && item && item.is_a?(RPG::UsableItem)
      if SceneManager.scene_is?(Scene_Battle)
        ecatb = DoubleX_RMVXA::ECATB
        if actor?
          actors = ecatb.send(item.ecatb_unison_actor, self).collect!(
          &ecatb::BLOCKS[:usable?])
          return ecatb_unison_usable?(item, actors) if actors.size > 1
        end
        return false if @ecatb_val[:charge] <= 0.0 && @ecatb_act_times < 
        ecatb.send(item.ecatb_act_cost, self)
      end
    end
    #
    usable_ecatb?(item, &argb)
  end # usable?(item)

  # act_times: The number of action points
  def ecatb_act_times=(act_times) # New
    return if @ecatb_act_times == act_times
    @ecatb_act_times = act_times
    set_ecatb_battler_change
  end # ecatb_act_times=

  #----------------------------------------------------------------------------|
  #  Raises the display redraw and cached notetag value reevaluation flags     |
  #----------------------------------------------------------------------------|
  def set_ecatb_battler_change # New
    @ecatb_battler_change ||= {}
    [:act, :atb, :charge, :cooldown, :order_icon, :order_opacity, :order_scale, 
     :order_z, :rate, :se, :speed].each { |t| @ecatb_battler_change[t] = true }
    @ecatb_refresh = true
  end # set_ecatb_battler_change

  #----------------------------------------------------------------------------|
  #  Returns the currently displayed atb bar type                              |
  #----------------------------------------------------------------------------|
  def ecatb_bar_type # New; Hotspot
    return :cooldown if @ecatb_val[:cooldown] > 0.0
    @ecatb_val[:charge] > 0.0 ? :charge : :atb
  end # ecatb_bar_type

  #----------------------------------------------------------------------------|
  #  Returns the charge gain and cooldown loss value per frame                 |
  #----------------------------------------------------------------------------|
  # v0.02c+; New; Hotspot
  DoubleX_RMVXA::ECATB::CHARGE_COOLDOWN_RATE.each_value { |v| module_eval(v) }
  #

  #----------------------------------------------------------------------------|
  #  Caches and returns the atb rate                                           |
  #----------------------------------------------------------------------------|
  def ecatb_gain_rate # New; Hotspot
    # Reevaluates the atb rate only if any of its determinators' changed
    return @ecatb_rate[:atb] unless BattleManager.ecatb_base_change || 
    ecatb_battler_change?(:rate)
    @ecatb_rate[:atb] = set_ecatb_gain_rate(BattleManager.ecatb_base.clone)
    #
  end # ecatb_gain_rate

  #----------------------------------------------------------------------------|
  #  Evaluates the value of all atb gain rate notetags using its ordering      |
  #----------------------------------------------------------------------------|
  # base: The base atb gain rate
  def set_ecatb_gain_rate(base) # v0.05a+; New; Potential Hotspot
    ecatb = DoubleX_RMVXA::ECATB
    ecatb_rate_ord.each { |data|
      next unless send(@ecatb_item[data][0])
      send(@ecatb_item[data][1]).each { |item|
        (0..(item.ecatb_notes[:rate].size - 1)).each { |index|
          next unless note = item.ecatb_notes[:rate][index]
          base[:val] = ecatb.send(note, self, base)
        }
      }
    }
    base[:val]
  end # set_ecatb_gain_rate

  #----------------------------------------------------------------------------|
  #  Sets the current battler gradual action gain flag when its notetags change|
  #----------------------------------------------------------------------------|
  def set_gradual_ecatb_act_gain # v0.05a+; New; Hotspot
    # Updates the battler gradual action gain notetags using the current order
    return @ecatb_notes[:act] unless ecatb_battler_change?(:act)
    @ecatb_notes[:act] = nil
    gradual_ecatb_action_gain_ord.each { |data|
      if send(@ecatb_item[data][0])
        set_ecatb_notes(send(@ecatb_item[data][1]), :act)
      end
      return @ecatb_notes[:act] unless @ecatb_notes[:act].nil?
    }
    @ecatb_notes[:act] = gradual_ecatb_action_gain
    #
  end # set_gradual_ecatb_act_gain

  #----------------------------------------------------------------------------|
  #  Sets the color of the current atb bar type when its notetags change       |
  #----------------------------------------------------------------------------|
  # type: The atb type
  def set_ecatb_bar_colors(type) # New; Potential Hotspot
    # Updates the color notetags using the current order of the current atb type
    @ecatb_notes[type].clear
    (color_ord = set_ecatb_bar_color_ord(type))[0].each { |data|
      if send(@ecatb_item[data][0])
        set_ecatb_bar_color_notes(send(@ecatb_item[data][1]), type)
      end
      return if @ecatb_notes[type].size == 2
    }
    color_ord[1].each_with_index { |color, i| @ecatb_notes[type][i] ||= color }
    #
  end # set_ecatb_bar_colors

  #----------------------------------------------------------------------------|
  #  Returns the atb bar color orders and default values for current type      |
  #----------------------------------------------------------------------------|
  # type: The atb type
  def set_ecatb_bar_color_ord(type) # New; Potential Hotspot
    return [ecatb_bar_color_ord, ecatb_bar_colors] if type == :atb
    if type == :charge
      return [ecatb_charge_bar_color_ord, ecatb_charge_bar_colors]
    elsif type == :cooldown
      return [ecatb_cooldown_bar_color_ord, ecatb_cooldown_bar_colors]
    end
    [[], []] # Does nothing if type stores an invalid value
  end # set_ecatb_bar_color_ord(type)

  #----------------------------------------------------------------------------|
  #  Evaluates the value of all atb bar color notetags using their orderings   |
  #----------------------------------------------------------------------------|
  # items: The data containing the notetags
  # note: The notetag type
  def set_ecatb_bar_color_notes(items, note) # v0.05a+; New; Potential Hotspot
    # Reads all item's atb bar color 1 and 2 notetag values
    ecatb = DoubleX_RMVXA::ECATB
    items.each { |item|
      return if @ecatb_notes[note].size >= 2
      n = item.ecatb_notes[note][0]
      @ecatb_notes[note][0] ||= ecatb.send(n, self) if n
      next unless n = item.ecatb_notes[note][1]
      @ecatb_notes[note][1] ||= ecatb.send(n, self)
    }
    #
  end # set_ecatb_bar_color_notes

  #----------------------------------------------------------------------------|
  #  Reads all atb order battler icon, opacity, scale and z notes              |
  #----------------------------------------------------------------------------|
  # v0.01a+; New; Potential Hotspot
  DoubleX_RMVXA::ECATB::ORDER.each_value { |method| module_eval(method) }
  #

  #----------------------------------------------------------------------------|
  #  Sets the current battler ready se when its notetags change                |
  #----------------------------------------------------------------------------|
  def set_ecatb_se_ready_act # New
    # Updates the battler ready se notetags using the current order
    return @ecatb_notes[:se] unless ecatb_battler_change?(:se)
    @ecatb_notes[:se] = nil
    ecatb_se_ready_act_ord.each { |data|
      if send(@ecatb_item[data][0])
        set_ecatb_notes(send(@ecatb_item[data][1]), :se)
      end
      return @ecatb_notes[:se] if @ecatb_notes[:se]
    }
    @ecatb_notes[:se] = ecatb_se_ready_act
    #
  end # set_ecatb_se_ready_act

  #----------------------------------------------------------------------------|
  #  Sets the current battler action input speed reduction in frames           |
  #----------------------------------------------------------------------------|
  def set_ecatb_speed_reduce # v0.02a+; New
    # Updates the battler speed reduce notetags using the current order
    ecatb = DoubleX_RMVXA::ECATB
    ecatb_speed_reduce_ord.each { |data|
      next unless send(@ecatb_item[data][0])
      send(@ecatb_item[data][1]).each { |item|
        (0..(item.ecatb_notes[:speed].size - 1)).each { |index|
          next unless note = item.ecatb_notes[:speed][index]
          ecatb.send(note, self)
        }
      }
    }
    #
  end # set_ecatb_speed_reduce

  #----------------------------------------------------------------------------|
  #  Sets the starting atb value of the start type at the start of a battle    |
  #----------------------------------------------------------------------------|
  # start: The battle start type
  def set_ecatb_start_val(start) # New
    # Updates the start notetags of the start type using the current order
    ecatb = DoubleX_RMVXA::ECATB
    ecatb_start_val_ord.each { |data|
      next unless send(@ecatb_item[data][0])
      send(@ecatb_item[data][1]).each { |item|
        (0..(item.ecatb_notes[start].size - 1)).each { |index|
          next unless note = item.ecatb_notes[start][index]
          ecatb.send(note, self)
        }
      }
    }
    #
  end # set_ecatb_start_val

  #----------------------------------------------------------------------------|
  #  Evaluates the value of all specified notetags using their orderings       |
  #----------------------------------------------------------------------------|
  # items: The data containing the notetags
  # note: The notetag type
  def set_ecatb_notes(items, note) # New; Potential Hotspot
    # Reads all item's speficied notetag values until the maximum size's reached
    ecatb = DoubleX_RMVXA::ECATB
    items.each { |item|
      return if @ecatb_notes[note]
      next unless n = item.ecatb_notes[note]
      @ecatb_notes[note] = ecatb.send(n, self)
    }
    #
  end # set_ecatb_notes

  #----------------------------------------------------------------------------|
  #  Checks if any new notetag added, old one gone or its value changed        |
  #----------------------------------------------------------------------------|
  # note: The notetag type to be checked
  def ecatb_battler_change?(note) # New; Hotspot
    change = @ecatb_note_change[note]
    @ecatb_note_change[note] &&= !change
    return change unless @ecatb_battler_change[note]
    !(@ecatb_battler_change[note] = false)
  end # ecatb_battler_change?

  #----------------------------------------------------------------------------|
  #  Checks if charging should take place                                      |
  #----------------------------------------------------------------------------|
  def ecatb_charge_update? # New; Hotspot
    return false if @ecatb_val[:cooldown] > 0.0 || @ecatb_val[:atb] < 100.0
    return false unless current_action
    return enemy? || current_action.ecatb_confirm if current_action.item
    !(@ecatb_val[:charge] = 0.0)
  end # ecatb_charge_update?

  #----------------------------------------------------------------------------|
  #  Checks if the unison skill/item can continue charging                     |
  #----------------------------------------------------------------------------|
  def ecatb_unison_charge_update? # New; Hotspot
    return false unless actor? && current_action && item = current_action.item
    # Rechecks the unison skill/item usability if any unison actor's refreshed
    return usable?(item) if @ecatb_unison_actors.any?(
    &DoubleX_RMVXA::ECATB::BLOCKS[:ecatb_refresh])
    #
    true
  end # ecatb_unison_charge_update?

  #----------------------------------------------------------------------------|
  #  Checks if the battler's actions should be executed                        |
  #----------------------------------------------------------------------------|
  def exec_ecatb_act? # New; Hotspot
    # Checks if the battler's valid and has valid input being fully charged
    return false if ecatb_val[:charge] < 100.0 || ecatb_val[:atb] < 100.0
    enemy? || input && input.item && input.ecatb_confirm
    #
  end # exec_ecatb_act?

  #----------------------------------------------------------------------------|
  #  Helper methods used by @ecatb_item                                        |
  #----------------------------------------------------------------------------|

  def ecatb_states # New; Potential Hotspot
    @states
  end # ecatb_states

  def ecatb_enemy # New; Potential Hotspot
    [enemy]
  end # ecatb_enemy

  def enemy # New; Potential Hotspot
  end # enemy

  def armors # New; Potential Hotspot
    []
  end # armors

  def weapons # New; Potential Hotspot
    []
  end # armors

  def ecatb_class # New; Potential Hotspot
    [self.class]
  end # ecatb_class

  def class # New; Potential Hotspot
  end # class

  def ecatb_actor # New; Potential Hotspot
    [actor]
  end # ecatb_actor

  def actor # New
  end # actor

  #----------------------------------------------------------------------------|
  #  Lets the compatibility fix deals with compatibility issues                |
  #----------------------------------------------------------------------------|
  def ecatb_reset_compatibility? # New
  end # ecatb_reset_compatibility?

end # Game_BattlerBase

#------------------------------------------------------------------------------|
#  * Implements the battler's atb actions, control flows and logics            |
#------------------------------------------------------------------------------|
class Game_Battler < Game_BattlerBase # Edit

  #----------------------------------------------------------------------------|
  #  New public instance variables                                             |
  #----------------------------------------------------------------------------|
  attr_accessor :ecatb_act_times_add # The action point increment
  attr_accessor :ecatb_act_times_cap # The action point cap reaching flag
  attr_accessor :ecatb_refresh # The refresh calling flag
  attr_accessor :ecatb_reset_val # The atb reset value upon resetting atb
  attr_accessor :ecatb_unison_invoker # The unison skill/item invoker flag
  attr_accessor :ecatb_val_change # The atb value change flags
  attr_reader :ecatb_act_times # The number of action points
  attr_reader :ecatb_countdown_freeze # The countdown freeze statuses
  attr_reader :ecatb_note_change # The notetag value change flags
  attr_reader :ecatb_notes # The caches of all notetags used
  attr_reader :ecatb_rate # The cached atb rates
  attr_reader :ecatb_unison_actors # The cached unison actor list
  attr_reader :ecatb_unison_rule # The cached unison charge/cooldown rule
  attr_reader :ecatb_val # The atb values
  attr_writer :ecatb_unison_item # The unison skill/item for damage evaluation

  #----------------------------------------------------------------------------|
  #  New private instance variables                                            |
  #----------------------------------------------------------------------------|
  # @ecatb_battler_change: The battler data change flags
  # @ecatb_countdown_updates: The countdown update method iterator block
  # @ecatb_item: The notetag value reader storing data types with their ordering
  # @ecatb_item_change: The skill/item usage change flags
  # @ecatb_speed_reduce: The action input speed frame number
  # @fail_ecatb_esc: The party escape attempt failure flag
  # @last_ecatb_item: The last item used/being used
  # @last_ecatb_rate: The last atb gain rate
  # @last_ecatb_speed_reduce: The last action input speed frame number
  # @max_ecatb_act_times The maximum number of action points
  # @temp_ecatb_act_times The temporary number of action points

  #----------------------------------------------------------------------------|
  #  Updates states with different auto removal timing to at different timings |
  #----------------------------------------------------------------------------|
  def update_state_turns # Rewrite
    ecatb_update_state_turns(2) # Rewritten
  end # update_state_turns

  #----------------------------------------------------------------------------|
  #  Fixes bugs and initializes all new variables as well                      |
  #----------------------------------------------------------------------------|
  alias initialize_ecatb initialize
  def initialize(*argv, &argb)
    initialize_ecatb(*argv, &argb)
    init_ecatb_vars # Added to let created methods to use new variables as well
  end # initialize

  #----------------------------------------------------------------------------|
  #  Raises the display redraw and cached notetag value reevaluation flags also|
  #----------------------------------------------------------------------------|
  alias clear_states_ecatb clear_states
  def clear_states(*argv, &argb)
    clear_states_ecatb(*argv, &argb)
    # Added
    set_ecatb_battler_change
    @ecatb_countdown_clock = {}
    @ecatb_countdown_freeze = {}
    #
  end # clear_states

  #----------------------------------------------------------------------------|
  #  Raises the display redraw and cached notetag value reevaluation flags also|
  #----------------------------------------------------------------------------|
  alias add_new_state_ecatb add_new_state # v0.05a+
  def add_new_state(state_id, &argb)
    add_new_state_ecatb(state_id, &argb)
    set_ecatb_battler_change # Added
  end # add_new_state

  #----------------------------------------------------------------------------|
  #  Clears the atb values but not action points in the ecatb battle system    |
  #----------------------------------------------------------------------------|
  alias on_restrict_ecatb on_restrict
  def on_restrict(*argv, &argb)
    # Rewritten
    return on_restrict_ecatb(*argv, &argb) unless BattleManager.btype?(:ecatb)
    #
    # Added
    ecatb_reset
    states.each { |s| remove_state(s.id) if s.remove_by_restriction }
    #
  end # on_restrict

  #----------------------------------------------------------------------------|
  #  Initializes the state's countdown as well if any                          |
  #----------------------------------------------------------------------------|
  alias reset_state_counts_ecatb reset_state_counts
  def reset_state_counts(state_id, &argb)
    reset_state_counts_ecatb(state_id, &argb)
    # Added
    return unless $data_states[state_id].ecatb_countdown_interval
    return unless @states.include?(state_id)
    @ecatb_countdown_clock[state_id] = 0
    @ecatb_countdown_freeze[state_id] = false
    #
  end # reset_state_counts

  #----------------------------------------------------------------------------|
  #  Ensures only 1 non forced action can be inputted and executed at a time   |
  #----------------------------------------------------------------------------|
  alias make_action_times_ecatb make_action_times
  def make_action_times(*argv, &argb)
    # Rewritten
    BattleManager.btype?(:ecatb) ? 1 : make_action_times_ecatb(*argv, &argb)
    #
  end # make_action_times

  #----------------------------------------------------------------------------|
  #  Preserves the existing actions but executes the forced one first instead  |
  #----------------------------------------------------------------------------|
  alias force_action_ecatb force_action
  def force_action(skill_id, target_index, &argb)
    # Added
    if BattleManager.btype?(:ecatb)
      return set_ecatb_force_action(skill_id, target_index)
    end
    #
    force_action_ecatb(skill_id, target_index, &argb)
  end # force_action

  #----------------------------------------------------------------------------|
  #  Sets and resets user's methods before and after using an unison skill/item|
  #----------------------------------------------------------------------------|
  alias make_damage_value_ecatb make_damage_value
  def make_damage_value(user, item, &argb)
    # Added
    if user.actor? && user.ecatb_unison_actors.size > 1
      user.ecatb_unison_item = item
    end
    #
    make_damage_value_ecatb(user, item, &argb)
    user.ecatb_unison_item = nil # Added
  end # make_damage_value

  #----------------------------------------------------------------------------|
  #  Asks all unison invokees to pay the skill/item costs for unison skill/item|
  #----------------------------------------------------------------------------|
  alias use_item_ecatb use_item
  def use_item(item, &argb)
    # Rewritten
    return use_item_ecatb(item, &argb) unless BattleManager.btype?(:ecatb)
    #
    # Added
    unless DoubleX_RMVXA::ECATB.send(item.ecatb_charge_prior_item_cost, self)
      return item.effects.each { |effect| item_global_effect_apply(effect) }
    end
    return if @ecatb_unison_actors.size <= 1
    @ecatb_unison_actors.each { |actor| actor.pay_skill_cost(item) }
    item.effects.each { |effect| item_global_effect_apply(effect) }
    #
  end # use_item

  #----------------------------------------------------------------------------|
  #  Updates states with Auto-removal Timing being Action End as well          |
  #----------------------------------------------------------------------------|
  alias on_action_end_ecatb on_action_end
  def on_action_end(*argv, &argb)
    on_action_end_ecatb(*argv, &argb)
    ecatb_update_state_turns(1) if BattleManager.btype?(:ecatb) # Added
  end # on_action_end

  #----------------------------------------------------------------------------|
  #  Removes buffs and debuffs having 0 remaining turns as well                |
  #----------------------------------------------------------------------------|
  alias on_turn_end_ecatb on_turn_end
  def on_turn_end(*argv, &argb)
    on_turn_end_ecatb(*argv, &argb)
    remove_buffs_auto if BattleManager.btype?(:ecatb) # Added
  end # on_turn_end

  #----------------------------------------------------------------------------|
  #  Frees up unnecessary memory usage upon battle end                         |
  #----------------------------------------------------------------------------|
  alias on_battle_end_ecatb on_battle_end
  def on_battle_end(*argv, &argb) # v0.02c+
    on_battle_end_ecatb(*argv, &argb)
    # Added to clear all new variables that are only used in battles
    clear_ecatb_vars
    #
  end # on_battle_end

  #----------------------------------------------------------------------------|
  #  Preserves the existing actions but executes the forced one first          |
  #----------------------------------------------------------------------------|
  def set_ecatb_force_action(skill_id, target_index) # New
    @ecatb_unison_invoker = false
    @ecatb_unison_rule.clear
    (act = Game_Action.new(self, true)).set_skill(skill_id)
    if target_index == -2
      act.target_index = last_target_index
    elsif target_index == -1
      act.decide_random_target
    else
      act.target_index = target_index
    end
    @actions.unshift(act)
  end # set_ecatb_force_action

  #----------------------------------------------------------------------------|
  #  Initializes all new variables before checking any configuration validities|
  #----------------------------------------------------------------------------|
  def init_ecatb_vars # New
    @ecatb_esc = false
    @ecatb_item_change = {}
    @ecatb_note_change = {}
    @ecatb_notes = {}
    [:atb, :charge, :cooldown].each { |type| @ecatb_notes[type] = [] }
    @ecatb_unison_actors = []
    @ecatb_unison_rule = {}
    init_ecatb_block
    init_ecatb_item_vars
    init_ecatb_val_vars
  end # init_ecatb_vars

  def init_ecatb_val_vars # New
    @ecatb_act_times = @ecatb_act_times_add = @temp_ecatb_act_times = 0
    @ecatb_speed_reduce = @last_ecatb_speed_reduce = 0
    @ecatb_rate = {}
    @ecatb_reset_val = 0.0
    @ecatb_val = { atb: 0.0, charge: 0.0, cooldown: 0.0 }
    @ecatb_val_change = true
    @last_ecatb_rate = { charge: -1, cooldown: -1 }
    @max_ecatb_act_times = 1
  end # init_ecatb_val_vars

  def init_ecatb_item_vars # New
    @ecatb_item = {}
    notes = [:states, :enemies, :armors, :weapons, :classes, :actors]
    conds = [:ecatb_states, :enemy?, :actor?, :actor?, :actor?, :actor?]
    items = [:states, :ecatb_enemy, :armors, :weapons, :ecatb_class,
             :ecatb_actor]
    notes.each_with_index { |n, i| @ecatb_item[n] = [conds[i], items[i]] }
  end # init_ecatb_item_vars

  #----------------------------------------------------------------------------|
  #  Initializes the new block to trade memory usage for time performance      |
  #----------------------------------------------------------------------------|
  def init_ecatb_block # New
    # Calls this block instead of an anonymous function per enumerable iteration
    @ecatb_countdown_updates = -> state_id {
      next if @ecatb_countdown_freeze[state_id]
      next if (@ecatb_countdown_clock[state_id] += 1) % ecatb_countdown_min != 0
      @ecatb_countdown_clock[state_id] %= Graphics.frame_rate * DoubleX_RMVXA::
      ECATB.send($data_states[state_id].ecatb_countdown_interval, self)
      next if @ecatb_countdown_clock[state_id] != 0
      if @state_turns[state_id] > 0
        @state_turns[state_id] -= 1
        set_ecatb_battler_change
      end
      ecatb_countdown_update_compatibility_3(state_id)
      next unless @ecatb_battler_sprite
      ecatb_countdown_update_compatibility_2(@ecatb_battler_sprite, state_id)
    }
    #
  end # init_ecatb_block

  #----------------------------------------------------------------------------|
  #  Clears all variables that are useless outside battles upon battle end     |
  #----------------------------------------------------------------------------|
  def clear_ecatb_vars # v0.05a+; New
    clear_ecatb_blocks
    @ecatb_item = @ecatb_item_change = @ecatb_note_change = @ecatb_notes = nil
    @ecatb_rate = @ecatb_unison_actors = @ecatb_unison_rule = @ecatb_val = nil
    @ecatb_val_change = nil
  end # clear_ecatb_vars

  #----------------------------------------------------------------------------|
  #  Clears all cached blocks used in battles                                  |
  #----------------------------------------------------------------------------|
  def clear_ecatb_blocks # v0.01a; New
    # Clears all cached notetag values, the unison actor id list and skill/item
    if @ecatb_notes[:order_icon]
      bitmap = @ecatb_notes[:order_icon][0]
      bitmap.dispose if bitmap && !bitmap.disposed?
    end
    [:act, :order_icon, :order_opacity, :order_scale, :order_z, :se].each { 
    |type| @ecatb_notes.delete(type) }
    [:atb, :charge, :cooldown].each { |type| @ecatb_notes[type].clear }
    $game_temp.ecatb_unison_actors[self] ||= @ecatb_unison_actors
    @ecatb_unison_actors.clear
    $game_temp.last_ecatb_item[self] ||= @last_ecatb_item
    @ecatb_battler_sprite = @ecatb_countdown_updates = @last_ecatb_item = nil
    #
  end # clear_ecatb_blocks

  #----------------------------------------------------------------------------|
  #  Resets all cached blocks used in battles                                  |
  #----------------------------------------------------------------------------|
  def reset_ecatb_blocks # v0.01a; New
    # Marks that all cached notetag values have to reread and restores the rest
    set_ecatb_battler_change
    if $game_temp.ecatb_unison_actors[self]
      @ecatb_unison_actors = $game_temp.ecatb_unison_actors.delete(self)
    end
    if $game_temp.last_ecatb_item[self]
      @last_ecatb_item = $game_temp.last_ecatb_item.delete(self)
    end
    init_ecatb_block
    #
  end # reset_ecatb_blocks

  # start: The battle start type
  def set_ecatb_start_val(start = :start_0) # New
    init_ecatb_vars
    set_ecatb_battler_change
    # Applies all the read notetag values to the default starting atb value
    default_ecatb_start_val(start)
    super(start)
    #
  end # set_ecatb_start_val

  # timing: The state auto removal timing
  def ecatb_update_state_turns(timing) # New
    change = false
    states.each { |state|
      next if @state_turns[state.id] <= 0 || state.auto_removal_timing != timing
      @state_turns[state.id] -= 1
      change = true
    }
    set_ecatb_battler_change if change
  end # ecatb_update_state_turns

  #----------------------------------------------------------------------------|
  #  Performs all the battler's atb frame updates                              |
  #----------------------------------------------------------------------------|
  def ecatb_updates # New; Hotspot
    unless @ecatb_val[:atb] <= 100.0 || set_gradual_ecatb_act_gain
      @temp_ecatb_act_times = @max_ecatb_act_times
      @ecatb_val[:atb] = 100.0
      @max_ecatb_act_times = 1
    end
    return unless @ecatb_esc || movable = restriction < 4
    # Updates the atb values, speed and countdown statuses and makes actions
    ecatb_val_updates(movable)
    ecatb_countdown_update unless @ecatb_countdown_clock.empty?
    #
  end # ecatb_updates

  #----------------------------------------------------------------------------|
  #  (v0.04c)Updates atb, charge and cooldown, speed reduce and makes actions  |
  #----------------------------------------------------------------------------|
  def ecatb_val_updates(movable) # New; Hotspot
    return ecatb_charge_update if @ecatb_esc || movable && ecatb_charge_update?
    if !@ecatb_esc && movable
      return ecatb_cooldown_update if @ecatb_val[:cooldown] > 0.0
      ecatb_update if @ecatb_val[:atb] < 100.0 * @max_ecatb_act_times
      return if @ecatb_val[:atb] < 100.0
      return ecatb_speed_reduce_update if @ecatb_speed_reduce > 0
    end
    make_ecatb_act unless @ecatb_val[:atb] < 100.0 || @ecatb_val[:charge] > 
    0.0 || ecatb_reset_compatibility? || actor? && inputable? && 
    current_action && current_action.item && current_action.ecatb_confirm
  end # ecatb_val_updates

  #----------------------------------------------------------------------------|
  #  Updates the atb cooldown value and triggers cooldown finish upon finishing|
  #----------------------------------------------------------------------------|
  def ecatb_cooldown_update # New; Hotspot
    @ecatb_val[:cooldown] -= ecatb_cooldown_loss_rate
    return if @ecatb_val[:cooldown] > 0.0
    @ecatb_val[:cooldown] = 0.0 if @ecatb_val[:cooldown] < 0.0
    @ecatb_unison_actors.clear
    @ecatb_unison_invoker = @fail_ecatb_esc = false
    @ecatb_unison_rule.clear
    ecatb_cooldown_finish
  end # ecatb_cooldown_update

  def ecatb_update # New; Hotspot
    # Raises the change flag upon atb value change and caps it to its max
    @ecatb_val_change = @ecatb_val[:atb] != @ecatb_val[:atb] += ecatb_gain_rate
    max = 100.0 * @max_ecatb_act_times
    @ecatb_val[:atb] = max if @ecatb_val[:atb] > max
    #
  end # ecatb_update

  #----------------------------------------------------------------------------|
  #  Updates the atb action input speed reduction by frames                    |
  #----------------------------------------------------------------------------|
  def ecatb_speed_reduce_update # v0.02a+; New; Hotspot
    # Returns the cached value unless it's to be reevalauted
    return set_ecatb_speed_reduce if ecatb_battler_change?(:speed)
    @ecatb_speed_reduce = 0 if (@ecatb_speed_reduce -= 1) < 0
    #
  end # ecatb_speed_reduce_update

  #----------------------------------------------------------------------------|
  #  Sets the atb action input speed reduction by frames                       |
  #----------------------------------------------------------------------------|
  def set_ecatb_speed_reduce # v0.02a+; New; Potential Hotspot
    # Adds the difference between the new and old to the current speed reduction
    last_speed_reduce = @last_ecatb_speed_reduce
    ecatb_speed_reduce
    super
    @ecatb_speed_reduce += @last_ecatb_speed_reduce - last_speed_reduce
    @ecatb_speed_reduce = 0 if @ecatb_speed_reduce < 0
    #
  end # set_ecatb_speed_reduce

  #----------------------------------------------------------------------------|
  #  Updates the atb charge value including the unison version                 |
  #----------------------------------------------------------------------------|
  def ecatb_charge_update # New; Hotspot
    unless @ecatb_unison_actors.size <= 1 || ecatb_unison_charge_update?
      return ecatb_reset
    end
    @ecatb_val[:charge] += ecatb_charge_gain_rate
    @ecatb_val[:charge] = 100.0 if @ecatb_val[:charge] > 100.0
  end # ecatb_charge_update

  #----------------------------------------------------------------------------|
  #  Makes actions and marks the battler as actable upon becoming able to act  |
  #----------------------------------------------------------------------------|
  def make_ecatb_act # New; Hotspot
    if @ecatb_act_times <= 0
      make_gradual_ecatb_act_gain
    elsif @ecatb_val[:atb] > 100.0
      make_ecatb_act_pool
    end
    BattleManager.make_ecatb_act(self)
  end # make_ecatb_act

  def make_gradual_ecatb_act_gain # v0.05a+; New
    unless set_gradual_ecatb_act_gain
      return @ecatb_act_times_add = @ecatb_act_times = 
      @temp_ecatb_act_times = make_action_times_ecatb
    end
    @ecatb_act_times_add = @ecatb_act_times = @temp_ecatb_act_times = 1
    @max_ecatb_act_times = make_action_times_ecatb
    # Prevents the previously reset atb value from exceeding the new maximum
    max = 100.0 * @max_ecatb_act_times
    @ecatb_val[:atb] = max if @ecatb_val[:atb] > max
    #
    set_ecatb_battler_change
  end # make_gradual_ecatb_act_gain

  #----------------------------------------------------------------------------|
  #  Synchronize the party/troop action point pool when changing action points |
  #----------------------------------------------------------------------------|
  def make_ecatb_act_pool # v0.05a+; New; Hotspot
    # Ensures that all party/troop members change their action points together
    return if 
    (act_add = @ecatb_val[:atb].to_i / 100 - @temp_ecatb_act_times) == 0
    @ecatb_act_times_add = act_add
    return if @ecatb_act_times_cap = 
    @temp_ecatb_act_times >= @max_ecatb_act_times
    @ecatb_act_times += @ecatb_act_times_add
    @temp_ecatb_act_times += @ecatb_act_times_add
    set_ecatb_battler_change
    #
  end # make_ecatb_act_pool

  #----------------------------------------------------------------------------|
  #  Updates all states' countdown clocks that aren't frozen if any            |
  #----------------------------------------------------------------------------|
  def ecatb_countdown_update # New; Hotspot
    @ecatb_battler_sprite ||= ecatb_countdown_update_compatibility_1
    # Checks if the clocks are divisible by seconds to boost time performance
    @ecatb_countdown_clock.each_key(&@ecatb_countdown_updates)
    #
    remove_states_auto(3)
  end # ecatb_countdown_update

  def confirm_ecatb_item # New
    # Recaches the cached values upon changes and pays costs now if specified
    @ecatb_item_change[:charge] = @ecatb_item_change[:cooldown] = 
    @last_ecatb_item != @last_ecatb_item = current_action.item
    pay_prior_ecatb_charge if @last_ecatb_item
    #
  end # confirm_ecatb_item

  def pay_prior_ecatb_charge # New
    ecatb = DoubleX_RMVXA::ECATB
    unless ecatb.send(@last_ecatb_item.ecatb_charge_prior_act_cost, self)
      pay_ecatb_unison_act_cost
    end
    return if ecatb.send(@last_ecatb_item.ecatb_charge_prior_item_cost, self)
    return consume_item(@last_ecatb_item) if @last_ecatb_item.is_a?(RPG::Item)
    pay_skill_cost(@last_ecatb_item) if @last_ecatb_item.is_a?(RPG::Skill)
  end # pay_prior_ecatb_charge

  #----------------------------------------------------------------------------|
  #  Pays the action cost and sets the atb reset value unless it's forced      |
  #----------------------------------------------------------------------------|
  # forced: The action force flag
  def exec_ecatb_act_cost(forced) # New
    return unless current_action && item = current_action.item
    ecatb = DoubleX_RMVXA::ECATB
    if (force_act_cost = ecatb.send(item.ecatb_force_act_cost, self)) || !forced
      # Pays the action cost now if the skill/item requests so
      if ecatb.send(item.ecatb_charge_prior_act_cost, self)
        pay_ecatb_unison_act_cost
      end
      #
      set_ecatb_reset_val
    end
    force_act_cost
  end # exec_ecatb_act_cost

  def pay_ecatb_unison_act_cost # New
    return pay_ecatb_act_cost if @ecatb_unison_actors.size <= 1
    @ecatb_unison_actors.each(
    &DoubleX_RMVXA::ECATB::BLOCKS[:pay_ecatb_act_cost])
  end # pay_ecatb_unison_act_cost

  def pay_ecatb_act_cost # New
    return unless current_action && item = current_action.item
    set_ecatb_battler_change
    cost = DoubleX_RMVXA::ECATB.send(item.ecatb_act_cost, self)
    @temp_ecatb_act_times -= cost
    unless friends_unit.ecatb_pool
      @ecatb_val[:atb] -= cost * 100.0 if set_gradual_ecatb_act_gain
      return @ecatb_act_times -= cost
    end
    size = (members = friends_unit.alive_members).size
    members.each { |mem|
      mem.ecatb_act_times -= cost
      next unless mem.set_gradual_ecatb_act_gain
      mem.ecatb_val[:atb] -= cost * 100.0 / size
    }
  end # pay_ecatb_act_cost

  def set_ecatb_reset_val # New
    # Sets all unison invokee's atb reset values as well for unison skill/item
    val = current_action.item.ecatb_reset_val
    @ecatb_reset_val = (ecatb = DoubleX_RMVXA::ECATB).send(val, self)
    return if @ecatb_unison_actors.size <= 1
    (@ecatb_unison_actors & $game_party.alive_members).each{ |actor|
      actor.ecatb_reset_val = ecatb.send(val, actor)
    }
    #
  end # set_ecatb_reset_val

  #----------------------------------------------------------------------------|
  #  Resets the atb values and reset value, speed reduce and action points     |
  #----------------------------------------------------------------------------|
  # reset: The atb reset flag
  def ecatb_reset(reset = restriction > 3) # New
    # Pays the escape cost, refreshes the battler and triggers the pre and post
    pre_ecatb_reset
    pay_ecatb_esc_cost if @ecatb_esc
    @ecatb_speed_reduce = 0
    @ecatb_val_change = true
    return ecatb_val_reset_compatibility(reset) if ecatb_reset_compatibility?
    BattleManager.del_ecatb_act(self)
    ecatb_act_val_reset(reset)
    post_ecatb_reset
    set_ecatb_battler_change
    #
  end # ecatb_reset

  # reset: The atb reset flag
  def ecatb_act_val_reset(reset) # New
    @ecatb_val[:cooldown] = 0.0 if dead?
    use_ecatb_reset_val if reset || @ecatb_act_times <= 0
    @temp_ecatb_act_times = @ecatb_act_times = 0 if reset && 
    @ecatb_act_times > 0
    @max_ecatb_act_times = 1 if reset || @ecatb_act_times <= 0
    ecatb_unison_reset(reset)
    @ecatb_val[:charge] = 0.0
    return if @ecatb_act_times > 0 && index && restriction <= 0
    @ecatb_reset_val = 0.0
  end # ecatb_act_val_reset

  def use_ecatb_reset_val # v0.04d+; New
    BattleManager.ecatb_pool_reset(self, @ecatb_unison_actors) if 
    friends_unit.ecatb_pool
    @ecatb_val[:atb] = @ecatb_reset_val
    return @ecatb_val[:atb] = 0.0 if @ecatb_val[:atb] < 0.0
    max = 100.0 * @max_ecatb_act_times
    @ecatb_val[:atb] = max if @ecatb_val[:atb] > max
  end # use_ecatb_reset_val

  def ecatb_unison_reset(reset) # v0.05a+; New
    # Clears the unison actor and invoker cache if there's no unison cooldown
    if reset || @ecatb_val[:charge] < 100.0
      @ecatb_unison_actors.clear
      @ecatb_unison_invoker = false
      return @ecatb_unison_rule.clear
    end
    #
    @ecatb_val[:cooldown] = 100.0
  end # ecatb_unison_reset

  #----------------------------------------------------------------------------|
  #  Lets the compatibility fix deals with compatibility issues                |
  #----------------------------------------------------------------------------|

  def ecatb_countdown_update_compatibility_1 # New; Hotspot
  end # ecatb_countdown_update_compatibility_1

  def ecatb_countdown_update_compatibility_2(battler_sprite, state_id) # New; 
  # Potential Hotspot
  end # ecatb_countdown_update_compatibility_2

  def ecatb_countdown_update_compatibility_3(state_id) # New; Potential Hotspot
  end # ecatb_countdown_update_compatibility_3

  # reset: The atb reset flag
  def ecatb_val_reset_compatibility(reset) # New
  end # ecatb_val_reset_compatibility

end # Game_Battler

#------------------------------------------------------------------------------|
#  * Implements the actor's additional atb actions, control flows and logics   |
#------------------------------------------------------------------------------|
class Game_Actor < Game_Battler # Edit

  #----------------------------------------------------------------------------|
  #  New public instance variable                                              |
  #----------------------------------------------------------------------------|
  attr_accessor :ecatb_esc # The party escape attempt flag

  #----------------------------------------------------------------------------|
  #  New private instance variable                                             |
  #----------------------------------------------------------------------------|
  # @ecatb_reserve: The reserved member flag

  #----------------------------------------------------------------------------|
  #  Creates new methods of all configurations used by actors as well          |
  #----------------------------------------------------------------------------|
  alias setup_ecatb setup
  def setup(actor_id, &argb)
    setup_ecatb(actor_id, &argb)
    # Added to fix nil @action_input_index and actors added during battle bugs
    @action_input_index = 0
    @ecatb_reserve = true
    create_ecatb_defs
    #
  end # setup

  #----------------------------------------------------------------------------|
  #  Confirms inputs made with the auto battle status as well                  |
  #----------------------------------------------------------------------------|
  alias make_auto_battle_actions_ecatb make_auto_battle_actions
  def make_auto_battle_actions(*argv, &argb) # v0.00d+
    make_auto_battle_actions_ecatb(*argv, &argb)
    # Added
    return unless BattleManager.btype?(:ecatb)
    confirm_ecatb_item
    set_ecatb_speed_reduce
    #
  end # make_auto_battle_actions

  #----------------------------------------------------------------------------|
  #  Confirms inputs made with the confusion status as well                    |
  #----------------------------------------------------------------------------|
  alias make_confusion_actions_ecatb make_confusion_actions
  def make_confusion_actions(*argv, &argb) # v0.00d+
    make_confusion_actions_ecatb(*argv, &argb)
    # Added
    return unless BattleManager.btype?(:ecatb)
    confirm_ecatb_item
    set_ecatb_speed_reduce
    #
  end # make_confusion_actions

  #----------------------------------------------------------------------------|
  #  Ensures actors added during battles are properly initialized as well      |
  #----------------------------------------------------------------------------|
  def on_battle_end(*argv, &argb) # v0.04e+; New
    super(*argv, &argb)
    @ecatb_reserve = true
  end # on_battle_end

  #----------------------------------------------------------------------------|
  #  Creates and checks the associated method for each configuration used here |
  #----------------------------------------------------------------------------|
  # config: The configuration requesting its associated method
  # validate: The configuration value validation flag
  def create_ecatb_def(config, validate = true) # New
    # Uses the name and value of configuration as its method's name and contents
    method = config.id2name
    eval(%Q(
  def #{method}#{DoubleX_RMVXA::ECATB::GAME_ACTOR[config][0]}
    #{$game_system.send(config)}
  end
    ))
    #
    return unless validate
    check_ecatb_def(method, DoubleX_RMVXA::ECATB::GAME_ACTOR[config])
  end # create_ecatb_def

  #----------------------------------------------------------------------------|
  #  Checks all new methods and resets them to the defaults if they're invalid |
  #----------------------------------------------------------------------------|
  module_eval(DoubleX_RMVXA::ECATB::CHECK_RESET_DEF[:GAME_ACTOR]) # New

  #----------------------------------------------------------------------------|
  #  Ensures actors added during battles are properly initialized as well      |
  #----------------------------------------------------------------------------|
  def set_ecatb_start_val(start = :start_0) # v0.04e+; New
    super(start)
    @ecatb_reserve = false
  end # set_ecatb_start_val

  # start: The battle start type
  def default_ecatb_start_val(start) # New
    return normal_actor_1st_ecatb_val if start == :start_0
    return preemptive_actor_1st_ecatb_val if start == :start_1
    surprise_actor_1st_ecatb_val
  end # default_ecatb_start_val

  #----------------------------------------------------------------------------|
  #  Ensures actors added during battles are properly initialized as well      |
  #----------------------------------------------------------------------------|
  def ecatb_updates # v0.04e+; New ; Hotspot
    if @ecatb_reserve
      init_ecatb_vars
      @ecatb_reserve = false
    end
    super
  end # ecatb_updates

  def confirm_ecatb_item # New
    super
    input.ecatb_confirm = input.last_ecatb_confirm = true
    # Caches the unison actors, charge and cooldown rules if any as well
    ecatb = DoubleX_RMVXA::ECATB
    @ecatb_unison_actors = ecatb.send(@last_ecatb_item.ecatb_unison_actor, self)
    @ecatb_unison_actors.collect!(&ecatb::BLOCKS[:usable?])
    if @ecatb_unison_invoker
      @ecatb_unison_rule[:charge] = ecatb.send(
      @last_ecatb_item.ecatb_unison_charge_rule, self)
      @ecatb_unison_rule[:cooldown] = ecatb.send(
      @last_ecatb_item.ecatb_unison_cooldown_rule, self)
    end
    #
    post_ecatb_input_act
    set_ecatb_battler_change
  end # confirm_ecatb_item

  def init_ecatb_escape # v0.05a+; New
    @ecatb_esc = @ecatb_item_change[:charge] = true
    @ecatb_unison_actors.clear
    @ecatb_unison_invoker = false
    @ecatb_unison_rule.clear
    BattleManager.del_ecatb_act(self)
  end # init_ecatb_escape

  def pay_ecatb_esc_cost # New
    @ecatb_act_times -= cost = ecatb_esc_act_cost
    @temp_ecatb_act_times -= cost
    @ecatb_reset_val = ecatb_esc_reset_val
    @ecatb_val[:atb] -= cost * 100.0 if @ecatb_val[:atb] > 100.0
    @ecatb_val[:charge] = 100.0
    @ecatb_esc = false
    @ecatb_item_change[:cooldown] = @fail_ecatb_esc = true
    set_ecatb_battler_change
  end # pay_ecatb_esc_cost

  def ecatb_inputable? # New; Hotspot
    return false if @ecatb_val[:charge] > 0.0 || @ecatb_val[:cooldown] > 0.0
    @ecatb_act_times > 0 && inputable? && !ecatb_reset_compatibility?
  end # ecatb_inputable?

  # actors: The unison actors
  def ecatb_unison_usable?(item, actors) # New
    return false unless item.is_a?(RPG::UsableItem) && actors.include?(self)
    # Checks if all unison actors are inputable and can use the skill/item
    return false unless (actors - BattleManager.ecatb_actor_act_list).empty?
    unless actors.all? { |actor| actor.ecatb_unison_actor?(item, actors) }
      return false
    end
    #
    ecatb_unison_skill_item_usable?(item, actors)
  end # ecatb_unison_usable?

  #----------------------------------------------------------------------------|
  #  Checks if the actor's can input the skill/item and pay its costs          |
  #----------------------------------------------------------------------------|
  # actors: The unison actors
  def ecatb_unison_actor?(item, actors) # New
    return false unless inputable?
    return false unless item.is_a?(RPG::Skill) || item_conditions_met?(item)
    return false unless skills.include?(item) || skill_conditions_met?(item)
    cost = (ecatb = DoubleX_RMVXA::ECATB).send(item.ecatb_act_cost, self)
    cost *= actors.size if $game_party.ecatb_pool
    return true if @ecatb_act_times >= cost
    return false if @ecatb_val[:charge] <= 0.0
    !ecatb.send(item.ecatb_charge_prior_act_cost, self)
  end # ecatb_unison_actor?

  #----------------------------------------------------------------------------|
  #  Checks if the unison actors can input or use the unison skill/item        |
  #----------------------------------------------------------------------------|
  # actors: The unison actors
  def ecatb_unison_skill_item_usable?(item, actors) # New
    # Checks if all unison actors are inputable or they're all charging
    input = charge = true
    actors.each { |actor|
      act = actor.current_action
      input &&= (!act || !act.item) && actor.ecatb_val[:charge] <= 0.0
      charge &&= act && act.item == item
      return false unless input || charge
    }
    #
  end # ecatb_unison_skill_item_usable?

end # Game_Actor

#------------------------------------------------------------------------------|
#  * Implements the enemy's additional atb actions, control flows and logics   |
#------------------------------------------------------------------------------|
class Game_Enemy < Game_Battler # New

  #----------------------------------------------------------------------------|
  #  New private instance variables                                            |
  #----------------------------------------------------------------------------|
  # @ecatb_bar_show: The cached atb bar part display flags with display details
  # @ecatb_state_change: The state change flags

  #----------------------------------------------------------------------------|
  #  Confirms the action and pays its now if charge prior costs are true also  |
  #----------------------------------------------------------------------------|
  alias make_actions_ecatb make_actions
  def make_actions(*argv, &argb)
    make_actions_ecatb(*argv, &argb)
    # Added
    return unless BattleManager.btype?(:ecatb)
    return unless current_action && current_action.item
    confirm_ecatb_item
    set_ecatb_speed_reduce
    #
  end # make_actions

  #----------------------------------------------------------------------------|
  #  Creates and checks the associated method for each configuration used here |
  #----------------------------------------------------------------------------|
  # config: The configuration requesting its associated method
  # validate: The configuration value validation flag
  def create_ecatb_def(config, validate = true) # New
    # Uses the name and value of configuration as its method's name and contents
    method = config.id2name
    eval(%Q(
  def #{method}#{DoubleX_RMVXA::ECATB::GAME_ENEMY[config][0]}
    #{$game_system.send(config)}
  end
    ))
    #
    return unless validate
    check_ecatb_def(method, DoubleX_RMVXA::ECATB::GAME_ENEMY[config])
  end # create_ecatb_def

  #----------------------------------------------------------------------------|
  #  Checks all new methods and resets them to the defaults if they're invalid |
  #----------------------------------------------------------------------------|
  module_eval(DoubleX_RMVXA::ECATB::CHECK_RESET_DEF[:GAME_ENEMY]) # New

  #----------------------------------------------------------------------------|
  #  Marks that the state array changed as well                                |
  #----------------------------------------------------------------------------|
  def erase_state(state_id, &argb) # New
    @ecatb_state_change = [true, true, true, true] if @states.include?(state_id)
    super(state_id, &argb)
  end # erase_state

  #----------------------------------------------------------------------------|
  #  Marks that the state array changed as well                                |
  #----------------------------------------------------------------------------|
  def clear_states(*argv, &argb) # New
    super(*argv, &argb)
    @ecatb_state_change = [true, true, true, true]
  end # clear_states

  #----------------------------------------------------------------------------|
  #  Marks that the state array changed as well                                |
  #----------------------------------------------------------------------------|
  def add_new_state(state_id, &argb) # New
    super(state_id, &argb)
    @ecatb_state_change = [true, true, true, true]
  end # add_new_state

  def init_ecatb_vars # New
    super
    @ecatb_bar_show = []
  end # init_ecatb_vars

  #----------------------------------------------------------------------------|
  #  Marks that the enemy with id being this enemy's id has been killed before |
  #----------------------------------------------------------------------------|
  def die # New
    super
    return if $game_party.ecatb_dead_enemies.include?(@enemy_id)
    $game_party.ecatb_dead_enemies << @enemy_id
  end # die

  # start: The battle start type
  def default_ecatb_start_val(start) # New
    return normal_enemy_1st_ecatb_val if start == :start_0
    return preemptive_enemy_1st_ecatb_val if start == :start_1
    surprise_enemy_1st_ecatb_val
  end # default_ecatb_start_val

  def confirm_ecatb_item # New
    super
    post_ecatb_input_act
  end # confirm_ecatb_item

  # index: The indicator of which atb bar parts queries its display flag
  def ecatb_bar_show?(index) # New; Hotspot
    # Reevaluates the atb bar part display flags only if the states changed
    if @ecatb_state_change[index]
      @ecatb_state_change[index] = @ecatb_bar_show[index] = nil
      states.each { |state|
        next if (show = state.enemy_ecatb_bar_show[index]).nil?
        return @ecatb_bar_show[index] = show
      }
    end
    #
    return @ecatb_bar_show[index] unless @ecatb_bar_show[index].nil?
    enemy.enemy_ecatb_bar_show[index]
  end # ecatb_bar_show?

end # Game_Enemy

#------------------------------------------------------------------------------|
#  * Hosts the atb pool mode flag for game party and troop                     |
#------------------------------------------------------------------------------|
class Game_Unit # Edit

  #----------------------------------------------------------------------------|
  #  New public instance variable                                              |
  #----------------------------------------------------------------------------|
  attr_accessor :ecatb_pool # The party/troop atb pool mode flag

end # Game_Unit

#------------------------------------------------------------------------------|
#  * Holds the defeated enemies, added actors and removed actors during battles|
#------------------------------------------------------------------------------|
class Game_Party < Game_Unit # Edit

  #----------------------------------------------------------------------------|
  #  New public instance variable                                              |
  #----------------------------------------------------------------------------|
  attr_accessor :ecatb_dead_enemies # The list of defeated enemies

  #----------------------------------------------------------------------------|
  #  Creates new methods of all configurations used by actors as well          |
  #----------------------------------------------------------------------------|
  alias initialize_ecatb initialize
  def initialize(*argv, &argb)
    initialize_ecatb(*argv, &argb)
    create_ecatb_defs # Added
  end # initialize

  #----------------------------------------------------------------------------|
  #  Initializes all new variables as well                                     |
  #----------------------------------------------------------------------------|
  alias init_all_items_ecatb init_all_items
  def init_all_items(*argv, &argb)
    init_all_items_ecatb(*argv, &argb)
    @ecatb_dead_enemies = [] # Added
  end # init_all_items

  #----------------------------------------------------------------------------|
  #  Notifies that an actor's added into the party as well                     |
  #----------------------------------------------------------------------------|
  alias add_actor_ecatb add_actor # v0.02b+
  def add_actor(actor_id, &argb)
    # Added
    if @in_battle && !@actors.include?(actor_id)
      $game_temp.ecatb_add_actors << $game_actors[actor_id]
    end
    #
    add_actor_ecatb(actor_id, &argb)
  end # add_actor

  #----------------------------------------------------------------------------|
  #  Notifies that an actor's removed from the party as well                   |
  #----------------------------------------------------------------------------|
  alias remove_actor_ecatb remove_actor # v0.02b+
  def remove_actor(actor_id, &argb)
    # Added
    if @in_battle && @actors.include?(actor_id)
      $game_temp.ecatb_remove_actors << $game_actors[actor_id]
    end
    #
    remove_actor_ecatb(actor_id, &argb)
  end # remove_actor

  #----------------------------------------------------------------------------|
  #  Creates and checks the associated method for each configuration used here |
  #----------------------------------------------------------------------------|
  # config: The configuration requesting its associated method
  # validate: The configuration value validation flag
  def create_ecatb_def(config, validate = true) # New
    # Uses the name and value of configuration as its method's name and contents
    method = config.id2name
    eval(%Q(
  def #{method}#{DoubleX_RMVXA::ECATB::GAME_PARTY_TROOP[config][0]}
    #{$game_system.send(config)}
  end
    ))
    #
    return unless validate
    check_ecatb_def(method, DoubleX_RMVXA::ECATB::GAME_PARTY_TROOP[config])
  end # create_ecatb_def

  #----------------------------------------------------------------------------|
  #  Checks all new methods and resets them to the defaults if they're invalid |
  #----------------------------------------------------------------------------|
  module_eval(DoubleX_RMVXA::ECATB::CHECK_RESET_DEF[:GAME_PARTY_TROOP]) # New

end # Game_Party

class Game_Troop < Game_Unit # Edit

  #----------------------------------------------------------------------------|
  #  Initializes all enemies' new variables and methods as well                |
  #----------------------------------------------------------------------------|
  alias setup_ecatb setup
  def setup(troop_id, &argb)
    setup_ecatb(troop_id, &argb)
    @enemies.each(&DoubleX_RMVXA::ECATB::BLOCKS[:create_ecatb_defs]) # Added
  end # setup

  #----------------------------------------------------------------------------|
  #  Creates and checks the associated method for each configuration used here |
  #----------------------------------------------------------------------------|
  # config: The configuration requesting its associated method
  # validate: The configuration value validation flag
  def create_ecatb_def(config, validate = true) # New
    # Uses the name and value of configuration as its method's name and contents
    method = config.id2name
    eval(%Q(
  def #{method}#{DoubleX_RMVXA::ECATB::GAME_PARTY_TROOP[config][0]}
    #{$game_system.send(config)}
  end
    ))
    #
    return unless validate
    check_ecatb_def(method, DoubleX_RMVXA::ECATB::GAME_PARTY_TROOP[config])
  end # create_ecatb_def

  #----------------------------------------------------------------------------|
  #  Checks all new methods and resets them to the defaults if they're invalid |
  #----------------------------------------------------------------------------|
  module_eval(DoubleX_RMVXA::ECATB::CHECK_RESET_DEF[:GAME_PARTY_TROOP]) # New

end # Game_Troop

#------------------------------------------------------------------------------|
#  * Hosts actor/enemy sprite atb, charge and cooldown bars                    |
#------------------------------------------------------------------------------|
class Sprite_Battler < Sprite_Base # Edit

  #----------------------------------------------------------------------------|
  #  New private instance variable                                             |
  #----------------------------------------------------------------------------|
  # @ecatb_bars: The battler's atb bars

  #----------------------------------------------------------------------------|
  #  Create all atb bars as well                                               |
  #----------------------------------------------------------------------------|
  alias initialize_ecatb initialize
  def initialize(viewport, battler = nil, &argb)
    initialize_ecatb(viewport, battler, &argb)
    # Added
    return unless BattleManager.btype?(:ecatb) && @battler
    return unless @battler.enemy? || BattleManager.actor_sprite_ecatb_bar
    create_ecatb_bars
    #
  end # initialize

  #----------------------------------------------------------------------------|
  #  Disposes all atb bars as well                                             |
  #----------------------------------------------------------------------------|
  alias dispose_ecatb dispose
  def dispose(*argv, &argb)
    dispose_ecatb(*argv, &argb)
    # Added
    return unless @ecatb_bars && BattleManager.btype?(:ecatb)
    @ecatb_bars.each_value(&DoubleX_RMVXA::ECATB::BLOCKS[:dispose])
    @ecatb_bars = nil
    #
  end # dispose

  #----------------------------------------------------------------------------|
  #  Updates all atb bars as well                                              |
  #----------------------------------------------------------------------------|
  alias update_ecatb update
  def update # Hotspot
    update_ecatb
    # Added
    return unless @ecatb_bars && BattleManager.btype?(:ecatb)
    @ecatb_bars.each_value(&DoubleX_RMVXA::ECATB::BLOCKS[:update])
    #
  end # update

  #----------------------------------------------------------------------------|
  #  Creates the back, atb, charge, color and text bars                        |
  #----------------------------------------------------------------------------|
  def create_ecatb_bars # New
    @ecatb_bars = {}
    # Uses 1 bar for each atb type if multilayer's used
    types = if @battler.ecatb_bar_multilayer
      [:back, :atb, :charge, :cooldown, :text]
    else
      [:back, :atbs, :text]
    end
    #
    types.each { |type| @ecatb_bars[type] = ECATB_Bar.new(@battler, type) }
  end # create_ecatb_bars

end # Sprite_Battler

#------------------------------------------------------------------------------|
#  * (v0.00b+)Fixes bugs and edge cases                                        |
#------------------------------------------------------------------------------|
class Spriteset_Battle # Edit

  #----------------------------------------------------------------------------|
  #  Inserts actors into the actor sprites as well                             |
  #----------------------------------------------------------------------------|
  alias create_actors_ecatb create_actors
  def create_actors(*argv, &argb)
    # Rewritten
    return create_actors_ecatb(*argv, &argb) unless BattleManager.btype?(:ecatb)
    dispose_actors if @actor_sprites
    @actor_sprites = $game_party.battle_members.reverse!.collect! { |actor|
      Sprite_Battler.new(@viewport1, actor)
    }
    #
  end # create_actors

end # Spriteset_Battle

#------------------------------------------------------------------------------|
#  * (v0.01a+)Handles the battler icons in the atb battler order window        |
#------------------------------------------------------------------------------|
class ECATB_Order_Battler_Icon < Sprite # New

  #----------------------------------------------------------------------------|
  #  Private instance variables                                                |
  #----------------------------------------------------------------------------|
  # @battler: The battler using the atb order icon
  # @icon: The battler atb order icon
  # @window: The battler atb order window

  def initialize(battler, window)
    super(SceneManager.scene.spriteset.viewport1)
    @battler = battler
    @window = window
    update
  end # initialize

  def dispose
    return if disposed?
    bitmap.dispose unless bitmap.disposed?
    super
  end # dispose

  def update # Hotspot
    return unless (self.visible = @battler.alive?) && 
    BattleManager.phase != :init
    if @icon != icon = @battler.set_ecatb_order_battler_icon
      @icon = icon.clone
      create_sprite_bitmap
    end
    update_pos
  end # update

  def create_sprite_bitmap # Potential Hotspot
    bitmap.dispose if bitmap && !bitmap.disposed?
    self.bitmap = Bitmap.new(dw = @icon[1].width, dh = @icon[1].height)
    self.ox = self.oy = 0
    scale = @battler.set_ecatb_order_battler_scale
    bitmap.stretch_blt(Rect.new(0, 0, dw * scale, dh * scale), @icon[0], 
    @icon[1], @battler.set_ecatb_order_battler_opacity)
    @icon[0].dispose unless @icon[0].disposed?
  end # create_sprite_bitmap

  #----------------------------------------------------------------------------|
  #  Updates the icon x, y and z positions if they're changed                  |
  #----------------------------------------------------------------------------|
  def update_pos # Hotspot
    # Checks the battler's atb type and updates the icon positions accordingly
    dw = @window.ecatb_order_bar_wh[0] / 3
    xyz = @window.ecatb_order_window_xyz
    dx = xyz[0] + @battler.ecatb_order_battler_icon_x
    dx += if (type = @battler.ecatb_bar_type) == :cooldown
      (100.0 - @battler.ecatb_val[type] % 100.0) / 100.0 * dw
    else
      ([@battler.ecatb_val[type], 100.0].min / 100.0 + 
      (type == :atb ? 1 : 2)) * dw
    end
    #
    self.x = dx if x != dx
    dy = xyz[1] + if @battler.actor?
      @battler.ecatb_order_actor_icon_y
    else
      @battler.ecatb_order_enemy_icon_y
    end
    self.y = dy if y != dy
    dz = @battler.set_ecatb_order_battler_z
    self.z = dz if z != dz
  end # update_pos

end # ECATB_Order_Battler_Icon

#------------------------------------------------------------------------------|
#  * Handles the actor/enemy sprite atb, charge and cooldown bars              |
#------------------------------------------------------------------------------|
class ECATB_Bar < Viewport # New

  #----------------------------------------------------------------------------|
  #  Private instance variables                                                |
  #----------------------------------------------------------------------------|
  # @battler: The battler using the atb bar
  # @last_wh: The last atb bar width and height
  # @last_text_xy_offset : The last text x and y offsets
  # @last_x: The last atb bar x position
  # @last_y: The last atb bar y position
  # @last_xy_offset: The last atb bar x and y offsets
  # @one_color: The color 1 and color 2 being the same flag
  # @outline: The atb bar outline drawing flag
  # @plane: The plane with the bitmap drawing the atb bar
  # @type: The atb bar type

  # type: The atb bar type
  def initialize(battler, type)
    init_vars(battler, type)
    create_ecatb_defs
    dw = (wh = ecatb_bar_wh)[0]
    dh = @type == :text ? ecatb_bar_text_size : wh[1]
    if @outline
      dw += 2
      dh += 2
    end
    super(Rect.new((xy = ecatb_bar_xy_offset)[0], xy[1], dw, dh))
    init_bars
  end # initialize

  # type: The atb bar type
  def init_vars(battler, type)
    @battler = battler
    @type = type
    @outline = @type == :back || @type == :text
  end # init_vars

  #----------------------------------------------------------------------------|
  #  Creates and checks the associated method for each configuration used here |
  #----------------------------------------------------------------------------|
  # config: The configuration requesting its associated method
  # validate: The configuration value validation flag
  def create_ecatb_def(config, validate = true) # v0.04f+
    # Uses the name and value of configuration as its method's name and contents
    method = config.id2name
    eval(%Q(
  def #{method}#{DoubleX_RMVXA::ECATB::ECATB_BAR[config][0]}
    #{$game_system.send(config)}
  end
    ))
    #
    return unless validate
    check_ecatb_def(method, DoubleX_RMVXA::ECATB::ECATB_BAR[config])
  end # create_ecatb_def

  #----------------------------------------------------------------------------|
  #  Checks all new methods and resets them to the defaults if they're invalid |
  #----------------------------------------------------------------------------|
  module_eval(DoubleX_RMVXA::ECATB::CHECK_RESET_DEF[:ECATB_BAR]) # v0.04f+

  def init_bars
    (@plane = Plane.new(self)).bitmap = Bitmap.new(rect.width * 2, rect.height)
    self.visible = false
    update_pos
    draw_bars
  end # init_bars

  def dispose
    return if @plane.disposed?
    @plane.bitmap.dispose if @plane.bitmap
    @plane.dispose
    super
  end # dispose

  #----------------------------------------------------------------------------|
  #  Updates the bar visibility, xy positions, width, height, color and text   |
  #----------------------------------------------------------------------------|
  def update # Hotspot
    super
    return unless self.visible = visible?
    update_pos
    unless @outline
      update_bar_w
      if @battler.ecatb_battler_change?(type = @battler.ecatb_bar_type)
        return draw_bars unless @type != type && @battler.ecatb_bar_multilayer
      end
    end
    return update_text if @type == :text
    @plane.ox -= ecatb_bar_ani_ox if @one_color && ecatb_bar_ani
  end # update

  #----------------------------------------------------------------------------|
  #  Updates the bar xy positions and height only if any of them changes       |
  #----------------------------------------------------------------------------|
  def update_pos # Hotspot
    z_pos = ecatb_bar_z
    self.z = z_pos if z != z_pos
    return unless update_pos?
    rect.width = @last_wh[0] + 2 if @outline
    rect.height = @last_wh[1] + (@outline ? 2 : 0)
    update_xy
  end # update_pos

  #----------------------------------------------------------------------------|
  #  Updates the bar and text xy positions                                     |
  #----------------------------------------------------------------------------|
  def update_xy # Hotspot
    dx = @last_x + @last_xy_offset[0] - (@last_wh[0] + (@outline ? 2 : 0)) / 2
    dy = @last_y + @last_xy_offset[1]
    if @type == :text
      dx += @last_text_xy_offset[0]
      dy += @last_text_xy_offset[1]
    end
    rect.x = dx
    dh = rect.height + (@outline ? 1 : 3)
    rect.y = dy + (@outline ? 0 : 1)
  end # update_xy

  def draw_bars
    dw = rect.width
    dh = rect.height
    @outline ? rect.width = @last_wh[0] + 2 : update_bar_w
    @one_color = (colors = set_bar_colors)[0] == colors[1]
    (bitmap = @plane.bitmap).gradient_fill_rect(0, 0, dw, dh, colors[0], 
    colors[1])
    bitmap.gradient_fill_rect(dw, 0, dw, dh, colors[1], colors[0])
  end # draw_bars

  #----------------------------------------------------------------------------|
  #  Updates the atb bar width if it's changed                                 |
  #----------------------------------------------------------------------------|
  def update_bar_w # Hotspot
    type = @battler.ecatb_bar_multilayer ? @type : @battler.ecatb_bar_type
    w = @battler.ecatb_val[type] % 100.0 * @last_wh[0] / 100.0
    rect.width = w if rect.width != w
  end # update_bar_w

  def set_bar_colors
    return ecatb_bar_back_colors if @type == :back
    return [Color.new(0, 0, 0, 0), Color.new(0, 0, 0, 0)] if @type == :text
    type = @battler.ecatb_bar_multilayer ? @type : @battler.ecatb_bar_type
    @battler.set_ecatb_bar_colors(type)
    @battler.ecatb_notes[type]
  end # set_bar_colors

  #----------------------------------------------------------------------------|
  #  Redraws the atb bar texts only if its contents and/or fonts changed       |
  #----------------------------------------------------------------------------|
  def update_text # Hotspot
    text = ecatb_bar_text((text = set_text)[0], text[1])
    return unless update_text_font? || @last_text != text
    @last_text = text
    return self.visible = false if text.empty?
    self.visible = true
    dw = (bitmap = @plane.bitmap).text_size(text).width
    bitmap.clear
    bitmap.draw_text(@last_wh[0] + 2 - dw, 0, dw, 
    bitmap.text_size(text).height, text)
  end # update_text

  #----------------------------------------------------------------------------|
  #  Sets the atb bar fill percent and action point text if they're to be shown|
  #----------------------------------------------------------------------------|
  def set_text # Hotspot
    [@battler.actor? || @battler.ecatb_bar_show?(2) ? 
     @battler.ecatb_val[@battler.ecatb_bar_type].to_i.to_s : "", 
     @battler.actor? || @battler.ecatb_bar_show?(3) ? 
     @battler.ecatb_act_times.to_s : ""]
  end # set_text

  #----------------------------------------------------------------------------|
  #  Checks if the atb bars and text should be visible                         |
  #----------------------------------------------------------------------------|
  def visible? # Hotspot
    # Checks if the battler's alive and the enemy's bars should be shown
    return false if $game_party.all_dead? || $game_troop.all_dead?
    return @battler.alive? if @battler.actor?
    return false unless @battler.alive? && @battler.ecatb_bar_show?(1)
    return true unless @battler.ecatb_bar_show?(0)
    $game_party.ecatb_dead_enemies.include?(@battler.enemy_id)
    #
  end # visible?

  #----------------------------------------------------------------------------|
  #  Checks if the atb bar and text positions need to be updated               |
  #----------------------------------------------------------------------------|
  def update_pos? # Hotspot
    # Checks if the bar width, height, offset or battler x or y position changes
    dx = @battler.screen_x
    dy = @battler.screen_y
    xy_offset = ecatb_bar_xy_offset
    same_pos = @last_wh == (wh = ecatb_bar_wh) && @last_x == dx && 
    @last_y == dy && @last_xy_offset == xy_offset
    return false if @type != :text && same_pos
    if @type == :text
      text_xy_offset = ecatb_bar_text_xy_offset
      return false if same_pos && @last_text_xy_offset == text_xy_offset
      @last_text_xy_offset = text_xy_offset.clone
    end
    @last_wh = wh.clone
    @last_x = dx
    @last_y = dy
    @last_xy_offset = xy_offset
    #
  end # update_pos?

  #----------------------------------------------------------------------------|
  #  Checks if the atb bar text color and size's changed and updates them if so|
  #----------------------------------------------------------------------------|
  def update_text_font? # Hotspot
    change = false
    if (font = @plane.bitmap.font).color != color = ecatb_bar_text_color
      change = font.color = color 
    end
    size = ecatb_bar_text_size
    change = font.size = size if font.size != size
    change
    #
  end # update_text_font?

end # ECATB_Bar

#------------------------------------------------------------------------------|
#  * Handles the battle atb clock bar in battle atb clock and turn window      |
#------------------------------------------------------------------------------|
class ECATB_Clock_Bar < Viewport # New

  #----------------------------------------------------------------------------|
  #  Private instance variables                                                |
  #----------------------------------------------------------------------------|
  # @last_w: Stores the last width of the atb clock bar
  # @plane: Stores the plane with the bitmap drawing the atb clock bar

  def initialize
    create_ecatb_defs
    xy = ecatb_clock_bar_xy
    rect = Rect.new(xy[0], xy[1], (wh = ecatb_clock_bar_wh)[0], wh[1])
    super(rect)
    create_bars
    update_bar_wh
    update_bar_xy
  end # initialize

  #----------------------------------------------------------------------------|
  #  Creates and checks the associated method for each configuration used here |
  #----------------------------------------------------------------------------|
  # config: The configuration requesting its associated method
  # validate: The configuration value validation flag
  def create_ecatb_def(config, validate = true) # New
    # Uses the name and value of configuration as its method's name and contents
    method = config.id2name
    eval(%Q(
  def #{method}#{DoubleX_RMVXA::ECATB::ECATB_CLOCK_BAR[config][0]}
    #{$game_system.send(config)}
  end
    ))
    #
    return unless validate
    check_ecatb_def(method, DoubleX_RMVXA::ECATB::ECATB_CLOCK_BAR[config])
  end # create_ecatb_def

  #----------------------------------------------------------------------------|
  #  Checks all new methods and resets them to the defaults if they're invalid |
  #----------------------------------------------------------------------------|
  module_eval(DoubleX_RMVXA::ECATB::CHECK_RESET_DEF[:ECATB_CLOCK_BAR]) # New

  def dispose
    return if @plane.disposed?
    @plane.bitmap.dispose if @plane.bitmap
    @plane.dispose
    super
  end # dispose

  def create_bars
    (@plane = Plane.new(self)).bitmap = Bitmap.new(rect.width * 2, rect.height)
    update_bar_colors
    self.visible = true
  end # create_bars

  def update_bar_colors # Potential Hotspot
    @plane.bitmap.gradient_fill_rect(0, 0, rect.width, rect.height, 
    (colors = ecatb_clock_bar_colors)[0], colors[1])
    rect.width = 0
  end # update_bar_colors

  #----------------------------------------------------------------------------|
  #  Updates the atb clock window bar width and height only if they've changed |
  #----------------------------------------------------------------------------|
  def update_bar_wh # Potential Hotspot
    wh = ecatb_clock_bar_wh
    rect.width = @last_w = wh[0] if @last_w != wh[0]
    rect.height = wh[1] if rect.height != wh[1]
  end # update_bar_wh

  #----------------------------------------------------------------------------|
  #  Updates the atb clock window bar xy positions only if they've changed     |
  #----------------------------------------------------------------------------|
  def update_bar_xy # Potential Hotspot
    xy = ecatb_clock_bar_xy
    rect.x = xy[0] if rect.x != xy[0]
    rect.y = xy[1] if rect.y != xy[1]
  end # update_bar_xy

  #----------------------------------------------------------------------------|
  #  Updates the atb clock window bar length only if it needs to change        |
  #----------------------------------------------------------------------------|
  # cur_clock: The number of frames passed in the current turn
  # max_clock: The number of frames of the current turn
  def update_bar(cur_clock, max_clock) # Hotspot
    update
    w = @last_w * 1.0 * cur_clock / max_clock
    rect.width = w if rect.width != w
  end # update_bar

end # ECATB_Clock_Bar

#------------------------------------------------------------------------------|
#  * Fixes bugs and edge cases                                                 |
#------------------------------------------------------------------------------|
class Window_ItemList < Window_Selectable # Edit

  #----------------------------------------------------------------------------|
  #  Disables items in battles when the user doesn't have enough action points |
  #----------------------------------------------------------------------------|
  alias enable_ecatb? enable?
  def enable?(item)
    # Added
    if SceneManager.scene_is?(Scene_Battle) && item && item.is_a?(RPG::Item)
      if BattleManager.btype?(:ecatb)
        battler = BattleManager.actor
        return battler.usable?(item) if (ecatb = DoubleX_RMVXA::ECATB).send(
        item.ecatb_act_cost, battler) > 1 || ecatb.send(
        item.ecatb_unison_actor, battler).size > 1
      end
    end
    #
    enable_ecatb?(item)
  end # enable?

end # Window_ItemList

#------------------------------------------------------------------------------|
#  * Fixes bugs and edge cases                                                 |
#------------------------------------------------------------------------------|
class Window_EquipItem < Window_ItemList # v0.02d+; Edit

  #----------------------------------------------------------------------------|
  #  Clears and resets all blocks of the actor before and after serialization  |
  #----------------------------------------------------------------------------|
  alias update_help_ecatb update_help
  def update_help
    @actor.clear_ecatb_blocks # Added
    update_help_ecatb
    @actor.reset_ecatb_blocks if SceneManager.scene_is?(Scene_Battle) # Added
  end # update_help

end # Window_EquipItem

#------------------------------------------------------------------------------|
#  * Shows all unison actors' names when executing an unison skill/item        |
#------------------------------------------------------------------------------|
class Window_BattleLog < Window_Selectable # Edit

  #----------------------------------------------------------------------------|
  #  Displays all unison actors' names if they're all to be shown as well      |
  #----------------------------------------------------------------------------|
  alias display_use_item_ecatb display_use_item
  def display_use_item(subject, item, &argb)
    # Added
    if BattleManager.btype?(:ecatb) && subject.show_ecatb_unison_battlers
      if subject.ecatb_unison_actors.size > 1
        return display_ecatb_unison_item(item, subject.ecatb_unison_actors)
      end
    end
    #
    display_use_item_ecatb(subject, item, &argb)
  end # display_use_item

  # actors: The unison actors
  def display_ecatb_unison_item(item, actors) # New
    battler_names = ecatb_unison_battler_names(actors)
    unless item.is_a?(RPG::Skill)
      return add_text(sprintf(Vocab::UseItem, battler_names, item.name))
    end
    add_text(battler_names + item.message1)
    return if item.message2.empty?
    wait
    add_text(item.message2)
  end # display_use_item

  # actors: The unison actors
  def ecatb_unison_battler_names(actors) # New
    names = ""
    max_index = actors.size - 1
    actors.each_with_index { |actor, index|
      (names += index < max_index ? ", " : " and ") if index > 0
      names += actor.name
    }
    names
  end # ecatb_unison_battler_names

end # Window_BattleLog

#------------------------------------------------------------------------------|
#  * Adds actor selection hotkeys and lets directional commands cycle          |
#------------------------------------------------------------------------------|
class Window_ActorCommand < Window_Command # Edit

  #----------------------------------------------------------------------------|
  #  New private instance variable                                             |
  #----------------------------------------------------------------------------|
  # @ecatb_hotkey_block: The hotkey handling block

  #----------------------------------------------------------------------------|
  #  Initializes the new block used by process_handling as well                |
  #----------------------------------------------------------------------------|
  alias initialize_ecatb initialize
  def initialize(*argv, &argb)
    initialize_ecatb(*argv, &argb)
    init_ecatb_block # Added
  end # initialize

  #----------------------------------------------------------------------------|
  #  Set left arrow output as switching to prior actor in ecatb battle system  |
  #----------------------------------------------------------------------------|
  alias process_dir4_ecatb process_dir4
  def process_dir4 # Potential Hotspot
    return process_dir4_ecatb unless BattleManager.btype?(:ecatb) # Rewritten
    # Added
    Sound.play_cursor
    Input.update
    deactivate
    call_handler(:dir4)
    #
  end # process_dir4

  #----------------------------------------------------------------------------|
  #  Calls the hotkey handler methods if the hotkey's pressed                  |
  #----------------------------------------------------------------------------|
  module_eval(DoubleX_RMVXA::ECATB::ACTOR_HOTKEY) # Alias; Hotspot

  #----------------------------------------------------------------------------|
  #  Initializes the new block to trade memory usage for time performance      |
  #----------------------------------------------------------------------------|
  def init_ecatb_block # New
    # Calls this block instead of an anonymous function per enumerable iteration
    @ecatb_hotkey_block = 
    -> hotkey { return call_handler(hotkey) if Input.trigger?(hotkey) }
    #
  end # init_ecatb_block

end # Window_ActorCommand

#------------------------------------------------------------------------------|
#  * Draws the atb, charge and cooldown bars of all actors                     |
#------------------------------------------------------------------------------|
class Window_BattleStatus < Window_Selectable # New

  #----------------------------------------------------------------------------|
  #  (v0.04f+)New public instance variables                                    |
  #----------------------------------------------------------------------------|
  attr_writer :ecatb_text_change # The atb bar text format change notifier
  attr_writer :ecatb_word_change # The atb bar description change notifier
  attr_writer :ecatb_y_add_change # The atb bar y offset change notifier

  #----------------------------------------------------------------------------|
  #  New private instance variables                                            |
  #----------------------------------------------------------------------------|
  # @ecatb_draw_bars: The atb bar drawing iteartor block
  # @last_ecatb_text: The last atb bar fill percentage and action point text
  # @last_ecatb_w: The last atb bar width

  #----------------------------------------------------------------------------|
  #  Initializes all new methods and block as well                             |
  #----------------------------------------------------------------------------|
  alias initialize_ecatb initialize
  def initialize(*argv, &argb)
    initialize_ecatb(*argv, &argb)
    # Added
    create_ecatb_defs
    @last_ecatb_text = {}
    @last_ecatb_w = {}
    init_ecatb_block
    #
  end # initialize

  #----------------------------------------------------------------------------|
  #  Redraws the atb bar and text if the battle started as well                |
  #----------------------------------------------------------------------------|
  alias draw_item_ecatb draw_item
  def draw_item(index, &argb) # Potential Hotspot
    draw_item_ecatb(index, &argb)
    # Added
    return if BattleManager.phase == :init
    return unless index && BattleManager.btype?(:ecatb)
    set_ecatb_bar(index, true) unless BattleManager.actor_sprite_ecatb_bar
    #
  end # draw_item

  #----------------------------------------------------------------------------|
  #  Creates and checks the associated method for each configuration used here |
  #----------------------------------------------------------------------------|
  # config: The configuration requesting its associated method
  # validate: The configuration value validation flag
  def create_ecatb_def(config, validate = true) # New
    # Uses the name and value of configuration as its method's name and contents
    method = config.id2name
    eval(%Q(
  def #{method}#{DoubleX_RMVXA::ECATB::WINDOW_BATTLESTATUS[config][0]}
    #{$game_system.send(config)}
  end
    ))
    #
    return unless validate
    check_ecatb_def(method, DoubleX_RMVXA::ECATB::WINDOW_BATTLESTATUS[config])
  end # create_ecatb_def

  #----------------------------------------------------------------------------|
  #  Checks all new methods and resets them to the defaults if they're invalid |
  #----------------------------------------------------------------------------|
  module_eval(DoubleX_RMVXA::ECATB::CHECK_RESET_DEF[:WINDOW_BATTLESTATUS]) # New

  #----------------------------------------------------------------------------|
  #  Initializes the new block to trade memory usage for time performance      |
  #----------------------------------------------------------------------------|
  def init_ecatb_block # New
    # Calls this block instead of an anonymous function per enumerable iteration
    @ecatb_draw_bars = -> index { set_ecatb_bar(index) }
    #
  end # init_ecatb_block

  def ecatb_bar_refresh # New; Hotspot
    item_max.times(&@ecatb_draw_bars)
  end # ecatb_bar_refresh

  #----------------------------------------------------------------------------|
  #  Sets the color, length, width and y position of the actor's atb bar       |
  #----------------------------------------------------------------------------|
  # redrawn: The status window redrawn flag
  def set_ecatb_bar(index, redrawn = false) # New; Hotspot
    return if $game_troop.all_dead?
    return unless actor = $game_party.battle_members[index]
    battler_change = actor.ecatb_battler_change?(type = actor.ecatb_bar_type)
    # Redraws atb bar and text only if they're changed or window's redrawn
    return unless draw_ecatb_bar?(actor, redrawn, type, battler_change)
    draw_ecatb_bar(actor, (rect = item_rect(index)).x + 2, line_height + 
    YEA::BATTLE::BATTLESTATUS_HPGAUGE_Y_PLUS + actor_ecatb_bar_y_add, 
    rect.width - 4, actor.ecatb_bar_type, battler_change)
    #
  end # set_ecatb_bar

  #----------------------------------------------------------------------------|
  #  Draws the actor's atb bar with its description and details text           |
  #----------------------------------------------------------------------------|
  # type: The atb bar type to be drawn
  # change: The atb bar color change flag
  def draw_ecatb_bar(actor, dx, dy, width, type, change) # New; Hotspot
    actor.set_ecatb_bar_colors(type) if change
    draw_gauge(dx, dy, width, actor.ecatb_val[type] % 100.0 / 100.0, 
    (colors = actor.ecatb_notes[type])[0], colors[1])
    change_color(system_color)
    draw_text(dx + 2, dy + (Font.default_size - contents.font.size) / 2 + 1, 
    30, line_height, actor_ecatb_bar_word)
    return if @last_ecatb_text[actor].empty?
    draw_ecatb_text(actor, dx, dy, width, type)
  end # draw_ecatb_bar

  # type: The atb bar type to be drawn
  def draw_ecatb_text(actor, dx, dy, width, type) # New; Hotspot
    dw = text_size(text = actor_ecatb_bar_text(@last_ecatb_text[actor][0], 
    @last_ecatb_text[actor][1])).width + 2
    draw_text(dx + width - dw, dy + (Font.default_size - contents.font.size) / 
    2 + 1, dw, line_height, text)
  end # draw_ecatb_text

  # redrawn: The status window redrawn flag
  def draw_ecatb_bar?(actor, redrawn, type, battler_change) # v0.04f+; New; 
  # Hotspot
    w_change = @last_ecatb_w[actor] != @last_ecatb_w[actor] = 
    actor.ecatb_val[type] % 100.0 * (item_rect(index).width - 4) / 100.0
    text_change = @last_ecatb_text[actor] != @last_ecatb_text[actor] = [
    actor.ecatb_val[type].to_i.to_s, actor.ecatb_act_times.to_s]
    # Lets users notifies that the atb bar text format's changed instead
    return false unless redrawn || battler_change || w_change || text_change || 
    @ecatb_text_change || @ecatb_word_change || @ecatb_y_add_change
    !(@ecatb_text_change = @ecatb_word_change = @ecatb_y_add_change = false)
    #
  end # set_ecatb_bar

end # Window_BattleStatus

#------------------------------------------------------------------------------|
#  * Adds actor selection hotkeys and lets directional commands cycle          |
#------------------------------------------------------------------------------|
class Window_BattleActor < Window_BattleStatus # Edit

  #----------------------------------------------------------------------------|
  #  New private instance variable                                             |
  #----------------------------------------------------------------------------|
  # @ecatb_hotkey_block: The hotkey handling block

  #----------------------------------------------------------------------------|
  #  Always allow cyclic directional navigations in the ecatb battle system    |
  #----------------------------------------------------------------------------|
  alias horizontal_ecatb? horizontal?
  def horizontal? # Hotspot
    BattleManager.btype?(:ecatb) || horizontal_ecatb? # Rewritten
  end # horizontal?

  #----------------------------------------------------------------------------|
  #  Always allow cyclic directional navigations in the ecatb battle system    |
  #----------------------------------------------------------------------------|
  alias cursor_right_ecatb cursor_right
  def cursor_right(wrap = false) # Hotspot
    cursor_right_ecatb(wrap || BattleManager.btype?(:ecatb)) # Rewritten
  end # cursor_right

  #----------------------------------------------------------------------------|
  #  Always allow cyclic directional navigations in the ecatb battle system    |
  #----------------------------------------------------------------------------|
  alias cursor_left_ecatb cursor_left
  def cursor_left(wrap = false) # Hotspot
    cursor_left_ecatb(wrap || BattleManager.btype?(:ecatb)) # Rewritten
  end # cursor_left

  #----------------------------------------------------------------------------|
  #  Calls the hotkey handler methods if the hotkey's pressed                  |
  #----------------------------------------------------------------------------|
  module_eval(DoubleX_RMVXA::ECATB::ACTOR_HOTKEY) # Alias; Hotspot

  #----------------------------------------------------------------------------|
  #  Initializes the new block to trade memory usage for time performance      |
  #----------------------------------------------------------------------------|
  def init_ecatb_block # New
    super
    # Calls this block instead of an anonymous function per enumerable iteration
    @ecatb_hotkey_block = 
    -> hotkey { return call_handler(hotkey) if Input.trigger?(hotkey) }
    #
  end # init_ecatb_block

end # Window_BattleActor

#------------------------------------------------------------------------------|
#  * Adds enemy selection hotkeys and fixes bugs and edge cases                |
#------------------------------------------------------------------------------|
class Window_BattleEnemy < Window_Selectable # Edit

  #----------------------------------------------------------------------------|
  #  New private instance variable                                             |
  #----------------------------------------------------------------------------|
  # @ecatb_hotkey_block: The hotkey handling block

  #----------------------------------------------------------------------------|
  #  Updates only when the enemies has changed                                 |
  #----------------------------------------------------------------------------|
  def update # Rewrite; Hotspot
    super
    # Added
    return unless active && (!BattleManager.btype?(:ecatb) || ecatb_update?)
    #
    return enemy.sprite_effect_type = :whiten unless select_all?
    @data.each(&DoubleX_RMVXA::ECATB::BLOCKS[:window_battleenemy_update])
  end # update

  #----------------------------------------------------------------------------|
  #  Initializes the new block used by process_handling as well                |
  #----------------------------------------------------------------------------|
  alias initialize_ecatb initialize # v0.04d+
  def initialize(info_viewport, &argb)
    initialize_ecatb(info_viewport, &argb)
    init_ecatb_block # Added
  end # initialize

  #----------------------------------------------------------------------------|
  #  Prevents division by 0 error                                              |
  #----------------------------------------------------------------------------|
  alias col_max_ecatb col_max
  def col_max # Hotspot
    # Added
    return ((max = col_max_ecatb) < 1 ? 1 : max) if BattleManager.btype?(:ecatb)
    #
    col_max_ecatb
  end # col_max

  #----------------------------------------------------------------------------|
  #  Calls the hotkey handler methods if the hotkey's pressed                  |
  #----------------------------------------------------------------------------|
  module_eval(DoubleX_RMVXA::ECATB::ACTOR_HOTKEY) # v0.04d+; Alias; Hotspot

  #----------------------------------------------------------------------------|
  #  Checks if the enemies has changed and updates their data accordingly      |
  #----------------------------------------------------------------------------|
  def ecatb_update? # New; Hotspot
    return false if (alive_members = $game_troop.alive_members).empty?
    if @data.size != alive_members.size
      @data = alive_members
      @data.sort!(&DoubleX_RMVXA::ECATB::BLOCKS[:sort_screen_x])
      @index = @data.size - 1 if @index >= @data.size
    end
    true
  end # ecatb_update?

  #----------------------------------------------------------------------------|
  #  Initializes the new block to trade memory usage for time performance      |
  #----------------------------------------------------------------------------|
  def init_ecatb_block # v0.04d+; New
    # Calls this block instead of an anonymous function per enumerable iteration
    @ecatb_hotkey_block = 
    -> hotkey { return call_handler(hotkey) if Input.trigger?(hotkey) }
    #
  end # init_ecatb_block

end # Window_BattleEnemy

#------------------------------------------------------------------------------|
#  * Fixes bugs and edge cases                                                 |
#------------------------------------------------------------------------------|
class Window_BattleHelp < Window_Help # v0.04a+; Edit

  #----------------------------------------------------------------------------|
  #  Only lets valid battlers have their names retrieved                       |
  #----------------------------------------------------------------------------|
  alias battler_name_ecatb battler_name
  def battler_name(battler) # Hotspot
    battler ? battler_name_ecatb(battler) : nil # Rewritten
  end # battler_name

  alias refresh_battler_name_ecatb refresh_battler_name
  def refresh_battler_name(battler) # v0.05a+; Hotspot
    refresh_battler_name_ecatb(battler) if battler # Rewritten
  end # refresh_battler_name

end # Window_BattleHelp

#------------------------------------------------------------------------------|
#  * Handles the battle atb clock and turn number window                       |
#------------------------------------------------------------------------------|
class ECATB_Clock_Window < Window_Base # New

  #----------------------------------------------------------------------------|
  #  Public instance variables                                                 |
  #----------------------------------------------------------------------------|
  attr_reader :clock_bar # The atb clock bar
  attr_writer :cur_clock # The current atb clock
  attr_writer :max_clock # The atb clock maximum

  #----------------------------------------------------------------------------|
  #  Private instance variables                                                |
  #----------------------------------------------------------------------------|
  # @last_text_x: The last text x position
  # @last_text_y: The last text y position

  # cur_clock: The number of frames passed in the current turn
  # max_clock: The number of frames of the current turn
  def initialize(cur_clock, max_clock)
    create_ecatb_defs
    xyz = ecatb_clock_window_xyz
    super(xyz[0], xyz[1], (wh = ecatb_clock_window_wh)[0], wh[1])
    self.z = xyz[2]
    @clock_bar = ECATB_Clock_Bar.new
    @cur_clock = cur_clock
    @max_clock = max_clock
    update_text_font
    update_text_xy
    refresh
  end # initialize

  #----------------------------------------------------------------------------|
  #  Creates and checks the associated method for each configuration used here |
  #----------------------------------------------------------------------------|
  # config: The configuration requesting its associated method
  # validate: The configuration value validation flag
  def create_ecatb_def(config, validate = true) # New
    # Uses the name and value of configuration as its method's name and contents
    method = config.id2name
    eval(%Q(
  def #{method}#{DoubleX_RMVXA::ECATB::ECATB_CLOCK_WINDOW[config][0]}
    #{$game_system.send(config)}
  end
    ))
    #
    return unless validate
    check_ecatb_def(method, DoubleX_RMVXA::ECATB::ECATB_CLOCK_WINDOW[config])
  end # create_ecatb_def

  #----------------------------------------------------------------------------|
  #  Checks all new methods and resets them to the defaults if they're invalid |
  #----------------------------------------------------------------------------|
  module_eval(DoubleX_RMVXA::ECATB::CHECK_RESET_DEF[:ECATB_CLOCK_WINDOW])

  def dispose
    @clock_bar.dispose if @clock_bar
    super
  end # dispose

  #----------------------------------------------------------------------------|
  #  Updates the window positions, width and height, and text font             |
  #----------------------------------------------------------------------------|
  module_eval(DoubleX_RMVXA::ECATB::WINDOW_DEFS[:clock])

  #----------------------------------------------------------------------------|
  #  Updates the atb clock text x and y positions only if they change          |
  #----------------------------------------------------------------------------|
  def update_text_xy # Potential Hotspot
    xy = ecatb_clock_text_xy
    @last_text_x = xy[0] if @last_text_x != xy[0]
    @last_text_y = xy[1] if @last_text_y != xy[1]
  end # update_text_xy

  #----------------------------------------------------------------------------|
  #  Refreshes the atb clock window bar and text                               |
  #----------------------------------------------------------------------------|
  def refresh # Hotspot
    contents.clear
    @clock_bar.update_bar(@cur_clock, @max_clock)
	  draw_text(@last_text_x, @last_text_y, contents.width, contents.height, 
    ecatb_clock_text(@cur_clock, @max_clock, $game_troop.turn_count), 0)
  end # refresh

end # ECATB_Clock_Window

#------------------------------------------------------------------------------|
#  * Handles the atb force status window                                       |
#------------------------------------------------------------------------------|
class ECATB_Force_Window < Window_Base # New

  #----------------------------------------------------------------------------|
  #  Private instance variables                                                |
  #----------------------------------------------------------------------------|
  # @last_text_x: The last text x position
  # @last_text_y: The last text y position

  # force: The atb force status
  def initialize(force)
    create_ecatb_defs
    xyz = ecatb_force_window_xyz
    super(xyz[0], xyz[1], (wh = ecatb_force_window_wh)[0], wh[1])
    self.z = xyz[2]
    update_text_font
    update_text_xy
    draw_text(force ||= :nil)
  end # initialize

  #----------------------------------------------------------------------------|
  #  Creates and checks the associated method for each configuration used here |
  #----------------------------------------------------------------------------|
  # config: The configuration requesting its associated method
  # validate: The configuration value validation flag
  def create_ecatb_def(config, validate = true) # New
    # Uses the name and value of configuration as its method's name and contents
    method = config.id2name
    eval(%Q(
  def #{method}#{DoubleX_RMVXA::ECATB::ECATB_FORCE_WINDOW[config][0]}
    #{$game_system.send(config)}
  end
    ))
    #
    return unless validate
    check_ecatb_def(method, DoubleX_RMVXA::ECATB::ECATB_FORCE_WINDOW[config])
  end # create_ecatb_def

  #----------------------------------------------------------------------------|
  #  Checks all new methods and resets them to the defaults if they're invalid |
  #----------------------------------------------------------------------------|
  module_eval(DoubleX_RMVXA::ECATB::CHECK_RESET_DEF[:ECATB_FORCE_WINDOW])

  #----------------------------------------------------------------------------|
  #  Updates the window positions, width and height, and text font             |
  #----------------------------------------------------------------------------|
  module_eval(DoubleX_RMVXA::ECATB::WINDOW_DEFS[:force])

  #----------------------------------------------------------------------------|
  #  Updates the atb force text x and y positions only if they change          |
  #----------------------------------------------------------------------------|
  def update_text_xy # Potential Hotspot
    xy = ecatb_force_text_xy
    @last_text_x = xy[0] if @last_text_x != xy[0]
    @last_text_y = xy[1] if @last_text_y != xy[1]
  end # update_text_xy

  # force: The atb force status
  def draw_text(force)
    contents.clear
    text = if force == :nil
      ecatb_force_nil_text
    elsif force == :run
      ecatb_force_run_text
    else
      ecatb_force_stop_text
    end
	  super(@last_text_x, @last_text_y, contents.width, contents.height, text, 0)
  end # draw_text

end # ECATB_Force_Window

#------------------------------------------------------------------------------|
#  * Handles the atb battler icon order window                                 |
#------------------------------------------------------------------------------|
class ECATB_Order_Window < Window_Base # v0.01a+; New

  #----------------------------------------------------------------------------|
  #  Private instance variable                                                 |
  #----------------------------------------------------------------------------|
  # @battler_icons: All atb order battler icons

  def initialize
    create_ecatb_defs
    xyz = ecatb_order_window_xyz
    super(xyz[0], xyz[1], (wh = ecatb_order_window_wh)[0], wh[1])
    self.z = xyz[2]
    draw_bars
    @battler_icons = {}
    ($game_party.all_members + $game_troop.members).each { |mem|
      @battler_icons[mem] = ECATB_Order_Battler_Icon.new(mem, self)
    }
  end # initialize

  #----------------------------------------------------------------------------|
  #  Creates and checks the associated method for each configuration used here |
  #----------------------------------------------------------------------------|
  # config: The configuration requesting its associated method
  # validate: The configuration value validation flag
  def create_ecatb_def(config, validate = true) # New
    # Uses the name and value of configuration as its method's name and contents
    method = config.id2name
    eval(%Q(
  def #{method}#{DoubleX_RMVXA::ECATB::ECATB_ORDER_WINDOW[config][0]}
    #{$game_system.send(config)}
  end
    ))
    #
    return unless validate
    check_ecatb_def(method, DoubleX_RMVXA::ECATB::ECATB_ORDER_WINDOW[config])
  end # create_ecatb_def

  #----------------------------------------------------------------------------|
  #  Checks all new methods and resets them to the defaults if they're invalid |
  #----------------------------------------------------------------------------|
  module_eval(DoubleX_RMVXA::ECATB::CHECK_RESET_DEF[:ECATB_ORDER_WINDOW])

  def dispose
    @battler_icons.each_value(&DoubleX_RMVXA::ECATB::BLOCKS[:dispose])
    super
  end # dispose

  #----------------------------------------------------------------------------|
  #  Updates the window positions, width and height, and text font             |
  #----------------------------------------------------------------------------|
  module_eval(DoubleX_RMVXA::ECATB::WINDOW_DEFS[:order])

  #----------------------------------------------------------------------------|
  #  Adding and removing some battler icons as well as updating existing ones  |
  #----------------------------------------------------------------------------|
  def update_battler_icons # Hotspot
    update_battler_icon_list
    @battler_icons.each_value(&DoubleX_RMVXA::ECATB::BLOCKS[:update])
  end # update_battler_icons

  #----------------------------------------------------------------------------|
  #  Updates the list of battlers having icons showing the orders              |
  #----------------------------------------------------------------------------|
  def update_battler_icon_list # v0.02b+; Hotspot
    # Creates and delete icons for newly added and removed battlers respectively
    unless (actors = $game_temp.ecatb_add_actors).empty?
      $game_temp.ecatb_add_actors.clear
      actors.each { |actor|
        @battler_icons[actor] ||= ECATB_Order_Battler_Icon.new(actor, self)
      }
    end
    return if (actors = $game_temp.ecatb_remove_actors).empty?
    $game_temp.ecatb_remove_actors.clear
    actors.each { |a| @battler_icons[a].dispose if @battler_icons[a] }
    #
  end # update_battler_icon_list

  #----------------------------------------------------------------------------|
  #  Draws the cooldown, atb and charge bars  from the left to the right       |
  #----------------------------------------------------------------------------|
  def draw_bars # Potential Hotspot
    color = ecatb_order_cooldown_bar_colors
    contents.gradient_fill_rect((xy = ecatb_order_bar_xy)[0], xy[1], 
    (wh = ecatb_order_bar_wh)[0] / 3, wh[1], color[0], color[1])
    contents.gradient_fill_rect(xy[0] + wh[0] / 3, xy[1], wh[0] / 3, wh[1], 
    (color = ecatb_order_bar_colors)[0], color[1])
    contents.gradient_fill_rect(xy[0] + wh[0] * 2 / 3, xy[1], wh[0] / 3, wh[1], 
    (color = ecatb_order_charge_bar_colors)[0], color[1])
    draw_texts(wh[0] / 3)
  end # draw_bars

  #----------------------------------------------------------------------------|
  #  Draws the cooldown, atb and charge texts from the left to the right       |
  #----------------------------------------------------------------------------|
  # dw: The maximum cooldown, atb and charge text width
  def draw_texts(dw) # Potential Hotspot
    update_text_font
    wh = text_size(text = ecatb_order_cooldown_bar_text)
    xy = ecatb_order_text_xy
    draw_text(xy[0], xy[1], wh.width + 2, wh.height, text)
    wh = text_size(text = ecatb_order_bar_text)
    draw_text(xy[0] + dw, xy[1], wh.width + 2, wh.height, text)
    wh = text_size(text = ecatb_order_charge_bar_text)
    draw_text(xy[0] + dw * 2, xy[1], wh.width + 2, wh.height, text)
  end # draw_texts

end # ECATB_Order_Window

#------------------------------------------------------------------------------|
#  * Handles the pool atb mode window                                          |
#------------------------------------------------------------------------------|
class ECATB_Pool_Window < Window_Base # New

  #----------------------------------------------------------------------------|
  #  Private instance variables                                                |
  #----------------------------------------------------------------------------|
  # @last_party_x: The last party pool text x position
  # @last_party_y: The last party pool text y position
  # @last_troop_x: The last troop pool text x position
  # @last_troop_y: The last troop pool text y position

  def initialize
    create_ecatb_defs
    xyz = ecatb_pool_window_xyz
    super(xyz[0], xyz[1], (wh = ecatb_pool_window_wh)[0], wh[1])
    self.z = xyz[2]
    update_text_font
    update_text_xy
    draw_text
  end # initialize

  #----------------------------------------------------------------------------|
  #  Creates and checks the associated method for each configuration used here |
  #----------------------------------------------------------------------------|
  # config: The configuration requesting its associated method
  # validate: The configuration value validation flag
  def create_ecatb_def(config, validate = true) # New
    # Uses the name and value of configuration as its method's name and contents
    method = config.id2name
    eval(%Q(
  def #{method}#{DoubleX_RMVXA::ECATB::ECATB_POOL_WINDOW[config][0]}
    #{$game_system.send(config)}
  end
    ))
    #
    return unless validate
    check_ecatb_def(method, DoubleX_RMVXA::ECATB::ECATB_POOL_WINDOW[config])
  end # create_ecatb_def

  #----------------------------------------------------------------------------|
  #  Checks all new methods and resets them to the defaults if they're invalid |
  #----------------------------------------------------------------------------|
  module_eval(DoubleX_RMVXA::ECATB::CHECK_RESET_DEF[:ECATB_POOL_WINDOW])

  #----------------------------------------------------------------------------|
  #  Updates the window positions, width and height, and text font             |
  #----------------------------------------------------------------------------|
  module_eval(DoubleX_RMVXA::ECATB::WINDOW_DEFS[:pool])

  #----------------------------------------------------------------------------|
  #  Updates party and troop atb pool mode text x, y positions if they change  |
  #----------------------------------------------------------------------------|
  def update_text_xy # Potential Hotspot
    xy = ecatb_pool_party_text_xy
    @last_party_x = xy[0] if @last_party_x != xy[0]
    @last_party_y = xy[1] if @last_party_y != xy[1]
    xy = ecatb_pool_troop_text_xy
    @last_troop_x = xy[0] if @last_troop_x != xy[0]
    @last_troop_y = xy[1] if @last_troop_y != xy[1]
  end # update_text_xy

  #----------------------------------------------------------------------------|
  #  Draws the party and troop atb mode text on the window                     |
  #----------------------------------------------------------------------------|
  def draw_text # Potential Hotspot
    contents.clear
	  super(@last_party_x, @last_party_y, contents.width, contents.height, 
    ecatb_pool_party_actor_text[$game_party.ecatb_pool ? 0 : 1], 0)
	  super(@last_troop_x, @last_troop_y, contents.width, contents.height, 
    ecatb_pool_troop_enemy_text[$game_troop.ecatb_pool ? 0 : 1], 0)
  end # draw_text

end # ECATB_Pool_Window

#------------------------------------------------------------------------------|
#  * Reconstructs the the whole battle flow to control the atb system          |
#------------------------------------------------------------------------------|
class Scene_Battle < Scene_Base # Edit

  #----------------------------------------------------------------------------|
  #  New public instance variables                                             |
  #----------------------------------------------------------------------------|
  attr_accessor :ecatb_clock_window # The atb clock window
  attr_accessor :ecatb_force_window # The atb force window
  attr_accessor :ecatb_order_window # The atb order window
  attr_accessor :ecatb_pool_window # The atb pool window

  #----------------------------------------------------------------------------|
  #  New private instance variables                                            |
  #----------------------------------------------------------------------------|
  # @ecatb_act_block: The action execution iterator block
  # @ecatb_cancel_help_window: The atb cancel help window
  # @ecatb_clock: The global atb clock
  # @ecatb_force_clock: The atb force status
  # @ecatb_refresh_block: The window refresh iterator block

  #----------------------------------------------------------------------------|
  #  Creates new methods, window command handlers, variables and blocks as well|
  #----------------------------------------------------------------------------|
  alias start_ecatb start
  def start(*argv, &argb)
    start_ecatb(*argv, &argb)
    ecatb_start # Added
  end # start

  #----------------------------------------------------------------------------|
  #  Updates the atb cancel window and force clock for the ecatb battle system |
  #----------------------------------------------------------------------------|
  alias update_basic_ecatb update_basic
  def update_basic # Hotspot
    update_basic_ecatb
    # Added
    return unless BattleManager.btype?(:ecatb)
    update_ecatb_cancel_window if update_ecatb_cancel_window?
    update_ecatb_force_clock
    #
  end # update_basic

  #----------------------------------------------------------------------------|
  #  Run the atb frame update if the wait conditions aren't met as well        |
  #----------------------------------------------------------------------------|
  alias update_for_wait_ecatb update_for_wait
  def update_for_wait # Hotspot
    update_for_wait_ecatb
    # Added
    return unless BattleManager.phase != :init && BattleManager.btype?(:ecatb)
    ecatb_update if ecatb_update?
    #
  end # update_for_wait

  #----------------------------------------------------------------------------|
  #  Moves the info viewport according to which windows are active as well     |
  #----------------------------------------------------------------------------|
  alias update_info_viewport_ecatb update_info_viewport
  def update_info_viewport # Hotspot
    update_info_viewport_ecatb
    ecatb_update_info_viewport if BattleManager.btype?(:ecatb) # Added
  end # update_info_viewport

  #----------------------------------------------------------------------------|
  #  Open the active status, actor command and party command windows as well   |
  #----------------------------------------------------------------------------|
  alias update_message_open_ecatb update_message_open
  def update_message_open # Hotspot
    update_message_open_ecatb
    # Added
    return if $game_message.busy?
    return unless @status_window.close?
    return if $game_troop.all_dead? || $game_party.all_dead?
    ecatb_update_message_open if BattleManager.btype?(:ecatb)
    #
  end # update_message_open

  #----------------------------------------------------------------------------|
  #  Create new windows in the ecatb battle system as well                     |
  #----------------------------------------------------------------------------|
  alias create_all_windows_ecatb create_all_windows
  def create_all_windows(*argv, &argb)
    create_all_windows_ecatb(*argv, &argb)
    create_ecatb_windows if BattleManager.btype?(:ecatb) # Added
  end # create_all_windows

  alias start_actor_command_selection_ecatb start_actor_command_selection
  def start_actor_command_selection # v0.05a+; Potential Hotspot
    start_actor_command_selection_ecatb
    @actor_command_window.show if BattleManager.btype?(:ecatb) # Added
  end # start_actor_command_selection

  #----------------------------------------------------------------------------|
  #  Processes unison attacks as well                                          |
  #----------------------------------------------------------------------------|
  alias command_attack_ecatb command_attack
  def command_attack(*argv, &argb)
    # Added
    return unless actor = BattleManager.actor
    if BattleManager.btype?(:ecatb)
      ecatb = DoubleX_RMVXA::ECATB
      actors = ecatb.send($data_skills[actor.attack_skill_id].
      ecatb_unison_actor, actor).collect!(&ecatb::BLOCKS[:usable?])
      return command_ecatb_unison_attack(actors) if actors.size > 1
    end
    #
    command_attack_ecatb(*argv, &argb)
    @status_window.draw_item(actor.index) # Added
  end # command_attack

  #----------------------------------------------------------------------------|
  #  Fixes bugs and edge cases                                                 |
  #----------------------------------------------------------------------------|
  alias command_skill_ecatb command_skill
  def command_skill(*argv, &argb)
    return if BattleManager.btype?(:ecatb) && !BattleManager.actor # Added
    command_skill_ecatb(*argv, &argb)
  end # command_skill

  #----------------------------------------------------------------------------|
  #  Confirms the guard and processes unison guards as well                    |
  #----------------------------------------------------------------------------|
  alias command_guard_ecatb command_guard
  def command_guard(*argv, &argb)
    # Added
    return unless actor = BattleManager.actor
    if ecatb = BattleManager.btype?(:ecatb)
      ecatb = DoubleX_RMVXA::ECATB
      actors = ecatb.send($data_skills[actor.guard_skill_id].
      ecatb_unison_actor, actor).collect!(&ecatb::BLOCKS[:usable?])
      return command_ecatb_unison_attack(actors) if actors.size > 1
    end
    actor.input.set_guard
    if ecatb
      actor.confirm_ecatb_item
      @status_window.draw_item(actor.index)
    end
    #
    command_guard_ecatb(*argv, &argb)
  end # command_guard

  #----------------------------------------------------------------------------|
  #  Confirms the skill/item and processes unison confirmation as well         |
  #----------------------------------------------------------------------------|
  alias on_actor_ok_ecatb on_actor_ok
  def on_actor_ok(*argv, &argb)
    # Added
    return unless actor = BattleManager.actor
    if BattleManager.btype?(:ecatb) && on_ecatb_unison?(:ok, @actor_window)
      return
    elsif BattleManager.btype?(:ecatb)
      actor.confirm_ecatb_item
      @status_window.draw_item(actor.index)
    end
    #
    on_actor_ok_ecatb(*argv, &argb)
  end # on_actor_ok

  #----------------------------------------------------------------------------|
  #  Confirms the skill/item and processes unison confirmation as well         |
  #----------------------------------------------------------------------------|
  alias on_enemy_ok_ecatb on_enemy_ok
  def on_enemy_ok(*argv, &argb)
    # Added
    return unless (actor = BattleManager.actor) && @enemy_window.ecatb_update?
    if BattleManager.btype?(:ecatb) && on_ecatb_unison?(:ok, @enemy_window)
      return
    elsif BattleManager.btype?(:ecatb)
      actor.confirm_ecatb_item
      @status_window.draw_item(actor.index)
    end
    #
    on_enemy_ok_ecatb(*argv, &argb)
  end # on_enemy_ok

  #----------------------------------------------------------------------------|
  #  Processes unison skill/item target cancellation as well                   |
  #----------------------------------------------------------------------------|
  # Alias
  DoubleX_RMVXA::ECATB::ON_TARGET_CANCEL.each_value { |val| module_eval(val) }
  #

  #----------------------------------------------------------------------------|
  #  Processes unison skill/item selection as well                             |
  #----------------------------------------------------------------------------|
  # Alias
  DoubleX_RMVXA::ECATB::ON_SKILL_ITEM_OK.each_value { |val| module_eval(val) }
  #

  #----------------------------------------------------------------------------|
  #  Closes all input windows right after finishing inputting actions          |
  #----------------------------------------------------------------------------|
  alias turn_start_ecatb turn_start
  def turn_start(*argv, &argb)
    return ecatb_turn_start if BattleManager.btype?(:ecatb) # Added
    turn_start_ecatb(*argv, &argb)
  end # turn_start

  #----------------------------------------------------------------------------|
  #  Triggers the atb frame update and executes forced actions as well         |
  #----------------------------------------------------------------------------|
  alias process_action_ecatb process_action
  def process_action # Hotspot
    return process_action_ecatb unless BattleManager.btype?(:ecatb) # Rewritten
    # Added
    ecatb_update if ecatb_update?
    return unless BattleManager.action_forced?
    exec_ecatb_act(@subject, true) if exec_ecatb_act?(@subject, true)
    #
  end # process_action

  #----------------------------------------------------------------------------|
  #  Refreshes all active command, item and target selection windows as well   |
  #----------------------------------------------------------------------------|
  alias status_redraw_target_ecatb status_redraw_target
  def status_redraw_target(target, &argb)
    # Added
    return if $game_party.all_dead? || $game_troop.all_dead?
    return unless BattleManager.phase
    #
    status_redraw_target_ecatb(target, &argb)
    # Added
    return unless BattleManager.btype?(:ecatb) && target.actor?
    refresh_ecatb_windows(true)
    #
  end # status_redraw_target

  def ecatb_start # v0.04d+; New
    create_ecatb_defs
    if BattleManager.btype?(:ecatb)
      set_ecatb_battler_window_handlers
      set_ecatb_actor_command_window_handlers
    end
    @ecatb_clock = { tick: 0, act: 0, force: 0 }
    @ecatb_force_clock = :nil
    init_ecatb_act_block
    init_ecatb_actor_refresh_block
  end # ecatb_start

  #----------------------------------------------------------------------------|
  #  Creates and checks the associated method for each configuration used here |
  #----------------------------------------------------------------------------|
  # config: The configuration requesting its associated method
  # validate: The configuration value validation flag
  def create_ecatb_def(config, validate = true) # New
    # Uses the name and value of configuration as its method's name and contents
    method = config.id2name
    eval(%Q(
  def #{method}#{DoubleX_RMVXA::ECATB::SCENE_BATTLE[config][0]}
    #{$game_system.send(config)}
  end
    ))
    #
    return unless validate
    check_ecatb_def(method, DoubleX_RMVXA::ECATB::SCENE_BATTLE[config])
  end # create_ecatb_def

  #----------------------------------------------------------------------------|
  #  Checks all new methods and resets them to the defaults if they're invalid |
  #----------------------------------------------------------------------------|
  module_eval(DoubleX_RMVXA::ECATB::CHECK_RESET_DEF[:SCENE_BATTLE]) # New

  #----------------------------------------------------------------------------|
  #  Initializes the new block to trade memory usage for time performance      |
  #----------------------------------------------------------------------------|
  def init_ecatb_act_block # New
    # Calls this block instead of an anonymous function per enumerable iteration
    @ecatb_act_block = -> battler {
      if battler.actor? && battler.input
        if !battler.input.last_ecatb_confirm && battler.input.ecatb_confirm
          battler.make_actions
        end
      end
      exec_ecatb_act(battler) if !@subject && exec_ecatb_act?(battler)
    }
    #
  end # init_ecatb_act_block

  #----------------------------------------------------------------------------|
  #  Initializes the new block to trade memory usage for time performance      |
  #----------------------------------------------------------------------------|
  def init_ecatb_actor_refresh_block # New
    # Calls this block instead of an anonymous function per enumerable iteration
    @ecatb_actor_refresh_block = -> mem {
      next unless mem.ecatb_refresh
      @actor_window.draw_item(mem.index) if @actor_window.active
      if @ecatb_cancel_window && @ecatb_cancel_window.active
        @ecatb_cancel_window.draw_item(mem.index)
      end
      @status_aid_window.refresh if @status_aid_window.visible
      @status_window.draw_item(mem.index) unless @status_window.close?
      mem.ecatb_refresh = false
      @ecatb_refresh = true
    }
    #
  end # init_ecatb_actor_refresh_block

  def create_ecatb_windows # New
    create_ecatb_cancel_window
    create_ecatb_clock_window
    create_ecatb_force_window
    create_ecatb_order_window
    create_ecatb_pool_window
  end # create_ecatb_windows

  #----------------------------------------------------------------------------|
  #  Closes all windows upon battle end                                        |
  #----------------------------------------------------------------------------|
  def close_ecatb_windows # New
    @ecatb_cancel_window.hide.deactivate.close if @ecatb_cancel_window
    close_ecatb_clock_window if @ecatb_clock_window
    close_ecatb_force_window if @ecatb_force_window
    close_ecatb_order_window if @ecatb_order_window
    close_ecatb_pool_window if @ecatb_pool_window
    [@actor_window, @enemy_window, @skill_window, @item_window, @help_window, 
     @actor_command_window, @party_command_window, @status_aid_window].each(
    &DoubleX_RMVXA::ECATB::BLOCKS[:close_ecatb_windows])
  end # close_ecatb_windows

  #----------------------------------------------------------------------------|
  #  Sets the battler window selection hotkeys and their handlers              |
  #----------------------------------------------------------------------------|
  def set_ecatb_battler_window_handlers # New
    battler_hotkeys = ecatb_battler_hotkeys
    create_ecatb_battler_hotkey_defs(battler_hotkeys, "actor", "actor")
    create_ecatb_battler_hotkey_defs(battler_hotkeys, "enemy", "enemy")
    battler_hotkeys.each_with_index { |hotkey, index|
      @actor_window.set_handler(hotkey, method(
      :"ecatb_actor_hotkey_#{index = index.to_s}"))
      @enemy_window.set_handler(hotkey, method(:"ecatb_enemy_hotkey_#{index}"))
    }
  end # set_ecatb_battler_window_handlers

  #----------------------------------------------------------------------------|
  #  Sets actor command window directional inputs and hotkeys and handlers     |
  #----------------------------------------------------------------------------|
  def set_ecatb_actor_command_window_handlers # New
    @actor_command_window.set_handler(:dir4, method(:prior_ecatb_actor))
    @actor_command_window.set_handler(:dir6, method(:next_ecatb_actor))
    actor_hotkeys = ecatb_battler_hotkeys
    create_ecatb_actor_command_hotkey_defs(actor_hotkeys)
    actor_hotkeys.each_with_index { |hotkey, index|
      @actor_command_window.set_handler(hotkey, method(
      :"ecatb_actor_command_hotkey_#{index.to_s}"))
    }
  end # set_ecatb_actor_command_window_handlers

  #----------------------------------------------------------------------------|
  #  Creates methods used by the actor command hotkey handlers                 |
  #----------------------------------------------------------------------------|
  def create_ecatb_actor_command_hotkey_defs(actor_hotkeys) # New
    actor_hotkeys.each_index { |index|
      next if respond_to?(:"ecatb_actor_command_hotkey_#{index = index.to_s}")
      eval(%Q(
    def ecatb_actor_command_hotkey_#{index}
      return if @ecatb_cancel_window && @ecatb_cancel_window.active
      return unless BattleManager.ecatb_input_list(true).include?(#{index})
      BattleManager.actor_index = #{index}
      start_actor_command_selection
    end
      ))
    }
  end # create_ecatb_actor_command_hotkey_defs

  def create_ecatb_cancel_window # New
    (@ecatb_cancel_help_window = Window_Help.new).visible = false
    (@ecatb_cancel_window = Window_BattleActor.new(@info_viewport)).x = 64
    @ecatb_cancel_window.set_handler(:ok, method(:on_ecatb_cancel_ok))
    @ecatb_cancel_window.set_handler(:cancel, method(:on_ecatb_cancel_back))
    battler_hotkeys = eval($game_system.ecatb_battler_hotkeys)
    create_ecatb_battler_hotkey_defs(battler_hotkeys, "cancel", "ecatb_cancel")
    battler_hotkeys.each_with_index { |hotkey, index|
      @ecatb_cancel_window.set_handler(hotkey, method(
      :"ecatb_cancel_hotkey_#{index.to_s}"))
    }
  end # create_ecatb_cancel_window

  #----------------------------------------------------------------------------|
  #  Creates methods used by the battler target selection hotkey handlers      |
  #----------------------------------------------------------------------------|
  def create_ecatb_battler_hotkey_defs(battler_hotkeys, type, window) # New
    battler_hotkeys.each_index { |index|
      eval(%Q(
    def ecatb_#{type}_hotkey_#{index = index.to_s}
      @#{window}_window.select(#{index})
    end
      )) unless respond_to?(:"ecatb_#{type}_hotkey_#{index}")
    }
  end # create_ecatb_battler_hotkey_defs

  def update_ecatb_cancel_window # New; Hotspot
    if @ecatb_cancel_window.active
      unless BattleManager.actor_sprite_ecatb_bar
        @ecatb_cancel_window.ecatb_bar_refresh
      end
      return
    end
    activate_ecatb_cancel_window if Input.trigger?(ecatb_cancel_key)
  end # update_ecatb_cancel_window

  def activate_ecatb_cancel_window # New
    @status_window.hide
    @actor_command_window.close if @actor_command_window.active
    @party_command_window.close if @party_command_window.active
    select_ecatb_cancel_selection
  end # activate_ecatb_cancel_window

  def on_ecatb_cancel_ok # New
    # Picks the actor and cancels that actor's action if it can be cancelled
    actor = $game_party.battle_members[@ecatb_cancel_window.index]
    return select_ecatb_cancel_selection unless actor.inputable?
    if actor.ecatb_val[:charge] <= 0.0 || actor.ecatb_val[:charge] >= 100.0
      return select_ecatb_cancel_selection unless actor.ecatb_esc
    end
    ecatb_cancel_act(actor)
    #
  end # on_ecatb_cancel_ok

  #----------------------------------------------------------------------------|
  #  Asks the actor to pay the action costs and clears that action             |
  #----------------------------------------------------------------------------|
  def ecatb_cancel_act(actor) # New
    # Asks all unison invokees to do those as well if the skill/item is unison
    if actor.ecatb_unison_actors.size < 2
      actor.ecatb_reset
      @status_window.draw_item(actor.index)
      @ecatb_cancel_window.draw_item(actor.index)
    else
      ecatb_cancel_unison_act(actor.ecatb_unison_actors)
    end
    #
    select_ecatb_cancel_selection
  end # ecatb_cancel_act

  #----------------------------------------------------------------------------|
  #  Pays the action costs and clears that action for unison skills/items      |
  #----------------------------------------------------------------------------|
  # actors: The unison actors
  def ecatb_cancel_unison_act(actors) # New
    actors.each { |actor|
      actor.ecatb_reset
      @status_window.draw_item(actor.index)
      @ecatb_cancel_window.draw_item(actor.index)
    }
  end # ecatb_cancel_unison_act

  def select_ecatb_cancel_selection # New
    @ecatb_cancel_window.show.activate.refresh
    @ecatb_cancel_help_window.show.activate.set_text(ecatb_cancel_text)
  end # select_ecatb_cancel_selection

  def on_ecatb_cancel_back # New
    @ecatb_cancel_window.hide.deactivate
    @ecatb_cancel_help_window.hide.deactivate
    @status_window.show
    @actor_command_window.open if @actor_command_window.active
    @party_command_window.open if @party_command_window.active
  end # on_ecatb_cancel_back

  def create_ecatb_clock_window # New
    return if @ecatb_clock_window
    return unless eval($game_system.show_ecatb_clock_window)
    @ecatb_clock_window = ECATB_Clock_Window.new(@ecatb_clock ? 
    @ecatb_clock[eval($game_system.ecatb_turn_type)] : 0, ecatb_max_clock)
  end # create_ecatb_clock_window

  def ecatb_max_clock # New
    if (type = eval($game_system.ecatb_turn_type)) == :tick
      return eval($game_system.ecatb_tick_count) * Graphics.frame_rate
    elsif type == :act
      return eval($game_system.ecatb_after_act)
    end
    eval($game_system.ecatb_battler_count) * 
    eval($game_system.ecatb_battler_scale[0])
  end # ecatb_max_clock

  #----------------------------------------------------------------------------|
  #  Creates the atb force, order and pool windows                             |
  #----------------------------------------------------------------------------|
  # v0.01b+; New
  DoubleX_RMVXA::ECATB::CREATE_WINDOW.each_value { |val| module_eval(val) }
  #

  #----------------------------------------------------------------------------|
  #  Closes the atb clock, force, order and pool windows                       |
  #----------------------------------------------------------------------------|
  # v0.01b+; New
  DoubleX_RMVXA::ECATB::CLOSE_WINDOW.each_value { |val| module_eval(val) }
  #

  #----------------------------------------------------------------------------|
  #  Moves the info viewport according to which windows are active             |
  #----------------------------------------------------------------------------|
  def ecatb_update_info_viewport # New; Hotspot
    return move_info_viewport(128) if @actor_command_window.active || 
    @actor_window.active || @enemy_window.active
    move_info_viewport(0) if @party_command_window.active || 
    update_msg_open_ecatb_compatibility?
  end # ecatb_update_info_viewport

  #----------------------------------------------------------------------------|
  #  Opens the status, command, item and target windows if they're active      |
  #----------------------------------------------------------------------------|
  def ecatb_update_message_open # New; Hotspot
    @status_window.open
    return @actor_command_window.open if @skill_window.active || 
    @item_window.active || @actor_window.active || @enemy_window.active || 
    @actor_command_window.active
    @party_command_window.open if @party_command_window.active || 
    update_msg_open_ecatb_compatibility?
  end # ecatb_update_message_open

  #----------------------------------------------------------------------------|
  #  Closes all input windows right after finishing inputting actions          |
  #----------------------------------------------------------------------------|
  def ecatb_turn_start # New
    @party_command_window.close
    @actor_command_window.close
    @status_window.unselect
    @log_window.wait
    @log_window.clear
  end # ecatb_turn_start

  def update_ecatb_force_clock # New; Hotspot
    if Input.trigger?(ecatb_force_run_key)
      @ecatb_force_clock = @ecatb_force_clock == :stop ? :nil : :run
      @ecatb_force_window.draw_text(@ecatb_force_clock) if @ecatb_force_window
    elsif Input.trigger?(ecatb_force_stop_key)
      @ecatb_force_clock = @ecatb_force_clock == :run ? :nil : :stop
      @ecatb_force_window.draw_text(@ecatb_force_clock) if @ecatb_force_window
    end
  end # update_ecatb_force_clock

  #----------------------------------------------------------------------------|
  #  Runs the atb frame update                                                 |
  #----------------------------------------------------------------------------|
  def ecatb_update # New; Hotspot
    pre_ecatb_update
    ecatb_ctb_update
    return unless BattleManager.phase
    refresh_ecatb_windows
    ecatb_update_actors
    unless @party_command_window.active || @status_window.index >= 0
      unless @ecatb_cancel_window && @ecatb_cancel_window.active
        start_actor_command_selection if BattleManager.ecatb_update_act_actor?
      end
    end
    BattleManager.action_battlers.each(&@ecatb_act_block)
    post_ecatb_update
  end # ecatb_update

  #----------------------------------------------------------------------------|
  #  Runs the battle and all battlers' atb clocks until any of them has to stop|
  #----------------------------------------------------------------------------|
  def ecatb_ctb_update # v0.04d+; New; Hotspot
    begin
      ecatb_update_tick_battler_count
      BattleManager.ecatb_update
    end until BattleManager.ecatb_ctb_break?
    @ecatb_clock_window.refresh if @ecatb_clock_window
  end # ecatb_ctb_update

  #----------------------------------------------------------------------------|
  #  Refreshes all windows used by actors if at least 1 of them has refreshed  |
  #----------------------------------------------------------------------------|
  # redrawn: Whether the whole status window has been redrawn
  def refresh_ecatb_windows(redrawn = false) # New; Hotspot
    $game_party.alive_members.each(&@ecatb_actor_refresh_block)
    @ecatb_order_window.update_battler_icons if @ecatb_order_window
    if @ecatb_refresh
      [@skill_window, @item_window, @actor_command_window, 
      @party_command_window].each(
      &DoubleX_RMVXA::ECATB::BLOCKS[:refresh_ecatb_windows])
      refresh_ecatb_windows_compatibility
      return @ecatb_refresh = false
    end
    return if BattleManager.actor_sprite_ecatb_bar
    @status_window.ecatb_bar_refresh unless redrawn && @status_window.close?
    @actor_window.ecatb_bar_refresh if @actor_window.active
  end # refresh_ecatb_windows

  #----------------------------------------------------------------------------|
  #  Resets non-actable selected actor's atb and updates all windows           |
  #----------------------------------------------------------------------------|
  def ecatb_update_actors # New; Hotspot
    if @status_window.index >= 0
      return if BattleManager.ecatb_input_list(true).include?(
      @status_window.index)
      ecatb_update_windows
    elsif BattleManager.ecatb_input_list.empty?
      @party_command_window.deactivate.close if @party_command_window.active
    end
  end # ecatb_update_actors

  def ecatb_update_windows # New; Hotspot
    if @skill_window.visible || @item_window.visible || 
    @actor_window.visible || @enemy_window.visible
      @status_window.open.show
      @status_aid_window.hide
    end
    [@actor_window, @enemy_window, @skill_window, @item_window, 
     @actor_command_window].each(
     &DoubleX_RMVXA::ECATB::BLOCKS[:ecatb_update_windows])
    @status_window.unselect
  end # ecatb_update_windows

  def ecatb_update_tick_battler_count # New; Hotspot
    return ecatb_update_tick_count if (type = ecatb_turn_type) == :tick
    return if type != :battler || ecatb_battler_scale[1] != :tick
    ecatb_update_battler_count
  end # ecatb_update_tick_battler_count

  def ecatb_update_tick_count # New; Hotspot
    max_clock = ecatb_tick_count * Graphics.frame_rate
    if (@ecatb_clock[:tick] += 1) >= max_clock
      @ecatb_clock[:tick] = 0
      ecatb_turn_add
    end
    return unless @ecatb_clock_window
    @ecatb_clock_window.cur_clock = @ecatb_clock[:tick]
    @ecatb_clock_window.max_clock = max_clock
  end # ecatb_update_tick_count

  # forced: The action force flag
  def exec_ecatb_act(subject, forced = false) # New
    # Disables party escape during action executions
    BattleManager.ecatb_can_esc = false
    force_act_cost = nil
    if @subject.current_action
      force_act_cost = exec_ecatb_act_loop(forced)
      exec_ecatb_act_clock(forced)
      process_action_end
    end
    BattleManager.ecatb_can_esc = true
    #
    return if BattleManager.judge_win_loss
    exec_ecatb_act_reset(forced, force_act_cost) if BattleManager.phase
  end # exec_ecatb_act

  #----------------------------------------------------------------------------|
  #  Executes all the battler's valid actions and sets their costs             |
  #----------------------------------------------------------------------------|
  # forced: The action force flag
  def exec_ecatb_act_loop(forced) # New
    while @subject.current_action.valid?
      @subject.current_action.prepare
      execute_action
      force_act_cost = @subject.exec_ecatb_act_cost(forced)
      process_event
      @subject.remove_current_action
      return if force_act_cost = exec_ecatb_act_loop_compatibility?(forced)
    end
    force_act_cost
  end # exec_ecatb_act_loop

  # forced: The action force flag
  def exec_ecatb_act_clock(forced) # New
    return exec_ecatb_act_update(forced) if (type = ecatb_turn_type) == :act
    return if type != :battler || ecatb_battler_scale[1] != :act
    ecatb_update_battler_count(forced)
  end # exec_ecatb_act_clock

  # forced: The action force flag
  def exec_ecatb_act_update(forced) # New
    @ecatb_clock[:act] += 1 if !forced || ecatb_force_act_count
    if @ecatb_clock[:act] >= (after_act = ecatb_after_act)
      @ecatb_clock[:act] = 0
      ecatb_turn_add
    end
    return unless @ecatb_clock_window
    @ecatb_clock_window.cur_clock = @ecatb_clock[:act]
    @ecatb_clock_window.max_clock = after_act
    @ecatb_clock_window.refresh
  end # exec_ecatb_act_update

  # forced: The action force flag
  def ecatb_update_battler_count(forced = false) # New; Hotspot
    @ecatb_clock[:battler] += 1 if !forced || ecatb_force_act_count
    max_clock = ecatb_battler_count * ecatb_battler_scale[0]
    if @ecatb_clock[:battler] >= (max_clock *= Graphics.frame_rate)
      @ecatb_clock[:battler] = 0
      ecatb_turn_add
    end
    return unless @ecatb_clock_window
    @ecatb_clock_window.cur_clock = @ecatb_clock[:tick]
    @ecatb_clock_window.max_clock = max_clock
  end # ecatb_update_battler_count

  #----------------------------------------------------------------------------|
  #  Resets the battler's atb and refreshes the actor in the status window     |
  #----------------------------------------------------------------------------|
  # forced: The action force flag
  def exec_ecatb_act_reset(forced, force_act_cost) # New
    if !forced || force_act_cost
      if @subject.ecatb_unison_actors.size > 1
        (@subject.ecatb_unison_actors & $game_party.alive_members).each { |a|
          a.ecatb_reset
          @status_window.draw_item(a.index)
        }
      else
        @subject.ecatb_reset
        @status_window.draw_item(@subject.index) if @subject.actor?
      end
    end
    @subject = nil
  end # exec_ecatb_act_reset

  def ecatb_turn_add # New
    BattleManager.turn_end if BattleManager.phase
    ecatb_turn_add_compatibility
    BattleManager.ecatb_on_turn_end
    $game_troop.increase_turn
  end # ecatb_turn_add

  #----------------------------------------------------------------------------|
  #  Picks and setups the prior inputable actor if any                         |
  #----------------------------------------------------------------------------|
  def prior_ecatb_actor # New; Potential Hotspot
    return if @ecatb_cancel_window && @ecatb_cancel_window.active
    start_actor_command_selection if BattleManager.change_ecatb_actor?(-1)
  end # prior_ecatb_actor

  #----------------------------------------------------------------------------|
  #  Picks and setups the next inputable actor if any                          |
  #----------------------------------------------------------------------------|
  def next_ecatb_actor # New; Potential Hotspot
    return if @ecatb_cancel_window && @ecatb_cancel_window.active
    start_actor_command_selection if BattleManager.change_ecatb_actor?(1)
  end # next_ecatb_actor

  # actors: The unison actors
  def command_ecatb_unison_attack(actors) # New
    $game_temp.battle_aid = $data_skills[BattleManager.actor.attack_skill_id]
    actors.each { |actor|
      actor.input.set_attack
      @status_window.draw_item(actor.index)
    }
    select_enemy_selection
  end # command_ecatb_unison_attack

  # actors: The unison actors
  def command_ecatb_unison_guard(actors) # New
    $game_temp.battle_aid = $data_skills[BattleManager.actor.guard_skill_id]
    confirm_ecatb_unison_item(actors)
    next_command
  end # command_ecatb_unison_guard

  # actors: The unison actors
  # window: The window having the unison item
  def on_ecatb_unison_target_ok(actors, window) # New
    $game_temp.battle_aid = nil
    unless BattleManager.actor.usable?(BattleManager.actor.input.item)
      return on_ecatb_unison_target_cancel(actors, window)
    end
    confirm_ecatb_unison_item(actors, window)
    window.hide
    @skill_window.hide
    @item_window.hide
    next_command
  end # on_ecatb_unison_target_ok

  # actors: The unison actors
  # window: The window having the unison item
  def confirm_ecatb_unison_item(actors, window = nil) # New
    actors.each { |actor|
      window ? actor.input.target_index = window.index : actor.input.set_guard
      actor.ecatb_unison_invoker = actor == BattleManager.actor
      actor.confirm_ecatb_item
      @status_window.draw_item(actor.index)
    }
  end # confirm_ecatb_unison_item

  # actors: The unison actors
  # window: The window having the unison item
  def on_ecatb_unison_target_cancel(actors, window) # New
    # Clears the unison item from all unison actors and backs to the last window
    clear_ecatb_unison_item(actors)
    @status_aid_window.refresh
    $game_temp.battle_aid = nil
    window.hide
    on_ecatb_unison_target_cancel_compatibility
    #
  end # on_ecatb_unison_target_cancel

  # actors: The unison actors
  def clear_ecatb_unison_item(actors) # New
    (actors & BattleManager.ecatb_input_list).each { |actor|
      actor.input.clear if actor.input
      @status_window.draw_item(actor.index)
    }
  end # on_ecatb_unison_target_cancel

  # actors: The unison actors
  # window: The window having the unison item
  def on_ecatb_unison_item_ok(actors, window) # New
    $game_temp.battle_aid = item = window.item
    $game_party.last_item.object = item if item.is_a?(RPG::Item)
    skill = item.is_a?(RPG::Skill)
    actors.each { |actor|
      actor.input.set_skill(item.id)
      actor.last_skill.object = item if skill
      @status_window.draw_item(actor.index)
    }
    return select_enemy_selection if item.for_opponent?
    select_actor_selection if item.for_friend?
  end # on_ecatb_unison_item_ok

  # actors: The unison actors
  # window: The window using the command
  def on_ecatb_unison_command(actors, command, window) # New
    return on_ecatb_unison_target_ok(actors, window) if command == :ok
    on_ecatb_unison_target_cancel(actors, window)
  end # on_ecatb_unison_command

  #----------------------------------------------------------------------------|
  #  Checks if the unison skill/item can be inputted                           |
  #----------------------------------------------------------------------------|
  def on_ecatb_unison_item_ok?(window) # New
    # Checks if the skill/item is an unison one and all unison actors' present
    return false unless BattleManager.btype?(:ecatb)
    ecatb = DoubleX_RMVXA::ECATB
    actors = ecatb.send(window.item.ecatb_unison_actor, BattleManager.actor)
    actors.collect!(&ecatb::BLOCKS[:usable?])
    return false if actors.size < 2
    on_ecatb_unison_item_ok(actors, window)
    true
    #
  end # on_ecatb_unison_item_ok?

  def update_ecatb_cancel_window? # New; Hotspot
    # Checks if no window that can interfere the atb cancel window is shown
    return false if @actor_window.active || @enemy_window.active
    return false if @skill_window.active || @item_window.active
    return false if $game_message.busy?
    !update_msg_open_ecatb_compatibility?
    #
  end # update_ecatb_cancel_window?

  #----------------------------------------------------------------------------|
  #  Checks if the atb frame update should be run                              |
  #----------------------------------------------------------------------------|
  def ecatb_update? # New; Hotspot
    # Checks if atb frame update can be updated and the wait condition isn't met
    return false if scene_changing? || BattleManager.phase == :init
    return false if $game_party.all_dead? || $game_troop.all_dead?
    return false if $game_message.visible
    BattleManager.phase && !ecatb_wait_cond
    #
  end # ecatb_update?

  #----------------------------------------------------------------------------|
  #  Checks if the battler's actions should be executed                        |
  #----------------------------------------------------------------------------|
  # forced: The action force flag
  def exec_ecatb_act?(subject, forced = false) # New; Hotspot
    # Checks if the battler's valid and has a fully charged valid input
    if subject
      return false unless forced || subject.exec_ecatb_act?
      @subject = subject
    end
    @subject
    #
  end # exec_ecatb_act?

  #----------------------------------------------------------------------------|
  #  Checks if the unison item command handlers should be called               |
  #----------------------------------------------------------------------------|
  # window: The window using the command
  def on_ecatb_unison?(command, window) # New
    # Checks if the input is an unison item and calls unison handlers if so
    return false unless (actor = BattleManager.actor).input && actor.input.item
    ecatb = DoubleX_RMVXA::ECATB
    actors = ecatb.send(actor.input.item.ecatb_unison_actor, actor)
    actors.collect!(&ecatb::BLOCKS[:usable?])
    return false if actors.size < 2
    on_ecatb_unison_command(actors, command, window)
    true
    #
  end # on_ecatb_unison?

  #----------------------------------------------------------------------------|
  #  (New)Lets the compatibility fix deals with compatibility issues           |
  #----------------------------------------------------------------------------|

  def refresh_ecatb_windows_compatibility # Potential Hotspot
  end # refresh_ecatb_windows_compatibility

  def update_msg_open_ecatb_compatibility? # Hotspot
  end # update_msg_open_ecatb_compatibility?

  # forced: The action force flag
  def exec_ecatb_act_loop_compatibility?(forced)
    forced || !@subject.current_action
  end # exec_ecatb_act_loop_compatibility?

  def ecatb_turn_add_compatibility
  end # ecatb_turn_add_compatibility

  def on_ecatb_unison_target_cancel_compatibility
    # Shows the last window upon cancelling picking targets of unison skill/item
    if @actor_command_window.current_symbol == :skill
      return @skill_window.activate.show
    elsif @actor_command_window.current_symbol == :item
      return @item_window.activate.show
    end
    @actor_command_window.activate.show
    #
  end # on_ecatb_unison_target_cancel_compatibility

end # Scene_Battle

  # Aliases all methods using unison method rules
  DoubleX_RMVXA::ECATB::UNISON_DEFS.each { |klass, defs|
    klass_def = %Q(
class #{klass[0].id2name}#{klass[1] ? " < #{klass[1].id2name}" : ""}
    )
    defs.each { |name|
      klass_def += %Q(
  alias #{name = name.id2name}_ecatb #{name}
  def #{name}(*argv, &argb)
    return #{name}_ecatb(*argv, &argb) unless @ecatb_unison_item
    defs = @ecatb_unison_item.ecatb_unison_actor_def[:#{name}]
    return #{name}_ecatb(*argv, &argb) unless defs
    ecatb = DoubleX_RMVXA::ECATB
    defs = [#{name}_ecatb(*argv, &argb)] + (ecatb.send(defs, self) - [id]).
    collect! { |i| $game_actors[i].#{name}(*argv, &argb) }
    rule = ecatb.send(@ecatb_unison_item.ecatb_unison_def_rule[:#{name}], self)
    ecatb_unison_rules(defs, rule)
  end
     )
    }
    eval(klass_def + %Q(
end
    ))
  }

#------------------------------------------------------------------------------|

else

  # Informs users that they didn't place YEA-BattleEngine above this script
  msgbox("To use DoubleX RMVXA Enhanced YSA Battle System: Classical ATB, put it
          below:\n" + 
         "Yanfly Engine Ace - Ace Battle Engine\n" +
         "but above Main") unless $imported["YEA-BattleEngine"]

  # Informs users that they used YSA-CATB with this script
  msgbox("DoubleX RMVXA Enhanced YSA Battle System: Classical ATB can't be used
          with:\n" + 
         "YSA Battle System: Classical ATB") if $imported["YSA-CATB"]

end # if $imported["YEA-BattleEngine"] && !$imported["YSA-CATB"]

#==============================================================================|