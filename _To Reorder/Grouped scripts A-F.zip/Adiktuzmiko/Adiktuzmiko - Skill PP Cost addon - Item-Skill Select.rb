=begin
 ==============================================================================

 Skill PP Cost Add-On: Item/Skill Skill Select v1.10
 by AdiktuzMiko
 --- Date Created: 01/10/2014
 --- Last Date Updated: 01/13/2014
 --- Level: Easy
 --- Requires: Skill PP Cost

 ==============================================================================
 Overview
 ==============================================================================
 
 Allows you to make an item/skill that selects a PP skill of the target to
 modify the PP of that skill. You can also open it up using event commands
 so you can make shops that restore PP for a selected skill
 
 Notes: You can only cancel the skill selection if you are in battle, outside
 of it, cancellation of selection is not allowed since it happens once the
 item is already used, which is the fastest way to make it work... 
 
 ==============================================================================
 How-To-Use
 ==============================================================================
  
 Edit the module below to adjust the window 
  
 For the item/skill set-up:
 
 Just put into the damage formula (if targettable item/skill): 
  
 b.is_restore_pp(a,type,value,gold,skillid,itemid)
  
 if caster is target
  
 a.is_restore_pp(a,type,value,gold,skillid,itemid)
  
 where:
  
 type => 
      "add" - adds value to current PP
      "mul" - multiplies value to current PP
		  "set" - sets current PP to value
      "add_max" - adds value to max PP
      "mul_max" - multiplies value to max PP
		  "set_max" - sets max PP to value
      "add_both" - adds value to current and max PP
      "mul_both" - multiplies value to current and max PP
		  "set_both" - sets current and max PP to value
      "restore" - restores PP to max

 #The following values can be omitted for battle-only skills/items
 gold = gold cost of restoration (mostly for paid events usage)
 skillid = id of skill (if skill)
 itemid = id of item (if item)
      
 You can also opt to use them in event script calls via
 
 $game_actors[id].is_restore_pp(nil,type,value)
 
 where id => id of actor to be healed
  
 ==============================================================================
 Compatibility
 ==============================================================================

 This script adds new methods to the Game_Actor and Scene_Base classes,
 and creates it's own window which inherits Window_SkillList
 
 Also aliases start methods of Scene_Base, Scene_Battle, Scene_Battle's
 on_item_ok,on_skill_ok,on_actor_ok, Game_Battler's item_test, Scene_Map's
 update and Window_BattleLog's display_damage
 
 ==============================================================================
 Terms and Conditions
 ==============================================================================

 View it here: http://lescripts.wordpress.com/terms-and-conditions/
 
 ==============================================================================
=end

module ADIK
  module SKILL_SELECT_PP
    #X position of the help window
    HELP_X = 0
	  #Y position of the help window
	  HELP_Y = 0
	  #Width of the help window
	  HELP_WIDTH = 544
	  #Height of the help window
	  HELP_HEIGHT = 64
    #Text shown on the help window
    HELP_TEXT = " Choose skill to modify PP"
    #Background color of help window
    #Color.new(Red,Green,Blue,Alpha)
    HELP_COLOR = Color.new(100,100,0,200)
    #Use gradient fill instead of single color?
    HELP_GRADIENT = true
    #Gradient color 1
    HELP_COLOR_1 = Color.new(100,100,0,200)
    #Gradient color 2
    HELP_COLOR_2 = Color.new(100,0,100,100)
    #Vertical gradient?
    HELP_VERTICAL = false
    #X position of the window
    X = 0
	  #Y position of the window
	  Y = HELP_HEIGHT
	  #Width of the window
	  WIDTH = 544
	  #Height of the window
	  HEIGHT = 416-Y
    #Shows skill PP restore message on battle log?
    SHOW_MESSAGE = true
  end
end

#==============================================================================
# DO NOT EDIT BELOW THIS LINE
#==============================================================================

class Window_SkillSelect < Window_SkillList
  
  def initialize(x, y, width, height)
    super(x, y, width, height)
    @spr = Sprite.new
    @spr.x = ADIK::SKILL_SELECT_PP::HELP_X
    @spr.y = ADIK::SKILL_SELECT_PP::HELP_Y
    ww = ADIK::SKILL_SELECT_PP::HELP_WIDTH
    wy = ADIK::SKILL_SELECT_PP::HELP_HEIGHT
    @spr.z = 400
    @spr.bitmap = Bitmap.new(ww,wy)
    rect = Rect.new(@spr.x,@spr.y,ww,wy)
    if ADIK::SKILL_SELECT_PP::HELP_GRADIENT 
      @spr.bitmap.gradient_fill_rect(rect,ADIK::SKILL_SELECT_PP::HELP_COLOR_1,ADIK::SKILL_SELECT_PP::HELP_COLOR_2,ADIK::SKILL_SELECT_PP::HELP_VERTICAL)
    else
      @spr.bitmap.fill_rect(rect,ADIK::SKILL_SELECT_PP::HELP_COLOR)
    end
    @spr.bitmap.draw_text(rect,ADIK::SKILL_SELECT_PP::HELP_TEXT,1)
  end
  
  def actor
    return @actor
  end
  
  def make_item_list
    @data = @actor ? @actor.skills.select {|skill| @actor.has_pp(skill.id) } : []
  end

   def enable?(item)
    return true
  end
  
  def dispose
    @spr.dispose
    super
  end
end

class Scene_Base
  #We attach the window to the scenes so that it updates when the scene updates
  #Also, doing it in Scene_Base makes it easier to use it in any scene
  attr_accessor :skill_select_window_pp
  attr_accessor :pp_restore_type
  attr_accessor :pp_restore_value
  attr_accessor :pp_restore_target
  attr_accessor :pp_restore_id
  attr_accessor :pp_restore_skill
  attr_accessor :pp_restore_mp
  attr_accessor :pp_restore_tp
  attr_accessor :pp_restore_gold
  attr_accessor :pp_restore_item
  attr_accessor :pp_restore_caster
  
  alias start_adik_pp_restore start
  def start
    start_adik_pp_restore
    @pp_restore_type = 0
    @pp_restore_value = 0
    @pp_restore_target = []
    @pp_restore_id = []
    @pp_restore_skill = ""
  end
  
  def is_restore_pp(actor,type,value,mp,tp,gold,item,caster)
	  @skill_select_window_pp = Window_SkillSelect.new(ADIK::SKILL_SELECT_PP::X, ADIK::SKILL_SELECT_PP::Y, ADIK::SKILL_SELECT_PP::WIDTH, ADIK::SKILL_SELECT_PP::HEIGHT)
    @view = Viewport.new
    @view.z = 400
    @skill_select_window_pp.viewport = @view
    @skill_select_window_pp.actor = actor
	  @skill_select_window_pp.activate
	  @skill_select_window_pp.show
	  @skill_select_window_pp.set_handler(:ok,     method(:on_skill_select_ok))
    @skill_select_window_pp.set_handler(:cancel,     method(:on_skill_select_cancel_p))
	  @pp_restore_type = type
	  @pp_restore_value = value
    if SceneManager.scene_is?(Scene_Item) or SceneManager.scene_is?(Scene_Skill)
	    @actor_window.deactivate
	  end
    @pp_restore_caster = caster
    @pp_restore_mp = mp
    @pp_restore_tp = tp
    @pp_restore_gold = gold
    @pp_restore_item = item
    @skill_select_window_pp.select_last
  end
  
  def on_skill_select_ok
	  skill_id = @skill_select_window_pp.item.id
	  actor = @skill_select_window_pp.actor
	  case @pp_restore_type
	    when "add"
	      actor.add_current_pp(skill_id,@pp_restore_value)
	    when "mul"
	      actor.mul_current_pp(skill_id,@pp_restore_value)
	    when "set"
	      actor.set_pp(skill_id,@pp_restore_value,actor.pp_max(skill_id))
	    when "add_max"
	      actor.add_max_pp(skill_id,@pp_restore_value)
	    when "mul_max"
	      actor.mul_max_pp(skill_id,@pp_restore_value)
	    when "set_max"
	      actor.set_pp(skill_id,actor.pp(skill_id),@pp_restore_value)
	    when "add_both"
	      actor.add_current_pp(skill_id,@pp_restore_value)
	      actor.add_max_pp(skill_id,@pp_restore_value)
	    when "mul_both"
	      actor.mul_current_pp(skill_id,@pp_restore_value)
	      actor.mul_max_pp(skill_id,@pp_restore_value)
	    when "set_both"
	      actor.set_pp(skill_id,@pp_restore_value,@pp_restore_value)
      when "restore"
        actor.reset_pp(skill_id)
	  end
	  on_skill_select_cancel
  end
  
  def on_skill_select_cancel_p
    on_skill_select_cancel(true)
  end
  
  def on_skill_select_cancel(cancelled=false)
    if cancelled
      @pp_restore_caster.mp += @pp_restore_mp
      @pp_restore_caster.tp += @pp_restore_tp
      $game_party.gain_gold(@pp_restore_gold)
      begin
        $game_party.gain_item(@pp_restore_item,1,false)
      rescue
      end
    end
	  @skill_select_window_pp.hide
	  @skill_select_window_pp.deactivate
	  @skill_select_window_pp.dispose
	  @skill_select_window_pp = nil
    @actor_window.hide
	  if SceneManager.scene_is?(Scene_Item) or SceneManager.scene_is?(Scene_Skill)
      skill = SceneManager.scene_is?(Scene_Skill)
      SceneManager.return
      skill ? SceneManager.call(Scene_Skill) : SceneManager.call(Scene_Item)
	  end
    @view.dispose
  end
  
end

class Scene_Battle
  
  attr_accessor :restore_pp
  
  alias start_adik_pp start
  def start
    start_adik_pp
    @restore_pp = false
  end
  
  alias on_skill_ok_adik_pp_restore on_skill_ok
  def on_skill_ok
    x = @skill_window.item.damage.formula.to_s
    if x.include?("is_restore_pp")
      on_is_restore_pp(@skill_window.item,:skill)
    else
      on_skill_ok_adik_pp_restore
    end
  end
  
  alias on_item_ok_adik_pp_restore on_item_ok
  def on_item_ok
    x = @item_window.item.damage.formula.to_s
    if x.include?("is_restore_pp")
      on_is_restore_pp(@item_window.item,:item)
    else
      on_item_ok_adik_pp_restore 
    end
  end
  
  alias on_actor_ok_adik_pp_restore on_actor_ok
  def on_actor_ok
    if @restore_pp
      BattleManager.actor.input.target_index = @actor_window.index
      @pp_restore_target[BattleManager.actor.id] = $game_party.battle_members[BattleManager.actor.input.target_index]
      battle_select_restore(BattleManager.actor,BattleManager.actor.last_skill.object)
      @restore_pp = false
    else
      on_actor_ok_adik_pp_restore
    end
  end
  
  def on_is_restore_pp(itemx,type)
    BattleManager.actor.input.set_skill(itemx.id) if type == :skill
    BattleManager.actor.last_skill.object = itemx if type == :skill
    BattleManager.actor.input.set_item(itemx.id) if type == :item
    @restore_pp = true
    if !itemx.need_selection?
      @skill_window.hide if type == :skill
      @item_window.hide if type == :item
      next_command
    elsif itemx.for_opponent?
      select_enemy_selection
    else
      select_actor_selection
    end
    $game_party.last_item.object = itemx if type == :item
  end
  
  def battle_select_restore(actor,item)
    @skill_select_window_pp = Window_SkillSelect.new(ADIK::SKILL_SELECT_PP::X, ADIK::SKILL_SELECT_PP::Y, ADIK::SKILL_SELECT_PP::WIDTH, ADIK::SKILL_SELECT_PP::HEIGHT)
    @view = Viewport.new
    @view.z = 400
    @skill_select_window_pp.viewport = @view
    @skill_select_window_pp.set_handler(:ok,     method(:on_restore_skill_select_ok))
    @skill_select_window_pp.set_handler(:cancel,     method(:on_restore_skill_select_cancel))
    @skill_select_window_pp.actor = @pp_restore_target[actor.id]
	  @skill_select_window_pp.activate
	  @skill_select_window_pp.show
    @skill_select_window_pp.select_last
  end
  
  def on_restore_skill_select_cancel
    @skill_select_window_pp.hide
	  @skill_select_window_pp.deactivate
    @skill_select_window_pp.dispose
	  @skill_select_window_pp = nil
    @view.dispose
    @actor_window.hide
    @skill_window.activate if @skill_window.visible
    @item_window.activate if @item_window.visible
  end
  
  def on_restore_skill_select_ok
    @pp_restore_id[@skill_select_window_pp.actor.id] = @skill_select_window_pp.item.id
    @skill_select_window_pp.hide
	  @skill_select_window_pp.deactivate
	  @skill_select_window_pp.dispose
	  @skill_select_window_pp = nil
    @actor_window.hide
    @skill_window.hide
    @item_window.hide
    @view.dispose
    next_command  
  end
  
  def on_skill_restore_finish(id,type,value)
    actor = @pp_restore_target[id]
    skill_id = @pp_restore_id[id]
    @pp_restore_skill = $data_skills[skill_id].name
	  case type
	    when "add"
	      actor.add_current_pp(skill_id,value)
	    when "mul"
	      actor.mul_current_pp(skill_id,value)
	    when "set"
	      actor.set_pp(skill_id,value,actor.pp_max(skill_id))
	    when "add_max"
	      actor.add_max_pp(skill_id,value)
	    when "mul_max"
	      actor.mul_max_pp(skill_id,value)
	    when "set_max"
	      actor.set_pp(skill_id,actor.pp(skill_id),value)
	    when "add_both"
	      actor.add_current_pp(skill_id,value)
	      actor.add_max_pp(skill_id,value)
	    when "mul_both"
	      actor.mul_current_pp(skill_id,value)
	      actor.mul_max_pp(skill_id,value)
	    when "set_both"
	      actor.set_pp(skill_id,value,value)
      when "restore"
        actor.reset_pp(skill_id)
	  end
  end
  
end

class Game_Actor
  
  def is_restore_pp(caster,type,value,gold=0,skill=0,item=0)
    mp = 0
    tp = 0
    items = nil
    if SceneManager.scene_is?(Scene_Battle)
      SceneManager.scene.on_skill_restore_finish(caster.id,type,value)
    else
      if skill != 0
        sk = $data_skills[skill] if skill != 0 
        mp = sk.mp_cost
        tp = sk.tp_cost
      elsif item != 0
        items = $data_items[item] if item != 0
      end
      SceneManager.scene.is_restore_pp(self,type,value,mp,tp,gold,items,caster)
    end
    return 0
  end
  
end

class Game_Battler
  alias item_test_adik_pp_restore item_test
  def item_test(user, item)
    return true if item.damage.formula.to_s.include?("is_restore_pp")
    return item_test_adik_pp_restore(user, item)
  end
end

class Window_BattleLog
  alias display_damage_restore_pp display_damage
  def display_damage(target, item)
    if item.damage.formula.to_s.include?("is_restore_pp")
        return unless ADIK::SKILL_SELECT_PP::SHOW_MESSAGE
        add_text(target.name + "'s " + SceneManager.scene.pp_restore_skill + "'s PP has been restored!")
        wait
    else
      display_damage_restore_pp(target, item)
    end
  end
end

class Scene_Map
  alias update_restore_pp update
  def update
    if @skill_select_window_pp.nil?
      update_restore_pp
    else
      super
    end
  end

end