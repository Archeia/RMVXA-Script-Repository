=begin
 ==============================================================================

 Equip Extension v1.10
 by AdiktuzMiko
 --- Date Created: 03/05/2014
 --- Last Date Updated: 03/06/2014
 --- Level: Easy

 ==============================================================================
 Overview
 ==============================================================================

 This script provides the ability to run RGSS3 methods/formulas during the
 equip and unequip of weapons/armors
 
 These can be used for: 
 
 actors/classes/weapons/armors
 
 Actors - affects all equip/unequip by the actor
 Classes - affects all equip/unequip by the actor that uses that class
 Weapons/Armors - affects all actors that equips/unequips the item
 
 ==============================================================================
 Set-Up
 ==============================================================================
 
 Just put this script into a blank slot above main but below materials
 (see compatibility section) and start tagging and making your own formulas
 
 ==============================================================================
 Method flow
 ==============================================================================

 This is the normal flow of the custom methods based on the default set-up
 
 Item Unequip
 Actor Unequip
 Class Unequip
 Item Equip
 Actor Equip
 Class Equip
 
 ==============================================================================
 Tags
 ==============================================================================
 
 -------------------------------------------------------------------
 For equip
 -------------------------------------------------------------------
 <start_equip_ext>
   formula
 <end_equip_ext>
 
 -------------------------------------------------------------------
 For unequip
 -------------------------------------------------------------------
 <start_unequip_ext>
   formula
 <end_unequip_ext>

 Use self to denote the actor that equips/unequips
 
 ==============================================================================
 Compatibility
 ==============================================================================

 This script aliases Game_Actor's change_equip and setup methods
 So put it below any script that overwrites those
 
 ==============================================================================
 Terms and Conditions
 ==============================================================================

 View it here: http://lescripts.wordpress.com/terms-and-conditions/
 
 ==============================================================================
=end

# ==============================================================================
# DO NOT EDIT BELOW THIS LINE
# ==============================================================================

module ADIK
  module EQUIP_EXTENSION
    EQUIP = /<start_equip_ext>(.*)<end_equip_ext>/m
    UNEQUIP = /<start_unequip_ext>(.*)<end_unequip_ext>/m
  end
end

class RPG::BaseItem

 def load_equip_extension_formula
    @equip_extension_formula = ""
    if self.note =~ ADIK::EQUIP_EXTENSION::EQUIP
      @equip_extension_formula = $1.to_s
    end
    return @equip_extension_formula 
  end
  
  def equip_extension_formula
    return @equip_extension_formula.nil? ? load_equip_extension_formula : @equip_extension_formula 
  end
  
  def load_unequip_extension_formula
    @unequip_extension_formula = ""
    if self.note =~ ADIK::EQUIP_EXTENSION::UNEQUIP
      @unequip_extension_formula = $1.to_s
    end
    return @unequip_extension_formula 
  end
  
  def unequip_extension_formula
    return @unequip_extension_formula.nil? ? load_unequip_extension_formula : @unequip_extension_formula 
  end
  
end

class Game_Actor
  
  alias change_equip_extension change_equip
  def change_equip(slot_id, item)
    unless equips[slot_id].nil?
      eval(equips[slot_id].unequip_extension_formula)
	    eval(self.actor.unequip_extension_formula)
      eval(self.class.unequip_extension_formula)
    end
    change_equip_extension(slot_id, item)
    unless item.nil?
      eval(item.equip_extension_formula)
      eval(self.actor.equip_extension_formula)
      eval(self.class.equip_extension_formula)	  
    end
  end
  
  alias setup_adik_extension setup
  def setup(actor_id)
    setup_adik_extension(actor_id)
    actor.equips.each_with_index do |item_id, i|
      etype_id = index_to_etype_id(i)
      item = etype_id == 0 ? $data_weapons[item_id] : $data_armors[item_id]
      unless item.nil?
        eval(item.equip_extension_formula)
        eval(self.actor.equip_extension_formula)
        eval(self.class.equip_extension_formula)	  
      end
    end
    refresh
  end
  
end