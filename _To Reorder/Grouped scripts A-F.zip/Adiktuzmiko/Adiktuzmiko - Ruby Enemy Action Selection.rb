=begin
======================================================
  
  Ruby Enemy Action Selection v1.01
  by Adiktuzmiko                   
  
  Date Created: 04/11/2014
  Date Last Updated: 04/11/2014
  Requires: N/A
  Difficulty: Easy
  
======================================================
 Overview
======================================================
 
 Allows you to use full RGSS3 formulas for determining
 which action an enemy will use.
 
======================================================
 Usage
====================================================== 

 Put this script into your scripts editor, probably
 below any other script that might modify Game_Enemy. 
 Next thing to do is to tag your enemies. Un-tagged 
 enemies will use the default method for selecting
 actions.
 
 <ruby_actions>
 formula
 <end_ruby_actions>
 
 Formula can be any valid RGSS3 formula. Accepts
 multiple lines
 
 example:
 
 Use skill 4 if HP is > 50, else use skill 10
 
 <ruby_actions>
   if self.hp > 50
     return 4
   else
    return 10
   end 
 <end_ruby_actions>

 It is important that all situations will return a valid 
 skill ID.
 
======================================================
 Compatibility
======================================================

 Aliases Game_Enemy's make_actions method
 
======================================================
 Terms and Conditions
======================================================

 View it here: http://lescripts.wordpress.com/terms-and-conditions/

======================================================
=end

#======================================================
#  Do not edit below this line
#======================================================


module ADIK
  module ENEMY_ACTION
    TAG = /<ruby_actions>(.*)<end_ruby_actions>/im
  end
end

class Game_Action
  
  def set_enemy_action_ruby(id)
    set_skill(id)
  end
  
end

class Game_Enemy
  
  def action_ruby_adik
    return true if @adik_ruby_action
    if self.enemy.note =~ ADIK::ENEMY_ACTION::TAG
      @adik_ruby_action = $1
      return true
    end
    return nil
  end
  
  alias make_actions_ruby_adik make_actions
  def make_actions
    if action_ruby_adik.nil?
      make_actions_ruby_adik
    else
      super
      return if @actions.empty?
      @actions.each do |action|
        action.set_enemy_action_ruby(action_selection_ruby)
      end
    end
  end
  
  def action_selection_ruby
    return eval(@adik_ruby_action)
    return 1
  end
  
end