=begin
 ==============================================================================

 Custom Equip Conditions v1.01
 by AdiktuzMiko
 --- Date Created: 08/29/2014
 --- Last Date Updated: 09/03/2014
 --- Level: Easy

 ==============================================================================
 Overview
 ==============================================================================

 This script provides the ability to use RGSS3 methods/formulas as custom
 requirements for equipping an item. Use it with the default RGSS3 scripts
 or couple it with custom scripts (like custom stat systems) for more
 custom requirement possibilities.
 
 The actor must be able to equip the item under normal conditions (equip types) 
 before the custom requirement is even checked.
 
 ==============================================================================
 Set-Up
 ==============================================================================
 
 Just put this script into a blank slot above main but below materials
 (see compatibility section) and start tagging and making your own formulas
 
 ==============================================================================
 Tags
 ==============================================================================

 <start_custom_req>
   formula
 <end_custom_req>
 
 Use the variable "actor" to denote the actor being checked
 
 Example: The item is only equippable if the actor's level is greater
 than 5
 
 <start_custom_req>
   actor.level > 5
 <end_custom_req>

 ==============================================================================
 Compatibility
 ==============================================================================

 This script aliases Game_Battler's equippable? method
 
 ==============================================================================
 Terms and Conditions
 ==============================================================================

 View it here: http://lescripts.wordpress.com/terms-and-conditions/
 
 ==============================================================================
=end

module ADIK
  module CUSTOM_EQUIP_REQUIREMENTS
    #the tag to use for setting custom requirements
    #modify if needed (i.e. conflict with another script)
    TAG = /<start_custom_req>(.*)<end_custom_req>/m
  end
end

# ==============================================================================
# DO NOT EDIT BELOW THIS LINE
# ==============================================================================

class RPG::BaseItem
  
  #attribute for the custom equip requirement
  attr_reader :custom_equip_requirement
  
  #reads the requirements if the item has the tag on the database
  def get_custom_equip_requirement
    @custom_equip_requirement = ""
    if self.note =~ ADIK::CUSTOM_EQUIP_REQUIREMENTS::TAG
      @custom_equip_requirement = $1.to_s
    end
  end
  
  #processes any custom requirement to determine 
  #if the item is equippable
  def custom_requirement_process(actor)
    #sets the data if it doesn't exist
    get_custom_equip_requirement if @custom_equip_requirement.nil?
    #if there is no custom requirement, then all's good to go
    return true if @custom_equip_requirement == ""
    #evaluates the custom requirement
    return eval(@custom_equip_requirement)
  end
  
end

class Game_BattlerBase
  
  #Checks first if the item is equippable by normal settings
  alias equippable_adik? equippable?
  def equippable?(item)
    return false unless equippable_adik?(item) 
    return item.custom_requirement_process(self)
  end
  
end