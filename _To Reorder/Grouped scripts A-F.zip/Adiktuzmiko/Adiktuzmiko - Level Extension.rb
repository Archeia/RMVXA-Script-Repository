=begin
 ==============================================================================

 Level Extension v1.10
 by AdiktuzMiko
 --- Date Created: 03/06/2014
 --- Last Date Updated: 03/08/2014
 --- Level: Easy

 ==============================================================================
 Overview
 ==============================================================================

 This script provides the ability to run RGSS3 methods/formulas during the
 level up and down
 
 These can be used for: 
 
 global/actors/classes/weapons/armors/states
 
 Global - affects all level up/downs
 Actors - affects all level up/down by the actor
 Classes - affects all level up/down by the class
 Weapons/Armors - affects all level up/down by the actor that is
                  equipped with the item
 States - affects all level up/down by the actor who has the state
 
 ==============================================================================
 Set-Up
 ==============================================================================
 
 Just put this script into a blank slot above main but below materials
 (see compatibility section) and start tagging and making your own formulas
 
 ==============================================================================
 Method flow
 ==============================================================================

 This is the normal flow of the custom methods based on the default set-up
 
 global
 Actor
 Class
 Equips
 State
 
 ==============================================================================
 Tags
 ==============================================================================
 
 -------------------------------------------------------------------
 For level up
 -------------------------------------------------------------------
 <start_level_ext>
   formula
 <end_level_ext>
 
 -------------------------------------------------------------------
 For level down
 -------------------------------------------------------------------
 <start_unlevel_ext>
   formula
 <end_unlevel_ext>

 Use self to denote the actor that is leveled
 
 As for the global, go to the module below and edit the method
 
 ==============================================================================
 Compatibility
 ==============================================================================

 This script aliases Game_Actor's level_up and level_down methods
 So put it below any script that overwrites those
 
 ==============================================================================
 Terms and Conditions
 ==============================================================================

 View it here: http://lescripts.wordpress.com/terms-and-conditions/
 
 ==============================================================================
=end

module ADIK
  module LEVEL_EXTENSION
    
    #Edit this one for global level extension
    
    def self.global_level(actor)
      actor.hp = actor.mhp
      actor.mp = actor.mmp
    end
    
    #Edit this one for global unlevel extension
    def self.global_unlevel(actor)
    end
    
    # ==============================================================================
    # DO NOT EDIT BELOW THIS LINE
    # ==============================================================================

    LEVEL = /<start_level_ext>(.*)<end_level_ext>/m
    UNLEVEL = /<start_unlevel_ext>(.*)<end_unlevel_ext>/m
  end
end

class RPG::BaseItem

 def load_level_extension_formula
    @level_extension_formula = ""
    if self.note =~ ADIK::LEVEL_EXTENSION::LEVEL
      @level_extension_formula = $1.to_s
    end
    return @level_extension_formula 
  end
  
  def level_extension_formula
    return @level_extension_formula.nil? ? load_level_extension_formula : @level_extension_formula 
  end
  
  def load_unlevel_extension_formula
    @unlevel_extension_formula = ""
    if self.note =~ ADIK::LEVEL_EXTENSION::UNLEVEL
      @unlevel_extension_formula = $1.to_s
    end
    return @unlevel_extension_formula 
  end
  
  def unlevel_extension_formula
    return @unlevel_extension_formula.nil? ? load_unlevel_extension_formula : @unlevel_extension_formula 
  end
  
end


class Game_Actor
 
  alias level_up_extension level_up
  def level_up
    level_up_extension
    ADIK::LEVEL_EXTENSION.global_level(self)
    eval(self.actor.level_extension_formula)
    eval(self.class.level_extension_formula)
    self.equips.each do |equip|
      next if equip.nil?
      eval(equip.level_extension_formula)
    end
    self.states.each do |state|
      next if state.nil?
      eval(state.level_extension_formula)
    end
  end
  
  alias level_down_extension level_down
  def level_down
    level_down_extension
    ADIK::LEVEL_EXTENSION.global_unlevel(self)
    eval(self.actor.unlevel_extension_formula)
    eval(self.class.unlevel_extension_formula)
    self.equips.each do |equip|
      next if equip.nil?
      eval(equip.unlevel_extension_formula)
    end
	  self.states.each do |state|
      next if state.nil?
      eval(state.unlevel_extension_formula)
    end
  end
  
end