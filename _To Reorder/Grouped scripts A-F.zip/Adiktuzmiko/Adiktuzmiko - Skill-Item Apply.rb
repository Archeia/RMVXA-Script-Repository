=begin
 ==============================================================================

 Skill/Item Apply Extension v1.00
 by AdiktuzMiko
 --- Date Created: 03/05/2014
 --- Last Date Updated: 03/05/2014
 --- Level: Easy

 ==============================================================================
 Overview
 ==============================================================================

 This script provides the ability to run RGSS3 methods/formulas during the
 different stages of effect application for items/skills. There are tags for
 both skill/item user and target.
 
 These can be used for: 
 
 actors/classes/items/weapons/armors/skills/states/enemies
 
 Actors - affects all skills/items used by/to the actor
 Classes - affects all skills/items used by/to the actor that uses that class
 Items - affects all usage of that item
 Weapons/Armors - affects all skills/items used by/to the actor that has the
                  weapon/armor
 Skills - affects all usage of that skill
 States - affects all skills/items used by/to the battler that has the state
 Enemies - affects all skills/items used by/to the enemy
 
 ==============================================================================
 Set-Up
 ==============================================================================
 
 Just put this script into a blank slot above main but below materials
 (see compatibility section) and start tagging and making your own formulas
 
 ==============================================================================
 Method flow
 ==============================================================================

 This is the normal flow of the custom methods based on the default set-up of
 the battle flow:
 
 Pre-Apply
 Pre-Damage
 After-Damage
 Miss
 Evade
 After-Apply
 
 ==============================================================================
 Tags
 ==============================================================================
 
 User Tags: This tags are for methods when you use a skill/item
 
 -------------------------------------------------------------------
 For before the item/skill is applied
 -------------------------------------------------------------------
 <start_papply_ext>
   formula
 <end_papply_ext>
 
 -------------------------------------------------------------------
 For after the item/skill is applied
 -------------------------------------------------------------------
 <start_apply_ext>
   formula
 <end_apply_ext>
 
 -------------------------------------------------------------------
 For when the item/skill misses
 -------------------------------------------------------------------
 <start_miss_ext>
   formula
 <end_miss_ext>
 
 -------------------------------------------------------------------
 For when the item/skill is evaded
 -------------------------------------------------------------------
 <start_evade_ext>
   formula
 <end_evade_ext>
 
 -------------------------------------------------------------------
 For before the damage is calculated
 -------------------------------------------------------------------
 <start_pdamage_ext>
   formula
 <end_pdamage_ext>
 
 -------------------------------------------------------------------
 For after the damage is calculated
 -------------------------------------------------------------------
 <start_damage_ext>
   formula
 <end_damage_ext>
 
 -------------------------------------------------------------------
 
 Target Tags: This tags are for methods when you are the target of
              an item/skill
 
 -------------------------------------------------------------------
 For before the item/skill is applied
 -------------------------------------------------------------------
 <start_papplied_ext>
   formula
 <end_papplied_ext>
 
 -------------------------------------------------------------------
 For after the item/skill is applied
 -------------------------------------------------------------------
 <start_applied_ext>
   formula
 <end_applied_ext>
 
 -------------------------------------------------------------------
 For when the item/skill misses
 -------------------------------------------------------------------
 <start_missed_ext>
   formula
 <end_missed_ext>
 
 -------------------------------------------------------------------
 For when the item/skill is evaded
 -------------------------------------------------------------------
 <start_evaded_ext>
   formula
 <end_evaded_ext>
 
 -------------------------------------------------------------------
 For before the damage is calculated
 -------------------------------------------------------------------
 <start_pdamaged_ext>
   formula
 <end_pdamaged_ext>
 
 -------------------------------------------------------------------
 For after the damage is calculated
 -------------------------------------------------------------------
 <start_damaged_ext>
   formula
 <end_damaged_ext>
 
 -------------------------------------------------------------------
 
 Some variables you can use:
 a = user
 b = target
 item = item/skill used

 ==============================================================================
 Compatibility
 ==============================================================================

 This script aliases Game_Battler's item_apply and make_damage_value methods
 So put it below any script that overwrites those
 
 ==============================================================================
 Terms and Conditions
 ==============================================================================

 View it here: http://lescripts.wordpress.com/terms-and-conditions/
 
 ==============================================================================
=end

# ==============================================================================
# DO NOT EDIT BELOW THIS LINE
# ==============================================================================

module ADIK
  module DAMAGE_EXT
    APPLY_FORMULA = /<start_apply_ext>(.*)<end_apply_ext>/m
    PRE_APPLY_FORMULA = /<start_papply_ext>(.*)<end_papply_ext>/m
	  APPLIED_FORMULA = /<start_applied_ext>(.*)<end_applied_ext>/m
    PRE_APPLIED_FORMULA = /<start_papplied_ext>(.*)<end_papplied_ext>/m
    MISS_FORMULA = /<start_miss_ext>(.*)<end_miss_ext>/m
    EVADE_FORMULA = /<start_evade_ext>(.*)<end_evade_ext>/m
    MISSED_FORMULA = /<start_missed_ext>(.*)<end_missed_ext>/m
    EVADED_FORMULA = /<start_evaded_ext>(.*)<end_evaded_ext>/m
    EXTENSION_FORMULA = /<start_damage_ext>(.*)<end_damage_ext>/m
    PRE_EXTENSION_FORMULA = /<start_pdamage_ext>(.*)<end_pdamage_ext>/m
    HIT_EXTENSION_FORMULA = /<start_damaged_ext>(.*)<end_damaged_ext>/m
    PRE_HIT_EXTENSION_FORMULA = /<start_pdamaged_ext>(.*)<end_pdamaged_ext>/m
  end
end

class RPG::BaseItem
  
  def load_apply_extension_formula
    @apply_extension_formula = ""
    if self.note =~ ADIK::DAMAGE_EXT::APPLY_FORMULA
      @apply_extension_formula = $1.to_s
    end
    return @apply_extension_formula 
  end
  
  def load_pre_apply_extension_formula
    @pre_apply_extension_formula = ""
    if self.note =~ ADIK::DAMAGE_EXT::PRE_APPLY_FORMULA
      @pre_apply_extension_formula = $1.to_s
    end
    return @pre_apply_extension_formula 
  end
  
  def apply_extension_formula
    return @apply_extension_formula.nil? ? load_apply_extension_formula : @apply_extension_formula 
  end
  
  def pre_apply_extension_formula
    return @pre_apply_extension_formula.nil? ? load_pre_apply_extension_formula : @pre_apply_extension_formula 
  end
  
  def load_applied_extension_formula
    @applied_extension_formula = ""
    if self.note =~ ADIK::DAMAGE_EXT::APPLIED_FORMULA
      @applied_extension_formula = $1.to_s
    end
    return @applied_extension_formula 
  end
  
  def load_pre_applied_extension_formula
    @pre_applied_extension_formula = ""
    if self.note =~ ADIK::DAMAGE_EXT::PRE_APPLIED_FORMULA
      @pre_applied_extension_formula = $1.to_s
    end
    return @pre_applied_extension_formula 
  end
  
  def applied_extension_formula
    return @applied_extension_formula.nil? ? load_applied_extension_formula : @applied_extension_formula 
  end
  
  def pre_applied_extension_formula
    return @pre_applied_extension_formula.nil? ? load_pre_applied_extension_formula : @pre_applied_extension_formula 
  end
  
  def load_miss_extension_formula
    @miss_extension_formula = ""
    if self.note =~ ADIK::DAMAGE_EXT::MISS_FORMULA
      @miss_extension_formula = $1.to_s
    end
    return @miss_extension_formula 
  end
  
  def miss_extension_formula
    return @miss_extension_formula.nil? ?  load_miss_extension_formula : @miss_extension_formula 
  end
  
  def load_evade_extension_formula
    @evade_extension_formula = ""
    if self.note =~ ADIK::DAMAGE_EXT::EVADE_FORMULA
      @evade_extension_formula = $1.to_s
    end
    return @evade_extension_formula 
  end
  
  def evade_extension_formula
    return @evade_extension_formula.nil? ? load_evade_extension_formula : @evade_extension_formula 
  end
  
  def load_missed_extension_formula
    @missed_extension_formula = ""
    if self.note =~ ADIK::DAMAGE_EXT::MISSED_FORMULA
      @missed_extension_formula = $1.to_s
    end
    return @missed_extension_formula 
  end
  
  def missed_extension_formula
    return @missed_extension_formula.nil? ? load_missed_extension_formula : @missed_extension_formula 
  end
  
  def load_evaded_extension_formula
    @evaded_extension_formula = ""
    if self.note =~ ADIK::DAMAGE_EXT::EVADED_FORMULA
      @evaded_extension_formula = $1.to_s
    end
    return @evaded_extension_formula 
  end
  
  def evaded_extension_formula
    return @evaded_extension_formula.nil? ? load_evaded_extension_formula : @evaded_extension_formula 
  end
  
  def load_damage_extension_formula
    @damage_extension_formula = ""
    if self.note =~ ADIK::DAMAGE_EXT::EXTENSION_FORMULA
      @damage_extension_formula = $1.to_s
    end
    return @damage_extension_formula 
  end
  
  def load_pre_damage_extension_formula
    @pre_damage_extension_formula = ""
    if self.note =~ ADIK::DAMAGE_EXT::PRE_EXTENSION_FORMULA
      @pre_damage_extension_formula = $1.to_s
    end
    return @pre_damage_extension_formula 
  end
  
  def damage_extension_formula
    return @damage_extension_formula.nil? ? load_damage_extension_formula : @damage_extension_formula 
  end
  
  def pre_damage_extension_formula
    return @pre_damage_extension_formula.nil? ? load_pre_damage_extension_formula : @pre_damage_extension_formula 
  end
  
  def load_hit_extension_formula
    @hit_extension_formula = ""
    if self.note =~ ADIK::DAMAGE_EXT::HIT_EXTENSION_FORMULA
      @hit_extension_formula = $1.to_s
    end
    return @hit_extension_formula 
  end
  
  def load_pre_hit_extension_formula
    @pre_hit_extension_formula = ""
    if self.note =~ ADIK::DAMAGE_EXT::PRE_HIT_EXTENSION_FORMULA
      @pre_hit_extension_formula = $1.to_s
    end
    return @pre_hit_extension_formula 
  end
  
  def hit_extension_formula
    return @hit_extension_formula.nil? ? load_hit_extension_formula : @hit_extension_formula 
  end
  
  def pre_hit_extension_formula
    return @pre_hit_extension_formula.nil? ? load_pre_hit_extension_formula : @pre_hit_extension_formula 
  end
  
end

class Game_Battler

  alias make_damage_value_adik_new_partition make_damage_value
  def make_damage_value(user,item)
    pre_damage_extension_methods(user,item)
    make_damage_value_adik_new_partition(user,item)
    damage_extension_methods(user,item)
  end
  
  alias item_apply_adik_new_partition item_apply
  def item_apply(user,item)
    pre_apply_extension_methods(user,item)
    item_apply_adik_new_partition(user,item)
    miss_extension_methods(user,item) if @result.missed
    evade_extension_methods(user,item) if @result.evaded
    apply_extension_methods(user,item)
  end
  
  def miss_extension_methods(a,item,b=self)
    eval(item.miss_extension_formula)
    a.states.each do |state|
      next if state.nil?
      eval(state.miss_extension_formula)
    end
    if a.actor?
      eval(a.actor.miss_extension_formula)
      eval(a.class.miss_extension_formula)
      a.equips.each do |equip|
        next if equip.nil?
        eval(equip.miss_extension_formula)
      end
    else
      eval(a.enemy.miss_extension_formula)
    end
    b.states.each do |state|
      next if state.nil?
      eval(state.missed_extension_formula)
    end
    if b.actor?
      eval(b.actor.missed_extension_formula)
      eval(b.class.missed_extension_formula)
      b.equips.each do |equip|
        next if equip.nil?
        eval(equip.missed_extension_formula)
      end
    else
      eval(b.enemy.missed_extension_formula)
    end
  end
  
  def evade_extension_methods(a,item,b=self)
    eval(item.evade_extension_formula)
    a.states.each do |state|
      next if state.nil?
      eval(state.evade_extension_formula)
    end
    if a.actor?
      eval(a.actor.evade_extension_formula)
      eval(a.class.evade_extension_formula)
      a.equips.each do |equip|
        next if equip.nil?
        eval(equip.evade_extension_formula)
      end
    else
      eval(a.enemy.evade_extension_formula)
    end
    b.states.each do |state|
      next if state.nil?
      eval(state.evaded_extension_formula)
    end
    if b.actor?
      eval(b.actor.evaded_extension_formula)
      eval(b.class.evaded_extension_formula)
      b.equips.each do |equip|
        next if equip.nil?
        eval(equip.evaded_extension_formula)
      end
    else
      eval(b.enemy.evaded_extension_formula)
    end
  end
  
  def apply_extension_methods(a,item,b=self)
    eval(item.apply_extension_formula)
    a.states.each do |state|
      next if state.nil?
      eval(state.apply_extension_formula)
    end
    if a.actor?
      eval(a.actor.apply_extension_formula)
      eval(a.class.apply_extension_formula)
      a.equips.each do |equip|
        next if equip.nil?
        eval(equip.apply_extension_formula)
      end
    else
      eval(a.enemy.apply_extension_formula)
    end
    b.states.each do |state|
      next if state.nil?
      eval(state.applied_extension_formula)
    end
    if b.actor?
      eval(b.actor.applied_extension_formula)
      eval(b.class.applied_extension_formula)
      b.equips.each do |equip|
        next if equip.nil?
        eval(equip.applied_extension_formula)
      end
    else
      eval(b.enemy.applied_extension_formula)
    end
  end
  
  def pre_apply_extension_methods(a,item,b=self)
    eval(item.pre_apply_extension_formula)
    a.states.each do |state|
      next if state.nil?
      eval(state.pre_apply_extension_formula)
    end
    if a.actor?
      eval(a.actor.pre_apply_extension_formula)
      eval(a.class.pre_apply_extension_formula)
      a.equips.each do |equip|
        next if equip.nil?
        eval(equip.pre_apply_extension_formula)
      end
    else
      eval(a.enemy.pre_apply_extension_formula)
    end
    b.states.each do |state|
      next if state.nil?
      eval(state.pre_applied_extension_formula)
    end
    if b.actor?
      eval(b.actor.pre_applied_extension_formula)
      eval(b.class.pre_applied_extension_formula)
      b.equips.each do |equip|
        next if equip.nil?
        eval(equip.pre_applied_extension_formula)
      end
    else
      eval(b.enemy.pre_applied_extension_formula)
    end
  end
  
  def damage_extension_methods(a,item,b=self)
    eval(item.damage_extension_formula)
    a.states.each do |state|
      next if state.nil?
      eval(state.damage_extension_formula)
    end
    if a.actor?
      eval(a.actor.damage_extension_formula)
      eval(a.class.damage_extension_formula)
      a.equips.each do |equip|
        next if equip.nil?
        eval(equip.damage_extension_formula)
      end
    else
      eval(a.enemy.damage_extension_formula)
    end
    b.states.each do |state|
      next if state.nil?
      eval(state.hit_extension_formula)
    end
    if b.actor?
      eval(b.actor.hit_extension_formula)
      eval(b.class.hit_extension_formula)
      b.equips.each do |equip|
        next if equip.nil?
        eval(equip.hit_extension_formula)
      end
    else
      eval(b.enemy.hit_extension_formula)
    end
  end
  
  def pre_damage_extension_methods(a,item,b=self)
    eval(item.pre_damage_extension_formula)
    a.states.each do |state|
      next if state.nil?
      eval(state.pre_damage_extension_formula)
    end
    if a.actor?
      eval(a.actor.pre_damage_extension_formula)
      eval(a.class.pre_damage_extension_formula)
      a.equips.each do |equip|
        next if equip.nil?
        eval(equip.pre_damage_extension_formula)
      end
    else
      eval(a.enemy.pre_damage_extension_formula)
    end
    b.states.each do |state|
      next if state.nil?
      eval(state.pre_hit_extension_formula)
    end
    if b.actor?
      eval(b.actor.pre_hit_extension_formula)
      eval(b.class.pre_hit_extension_formula)
      b.equips.each do |equip|
        next if equip.nil?
        eval(equip.pre_hit_extension_formula)
      end
    else
      eval(b.enemy.pre_hit_extension_formula)
    end
  end
end