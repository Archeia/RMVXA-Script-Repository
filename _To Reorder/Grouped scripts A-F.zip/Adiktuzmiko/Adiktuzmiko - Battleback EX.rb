#==============================================================================
# 
# BattleBack_EX v1.0
# by AdiktuzMiko
# --- Date Created: 03/01/2013
# --- Last Date Updated: 03/01/2013
# --- Level: Easy
# Requires: n/a
# 
# Basically, this allows you to have different battlebacks in one map
# via regions.
#
#==============================================================================

#==============================================================================
# Aliased methods:
#
# battleback1_bitmap, battleback2_bitmap (both belongs to Spriteset_Battle)
#==============================================================================

#==============================================================================
# How To Install:
#
# Just put this anywhere before main and you're good to go.
#==============================================================================

#==============================================================================
# Compatibility:
#
# This script is made strictly for RPG Maker VX Ace. It is highly unlikely that
# it will run with RPG Maker VX without adjusting.
#
# As for compatibility with other scripts, it's compatible with YEA scripts. 
# I don't know for other scripts though. Though I don't think it would be
# incompatible with other scripts unless they overwrite the battleback creation
# at the start too.
#
#==============================================================================

#==============================================================================
# How To Use:
#
# Go to the module below and just insert lines for the maps that you need
# different battlebacks per region. Look at the example to know how to add
# new lines.
#
# Format:
#
# Map ID => {Region ID => [Battleback1,Battleback2],
#            Region ID => [Battleback1,Battleback2], And so on}
#
# If a map or region is not included in the module, it will use the battleback
# specified on the map data
#==============================================================================

module BattleBack_EX
  
  BATTLEBACKEX = {
  
  15 => {1 => ["Dirt1","Forest1"]},
  16 => {1 => ["Dirt1","Forest1"]},
  28 => {1 => ["Cobblestones1",""]},
  } #Do not remove
  
end #BattleBack_EX

#==============================================================================
# Do not touch anything below this line unless you know what you are doing.
#==============================================================================

class Spriteset_Battle
  
  alias battleback1_bitmap_x battleback1_bitmap
  def battleback1_bitmap
    if $BTEST #without this it bugs during battle test
      battleback1_bitmap_x
    else
      BattleBack_EX::BATTLEBACKEX[$game_map.map_id] != nil ? bb = BattleBack_EX::BATTLEBACKEX[$game_map.map_id][$game_map.region_id($game_player.x,$game_player.y)] : nil
      if bb != nil
        Cache.battleback1(bb[0])
      elsif battleback1_name
        Cache.battleback1(battleback1_name)
      else
        create_blurry_background_bitmap
      end
    end
  end
  
  alias battleback2_bitmap_x battleback2_bitmap
  def battleback2_bitmap
    if $BTEST #without this it bugs during battle test
      battleback2_bitmap_x
    else
      BattleBack_EX::BATTLEBACKEX[$game_map.map_id] != nil ? bb = BattleBack_EX::BATTLEBACKEX[$game_map.map_id][$game_map.region_id($game_player.x,$game_player.y)] : nil
      if bb != nil
        Cache.battleback2(bb[1])
      elsif battleback2_name
        Cache.battleback2(battleback2_name)
      else
        create_blurry_background_bitmap
      end
    end
  end
  
end #Spriteset_Battle