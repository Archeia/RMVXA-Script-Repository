#==============================================================================
# 
# Extended Blue Magic v1.01
# by AdiktuzMiko
# --- Date Created: 05/22/2013
# --- Last Date Updated: 05/23/2013
# --- Level: Easy
# Requires: 
#         "Tag Manager" - by Tsukihime
#         http://himeworks.wordpress.com/2013/03/07/tag-manager/
#
# Based/Edited on Blue Magic Script by:
#     Mr. Bubble (http://mrbubblewand.wordpress.com/rgss3/blue-magic/)
#
# All I did was modify his script to enable multiple kinds of "blue" magic
# by utilizing the Tag Manager by Tsukihime
#
# For those who don't know what blue magic is, its a method of learning
# abilities from monsters that was introduced by Final Fantasy.
# When a monster with a blue magic hits a blue mage, he will learn that
# ability.
#
# Now, this script allows you to have more than one kind of "blue" magic
# which gives you better flexibility on your "blue" magic escapades.
#
# If you only need a single blue magic type for your game, I would suggest
# that you use the original version by Mr. Bubble
#
#==============================================================================
#   ++ Notetags ++
#==============================================================================
#
# Note tags will depend on the tags that you will set on the settings below
#
#==============================================================================
#   ++ Installation ++
#==============================================================================
# Install this script in the Materials section in your project's
# script editor.
#
# This script requires:
#
#     "Tag Manager" - by Tsukihime
#         http://himeworks.wordpress.com/2013/03/07/tag-manager/
#
#==============================================================================
#   ++ Compatibility ++
#==============================================================================
# This script aliases the following default VXA methods:
#
#     Game_ActionResult#clear
#     Game_Battler#item_apply
#     Scene_Battle#process_action_end
#     Scene_Battle#use_item
#    
# There are no default method overwrites.
#
# I don't know if this is compatible with the original Blue Magic script by Mr. Bubble
# but I don't see why you'll have them both in your game anyway
#
# Also, it doesn't seem to be compatible with the Yami Engine Ace - Charge Skill
# script.
#
#==============================================================================
#   ++ Terms and Conditions ++
#==============================================================================
#
# The terms and conditions to be used on this script will be the same
# as that of the original script for the moment.
#
#==============================================================================

$imported ||= {}
$imported["ExtendedBlueMagic"] = true

#==========================================================================
# ++ START OF USER CUSTOMIZATION MODULE ++
#==========================================================================

#==========================================================================
# ++ Adiktuz::Regexp
#==========================================================================
module Adiktuz
  module Regexp
    #register tags here
    #key => "tagname",
    
    #remember that since this utilizes TagManager
    #the actual tags that you put in the note boxes would be
    #<tag: tagname>
    
    #BLUE_MAGIC_SKILLS_TAG lists the tags that you will put on skills
    #that are to be specified as blue magic

    #BLUE_MAGIC_LEARNING_TAG lists the tags that you will put on
    #actors, classes, equipments and states that should be given the
    #blue mage property
    
    #If an actor is tagged as a blue mage, then he can learn the blue magic
    #skills of that type
    #If a class is tagged as a blue mage, then any actor of that class can 
    #learn the blue magic skills of that type
    #If an equipment is tagged as a blue mage, then any actor that equips it
    #can learn the blue magic skills of that type
    #If a state is tagged as a blue mage, then any actor who has that state
    #can learn the blue magic skills of that type
    
    #Example: If a skill tagged with <tag: oversoul> hits an actor tagged
    #         with <tag: oversoullearn>, then that actor will learn that
    #         skill

    #Remember also that multiple of these tags can be used on a single object
    
    #Example: Skill 1 can be both a dragonmagic and an oversoul
    #         Actor 2 can be both a blue mage and an oversoul user
    #         If skill 1 is used on Actor 2, he will learn that skill
    #         since it has the oversoul tag, and the actor has the oversoullearn tag
    #         Now if it hits for example Actor 3 that is only tagged as a bluemage
    #         then actor 3 won't learn the ability since that ability is not
    #         tagged as a blue magic   

    BLUE_MAGIC_SKILLS_TAG = 
    {
        1 => "bluemagic",
        2 => "dragonmagic",
        3 => "oversoul",
    }
    BLUE_MAGIC_LEARNING_TAG = 
    {
        1 => "bluemagiclearn",
        2 => "dragonmagiclearn",
        3 => "oversoullearn",
    }
    
  end # module Regexp
end # module Adiktuz

module Adiktuz
  #==========================================================================
  # ++ Blue Magic Settings
  #==========================================================================
  #
  # All of these settings are to be set per key that you have placed on the 
  # tags part above.
  #
  # Make sure that all keys have registered values, else it might throw an error
  #
  # Example: If I have a key (3) on any of the settings or the tags, then
  #          all settings and tags must also have an entry for the key (3)
  module BlueMagic
  #--------------------------------------------------------------------------
  #   Alternative Blue Magic Learning Methods
  #--------------------------------------------------------------------------
  # true  : Actors can learn Blue Magic regardless of who it hits.
  # false : Actors must be hit directly with Blue Magic to learn.
  LEARN_BY_SIGHT = 
  {
      1 => true,
      2 => false,
      3 => false,
  }
  # true  : Actors can learn Blue Magic cast by other actors.
  # false : Actors can only learn Blue Magic from enemies.
  LEARN_BY_ALLIES = 
  {
      1 => false,
      2 => false,
      3 => false,
  }

  #--------------------------------------------------------------------------
  #   Blue Magic Learned Battle Message
  #--------------------------------------------------------------------------
  # This defines the message displayed in battle when an actor learns an
  # Blue Magic skill.
  #
  # The first %s is automatically replaced by the actor's name.
  # The second %2 is automatically replaced by the skill's name.
  BLUE_MAGIC_LEARNED_MESSAGE = 
  {
     1 => "%s learned %s.",
     2 => "%s assimilated the dragon's %s.",
     3 => "%s learned %s.",
  }
  
  #--------------------------------------------------------------------------
  #   Blue Magic Learned Sound Effect
  #--------------------------------------------------------------------------
  # Sound effect played when the Blue Magic learned message is displayed.
  # Filename is a sound effect found in the Audio/SE/ folder.
  #
  #                        "filename", volume, pitch
  BLUE_MAGIC_LEARNED_SE = 
  {
     1 => [  "Chime2",     80,   100],
     2 => [  "Chime2",     80,   100],
     3 => [  "Chime2",     80,   100],
  }
  
  #--------------------------------------------------------------------------
  #   Blue Magic Message Wait
  #--------------------------------------------------------------------------
  # This setting determines how long the Blue Magic learned message is
  # displayed in battle. Higher values increase the wait time.
  BLUE_MAGIC_LEARNED_MESSAGE_WAIT = 
  {
      1 => 3,
      2 => 3,
      3 => 3,
  }

  end # module BlueMagic
end # module Adiktuz


#==========================================================================
# ++ END OF USER CUSTOMIZATION MODULE ++
#==========================================================================

#==========================================================================
# ++ DO NOT TOUCH ++
#==========================================================================

$Which = 0

#==============================================================================
# ++ Sound
#==============================================================================
module Sound
  #--------------------------------------------------------------------------
  # new method : play_blue_magic_learned
  #--------------------------------------------------------------------------
  def self.play_blue_magic_learned
    filename = Adiktuz::BlueMagic::BLUE_MAGIC_LEARNED_SE[$Which][0]
    volume = Adiktuz::BlueMagic::BLUE_MAGIC_LEARNED_SE[$Which][1]
    pitch = Adiktuz::BlueMagic::BLUE_MAGIC_LEARNED_SE[$Which][2]
    Audio.se_play("Audio/SE/" + filename, volume, pitch) 
  end
  
end # module Sound


#==============================================================================
# ++ Window_BattleLog
#==============================================================================
class Window_BattleLog < Window_Selectable
  #--------------------------------------------------------------------------
  # new method : display_learned_blue_magic
  #--------------------------------------------------------------------------
  def display_learned_blue_magic(actor)
    id = actor.result.blue_magic_skill_to_learn
    fmt = Adiktuz::BlueMagic::BLUE_MAGIC_LEARNED_MESSAGE[$Which]
    add_text( sprintf(fmt, actor.name, $data_skills[id].name) )
    Sound.play_blue_magic_learned
    Adiktuz::BlueMagic::BLUE_MAGIC_LEARNED_MESSAGE_WAIT[$Which].times do wait end
    wait_for_effect
  end
end


#==============================================================================
# ++ Game_ActionResult
#==============================================================================
class Game_ActionResult
  #--------------------------------------------------------------------------
  # public instance variables
  #--------------------------------------------------------------------------
  attr_accessor :blue_magic_skill_to_learn
  #--------------------------------------------------------------------------
  # alias : clear
  #--------------------------------------------------------------------------
  alias clear_Adiktuz_bluemagic clear
  def clear
    clear_Adiktuz_bluemagic # alias
    
    @blue_magic_skill_to_learn = 0
  end
end


#==============================================================================
# ++ Game_Battler
#==============================================================================
class Game_Battler < Game_BattlerBase
  #--------------------------------------------------------------------------
  # alias : item_apply
  #--------------------------------------------------------------------------
  alias item_apply_Adiktuz_bluemagic item_apply
  def item_apply(user, item)
    item_apply_Adiktuz_bluemagic(user, item) # alias
    
    if blue_magic_learning_ok?(user, item)
      @result.blue_magic_skill_to_learn = item.id
    end
  end
  
  #--------------------------------------------------------------------------
  # new method : blue_magic_learning_ok?
  #--------------------------------------------------------------------------
  #This is done so that each ability and actor can have multiple
  #bluemagic types and so that it will correctly process if any of those
  #combinations are present
  def blue_magic_learning_ok?(user, item)
    if @result.hit? then
      Adiktuz::Regexp::BLUE_MAGIC_LEARNING_TAG.each_pair do |index,value|
         return true if blue_magic_learning?(index,value) && item.object_tags.include?(Adiktuz::Regexp::BLUE_MAGIC_SKILLS_TAG[index]) && blue_magic_learn_by_allies?(user)
      end
    end
    return false
  end 
  
  #--------------------------------------------------------------------------
  # new method : blue_magic_learning?
  #--------------------------------------------------------------------------
  def blue_magic_learning?(index,value)
    if actor?
        $Which = index
      	return true if self.actor.object_tags.include?(value)
      	return true if self.class.object_tags.include?(value)
      	for equip in equips
       	 next if equip.nil?
       	 return true if equip.object_tags.include?(value)
      	end
     	  for state in states
       	 next if state.nil?
         return true if state.object_tags.include?(value)
      	end
    end
    return false
  end # def blue_magic_learning?
  
  #--------------------------------------------------------------------------
  # new method : blue_magic_learn_by_allies?
  #--------------------------------------------------------------------------
  def blue_magic_learn_by_allies?(user)
    if user.actor?
      return Adiktuz::BlueMagic::LEARN_BY_ALLIES[$which]
    else
      return true
    end
  end # def

end # class Game_Battler


#==============================================================================
# ++ Game_Actor
#==============================================================================
class Game_Actor < Game_Battler
  
  #--------------------------------------------------------------------------
  # new method : new_blue_magic_skill_learned?
  #--------------------------------------------------------------------------
  def new_blue_magic_skill_learned?
    skill_id = @result.blue_magic_skill_to_learn
    return false unless skill_id > 0
    return false if skill_learn?($data_skills[skill_id])
    learn_skill(skill_id)
    return true
  end
  
  #--------------------------------------------------------------------------
  # new method : blue_magic_skills
  #--------------------------------------------------------------------------
  # returns an array of Blue Magic skill ids learned by the battler
  def blue_magic_skills
    Adiktuz::Regexp::BLUE_MAGIC_SKILLS_TAG.each_value do |value|
        @skills.select { |id| $data_skills[id].object_tags.include?(value) }
    end
  end
  
  #--------------------------------------------------------------------------
  # new method : learnable_blue_magic_from_target
  #--------------------------------------------------------------------------
  def learnable_blue_magic_from_target(target)
    target.blue_magic_skills.select { |id| !@skills.include?(id) }
  end

end # class Game_Actor


#==============================================================================
# ++ Game_Enemy
#==============================================================================
class Game_Enemy < Game_Battler
  #--------------------------------------------------------------------------
  # new method : blue_magic_skills
  #--------------------------------------------------------------------------
  # returns an array of Blue Magic skill ids learned by the battler
  def blue_magic_skills
    skill_ids = enemy.actions.collect { |action| action.skill_id }
    Adiktuz::Regexp::BLUE_MAGIC_SKILLS_TAG.each_key do |index|
        skill_ids.uniq!.select! { |id| $data_skills[id].object_tags.include?(Adiktuz::Regexp::BLUE_MAGIC_SKILLS_TAG[index]) }
    end
  end

end # class Game_Enemy


#==============================================================================
# ++ Scene_Battle
#==============================================================================
class Scene_Battle < Scene_Base
  #--------------------------------------------------------------------------
  # alias : process_action_end
  #--------------------------------------------------------------------------
  # Checks all Blue Magic learn flags and displays message if found
  alias process_action_end_Adiktuz_bluemagic process_action_end
  def process_action_end
    $game_party.members.each do |actor|
      if actor.new_blue_magic_skill_learned?
        @log_window.display_learned_blue_magic(actor)
        @log_window.clear
      end
    end
    process_action_end_Adiktuz_bluemagic # alias
  end
  
  #--------------------------------------------------------------------------
  # alias : use_item
  #--------------------------------------------------------------------------
  alias use_item_Adiktuz_bluemagic use_item
  def use_item
    use_item_Adiktuz_bluemagic # alias
        
    item = @subject.current_action.item 
    determine_blue_magic_learn_by_sight(@subject, item)
  end # def
  
  #--------------------------------------------------------------------------
  # new method : determine_blue_magic_learn_by_sight
  #--------------------------------------------------------------------------
  def determine_blue_magic_learn_by_sight(subject, item)
    return unless subject
    all_battle_members.each do |member|
      if member.result.hit?
        set_blue_magic_skill_to_learn_flags(item)
        break
      end # if
    end # do
  end # def
    
  #--------------------------------------------------------------------------
  # new method : can_actor_learn?
  #--------------------------------------------------------------------------
  def can_actor_learn?(actor,item)
    Adiktuz::Regexp::BLUE_MAGIC_LEARNING_TAG.each_pair do |index,value|
        return true if actor.blue_magic_learning?(index,value) && item.object_tags.include?(Adiktuz::Regexp::BLUE_MAGIC_SKILLS_TAG[index])
    end
    return false
  end 
  
  #--------------------------------------------------------------------------
  # new method : set_blue_magic_skill_to_learn_flags
  #--------------------------------------------------------------------------
  def set_blue_magic_skill_to_learn_flags(item)
    $game_party.members.each do |actor|
      if can_actor_learn?(actor,item)
        if Adiktuz::BlueMagic::LEARN_BY_SIGHT[$Which] && blue_magic_learn_by_allies?(subject) then
            actor.result.blue_magic_skill_to_learn = item.id
        end
      end # if
    end # do
  end # def
    
  #--------------------------------------------------------------------------
  # new method : blue_magic_learn_by_allies?
  #--------------------------------------------------------------------------
  def blue_magic_learn_by_allies?(subject)
    if subject.actor?
      return Adiktuz::BlueMagic::LEARN_BY_ALLIES[$Which]
    else
      return true
    end
  end # def
  
end # class Scene_Battle