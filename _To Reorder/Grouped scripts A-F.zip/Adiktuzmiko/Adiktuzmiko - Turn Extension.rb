=begin
 ==============================================================================

 Turn Extension v1.00
 by AdiktuzMiko
 --- Date Created: 10/18/2014
 --- Last Date Updated: 10/18/2014
 --- Level: Easy

 ==============================================================================
 Overview
 ==============================================================================

 This script provides the ability to run RGSS3 methods/formulas during the
 start and end of turns.
 
 These can be used for: 
 
 actors/classes/weapons/armors/states/enemies
 
 Global - always affects turn start and end
 Actors - affects all turn start and end when the actor is present in battle
 Classes - affects all turn start and end when the class is present in battle
 Weapons/Armors - affects all turn start and end when the weapon/armor
                  is equipped by any actor in battle
 Enemies - affects all turn start and end when the enemy is present in battle
 States - affects all turn start and end when the state is present in battle
 
 ==============================================================================
 Set-Up
 ==============================================================================
 
 Just put this script into a blank slot above main but below materials
 (see compatibility section) and start tagging and making your own formulas
 
 ==============================================================================
 Method flow
 ==============================================================================

 This is the normal flow of the custom methods based on the default set-up
 
 Global
 Actor
 Class
 Equips
 Actor States
 Enemies
 Enemy States
 
 ==============================================================================
 Tags
 ==============================================================================
 
 -------------------------------------------------------------------
 For turn_start
 -------------------------------------------------------------------
 <start_turn_start_ext>
   formula
 <end_turn_start_ext>
 
 -------------------------------------------------------------------
 For turn end
 -------------------------------------------------------------------
 <start_turn_end_ext>
   formula
 <end_turn_end_ext>

 Use battler to denote the battler, equip to denote the equipment,
 state to denote the state
 
 ==============================================================================
 Compatibility
 ==============================================================================

 This script aliases Scene_Battle's turn start and turn end methods
 
 ==============================================================================
 Terms and Conditions
 ==============================================================================

 View it here: http://lescripts.wordpress.com/terms-and-conditions/
 
 ==============================================================================
=end


module ADIK
  module TURN_EXTENSION

# ==============================================================================
# Edit these two for global turn start and turn end methods
# ==============================================================================
    
    def self.global_turn_start
    end
    
    def self.global_turn_end
    end

# ==============================================================================
# DO NOT EDIT BELOW THIS LINE
# ==============================================================================

    
    TURN_START = /<start_turn_start_ext>(.*)<end_turn_start_ext>/m
    TURN_END = /<start_turn_end_ext>(.*)<end_turn_end_ext>/m
  end
end

class RPG::BaseItem

 def load_turn_extension_formula
    @turn_extension_formula = ""
    if self.note =~ ADIK::TURN_EXTENSION::TURN_START
      @turn_extension_formula = $1.to_s
    end
    return @turn_extension_formula 
  end
  
  def turn_extension_formula
    return @turn_extension_formula.nil? ? load_turn_extension_formula : @turn_extension_formula 
  end
  
  def load_turn_end_extension_formula
    @turn_end_extension_formula = ""
    if self.note =~ ADIK::TURN_EXTENSION::TURN_END
      @turn_end_extension_formula = $1.to_s
    end
    return @turn_end_extension_formula 
  end
  
  def turn_end_extension_formula
    return @turn_end_extension_formula.nil? ? load_turn_end_extension_formula : @turn_end_extension_formula 
  end
  
end

class Scene_Battle
  
  alias turn_start_extension turn_start
  def turn_start
    turn_start_extension
    ADIK::TURN_EXTENSION.global_turn_start
    $game_party.battle_members.each do |battler|
      eval(battler.actor.turn_extension_formula)
      eval(battler.class.turn_extension_formula)
      battler.equips.each do |equip|
        next if equip.nil?
        eval(equip.turn_extension_formula)
      end
      battler.states.each do |state|
        next if state.nil?
        eval(state.turn_extension_formula)
      end
    end
    $game_troop.members.each do |battler|
      eval(battler.enemy.turn_extension_formula)
      battler.states.each do |state|
        next if state.nil?
        eval(state.turn_extension_formula)
      end
    end
  end
  
  alias turn_end_extension turn_end
  def turn_end
    turn_end_extension
    ADIK::TURN_EXTENSION.global_turn_end
    $game_party.battle_members.each do |battler|
      eval(battler.actor.turn_end_extension_formula)
      eval(battler.class.turn_end_extension_formula)
      battler.equips.each do |equip|
        next if equip.nil?
        eval(equip.turn_end_extension_formula)
      end
      battler.states.each do |state|
        next if state.nil?
        eval(state.turn_end_extension_formula)
      end
    end
    $game_troop.members.each do |battler|
      eval(battler.enemy.turn_end_extension_formula)
      battler.states.each do |state|
        next if state.nil?
        eval(state.turn_end_extension_formula)
      end
    end
  end
  
end