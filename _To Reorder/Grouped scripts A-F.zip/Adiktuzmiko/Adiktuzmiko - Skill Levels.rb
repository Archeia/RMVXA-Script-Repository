=begin
======================================================
  
  Skill Levels v1.05
  by Adiktuzmiko                   
  
  Date Created: 02/27/2014
  Date Last Updated: 04/12/2014
  Requires: N/A
  Difficulty: Easy
  
======================================================
 Overview
======================================================
 
 This script allows you to have skill levels. Initial
 and maximum skill level values can be defined per
 actor. Escape code sequences for
 text boxes that support escape codes are given for
 showing skill level,max and exp.
 
 Do note that this script does not provide a default,
 automatic way to increase exp and/or levels. Those
 will be provided as Add-Ons. Script calls to do those
 are built-in
 
 Also, how levels modify your abilities are up to you.
 For simple things like increased damage, you can use
 the damage formula for that. 
 
======================================================
 Usage
====================================================== 

 Put this script into your scripts editor, probably
 below any other script that might modify Game_Actor
 and/or Game_Enemy and Game_Battler. Next thing to do
 is to tag your actors.
 
 Remember that these settings are per actor
 
 <SKILL LEVEL: ID,VALUE> = Sets initial level of 
 skill denoted by ID to VALUE
 
 <SKILL MAX: ID,VALUE> = Sets the maximum level of
 skill denoted by ID to VALUE
 
 <SKILL EXTENSION: ID>VALUE<END SKILL EXTENSION> = Allows you to run ruby lines
 when the skill denoted by ID levels. VALUE accepts multilines
 
 <SKILL EXTENSION_A>VALUE<END SKILL EXTENSION_A> = Allows you to run ruby lines
 when any skill levels. VALUE accepts multilines
 
 #This is for the skill  
   
 <SKILL PATH>FORMULA<END SKILL PATH> = The formula used to determine
 how much EXP is needed per level. Supports multiple
 lines.  
   
 Script calls:
 
 To modify the skill level for an actor
 $game_actors[id].mod_skill_level(id,type,value)
 
 To modify the skill max level for an actor
 $game_actors[id].mod_skill_max(id,type,value)
 
 To modify the skill exp for an actor
 $game_actors[id].mod_skill_exp(id,type,value)
   
   type => 'add' for adding 
           'mul' for multiplying
   value => value to add or multiply
   
 To obtain the skill level,max and exp for an Actor
 
 $game_actors[id].skill_level(skill_id)
 $game_actors[id].skill_max(skill_id)
 $game_actors[id].skill_exp(skill_id)
 
 You can also use those methods on battler objects,
 so like if you want a skill to deal damage depending
 on level, you can do this in the damage formula:
 
 10*a.skill_level(skill_id)
 
 Escape Character Codes:
 
 \SL[actor_id,skill_id] = Shows skill level for that actor
 \SM[actor_id,skill_id] = Shows skill max for that actor
 \SE[actor_id,skill_id] = Shows skill exp for that actor

======================================================
 Compatibility
======================================================

 Aliases Game_Actor/Enemy's initialize, and 
 Window Base's convert_escape_characters
 
======================================================
 Terms and Conditions
======================================================

 View it here: http://lescripts.wordpress.com/terms-and-conditions/

======================================================
=end

#======================================================
#  Do not edit below this line
#======================================================

module ADIK
  module SKILL_LEVEL
    TAG = /<SKILL LEVEL: (\d+),(\d+)>/i
    TAG_MAX = /<SKILL MAX: (\d+),(\d+)>/i
	  EXT = /<SKILL EXTENSION: (\d+)>/i
    EXT_END = /<END SKILL EXTENSION>/i
	  EXT_A = /<SKILL EXTENSION_A>(.*)<END SKILL EXTENSION_A>/im
    FORMULA = /<SKILL PATH>(.*)<END SKILL PATH>/im
  end
end

class Game_Battler
  
  attr_accessor :skill_levels
  attr_accessor :skill_exps
  
  #alias initialize_skill_levels_adik initialize
  #def initialize
    #initialize_skill_levels_adik
    
  #end
  
  def load_skill_level_notetag
    @skill_levels = [1]*$data_skills.size
    @skill_exps = [0]*$data_skills.size
    @skill_max = [1]*$data_skills.size
	  @skill_ext = [""]*$data_skills.size
    extension = false
    id = 0
    x = self.actor? ? self.actor : self.enemy  
    x.note.split(/[\r\n]+/).each { |line|
      case line
      when ADIK::SKILL_LEVEL::TAG
        @skill_levels[$1.to_i] = $2.to_i
      when ADIK::SKILL_LEVEL::TAG_MAX
        @skill_max[$1.to_i] = $2.to_i
      when ADIK::SKILL_LEVEL::EXT
        extension = true
        id = $1.to_i
        next
      when ADIK::SKILL_LEVEL::EXT_END
        extension = false
        id = 0
        next
      end
      if extension
        @skill_ext[id] += line.to_s
      end
    }
  end
  
  def skill_level(id)
    if @skill_levels[id] > @skill_max[id]
	  @skill_levels[id] = @skill_max[id]
	end
    return @skill_levels[id]
  end
  
  def skill_max(id)
    return @skill_max[id]
  end
  
  def skill_exp(id)
    return @skill_exps[id]
  end
  
  def mod_skill_level(id,type,value)
    case type
    when 'add'
      @skill_levels[id] += value
    when 'mul'
      @skill_levels[id] *= value
    end
	refresh_skill_adik_level
  end
  
  def mod_skill_max(id,type,value)
    case type
    when 'add'
      @skill_max[id] += value
    when 'mul'
      @skill_max[id] *= value
    end
	refresh_skill_adik_level
  end
  
  def mod_skill_exp(id,type,value)
    case type
    when 'add'
      @skill_exps[id] += value
    when 'mul'
      @skill_exps[id] *= value
    end
    refresh_skill_level(id)
    refresh_skill_adik_level(id)
  end 
  
  def refresh_skill_adik_level(id)
    if @skill_levels[id] > @skill_max[id]
      @skill_levels[id] = @skill_max[id]
    end
    skill_level_extension(id)
  end
  
  def skill_level_extension(id)
    eval(@skill_ext[id])
    x = self.actor? ? self.actor : self.enemy
    if x.note =~ ADIK::SKILL_LEVEL::EXT_A
      eval($1.to_s)
    else
      return
    end 
  end
  
  def refresh_skill_level(id)
    if $data_skills[id].note =~ ADIK::SKILL_LEVEL::FORMULA
      formula = $1.to_s
    else
      return
    end
    while true
      lvl = @skill_levels[id]
	    if lvl >= @skill_max[id]
	      break
	    end
      req = eval(formula)
      if @skill_exps[id] >= req
        @skill_levels[id] += 1
        @skill_exps[id] -= req
      else
        break
      end
    end	
  end
  
end

class Game_Actor
  alias initialize_skill_levels_adikx initialize
  def initialize(actor_id)
    initialize_skill_levels_adikx(actor_id)
    load_skill_level_notetag
  end
end

class Game_Enemy
  alias initialize_skill_levels_adikx initialize
  def initialize(index,enemy_id)
    initialize_skill_levels_adikx(index,enemy_id)
    load_skill_level_notetag
  end
end

class Window_Base
  alias escape_character_skill_levels convert_escape_characters
  def convert_escape_characters(text)
    result = escape_character_skill_levels(text)
    result.gsub!(/\eSL\[(\d+)\,(\d+)\]/i) { $game_actors[$1.to_i].skill_level($2.to_i) }
    result.gsub!(/\eSM\[(\d+)\,(\d+)\]/i) { $game_actors[$1.to_i].skill_max($2.to_i) }
    result.gsub!(/\eSE\[(\d+)\,(\d+)\]/i) { $game_actors[$1.to_i].skill_exp($2.to_i) }
    result
  end
end