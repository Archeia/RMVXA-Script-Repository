#Adds level to the skill name

class RPG::BaseItem    
  def name    
	if self.is_a?(RPG::Skill) then      
	  if SceneManager.scene_is?(Scene_Battle)        
		return @name if BattleManager.actor.nil?        
		return @name + ": Level " + BattleManager.actor.skill_level(@id).to_s      
	  else        
		return @name + ": Level " + SceneManager.scene.actor.skill_level(@id).to_s      
	  end    
	else      
	  return @name    
	end  
  end  
end

class Scene_Base  
  attr_accessor :actor
end