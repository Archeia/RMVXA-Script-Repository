=begin
======================================================
  
  Shared Storage v2.40
  by Adiktuzmiko                   
  
  Date Created: 09/25/2014
  Date Last Updated: 10/03/2015
  Requires: N/A
  Difficulty: Easy
  
======================================================
 Overview
======================================================
 
 This script allows you to have shared storages
 where you can put/take items. The storage is accessible
 to all save files of your game or even another game as
 long as you set them to use the same storage file.
 
 You can modify most of the properties of each window
 involved in the scene, and also where to put the
 storage file.
 
 You could also set a different max item limit for the
 storage than that of the normal limit for the party
 inventory
 
 All window settings and limitations can now be set
 separately for each storage. Any storage opened
 that doesn't have it's own settings will use
 the default.
 
 Allows multiple storages in one file
======================================================
 Usage
====================================================== 

 Put this script into your scripts editor and modify
 the settings below

 Then to open up the storage window
 
 Script call:
 
 SceneManager.open_shared_storage(number)
 
 Where number is the number of the storage that you will open.
 
 If you want to open multiple storages that can be switched
 right on the scene via button inputs (configurable below)
 
 you can use 
 
 SceneManager.open_shared_storage(min,max)
 
 where:
 
 min => storage to open right away, also the minimum that can be switched
 max => the maximum storage number that can be switched into
 
 example: If I want to open storages 3,4,5 and 6
 
 SceneManager.open_shared_storage(3,6)
 
 I don't know the limit of how many storages you can make,
 possibly hundreds or thousands.
 
 If you want to directly modify the contents of a storage
 (like if you want a certain storage to start with an item
 already in it)
 
 you can do this
 
 $shared_storage[[storage_number,item_class,item_id]] = amount
 ADIK::SHARED_STORAGE.save_storage
 
 item_class could be "RPG::Item", "RPG::Weapon", "RPG::Armor"
 
 the "" is important by the way
 
 For gold,
 
 $shared_storage[[:gold,storage_number]] = amount
 ADIK::SHARED_STORAGE.save_storage
 
 Take note that you must do it only ONCE per item that you wanna
 add to the storage.
 
 Better do it during the title screen script, 
 test play so that it runs,
 then delete the script lines afterward
 
 I'd also advice only doing it when you're going to ship the
 game already, else you might actually need to redo it before
 shipping out your game. 

 On configuring multiple storages:
 
 Important: The 0 indexed setting will be the one used by default
 by any storage that you open that doesn't have it's own
 settings defined. So don't remove it.
 
 Copy paste the setting constants and modify the index to the
 storage number that you want, then modify the values
 
 For example:
 
 This would be the settings for the custom window
 of storage number 1
 
 CUSTOM_WINDOW[1] = blahblah
 
 Do that for every setting that you want to change
 for a particular storage
 
======================================================
 Compatibility
======================================================

 Aliases DataManager's load_game and save_game_without_rescue
 methods, Scene_Title's start method
 
 Inherits Window_Selectable, Window_HorzCommand,
 Window_Base and Scene_Base
 
======================================================
 Terms and Conditions
======================================================

 View it here: http://lescripts.wordpress.com/terms-and-conditions/

======================================================
=end

module ADIK
  module SHARED_STORAGE
    
  # Primary folder where the save data will be placed
  # based on the default paths in your computer
  # set to nil if you don't want to use this
  DATA_PATH = 'CURRENT'
	
#~ 	Heres a list of parameters you can set the DATA_PATH into
#~ 	
#~ 	AppData = Contains the full path to the Application Data directory of the logged-in user
#~ 	LOCALAPPDATA = This variable is the temporary files of Applications.
#~  CURRENT = Folder where the game is run from

#~ 	!!!The following might require your game to run in admin mode!!!

#~ 	ProgramFiles = This variable points to Program Files directory
#~ 	CommonProgramFiles = This variable points to Common Files directory
    
    #Enter each subfolder paths after the primary folder here
    #The script automatically creates the folder path specified
    
    #FOLDER = [FOLDER1,FOLDER2,and so on]
    FOLDER = ["Storage"]
    
    #Filename for the storage file
    NAME = "storage.rvdata2"
    
    #Does it autosave when you put items into it?
    #If False, then it only saves the storage once
    #the player saves his game
    
    #You'd pretty much want to set this to false
    #unless you're also autosaving the game
    AUTOSAVE = true
    
    #Tag to make items not placeable in storage
    NON_STORAGE_TAG = /<non_storage>/
    
    #Important:  Do not remove!
    #======================================================
    BACKGROUND = []
    #======================================================
    
    #Background picture for the scene
    #Must be inside your Graphics\System folder
    BACKGROUND[0] = ""
    
    #Important:  Do not remove!
    #======================================================
    SS_CATEGORY_WINDOW = []
    SS_CATEGORY_FONT = []
    #======================================================
    
    #Settings for the Deposit/Withdraw window
    #x,y,width,height,Windowskin,Deposit Text, Withdraw Text
    SS_CATEGORY_WINDOW[0] = [0,0,164,32,"Window.png","Deposit","Withdraw"]
    #Font name, font size, color (based on windowskin)
    SS_CATEGORY_FONT[0] = [Font.default_name,24,0]
    
    #Important:  Do not remove!
    #======================================================
    CATEGORY_WINDOW = []
    CATEGORY_FONT = []
    #======================================================
    
    #Settings for the Item/Weapon/Armor/Key Item window
    #x,y,width,height,Windowskin,Item text, weapon text, armor text, key item text, gold text
    #set text to nil if you don't want it to show
    CATEGORY_WINDOW[0] = [164,0,380,32,"Window.png","Item","Weapon","Armor","Key Item","Gold"]
    #Font name, font size, color (based on windowskin)
    CATEGORY_FONT[0] = [Font.default_name,24,0]
    
    #Important:  Do not remove!
    #======================================================
    PLAYER_WINDOW = []
    PLAYER_FONT = []
    #======================================================
    
    #Settings for the Player Item Header window
    #x,y,width,height,Windowskin, Player inventory text
    PLAYER_WINDOW[0] = [0,48,226,48,"Window.png","Player Inventory"]
    #Font name, font size, color (based on windowskin)
    PLAYER_FONT[0] = [Font.default_name,18,1]
    
    #Important:  Do not remove!
    #======================================================
    STORAGE_WINDOW = []
    STORAGE_FONT = []
    #======================================================
    
    #Settings for the Storage Header window
    #x,y,width,height,Windowskin, Storage text
    STORAGE_WINDOW[0] = [318,48,226,48,"Window.png","Storage"]
    #Font name, font size, color (based on windowskin)
    STORAGE_FONT[0] = [Font.default_name,18,1]
    
    #Important:  Do not remove!
    #======================================================
    ITEM_LIST_PLAYER_WINDOW = []
    ITEM_LIST_PLAYER_FONT = []
    #======================================================
    
    #Settings for the player item window
    #x,y,width,height,Windowskin
    #You could set width and height to 0 to "remove"
    #the window
    ITEM_LIST_PLAYER_WINDOW[0] = [0,208,272,208,"Window.png"]
    #Font name, font size, color (based on windowskin)
    ITEM_LIST_PLAYER_FONT[0] = [Font.default_name,24,0]
    
    #Important:  Do not remove!
    #======================================================
    ITEM_LIST_STORAGE_WINDOW = []
    ITEM_LIST_STORAGE_FONT = []
    #======================================================
    
    #Settings for the storage item window
    #x,y,width,height,Windowskin
    #You could set width and height to 0 to "remove"
    #the window
    ITEM_LIST_STORAGE_WINDOW[0]= [272,208,272,208,"Window.png"]
    #Font name, font size, color (based on windowskin)
    ITEM_LIST_STORAGE_FONT[0] = [Font.default_name,24,0]
    
    
    
    #Important:  Do not remove!
    #======================================================
    NUMBER_MAX = []
    #======================================================
    
    #Maximum digits for item number selection
    NUMBER_MAX[0] = 2
    
    
    #Important:  Do not remove!
    #======================================================
    MAX_ITEM_NUMBER = []
    #======================================================
    
    #Formula for obtaining the maximum number
    #that each item can be placed in the storage
    MAX_ITEM_NUMBER[0] = "$game_party.max_item_number(item)"
    MAX_ITEM_NUMBER[1] = "SceneManager.scene.get_item_limit"
    
    #Important:  Do not remove!
    #======================================================
    ITEM_NUMBER_WINDOW = []
    ITEM_NUMBER_FONT = []
    #======================================================
    
    #Settings for item number window
    #x,y,width,height,Windowskin
    ITEM_NUMBER_WINDOW[0] = [240,156,32,32,"Window.png"]
    #Font name, font size, color (based on windowskin)
    ITEM_NUMBER_FONT[0] = [Font.default_name,18,0]
    
    #Important:  Do not remove!
    #======================================================
    HELP_WINDOW = []
    HELP_FONT = []
    #======================================================
    
    #Settings for help window
    #x,y,width,height,Windowskin
    HELP_WINDOW[0] = [0,96,Graphics.width,64,"Window.png"]
    #Font name, font size, color (based on windowskin)
    HELP_FONT[0] = [Font.default_name,18,0]
    
    
    #Important:  Do not remove!
    #======================================================
    CUSTOM_WINDOW = []
    CUSTOM_FONT = []
    CUSTOM_TEXT = []
    #======================================================
    
    #Settings for Custom Window
    #x,y,width,height,Windowskin
    #You could set width and height to 0 to "remove"
    #the window
    CUSTOM_WINDOW[0] = [226,48,96,48,"Window.png"]
    #Font name, font size, color (based on windowskin)
    CUSTOM_FONT[0] = [Font.default_name,18,0]
    #Formula/Method to determine what is shown on the custom
    #window
    CUSTOM_TEXT[0] = "$game_actors[1].name"
    CUSTOM_TEXT[1] = "SceneManager.scene.get_remaining_slots"
    
    #Important:  Do not remove!
    #======================================================
    GOLD_WINDOW = []
    GOLD_FONT = []
    #======================================================
    
    #Settings for Gold Window of storage
    #x,y,width,height,Windowskin,Text
    #You could set width and height to 0 to "remove"
    #the window
    GOLD_WINDOW[0] = [272,160,272,48,"Window.png","Gold: "]
    #Font name, font size, color (based on windowskin)
    GOLD_FONT[0] = [Font.default_name,18,0]
    
    #Important:  Do not remove!
    #======================================================
    GOLD_P_WINDOW = []
    GOLD_P_FONT = []
    #======================================================
    
    #Settings for Gold Window ofparty
    #x,y,width,height,Windowskin,Text
    #You could set width and height to 0 to "remove"
    #the window
    GOLD_P_WINDOW[0] = [0,160,272,48,"Window.png","Gold: "]
    #Font name, font size, color (based on windowskin)
    GOLD_P_FONT[0] = [Font.default_name,18,0]
    
    #Important:  Do not remove!
    #======================================================
    GOLD_LIMIT = []
    GOLD_P_LIMIT = []
    #======================================================
    
    #Limit for storage gold
    GOLD_LIMIT[0] = "$game_party.max_gold"
    GOLD_P_LIMIT[0] = "$game_party.max_gold"
    
    #Important:  Do not remove!
    #======================================================
    GOLD_NUMBER_WINDOW = []
    GOLD_NUMBER_FONT = []
    #======================================================
    
    #Settings for gold number window
    #x,y,width,height,Windowskin
    GOLD_NUMBER_WINDOW[0] = [240,156,32,32,"Window.png"]
    #Font name, font size, color (based on windowskin)
    GOLD_NUMBER_FONT[0] = [Font.default_name,18,0]
    
    #Key input for next storage
    NEXT_KEY = :c
    #Key input for prev storage
    PREV_KEY = :z
    
    #======================================================
    #  Do not edit below this line
    #======================================================
    
    #======================================================
    #  Do not edit below this line
    #======================================================
    
    #======================================================
    #  Do not edit below this line
    #======================================================
 
    
#========================================================================#    
    def self.check_storage
      @path = ""
      if not DATA_PATH == 'CURRENT'
        @path = ENV[DATA_PATH] + "\\"
      end
      FOLDER.each do |path|
        @path += path + "\\"
        Dir.mkdir(@path) if !FileTest.exist?(@path)
      end
      @path += NAME
      begin
        load_storage
      rescue
        $shared_storage = {}
        save_storage
      end
    end
    
    def self.save_storage
      File.open(@path, "wb") do |file|
        Marshal.dump($shared_storage, file)
      end
    end
    
    def self.load_storage
      File.open(@path, "rb") do |file|
        $shared_storage = Marshal.load(file)
      end
    end
    
  end
end

class Scene_Title
  alias shared_storage_start start
  def start
   shared_storage_start
   #loads storage from disk (or create it if it isn't yet)
   #everytime you go to the title screen
   ADIK::SHARED_STORAGE.check_storage
 end
end

class Window_SS_Category < Window_HorzCommand
  
  def initialize(x, y)
    super(x,y)
    categ = ADIK::SHARED_STORAGE::SS_CATEGORY_WINDOW[$shared_storage_number]
    categ = ADIK::SHARED_STORAGE::SS_CATEGORY_WINDOW[0] if categ.nil?
    self.windowskin = Cache.system(categ[4])
    categ = ADIK::SHARED_STORAGE::SS_CATEGORY_FONT[$shared_storage_number]
    categ = ADIK::SHARED_STORAGE::SS_CATEGORY_FONT[0] if categ.nil?
    contents.font.name = categ[0]
    contents.font.size = categ[1]
    contents.font.color = text_color(categ[2])
  end
  
  def col_max
    return 2
  end
  
  def window_width
    categ = ADIK::SHARED_STORAGE::SS_CATEGORY_WINDOW[$shared_storage_number]
    categ = ADIK::SHARED_STORAGE::SS_CATEGORY_WINDOW[0] if categ.nil?
    return categ[2]
  end
  
  def window_heigth
    categ = ADIK::SHARED_STORAGE::SS_CATEGORY_WINDOW[$shared_storage_number]
    categ = ADIK::SHARED_STORAGE::SS_CATEGORY_WINDOW[0] if categ.nil?
    return categ[3]
  end
  
  def make_command_list
    categ = ADIK::SHARED_STORAGE::SS_CATEGORY_WINDOW[$shared_storage_number]
    categ = ADIK::SHARED_STORAGE::SS_CATEGORY_WINDOW[0] if categ.nil?
    add_command(categ[5],   :deposit, true)
    add_command(categ[6],   :withdraw, true)
  end
  
end

class Window_Category_SS < Window_HorzCommand
  
  def initialize(x, y)
    super(x,y)
    categ = ADIK::SHARED_STORAGE::CATEGORY_WINDOW[$shared_storage_number]
    categ = ADIK::SHARED_STORAGE::CATEGORY_WINDOW[0] if categ.nil?
    self.windowskin = Cache.system(categ[4])
    categ = ADIK::SHARED_STORAGE::CATEGORY_FONT[$shared_storage_number]
    categ = ADIK::SHARED_STORAGE::CATEGORY_FONT[0] if categ.nil?
    contents.font.name = categ[0]
    contents.font.size = categ[1]
    contents.font.color = text_color(categ[2])
  end
  
  def col_max
    count = 0
    categ = ADIK::SHARED_STORAGE::CATEGORY_WINDOW[$shared_storage_number]
    categ = ADIK::SHARED_STORAGE::CATEGORY_WINDOW[0] if categ.nil?
    [5,6,7,8,9].each {|x| count+=1 unless categ[x].nil? }
    return count
  end
  
  def window_width
    categ = ADIK::SHARED_STORAGE::CATEGORY_WINDOW[$shared_storage_number]
    categ = ADIK::SHARED_STORAGE::CATEGORY_WINDOW[0] if categ.nil?
    return categ[2]
  end
  
  def window_heigth
    categ = ADIK::SHARED_STORAGE::CATEGORY_WINDOW[$shared_storage_number]
    categ = ADIK::SHARED_STORAGE::CATEGORY_WINDOW[0] if categ.nil?
    return categ[3]
  end
  
  def make_command_list
    categ = ADIK::SHARED_STORAGE::CATEGORY_WINDOW[$shared_storage_number]
    categ = ADIK::SHARED_STORAGE::CATEGORY_WINDOW[0] if categ.nil?
    add_command(categ[5],   :item, true) unless categ[5].nil?
    add_command(categ[6],   :weapon, true) unless categ[6].nil?
    add_command(categ[7],   :armor, true) unless categ[7].nil?
    add_command(categ[8],   :key_item, true) unless categ[8].nil?
    add_command(categ[9],   :gold, true) unless categ[9].nil?
  end
  
  def process_ok
    if current_item_enabled?
      if current_symbol == :gold
        Input.update
        deactivate
        call_ok_handler
      else
        Sound.play_ok
        Input.update
        deactivate
        call_ok_handler
      end
    else
      Sound.play_buzzer
    end
  end
  
end

class Window_ItemList_SS_Player < Window_Selectable
  #--------------------------------------------------------------------------
  # * Object Initialization
  #--------------------------------------------------------------------------
  def initialize(x, y, width, height)
    super
    @category = :none
    @data = []
    categ = ADIK::SHARED_STORAGE::ITEM_LIST_PLAYER_WINDOW[$shared_storage_number]
    categ = ADIK::SHARED_STORAGE::ITEM_LIST_PLAYER_WINDOW[0] if categ.nil?
    self.windowskin = Cache.system(categ[4])
    categ = ADIK::SHARED_STORAGE::ITEM_LIST_PLAYER_FONT[$shared_storage_number]
    categ = ADIK::SHARED_STORAGE::ITEM_LIST_PLAYER_FONT[0] if categ.nil?
    contents.font.name = categ[0]
    contents.font.size = categ[1]
    contents.font.color = text_color(categ[2])
  end
  #--------------------------------------------------------------------------
  # * Set Category
  #--------------------------------------------------------------------------
  def category=(category)
    return if @category == category
    @category = category
    refresh
    self.oy = 0
    select_last
  end
  #--------------------------------------------------------------------------
  # * Get Digit Count
  #--------------------------------------------------------------------------
  def col_max
    return 1
  end
  #--------------------------------------------------------------------------
  # * Get Number of Items
  #--------------------------------------------------------------------------
  def item_max
    @data ? @data.size : 0
  end
  #--------------------------------------------------------------------------
  # * Get Item
  #--------------------------------------------------------------------------
  def item
    @data && index >= 0 ? @data[index] : nil
  end
  #--------------------------------------------------------------------------
  # * Get Activation State of Selection Item
  #--------------------------------------------------------------------------
  def current_item_enabled?
    enable?(@data[index])
  end
  #--------------------------------------------------------------------------
  # * Include in Item List?
  #--------------------------------------------------------------------------
  def include?(item)
    return false if item.nil?
    return false if item.note =~ ADIK::SHARED_STORAGE::NON_STORAGE_TAG
    case @category
    when :item
      item.is_a?(RPG::Item) && !item.key_item?
    when :weapon
      item.is_a?(RPG::Weapon)
    when :armor
      item.is_a?(RPG::Armor)
    when :key_item
      item.is_a?(RPG::Item) && item.key_item?
    else
      false
    end
  end
  #--------------------------------------------------------------------------
  # * Display in Enabled State?
  #--------------------------------------------------------------------------
  def enable?(item)
    if SceneManager.scene.ss_category == :withdraw
      false
    else
      SceneManager.scene.can_store(item)
    end
  end
  #--------------------------------------------------------------------------
  # * Create Item List
  #--------------------------------------------------------------------------
  def make_item_list
    @data = $game_party.all_items.select {|item| include?(item) }
    @data.push(nil) if include?(nil)
  end
  #--------------------------------------------------------------------------
  # * Restore Previous Selection Position
  #--------------------------------------------------------------------------
  def select_last
    select(@data.index($game_party.last_item.object) || 0)
  end
  #--------------------------------------------------------------------------
  # * Draw Item
  #--------------------------------------------------------------------------
  def draw_item(index)
    item = @data[index]
    if item
      rect = item_rect(index)
      rect.width -= 4
      draw_item_name(item, rect.x, rect.y, enable?(item))
      draw_item_number(rect, item)
    end
  end
  #--------------------------------------------------------------------------
  # * Draw Number of Items
  #--------------------------------------------------------------------------
  def draw_item_number(rect, item)
    draw_text(rect, sprintf(":%2d", $game_party.item_number(item)), 2)
  end
  #--------------------------------------------------------------------------
  # * Update Help Text
  #--------------------------------------------------------------------------
  def update_help
    @help_window.set_item(item)
  end
  #--------------------------------------------------------------------------
  # * Refresh
  #--------------------------------------------------------------------------
  def refresh
    make_item_list
    create_contents
    draw_all_items
  end
  
  def process_ok
    if current_item_enabled?
      Input.update
      deactivate
      call_ok_handler
    else
      Sound.play_buzzer
    end
  end
  
end

class Window_ItemList_SS_Storage < Window_Selectable
  #--------------------------------------------------------------------------
  # * Object Initialization
  #--------------------------------------------------------------------------
  def initialize(x, y, width, height)
    super
    @category = :none
    @data = []
    categ = ADIK::SHARED_STORAGE::ITEM_LIST_STORAGE_WINDOW[$shared_storage_number]
    categ = ADIK::SHARED_STORAGE::ITEM_LIST_STORAGE_WINDOW[0] if categ.nil?
    self.windowskin = Cache.system(categ[4])
    categ = ADIK::SHARED_STORAGE::ITEM_LIST_STORAGE_FONT[$shared_storage_number]
    categ = ADIK::SHARED_STORAGE::ITEM_LIST_STORAGE_FONT[0] if categ.nil?
    contents.font.name = categ[0]
    contents.font.size = categ[1]
    contents.font.color = text_color(categ[2])
  end
  
  def process_ok
    if current_item_enabled?
      Input.update
      deactivate
      call_ok_handler
    else
      Sound.play_buzzer
    end
  end
  
  #--------------------------------------------------------------------------
  # * Set Category
  #--------------------------------------------------------------------------
  def category=(category)
    return if @category == category
    @category = category
    refresh
    self.oy = 0
    select_last
  end
  #--------------------------------------------------------------------------
  # * Get Digit Count
  #--------------------------------------------------------------------------
  def col_max
    return 1
  end
  #--------------------------------------------------------------------------
  # * Get Number of Items
  #--------------------------------------------------------------------------
  def item_max
    @data ? @data.size : 0
  end
  #--------------------------------------------------------------------------
  # * Get Item
  #--------------------------------------------------------------------------
  def item
    @data && index >= 0 ? @data[index] : nil
  end
  #--------------------------------------------------------------------------
  # * Get Activation State of Selection Item
  #--------------------------------------------------------------------------
  def current_item_enabled?
    enable?(@data[index])
  end
  #--------------------------------------------------------------------------
  # * Include in Item List?
  #--------------------------------------------------------------------------
  def include?(item)
    return false if item.nil?
    case @category
    when :item
      item.is_a?(RPG::Item) && !item.key_item?
    when :weapon
      item.is_a?(RPG::Weapon)
    when :armor
      item.is_a?(RPG::Armor)
    when :key_item
      item.is_a?(RPG::Item) && item.key_item?
    else
      false
    end
  end
  #--------------------------------------------------------------------------
  # * Display in Enabled State?
  #--------------------------------------------------------------------------
  def enable?(item)
    if SceneManager.scene.ss_category == :deposit
      false
    else
      SceneManager.scene.can_store(item)
    end
  end
  #--------------------------------------------------------------------------
  # * Create Item List
  #--------------------------------------------------------------------------
  def make_item_list
    @data = []
    $shared_storage.each_key do |key|
      next if key[0] != @storage_number
      case key[1]
      when "RPG::Item"
        item = $data_items[key[2]]
        @data.push(item) if include?(item)
      when "RPG::Weapon"
        item = $data_weapons[key[2]]
        @data.push(item) if include?(item)
      when "RPG::Armor"
        item = $data_armors[key[2]]
        @data.push(item) if include?(item)
      end
    end
  end
  
  def set_number(sn)
    @storage_number = sn
  end
  
  #--------------------------------------------------------------------------
  # * Restore Previous Selection Position
  #--------------------------------------------------------------------------
  def select_last
    select(@data.index($game_party.last_item.object) || 0)
  end
  #--------------------------------------------------------------------------
  # * Draw Item
  #--------------------------------------------------------------------------
  def draw_item(index)
    item = @data[index]
    if item
      rect = item_rect(index)
      rect.width -= 4
      draw_item_name(item, rect.x, rect.y, enable?(item))
      draw_item_number(rect, item)
    end
  end
  #--------------------------------------------------------------------------
  # * Draw Number of Items
  #--------------------------------------------------------------------------
  def draw_item_number(rect, item)
    draw_text(rect, sprintf(":%2d", $shared_storage[[@storage_number,item.class.to_s,item.id]]), 2)
  end
  #--------------------------------------------------------------------------
  # * Update Help Text
  #--------------------------------------------------------------------------
  def update_help
    @help_window.set_item(item)
  end
  #--------------------------------------------------------------------------
  # * Refresh
  #--------------------------------------------------------------------------
  def refresh
    make_item_list
    create_contents
    draw_all_items
  end
end


class Window_Player_Header < Window_Base
  
  def initialize(x, y, width, height)
    super
    categ = ADIK::SHARED_STORAGE::PLAYER_WINDOW[$shared_storage_number]
    categ = ADIK::SHARED_STORAGE::PLAYER_WINDOW[0] if categ.nil?
    self.windowskin = Cache.system(categ[4])
    categ1 = ADIK::SHARED_STORAGE::PLAYER_FONT[$shared_storage_number]
    categ1 = ADIK::SHARED_STORAGE::PLAYER_FONT[0] if categ1.nil?
    contents.font.name = categ1[0]
    contents.font.size = categ1[1]
    contents.font.color = text_color(categ1[2])
    contents.draw_text(0,0,categ[2],categ1[1],categ[5],1)
  end
  
end

class Window_Storage_Header < Window_Base
  
  def initialize(x, y, width, height)
    super
    categ = ADIK::SHARED_STORAGE::STORAGE_WINDOW[$shared_storage_number]
    categ = ADIK::SHARED_STORAGE::STORAGE_WINDOW[0] if categ.nil?
    self.windowskin = Cache.system(categ[4])
    categ1 = ADIK::SHARED_STORAGE::STORAGE_FONT[$shared_storage_number]
    categ1 = ADIK::SHARED_STORAGE::STORAGE_FONT[0] if categ1.nil?
    contents.font.name = categ1[0]
    contents.font.size = categ1[1]
    contents.font.color = text_color(categ1[2])
    contents.draw_text(0,0,categ[2],categ1[1],categ[5],1)
  end
  
end

class Window_NumberInput_SS < Window_Base
  #--------------------------------------------------------------------------
  # * Object Initialization
  #--------------------------------------------------------------------------
  def initialize
    categ = ADIK::SHARED_STORAGE::ITEM_NUMBER_WINDOW[$shared_storage_number]
    categ = ADIK::SHARED_STORAGE::ITEM_NUMBER_WINDOW[0] if categ.nil?
    super(categ[0],categ[1],categ[2],categ[3])
    @number = 0
    @digits_max = 1
    @index = 0
    @item = nil
    self.windowskin = Cache.system(categ[4])
    categ = ADIK::SHARED_STORAGE::ITEM_NUMBER_FONT[$shared_storage_number]
    categ = ADIK::SHARED_STORAGE::ITEM_NUMBER_FONT[0] if categ.nil?
    contents.font.name = categ[0]
    contents.font.size = categ[1]
    contents.font.color = text_color(categ[2])
    self.openness = 0
    deactivate
  end
  #--------------------------------------------------------------------------
  # * Start Input Processing
  #--------------------------------------------------------------------------
  def start(item,category)
    @digits_max = ADIK::SHARED_STORAGE::NUMBER_MAX[$shared_storage_number]
    @digits_max = ADIK::SHARED_STORAGE::NUMBER_MAX[0] if @digits_max.nil?
    @index = @digits_max - 1
    @item = item
    @category = category
    update_placement
    create_contents
    refresh
    open
    activate
  end
  #--------------------------------------------------------------------------
  # * Update Window Position
  #--------------------------------------------------------------------------
  def update_placement
    self.width = @digits_max * 20 + padding * 2
    self.height = fitting_height(1)
  end
  #--------------------------------------------------------------------------
  # * Move Cursor Right
  #     wrap : Wraparound allowed
  #--------------------------------------------------------------------------
  def cursor_right(wrap)
    if @index < @digits_max - 1 || wrap
      @index = (@index + 1) % @digits_max
    end
  end
  #--------------------------------------------------------------------------
  # * Move Cursor Left
  #     wrap : Wraparound allowed
  #--------------------------------------------------------------------------
  def cursor_left(wrap)
    if @index > 0 || wrap
      @index = (@index + @digits_max - 1) % @digits_max
    end
  end
  #--------------------------------------------------------------------------
  # * Frame Update
  #--------------------------------------------------------------------------
  def update
    super
    process_cursor_move
    process_digit_change
    process_handling
    update_cursor
  end
  #--------------------------------------------------------------------------
  # * Cursor Movement Processing
  #--------------------------------------------------------------------------
  def process_cursor_move
    return unless active
    last_index = @index
    cursor_right(Input.trigger?(:RIGHT)) if Input.repeat?(:RIGHT)
    cursor_left (Input.trigger?(:LEFT))  if Input.repeat?(:LEFT)
    Sound.play_cursor if @index != last_index
  end
  #--------------------------------------------------------------------------
  # * Change Processing for Digits
  #--------------------------------------------------------------------------
  def process_digit_change
    return unless active
    if Input.repeat?(:UP) || Input.repeat?(:DOWN)
      Sound.play_cursor
      place = 10 ** (@digits_max - 1 - @index)
      n = @number / place % 10
      @number -= n * place
      n = (n + 1) % 10 if Input.repeat?(:UP)
      n = (n + 9) % 10 if Input.repeat?(:DOWN)
      @number += n * place
      if @category == :deposit
        item = @item
        numb = ADIK::SHARED_STORAGE::MAX_ITEM_NUMBER[$shared_storage_number]
        numb = ADIK::SHARED_STORAGE::MAX_ITEM_NUMBER[0] if numb.nil?
        numb = eval(numb)
        begin
          numb -= $shared_storage[[$shared_storage_number,@item.class.to_s,@item.id]]
        rescue
        end
        @number = [@number,$game_party.item_number(@item),numb].min
      else
        amount = $shared_storage[[$shared_storage_number,@item.class.to_s,@item.id]]
        limit = $game_party.max_item_number(@item)- $game_party.item_number(@item)
        @number = [@number,amount,limit].min
      end
      refresh
    end
  end
  #--------------------------------------------------------------------------
  # * Handling Processing for OK and Cancel
  #--------------------------------------------------------------------------
  def process_handling
    return unless active
    return process_ok     if Input.trigger?(:C)
    return process_cancel if Input.trigger?(:B)
  end
  #--------------------------------------------------------------------------
  # * Processing When OK Button Is Pressed
  #--------------------------------------------------------------------------
  def process_ok
    Sound.play_ok
    SceneManager.scene.set_number(@number)
    deactivate
    close
  end
  #--------------------------------------------------------------------------
  # * Processing When Cancel Button Is Pressed
  #--------------------------------------------------------------------------
  def process_cancel
    SceneManager.scene.set_number(0)
    deactivate
    close
  end
  #--------------------------------------------------------------------------
  # * Get Rectangle for Displaying Item
  #--------------------------------------------------------------------------
  def item_rect(index)
    Rect.new(index * 20, 0, 20, line_height)
  end
  #--------------------------------------------------------------------------
  # * Refresh
  #--------------------------------------------------------------------------
  def refresh
    contents.clear
    change_color(normal_color)
    s = sprintf("%0*d", @digits_max, @number)
    @digits_max.times do |i|
      rect = item_rect(i)
      rect.x += 1
      draw_text(rect, s[i,1], 1)
    end
  end
  #--------------------------------------------------------------------------
  # * Update Cursor
  #--------------------------------------------------------------------------
  def update_cursor
    cursor_rect.set(item_rect(@index))
  end
end

class Window_NumberInput_Gold < Window_Base
  #--------------------------------------------------------------------------
  # * Object Initialization
  #--------------------------------------------------------------------------
  def initialize
    categ = ADIK::SHARED_STORAGE::GOLD_NUMBER_WINDOW[$shared_storage_number]
    categ = ADIK::SHARED_STORAGE::GOLD_NUMBER_WINDOW[0] if categ.nil?
    super(categ[0],categ[1],categ[2],categ[3])
    @number = 0
    @digits_max = 1
    @index = 0
    @item = nil
    self.windowskin = Cache.system(categ[4])
    categ = ADIK::SHARED_STORAGE::GOLD_NUMBER_FONT[$shared_storage_number]
    categ = ADIK::SHARED_STORAGE::GOLD_NUMBER_FONT[0] if categ.nil?
    contents.font.name = categ[0]
    contents.font.size = categ[1]
    contents.font.color = text_color(categ[2])
    self.openness = 0
    deactivate
  end
  #--------------------------------------------------------------------------
  # * Start Input Processing
  #--------------------------------------------------------------------------
  def start(category)
    if category == :deposit
      if ADIK::SHARED_STORAGE::GOLD_LIMIT[$shared_storage_number].nil?
        @digits_max = eval(ADIK::SHARED_STORAGE::GOLD_LIMIT[0]).to_s.length
      else
        @digits_max = eval(ADIK::SHARED_STORAGE::GOLD_LIMIT[$shared_storage_number]).to_s.length
      end
    else
      if ADIK::SHARED_STORAGE::GOLD_P_LIMIT[$shared_storage_number].nil?
        @digits_max = eval(ADIK::SHARED_STORAGE::GOLD_P_LIMIT[0]).to_s.length
      else
        @digits_max = eval(ADIK::SHARED_STORAGE::GOLD_P_LIMIT[$shared_storage_number]).to_s.length
      end
    end
    @index = @digits_max - 1
    @category = category
    update_placement
    create_contents
    refresh
    open
    activate
  end
  #--------------------------------------------------------------------------
  # * Update Window Position
  #--------------------------------------------------------------------------
  def update_placement
    self.width = @digits_max * 20 + padding * 2
    self.height = fitting_height(1)
  end
  #--------------------------------------------------------------------------
  # * Move Cursor Right
  #     wrap : Wraparound allowed
  #--------------------------------------------------------------------------
  def cursor_right(wrap)
    if @index < @digits_max - 1 || wrap
      @index = (@index + 1) % @digits_max
    end
  end
  #--------------------------------------------------------------------------
  # * Move Cursor Left
  #     wrap : Wraparound allowed
  #--------------------------------------------------------------------------
  def cursor_left(wrap)
    if @index > 0 || wrap
      @index = (@index + @digits_max - 1) % @digits_max
    end
  end
  #--------------------------------------------------------------------------
  # * Frame Update
  #--------------------------------------------------------------------------
  def update
    super
    process_cursor_move
    process_digit_change
    process_handling
    update_cursor
  end
  #--------------------------------------------------------------------------
  # * Cursor Movement Processing
  #--------------------------------------------------------------------------
  def process_cursor_move
    return unless active
    last_index = @index
    cursor_right(Input.trigger?(:RIGHT)) if Input.repeat?(:RIGHT)
    cursor_left (Input.trigger?(:LEFT))  if Input.repeat?(:LEFT)
    Sound.play_cursor if @index != last_index
  end
  #--------------------------------------------------------------------------
  # * Change Processing for Digits
  #--------------------------------------------------------------------------
  def process_digit_change
    return unless active
    if Input.repeat?(:UP) || Input.repeat?(:DOWN)
      Sound.play_cursor
      place = 10 ** (@digits_max - 1 - @index)
      n = @number / place % 10
      @number -= n * place
      n = (n + 1) % 10 if Input.repeat?(:UP)
      n = (n + 9) % 10 if Input.repeat?(:DOWN)
      @number += n * place
      if @category == :deposit
        numb = ADIK::SHARED_STORAGE::GOLD_LIMIT[$shared_storage_number]
        numb = ADIK::SHARED_STORAGE::GOLD_LIMIT[0] if numb.nil?
        numb = eval(numb)
        begin
          numb -= $shared_storage[[:gold,$shared_storage_number]]
        end
        @number = [@number,$game_party.gold,numb].min
      else
        numb = ADIK::SHARED_STORAGE::GOLD_P_LIMIT[$shared_storage_number]
        numb = ADIK::SHARED_STORAGE::GOLD_P_LIMIT[0] if numb.nil?
        numb = eval(numb)
        begin
          numb -= $game_party.gold
        end
        @number = [@number,$shared_storage[[:gold,$shared_storage_number]],numb].min
      end
      refresh
    end
  end
  #--------------------------------------------------------------------------
  # * Handling Processing for OK and Cancel
  #--------------------------------------------------------------------------
  def process_handling
    return unless active
    return process_ok     if Input.trigger?(:C)
    return process_cancel if Input.trigger?(:B)
  end
  #--------------------------------------------------------------------------
  # * Processing When OK Button Is Pressed
  #--------------------------------------------------------------------------
  def process_ok
    Sound.play_ok
    SceneManager.scene.adjust_gold(@number)
    deactivate
    close
  end
  #--------------------------------------------------------------------------
  # * Processing When Cancel Button Is Pressed
  #--------------------------------------------------------------------------
  def process_cancel
    SceneManager.scene.set_number(0)
    deactivate
    close
  end
  #--------------------------------------------------------------------------
  # * Get Rectangle for Displaying Item
  #--------------------------------------------------------------------------
  def item_rect(index)
    Rect.new(index * 20, 0, 20, line_height)
  end
  #--------------------------------------------------------------------------
  # * Refresh
  #--------------------------------------------------------------------------
  def refresh
    contents.clear
    change_color(normal_color)
    s = sprintf("%0*d", @digits_max, @number)
    @digits_max.times do |i|
      rect = item_rect(i)
      rect.x += 1
      draw_text(rect, s[i,1], 1)
    end
  end
  #--------------------------------------------------------------------------
  # * Update Cursor
  #--------------------------------------------------------------------------
  def update_cursor
    cursor_rect.set(item_rect(@index))
  end
end

class Custom_Text_SS < Window_Base
  
  def update_text
    category = ADIK::SHARED_STORAGE::CUSTOM_WINDOW[SceneManager.scene.storage_number]
    category = ADIK::SHARED_STORAGE::CUSTOM_WINDOW[0] if category.nil?
    return if category[2] == 0 or category[3] == 0
    contents.clear
    category = ADIK::SHARED_STORAGE::CUSTOM_TEXT[SceneManager.scene.storage_number]
    category = ADIK::SHARED_STORAGE::CUSTOM_TEXT[0] if category.nil?
    contents.draw_text(0,0,contents.width,contents.font.size,eval(category).to_s,1)
  end
  
end

class Gold_Window_SS < Window_Base
  
  def update_text
    category = ADIK::SHARED_STORAGE::GOLD_WINDOW[SceneManager.scene.storage_number]
    category = ADIK::SHARED_STORAGE::GOLD_WINDOW[0] if category.nil?
    return if category[2] == 0 or category[3] == 0
    contents.clear
    $shared_storage[[:gold,SceneManager.scene.storage_number]] = 0 if $shared_storage[[:gold,SceneManager.scene.storage_number]].nil?
    text = category[5].to_s + $shared_storage[[:gold,SceneManager.scene.storage_number]].to_s
    contents.draw_text(0,0,contents.width,contents.font.size,text,0)
  end
  
end

class Gold_Window_P < Window_Base
  
  def update_text
    category = ADIK::SHARED_STORAGE::GOLD_P_WINDOW[SceneManager.scene.storage_number]
    category = ADIK::SHARED_STORAGE::GOLD_P_WINDOW[0] if category.nil?
    return if category[2] == 0 or category[3] == 0
    contents.clear
    text = category[5].to_s + $game_party.gold.to_s
    contents.draw_text(0,0,contents.width,contents.font.size,text,0)
  end
  
end

class Scene_SharedStorage < Scene_Base
  
  attr_accessor :ss_category
  attr_accessor :category
  attr_accessor :storage_number
  attr_accessor :storage_number_max
  attr_accessor :storage_number_min
  
  def start
    super
    @storage_number = $shared_storage_number
    @background_sprite = Sprite.new
    begin
      @background_sprite.bitmap = Cache.system(ADIK::SHARED_STORAGE::BACKGROUND[@storage_number])
    rescue
      @background_sprite.bitmap = Cache.system(ADIK::SHARED_STORAGE::BACKGROUND[0])
    end
    create_ss_category_window
    create_category_window
    create_header_windows
    create_window_item_list_ss_player
    create_window_item_list_ss_storage
    create_help_window
    create_custom_text_window
    create_gold_window
    @ss_category_window.activate
  end
  
  def terminate
    @background_sprite.dispose
    super
  end
  
  def create_custom_text_window
    category = ADIK::SHARED_STORAGE::CUSTOM_WINDOW[@storage_number]
    category = ADIK::SHARED_STORAGE::CUSTOM_WINDOW[0] if category.nil?
    @custom_text_window = Custom_Text_SS.new(category[0],category[1],category[2],category[3])
    @custom_text_window.x = category[0]
    @custom_text_window.y = category[1]
    @custom_text_window.width = category[2]
    @custom_text_window.height = category[3]
    @custom_text_window.windowskin = Cache.system(category[4])
    category = ADIK::SHARED_STORAGE::CUSTOM_FONT[@storage_number]
    category = ADIK::SHARED_STORAGE::CUSTOM_FONT[0] if category.nil?
    @custom_text_window.contents.font.name = category[0]
    @custom_text_window.contents.font.size = category[1]
    @custom_text_window.contents.font.color = @help_window.text_color(category[2])
    @custom_text_window.update_text
  end
  
  def create_gold_window
    category = ADIK::SHARED_STORAGE::GOLD_WINDOW[@storage_number]
    category = ADIK::SHARED_STORAGE::GOLD_WINDOW[0] if category.nil?
    @gold_window_ss = Gold_Window_SS.new(category[0],category[1],category[2],category[3])
    @gold_window_ss.x = category[0]
    @gold_window_ss.y = category[1]
    @gold_window_ss.width = category[2]
    @gold_window_ss.height = category[3]
    @gold_window_ss.windowskin = Cache.system(category[4])
    category = ADIK::SHARED_STORAGE::GOLD_FONT[@storage_number]
    category = ADIK::SHARED_STORAGE::GOLD_FONT[0] if category.nil?
    @gold_window_ss.contents.font.name = category[0]
    @gold_window_ss.contents.font.size = category[1]
    @gold_window_ss.contents.font.color = @help_window.text_color(category[2])
    @gold_window_ss.update_text
    category = ADIK::SHARED_STORAGE::GOLD_P_WINDOW[@storage_number]
    category = ADIK::SHARED_STORAGE::GOLD_P_WINDOW[0] if category.nil?
    @gold_window_p = Gold_Window_P.new(category[0],category[1],category[2],category[3])
    @gold_window_p.x = category[0]
    @gold_window_p.y = category[1]
    @gold_window_p.width = category[2]
    @gold_window_p.height = category[3]
    @gold_window_p.windowskin = Cache.system(category[4])
    category = ADIK::SHARED_STORAGE::GOLD_P_FONT[@storage_number]
    category = ADIK::SHARED_STORAGE::GOLD_P_FONT[0] if category.nil?
    @gold_window_p.contents.font.name = category[0]
    @gold_window_p.contents.font.size = category[1]
    @gold_window_p.contents.font.color = @help_window.text_color(category[2])
    @gold_window_p.update_text
  end
  
  def create_help_window
    @help_window = Window_Help.new
    category = ADIK::SHARED_STORAGE::HELP_WINDOW[@storage_number]
    category = ADIK::SHARED_STORAGE::HELP_WINDOW[0] if category.nil?
    @help_window.x = category[0]
    @help_window.y = category[1]
    @help_window.width = category[2]
    @help_window.height = category[3]
    @help_window.windowskin = Cache.system(category[4])
    category = ADIK::SHARED_STORAGE::HELP_FONT[@storage_number]
    category = ADIK::SHARED_STORAGE::HELP_FONT[0] if category.nil?
    @help_window.contents.font.name = category[0]
    @help_window.contents.font.size = category[1]
    @help_window.contents.font.color = @help_window.text_color(category[2])
    @list_storage_window.help_window = @help_window
    @list_player_window.help_window = @help_window
  end
  
  def create_header_windows
    category = ADIK::SHARED_STORAGE::PLAYER_WINDOW[@storage_number]
    category = ADIK::SHARED_STORAGE::PLAYER_WINDOW[0] if category.nil?
    @player_header = Window_Player_Header.new(category[0],category[1],category[2],category[3])
    category = ADIK::SHARED_STORAGE::STORAGE_WINDOW[@storage_number]
    category = ADIK::SHARED_STORAGE::STORAGE_WINDOW[0] if category.nil?
    @storage_header = Window_Storage_Header.new(category[0],category[1],category[2],category[3])
  end
  
  def create_ss_category_window
    category = ADIK::SHARED_STORAGE::SS_CATEGORY_WINDOW[@storage_number]
    category = ADIK::SHARED_STORAGE::SS_CATEGORY_WINDOW[0] if category.nil?
    @ss_category_window = Window_SS_Category.new(category[0],category[1])
    @ss_category_window.set_handler(:cancel, method(:return_scene))
    @ss_category_window.set_handler(:deposit, method(:on_deposit))
    @ss_category_window.set_handler(:withdraw, method(:on_withdraw))
  end
  
  def create_category_window
    category = ADIK::SHARED_STORAGE::CATEGORY_WINDOW[@storage_number]
    category = ADIK::SHARED_STORAGE::CATEGORY_WINDOW[0] if category.nil?
    @category_window = Window_Category_SS.new(category[0],category[1])
    @category_window.set_handler(:cancel, method(:return_ss_category))
    @category_window.set_handler(:item, method(:on_item))
    @category_window.set_handler(:weapon, method(:on_weapon))
    @category_window.set_handler(:armor, method(:on_armor))
    @category_window.set_handler(:key_item, method(:on_key_item))
    @category_window.set_handler(:gold, method(:on_gold))
    @category_window.deactivate
  end
  
  def create_window_item_list_ss_player
    category = ADIK::SHARED_STORAGE::ITEM_LIST_PLAYER_WINDOW[@storage_number]
    category = ADIK::SHARED_STORAGE::ITEM_LIST_PLAYER_WINDOW[0] if category.nil?
    @list_player_window = Window_ItemList_SS_Player.new(category[0],category[1],category[2],category[3])
    @list_player_window.set_handler(:cancel, method(:return_list))
    @list_player_window.set_handler(:ok, method(:on_player_ok))
    @list_player_window.deactivate
  end
  
  def create_window_item_list_ss_storage
    category = ADIK::SHARED_STORAGE::ITEM_LIST_STORAGE_WINDOW[@storage_number]
    category = ADIK::SHARED_STORAGE::ITEM_LIST_STORAGE_WINDOW[0] if category.nil?
    @list_storage_window = Window_ItemList_SS_Storage.new(category[0],category[1],category[2],category[3])
    @list_storage_window.set_handler(:cancel, method(:return_list))
    @list_storage_window.set_handler(:ok, method(:on_player_ok))
    @list_storage_window.set_number(@storage_number)
    @list_storage_window.deactivate
  end
  
  def on_deposit
    @ss_category = :deposit
    @category_window.activate
  end
  
  def on_withdraw
    @ss_category = :withdraw
    @category_window.activate
  end

  def return_ss_category
    @ss_category_window.activate 
  end
  
  def return_list
    @category_window.activate
  end
  
  def select_window
    @list_player_window.category = @category
    @list_storage_window.category = @category
    if @ss_category == :deposit
      @list_player_window.refresh
      @list_storage_window.refresh
      @list_player_window.activate
    else
      @list_player_window.refresh
      @list_storage_window.refresh
      @list_storage_window.activate
    end
  end
  
  def on_item
    @category = :item
    select_window
  end
  
  def on_weapon
    @category = :weapon
    select_window
  end
  
  def on_armor
    @category = :armor
    select_window
  end
  
  def on_key_item
    @category = :key_item
    select_window
  end
  
  def on_gold
    @category = :gold
    if @ss_category == :deposit
      if $game_party.gold < 1
        Sound.play_buzzer
        @category_window.activate
        return
      end
    else
      $shared_storage[[:gold,SceneManager.scene.storage_number]] = 0 if $shared_storage[[:gold,SceneManager.scene.storage_number]].nil?
      if $shared_storage[[:gold,SceneManager.scene.storage_number]] == 0
        Sound.play_buzzer
        @category_window.activate
        return
      end
    end
    Sound.play_ok
    @number_g_window = Window_NumberInput_Gold.new
    @number_g_window.start(@ss_category)
  end
  
  def adjust_gold(amount)
    if @ss_category == :deposit
      $shared_storage[[:gold,SceneManager.scene.storage_number]] += amount
      $game_party.gain_gold(-amount)
    else
      $game_party.gain_gold(amount)
      $shared_storage[[:gold,SceneManager.scene.storage_number]] -= amount
    end
    @gold_window_ss.update_text
    @gold_window_p.update_text
    ADIK::SHARED_STORAGE.save_storage if ADIK::SHARED_STORAGE::AUTOSAVE
    @category_window.activate
  end
  
  def on_player_ok
    if has_item_to_pick
      Sound.play_ok
      @number_window = Window_NumberInput_SS.new
      @number_window.start(get_item,@ss_category)
    else
      Sound.play_buzzer
      select_window
    end
  end
  
  def has_item_to_pick
    if @ss_category == :deposit
      return @list_player_window.item_max > 0
    else
      return @list_storage_window.item_max > 0
    end
  end
  
  def get_item
    if @ss_category == :deposit
      return @list_player_window.item
    else
      return @list_storage_window.item
    end
  end
  
  def can_store(item)
    if @ss_category == :deposit
      numb = ADIK::SHARED_STORAGE::MAX_ITEM_NUMBER[@storage_number]
      numb = ADIK::SHARED_STORAGE::MAX_ITEM_NUMBER[0] if numb.nil?
      numb = eval(numb)
      begin
        numb -= $shared_storage[[@storage_number,item.class.to_s,item.id]]
      rescue
      end
      return numb > 0
    else
      numb = $game_party.item_number(item)
      return numb < $game_party.max_item_number(item)
    end
  end
  
  def set_number(number)
    @number = number
    item = get_item
    if @ss_category == :deposit
      if number > 0
        $shared_storage[[@storage_number,item.class.to_s,item.id]] = 0 if $shared_storage[[@storage_number,item.class.to_s,item.id]].nil?
        $game_party.lose_item(item,number)
        $shared_storage[[@storage_number,item.class.to_s,item.id]] += number
        @list_player_window.refresh
        @list_storage_window.refresh
        ADIK::SHARED_STORAGE.save_storage if ADIK::SHARED_STORAGE::AUTOSAVE
      end
    else
      if number > 0
        $game_party.gain_item(item,number)
        $shared_storage[[@storage_number,item.class.to_s,item.id]] -= number
        if $shared_storage[[@storage_number,item.class.to_s,item.id]] == 0
          $shared_storage.delete([@storage_number,item.class.to_s,item.id])
        end
        @list_player_window.refresh
        @list_storage_window.refresh
        ADIK::SHARED_STORAGE.save_storage if ADIK::SHARED_STORAGE::AUTOSAVE
      end
    end
    @custom_text_window.update_text
    select_window
  end
  
  def update
    super
    return if @storage_number_max.nil?
    if Input.trigger?(ADIK::SHARED_STORAGE::NEXT_KEY)
      if @storage_number < @storage_number_max
        @storage_number += 1
      else
        @storage_number = @storage_number_min
      end
      SceneManager.next_storage(@storage_number,@storage_number_min,@storage_number_max)
    elsif Input.trigger?(ADIK::SHARED_STORAGE::PREV_KEY)
      if @storage_number > @storage_number_min
        @storage_number -= 1
      else
        @storage_number = @storage_number_max
      end
      SceneManager.next_storage(@storage_number,@storage_number_min,@storage_number_max)
    end
  end
  
end

module DataManager
  
  class <<self; alias load_game_shared_storage load_game; end
  def self.load_game(index)
    load_game_shared_storage(index)
    ADIK::SHARED_STORAGE.load_storage
  end
  
  class <<self; alias save_game_without_rescue_sharedstorage save_game_without_rescue; end
  def self.save_game_without_rescue(index)
    save_game_without_rescue_sharedstorage(index)
    ADIK::SHARED_STORAGE.save_storage
    return true
  end
  
end

module SceneManager
  
  def self.open_shared_storage(number,limit=nil)
    @stack.push(@scene)
    @scene = Scene_SharedStorage.new
    $shared_storage_number = number
    @scene.storage_number_min = number
    @scene.storage_number_max = limit
  end
  
  def self.next_storage(number,min,max)
    #doesn't add the last scene to stack and that
    #is just the old storage scene
    @scene = Scene_SharedStorage.new
    $shared_storage_number = number
    @scene.storage_number_min = min
    @scene.storage_number_max = max
  end
  
end