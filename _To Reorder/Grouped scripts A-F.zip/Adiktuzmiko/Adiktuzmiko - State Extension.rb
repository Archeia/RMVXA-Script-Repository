=begin
 ==============================================================================

 State Extension v1.00
 by AdiktuzMiko
 --- Date Created: 03/06/2014
 --- Last Date Updated: 03/06/2014
 --- Level: Easy

 ==============================================================================
 Overview
 ==============================================================================

 This script provides the ability to run RGSS3 methods/formulas during the
 adding and removing of states
 
 These can be used for: 
 
 actors/classes/weapons/armors/states/enemies
 
 Actors - affects all state application/removal on the actor
 Classes - affects all state application/removal on the class
 Weapons/Armors - affects all state application/removal on the actor that is
                  equipped with the item
 Enemies - affects all state application/removal on the enemy
 States - affects all state application/removal of the state
 
 ==============================================================================
 Set-Up
 ==============================================================================
 
 Just put this script into a blank slot above main but below materials
 (see compatibility section) and start tagging and making your own formulas
 
 ==============================================================================
 Method flow
 ==============================================================================

 This is the normal flow of the custom methods based on the default set-up
 
 State
 Actor
 Class
 Equips
 Enemiy
 
 ==============================================================================
 Tags
 ==============================================================================
 
 -------------------------------------------------------------------
 For apply
 -------------------------------------------------------------------
 <start_state_ext>
   formula
 <end_state_ext>
 
 -------------------------------------------------------------------
 For removal
 -------------------------------------------------------------------
 <start_unstate_ext>
   formula
 <end_unstate_ext>

 Use self to denote the actor/enemy that in which the state is applied/removed
 Use state_id to denote the ID of the state being applied/removed
 
 ==============================================================================
 Compatibility
 ==============================================================================

 This script aliases Game_Battlers's add_new_state and remove_state methods
 So put it below any script that overwrites those
 
 ==============================================================================
 Terms and Conditions
 ==============================================================================

 View it here: http://lescripts.wordpress.com/terms-and-conditions/
 
 ==============================================================================
=end

# ==============================================================================
# DO NOT EDIT BELOW THIS LINE
# ==============================================================================

module ADIK
  module STATE_EXTENSION
    STATE = /<start_state_ext>(.*)<end_state_ext>/m
    UNSTATE = /<start_unstate_ext>(.*)<end_unstate_ext>/m
  end
end

class RPG::BaseItem

 def load_state_extension_formula
    @state_extension_formula = ""
    if self.note =~ ADIK::STATE_EXTENSION::STATE
      @state_extension_formula = $1.to_s
    end
    return @state_extension_formula 
  end
  
  def state_extension_formula
    return @state_extension_formula.nil? ? load_state_extension_formula : @state_extension_formula 
  end
  
  def load_unstate_extension_formula
    @unstate_extension_formula = ""
    if self.note =~ ADIK::STATE_EXTENSION::UNSTATE
      @unstate_extension_formula = $1.to_s
    end
    return @unstate_extension_formula 
  end
  
  def unstate_extension_formula
    return @unstate_extension_formula.nil? ? load_unstate_extension_formula : @unstate_extension_formula 
  end
  
end

class Game_Battler
  
  alias add_new_state_extension add_new_state
  def add_new_state(state_id)
    add_new_state_extension(state_id)
    eval($data_states[state_id].state_extension_formula)
    if self.actor?
      eval(self.actor.state_extension_formula)
      eval(self.class.state_extension_formula)
      self.equips.each do |equip|
        next if equip.nil?
        eval(equip.state_extension_formula)
      end
    else
      eval(self.enemy.state_extension_formula)
    end
    refresh
  end
  
  alias remove_state_extension remove_state
  def remove_state(state_id)
    return unless state?(state_id)
    remove_state_extension(state_id)
    eval($data_states[state_id].unstate_extension_formula)
    if self.actor?
      eval(self.actor.unstate_extension_formula)
      eval(self.class.unstate_extension_formula)
      self.equips.each do |equip|
        next if equip.nil?
        eval(equip.unstate_extension_formula)
      end
    else
      eval(self.enemy.unstate_extension_formula)
    end
    refresh
  end
  
end