#==============================================================================
# 
# Slip Damage EX v1.06
# by AdiktuzMiko
# --- Date Created: 06/02/2013
# --- Last Date Updated: 10/23/2014
# --- Level: Easy
#
# Basically it allows you to give more control over slip damage values.
# Right now, slip damage is done via negative regeneration, which is
# only based on max hp/mp.
#
# With this script, you can add slip damage to equipments and states and
# have more control over the amount of damage.
#
# This script supports slip damage to HP, MP and TP
#
# You can also set different values for battle and map slip damages
#
# You can also define two behaviors for slip damage calculation
# -Damage is only calculated when the state is added
# -Damage is calculated every time it will be dealt
#
# If you have the ElementsEX script, you can also make slip damages have 
# an element, which makes it affected by the elemental defense of the
# afflicted unit. The element only works for the hp slip damages.
#          
# If you have Yanfly's element pop up + my Element's EX script, battle hp slip
# damages will now show correct element color and weakness/resistance rates
#
# Take note that the damage/regeneration that will show in battle if you
# have a damage pop-up screen will be the total of the individual 
# slip damages that your battler might have.
#
#==============================================================================
#   ++ Notetags ++
#==============================================================================
#
# These tags goes into weapons, armors and states.
#
# To assign element to slip_damage (Requires: Elements EX script)
#
# <slip_element x>
#     x => element id
#
# Note: 1) The element is only applied to hp slip damage
#       2) If you have element pop up by Yanfly, the pop-up for hp slip damage
#          will still be white/green in color no matter what element you put.
#
# If you want to use the caster's info for the formula, use:
# 
# a.xx 
# 	xx => actor/battler info like hp, mhp, cri etc
#
# Note: -Caster data is not advisable to be used for map slip damages
#       -Using caster data for updating damages might cause errors in cases
#        like if the caster is removed from the game during the duration of
#        the state so unless you're sure that it won't happen, better just
#        use them for non-updating damages
#
# If you want to use the affected battler's info for the formula, use:
# 
# b.xx 
# 	xx => actor/battler info like hp, mhp, cri etc
# 
# You can also retrieve data about the state itself using the variable: state
# and about the equipment using the variable: equip
#
# state variable will only work for state slip damages and equip variable will only work for equip slip 
# damages...
#
# Positive value = damage
# Negative value = regeneration
#
# The following tags are for updating damages
# -Damages are calculated every time that it will be
#  dealt
#
# Put this tag to denote the start of a custom formula
#
# <U_SLIP_X_START>
#     x => HP, MP or TP
#
# Put this tag to denote the end of a custom formula
#
# <U_SLIP_X_END>
#     x => HP, MP or TP
#
# For slip damages that should happen on the map
#
# Put this tag to denote the start of a custom formula
#
# <U_SLIP_X_MAP_START>
#     x => HP, MP or TP
#
# Put this tag to denote the end of a custom formula
#
# <U_SLIP_X_MAP_END>
#     x => HP, MP or TP
#       
# The following tags are for non-updating damages
# -Damages are calculated only upon the time that
#  the states are inflicted
# -For states only
#
# Put this tag to denote the start of a custom formula
#
# <SLIP_X_START>
#     x => HP, MP or TP
#
# Put this tag to denote the end of a custom formula
#
# <SLIP_X_END>
#     x => HP, MP or TP
#
# For slip damages that should happen on the map
#
# Put this tag to denote the start of a custom formula
#
# <SLIP_X_MAP_START>
#     x => HP, MP or TP
#
# Put this tag to denote the end of a custom formula
#
# <SLIP_X_MAP_END>
#     x => HP, MP or TP
#       
# Example:
#
# <SLIP_MP_START>
#  -b.mmp
# <SLIP_MP_END>
#
# => This will cause the unit to regenerate its max mp per turn in battle
#
# Example:
#
# <SLIP_HP_START>
#  (a.atk + a.mat)
# <SLIP_HP_END>
#
# => This will cause the unit to get damaged equal to the caster's attack + magic attack
#
# <U_SLIP_HP_START>
#  -b.hp*0.1
# <U_SLIP_HP_END>
#
# => This will cause the unit to get regenerate 10% of his hp every turn
#
# <SLIP_HP_START>
#  -b.hp*0.1
# <SLIP_HP_END>
#
# => This will cause the unit to get regenerate 10% of his current hp 
#    (during application of state) per turn
#
# <SLIP_HP_START>
#  (a.actor? 200 : 100)
# <SLIP_HP_END>
#
# => This will cause the unit to get damaged by 200 is the cause is an actor, 100 if not
#
# Note: The slip damage values per object are additive for battle hp slips.
#
# NOTICE: To be safe, enclose the formula in parenthesis
#
#==============================================================================
#   ++ Installation ++
#==============================================================================
# Install this script in the Materials section in your project's
# script editor and start tagging.
#
# Modify the max damage amounts below in case you want to have a damage cap.
#
#==============================================================================
#   ++ Compatibility ++
#==============================================================================
# This script aliases the following default VXA methods:
#
#     DataManager: Load_Database
#     Game_Battler: regenerate_hp, regenerate_mp, regenerate_tp
#
# This script is tested and is working with Yanfly's Battle Engine
#
#==============================================================================
#   ++ Terms and Conditions ++
#==============================================================================
#
# Read this: http://lescripts.wordpress.com/terms-and-conditions/
#
#==============================================================================

$imported = {} if $imported.nil?
$imported["SlipDamageEX"] = true

#--------------------------------------------------------------------------
# ? module Adiktuz
#--------------------------------------------------------------------------
module Adiktuz
  #--------------------------------------------------------------------------
  # ? module SlipDamageEx
  #--------------------------------------------------------------------------
  module SlipDamageEx
    #The max damage that can be done by slip damages dealt
    #using this script, does not affect slip damages
    #done through the traits
    #You can use any formula that RGSS3 can process
    #Set to nil for unlimited damage
    MAX_HP_DAMAGE = nil #example: if you set it to "mhp", hp slip damages
                        #won't exceed the unit's max hp
    MAX_MP_DAMAGE = nil #example: if you set it to "mmp", mp slip damages
                        #won't exceed the unit's max mp
    MAX_TP_DAMAGE = nil #example: if you set it to "mtp", tp slip damages
                        #won't exceed the unit's max tp
    
    #Note: If you set a postive max damage, then negative slip damages (regen)
    #      can be of any value since they are negative.
    
    #Notetags used by the script
    #Do not edit
    #Seriously, don't edit anything below this line
    #Don't even view coz you might accidentally change something
    SLIP_ELEMENT = /<slip_element (.*)>/i
    SLIP_HP_BEGIN = /<(?:SLIP_HP_START)>/i
    SLIP_HP_END = /<(?:SLIP_HP_END)>/i 
    SLIP_MP_BEGIN = /<(?:SLIP_MP_START)>/i
    SLIP_MP_END = /<(?:SLIP_MP_END)>/i
    SLIP_TP_BEGIN = /<(?:SLIP_TP_START)>/i
    SLIP_TP_END = /<(?:SLIP_TP_END)>/i
    SLIP_HP_MAP_BEGIN = /<(?:SLIP_HP_MAP_START)>/i
    SLIP_HP_MAP_END = /<(?:SLIP_HP_MAP_END)>/i 
    SLIP_MP_MAP_BEGIN = /<(?:SLIP_MP_MAP_START)>/i
    SLIP_MP_MAP_END = /<(?:SLIP_MP_MAP_END)>/i
    SLIP_TP_MAP_BEGIN = /<(?:SLIP_TP_MAP_START)>/i
    SLIP_TP_MAP_END = /<(?:SLIP_TP_MAP_END)>/i
    U_SLIP_HP_BEGIN = /<(?:U_SLIP_HP_START)>/i
    U_SLIP_HP_END = /<(?:U_SLIP_HP_END)>/i 
    U_SLIP_MP_BEGIN = /<(?:U_SLIP_MP_START)>/i
    U_SLIP_MP_END = /<(?:U_SLIP_MP_END)>/i
    U_SLIP_TP_BEGIN = /<(?:U_SLIP_TP_START)>/i
    U_SLIP_TP_END = /<(?:U_SLIP_TP_END)>/i
    U_SLIP_HP_MAP_BEGIN = /<(?:U_SLIP_HP_MAP_START)>/i
    U_SLIP_HP_MAP_END = /<(?:U_SLIP_HP_MAP_END)>/i 
    U_SLIP_MP_MAP_BEGIN = /<(?:U_SLIP_MP_MAP_START)>/i
    U_SLIP_MP_MAP_END = /<(?:U_SLIP_MP_MAP_END)>/i
    U_SLIP_TP_MAP_BEGIN = /<(?:U_SLIP_TP_MAP_START)>/i
    U_SLIP_TP_MAP_END = /<(?:U_SLIP_TP_MAP_END)>/i
    
  end #module SlipDamageEx
end #module Adiktuz

#==============================================================================
# ? DataManager
#==============================================================================

module DataManager
  
  #--------------------------------------------------------------------------
  # alias method: load_database
  #--------------------------------------------------------------------------
  class <<self; alias load_database_sdex load_database; end
  def self.load_database
    load_database_sdex
    load_notetags_sdex
  end
  
  #--------------------------------------------------------------------------
  # new method: load_notetags_eds
  #--------------------------------------------------------------------------
  def self.load_notetags_sdex
    groups = [$data_weapons, $data_armors, $data_states]
    for group in groups
      for obj in group
        next if obj.nil?
        obj.load_notetags_sdex
      end
    end
  end
  
end # DataManager

#===============================================================================
# ? class RPG::BaseItem
#===============================================================================

class RPG::BaseItem
  
  #---------------------------------------------------------------------------
  # public instance Variables
  #---------------------------------------------------------------------------
  attr_accessor :slip_hp_prog_eval
  attr_accessor :slip_mp_prog_eval
  attr_accessor :slip_tp_prog_eval
  attr_accessor :slip_hp_map_prog_eval
  attr_accessor :slip_mp_map_prog_eval
  attr_accessor :slip_tp_map_prog_eval
  attr_accessor :slip_hp_eval
  attr_accessor :slip_mp_eval
  attr_accessor :slip_tp_eval
  attr_accessor :slip_hp_map_eval
  attr_accessor :slip_mp_map_eval
  attr_accessor :slip_tp_map_eval
  attr_accessor :slip_element

  
  #--------------------------------------------------------------------------
  # common cache : load_notetags_sdex
  #--------------------------------------------------------------------------
  def load_notetags_sdex
    @slip_element = 0
    slip_hp_start = false
    slip_mp_start = false
    slip_tp_start = false
    slip_hp_map_start = false
    slip_mp_map_start = false
    slip_tp_map_start = false
    slip_hp_prog_start = false
    slip_mp_prog_start = false
    slip_tp_prog_start = false
    slip_hp_map_prog_start = false
    slip_mp_map_prog_start = false
    slip_tp_map_prog_start = false
    self.note.split(/[\r\n]+/).each do |line|
      case line
      when Adiktuz::SlipDamageEx::SLIP_ELEMENT
        @slip_element = $1.to_i
      when Adiktuz::SlipDamageEx::SLIP_HP_BEGIN
        slip_hp_start = true
      when Adiktuz::SlipDamageEx::SLIP_HP_END
        slip_hp_start = false 
      when Adiktuz::SlipDamageEx::SLIP_MP_BEGIN
        slip_mp_start = true
      when Adiktuz::SlipDamageEx::SLIP_MP_END
        slip_mp_start = false 
      when Adiktuz::SlipDamageEx::SLIP_TP_BEGIN
        slip_tp_start = true
      when Adiktuz::SlipDamageEx::SLIP_TP_END
        slip_tp_start = false 
      when Adiktuz::SlipDamageEx::SLIP_HP_MAP_BEGIN
        slip_hp_map_start = true
      when Adiktuz::SlipDamageEx::SLIP_HP_MAP_END
        slip_hp_map_start = false 
      when Adiktuz::SlipDamageEx::SLIP_MP_MAP_BEGIN
        slip_mp_map_start = true
      when Adiktuz::SlipDamageEx::SLIP_MP_MAP_END
        slip_mp_map_start = false 
      when Adiktuz::SlipDamageEx::SLIP_TP_MAP_BEGIN
        slip_tp_map_start = true
      when Adiktuz::SlipDamageEx::SLIP_TP_MAP_END
        slip_tp_map_start = false 
      when Adiktuz::SlipDamageEx::U_SLIP_HP_BEGIN
        slip_hp_prog_start = true
      when Adiktuz::SlipDamageEx::U_SLIP_HP_END
        slip_hp_prog_start = false 
      when Adiktuz::SlipDamageEx::U_SLIP_MP_BEGIN
        slip_mp_prog_start = true
      when Adiktuz::SlipDamageEx::U_SLIP_MP_END
        slip_mp_prog_start = false 
      when Adiktuz::SlipDamageEx::U_SLIP_TP_BEGIN
        slip_tp_prog_start = true
      when Adiktuz::SlipDamageEx::U_SLIP_TP_END
        slip_tp_prog_start = false 
      when Adiktuz::SlipDamageEx::U_SLIP_HP_MAP_BEGIN
        slip_hp_map_prog_start = true
      when Adiktuz::SlipDamageEx::U_SLIP_HP_MAP_END
        slip_hp_map_prog_start = false 
      when Adiktuz::SlipDamageEx::U_SLIP_MP_MAP_BEGIN
        slip_mp_map_prog_start = true
      when Adiktuz::SlipDamageEx::U_SLIP_MP_MAP_END
        slip_mp_map_prog_start = false 
      when Adiktuz::SlipDamageEx::U_SLIP_TP_MAP_BEGIN
        slip_tp_map_prog_start = true
      when Adiktuz::SlipDamageEx::U_SLIP_TP_MAP_END
        slip_tp_map_prog_start = false
      else
        @slip_hp_prog_eval = "" if slip_hp_prog_start && @slip_hp_prog_eval.nil?
        @slip_mp_prog_eval = "" if slip_mp_prog_start && @slip_mp_prog_eval.nil?
        @slip_tp_prog_eval = "" if slip_tp_prog_start && @slip_tp_prog_eval.nil?
        @slip_hp_prog_eval += line.to_s if slip_hp_prog_start
        @slip_mp_prog_eval += line.to_s if slip_mp_prog_start
        @slip_tp_prog_eval += line.to_s if slip_tp_prog_start
        @slip_hp_map_prog_eval = "" if slip_hp_map_prog_start && @slip_hp_map_prog_eval.nil?
        @slip_mp_map_prog_eval = "" if slip_mp_map_prog_start && @slip_mp_map_prog_eval.nil?
        @slip_tp_map_prog_eval = "" if slip_tp_map_prog_start && @slip_tp_map_prog_eval.nil?
        @slip_hp_map_prog_eval += line.to_s if slip_hp_map_prog_start
        @slip_mp_map_prog_eval += line.to_s if slip_mp_map_prog_start
        @slip_tp_map_prog_eval += line.to_s if slip_tp_map_prog_start
        @slip_hp_eval = "" if slip_hp_start && @slip_hp_eval.nil?
        @slip_mp_eval = "" if slip_mp_start && @slip_mp_eval.nil?
        @slip_tp_eval = "" if slip_tp_start && @slip_tp_eval.nil?
        @slip_hp_eval += line.to_s if slip_hp_start
        @slip_mp_eval += line.to_s if slip_mp_start
        @slip_tp_eval += line.to_s if slip_tp_start
        @slip_hp_map_eval = "" if slip_hp_map_start && @slip_hp_map_eval.nil?
        @slip_mp_map_eval = "" if slip_mp_map_start && @slip_mp_map_eval.nil?
        @slip_tp_map_eval = "" if slip_tp_map_start && @slip_tp_map_eval.nil?
        @slip_hp_map_eval += line.to_s if slip_hp_map_start
        @slip_mp_map_eval += line.to_s if slip_mp_map_start
        @slip_tp_map_eval += line.to_s if slip_tp_map_start
      end
    end
  end
  
end # << RPG::BaseItem

class Game_BattlerBase
  
  #--------------------------------------------------------------------------
  # ? new method: make_slip_popup
  #--------------------------------------------------------------------------
  def make_slip_popup(value,rate,element)
    flags = []
    return if value == 0
    if rate > 1.0
      text = YEA::BATTLE::POPUP_SETTINGS[:weakpoint]
      rules = "WEAK_ELE"
      flags.push("weakness")
    elsif rate == 0.0
      text = YEA::BATTLE::POPUP_SETTINGS[:immune]
      rules = "IMMU_ELE"
      flags.push("immune")
    elsif rate < 0.0
      text = YEA::BATTLE::POPUP_SETTINGS[:absorbed]
      rules = "ABSB_ELE"
      flags.push("absorbed")
    else
      text = YEA::BATTLE::POPUP_SETTINGS[:resistant]
      rules = "REST_ELE"
      flags.push("resistant")
    end
    create_popup(text, rules, flags) unless rate == 1.0
    value = value*-1
    value = value.to_i
    if value > 0 
      value = "+" + value.to_s + " HP"
    else 
      value = value.to_s + " HP"
    end
    
    element > 0 ? create_popup(value, "ELEMENT_" + element.to_s) : create_popup(value, "HP_DMG")
  end
  
end

#--------------------------------------------------------------------------
# ? class Game_Battler
#--------------------------------------------------------------------------

class Game_Battler < Game_BattlerBase
  
  #--------------------------------------------------------------------------
  # ? new method: clear_slip_states
  #--------------------------------------------------------------------------
  def clear_slip_states
    @state_cause = {}
    @slip_hp_damage = [0] * $data_states.size
    @slip_mp_damage = [0] * $data_states.size
    @slip_tp_damage = [0] * $data_states.size
    @slip_hp_map_damage = [0] * $data_states.size
    @slip_mp_map_damage = [0] * $data_states.size
    @slip_tp_map_damage = [0] * $data_states.size
  end
  
  #--------------------------------------------------------------------------
  # ? alias method: add_state
  #--------------------------------------------------------------------------
  alias slip_add_state add_state
  def add_state(state_id)
    slip_add_state(state_id)
    clear_slip_states if @state_cause == nil
    @state_cause[state_id] = @cause
    a = @cause
    b = self
    state = $data_states[state_id]
    @slip_hp_damage[state_id] = eval(state.slip_hp_eval) unless state.slip_hp_eval.nil?
    @slip_mp_damage[state_id] = eval(state.slip_mp_eval) unless state.slip_mp_eval.nil?
    @slip_tp_damage[state_id] = eval(state.slip_tp_eval) unless state.slip_tp_eval.nil?
    @slip_hp_map_damage[state_id] = eval(state.slip_hp_map_eval) unless state.slip_hp_map_eval.nil? 
    @slip_mp_map_damage[state_id] = eval(state.slip_mp_map_eval) unless state.slip_mp_map_eval.nil? 
    @slip_tp_map_damage[state_id] = eval(state.slip_tp_map_eval) unless state.slip_tp_map_eval.nil? 
  end
  
  #--------------------------------------------------------------------------
  # ? alias method: item_effect_add_state_attack
  #--------------------------------------------------------------------------
  alias slip_item_effect_add_state_attack item_effect_add_state_attack
  def item_effect_add_state_attack(user, item, effect)
    @cause = user
    slip_item_effect_add_state_attack(user, item, effect)
  end
  #--------------------------------------------------------------------------
  # ? alias method: item_effect_add_state_normal
  #--------------------------------------------------------------------------
  alias slip_item_effect_add_state_normal item_effect_add_state_normal
  def item_effect_add_state_normal(user, item, effect)
    @cause = user
    slip_item_effect_add_state_normal(user, item, effect)
  end
  
  #--------------------------------------------------------------------------
  # ? alias method: remove_state
  #--------------------------------------------------------------------------
  alias slip_remove_state remove_state
  def remove_state(state_id)
    slip_remove_state(state_id)
    clear_slip_states if @state_cause == nil
    @state_cause[state_id] = nil
    @slip_hp_damage[state_id] = 0
    @slip_mp_damage[state_id] = 0
    @slip_tp_damage[state_id] = 0
    @slip_hp_map_damage[state_id] = 0
    @slip_mp_map_damage[state_id] = 0 
    @slip_tp_map_damage[state_id] = 0
  end
  
  #--------------------------------------------------------------------------
  # ? new method: get_rate_slip_ex
  #--------------------------------------------------------------------------
  def get_rate_slip_ex(obj)
    obj.slip_element > 0 ? 1.0 - get_def_element_multi(obj.slip_element) : 1.0
  end
  
  #--------------------------------------------------------------------------
  # ? new method: regenerate_hp_battle
  #--------------------------------------------------------------------------
  def regenerate_hp_battle
    damage = 0
    if actor?
      for equip in equips
        next if equip.nil?
        b = self
        damage += eval(equip.slip_hp_prog_eval) unless equip.slip_hp_prog_eval.nil?
      end
      for state in states
        next if state.nil?
        damage += @slip_hp_damage[state.id]
        a = @state_cause[state.id]
        b = self
        damage += eval(state.slip_hp_prog_eval) unless state.slip_hp_prog_eval.nil?
      end
    elsif enemy?
      for state in states
        next if state.nil?
        damage += @slip_hp_damage[state.id]
        a = @state_cause[state.id]
        b = self
        damage += eval(state.slip_hp_prog_eval) unless state.slip_hp_prog_eval.nil?
      end
    end
    return damage
  end
  
  #--------------------------------------------------------------------------
  # ? new method: regenerate_hp_battle_element
  #--------------------------------------------------------------------------
  def regenerate_hp_battle_element
    damage = 0
    if actor?
      for equip in equips
        next if equip.nil?
        damage = 0
        rate = get_rate_slip_ex(equip)
        b = self
        damage += rate*eval(equip.slip_hp_prog_eval) unless equip.slip_hp_prog_eval.nil?
        damage -= get_def_element_bonus(equip.slip_element)
        unless Adiktuz::SlipDamageEx::MAX_HP_DAMAGE.nil? then
          slip_max = eval(Adiktuz::SlipDamageEx::MAX_HP_DAMAGE)
          damage = [damage,slip_max].min.to_i  
          @result.hp_damage = damage
        else
          @result.hp_damage = damage.to_i  
        end
        self.hp -= @result.hp_damage
        self.make_slip_popup(damage,rate,equip.slip_element) if $imported["YEA-BattleEngine"]
      end
      for state in states
        next if state.nil?
        damage = 0
        rate = get_rate_slip_ex(state)
        damage += rate*@slip_hp_damage[state.id]
        a = @state_cause[state.id]
        b = self
        damage += rate*eval(state.slip_hp_prog_eval) unless state.slip_hp_prog_eval.nil?
        damage -= get_def_element_bonus(state.slip_element)
        unless Adiktuz::SlipDamageEx::MAX_HP_DAMAGE.nil? then
          slip_max = eval(Adiktuz::SlipDamageEx::MAX_HP_DAMAGE)
          damage = [damage,slip_max].min.to_i  
          @result.hp_damage = damage
        else
          @result.hp_damage = damage.to_i  
        end
        self.hp -= @result.hp_damage
        self.make_slip_popup(damage,rate,state.slip_element) if $imported["YEA-BattleEngine"]
      end
    elsif enemy?
      for state in states
        next if state.nil?
        damage = 0
        rate = get_rate_slip_ex(state)
        damage += rate*@slip_hp_damage[state.id]
        a = @state_cause[state.id]
        b = self
        damage += rate*eval(state.slip_hp_prog_eval) unless state.slip_hp_prog_eval.nil?
        damage -= get_def_element_bonus(state.slip_element)
        unless Adiktuz::SlipDamageEx::MAX_HP_DAMAGE.nil? then
          slip_max = eval(Adiktuz::SlipDamageEx::MAX_HP_DAMAGE)
          damage = [damage,slip_max].min.to_i  
          @result.hp_damage = damage
        else
          @result.hp_damage = damage.to_i  
        end
        self.hp -= @result.hp_damage
        self.make_slip_popup(damage,rate,state.slip_element) if $imported["YEA-BattleEngine"]
      end
    end
    @result.hp_damage = 0
  end
  
  #--------------------------------------------------------------------------
  # ? new method: regenerate_hp_map
  #--------------------------------------------------------------------------
  def regenerate_hp_map
    return 0 if enemy?
    damage = 0
    if actor?
      for equip in equips
        next if equip.nil?
        b = self
        damage += eval(equip.slip_hp_map_prog_eval) unless equip.slip_hp_map_prog_eval.nil?
      end
      for state in states
        next if state.nil?
        damage += @slip_hp_map_damage[state.id]
        a = @state_cause[state.id]
        b = self
        damage += eval(state.slip_hp_map_prog_eval) unless state.slip_hp_map_prog_eval.nil?
      end
    end
    return damage
  end
  
  #--------------------------------------------------------------------------
  # ? new method: regenerate_hp_map_element
  #--------------------------------------------------------------------------
  def regenerate_hp_map_element
    return 0 if enemy?
    damage = 0
    if actor?
      for equip in equips
        next if equip.nil?
        rate = get_rate_slip_ex(equip)
        b = self
        damage += rate*eval(equip.slip_hp_map_prog_eval) unless equip.slip_hp_map_prog_eval.nil?
      end
      for state in states
        next if state.nil?
        rate = get_rate_slip_ex(state)
        damage += rate*@slip_hp_map_damage[state.id]
        a = @state_cause[state.id]
        b = self
        damage += rate*eval(state.slip_hp_map_prog_eval) unless state.slip_hp_map_prog_eval.nil?
      end
    end
    return damage
  end
  
  #--------------------------------------------------------------------------
  # ? alias method: regenerate_hp
  #--------------------------------------------------------------------------
  alias regenerate_hp_sdex regenerate_hp
  def regenerate_hp
    regenerate_hp_sdex
    damage = 0
    if $game_party.in_battle then
      if $imported["ElementEX"]
        regenerate_hp_battle_element
        return
      else
        damage = regenerate_hp_battle 
      end
    else
      damage = $imported["ElementEX"] ? regenerate_hp_map_element : regenerate_hp_map
    end
    perform_map_damage_effect if damage > 0
    unless Adiktuz::SlipDamageEx::MAX_HP_DAMAGE.nil? then
      slip_max = eval(Adiktuz::SlipDamageEx::MAX_HP_DAMAGE)
      @result.hp_damage = [damage,slip_max].min.to_i  
    else
      @result.hp_damage = damage.to_i  
    end
    self.hp -= @result.hp_damage
    self.make_slip_popup(@result.hp_damage,1.0,0) if $imported["YEA-BattleEngine"]
  end #regenerate_hp
  
  #--------------------------------------------------------------------------
  # ? new method: regenerate_mp_battle
  #--------------------------------------------------------------------------
  def regenerate_mp_battle
    return 0 if enemy?
    damage = 0
    if actor?
      for equip in equips
        next if equip.nil?
        b = self
        damage += eval(equip.slip_mp_prog_eval) unless equip.slip_mp_prog_eval.nil?
      end
      for state in states
        next if state.nil?
        damage += @slip_mp_damage[state.id]
        a = @state_cause[state.id]
        b = self
        damage += eval(state.slip_mp_prog_eval) unless state.slip_mp_prog_eval.nil?
      end
    elsif enemy?
      for state in states
        next if state.nil?
        damage += @slip_mp_damage[state.id]
        a = @state_cause[state.id]
        b = self
        damage += eval(state.slip_mp_prog_eval) unless state.slip_mp_prog_eval.nil?
      end
    end
    return damage
  end
  
  #--------------------------------------------------------------------------
  # ? new method: regenerate_mp_map
  #--------------------------------------------------------------------------
  def regenerate_mp_map
    damage = 0
    if actor?
      for equip in equips
        next if equip.nil?
        b = self
        damage += eval(equip.slip_mp_map_prog_eval) unless equip.slip_mp_map_prog_eval.nil?
      end
      for state in states
        next if state.nil?
        damage += @slip_mp_map_damage[state.id]
        a = @state_cause[state.id]
        b = self
        damage += eval(state.slip_mp_map_prog_eval) unless state.slip_mp_map_prog_eval.nil?
      end
    end
    return damage
  end
  
  
  #--------------------------------------------------------------------------
  # ? alias method: regenerate_mp
  #--------------------------------------------------------------------------
  alias regenerate_mp_sdex regenerate_mp
  def regenerate_mp
    regenerate_mp_sdex
    damage = 0
    damage = $game_party.in_battle ? regenerate_mp_battle : regenerate_mp_map
    perform_map_damage_effect if damage > 0
    unless Adiktuz::SlipDamageEx::MAX_MP_DAMAGE.nil? then
      slip_max = eval(Adiktuz::SlipDamageEx::MAX_MP_DAMAGE)
      @result.mp_damage = [damage,slip_max].min.to_i  
    else
      @result.mp_damage = damage.to_i  
    end
    self.mp -= @result.mp_damage
  end #regenerate_mp
  
  #--------------------------------------------------------------------------
  # ? new method: regenerate_tp_battle
  #--------------------------------------------------------------------------
  def regenerate_tp_battle
    damage = 0
    if actor?
      for equip in equips
        next if equip.nil?
        b = self
        damage += eval(equip.slip_tp_prog_eval) unless equip.slip_tp_prog_eval.nil?
      end
      for state in states
        next if state.nil?
        damage += @slip_tp_damage[state.id]
        a = @state_cause[state.id]
        b = self
        damage += eval(state.slip_tp_prog_eval) unless state.slip_tp_prog_eval.nil?
      end
    end
    return damage
  end
  
  #--------------------------------------------------------------------------
  # ? new method: regenerate_tp_map
  #--------------------------------------------------------------------------
  def regenerate_tp_map
    damage = 0
    if actor?
      for equip in equips
        next if equip.nil?
        b = self
        damage += eval(equip.slip_tp_map_prog_eval) unless equip.slip_tp_map_prog_eval.nil?
      end
      for state in states
        next if state.nil?
        damage += @slip_tp_map_damage[state.id]
        a = @state_cause[state.id]
        b = self
        damage += eval(state.slip_tp_map_prog_eval) unless state.slip_tp_map_prog_eval.nil?
      end
    end
    return damage
  end
  
  #--------------------------------------------------------------------------
  # ? alias method: regenerate_tp
  #--------------------------------------------------------------------------
  alias regenerate_tp_sdex regenerate_tp
  def regenerate_tp
    return if enemy?
    regenerate_tp_sdex
    damage = 0
    damage = $game_party.in_battle ? regenerate_tp_battle : regenerate_tp_map
    perform_map_damage_effect if damage > 0
    unless Adiktuz::SlipDamageEx::MAX_TP_DAMAGE.nil? then
      slip_max = eval(Adiktuz::SlipDamageEx::MAX_TP_DAMAGE)
      @result.tp_damage = [damage,slip_max].min.to_i  
    else
      @result.tp_damage = damage.to_i  
    end
    self.tp -= @result.tp_damage
  end #regenerate_tp
  
end