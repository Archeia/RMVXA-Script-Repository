#==============================================================================
# 
# BattleBack_Seasons v1.0
# by AdiktuzMiko
# --- Date Created: 18/01/2013
# --- Last Date Updated: 18/01/2013
# --- Level: Easy
# Requires: n/a
# 
# Basically, this allows you to have different battlebacks in one map
# depending on seasons. Take note that this doesn't work on Battle Test.
#
#==============================================================================
 
#==============================================================================
# Aliased methods:
#
# battleback1_bitmap, battleback2_bitmap (both belongs to Spriteset_Battle)
#==============================================================================
 
#==============================================================================
# How To Install:
#
# Just put this anywhere before main and you're good to go.
#==============================================================================
 
#==============================================================================
# Compatibility:
#
# This script is made strictly for RPG Maker VX Ace. It is highly unlikely that
# it will run with RPG Maker VX without adjusting.
#
# As for compatibility with other scripts, it's compatible with YEA scripts. 
# I don't know for other scripts though. Though I don't think it would be
# incompatible with other scripts unless they overwrite the battleback creation
# at the start too.
#
# I don't think that this is compatible with my BattleBack_EX script.
#
#==============================================================================
 
#==============================================================================
# How To Use:
#
# 1)Set the game variable that sets the season
# 2)Create a battleback set at the BATTLEBACKSEASON_1 Hash, format is:
#   Key => [Season1,Season2 and so on...],
# 3)Do the same for BATTLEBACKSEASON_2 Hash
#   *BATTLEBACKSEASON_1 = the set of BattleBack1 images
#   *BATTLEBACKSEASON_2 = the set of BattleBack2 images
# 3)Set the battleback set to be used by maps via the SEASONMAP Hash, format is:
#   MapID => Key
#
# So now, if the value of the variable linked to SEASON_VAR is 1, it will use
# the battleback for Season1 and so on
#==============================================================================
 
module BattleBack_Season
  
  SEASON_VAR = 16
  
  BATTLEBACKSEASON_1 = {
  
  "Forest" => ["ForestWinter","ForestSpring","ForestSummer","ForestFall"],
  "Dirt" => ["DirtWinter","Dirt","Dirt","Dirt"],
  
  } #Do not remove
  
  BATTLEBACKSEASON_2 = {
  
  "Forest" => ["","","",""],
  "Dirt" => ["DirtWinter","Dirt","Dirt","Dirt"],
  
  }
  
  SEASONMAP = {
  
  14 => "Forest",
  15 => "Dirt",
  
  }
  
end #BattleBack_Season
 
#==============================================================================
# Do not touch anything below this line unless you know what you are doing.
#==============================================================================
 
class Spriteset_Battle
  
  alias battleback1_bitmap_seasons battleback1_bitmap
  def battleback1_bitmap
    if $BTEST #without this it bugs during battle test
      battleback1_bitmap_seasons
    else
      season = BattleBack_Season::SEASONMAP[$game_map.map_id]
      if season != nil then
        Cache.battleback1(BattleBack_Season::BATTLEBACKSEASON_1[season][$game_variables[BattleBack_Season::SEASON_VAR] - 1])
      elsif battleback1_name
        Cache.battleback1(battleback1_name)
      else
        create_blurry_background_bitmap
      end
    end
  end
  
  alias battleback2_bitmap_seasons battleback2_bitmap
  def battleback2_bitmap
    if $BTEST #without this it bugs during battle test
      battleback2_bitmap_seasons
    else
      season = BattleBack_Season::SEASONMAP[$game_map.map_id]
      if season != nil then
        Cache.battleback1(BattleBack_Season::BATTLEBACKSEASON_2[season][$game_variables[BattleBack_Season::SEASON_VAR] - 1])
      elsif battleback2_name
        Cache.battleback2(battleback2_name)
      else
        create_blurry_background_bitmap
      end
    end
  end
  
end #Spriteset_Battle