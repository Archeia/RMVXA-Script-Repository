#==============================================================================
# 
# Duplicate and Auto-Untint Events v1.00
# by AdiktuzMiko
# --- Date Created: 11/08/2013
# --- Last Date Updated: 11/08/2013
# --- Level: Easy
#
# Allows you to have events that doesn't get affected by screen tint commands
# and allows you to duplicate events from any map to another, and to also place
# these duplicate events on top of one another (useful for things like making
# 3+ layers of decorative events)
#
# Allows you to disable tinting of the character types (player,events,vehicles)
# automatically via regions
#
#==============================================================================
#   ++ How to use ++
#==============================================================================
#
# For making events unaffected by screen tints, simply make sure that it's name
# includes the string set below in the configuration (default: lights)
#
# To duplicate events, simply use this script call
#
# dup_event(mapid,eventid,x,y,view,z)
# 
# where:
#
# mapid = Map ID of the map from which the event will be copied from
# eventid = ID of the event to be copied
# x = X tile position on where to put the duplicated event
# y = Y tile position on where to put the duplicated event
# view = Viewport in which to spawn the duplicate event
#        (Set it to 2 or 3 if you want the events to be untinted without
#         having to need to use the untint string on it's name)
# z = Priority of the event
#     0 => Below Characters
#     1 => Same as characters
#     2 => Above characters
#     You can also use any arbitrary number to arrange your events in case
#     you will duplicate more than one event in a single tile
#
# Example:
# 
# dup_event(1,2,1,1,1,2.1)
# dup_event(1,1,1,1,1,2)
# 
# Since event 2's z is 2.1 and event 1's z is 2: Event 2 will be placed above
# Event 1 in-game
#
# To set-up the character types untint:
#
# Go to the configuration below and set hte untint region and delay
# then start setting your tiles to the right region
#
#==============================================================================
#   ++ Installation ++
#==============================================================================
# Install this script in the Materials section in your project's
# script editor and configure what should be in the name of event's that
# should be untinted (default: lights) and start using it
#
#==============================================================================
#   ++ Compatibility ++
#==============================================================================
# This script overwrites the following default VXA methods:
#
#     Spriteset_Map: create_characters
#     Game_CharacterBase: initialize
#
# and aliases the following methods:
#
#    Game_Event: initialize
#    Game_CharacterBase: update
#
#==============================================================================
#   ++ Terms and Conditions ++
#==============================================================================
#
# Read this: http://lescripts.wordpress.com/terms-and-conditions/
#
#==============================================================================
#   ++ Notes ++
#==============================================================================
#
# 1) Right now, I don't advise using the Duplicate function for events that
# interact with the player
#
# 2) As far as my tests go, the passability of the event in the lowest 
#    layer is the one used for the passability of that tile
#
# 3) The auto-untinting via regions doesn't work for duplicated events
#
#==============================================================================
$imported = {} if $imported.nil?
$imported["DupUntint-Adik"] = true


#======================================================================#
# CONFIGURATION
#======================================================================#
module ADIK
  module EVENTS
    #This sets what string your events' name should have if you want them
    #to be not affected by screen tints
    UNTINT = "lights"
    #Region ID in which all character classes will be untinted
    #Player,Follower,Events and vehicles
    UNTINT_REGION = 1
    #Frame delay between each untint check
    #Lower value = less delay = higher chance of lag
    FRAME_DELAY = 15
  end
end

=begin
#======================================================================#
DO NOT EDIT BELOW THIS LINE
#======================================================================#
=end 

class Game_Event
  
  attr_accessor :event
  attr_accessor :doodad
  attr_accessor :view
  attr_accessor :priority_type
  
  alias adik_init initialize
  def initialize(map_id, event)
    adik_init(map_id,event)
    @view = 1
  end
  
  def get_name
    return @event.name
  end
  
end

class Spriteset_Map
  
  def viewport(index)
    case index
      when 1
        return @viewport1
      when 2
        return @viewport2
      when 3
        return @viewport3
      end
  end
  
  def character_sprites 
    return @character_sprites 
  end
  
  def create_characters
    @character_sprites = []
    $game_map.events.values.each do |event|
      if event.get_name.include?(ADIK::EVENTS::UNTINT)
        @character_sprites.push(Sprite_Character.new(@viewport3, event))
      elsif event.doodad
        @character_sprites.push(Sprite_Character.new(viewport(event.view), event))
      elsif event.region_id == ADIK::EVENTS::UNTINT_REGION
        if event.view > 1
          @character_sprites.push(Sprite_Character.new(viewport(event.view), event))
        else
          @character_sprites.push(Sprite_Character.new(viewport(2), event))
        end
      else
        @character_sprites.push(Sprite_Character.new(@viewport1, event))
      end
    end
    $game_map.vehicles.each do |vehicle|
      if vehicle.region_id == ADIK::EVENTS::UNTINT_REGION
        @character_sprites.push(Sprite_Character.new(@viewport2, vehicle))
      else
        @character_sprites.push(Sprite_Character.new(@viewport1, vehicle))
      end
    end
    $game_player.followers.reverse_each do |follower|
      if follower.region_id == ADIK::EVENTS::UNTINT_REGION
        @character_sprites.push(Sprite_Character.new(@viewport2, follower))
      else
        @character_sprites.push(Sprite_Character.new(@viewport1, follower))
      end
    end
    if $game_player.region_id == ADIK::EVENTS::UNTINT_REGION
      @character_sprites.push(Sprite_Character.new(@viewport2, $game_player))
    else
      @character_sprites.push(Sprite_Character.new(@viewport1, $game_player))
    end
    @map_id = $game_map.map_id
  end
end

class Game_Interpreter

  def dup_event(mapid,eventid,x,y,view,z)
    $game_map.dup_event(mapid,eventid,x,y,view,z)
  end
  
end

class Game_Map
  def dup_event(mapid,eventid,x,y,view,z)
    @mapx = load_data(sprintf("Data/Map%03d.rvdata2", mapid))
    event = get_event(@mapx, eventid)
    key = @events.keys.max + 1
    @events[key] = Game_Event.new(@map_id, event)
    @events[key].view = view
    @events[key].priority_type = z
    @events[key].doodad = true
    @events[key].moveto(x,y)
    @events[key].update
    SceneManager.scene.spriteset.refresh_characters
    refresh
    update
  end
  
  def get_event(map, event_id)
    for events in map.events
      event = events[1]
      next if event.nil?
      return event if event.id == event_id
    end
    return nil
  end
end

class Scene_Map
  def spriteset
    return @spriteset
  end
end

class Game_CharacterBase
  
  attr_accessor :regionid
  attr_accessor :reg_count
  
  def initialize
    init_public_members
    init_private_members
    @regionid = 0
    @reg_count = 0
  end
  
  alias adik_update update
  def update
    adik_update
    @reg_count += 1
    if @reg_count == ADIK::EVENTS::FRAME_DELAY
      @reg_count = 0
    else
      return
    end
    if region_id != @regionid and self.character_name != ""
      @regionid = region_id
      SceneManager.scene.spriteset.refresh_characters
    end
  end
end