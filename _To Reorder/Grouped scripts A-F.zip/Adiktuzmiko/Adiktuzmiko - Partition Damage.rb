#==============================================================================
# 
# Partition Damage v1.10
# by AdiktuzMiko
# --- Date Created: 06/28/2013
# --- Last Date Updated: 01/21/2014
# --- Level: Easy
# --- Requires: 
#     Elements EX
# --- Optional: 
#     YEA Battle Engine + Element Popups
#
# Basically it allows you to have a percentage of your damage
# dealt as bonus damage having a different element.
#
# Example: I have a weapon that has a 10% partition damage property
#          of fire element. If I attack an enemy and deal 100 damage
#          then I will deal another 10 damage with the fire element
#
# Note: Partition damage does not affect slip damages
#
#==============================================================================
#   ++ Notetags ++
#==============================================================================
#
# These tags goes into Actors, Classes, Items, Skills, Weapons, Armors, Enemies
# and States
#
# <selfatkpart x:y>
# -> For skills and items
# -> Damage partition that only affects the skill/item that has this tag
#
# <atkpart x:y>
# -> Damage partition that affects all damage done
#
# x => Element ID of the element that you want the partition to have
# y => Percent of damage to deal as partition
# 
#==============================================================================
#   ++ Installation ++
#==============================================================================
# Install this script in the Materials section in your project's
# script editor.
#
#==============================================================================
#   ++ Compatibility ++
#==============================================================================
# This script aliases the following default VXA methods:
#
#     Game_Battler#adik_damage_extension
#    
# There are no default method overwrites.
#
# Place this under ElementsEX.
#
#==============================================================================
#   ++ Terms and Conditions ++
#==============================================================================
#
# Read this: http://lescripts.wordpress.com/terms-and-conditions/
#
#==============================================================================

$imported = {} if $imported.nil?
$imported["CriticalEX"] = true

module Adiktuz
  module PartitionDamage
    
    #Determines if partition damage will affect negative damages
    #which are normally, heals
    CAN_PARTITION_NEGATIVE = false
    
  #DO NOT EDIT BEYOND THIS POINT UNLESS YOU ARE SURE OF WHAT YOU ARE DOING!  
    ATK_PART = /<atkpart (.*):(.*)>/i
    SELF_ATK_PART = /<selfatkpart (.*):(.*)>/i
  end #PartitionDamage
end #Adiktuz


#===============================================================================
module DataManager
#===============================================================================

  #---------------------------------------------------------------------------
  # alias: load_database
  #---------------------------------------------------------------------------
  class << self; alias :load_unique_partition_adik :load_database; end
  def self.load_database
    load_unique_partition_adik
    load_unique_partition
  end
  #--------------------------------------------------------------------------
  # new method: load_elemental_control
  #--------------------------------------------------------------------------
  def self.load_unique_partition
    classes = [$data_weapons, $data_armors, $data_skills , $data_items,
               $data_actors , $data_classes, $data_enemies, $data_states ]
    for classe in classes
      for obj in classe
        next if obj.nil?
        obj.load_partition_adik
      end
    end
  end
  
end # DataManager

#===============================================================================
class RPG::BaseItem
#===============================================================================

  #---------------------------------------------------------------------------
  # public instance Variables
  #---------------------------------------------------------------------------
  attr_accessor :atk_partition
  attr_accessor :self_atk_partition
  
  #--------------------------------------------------------------------------
  # new method: load_partition_adik
  #--------------------------------------------------------------------------
  def load_partition_adik
    @atk_partition     = [0] * $data_system.elements.size
    @self_atk_partition  = [0] * $data_system.elements.size
    set_atk_partition
  end
  #--------------------------------------------------------------------------
  # common cache : set_atk_partition
  #--------------------------------------------------------------------------
  def set_atk_partition
    self.note.split(/[\r\n]+/).each do |line|
      case line
      when Adiktuz::PartitionDamage::ATK_PART
        @atk_partition[$1.to_i] = $2.to_f
      when Adiktuz::PartitionDamage::SELF_ATK_PART
        @self_atk_partition[$1.to_i] = $2.to_f
      end
    end
  end
  
end # << RPG::BaseItem

class Game_BattlerBase
  
  #--------------------------------------------------------------------------
  # ? new method: make_parition_popup
  #--------------------------------------------------------------------------
  def make_partition_popup(value,rate,element)
    flags = []
    return if value == 0
    if rate > 1.0
      text = YEA::BATTLE::POPUP_SETTINGS[:weakpoint]
      rules = "WEAK_ELE"
      flags.push("weakness")
    elsif rate == 0.0
      text = YEA::BATTLE::POPUP_SETTINGS[:immune]
      rules = "IMMU_ELE"
      flags.push("immune")
    elsif rate < 0.0
      text = YEA::BATTLE::POPUP_SETTINGS[:absorbed]
      rules = "ABSB_ELE"
      flags.push("absorbed")
    else
      text = YEA::BATTLE::POPUP_SETTINGS[:resistant]
      rules = "REST_ELE"
      flags.push("resistant")
    end
    create_popup(text, rules, flags) unless rate == 1.0
    value = value*-1
    value = value.to_s + " HP"
    value = value.to_i
    element > 0 ? create_popup(value, "ELEMENT_" + element.to_s) : create_popup(value, "HP_DMG")
  end
  
end #Game_BattlerBase

class Game_Battler < Game_BattlerBase
  
  #--------------------------------------------------------------------------
  # aliased method: adik_damage_extension
  #--------------------------------------------------------------------------
  alias bdex_adik_damage_extension adik_damage_extension
  def adik_damage_extension(user,item,damage)
    elements = Adiktuz::ElementEX::ELEMENTS.clone
    elements.each do |id|
      next if !Adiktuz::PartitionDamage::CAN_PARTITION_NEGATIVE and damage < 0
      part_damage = damage*item.self_atk_partition[id]
      if user.actor?
        part_damage += damage*user.actor.atk_partition[id]
        part_damage += damage*user.class.atk_partition[id] 
        for equip in user.equips
          next if equip.nil?
          part_damage += damage*equip.atk_partition[id] 
        end
        for state in user.states
          next if state.nil?
          part_damage += damage*state.atk_partition[id] 
        end
      elsif user.enemy? then
        part_damage += damage*user.enemy.atk_partition[id] 
        for state in user.states
          next if state.nil?
          part_damage += damage*state.atk_partition[id]
        end
      end
      next if part_damage == 0
      rate = 1.0
      rate += get_atk_element_multi(user,id) - get_def_element_multi(id)
      part_damage *= rate
      part_damage += get_atk_element_bonus(user,id) - get_def_element_bonus(id) 
      self.hp -= part_damage
      make_partition_popup(part_damage,rate,id) if $imported["YEA-BattleEngine"]
    end
    bdex_adik_damage_extension(user,item,damage)
  end
  
end #Game_Battler