=begin
======================================================
  
  SS Add-On: Total Item Limit v1.00
  by Adiktuzmiko                   
  
  Date Created: 09/27/2014
  Date Last Updated: 09/27/2014
  Requires: Shared Storage v2.10
  Difficulty: Easy
  
======================================================
 Overview
======================================================
 
 Allows the shared storages to have a limit based
 on total items inside of it
 
======================================================
 Usage
====================================================== 

 Put this script into your scripts editor and modify
 the settings below

 To make a storage use this limit script, on the ITEM_MAX_NUMBER
 of that storage, put "SceneManager.scene.get_item_limit"
 
 Example: If you want storage 1 to use this:
 
 ITEM_MAX_NUMBER[1] = "SceneManager.scene.get_item_limit"
 
 if you want the remaining slots to show on the custom window:
   
 CUSTOM_WINDOW[index] = "SceneManager.scene.get_remaining_slots"
 
 Example: If you want storage 1 to use this:
 
 CUSTOM_WINDOW[1] = "SceneManager.scene.get_remaining_slots"
 
 The 0 indexed setting will be the one used by default
 by any storage that you open that doesn't have it's own
 settings defined. So don't remove it.
 
 Copy paste the setting constants and modify the index to the
 storage number that you want, then modify the values
 
 For example:
 
 This would be the limit for storage 1
 
 ITEM_TOTAL_LIMIT[1] = 10
 
 Do that for every setting that you want to change
 for a particular storage
 
======================================================
 Compatibility
======================================================

 Overwrites the Shared Stash's can_store and Process
 Digits methods
 
======================================================
 Terms and Conditions
======================================================

 View it here: http://lescripts.wordpress.com/terms-and-conditions/

======================================================
=end


module ADIK
  module SHARED_STORAGE
    #Important:  Do not remove!
    #======================================================
    ITEM_TOTAL_LIMIT = []
    #======================================================
    
    ITEM_TOTAL_LIMIT[0] = "1"
  end
end

class Scene_SharedStorage
  
  def get_remaining_slots
    total = 0
    $shared_storage.each_key do |key|
      if key[0] == @storage_number
        total += $shared_storage[key]
      end
    end
    limit = ADIK::SHARED_STORAGE::ITEM_TOTAL_LIMIT[@storage_number]
    limit = ADIK::SHARED_STORAGE::ITEM_TOTAL_LIMIT[0] if limit.nil?
    return eval(limit) - total
  end
  
  def get_item_limit
    item = get_item
    begin
      return $shared_storage[[@storage_number,item.class.to_s,item.id]] + get_remaining_slots
    rescue
      return get_remaining_slots
    end
  end
  
  def get_item_limit_ex(item)
    begin
      return $shared_storage[[@storage_number,item.class.to_s,item.id]] + get_remaining_slots
    rescue
      return get_remaining_slots
    end
  end
  
  #Overwrites the original
  def can_store(item)
    if @ss_category == :deposit
      numb = ADIK::SHARED_STORAGE::MAX_ITEM_NUMBER[@storage_number]
      numb = ADIK::SHARED_STORAGE::MAX_ITEM_NUMBER[0] if numb.nil?
      if numb == "SceneManager.scene.get_item_limit"
        numb = get_item_limit_ex(item)
      else
        numb = eval(numb)
      end
      begin
        numb -= $shared_storage[[@storage_number,item.class.to_s,item.id]]
      rescue
      end
      return numb > 0
    else
      numb = $game_party.item_number(item)
      return numb < $game_party.max_item_number(item)
    end
  end
  
end

class Window_NumberInput_SS
  
  #Overwrites the original
  def process_digit_change
    return unless active
    if Input.repeat?(:UP) || Input.repeat?(:DOWN)
      Sound.play_cursor
      place = 10 ** (@digits_max - 1 - @index)
      n = @number / place % 10
      @number -= n * place
      n = (n + 1) % 10 if Input.repeat?(:UP)
      n = (n + 9) % 10 if Input.repeat?(:DOWN)
      @number += n * place
      if @category == :deposit
        item = @item
        numb = ADIK::SHARED_STORAGE::MAX_ITEM_NUMBER[$shared_storage_number]
        numb = ADIK::SHARED_STORAGE::MAX_ITEM_NUMBER[0] if numb.nil?
        if numb == "SceneManager.scene.get_item_limit"
          numb = SceneManager.scene.get_item_limit_ex(item)
        else
          numb = eval(numb)
        end
        begin
          numb -= $shared_storage[[$shared_storage_number,@item.class.to_s,@item.id]]
        rescue
        end
        @number = [@number,$game_party.item_number(@item),numb].min
      else
        amount = $shared_storage[[$shared_storage_number,@item.class.to_s,@item.id]]
        limit = $game_party.max_item_number(@item)- $game_party.item_number(@item)
        @number = [@number,amount,limit].min
      end
      refresh
    end
  end
  
end