#==============================================================================
# 
# BattleBack_Seasons + EX v1.0
# by AdiktuzMiko
# --- Date Created: 18/01/2013
# --- Last Date Updated: 18/01/2013
# --- Level: Easy
# Requires: n/a
# 
# Basically, this allows you to have different battlebacks in one map
# depending on seasons. You can also have different battleback sets per
# region on a single map.
#
# Take note that this doesn't work on Battle Test.
#
#==============================================================================

#==============================================================================
# Aliased methods:
#
# battleback1_bitmap, battleback2_bitmap (both belongs to Spriteset_Battle)
#==============================================================================

#==============================================================================
# How To Install:
#
# Just put this anywhere before main and you're good to go.
#==============================================================================

#==============================================================================
# Compatibility:
#
# This script is made strictly for RPG Maker VX Ace. It is highly unlikely that
# it will run with RPG Maker VX without adjusting.
#
# As for compatibility with other scripts, it's compatible with YEA scripts. 
# I don't know for other scripts though. Though I don't think it would be
# incompatible with other scripts unless they overwrite the battleback creation
# at the start too.
#
# I don't think that this is compatible with my BattleBack_EX script.
#
#==============================================================================

#==============================================================================
# How To Use:
#
# 1)Set the game variable that sets the season
# 2)Create a battleback set at the BATTLEBACKSEASON_1 Hash, format is:
#   Key => [Season1,Season2 and so on...],
# 3)Do the same for BATTLEBACKSEASON_2 Hash
#   *BATTLEBACKSEASON_1 = the set of BattleBack1 images
#   *BATTLEBACKSEASON_2 = the set of BattleBack2 images 
# 3)Set the battleback set to be used by maps via the SEASONMAP Hash, format is:
#   MapID => Key
#
# So now, if the value of the variable linked to SEASON_VAR is 1, it will use
# the battleback for Season1 and so on
#
# For the EX mode:
#
# Set the corresponding keys for each region of maps via the BATTLEBACKEX Hash,
# format is:
#
# MapID => {RegionID = Key, RegionID = Key and so on}
#
# Maps not registered in the EX Hash will use the default registered battleback
# set for that map via the SEASONMAP. Same goes for regions of a map that is not
# registered.
#
#==============================================================================

#==============================================================================
# Explanation of Sample Settings:
#
# SEASON_VAR is set to 16, this means that season will be determined by
# Game Variable number 16
#
# For BATTLEBACKSEASON_1, there are two specified battleback sets
# the first one, containing a different battleback for each of the four
# basic seasons. The second one though has the same battleback for all the
# seasons, this is to be used to show how the EX mode works. 
#
# For BATTLEBACKSEASON_2, the same keys of battleback sets are registered
# I used null/nil battlebacks for this sample
#
# For SEASONMAP, we specify the battleback set that each map uses. Here we
# link map number 14 to the Forest battleback set
#
# For BATTLEBACKEX, we registered map number 14 which means we plan to have
# different battleback sets for the different regions of that single map.
# We set region 3 to use the Forest2 battleback set. This means that
# if you enter a batlle in map 14 in a position that belongs to region 3,
# the game will use the Forest2 battleback set rather than the Forest
# battleback set that is used by all other positions on that map.
#
#==============================================================================


module BattleBack_Season
  
  SEASON_VAR = 16
  
  BATTLEBACKSEASON_1 = {
  
  "Forest" => ["ForestWinter","ForestSpring","ForestSummer","ForestFall"],
  "Forest2" => ["ForestFall","ForestFall","ForestFall","ForestFall"],
  
  } #Do not remove
  
  BATTLEBACKSEASON_2 = {
  
  "Forest" => ["","","",""],
  "Forest2" => ["","","",""],
  
  }
  
  SEASONMAP = {
  
  14 => "Forest",
  
  }
  
  BATTLEBACKEX = {
  
  14 => {3 => "Forest2",},

  } #Do not remove
  
end #BattleBack_Season

#==============================================================================
# Do not touch anything below this line unless you know what you are doing.
#==============================================================================

class Spriteset_Battle
  
  alias battleback1_bitmap_seasons battleback1_bitmap
  def battleback1_bitmap
    if $BTEST #without this it bugs during battle test
      battleback1_bitmap_seasons
    else
      id = $game_map.map_id
      region = $game_map.region_id($game_player.x,$game_player.y)
      if BattleBack_Season::BATTLEBACKEX[id] != nil then
        if BattleBack_Season::BATTLEBACKEX[id][region] != nil then
          season = BattleBack_Season::BATTLEBACKEX[id][region]
        else
          season = BattleBack_Season::SEASONMAP[id]
        end
      else
        season = BattleBack_Season::SEASONMAP[id]
      end
      if season != nil then
        Cache.battleback1(BattleBack_Season::BATTLEBACKSEASON_1[season][$game_variables[BattleBack_Season::SEASON_VAR] - 1])
      elsif battleback1_name
        Cache.battleback1(battleback1_name)
      else
        create_blurry_background_bitmap
      end
    end
  end
  
  alias battleback2_bitmap_seasons battleback2_bitmap
  def battleback2_bitmap
    if $BTEST #without this it bugs during battle test
      battleback2_bitmap_seasons
    else
      id = $game_map.map_id
      region = $game_map.region_id($game_player.x,$game_player.y)
      if BattleBack_Season::BATTLEBACKEX[id] != nil then
        if BattleBack_Season::BATTLEBACKEX[id][region] != nil then
          season = BattleBack_Season::BATTLEBACKEX[id][region]
        else
          season = BattleBack_Season::SEASONMAP[id]
        end
      else
        season = BattleBack_Season::SEASONMAP[id]
      end
      if season != nil then
        Cache.battleback1(BattleBack_Season::BATTLEBACKSEASON_2[season][$game_variables[BattleBack_Season::SEASON_VAR] - 1])
      elsif battleback2_name
        Cache.battleback2(battleback2_name)
      else
        create_blurry_background_bitmap
      end
    end
  end
  
end #Spriteset_Battle