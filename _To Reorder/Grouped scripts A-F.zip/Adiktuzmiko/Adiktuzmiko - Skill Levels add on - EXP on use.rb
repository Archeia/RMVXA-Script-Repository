=begin
======================================================
  
  Skill Levels Add-On: EXP On Use v1.01
  by Adiktuzmiko                   
  
  Date Created: 02/27/2014
  Date Last Updated: 04/11/2014
  Requires: Skill Levels v1.03 and up
  Difficulty: Easy
  
======================================================
 Overview
======================================================
 
 This script allows you to set-up skills so that they
 gain exp when you use them. Set-up is via formula so
 you can make whatever formula you want. Formula is
 set for both hit and miss so you can make skills have
 different EXP gain if it hits or misses.
 
======================================================
 Usage
====================================================== 

 Put this script into your scripts editor, probably
 below any other script that might modify Game_Battler. 
 Next thing to do is to tag your skills.
 
 <SKILL EXP_H>formula<END SKILL EXP_H> = Sets the formula for exp
 gain when this skill hits. Accepts multiple lines
 
 <SKILL EXP_M>formula<END SKILL EXP_M> = Sets the formula for exp
 gain when this skill misses. Accepts multiple lines
 
======================================================
 Compatibility
======================================================

 Aliases Game_Battler's item_apply
 
======================================================
 Terms and Conditions
======================================================

 View it here: http://lescripts.wordpress.com/terms-and-conditions/

======================================================
=end

#======================================================
#  Do not edit below this line
#======================================================

module ADIK
  module SKILL_LEVEL_USE
    HIT = /<SKILL EXP_H>(.*)<END SKILL EXP_H>/im
    MISS = /<SKILL EXP_M>(.*)<END SKILL EXP_M>/im
  end
end

class Game_Battler

  alias item_apply_skill_level item_apply
  def item_apply(user, item)
    item_apply_skill_level(user, item)
    return unless item.is_a?(RPG::Skill)
    a = user
    b = self
    if @result.hit?
      if item.note =~ ADIK::SKILL_LEVEL_USE::HIT
        value = eval($1.to_s)
      else
        return
      end
	  user.mod_skill_exp(item.id,'add',value)
    else
      if item.note =~ ADIK::SKILL_LEVEL_USE::MISS
        value = eval($1.to_s)
      else
        return
      end
      user.mod_skill_exp(item.id,'add',value)  
    end
  end

end