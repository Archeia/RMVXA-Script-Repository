#==============================================================================
# 
# Chest Drop Randomizer Ace v1.1
# by AdiktuzMiko
# --- Date Created: 04/11/2012
# --- Last Date Updated: 05/29/2013
# --- Level: Normal
# Requires: n/a
# 
# Basically, this allows you to easily randomize items that you obtain from
# chests, etc. It also displays a message which tells you what item and how
# many of it was obtained.
#
#==============================================================================


#==============================================================================
# How To Install:
#
# Just put this anywhere before main and you're good to go.
#==============================================================================


#==============================================================================
# How To Use:
# 
# Just call one of these functions: 
#
# Chest::AddGold(low,high) -> for gold/currency
# Chest::AddArmor(value, low, high, equip) -> for armor type items
# Chest::AddWeapon(value, low, high, equip) -> for weapon type items
# Chest::AddItem(value, low, high) -> for other items
#
# Loop methods
#
# Chest::AddGoldEx(times, low,high) -> for gold/currency
# Chest::AddArmorEx(times, value, low, high, equip) -> for armor type items
# Chest::AddWeaponEx(times, value, low, high, equip) -> for weapon type items
# Chest::AddItemEx(times, value, low, high) -> for other items
#
# times -> how many times the randomization will be done
# value = the amount of item to be added
# low = the low bound for the randomization [corresponds to id in the database]
# high = the high bound for the randomization [corresponds to id in the database]
# equip = whether to include the equipped items when checking
#         for the maximum amount of item that the player can have
#        -> by default, this is false
# 
# Array methods
#
# These methods take in an array of values instead of a low and high value.
# They randomize the result from the array of values passed into it.
#
# Chest::AddGold2([gold values]) -> for gold/currency
# Chest::AddArmor2(value, [armor ids], equip) -> for armor type items
# Chest::AddWeapon2(value, [weapon ids], equip) -> for weapon type items
# Chest::AddItem2(value,[item ids]) -> for other items
#
# Loop methods
#
# Chest::AddGold2Ex(times, [gold values]) -> for gold/currency
# Chest::AddArmor2Ex(times, value, [armor ids], equip) -> for armor type items
# Chest::AddWeapon2Ex(times, value, [weapon ids], equip) -> for weapon type items
# Chest::AddItem2Ex(times, value, [item ids]) -> for other items
#
# Example:
#
# Chest::AddArmor(2, 1, 3)
# 
# this will result to having 2 pieces of an armor which is randomized from
# the armor with the id of 1 up to the armor with an id of 3 at the database
# 
# Since equip was not set, it will be false by default, so if for example
# the armor I obtained was armor 1, then I have 1 of it equipped and 97
# on the inventory, if the item limit is set to 99, then I will now have
# 99 armor 1 in the inventory + 1 equipped
#
# if I set it to true, I will only have 98 on my inventory even I originally have
# 97 only and the value was set to 2, since the 1 equipped will be included 
# in the counting of item number
# 
# Chest::AddGoldEx(2, 100,200)
# 
# This will give you random gold twice, the value of each will be between 100 
# and 200. so it can be like  100 and 200 or 101 and 150 and so on.
#
# Chest::AddGold2([100,2,50,15,1,1,1,1,8,9])
#
# This will give you random gold from the array given.
#
# To show the item obtain message just call
# Chest::ShowItemMessage()
#
# Note: Only call this function after you have finished adding all the item
# drops for the specific event, else it might malfunction.
# 
# See the example events for a concrete look at how it is used.
#
#==============================================================================

module Chest 
  
  POPUP_SOUND = 'Chime2'
  POSITION = 2 # 0 - top, 1 - mid, 2 - bottom
  POPUP_SOUND_VOLUME = 100
  POPUP_SOUND_PITCH = 150
  COLOR = 2
  
#==============================================================================
# Do not touch anything below this line unless you know what you are doing.
#==============================================================================
  
  $textitem = []
  $textcount = 0
  
  def self.ShowItemMessage
    unless $game_message.busy?
      Audio.se_play('Audio/SE/' + POPUP_SOUND, POPUP_SOUND_VOLUME, POPUP_SOUND_PITCH)
      $game_message.face_name = ""
      $game_message.face_index = 0
      $game_message.background = 1
      $game_message.position = POSITION
      for i in 1..$textcount
        $game_message.texts.push("\\C[" + COLOR.to_s + "]" + $textitem[i])
      end
      $textitem.clear()
      $textcount = 0
    end
    return false
  end
  
  def self.AddGold(low,high)
    value = low + rand(high - low + 1)
    $game_party.gain_gold(value)
    $textcount += 1
    $textitem[$textcount] = (value.to_s + " gold acquired!")
  end
  
  def self.AddGoldEx(times, low,high)
    for i in 1..times
      value = low + rand(high - low + 1)
      $game_party.gain_gold(value)
      $textcount += 1
      $textitem[$textcount] = (value.to_s + " gold acquired!")
    end
  end
  
  def self.AddGold2(gold)
    value = gold[rand(gold.length)]
    $game_party.gain_gold(value)
    $textcount += 1
    $textitem[$textcount] = (value.to_s + " gold acquired!")
  end
  
  def self.AddGold2Ex(times, gold)
    for i in 1..times
      value = gold[rand(gold.length)]
      $game_party.gain_gold(value)
      $textcount += 1
      $textitem[$textcount] = (value.to_s + " gold acquired!")
    end
  end
  
  def self.AddArmor(value, low, high,equip = false)
    ite = $data_armors[low + rand(high - low + 1)]
    $game_party.gain_item(ite, value, equip)
    $textcount += 1
    $textitem[$textcount] = (ite.name + " (x" + value.to_s + ") acquired!")
  end
  
  def self.AddArmor2(value, armor,equip = false)
    ite = $data_armors[armor[rand(armor.length)]]
    $game_party.gain_item(ite, value, equip)
    $textcount += 1
    $textitem[$textcount] = (ite.name + " (x" + value.to_s + ") acquired!")
  end
  
  def self.AddArmorEx(times, value, low, high,equip = false)
    for i in 1..times
      ite = $data_armors[low + rand(high - low + 1)]
      $game_party.gain_item(ite, value, equip)
      $textcount += 1
      $textitem[$textcount] = (ite.name + " (x" + value.to_s + ") acquired!")
    end
  end
  
  def self.AddArmor2Ex(times, value, armor,equip = false)
    for i in 1..times
      ite = $data_armors[armor[rand(armor.length)]]
      $game_party.gain_item(ite, value, equip)
      $textcount += 1
      $textitem[$textcount] = (ite.name + " (x" + value.to_s + ") acquired!")
    end
  end
  
  def self.AddItem(value, low, high)
    ite = $data_items[low + rand(high - low + 1) ]
    $game_party.gain_item(ite, value, false)
    $textcount += 1
    $textitem[$textcount] = (ite.name + " (x" + value.to_s + ") acquired!")
  end
  
  def self.AddItem2(value, item)
    ite = $data_items[item[rand(item.length)] ]
    $game_party.gain_item(ite, value, false)
    $textcount += 1
    $textitem[$textcount] = (ite.name + " (x" + value.to_s + ") acquired!")
  end
  
  def self.AddItemEx(times,value, low, high)
    for i in 1..times
      ite = $data_items[low + rand(high - low + 1) ]
      $game_party.gain_item(ite, value, false)
      $textcount += 1
      $textitem[$textcount] = (ite.name + " (x" + value.to_s + ") acquired!")
    end
  end
  
  def self.AddItem2Ex(times,value, item)
    for i in 1..times
      ite = $data_items[item[rand(item.length)] ]
      $game_party.gain_item(ite, value, false)
      $textcount += 1
      $textitem[$textcount] = (ite.name + " (x" + value.to_s + ") acquired!")
    end
  end
  
  def self.AddWeapon(value, low, high,equip = false)
    ite = $data_weapons[low + rand(high - low + 1)]
    $game_party.gain_item(ite, value, equip)
    $textcount += 1
    $textitem[$textcount] = (ite.name + " (x" + value.to_s + ") acquired!")
  end
  
  def self.AddWeapon2(value, weapon,equip = false)
    ite = $data_weapons[weapon[rand(weapon.length)]]
    $game_party.gain_item(ite, value, equip)
    $textcount += 1
    $textitem[$textcount] = (ite.name + " (x" + value.to_s + ") acquired!")
  end
  
  def self.AddWeaponEx(times, value, low, high,equip = false)
    for i in 1..times
      ite = $data_weapons[low + rand(high - low + 1)]
      $game_party.gain_item(ite, value, equip)
      $textcount += 1
      $textitem[$textcount] = (ite.name + " (x" + value.to_s + ") acquired!")
    end
  end
  
  def self.AddWeapon2Ex(times, value, weapon,equip = false)
    for i in 1..times
      ite = $data_weapons[weapon[rand(weapon.length)]]
      $game_party.gain_item(ite, value, equip)
      $textcount += 1
      $textitem[$textcount] = (ite.name + " (x" + value.to_s + ") acquired!")
    end
  end
  
end #Chest