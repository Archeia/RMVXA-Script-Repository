#==============================================================================
# 
# Critical EX v1.01
# by AdiktuzMiko
# --- Date Created: 05/23/2013
# --- Last Date Updated: 06/21/2013
# --- Level: Easy
#
# Basically it allows you to tag objects to enable critical hits in all
# hits (attack/skill must have allow criticals turned on)
# And also allows you to tag objects to protect from critical hits
#
# Also allows you to define what will happen if an incoming damage is affected
# by perfect critical, while the target is protected from criticals
#
# Why not just add 100% critical rate to the object? Well because the formula
# for critical selection is critical*(1-critical evasion), so if you have 100%
# critical, but the target has a higher than 0 cev, then you can still miss that
# critical. And also because it will still be subjected to traits that can lower
# critical rate if you do it that way.
#
# Now that means that critical immunity is doable by default, but I added it too
# to this system just so its easier to set up the scenario where the damage
# has perfect crit and target has immunity. And also so that immunity won't
# be affected by traits that could lower cev value.
#
# You can now also alter the critical formula to be used. You can even
# set actors, classes or enemies to have different formulas. 
# Requires: Elements EX
#
#==============================================================================
#   ++ Notetags ++
#==============================================================================
#
# These tags goes into Actors, Classes, Items, Skills, Weapons, Armors, Enemies
# and States
#
# <CRITEX> = Flags that object to have perfect critical
# <ANTICRITEX> = Flags that object to have critical immunity
#
# For actors, classes and enemies only
#
# Note: class critical formula will override the actor formula
#       REQUIRES my ElementsEX script
#
# <CRITICAL_START> = Flags the start of a custom critical formula
#   Place your custom ruby formula here!
# <CRITICAL_END> = Flags the end of a custom critical formula
#
# self => the target of the damage
# user => the source of the damage
# item => item or skill used to deal the damage
# damage => current damage amount
#
# ex: 
# <CRITICAL_START>
# user.mhp*10
# <CRITICAL_END>
#
# Everytime an actor/class/enemy tagged with this attacks and scores a critical
# he will deal critical damage equal to his max hp times 10.
#
# <CRITICAL_START>
# damage + user.mhp*10
# <CRITICAL_END>
#
# Everytime an actor/class/enemy tagged with this attacks and scores a critical
# he will deal critical damage equal to the damage amount + 10 times his maximum hp.
#
# Note: critical damage is the last calculation in the damage part
#
#==============================================================================
#   ++ Installation ++
#==============================================================================
# Install this script in the Materials section in your project's
# script editor.
#
# Edit the WHAT_TO_DO constant to fit your needs then start tagging objects!
#
#==============================================================================
#   ++ Compatibility ++
#==============================================================================
# This script aliases the following default VXA methods:
#
#     Game_Battler#make_damage_value
#    
# There are no default method overwrites.
#
# Place this under ElementsEX if you have that script.
#
#==============================================================================
#   ++ Terms and Conditions ++
#==============================================================================
#
# This script is free to use
#
#==============================================================================

$imported = {} if $imported.nil?
$imported["CriticalEX"] = true

#==========================================================================
# ++ Adiktuz::Crit
#==========================================================================
module Adiktuz
  module Crit
    #==========================================================================
    # Determines what to do if the damage has a perfect critical flag
    # while the target has a critical immunity flag
    #
    # Values:
    # 
    # 1 -> Perfect critical takes into effect
    # 2 -> Critical Immunity takes into effect
    # Any other number -> Lets the default system handle the critical chance
    #==========================================================================
    WHAT_TO_DO = 3
    
    #==========================================================================
    # Determines the critical formula to be used
    #
    # REQUIRES my Elements EX script
    #
    # self => the target of the damage
    # user => the source of the damage
    # item => item or skill used to deal the damage
    # damage => current damage amount
    #
    #==========================================================================
    CRITICAL_FORMULA = "damage * 2"
  end #module Crit
end #module Adiktuz

#==========================================================================
# ++ DataManager
#==========================================================================
module DataManager
  #--------------------------------------------------------------------------
  # alias : load_database
  #--------------------------------------------------------------------------
  class << self; alias load_database_critex load_database; end
  def self.load_database
    load_database_critex # alias
    load_notetags_critex
  end
  
  #--------------------------------------------------------------------------
  # new method : load_notetags_critex
  #--------------------------------------------------------------------------
  def self.load_notetags_critex
    groups = [$data_skills, $data_weapons, $data_armors, $data_actors,
              $data_states, $data_classes, $data_items, $data_enemies]
    for group in groups
      for obj in group
        next if obj.nil?
        obj.load_notetags_critex
      end # for obj
    end # for group
  end # def
  
end # module DataManager


#==========================================================================
# ++ Adiktuz::Regexp
#==========================================================================
module Adiktuz
  module Regexp
    CRIT_TAG = /<CRITEX>/i
    ANTI_CRIT_TAG = /<ANTICRITEX>/i
    CRITICAL_START = /<CRITICAL_START>/i
    CRITICAL_END = /<CRITICAL_END>/i
  end # module Regexp
end # module Adiktuz


#==========================================================================
# ++ RPG::BaseItem
#==========================================================================
class RPG::BaseItem
  #--------------------------------------------------------------------------
  # public instance variables
  #--------------------------------------------------------------------------
  attr_accessor :crit_ex
  attr_accessor :anti_crit_ex
  attr_accessor :critical_formula
  #--------------------------------------------------------------------------
  # common cache : load_notetags_critex
  #--------------------------------------------------------------------------
  def load_notetags_critex
    @crit_ex = false
    @anti_crit_ex = false
    @critical_formula = nil
    crit_start = false
    
    self.note.split(/[\r\n]+/).each { |line|
      case line
      when Adiktuz::Regexp::CRIT_TAG
        @crit_ex = true
      when Adiktuz::Regexp::ANTI_CRIT_TAG
        @anti_crit_ex = true
      when Adiktuz::Regexp::CRITICAL_START
        crit_start = true
      when Adiktuz::Regexp::CRITICAL_END
        crit_start = false
      else
        @critical_formula = "" if @critical_formula.nil? && crit_start
        @critical_formula += line.to_s if crit_start
      end # case
    } # self.note.split
  end # def load_notetags_critex
end # class RPG::BaseItem


#==========================================================================
# ++ Game_Battler
#==========================================================================
class Game_Battler < Game_BattlerBase
  
  #--------------------------------------------------------------------------
  # new method : has_anti_critex?
  #--------------------------------------------------------------------------
  def has_anti_critex?
    if actor? then
      return true if self.actor.anti_crit_ex
      return true if self.class.anti_crit_ex
      for equip in equips
        next if equip.nil?
        return true if equip.anti_crit_ex
      end
      for state in states
        next if state.nil?
        return true if state.anti_crit_ex
      end
    end
    if enemy? then
      return true if self.enemy.anti_crit_ex
      for state in states
        next if state.nil?
        return true if state.anti_crit_ex
      end
    end
    return false
  end
  
  #--------------------------------------------------------------------------
  # new method : has_critex?
  #--------------------------------------------------------------------------
  def has_critex?(user,item)
    return true if item.crit_ex
    if user.actor? then
      return true if user.actor.crit_ex
      return true if user.class.crit_ex
      for equip in user.equips
        next if equip.nil?
        return true if equip.crit_ex
      end
      for state in user.states
        next if state.nil?
        return true if state.crit_ex
      end
    end
    if user.enemy? then
      return true if user.enemy.crit_ex
      for state in user.states
        next if state.nil?
        return true if state.crit_ex
      end
    end
    return false
  end
  
  
  #--------------------------------------------------------------------------
  # aliased method : make_damage_value(user,item)
  #--------------------------------------------------------------------------
  alias CritEX make_damage_value
  def make_damage_value(user,item)
    positive = has_critex?(user,item)
    negative = has_anti_critex?
    if positive then
      if negative then
        case Adiktuz::Crit::WHAT_TO_DO
        when 1
          @result.critical = true
        when 2
          @result.critical = false
        end
      else
        @result.critical = true
      end
    elsif negative
      @result.critical = false
    end
    CritEX(user,item)
  end
  
  #--------------------------------------------------------------------------
  # aliased method : apply_critical(damage)
  #--------------------------------------------------------------------------
  if $imported["ElementEX"] 
    alias apply_critical_exe apply_critical
    def apply_critical(damage)
      #Just so it doesn't do anything
    end
  end
  
  def apply_critical_ex(damage,user,item)
    if user.actor?
      if not user.class.critical_formula.nil?
        return eval(user.class.critical_formula)
      elsif not user.actor.critical_formula.nil?
        return eval(user.actor.critical_formula)
      end
    elsif user.enemy?
      if not user.enemy.critical_formula.nil?
        return eval(user.enemy.critical_formula)
      end
    end
    eval(Adiktuz::Crit::CRITICAL_FORMULA)
  end
  
end