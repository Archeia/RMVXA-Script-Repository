=begin
 ==============================================================================

 Animated Title v1.00
 by AdiktuzMiko
 --- Date Created: 10/07/2014
 --- Last Date Updated: 10/07/2014
 --- Level: Easy

 ==============================================================================
 Overview
 ==============================================================================

 This script provides the ability to add pictures on the title screen
 that could be animated.
 
 ==============================================================================
 Set-Up
 ==============================================================================
 
 Just put this script into a blank slot above main but below materials
 (see compatibility section) and modify the settings below

 ==============================================================================
 Compatibility
 ==============================================================================

 This script aliases Scene_Titles' start and terminate method. It also
 defines the update method for Scene_Title
 
 ==============================================================================
 Terms and Conditions
 ==============================================================================

 View it here: http://lescripts.wordpress.com/terms-and-conditions/
 
 ==============================================================================
=end

module ADIK
  module ANIMATED_TITLE
    
    LIST = {} #Important, Do not delete!
    
    #Pictures should be inside the Graphics\Pictures folder of your game
    #List down the pictures here and their initial setup
    #x,y,w,h,filename,opacity,z
    LIST[0] = [0,0,200,200,"Window.png",255,1]
    
    ANIMATE = {} #Important, Do not delete!
    
    #List down here the final settings of the picture
    #time => time required to finish one animation
    #reverse => reverse the animation once it finishes?
    #loop => will the animation loop once it finishes?
    # if reverse and loop is both true, it will only loop
    # after the reverse
    #x,y,w,h,opacity,time,reverse,loop
    ANIMATE[0] = [400,0,200,200,255,120,true,true]
  end
end

# ==============================================================================
# DO NOT EDIT BELOW THIS LINE
# ==============================================================================

class Scene_Title
  
  alias start_anim_title_adik start
  def start
    start_anim_title_adik
    @pic_list = []
    ADIK::ANIMATED_TITLE::LIST.each do |key,value|
      @pic_list[key] = []
      @pic_list[key][0] = Sprite.new
      @pic_list[key][0].z = value[6]
      @pic_list[key][0].bitmap = Bitmap.new(Graphics.width,Graphics.height)
      bit = Cache.picture(value[4])
      from_rect = Rect.new(0,0,bit.width,bit.height)
      dest_rect = Rect.new(value[0],value[1],value[2],value[3])
      @pic_list[key][0].bitmap.stretch_blt(dest_rect,bit,from_rect,value[5])
      @pic_list[key][1] = value[0]
      @pic_list[key][2] = value[1]
      @pic_list[key][3] = value[2]
      @pic_list[key][4] = value[3]
      @pic_list[key][5] = value[5]
    end
    @animate = []
    ADIK::ANIMATED_TITLE::ANIMATE.each do |key,value|
      @animate[key] = []
      @animate[key][0] = value[0] - ADIK::ANIMATED_TITLE::LIST[key][0]
      @animate[key][1] = value[1] - ADIK::ANIMATED_TITLE::LIST[key][1]
      @animate[key][2] = value[2] - ADIK::ANIMATED_TITLE::LIST[key][2]
      @animate[key][3] = value[3] - ADIK::ANIMATED_TITLE::LIST[key][3]
      @animate[key][4] = value[4] - ADIK::ANIMATED_TITLE::LIST[key][5]
      @animate[key][5] = value[6]
      @animate[key][10] = value[7]
      @animate[key][0] /= value[5]
      @animate[key][1] /= value[5]
      @animate[key][2] /= value[5]
      @animate[key][3] /= value[5]
      @animate[key][4] /= value[5]
      @animate[key][7] = false
      @animate[key][8] = 0
      @animate[key][9] = value[5]
    end
  end
  
  def update
    super
    @animate.each_index do |key|
      next if @animate[key].nil?
      if @animate[key][7]
        if @animate[key][8] == 0
          @animate[key][7] = false if @animate[key][10]
          next
        end
        @pic_list[key][0].bitmap.clear
        bit = Cache.picture(ADIK::ANIMATED_TITLE::LIST[key][4])
        @pic_list[key][1] -= @animate[key][0]
        @pic_list[key][2] -= @animate[key][1]
        @pic_list[key][3] -= @animate[key][2]
        @pic_list[key][4] -= @animate[key][3]
        @pic_list[key][5] -= @animate[key][4]
        from_rect = Rect.new(0,0,bit.width,bit.height)
        dest_rect = Rect.new(@pic_list[key][1],@pic_list[key][2],@pic_list[key][3],@pic_list[key][4])
        @pic_list[key][0].bitmap.stretch_blt(dest_rect,bit,from_rect,@pic_list[key][5])
        @animate[key][8] -= 1
      else
        if @animate[key][8] == @animate[key][9]
          if @animate[key][5]
            @animate[key][7] = true 
            next
          else
            #only process loop if reverse is false
            if @animate[key][10]
              @pic_list[key][1] = ADIK::ANIMATED_TITLE::LIST[key][0]
              @pic_list[key][2] = ADIK::ANIMATED_TITLE::LIST[key][1]
              @pic_list[key][3] = ADIK::ANIMATED_TITLE::LIST[key][2]
              @pic_list[key][4] = ADIK::ANIMATED_TITLE::LIST[key][3]
              @pic_list[key][5] = ADIK::ANIMATED_TITLE::LIST[key][5]
              @animate[key][8] = 0
            else
              next
            end
          end
        end
        @pic_list[key][0].bitmap.clear
        bit = Cache.picture(ADIK::ANIMATED_TITLE::LIST[key][4])
        @pic_list[key][1] += @animate[key][0]
        @pic_list[key][2] += @animate[key][1]
        @pic_list[key][3] += @animate[key][2]
        @pic_list[key][4] += @animate[key][3]
        @pic_list[key][5] += @animate[key][4]
        from_rect = Rect.new(0,0,bit.width,bit.height)
        dest_rect = Rect.new(@pic_list[key][1],@pic_list[key][2],@pic_list[key][3],@pic_list[key][4])
        @pic_list[key][0].bitmap.stretch_blt(dest_rect,bit,from_rect,@pic_list[key][5])
        @animate[key][8] += 1
      end
    end
  end
  
  alias terminate_anim_title_adik terminate
  def terminate
    unless @pic_list.nil?
      @pic_list.each {|pic| pic[0].dispose}
    end
    terminate_anim_title_adik
  end
  
end