=begin
 ==============================================================================

 Skill PP Cost v1.01
 by AdiktuzMiko
 --- Date Created: 01/03/2014
 --- Last Date Updated: 01/03/2014
 --- Level: Easy

 ==============================================================================
 Overview
 ==============================================================================

 So this script provides to make skills that can only be used a number of times
 until you reset it. You can set each skills "PP" per actor, meaning one actor
 can have a different PP for 1 skill than another actor. The PP can also be
 modified in-game via script calls 

 Also, it's set-up in a way that you can choose if a skill will have PP or not.
 If PP for a skill is not defined for that actor, it will use the default costs
 instead (MP/TP or probably if you have a custom cost manager, the custom cost)
 So you can do like only a certain actor uses PP while all others uses the normal
 method.

 ==============================================================================
 Set-Up
 ==============================================================================
 
 Just put this script into a blank slot above main but below materials and
 go to the module PP_SET_UP below to set up your actors

 Note that when you initialize an actor, it will reload the default PP values
 for that actor.
   
 Set the color of normal and critical PP using the module. You can also set
 up the critical rate
 
 ==============================================================================
 Script Calls
 ==============================================================================

 Legend:
 
 id => actor id
 skill_id => skill id
 initial => initial/current PP
 max => maximum PP
 value => value to add/multiply
 
 to get the current PP of a skill of an actor:

 $game_actors[id].pp(skill_id)

 to get the max PP of a skill of an actor:

 $game_actors[id].pp_max(skill_id)

 go reset PP of a skill on an actor:

 $game_actors[id].reset_pp(skill_id)

 to reset PP of all skills of an actor:

 $game_actors[id].reset_pp_all

 to change the PP of the skill of an actor:

 $game_actors[id].set_pp(skill_id,initial,max)

 to know if a skill has a PP value set-up:

 $game_actors[id].has_pp(skill_id)

 -Wrapper Functions-

 to add to the current PP of a skill of an actor

 $game_actors[id].add_current_pp(skill_id,value)

 to add value to max PP of a skill of an actor:

 $game_actors[id].add_max_pp(skill_id,value)

 to multiply the current PP of a skill of an actor:

 $game_actors[id].mul_current_pp(skill_id,value)

 to multiply the max PP of a skill of an actor:

 $game_actors[id].mul_max_pp(skill_id,value)

 to add value to current PP for all skills of an actor:

 $game_actors[id].add_current_pp_all(value)

 to add value to max PP for all skills of an actor:

 $game_actors[id].add_max_pp_all(value)

 to multiply the current PP for all skills of an actor:

 $game_actors[id].mul_current_pp_all(value)

 to multiply the max PP for all skills of an actor:

 $game_actors[id].mul_max_pp_all(value)

 to apply the above eight functions to party:
 
 just remove the $game_actors[id]. part

 to reset PP of all party members:

 party_reset_pp

 ==============================================================================
 Compatibility
 ==============================================================================

 This script aliases Game_BattlerBase.usable? method, Game_Actor.use_item 
 method and Window_SkillList.draw_skill_cost method

 So put it below any script that overwrites those
 
 ==============================================================================
 Terms and Conditions
 ==============================================================================

 View it here: http://lescripts.wordpress.com/terms-and-conditions/
 
 ==============================================================================
=end

module PP_SET_UP
  PP_DEFAULT = {
    
    #Actor ID
    1 => { 
      #Skill ID => [Initial PP, Max PP],
      26 => [1,10],
      2 => [30,30],
      3 => [22,22],
    },
    2 => { 
      #Skill ID => [Initial PP, Max PP],
      1 => [5,5],
      2 => [30,30],
      3 => [22,22],
    },
    #And so on

  }
  #Show max PP?
  SHOW_MAX = true
  #Color.new(R,G,B)
  #Color of normal PP
  NORMAL_PP = Color.new(0,255,200)
  #Color of critical PP
  CRIT_PP = Color.new(255,255,0)
  #Rate/Percent of PP before it's tagged as critical
  CRIT_RATE = 0.5
  
end

#Do not edit below this line

class Game_Actor
 
  attr_accessor :skills_pp

  alias initialize_skill_pp initialize
  def initialize(actor_id)
    initialize_skill_pp(actor_id)
    @skills_pp = PP_SET_UP::PP_DEFAULT[actor_id].nil? ? {} : PP_SET_UP::PP_DEFAULT[actor_id]
  end

  def has_pp(id)
    return false if @skills_pp.keys.empty?
    return @skills_pp.keys.include?(id)
  end

  def pp(id)
    return @skills_pp[id][0]
  end
  
  def pp_max(id)
    return @skills_pp[id][1]
  end
  
  def use_pp(id)
    @skills_pp[id][0] -= 1
  end
  
  def reset_pp(id)
    @skills_pp[id][0] = @skills_pp[id][1]
  end

  def reset_pp_all
    @skills_pp.each_value  {|skill| skill[0] = skill[1]}
  end

  def add_current_pp(id,value)
    @skills_pp[id][0] += value  
  end

  def add_max_pp(id,value)
    @skills_pp[id][1] += value    
  end

  def mul_current_pp(id,value)
    @skills_pp[id][0] *= value
  end

  def mul_max_pp(id,value)
    @skills_pp[id][1] *= value
  end

  def add_current_pp_all(value)
    @skills_pp.each_value  {|skill| skill[0] += value}
  end

  def add_max_pp_all(value)
    @skills_pp.each_value  {|skill| skill[1] += value}
  end

  def mul_current_pp_all(value)
    @skills_pp.each_value  {|skill| skill[0] *= value}
  end

  def mul_max_pp_all(value)
    @skills_pp.each_value  {|skill| skill[1] *= value}
  end

  def set_pp(id,init,max)
    @skills_pp[id][0] = init
    @skills_pp[id][1] = max
  end

  def get_pp_count(id)
    return self.pp(id).to_s if !PP_SET_UP::SHOW_MAX
    return self.pp(id).to_s + " / " + self.pp_max(id).to_s
  end

  alias use_item_adik_pp use_item
  def use_item(item)
    if (item.is_a?(RPG::Skill) and self.has_pp(item.id))
      self.use_pp(item.id)
      item.effects.each {|effect| item_global_effect_apply(effect) }
    else
      use_item_adik_pp(item)
    end
  end
end

class Game_BattlerBase
  alias adik_pp_usable? usable?
  def usable?(item)
    begin
      ex = (usable_item_conditions_met?(item) &&
      skill_wtype_ok?(item) && !skill_sealed?(item.id) && 
      !skill_type_sealed?(item.stype_id))
      return (self.pp(item.id) > 0 and ex)
    rescue
      return adik_pp_usable?(item)
    end
  end
end

class Window_SkillList
  
  def pp_color(cur,max,enabled)
    x = cur.to_f/max
    if x <= PP_SET_UP::CRIT_RATE
      contents.font.color.set(PP_SET_UP::CRIT_PP)
    else
      contents.font.color.set(PP_SET_UP::NORMAL_PP)
    end
    contents.font.color.alpha = translucent_alpha unless enabled
  end
  
  #alias method draw_skill_cost
  alias draw_skill_cost_adik_pp draw_skill_cost
  def draw_skill_cost(rect, skill)
    if @actor.has_pp(skill.id)
      pp_color(@actor.pp(skill.id),@actor.pp_max(skill.id),enable?(skill))
      draw_text(rect, @actor.get_pp_count(skill.id), 2)
    else
      draw_skill_cost_adik_pp(rect, skill)
    end
  end
end

class Game_Interpreter

  def party_reset_pp
    $game_party.all_members.each { |act| act.reset_pp_all }
  end

  def add_current_pp_all(value)
    $game_party.all_members.each { |act| act.add_current_pp_all(value) }
  end

  def add_max_pp_all(value)
    $game_party.all_members.each { |act| act.add_max_pp_all(value) }
  end

  def mul_current_pp_all(value)
    $game_party.all_members.each { |act| act.mul_current_pp_all(value) }
  end

  def mul_max_pp_all(value)
    $game_party.all_members.each { |act| act.mul_max_pp_all(value) }
  end

  def add_current_pp(id,value)
    $game_party.all_members.each { |act| act.add_current_pp(id,value) }
  end

  def add_max_pp(id,value)
    $game_party.all_members.each { |act| act.add_max_pp(id,value) }
  end

  def mul_current_pp(id,value)
    $game_party.all_members.each { |act| act.mul_current_pp(id,value) }
  end

  def mul_max_pp(id,value)
    $game_party.all_members.each { |act| act.mul_max_pp(id,value) }
  end
end