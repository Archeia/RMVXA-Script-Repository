=begin
Set Gold
by KB, Amyrakunejo
Assisted by r/transprogrammer Discord, Kayzee

Instructions:
In the events script call, use the following:
$game_party.set_gold(#)
$game_party.set_gold($game_variables[#])

You'll have your gold set to the amount. By setting the gold directly,
there is no need to use gain or loss commands. Useful if you have an event
that will decrease or increase the gold to a specific amount, or if you have
an event condition that checks for a specific max or minimum gold, or,
you know, whatever you may find this useful for.

Usage:
Place above all other modifier scripts for best performance.

Script conflicts:
Calestian's Currencies will need some serious editing to get this
script to work with it. If you succeed at this, let me know, thanks.
Addendum: I made a compatibility patch that works flawlessly.

Other known conflicts:
None yet.

Author requirements:
Commercial, Non-Commercial, I don't care. If you like this little script enough,
then all I'd like in return is for you to let me know. If you gave me a
free copy of your game, I'd appreciate that as well, but not necessary.
Is your game 18+ only? Cool by me, by the way. I'm not skeezy like most
script writers in this regard, like seriously; I'm kinky too. Jeez.
=end

class Game_Party < Game_Unit
  #--------------------------------------------------------------------------
  # * Set Gold
  #--------------------------------------------------------------------------
  def set_gold(amount)
#     @gold = amount
    @gold = [[@gold = amount, 0].max, max_gold].min
  end
end