# )----------------------------------------------------------------------------(
# )--     AUTHOR:     Mr. Trivel & Original Script by Calestian              --(
# )--     NAME:       Calestian's Achievement System extension               --(
# )--     CREATED:    2015-04-18                                             --(
# )--     VERSION:    1.0                                                    --(
# )----------------------------------------------------------------------------(
# )--                           REQUIRES                                     --(
# )--  Original Achievement Script by Calestian.                             --(
# )----------------------------------------------------------------------------(
# )--                          DESCRIPTION                                   --(
# )--  Allows increasing achievements with gold and variables.               --(
# )--  E.g. increasing variable 5 by 9 points, will increase achievement     --(
# )--    99 by 9 points.                                                     --(
# )--  Or increasing gold will increase another variable and so on.          --(
# )--                                                                        --(
# )----------------------------------------------------------------------------(

# )===========-----------------------------------------------------------------(
# )--  Module: Clstn_Achievement_System                                      --(
# )-----------------------------------------------------------------===========(
module Clstn_Achievement_System
  # )--------------------------------------------------------------------------(
  # )--  The place to set up the variable/achievement gain.                  --(
  # )--------------------------------------------------------------------------(
  # )--  The table is as follows:                                            --(
  # )--  Variable ID => [Achievement ID, type],                              --(
  # )--
  # )--  Variable ID is the variable you're changing.                        --(
  # )--  Achievement ID is ID in achievement list in the original script.    --(
  # )--  type is either :add or :current or :highest                         --(
  # )--    :add - when you increase the variable, the increase will get      --(
  # )--           added to achievement, too.                                 --(
  # )--    :current - when you change the variable, achievement progression  --(
  # )--               will change to the variable.                           --(
  # )--    :highest - when you change the variable, if it's value is higher  --(
  # )--               than achievement progession, it'll change to that var. --(
  # )--------------------------------------------------------------------------(
  VARIABLE_TABLE = {
  
    # Variable ID => [Achievement ID, :add/:current/:highest],
    5 => [0, :highest],
  }
  
  # )--------------------------------------------------------------------------(
  # )--  Achievement ID to increase when gaining gold.                       --(
  # )--  If there's no achievement that changes with gold gain, change the   --(
  # )--    number to -1.                                                     --(
  # )--------------------------------------------------------------------------(
  GOLD_GAIN_ADD = 2 # Set to -1 of no achivement
  
  # )--------------------------------------------------------------------------(
  # )--  Method copied from interpreter.                                     --(
  # )--------------------------------------------------------------------------(
  def self.gain_achievement(amount, index)
    item = Clstn_Achievement_System::Achievements[index]
    tier = Clstn_Achievement_System::tier?(Clstn_Achievement_System::Achievements[index])
    if $game_party.achievements[index] != item[:Tiers][-1]
      if !Clstn_Achievement_System::locked?(item)
        if amount <= item[:Tiers][tier]
          $game_party.achievements[index] += amount
          set_achievement(item[:Tiers][tier], index) if $game_party.achievements[index] > Clstn_Achievement_System::Achievements[index][:Tiers][tier]
        else
          set_achievement(item[:Tiers][tier], index)
        end
      end
      $game_party.achievement_completed(index)
      if $game_party.achievements[index] == item[:Tiers][-1] && item[:Repeatable] != false && item[:Repeatable] > $game_party.achievement_repeated[index]
        $game_party.achievements[index] = 0
        $game_party.achievement_repeated[index] += 1
      end
    end
  end
  
  # )--------------------------------------------------------------------------(
  # )--  Method copied from interpreter.                                     --(
  # )--------------------------------------------------------------------------(
  def self.set_achievement(amount, index)
    item = Clstn_Achievement_System::Achievements[index]
    if $game_party.achievements[index] != item[:Tiers][-1]
      $game_party.achievements[index] = amount unless Clstn_Achievement_System::locked?(Clstn_Achievement_System::Achievements[index])
      $game_party.achievement_completed(index)
      if $game_party.achievements[index] == item[:Tiers][-1] && item[:Repeatable] != false && item[:Repeatable] > $game_party.achievement_repeated[index]
        $game_party.achievements[index] = 0
        $game_party.achievement_repeated[index] += 1
      end
    end
  end
end

# )===========-----------------------------------------------------------------(
# )--  Class: Game_Variables                                                 --(
# )-----------------------------------------------------------------===========(
class Game_Variables
  # )--------------------------------------------------------------------------(
  # )--  Alias list                                                          --(
  # )--------------------------------------------------------------------------(
  alias :mrts_clsn_achv_equal_operator :[]=
  
  # )--------------------------------------------------------------------------(
  # )--  Method: []=                                                         --(
  # )--------------------------------------------------------------------------(
  def []=(variable_id, value)
    unless Clstn_Achievement_System::VARIABLE_TABLE[variable_id]
      mrts_clsn_achv_equal_operator(variable_id, value)
    else
      dif = value - (@data[variable_id] ? @data[variable_id] : 0)
      q = Clstn_Achievement_System::VARIABLE_TABLE[variable_id]
      case q[1]
      when :add
        if dif > 0
          Clstn_Achievement_System::gain_achievement(dif, q[0])
          mrts_clsn_achv_equal_operator(variable_id, dif)
        else
          mrts_clsn_achv_equal_operator(variable_id, dif)
        end
      when :current
        mrts_clsn_achv_equal_operator(variable_id, value)
        Clstn_Achievement_System::set_achievement(@data[variable_id], q[0])
      when :highest
        mrts_clsn_achv_equal_operator(variable_id, value)
        Clstn_Achievement_System::set_achievement(@data[variable_id], q[0]) unless $game_party.achievements[q[0]] > value
      else
        mrts_clsn_achv_equal_operator(variable_id, value)
      end  
    end
  end
end

# )===========-----------------------------------------------------------------(
# )--  Class: Game_Party                                                     --(
# )-----------------------------------------------------------------===========(
class Game_Party < Game_Unit
  # )--------------------------------------------------------------------------(
  # )--  Alias list                                                          --(
  # )--------------------------------------------------------------------------(
  alias :mrts_clsn_achv_gain_gold :gain_gold
  
  # )--------------------------------------------------------------------------(
  # )--  Method: gain_gold                                                   --(
  # )--------------------------------------------------------------------------(
  def gain_gold(amount)
    unless (amount > 0)
      mrts_clsn_achv_gain_gold(amount)
    else
      Clstn_Achievement_System::gain_achievement(amount, Clstn_Achievement_System::GOLD_GAIN_ADD) if Clstn_Achievement_System::GOLD_GAIN_ADD != -1
      mrts_clsn_achv_gain_gold(amount)
    end
  end
end 