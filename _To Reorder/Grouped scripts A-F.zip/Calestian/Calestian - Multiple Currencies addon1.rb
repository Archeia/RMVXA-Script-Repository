=begin
Add-On: Calestian Currencies - Set Gold and Set Currency

Original Script written by Calestian

Add-On/Mod written by Amyrakunejo for KB Games

Instructions:
Place below Calestian's Currencies script, directly below is best.

Only usable with KB-Set Gold Modifier script, this script must also be
placed below KB-Set Gold Modifier script.

Otherwise, Plug and Play, with the following sub-set of instructions:

With Calestian's Currency script, in the event's Advanced Script Call tab,
you can use the following two calls to do the following:
add_currency(amount, Currency_ID) to apply a currency gain
add_currency(-amount, Currency_ID) to apply a currency loss

With this Add-On script, and KB-Set Gold Modifier, the following
script call has also been added:
set_currency(amount, Currency_ID) to apply a currency set

Alternatively, one can use the following script call to set the currency:
$game_party.set_gold(amount, Currency_ID)

=end

class Game_Party < Game_Unit
  attr_accessor :currency
  
  #-------------------------------------------------------------------------
  # * Method: set_gold
  #-------------------------------------------------------------------------
  def set_gold(amount, currency_index = $game_temp.currency_index)
     if currency_index != 0
      @currency[currency_index] = [[@currency[currency_index] = amount, 0].max, max_gold].min #not invalid by the way
     else
      @gold = [[@gold = amount, 0].max, max_gold].min
  end
end

class Game_Interpreter
  
  #--------------------------------------------------------------------------
  # * Method: set_currency 
  #--------------------------------------------------------------------------
  def set_currency(amount, currency_index)
    $game_party.set_gold(amount, currency_index)
  end
 end
end