#==============================================================================
# ** Titles for VXACE, by Blackmorning
#==============================================================================
#  Blackmorning
#  Version 1.10
#  released 01/29/2014
#  updated 09/27/2017
# updates
# - allowed to select parameters shown
#==============================================================================
# Based on Titles System from RPG Maker VX by Blackmorning
# 
# * compatible with YEA status menu
# add [  :titles,  "Titles"], to list in COMMANDS in YEA status menu script
#
# * compatible with YEA menu engine
# add :titles to COMMANDS in YEA menu engine script
#
#===============================================================================
# Instructions
# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# To install this script, open up your script editor and copy/paste this script
# to an open slot below BM - Base but above ? Main. Remember to save. 
# 
# -----------------------------------------------------------------------------
# Actor Notetags - These notetags go in the actors notebox in the database.
# -----------------------------------------------------------------------------
# <unlocked titles: x>
# <unlocked titles: x, x>
# This will set the default titles as unlocked for the actor. This does not
# override the default titles unlocked in the module, but instead, adds on
# to the number of unlocked titles.

# <init title: x>
# This will set the initial title for the actor.
# -----------------------------------------------------------------------------
# Message Window codes - These go inside of your message window.
# \nti[x]    - Writes out title x's name.
# \ati[x]    - Write name of the title for actor x.
# -----------------------------------------------------------------------------
# Script Calls - These commands are used with script calls.
# -----------------------------------------------------------------------------
#
# * Add title to actor
#     add_titles(x, y)
# This allows actor x to unlock title y, making it available for switching in
# and out in the Titles scene.
#
# * remove title from actor
#     remove_titles(x, y)
# This causes actor x to remove title y from being able to switch to and from.
# If the actor is currently title y, the actor's title will default to 0 and the 
# title will be removed. 
#
# * change title from actor
#     change_titles(x, y)
# This causes actor x to change to title y.
#
# * check if title in list and assigns it to a switch
#     check_titles(actor_id, title_id, switch)
#   example:
#     check_titles(4, 2, 5)
#   checks if actor 4 has title 2 and puts answer in switch 5
#   -can be used without switch_id 
#
# * check actor title size and assigns it to a variable
#     actor_title_list_size(actor_id, variable_id)
#   example:
#     actor_title_list_size(4, 10) 
#   checks title list size for actor 4 and puts answer in variable 10
#
# * assigns current title_id to variable
#     actor_title_is?(actor_id, variable_id)
#
# * change default graphics to return to if some titles can change it. 
#     change_init_character(actor_id, character_name, character_index)
#     change_init_face(actor_id, face_name, face_index)
#==============================================================================
module BM
module TITLES_SYSTEM 
  #=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  # Titles Customization
  #=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  # Titles can alter the actors' walking graphic and if desired will also change 
  # the face graphic.
  CHANGE_GRAPHIC = true
  # if set to true, can change actor graphic based on those set in custom titles 
  # (if no graphic set, will revert to default)
  # if set to false, no graphic change will occur
  #=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  CUSTOM_TITLES = {
  # format as follows:
  # title_id => ["Title name", "Description"],
  
  # or 
  # title_id => ["Title name", "Description", costume name, costume Index],
  
  # or
  # title_id => ["Title name", "Description", costume name, costume Index, face name, face Index],
    1 => ["Normal",""],
    2 => ["Nobleman","Those of noble birth"],
    3 => ["Privateer","A real scoundrel at heart"],
    4 => ["Crusader","Willing to take on any brave endevour"],
    5 => ["Clumsy Fool","Keep out of the way!"],
    6 => ["Juggler","What goes up, does not fall to the ground."],
    7 => ["Bashful","Don't talk about me like that, I'm going red."],
    8 => ["Tipsy","What wash in thish drink?  Whoops!"],
    9 => ["Wolf","Hungry like a wolf", "Animal",6],
  # Add more titles as you like      
  
  }# don't remove  
  #=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  # Level Up Bonus
  #=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  # titles can add (or subtract) from stats during level up
  TITLE_PARAM_GROWTH_CHANGE = true  
  PARAM_GROWTH = { # do not remove
  #title_id    Hp  Mp Atk Def  Mat  Mdf   Agi   Luk]
         2 => [ 40,  0,  0,  5,  0,   0,   0,    0],
         3 => [ 0,  20,  0,  0,  0,   5,   0,    0],
         4 => [50,  0,  0,  0,  0,   0,   0,    0],
         5 => [10,  0,  0,  0,  0,   0,   0,    0],
         6 => [ 0,  30,  0,  0,  0,   2,   0,    0],
         7 => [ 60,  0,  0,  2,  0,   0,   0,    0],
  # Add more titles as you like                
         
  }# do not remove  
  #=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  # Base Stat Bonus
  #=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  # titles can change base stats  
  TITLE_PARAM_BASE_CHANGE = true
  # change base stat change to :percent or :static
  # :percent (ie. 20 is a 20% increase)
  # :static (ie. 20 is +20)
  TITLE_PARAM_BASE = :percent
  PARAM_BASE = { # do not remove
  #title_id    Hp  Mp Atk Def  Mat  Mdf   Agi   Luk]
         2 => [20,  0,  0,  50,  0,   0,   0,    0],
         3 => [ 0,  20,  0,  0,  0,   50,   0,    0],
         4 => [50,  0,  0,  0,  0,   0,   0,    0],
         5 => [10,  0,  0,  0,  0,   0,   0,    0],
         6 => [ 0,  30,  0,  0,  0,   20,   0,    0],
         7 => [ 60,  0,  0,  20,  0,   0,   0,    0],
  # Add more titles as you like                
         
  }# do not remove
  
  #=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  # - Switch Settings -
  #=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  # These are the switches that govern whether or not certain menu items will
  # appear and/or will be enabled. By binding them to a Switch, you can just
  # set the Switch ON/OFF to show/hide or enable/disable a menu command. If
  # you do not wish to use this feature, set these commands to 0.
  #=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  STATUS_COMMANDS ={ # for YEA Status Menu
  # :command => [EnableSwitch, ShowSwitch, Handler Method, Window Draw],
    :titles    => [ 0,  0, :command_titles, :draw_titles],
  } # DO NOT REMOVE
  MENU_COMMANDS ={ # For main menu
  # :command => ["Display Name", EnableSwitch, ShowSwitch, Handler Method],
    :titles   => [  "Titles",            3,          3, :command_titles],
  } # DO NOT REMOVE
  #=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  # Titles Window Options
  #=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  CURRENT_TITLE_COLOUR = 17
  PARAM_FONT_SIZE = 20 
  # This array sets the order of how classes are ordered in the class listing
  # window. Any class ID's unlisted will not be shown.
  TITLE_ORDER = [1..20]
  DEFAULT_UNLOCKS = [1, 5]   # Titles unlocked by default.
  PARAM_SHOWN = 0..7 # parameters shown when selecting titles
  #=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  # - Titles Scene Commands -
  #=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
  # These settings adjust how the titles scene appears. Here, you can adjust
  # the command list and the order at which items appear. These are mostly
  # visual settings. Adjust them as you see fit.
  COMMANDS =[ # The order at which the menu items are shown.
    # [ :command,   "Display"],
      [ :primary,   "Titles"],
    # [ :custom1,   "Custom1"],
    # [ :custom2,   "Custom2"],
    ] # Do not remove this.
  # For those who use scripts to that may produce unique effects for the
  # titles menu, use this hash to manage the custom commands for the Titles
  # Command Window. You can disable certain commands or prevent them from
  # appearing by using switches. If you don't wish to bind them to a switch,
  # set the proper switch to 0 for it to have no impact.
  #--------------------------------------------------------------------------
  CUSTOM_TITLES_COMMANDS ={
  # :command => [EnableSwitch, ShowSwitch, Handler Method,
    :custom1 => [           0,          0, :command_name1],
    :custom2 => [           0,          0, :command_name2],
  } # Do not remove this.   
  end
end
#===============================================================================
# Editting anything past this point may potentially result in causing computer
# damage, incontinence, explosion of user's head, coma, death, and/or halitosis.
# Therefore, edit at your own risk.
#==============================================================================
# ** module BM
#==============================================================================
module BM
  def self.required(name, req, version, type = nil)
    if !$imported[:bm_base]
      msg = "The script '%s' requires the script\n"
      msg += "'BM - Base' v%s or higher above it to work properly\n"
      msg += "Go to bmscripts.weebly.com to download this script."
      msgbox(sprintf(msg, self.script_name(name), version))
      exit
    else
      self.required_script(name, req, version, type)
    end
  end
  #--------------------------------------------------------------------------
  # * script_name
  #   Get the script name base on the imported value
  #--------------------------------------------------------------------------
  def self.script_name(name, ext = "BM")
    name = name.to_s.gsub("_", " ").upcase.split
    name.collect! {|char| char == ext ? "#{char} -" : char.capitalize }
    name.join(" ")
  end
end
$imported ||= {}
$imported[:bm_titles] = 1.09
BM.required(:bm_titles, :bm_base, 1.00, :above)
#==========================================================================
# ** Game Interpreter
#==========================================================================
class Game_Interpreter
  #--------------------------------------------------------------------------
  # * new method: add title
  #--------------------------------------------------------------------------
  def add_titles(actor_id, title_id)
    $game_actors[actor_id].unlock_title(title_id)
  end
  #--------------------------------------------------------------------------
  # * new method: remove title
  #--------------------------------------------------------------------------
  def remove_titles(actor_id, title_id)
    $game_actors[actor_id].remove_title(title_id)
  end
  #--------------------------------------------------------------------------
  # * new method: change title
  #--------------------------------------------------------------------------
  def change_titles(actor_id, title_id)
    $game_actors[actor_id].change_title(title_id)
  end
  #--------------------------------------------------------------------------
  # * new method: change initial graphic
  #--------------------------------------------------------------------------
  def change_init_character(actor_id, character_name, character_index)
    $game_actors[actor_id].init_titles_graphics_name = character_name
    $game_actors[actor_id].init_titles_graphics_index = character_index
  end
  #--------------------------------------------------------------------------
  def change_init_face(actor_id, face_name, face_index)
    $game_actors[actor_id].init_titles_face_name = face_name
    $game_actors[actor_id].init_titles_face_index = face_index
  end
  #--------------------------------------------------------------------------
  # * new method: actor title is?
  #--------------------------------------------------------------------------
  def actor_title_is?(actor_id, variable_id = 0)
    titles_id = $game_actors[actor_id].title_id
    $game_variables[variable_id] = titles_id if variable_id > 0
    return titles_id
  end
  #--------------------------------------------------------------------------
  # * new method: check titles
  #--------------------------------------------------------------------------
  def check_titles(actor_id, title_id, switch_id = nil)
    in_list = $game_actors[actor_id].unlocked_titles.include?(title_id)
    $game_switches[switch_id] = in_list if switch_id > 0
    return in_list
  end
  #--------------------------------------------------------------------------
  # * new method: title list size
  #--------------------------------------------------------------------------
  def actor_title_list_size(actor, variable_id = 0)
    title_list = $game_actors[actor].unlocked_titles
    $game_variables[variable_id] = title_list.size if variable_id > 0
    return title_list
  end
end
#==========================================================================
# ** BM::TITLES_SYSTEM
#==========================================================================
module BM::TITLES_SYSTEM
  module_function  
  #--------------------------------------------------------------------------
  # convert_integer_array
  #--------------------------------------------------------------------------
  def convert_integer_array(array)
    result = []
    array.each { |i|
      case i
      when Range; result |= i.to_a
      when Integer; result |= [i]
      end }
    return result
  end
  #--------------------------------------------------------------------------
  # converted_contants
  #--------------------------------------------------------------------------
  DEFAULT_UNLOCKS = convert_integer_array(DEFAULT_UNLOCKS)
  TITLE_ORDER = convert_integer_array(TITLE_ORDER)
end
#==============================================================================
module BM
  module REGEXP
  module ACTOR    
    UNLOCKED_TITLES = 
      /<(?:UNLOCKED_TITLES|unlocked titles):[ ]*(\d+(?:\s*,\s*\d+)*)>/i    
    INIT_TITLE = 
      /<(?:INIT_TITLE|init title):[ ](\d+)>/i   
  end # ACTOR
  end # REGEXP
end # YEA
#==============================================================================
# ** Switch
#==============================================================================
module Switch  
  #--------------------------------------------------------------------------
  # self.titles_show
  #--------------------------------------------------------------------------
  def self.titles_show
    return true if BM::TITLES_SYSTEM::MENU_COMMANDS[:titles][2] <= 0
    return $game_switches[BM::TITLES_SYSTEM::MENU_COMMANDS[:titles][2]]
  end
  #--------------------------------------------------------------------------
  # self.titles_enable
  #--------------------------------------------------------------------------
  def self.titles_enable
    return true if BM::TITLES_SYSTEM::MENU_COMMANDS[:titles][1] <= 0
    return $game_switches[BM::TITLES_SYSTEM::MENU_COMMANDS[:titles][1]]
  end    
end # Switch
#==============================================================================
# ** Vocab
#==============================================================================
module Vocab
  def self.titles_name(id)
    return "" unless BM::TITLES_SYSTEM::CUSTOM_TITLES.include?(id)
    return BM::TITLES_SYSTEM::CUSTOM_TITLES[id][0]
  end
end
#==============================================================================
# ** DataManager
#==============================================================================
module DataManager  
  #--------------------------------------------------------------------------
  # alias method: load_database
  #--------------------------------------------------------------------------
  class <<self; alias :bm_titles_ld :load_database; end
  def self.load_database
    bm_titles_ld
    load_notetags_bm_titles
  end  
  #--------------------------------------------------------------------------
  # new method: load_notetags_bm_titles
  #--------------------------------------------------------------------------
  def self.load_notetags_bm_titles
    groups = [$data_actors]
    for group in groups
      for obj in group
        next if obj.nil?
        obj.load_notetags_bm_titles
      end
    end
  end  
end # DataManager
#==============================================================================
# ** RPG::Actor
#==============================================================================
class RPG::Actor < RPG::BaseItem  
  #--------------------------------------------------------------------------
  # public instance variables
  #--------------------------------------------------------------------------
  attr_accessor :unlocked_titles  
  attr_accessor :init_title
  #--------------------------------------------------------------------------
  # common cache: load_notetags_bm_titles
  #--------------------------------------------------------------------------
  def load_notetags_bm_titles
    @unlocked_titles = []
    @init_title = 1
    #---
    self.note.split(/[\r\n]+/).each { |line|
      case line
      #---
      when BM::REGEXP::ACTOR::UNLOCKED_TITLES
        $1.scan(/\d+/).each { |num| 
        @unlocked_titles.push(num.to_i) if num.to_i > 0 }
      when BM::REGEXP::ACTOR::INIT_TITLE
        @init_title = $1.to_i
      #---
      end
    } # self.note.split
    #---
  end  
end # RPG::Actor
#==============================================================================
# ** Game_Temp
#==============================================================================
class Game_Temp  
  #--------------------------------------------------------------------------
  # public instance variables
  #--------------------------------------------------------------------------
  attr_accessor :scene_titles_index
  attr_accessor :scene_titles_oy  
end # Game_Temp
#==============================================================================
# ** Game_BattlerBase
#==============================================================================
class Game_BattlerBase  
  #--------------------------------------------------------------------------
  # public instance variables
  #--------------------------------------------------------------------------
  attr_accessor :temp_flag
  #--------------------------------------------------------------------------
  # * new method: title_param_bonus_growth
  #--------------------------------------------------------------------------
  def title_param_bonus_growth(param_id)
    n = 0.0
    return n unless BM::TITLES_SYSTEM::TITLE_PARAM_GROWTH_CHANGE && BM::TITLES_SYSTEM::PARAM_GROWTH.include?(@title_id)
    if actor?
      n += BM::TITLES_SYSTEM::PARAM_GROWTH[@title_id][param_id]
    end
    return n
  end  
  #--------------------------------------------------------------------------
  # * new method: title_param_bonus_base
  #--------------------------------------------------------------------------
  def title_param_bonus_base(param_id)
    n = 0.0
    return n unless BM::TITLES_SYSTEM::TITLE_PARAM_BASE_CHANGE && BM::TITLES_SYSTEM::PARAM_BASE.include?(@title_id)
    if actor?
      n += BM::TITLES_SYSTEM::PARAM_BASE[@title_id][param_id]
    end
    return n
  end  
end # Game_BattlerBase
#===============================================================================
# Game_actor 
#===============================================================================
class Game_Actor < Game_Battler
  #--------------------------------------------------------------------------
  # * Public Instance Variables
  #--------------------------------------------------------------------------
  attr_accessor :title_id                     # Title id
  #--------------------------------------------------------------------------
  # * alias: setup
  #--------------------------------------------------------------------------
  alias :bm_titles_setup :setup 
  def setup(actor_id)
    bm_titles_setup(actor_id)
    init_unlocked_titles
  end
  #--------------------------------------------------------------------------
  # new method: init_unlocked_titles
  #--------------------------------------------------------------------------
  def init_unlocked_titles
    @title_id = actor.init_title
    @unlocked_titles = actor.unlocked_titles.clone
    @unlocked_titles.push(@title_id) if !@unlocked_titles.include?(@title_id)
    @unlocked_titles.sort!
    @init_titles_graphics_name = @character_name
    @init_titles_graphics_index = @character_index
    @init_titles_face_name = @face_name
    @init_titles_face_index = @face_index
    change_title_graphic(@title_id)
  end
  #--------------------------------------------------------------------------
  # new method: unlocked_titles
  #--------------------------------------------------------------------------
  def unlocked_titles
    init_unlocked_titles if @unlocked_titles.nil?
    return @unlocked_titles
  end
  #--------------------------------------------------------------------------
  # new method: unlock_title
  #--------------------------------------------------------------------------
  def unlock_title(title_id)
    init_unlocked_titles if @unlocked_titles.nil?
    return unless BM::TITLES_SYSTEM::CUSTOM_TITLES.include?(title_id)
    return if @unlocked_titles.include?(title_id)
    @unlocked_titles.push(title_id)
  end
  #--------------------------------------------------------------------------
  # new method: remove_title
  #--------------------------------------------------------------------------
  def remove_title(title_id)
    init_unlocked_titles if @unlocked_titles.nil?
    if title_id == @title_id
      @title_id = 0
    end
    @unlocked_titles.delete(title_id)
    refresh
  end
  #--------------------------------------------------------------------------
  # new method: change_title
  #--------------------------------------------------------------------------
  def change_title(title_id)
    return unless BM::TITLES_SYSTEM::CUSTOM_TITLES.include?(title_id)
    @title_id = title_id
    change_title_graphic(title_id) 
    unlock_title(title_id)
    $game_player.refresh
  end
  #--------------------------------------------------------------------------
  def change_title_graphic(title_id)
    return unless BM::TITLES_SYSTEM::CHANGE_GRAPHIC
    character_name = @init_titles_graphics_name
    character_index = @init_titles_graphics_index
    face_name = @init_titles_face_name
    face_index = @init_titles_face_index
    unless BM::TITLES_SYSTEM::CUSTOM_TITLES[title_id][2].nil?
      character_name = BM::TITLES_SYSTEM::CUSTOM_TITLES[title_id][2]
      character_index = BM::TITLES_SYSTEM::CUSTOM_TITLES[title_id][3]
    end
    unless BM::TITLES_SYSTEM::CUSTOM_TITLES[title_id][4].nil?
      face_name = BM::TITLES_SYSTEM::CUSTOM_TITLES[title_id][4]
      face_index = BM::TITLES_SYSTEM::CUSTOM_TITLES[title_id][5]
    end
    set_graphic(character_name, character_index, face_name, face_index)
    refresh
  end
  #--------------------------------------------------------------------------
  # * alias: param_base
  #--------------------------------------------------------------------------
  alias :bm_title_pb :param_base
  def param_base(param_id)
    result = bm_title_pb(param_id)
    if BM::TITLES_SYSTEM::TITLE_PARAM_BASE == :percent
      result += result * title_param_bonus_base(param_id)/100
    elsif BM::TITLES_SYSTEM::TITLE_PARAM_BASE == :static
      result += title_param_bonus_base(param_id)
    end    
    return result.to_i
  end
  #---------------------------------------------------------------------------
  # alias: level_up
  #---------------------------------------------------------------------------
  alias :bm_title_lup :level_up 
  def level_up
    last_level = @level
    bm_title_lup
    apply_title_param_bonus_growth if last_level != @level  
  end
  #--------------------------------------------------------------------------
  # new method: apply_title_param_bonus_growth
  #--------------------------------------------------------------------------
  def apply_title_param_bonus_growth(rate = 1)
    for i in 0...8 do @param_plus[i] += title_param_bonus_growth(i) * rate end
  end
end 
#==============================================================================
# ** Window_Base
#==============================================================================
class Window_Base < Window
  #--------------------------------------------------------------------------
  # * Alias: convert_escape_characters
  #--------------------------------------------------------------------------
  alias :bm_titles_cec :convert_escape_characters
  def convert_escape_characters(text)
    result = bm_titles_cec(text)
    result = convert_bm_titles_characters(result)    
    return result
  end
  #--------------------------------------------------------------------------
  def convert_bm_titles_characters(result)
    result.gsub!(/\eNTI\[(\d+)\]/i)  { Vocab.titles_name($1.to_i) rescue "" }    
    result.gsub!(/\eATI\[([-+]?\d+)\]/i) {  escape_actor_titles_name($1.to_i) }
    return result
  end
  #--------------------------------------------------------------------------
  # new method: escape_actor_titles_name
  #--------------------------------------------------------------------------
  def escape_actor_titles_name(actor_id)
    actor_id = $game_party.members[actor_id.abs].id if actor_id <= 0
    actor = $game_actors[actor_id]
    return "" if actor.nil?
    return Vocab.titles_name(actor.title_id)
  end
  #--------------------------------------------------------------------------
  def titles_desc(title_id)
    return "" unless BM::TITLES_SYSTEM::CUSTOM_TITLES.include?(title_id)
    desc = BM::TITLES_SYSTEM::CUSTOM_TITLES[title_id][1]
    return (desc == nil) ? "" : desc
  end
  #--------------------------------------------------------------------------
  # new method: draw_actor_title
  #--------------------------------------------------------------------------
  def draw_actor_title(actor, x, y, width = 112)
    change_color(normal_color)
    text = Vocab.titles_name(actor.title_id)
    draw_text(x, y, width, line_height, text)
  end  
end # Window_Base
#==============================================================================
# ** Window_StatusItem
#==============================================================================
class Window_StatusItem < Window_Base
  def draw_titles
    data = []
    for title_id in BM::TITLES_SYSTEM::TITLE_ORDER
      next if !BM::TITLES_SYSTEM::CUSTOM_TITLES.include?(title_id)
      next unless @actor.unlocked_titles.include?(title_id) or 
        BM::TITLES_SYSTEM::DEFAULT_UNLOCKS.include?(title_id)
      data.push(title_id)
    end
    dx = 0; dy = 0; title_index = 0
    for id in data
      item = data[title_index]
      reset_font_settings
      if item == @actor.title_id
        change_color(text_color(BM::TITLES_SYSTEM::CURRENT_TITLE_COLOUR))
      else
        change_color(normal_color)
      end
      text = Vocab.titles_name(item)
      draw_text(24, dy, contents.width-24, line_height, text)
      title_index += 1
      dy += line_height
      break if dy + line_height > contents.height
    end
    dw = Graphics.width * 2 / 5 - 24
    dx = contents.width - dw; dy = 0
    param_id = 0
    for param_id in BM::TITLES_SYSTEM::PARAM_SHOWN
      colour = Color.new(0, 0, 0, translucent_alpha/2)
      rect = Rect.new(dx+1, dy+1, dw - 2, line_height - 2)
      contents.fill_rect(rect, colour)
      contents.font.size = BM::TITLES_SYSTEM::PARAM_FONT_SIZE
      change_color(system_color)
      draw_text(dx+4, dy, dw, line_height, Vocab::param(param_id))
      change_color(normal_color)
      dwa = (Graphics.width * 2 / 5 - 2) / 2
      draw_text(dx, dy, dwa, line_height, @actor.param(param_id).group, 2)
      reset_font_settings
      change_color(system_color)
      draw_text(dx + dwa, dy, 22, line_height, "?", 1)
      dy += line_height
      break if dy + line_height > contents.height
    end
  end
end
#==============================================================================
# ** Window_TitleParam
#==============================================================================
class Window_TitleParam < Window_Base  
  #--------------------------------------------------------------------------
  # initialize
  #--------------------------------------------------------------------------
  def initialize(dx, dy)
    super(dx, dy, window_width, Graphics.height - dy)
    @actor = nil
    @temp_actor = nil
    refresh
  end  
  #--------------------------------------------------------------------------
  # window_width
  #--------------------------------------------------------------------------
  def window_width; return Graphics.width * 2 / 5; end
  #--------------------------------------------------------------------------
  # actor=
  #--------------------------------------------------------------------------
  def actor=(actor)
    return if @actor == actor
    @actor = actor
    refresh
  end  
  #--------------------------------------------------------------------------
  # refresh
  #--------------------------------------------------------------------------
  def refresh
    contents.clear
    dy = 0
    for i in BM::TITLES_SYSTEM::PARAM_SHOWN
      draw_item(0, dy, i)
      dy += line_height
      break if dy + line_height > contents.height
    end
  end  
  #--------------------------------------------------------------------------
  # set_temp_actor
  #--------------------------------------------------------------------------
  def set_temp_actor(temp_actor)
    return if @temp_actor == temp_actor
    @temp_actor = temp_actor
    refresh
  end  
  #--------------------------------------------------------------------------
  # draw_item
  #--------------------------------------------------------------------------
  def draw_item(dx, dy, param_id)
    draw_background_colour(dx, dy)
    draw_param_name(dx + 4, dy, param_id)
    draw_current_param(dx + 4, dy, param_id) if @actor
    drx = (contents.width + 22) / 2
    draw_right_arrow(drx, dy)
    draw_new_param(drx + 22, dy, param_id) if @temp_actor
    reset_font_settings
  end  
  #--------------------------------------------------------------------------
  # draw_background_colour
  #--------------------------------------------------------------------------
  def draw_background_colour(dx, dy)
    colour = Color.new(0, 0, 0, translucent_alpha/2)
    rect = Rect.new(dx+1, dy+1, contents.width - 2, line_height - 2)
    contents.fill_rect(rect, colour)
  end  
  #--------------------------------------------------------------------------
  # draw_param_name
  #--------------------------------------------------------------------------
  def draw_param_name(dx, dy, param_id)
    contents.font.size = BM::TITLES_SYSTEM::PARAM_FONT_SIZE
    change_color(system_color)
    draw_text(dx, dy, contents.width, line_height, Vocab::param(param_id))
  end  
  #--------------------------------------------------------------------------
  # draw_current_param
  #--------------------------------------------------------------------------
  def draw_current_param(dx, dy, param_id)
    change_color(normal_color)
    dw = (contents.width + 22) / 2
    draw_text(0, dy, dw, line_height, @actor.param(param_id).group, 2)
    reset_font_settings
  end  
  #--------------------------------------------------------------------------
  # draw_right_arrow
  #--------------------------------------------------------------------------
  def draw_right_arrow(x, y)
    change_color(system_color)
    draw_text(x, y, 22, line_height, "?", 1)
  end  
  #--------------------------------------------------------------------------
  # draw_new_param
  #--------------------------------------------------------------------------
  def draw_new_param(dx, dy, param_id)
    contents.font.size = BM::TITLES_SYSTEM::PARAM_FONT_SIZE
    new_value = @temp_actor.param(param_id)
    change = new_value - @actor.param(param_id)
    change_color(param_change_color(change))
    w = contents.text_size(new_value).width
    draw_icon(Icon.param_compare(change), contents.width-w-12, dy) if $imported[:bm_icon]    
    draw_text(0, dy, contents.width-4, line_height, new_value.group, 2)
    reset_font_settings
  end  
end 
#==============================================================================
# � Window_TitleList
#==============================================================================
class Window_TitleList < Window_Selectable  
  #--------------------------------------------------------------------------
  # initialize
  #--------------------------------------------------------------------------
  def initialize(dx, dy)
    dw = Graphics.width - (Graphics.width * 2 / 5)
    dh = Graphics.height - dy
    super(dx, dy, dw, dh)
    @actor = nil
    @command_window = nil
    @status_window
    @data = []
  end  
  #--------------------------------------------------------------------------
  # actor=
  #--------------------------------------------------------------------------
  def actor=(actor)
    return if @actor == actor
    @actor = actor
    @last_item = nil
    refresh
    self.oy = 0
  end  
  #--------------------------------------------------------------------------
  # command_window=
  #--------------------------------------------------------------------------
  def command_window=(command_window)
    @command_window = command_window
  end  
  #--------------------------------------------------------------------------
  # status_window=
  #--------------------------------------------------------------------------
  def status_window=(status_window)
    @status_window = status_window
  end  
  #--------------------------------------------------------------------------
  # item_max
  #--------------------------------------------------------------------------
  def item_max; return @data ? @data.size : 1; end  
  #--------------------------------------------------------------------------
  # item
  #--------------------------------------------------------------------------
  def item; return @data && index >= 0 ? @data[index] : nil; end  
  #--------------------------------------------------------------------------
  # current_item_enabled?
  #--------------------------------------------------------------------------
  def current_item_enabled?; return enable?(@data[index]); end  
  #--------------------------------------------------------------------------
  # include?
  #--------------------------------------------------------------------------
  def include?(item)
    return true if BM::TITLES_SYSTEM::DEFAULT_UNLOCKS.include?(item)
    return @actor.unlocked_titles.include?(item)
  end  
  #--------------------------------------------------------------------------
  # enable?
  #--------------------------------------------------------------------------
  def enable?(item)
    return false if item == @actor.title_id
    return true
  end  
  #--------------------------------------------------------------------------
  # make_item_list
  #--------------------------------------------------------------------------
  def make_item_list
    @data = []
    for title_id in BM::TITLES_SYSTEM::TITLE_ORDER
      next if BM::TITLES_SYSTEM::CUSTOM_TITLES[title_id].nil?
      item = title_id
      @data.push(item) if include?(item)
    end
  end  
  #--------------------------------------------------------------------------
  # select_last
  #--------------------------------------------------------------------------
  def select_last
    case @command_window.current_symbol
    when :primary
      select(@data.index(@actor.title_id))
    else
      select(0)
    end
  end  
  #--------------------------------------------------------------------------
  # draw_item
  #--------------------------------------------------------------------------
  def draw_item(index)
    item = @data[index]
    return if item.nil?
    rect = item_rect(index)
    rect.width -= 4
    reset_font_settings
    set_item_colour(item)
    draw_titles_name(item, rect)
  end  
  #--------------------------------------------------------------------------
  # set_item_colour
  #--------------------------------------------------------------------------
  def set_item_colour(item)
    if item == @actor.title_id
      change_color(text_color(BM::TITLES_SYSTEM::CURRENT_TITLE_COLOUR))
    else
      change_color(normal_color, enable?(item))
    end
  end
  #--------------------------------------------------------------------------
  # draw_titles_name
  #--------------------------------------------------------------------------
  def draw_titles_name(item, rect)
    text = Vocab.titles_name(item)
    draw_text(24, rect.y, rect.width-24, line_height, text)
  end
  #--------------------------------------------------------------------------
  # update_help
  #--------------------------------------------------------------------------
  def update_help
    @help_window.set_text(Vocab.titles_name(item) ? titles_desc(item) : "")
    return if @actor.nil?
    return if @status_window.nil?
    update_param_window
  end  
  #--------------------------------------------------------------------------
  # update_param_window
  #--------------------------------------------------------------------------
  def update_param_window
    return if @last_item == item
    @last_item = item
    title_id = item.nil? ? @actor.title_id : item
    temp_actor = Marshal.load(Marshal.dump(@actor))
    temp_actor.temp_flag = true
    case @command_window.current_symbol
    when :primary
      temp_actor.change_title(title_id)
    end
    @status_window.set_temp_actor(temp_actor)
  end  
  #--------------------------------------------------------------------------
  # update_titles
  #--------------------------------------------------------------------------
  def update_titles
    @last_item = nil
    update_help
    refresh
    activate
  end  
  #--------------------------------------------------------------------------
  # refresh
  #--------------------------------------------------------------------------
  def refresh
    make_item_list
    create_contents
    draw_all_items
  end  
end 
#==============================================================================
# � Window_MenuCommand
#==============================================================================
class Window_MenuCommand < Window_Command  
  #--------------------------------------------------------------------------
  # alias method: add_formation_command
  #--------------------------------------------------------------------------
  alias :bm_titles_aoc :add_original_commands
  def add_original_commands
    add_titles_command unless $imported["YEA-AceMenuEngine"]
    bm_titles_aoc
  end  
  #--------------------------------------------------------------------------
  # new method: add_titles_command
  #--------------------------------------------------------------------------
  def add_titles_command
    return unless Switch.titles_show
    text = BM::TITLES_SYSTEM::MENU_COMMANDS[:titles][0]
    add_command(text, :titles, Switch.titles_enable)
  end  
end # Window_MenuCommand
#==============================================================================
# � Window_TitlesCommand
#==============================================================================
class Window_TitlesCommand < Window_Command  
  #--------------------------------------------------------------------------
  # initialize
  #--------------------------------------------------------------------------
  def initialize(x, y)
    super(x, y)
    @actor = nil
  end  
  #--------------------------------------------------------------------------
  # ? ?????????
  #--------------------------------------------------------------------------
  def window_width; return 160; end  
  #--------------------------------------------------------------------------
  # actor=
  #--------------------------------------------------------------------------
  def actor=(actor)
    return if @actor == actor
    @actor = actor
    refresh
  end  
  #--------------------------------------------------------------------------
  # item_window=
  #--------------------------------------------------------------------------
  def item_window=(window)
    @item_window = window
  end  
  #--------------------------------------------------------------------------
  # visible_line_number
  #--------------------------------------------------------------------------
  def visible_line_number; return 4; end  
  #--------------------------------------------------------------------------
  # make_command_list
  #--------------------------------------------------------------------------
  def make_command_list
    return if @actor.nil?
    for command in BM::TITLES_SYSTEM::COMMANDS
      case command[0]
      when :primary
        add_command(command[1], command[0])
      else
        process_custom_command(command)
      end
    end
    if !$game_temp.scene_titles_index.nil?
      select($game_temp.scene_titles_index)
      self.oy = $game_temp.scene_titles_oy
    end
    $game_temp.scene_titles_index = nil
    $game_temp.scene_titles_oy = nil
  end  
  #--------------------------------------------------------------------------
  # process_ok
  #--------------------------------------------------------------------------
  def process_ok
    $game_temp.scene_titles_index = index
    $game_temp.scene_titles_oy = self.oy
    super
  end  
  #--------------------------------------------------------------------------
  # process_custom_command
  #--------------------------------------------------------------------------
  def process_custom_command(command)
    return unless BM_TITLES_SYSTEM::CUSTOM_TITLES_COMMANDS.include?(command[0])
    show =  BM_TITLES_SYSTEM::CUSTOM_TITLES_COMMANDS[command[0]][1]
    continue = show <= 0 ? true : $game_switches[show]
    return unless continue
    text = command[1]
    switch =  BM_TITLES_SYSTEM::CUSTOM_TITLES_COMMANDS[command[0]][0]
    enabled = switch <= 0 ? true : $game_switches[switch]
    add_command(text, command[0], enabled)
  end
  #--------------------------------------------------------------------------
  # update
  #--------------------------------------------------------------------------
  def update
    super
    update_visible_windows
  end  
  #--------------------------------------------------------------------------
  # update_visible_windows
  #--------------------------------------------------------------------------
  def update_visible_windows
    return if @current_index == current_symbol
    @current_index = current_symbol
    @item_window.refresh unless @item_window.nil?
  end   
end 
#==============================================================================
# ** Scene_Menu
#==============================================================================
class Scene_Menu < Scene_MenuBase  
  #--------------------------------------------------------------------------
  # alias method: create_command_window
  #--------------------------------------------------------------------------
  alias :bm_titles_ccw :create_command_window
  def create_command_window
    bm_titles_ccw
    @command_window.set_handler(:titles, method(:command_personal))
  end  
  #--------------------------------------------------------------------------
  # alias method: on_personal_ok
  #--------------------------------------------------------------------------
  alias :bm_titles_opk :on_personal_ok
  def on_personal_ok
    case @command_window.current_symbol
    when :titles
      command_titles
    else
      bm_titles_opk
    end
  end
  #--------------------------------------------------------------------------
  # new method: command_titles
  #--------------------------------------------------------------------------
  def command_titles
    SceneManager.call(Scene_Titles)
  end  
end # Scene_Menu
#==============================================================================
# ** Scene_Titles
#==============================================================================
class Scene_Titles < Scene_MenuBase  
  #--------------------------------------------------------------------------
  # start
  #--------------------------------------------------------------------------
  def start
    super
    create_help_window
    create_command_window
    create_status_window
    create_param_window
    create_item_window
    relocate_windows
  end  
  #--------------------------------------------------------------------------
  # create_command_window
  #--------------------------------------------------------------------------
  def create_command_window
    wy = @help_window.height
    @command_window = Window_TitlesCommand.new(0, wy)
    @command_window.viewport = @viewport
    @command_window.help_window = @help_window
    @command_window.actor = @actor
    @command_window.set_handler(:cancel,   method(:return_scene))
    @command_window.set_handler(:primary,  method(:command_title_change))
    process_custom_class_commands
    return if $game_party.in_battle
    @command_window.set_handler(:pagedown, method(:next_actor))
    @command_window.set_handler(:pageup,   method(:prev_actor))
  end
  #--------------------------------------------------------------------------
  # process_custom_class_commands
  #--------------------------------------------------------------------------
  def process_custom_class_commands
    for command in BM::TITLES_SYSTEM::COMMANDS
      next unless BM::TITLES_SYSTEM::CUSTOM_TITLES_COMMANDS.include?(command[0])
      called_method = BM::TITLES_SYSTEM::CUSTOM_TITLES_COMMANDS[command[0]][2]
      @command_window.set_handler(command[0], method(called_method))
    end
  end
  #--------------------------------------------------------------------------
  # create_status_window
  #--------------------------------------------------------------------------
  def create_status_window
    wy = @help_window.height
    @status_window = Window_SkillStatus.new(@command_window.width, wy)
    @status_window.viewport = @viewport
    @status_window.actor = @actor
  end  
  #--------------------------------------------------------------------------
  # create_param_window
  #--------------------------------------------------------------------------
  def create_param_window
    dx = Graphics.width - (Graphics.width * 2 / 5)
    dy = @status_window.y + @status_window.height
    @param_window = Window_TitleParam.new(dx, dy)
    @param_window.viewport = @viewport
    @param_window.actor = @actor
  end  
  #--------------------------------------------------------------------------
  # create_item_window
  #--------------------------------------------------------------------------
  def create_item_window
    dy = @status_window.y + @status_window.height
    @item_window = Window_TitleList.new(0, dy)
    @item_window.help_window = @help_window
    @item_window.command_window = @command_window
    @item_window.status_window = @param_window
    @item_window.viewport = @viewport
    @item_window.actor = @actor
    @command_window.item_window = @item_window
    @item_window.set_handler(:ok,     method(:on_title_ok))
    @item_window.set_handler(:cancel, method(:on_title_cancel))
  end  
  #--------------------------------------------------------------------------
  # relocate_windows
  #--------------------------------------------------------------------------
  def relocate_windows
    return unless $imported["YEA-AceMenuEngine"]
    case Menu.help_window_location
    when 0 # Top
      @help_window.y = 0
      @command_window.y = @help_window.height
      @param_window.y = @command_window.y + @command_window.height
    when 1 # Middle
      @command_window.y = 0
      @help_window.y = @command_window.height
      @param_window.y = @help_window.y + @help_window.height
    else # Bottom
      @command_window.y = 0
      @param_window.y = @command_window.height
      @help_window.y = @param_window.y + @param_window.height
    end
    @status_window.y = @command_window.y
    @item_window.y = @param_window.y
  end  
  #--------------------------------------------------------------------------
  # on_actor_change
  #--------------------------------------------------------------------------
  def on_actor_change
    @command_window.actor = @actor
    @status_window.actor = @actor
    @param_window.actor = @actor
    @item_window.actor = @actor
    @command_window.activate
  end
  #--------------------------------------------------------------------------
  # command_title_change
  #--------------------------------------------------------------------------
  def command_title_change
    @item_window.activate
    @item_window.select_last
  end  
  #--------------------------------------------------------------------------
  # on_title_cancel
  #--------------------------------------------------------------------------
  def on_title_cancel
    @item_window.unselect
    @command_window.activate
    @param_window.set_temp_actor(nil)
  end  
  #--------------------------------------------------------------------------
  # on_title_ok
  #--------------------------------------------------------------------------
  def on_title_ok
    Sound.play_equip
    title_id = @item_window.item
    hp = @actor.hp * 1.0 / @actor.mhp
    mp = @actor.mp * 1.0 / [@actor.mmp, 1].max
    case @command_window.current_symbol
    when :primary
      @actor.change_title(title_id)
    else
      @item_window.activate
      return
    end
    @actor.hp = (@actor.mhp * hp).to_i
    @actor.mp = (@actor.mmp * mp).to_i
    @status_window.refresh
    @item_window.update_titles
  end
  #--------------------------------------------------------------------------
  # command_name1
  #--------------------------------------------------------------------------
  def command_name1
    # Do nothing.
  end  
  #--------------------------------------------------------------------------
  # command_name2
  #--------------------------------------------------------------------------
  def command_name2
    # Do nothing.
  end
end
#==============================================================================
# ** Scene_Status
#==============================================================================
class Scene_Status < Scene_MenuBase
  #--------------------------------------------------------------------------
  # new method: command_titles
  #--------------------------------------------------------------------------
  def command_titles
    SceneManager.call(Scene_Titles)
  end  
end # Scene_Status
#==============================================================================
if $imported["YEA-StatusMenu"]
  if !YEA::STATUS::CUSTOM_STATUS_COMMANDS.include?(:titles)
    YEA::STATUS::CUSTOM_STATUS_COMMANDS.merge!(BM::TITLES_SYSTEM::STATUS_COMMANDS)
  end
end
#==============================================================================
if $imported["YEA-AceMenuEngine"]
  if !YEA::MENU::CUSTOM_COMMANDS.include?(:titles)
    YEA::MENU::CUSTOM_COMMANDS.merge!(BM::TITLES_SYSTEM::MENU_COMMANDS)
  end
end