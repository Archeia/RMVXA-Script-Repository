#==============================================================================
# ** Blackmorning -> Advanced Item/Skill Scene
#------------------------------------------------------------------------------
#  Blackmorning
#  Version 1.0
#  released 11/05/2015
#==============================================================================
#  - INTRODUCTION -
# - can change background image 
# - can change opacity of item/skill scene
# - changes style of actor window
#==============================================================================
# ? Instructions
# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# To install this script, open up your script editor and copy/paste this script
# to an open slot below BM - Base but above ? Main. 
# If using BM - Advanced Menu, put this below it.
# Remember to save.
#==============================================================================
module BM
  module SCENE
    ITEM_BG_OPTIONS ={
      :win_opacity  => 255,    # window opacity for menu
      :show_bg_img  => false, # show background image
      :bg_image     => "StarlitSky",   # image name (Located in Graphics/System
      :bg_opacity   => 255,  # background image opacity
      :bg_scroll_x  => 0,    # horizontal movement
      :bg_scroll_y  => 0,    # vertical movement
    }# DO NOT REMOVE
    ACTOR_OPTIONS={ # for item/skill selection
      :image        => :char,  #:face or :char to show scaled down face or the character graphic
      :ani_sel      => true, # bounces selected actor image
      :walk_char    => true, # walking actor graphics (may slow down game in menu) 
      :image_width  => 40, # width of face
      :image_height => 40, # height of face
      :hp_fontsize  => 16,   # font size of hp and mp gauge
      :hpmp_box     => true, # darkens area around hp,mp,tp gauges
    }# DO NOT REMOVE
    SKILL_BG_OPTIONS ={
      :win_opacity  => 255,    # window opacity for menu
      :show_bg_img  => false, # show background image
      :bg_image     => "StarlitSky",   # image name (Located in Graphics/System
      :bg_opacity   => 255,  # background image opacity
      :bg_scroll_x  => 0,    # horizontal movement
      :bg_scroll_y  => 0,    # vertical movement
    }# DO NOT REMOVE
  end
end
#==============================================================================
# Editting anything past this point may potentially result in causing computer
# damage, incontinence, explosion of user's head, coma, death, and/or halitosis.
# Therefore, edit at your own risk.
#==============================================================================
module BM
  def self.required(name, req, version, type = nil)
    if !$imported[:bm_base]
      msg = "The script '%s' requires the script\n"
      msg += "'BM - Base' v%s or higher above it to work properly\n"
      msg += "Go to bmscripts.weebly.com to download this script."
      msgbox(sprintf(msg, self.script_name(name), version))
      exit
    else
      self.required_script(name, req, version, type)
    end
  end
  #--------------------------------------------------------------------------
  # * script_name
  #   Get the script name base on the imported value
  #--------------------------------------------------------------------------
  def self.script_name(name, ext = "BM")
    name = name.to_s.gsub("_", " ").upcase.split
    name.collect! {|char| char == ext ? "#{char} -" : char.capitalize }
    name.join(" ")
  end
end
#==============================================================================
$imported ||= {}
$imported[:bm_item_skill] = 1.00
BM.required(:bm_item_skill, :bm_base, 1.23, :above)
#=============================================================================#
# ** Window_MenuStatus 
#=============================================================================#
unless $imported[:bm_menustatus]
class Window_MenuStatus < Window_Selectable
  #--------------------------------------------------------------------------
  # * Alias: Object Initialization
  #--------------------------------------------------------------------------
  alias :bm_menu_init :initialize
  def initialize(*args, &block)
    @walk = 0
    @step = 0  # 0 is left, 1 is right
    @animtime = 0
    @e_images = {}
    bm_menu_init(*args, &block)
  end  
end
end
#==============================================================================
# ** Window_ItemList
#==============================================================================
class Window_ItemList < Window_Selectable
  #--------------------------------------------------------------------------
  # * Overwrite: col max
  #--------------------------------------------------------------------------
  def col_max; return 1; end
end
#==============================================================================
# ** Window_battleitem
#==============================================================================
class Window_BattleItem < Window_ItemList
  #--------------------------------------------------------------------------
  # * Overwrite: col max
  #--------------------------------------------------------------------------
  def col_max; return 2; end
end
#==============================================================================
# ** Scene_Item
#==============================================================================
class Scene_Item < Scene_ItemBase
  alias :bm_item_start :start
  def start
    bm_item_start
    bm_win_opacity
  end
  #--------------------------------------------------------------------------
  def bm_win_opacity
    @category_window.opacity = BM::SCENE::ITEM_BG_OPTIONS[:win_opacity] unless @category_window.nil?
    @help_window.opacity = BM::SCENE::ITEM_BG_OPTIONS[:win_opacity] unless @help_window.nil?
    @item_window.opacity = BM::SCENE::ITEM_BG_OPTIONS[:win_opacity] unless @item_window.nil?
    @actor_window.opacity = BM::SCENE::ITEM_BG_OPTIONS[:win_opacity] unless @actor_window.nil?
  end
  #--------------------------------------------------------------------------
  # * Create Background Image
  #--------------------------------------------------------------------------
  alias :bm_item_cb :create_background
  def create_background
    return bm_item_cb unless custom_bg? && !$imported[:bm_menustatus] 
    custom_background
  end
  #--------------------------------------------------------------------------
  def custom_bg?
    return false if BM::SCENE::ITEM_BG_OPTIONS[:bg_image] == "" 
    return false unless BM::SCENE::ITEM_BG_OPTIONS[:show_bg_img]
    return true
  end
  #--------------------------------------------------------------------------
  def custom_background
    @background_sprite = Plane.new
    @background_sprite.bitmap = Cache.system(BM::SCENE::ITEM_BG_OPTIONS[:bg_image])
    @background_sprite.opacity = BM::SCENE::ITEM_BG_OPTIONS[:bg_opacity]
  end
  #--------------------------------------------------------------------------
  def update_background
    return if BM::SCENE::ITEM_BG_OPTIONS[:bg_scroll_x] == 0 && BM::SCENE::ITEM_BG_OPTIONS[:bg_scroll_y] == 0
    @background_sprite.ox += BM::SCENE::ITEM_BG_OPTIONS[:bg_scroll_x]
    @background_sprite.oy += BM::SCENE::ITEM_BG_OPTIONS[:bg_scroll_y]
  end
  #--------------------------------------------------------------------------
  # * Update_Background_Image
  #--------------------------------------------------------------------------
  alias :bm_item_u :update
  def update
    bm_item_u
    update_background if custom_bg? && !$imported[:bm_menustatus] 
  end
  #--------------------------------------------------------------------------
  # * Overwrite: show sub window
  #--------------------------------------------------------------------------
  def show_sub_window(window); window.activate; end
  #--------------------------------------------------------------------------
  # * Overwrite: hide sub window
  #--------------------------------------------------------------------------
  def hide_sub_window(window)
    window.deactivate
    activate_item_window
  end
  #--------------------------------------------------------------------------
  # * Overwrite: Create Actor Window
  #--------------------------------------------------------------------------
  def create_actor_window
    @actor_window = Window_MenuActor.new(:item)
    @actor_window.set_handler(:ok,     method(:on_actor_ok))
    @actor_window.set_handler(:cancel, method(:on_actor_cancel))
  end
  #--------------------------------------------------------------------------
  # * Overwrite: create item window
  #--------------------------------------------------------------------------
  def create_item_window
    wy = @category_window.y + @category_window.height
    ww = Graphics.width - @actor_window.width
    wh = Graphics.height - wy
    @item_window = Window_ItemList.new(0, wy, ww, wh)
    @item_window.viewport = @viewport
    @item_window.help_window = @help_window
    @item_window.set_handler(:ok,     method(:on_item_ok))
    @item_window.set_handler(:cancel, method(:on_item_cancel))
    @category_window.item_window = @item_window
  end
  #--------------------------------------------------------------------------
  # new method: relocate_windows
  #--------------------------------------------------------------------------
  def relocate_windows
    return unless $imported["YEA-AceMenuEngine"]
    case Menu.help_window_location
    when 0 # Top
      @help_window.y = 0
      @category_window.y = @help_window.height
      @item_window.y = @category_window.y + @category_window.height
    when 1 # Middle
      @category_window.y = 0
      @help_window.y = @category_window.height
      @item_window.y = @help_window.y + @help_window.height
    else # Bottom
      @category_window.y = 0
      @item_window.y = @category_window.height
      @help_window.y = @item_window.y + @item_window.height
    end
    if $imported["YEA-ItemMenu"]
      @types_window.y = @category_window.y
      @status_window.y = @category_window.y
    end
    @actor_window.y = @item_window.y
  end
end
#==============================================================================
# ** Window_skillList
#============================================================================== 
class Window_SkillList < Window_Selectable
  #--------------------------------------------------------------------------
  # * Overwrite: col max
  #--------------------------------------------------------------------------
  def col_max; return 1; end
end  
#==============================================================================
# ** Window_battleskill
#==============================================================================  
class Window_BattleSkill < Window_SkillList
  #--------------------------------------------------------------------------
  # * Overwrite: col max
  #--------------------------------------------------------------------------
  def col_max; return 2; end
end
#==============================================================================
# ** Scene_Skill
#==============================================================================
class Scene_Skill < Scene_ItemBase
  alias :bm_skill_start :start
  def start
    bm_skill_start
    bm_win_opacity
  end
  #--------------------------------------------------------------------------
  def bm_win_opacity
    @command_window.opacity = BM::SCENE::SKILL_BG_OPTIONS[:win_opacity] unless @command_window.nil?
    @help_window.opacity = BM::SCENE::SKILL_BG_OPTIONS[:win_opacity] unless @help_window.nil?
    @status_window.opacity = BM::SCENE::SKILL_BG_OPTIONS[:win_opacity] unless @status_window.nil?
    @item_window.opacity = BM::SCENE::SKILL_BG_OPTIONS[:win_opacity] unless @item_window.nil?
    @actor_window.opacity = BM::SCENE::SKILL_BG_OPTIONS[:win_opacity] unless @actor_window.nil?
  end
  #--------------------------------------------------------------------------
  # * Create Background Image
  #--------------------------------------------------------------------------
  alias :bm_skill_cb :create_background
  def create_background
    return bm_skill_cb unless custom_bg? && !$imported[:bm_menustatus] 
    custom_background
  end
  #--------------------------------------------------------------------------
  def custom_bg?
    return false if BM::SCENE::SKILL_BG_OPTIONS[:bg_image] == "" 
    return false unless BM::SCENE::SKILL_BG_OPTIONS[:show_bg_img]
    return true
  end
  #--------------------------------------------------------------------------
  def custom_background
    @background_sprite = Plane.new
    @background_sprite.bitmap = Cache.system(BM::SCENE::SKILL_BG_OPTIONS[:bg_image])
    @background_sprite.opacity = BM::SCENE::SKILL_BG_OPTIONS[:bg_opacity]
  end
  #--------------------------------------------------------------------------
  def update_background
    return if BM::SCENE::SKILL_BG_OPTIONS[:bg_scroll_x] == 0 && BM::SCENE::SKILL_BG_OPTIONS[:bg_scroll_y] == 0
    @background_sprite.ox += BM::SCENE::SKILL_BG_OPTIONS[:bg_scroll_x]
    @background_sprite.oy += BM::SCENE::SKILL_BG_OPTIONS[:bg_scroll_y]
  end
  #--------------------------------------------------------------------------
  # * Update_Background_Image
  #--------------------------------------------------------------------------
  alias :bm_skill_u :update
  def update
    bm_skill_u
    update_background if custom_bg? && !$imported[:bm_menustatus] 
  end
  #--------------------------------------------------------------------------
  # * Overwrite: show sub window
  #--------------------------------------------------------------------------
  def show_sub_window(window); window.activate; end
  #--------------------------------------------------------------------------
  # * Overwrite: hide sub window
  #--------------------------------------------------------------------------
  def hide_sub_window(window)
    window.deactivate
    activate_item_window
  end
  #--------------------------------------------------------------------------
  # * Overwrite: Create Actor Window
  #--------------------------------------------------------------------------
  def create_actor_window
    @actor_window = Window_MenuActor.new(:skill)
    @actor_window.set_handler(:ok,     method(:on_actor_ok))
    @actor_window.set_handler(:cancel, method(:on_actor_cancel))
  end
  #--------------------------------------------------------------------------
  # * Overwrite: create item window
  #--------------------------------------------------------------------------
  def create_item_window
    wy = @status_window.y + @status_window.height
    ww = Graphics.width - @actor_window.width
    wh = Graphics.height - wy
    @item_window = Window_SkillList.new(0, wy, ww, wh)
    @item_window.actor = @actor
    @item_window.viewport = @viewport
    @item_window.help_window = @help_window
    @item_window.set_handler(:ok,     method(:on_item_ok))
    @item_window.set_handler(:cancel, method(:on_item_cancel))
    @command_window.skill_window = @item_window
  end
  #--------------------------------------------------------------------------
  # new method: relocate_windows
  #--------------------------------------------------------------------------
  def relocate_windows
    return unless $imported["YEA-AceMenuEngine"]
    case Menu.help_window_location
    when 0 # Top
      @help_window.y = 0
      @command_window.y = @help_window.height
      @status_window.y = @help_window.height
      @item_window.y = @status_window.y + @status_window.height
    when 1 # Middle
      @command_window.y = 0
      @status_window.y = 0
      @help_window.y = @status_window.y + @status_window.height
      @item_window.y = @help_window.y + @help_window.height
    else # Bottom
      @command_window.y = 0
      @status_window.y = 0
      @item_window.y = @status_window.y + @status_window.height
      @help_window.y = @item_window.y + @item_window.height
    end
    @actor_window.y = @item_window.y
  end
end
#==============================================================================
# ** Window_Menu Actor
#==============================================================================
class Window_MenuActor < Window_MenuStatus
  #--------------------------------------------------------------------------
  # * Overwrite: initialize
  #--------------------------------------------------------------------------
  def initialize(type = :item)
    @type = type
    @walk = 0
    @step = 0  # 0 is left, 1 is right
    @animtime = 0
    @e_images = {}
    super(Graphics.width - window_width, window_y)
  end
  #--------------------------------------------------------------------------
  # * Overwrite: window_y
  #--------------------------------------------------------------------------
  def window_y
    if $imported["YEA-ItemMenu"] || @type == :skill
      return fitting_height(4) + fitting_height(BM::HELP_SIZE)
    elsif @type == :item
      return fitting_height(1) + fitting_height(BM::HELP_SIZE)
    elsif $imported["YEA-ShopOptions"] && @type == :shop
      return fitting_height(4) + fitting_height(BM::HELP_SIZE)
    elsif $imported["YSE-GuardianMenu"] && @type == :guard
      return fitting_height(4) + fitting_height(BM::HELP_SIZE)
    end
  end
  #--------------------------------------------------------------------------
  # * Overwrite: window_height
  #--------------------------------------------------------------------------
  def window_height; Graphics.height - window_y; end
  #--------------------------------------------------------------------------
  # * Overwrite: window width
  #--------------------------------------------------------------------------
  def window_width; Graphics.width * 2 / 5; end
  #--------------------------------------------------------------------------
  # * Overwrite: col max
  #--------------------------------------------------------------------------
  def col_max; 1; end
  #--------------------------------------------------------------------------
  # * Overwrite: page row max
  #--------------------------------------------------------------------------
  def page_row_max; member_size;  end
  #--------------------------------------------------------------------------
  # * Overwrite: visible line number
  #--------------------------------------------------------------------------
  def visible_line_number; member_size; end
  #--------------------------------------------------------------------------
  # new method: member_size
  #--------------------------------------------------------------------------
  def member_size
    ms = $game_party.max_battle_members
    minh = (416 - window_y - standard_padding * 2) / 4
    minh = BM::SCENE::ACTOR_OPTIONS[:image_height] if BM::SCENE::ACTOR_OPTIONS[:image] == :face
    loop do
      maxh = (height - standard_padding * 2) / ms
      if maxh >= minh; return ms; end
      ms -= 1
    end
    return ms
  end
  #--------------------------------------------------------------------------
  # * Overwrite: row max
  #--------------------------------------------------------------------------
  def row_max; [(item_max + col_max - 1) / col_max, 1].max; end
  #--------------------------------------------------------------------------
  # * Overwrite: Get Item Height
  #--------------------------------------------------------------------------
  def item_height; (height - standard_padding * 2) / member_size;  end
  #--------------------------------------------------------------------------
  # * Overwrite: draw item
  #--------------------------------------------------------------------------
  def draw_item(index)
    reset_font_settings
    contents.font.size = 14
    actor = $game_party.members[index]
    enabled = battle_party?(actor)
    rect = item_rect(index)
    draw_item_background(index)
    contents.fill_rect(rect.x, rect.y, item_width, item_height, standby_color(actor))
    dy = rect.y
    dy = rect.y + @walk*5 if index == @index && self.active && BM::SCENE::ACTOR_OPTIONS[:ani_sel]
    iwidth = BM::SCENE::ACTOR_OPTIONS[:image_width]
    iheight = BM::SCENE::ACTOR_OPTIONS[:image_height]
    image_rect = Rect.new(rect.x, dy + 18, iwidth, iheight)
    if BM::SCENE::ACTOR_OPTIONS[:image] == :face
      draw_icon_face(actor, image_rect, enabled)
    elsif BM::SCENE::ACTOR_OPTIONS[:image] == :char
      draw_actor_graphic(actor, rect.x + 16, dy + item_height, enabled)
    end
    draw_actor_simple_status(actor, rect.x, rect.y)
  end
  #--------------------------------------------------------------------------
  # * Overwrite: Draw Simple Status
  #--------------------------------------------------------------------------
  def draw_actor_simple_status(actor, x, y)
    draw_actor_name(actor, x + 32, y)    
    contents.font.size = BM::SCENE::ACTOR_OPTIONS[:hp_fontsize]
    draw_actor_icons(actor, x + 32, y + line_height, 48)
    dx = x + 90
    dy = y + (item_height - line_height*2)/2
    color = Color.new(0, 0, 0, 128)
    contents.fill_rect(dx, y, item_width-dx, item_height+4, color) if BM::SCENE::ACTOR_OPTIONS[:hpmp_box]
    draw_actor_hp(actor, dx + 4, dy + line_height*0 - 0,item_width-dx-8)
    draw_actor_mp(actor, dx + 4, dy + line_height*1 - 4,item_width-dx-8)
  end
  #--------------------------------------------------------------------------
  # * Overwrite: Draw Name
  #--------------------------------------------------------------------------
  def draw_actor_name(actor, x, y)
    contents.font.bold = true
    contents.font.color = hp_color(actor)
    contents.draw_text(x, y, item_width - 136, line_height, actor.name)
    contents.font.color = normal_color
    contents.font.bold = false
  end 
  #--------------------------------------------------------------------------
  # * Alias: update
  #--------------------------------------------------------------------------
  alias :bm_scene_up :update
  def update
    bm_scene_up
    ani_motion if BM::SCENE::ACTOR_OPTIONS[:walk_char] 
  end
end
if $imported["YSE-GuardianMenu"]
#==============================================================================
# ** Scene_GuardianMenu
#==============================================================================
class Scene_GuardianMenu < Scene_MenuBase
  #--------------------------------------------------------------------------
  # overwrite method: show_sub_window
  #--------------------------------------------------------------------------
  def show_sub_window(window)
    @status_window.visible = false
    window.visible = true
    window.show.activate
  end
  #--------------------------------------------------------------------------
  # overwrite method: hide_sub_window
  #--------------------------------------------------------------------------
  def hide_sub_window(window)
    @status_window.visible = true
    window.visible = false
    window.hide.deactivate
    @command_window.activate
  end
  #--------------------------------------------------------------------------
  # overwrite method: create_actor_window
  #--------------------------------------------------------------------------
  def create_actor_window
    @actor_window = Window_MenuActor.new(:guard)
    @actor_window.set_handler(:ok,     method(:on_actor_ok))
    @actor_window.set_handler(:cancel, method(:on_actor_cancel))  
    @actor_window.visible = false
    @actor_window.z = 1000
  end
end
end
if $imported['KRX-SkillUpgrade']
#==============================================================================
# ** Scene_Upgrade
#==============================================================================
class Scene_Upgrade < Scene_Skill
  #--------------------------------------------------------------------------
  # overwrite method: show_sub_window
  #--------------------------------------------------------------------------
  def show_sub_window(window)
    @status_window.visible = false
    window.visible = true
    window.show.activate
  end
  #--------------------------------------------------------------------------
  # overwrite method: hide_sub_window
  #--------------------------------------------------------------------------
  def hide_sub_window(window)
    @status_window.visible = true
    window.visible = false
    window.hide.deactivate
    @command_window.activate
  end
  #--------------------------------------------------------------------------
  # overwrite method: create_actor_window
  #--------------------------------------------------------------------------
  def create_actor_window
    @actor_window = Window_MenuActor.new
    @actor_window.set_handler(:ok,     method(:on_actor_ok))
    @actor_window.set_handler(:cancel, method(:on_actor_cancel))  
    @actor_window.visible = false
    @actor_window.z = 1000
  end
end
end
if $imported["YEA-ShopOptions"]
#==============================================================================
# ** Scene_Shop
#==============================================================================
class Scene_Shop < Scene_MenuBase
  #--------------------------------------------------------------------------
  # overwrite method: show_sub_window
  #--------------------------------------------------------------------------
  def show_sub_window(window)
    @status_window.visible = false
    @gold_window.visible = false
    window.visible = true
    window.show.activate
  end
  #--------------------------------------------------------------------------
  # overwrite method: hide_sub_window
  #--------------------------------------------------------------------------
  def hide_sub_window(window)
    @status_window.visible = true
    @gold_window.visible = true
    window.visible = false
    window.hide.deactivate
    @command_window.activate
  end
  #--------------------------------------------------------------------------
  # overwrite method: create_actor_window
  #--------------------------------------------------------------------------
  def create_actor_window
    @actor_window = Window_MenuActor.new(:shop)
    @actor_window.set_handler(:ok,     method(:on_actor_ok))
    @actor_window.set_handler(:cancel, method(:on_actor_cancel))  
    @actor_window.visible = false
  end
end
end