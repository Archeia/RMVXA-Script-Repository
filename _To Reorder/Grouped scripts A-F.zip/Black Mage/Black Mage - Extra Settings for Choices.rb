#----------------------------------------------------------------------------
# Extra Settings for Choices Script By Black Mage (Credit required to use)
# Version : 1.1
#
# https://burningwizard.wordpress.com/2017/12/29/extra-settings-for-choices-script-rmvxa-rgss3/
#----------------------------------------------------------------------------
#
# This script have several function regarding choices command.
#
# 1. Scrolling Choices
#    You can make the choices cursor scrolling from top to the bottom by using
#    this script call:
#
#    choice_scroll(boolean, delay)
#
#    where boolean value is true or false. When boolean is false, nothing is
#    happened, and you can put delay value whatever you like. If the boolean
#    is true, however, then the choices will start to scrolling from top to the
#    bottom of available choices. The speed of the scrolling is depends on the
#    value of delay. The smaller the delay value, means the scrolling speed
#    will be faster.
#
# 2. Arrow Lock
#    You can lock the directional button during choice selection, leaving
#    player to have access only on confirm and cancel button, by using this 
#    script call:
#
#    choice_arrow_lock(value)
#
#    where the value is true or false. Set the value on true to disable the 
#    directional button, and set it on false to enable the directional button.
#
# 3. Forced Choices
#    This setting will make the choice cursor will always return to a specified 
#    index, no matter where the player move the cursor. The cursor will return 
#    to the specified index after several delay. You can use it by calling this 
#    script call:
#
#    choice_forced(boolean, index, delay)
#
#    where boolean is either true or false, determining wether the setting is
#    used or not. index is where the choice cursor will return at. And delay is
#    how many frame passed before the cursor return to the specified index.
#
# 4. Timed Choices
#    This will make the choice have an invisible timer on it. When the timer
#    reaches 0, the highlited choice will be selected, or it will trigger 
#    another event depending on the setting. You can use it by using this script
#    call:
#
#    choice_timer(boolean1, boolean2, duration, common_event)
#
#    where boolean1 stands for determining wether the setting is in effect or
#    not. Set it to false so you don't need to worry about the other arguments
#    value, just put whatever on them.
#
#    boolean2 stands for wether when the time is running out, a specific common
#    event will be played or it will choos the highlighted choice. When this
#    value is false, the highlighted choice will be selected. When this is true,
#    a common event will be played depending on common_event value.
#
#    duration is how many frames will passed before Boolean2 setting took effect.
#
#    common_event is an ID for which common event get executed if boolean2 value
#    is true. If boolean2 value is false, you can put whatever on it's value.
#
#    You can check how many frames left on the timer on this variable:
#    
#    $game_system.choice_remaining_time
#
# 5. Button Customize
#    You can customize the button used to move the choices by using this script 
#    call:
#
#    choice_button(down, up)
#
#    where down and up are the button that will make the choices go down and up
#    respectively. Ex: choice_button(:LEFT, :RIGHT) will make the left arrow to
#    move the choice cursor up, and the right arrow will move the choice cursor
#    down.
#    
#    Default available button:
#    down arrow         :DOWN
#    up arrow           :UP
#    left arrow         :LEFT
#    right arrow        :RIGHT
#
#    You can add more button by using some script that enable another button to
#    be used in your game.
#
# 6. Centered Choices
#    I hate the default positioning of choices in RMVXA, and some script out
#    there aren't suited for my needs. So here's a function to have the choices
#    got centered.
#
#    choice_centered(boolean)
#
#    where boolean are set to true if you want the choices to be centered.
#    
#----------------------------------------------------------------------------

#==============================================================================
# * Initial Setting. Just left them untouched.
#==============================================================================
module BLACK_CHOICES
  SCROLL       = [false, 0]  # Setting, delay
  TIMER        = [false, false, 0, 0]  # Setting, event on, duration, common event]
  ARROW_LOCK   = false
  FORCED       = [false,0,0] # Setting, index, delay
  BUTTON       = [:DOWN, :UP]
  CENTERED     = false
end

#==============================================================================
# ■ Game_System
#==============================================================================
class Game_System
  attr_accessor :choice_scroll
  attr_accessor :choice_timer
  attr_accessor :choice_arrow_lock
  attr_accessor :choice_remaining_time
  attr_accessor :choice_forced
  attr_accessor :choice_button
  attr_accessor :choice_centered
  
  alias black_initialize initialize
  def initialize
    @choice_scroll        = [BLACK_CHOICES::SCROLL[0], BLACK_CHOICES::SCROLL[1]]
    @choice_timer         = [BLACK_CHOICES::TIMER[0], BLACK_CHOICES::TIMER[1], BLACK_CHOICES::TIMER[2]]
    @choice_arrow_lock    = BLACK_CHOICES::ARROW_LOCK
    @choice_forced        = [BLACK_CHOICES::FORCED[0], BLACK_CHOICES::FORCED[1], BLACK_CHOICES::FORCED[2]]
    @choice_button        = [BLACK_CHOICES::BUTTON[0], BLACK_CHOICES::BUTTON[1]]
    @choice_centered      = BLACK_CHOICES::CENTERED
    black_initialize
  end
end

#==============================================================================
# * Game Interpreter
#==============================================================================
class Game_Interpreter
  #--------------------------------------------------------------------------
  # * Choice scroll setting
  #--------------------------------------------------------------------------         
  def choice_scroll(boolean, delay)
      $game_system.choice_scroll = [boolean, delay]
  end
  #--------------------------------------------------------------------------
  # * Choice timer
  #--------------------------------------------------------------------------         
  def choice_timer(boolean1, boolean2, timer, common_event)
      $game_system.choice_timer = [boolean1, boolean2, timer, common_event]
  end
  #--------------------------------------------------------------------------
  # * Arrow lock
  #--------------------------------------------------------------------------         
  def choice_arrow_lock(value)
      $game_system.choice_arrow_lock = value
  end
  #--------------------------------------------------------------------------
  # * Choice forced.
  #--------------------------------------------------------------------------         
  def choice_forced(boolean, index, delay)
      $game_system.choice_forced = [boolean, index, delay]
  end
  #--------------------------------------------------------------------------
  # * Choice reverse.
  #--------------------------------------------------------------------------         
  def choice_button(down, up)
      $game_system.choice_button = [down, up]
  end
  #--------------------------------------------------------------------------
  # * Choice centered.
  #--------------------------------------------------------------------------         
  def choice_centered(boolean)
      $game_system.choice_centered = boolean
  end
end

class Window_ChoiceList < Window_Command
  #--------------------------------------------------------------------------
  # * Update
  #--------------------------------------------------------------------------
  def update
    super
    scrolling_choices if $game_system.choice_scroll[0] == true
    countdown_timer if $game_system.choice_timer[0] == true
    forced_choices if $game_system.choice_forced[0] == true
  end
  
  #--------------------------------------------------------------------------
  # * Method for scrolling choices
  #--------------------------------------------------------------------------
  def scrolling_choices
    @speed = 0 if @speed == nil
    @speed += 1
    @speed = 0 if @speed >= $game_system.choice_scroll[1]
    if self.active and @speed == 0
      if @index == ($game_message.choices.size - 1)
        @index = 0
      else 
        @index += 1 
      end
      update_cursor
    end
  end
  
  #--------------------------------------------------------------------------
  # * Method for timed choices
  #--------------------------------------------------------------------------
  def countdown_timer
    $game_system.choice_remaining_time = $game_system.choice_timer[2] if @timer == nil
    @timer = true
    $game_system.choice_remaining_time -= 1
    if $game_system.choice_remaining_time <= 0 and @timer != nil
      if $game_system.choice_timer[1]
        deactivate
        close
        black_reset
        $game_temp.reserve_common_event($game_system.choice_timer[3])
      else
        process_ok
      end
    end
  end  

  #--------------------------------------------------------------------------
  # * Method for forced choices
  #--------------------------------------------------------------------------
  def forced_choices
    @delay = $game_system.choice_forced[2] if @delay == nil
    @delay -= 1
    if @delay <= 0
      @delay = nil
      select($game_system.choice_forced[1])
    end
  end
  
  #--------------------------------------------------------------------------
  # * Call OK Handler
  #--------------------------------------------------------------------------
  alias black_call_ok_handler call_ok_handler
  def call_ok_handler
    black_reset
    black_call_ok_handler
  end

  #--------------------------------------------------------------------------
  # * Call Cancel Handler
  #--------------------------------------------------------------------------
  alias black_call_cancel_handler call_cancel_handler
  def call_cancel_handler
    black_reset
    black_call_cancel_handler
  end
  
  #--------------------------------------------------------------------------
  # * Reset setting
  #--------------------------------------------------------------------------
  def black_reset
    @timer = nil
    @delay = nil
    $game_system.choice_forced[0] = false
    $game_system.choice_timer[0] = false
  end
  
  #--------------------------------------------------------------------------
  # * Arrow lock
  #--------------------------------------------------------------------------
  def cursor_movable?
      super if !$game_system.choice_arrow_lock
  end
  #--------------------------------------------------------------------------
  # * Cursor Movement Processing
  #--------------------------------------------------------------------------
  def process_cursor_move
    return unless cursor_movable?
    last_index = @index
    down  = $game_system.choice_button[0]
    up    = $game_system.choice_button[1]
    cursor_down (true)  if Input.repeat?(down)
    cursor_up   (true)    if Input.repeat?(up)
    Sound.play_cursor if @index != last_index
  end
end

#==============================================================================
# * Centered Choices Script.
#==============================================================================
class Window_ChoiceList < Window_Command
  def draw_item(index)
    a = 0    
    if $game_system.choice_centered
      b = text_size($game_message.choices[index]).width
      if index == 0
        c = 6
      else
        c = 0
      end
      a = ((self.width - 36 - b + c)/2)
    end    
    rect = item_rect_for_text(index)
    draw_text_ex(rect.x + a, rect.y, command_name(index))
  end
    
  alias black_update_placement update_placement
  def update_placement
    black_update_placement
    if $game_system.choice_centered
      self.width = [width, 144].max
      self.x = (Graphics.width - width)/2
      self.y = self.y - 2
    end
  end
end