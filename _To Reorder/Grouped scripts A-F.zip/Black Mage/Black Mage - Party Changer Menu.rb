#----------------------------------------------------------------------------
# Lizzie S Party Changer for RMVXA
# 
# This script is recreated from scratch on RGSS3 to mimic Lizzie S's Party
# Changer script on RMXP. Credit is required to use. Check the page below
# for more information
#
# https://burningwizard.wordpress.com/2015/02/15/party-changer-menu-script-rmvxace-rgss3/
#----------------------------------------------------------------------------

# Change $mode to 0 to use walking sprite instead of face
# Change $mode to 1 to use face instead of walking sprite
$mode = 0 

$partylock = []
$partychanger = []

###### Enable the line below until you find "STOP" to replace the default 
###### formation window into this one.

#class Window_MenuCommand < Window_Command
#  def formation_enabled
#    $game_party.members.size >= 1 && !$game_system.formation_disabled
#  end
#end
#class Scene_Menu < Scene_MenuBase
#  def command_formation
#    SceneManager.call(Scene_Changer)
#  end
#end

###### STOP

#----------------------------------------------------------------------------
# * The Scene Changer
#----------------------------------------------------------------------------

class Scene_Changer < Scene_MenuBase
  #--------------------------------------------------------------------------
  # * Start Processing
  #--------------------------------------------------------------------------
  def initialize
  end

  def start
    super
    create_help_party_window
    create_current_party_window
    current_party_check
    create_reserve_party_window
    @current_party_window.activate
    @current_party_window.select(0)
    @current_party_window.refresh
  end
  
  def current_party_check
    $game_party.members.size.times {|i| party_check(i)}
  end
  
  def party_check(index)
    $partychanger[$game_party.members[index].id - 1] = true
  end
  
  #--------------------------------------------------------------------------
  # * Create Party Help Window
  #--------------------------------------------------------------------------
  def create_help_party_window
    @party_help_window = Window_Help.new(1)
    @party_help_window.set_text('Choose your party.')
  end

  #--------------------------------------------------------------------------
  # * Create Current Party Window
  #--------------------------------------------------------------------------
  def create_current_party_window
    wy = @party_help_window.height
    wh = Graphics.height - wy
    @current_party_window = Window_CurrentParty.new(0, wy, (Graphics.width)/2, wh)
    @current_party_window.viewport = @viewport
    @current_party_window.set_handler(:ok, method(:current_party_ok))
    @current_party_window.set_handler(:cancel, method(:current_party_cancel))
  end
  def current_party_cancel
    SceneManager.return
  end
  def current_party_ok
    if $game_party.members[@current_party_window.index] == nil
      @reserve_party_window.activate
      @reserve_party_window.select(0)
      @current_party_window.index      
    elsif $partylock[$game_party.members[@current_party_window.index].id - 1] == true
      Sound.play_buzzer
      @current_party_window.activate      
      @current_party_window.select(@current_party_window.index)      
    elsif $game_party.members.size == 1 && @current_party_window.index == 0
      Sound.play_buzzer
      @current_party_window.activate      
      @current_party_window.select(@current_party_window.index)
    else
      @reserve_party_window.activate
      @reserve_party_window.select(0)
      @current_party_window.index
    end
  end
  
  #--------------------------------------------------------------------------
  # * Create Reserve Party Window
  #--------------------------------------------------------------------------
  def create_reserve_party_window
    wy = @party_help_window.height
    wh = Graphics.height - wy
    @reserve_party_window = Window_ReserveParty.new((Graphics.width)/2, wy, (Graphics.width)/2, wh)
    @reserve_party_window.viewport = @viewport
    @reserve_party_window.refresh
    @reserve_party_window.set_handler(:ok, method(:reserve_party_ok))
    @reserve_party_window.set_handler(:cancel, method(:reserve_party_cancel))
  end
  def reserve_party_cancel
    @reserve_party_window.select(-1)
    @reserve_party_window.deactivate
    @current_party_window.activate
    @current_party_window.select(@current_party_window.index)
  end
  
  def reserve_party_ok
    if @reserve_party_window.data(@reserve_party_window.index) == nil
      reserve_end_method
    elsif $partylock[@reserve_party_window.data(@reserve_party_window.index).id - 1] == true
      Sound.play_buzzer
      @reserve_party_window.activate
      @reserve_party_window.select(@reserve_party_window.index)
    else
      reserve_end_method
    end
  end
  
  def reserve_end_method
      @party = []
      @partytemp = []
      for i in 1..$game_party.members.size
        @party[i-1] = $game_party.members[i-1].id
        @partytemp[i-1] = $game_party.members[i-1].id
      end
    
      if @reserve_party_window.data(@reserve_party_window.index) == nil
        @party[@current_party_window.index] = nil
        @party2 = []
        for i in 0..@party.size
          if @party[i] != nil
            @party2.push(@party[i])
          end
        end
        @party = @party2
      else
        @party[@current_party_window.index] = @reserve_party_window.data(@reserve_party_window.index).id
      end
    
      for i in 1..@partytemp.size
        $game_party.remove_actor($game_actors[@partytemp[i-1]].id)
      end
    
      for i in 1..@party.size
        $game_party.add_actor(@party[i-1])
      end
    
      @current_party_window.refresh
      @reserve_party_window.refresh
      @reserve_party_window.select(0)
      @reserve_party_window.select(-1)
      @reserve_party_window.deactivate
      @current_party_window.activate
      @current_party_window.select(@current_party_window.index)
  end

end


##### The Current Party Window

class Window_CurrentParty < Window_Selectable
  #--------------------------------------------------------------------------
  # * Object Initialization
  #--------------------------------------------------------------------------
  def initialize(x, y, width, height)
    super
    @data = []
  end
  #--------------------------------------------------------------------------
  # * Get Item Height
  #--------------------------------------------------------------------------
  def line_height
    return 86
  end
  #--------------------------------------------------------------------------
  # * Get Number of Items
  #--------------------------------------------------------------------------
  def item_max
    if $game_party.members.size == 4
      $game_party.members.size
    else
      ($game_party.members.size) + 1
    end
  end
  #--------------------------------------------------------------------------
  # * Draw Item
  #--------------------------------------------------------------------------
  def draw_all_items
    item_max.times {|i| draw_item(i) }
  end
  def draw_item(index)
    @actor = $game_party.members[index]
    if @actor != nil
      case $mode
      when 0
        x_pos = 60
        draw_actor_graphic(@actor, 30, index*86 + 60)
      when 1
        x_pos = 90
        draw_actor_face(@actor, 2, index*86 + 2)
      end
      draw_actor_name(@actor, x_pos, index*86 - 16)
      draw_actor_level(@actor, x_pos, index*86 + 16)
    end
  end
  
  # Draw Face Custom
  def draw_face(face_name, face_index, x, y, enabled = true)
    bitmap = Cache.face(face_name)
    rect = Rect.new(face_index % 4 * 96, face_index / 4 * 96, 82, 82)
    contents.blt(x, y, bitmap, rect, enabled ? 255 : translucent_alpha)
    bitmap.dispose
  end
  
  def draw_actor_name(actor, x, y, width = 112)
    if $partylock[@actor.id - 1] == true
      change_color(normal_color, enabled = false)
    else
      change_color(hp_color(actor))
    end
    draw_text(x, y, width, line_height, actor.name)
  end
  def draw_actor_level(actor, x, y)
    if $partylock[@actor.id - 1] == true
      change_color(normal_color, enabled = false)
      draw_text(x, y, 32, line_height, Vocab::level_a)
      change_color(normal_color, enabled = false)
      draw_text(x + 32, y, 24, line_height, actor.level, 2)
    else
      change_color(system_color)
      draw_text(x, y, 32, line_height, Vocab::level_a)
      change_color(normal_color)
      draw_text(x + 32, y, 24, line_height, actor.level, 2)
    end
  end
  #--------------------------------------------------------------------------
  # * Refresh
  #--------------------------------------------------------------------------
  def refresh
    contents.clear
    draw_all_items
  end
end


##### The Reserve Party Window

class Window_ReserveParty < Window_Selectable
  #--------------------------------------------------------------------------
  # * Object Initialization
  #--------------------------------------------------------------------------
  def initialize(x, y, width, height)
    super
    @data = []
    self.oy = 0
  end
  #--------------------------------------------------------------------------
  # * Get Item Height
  #--------------------------------------------------------------------------
  def line_height
    return 86
  end
  #--------------------------------------------------------------------------
  # * Get Number of Items
  #--------------------------------------------------------------------------
  def item_max
    if @data == nil
      return 1
    else
      @data.size + 1
    end
  end
  def get_data
    @data = []
    if $partychanger.size > 0
      for i in 0..$partychanger.size
        if $partychanger[i] == true
          @partycheck = false
          for a in 1..$game_party.members.size            
            if $game_party.members[a-1].id == i + 1
              @partycheck = true
            end
          end
          if @partycheck == true
          else
            @data.push($game_actors[i+1])
          end
        end
      end
    end
  end
  #--------------------------------------------------------------------------
  # * Draw Item
  #--------------------------------------------------------------------------
  def draw_all_items
    item_max.times {|i| draw_item(i) }
  end
  def draw_item(index)
    if @data[index] != nil
      @actor = @data[index]
      case $mode
      when 0
        x_pos = 60
        draw_actor_graphic(@actor, 30, index*86 + 60)
      when 1
        x_pos = 90
        draw_actor_face(@actor, 2, index*86 + 2)
      end
      draw_actor_name(@actor, x_pos, index*86 - 16)
      draw_actor_level(@actor, x_pos, index*86 + 16)
    end
  end

  # Draw Face Custom
  def draw_face(face_name, face_index, x, y, enabled = true)
    bitmap = Cache.face(face_name)
    rect = Rect.new(face_index % 4 * 96, face_index / 4 * 96, 82, 82)
    contents.blt(x, y, bitmap, rect, enabled ? 255 : translucent_alpha)
    bitmap.dispose
  end
  
  def draw_actor_name(actor, x, y, width = 112)
    if $partylock[@actor.id - 1] == true
      change_color(normal_color, enabled = false)
    else
      change_color(hp_color(actor))
    end
    draw_text(x, y, width, line_height, actor.name)
  end
  def draw_actor_level(actor, x, y)
    if $partylock[@actor.id - 1] == true
      change_color(normal_color, enabled = false)
      draw_text(x, y, 32, line_height, Vocab::level_a)
      change_color(normal_color, enabled = false)
      draw_text(x + 32, y, 24, line_height, actor.level, 2)
    else
      change_color(system_color)
      draw_text(x, y, 32, line_height, Vocab::level_a)
      change_color(normal_color)
      draw_text(x + 32, y, 24, line_height, actor.level, 2)
    end
  end
  #--------------------------------------------------------------------------
  # * Refresh
  #--------------------------------------------------------------------------
  def refresh
    contents.clear
    get_data
    create_contents
    draw_all_items
  end
  
  def data(index)
    return @data[index]
  end
end