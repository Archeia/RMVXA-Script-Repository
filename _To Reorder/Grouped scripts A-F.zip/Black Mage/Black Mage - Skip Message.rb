#==============================================================================
# ** Skip Message Script by Black Mage (Credit required to use)
# https://burningwizard.wordpress.com/2015/04/23/skip-message-feature-script-rmvxace-rgss3/
#==============================================================================
# With this you can skip messages by pressing CTRL.
#==============================================================================

class Window_Message < Window_Base

  def process_input
    if $game_message.choice?
      input_choice
    elsif $game_message.num_input?
      input_number
    elsif $game_message.item_choice?
      input_item
    else
      if Input.press?(:CTRL)
      else
        input_pause unless @pause_skip
      end
    end
  end

  def input_pause
    self.pause = true
    wait(10)
    Fiber.yield until Input.trigger?(:B) || Input.trigger?(:C) || Input.press?(:CTRL)
    Input.update
    self.pause = false
  end

  def update_show_fast
    @show_fast = true if Input.trigger?(:C) or Input.press?(:CTRL)
  end

  def wait(duration)
    if Input.press?(:CTRL)
    else
      duration.times { Fiber.yield }
    end
  end

end