#==============================================================================
# ** Window_Credits by Black Mage (Credit required to use)
# https://burningwizard.wordpress.com/2014/03/04/rgss3-credits-script/
#==============================================================================
class Window_TitleCommand < Window_Command
  def make_command_list
    add_command(Vocab::new_game, :new_game)
    add_command(Vocab::continue, :continue, continue_enabled)
    add_command("Credits", :credits)
    add_command(Vocab::shutdown, :shutdown)
  end
end

class Scene_Title < Scene_Base
  def create_command_window
    @command_window = Window_TitleCommand.new
    @command_window.set_handler(:new_game, method(:command_new_game))
    @command_window.set_handler(:continue, method(:command_continue))
    @command_window.set_handler(:credits,  method(:command_credits))
    @command_window.set_handler(:shutdown, method(:command_shutdown))
  end
  #--------------------------------------------------------------------------
  # * [Credits] Command
  #--------------------------------------------------------------------------
  def command_credits
    close_command_window    
    SceneManager.call(Scene_Credits)
  end
end

class Window_Credits < Window_Base
  #--------------------------------------------------------------------------
  # * Object Initialization
  #--------------------------------------------------------------------------
  def initialize
    super(0, 0, window_width, 416)
    refresh
  end
  #--------------------------------------------------------------------------
  # * Get Window Width
  #--------------------------------------------------------------------------
  def window_width
    return 544
  end
  #--------------------------------------------------------------------------
  # * Refresh
  #--------------------------------------------------------------------------
  def refresh
    contents.clear
    draw_text_ex(0, 0, '\C[2]' + "Credits")  #This is how to write escape character.
    draw_text_ex(0, 20, "Credits")      
    draw_text_ex(0, 40, "Credits")      
    draw_text_ex(0, 60, "Credits")      
    draw_text_ex(0, 80, "Credits")      
    draw_text_ex(0, 100, "Credits")      
    draw_text_ex(0, 120, "Credits")      
    draw_text_ex(0, 140, "Credits")      
    draw_text_ex(0, 160, "Credits")      
    draw_text_ex(0, 180, "Credits")      
    draw_text_ex(0, 200, "Credits")      
    draw_text_ex(0, 220, "Credits")      
    draw_text_ex(0, 240, "Credits")      
    draw_text_ex(0, 260, "Credits")      
    draw_text_ex(0, 280, "Credits")      
    draw_text_ex(0, 300, "Credits")      
    draw_text_ex(0, 320, "Credits")      
    draw_text_ex(0, 340, "Credits")      
    draw_text_ex(0, 360, "Credits")      
  end
  #--------------------------------------------------------------------------
  # * Open Window
  #--------------------------------------------------------------------------
  def open
    refresh
    super
  end

end

#==============================================================================
# ** Scene_Status
#------------------------------------------------------------------------------
#  This class performs the status screen processing.
#==============================================================================

class Scene_Credits < Scene_MenuBase
  #--------------------------------------------------------------------------
  # * Start Processing
  #--------------------------------------------------------------------------
  def start
    super
    create_credits_window
  end

  def create_credits_window
    @credits_window = Window_Credits.new
    @credits_window.x = 0
    @credits_window.y = 0
  end

  def update
    super
    update_credits
  end  

  def update_credits
    return credits_return     if Input.trigger?(:C)
    return credits_return     if Input.trigger?(:B)
  end

  def credits_return
      Sound.play_cancel
      SceneManager.goto(Scene_Title)    
  end
end