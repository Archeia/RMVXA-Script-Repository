#bgillisp 27 March 2015. Free for commercial
#To have EXP gain from an accessory have a bonus based on actor's level with
#a slight element of randomness.
#
#Editable region

module BonusEXPonState
  
  #Set the State for when the bonus EXP is awarded here.
  BonusEXPState = 82
  
  #Set the minimum number to be multiplied to the level here. 
  MutiplierMin = 6
  
  #Set this to the range + 1. For instance, if you want it so that the level
  #is mulitplied by a number between 3 and 5, the range would be 5 - 3 = 2, 
  #then add 1 to that to get 3.
  MutiplierRange = 3 
end

#End of Editable Region

#Class Game_Actor
class Game_Actor < Game_Battler

  #Overwritten method, gain_exp
  def gain_exp(exp)
    if state?(BonusEXPonState::BonusEXPState)
      change_exp(self.exp + (exp * final_exp_rate + self.level * (rand(BonusEXPonState::MutiplierRange) + BonusEXPonState::MutiplierMin)).to_i, true)
    else
      change_exp(self.exp + (exp * final_exp_rate).to_i, true)
     end
  end #End overwritten method

end #End class Game_Actor
  