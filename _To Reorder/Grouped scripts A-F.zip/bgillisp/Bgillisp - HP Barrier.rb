#         Script HP Barrier Bar, version 1.1
#         Author: bgillisp
#         Released: 10/23/2014
 
#         This script allows you to define states that add barriers around
#         actors and enemies. These barriers will take all HP damage
#         until they fall, and allow healing spells to pass through
#         the barrier.
 
# To use: Place in the materials section, but above main
 
#         To create a barrier, set up a skill or item as HP restore, and use
#         the damage box to set up the formula to determine the HP on the
#         barrier. Then, add the notetag:
#
#         <HP Barrier: Create>
#
#         This then tells the skill to override the default behvaior, and to
#         create a barrier, using the formula in the damage box.
#
#         Barriers by default last until they are destroyed. To override that,
#         first, create a state that is set to expire when you wish the
#         the barrier to expire. Then, add the following notetag to the
#         item or skill which created the barrier
#
#         <HP Barrier State: x>
#
#         Where x is the state you set up earlier. This then links the barrier
#         to the state, and when the state is removed, the barrier is removed.
#
#         To set up a skill or item to heal the barrier, use the notetag
#        
#         <HP Barrier: Restore>
 
 
#         Other Optional Notetags
 
 
#         <HP Barrier MAX: x>
#
#         This tells the game that the barrier created with this skill can
#         never have more than x HP.
 
 
#         <HP Barrier Regen Plus: x>
 
#         This sets it up so that the end of every turn, the barrier
#         regenerates x hitpoints (or loses x hitpoints if x is negative)
 
#         <HP Barrier Modify: x>
#
#         Add this to a actor or an enemy to make it so that all barriers
#         created by this person (or enemy) are multiplied by x before being
#         applied. Can be used to make it so that a specific enemy can
#         cast an enhanced version of the skill without creating a new skill.
#         This can also be added to an equip to make it so that all barriers
#          cast by that person are improved (or weakened) as well.
 
#         <HP Barrier Heal Multiplier: x>
 
#         Add this to the skill that adds the barrier if you want to heal the
#         target of the barrier at the same time. X stands for the amount
#         multiplied to the value of the barrier. So if x is 1.0, you will
#         create a barrier and heal the target for the same amount.
 
#         <HP Barrier Regen Percent: x>
 
#         Add this to the skill that adds the barrier to make the barrier
#         heal x% every turn. Let x be negative if you want the barrier to
#         weaken by x% every turn instead.
 
#         <HP Barrier Block Percent: x>
#
#         Add this to the skill that adds the barrier to make the barrier
#         block only x of the damage it takes every turn. If not present
#         the barrier will block all damage until it falls.
 
#         There is also a notetag called HP Barrier Regen Mult, but that
#         works by mutiplying the barrier by x every turn. This does not
#         work like the normal regen so best to use with cauation. Right now
#         it will make a barrier with 1 hp have 2, then 4, then 8, then 16,
#         then 32, then 64, and so on with an x of 2. There are fun ways to
#         use this, so even though this was originally an accident, leaving
#         it in for the creative designer to use if they wish.
 
 
#Terms of Use:
#         Free for use in commercial and non-commercial projects, with
#         credit given.
 
 
# Release history:
# 8/23/2014: Initial beta release for testing.
# 9/25/2014: Version 1.0 released! Thanks to spacemanfive, zevia, supernurse,
#            and Rydiamist for their testing of the beta version for me!
# 10/9/2014: Version 1.01: Fixed bug where it was using ints instead of floats
#            for some percentages in notetags. The scipt should now let you
#            do something like create a barrier and heal the target for half
#            the HP the barrier was for as well.
# 10/23/2014: Version 1.1: Added the ability to have barriers only block
#             a percent of the damage they take.
#             Fixed placement of the barrier bar for default engine
#             Added the ability to have it play an anmiation when the barrier
#             falls. Best used on ATB systems due to the way the animation is
#             handled.
 
 
#----------------------------------------------------------------------------
# Editable region
 
module BGHP_Barrier
  #Set the highest HP value allowed on any barrier
  Barrier_Max = 5000
 
  #Flag to set how the Max_HP of the barrier is set. Set the flag as follows
  #> 0         means use this as a static value for the barrier
  #0           means to use the actors maxhp for the barrier.max.hp
  #-1          means to use the barrier's max hp on creation
  #-2          means to use the maximum set by the skill.
  Barrier_Max_HP_Display = -1
 
  #Set whether drain spells penetrate the barrier
  Drain_penetrate = false  
 
  #Determines whether an element type can always penetrate a barrier.
  #Set to false to disable, true to enable.
  #Penetrated barriers will still exist, but will fail to block all attacks
  #of that element.
  Penetrate_Element = false
 
  #Determines whether a barrier can be shattered by an element.
  #Set to false to disable, true to enable
  #Shattered barriers automatically fall, but the opponent takes 0 damage still.
  Shatter_Element = false
 
  #Set which element is the one that penetrates all barriers.
  #The default of 3 will correspond to Fire in the default database
  Element_to_penetrate = 3
 
  #Default shatter element. If do not wish to use, set this to -2, or an element
  #not actually in your game.
  #If you want to allow any physical attack to shatter a batter, use -1.
  Default_shatter = -2
 
  #Text Color for bar. Valid colors are any text color recognized by
  #the program.
  Color_bar = 4
 
  #Sound effect to play when the shield takes damage.
  Shield_sound_effect = "Reflection"
 
  #Animation to play when the shield shatters. Replace 96 with the id of the
  #animation in the database you want to play when shields shatter.
  Shield_removal_animation = 530
 
  #Set to false to disable the animation for the shield
  Shield_removal_animation_on = false
  
  #Flag to set if you want to display how much hp the barrier gained when created
  Display_for_ally = true
  Display_for_enemy = false
 
  #Flag to set if you want barriers to be able to be healed beyond their
  #initial HP values. True means yes, false means no
  Regenerate_beyond_initial = false
 
end
 
#End of Editable Region
#--------------------------------------------------------------------------
 
 
#Do not edit anything below here unless you know what you are doing.
#Failure to ahead to this warning may result in unpredictable behavior in
#your game. Consider yourself warned
#__________________________________________________________________________
 
$imported = {} if $imported.nil?
$imported["BGHPBarrier"] = true
 
module DataManager
 
  #--------------------------------------------------------------------------
  # alias method: load_database
  #--------------------------------------------------------------------------
  class <<self; alias load_database_bg_hpbarrier_load_database load_database; end
  def self.load_database
    load_database_bg_hpbarrier_load_database
    load_notetags_bg_hpbarrier
  end
 
  #--------------------------------------------------------------------------
  # new method: load_notetags_bg_bpbarrier
  #--------------------------------------------------------------------------
  def self. load_notetags_bg_hpbarrier
    groups = [$data_actors, $data_classes, $data_weapons, $data_armors,
      $data_enemies, $data_states, $data_skills, $data_items]
    for group in groups
      for obj in group
        next if obj.nil?
        obj.load_notetags_bg_hpbarrier
      end
    end
  end
 
end # DataManager
 
#Code to load the notetags and store it in a state
class RPG::BaseItem
 
  #--------------------------------------------------------------------------
  # public instance variables
  #--------------------------------------------------------------------------
  #Variables for an hp barrier
  attr_accessor :barrier_element
  attr_accessor :barrier_counter_element
  attr_accessor :barrier_shatter_element
  attr_accessor :hp_barrier_create
  attr_accessor :hp_barrier_restore
  attr_accessor :hp_barrier_set_max
  attr_accessor :hp_barrier_state
  attr_accessor :hp_barrier_regen_add
  attr_accessor :hp_barrier_regen_mult
  attr_accessor :hp_barrier_heal_mult
  attr_accessor :hp_barrier_regen_percent
  attr_accessor :hp_barrier_block_percent
 
  #Variables for an mp barrier
  attr_accessor :mp_barrier_element
  attr_accessor :mp_barrier_counter_element
  attr_accessor :mp_barrier_shatter_element
  attr_accessor :mp_barrier_create
  attr_accessor :mp_barrier_restore
 
  #Code for the variables to be added/subtracted
  attr_accessor :barrier_stats
  attr_accessor :barrier_fixed_value
 
  #Code for an actor if they can modify how barriers work
  attr_accessor :barrier_modify
 
  #--------------------------------------------------------------------------
  # common cache: load_notetags_bg_hpbarrier
  #--------------------------------------------------------------------------
  def load_notetags_bg_hpbarrier
    @hp_barrier_create = false
    @hp_barrier_restore = false
    @mp_barrier_create = false
    @mp_barrier_restore = false
    @hp_barrier_state = 0
    @hp_barrier_heal_mult = 0
    @hp_barrier_regen_percent = 0
   
    #Set to the default of 100% of damage blocked.
    @hp_barrier_block_percent = 1.0
   
    #Set to the default of 100%
    @barrier_modify = 1.0
   
    #Set the regenerate abilities to zero by default
    @hp_barrier_regen_add = 0.0
    @hp_barrier_regen_mult = 1.0
   
    #Set to the defaults for the barrier. If notetags are set, the rest
    #will be added later.
    @barrier_hp_shatter_element = BGHP_Barrier::Default_shatter
    @barrier_hp_penetrate_element = BGHP_Barrier::Element_to_penetrate
    @hp_barrier_set_max = BGHP_Barrier::Barrier_Max
   
    @store = self.note[/(?<=<HP Barrier Modify: ).*?(?=[>])/].to_f
    if(@store && @store != 0)
      @barrier_modify = @store
    end
   
    @store = self.note[/(?<=<HP Barrier State: ).*?(?=[>])/].to_i
    if(@store && @store != 0)
      @hp_barrier_state = @store
    end
   
    @store = self.note[/(?<=<HP Barrier MAX: ).*?(?=[>])/].to_i
    if(@store && @store != 0)
      @hp_barrier_set_max = @store
     
      #Error catching. If this ever happens, reset to module default
      if(@hp_barrier_set_max < 0)
        @hp_barrier_set_max = BGHP_Barrier::Barrier_Max
      end
     
    end
   
    #Set the shatter element of the barrier now
    @store = self.note[/(?<=<HP Barrier Shatter Element: ).*?(?=[>])/].to_i
    if(@store && @store != 0)
      @barrier_shatter_element = @store
    end
   
    #Set the penetrate element of the barrier now
    @store = self.note[/(?<=<HP Barrier Penetrate Element: ).*?(?=[>])/].to_i
    if(@store && @store != 0)
      @barrier_penetrate_element = @store
    end
   
    @store = self.note[/(?<=<HP Barrier Regen Plus: ).*?(?=[>])/].to_i
    if(@store && @store != 0)
      @hp_barrier_regen_add = @store
    end
   
    @store = self.note[/(?<=<HP Barrier Regen Times: ).*?(?=[>])/].to_f
    if(@store && @store != 0)
      @hp_barrier_regen_mult = @store
    end
   
    @store = self.note[/(?<=<HP Barrier Regen Percent: ).*?(?=[>])/].to_f
    if(@store && @store != 0)
      @hp_barrier_regen_percent = @store
    end
   
    @store = self.note[/(?<=<HP Barrier Block Percent: ).*?(?=[>])/].to_f
    if(@store && @store != 0)
     
      #Error catching for bad inputs
      if(@store < 0)
        @store = 0.0
      end
      if(@store > 1)
        @store = 1.0
      end
     
      @hp_barrier_block_percent = @store
    end
   
     @store = self.note[/(?<=<HP Barrier Heal Multiplier: ).*?(?=[>])/].to_f
    if(@store && @store != 0)
      @hp_barrier_heal_mult = @store
    end
   
    #Check for flag to see if we are to heal the barrier, not create a new one.
    if(self.note[/<HP Barrier: Restore>/im])
      @hp_barrier_create = false
      @hp_barrier_restore = true
    end
   
    if(self.note[/<HP Barrier: Create>/im])
      @hp_barrier_create = true
      @hp_barrier_restore = false
    end
   
  end #End loading notetags module
 
end #End RPG::BaseItem
 
#Create a new variable, shielded_hp, which you can access to display damage
#to the sheild if so desired.
class Game_ActionResult
 
  attr_accessor :shielded_hp
 
  alias bg_hp_barrier_clear_damage_values clear_damage_values
  alias bg_hp_barrier_initialize initialize
 
  def initialize(battler)
    bg_hp_barrier_initialize(battler)
    @shielded_hp = 0
  end
 
  #Aliased method, clear damage values
  def clear_damage_values
   
    #Call aliased method
    bg_hp_barrier_clear_damage_values
   
    @shieled_hp = 0
  end
 
end
 
class Game_Battler < Game_BattlerBase
 
  #Variables for an hp barrier
  attr_accessor :hp_barrier
  attr_accessor :hp_barrier_max
  attr_accessor :hp_barrier_set_max
  attr_accessor :barrier_state
  attr_accessor :barrier_penetrate_element
  attr_accessor :barrier_shatter_element
  attr_accessor :hp_barrier_regen_add
  attr_accessor :hp_barrier_regen_mult
  attr_accessor :hp_barrier_percent_regen
  attr_accessor :hp_barrier_blocked_perc
 
  #Variables for an mp barrier
  attr_accessor :mp_barrier
  attr_accessor :mp_barrier_max
  attr_accessor :mp_barrier_state
  attr_accessor :mp_barrier_penetrate_element
  attr_accessor :mp_barrier_shatter_element
 
  #Set up all aliased functions here
  alias bg_barrier_make_damage_value make_damage_value
  alias bg_barrier_iniitialize initialize
  alias bg_barrier_add_new_state add_new_state
  alias bg_barrier_remove_state remove_state
  alias bg_barrier_refresh refresh
  alias bg_barrier_reset_state_counts reset_state_counts
  alias bg_barrier_regenerate_all regenerate_all
 
  def initialize
    #Start all battlers with no barrier
    self.hp_barrier = 0
    self.barrier_state = 0
    self.hp_barrier_max = 0
    self.hp_barrier_set_max = 1
    self.hp_barrier_regen_add = 0.0
    self.hp_barrier_regen_mult = 1.0
    self.hp_barrier_percent_regen = 0.0
    self.hp_barrier_blocked_perc = 0.0
   
    #Call aliased method
    bg_barrier_iniitialize
  end
 
   #--------------------------------------------------------------------------
  # * Calculate Damage
  #--------------------------------------------------------------------------
  def make_damage_value(user, item)
   
    #Call aliased method first
    bg_barrier_make_damage_value(user, item)
   
    #Set the result for damage done to the shield to 0.
    @result.shielded_hp = 0
   
    #If a healing item
    if(item.damage.recover?)
     
      #If we used an item to recover the shiled, heal it, and set result to 0
      if(item.hp_barrier_restore == true && self.hp_barrier > 0)
        pass = 0 - @result.hp_damage
        add_to_barrier(pass)
        @result.hp_damage = 0
      end
     
      #Create marrier if we are supposed to
      if(item.hp_barrier_create == true)
       
        #initiliaze all variables
        self.hp_barrier = 0
        self.hp_barrier_max = 0
        self.hp_barrier_set_max = item.hp_barrier_set_max
        self.barrier_state = item.hp_barrier_state
        self.barrier_penetrate_element = BGHP_Barrier::Element_to_penetrate
        self.barrier_shatter_element = BGHP_Barrier::Default_shatter
        self.hp_barrier_regen_add = item.hp_barrier_regen_add
        self.hp_barrier_regen_mult = item.hp_barrier_regen_mult
        self.hp_barrier_percent_regen = item.hp_barrier_regen_percent
        self.hp_barrier_blocked_perc = item.hp_barrier_block_percent
       
        pass = 0 - @result.hp_damage
       
        #Clear out the value so it does not heal you after the shield is applied,
        #unless a notetag was set to not clear it out.
        @result.hp_damage = (pass * item.hp_barrier_heal_mult * -1.0).to_i
       
        if actor?
          pass *= user.actor.barrier_modify
         
          #Add modifiers from equips. Currently this is being applied
          #to the equips of the target, intend to fix this soon.
          for equip in user.equips
            next if equip.nil?
            pass *= equip.barrier_modify
          end
        end #End if statement
       
        if enemy?
          pass *= user.enemy.barrier_modify
        end
       
        set_barrier(pass)
       
        #Set the result vaule to the correct value now
        @result.shielded_hp = 0 - self.hp_barrier.to_i
       
        #Clear the value if we want the result to be hidden
        if enemy?
           if(BGHP_Barrier::Display_for_enemy == false)
            @result.shielded_hp = 0
          end
        end
       
        if actor?
          if(BGHP_Barrier::Display_for_ally == false)
            @result.shielded_hp = 0
          end
        end
       
        #Add the timer to the shield if desired
        if(self.barrier_state > 0)
          add_state(self.barrier_state)
        end
       
        #Set the maximum HP for the displayed barrer.
        set_barrier_max_hp
       
        #Set the barrier to be unable to be healed beyond the starting hp,
        #if set to do that
        if(BGHP_Barrier::Regenerate_beyond_initial == false)
          self.hp_barrier_set_max = self.hp_barrier
        end #End if statement
       
      end #End if creating a barrier code.
     
      #If no barrier up at the moment, do nothing
      if(item.hp_barrier_restore == true && self.hp_barrier <= 0)
        @result.hp_damage = 0
      end
     
      #Return, as nothing more to be done if healing item.
      return
    end  
   
    #If drain, and allowing drain penetrating, return
    if(item.damage.drain? && BGHP_Barrier::Drain_penetrate)
      return
    end
   
    #If penetrating element and allowed, return as barrier penetrated
    if(item.damage.element_id == BGHP_Barrier::Element_to_penetrate && BGHP_Barrier::Penetrate_Element)
      return
    end
   
    #Calculate the value the shield would block.
    @result.shielded_hp = (@result.hp_damage * self.hp_barrier_blocked_perc).to_i
   
    #Apply the effects of the barrier now,
    #if the barrier has more hp left than the damage dealt
    if(self.hp_barrier > 0 && self.hp_barrier >= @result.shielded_hp)
     
      #Check to see if barrier shattered now
      if(item.damage.element_id == self.barrier_shatter_element && BGHP_Barrier::Shatter_Element)
        @result.hp_damage = 0
        remove_barrier
       
        #Play the animation if we are supposed to play it.
        if(BGHP_Barrier::Shield_removal_animation_on == true)
          self.animation_id = BGHP_Barrier::Shield_removal_animation
         
        end
      end
     
      #Apply normal damage if barrier not shattered
      self.hp_barrier -= @result.shielded_hp
      @result.hp_damage = [@result.hp_damage - @result.shielded_hp, 0].max
   
    #If the barrier has less HP left than the damage dealt, remove it
    elsif(self.hp_barrier > 0 && self.hp_barrier <= @result.shielded_hp)
      @result.shielded_hp = self.hp_barrier.to_i
      @result.hp_damage -= self.hp_barrier.to_i
      remove_barrier
     
      #Play the animation if we are supposed to play it.
      if(BGHP_Barrier::Shield_removal_animation_on == true)
        self.animation_id = BGHP_Barrier::Shield_removal_animation
      end
    end
   
    #Clear the value for shielded.hp if no barrier really existed
    if(self.hp_barrier <= 0)
      @result.shielded_hp = 0
    end
   
 
  end #End of make_damage_value
 
  #Aliased method, remove_state
  def remove_state(state_id)
   
    if state?(state_id)
       #Call aliased method
       bg_barrier_remove_state(state_id)
       
       #If this occurs, need to remove the barrier
       if(self.barrier_state == state_id)
         self.hp_barrier = 0
       end      
    end
     
  end #end of remove_state
 
  #Originial method add_to_barrier.
  #This adds the new value to the current barrier.
  def add_to_barrier(value)
    self.hp_barrier += value
    if(self.hp_barrier >= self.hp_barrier_set_max)
      self.hp_barrier = self.hp_barrier_set_max
    end
  end #End add_to_barrier
 
  #Originial method set_barrier.
  #This sets a barrier to a fixed value, overwriting the previous value
  def set_barrier(value)
    self.hp_barrier = value
    if(self.hp_barrier >= self.hp_barrier_set_max)#self.hp_barrier_set_max)
      self.hp_barrier = self.hp_barrier_set_max
    end
  end #End set_barrier method
 
  #Original method, set barrier max hp
  def set_barrier_max_hp
   
    #Set up the static barrier
    if(BGHP_Barrier::Barrier_Max_HP_Display > 0)
      self.hp_barrier_max = BGHP_Barrier::Barrier_Max_HP_Display
    end
   
    #Set up the barrier based on max hp of the actor
    if(BGHP_Barrier::Barrier_Max_HP_Display == 0)
      self.hp_barrier_max = self.mhp
    end
   
    #Set up the barrier based on the max hp of the barrier
    if(BGHP_Barrier::Barrier_Max_HP_Display == -1)
      self.hp_barrier_max = self.hp_barrier
    end
   
    if(BGHP_Barrier::Barrier_Max_HP_Display == -2)
      self.hp_barrier_max = self.hp_barrier_set_max
    end
   
    #If it somehow gets here with less than 0, set it to 1
    if(self.hp_barrier_max <= 0)
      self.hp_barrier_max = 1
    end
   
  end #End of set_barrier_max_hp
 
  #Original method remove_barrier()
  def remove_barrier()
    self.hp_barrier = 0
   
    #Remove the barrier state if not on the default
    if(self.barrier_state > 0)
     remove_state(self.barrier_state)
   end
   
 end #End remove_barrier
 
 #Alias method regenrate_all
 def regenerate_all
 
   #Call aliased method
   bg_barrier_regenerate_all
   
   if alive?
      #Regenerate the barrier if we are supposed to
      if(self.hp_barrier > 0)
        self.hp_barrier += self.hp_barrier_regen_add
        self.hp_barrier *= self.hp_barrier_regen_mult
        self.hp_barrier += (self.hp_barrier_set_max * self.hp_barrier_percent_regen).to_i
       
        #See if the barrier has too much health now
        if(self.hp_barrier >= self.hp_barrier_set_max)
          self.hp_barrier = self.hp_barrier_set_max
        end
       
        #See if the barrier somehow went to zero
        if(self.hp_barrier <= 0)
          remove_barrier
        end
       
      end  
    end
   
  end #End regenerate all
 
end #End class Game_Battler
 
class Window_Base < Window
 
  alias bg_barrier_draw_actor_hp draw_actor_hp
  def draw_actor_hp(actor, x, y, width = 124)
   
    #Call aliased method
    bg_barrier_draw_actor_hp(actor, x, y, width)
   
    #Draw the barrier bar if needed
    if(actor.hp_barrier > 0)
      barrier_rate = (actor.hp_barrier.to_f) / (actor.hp_barrier_max)
      draw_gauge(x+8, y+5, width, barrier_rate, text_color(BGHP_Barrier::Color_bar), text_color(BGHP_Barrier::Color_bar))
    end
  end
end
 
#This is added for Yanfly compatability. This will draw the bar
#Over the HP bar when a bar exists.
 
#IF you are not in battle, the Barrier bar defaults to the line above
#the current HP bar.
 
#Check first to see if we have Yanfly installed. If not, skip all of this.
if $imported["YEA-BattleEngine"] == true
class Window_BattleStatus < Window_Selectable
 
  alias bg_barrier_draw_item draw_item
  #Draw Actor Barrier
  def draw_actor_barrier(actor, dx, dy, width = 124)
    barrier_rate = (actor.hp_barrier.to_f) / (actor.hp_barrier_max)
    draw_gauge(dx, dy, width, barrier_rate, text_color(BGHP_Barrier::Color_bar), text_color(BGHP_Barrier::Color_bar))
    change_color(system_color)
    cy = (Font.default_size - contents.font.size) / 2 + 1
    draw_text(dx+2, dy+cy, 45, line_height, "SH")
    change_color(text_color(0))
    draw_text(dx + width - 42, dy+cy, 42, line_height, actor.hp_barrier.to_i, 2)
  end #End draw_actor_barrier method
   
  #Alias method draw_item
  def draw_item(index)
   
    #Call aliased method
    bg_barrier_draw_item(index)
   
    #Return if index or actor nil. The orginal method already cleared everything
    #so no clear called.
    return if index.nil?
    actor = battle_members[index]
    rect = item_rect(index)
    return if actor.nil?
    offset = YEA::BATTLE::BATTLESTATUS_HPGAUGE_Y_PLUS
    if(actor.hp_barrier > 0)
     
      #This is the line that draws the barrier. If you wish to move
      #the bar, edit the line_height*2+offset to move the starting y value,
      #Edit the rect.x+2 to move the starting x value.
      draw_actor_barrier(actor, rect.x+2, line_height*1.5+offset, rect.width-4)
    end
  end #End draw_item method
 
end #End class Window_Battle_Status
 
#Code to display a graphical pop-up when a barrier is hit.
class Game_BattlerBase
 
  alias bg_hp_barrier_make_damage_popups make_damage_popups
  #--------------------------------------------------------------------------
  # new method: make_damage_popups
  #--------------------------------------------------------------------------
  def make_damage_popups(user)
   
    #Call the aliased method, if shield took no damage
    bg_hp_barrier_make_damage_popups(user)
   
    #Add pop-up for the damage to the shield now.
    if (@result.shielded_hp > 0 && result.shielded_hp != nil)
      flags = []
      setting = :hp_dmg  if @result.shielded_hp > 0
      rules = "HP_DMG"   if @result.shielded_hp > 0
      value = @result.shielded_hp.abs
      text = sprintf(YEA::BATTLE::POPUP_SETTINGS[setting], value.group)
      create_popup(text, rules, flags)
     
      #Set any sound you would like to see played here.
      RPG::SE.new(BGHP_Barrier::Shield_sound_effect, 80, 100).play rescue Sound.play_cancel
     
    end
   
    #Add pop-up for the creation of the shield now.
    if (@result.shielded_hp < 0 && result.shielded_hp != nil)
      flags = []
      setting = :hp_heal    if @result.shielded_hp < 0
      rules = "HP_HEAL"     if @result.shielded_hp < 0
      value = @result.shielded_hp.abs
      text = sprintf(YEA::BATTLE::POPUP_SETTINGS[setting], value.group)
      create_popup(text, rules, flags)
     
      #Set any sound you would like to see played here.
      RPG::SE.new(BGHP_Barrier::Shield_sound_effect, 80, 100).play rescue Sound.play_cancel
     
    end
   
  end #End make_damage_popups
 
  #Overwritten method, make_miss_popups
  #To avoid the program showing Null when an attack was shielded against,
  #this code had to be re-written. The only changes are near the end.
  def make_miss_popups(user, item)
    return if dead?
    if @result.missed
      text = YEA::BATTLE::POPUP_SETTINGS[:missed]
      rules = "DEFAULT"
      create_popup(text, rules)
    end
    if @result.evaded
      text = YEA::BATTLE::POPUP_SETTINGS[:evaded]
      rules = "DEFAULT"
      create_popup(text, rules)
    end
    if @result.hit? && !@result.success
      text = YEA::BATTLE::POPUP_SETTINGS[:failed]
      rules = "DEFAULT"
      create_popup(text, rules)
    end
   
    #This next line is the major change from Yanfly's code
    if @result.hit? && item.damage.to_hp? && result.shielded_hp == 0
      if @result.hp_damage == 0 && @result.hp_damage == 0
        text = YEA::BATTLE::POPUP_SETTINGS[:nulled]
        rules = "DEFAULT"
        create_popup(text, rules)
      end
    end
   
    #Clear the stored shield damage taken now, as we no longer need to
    #reference it.
    @result.shielded_hp = 0
  end
 
end #End class Game_Battler_Base
 
end #End if imported Yanfly Battle Engine.