#             Script: Encounter Control, Version 0.41
#             Author: bgillisp
#             Released 1/26/2015

#             This script is designed to give game developers more control over
#             how encounters are managed in the game. Currently in developement

#             Current Features
#             -Ability to designate a switch that if the switch is ON, all random
#              fights are off for the map.
#             -Ability to set a minimum number of steps per map that must
#              be taken before an encounter is met. Now compatabile with Yanfly's
#              encounter manager, and will use the encounter manager's global
#              minimum if no minimum is set for the map.
#             -Ability to turn off all random fights in the game with one swtich
#             -Ability to set a uniform distribution, using the number in the
#              editer as the mean, then the number in the notetag as the 
#              variance. Currently it goes 3 standard deviations out from the
#              mean in either direction
#             -Ability to set a maximum number of battles per map (resets when
#              map changed or game loaded). Works exactly like Ar Tonelico if 
#              you played that game.
#             -You can now set a switch to make it so that fixed battles
#              can be preemptive or surprise attack now.
#             -You can set a swtich to make it so that all battles are
#              surprise or preemptive.
#             -Combine the last two to make a fixed fight on the map
#              be a surprise attack. Now those thiefs really can get the
#              drop on you!


#             Compatability (Known issues):
#             -To work with Yanfly's Encounter Rate Manager, this script must
#              be installed below it. If you install this script above it
#              Yanfly's script will overwrite this script and nothing in here
#              will work.

#             Terms of use: Free for use in commercial and non-commercial games
#             with credit given.

$imported = {} if $imported.nil?
$imported["BG-EncounterControl"] = true

#-----------------------------------------------------------------------------

      #Editable region 
      
#-----------------------------------------------------------------------------

module BGEncounter_Control
  
  #Set the switch that if it is off, no random fights will occur no matter what
  #Set to zero to disable.
  Encounter_Off = 0
  
  #If this switch is on, the party cannot be surprised
  Surprise_Off = 121
  
  #If this switch is on, the party cannot get preemptive attacks. 
  Preemptive_Off = 122
  
  #Turn on to force a premeptive fight
  Preemptive_Always = 123
  
  #Turn on to force a surprise fight
  Surprise_Always = 124
  
  #Turn on to force fixed battles (or evented battles) to check for surprise
  #and preemptive rates. Required to make the four switchs above this work
  #on fixed encounters
  Check_Preemp_and_Surprise_Always = 125
  
  #Set a variable that if this variable is not zero, all random fights will
  #be only with the troop id stored in the variable until it is set back to zero.
  Troop_Var = 0
  
  #Set the Global Maximum number of battles you want per map
  Max_Encounters = 30
  
  #Set how random fights are determined, according to the following flags
  # 1 - Value in the database is the maximum
  # 2 - Default RPGMaker setting
  # If set to an invalid number, it will default to 1
  Encounter_Method = 2
  
  #Set the Global Fear Level. The fear level is the point when enemies 
  #will avoid the party. Default is 99, so random fights will only
  #avoid the party once they hit max level.
  Fear_Level = 99
  
end

#----------------------------------------------------------------------------

 #Do not edit anything below here unless you know what you are doing.

#----------------------------------------------------------------------------

class RPG::Map
  
  attr_accessor :encounter_switch
  attr_accessor :region_switch
  attr_accessor :encounter_minimum
  attr_accessor :standard_deviation
  attr_accessor :number_of_encounters
  attr_accessor :fear_level
  attr_accessor :region_fear_level
  
  def initialize
    @region_switch = []
    @region_fear_level = []
  end
  
  
  def load_notetags_encounter_switch
    
    #Set the encounter switch to 0 to say no switch used.
    @encounter_switch = 0
    
    #Set the number of encounters to the global maximum
    @number_of_encounters = BGEncounter_Control::Max_Encounters
    
    #Yanfly Compatability
    if($imported["YEA-EncounterRateManager"] = true)
      @encounter_minimun = YEA::ENCOUNTER::MINIMUM_FREE_STEPS
    else
      @encounter_minimum = 1
    end
    
    @standard_deviation = 0
    
    @fear_level = BGEncounter_Control::Fear_Level
    
    #Set the encounter switch, if appliciable
    @store = self.note[/(?<=<Encounter Switch: ).*?(?=[>])/].to_i
    if(@store && @store != 0)
      @encounter_switch = @store
    end
    
    #Loads the minimum number of steps
    @store = self.note[/(?<=<Encounter Minimum: ).*?(?=[>])/].to_i
    if(@store && @store != 0)
      @encounter_minimum = @store
    end
    
    #for the normal distribution, experimental
    @store = self.note[/(?<=<Normal Distribution: ).*?(?=[>])/].to_i
    if(@store && @store != 0)
      @standard_deviation = @store
    end
    
    #Loads the maximum number of battles allowed
    @store = self.note[/(?<=<Maximum Encounters: ).*?(?=[>])/].to_i
    if(@store && @store != 0)
      @number_of_encounters = @store
    end
    
    #Loads the Fear Level
    @store = self.note[/(?<=<Fear Level: ).*?(?=[>])/].to_i
    if(@store && @store != 0)
      @fear_level = @store
    end

  end
  
end # End RPG::Map


class Game_Party < Game_Unit
  
  #Overwritten method, rate_preemptive
  def rate_preemptive(troop_agi)
    @prate = (agi >= troop_agi ? 0.05 : 0.03) * (raise_preemptive? ? 4 : 1)
        
    if($game_switches[BGEncounter_Control::Preemptive_Always] == true)
      @prate = 1.0
    end
    
    if($game_switches[BGEncounter_Control::Preemptive_Off] == true)
      @prate = 0.0
    end
    
    return @prate
  end #End rate_preemptive
  
  #Overwritten method, rate_surprise
  def rate_surprise(troop_agi)
    @srate = cancel_surprise? ? 0 : (agi >= troop_agi ? 0.03 : 0.05)
    
    if($game_switches[BGEncounter_Control::Surprise_Always] == true)
      return 1.0
    end
    
    if($game_switches[BGEncounter_Control::Surprise_Off] == true)
      return 0.0
    end
    
    return @srate
  end
  
  #Average level function is from Yanfly's Enemy Levels script (thanks Yanfly!),
  #Pasted here so as to not require the enemy level script for this script to work.
  def average_level 
    lv = 0 
    for member in all_members; lv += member.level; end 
    lv /= all_members.size 
    return lv 
  end 

end #End Game_Party Class


class Game_Map
  
  alias bg_map_encounter_switch setup
  
  #Alias method: setup
  def setup(map_id)
    
    #Call Aliased method
    bg_map_encounter_switch(map_id)
    
    #Set up the map
    @map.load_notetags_encounter_switch
    
  end
  
  def encounter_switch
    return @map.encounter_switch ||=0  
  end
  
  def encounter_minimum
    return @map.encounter_minimum ||=1
  end

  def standard_deviation
    return @map.standard_deviation ||=0  
  end
  
  def number_of_encounters
    return @map.number_of_encounters ||= BGEncounter_Control::Max_Encounters
  end
  
  def fear_level
    return @map.fear_level ||= BGEncounter_Control::Fear_Level
  end
  
  
  #New method, update encounter count
  #Num is the number to add (or subtract if negative) from the encounter count
  
  #To call manually, use the command $game_map.update_encounter_count(x), where
  #x is the number you want the count increased by (negative to decrease)
  def update_encounter_count(num)
    @map.number_of_encounters += num
    if(@map.number_of_encounters < 0)
        @map.number_of_encounters = 0
    end
    
  end #End Update_Encounter_Count
  
end # End Class Game_Map


class Game_Player < Game_Character
  
  attr_accessor  :encounter_rate    
  
  #Set up all aliased functions here
  alias bg_map_encounter_switch_update_encounter update_encounter
  alias bg_map_encounter_switch_initialize initialize
  alias bg_map_encounter_switch_encounter encounter
  alias bg_map_encounter_switch_make_encounter_troop_id make_encounter_troop_id
  
  #Aliased method, initialize
  def initialize
    bg_map_encounter_switch_initialize
    @encounter_rate = 1.0
  end
  
  #Alias method, update_encounter
  def update_encounter
    
    #Return if the parties average level is above or equal to the fear level
    if($game_party.average_level >= $game_map.fear_level)
      return
    end
    
    #Call code if the encounter switch is set to a valid number
    if($game_map.encounter_switch > 0)
      
      #Return if the switch is on, as no encounters.
      if($game_switches[$game_map.encounter_switch] == true)
        return
      end
      
    end
    
    #If the universal random encounter swtich is off, return as no
    #random fights allowed.
    if($game_switches[BGEncounter_Control::Encounter_Off] == false && BGEncounter_Control::Encounter_Off != 0)
      return
    end
    
    #If no more encounters left on the map, return
    if($game_map.number_of_encounters <= 0)
      return
    end
    
    #Call and return the aliased method
    return bg_map_encounter_switch_update_encounter
  end
  
  #Overwrite method, make encounter count
  def make_encounter_count
    n = $game_map.encounter_step - $game_map.encounter_minimum
    
    #error correction in case encounter min > encounter step
    if(n <= 0)
      n = 1
    end
    
    if($game_map.standard_deviation == 0)
      
      #Check to see whether to use the default RPGMaker setting, or the other
      if(BGEncounter_Control::Encounter_Method == 2)
        @encounter_count = rand(n) + rand(n) + $game_map.encounter_minimum
      else
        @encounter_count = rand(n) + $game_map.encounter_minimum
      end
      
    elsif
      #Ad-hoc normal distribution roll. Currently rolls any value between -3 and 3
      #for the value for z
      ctr = (rand * 6.0) - 3.0
      
      #Compute the value x as follows: x = mu + z * sigma. 
      @encounter_count = ($game_map.encounter_step + ctr * $game_map.standard_deviation).to_i
 
      #Safety check, if the value is < 1 or the minimum, set it to the minimum.
      if(@encounter_count < $game_map.encounter_minimum)
        @encounter_count = $game_map.encounter_minimum
      end #End of check to see if above the minimum
      
    end #End of check to see if normal distribution was used.
    
    #Add on the encounter boost from Yanfly's script, if installed.
    #Note that this script will allow you to go below the minimum with the
    #variable is so desired, so be careful!
    if($imported["YEA-EncounterRateManager"] = true)
      @encounter_count += Variable.encounter_boost
    end
    
    #Make sure we never went below 1 before exiting.
    if(@encounter_count < 1)
      @encounter_count = 1
    end
    
  end
  
  #Aliased method encounter
  def encounter
    #Call aliased method
    have_a_battle = bg_map_encounter_switch_encounter
    
    #If we just ended a fight, decrease the encounters on the map by one.
    if(have_a_battle == true)
      $game_map.update_encounter_count(-1)
    end
    
    #Return the original value for game processing.
    return have_a_battle
    
  end #End method encounter
  
  #Aliased method make_encounter_troop_id
  def make_encounter_troop_id
    #Call aliased method, store returned value
    current_troop = bg_map_encounter_switch_make_encounter_troop_id
    
    #If the variable is set for a forced troop, return that.
    if($game_variables[BGEncounter_Control::Troop_Var] != 0 && current_troop != 0)
      return $game_variables[BGEncounter_Control::Troop_Var]
    end
    
    #Return the returned value from the aliased method
    return current_troop
  end #End make_encounter_troop_id
  
end # Game_Player

#Class Game_Interpreter, for the new handing of surprise and preemptive rates
class Game_Interpreter

  #Overwriten method, command_301, also known as Battle Processing in the 
  #Event list
  def command_301
    return if $game_party.in_battle
    if @params[0] == 0                      # Direct designation
      troop_id = @params[1]
    elsif @params[0] == 1                   # Designation with variables
      troop_id = $game_variables[@params[1]]
    else                                    # Map-designated troop
      troop_id = $game_player.make_encounter_troop_id
    end
    if $data_troops[troop_id]
      BattleManager.setup(troop_id, @params[2], @params[3])
      
      if($game_switches[BGEncounter_Control::Check_Preemp_and_Surprise_Always] == true)
        BattleManager.on_encounter
      end
      
      BattleManager.event_proc = Proc.new {|n| @branch[@indent] = n }
      $game_player.make_encounter_count
      SceneManager.call(Scene_Battle)
    end
    Fiber.yield
  end #End command_301
  
end #End Class Game_Interpreter