# Game_Battler
# def item_apply

 #--------------------------------------------------------------------------
  # * Apply Effect of Skill/Item
  #--------------------------------------------------------------------------
  def item_apply(user, item)
    @result.clear
    @result.used = item_test(user, item)
    ctr = rand
    @result.missed = (@result.used && ctr > (item_hit(user, item) - item_eva(user, item)))
    store = item_hit(user, item) - item_eva(user, item)
  
    #@result.missed = (@result.used && rand >= item_hit(user, item))
    #@result.evaded = (!@result.missed && rand < item_eva(user, item))
    if @result.hit?
      unless item.damage.none?
        @result.critical = (rand < item_cri(user, item))
        make_damage_value(user, item)
        execute_damage(user)
      end
      item.effects.each {|effect| item_effect_apply(user, item, effect) }
      item_user_effect(user, item)
    end
  end