#==============================================================================
# ▼ State Common Events
# -- Author: Aeirex
# -- Version: 1.0.0
# -- Last Updated: 2015.01.06
# -- Level: Easy
# -- Requires: Hime - Scene Interpreter
#==============================================================================

#==============================================================================
# ■ Script Import
#==============================================================================
$imported = {} if $imported.nil?
$imported["AE-StateCommonEvents"] = true
#==============================================================================

#==============================================================================
# ▼ Introduction
# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# This is a basic state script which allows common event injection to states.
#==============================================================================

#==============================================================================
# ■ Configuration
#==============================================================================
module AeirexStateHelper
  InCombat = false # States will only call a Common Event in combat.
end
#==============================================================================

#==============================================================================
# ▼ Instructions
# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# Use these tags in States.
# <add common event: #>
# <remove common event: #>
#
# Add common event will trigger when a State is added. It will only process the
# common event after it is added and not before.
#
# Remove common event will trigger when a State is removed. It will only process
# the common event after it is removed and not before.
#
# This script relies on Hime - Scene Interpreter since RPG Maker VX ACE lacks
# global Common Events and are restricted to only process on the game map.
# Menus and battles do not work with common events, so this script is required
# for this script to work. You need to follow the instructions of the script,
# to specify which scene that the common event will open in.
#==============================================================================

#==============================================================================
# * States
#==============================================================================
class RPG::State
  #------------------------------------------------------------------------
  # * new add state: common event
  #------------------------------------------------------------------------
  def add_common_event
    if @add_common_event.nil?
      if @note =~ /<add common event: (.*)>/i
        @add_common_event = $1.to_i
      else
        @add_common_event = 0
      end
    end
    
    @add_common_event
  end

  #------------------------------------------------------------------------
  # * new remove state: common event
  #------------------------------------------------------------------------
  def remove_common_event
    if @remove_common_event.nil?
      if @note =~ /<remove common event: (.*)>/i
        @remove_common_event = $1.to_i
      else
        @remove_common_event = 0
      end
    end
    
    @remove_common_event
  end
 
end

#==============================================================================
# * Game_Battler
#==============================================================================
class Game_Battler < Game_BattlerBase   
  #------------------------------------------------------------------------
  # * alias method: add_state
  #------------------------------------------------------------------------
  alias add_state_ace add_state
  def add_state(state_id)   
    add_state_ace(state_id)

    # Call the common event only if in battle
    if !AeirexStateHelper::InCombat || $game_party.in_battle
      $game_temp.reserve_common_event($data_states[state_id].add_common_event)
    end
  end
 
  #------------------------------------------------------------------------
  # * alias method: erase_state
  #------------------------------------------------------------------------
  alias erase_state_ace erase_state
  def erase_state(state_id)   
    erase_state_ace(state_id)

    # Call the common event only if in battle
    if !AeirexStateHelper::InCombat || $game_party.in_battle
      $game_temp.reserve_common_event($data_states[state_id].remove_common_event)
    end
  end
 
end

#==============================================================================
# ▼ End of File
#==============================================================================