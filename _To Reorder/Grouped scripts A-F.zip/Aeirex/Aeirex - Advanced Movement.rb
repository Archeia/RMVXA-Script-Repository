﻿#==============================================================================
# ▼  Advanced Movement 1.3.0
# -- Last Updated: 2015.01.06
# -- Author: Aeirex
# -- Level: Easy
# -- Requires: n/a
#==============================================================================
# This will add more options to dash, and to movement speed and frequency.
#==============================================================================

#==============================================================================
# ■ Script Import
#==============================================================================
$imported = {} if $imported.nil?
$imported["AE-AdvancedMovement"] = true
#==============================================================================

#==============================================================================
# ■ Instructions
#==============================================================================
# By default this will lower the dash speed and turn dash always on, but you
# can alter these settings in the configuration below.
#==============================================================================

#==============================================================================
# ■ Installation
#==============================================================================
# Place this above all other scripts you have installed and below all base
# scripts.
#==============================================================================

#==============================================================================
# ■ Configuration
#==============================================================================
module AeirexMovement
  DISABLE_DASH = false # Disable dash completely?
  # If this option is enabled all options below will have no effect.
  
  DISABLE_WALK = true # Always dash?
  # If this option is enabled SHIFT_WALK will have no effect. This is useful if
  # the speed of dash and walk are so close that the difference is unnoticeable.
  
  SHIFT_WALK = false # Walk if you hold shift?
  
  # Determines how much speed is added when you dash (1 is default).
  DASH_SPEED = 1.0 # Only use whole numbers or prepare for event screen tearing.
  
  # This will alter your vehicle speed as well as your player speed.
  MOVE_SPEED = 3 # Set this higher to move faster (default 4).  
  MOVE_FREQUENCY = 6 # Set this higher to move more often (default 6).
  
  DASH_SWITCH = 0 # Dash will work always while this is on.
  # This is useful for cut-scenes and bypassing restrictions temporarily.
  
  DASH_VARIABLE = 0 # This is used to increase or decrease the speed of dash.
  # It will increase/decrease dash's speed for every point that it contains.
  # For example, if the variable is 200 it will increase dash by 200%. This is
  # useful if you want to control the speed of dash throughout your game as the
  # player becomes stronger. Also, the same rule applies with this as it does
  # with dash speed. Do not use values that aren't divisible by 100.
end
#==============================================================================

#------------------------------------------------------------------------------
# ■ Overrided methods
#------------------------------------------------------------------------------
# ▼ Game_Player
# dash?
# get_off_vehicle
#
# ▼ Game_CharacterBase
# real_move_speed
#
# ▼ Game_Vehicle
# init_move_speed
#------------------------------------------------------------------------------

#------------------------------------------------------------------------------
# ■ Alias methods
#------------------------------------------------------------------------------
# ▼ Game_CharacterBase
# init_public_members
#------------------------------------------------------------------------------

#==============================================================================
# * Game_Vehicle
#==============================================================================
class Game_Vehicle < Game_Character
  #--------------------------------------------------------------------------
  # override method: init_move_speed
  #--------------------------------------------------------------------------
  def init_move_speed
    @move_speed = AeirexMovement::MOVE_SPEED if @type == :boat
    @move_speed = AeirexMovement::MOVE_SPEED + 1 if @type == :ship
    @move_speed = AeirexMovement::MOVE_SPEED + 2 if @type == :airship
  end
end

#==============================================================================
# * Game_Player
#==============================================================================
class Game_Player < Game_Character
  #--------------------------------------------------------------------------
  # override method: dash?
  #--------------------------------------------------------------------------
  def dash?
    return true if $game_switches[AeirexMovement::DASH_SWITCH]
    return false if @move_route_forcing
    return false if $game_map.disable_dash?
    return false if vehicle
    return false if AeirexMovement::DISABLE_DASH
    return true if AeirexMovement::DISABLE_WALK
    
    if AeirexMovement::SHIFT_WALK
      return !Input.press?(:A)
    else
      return Input.press?(:A)
    end
  end
end
  
#==============================================================================
# * Game_CharacterBase
#==============================================================================
class Game_CharacterBase
  #--------------------------------------------------------------------------
  # override method: real_move_speed
  #--------------------------------------------------------------------------
  def real_move_speed
    @move_speed  + (dash? ? AeirexMovement::DASH_SPEED + ($game_variables[AeirexMovement::DASH_VARIABLE] / 100) : 0)
  end
  
  #--------------------------------------------------------------------------
  # override method: get_off_vehicle
  #--------------------------------------------------------------------------
  def get_off_vehicle
    if vehicle.land_ok?(@x, @y, @direction)
      set_direction(2) if in_airship?
      @followers.synchronize(@x, @y, @direction)
      vehicle.get_off
      unless in_airship?
        force_move_forward
        @transparent = false
      end
      @vehicle_getting_off = true
      @move_speed = AeirexMovement::MOVE_SPEED
      @through = false
      make_encounter_count
      @followers.gather
    end
    @vehicle_getting_off
  end
  
  #--------------------------------------------------------------------------
  # alias method: init_public_members
  #--------------------------------------------------------------------------
  alias init_public_members_ace init_public_members
  def init_public_members
    init_public_members_ace
    @move_speed = AeirexMovement::MOVE_SPEED
    @move_frequency = AeirexMovement::MOVE_FREQUENCY
  end
end