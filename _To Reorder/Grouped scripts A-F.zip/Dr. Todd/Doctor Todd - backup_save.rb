module Autosave
	def self.call
		DataManager.save_game_without_rescue($game_variables[ToddAutoSaveAce::VARIABLE])
		DataManager.backup_save
	end
end

module DataManager
	def self.backup_save
		File.open("backup_save.rvdata2", "wb") do |file|
			Marshal.dump(make_save_header, file)
			Marshal.dump(make_save_contents, file)
		end
	end
end
