#===============================================================================
#
# TP System Overhaul (1.1)
# 22/6/2014
# By Pacman
# RPG Maker VX Ace comes with a very cool system secondary to MP called TP. All
# actors (and enemies) have TP (whether it is shown or not is up to the user),
# with a maximum of 100. While an interesting idea and useful in a lot of ways,
# the default TP system is not very flexible to the users needs. This script
# sets out to get rid of restrictions placed by the default scripts in relation
# to TP.
#
# This super-sexy script will allow you to:
#   Give actors and enemies different maximum TP values (exceeding the default
#     limit of 100)
#   Give skills a TP cost of over 100
#   Change actor and enemy base TP values at your pleasure
#   Let the TP of an actor be effected by the actor's level
#   Give each actor or enemy a different formula for calculating the initial
#     TP they start every battle with.
#   Set TP altering stats on equips (Armors and Weapons)
#
# Notetags:
#   Put \mtp[x] in the notebox of an enemy or actor to give them the base max
#     TP value x.
#   Put \tp_gain[x] in the notebox of an equip to add x to the TP of an actor
#     who has it equipped.
#   Put \tp_mul[x] in the notebox of an equip to multiply the TP of an actor
#     who has it equipped by x.
#   Put \tp_per[x] in the notebox of an equip to change the TP of an actor who
#     has it equipped to x% of the preexisting value (\tp_per[150] will change,
#     for example, 200 into 300).
#
# Script Calls:
#   change_tp_limit(id, limit[, type])
#     Changes the base max TP of actor or enemy with ID id to limit. id and
#     limit must both be positive numbers. type must be :actor or :a for
#     changing and actor's limit, or :enemy or :e for changing an enemy's limit.
#     If type is ommited, it will default to actor.
#
# Configuration is below. Note that the formulaic options can be extremely
# complicated. They are there for super-duper-crazy-smart people to make their
# games extra-special fun if they want to. By all means, do not feel pressured
# to use these options.
#
#===============================================================================
#
# CONFIGURATION
#
#===============================================================================
 
module PAC
  module TP
    ACTOR_DEFAULT = 100 # Default for actor TP
    ENEMY_DEFAULT = 100 # Default for enemy TP
    LEVEL = true        # Does TP go up with actors' levels?
    LEVEL_GAIN_DEFAULT = "0"  # How much does TP go up in levels by default?
    # This is multiplied by the level of the actor.
    LEVEL_GAIN = []
    # In this array, we can store the formulae for calculating the amount TP
    # is gained specific to each actor. This is multiplied by the level of the
    # actor.
    LEVEL_GAIN[2] = "self.agi / 20"
    LEVEL_GAIN[6] = "self.atk / 20"
    ACTOR_INIT_FORMULA = "100"  # Default formula for
    # initializing actors' TP at the start of all battles.
    # You can specify the formula for actors in this array.
    AIF = []
    AIF[2] = "[[(rand * 100) - (rand * 100), 0].max + self.mtp / 100 *
    self.level, self.mtp / (self.level / 25)].min"
    ENEMY_INIT_FORMULA = "rand * 25"  # Default formula for
    # initializing enemies' TP at the start of all battles.
    # You can specify the formula for enemies in this array.
    EIF = []
  end
end
 
#===============================================================================
#
# END CONFIGURATION
#
#===============================================================================
 
($pac ||= {})[:tp_system] = 1.1
 
#==============================================================================
# ** RPG::Actor and RPG::Enemy
#------------------------------------------------------------------------------
#  Data classes for actors and enemies respectively.
#==============================================================================
 
#--------------------------------------------------------------------------
# Some high-tech shit goin' on up in here
#--------------------------------------------------------------------------
class RPG::Actor < RPG::BaseItem
  def mtp
    return !self.note[/\\mtp\[(\d+)\]/i].nil? ? $1.to_i : nil
  end
end

class RPG::Enemy < RPG::BaseItem
  def mtp
    return !self.note[/\\mtp\[(\d+)\]/i].nil? ? $1.to_i : nil
  end
end


#==============================================================================
# ** RPG::EquipItem
#------------------------------------------------------------------------------
#  A superclass of weapons and armor.
#==============================================================================
 
class RPG::EquipItem < RPG::BaseItem
  #--------------------------------------------------------------------------
  # * Get TP Gain value
  #--------------------------------------------------------------------------
  def tp_gain
    !self.note[/\\tp[_ ]?gain\[(\d+)\]/i].nil? ? $1.to_i : 0
  end
  #--------------------------------------------------------------------------
  # * Get TP Multiply value
  #--------------------------------------------------------------------------
  def tp_multiply
    !self.note[/\\tp[_ ]?mul(tiply)?\[(\d+)\]/i].nil? ? $1.to_i : 1
  end
  #--------------------------------------------------------------------------
  # * Get TP Percentage value
  #--------------------------------------------------------------------------
  def tp_percent
    !self.note[/\\tp[_ ]?per(cent)?\[(\d+)\]/i].nil? ? $1.to_i : 100
  end
end
 
#==============================================================================
# ** RPG::Skill
#------------------------------------------------------------------------------
#  The data class for skills.
#==============================================================================
 
class RPG::Skill < RPG::UsableItem
  #--------------------------------------------------------------------------
  # Alias listing
  #--------------------------------------------------------------------------
  alias pac_tpsys tp_cost
  #--------------------------------------------------------------------------
  # * Get adjusted TP cost
  #--------------------------------------------------------------------------
  def tp_cost(*args)
    !self.note[/\\tp[_ ]?cost\[(\d+)\]/i].nil? ? $1.to_i : pac_tpsys(*args)
  end
end
 
#==============================================================================
# ** Game_System
#------------------------------------------------------------------------------
#  This class handles system data. It saves the disable state of saving and
# menus. Instances of this class are referenced by $game_system.
#==============================================================================
 
class Game_System
  #--------------------------------------------------------------------------
  # Public Instance Variables
  #--------------------------------------------------------------------------
  attr_accessor :actor_tp
  attr_accessor :enemy_tp
  #--------------------------------------------------------------------------
  # Alias listing
  #--------------------------------------------------------------------------
  alias pac_tpsys_init initialize
  #--------------------------------------------------------------------------
  # * Object Initialization
  #--------------------------------------------------------------------------
  def initialize(*args)
    pac_tpsys_init(*args)
    setup_tp_arrays
  end
  #--------------------------------------------------------------------------
  # * Initialize TP Arrays
  #--------------------------------------------------------------------------
  def setup_tp_arrays
    @actor_tp = []
    for actor in $data_actors
      next if actor.nil?
      @actor_tp[actor.id] = actor.mtp || PAC::TP::ACTOR_DEFAULT
    end
    #----
    @enemy_tp = []
    for enemy in $data_enemies
      next if enemy.nil?
      @enemy_tp[enemy.id] = enemy.mtp || PAC::TP::ENEMY_DEFAULT
    end
  end
end
 
#==============================================================================
# ** Game_BattlerBase
#------------------------------------------------------------------------------
#  This base class handles battlers. It mainly contains methods for calculating
# parameters. It is used as a super class of the Game_Battler class.
#==============================================================================
 
class Game_BattlerBase
  #--------------------------------------------------------------------------
  # * Get Battler ID
  #--------------------------------------------------------------------------
  if !defined?(id); def id
    actor? ? @actor_id : @enemy_id
  end; end
  #--------------------------------------------------------------------------
  # * Get Max TP value
  #--------------------------------------------------------------------------
  def mtp
    b = actor? ? $game_system.actor_tp[self.id] : $game_system.enemy_tp[self.id]
    if actor? && PAC::TP::LEVEL
      e = PAC::TP::LEVEL_GAIN[self.id] || PAC::TP::LEVEL_GAIN_DEFAULT
      a = eval(e) * (self.level - 1) rescue 0
      b += a
      b += weapon_tp
    end
    b
  end
  #--------------------------------------------------------------------------
  # * Alias for Max TP value
  #--------------------------------------------------------------------------
  def max_tp
    mtp
  end
  #--------------------------------------------------------------------------
  # * Get TP modifiers from equips
  #--------------------------------------------------------------------------
  def weapon_tp
    return 0 if !actor?
    t = 0
    equips.each { |equip|
      next if equip.nil?
      n = 0
      n += equip.tp_gain
      n *= equip.tp_multiply
      n = (n * equip.tp_percent) / 100
      t += n
    }
    return t
  end
  #--------------------------------------------------------------------------
  # * Fix TP rate for adjusted Max TP
  #--------------------------------------------------------------------------
  def tp_rate
    @tp.to_f / max_tp
  end
end
 
#==============================================================================
# ** Game_Battler
#------------------------------------------------------------------------------
#  A battler class with methods for sprites and actions added. This class
# is used as a super class of the Game_Actor class and Game_Enemy class.
#==============================================================================
 
class Game_Battler < Game_BattlerBase
  #--------------------------------------------------------------------------
  # * Initialize TP
  #--------------------------------------------------------------------------
  def init_tp
    if actor?
      e = PAC::TP::AIF[self.id] || PAC::TP::ACTOR_INIT_FORMULA
    else
      e = PAC::TP::EIF[self.id] || PAC::TP::ENEMY_INIT_FORMULA
    end
    self.tp = eval(e) rescue (rand * 25)
  end
end
 
#==============================================================================
# ** Window_Base
#------------------------------------------------------------------------------
#  This is a super class of all windows within the game.
#==============================================================================
 
class Window_Base < Window
  #--------------------------------------------------------------------------
  # * Draw TP
  #--------------------------------------------------------------------------
  def draw_actor_tp(actor, x, y, width = 124)
    draw_gauge(x, y, width, actor.tp_rate, tp_gauge_color1, tp_gauge_color2)
    change_color(system_color)
    draw_text(x, y, 30, line_height, Vocab::tp_a)
    draw_current_and_max_values(x, y, width, actor.tp.to_i, actor.mtp,
      tp_color(actor), normal_color)
  end
end
 
#==============================================================================
# ** Game_Interpreter
#------------------------------------------------------------------------------
#  An interpreter for executing event commands. This class is used within the
# Game_Map, Game_Troop, and Game_Event classes.
#==============================================================================
 
class Game_Interpreter
  #--------------------------------------------------------------------------
  # * Alter TP limit for enemy or actor
  #--------------------------------------------------------------------------
  def change_tp_limit(id, limit, type = :actor)
    if type == :actor || type == :a
      $game_system.actor_tp[id] = [limit, 0].max
    elsif type == :enemy || type == :e
      $game_system.enemy_tp[id] = [limit, 0].max
    end
  end
end
 
#===============================================================================
#
# END OF SCRIPT
#
#===============================================================================