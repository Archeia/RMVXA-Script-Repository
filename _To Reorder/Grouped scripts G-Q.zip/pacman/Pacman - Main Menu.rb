#===============================================================================
#
# PAC Main Menu Ace (1.2)
# 15/7/2012
# By Pacman
#
#===============================================================================
#
# This is the PAC Main Menu converted to VX Ace. On a basic level, this offers
# a configurable setup for your main menu, allowing the user to create, alter
# and move the position of menu commands at their pleasure. It can be used
# very simply to merely reorder the default commands, or to its' fullest
# potential, that is creating commands to put custom scenes into the menu. It
# also offers two graphical features: adding an EXP gauge into the menu status
# window, and adding icons into the command display. Both are optional and
# customizable.
#
#===============================================================================
#
#   ~! INSTALLATION !~
# Paste above Main, below Materials. I suggest you paste this high up in your
# custom scripts list, for technical reasons considering overwriting methods.
# There are details for configuration below.
#
#===============================================================================
#
#   ~! DO NOT HESITATE TO ASK FOR HELP !~
# This can get very confusing, and there is so much you can do with this, so if
# you would like to know anything, just ask.
#
#===============================================================================
#--------------------
module PAC; module MM # <- Do not touch.
  #------------------
  # How to set up your menu commands:
  # Below is the COMMANDS array, which holds all the commands for the menu in
  # it. Within the array is a set of more arrays. Each array represents one
  # command. These command arrays can contain 5 elements, which each give a
  # piece of information to the script that sets up the menu. Note that each
  # element must be followed by a comma or an error will occur. Make sure that
  # each array begins with an open square bracket ([) and a close square bracket
  # (]).
  #----------
  # Element 1 - The Name
  # The first element of each array is the name that is displayed for that
  # command on the menu. It must be written in quotation marks ('' or "").
  #----------
  # Element 2 - The Method
  # The second element of each array is the name of the method that is executed
  # when the command is selected. The method must be located in the Scene_Menu
  # class. If you are planning on using this in tandem with a custom script's
  # scene, you should try and find the methods necessary to open that scene.
  # If a scene requires actor selection (Skill, Equip, etc.), put
  # "command_personal" as the method and set the scene in element 5.
  #----------
  # Element 3 - The Icon
  # The third element of each array is a number: the index of the icon to be
  # displayed in the menu window. The index is the number displayed at the
  # bottom-left of the icon selection window.
  #----------
  # Element 4 - The Disable Method
  # The fourth element of each array is a condition which, if met, disables
  # the command associated with it. The method must be located in the Scene_Menu
  # class, or accessible otherwise. To disable a command with a switch, use:
  # "$game_switches[x]" which will disable the command when switch with ID x is
  # on. To do the same with a variable, use:
  # "$game_variables[x] <=> n" which will disable the command when variable with
  # ID x is <=> to n.
  # This element can be ommited, or simply written as nil if you don't want one.
  # It must be there if you wish to include the fifth element though.
  #----------
  # Element 5 - The Scene Call
  # The fifth element (teehee) of each array is only required if the second
  # element is set to 'command_personal'. It is the command to be executed upon
  # actor selection. This is required for scenes that are specific to actors,
  # namely Skill, Equip, Status and any custom scenes that are similar.
  #----------
  # If you have any inquiries on how to use these elements in the most effective
  # way possible, or at all, ask away.
  #----------
  COMMANDS = [  # <- Do not touch
  #----------
    ['Inventory',             # Command Name
    'command_item',           # Command Method
    270,                      # Command Icon
    'main_commands_enabled'], # Disable Method
  #----------
    ['Skills',
    'command_personal',
    112,
    'main_commands_enabled',
    'SceneManager.call(Scene_Skill)'],  # Scene Call.
  #----------
    ['Equipment',
    'command_personal',
    147,
    'main_commands_enabled',
    'SceneManager.call(Scene_Equip)'],
  #----------
    ['Status',
    'command_personal',
    121,
    'main_commands_enabled',
    'SceneManager.call(Scene_Status)'],
  #----------
    ['Formation',
    'command_formation',
    12,
    'formation_enabled'],
  #----------
    ['Save',
    'command_save',
    117,
    'save_enabled'],
  #----------
    ['Game End',
    'command_game_end',
    6]
  #----------
  ] # <- Do not touch.
  #------------------
  Exp_Gauge = true  # Use the EXP Gauge?
  Exp_Color1 = "text_color(30)" # Color 1 for EXP gauge.
  Exp_Color2 = "text_color(31)" # Color 2 for EXP gauge.
  Exp_a = "EXP" # Text displayed on the EXP Gauge.
  Icons = true  # Use icons in the menu display?
  ALIGNMENT = 0 # Alignment of menu command text. 0 for left, 1 for center, 2
  # for right.
  Map_Window = true   # Use the map window in the menu display?
  Time_Window = true  # Use the time window in the menu display?
  Time_Height = 1     # Height of the time window.
  Gold_Window = true  # Use the gold window in the menu display
  Gold_Correction = true  # Correct the gold window's y value to fit in?
  Windows_Pos = :left # Command, gold, map and time window orientation. :left
  # or :right. Anything else will go to :left.
  Heal_Button = :F5 # Button to fully heal the party in the menu. Set to nil if
  # you don't want that. It will also clear all statuses. Only in test play, of
  # course.
#--------------------
end; end
#--------------------

#===============================================================================
#
# END OF CONFIGURATION
#
#==============================================================================
# ** Game_System
#------------------------------------------------------------------------------
#  This class handles system data. It saves the disable state of saving and 
# menus. Instances of this class are referenced by $game_system.
#==============================================================================

class Game_System
  #--------------------------------------------------------------------------
  # Public Instance Variables
  #--------------------------------------------------------------------------
  attr_accessor :menu_index, :menu_actor_selection
  #--------------------------------------------------------------------------
  # Alias listing
  #--------------------------------------------------------------------------
  alias pac_mm_gsys_ini initialize
  #--------------------------------------------------------------------------
  # * Object Initialization
  #--------------------------------------------------------------------------
  def initialize(*args)
    pac_mm_gsys_ini(*args)
    @menu_index = 0
    @menu_actor_selection = false
  end
end

#==============================================================================
# ** Window_Base
#------------------------------------------------------------------------------
#  This is a super class of all windows within the game.
#==============================================================================

if PAC::MM::Exp_Gauge
class Window_Base < Window
  #--------------------------------------------------------------------------
  # Alias Listing
  #--------------------------------------------------------------------------
  alias pac_mm_wnbs_simsta draw_actor_simple_status if PAC::MM::Exp_Gauge
  #--------------------------------------------------------------------------
  # * Get Text Colors (writing color without the u is killing me)
  #--------------------------------------------------------------------------
  def exp_gauge_color1; eval PAC::MM::Exp_Color1 rescue text_color(30); end
  def exp_gauge_color2; eval PAC::MM::Exp_Color2 rescue text_color(31); end
  #--------------------------------------------------------------------------
  # * Draw EXP
  #--------------------------------------------------------------------------
  def draw_actor_exp(actor, x, y, width = 60)
    draw_gauge(x, y, width, actor.final_exp_rate, exp_gauge_color1,
     exp_gauge_color2)
    change_color(system_color)
    draw_text(x, y, 30, line_height, PAC::MM::Exp_a)
    draw_current_and_max_values(x, y, width, actor.exp, actor.next_level_exp,
      normal_color, normal_color)
  end
  #--------------------------------------------------------------------------
  # * Draw Simple Status
  #--------------------------------------------------------------------------
  def draw_actor_simple_status(actor, x, y, *args)
    pac_mm_wnbs_simsta(actor, x, y, *args)
    draw_actor_exp(actor, x + 58, y + line_height)
  end
end
end

#==============================================================================
# ** Window_MenuStatus
#------------------------------------------------------------------------------
#  This window displays the map name on the menu screen.
#==============================================================================

class Window_MenuMap < Window_Base
  #--------------------------------------------------------------------------
  # * Object Initialization
  #--------------------------------------------------------------------------
  def initialize(x, y)
    super(x, y, window_width, fitting_height(1))
    refresh
  end
  #--------------------------------------------------------------------------
  # * Get Window Width
  #--------------------------------------------------------------------------
  def window_width
    return 160
  end
  #--------------------------------------------------------------------------
  # * Refresh
  #--------------------------------------------------------------------------
  def refresh
    contents.clear
    change_color(normal_color)
    unless $game_map.display_name.empty?
      draw_text(contents.rect, $game_map.display_name, 1)
    end
  end
end

#==============================================================================
# ** Window_Time
#------------------------------------------------------------------------------
#  This window displays play time on the menu screen.
#==============================================================================

class Window_Time < Window_Base
  #--------------------------------------------------------------------------
  # * Object Initialization
  #--------------------------------------------------------------------------
  def initialize(x, y)
    super(x, y, window_width, fitting_height(PAC::MM::Time_Height || 1))
    refresh
  end
  #--------------------------------------------------------------------------
  # * Get Window Width
  #--------------------------------------------------------------------------
  def window_width
    return 160
  end
  #--------------------------------------------------------------------------
  # * Refresh
  #--------------------------------------------------------------------------
  def refresh
    contents.clear
    @time = Graphics.frame_count / Graphics.frame_rate
    hour = @time / 3600
    min = @time / 60 % 60
    sec = @time % 60
    text = sprintf("%02d:%02d:%02d", hour, min, sec)
    change_color(normal_color)
    draw_text(contents.rect, text, 1)
  end
  #--------------------------------------------------------------------------
  # * Frame Update
  #--------------------------------------------------------------------------
  def update
    super
    refresh if Graphics.frame_count / Graphics.frame_rate != @time
  end
end

#==============================================================================
# ** Window_MenuCommand
#------------------------------------------------------------------------------
#  This command window appears on the menu screen.
#==============================================================================

class Window_MenuCommand < Window_Command
  #--------------------------------------------------------------------------
  # * Initialize Command Selection Position (Class Method)
  #--------------------------------------------------------------------------
  def self.init_command_position(*args)
    @@last_command_symbol ||= nil
  end
  #--------------------------------------------------------------------------
  # * Create Command List
  #--------------------------------------------------------------------------
  def make_command_list(*args)
    PAC::MM::COMMANDS.each {|c| add_command(c[0], c[0].to_sym, pac_disable(c))}
  end
  #--------------------------------------------------------------------------
  # * Disable PAC Command
  #--------------------------------------------------------------------------
  def pac_disable(command)
    command[3] || ''
  end
  #--------------------------------------------------------------------------
  # * Draw Item
  #--------------------------------------------------------------------------
  def draw_item(index, *args)
    rect = item_rect_for_text(index)
    if PAC::MM::Icons && PAC::MM::COMMANDS[index][2] != nil
      irect = item_rect(index)
      draw_icon(PAC::MM::COMMANDS[index][2], irect.x, irect.y)
      rect.x += 24
    end
    change_color(normal_color, command_enabled?(index))
    draw_text(rect, command_name(index), PAC::MM::ALIGNMENT)
  end
end

#==============================================================================
# ** Scene_Menu
#------------------------------------------------------------------------------
#  This class performs the menu screen processing.
#==============================================================================

class Scene_Menu < Scene_MenuBase
  #--------------------------------------------------------------------------
  # Alias listing
  #--------------------------------------------------------------------------
  alias pac_mm_start  start
  alias pac_mm_update update
  alias pac_mm_cgw    create_gold_window if PAC::MM::Gold_Correction
  alias pac_mm_opc    on_personal_cancel
  #--------------------------------------------------------------------------
  # * Start Processing
  #--------------------------------------------------------------------------
  def start(*args)
    pac_mm_start
    @@start_personal ||= false
    if @@start_personal; @command_window.deactivate; command_personal; end
    if PAC::MM::Windows_Pos == :right
      @gold_window.x = Graphics.width-@gold_window.width if @gold_window != nil
      @status_window.x = 0
    end
  end
  #--------------------------------------------------------------------------
  # * Frame Update
  #--------------------------------------------------------------------------
  def update(*args)
    pac_mm_update(*args)
    update_heal
  end
  #--------------------------------------------------------------------------
  # * Update Heal Butten
  #--------------------------------------------------------------------------
  def update_heal # BUTTEN
    if $TEST && PAC::MM::Heal_Button != nil &&
     Input.trigger?(PAC::MM::Heal_Button)
      Sound.play_recovery
      $game_party.members do |actor| actor.recover_all end
    end
  end
  #--------------------------------------------------------------------------
  # * Create Command Window
  #--------------------------------------------------------------------------
  def create_command_window(*args)
    @command_window = Window_MenuCommand.new
    PAC::MM::COMMANDS.each {|c|
      @command_window.set_handler(c[0].to_sym, pac_method(c))
    }
    @command_window.set_handler(:cancel, method(:return_scene))
    if PAC::MM::Windows_Pos == :right
      @command_window.x = Graphics.width - @command_window.width
    end
    create_map_window
    create_time_window
  end
  #--------------------------------------------------------------------------
  # * Create Gold Window
  #--------------------------------------------------------------------------
  if PAC::MM::Gold_Correction; def create_gold_window(*args)
    pac_mm_cgw(*args)
    @gold_window.visible = false if !PAC::MM::Gold_Window
    y = @command_window.height
    y += @map_window.height if @map_window
    y += @time_window.height if @time_window
    @gold_window.y = y
  end; end
  #--------------------------------------------------------------------------
  # * Create Map Window
  #--------------------------------------------------------------------------
  def create_map_window
    x = PAC::MM::Windows_Pos ==:right ? Graphics.width-@command_window.width : 0
    @map_window = Window_MenuMap.new(x, @command_window.height)
    @map_window.visible = false if !PAC::MM::Map_Window
  end
  #--------------------------------------------------------------------------
  # * Create Time Window
  #--------------------------------------------------------------------------
  def create_time_window
    x = PAC::MM::Windows_Pos ==:right ? Graphics.width-@command_window.width : 0
    y = @map_window.nil? ? @command_window.height : @map_window.height +
     @map_window.y
    @time_window = Window_Time.new(x, y)
    @time_window.visible = fasle if !PAC::MM::Time_Window
  end
  #--------------------------------------------------------------------------
  # * Get Method for Command
  #--------------------------------------------------------------------------
  def pac_method(command)
    method(command[1] || '')
  end
  #--------------------------------------------------------------------------
  # * [OK] Personal Command
  #--------------------------------------------------------------------------
  def on_personal_ok(*args)
    @@start_personal = true
    eval(PAC::MM::COMMANDS[@command_window.index][4]) rescue nil
  end
  #--------------------------------------------------------------------------
  # * [Cancel] Personal Command
  #--------------------------------------------------------------------------
  def on_personal_cancel(*args)
    pac_mm_opc(*args)
    @command_window.activate
    @@start_personal = false
  end
end

($pac ||= {})[:main_menu] = 1.2

#===============================================================================
#
# END OF SCRIPT
#
#===============================================================================