#===============================================================================
#
# Enemy HUD (1.3)
# 15/4/2012
# By Pacman (ported to VXA from a VX script also by Pacman)
# This script displays enemy stats (HP, MP, TP, stat icons) in the battle screen
# whilst selecting which enemy to target. It also includes special tags to
# prevent any of these stats from being drawn. And yes, enemies do have TP.
# To have the HP, MP, TP (more info later), name or stat icons not drawn, use
# the following words in the enemy's notebox:
# unknown hp
# unknown mp
# unknown tp
# unknown name
# unknown stat
# These are case insensetive (i.e., you may use any case for them) and you can
# use underscores (_) or nothing instead of spaces.
# By default, enemies' TP gauges are not drawn. If you want it to be drawn,
# you can use the tag:
# display tp
# in the enemy's notebox. This is also case insensetive.
#
# New in 1.1, you can make the numbers of the enemy's gauges hidden. This would
# be specifically useful for boss battles. To do this, use either one of these:
# \boss
# hide numbers
#
# New in 1.2, you can make use of MA's Monster Catalogue by placing the tag:
# \ma_scan
# in the enemy's notebox to make it only display the numbers on the gauges once
# the enemy has been scanned. You can also adjust this at line 39.
#
#===============================================================================
 
($pac ||= {})[:enemy_hud] = 1.3
 
module PAC
  module ENHUD
    MA_MC = false       # If this is true, any enemy must be scanned before its
                        # details are shown.
    MA_MC_NAME = false  # If this is true, names won't be displayed on enemies
                        # that require the MA scan.
  end
end
 
#==============================================================================
# ** Game_Battler
#------------------------------------------------------------------------------
#  A battler class with methods for sprites and actions added. This class
# is used as a super class of the Game_Actor class and Game_Enemy class.
#==============================================================================
 
class Game_Battler < Game_BattlerBase
  #--------------------------------------------------------------------------
  # * Get data from notebox
  #--------------------------------------------------------------------------
  def stat_note?(code)
    data = actor? ? actor : enemy
    if code.is_a?(String)
      data.note.include?(note)
    else
      !data.note[code].nil?
    end
  end
  #--------------------------------------------------------------------------
  # * Monster Catalogue Scan
  #--------------------------------------------------------------------------
  def ma_scan_req
    stat_note?(/\\ma[_ ]?scan[_ ]?(req(uired)?)?/i)
  end
  #--------------------------------------------------------------------------
  # * Have I been scanned?
  #--------------------------------------------------------------------------
  def scanned?
    return true if actor? || !PAC::ENHUD::MA_MC
    return $game_system.mamc_data_conditions_met?(:analyze, @enemy_id)
  end
  #--------------------------------------------------------------------------
  # * Don't display gauge numbers?
  #--------------------------------------------------------------------------
  def boss?
    stat_note?(/\\boss/i) || stat_note?(/\\hide[_ ]?num(bers)?/i)
  end
  #--------------------------------------------------------------------------
  # * Don't display enemy MP?
  #--------------------------------------------------------------------------
  def no_mp_display?
    stat_note?(/UNKNOWN[_ ]?MP/i)
  end
  #--------------------------------------------------------------------------
  # * Display enemy TP?
  #--------------------------------------------------------------------------
  def tp_display?
    stat_note?(/DISPLAY[_ ]?TP/i)
  end
  #--------------------------------------------------------------------------
  # * Don't display enemy TP?
  #--------------------------------------------------------------------------
  def no_tp_display?
    stat_note?(/UNKNOWN[_ ]?TP/i) || !tp_display?
  end
  #--------------------------------------------------------------------------
  # * Don't display enemy HP?
  #--------------------------------------------------------------------------
  def no_hp_display?
    stat_note?(/UNKNOWN[_ ]?HP/i)
  end
  #--------------------------------------------------------------------------
  # * Don't display enemy name?
  #--------------------------------------------------------------------------
  def no_name_display?
    return true if stat_note?(/UNKNOWN[_ ]?NAME/i)
    return false unless self.enemy?
    return true if PAC::ENHUD::MA_MC_NAME && !scanned?
    return false
  end
  #--------------------------------------------------------------------------
  # * Don't display enemy stat icons?
  #--------------------------------------------------------------------------
  def no_stat_display?
    stat_note?(/UNKNOWN[_ ]?STATS?/i)
  end
end
 
#==============================================================================
# ** Window_Base
#------------------------------------------------------------------------------
#  This is a super class of all windows within the game.
#==============================================================================
 
class Window_Base < Window
  #--------------------------------------------------------------------------
  # * Find battler's boss value
  #--------------------------------------------------------------------------
  def boss?(battler)
    return battler.boss?
  end
  #--------------------------------------------------------------------------
  # * Draw HP
  #--------------------------------------------------------------------------
  def draw_actor_hp(actor, x, y, width = 124)
    draw_gauge(x, y, width, actor.hp_rate, hp_gauge_color1, hp_gauge_color2)
    change_color(system_color)
    draw_text(x, y, 30, line_height, Vocab::hp_a)
    draw_current_and_max_values(x, y, width, actor.hp, actor.mhp,
      hp_color(actor), normal_color) unless boss?(actor)
  end
  #--------------------------------------------------------------------------
  # * Draw MP
  #--------------------------------------------------------------------------
  def draw_actor_mp(actor, x, y, width = 124)
    draw_gauge(x, y, width, actor.mp_rate, mp_gauge_color1, mp_gauge_color2)
    change_color(system_color)
    draw_text(x, y, 30, line_height, Vocab::mp_a)
    draw_current_and_max_values(x, y, width, actor.mp, actor.mmp,
      mp_color(actor), normal_color) unless boss?(actor)
  end
  #--------------------------------------------------------------------------
  # * Draw TP
  #--------------------------------------------------------------------------
  def draw_actor_tp(actor, x, y, width = 124)
    draw_gauge(x, y, width, actor.tp_rate, tp_gauge_color1, tp_gauge_color2)
    change_color(system_color)
    draw_text(x, y, 30, line_height, Vocab::tp_a)
    change_color(tp_color(actor))
    if $pac[:tp_system]
      draw_current_and_max_values(x, y, width, actor.tp.to_i, actor.mtp,
        tp_color(actor), normal_color) unless boss?(actor)
    else
      unless boss?(actor)
        draw_text(x + width - 42, y, 42, line_height, actor.tp.to_i, 2)
      end
    end
  end
end
 
#==============================================================================
# ** Window_EnemyHUD
#------------------------------------------------------------------------------
# 　戦闘は画面上のウィンドウで、ターゲットの敵キャラクタのアクションを選択します。このウィンドウには、敵のHP、MP、
#  TP、統計情報と名前が表示されます。
#==============================================================================
 
class Window_EnemyHUD < Window_BattleStatus
  #--------------------------------------------------------------------------
  # * Object Initialization
  #--------------------------------------------------------------------------
  def initialize(info_viewport)
    super()
    self.y = info_viewport.rect.y
    self.visible = false
    self.openness = 255
    @info_viewport = info_viewport
    @enemies = []
    $game_troop.alive_members.each do |enemy|
      next unless enemy.exist?
      @enemies.push(enemy)
    end
  end
  #--------------------------------------------------------------------------
  # * Show window
  #--------------------------------------------------------------------------
  def show
    if @info_viewport
      width_remain = Graphics.width - width
      self.x = width_remain
      @info_viewport.rect.width = width_remain
      select(0)
    end
    super
  end
  #--------------------------------------------------------------------------
  # * Hide window
  #--------------------------------------------------------------------------
  def hide
    @info_viewport.rect.width = Graphics.width if @info_viewport
    super
  end
  #--------------------------------------------------------------------------
  # * Get enemy
  #--------------------------------------------------------------------------
  def enemy
    $game_troop.members[@index]
  end
  #--------------------------------------------------------------------------
  # * Get item max
  #--------------------------------------------------------------------------
  def item_max
    return $game_troop.members.size
  end
  #--------------------------------------------------------------------------
  # * Draw Item
  #     index : item to be drawn
  #--------------------------------------------------------------------------
  def draw_item(index)
    rect = item_rect(index)
    rect.x += 4
    rect.width -= 8
    contents.clear_rect(rect)
    contents.font.color = normal_color
    enemy = $game_troop.members[index]
    draw_basic_area(basic_area_rect(index), enemy)
    draw_gauge_area(gauge_area_rect(index), enemy)
  end
  #--------------------------------------------------------------------------
  # * Get rect for basic area
  #--------------------------------------------------------------------------
  def basic_area_rect(index)
    rect = item_rect_for_text(index)
    rect.width -= gauge_area_width + 10
    rect
  end
  #--------------------------------------------------------------------------
  # * Get rect for gauge area
  #--------------------------------------------------------------------------
  def gauge_area_rect(index)
    rect = item_rect_for_text(index)
    rect.x += rect.width - gauge_area_width
    rect.width -= gauge_area_width
    rect
  end
  #--------------------------------------------------------------------------
  # * Get width for gauge area
  #--------------------------------------------------------------------------
  def gauge_area_width
    return 220
  end
  #--------------------------------------------------------------------------
  # * Draw Enemy's basic information
  #--------------------------------------------------------------------------
  def draw_basic_area(rect, enemy)
    unless enemy.no_name_display?
      draw_actor_name(enemy, 4, rect.y)
    end; unless enemy.no_stat_display?
      draw_actor_icons(enemy, 114, rect.y, 48)
    end
  end
  #--------------------------------------------------------------------------
  # * Draw Enemy's gauges
  #--------------------------------------------------------------------------
  def draw_gauge_area(rect, enemy)
    if !enemy.no_tp_display?
      if enemy.no_mp_display? && !enemy.no_hp_display?
        draw_gauge_area_without_mp(rect, enemy)
      elsif enemy.no_hp_display? && !enemy.no_mp_display?
        draw_gauge_area_without_hp(rect, enemy)
      elsif enemy.no_hp_display? && enemy.no_mp_display?
        draw_gauge_area_without_mp_hp(rect, enemy)
      else
        draw_gauge_area_with_tp(rect, enemy)
      end
    else
      if enemy.no_mp_display? && !enemy.no_hp_display?
        draw_gauge_area_without_tp_mp(rect, enemy)
      elsif enemy.no_hp_display? && !enemy.no_mp_display?
        draw_gauge_area_without_tp_hp(rect, enemy)
      elsif enemy.no_hp_display? && enemy.no_mp_display?
        draw_gauge_area_blank(rect, enemy)
      else
        draw_gauge_area_without_tp(rect, enemy)
      end
    end
  end
  #--------------------------------------------------------------------------
  # * Draw gauge area with HP, MP and TP
  #--------------------------------------------------------------------------
  def draw_gauge_area_with_tp(rect, actor)
    draw_actor_hp(actor, rect.x + 0, rect.y, 72)
    draw_actor_mp(actor, rect.x + 82, rect.y, 64)
    draw_actor_tp(actor, rect.x + 156, rect.y, 64)
  end
  #--------------------------------------------------------------------------
  # * Draw gauge area with HP and MP
  #--------------------------------------------------------------------------
  def draw_gauge_area_without_tp(rect, actor)
    draw_actor_hp(actor, rect.x + 0, rect.y, 134)
    draw_actor_mp(actor, rect.x + 144,  rect.y, 76)
  end
  #--------------------------------------------------------------------------
  # * Draw gauge area with HP and TP
  #--------------------------------------------------------------------------
  def draw_gauge_area_without_mp(rect, actor)
    draw_actor_hp(actor, rect.x + 0, rect.y, 134)
    draw_actor_tp(actor, rect.x + 144, rect.y, 76)
  end
  #--------------------------------------------------------------------------
  # * Draw gauge area with MP and TP
  #--------------------------------------------------------------------------
  def draw_gauge_area_without_hp(rect, actor)
    draw_actor_mp(actor, rect.x + 0, rect.y, 134)
    draw_actor_tp(actor, rect.x + 144, rect.y, 76)
  end
  #--------------------------------------------------------------------------
  # * Draw gauge area with MP
  #--------------------------------------------------------------------------
  def draw_gauge_area_without_tp_hp(rect, actor)
    draw_actor_mp(actor, rect.x + 0, rect.y, rect.width)
  end
  #--------------------------------------------------------------------------
  # * Draw gauge area with TP
  #--------------------------------------------------------------------------
  def draw_gauge_area_without_mp_hp(rect, actor)
    draw_actor_tp(actor, rect.x + 0, rect.y, rect.width)
  end
  #--------------------------------------------------------------------------
  # * Draw gauge area with HP
  #--------------------------------------------------------------------------
  def draw_gauge_area_without_tp_mp(rect, actor)
    draw_actor_hp(actor, rect.x + 0, rect.y, rect.width)
  end
  #--------------------------------------------------------------------------
  # * Draw gauge area with no gauges (useless method ;0)
  #--------------------------------------------------------------------------
  def draw_gauge_area_blank(*a)
  end
end
 
#==============================================================================
# ** Scene_Battle
#------------------------------------------------------------------------------
# 　バトル画面の処理を行うクラスです。
#==============================================================================
 
class Scene_Battle < Scene_Base
  #--------------------------------------------------------------------------
  # * 敵キャラウィンドウの作成
  #--------------------------------------------------------------------------
  def create_enemy_window
    @enemy_window = Window_EnemyHUD.new(@info_viewport)
    @enemy_window.set_handler(:ok,     method(:on_enemy_ok))
    @enemy_window.set_handler(:cancel, method(:on_enemy_cancel))
  end
end
 
if PAC::ENHUD::MA_MC && !($imported ||= {})[:MA_MonsterCatalogue]
msg = "PAC Enemy HUD: Modern Algebra's Monster Catalogue not installed.\n"
msg += "Please install that script or disable its' usage in existing scripts.\n"
msg += "Make sure the Monster Catalogue is above the Enemy HUD in the editor.\n"
msgbox msg; exit; end
 
#===============================================================================
#
# END OF SCRIPT
#
#===============================================================================