# Change Gauge Display (2.0)
# 29/1/2012
# By Pacman
# This script allows you to change if TP is displayed throughout the game. You
# can also set actors to not have their TP, HP or MP gauges drawn in battle.
# To change the displaying of TP, use the following script call:
# change_tp_display(true / false)
# Putting the argument as true will make the TP display, false will make it not
# display. Having no argument will simply toggle it.
# To have an actor's TP not drawn in battle, place the following tag in their
# notebox:
# \no_tp_display
# Similarly, to have an actor's HP or MP not drawn in battle, place the
# following tags in their notebox, respectively:
# \no_hp_display
# \no_mp_display
#

#==============================================================================
# ** RPG::Actor
#------------------------------------------------------------------------------
# 　Data class for actors. Subclass of RPG::BaseItem. Some Japanese twaddle.
#==============================================================================

class RPG::Actor < RPG::BaseItem
  #--------------------------------------------------------------------------
  # * Don't display actor's TP?
  #--------------------------------------------------------------------------
  def no_tp_display?
    return !self.note[/\\no[_ ]?tp[_ ]?display/i].nil?
  end
  #--------------------------------------------------------------------------
  # * Don't display actor's MP?
  #--------------------------------------------------------------------------
  def no_mp_display?
    return !self.note[/\\no[_ ]?mp[_ ]?display/i].nil?
  end
  #--------------------------------------------------------------------------
  # * Don't display actor's HP?
  #--------------------------------------------------------------------------
  def no_hp_display?
    return !self.note[/\\no[_ ]?hp[_ ]?display/i].nil?
  end
end

#==============================================================================
# ** Game_System
#------------------------------------------------------------------------------
#==============================================================================

class Game_System
  #--------------------------------------------------------------------------
  # Puclic Instance Variables no desu
  #--------------------------------------------------------------------------
  attr_accessor :opt_display_tp
  #--------------------------------------------------------------------------
  # Alias listing desu
  #--------------------------------------------------------------------------
  alias tp_change_init initialize
  #--------------------------------------------------------------------------
  # * Object Initialization
  #--------------------------------------------------------------------------
  def initialize(*args) # Desu
    @opt_display_tp = $data_system.opt_display_tp
    tp_change_init(*args)
  end
end

#==============================================================================
# ** Game_Interpreter
#------------------------------------------------------------------------------
#==============================================================================

class Game_Interpreter
  #--------------------------------------------------------------------------
  # * Alter displaying of TP
  #     boo : Argument to decide the state of TP. If left out, desu.
  #--------------------------------------------------------------------------
  def change_tp_display(boo = nil)
    $game_system.opt_display_tp = boo == nil ? !$game_system.opt_display_tp :
    boo
  end
end

#=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+
# ** Window_BattleStatus
#=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+

class Window_BattleStatus < Window_Selectable
  #--------------------------------------------------------------------------
  # * Draw Actor Gauges です
  #--------------------------------------------------------------------------
  def draw_gauge_area(rect, actor, *a)
    if $game_system.opt_display_tp && !actor.actor.no_tp_display?
      if actor.actor.no_mp_display? && !actor.actor.no_hp_display?
        draw_gauge_area_without_mp(rect, actor, *a)
      elsif actor.actor.no_hp_display? && !actor.actor.no_mp_display?
        draw_gauge_area_without_hp(rect, actor, *a)
      elsif actor.actor.no_hp_display? && actor.actor.no_mp_display?
        draw_gauge_area_without_mp_hp(rect, actor, *a)
      else
        draw_gauge_area_with_tp(rect, actor, *a)
      end
    else
      if actor.actor.no_mp_display? && !actor.actor.no_hp_display?
        draw_gauge_area_without_tp_mp(rect, actor, *a)
      elsif actor.actor.no_hp_display? && !actor.actor.no_mp_display?
        draw_gauge_area_without_tp_hp(rect, actor, *a)
      elsif actor.actor.no_hp_display? && actor.actor.no_mp_display?
        draw_gauge_area_blank(rect, actor, *a)
      else
        draw_gauge_area_without_tp(rect, actor, *a)
      end
    end
  end
  #--------------------------------------------------------------------------
  # * Draw without MP
  #--------------------------------------------------------------------------
  def draw_gauge_area_without_mp(rect, actor)
    draw_actor_hp(actor, rect.x + 0, rect.y, 134)
    draw_actor_tp(actor, rect.x + 144, rect.y, 76)
  end
  #--------------------------------------------------------------------------
  # * Draw without HP
  #--------------------------------------------------------------------------
  def draw_gauge_area_without_hp(rect, actor)
    draw_actor_mp(actor, rect.x + 0, rect.y, 134)
    draw_actor_tp(actor, rect.x + 144, rect.y, 76)
  end
  #--------------------------------------------------------------------------
  # * Draw without TP and HP
  #--------------------------------------------------------------------------
  def draw_gauge_area_without_tp_hp(rect, actor)
    draw_actor_mp(actor, rect.x + 0, rect.y, rect.width)
  end
  #--------------------------------------------------------------------------
  # * Draw without MP and HP
  #--------------------------------------------------------------------------
  def draw_gauge_area_without_mp_hp(rect, actor)
    draw_actor_tp(actor, rect.x + 0, rect.y, rect.width)
  end
  #--------------------------------------------------------------------------
  # * Draw without TP and MP
  #--------------------------------------------------------------------------
  def draw_gauge_area_without_tp_mp(rect, actor)
    draw_actor_hp(actor, rect.x + 0, rect.y, rect.width)
  end
  #--------------------------------------------------------------------------
  # * Draw blank (useless method ;])
  #--------------------------------------------------------------------------
  def draw_gauge_area_blank(*a)
  end
end

$imported ||= {}
$imported[:pac_gauge_change] = [2.0]

#
# END OF SCRIPT.
