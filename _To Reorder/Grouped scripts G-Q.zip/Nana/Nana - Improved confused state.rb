#==============================================================================
#                     「Confusion State Improvement」(ACE) Ver.1.0
#   Author: Nana
#   Homepage: http://heptanas.mamagoto.com/
#
#   ◇Terms of Use
#   Please credit "Nana."
#   Feel free to modify this script and/or distribute it.
#   Also please include the credit in the readme or somewhere it's accessible. (Not from credit roll)
#   Check the blog for detailed terms of use.
#
#------------------------------------------------------------------------------
#  
#   Confusion by default, attacks enemies or allies.
#   First, decide whether confused state attacks an enemy or ally by 1/2
#   It determines of who will be attacked according to the target rate.
#  
#   Under confused state, it attacks enemy/ party member not yourself.
#   Based on the target rate.
#  
#   Attacking your party member are likely if you have more with you in battle.
#   It's possible to prevent confused state from attacking your ally during battle.
#   Effectiveness of confusion will be reduced if there's 1 party member.
#  
#   Paste this script above Main.
#   （No need to set the scripts in a particular order）
#  
#==============================================================================
 
#==============================================================================
# ■ Game_Action
#------------------------------------------------------------------------------
# 　Class that controls battle behavior. Handled inside Game_Battler class.
#==============================================================================
 
class Game_Action
  #--------------------------------------------------------------------------
  # ● Confused Target
  #--------------------------------------------------------------------------
  def confusion_target
    case subject.confusion_level
    when 1
      opponents_unit.random_target
    when 2
      random_target_without_self
    else
      friends_random_target_without_self
    end
  end
  #Game_Unit under processing
  #--------------------------------------------------------------------------
  # ● Random Targets Determined
  #--------------------------------------------------------------------------
  def random_target_without_self
    o = opponents_unit
    f = friends_unit
    s = subject
   
    tgr_rand = rand * (o.tgr_sum + f.tgr_sum - s.tgr)
    o.alive_members.each do |member|
      tgr_rand -= member.tgr
      return member if tgr_rand < 0
    end
    f.alive_members.each do |member|
      next if member == s
      tgr_rand -= member.tgr
      return member if tgr_rand < 0
    end
    o.alive_members[0]
  end
  #--------------------------------------------------------------------------
  # ● Random Ally Targets Determined
  #--------------------------------------------------------------------------
  def friends_random_target_without_self
    f = friends_unit
    s = subject
   
    tgr_rand = rand * (f.tgr_sum - s.tgr)
    f.alive_members.each do |member|
      next if member == s
      tgr_rand -= member.tgr
      return member if tgr_rand < 0
    end
    f.alive_members[0]
  end
end