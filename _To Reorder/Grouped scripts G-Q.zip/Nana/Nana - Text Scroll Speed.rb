#==============================================================================
#                   「Scrolling Text Speed Control」(ACE) ver1.0
#   Author: Nana
#   Homepage: http://heptanas.mamagoto.com/
#
#   ◇Terms of Use
#   Please credit "Nana."
#   Feel free to modify this script and/or distribute it.
#   Also please include the credit in the readme or somewhere it's accessible. (Not from credit roll)
#   Check the blog for detailed terms of use.
#
#------------------------------------------------------------------------------
#
#   It's possible to set the speed for scrolling text.
#   You can change the speed by pressing a certain key.
#  
#   Please include a numerical value by default.
#
#==============================================================================
#◇Initial Setting
module Nana_STC
 
  SPEED = 1       #Normal scroll speed, default = 1
 
  A_SPEED = 2     #Scroll speed from A button （confirm key） when pressed.
 
  B_SPEED = 1000  #Scroll speed from B button (cancel key) when pressed.
 
  C_SPEED = 1     #Scroll speed when C button (subkey) is pressed.
 
end
 
#==============================================================================
# ■ Window_ScrollText
#------------------------------------------------------------------------------
# Window used for Scroll Text. Although frames are not displayed-
# It's treated as a window for convenience.
#==============================================================================
 
class Window_ScrollText < Window_Base
  #--------------------------------------------------------------------------
  # ● Acquired scroll speed
  #--------------------------------------------------------------------------
  def scroll_speed
    $game_message.scroll_speed * show_fast? * 0.5
  end
  #--------------------------------------------------------------------------
  # ● Fast forward control
  #--------------------------------------------------------------------------
  def show_fast?
    return Nana_STC::SPEED if $game_message.scroll_no_fast
    return Nana_STC::A_SPEED if Input.press?(:A)
    return Nana_STC::B_SPEED if Input.press?(:B)
    return Nana_STC::C_SPEED if Input.press?(:C)
    return Nana_STC::SPEED
  end
end