###--------------------------------------------------------------------------###
#  CP Debug Skills script                                                      #
#  Version 1.0                                                                 #
#                                                                              #
#      Credits:                                                                #
#  Original code by: Neon Black                                                #
#  Modified by:                                                                #
#                                                                              #
#  This work is licensed under the Creative Commons Attribution-NonCommercial  #
#  3.0 Unported License. To view a copy of this license, visit                 #
#  http://creativecommons.org/licenses/by-nc/3.0/.                             #
#  Permissions beyond the scope of this license are available at               #
#  http://cphouseset.wordpress.com/liscense-and-terms-of-use/.                 #
#                                                                              #
#      Contact:                                                                #
#  NeonBlack - neonblack23@live.com (e-mail) or "neonblack23" on skype         #
###--------------------------------------------------------------------------###

###--------------------------------------------------------------------------###
#  V1.0 - 11.19.2012                                                           #
#   Released script                                                            #
###--------------------------------------------------------------------------###

###--------------------------------------------------------------------------###
#      Instructions:                                                           #
#  Place this script in the "Materials" section of the scripts above "Main".   #
#  If you are using CP's Dev Console, place this script UNDER that script.     #
#  This script adds a debug scene that allows you to change what skills any    #
#  actor in the database has at a given moment.  To call up this screen,       #
#  either type "debug skill" into the dev console, or access it via the        #
#  script call "SceneManager.call(Scene_DebugSkill)".                          #
###--------------------------------------------------------------------------###


###--------------------------------------------------------------------------###
#  The following lines are the actual core code of the script.  While you are  #
#  certainly invited to look, modifying it may result in undesirable results.  #
#  Modify at your own risk!                                                    #
###--------------------------------------------------------------------------###


$imported = {} if $imported.nil?
$imported["CP_DEBUG_SKILL"] = 1.0

module Console  ## Prepares the console.
  class << self; alias skill_debug_menu_console new_console_commands; end rescue nil
  
  def self.new_console_commands
    skill_debug_menu_console
    new_debug("skill", Scene_DebugSkill)
  end
end

class Scene_DebugSkill < Scene_ItemBase
  def start
    super  ## The basic debug scene.
    create_help_window
    create_hero_window
    create_list_window
    create_skill_window
  end
  
  def create_hero_window
    @hero_window = Window_DSHero.new
    @hero_window.y = @help_window.height
    @hero_window.set_handler(:ok,     method(:on_hero_ok))
    @hero_window.set_handler(:cancel, method(:return_scene))
  end
  
  def create_list_window
    wy = @hero_window.y + @hero_window.height
    wh = Graphics.height - wy
    @list_window = Window_DSList.new(0, wy, Graphics.width / 2, wh)
    @list_window.help_window = @help_window
    @list_window.set_handler(:ok,     method(:on_list_ok))
    @list_window.set_handler(:cancel, method(:on_list_cancel))
    @list_window.set_handler(:toggle, method(:toggle_to_skill))
    @hero_window.list_window = @list_window
  end
  
  def create_skill_window
    wy = @hero_window.y + @hero_window.height
    wh = Graphics.height - wy
    @skill_window = Window_DSSkill.new(Graphics.width / 2, wy, Graphics.width / 2, wh)
    @skill_window.help_window = @help_window
    @skill_window.set_handler(:ok,     method(:on_skill_ok))
    @skill_window.set_handler(:cancel, method(:on_list_cancel))
    @skill_window.set_handler(:toggle, method(:toggle_to_list))
    @hero_window.skill_window = @skill_window
  end
  
  def on_hero_ok
    @list_window.activate.select(0)
  end
  
  def on_list_ok
    @list_window.activate
    $game_actors[hero].learn_skill(@list_window.item.id)
    @list_window.refresh
    @skill_window.refresh
  end
  
  def on_skill_ok
    @skill_window.activate
    $game_actors[hero].forget_skill(@skill_window.item.id)
    @list_window.refresh
    @skill_window.refresh
  end
  
  def toggle_to_skill
    @list_window.save_last
    @skill_window.get_last
  end
  
  def toggle_to_list
    @skill_window.save_last
    @list_window.get_last
  end
  
  def on_list_cancel
    @list_window.unselect
    @skill_window.unselect
    @list_window.oy = 0
    @skill_window.oy = 0
    @hero_window.activate
    @help_window.clear
  end
  
  def hero
    @hero_window.current_symbol
  end
end

class Window_DSHero < Window_Command
  attr_reader   :skill_window
  attr_reader   :list_window
  
  def initialize
    super(0, 0)
  end  ## The list of all actors.
  
  def window_width
    Graphics.width
  end
  
  def col_max
    return 4
  end
  
  def visible_line_number
    return 2
  end
  
  def update
    super
    @skill_window.category = current_symbol if @skill_window
    @list_window.category = current_symbol if @list_window
  end
  
  def make_command_list
    $data_actors.each {|h| next if h.nil?; add_command(h.name, h.id)}
  end
  
  def skill_window=(skill_window)
    @skill_window = skill_window
    update
  end
  
  def list_window=(list_window)
    @list_window = list_window
    update
  end
end

class Window_DSList < Window_Selectable
  def initialize(x, y, width, height)
    super
    @category = 0
    @data = []
    @last = 0
  end
  
  def category=(category)
    return if @category == category
    @category = category
    @last = 0
    refresh
    self.oy = 0
  end
  
  def col_max
    return 1
  end
  
  def item_max
    @data ? @data.size : 1
  end
  
  def item
    @data && index >= 0 ? @data[index] : nil
  end
  
  def make_item_list
    @data = $data_skills[1..-1]
  end
  
  def current_item_enabled?
    !learned?(@index)
  end
  
  def learned?(index)
    $game_actors[@category].skill_learn?(@data[index])
  end
  
  def draw_item(index)
    item = @data[index]
    if item
      rect = item_rect(index)
      rect.width -= 4
      draw_item_name(item, rect.x, rect.y, !learned?(index))
    end
  end
  
  def refresh
    make_item_list
    create_contents
    draw_all_items
  end
  
  def update_help
    @help_window.set_item(item)
  end
  
  def process_cursor_move
    return cursor_right if Input.trigger?(:RIGHT)
    return unless cursor_movable?
    last_index = @index
    cursor_down (Input.trigger?(:DOWN))  if Input.repeat?(:DOWN)
    cursor_up   (Input.trigger?(:UP))    if Input.repeat?(:UP)
    cursor_pagedown   if !handle?(:pagedown) && Input.trigger?(:R)
    cursor_pageup     if !handle?(:pageup)   && Input.trigger?(:L)
    Sound.play_cursor if @index != last_index
  end  ## Toggle left and right switching.
  
  def cursor_right
    return unless active
    call_handler(:toggle)
    Sound.play_cursor
  end
  
  def save_last
    @last = @index
    unselect
    deactivate
  end
  
  def get_last
    select(@last)
    activate
  end
end

class Window_DSSkill < Window_Selectable
  def initialize(x, y, width, height)
    super  ## The list of all skills.
    @category = 0
    @data = []
    @last = 0
  end
  
  def category=(category)
    return if @category == category
    @category = category
    @last = 0
    refresh
    self.oy = 0
  end
  
  def col_max
    return 1
  end
  
  def item_max
    @data ? @data.size : 1
  end
  
  def num
    @data && index >= 0 ? $game_party.item_number(item) : 0
  end
  
  def item
    @data && index >= 0 ? @data[index] : nil
  end
  
  def current_item_enabled?
    learned?(@index)
  end
  
  def make_item_list
    if @category.is_a?(Integer)
      @data = $game_actors[@category].skills
    else
      @data = [nil]
    end
  end
  
  def learned?(index)
    $game_actors[@category].skill_learn?(@data[index])
  end
  
  def draw_item(index)
    item = @data[index]
    if item
      rect = item_rect(index)
      rect.width -= 4
      draw_item_name(item, rect.x, rect.y, learned?(index))
    end
  end
  
  def refresh
    make_item_list
    create_contents
    draw_all_items
  end
  
  def update_help
    @help_window.set_item(item)
  end
  
  def process_cursor_move
    return cursor_left if Input.trigger?(:LEFT)
    return unless cursor_movable?
    last_index = @index
    cursor_down (Input.trigger?(:DOWN))  if Input.repeat?(:DOWN)
    cursor_up   (Input.trigger?(:UP))    if Input.repeat?(:UP)
    cursor_pagedown   if !handle?(:pagedown) && Input.trigger?(:R)
    cursor_pageup     if !handle?(:pageup)   && Input.trigger?(:L)
    Sound.play_cursor if @index != last_index
  end  ## Left and right switching.
  
  def cursor_left
    return unless active
    call_handler(:toggle)
    Sound.play_cursor
  end
  
  def save_last
    @last = @index
    unselect
    deactivate
  end
  
  def get_last
    select(@last)
    activate
  end
end


###--------------------------------------------------------------------------###
#  End of script.                                                              #
###--------------------------------------------------------------------------###