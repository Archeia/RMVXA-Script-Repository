###--------------------------------------------------------------------------###
#  CP Debug Items script                                                       #
#  Version 1.0                                                                 #
#                                                                              #
#      Credits:                                                                #
#  Original code by: Neon Black                                                #
#  Modified by:                                                                #
#                                                                              #
#  This work is licensed under the Creative Commons Attribution-NonCommercial  #
#  3.0 Unported License. To view a copy of this license, visit                 #
#  http://creativecommons.org/licenses/by-nc/3.0/.                             #
#  Permissions beyond the scope of this license are available at               #
#  http://cphouseset.wordpress.com/liscense-and-terms-of-use/.                 #
#                                                                              #
#      Contact:                                                                #
#  NeonBlack - neonblack23@live.com (e-mail) or "neonblack23" on skype         #
###--------------------------------------------------------------------------###

###--------------------------------------------------------------------------###
#  V1.0 - 11.19.2012                                                           #
#   Released script                                                            #
###--------------------------------------------------------------------------###

###--------------------------------------------------------------------------###
#      Instructions:                                                           #
#  Place this script in the "Materials" section of the scripts above "Main".   #
#  If you are using CP's Dev Console, place this script UNDER that script.     #
#  This script adds a debug scene that allows you to change the items in your  #
#  inventory using a relatively simple items screen listing all the items in   #
#  the database.  To call up this screen, either type "debug item" into the    #
#  dev console, or access it via the script call                               #
#  "SceneManager.call(Scene_DebugItem)".                                       #
###--------------------------------------------------------------------------###


###--------------------------------------------------------------------------###
#  The following lines are the actual core code of the script.  While you are  #
#  certainly invited to look, modifying it may result in undesirable results.  #
#  Modify at your own risk!                                                    #
###--------------------------------------------------------------------------###


$imported = {} if $imported.nil?
$imported["CP_DEBUG_ITEM"] = 1.0

module Console  ## Adds the console debug.
  class << self; alias item_debug_menu_console new_console_commands; end rescue nil
  
  def self.new_console_commands
    item_debug_menu_console
    new_debug("item", Scene_DebugItem)
  end
end

class Scene_DebugItem < Scene_ItemBase
  def start  ## The basic debug scene.
    super
    create_help_window
    create_category_window
    create_item_window
    create_number_window
  end
  
  def create_category_window
    @category_window = Window_DICategory.new
    @category_window.y = @help_window.height
    @category_window.set_handler(:ok,     method(:on_category_ok))
    @category_window.set_handler(:cancel, method(:return_scene))
  end
  
  def create_item_window
    wy = @category_window.y + @category_window.height
    wh = Graphics.height - wy
    @item_window = Window_DIList.new(0, wy, Graphics.width, wh)
    @item_window.help_window = @help_window
    @item_window.set_handler(:ok,     method(:on_item_ok))
    @item_window.set_handler(:cancel, method(:on_item_cancel))
    @category_window.item_window = @item_window
  end
  
  def create_number_window
    @number_window = Window_DINumber.new
    @number_window.set_handler(:ok,     method(:on_number_ok))
    @number_window.set_handler(:cancel, method(:on_number_cancel))
    @number_window.hide
  end
  
  def on_category_ok
    @item_window.activate.select(0)
  end
  
  def on_item_ok
    @number_window.num = @item_window.num
    @number_window.show.activate
  end
  
  def on_number_ok
    @item_window.activate
    @number_window.hide
    i = @number_window.num - @item_window.num
    $game_party.gain_item(@item_window.item, i) unless i == 0
    @item_window.redraw_current_item
  end
  
  def on_item_cancel
    @item_window.unselect
    @item_window.oy = 0
    @category_window.activate
    @help_window.clear
  end
  
  def on_number_cancel
    @item_window.activate
    @number_window.hide
  end
end

class Window_DICategory < Window_HorzCommand
  attr_reader   :item_window
  
  def initialize
    super(0, 0)
  end  ## The catagories window.
  
  def window_width
    Graphics.width
  end
  
  def col_max
    return 3
  end
  
  def update
    super
    @item_window.category = current_symbol if @item_window
  end
  
  def make_command_list
    add_command(Vocab::item,   :item)
    add_command(Vocab::weapon, :weapon)
    add_command(Vocab::armor,  :armor)
  end
  
  def item_window=(item_window)
    @item_window = item_window
    update
  end
end

class Window_DIList < Window_Selectable
  def initialize(x, y, width, height)
    super
    @category = :none
    @data = []
  end  ## A list of all items based on the selected catagory.
  
  def category=(category)
    return if @category == category
    @category = category
    refresh
    self.oy = 0
  end
  
  def col_max
    return 2
  end
  
  def item_max
    @data ? @data.size : 1
  end
  
  def num
    @data && index >= 0 ? $game_party.item_number(item) : 0
  end
  
  def item
    @data && index >= 0 ? @data[index] : nil
  end
  
  def make_item_list
    case @category
    when :item
      @data = $data_items[1..-1]
    when :weapon
      @data = $data_weapons[1..-1]
    when :armor
      @data = $data_armors[1..-1]
    else
      @data = [nil]
    end
  end
  
  def draw_item(index)
    item = @data[index]
    if item
      rect = item_rect(index)
      rect.width -= 4
      draw_item_name(item, rect.x, rect.y)
      draw_item_number(rect, item)
    end
  end
  
  def draw_item_number(rect, item)
    draw_text(rect, sprintf(":%2d", $game_party.item_number(item)), 2)
  end
  
  def update_help
    @help_window.set_item(item)
  end
  
  def refresh
    make_item_list
    create_contents
    draw_all_items
  end
end

class Window_DINumber < Window_Selectable
  def initialize
    w = 180; x = (Graphics.width - w) / 2
    h = fitting_height(3); y = (Graphics.height - h) / 2
    super(x, y, w, h)
    self.back_opacity = 255
  end  ## The window used to add or remove items.
  
  def num
    return @num
  end
  
  def num=(i)
    @num = i; @old_num = i
  end
  
  def num_min
    0
  end
  
  def num_max
    9999
  end  ## The max number of an item you can have via the script.
  
  def update
    super
    process_digit_change
    process_handling
    update_cursor
  end
  
  def refresh
    contents.clear
    draw_text(2, line_height * 0.5, contents.width - 4, line_height, "New total:", 1)
    draw_text(2, line_height * 1.5, contents.width - 4, line_height, @num, 1)
  end
  
  def process_digit_change
    return unless active
    case Input.dir4
    when 2
      @num -= 1  if Input.repeat?(:DOWN)
      @type = false
    when 4
      @num -= 10 if Input.repeat?(:LEFT)
      @type = false
    when 6
      @num += 10 if Input.repeat?(:RIGHT)
      @type = false
    when 8
      @num += 1  if Input.repeat?(:UP)
      @type = false
    end
    
    if number_press?
      if @type
        @num = (@num * 10) + num_key
      else
        @type = true
        @num = num_key
      end
    end
    @num = [[@num, num_min].max, num_max].min
    if @old_num != @num
      Sound.play_cursor
      @old_num = @num
      refresh
    end
  end
  
  def number_press?
    return [0, 1, 2, 3, 4, 5, 6, 7, 8, 9].include?(num_key)
  end  ## The keyboard section of CP's keyboard is installed..
  
  def num_key
    return 0 if Input.trigger?(:k0)
    return 1 if Input.trigger?(:k1)
    return 2 if Input.trigger?(:k2)
    return 3 if Input.trigger?(:k3)
    return 4 if Input.trigger?(:k4)
    return 5 if Input.trigger?(:k5)
    return 6 if Input.trigger?(:k6)
    return 7 if Input.trigger?(:k7)
    return 8 if Input.trigger?(:k8)
    return 9 if Input.trigger?(:k9)
    return nil
  end
  
  def process_handling
    return unless active
    return process_ok     if Input.trigger?(:C)
    return process_cancel if Input.trigger?(:B)
  end
  
  def update_cursor
    ci = (contents.width - 64) / 2
    rect = Rect.new(ci, line_height * 1.5, contents.width - ci * 2, line_height)
    cursor_rect.set(rect)
  end
  
  def show
    @type = false
    refresh
    super
  end
end


###--------------------------------------------------------------------------###
#  End of script.                                                              #
###--------------------------------------------------------------------------###