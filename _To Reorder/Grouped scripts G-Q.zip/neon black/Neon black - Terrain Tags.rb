###--------------------------------------------------------------------------###
#  CP Terrain Tags script                                                      #
#  Version 1.2                                                                 #
#                                                                              #
#      Credits:                                                                #
#  Original code by: Neon Black                                                #
#  Modified by:                                                                #
#                                                                              #
#  This work is licensed under the Creative Commons Attribution-NonCommercial  #
#  3.0 Unported License. To view a copy of this license, visit                 #
#  http://creativecommons.org/licenses/by-nc/3.0/.                             #
#  Permissions beyond the scope of this license are available at               #
#  http://cphouseset.wordpress.com/liscense-and-terms-of-use/.                 #
#                                                                              #
#      Contact:                                                                #
#  NeonBlack - neonblack23@live.com (e-mail) or "neonblack23" on skype         #
###--------------------------------------------------------------------------###

###--------------------------------------------------------------------------###
#      Revision information:                                                   #
#  V1.2 - 12.22.2012                                                           #
#   Fixed an issue related to loading a saved game                             #
#  V1.1 - 12.3.2012                                                            #
#   Rewrote passage checking                                                   #
#   Fixed various passability issues                                           #
#  V1.0 - 11.30.2012                                                           #
#   Wrote and debugged main script                                             #
###--------------------------------------------------------------------------###

###--------------------------------------------------------------------------###
#      Compatibility:                                                          #
#  Alias       - Game_CharacterBase: passable?                                 #
#                Game_Player: moveto                                           #
#                Game_Follower: chase_preceding_character                      #
#                Game_Map: setup,                                              #
#                Scene_Load: on_load_success                                   #
#  Overwrites  - Game_Player: move_by_input                                    #
#                Game_Map: check_passage                                       #
#  New Objects - Game_CharacterBase: move_slope, slope_passable?               #
#                Game_Player: move_modif_direction, move_slope                 #
#                Game_Map: reset_map, init_fold, init_setup, add_tile_id,      #
#                          bridge_flip, bridge?                                #
###--------------------------------------------------------------------------###

###--------------------------------------------------------------------------###
#      Instructions:                                                           #
#  Place this script in the "Materials" section of the scripts above main.     #
#  This script allows tiles on a map to be tagged using regions to change the  #
#  properties of those tiles.  This includes slopes, cover, blockers, and      #
#  bridges.  Each terrain type is detailed with each config option below.      #
###--------------------------------------------------------------------------###

###--------------------------------------------------------------------------###
#      Config:                                                                 #
#  This is the config section of the script.  This script is split into a few  #
#  parts to make using it a little easier.  You may change these values to     #
#  fit your liking.                                                            #
#                                                                              #
module CP      # Do not edit                                                   #
module TERRAIN #  these lines.                                                 #
#                                                                              #
###-----                                                                -----###
#      Slope Options:                                                          #
# Slope terrains cause the player to move diagonally while walking over them,  #
# much like a horizontal stair case.  This only affects horizontal movement    #
# and has no effect on vertical movement.  As a general rule of thumb, all     #
# stair tiles must be marked with these tags even if they cannot be walked on. #
# Also, both slopes do not work if the bottom edges are touching, so avoid     #
# creating maps where this happens.  Note that events are no affected by these #
# tags, only player and followers are.                                         #
#                                                                              #
# Region tag for a slope with a shape like \.                                  #
DOWN_RIGHT = 16 # Default = 16                                                 #
#                                                                              #
# Region tag for a slope with a shape like /.                                  #
DOWN_LEFT  = 17 # Default = 17                                                 #
#                                                                              #
###-----                                                                -----###
#      Cover Options:                                                          #
# This affects cover and blocking region tags.  Cover tags cause the tile      #
# tagged to appear above characters and events.  Block tags cause the tagged   #
# tile to become impassible.  Because auto tiles have odd passage settings on  #
# inside tiles, it is recommended to use these tags on edges of cover tiles.   #
#                                                                              #
# The region tag for cover tiles.                                              #
COVER = 18 # Default = 18                                                      #
#                                                                              #
# The region id to use for block tiles.                                        #
BLOCK = 19 # Default = 19                                                      #
#                                                                              #
###-----                                                                -----###
#      Bridge Options:                                                         #
# This affects bridge and catwalk type tiles.  Bridges use tileset A while     #
# catwalks use tilesets B-E.  Bridges flip when the player steps onto a region #
# tagged as a lower or upper tile.  To prevent bugs, a player can only step    #
# from a bridge or catwalk tile onto another bridge or catwalk tile or a       #
# lower/upper region of the same type.  Also note that bridges use the CLEAR   #
# tile from above for when the bridge is flipped to lower.  Events also do NOT #
# function properly with bridges, so avoid having events on bridges.           #
#                                                                              #
# The region IDs to use for bridges and catwalks.                              #
BRIDGE = 20 # Default = 20                                                     #
CATWALK = 21 # Default = 21                                                    #
#                                                                              #
# The region tags for the upper and lower enterances of the bridge.            #
LOWER = 22 # Default = 22                                                      #
UPPER = 23 # Default = 23                                                      #
###--------------------------------------------------------------------------###


###--------------------------------------------------------------------------###
#  The following lines are the actual core code of the script.  While you are  #
#  certainly invited to look, modifying it may result in undesirable results.  #
#  Modify at your own risk!                                                    #
###--------------------------------------------------------------------------###


end
end

$imported = {} if $imported.nil?
$imported["CP_TERRAIN"] = 1.1

class Game_CharacterBase
  def move_slope(horz, vert)
    @move_succeed = slope_passable?(x, y, horz, vert)
    if @move_succeed
      @x = $game_map.round_x_with_direction(@x, horz)
      @y = $game_map.round_y_with_direction(@y, vert)
      @real_x = $game_map.x_with_direction(@x, reverse_dir(horz))
      @real_y = $game_map.y_with_direction(@y, reverse_dir(vert))
      increase_steps
    end
    set_direction(horz) if @direction == reverse_dir(horz)
    set_direction(vert) if @direction == reverse_dir(vert)
  end
  
  def slope_passable?(x, y, horz, vert)
    x2 = $game_map.round_x_with_direction(x, horz)
    y2 = $game_map.round_y_with_direction(y, vert)
    return false unless $game_map.valid?(x2, y2)
    return true if @through || debug_through?
    return false if collide_with_characters?(x2, y2)
    (map_passable?(x, y, horz) && map_passable?(x2, y2, reverse_dir(vert))) ||
    (map_passable?(x, y, vert) && map_passable?(x2, y2, reverse_dir(horz)))
  end
  
  alias cp_terrain_pass passable?
  def passable?(x, y, d)
    x2 = $game_map.round_x_with_direction(x, d)
    y2 = $game_map.round_y_with_direction(y, d)
    if region_id == CP::TERRAIN::BRIDGE || region_id == CP::TERRAIN::CATWALK
      return true if @through || debug_through?
      sets = [CP::TERRAIN::BRIDGE, CP::TERRAIN::CATWALK]
      $game_map.bridge? ? sets.push(CP::TERRAIN::LOWER) : sets.push(CP::TERRAIN::UPPER)
      return false unless sets.include?($game_map.region_id(x2, y2))
    end
    cp_terrain_pass(x, y, d)
  end
end

class Game_Player < Game_Character
  def move_by_input
    return if !movable? || $game_map.interpreter.running?
    move_modif_direction
  end

  def move_modif_direction
    dir = Input.dir4
    return if dir <= 0
    case dir
    when 4
      if region_id == CP::TERRAIN::DOWN_LEFT
        set_direction(4)
        move_slope(4, 2)
      elsif $game_map.region_id(@x - 1, @y) == CP::TERRAIN::DOWN_RIGHT
        set_direction(4)
        move_slope(4, 8)
      else
        move_straight(dir)
      end
    when 6
      if region_id == CP::TERRAIN::DOWN_RIGHT
        set_direction(6)
        move_slope(6, 2)
      elsif $game_map.region_id(@x + 1, @y) == CP::TERRAIN::DOWN_LEFT
        set_direction(6)
        move_slope(6, 8)
      else
        move_straight(dir)
      end
    else
      move_straight(dir)
    end
    $game_map.bridge_flip(region_id)
  end
  
  def move_slope(horz, vert)
    @followers.move if slope_passable?(@x, @y, horz, vert)
    super
  end
  
  alias cp_fix_moveto moveto
  def moveto(x, y)
    cp_fix_moveto(x, y)
    $game_map.bridge_flip(region_id)
  end
end

class Game_Follower < Game_Character
  alias cp_slopes_chase chase_preceding_character
  def chase_preceding_character
    set_direction(@preceding_character.direction) unless moving?
    cp_slopes_chase
  end
end

class Game_Map
  alias cp_terrain_setup setup
  def setup(map_id)
    init_fold
    cp_terrain_setup(map_id)
    init_setup
  end
  
  def reset_map
    tf = @flip
    init_fold
    @map = load_data(sprintf("Data/Map%03d.rvdata2", @map_id))
    @tileset_id = @map.tileset_id
    init_setup
    id = tf ? CP::TERRAIN::LOWER : CP::TERRAIN::UPPER
    bridge_flip(id)
  end
  
  def init_fold
    @flip = false if @flip.nil?
    return_tiles
  end
  
  def init_setup
    @bridges = []; @catwalks = []; @tile_flag_set = {}
    width.times do |x|
      height.times do |y|
        id = region_id(x, y)
        if id == CP::TERRAIN::BRIDGE || id == CP::TERRAIN::UPPER
          bset = [x, y]
          bset.push(data[x, y, 2])
          bset.push(tileset.flags[data[x, y, 0]])
          @bridges.push(bset)
          add_tile_id(data[x, y, 0])
        end
        if id == CP::TERRAIN::CATWALK
          bset = [x, y]
          bset.push(tileset.flags[data[x, y, 2]])
          @catwalks.push(bset) 
        end
        next unless id == CP::TERRAIN::COVER
        add_tile_id(data[x, y, 0])
        data[x, y, 2] = data[x, y, 0]
        data[x, y, 0] = 0
        tileset.flags[data[x, y, 2]] = 0x10
      end
    end
  end
  
  def add_tile_id(id)
    @tile_flag_set = {} if @tile_flag_set.nil?
    return if @tile_flag_set.include?(id)
    @tile_flag_set[id] = tileset.flags[id]
  end
  
  def check_passage(x, y, bit)
    @tile_flag_set = {} if @tile_flag_set.nil?
    rid = region_id(x, y)
    return false if rid == CP::TERRAIN::BLOCK
    all_tiles(x, y).each do |tile_id|
      if (rid == CP::TERRAIN::BRIDGE && bridge?) ||
         (rid == CP::TERRAIN::COVER && tile_id == 0)
        flag = 0x600
      elsif @tile_flag_set.include?(tile_id) && rid != CP::TERRAIN::COVER
        flag = @tile_flag_set[tile_id]
      else
        flag = tileset.flags[tile_id]
      end
      next if flag & 0x10 != 0            # [☆]: No effect on passage
      return true  if flag & bit == 0     # [○] : Passable
      return false if flag & bit == bit   # [×] : Impassable
    end
    return false                          # Impassable
  end
  
  def bridge_flip(id)
    @flip = false if @flip.nil?
    case id
    when CP::TERRAIN::LOWER
      return if @flip
      @bridges.each do |set|
        x, y = set[0..1]
        data[x, y, 2] = data[x, y, 0]
        data[x, y, 0] = 0
        tileset.flags[data[x, y, 2]] = 0x10
      end
      @catwalks.each do |set|
        x, y = set[0..1]
        tileset.flags[data[x, y, 2]] = 0x10
      end
      @flip = true
    when CP::TERRAIN::UPPER
      return_tiles
    end
  end
  
  def return_tiles
    return if !@flip
    @bridges.each do |set|
      x, y = set[0..1]
      data[x, y, 0] = data[x, y, 2]
      data[x, y, 2] = set[2]
      tileset.flags[data[x, y, 0]] = set[3]
    end
    @catwalks.each do |set|
      x, y = set[0..1]
      tileset.flags[data[x, y, 2]] = set[2]
    end
    @flip = false
  end
  
  def bridge?
    @flip = false if @flip.nil?
    return @flip
  end
end

class Scene_Load < Scene_File
  alias cp_terrain_load on_load_success
  def on_load_success
    $game_map.reset_map
    cp_terrain_load
  end
end


###--------------------------------------------------------------------------###
#  End of script.                                                              #
###--------------------------------------------------------------------------###