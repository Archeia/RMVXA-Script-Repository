###--------------------------------------------------------------------------###
#  CP Basic script                                                             #
#  Version 1.3                                                                 #
#                                                                              #
#      Credits:                                                                #
#  Original code by: Neon Black                                                #
#  Modified by:                                                                #
#                                                                              #
#  This work is licensed under the Creative Commons Attribution-NonCommercial  #
#  3.0 Unported License. To view a copy of this license, visit                 #
#  http://creativecommons.org/licenses/by-nc/3.0/.                             #
#  Permissions beyond the scope of this license are available at               #
#  http://cphouseset.wordpress.com/liscense-and-terms-of-use/.                 #
#                                                                              #
#      Contact:                                                                #
#  NeonBlack - neonblack23@live.com (e-mail) or "neonblack23" on skype         #
###--------------------------------------------------------------------------###

module CP    # Just ignore
module BASIC #  these lines.

###--------------------------------------------------------------------------###
#  Don't edit this willy-nilly.  It's an array used by the script.             #
       REVISIONS                                                              =[
"  V1.3 - 10.26.2012~11.15.2012",
"   Script rewrite and cleanup",
"  V1.2 - 9.8.2012",
"   Simplified adding commands",
"  V1.1 - 8.11.2012",
"   Split the console and keyboard module",
"  V1.0 - 7.22.2012",
"   Removed basic debugs",
"   General cleanup",
"  V0.4 - 7.11.2012",
"   Made the console awesome",
"  V0.3 - 7.10.2012",
"   Rewrote console",
"  V0.2 - 7.9.2012",
"   Added basic debugs",
"  V0.1 - 7.9.2012",
"   Wrote main script",                                                        ]
###--------------------------------------------------------------------------###

###--------------------------------------------------------------------------###
#      Instructions:                                                           #
#  Place this script in the "Materials" section of the scripts above main.     #
#  Note that the keyboard module script is required in order to use this.      #
#  Place this script above as many other custom scripts as possible to assure  #
#  it remains compatible with other scripts.  Also make sure you set the       #
#  settings below to prevent this script from altering your project in any     #
#  undesirable way.                                                            #
#                                                                              #
###-----                                                                -----###
#      Console Usage:                                                          #
#  Because I was annoyed by not having a console, I added one.  This console   #
#  can be brought up at any time by pressing a certain button (tilde by        #
#  default) and can be used to perform certain new functions.  Each of these   #
#  functions have instructions for use by typing "help" and the name of the    #
#  function, for example, "help eval".  The menu is fairly simple and does     #
#  not boast much power, but it can be used to perform short scripts in ruby   #
#  or to save, load, and delete save games.  More functions can be added, all  #
#  you have to do is ASK and I'll see if it is doable.                         #
###-----                                                                -----###
#      Adding Console Commands:                                                #
#  As of version 1.2 console commands can be added easier by scripters.  Note  #
#  that all the following instructions must be done within the "Console"       #
#  module.  First make a new method for your command (make sure it has 3       #
#  arguments) and a method to display the help for your command (with 0        #
#  arguments).  Alias "new_console_commands" like so:                          #
#    class << self; alias :the_alias_name :new_console_commands; end           #
#  Next, create the method self.new_console_commands and call the alias.       #
#  After you've done that, you can add your command.  To do this, use the      #
#  following method:                                                           #
#    new_command("name", :call_command, :help_command)                         #
#  Replace "name" with the name of your new command (all lower case and no     #
#  spaces), replace ":call_command" with the command method and replace        #
#  ":help_command" with the help method.                                       #
#  TIP!:  "push_string('string')" is a useful way to display a line of text    #
#         in the console.  Use it to give the console use information.         #
###--------------------------------------------------------------------------###

###--------------------------------------------------------------------------###
#      Config:                                                                 #
#  These are the default values used by several of the functions in the        #
#  script.  You may change these values as you find your game requires in      #
#  order to give the player a better playing experience based on your game.    #
#                                                                              #
###-----                                                                -----###
#  The following are the settings related to some of the added debugging       #
#  features and other new features.                                            #
#                                                                              #
# The title will be skipped if no save files are detected.  ONLY works in test #
# play mode.                                                                   #
SKIP_TITLE = false # Default = false                                           #
#                                                                              #
# The dialogue placed in the "delete file" window when selecting which file to #
# delete.  By default this action can only be done from the debug menu.        #
DELETE_MSG = "Delete which file?" # Default = "Delete which file?"             #
#                                                                              #
# The developer console settings.  First of all, set the key on the keyboard   #
# used to open the console (tilde by default).  Second, set if it can only be  #
# opened during test play (true) or if it can be opened by normal players      #
# (false).  Finally, set a password for the console.  This can be used to      #
# prevent normal players from having access to it.  Set it to "nil" to remove  #
# the password.                                                                #
CONSOLE = :kTILDE # Default = :kTILDE                                          #
TEST_ONLY = true # Default = true                                              #
PASSWORD = nil # Default = nil                                                 #
#                                                                              #
###--------------------------------------------------------------------------###


###--------------------------------------------------------------------------###
#  The following lines are the actual core code of the script.  While you are  #
#  certainly invited to look, modifying it may result in undesirable results.  #
#  Modify at your own risk!                                                    #
###--------------------------------------------------------------------------###


end
end

$imported = {} if $imported.nil?
$imported["CP_BASIC"] = 1.3

##-----
## Skips the title screen if no save file is found.
##-----
if $TEST and CP::BASIC::SKIP_TITLE
class Scene_Title < Scene_Base
  def start
    super
    SceneManager.clear
    Graphics.freeze
    command_new_game if !DataManager.save_file_exists?
    command_continue if DataManager.save_file_exists?
  end
  
  def command_new_game
    DataManager.setup_new_game
    $game_map.autoplay
    SceneManager.goto(Scene_Map)
  end
  
  def command_continue
    return command_new_game if @load_scene; @load_scene = true
    SceneManager.call(Scene_Load)
  end
  
  def terminate
    super
    SceneManager.snapshot_for_background
  end
end
end

##-----
## The screen used by the console.  Shows the output stuff.
##-----
class Window_Console < Window_Base  
  def initialize(x, y, width, height)
    super  ## Sends the console the screens height and width.
    self.z = 500
    console_window_size
    update_display
  end
  
  def console_window_size
    Console.max_lines = contents.height / line_height - 1
    Console.c_width = contents.width - 2
  end
  
  def update
    super  ## Updates only if the console added stuff.
    update_display if Console.update?
  end
  
  def update_display  ## Used to display the console stuff.
    contents.clear
    lines = contents.height / line_height  ## Max lines displayed (prev. lag).
    display = Console.display.last(lines)  ## Gets the last lines written.
    lines -= display.size
    display.reverse!                       ## Reverses the lines and
    lines.times do; display.push(""); end  ## puts blank ones if the
      display.reverse!                       ## console is empty.
      display.each_with_index do |l, i|
      draw_text(0, i * line_height, contents.width, line_height, l)
    end
    Console.update = false
  end
end

##-----
## The input window used by the console.  Uses the Keyboard module to type.
##-----
class Window_Keyboard < Window_Base
  attr_accessor :string
  attr_accessor :console
  
  def initialize(x, y, width, height, console = nil)
    super(x, y, width, height)
    self.z = 500
    @console = console
    @string = ""
    draw_display
  end

  def update
    super  ## Quite a bit here.  Some commands want the input to wait.
    if open?
      if Console.ex_menu
        process_check if Console.wait
      elsif !Console.hold
        process_keyboard unless Console.wait
        process_send unless Console.wait
        process_end unless Console.wait
        draw_display
      end
    end
  end

  def process_check  ## Used for "press any key" functions.
    Console.do_any_key if Keyboard.press_any_key
  end

  def draw_display  ## Draws the contents currently being typed.
    return if (@display <=> @string) == 0
    @display = @string.dup
    type = Console.lock ? "" : @display  ## These 2 lines hide the password.
    @display.chars {type += '*'} if Console.lock ## -^
    contents.clear
    pre = Console.module ? Console.module + '>' : '>'
    si = contents.text_size(pre).width + 2
    draw_text(0, 0, si, contents.height, pre)  ## Draws an input icon.
    draw_text(si + 1, 0, contents.width - 12, contents.height, type)
    mx = si + contents.text_size(type).width  ## These 2 lines are the cursor.
    cl = normal_color
    if $imported["CP_COLOUR"]
      i = 254 - cl.alpha.to_i
      cl = special_color(i)
      cb = special_color(i, 1)
    else
      cb = Font.default_out_color
    end
    contents.fill_rect(mx, 2, 3, contents.height - 4, cb)
    contents.fill_rect(mx + 1, 3, 1, contents.height - 6, cl)
  end

  def process_keyboard  ## Calls the keyboard typing function.  Don't ask me
    new_string = Keyboard.bittype(@string)  ## about the name....
    if Keyboard.trigger?(:kUP)
      new_string = Console.last_string unless Console.last_string.empty?
    end
    @string = new_string.dup if (@string <=> new_string) != 0
  end
  
  def process_send  ## Checks if the input is being sent to the console.
    return unless Keyboard.trigger?(13)
    return if @string == ""  ## Ignores blank strings.
    #msgbox @string if @console.nil?  ## Using this line later.
    Console.input(@string) #if @console  ## This used to have a use.
    @string = ""
  end

  def process_end
    close_console if Keyboard.trigger?(CP::BASIC::CONSOLE)
  end
  
  def close_console
    @string = ""
    @console.close
    close
  end
end

##-----
## The console scene.  Only has two windows so nothing much here.
##-----
class Scene_Console < Scene_MenuBase
  def start
    super
    @console_window = Window_Console.new(0, 0, Graphics.width,
                                         Graphics.height - 56)
    @keyboard_window = Window_Keyboard.new(0, Graphics.height - 56,
                                           Graphics.width, 56, @console_window)
  end
end

class Scene_Base
  def main
    start
    post_start
    until scene_changing?
      update if !console?  ## Only do console if console is up.
      cp_console_update if console?
    end
    pre_terminate
    terminate
  end
  
  alias cp_basic_start start
  def start
    cp_basic_start
    call_up_console  ## Creates the console.
  end
  
  alias cp_basic_update update
  def update
    cp_basic_update
    update_call_console  ## Updates the console while console is close.
  end
  
  def cp_console_update
    Graphics.update  ## Update while everything is stopped.
    Input.update
    @cb_console_window.update
    @cb_keyboard_window.update
  end
  
  def update_call_console  ## First check test play status.
    go = CP::BASIC::TEST_ONLY ? $TEST : true
    #Console.reset  ## Resets the console and calls the scene.
    return unless $imported["CP_KEYBOARD"]
    open_console if go && Keyboard.trigger?(CP::BASIC::CONSOLE) && !console?
  end
  
  def call_up_console  ## Creates the console windows everywhere.
    @cb_console_window = Window_Console.new(0, 0, Graphics.width,
                                            Graphics.height - 56)
    @cb_keyboard_window = Window_Keyboard.new(0, Graphics.height - 56,
                                              Graphics.width, 56, @cb_console_window)
    @cb_console_window.openness = 0  ## Closes the windows.
    @cb_keyboard_window.openness = 0
  end
  
  def open_console  ## Resets the input window's string and opens the console.
    @cb_keyboard_window.string = ""
    @cb_console_window.open
    @cb_keyboard_window.open
  end
  
  def console?  ## Check if console is open.
    @cb_console_window.open?
    @cb_keyboard_window.open?
  end
  
  def get_vars(var)  ## Gets a window's variables.
    arg = var[0] == '@' ? var : '@' + var
    arg += ".instance_variables"
    res = eval(arg)
    return res
  end
  
  def get_methods(var)  ## Gets a window's methods.
    arg = var[0] == '@' ? var : '@' + var
    arg += ".public_methods(false)"
    res = eval(arg)
    return res
  end
  
  def get_constants(var)  ## Does not actually work, but I keep it here for fun.
    arg = var[0] == '@' ? var : '@' + var
    arg += ".constants"
    res = eval(arg)
    return res
  end
  
  def get_self_variables  ## Checks all variables and if they are windows.
    res = instance_variables  ## Worked on this for 3 hours, everything bugged
    return res                ## out.  Got pissed off and simplified it.
  end
  
  def check_window(win)  ## Checks if stuff is windows.
    arg = win[0] == '@' ? win : '@' + win
    wind = instance_variable_get(arg)
    return wind.is_a?(Window)
  end
  
  def window_peek(win)
    res = []
    arg = win[0] == '@' ? win : '@' + win
    wind = instance_variable_get(arg)
    res.push("x = #{wind.x}")
    res.push("y = #{wind.y}")
    res.push("z = #{wind.z}")
    res.push("width = #{wind.width}")
    res.push("height = #{wind.height}")
    res.push("openness = #{wind.openness}")
    res.push("opacity = #{wind.opacity}")
    res.push("back_opacity = #{wind.back_opacity}")
    res.push("active = #{wind.active}")
    res.push("visible = #{wind.visible}")
    return res
  end
  
  def console_value(win, var, set)  ## Sets a variable.
    if win.nil?
      vari = var[0] == '@' ? var : '@' + var
      eval(vari + " = " + set)
    else
      vari = win[0] == '@' ? win : '@' + win
      wind = instance_variable_get(vari)
      wind.console_value(var, set)
    end
  end
  
  def return_value(win, var)  ## Checks variables.
    if win.nil?
      vari = var[0] == '@' ? var : '@' + var
      result = instance_variable_get(vari)
    else
      vari = win[0] == '@' ? win : '@' + win
      wind = instance_variable_get(vari)
      result = wind.return_value(var)
    end
    return result
  end
  
  def console_window_size
    @cb_console_window.console_window_size if @cb_console_window
  end
end

class Window_Base < Window
  def console_value(var, set)  ## Sets a value.
    vari = var[0] == '@' ? var : '@' + var
    eval(vari + " = " + set)
  end
  
  def return_value(var)  ## Checks values.
    vari = var[0] == '@' ? var : '@' + var
    result = instance_variable_get(vari)
    return result
  end
end

##-----
## A new delete scene.  Works like save and load.
##-----
class Scene_Delete < Scene_File
  def help_window_text
    CP::BASIC::DELETE_MSG
  end
  
  def first_savefile_index
    DataManager.last_savefile_index
  end
  
  def on_savefile_ok
    super
    if DataManager.delete_save_file(@index)
      on_delete_success
    else
      Sound.play_buzzer
    end
  end
  
  def on_delete_success
    Sound.play_escape
    return_scene
  end
end

##-----
## The console.  This is the console system that runs in the background and has
## no GUI.  This allows it to run free from from any scenes.
##-----
module Console
  def self.lock; return @lock; end
  def self.wait; return @wait; end
  def self.hold; return @hold; end
  def self.module; return @module; end
  def self.update?; return @update; end
  def self.update=(c); @update = c; end
  
  @display = []
  def self.display; return @display; end
  
  def self.password_string
    return "Please enter the console password."
  end
  
  def self.unlocked_string
    return "Type \"help\" for info or \"commands\" for commands."
  end
    
  def self.ex_menu; return @ex_menu; end
  def self.max_lines=(c); @max_lines = c; end
  def self.c_width=(c); @c_width = c; end
  
  def self.reset
    @lock = CP::BASIC::PASSWORD.nil? ? false : true
    @wait = false
    @hold = false
    @module = nil
    @display = []
    push_string("CP Console v#{$imported["CP_BASIC"]}")
    push_string(password_string) if @lock
    push_string(unlocked_string) if !@lock
    @ex_menu = nil
    @eval = ""
    @last_string = ""
    @imported_line = 0
    @max_lines = 8
    @c_width = Graphics.width - 24
    SceneManager.scene.console_window_size if SceneManager.scene
    @update = true
  end
  
  def self.push_string(string)
    puts string
    @display.push(string)
    @display = @display.last(50) if @display.size > 50
    @update = true
  end
  
  def self.push_space
    push_string(" ")
  end
  
  def self.push_list(list = nil, string = nil)
    @list = list unless list.nil?
    @imp_line = 0 if @list_res.nil?
    @list_res = string ? string : "" unless !@list_res.nil?
    @ex_menu = :list
    did = 0
    push_space
    for i in [@imp_line, 0].max...[@max_lines + @imp_line, @list.size].min
      did += 1
      push_string("#{@list[i]}")
    end
    @imp_line += did
    if @imp_line >= @list.size
      push_string(@list_res) unless @list_res == ""
      @list_res = nil
      pause_end
    else
      pause
    end
  end
  
  def self.pause
    push_string("Press any key to continue....")
    @wait = true
    @ex_menu = :pause if @ex_menu.nil?
  end
  
  def self.pause_end
    push_space
    @wait = false
    @ex_menu = nil
  end
  
  def self.push_wrap_string(string)
    if string.is_a?(Array) || string.is_a?(Hash)
      full_string = ""
      string.each do |comm, v|
        full_string += comm + ", "
      end
      full_string.chop!.chop! unless full_string == ""
      string = full_string
    end
    return unless string.is_a?(String)
    bit = Bitmap.new(@c_width, 100)
    line = ""
    string.split(/ /).each do |word|
      if (bit.text_size(word).width + bit.text_size(line).width +
          bit.text_size(" ").width) <= bit.width - 2
        line += word + " "
      else
        push_string(line)
        line = ""
        line += word + " "
      end
    end
    push_string(line)
  end
  
  reset ## Resets the console on first run.
  
  def self.last_string; return @last_string; end
  
  def self.input(text)
    @last_string = text
    @hold = true
    if @lock
      type = ""
      text.chars {type += '*'}
      push_string('>' + type)
      check_password(text)
    else
      case text
      when /[ ]*(\w+)[ ]*(.*)/i
        push_string('>' + text)
        com = $1.to_s
        args = $2.to_s
        check_input(com.downcase, args)
      end
    end
    @hold = false
  end
  
  def self.check_password(string)
    if string == CP::BASIC::PASSWORD
      @lock = false
      push_string("Password correct.  Console unlocked.")
      push_string("Type \"help\" for info or \"commands\" for commands.")
    else
      push_string("Incorrect password.")
      push_string(password_string)
    end
  end
  
  def self.check_input(string, args)
    text = string.dup
    text.chop! if commands(string) == 2
    return bad_command if commands(text) == 0
    return do_command(text.downcase, args) if @wholestring.include?(text.downcase)
    arguments = args.split(' ')
    arguments = nil if arguments.empty?
    do_command(text.downcase, arguments)
  end
  
  def self.bad_command
    push_string("Command not recognized.")
    push_string("Type \"commands\" for a list of commands.")
  end
  
  def self.commands(com)
    return 0 if @commands.nil?
    return 1 if @commands.include?(com.downcase)
    return 2 if (com[-1].downcase == 's' && @commands.include?(com.chop))
    return 0
  end
  
  def self.do_command(com, args)
    return unless @commands
    @commands[com][0].call(*args) unless @commands[com].nil?
  end
  
  def self.do_any_key
    @hold = true
    push_list if @ex_menu == :list
    pause_end if @ex_menu == :pause
    any_end
  end
  
  def self.update
    return if Keyboard.trigger?(13) || @wait
    do_wait_menu
  end
  
  def self.show_list(*args)
    push_list(*args)
  end
  
  def self.any_end
    @hold = false
  end
  
  def self.do_wait_menu
    @debug_scenes = {} if @debug_scenes.nil?
    SceneManager.call(@debug_scenes[@ex_menu]) if @debug_scenes.include?(@ex_menu)
    if @ex_menu == :eval
      begin
        str = eval(@eval)
        push_string(str.to_s) rescue nil
        push_string("Script evaluation successful.")
      rescue
        push_string("Invalid argument.  Type \"help eval\" for info.")
      end
    end
    wait_end
  end
  
  def self.wait_end
    @ex_menu = nil
  end
  
  def self.do_version(*args)
    push_space
    push_string("Running CP Basic Developer Console")
    push_string("Latest version:#{CP::BASIC::REVISIONS[0]}")
    push_space
    push_string("Created by Neon Black for your enjoyment.")
    push_string("Type \"help\" for info or \"commands\" for commands.")
    push_space
  end
  
  def self.do_help(*arg)
    arg[0] = "help" if (arg[0].nil? || arg[0] == "")
    return unless @commands
    return help_fail unless @commands.include?(arg[0].downcase)
    @commands[arg[0].downcase][1].call unless @commands[arg[0].downcase].nil?
  end
  
  def self.help_fail
    push_string("Invalid command.")
    push_string("Type \"command\" for a list of commands.")
  end
  
  def self.do_commands(*arg)
    @commands = {} if @commands.nil?
    push_space
    push_string("These are the available commands:")
    push_wrap_string(@commands)
    push_space
    push_string("Type \"help [command]\" for more info on a command.")
  end
  
  def self.do_imported(*arg)
    vers = []
    $imported.each do |v|; vers.push(v); end
    i = vers.size
    str = i.to_s + " script(s) found."
    push_list(vers, str)
  end
  
  def self.do_revision(*arg)
    revs = []
    CP::BASIC::REVISIONS.each do |v|; revs.push(v); end
    push_list(revs)
  end
  
  def self.do_eval(*arg)
    @ex_menu = :eval
    @eval = arg[0]
  end
  
  def self.do_debug(*arg)
    @debug_scenes = {} if @debug_scenes.nil?
    return @ex_menu = arg[0] if @debug_scenes.include?(arg[0])
    push_string("Debug scene not installed or defined.")
    push_string("Type \"help debug\" for a list of debug tools.")
  end
  
  def self.do_exit(*arg)
    exit
  end
  
  def self.do_lock(*arg)
    unless CP::BASIC::PASSWORD.nil?
      push_string("The console has been locked.")
      push_string(password_string)
      @lock = true
    else
      push_string("No password assigned.")
      push_string("Please assign a password in the script.")
    end
  end
  
  def self.do_reset(*arg)
    reset
  end
  
  def self.do_variable(*arg)
    begin
      if !@module.nil?
        if @module[0] == '@'
          vars = SceneManager.scene.get_vars(@module) 
        else
          vars = eval(@module + ".instance_variables")
        end
      elsif (arg[0].nil?) || (arg[0] == "")
        vars = SceneManager.scene.get_self_variables
      else
        vars = SceneManager.scene.get_vars(arg[0]) 
      end
      i = vars.size
      res = i.to_s + " variable(s) found."
      push_list(vars, res)
    rescue
      scene_error
    end
  end
  
  def self.do_method(*arg)
    begin
      if !@module.nil?
        if @module[0] == '@'
          vars = SceneManager.scene.get_methods(@module)
        else
          vars = eval(@module + ".singleton_methods(false)")
        end
      elsif (arg[0].nil?) || (arg[0] == "")
        vars = SceneManager.scene.public_methods(false)
      else
        vars = SceneManager.scene.get_methods(arg[0])
      end
      i = vars.size
      res = i.to_s + " method(s) found."
      push_list(vars, res)
    rescue
      scene_error
    end
  end
  
  def self.do_constant(*arg)
    begin
      if (arg[0].nil?) || (arg[0] == "")
        vars = eval(@module + ".constants")
        front = @module.nil? ? "" : @module + "::"
      else
        vars = eval(arg[0] + ".constants")
        front = arg + "::"
      end
      md = 0
      vars.each_with_index do |v, i|
        ch = eval(front + v.to_s + ".is_a?(Module)") rescue ch = false
        vars[i] = ch ? "::" + v.to_s : v.to_s
        md += 1 if ch
      end
      i = vars.size - md
      res = i.to_s + " constant(s) and " + md.to_s + " module(s) found."
      push_list(vars, res)
    rescue
      scene_error
    end
  end
  
  def self.scene_error
    push_string("An error occured while trying to retrieve the list.")
    push_string("Please check the command and try again.")
  end
  
  def self.do_module(*arg)
    if (arg[0].nil?) || arg[0] == ""
      @module = nil
      push_string("Module has been reset.")
    else
      unless @module.nil?
        @module = nil if @module[0] == '@'
      end
      arg[0] = arg[0][2..-1] if arg[0][0..1] == '::'
      check1 = eval(@module + '::' + arg + ".is_a?(Module)") rescue check1 = false
      check2 = eval(arg[0] + ".is_a?(Module)") rescue check2 = false
      if check1
        @module = @module + '::' + arg[0]
        push_string("Current module set to #{@module}.")
      elsif check2
        @module = arg[0]
        push_string("Current module set to #{@module}.")
      else
        push_string("Module #{arg[0]} does not exist.")
      end
    end
  end
  
  def self.do_window(*arg)
    if arg[0].nil? || arg[0] == ""
      @module = nil
      push_string("Window has been reset.")
    else
      check = SceneManager.scene.check_window(arg[0])
      if check
        @module = arg[0][0] == '@' ? arg[0] : '@' + arg[0]
        push_string("Current window set to #{@module}.")
      else
        push_string("Window #{arg[0]} does not exist within this scene.")
      end
    end
  end
  
  def self.do_make(*arg)
    begin
      var = nil
      if !arg[0].include?('.')
        var = @module[0] == '@' ? @module : nil if @module
        fro = arg[0]
        sst = arg[1]
      else
        word = arg[0].split('.')
        var = word[0]
        fro = word[1]
        sst = arg[1]
      end
      SceneManager.scene.console_value(var, fro, sst)
      push_string("New value has been set.")
    rescue
      set_failed
    end
  end
  
  def self.set_failed
    push_string("An error occured trying to set the value.")
    push_string("Please check the command and try again.")
  end
  
  def self.do_get(*arg)
    begin
      if arg[1].nil?
        var = @module[0] == '@' ? @module : nil if @module
        fro = arg[0]
      else
        var = arg[0]
        fro = arg[1]
      end
      value = SceneManager.scene.return_value(var, fro)
      value = "nil" if value.nil?
      push_string(value)
    rescue
      get_failed
    end
  end
  
  def self.get_failed
    push_string("An error occured trying to retrieve the value.")
    push_string("Please check the command and try again.")
  end
  
  def self.do_peek(*arg)
    res = nil
    if (arg[0].nil?) || arg[0] == ""
      return peek_failed if @module.nil?
      if @module[0] == '@'
        res = SceneManager.scene.window_peek(@module)
      else
        peek_failed
      end
    else
      check = SceneManager.scene.check_window(arg[0])
      if check
        res = SceneManager.scene.window_peek(arg[0])
      else
        peek_failed
      end
    end
    push_list(res) unless res.nil?
  end
  
  def self.do_bitsize(*arg)
    temp = Bitmap.new(Graphics.width, Graphics.height)
    push_string("The text is #{temp.text_size(arg[0]).width} pixels wide.")
  end
  
  def self.peek_failed
    push_string("An error occured while trying to check the window.")
    push_string("Please check the command and try again.")
  end
  
  def self.help_version
    push_string("Displays console version information.")
  end
  
  def self.help_help
    push_string("Displays help on a command.")
    push_string("Usage: \"help [command]\"")
    push_string("Usage: \"help\"")
  end
    
  def self.help_commands
    push_string("Displays a list of available commands")
  end
  
  def self.help_imported
    push_string("Displays a list of scripts that use \"$imported\".")
    push_string("Also displays version number of \"CP\" scripts.")
  end
  
  def self.help_revision
    push_string("Displays revision information on the script.")
  end
  
  def self.help_eval
    push_string("Evaluates and performs a ruby script.")
    push_string("Usage: \"eval \'script\'\"")
  end
  
  def self.help_debug
    push_string("Opens an applied debug menu.")
    push_string("These are the currently applied debug menus:")
    @debug_scenes = {} if @debug_scenes.nil?
    push_wrap_string(@debug_scenes)
  end
  
  def self.help_exit
    push_string("Forces the game to exit.")
  end
  
  def self.help_lock
    push_string("Locks the console.")
  end
  
  def self.help_reset
    push_string("Restores the console to it's default state.")
  end
  
  def self.help_variable
    push_string("Get a list of variables assigned to the current")
    push_string("scene, a window within it, or the current module or")
    push_string("window.")
    push_string("Usage: \"variable \'window\'\"")
    push_string("       \"variable\"")
  end
  
  def self.help_method
    push_string("Get a list of methods belonging to the current")
    push_string("scene, a window within it, or the current module or")
    push_string("window.")
    push_string("Usage: \"method \'window\'\"")
    push_string("       \"method\"")
  end
  
  def self.help_constant
    push_string("Get a list of constants and modules belonging to")
    push_string("the current current module or a defined one.")
    push_string("Usage: \"constant \'module\'\"")
    push_string("       \"constant\"")
  end
  
  def self.help_module
    push_string("Prepares a module for use in place of the current")
    push_string("scene.  Use this method with no arguments to clear")
    push_string("the current module.")
    push_string("Usage: \"module \'name\'\"")
    push_string("       \"module\"")
  end
  
  def self.help_window
    push_string("Prepares a window within the scene for use in place")
    push_string("of the current scene.  Use this method with no")
    push_string("arguments to clear the current window.")
    push_string("Usage: \"window \'name\'\"")
    push_string("       \"window\"")
  end
  
  def self.help_make
    push_string("Change the value of a variable within the current")
    push_string("scene or window, or a set window.")
    push_string("Usage: \"make \'variable\' \'value\'\"")
    push_string("       \"make \'window.variable\' \'value\'\"")
  end
  
  def self.help_get
    push_string("Gets the value of a variable within the current")
    push_string("scene or window, or a set window.")
    push_string("Usage: \"get \'variable\'\"")
    push_string("       \"get \'window.variable\'\"")
  end
  
  def self.help_peek
    push_string("Checks certain aspects of a window in the scene or")
    push_string("the current window.")
    push_string("Usage: \"peek \'window\'\"")
    push_string("       \"peek\"")
  end
  
  def self.help_bitsize
    push_string("Checks the length of the following typed string.")
    push_string("Usage: \"bittype \'string\'\"")
  end
  
  def self.new_command(com, com_do, com_help, wholestring = false)
    @commands = {} if @commands.nil?
    @wholestring = [] if @wholestring.nil?
    return if @commands.include?(com)
    @commands[com.downcase] = [method(com_do), method(com_help)]
    @wholestring.push(com.downcase) if wholestring
  end
  
  def self.new_debug(name, scene)
    @debug_scenes = {} if @debug_scenes.nil?
    @debug_scenes[name] = scene
  end
  
  def self.make_console_commands
    new_command("version",  :do_version,  :help_version)
    new_command("help",     :do_help,     :help_help)
    new_command("command",  :do_commands, :help_commands)
    new_command("imported", :do_imported, :help_imported)
    new_command("revision", :do_revision, :help_revision)
    new_command("eval",     :do_eval,     :help_eval, true)
    new_command("debug",    :do_debug,    :help_debug)
    new_command("exit",     :do_exit,     :help_exit)
    new_command("lock",     :do_lock,     :help_lock)
    new_command("reset",    :do_reset,    :help_reset)
    new_command("variable", :do_variable, :help_variable)
    new_command("method",   :do_method,   :help_method)
    new_command("constant", :do_constant, :help_constant)
    new_command("module",   :do_module,   :help_module)
    new_command("window",   :do_window,   :help_window)
    new_command("make",     :do_make,     :help_make)
    new_command("get",      :do_get,      :help_get)
    new_command("peek",     :do_peek,     :help_peek)
    new_command("bitsize",  :do_bitsize,  :help_bitsize, true)
    new_debug("variable", Scene_Debug)
    new_debug("switch",   Scene_Debug)
    new_debug("save",     Scene_Save)
    new_debug("load",     Scene_Load)
    new_debug("delete",   Scene_Delete)
    new_console_commands
  end
  
  def self.new_console_commands
  end
end

module DataManager
  class << self; alias cp_console_init init; end
  def self.init
    cp_console_init
    Console.make_console_commands
  end
end

module Graphics
  class << self; alias cp_console_update update; end
  def self.update
    cp_console_update
    Console.update
  end
end


###--------------------------------------------------------------------------###
#  End of script.                                                              #
###--------------------------------------------------------------------------###