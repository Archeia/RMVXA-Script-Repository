################################################################################
# Made by mobychan, slightly edited by Bird Eater.
# Give mobychan the cookies.
# http://forums.rpgmakerweb.com/index.php?/topic/3463-mss-text-se/
#
#
# INSTRUCTIONS:
# Place above 'Main' in the scripts section but below 'Materials'.
# Change things in module TSE to your liking to vary the sound, pitch and volume
# of the SE played. These correspond with the value VARIABLE 5 has. Make sure
# variable 5 has a value between 1 and 7. HAVE FUN.
#
# So if variable 5 is equal to 5,
# SE5 will be played
# Pitch5 will be used
# With a volume of Volume5
################################################################################
module TSE

# The name of the file that will be played, must be placed in Audio/SE
# CHANGE THESE TO ALTHER THE SOUND PLAYED DURING THE MESSAGE
SE1 = "Cursor1"
SE2 = "Cursor1"
SE3 = "Cursor1"
SE4 = "Cursor1"
SE5 = "Cursor1"
SE6 = "Cursor1"
SE7 = "Knock"
SE8 = "Blow1"
SE9 = "Cursor2"
SE10 = "Cursor2"

# The pitch range of the file being played, change them however you like
# [start_pitch, end_pitch]
# start and end pitch can be the same to have a static pitch
# CHANGE THESE TO ALTER THE DIFFERENT PITCHES!
Pitch1 = [50, 30]
Pitch2 = [70, 90]
Pitch3 = [90, 110]
Pitch4 = [120, 130]
Pitch5 = [130, 140]
Pitch6 = [140, 150]
Pitch7 = [70, 80]
Pitch8 = [90, 100]
Pitch9 = [80, 90]
Pitch10 = [50, 60]

# The volume of the file being played
Volume1 = 90
Volume2 = 100
Volume3 = 100
Volume4 = 100
Volume5 = 100
Volume6 = 100
Volume7 = 80
Volume8 = 110
Volume9 = 110
Volume10 = 110

# The interval at which the sound is being played, every x characters
Interval = 4
end
#==============================================================================
# ** Sound
#==============================================================================
module Sound
# System Sound Effect
def self.play_text_se
#puts $game_variables[5]
if $game_variables[115] == 1
	 file = "Audio/SE/" + TSE::SE1
	 pitch = rand(TSE::Pitch1[1] - TSE::Pitch1[0]) + TSE::Pitch1[0]
	 Audio.se_play(file, TSE::Volume1, pitch)
elsif $game_variables[115] == 2
	 file = "Audio/SE/" + TSE::SE2
	 pitch = rand(TSE::Pitch2[1] - TSE::Pitch2[0]) + TSE::Pitch2[0]
	 Audio.se_play(file, TSE::Volume2, pitch)
elsif $game_variables[115] == 3
	 file = "Audio/SE/" + TSE::SE3
	 pitch = rand(TSE::Pitch3[1] - TSE::Pitch3[0]) + TSE::Pitch3[0]
	 Audio.se_play(file, TSE::Volume3, pitch)
elsif $game_variables[115] == 4
	 file = "Audio/SE/" + TSE::SE4
	 pitch = rand(TSE::Pitch4[1] - TSE::Pitch4[0]) + TSE::Pitch4[0]
	 Audio.se_play(file, TSE::Volume4, pitch)
elsif $game_variables[115] == 5
	 file = "Audio/SE/" + TSE::SE5
	 pitch = rand(TSE::Pitch5[1] - TSE::Pitch5[0]) + TSE::Pitch5[0]
	 Audio.se_play(file, TSE::Volume5, pitch)
elsif $game_variables[115] == 6
	 file = "Audio/SE/" + TSE::SE6
	 pitch = rand(TSE::Pitch6[1] - TSE::Pitch6[0]) + TSE::Pitch6[0]
	 Audio.se_play(file, TSE::Volume6, pitch)
elsif $game_variables[115] == 7
	 file = "Audio/SE/" + TSE::SE7
	 pitch = rand(TSE::Pitch7[1] - TSE::Pitch7[0]) + TSE::Pitch7[0]
	 Audio.se_play(file, TSE::Volume7, pitch)
elsif $game_variables[115] == 8
	 file = "Audio/SE/" + TSE::SE8
	 pitch = rand(TSE::Pitch8[1] - TSE::Pitch8[0]) + TSE::Pitch8[0]
	 Audio.se_play(file, TSE::Volume8, pitch)
elsif $game_variables[115] == 9
	 file = "Audio/SE/" + TSE::SE9
	 pitch = rand(TSE::Pitch9[1] - TSE::Pitch9[0]) + TSE::Pitch9[0]
	 Audio.se_play(file, TSE::Volume9, pitch)
elsif $game_variables[115] == 10
	 file = "Audio/SE/" + TSE::SE10
	 pitch = rand(TSE::Pitch10[1] - TSE::Pitch10[0]) + TSE::Pitch10[0]
	 Audio.se_play(file, TSE::Volume10, pitch)
else
	 #puts "Your variable number 9 isn't 1-7, change it!"
end
end
end
#==============================================================================
# ** Window_Message
#==============================================================================
class Window_Message < Window_Base
#--------------------------------------------------------------------------
# * Object Initialization
#--------------------------------------------------------------------------
alias tse_init initialize unless $@
def initialize
	 tse_init
	 @character = 0
end
#--------------------------------------------------------------------------
# * Normal Character Processing
#--------------------------------------------------------------------------
alias tse_process_normal_character process_normal_character unless $@
def process_normal_character(c, pos)
	 tse_process_normal_character(c, pos)
	 Sound.play_text_se if @character % TSE::Interval == 0 && !@line_show_fast
	 #p @character if @character % TSE::Interval == 0 && !@line_show_fast
	 @character += 1
end
alias tse_process_new_page process_new_page unless $@
#--------------------------------------------------------------------------
# * New Page Character Processing
#--------------------------------------------------------------------------
def process_new_page(text, pos)
	 tse_process_new_page(text, pos)
	 @character = 0
end
end