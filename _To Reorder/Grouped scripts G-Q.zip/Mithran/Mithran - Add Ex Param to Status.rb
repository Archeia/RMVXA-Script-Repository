# add xparams to equip status window
# example script by Mithran at forums.rpgmakerweb.com
# Terms of Use: use as you see fit (learn, edit, repost, commercial allowed)
module Vocab
  XPARAM = # xparam terms
  ["HIT", # 0 HIT  HIT rate
  "EVA", # 1 EVA  EVAsion rate
  "CRI",# 2 CRI  CRItical rate
  "CEV", # 3 CEV  Critical EVasion rate
  "MEV",  # 4 MEV  Magic EVasion rate
  "MRF",# 5 MRF  Magic ReFlection rate
  "CNT", # 6 CNT  CouNTer attack rate
  "HRG",# 7 HRG  Hp ReGeneration rate
  "MRG", # 8 MRG  Mp ReGeneration rate
  "TRG",# 9 TRG  Tp ReGeneration rate
  ]
  def self.xparam(param_id)
    XPARAM[param_id]
  end
end

class Window_EquipStatus
  XPARAM_DISPLAY_MULT = true # if true, multiply xparam as %
  FONT_SIZE = 21 # font point size of this window
  SKIP_XPARAMS = [7, 8] # skip drawing these xparams
  alias initialize_setfont initialize 
  # making a copy of the origina method so it can be used in the redefinition
  def initialize(*args)
    initialize_setfont(*args) # calling original method
    if FONT_SIZE 
      contents.font.size = FONT_SIZE # setting custom font size
      refresh # redrawing window
    end
  end
  
  alias refresh_drawxparam refresh
  def refresh
    refresh_drawxparam
    off = 0
    10.times {|i| # 10 times, one for each number of xparams
    if SKIP_XPARAMS.include?(i) # if this xparam is to be omitted
      off += 1 # increase offset variable so there are no gaps in drawing
      next # skip drawing and move onto the next one
    end
    draw_item_ex(0, line_height * (7 + i - off), i) # draw item calls all other draw methods
    }
  end
    
  def draw_item_ex(x, y, param_id)
    # calls all seperate draw methods, see below
    # this method basically passes the origin of where each item should be drawn
    draw_xparam_name(x + 4, y, param_id) 
    draw_current_xparam(x + 94, y, param_id) if @actor
    draw_right_arrow(x + 126, y)
    draw_new_xparam(x + 150, y, param_id) if @temp_actor
  end
  
  def draw_xparam_name(x, y, param_id) # draw the parameter name
    change_color(system_color)
    draw_text(x, y, 80, line_height, Vocab.xparam(param_id)) 
  end
  
  def draw_current_xparam(x, y, param_id) # draw current value of xparam
    change_color(normal_color)
    text = !XPARAM_DISPLAY_MULT ? sprintf("%0.2f", @actor.xparam(param_id)) : "#{(@actor.xparam(param_id) * 100).to_i}%"
    draw_text(x, y, 32, line_height, text, 2)
  end
  
  def draw_new_xparam(x, y, param_id)
    new_value = @temp_actor.xparam(param_id)
    change_color(param_change_color(new_value - @actor.xparam(param_id)))
    text = !XPARAM_DISPLAY_MULT ? sprintf("%0.2f", new_value) : "#{(new_value * 100).to_i}%"
    # above line - get text to be drawn.  if using display mult, multiply value
    # by 100 and add a percent sign instead of displaying the decimal
    # if not, display two decimal values with a leading zero
    draw_text(x, y, 32, line_height, text, 2)
  end
  
  def window_height
    344 # default of Graphics.height minus the help window's height
    # calculating this dynamically would require redefining a few other methods
  end
  
  def line_height
    return FONT_SIZE if FONT_SIZE # if font size is set, use it for line height
    super # if not set, use the default value
  end

end

class Scene_Equip
  
  def create_item_window 
    # redefining this and using math to put the item window in the correct place
    wx = @status_window.width
    wy = @slot_window.y + @slot_window.height
    ww = Graphics.width - @status_window.width
    wh = Graphics.height - wy
    @item_window = Window_EquipItemCompact.new(wx, wy, ww, wh)
    @item_window.viewport = @viewport
    @item_window.help_window = @help_window
    @item_window.status_window = @status_window
    @item_window.actor = @actor
    @item_window.set_handler(:ok,     method(:on_item_ok))
    @item_window.set_handler(:cancel, method(:on_item_cancel))
    @slot_window.item_window = @item_window
  end
end

class Window_EquipItemCompact < Window_EquipItem
  # compact version of the equip item window with one column
  def col_max
    1
  end
end