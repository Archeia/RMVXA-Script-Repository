# Mithran patches for memory leak issues
# Yanfly Battle System - v 1.22 (2012.03.04)
# Problem - popup sprites have no individual disposal method 
# if there are any popups still playing when the battle terminates, they are not disposed
# Fix:
class Sprite_Battler 
  alias dispose_beforeYanflypopups dispose
  def dispose
    dispose_popups # added
    dispose_beforeYanflypopups 
  end
  
  def dispose_popups
    @popups.each { |s| 
    s.bitmap.dispose
    s.dispose
    }    
  end
  
end