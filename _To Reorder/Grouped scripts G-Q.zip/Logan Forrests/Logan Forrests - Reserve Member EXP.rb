#==============================================================================
#   Reserve Member EXP Rate MiniScript (ver 1.0)
#
#   ~ Part of the OvertureAce MiniScript compilation by Logan Forrests ~
#
#==============================================================================
#   About
#------------------------------------------------------------------------------
#   Title: Reserve Member EXP Rate
#
#   A script to allow the customisation of the EXP gained by reserve party
#    members, and to provide a means of excluding certain actors from the
#    benefit of EXP gained as a reserve party member.
#
#   Version: 1.0
#   Date: 10 December 2012
#   Author: Logan Forrests
#   Hosted on: RMRK.net only.
#
#   Permissions for use of this script can be found here:
#       - http://rmrk.net/index.php/topic,45481.0.html
#
#   Redistribution of this script is stricly prohibited.
#==============================================================================
#   Directions
#------------------------------------------------------------------------------
#   You can change the proportion of the exp awarded at the end of battle
#    the reserve party members gain.
#
#   RATE : The proportion of exp awarded. Can be written in one of two ways:
#         Way 1: A real number between 0 and 1. This is the decimal percentage
#                Ex: 0.5 is 50%, 0.85 is 85%.
#         Way 2: A real number between 0 and 100. This will be converted into 
#                the above. Ex: 50 is 50%, 80 is 80%.
#         Note: In the event '1' is used, it was will be considered under Way 1
#                and will be treated to mean 100%.
#
#   EXCLUSION : This array contains the IDs of actors who will not benefit from
#       shared exp. An excluded actor will still gain exp from battles if they
#       take part in the battle.
#       By default, this is empty. IDs added directly to this script
#       will be considered excluded from this benefit from the beginning of the
#       game. IDs can be added and removed from this list during the game via 
#       Script calls in events.
#
#
#   The following Script commands can be used: 
#
#      rmer_exclude(actor_id):
#          Adds the actor_id to the Exclusion list. This actor will not gain
#          any exp from battles when outside of the active party.
#
#      rmer_remove(actor_id):
#          Removes the actor_id from the Exclusion list. The actor will continue
#          to receive a share of the exp from battles.
#
#    Script commands can be used by selecting the "Script..." command within
#     the Event Command list. It can be found under "Advanced" on page 3.
#==============================================================================
# Important Notes
#------------------------------------------------------------------------------
#  It is incredibly important to note that using this script will render
#    the option to enable and disable the "Reserve Members EXP" option in
#    the database redundant. This script assumes that you want to share
#    EXP to all actors unless they are on the Exclusion list, and does NOT
#    check that the option is enabled, as it does in the default, original code.
#==============================================================================


module OvertureAce
  module MiniScripts
  
    module Reserve_Member_EXP_Rate
#==============================================================================
#          !!!!!!!          START OF CUSTOMISATION       !!!!!!!
#==============================================================================
    #How much of the awarded exp that will be also awarded to reserve party
    #members. Can be a real number between 0 and 1 (inclusive), or a real number
    # between greater than 0 (inclusive). The value given will be converted into a
    # percentage. Note: the value '1' will be treated as 100%. Please use 0.01 to represent
    # 1%
    RATE = 1
    
    #Which party members should be excluded from the Reserve Party Member EXP 
    #award? Insert the IDs of the Party Members (their Actor ID) who should
    #not be given reserve exp, seperated by a comma ',' as in the example below
    # Ex: EXCLUSION = [ 1, 3, 6]
    EXCLUSION = [ ]
#===============================================================================
#          !!!!!!!          END OF CUSTOMISATION       !!!!!!!
#===============================================================================
#      DO NOT EDIT BEYOND THIS LINE         DO NOT EDIT BEYOND THIS LINE 
#===============================================================================
    end
  end
end
#===============================================================================
# Game_Actor
#    Overwritten methods:
#            reserve_members_exp_rate
#               - Reflects Exclusion list
#               - Removes check for option being enabled (implied enabling)
#               - Converts rate to decimal percentage if necessary
#===============================================================================
class Game_Actor
  
  #--------------------------------------------------------------------------
  # * Get EXP Rate for Reserve Members
  #--------------------------------------------------------------------------
  def reserve_members_exp_rate
    #shorten module name
    mod_ref = OvertureAce::MiniScripts::Reserve_Member_EXP_Rate
    unless mod_ref::EXCLUSION.include?(self.id)
      #get rate as floating point number
      rate = (mod_ref::RATE).to_f
      #convert to number between 0 and 1 if necessary
      rate /= 100.0 if rate > 1
      return rate
    end
    return 0 #If excluded, no exp is awarded
  end
  
end

#===============================================================================
# Game_Interpreter
#     Added methods:
#               rmer_exclude(actor_id)
#                 - Adds given actor_id to exclusion array
#               rmer_remove(actor_id)
#                 - Removes given actor_id from exclusion array
#===============================================================================
class Game_Interpreter
  
  def rmer_exclude(actor_id)
    mod_ref = OvertureAce::MiniScripts::Reserve_Member_EXP_Rate
    mod_ref::EXCLUSION.push(actor_id) unless mod_ref::EXCLUSION.include?(actor_id)
  end
  
  def rmer_remove(actor_id)
    mod_ref = OvertureAce::MiniScripts::Reserve_Member_EXP_Rate
    mod_ref::EXCLUSION.delete(actor_id) if mod_ref::EXCLUSION.include?(actor_id)
  end
  
#~   #Testing methods
#~   #Check for correct exp share
#~   def rmer_test_exp(actor_id, exp)
#~     actor = $game_actors[actor_id]
#~     rate = actor.reserve_members_exp_rate
#~     gain = exp * rate
#~     p "EXP gained by actor #{actor_ud}: #{gain}"
#~   end
#~   
#~   #Test the adding of excluded actors
#~   def rmer_test_exclude(actor_id)
#~     rmer_exclude(actor_id)
#~     p OvertureAce::MiniScripts::Reserve_Member_EXP_Rate::EXCLUSION
#~   end
#~   
#~   #Test the removal of excluded actors
#~   def rmer_test_remove(actor_id)
#~     rmer_remove(actor_id)
#~     p OvertureAce::MiniScripts::Reserve_Member_EXP_Rate::EXCLUSION
#~   end
  
end