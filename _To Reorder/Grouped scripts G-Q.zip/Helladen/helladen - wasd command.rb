#==============================================================================
# ▼ WASD Movement
# -- Last Updated: 2014.02.25
# -- Author: Helladen
#==============================================================================

module Input
  #--------------------------------------------------------------------------
  # alias method: self.dir4
  #--------------------------------------------------------------------------
  class <<self; alias helladen_dir4 dir4; end
  def self.dir4
    return 2 if Input.press?(:Y)
    return 4 if Input.press?(:X)
    return 6 if Input.press?(:Z)
    return 8 if Input.press?(:R)
    helladen_dir4
  end
end