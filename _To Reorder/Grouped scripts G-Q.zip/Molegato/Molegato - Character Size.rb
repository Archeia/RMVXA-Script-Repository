#==============================================================================
# CHARACTER SIZE SCRIPT
# Author Molegato
# Version 1.0
#------------------------------------------------------------------------------
# Allows you to make event, vehicle, player and followers character shrink or
# grow, as well as make maps have a default character size, actin like a zoom.
#------------------------------------------------------------------------------
# INSTRUCTIONS
# Every character will be of normal size if you don't do anything.
# For setting a character size for a map, add this tag to its notes:
#   <chara_size: size>
# Size = 1 means normal size, 2 is double, 0.5 is half, etc
# You can also change specific events, or even the player character,
# its followers, or vehicles to a specific size via event script call.
# for that, use:
#   $game_map.set_vehicle_size(index,size)
#       index=0 boat, 1 ship, 2 airship
#   $game_map.set_event_size(number,size)
#   $game_map.set_player_size(size)
#   $game_map.set_followers_size(size)
#==============================================================================

$imported = {} if $imported.nil?
$imported['Molegato-character_size'] = true

#==============================================================================
# ■ Sprite_Character
#==============================================================================
class Game_Map
  attr_reader   :map
end
#==============================================================================
# ■ Sprite_Character
#==============================================================================

class Sprite_Character < Sprite_Base
  attr_accessor :size
  alias character_size_initialize initialize
  def initialize(viewport, character = nil)
    @size=1
    map = $game_map.map
    if map.tag_check_multivalues(map.note,"chara_size")
      @size=map.tag_check_multivalues(map.note,"chara_size")[0].to_f
    end
    $game_player.size=nil
    for i in 0..$game_player.followers.data.size-1
      $game_player.followers[i].size=nil
    end
    character_size_initialize(viewport,character)
  end

  alias character_size_update update
  def update
    character_size_update
    if @character and @character.size and @size!=@character.size
      @size=@character.size
      set_character_bitmap
    end
  end
  
  alias character_size_set_character_bitmap set_character_bitmap
  def set_character_bitmap
    character_size_set_character_bitmap
    self.bitmap = Cache.character(@character_name).clone
    self.ox*=@size
    self.oy*=@size
    @cw*=@size
    @ch*=@size
    rect=Cache.character(@character_name).rect
    rect.width*=@size
    rect.height*=@size
    if @size!=1
      source = self.bitmap
      self.bitmap = Bitmap.new(source.width*@size, source.height*@size)
      self.bitmap.stretch_blt(self.bitmap.rect, source, source.rect)
    end
  end
end

#==============================================================================
# ■ Game_CharacterBase
#==============================================================================

class Game_CharacterBase
  attr_accessor :size
end

#==============================================================================
# ■ Game_Map
#==============================================================================

class Game_Map

  def set_vehicle_size(index,size)
    @vehicles[index].size=size
  end

  def set_event_size(number,size)
    @events[number].size=size
  end
  
  def set_player_size(size)
    $game_player.size=size
  end

  def set_followers_size(size)
    for i in 0..$game_player.followers.data.size-1
      $game_player.followers[i].size=size
    end
  end
  
end

class Game_Followers
  attr_accessor :data
end