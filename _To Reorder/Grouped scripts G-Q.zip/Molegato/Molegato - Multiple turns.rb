#==============================================================================
# Multiple turns
# Author Molegato
# Version 1.0
#------------------------------------------------------------------------------
# Every turn, every actor and enemy has a set number of actions, rather than 1.
#------------------------------------------------------------------------------
# INSTRUCTIONS
#==============================================================================

$imported = {} if $imported.nil?
$imported['Molegato-Multiple_turns'] = true

#==============================================================================
# CONFIGURATION, YOU CAN TOUCH THIS
#==============================================================================

module MOLEGATO_MULTIPLE_TURNS
  #If set to true, after each action is performed, the order for the remaining
  #ones will be calculated again. If set to false, the exact same order pattern
  #will be followed again and again, making the first action the one that affects
  #the order.
  RECALCULATE_ORDER = true
  
  #When set to 0, characters will have 1 turn, plus the extra turns allowed via
  #traits, plus the extra turns added by agi.
  GLOBAL_EXTRA_TURNS = 0
  
  #If agi is greater than the average of the battlers, the battler will have
  #additional turns for each agi point surpassing the average.
  #If this value is 0.5, for example, for each 2 agi points that surpass
  #the average, the battler will gain 1 turn. I advise to use very small values.
  TURNS_PER_AGI = 0.05
  
  #If this is set as true, turns will be rewarded for every agi point, regardless
  #of the average. Use only if you have very very small agi values in your game.
  IGNORE_AVERAGE = false
end
#==============================================================================
# END OF CONFIGURATION. EVERYTHING UNDER HERE IS A HELLISH MESS OF DEFICIENT
# AMATEUR SCRIPTING. BE AWARE THAT MESSING WITH IT CAN RESULT IN DISASTER
#==============================================================================

#==============================================================================
# ■ Game_Battler
#==============================================================================

class Game_Battler < Game_BattlerBase
  
  alias multiturns_make_action_times make_action_times
  def make_action_times
    total_turns = multiturns_make_action_times + MOLEGATO_MULTIPLE_TURNS::GLOBAL_EXTRA_TURNS
    total_turns += calculate_extra_turns.to_i
    return total_turns
  end

  alias multiturns_make_speed make_speed
  def make_speed
    multiturns_make_speed
    @speed+= agi
  end

  def calculate_extra_turns
    if MOLEGATO_MULTIPLE_TURNS::IGNORE_AVERAGE
      return MOLEGATO_MULTIPLE_TURNS::TURNS_PER_AGI * agi
    end
      
    if agi< BattleManager.average_speed
      return 0
    else
      return (agi - BattleManager.average_speed) * MOLEGATO_MULTIPLE_TURNS::TURNS_PER_AGI
    end
  end
  
end

#==============================================================================
# ■ BattleManager
#==============================================================================

module BattleManager
  
  def self.change_subject
    delete_dead_battlers
    loop do
      battler = @action_battlers.shift
      return nil unless battler
      @action_battlers.push(battler)
      if MOLEGATO_MULTIPLE_TURNS::RECALCULATE_ORDER
        @action_battlers.sort! {|a,b| b.speed - a.speed }
      end
      next unless battler.index && battler.alive?
      return battler
    end
  end
  
  def self.average_speed
    total_battlers = []
    total_battlers += $game_party.alive_members
    total_battlers += $game_troop.alive_members
    average=0
    return 0 if total_battlers.size<=1
    
    for i in 0..total_battlers.size-1
      average+=total_battlers[i].agi
    end
    average=average/total_battlers.size
    return average
  end
  
end

#==============================================================================
# ■ Scene_Battle
#==============================================================================

class Scene_Battle < Scene_Base

  def process_action
    return if scene_changing?
        
    if !@subject || !@subject.current_action
      @subject = BattleManager.change_subject
    end

    return turn_end unless @subject
    if @subject.current_action
      @subject.current_action.prepare
      if @subject.current_action.valid?
        @status_window.open
        execute_action
      end
      @subject.remove_current_action
    end
    
    if @subject.current_action
      @subject = BattleManager.change_subject
      process_action_end
    else
      process_action_end
      @subject = BattleManager.next_subject
    end
    
  end

end