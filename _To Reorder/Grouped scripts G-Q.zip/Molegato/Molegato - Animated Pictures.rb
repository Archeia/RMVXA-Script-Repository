#==============================================================================
# ANIMATED PICTURES
# Author Molegato
# Version 1.1
#------------------------------------------------------------------------------
# explanation
#   This script allows you to use animated pictures as you'd use normal ones
#   with the 'show picture' event block. For that you only need to set up
#   an animation here on the config module, and then use an image named as
#   the animation. That image doesn't need to be contained within the animation
#   per se, so you can use a dummy one if you wish.
# The animations are set as the examples below:
#   'name' => [frame_delay,'loop_mode',['frame1','frame2','frame3'...]]
# Frame delay: how many game-frames will take for an image to switch
# Loop modes: how to behave at the end of the animation
#   'loop': repeats the animation again and again
#   'once': when finished, stays on the last frame
#   anything else: the animation will stick to the first frame
# Frames: you can use any image that is on the pictures folder, you can
#   use them more than once, and reuse them in different animations
#   The number of frames is entirely up to you, with a minimum of 1
#==============================================================================

$imported = {} if $imported.nil?
$imported['Molegato-Picture_anim'] = true

#==============================================================================
# CONFIGURATION, YOU CAN TOUCH THIS
#==============================================================================
module ANIM_PICTURES
  
  #'animation_name'=> {frames_per_still, loop_mode, {frame,frame,frame...}}
  ANIMS={
      'circle1' => [2, 'loop', ['circle1','circle2','circle3','circle4','circle5','circle6']],
      'slow_anim' => [25, 'loop', ['test_1','test_2']],
      'once_anim' => [10, 'once', ['test_1','test_2','test_3','test_4']],
  }
  
end
#==============================================================================
# END OF CONFIGURATION. EVERYTHING UNDER HERE IS A HELLISH MESS OF DEFICIENT
# AMATEUR SCRIPTING. BE AWARE THAT MESSING WITH IT CAN RESULT IN DISASTER
#==============================================================================
#==============================================================================
# ■ Sprite_Picture
#==============================================================================

class Sprite_Picture < Sprite

  alias anim_initialize initialize
  def initialize(viewport, picture)
    anim_initialize(viewport, picture)
    animation_setup
  end

  def animation_setup
    if (ANIM_PICTURES::ANIMS.include?(@picture.name))
      @animation=@picture.name
      @animated=true
      @anim_speed=ANIM_PICTURES::ANIMS[@picture.name][0]
      @loop_mode=ANIM_PICTURES::ANIMS[@picture.name][1]
      @frames=ANIM_PICTURES::ANIMS[@picture.name][2]
      @frame_max=@frames.size
      @frame_count=0.0
      @frame_images=[]
      @frames.each do |frame|
        new_bitmap=Cache.picture(frame)
        @frame_images.push(new_bitmap)
      end
    end
  end
  
  alias anim_update update
  def update
    if (@picture.name=="")
      @animated=false
    end
    
    if (@animated)
      if (@picture.name!=@animation)
        animation_setup
      end
      update_animation
    end
    anim_update
  end
  
  def update_animation
    @frame_count+=1.0/@anim_speed
    if (@loop_mode=='loop') #loop
      if (@frame_count>=@frame_max)
        @frame_count=0.0
      end
    elsif (@loop_mode=='once') #once
      if (@frame_count>=@frame_max)
        @frame_count=@frame_max-1
      end
    else  #no valid loop mode
      @frame_count=0.0
    end
  end
  
  def update_bitmap
    if (@animated)
      self.bitmap = @frame_images[@frame_count.to_i]
    else
      self.bitmap = Cache.picture(@picture.name)
    end
  end

end

class Game_Picture
  
  alias anim_erase erase
  def erase
    anim_erase
    @name = ""
    @origin = 0
  end
end