#==============================================================================
# ITEM FRAGMENTS
# Author Molegato
# Version 1.1
#------------------------------------------------------------------------------
# A number of items joins automatically into a different one
#------------------------------------------------------------------------------
# INSTRUCTIONS
# 
#   You have to put this tag on the FRAGMENT item.
#
# <fragment_of: result_id,result_kind,fragments_amount,result_amount,auto_join,auto_tell>
#
#   result_kind should be 0 for items, 1 for weapons and 2 for protectors
#   if auto_join is 1, the fragments will unite in the result as soon as you
#   get them. Else they wont unite until you call the unite function.
#   if auto_tell is 1, a message will show up telling that the items united
#
#   If you have fragment items with no auto_join, you can join them via event
#   script call using this
#
# ITEM_FRAGMENTS.unite(fragment_id,max_number,tell)
#
#   max number is the maximum amount of unions in the process.
#   You can skip the tell parameter, wich defaults at false
#==============================================================================

$imported = {} if $imported.nil?
$imported['Molegato-Item_fragments'] = true

#==============================================================================
# CONFIGURATION, YOU CAN TOUCH THIS
#==============================================================================
module ITEM_FRAGMENTS_CONFIG
  
  #sound to play
  UNITE_SOUND = "Chime2"
  
  # 0 = fragment item name with icon
  # 1 = fragment ammount
  # 2 = result item name with icon
  # 3 = result amount
  # 4 = fragment item icon
  # 5 = result item icon
  # 6 = fragment item name
  # 7 = result item name
  # any text string will be displayed as written. Might be compatible with
  # any message system
  CUSTOM_MESSAGE = [0, " x ", 1," becomes ", 2," x ", 3]
  CUSTOM_MESSAGE_ONE = [0, " x ", 1," becomes ", 2]
  
  #message position. 0 = up, 1 = middle screen, 2 = down
  MESSAGE_POS = 1
  #message background. 0 = window, 1 = black background, 2 = transparent
  MESSAGE_BACK = 1
end

#==============================================================================
# END OF CONFIGURATION. EVERYTHING UNDER HERE IS A HELLISH MESS OF DEFICIENT
# AMATEUR SCRIPTING. BE AWARE THAT MESSING WITH IT CAN RESULT IN DISASTER
#==============================================================================


class Game_Party
  
  alias item_fragments_gain_item gain_item
  def gain_item(item, number, include_equip = false)
    item_fragments_gain_item(item, number, include_equip)
    # llamar a item_fragments.unite
    if item and item.tag_check_multivalues(item.note,"fragment_of")
      values = item.tag_check_multivalues(item.note,"fragment_of")
      if values[4]
        ITEM_FRAGMENTS.unite(item.id,99,values[5])
      end
    end
  end
  
end

module ITEM_FRAGMENTS
  
  def self.unite(fragment_id,max_number,tell=false)
    item = $data_items[fragment_id]
    return if not item
    return if fragment_id==0
    
    for i in 0..max_number
      if item and item.tag_check_multivalues(item.note,"fragment_of")
        values = item.tag_check_multivalues(item.note,"fragment_of")
        if values[1].to_i()==0
          result=$data_items[values[0].to_i()]
        end
        if values[1].to_i()==1
          result=$data_weapons[values[0].to_i()]
        end
        if values[1].to_i()==2
          result=$data_armors[values[0].to_i()]
        end
        
        if $game_party.item_number(item)>=values[2].to_i()
          $game_party.lose_item(item, values[2].to_i())
          $game_party.gain_item(result, values[3].to_i())
          if tell
            tell_union(values,item,result)
          end
        end
      end
    end
  end

  def self.tell_union(values,item,result)
            result_name=result.name
            if values[5].to_i()==1
            RPG:: SE.new( ITEM_FRAGMENTS_CONFIG::UNITE_SOUND ).play
            text=''
            if values[3].to_i()>1
              message_set=ITEM_FRAGMENTS_CONFIG::CUSTOM_MESSAGE
            else
              message_set=ITEM_FRAGMENTS_CONFIG::CUSTOM_MESSAGE_ONE
            end
            for ii in 0..message_set.size-1
              if message_set[ii].is_a?(Integer)
                if message_set[ii]==0
                  text+="\\i[#{item.icon_index}]#{item.name}"
                end
                if message_set[ii]==1
                  text+="#{values[2]}"
                end
                if message_set[ii]==2
                  text+="\\i[#{result.icon_index}]#{result_name}"
                end
                if message_set[ii]==3
                  text+="#{values[3]}"
                end
                if message_set[ii]==4
                  text+="\\i[#{item.icon_index}]"
                end
                if message_set[ii]==5
                  text+="\\i[#{result.icon_index}]"
                end
                if message_set[ii]==6
                  text+="#{item.name}"
                end
                if message_set[ii]==7
                  text+="#{result.name}"
                end

              else
                text+=ITEM_FRAGMENTS_CONFIG::CUSTOM_MESSAGE[ii]
              end
            end
            $game_message.background = ITEM_FRAGMENTS_CONFIG::MESSAGE_BACK
            $game_message.position = ITEM_FRAGMENTS_CONFIG::MESSAGE_POS
            $game_message.add(text)
          end
  end
end