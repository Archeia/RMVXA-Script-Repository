#==============================================================================
# MULTIPLE PARALLAXES
# Author Molegato
# Version 1.0
#------------------------------------------------------------------------------
# Lets you use as many parallaxes as you want, and set their x and y speed,
# and their z value. Also, speed is not restricted and it can be used as
# overlay instead of background.
# The tags work like this:
# <parallax>
# <parallax: parallax_image_name,z,horizontal_speed,vertical_speed,pinned>;
# <parallax: parallax_image_name,z,horizontal_speed,vertical_speed,pinned>;
# <parallax: parallax_image_name,z,horizontal_speed,vertical_speed,pinned>
# </parallax>
#
# * Note that the last parallax added need no ; at the end. Adding it anyway
#   could cause problems.
#
# * Just for reference, the z value of RPGMVXA built in parallax is -100, and
#   more negative numbers means 'deeper' into the screen.
#
# * pinned may be 1 or 0. Be it 1, the image will not move with the camera,
#   sticking to its place, making it perfect for backgrounds, if it's not 1,
#   it'll follow the camera, wich is better for fogs or other stuff.
#
#==============================================================================


#==============================================================================
# ■ Game_Map
#==============================================================================
class Game_Map
  attr_reader   :map
  attr_accessor :parallax_updated
  
  alias molegato_initialize initialize
  def initialize
    molegato_initialize
    @parallax_updated=false
  end
  
  alias molegato_setup_parallax setup_parallax
  def setup_parallax
    molegato_setup_parallax
    @parallax_updated=false
  end

end

#==============================================================================
# ■ Spriteset_Map
#==============================================================================

class Spriteset_Map


  alias molegato_create_parallax create_parallax
  def create_parallax
    molegato_create_parallax
    create_parallaxes
  end

  def create_parallaxes
    @parallaxes = []
    @parallaxes_x_vel = []
    @parallaxes_y_vel = []
    @parallaxes_x_orig = []
    @parallaxes_y_orig = []
    @parallaxes_fixed = []
    if not $game_map.map.has_tag?("parallax")
      return
    end
    @addmaps=$game_map.map.tag_check_multiple_multivalues("parallax")
    num=0
    @addmaps.each do |each|
      new_parallax = Plane.new(@viewport1)
      new_parallax.z = @addmaps[num][1].to_i()
      new_parallax.bitmap = Cache.parallax(@addmaps[num][0])
      @parallaxes_x_vel[num]=@addmaps[num][2]
      @parallaxes_y_vel[num]=@addmaps[num][3]
      @parallaxes_fixed[num]=@addmaps[num][4].to_i()
      @parallaxes_x_orig[num] = 0
      @parallaxes_y_orig[num] = 0
      @parallaxes=@parallaxes.push(new_parallax)
      num+=1
    end
  end

  alias molegato_dispose_parallax dispose_parallax
  def dispose_parallax
    dispose_parallaxes
    molegato_dispose_parallax    
  end

  def dispose_parallaxes
    @parallaxes.each do |each|
      each.bitmap.dispose if each.bitmap
      each.dispose
    end
  end

  alias molegato_update_parallax update_parallax
  def update_parallax
    molegato_update_parallax
    if $game_map.parallax_updated==false
      dispose_parallaxes
      create_parallaxes
      $game_map.parallax_updated=true
    end
    num = 0
    @parallaxes.each do |each|
      @parallaxes_x_orig[num]+=@parallaxes_x_vel[num].to_i()
      @parallaxes_y_orig[num]+=@parallaxes_y_vel[num].to_i()
      
      if @parallaxes_fixed[num]==1
        each.ox = $game_map.display_x*32 - @parallaxes_x_orig[num]
        each.oy = $game_map.display_y*32 - @parallaxes_y_orig[num]
      else
        each.ox = -1*@parallaxes_x_orig[num]
        each.oy = -1*@parallaxes_y_orig[num]
      end
      
      num+=1
    end

  end
  
end

#==============================================================================
# MOLEGATO TAG METHODS
# Author Molegato
# Version 1.0
#------------------------------------------------------------------------------
# Several methods for using tags. Needed by some of my scripts.
#------------------------------------------------------------------------------
# Included in some of my scripts.
#==============================================================================

$imported = {} if $imported.nil?
$imported['Molegato-Sudden death'] = true

class RPG::BaseItem
  
  def has_tag?(tag)
    if self.note[/<#{tag}>/mi]
      return true
    else
      return false
    end
  end
  
  def tag_check_value(tag) 
    if self.note[/<#{tag}: (.*?)>/mi]
      return $1
    else
      return false
    end
  end
  
  def tag_check_multivalues(tag)
    if self.note[/<#{tag}: (.*?)>/mi]
      return $1.split(',')
    else
      return false
    end
  end
   
  def tag_check_multivalues(string, tag)
    if string[/<#{tag}: (.*?)>/mi]
      return $1.split(',')
    else
      return false
    end
  end

  def tag_get_block(tag)
    if self.note[/<#{tag}>(.*?)<\\#{tag}>/mi]
      return $1
    else
      return false
    end
  end
  
  def tag_multiple(tag)
    if tag_get_block(tag)
      var=tag_get_block(tag)
      return var.split(';')
    else
      return false
    end
  end
  
  def tag_check_multiple_multivalues(tag)
      if tag_multiple(tag)
        array=[]
        tag_multiple(tag).each do |each|
          array.push(tag_check_multivalues(each,tag))
        end
        return array
      else
        return false
      end
  end
  
  end
  
  
class RPG::Map
  
  def has_tag?(tag)
    if self.note[/<#{tag}>/mi]
      return true
    else
      return false
    end
  end
  
  def tag_check_value(tag) 
    if self.note[/<#{tag}: (.*?)>/mi]
      return $1
    else
      return false
    end
  end
  
  def tag_check_multivalues(tag)
    if self.note[/<#{tag}: (.*?)>/mi]
      return $1.split(',')
    else
      return false
    end
  end
   
  def tag_check_multivalues(string, tag)
    if string[/<#{tag}: (.*?)>/mi]
      return $1.split(',')
    else
      return false
    end
  end

  def tag_get_block(tag)
    if self.note[/<#{tag}>(.*?)<\\#{tag}>/mi]
      return $1
    else
      return false
    end
  end
  
  def tag_multiple(tag)
    if tag_get_block(tag)
      var=tag_get_block(tag)
      return var.split(';')
    else
      return false
    end
  end
  
  def tag_check_multiple_multivalues(tag)
      if tag_multiple(tag)
        array=[]
        tag_multiple(tag).each do |each|
          array.push(tag_check_multivalues(each,tag))
        end
        return array
      else
        return false
      end
  end
  
end