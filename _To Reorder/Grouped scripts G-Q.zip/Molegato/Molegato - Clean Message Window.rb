#==============================================================================
# CLEAN MESSAGE WINDOW
# Author Molegato
# Version 1.0.2
#------------------------------------------------------------------------------
# Just some small size fixes to the message window, without adding new features
# Now the window can change its size to fit text (vertically) and automatically
# add line jumps when a line is too long.
# Also is possible to change the maximum line number and to actively change if
# the message box fits vertically the text or not with a script call.
# To do so, use this:
#     $game_system.scalewindow=false/true
#==============================================================================

$imported = {} if $imported.nil?
$imported['Molegato-Clean_message'] = true

#==============================================================================
# CONFIGURATION, YOU CAN TOUCH THIS
#==============================================================================
module CLEAN_MESSAGE
  #Default maximum number of lines. more than 4 will result in huge windows
  LINE_NUMBER=4
  
  #Default state of the scalation. if set to true, the window will fit vertically
  #the text.
  SCALE_WINDOW=true
end
#==============================================================================
# END OF CONFIGURATION. EVERYTHING UNDER HERE IS A HELLISH MESS OF DEFICIENT
# AMATEUR SCRIPTING. BE AWARE THAT MESSING WITH IT CAN RESULT IN DISASTER
#==============================================================================


class Game_System
  attr_accessor :scalewindow
  
  alias molegato_clean_message_initialize initialize
  def initialize
    molegato_clean_message_initialize
    @scalewindow=CLEAN_MESSAGE::SCALE_WINDOW
  end
end

class Window_Message < Window_Base

  alias molegato_initialize initialize
  def initialize
    @current_text=""
    molegato_initialize
  end

  def visible_line_number
    lines=0
    @current_text.each_line do |line|
      lines+=1
    end
    if $game_system.scalewindow
      return [[lines,minimum_height].max(),CLEAN_MESSAGE::LINE_NUMBER].min
    else
      return CLEAN_MESSAGE::LINE_NUMBER
    end
  end
   
  def minimum_height
    if $game_message.face_name.empty?
      return 1
    else
      return 4
    end
  end
  
  def contents_height
    fitting_height(CLEAN_MESSAGE::LINE_NUMBER) - standard_padding * 2
  end
  
  alias molegato_update update
  def update
    self.height=window_height
    molegato_update
    #update_placement
  end
  
  def open_and_wait
    open
    create_back_bitmap
    create_back_sprite
    
    until open?
      Fiber.yield
      update_placement
    end
  end

  def process_all_text
    pos = {}
    text = convert_escape_characters($game_message.all_text)
    text = text_with_autojumps(text)
    @current_text=text.clone()
    open_and_wait
    new_page(text, pos)
    process_character(text.slice!(0, 1), text, pos) until text.empty?
  end
  
  def settings_changed?
    text = convert_escape_characters($game_message.all_text)
    text = text_with_autojumps(text)
    lines=0
    text.each_line do |line|
      lines+=1
    end
    
    @background != $game_message.background ||
    @position != $game_message.position ||
    lines != visible_line_number
  end
    
  def text_with_autojumps(text)  
    totaltext=''
    lines=text.split("\n")
    lines.each do |current_line|
      words=current_line.split(' ')
      lineatotal=''
      linea=''
      words.each do |current_word|
        if contents.text_size(linea+current_word).width<=contents_width-new_line_x
          linea+=current_word+' '
        else
          linea+="\n"
          lineatotal+=linea
          linea=current_word+' '
        end
      end
      lineatotal+=linea
      current_line=lineatotal+"\n"
      totaltext+=current_line
    end
    return totaltext
  end

end