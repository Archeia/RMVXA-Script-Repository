#==============================================================================
# EVENT INFO WINDOW
# Author Molegato
# Version 1.0
#------------------------------------------------------------------------------
# Displays a window with info about an event
#------------------------------------------------------------------------------
# INSTRUCTIONS
# You have to use tags on comments
# You cannot add more than a single tag to each comment, so you'll have to
# use multiple comments with a single line. Sorry about that.
# In the comments, you can use the following tags, all of them are optional
# and you can use some of them for an event, and a different set for another
#
# <event_info>                This event has info, and a window will appear
#                             when the player is near. This tag is neccessary
#                             for the rest of tags to even have a meaning.
# <event_name: name>          This is the name to display.
# <event_name_color: id>      The color id for the name.
#* <event_descript: text>      A line of text for the event info
#* <event_descript_color: id>  The color id for the description.
# <event_icon: index>         The index of the icon to show, if any.
# <event_face: name, index>   The name of the face image, and the index.
#==============================================================================

$imported = {} if $imported.nil?
$imported['Molegato-Event_info'] = true

#==============================================================================
# CONFIGURATION, YOU CAN TOUCH THIS
#==============================================================================

module MOLEGATO_EVENT_INFO
  #Minimum distance in tiles to an event to show its information
  DISTANCE = 4
  
  #Window parameters
  WINDOW = 'Window'
  TONE = [255,255,255,255]
  OPACITY = 255
  X = 0
  Y = Graphics.height-75
  WIDTH = 250
  HEIGHT = 75
  
  #Images
  USE_IMAGE1 = false
  IMAGE1_NAME = ''
  IMAGE1_X = 0
  IMAGE1_Y = 0
  USE_IMAGE2 = false
  IMAGE2_NAME = ''
  IMAGE2_X = 0
  IMAGE2_Y = 0

  #Event name
  NAME_FONT_SIZE = Font.default_size
  NAME_X = 50
  NAME_Y = 0
  NAME_WIDTH = 200
  NAME_HEIGHT =32
  NAME_ALIGN=0 #0 for left, 1 for center, 2 for right
  
  #Event Descript
  DES_FONT_SIZE = Font.default_size-6
  DES_X = 50
  DES_Y = 24
  DES_WIDTH = 200
  DES_HEIGHT =32
  DES_ALIGN=0 #0 for left, 1 for center, 2 for right
  
  #Event icon
  ICON_X = 0
  ICON_Y = 0
  
  #Event face
  FACE_X = 0
  FACE_Y = 0
  FACE_SCALE = 0.5
  
end
#==============================================================================
# END OF CONFIGURATION. EVERYTHING UNDER HERE IS A HELLISH MESS OF DEFICIENT
# AMATEUR SCRIPTING. BE AWARE THAT MESSING WITH IT CAN RESULT IN DISASTER
#==============================================================================




#==============================================================================
# ■ Game_Event
#==============================================================================

class Game_Event < Game_Character
  attr_reader   :x                  # トリガー
  attr_reader   :y                     # 実行内容
end

#==============================================================================
# ■ Window_Event_info
#==============================================================================

class Window_Event_info < Window_Base
  attr_accessor   :event

  def initialize
    super(MOLEGATO_EVENT_INFO::X, MOLEGATO_EVENT_INFO::Y, MOLEGATO_EVENT_INFO::WIDTH, MOLEGATO_EVENT_INFO::HEIGHT)
    self.openness = 0
    refresh
    self.windowskin = Cache.system(MOLEGATO_EVENT_INFO::WINDOW)
    self.opacity=MOLEGATO_EVENT_INFO::OPACITY
  end
  
  def refresh
    contents.clear
    if not @event
      return
    end
    
    #Draw image 1
    if MOLEGATO_EVENT_INFO::USE_IMAGE1
      draw_system(MOLEGATO_EVENT_INFO::IMAGE1_NAME,MOLEGATO_EVENT_INFO::IMAGE1_X,MOLEGATO_EVENT_INFO::IMAGE1_Y)
    end

    #Draw face
    if @event.tag_check_multivalues(@event.note,"event_face")
      facename=@event.tag_check_multivalues(@event.note,"event_face")[0]
      faceindex=@event.tag_check_multivalues(@event.note,"event_face")[1].to_i
      if open?
        draw_face_scaled(facename, faceindex, MOLEGATO_EVENT_INFO::FACE_X, MOLEGATO_EVENT_INFO::FACE_Y, MOLEGATO_EVENT_INFO::FACE_SCALE)
      end
    end

    #Draw icon
    if @event.tag_check_multivalues(@event.note,"event_icon")
      draw_icon(@event.tag_check_multivalues(@event.note,"event_icon")[0].to_i, MOLEGATO_EVENT_INFO::ICON_X, MOLEGATO_EVENT_INFO::ICON_Y, true)
    end

    #Draw image 2
    if MOLEGATO_EVENT_INFO::USE_IMAGE2
      draw_system(MOLEGATO_EVENT_INFO::IMAGE2_NAME,MOLEGATO_EVENT_INFO::IMAGE2_X,MOLEGATO_EVENT_INFO::IMAGE2_Y)    end
    
    #Draw name
    if @event.tag_check_multivalues(@event.note,"event_name")
      if @event.tag_check_multivalues(@event.note,"event_name_color")
        change_color(text_color(event.tag_check_multivalues(event.note,"event_name_color")[0].to_i))
      else
        change_color(normal_color)
      end
      contents.font.size = MOLEGATO_EVENT_INFO::NAME_FONT_SIZE
      draw_text(MOLEGATO_EVENT_INFO::NAME_X,MOLEGATO_EVENT_INFO::NAME_Y,MOLEGATO_EVENT_INFO::NAME_WIDTH,MOLEGATO_EVENT_INFO::NAME_HEIGHT,@event.tag_check_multivalues(event.note,"event_name")[0],MOLEGATO_EVENT_INFO::NAME_ALIGN)
    end
    
    #Draw description
    if @event.tag_check_multivalues(@event.note,"event_descript")
      if @event.tag_check_multivalues(@event.note,"event_descript_color")
        change_color(text_color(event.tag_check_multivalues(event.note,"event_descript_color")[0].to_i))
      else
        change_color(normal_color)
      end
      contents.font.size = MOLEGATO_EVENT_INFO::DES_FONT_SIZE
      draw_text(MOLEGATO_EVENT_INFO::DES_X,MOLEGATO_EVENT_INFO::DES_Y,MOLEGATO_EVENT_INFO::DES_WIDTH,MOLEGATO_EVENT_INFO::DES_HEIGHT,@event.tag_check_multivalues(event.note,"event_descript")[0],MOLEGATO_EVENT_INFO::DES_ALIGN)
    end

  end
  
  def update_open
    super
    refresh
  end

  def update_close
    super
    refresh
  end
  
end

#==============================================================================
# ■ Scene_Map
#==============================================================================

class Scene_Map < Scene_Base
  alias event_info_start start
  def start
    event_info_start
    create_event_info_window
  end
  
  def create_event_info_window
    @event_info=Window_Event_info.new
    @event_info.instant_close
  end

  alias event_info_update_scene update_scene
  def update_scene
    event_info_update_scene  
    minimum_dis=8
    for i in -1*MOLEGATO_EVENT_INFO::DISTANCE..MOLEGATO_EVENT_INFO::DISTANCE
      for e in -1*MOLEGATO_EVENT_INFO::DISTANCE..MOLEGATO_EVENT_INFO::DISTANCE
        if $game_map.events_xy($game_player.x+i,$game_player.y+e)[0]
          dis = i.abs + e.abs
          current_event=$game_map.events_xy($game_player.x+i,$game_player.y+e)[0]
          
          if dis<minimum_dis and current_event.has_tag?("event_info")
            minimum_dis=dis
            near_event=current_event
          end
        end
      end
    end

    if near_event
      if not @event_info.open?
        @event_info.open
        @event_info.event=near_event
        @event_info.refresh
      end
    else
      @event_info.close
    end
    
  end


end