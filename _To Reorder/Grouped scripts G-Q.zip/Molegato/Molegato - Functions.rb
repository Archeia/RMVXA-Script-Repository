#==============================================================================
# MOLEGATO FUNCTIONS
# Author Molegato
# Version 1.2.4
#------------------------------------------------------------------------------
# Several methods that I use in my scripts.
#------------------------------------------------------------------------------
# Included in some of my scripts. May be needed for those that dont include it
# in order to make them work.
#==============================================================================


#==============================================================================
# MOLEGATO Sprite_Base
#------------------------------------------------------------------------------
# Animation fixation plus afterimage_effect
#==============================================================================
class Sprite_Base < Sprite
  
  alias molegato_initialize initialize
  def initialize(viewport = nil)
    molegato_initialize(viewport)
    @past_info=[]
    @after_sprites=[]
    @afterimage=false
    @afterimage_options={}
    @afterimage_options[:max_images]=3
    @afterimage_options[:time]=10
    @afterimage_options[:color]=nil
    
    @afterimage_frame=0
  end
  
  alias molegato_update update
  def update
    molegato_update
    update_past_info
    update_afterimages if @afterimage
  end

  alias molegato_dispose dispose
  def dispose
    stop_afterimage
    molegato_dispose
  end
  
  def update_past_info
    data = {
      :x => x, :y => y, :ox => ox, :oy => oy, :z=>z-1,
      :zoom_x => zoom_x, :zoom_y => zoom_y,
      :opacity => opacity,
      :bitmap => bitmap, :src_rect => src_rect,
      :tone => tone, :color => color,
      :angle => angle,  :mirror => mirror,
      :wave_amp => wave_amp,
      :wave_length => wave_length,
      :wave_speed => wave_speed,
      :wave_phase => wave_phase,
      :viewport => viewport,
      :bush_depth => bush_depth, :bush_opacity => bush_opacity
    }
    if bitmap
      @past_info << data
    end
  end
  
  def update_afterimages
    for i in @after_sprites
      i.update
      if not i.animating?
        i.dispose
        @after_sprites.delete(i)
      end
    end
    
    if @afterimage_frame==0
      t=(-@afterimage_options[:time]/@afterimage_options[:max_images])
      @after_sprites.push(Sprite_afterimage.new(@past_info[t],@afterimage_options)) if not @past_info.empty?
    end
    @afterimage_frame+=1
    @afterimage_frame %= @afterimage_options[:time]
    @afterimage_frame %= (-@afterimage_options[:time]/@afterimage_options[:max_images])
  end
  
  def start_afterimage(max_images=3,time=10,color=nil,fade=0)
    stop_afterimage
    @afterimage_options[:max_images]=max_images
    @afterimage_options[:time]=time
    @afterimage_options[:color]=color
    @afterimage_options[:fade]=fade
    @afterimage=true
    @afterimage_frame=0
  end
  
  def stop_afterimage
    @afterimage=false
    for sprite in @after_sprites
      sprite.dispose
    end
    @after_sprites.clear
  end
  
  def afterimage?
    return @afterimage
  end
  
  alias molegato_update_animation update_animation
  def update_animation
    molegato_update_animation
    set_animation_origin if @animation
  end

  def set_bitmap_as_icon(icon_index)
    bitmap = Cache.system("Iconset")
    new_bitmap= Bitmap.new(24,24)
    rect = Rect.new(icon_index % 16 * 24, icon_index / 16 * 24, 24, 24)
    new_bitmap.blt(0, 0, bitmap, rect, 255)
    self.bitmap=new_bitmap
  end
end
#------------------------------------------------------------------------------
# Sprite_Afterimage
#------------------------------------------------------------------------------
class Sprite_afterimage < Sprite
  def initialize(data, options)
    super()
    self.bitmap=data[:bitmap]
    self.x=data[:x]
    self.ox=data[:ox]
    self.y=data[:y]
    self.oy=data[:oy]
    self.z=data[:z]
    self.zoom_x=data[:zoom_x]
    self.zoom_y=data[:zoom_y]
    self.opacity=data[:opacity]
    self.src_rect=data[:src_rect]
    self.tone=data[:tone]
    self.color=data[:color]
    self.angle=data[:angle]
    self.wave_amp=data[:wave_amp]
    self.wave_length=data[:wave_length]
    self.wave_speed=data[:wave_speed]
    self.wave_phase=data[:wave_phase]
    self.viewport=data[:viewport]
    self.bush_depth=data[:bush_depth]
    self.bush_opacity=data[:bush_opacity]
    @anime_time=options[:time]
        
    if options[:color]
      self.color=options[:color]
    end
    @fade=options[:fade]
  end
  
  def update
    super
    if @anime_time>0
      if @fade==0
        self.opacity = ( self.opacity * ( @anime_time - 1 )  ) / @anime_time
      else
        self.opacity=@fade
      end
      @anime_time-=1
    end
  end
  
  def animating?
    return (@anime_time>0)
  end
  
end

#==============================================================================
# MOLEGATO GAME_EVENT
#------------------------------------------------------------------------------
# Several methods for Game_Event
#==============================================================================
class Game_Event < Game_Character

  def note
    string_note=""
    
    return "" if not list
    
    for i in 0..list.size-1
      if list[i] and list[i].code==108
        string_note += list[i].parameters[0]
      end
    end
    return string_note
  end
  
end

#==============================================================================
# MOLEGATO BattleManager
#------------------------------------------------------------------------------
# Several methods for BattleManager
#==============================================================================
module BattleManager
  
  def self.action_battlers
    return @action_battlers
  end
  
  def self.delete_battler_from_turn(battler)
    @action_battlers.delete(battler)
  end
  
  def self.delete_dead_battlers
    for i in 0..@action_battlers.size-1
      if @action_battlers[i] && !@action_battlers[i].alive?
        @action_battlers.delete(@action_battlers[i])
      end
    end
  end
  
end

#==============================================================================
# MOLEGATO WINDOW BASE
#------------------------------------------------------------------------------
# Several methods for window_base
#==============================================================================

class Window_Base < Window
  def draw_face_scaled(face_name, face_index, x, y, scale,enabled = true)
    bitmap = Cache.face(face_name)
    rect = Rect.new(face_index % 4 * 96, face_index / 4 * 96, 96, 96)
    rect2 = Rect.new(x,y, 96*scale, 96*scale)
    contents.stretch_blt(rect2, bitmap, rect,enabled ? 255 : translucent_alpha)
    bitmap.dispose
  end
  
  def draw_actor_face_scaled(actor, x, y, scale, enabled = true)
    draw_face_scaled(actor.face_name, actor.face_index, x, y, scale, enabled)
  end
  
  def draw_system(name, x, y, ox=0,oy=0)
    bitmap = Cache.system(name)
    rect = Rect.new(0, 0, bitmap.width, bitmap.width)
    contents.blt(x-bitmap.width*ox, y-bitmap.height*oy, bitmap, rect, 255)
    vector=[x-bitmap.width*ox, y-bitmap.height*oy,x-bitmap.width*ox+bitmap.width, y-bitmap.height*oy+bitmap.height]
    return vector
  end
  
  def instant_close
    @openness=0
    @closing=false
    @opening=false
  end
  
  def instant_open
    @openness=255
    @closing=false
    @opening=false
  end  
  
end

#==============================================================================
# MOLEGATO TAG METHODS
#------------------------------------------------------------------------------
# Several methods for using tags. Needed by some of my scripts.
#==============================================================================

module MOLEGATO_TAG_METHODS
  def has_tag?(tag)
    if self.note[/<#{tag}>/mi]
      return true
    else
      return false
    end
  end
  
  def tag_check_value(tag) 
    if self.note[/<#{tag}: (.*?)>/mi]
      return $1
    else
      return false
    end
  end
  
  def tag_check_multivalues_note(tag)
    if self.note[/<#{tag}: (.*?)>/mi]
      return $1.split(',')
    else
      return false
    end
  end
   
  def tag_check_multivalues(string, tag)
    if string[/<#{tag}: (.*?)>/mi]
      return $1.split(',')
    else
      return false
    end
  end

  def tag_get_block(tag)
    if self.note[/<#{tag}>(.*?)<\\#{tag}>/mi]
      return $1
    else
      return false
    end
  end
  
  def tag_multiple(tag)
    if tag_get_block(tag)
      var=tag_get_block(tag)
      return var.split(';')
    else
      return false
    end
  end
  
  def tag_check_multiple_multivalues(tag)
    if tag_multiple(tag)
      array=[]
      tag_multiple(tag).each do |each|
        array.push(tag_check_multivalues(each,tag))
      end
      return array
    else
      return false
    end
  end
    
end

  #---For items/skills/actors/etc
  class RPG::BaseItem
    include MOLEGATO_TAG_METHODS
  end
  
  #---for maps
  class RPG::Map
    include MOLEGATO_TAG_METHODS
  end
  
  #---for events
  class Game_Event < Game_Character
    include MOLEGATO_TAG_METHODS
  end