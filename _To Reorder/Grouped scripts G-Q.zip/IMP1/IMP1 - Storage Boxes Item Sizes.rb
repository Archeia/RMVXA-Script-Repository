#==============================================================================
# Storage Boxes Addon: Item Sizes
#   by IMP1
#------------------------------------------------------------------------------
# THIS SCRIPT REQUIRES THE 'STORAGE BOXES' SCRIPT BY IMP1
#------------------------------------------------------------------------------
#   Compatability:
#
# Aliased Methods:
#   IMP1_Game_Boxes.fullness
#   IMP1_Game_Boxes.space_for
#   Scene_ItemStorage.can_move_item_to_inventory?
#   Window_BoxTitle.refresh
#
# New Methods/Fields:
#   Window_BoxTitle.draw_inventory_amount
#
# Overwritten Methods:
#   none.
#
#------------------------------------------------------------------------------
#   Version History:
# by vFoggy
# v1.4 [2017/10/05] : Added compatibility for gold withdrawal addon.
#
# by IMP1
# v1.3 [2015/06/27] : Use updates to base script.
# v1.2 [2014/11/16] : Fixed bug where inventory limit would not update.
# v1.1 [2014/11/15] : Added and displays the player inventory limit.
# v1.0 [2014/11/14] : Initial release.
#==============================================================================

#==============================================================================
# Game_Boxes
#==============================================================================
class IMP1_Game_Boxes
  #--------------------------------------------------------------------------
  # Returns the space in a box.
  #--------------------------------------------------------------------------
  # Changes:
  #   * Added condition, if item is :gold only 1 is added to the total size.
  #--------------------------------------------------------------------------
  alias :default_size_fullness :fullness unless $@
  def fullness(box_id)
    if $imported[:Theo_LimInventory]
      i = 0
      box(box_id).each do |item, amount|
        if item == :gold
          i += 1
        else
          i += item.inv_size * amount
        end
      end
      return i
    else
      return default_size_fullness(box_id)
    end
  end
  #--------------------------------------------------------------------------
  # Returns true if there is enough room for multiple items.
  #--------------------------------------------------------------------------
  # Changes:
  #   * Added condition, if the item is :gold the amount is set to 1 (gold
  #     counted as 1 in boxes).
  #--------------------------------------------------------------------------
  alias :default_size_space :space_for unless $@
  def space_for(item, amount, box)
    if $imported[:Theo_LimInventory]
      if item == :gold
        amount = 1
      else
        amount *= item.inv_size
      end
    end
    return default_size_space(item, amount, box)
  end
 
end # IMP1_Game_Boxes

#==============================================================================
# Scene_ItemStorage
#==============================================================================
class Scene_ItemStorage
  #--------------------------------------------------------------------------
  # Returns true if there is enough room in the player's inventory.
  #--------------------------------------------------------------------------
  # Changes (For gold withdrawal addon):
  #   * Added variable item_size that stores the size of the item. If it is
  #     :gold its size is set 0.
  #--------------------------------------------------------------------------
  alias :default_can_move? :can_move_item_to_inventory? unless $@
  def can_move_item_to_inventory?(item)
    return false if !default_can_move?(item)
    space_in_inventory = true
    if $imported[:Theo_LimInventory]
      item_size = item == :gold ? 0 : item.inv_size
      space_in_inventory =
          $game_party.total_inv_size + item_size < $game_party.inv_max
    end
    return space_in_inventory
  end
 
end # Scene_ItemStorage

#==============================================================================
# Window_BoxTitle
#==============================================================================
class Window_BoxTitle
  #--------------------------------------------------------------------------
  # Draws the contents.
  #--------------------------------------------------------------------------
  alias :non_limited_inventory_refresh :refresh unless $@
  def refresh(*args)
    non_limited_inventory_refresh(*args)
    if is_inventory_title?
      draw_inventory_amount
    end
  end
  #--------------------------------------------------------------------------
  # Displays how full the inventory is.
  #--------------------------------------------------------------------------
  def draw_inventory_amount
    if $imported[:Theo_LimInventory]
      text = "#{$game_party.total_inv_size}/#{$game_party.inv_max}"
      draw_text(0, 0, (Graphics.width/2)-32, line_height, text, 2)
    end
  end
 
end # Window_BoxTitle