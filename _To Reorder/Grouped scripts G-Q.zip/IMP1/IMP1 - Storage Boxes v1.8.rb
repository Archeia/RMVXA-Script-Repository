#==============================================================================
# Storage Boxes v1.8
#   by IMP1
#------------------------------------------------------------------------------
# Support can be found at
#   http://forums.rpgmakerweb.com/index.php?/topic/27727-storage-boxes
#------------------------------------------------------------------------------
# This script enables items to be depostied into (and withdrawn from) multiple 
# boxes in game.
#
#   Usage:
# In an event, use the following script commands:
#
#   SceneManager.call(Scene_ItemStorage)
#   SceneManager.scene.prepare(4)
# This will start the item storage scene with box 4.
#
#   SceneManager.call(Scene_ItemStorage)
#   SceneManager.scene.prepare(4, true)
# This will start the item storage scene with box 4, but the cursor will start
# in the box, rather than the party's items.
#
#   item = $data_items[7]
#   $game_boxes.box(2)[item] = 9
# This will make a new item (item with id 7) in box 2, and will set the amount 
# of that item in that box to 9.
#
#   item = $data_items[1]
#   $game_boxes.add_item(item, 5, 3, :all)
# This will add 5 of item with id 1 to box 3 if, and only if, there is room for 
# *all* of the items.
#
#   item = $data_items[1]
#   $game_boxes.add_item(item, 5, 3, :force)
# Unlike the previous script call, this will add the items regardless of how
# full the box is. This can mean a box has more items in it than its capacity
# allows for.
#
#   item = $data_items[1]
#   $game_boxes.add_item(item, 5, 3, :max)
# Unlike the previous two script calls, this will put in as many of that item 
# as it can, up to the amount specified.
#
# If you fail to specify :all, :force or :max, then it will default to :max.
#
# To stop an item from being stored, add <not storable> into its notebox.
#
# You can also use weapons and armours in the same way as items, changing 
# $data_items[1] to $data_weapons[1] or $data_armors[1].
#
#   item = $data_items[1]
#   $game_boxes.remove_item(item, 10, 3)
# This will attempt to remove 10 items from box 3. If there are fewer than 10, 
# then it won't do anything.
#
#   item = $data_items[1]
#   $game_boxes.remove_item(item, 10, 3, false)
# This is as above, but if there are fewer than 10 items, then it will remove
# them all.
#
#   $game_boxes.remove_all(5)
# This will remove all items from box 5.
#
#   item = $data_items[1]
#   $game_boxes.transfer(item, 10, 2, 3)
# This will transfer 10 items from box 2, to box 3. If there are fewer than 10
# items in box 2, or there isn't room for 10 items in box 3, then it won't do
# anything
#
#   item = $data_items[1]
#   $game_boxes.transfer(item, 10, 2, 3, :)

#
# To set up a box programmatically (if you don't want to have all your boxes
# typed out in a big list in this script), you can use the following script 
# command:
#
#   box_id = 300
#   name = "Closet"
#   size = 5
#   $game_boxes.setup(box_id, name, size)
# You can also add the opening and closing sounds after the size, in the same
# format as below, like so:
#
#   box_id = 300
#   name = "Closet"
#   size = 5
#   open_sound = {
#       name: "Open5",
#       volume: 80,
#       pitch: 100,
#   }
#   close_sound = {
#       name: "Open5",
#       volume: 80,
#       pitch: 60,
#   }
#   $game_boxes.setup(box_id, name, size, open_sound, close_sound)
# If you don't setup a box before opening it, it will have the default values 
# for all these parameters.
#
# To set up an item to have a different sound to the default when being 
# deposited or withdrawn, you can add <deposit sound: Bell1> into its notebox. 
# This example will make the item play the 'Bell1' sound when deposited, but 
# you can replace 'deposit sound' with 'withdraw sound', and 'Bell1' with any
# SE name.
#
#------------------------------------------------------------------------------
#   Compatability:
#
# Aliased Methods:
#   DataManager.create_game_objects
#   DataManager.make_save_contents
#   DataManager.extract_save_contents
#
# New Methods/Fields:
#   IMP1_Game_Boxes.*
#   Scene_ItemStorage.*
#   Window_ItemStorageLeft.*
#   Window_ItemStorageRight.*
#   Window_BoxTitle.*
#
# Overwritten Methods:
#   none.
#
#------------------------------------------------------------------------------
#   Version History:
# v1.8 [2017/04/02] : Boxes can be queried as to whether they contain certain 
#                     items. Also added transfering from and to the party's 
#                     inventory. Also made it more easily modable to be 
#                     compatible with limited inventory scripts.
# v1.7 [2016/01/27] : Boxes can be emptied and contents can be transfered.
# v1.6 [2015/06/27] : Boxes can be opened without having been setup previously.
#                     They can also be setup via script calls. Also general 
#                     refactoring of how boxes are accessed and setup.
# v1.5 [2014/11/17] : Fixed bug where default sound values were being edited.
# v1.4 [2014/11/16] : Added sounds upon opening and closing boxes, as well as
#                     withdrawing and depositing items.
# v1.3 [2014/11/16] : Fixed bug that would move from box to bag even if bag was
#                     selected. Also added methods for maintainability.
# v1.3 [2014/11/15] : Now allows for multiple lines of help window.
# v1.2 [2014/11/14] : Fixed bug where help window was not being refreshed.
# v1.1 [2014/11/14] : Fixed bug where 0 amount of an item would be added if
#                     there wasn't room for them all.
# v1.0 [2014/06/02] : Initial release.
#==============================================================================
$imported ||= {}
$imported[:IMP1_StorageBoxes] = 1.8

module IMP1_Storage_Boxes
#------------------------------------------------------------------------------
# CONFIGURATION BEGIN:
#------------------------------------------------------------------------------

  BOXES = [ # Do not remove.
    
    # This first Box has the ID 0. IDs go up by 1 with each box.
    {
        # The name of the box to be displayed (eg. crate, barrel, chest).
        name: "Drawer",
        # Size of the box (set to 0 for infinite).
        size: 15,
        # SE (Sound Effect) played when opening the box. If left black, the 
        # default will be used.
        open_sound: {
            name: "Open5",  # Name of SE
            volume: 80,     # Volume to play it at (0-100%)
            pitch: 100,     # Pitch to play it at (50-150%)
        },
        # Same as above, but played when closing the box.
        close_sound: {
            name: "Close1", # Name of SE
            volume: 80,     # Volume to play it at (0-100%)
            pitch: 100,     # Pitch to play it at (50-150%)
        },
    },
    
    {
        name: "Drawer",
        size: 20,
        # This will make no sound played (rather than the default) when this
        # box is opened.
        open_sound: {},
        # This will make no sound played (rather than the default) when this
        # box is closed.
        close_sound: {},
    },
    
    {
        name: "Bank",
        size: 0,
    },
    
    {
        name: "Jewelery Box",
        size: 10,
    },
  
  ]# Do not remove.
  
  # The default box name.
  DEFAULT_BOX_NAME = "Box"
  
  # The default box capacity.
  DEFAULT_BOX_SIZE = 20
  
  # The default SE (Sound Effect) to play when a box is opened, if one has not 
  # been specified for a box. Leave as {} if you want no sound to play.
  OPEN_SOUND = {} # This means no sound will play.
  # The same but for when the box is closed.
  CLOSE_SOUND = {
      name: "Applause1",      # Name of SE
      volume: 80,             # Volume to play it at (0-100%)
      pitch: 150,             # Pitch to play it at (50-150%)
  }
  
  # The default SE (Sound Effect) to play when an item is deposited, if one 
  # has not been specified for an item. Leave as {} if you want no sound to 
  # play.
  DEPOSIT_SOUND = {
      name: "Water2",         # Name of SE
      volume: 80,             # Volume to play it at (0-100%)
      pitch: 100,             # Pitch to play it at (50-150%)
  }
  # Same as above, but played when withdrawing an item
  WITHDRAW_SOUND = {
      name: "Book1",          # Name of SE
      volume: 80,             # Volume to play it at (0-100%)
      pitch: 150,             # Pitch to play it at (50-150%)
  }

  # Name of party's items to be displayed.
  PARTY_NAME = "Bag"
  
  # If this is true, key items cannot be stored in boxes. If false, only items
  # with <not storable> in their notebox cannot be stored.
  KEY_ITEMS_NOT_STORABLE = false
  
  # This will set how many lines of text the help window will be able to use.
  HELP_WINDOW_LINES = 2
  
#------------------------------------------------------------------------------
# CONFIGURATION END.
#------------------------------------------------------------------------------
end

#==============================================================================
# Game_Boxes
#==============================================================================
class IMP1_Game_Boxes
  include IMP1_Storage_Boxes
  #--------------------------------------------------------------------------
  # Creates the empty boxes.
  #--------------------------------------------------------------------------
  def initialize
    @boxes = []
  end
  #--------------------------------------------------------------------------
  # Returns box with the specified id, or returns a new, empty, default box.
  #--------------------------------------------------------------------------
  def setup(box_id, name=DEFAULT_BOX_NAME, size=DEFAULT_BOX_SIZE, 
            open_sound=nil, close_sound=nil)
    BOXES[box_id] = {
      name: name,
      size: size,
      open_sound: open_sound,
      close_sound: close_sound
    }
  end
  #--------------------------------------------------------------------------
  # Returns box with the specified id, or returns a new, empty, default box.
  #--------------------------------------------------------------------------
  def box(box_id)
    @boxes[box_id] ||= {}
    if BOXES[box_id].nil?
      setup(box_id)
    end
    return @boxes[box_id]
  end
  #--------------------------------------------------------------------------
  # Returns whether a box contains an item.
  #--------------------------------------------------------------------------
  def contains?(item_to_check, box_id)
    return item_number(item_to_check, box_id) > 0
  end
  #--------------------------------------------------------------------------
  # Checks how many of item there are in box_id.
  #--------------------------------------------------------------------------
  def item_number(item_to_check, box_id)
    return box(box_id)[item_to_check].to_i
  end
  #--------------------------------------------------------------------------
  # Adds amount to item in box.
  #--------------------------------------------------------------------------
  def add_item(item, amount, box_id, overfill=:max)
    if overfill == :force || space_for(item, amount, box_id)
      box(box_id)[item] ||= 0
      box(box_id)[item] += amount
    elsif overfill == :max
      box(box_id)[item] ||= 0
      box(box_id)[item] += capacity(box_id)
    end
  end
  #--------------------------------------------------------------------------
  # Removes amount from item in box.
  #--------------------------------------------------------------------------
  def remove_item(item, amount, box_id, fail_if_impossible=true)
    return if item_number(item, box_id) == 0
    if item_number(item, box_id) - amount < 0
      return if fail_if_impossible
      box(box_id)[item] = 0
    else
      box(box_id)[item] -= amount
    end
    @boxes[box_id].delete(item) if box(box_id)[item] == 0
  end
  #--------------------------------------------------------------------------
  # Removes all items from box.
  #--------------------------------------------------------------------------
  def remove_all(box_id)
    @boxes[box_id] = {}
  end
  #--------------------------------------------------------------------------
  # How much space the part's inventory has left.
  #--------------------------------------------------------------------------
  def party_inventory_space
    999_999_999
  end
  #--------------------------------------------------------------------------
  # Default method for whether the party has space for an item.
  #--------------------------------------------------------------------------
  def party_inventory_space_for(item, amount)
    true
  end
  #--------------------------------------------------------------------------
  # Moves items from one box to another.
  #--------------------------------------------------------------------------
  def transfer(item, amount, box_from, box_to, 
               overfill=:all, fail_if_impossible=true)
    if box_from == :party
      item_count = $game_party.item_number(item)
    else
      item_count = item_number(item, box_from)
    end
    amount_existing = [amount, item_count].min
    return false if fail_if_impossible and amount_existing < amount
    
    if box_to == :party
      item_space = party_inventory_space
      has_space = party_inventory_space_for(item, amount)
    else
      item_space = how_many_fit(item, box_to)
      has_space = space_for(item, amount_existing, box_to)
    end
    item_space = amount_existing if has_space
    return false if overfill == :all and !has_space
    amount = [amount_existing, item_space].min
    
    if box_from == :party
      $game_party.lose_item(item, amount)
    else
      remove_item(item, amount, box_from, fail_if_impossible)
    end
    if box_to == :party
      $game_party.gain_item(item, amount)
    else
      add_item(item, amount, box_to, overfill)
    end
    return true
  end
  #--------------------------------------------------------------------------
  # Moves all items from one box to another.
  #--------------------------------------------------------------------------
  def transfer_all(box_from, box_to, fail_type=:total, fail_condition=:any)
    box(box_from).each do |item, amount|
      success = transfer(item, amount, box_from, box_to, fail_condition)
      return if !success and fail_type == :total
    end
    # ~TODO: allow for overflow setting as well as fail_if_underflow.
    # ~TODO: allow for total fail rather than individual item fails.
  end
  #--------------------------------------------------------------------------
  # Returns how many of said item can fit into the box.
  #--------------------------------------------------------------------------
  def how_many_fit(item, box_id)
    return capacity(box_id)
  end
  #--------------------------------------------------------------------------
  # Returns true if there is enough room for multiple items.
  #--------------------------------------------------------------------------
  def space_for(item, amount, box_id)
    return (capacity(box_id) >= amount || BOXES[box_id][:size] == 0)
  end
  #--------------------------------------------------------------------------
  # Returns how full the box is.
  #--------------------------------------------------------------------------
  def fullness(box_id)
    i = 0
    box(box_id).each do |item, amount|
      i += amount
    end
    return i
  end
  #--------------------------------------------------------------------------
  # Returns the remaining space in a box.
  #--------------------------------------------------------------------------
  def capacity(box_id)
    return BOXES[box_id][:size] - fullness(box_id)
  end
  #--------------------------------------------------------------------------
  # Returns either the amount of items in a box, or a fraction of the amount 
  # in the box out of the box's capacity.
  #--------------------------------------------------------------------------
  def how_full(box_id, denom = true)
    i = fullness(box_id)
    return "#{i}/#{BOXES[box_id][:size]}" if denom
    return i.to_s
  end
  #--------------------------------------------------------------------------
  # Returns true if there's space in the box.
  #--------------------------------------------------------------------------
  def space?(box)
    return true if BOXES[box][:size] == 0
    return capacity(box) > 0
  end
  #--------------------------------------------------------------------------
  # Returns true if the box is full.
  #--------------------------------------------------------------------------
  def full?(box_id)
    return !space?(box_id)
  end
  #--------------------------------------------------------------------------
  # Returns true if the box is empty.
  #--------------------------------------------------------------------------
  def empty?(box_id)
    return box(box_id).empty?
  end
  
end # IMP1_Game_Boxes

#==============================================================================
# DataManager
#==============================================================================
class << DataManager
    #------------------------------------------------------------------------
    # Added boxes to created objects.
    #------------------------------------------------------------------------
    alias imp_create_storage_boxes create_game_objects unless $@
    def create_game_objects
      imp_create_storage_boxes
      $game_boxes = IMP1_Game_Boxes.new
    end
    #------------------------------------------------------------------------
    # Added boxes to saved objects.
    #------------------------------------------------------------------------
    alias imp_save_storage_boxes make_save_contents unless $@
    def make_save_contents
      contents = imp_save_storage_boxes
      contents[:imp_boxes] = $game_boxes
      contents
    end
    #------------------------------------------------------------------------
    # Added boxes to loaded objects.
    #------------------------------------------------------------------------
    alias imp_load_storage_boxes extract_save_contents unless $@
    def extract_save_contents(contents)
      imp_load_storage_boxes(contents)
      $game_boxes = contents[:imp_boxes]
    end
    
end # DataManager

#==============================================================================
# Scene_ItemStorage
#==============================================================================
class Scene_ItemStorage < Scene_MenuBase
  #--------------------------------------------------------------------------
  # Added to take box_id into account.
  #--------------------------------------------------------------------------
  def prepare(box_id, taking = false)
    @box_id = box_id
    @taking = taking
  end
  #--------------------------------------------------------------------------
  # Creates background and windows.
  #--------------------------------------------------------------------------
  def start
    super
    play_open_sound
    create_windows
  end
  #--------------------------------------------------------------------------
  # Creates windows.
  #--------------------------------------------------------------------------
  def create_windows
    @bag_window = Window_ItemStorageLeft.new
    @box_window = Window_ItemStorageRight.new(@box_id)
    @help_window = Window_Help.new(IMP1_Storage_Boxes::HELP_WINDOW_LINES)
    @bag_title = Window_BoxTitle.new(0, IMP1_Storage_Boxes::PARTY_NAME)
    @box_title = Window_BoxTitle.new((Graphics.width/2), 
            IMP1_Storage_Boxes::BOXES[@box_id][:name], @box_id)
    @box_window.help_window = @help_window
    @bag_window.help_window = @help_window
    @bag_window.help_window.back_opacity = 200
    @taking = false if $game_boxes.full?(@box_id)
    if @taking
      @box_window.activate.select_last
      @bag_window.deactivate.select_last
    else
      @bag_window.activate.select_last
      @box_window.deactivate.select_last
    end
  end
  #--------------------------------------------------------------------------
  # Frame update.
  #--------------------------------------------------------------------------
  def update
    super
    update_item_selection
  end
  #--------------------------------------------------------------------------
  # Update input.
  #--------------------------------------------------------------------------
  def update_item_selection
    if input_cancel
      play_close_sound
      return_scene
    elsif input_ok
      move_item
    elsif input_switch
      Sound.play_cursor
      switch_over
    end
  end
  #--------------------------------------------------------------------------
  # Input for cancelling scene.
  #--------------------------------------------------------------------------
  def input_cancel
    Input.trigger?(:B)
  end
  #--------------------------------------------------------------------------
  # Input for storing/retrieving.
  #--------------------------------------------------------------------------
  def input_ok
    Input.trigger?(:C)
  end
  #--------------------------------------------------------------------------
  # Input for switching between box and bag.
  #--------------------------------------------------------------------------
  def input_switch
    Input.trigger?(:LEFT) || Input.trigger?(:RIGHT)
  end
  #--------------------------------------------------------------------------
  # Switch active box.
  #--------------------------------------------------------------------------
  def switch_over
    if @bag_window.active
      @bag_window.deactivate
      @box_window.activate
    else
      @box_window.deactivate
      @bag_window.activate
    end
    @box_window.update_cursor
    @bag_window.update_cursor
    refresh_help_window
  end
  #--------------------------------------------------------------------------
  # Move item from one side to the other.
  #--------------------------------------------------------------------------
  def move_item
    withdrawn = deposited = false
    if @box_window.active && can_move_item_to_inventory?(@box_window.item)
      item = @box_window.item
      $game_boxes.remove_item(item, 1, @box_id)
      $game_party.gain_item(item, 1)
      play_withdraw_sound(item)
      withdrawn = true
    elsif @bag_window.active && can_move_item_to_box?(@bag_window.item)
      item = @bag_window.item
      $game_party.lose_item(item, 1)
      $game_boxes.add_item(item, 1, @box_id)
      play_deposit_sound(item)
      deposited = true
    end
    if !(withdrawn || deposited)
      Sound.play_buzzer
    end
    refresh
  end
  #--------------------------------------------------------------------------
  # Play a sound if it has a name that is not "".
  #--------------------------------------------------------------------------
  def play_sound(se)
    if se[:name] && se[:name] != ""
      Audio.se_play('Audio/SE/' + se[:name], se[:volume], se[:pitch])
    end
  end
  #--------------------------------------------------------------------------
  # Play the box's opening sound.
  #--------------------------------------------------------------------------
  def play_open_sound
    if !IMP1_Storage_Boxes::BOXES[@box_id].nil?
      se = IMP1_Storage_Boxes::BOXES[@box_id][:open_sound]
    end
    se ||= IMP1_Storage_Boxes::OPEN_SOUND
    play_sound(se)
  end
  #--------------------------------------------------------------------------
  # Play the box's closing sound.
  #--------------------------------------------------------------------------
  def play_close_sound
    se = IMP1_Storage_Boxes::BOXES[@box_id][:close_sound]
    se ||= IMP1_Storage_Boxes::CLOSE_SOUND
    play_sound(se)
  end
  #--------------------------------------------------------------------------
  # Play the item's deposit sound.
  #--------------------------------------------------------------------------
  def play_deposit_sound(item)
    se = IMP1_Storage_Boxes::DEPOSIT_SOUND
    if item.note.include?("<deposit sound:")
      se = se.dup
      se[:name] = item.note.scan(/<deposit sound: (.+)>/).flatten[0]
    end
    play_sound(se)
  end
  #--------------------------------------------------------------------------
  # Play the item's withdraw sound.
  #--------------------------------------------------------------------------
  def play_withdraw_sound(item)
    se = IMP1_Storage_Boxes::WITHDRAW_SOUND
    if item.note.include?("<withdraw sound:")
      se = se.dup
      se[:name] = item.note.scan(/<withdraw sound: (.+)>/).flatten[0]
    end
    play_sound(se)
  end
  #--------------------------------------------------------------------------
  # Returns true if item can be moved from the inventory to the box.
  #--------------------------------------------------------------------------
  def can_move_item_to_box?(item)
    if @bag_window.index < 0 or item.nil?
      return false
    elsif !$game_boxes.space?(@box_id) or !@bag_window.enable?(item)
      return false
    else
      return true
    end
  end
  #--------------------------------------------------------------------------
  # Returns true if item can be moved from the box to the inventory.
  #--------------------------------------------------------------------------
  def can_move_item_to_inventory?(item)
    if @box_window.index < 0 or item.nil?
      return false
    else
      return true
    end
  end
  #--------------------------------------------------------------------------
  # Refreshes windows.
  #--------------------------------------------------------------------------
  def refresh
    @box_window.refresh
    @bag_window.refresh
    @bag_title.refresh
    @box_title.refresh
    refresh_help_window
  end
  #--------------------------------------------------------------------------
  # Refreshes the help window
  #--------------------------------------------------------------------------
  def refresh_help_window
    @box_window.call_update_help
    @bag_window.call_update_help
  end
  #--------------------------------------------------------------------------
  # Termination Processing.
  #--------------------------------------------------------------------------
  def terminate
    super
    @bag_window.dispose
    @box_window.dispose
    @help_window.dispose
    @bag_title.dispose
    @box_title.dispose
  end
  
end # Scene_ItemStorage

#==============================================================================
# Window_Item_StorageLeft
#==============================================================================
class Window_ItemStorageLeft < Window_ItemList
  #--------------------------------------------------------------------------
  # Edited to make there only one column, to change the positioning and make 
  # it inactive by default.
  #--------------------------------------------------------------------------
  def initialize
    y_pos = fitting_height(IMP1_Storage_Boxes::HELP_WINDOW_LINES)
    y_pos += fitting_height(1)
    super(0, y_pos, Graphics.width/2, Graphics.height-y_pos)
    refresh
  end
  #--------------------------------------------------------------------------
  # Checks item for note
  #--------------------------------------------------------------------------
  def enable?(item)
    return !(item.note.include?("<not storable>") ||
      IMP1_Storage_Boxes::KEY_ITEMS_NOT_STORABLE && item.key_item?)
  end
  #--------------------------------------------------------------------------
  # Include all items
  #--------------------------------------------------------------------------
  def include?(item)
    !item.nil?
  end
  #--------------------------------------------------------------------------
  # * Number of columns
  #--------------------------------------------------------------------------
  def col_max
    return 1
  end
  #--------------------------------------------------------------------------
  # * If moved item over, select existing item
  #--------------------------------------------------------------------------
  def refresh
    super
    if @data[@index].nil?
      cursor_up(true)
    end
  end
  #--------------------------------------------------------------------------
  # * Get Number of Items
  #--------------------------------------------------------------------------
  def item_max
    @data ? [1, @data.size].max : 1
  end
  
end # Window_ItemStorageLeft

#==============================================================================
# Window_ItemStorageRight
#==============================================================================
class Window_ItemStorageRight < Window_ItemList
  attr_reader :data
  #--------------------------------------------------------------------------
  # Edited to make there only one column, to change the positioning and make 
  # it inactive by default.
  #--------------------------------------------------------------------------
  def initialize(box_id)
    @box_id = box_id
    y_pos = fitting_height(IMP1_Storage_Boxes::HELP_WINDOW_LINES)
    y_pos += fitting_height(1)
    super(Graphics.width/2, y_pos, Graphics.width/2, Graphics.height-y_pos)
    refresh
  end
  #--------------------------------------------------------------------------
  # Include all items
  #--------------------------------------------------------------------------
  def include?(item)
    !item.nil?
  end
  def enable?(item)
    true
  end
  #--------------------------------------------------------------------------
  # * Create Item List
  #--------------------------------------------------------------------------
  def make_item_list
    @data = $game_boxes.box(@box_id).keys.select {|item| include?(item) }
    @data.push(nil) if include?(nil)
  end
  #--------------------------------------------------------------------------
  # * Number of columns
  #--------------------------------------------------------------------------
  def col_max
    return 1
  end
  #--------------------------------------------------------------------------
  # * Draw Number of Items
  #--------------------------------------------------------------------------
  def draw_item_number(rect, item)
    draw_text(rect, sprintf(":%2d", $game_boxes.item_number(item, @box_id)), 2)
  end
  #--------------------------------------------------------------------------
  # * If moved item over, select existing item
  #--------------------------------------------------------------------------
  def refresh
    super
    if @data[@index].nil?
      cursor_up(true)
    end
  end
  #--------------------------------------------------------------------------
  # * Get Number of Items
  #--------------------------------------------------------------------------
  def item_max
    @data ? [1, @data.size].max : 1
  end

end # Window_ItemStorageRight

#==============================================================================
# Window_BoxTitle
#==============================================================================
class Window_BoxTitle < Window_Base
  #--------------------------------------------------------------------------
  # Initialization.
  #--------------------------------------------------------------------------
  def initialize(x, t, box = nil)
    y_pos = fitting_height(IMP1_Storage_Boxes::HELP_WINDOW_LINES)
    super(x, y_pos, Graphics.width/2, fitting_height(1))
    @box = box
    @title = t
    refresh
  end
  #--------------------------------------------------------------------------
  # Frame update.
  #--------------------------------------------------------------------------
  def update
    super
    if is_box_title?
      a = $game_boxes.how_full(@box, true) != @text 
      b = $game_boxes.how_full(@box, false) != @text
      if a and b
        refresh
      end
    end
  end
  #--------------------------------------------------------------------------
  # Draws the contents.
  #--------------------------------------------------------------------------
  def refresh
    self.contents.clear
    self.contents.draw_text(0, 0, (Graphics.width/2)-32, line_height, @title)
    if is_box_title?
      draw_box_amount(IMP1_Storage_Boxes::BOXES[@box][:size] != 0)
    end
  end
  #--------------------------------------------------------------------------
  # Displays how full the box is.
  #--------------------------------------------------------------------------
  def draw_box_amount(draw_maximum)
    text = $game_boxes.how_full(@box, draw_maximum)
    draw_text(0, 0, (Graphics.width/2)-32, line_height, text, 2)
  end
  #--------------------------------------------------------------------------
  # Returns whether this instance is the title of a box.
  #--------------------------------------------------------------------------
  def is_box_title?
    return !@box.nil?
  end
  #--------------------------------------------------------------------------
  # Returns whether this instance is the title of the player's inventory.
  #--------------------------------------------------------------------------
  def is_inventory_title?
    return @box.nil?
  end

end # Window_BoxTitle