#=============================================================================
#
# * "Shared Storage Boxes" Addon for IMP1's "Storage Boxes" Script
#   Version 1.01 (February 2nd, 2018)
#   by Another Fen <forums.rpgmakerweb.com>
#
# Contents: ------------------------------------------------------------------
#   Allow certain storage boxes to be "shared" and carry over their contents
#   between all savestates. Boxes are updated whenever the game is saved.
#   Shared storage boxes can be configured below.
#
#   This script should be placed below IMP1's "Storage Boxes" script, which
#   can be found here:
#     http://forums.rpgmakerweb.com/index.php?/topic/27727-storage-boxes
#
#=============================================================================

# ---------------------------------------------------------------------------
#  IL_Shared_Storage
#    Handles Shared Box Saving.
# ---------------------------------------------------------------------------
module IL_Shared_Storage
 
  BOXES = [1, 2]                             # IDs of shared storage boxes
  NORMAL_FILENAME = "SharedStorage.rvdata2"  # Shared Storage Filename
  BACKUP_FILENAME = "SharedStorage.tmp"      # Backup Filename
 
 
  def load_shared_storage
    contents = load_shared_storage_data rescue nil
    BOXES.each_with_index do |box_id, index|
      $game_boxes.remove_all(box_id)
      next unless contents && contents[index]
      contents[index].each_item do |item, amount|
        $game_boxes.add_item(item, amount, box_id, :force)
      end
    end
  end
 
  def load_shared_storage_data
    if File.exists?(BACKUP_FILENAME)
      begin
        backup = File.open(BACKUP_FILENAME, "rb") { |file| Marshal.load(file) }
      rescue
        # Continue (Corrupt Backup)
      end
      if backup
        File.open(NORMAL_FILENAME, "wb") { |file| Marshal.dump(backup, file) }
        File.delete(BACKUP_FILENAME)
        return backup
      end
    end
    if File.exists?(NORMAL_FILENAME)
      return File.open(NORMAL_FILENAME, "rb") { |file| Marshal.load(file) }
    else
      return nil
    end
  end
 
  def save_shared_storage
    contents = BOXES.map do |box_id|
      next Storage_Box.new($game_boxes.box(box_id).each_pair)
    end
    save_shared_storage_data(contents) rescue nil
  end
 
  def save_shared_storage_data(contents)
    buffer = Marshal.dump(contents)
    File.open(BACKUP_FILENAME, "wb") { |file| file.write(buffer) }
    File.open(NORMAL_FILENAME, "wb") { |file| file.write(buffer) }
    File.delete(BACKUP_FILENAME)
  end
end


# ---------------------------------------------------------------------------
#  IL_Shared_Storage::Storage_Box
#   Holds serializable contents of a storage box
# ---------------------------------------------------------------------------
class IL_Shared_Storage::Storage_Box
 
  Item_Key = Struct.new(:type, :id)
 
  def initialize(enum = nil)
    @contents = Array.new
    enum.each { |item, amount| add(item, amount) }  if enum
  end
 
  def add(item, amount)
    @contents.push(key_for(item), amount)  if item
  end
 
  def each_item
    @contents.each_slice(2) { |key, amount| yield(item_for(key), amount) }
  end
 
  def key_for(item)
    case item
    when RPG::Item   then type = :item
    when RPG::Armor  then type = :armor
    when RPG::Weapon then type = :weapon
    else raise "Unexpected Item:\n#{item}"
    end
    return Item_Key.new(type, item.id)
  end
 
  def item_for(key)
    case key.type
    when :item   then set = $data_items
    when :armor  then set = $data_armors
    when :weapon then set = $data_weapons
    else raise "Unexpected Key:\n#{key}"
    end
    return set[key.id]
  end
end


# ---------------------------------------------------------------------------
#  class of DataManager *Modified*
#    Synchronize the Shared Storage on Load/Save
# ---------------------------------------------------------------------------
class << DataManager
  include IL_Shared_Storage
 
  alias_method(:create_game_objects_ILC_sharedStorage, :create_game_objects)
  def create_game_objects
    create_game_objects_ILC_sharedStorage
    load_shared_storage
  end
 
  alias_method(:load_game_ILC_sharedStorage, :load_game)
  def load_game(index)
    success = load_game_ILC_sharedStorage(index)
    load_shared_storage  if success
    return success
  end
 
  alias_method(:save_game_ILC_sharedStorage, :save_game)
  def save_game(index)
    success = save_game_ILC_sharedStorage(index)
    save_shared_storage  if success
    return success
  end
end