# ---------------------------------------------------------------------------
# Scene_ItemStorage *Modified*
#   Fix for gold withdrawal / item pickup with limited inventory size
# ---------------------------------------------------------------------------
class Scene_ItemStorage

  # Modified Method from IMP1's "Item Sizes" script
  # (including vFoggy's gold withdrawal edit)
  # - Gold should no longer regard inventory size at all
  # - Picking up an item may completely fill inventory
  def can_move_item_to_inventory?(item)
    return false unless default_can_move?(item)
    return true  unless $imported[:Theo_LimInventory]
    return true  if item == :gold
    return $game_party.total_inv_size + item.inv_size <= $game_party.inv_max
  end
end