#==============================================================================
# Storage Boxes Addon: Item Types
#   by IMP1
#------------------------------------------------------------------------------
# THIS SCRIPT REQUIRES THE 'STORAGE BOXES' SCRIPT BY IMP1
#
# Now items can only be put in a box if that box allows that type of item.
# You can give a type to an item with the notetag <item type: Clothing> in the
# items notebox (replacing Clothing with whatever types you want).
# To specify that a box can handle items of a type, or can handle all types
# except a few, see below.
#
#------------------------------------------------------------------------------
#   Compatability:
#
# Aliased Methods:
#   IMP1_Game_Boxes.setup
#   Scene_ItemStorage.can_move_item_to_box?
#
# New Methods/Fields:
#   Scene_ItemStorage.item_goes_in_box?
#
# Overwritten Methods:
#   none.
#
#------------------------------------------------------------------------------
#   Version History:
# v1.0 [2015/06/27] : Initial release.
#==============================================================================

module IMP1_Storage_Boxes
#------------------------------------------------------------------------------
# CONFIGURATION BEGIN:
#------------------------------------------------------------------------------

  # If this is set to true, and you haven't specified the allowed types for the 
  # box, all items will be allowed. If it is set to false, no items will be 
  # allowed.
  ALLOWED_BY_DEFAULT = true

  BOX_TYPES = { # Do not remove.
  
    # To allow a box to take all items, have the following:
    # id => :all,
    
    # To have a box accept ONLY the specified item types, have the following:
    # id => [:only, "Item Type 1", "Item Type 2"],
    
    # To have a box accept all item types EXCEPT some, have the following:
    # id => [:all_but, "Item Type 1", "Item Type 2"],
    
    # The first box will take everything
    0 => :all,
    
    # The fourth will be a jewelery box (eg. and so only take jewelery)
    3 => [:only, "Jewelery"],
    
    # The fourth will be a microwave (eg. and so can't take metal)
    4 => [:all_but, "Metal"],
  
  } # Do not remove.
  
#------------------------------------------------------------------------------
# CONFIGURATION END.
#------------------------------------------------------------------------------
end
#==============================================================================
# Game_Boxes
#==============================================================================
class IMP1_Game_Boxes
  #--------------------------------------------------------------------------
  # Returns box with the specified id, or returns a new, empty, default box.
  #--------------------------------------------------------------------------
  alias :non_type_setup :setup unless $@
  def setup(box_id, name=DEFAULT_BOX_NAME, size=DEFAULT_BOX_SIZE, 
            open_sound=nil, close_sound=nil, type=nil)
    non_type_setup(box_id, name, size, open_sound, close_sound)
    if !type.nil?
      BOX_TYPES[box_id] = type
    end
  end
  
end # IMP1_Game_Boxes

#==============================================================================
# Scene_ItemStorage
#==============================================================================
class Scene_ItemStorage
  #--------------------------------------------------------------------------
  # Returns true if item can be moved from the inventory to the box.
  #--------------------------------------------------------------------------
  alias :non_type_check :can_move_item_to_box? unless $@
  def can_move_item_to_box?(item)
    return false if !non_type_check(item)
    return item_goes_in_box?(item)
  end
  #--------------------------------------------------------------------------
  # Returns true the item is of the right type for this box.
  #--------------------------------------------------------------------------
  def item_goes_in_box?(item)
    if !IMP1_Storage_Boxes::BOX_TYPES.has_key?(@box_id)
      return IMP1_Storage_Boxes::ALLOWED_BY_DEFAULT
    end
    box_types = IMP1_Storage_Boxes::BOX_TYPES[@box_id]
    return true if box_types == :all
    if box_types[0] == :only
      looking_for = true
    elsif box_types[0] == :all_but
      looking_for = false
    else
      error = "You've not set the permissions for box number #{@box_id}" + 
              "correctly. The list must start with either :only or :all_but"
      msgbox(error)
      return IMP1_Storage_Boxes::ALLOWED_BY_DEFAULT
    end
    for item_type in item.note.scan(/<item type: (.+)>/).flatten
      return looking_for if box_types.include?(item_type)
    end
    return !looking_for
  end
  
end # Scene_ItemStorage