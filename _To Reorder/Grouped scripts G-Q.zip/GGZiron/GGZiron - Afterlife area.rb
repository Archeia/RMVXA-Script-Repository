module AfterLife # do not touch this line
 
=begin
==============================================================================
                        Script's Header
==============================================================================

 Script's Name: AfterLife Handler
 Script's Author: GGZiron
 Terms of use: Free for commercial and non commercial projects.
 Credit me (GGZiron).
 Version: 0.1 Beta
 
=============================================================================
                          About The Script
=============================================================================
 This script gives the option for alternative handling instead Game Over,
 when losing battle. When losing battle, instead game over, the player
 will be moved to "afterlife" area, and the party will be replaced by actor,
 which will represent a "Ghost". There are few settings that must be done
 for the script to work, and few script calls as well.
 
 The afterlife handler will NOT activate on evented battle, that have
 "Continue Even When Loser" handler. My logic is, that if party can lose,
 then it doesn't die. If doesn't die, no need of afterlife handler.
 
=end
#============================================================================
#                            Settings:
#                Do not skip them! It won't work if you do.
#============================================================================
module Settings #do not touch this line
   
# Set the AfterLife handling enabler switch. By default that is Switch 100.
# For the AfterLife handler to activate, this switch must be on.

  SWITCH_ID = 100 # Default is Switch ID 100
 
# The AfterLife handler will replace the active party with actor, which
# represent a ghost.
  GHOST_ACTOR_ID = 1 # Set the actual Ghost's id
 
end #do not touch this line

# That are all the settings(for now).
 
#============================================================================
#                       Important Script Calls                      
#============================================================================
=begin
 
 For the afterlife handler to work properly, you must set the afterlife
 destination via script calls. Once set, it will remain until you set it
 again with the same script calls. Not setting the afterlife destination
 before the afterlife handler is activated will lead to error message and
 game crash.
 
 Setting the Destination Map:
 $game_party.al_destination[:map_id] = map_id
 
 You must replace the map_id with the desired map id number.
 Example Use: $game_party.al_destination[:map_id] = 3
 With the example, the afterlife map ID is set to 3.
 
 Now, you must set the x and y coordinates, and optionally, the direction
 the player is going to face once moved to afterlife area.
 Not doing that still will lead to crash!
 
 Setting the destination x coordinate:
 $game_party.al_destination[:x] = desired_x_coordinate
 Example Use:  $game_party.al_destination[:x] = 5
 
 Setting the destination y coordinate:
 $game_party.al_destination[:y] = desired_y_coordinate
 Example Use:  $game_party.al_destination[:y] = 5
 
 Setting the destination facing direction:
 $game_party.al_destination[:direction] = direction #2, 4, 6 or 8
 Example Use:  $game_party.al_destination[:y] = 8
 With the example use, the player will be set to face up direction.
 This is the only script call you can skip, as the direction value
 is initialized with value 2 - facing down.
 Reminding: 2 = Facing Down, 4 = Facing Left, 6 = Facing Right, 8 = Facing Up.

 If you want to recollect your party, and get rid of the "Ghost",
 use this script call:
 
 $game_party.install_banked_party
 
 What this does is to remove current party(assumed that ll be the ghost),
 and adds the party members, that were in the last lost battle.
 
 Next script call:
 AfterLife.to_death_location
 
 It will transfer the party to the exact location (always facing down),
 where the said party lost last battle. The ussage of this script call
 without death location setted(it will set by this script when party loses
 battle) will lead to game crash. Make sure this doesn't happen.
 
 Since I mentioned last lost battle, I mean battles which game over sequence
 where canceled by this script. For example, evented battle with "can lose"
 handler doesn't count.
 
 All transfers done by my script are instant. Will see if can add some fading
 options. If not, the screen could be faded in and out via event.
 
=============================================================================
                    Additional Script Calls
=============================================================================                  
 
 AfterLife.to_afterlife_area
 
 This script call will transfer you to the setted by you after life area.
 You do not need to use it for the after life handler, but if by some
 reason you would want party to go in afterlife area (like, it died in cut
 scene instead battle), or simply "visiting". Will crash if the after life
 destination is not set.
 
 Since I mentioned about going "Afterlife mode" outside battle, I decided
 the provide all the means for it.
 
 AfterLife.set_party_hp(hp)
 This will set all party members hp to the said value, as long it does not
 go above max hp of the respective members. Used to set them to 1, if
 they die after cut scene.
 
 AfterLife.bank_party
 It "banks" the current party members, so later player can take them
 bank in party.
 
 $game_party.remove_entire_party
 Removes the entire current party.

 AfterLife.add_ghost
 Adds the "Ghost" member.
 
=end

#============================================================================
#                        Do not touch anything bellow,
#                unless you understand the code or/and feel brave.
#============================================================================



  def self.to_afterlife_area(destination = $game_party.al_destination)
    map_id = destination[:map_id]
    x = destination[:x]
    y = destination[:y]
    direction = destination[:direction]
    $game_player.reserve_transfer(map_id, x, y, direction)
    $game_player.perform_transfer
  end
 
  def self.to_death_location
    to_afterlife_area($game_party.death_location)
  end
 
  def self.set_party_hp(hp = 1)
    $game_party.all_members.each_with_index do |member, index|
      member.hp = hp
    end        
  end
 
  def self.bank_party
    $game_party.all_members.each_with_index do |member, index|
      $game_party.banked_party[index] = member.id
    end    
  end
 
  def self.add_ghost
     $game_party.add_actor(Settings::GHOST_ACTOR_ID)
  end
 
end

class Game_Party < Game_Unit
 
  attr_accessor :al_destination, :death_location, :banked_party
  alias_method :initialize_z001231, :initialize
 
  def initialize
    initialize_z001231
    init_afterlife_destination
    @death_location = {}
    @banked_party = []
  end
 
  def init_afterlife_destination
    @al_destination = {}
    @al_destination[:direction] = 2
  end
 
  def remove_entire_party
    @actors = []
    $game_player.refresh
    $game_map.need_refresh = true
  end
 
  def install_banked_party
    remove_entire_party
    @banked_party.each do |member_index|
      $game_party.add_actor(member_index)
    end
  end

end

module BattleManager

  class << self
    alias_method :process_defeat_z001231, :process_defeat
  end    
 
  def self.process_defeat
    if $game_switches[AfterLife::Settings::SWITCH_ID] && !@can_lose
      $game_message.add(sprintf(Vocab::Defeat, $game_party.name))
      wait_for_message
      revive_battle_members
      replay_bgm_and_bgs
      SceneManager.return
      battle_end(2)
      AfterLife.set_party_hp
      AfterLife.bank_party
      $game_party.death_location[:map_id] = $game_map.map_id
      $game_party.death_location[:x] = $game_player.x
      $game_party.death_location[:y] = $game_player.y
      $game_party.death_location[:direction] = 2
      AfterLife::to_afterlife_area
      $game_party.remove_entire_party
      AfterLife.add_ghost
      return true
    end
    process_defeat_z001231
  end
 
end
#================================ End Of File ===============================