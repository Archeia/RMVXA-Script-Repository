module Scrolling_Battkeback
 
#=============================================================================
#                         SCRIPT'S HEADER                         
#=============================================================================

# Author: GGZiron
# The script is made for: RPG Maker VXAce
# Script's name: Scrolling Battlebacks
# Script's version: 1.0.1
# Date or release 2 June 2018
# Temrs: Free to use for comercial and non comercial projects,
# as long credits are given to GGZiron.

# Changelog: On the initial version forgot to add disposing method for the
# new background.

#=============================================================================

#                          About the script

# It allows the game developer to set scrolling battleback.
# The battleback  scrolls only on two directions - foward and backward.
# It does not overwrite the default battleback, it goes above it.
# You can set many pictures, but only one can be used at time.

#=============================================================================
#                             How to use
#=============================================================================

# You can set multiple pictures.
# The pictures, that you are going to use, must be in Battlebacks 1 Folder

BATTLEBACKS = {
#The key values must start from 1, and be in ascending order.
# 1=>  - That's how it looks a key value I talk about.
  1=> {
     :Name => "filename.png",   #replace filename png with the actual filename.
     :Speed => 4, # bigger the number, faster the picture will move.
     :Direction => 0,  # 0 = moving foward, any other value - moving backward
     :Opacity => 255, # Set transparency. Range from 255 to 0
     :Alpha_Color => 0, # How iluminated to light is the picture.
                        # When 0: Fully illuminated. When 255: Black.
     },

# Second entry. Delete all its lines, if you are not going to use.   
 2=> {
     :Name => "filename.png",
     :Speed => 1,
     :Direction => 1,  
     :Opacity => 255,
     :Alpha_Color => 0,
     }, # if you are deleting this entry, delete this line too.

# Add more entries if you need, following the patern above.

     
} # Do not touch this. Do not add more battleback entries after this line

# Here you set which $game_variable (the ones used in Event commands) is going
# to linked with the used battleback.
# With the default GAME_VARIABLE_LINK link value, you will have to set
# Variable 100 from the Event editor to which key value will link.
# Keep it zero, if you don't want scrolling battlebacks

GAME_VARIABLE_LINK = 100

# The script will give error message if the variable links to incorect entry.
 
end

#============================================================================
#                         The boring part of the script.
#                      Don't edit it unless you understand it!
#============================================================================

class Spriteset_Battle
#============================================================================  
#                           Edited  Methods
#============================================================================
  alias_method :initialize_original, :initialize
 
  def initialize
    initialize_original
    create_animated_battleback
  end
 
   alias_method :update_original, :update
 
  def update
    update_original
    refresh_animated_battleback
  end
 
  alias_method :dispose_original, :dispose
 
  def dispose
    dispose_original
    dispose_animated_battleback
  end
 
#============================================================================  
#                           New  Methods
#============================================================================
 
  def create_animated_battleback
    variable_id = Scrolling_Battkeback::GAME_VARIABLE_LINK
    variable_value = $game_variables[variable_id]
    return if variable_value == 0
    if !Scrolling_Battkeback::BATTLEBACKS[variable_value]
      msgbox "Scrolling Battlebacks's script: Incorect Entry. Please, check the script's settings!"  
      exit
    end
    picture_name = Scrolling_Battkeback::BATTLEBACKS[variable_value][:Name]
    @scrolling_speed = Scrolling_Battkeback::BATTLEBACKS[variable_value][:Speed]
    direction = Scrolling_Battkeback::BATTLEBACKS[variable_value][:Direction]
    opacity = Scrolling_Battkeback::BATTLEBACKS[variable_value][:Opacity]
    alpha = Scrolling_Battkeback::BATTLEBACKS[variable_value][:Alpha_Color]
    @moving_background1 = Sprite.new(@viewport1)
    @moving_background2 = Sprite.new(@viewport1)
    @moving_background1.opacity = opacity
    @moving_background2.opacity = opacity
    @moving_background1.color.alpha = alpha
    @moving_background2.color.alpha = alpha
    @moving_background1.bitmap = Cache.battleback1(picture_name)
    @moving_background2.bitmap = Cache.battleback1(picture_name)
    @moving_background1.z = 2
    @moving_background2.z = 2
    width = @moving_background1.width
    if direction == 0
      @moving_background2.x = @moving_background1.x - width
    else
      @moving_background2.x = @moving_background1.x + width
      @scrolling_speed = -@scrolling_speed
    end  
  end
 
  def refresh_animated_battleback
    return if !@moving_background1 || !@moving_background2
    x1 = @moving_background1.x; x2 =@moving_background2.x
     x1 += @scrolling_speed; x2 += @scrolling_speed
    width1 = @moving_background1.width
    width2 = @moving_background2.width
    if @scrolling_speed > 0
      x1 = x2 - width2 if x1 > Graphics.width
      x2 = x1- width1 if x2 > Graphics.width
    else
      x2 = x1 + width1 if x2 + width2 < 0
      x1 = x2 + width2 if x1 + width1 < 0   
    end  
    @moving_background1.x = x1
    @moving_background2.x = x2
  end
 
  def dispose_animated_battleback
    @moving_background1.bitmap.dispose
    @moving_background2.bitmap.dispose
    @moving_background1.dispose
    @moving_background2.dispose
  end  
 
end