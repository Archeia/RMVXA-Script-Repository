($imported ||= {})[:Ziron_AfterLife_Handler] = true

module AfterLife # do not touch this line
 
=begin
==============================================================================
                        Script's Header
==============================================================================

 Script's Name: AfterLife Handler
 Script's Author: GGZiron
 Terms of use: Free for commercial and non commercial projects.
 Credit me (GGZiron).
 Version: 1.2
 
 Changes with Version 1.1:
  *Now the transfer after the script call "AfterLife.to_death_location"
 changes the party on mid transfer. For that, I rewrote the transfer
 method, because the changes are on the middle of the method.
 The original transfer method is aliased, and used instead the modifed, when
 the party is not going to be changed mid way. So, the normal transfer via the
 event editor command, and any other that doesn't come from
 "AfterLife.to_death_location", should work as before.
  *Added my script name into the "$imported" hash, that is used by many scripts.
  *Minor edits here and there.
 
 Changes with Version 1.2
  *Now the "after life" area coordinates are set via game variables.
 Check the new settings options.
  *Changed the way some methods work.
  *Removed methods and script calls that won't be needed anymore.
  *Edited the documentation bellow.
 
=============================================================================
                          About The Script
=============================================================================
 This script gives the option for alternative handling instead Game Over,
 when losing battle. When losing battle, instead game over, the player
 will be moved to "afterlife" area, and the party will be replaced by actor,
 which will represent a "Ghost". There are few settings that must be done
 for the script to work, and few script calls as well.
 
 The afterlife handler will NOT activate on evented battle, that have
 "Continue Even When Loser" handler. My logic is, that if party can lose,
 then it doesn't die. If doesn't die, no need of afterlife handler.
 
 Warning: This script is not set to work on ABS battle systems.
 It may not work with all battle systems.
 
=end
#============================================================================
#                            Settings:
#                Do not skip them! It won't work if you do.
#============================================================================
module Settings #do not touch this line
    
# Set the AfterLife handling enabler switch. By default that is Switch 100.
# For the AfterLife handler to activate, this switch must be on.

  SWITCH_ID = 100 # Default is Switch ID 100
 
# The AfterLife handler will replace the active party with actor, which
# represent a ghost.
  GHOST_ACTOR_ID = 10 # Set the actual Ghost's id
 
# Define how fast will fade out the battle scene that will lead to
# afterlife area
  FADE_OUT_SPEED = 5 # Bigger number, faster it fades
 
# Once the lost battle fades out, it will wait as many frames as you set here.
# In default frame rate 60 frames = 1 second.
  WAIT_AFTER_FADE_IN = 120 # Wait 2 seconds on default settings

# Option to block menu access when in ghost form.
  MENU_ACCESS = true # True is menu blocked, false is not blocked
 
# Now, here you must determinate which Game Variables ID will hold
# the afterlife coordinates

  MAP_ID = 101 # Map_Id value gonna be held by Game Variable 101
 
  X = 102 # X value gonna be held by Game Variable 102
 
  Y = 103 # Y value gonna be held by Variable 103
 
  DIR = 2
# Direction value will not be held by any variable, and thus, will be always
# with default value 2 (facing gown).
# Reminding: 2 = Facing Down, 4 = Facing Left, 6 = Facing Right, 8 = Facing Up. 
 
 
end #do not touch this line

# That are all the settings.
 
#============================================================================
#                       Important Script Calls                       
#============================================================================
=begin
 
 For the afterlife handler to work properly, you must set the afterlife
 destination via Game Variables. Check and set in the Settings header which
 coordinate is linked to which Game Variable.
 Not setting properly the afterlife destination before the afterlife handler
 is activated will lead to error message and game crash.
 
 
 If you want to recollect your party, and get rid of the "Ghost",
 use this script call:
 
 $game_party.install_banked_party
 
 What this does is to remove current party(assumed that ll be the ghost),
 and adds the party members, that were in the last lost battle.
 After version 1.1, this is part of the script call, that transfers
 the party to the death spot location(see it bellow).
 
 AfterLife.to_death_location(fade_in)
 Replace fade_in with:
 0 for normal fade in
 1 for white fade in
 2 for instant transfer
 
 Alternatively, you can use this:
 AfterLife.to_death_location
 Which will lead to instant transfer too.
 
 It will transfer the party to the exact location (always facing down),
 where the said party lost last battle. The ussage of this script call
 without death location setted(it will set by this script when party loses
 battle) will lead to game crash. Make sure this doesn't happen.
 
 Since I mentioned last lost battle, I mean battles which "Game Over" sequence
 was canceled by this script. For example, evented battle with "can lose"
 handler doesn't count.
 
 After version 1.1 , the script call "AfterLife.to_death_location(fade_in)"
 also automatically install the banked party and removes the ghost during
 mid transfer. If you want to go to the death location with the Ghost party,
 or do your own indepedent party handling, use this:
 AfterLife.to_death_location(fade_in, false)
 
 If you want to extract deathspot coordinates into variables, use this:
 AfterLife.extract_deathspot_cord(map_id, x, y)
 Here the specific is that this script call does not transfer, but store
 the destination info into game variables. Replace map_id, x and y wiith
 the id of desired game variables.
 Example use:
 AfterLife.extract_deathspot_cord(1, 2, 3)
 This call will write on Variable 1 the value of map id, on variable 2 the value
 of x coordinate, and on variable 3 the valye of y coordinate.
 Once that done, all you must do is to set transfer with event command, using
 the respective variables you set on this script call.
 
=============================================================================
                    Additional Script Calls
=============================================================================                   
 
 AfterLife.to_afterlife_area
 
 This script call will transfer you to the setted by you after life area.
 You do not need to use it for the after life handler, but if by some
 reason you would want party to go in afterlife area (like, it died in cut
 scene instead battle), or simply "visiting". Will crash if the after life
 destination is not set.
 
 AfterLife.to_afterlife_area(fade_type)
 
 Same like the script call above, only that here you can also add the fade time:
 0 = black fade out, 1 = white fade out, 2 = instant fade out.
 
 Since I mentioned about going "Afterlife mode" outside battle, I decided
 the provide all the means for it.
 
 AfterLife.set_party_hp(hp)
 This will set all party members hp to the said value, as long it does not
 go above max hp of the respective members.
 
 AfterLife.bank_party
 It "banks" the current party members, so later player can take them
 bank in party.
 
 $game_party.remove_entire_party
 Removes the entire current party.

 AfterLife.add_ghost
 Adds the "Ghost" member.
 
=end

#============================================================================
#                        Do not touch anything bellow,
#                unless you understand the code or/and feel brave.
#============================================================================


class << self; attr_accessor :party_install; end

  @party_install = false
 
  def self.get_al_destination
    al_destination = {}
    al_destination[:map_id] = $game_variables[Settings::MAP_ID]
    al_destination[:x] = $game_variables[Settings::X]
    al_destination[:y] = $game_variables[Settings::Y]
    al_destination[:direction] = [2, 4 ,6 ,8].include?($game_variables[Settings::DIR]) ? $game_variables[Settings::DIR] : 2
    return al_destination
  end 

  def self.extract_deathspot_cord(map_id, x, y)
    destination = $game_party.death_location
    $game_variables[map_id] = destination[:map_id]
    $game_variables[x] = destination[:x]
    $game_variables[y] = destination[:y]
  end
 
  def self.to_afterlife_area(fade_type = nil, destination = get_al_destination)
    map_id = destination[:map_id]
    x = destination[:x]; y = destination[:y]
    direction = destination[:direction]
    $game_player.reserve_transfer(map_id, x, y, direction)
    fade_type ? $game_temp.fade_type = fade_type : $game_player.perform_transfer
  end
 
  def self.to_death_location(fade_type = 0, party_install = true)
    @party_install = party_install
    to_afterlife_area(fade_type, $game_party.death_location)
  end
 
  def self.set_party_hp(hp = 1)
    $game_party.all_members.each_with_index do |member, index|
      member.hp = hp
    end         
  end
 
  def self.bank_party
    $game_party.all_members.each_with_index do |member, index|
      $game_party.banked_party[index] = member.id
    end     
  end
 
  def self.add_ghost
     $game_system.menu_disabled = Settings::MENU_ACCESS
     $game_party.add_actor(Settings::GHOST_ACTOR_ID)
  end
 
end

class Game_Party < Game_Unit
 
  attr_accessor :al_destination, :death_location, :banked_party
  alias_method :initialize_z001231, :initialize
 
  def initialize
    initialize_z001231
    @death_location = {}
    @banked_party = []
  end
 
  def remove_entire_party
    @actors = []
    @battle_members_array = nil  if $imported["YEA-PartySystem"]
    $game_player.refresh
    $game_map.need_refresh = true
  end
 
  def install_banked_party
    remove_entire_party
    @banked_party.each do |member_index|
      $game_party.add_actor(member_index)
    end
    $game_system.menu_disabled = false
  end

end

module BattleManager

  class << self
    alias_method :process_defeat_z001231, :process_defeat
  end     
 
  def self.process_defeat
    if $game_switches[AfterLife::Settings::SWITCH_ID] && !@can_lose
      RPG::BGM.stop
      $game_message.add(sprintf(Vocab::Defeat, $game_party.name))
      wait_for_message
      SceneManager.scene.ggzksjfn5427
      revive_battle_members
      SceneManager.return
      battle_end(2)
      AfterLife.bank_party
      $game_party.death_location[:map_id] = $game_map.map_id
      $game_party.death_location[:x] = $game_player.x
      $game_party.death_location[:y] = $game_player.y
      $game_party.death_location[:direction] = 2
      $game_party.remove_entire_party
      AfterLife.add_ghost
      AfterLife.to_afterlife_area
      replay_bgm_and_bgs
      return true
    end
    process_defeat_z001231
  end
 
end

class Spriteset_Battle
 
  def ggzksjfn5428 #Method fades out sprites and background during battle.
    speed = AfterLife::Settings::FADE_OUT_SPEED
    begin
      @back1_sprite.color.alpha += speed unless @back1_sprite.color.alpha >= 255
      @back2_sprite.color.alpha += speed unless @back2_sprite.color.alpha >= 255
      all_enemies = true
      @enemy_sprites.each do |sprite|
        sprite.color.alpha += speed unless sprite.color.alpha >= 255
        all_enemies = false if sprite.color.alpha < 255
      end
      Graphics.wait(1)
      Graphics.update
    end until @back1_sprite.color.alpha >= 255 && @back2_sprite.color.alpha >= 255 && all_enemies
    begin
      zero_opacity = true
      @enemy_sprites.each do |sprite|
        sprite.opacity -= speed
        zero_opacity = false  if sprite.opacity > 0
      end
      Graphics.wait(1)
    end until zero_opacity
    Graphics.wait(AfterLife::Settings::WAIT_AFTER_FADE_IN)
  end
 
end

class Scene_Battle < Scene_Base
 
  def ggzksjfn5427
    @spriteset.ggzksjfn5428
  end
    
end

class Game_Player < Game_Character
 
  alias_method :perform_transfer_z432, :perform_transfer
 
    def perform_transfer
      if !AfterLife.party_install
        perform_transfer_z432
        return
      end
    if transfer?
      set_direction(@new_direction)
      if @new_map_id != $game_map.map_id
        $game_map.setup(@new_map_id)
        $game_map.autoplay
      end
      $game_party.install_banked_party
      moveto(@new_x, @new_y)
      AfterLife.party_install = false
      clear_transfer_info
    end
  end
 
end
#================================ End Of File ===============================
