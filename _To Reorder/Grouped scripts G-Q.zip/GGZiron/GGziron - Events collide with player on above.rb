# event to 'above character', and 'through' 
# still collide with player for encounter

class Game_CharacterBase
 
#======================New method==========================================
  def above_priority?
    @priority_type == 2
  end
#=========================================================================

#=====================Original method edit================================
    def move_straight(d, turn_ok = true)
    @move_succeed = passable?(@x, @y, d)
    if @move_succeed
      set_direction(d)
      @x = $game_map.round_x_with_direction(@x, d)
      @y = $game_map.round_y_with_direction(@y, d)
      @real_x = $game_map.x_with_direction(@x, reverse_dir(d))
      @real_y = $game_map.y_with_direction(@y, reverse_dir(d))
      increase_steps
      check_event_trigger_touch(@x, @y) if above_priority?
    elsif turn_ok
      set_direction(d)
      check_event_trigger_touch_front
    end
  end
#===========================================================================

end

class Game_Event < Game_Character
 
#=====================Original method edit================================
  def check_event_trigger_touch(x, y)
    return if $game_map.interpreter.running?
    if @trigger == 2 && $game_player.pos?(x, y)
      start if !jumping? &&   (normal_priority? || above_priority? )
    end
  end
#===========================================================================
end  