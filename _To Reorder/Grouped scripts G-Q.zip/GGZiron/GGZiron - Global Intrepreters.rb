=begin
Author:GGZiron
Script Name: Global Interpreters
Term of use: Free both for comercial and non comercial use. Credit me
if you are going to use it. Do not share directly on other forums. Give link
instead.
Optionally, you can send me link to check your finished game, if
my script is used on it.

Version 1.0. Date of release: 22 May 2018

About the script: Did you ever had to use parallel process event, across the maps,
without it to restart everytime you transfer?
This script does just that, but only with the common events.
It does that by adding the common event interpreters into global array.
This global interpreter goes into the save file too.
You have the option to set this to work for all common events,
or only those, which id's are included in the array bellow, in the Settings
header.



=end

module GGZiron_GlobalInterpreter # don't touch this
#=============================Settings======================================
#Add all the common events Id's you want to work
#with global interpreter into this array.
#You can add as many entries you like, as long you follow the syntaxis rules
COMMON_EVENTS =[1, 2, 3]

#Or alternatively, if you want to work with all common events,
#set the value of this to true:
USE_FOR_ALL = false

#===========================End of settings================================
# Do not touch bellow, unless you know what you are doing.
end



#==============================================================================
# ** Game_CommonEvent
#------------------------------------------------------------------------------
module DataManager


singleton_class.send(:alias_method, :setup_new_game_old, :setup_new_game)
singleton_class.send(:alias_method, :extract_save_contents_old, :extract_save_contents)
singleton_class.send(:alias_method, :make_save_contents_old, :make_save_contents)

 #======================Original methods edit====================================

   def self.setup_new_game
      setup_new_game_old
      $game_interpreters = []
      end

    def self.extract_save_contents(contents)
      extract_save_contents_old(contents)
      $game_interpreters  = contents[:interpreter]
      end

    def self.make_save_contents
      ggziron_extended_save_contents
      end

#=============================================================================

#========================New Method===========================================
    def self.ggziron_extended_save_contents
      saves = {}
      saves = make_save_contents_old
      saves[:interpreter] = $game_interpreters
      saves
      end
#==============================================================================
end

class Game_CommonEvent


  #======================Original methods edit====================================

  def initialize(common_event_id)
    $game_interpreters =[] if !$game_interpreters
    @id = common_event_id
    @event = $data_common_events[@id]
    refresh
    end
  #--------------------------------------------------------------------------
  # * Refresh
  #--------------------------------------------------------------------------
  def refresh
    global_interpreter? ?  global_refresh :  instance_refresh
    end

  #--------------------------------------------------------------------------
  # * Frame Update
  #--------------------------------------------------------------------------
  def update
    global_interpreter? ? global_update : instance_update
    end
#=============================================================================

#============================New Methods======================================

  def instance_update
    if @interpreter
      @interpreter.setup(@event.list) unless @interpreter.running?
      @interpreter.update
      end
    end

  def global_update
    if $game_interpreters[@id]
      $game_interpreters[@id].setup(@event.list) unless $game_interpreters[@id].running?
      $game_interpreters[@id].update
      end
    end

  def instance_refresh
    if active?
      @interpreter ||= Game_Interpreter.new
      else
      @interpreter = nil
      end
    end

  def global_refresh
    if active?
      $game_interpreters[@id] ||= Game_Interpreter.new
      else
      $game_interpreters[@id] = nil
      end
    end

  def global_interpreter?
    work_with_this = GGZiron_GlobalInterpreter::COMMON_EVENTS.include?(@id)
    work_with_all =  GGZiron_GlobalInterpreter::USE_FOR_ALL
    work_with_this  ||  work_with_all
    end
#=============================================================================
end