module AfterLife # do not touch this line
 
=begin
==============================================================================
                        Script's Header
==============================================================================

 Script's Name: AfterLife Handler
 Script's Author: GGZiron
 Terms of use: Free for commercial and non commercial projects.
 Credit me (GGZiron).
 Version: 1.0
 
=============================================================================
                          About The Script
=============================================================================
 This script gives the option for alternative handling instead Game Over,
 when losing battle. When losing battle, instead game over, the player
 will be moved to "afterlife" area, and the party will be replaced by actor,
 which will represent a "Ghost". There are few settings that must be done
 for the script to work, and few script calls as well.
  
 The afterlife handler will NOT activate on evented battle, that have
 "Continue Even When Loser" handler. My logic is, that if party can lose,
 then it doesn't die. If doesn't die, no need of afterlife handler.
 
 Warning: This script is not set to work on ABS battle systems.
 It may not work with all battle systems.
 
=end
#============================================================================
#                            Settings:
#                Do not skip them! It won't work if you do.
#============================================================================
module Settings #do not touch this line
    
# Set the AfterLife handling enabler switch. By default that is Switch 100.
# For the AfterLife handler to activate, this switch must be on.

  SWITCH_ID = 100 # Default is Switch ID 100
 
# The AfterLife handler will replace the active party with actor, which
# represent a ghost.
  GHOST_ACTOR_ID = 10 # Set the actual Ghost's id
 
# Define how fast will fade out the battle scene that will lead to
# afterlife area
  FADE_OUT_SPEED = 5 #Bigger number, faster it fades
 
# Once the lost battle fades out, it will wait as many frames as you set here.
# In default frame rate 60 frMes = 1 second.
  WAIT_AFTER_FADE_IN = 120 # Wait 2 seconds on default settings
 
end #do not touch this line

# That are all the settings.
 
#============================================================================
#                       Important Script Calls                       
#============================================================================
=begin
 
 For the afterlife handler to work properly, you must set the afterlife
 destination via script calls. Once set, it will remain until you set it
 again with the same script calls. Not setting the afterlife destination
 before the afterlife handler is activated will lead to error message and
 game crash.
 
 Setting the Destination Map:
 $game_party.al_destination[:map_id] = map_id
 
 You must replace the map_id with the desired map id number.
 Example Use: $game_party.al_destination[:map_id] = 3
 With the example, the afterlife map ID is set to 3.
 
 Now, you must set the x and y coordinates, and optionally, the direction
 the player is going to face once moved to afterlife area.
 Not doing that still will lead to crash!
 
 Setting the destination x coordinate:
 $game_party.al_destination[:x] = desired_x_coordinate
 Example Use:  $game_party.al_destination[:x] = 5
 
 Setting the destination y coordinate:
 $game_party.al_destination[:y] = desired_y_coordinate
 Example Use:  $game_party.al_destination[:y] = 5
 
 Setting the destination facing direction:
 $game_party.al_destination[:direction] = direction #2, 4, 6 or 8
 Example Use:  $game_party.al_destination[:direction] = 8
 With the example use, the player will be set to face up direction.
 This is the only script call you can skip, as the direction value
 is initialized with value 2 - facing down.
 Reminding: 2 = Facing Down, 4 = Facing Left, 6 = Facing Right, 8 = Facing Up.

 If you want to recollect your party, and get rid of the "Ghost",
 use this script call:
 
 $game_party.install_banked_party
 
 What this does is to remove current party(assumed that ll be the ghost),
 and adds the party members, that were in the last lost battle.
 
 Next script call:
 AfterLife.to_death_location(fade_in)
 Replace fade_in with:
 0 for normal fade in
 1 for white fade in
 2 for instant transfer
 
 Alternatively, you can use this:
 AfterLife.to_death_location
 Which will lead to instant transfer too.
 
 It will transfer the party to the exact location (always facing down),
 where the said party lost last battle. The ussage of this script call
 without death location setted(it will set by this script when party loses
 battle) will lead to game crash. Make sure this doesn't happen.
 
 Since I mentioned last lost battle, I mean battles which game over sequence
 where canceled by this script. For example, evented battle with "can lose"
 handler doesn't count.
 
 All transfers done by my script are instant. Will see if can add some fading
 options. If not, the screen could be faded in and out via event.
 
 Since the above method doesn't give too pleasant result, I provide alternative:
 AfterLife.extract_deathspot_cord(map_id, x, y)
 Here the specific is that this script call does not transfer, but store
 the destination info into game variables. Replace map_id, x and y wiith
 the id of desired game variables.
 Example use:
 AfterLife.extract_deathspot_cord(1, 2, 3)
 This call will write on Variable 1 the value of map id, on variable 2 the value
 of x coordinate, and on variable 3 the valye of y coordinate.
 Once that done, all you must do is to set transfer with event command, using
 the respective variables you set on this script call.
 
=============================================================================
                    Additional Script Calls
=============================================================================                   
 
 AfterLife.to_afterlife_area
 
 This script call will transfer you to the setted by you after life area.
 You do not need to use it for the after life handler, but if by some
 reason you would want party to go in afterlife area (like, it died in cut
 scene instead battle), or simply "visiting". Will crash if the after life
 destination is not set.
 
 Alternative way to go to afterlife location outside battle is via
 script call, that extracts the afterlife coordinates.
 
 AfterLife.extract_afterlife_cord(map_id, x, y)
 Replace map_id with the ID of the variable, which will hold map_id value.
 Do same with x and y, and then transfer via event command using those
 variables.
 
 Example use:
 AfterLife.extract_afterlife_cord(1, 2, 3)
 
 Since I mentioned about going "Afterlife mode" outside battle, I decided
 the provide all the means for it.
 
 AfterLife.set_party_hp(hp)
 This will set all party members hp to the said value, as long it does not
 go above max hp of the respective members.
 
 AfterLife.bank_party
 It "banks" the current party members, so later player can take them
 bank in party.
 
 $game_party.remove_entire_party
 Removes the entire current party.

 AfterLife.add_ghost
 Adds the "Ghost" member.
 
=end

#============================================================================
#                        Do not touch anything bellow,
#                unless you understand the code or/and feel brave.
#============================================================================

  def self.extract_deathspot_cord(map_id, x, y)
    destination = $game_party.death_location
    $game_variables[map_id] = destination[:map_id]
    $game_variables[x] = destination[:x]
    $game_variables[y] = destination[:y]
  end 
 
  def self.extract_afterlife_cord(map_id, x, y)
    destination = $game_party.al_destination
    $game_variables[map_id] = destination[:map_id]
    $game_variables[x] = destination[:x]
    $game_variables[y] = destination[:y]
  end 
 
  def self.to_afterlife_area(fade_type = nil, destination = $game_party.al_destination)
    map_id = destination[:map_id]
    x = destination[:x]
    y = destination[:y]
    direction = destination[:direction]
    $game_player.reserve_transfer(map_id, x, y, direction)
    $game_temp.fade_type = fade_type if fade_type
    $game_player.perform_transfer if !fade_type
    @done = true
  end
 
  def self.to_death_location(fade_type = nil)
    to_afterlife_area(fade_type, $game_party.death_location)
  end 
 
  def self.set_party_hp(hp = 1)
    $game_party.all_members.each_with_index do |member, index|
      member.hp = hp
    end         
  end 
 
  def self.bank_party
    $game_party.all_members.each_with_index do |member, index|
      $game_party.banked_party[index] = member.id
    end     
  end 
 
  def self.add_ghost
     $game_party.add_actor(Settings::GHOST_ACTOR_ID)
  end
 
end

class Game_Party < Game_Unit
 
  attr_accessor :al_destination, :death_location, :banked_party
  alias_method :initialize_z001231, :initialize
 
  def initialize
    initialize_z001231
    init_afterlife_destination
    @death_location = {}
    @banked_party = []
  end 
 
  def init_afterlife_destination
    @al_destination = {}
    @al_destination[:direction] = 2
  end
 
  def remove_entire_party
    @actors = []
    @battle_members_array = nil  if $imported["YEA-PartySystem"]
    $game_player.refresh
    $game_map.need_refresh = true
  end
 
  def install_banked_party
    remove_entire_party
    @banked_party.each do |member_index|
      $game_party.add_actor(member_index)
    end
  end 

end 

module BattleManager 

  class << self
    alias_method :process_defeat_z001231, :process_defeat
  end     
 
  def self.process_defeat
    if $game_switches[AfterLife::Settings::SWITCH_ID] && !@can_lose
      RPG::BGM.stop
      $game_message.add(sprintf(Vocab::Defeat, $game_party.name))
      wait_for_message
      SceneManager.scene.ggzksjfn5427
      AfterLife.to_afterlife_area
      revive_battle_members
      SceneManager.return
      battle_end(2)
      AfterLife.bank_party
      $game_party.death_location[:map_id] = $game_map.map_id
      $game_party.death_location[:x] = $game_player.x
      $game_party.death_location[:y] = $game_player.y
      $game_party.death_location[:direction] = 2
      $game_party.remove_entire_party
      AfterLife.add_ghost
      replay_bgm_and_bgs
      return true
    end
    process_defeat_z001231
  end
 
end

class Spriteset_Battle
 
  def ggzksjfn5428
    a = 0
    b = 0
    all_enemies = false
    speed = AfterLife::Settings::FADE_OUT_SPEED
    until a >= 255 && b >= 255 && all_enemies do
      a = @back1_sprite.color.alpha
      b = @back2_sprite.color.alpha
      @back1_sprite.color.alpha += speed unless a >= 255
      @back2_sprite.color.alpha += speed unless b >= 255
      all_enemies = true
      @enemy_sprites.each do |sprite|
        sprite.color.alpha += speed unless sprite.color.alpha >= 255 
        all_enemies = false if sprite.color.alpha < 255
      end
      Graphics.wait(1)
      Graphics.update
    end
    zero_opacity = false
    until zero_opacity do
      zero_opacity = true
      @enemy_sprites.each do |sprite|
        sprite.opacity -= speed
        zero_opacity = false  if sprite.opacity > 0
      end
      Graphics.wait(1)
    end
    Graphics.wait(AfterLife::Settings::WAIT_AFTER_FADE_IN)
  end 
 
end 

class Scene_Battle < Scene_Base
 
  def ggzksjfn5427
    @spriteset.ggzksjfn5428
  end 
    
end 
#================================ End Of File ===============================