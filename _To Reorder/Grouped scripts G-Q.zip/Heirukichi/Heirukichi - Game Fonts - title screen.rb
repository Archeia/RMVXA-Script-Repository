module HTW
  
  # Change this to be the font size you want to use in your game
  FONT_SIZE_DEFAULT = 24
  
  # Change this to be the font size you want to use in your title screen
  FONT_SIZE_TITLE = 48
  
end

class Window_TitleCommand < Window_Command
  
  alias htw_initialize_old  initialize
  def initialize
    Font.default_size = HTW::FONT_SIZE_TITLE
    htw_initialize_old
  end
  
  def line_height
    return Font.default_size
  end
  
  def update_placement
    self.x = (Graphics.width - width) / 2
    self.y = Graphics.height - height - 30
  end
  
end

class Scene_Title < Scene_Base
  
  alias htw_command_new_game_old  command_new_game
  alias htw_command_continue_old  command_continue
  
  def command_new_game
    Font.default_size = HTW::FONT_SIZE_DEFAULT
    htw_command_new_game_old
  end
  
  def command_continue
    Font.default_size = HTW::FONT_SIZE_DEFAULT
    htw_command_continue_old
  end
  
end