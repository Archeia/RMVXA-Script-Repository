# Turn on a switch when loading a game file
# useful for controlling a scene 
# By: Heirukichi

module Config
    SAVE_SWITCH = 1 # Change this to be the correct switch ID
end

class Scene_Save
    alias hrk_on_save_success_old  on_save_success
    def on_save_success
        $game_switches[Config::SAVE_SWITCH] = false
        hrk_on_save_success_old
    end
end

class Scene_Load
    alias hrk_on_load_success_old  on_load_success
    def on_load_success
        $game_switches[Config::SAVE_SWITCH] = true
        hrk_on_load_success_old
    end
end