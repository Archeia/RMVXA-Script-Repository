#===========================================================================================
# HEIRUKICHI RAMPAGE SKILLS
#===========================================================================================
# Version 1.1
# - Last update 11-04-2017 [M-D-Y]
# - Customization: none, just copy/paste
#-------------------------------------------------------------------------------------------
# Aliased methods:
#-------------------------------------------------------------------------------------------
# - Scene_Base
#	-- battle_start
#	-- terminate
#	-- turn_end
#-------------------------------------------------------------------------------------------
# - Game_Battler
#	-- initialize
#===========================================================================================
# DESCRIPTION:
# This script allows you to create rampaging skills, skill that increase (or decrease) their
# strength the more they are used consecutively and succesfully hit.
#===========================================================================================
# INSTRUCTIONS:
# Copy/paste this script in your Material then use a.rampage(number) in a rampaging skill
# formula. Using the same value for "number" in different skills means that those skill can
# rampage together and so using either one or the other does not stop their rampage.
# If you do not want two or more of your skills to rampage together just set number for each
# skill to be the skill id.
# It is now possible to use a.rampage_flat(damage_value, number) in a formula to add a flat
# value to skill damage based on how many times the skill has been used.
# Using a.rampage_percent(dval, pval, number) increases skill damage by a set percentage
# expressed in pval. In this case dval is the part of skill formula affected by the rampage
# effect.
# 
# NOTE: Both rampage_flat and rampage_percent can be used to decrease skill strength. To
#		decrease skill strength just insert a negative value as "damage_value" or "dval".
#		In one of the examples below there is a skill with decreased damage for each use.
#
#-------------------------------------------------------------------------------------------
# Skill Formulae Samples:
#-------------------------------------------------------------------------------------------
# a.atk*4*a.rampage(3) - b.def*2
#
# a.atk*4 - b.def*2 + a.rampage_flat(20, 4) <- this increases skill damage by 20 every time
#
# dmg = a.atk*4 - b.def*2; a.rampage_percent(dmg, 30, 6) <- increases skill damage by 30%
#															every time
# dmg = a.atk*4; a.rampage_percent(dmg, 20, 1) - b.def*2 <- increases skill damage BEFORE
#															applying target defense. This
#															can be used to rapidly increase
#															skill damage
# dmg = a.atk*4 - b.def*2; a.rampage_percent(dmg, -10, 6) <- decreases skill damage by 10%
#															 every time
#===========================================================================================
# TERMS OF USE:
# This script is free for both commercial and non commercial use as long as you give credits
# to me (Heirukichi).
#===========================================================================================
# BUGS:
# Report bugs via PM to Heirukichi at http://forums.rpgmakerweb.com/
#===========================================================================================
# CHANGE LOG:
# 11-04-2017
# - Added new features to shorten length of skills' damage formula.
#===========================================================================================

class Scene_Battle < Scene_Base
	
	alias hrs_terminate		terminate
	alias hrs_battle_start	battle_start
	alias hrs_turn_end		turn_end
	
	def battle_start
		hrs_battle_start
		all_battle_members.each do |battler|
			battler.reset_skill_use
			battler.reset_nonused_rampage
		end
	end
	
	def terminate
		all_battle_members.each do |battler|
			battler.reset_skill_use
			battler.reset_nonused_rampage
		end
		hrs_terminate
	end
	
	def turn_end
		all_battle_members.each do |battler|
			battler.reset_nonused_rampage
			battler.reset_skill_use
		end
		hrs_turn_end
	end
	
end

class Game_Battler < Game_BattlerBase

	alias hrs_initialize	initialize
	
	def initialize
		@skill_used = []
		@skill_switches = []
		@skill_rampage = []
		hrs_initialize
	end
	
	def skill_known?(id)
		flag = false
		if @skill_used.include?(id)
			flag = true
		end
		return flag
	end
	
	def set_skill_use(id)
		for i in 0..(@skill_used.size - 1)
			if (@skill_used[i] == id)
				@skill_switches[i] = true
			end
		end
	end
	
	def reset_skill_use
		for i in 0..(@skill_used.size - 1)
			@skill_switches[i] = false
		end
	end
	
	def get_skill(id)
		unless skill_known?(id)
			@skill_used << id
			@skill_switches << true
			@skill_rampage << 1
		else
			set_skill_use(id)
			rampage_increase(id)
		end
	end
	
	def rampage_increase(id)
		for i in 0..(@skill_used.size - 1)
			if (@skill_used[i] == id)
				@skill_rampage[i] += 1
			end
		end
	end
	
	def reset_nonused_rampage
		for i in 0..(@skill_used.size - 1)
			unless @skill_switches[i]
				@skill_rampage[i] = 1
			end
		end
	end
	
	def access_rampage(id)
		rampage_value = 1
		for i in 0..(@skill_used.size - 1)
			if (@skill_used[i] == id)
				rampage_value = @skill_rampage[i]
			end
		end
		return rampage_value
	end
	
	def rampage(num)
		get_skill(num)
		return access_rampage(num)
	end
	
	def rampage_flat(dval, num)
		rflat = dval * (rampage(num) - 1)
		return rflat.to_i
	end
	
	def rampage_percent(dval, pval, num)
		pval = pval.to_f / 100
		rpercent = dval * (1 + pval * (rampage(num) - 1))
		return rpercent.to_i
	end
	
end