#==============================================================================
# HEIRUKICHI MOG'S LINEAR MOVEMENT BATTLE SYSTEM GRAVITY ADDON
#==============================================================================
# Version 1.0
# - Last updated: 10-12-2018 [MM-DD-YYYY]
# - Author: Heirukichi
# - Required: Mog's Linear Movement Battle System (LMBS)
#	You can download the required script here:
#	https://atelierrgss.wordpress.com/rgss3-lmbs-linear-motion-battle-system/
#==============================================================================
# TERMS OF USE
#------------------------------------------------------------------------------
# This script was commissioned by JosephSeraph from RPGMaker community.
#
# You can use this script for both commercial and non commercial games as long
# as proper credit is given to me (Heirukichi).
# Keep in mind that this script is an addon to Mog's Linear Movement Battle
# System. If you are using this you need that one and so you have to give
# proper credits to the autor of the original script as well.
#
# Credits for the original script (required to run this one) go to Moghunter.
# Here is a link to his website: https://atelierrgss.wordpress.com
#
# You can edit this script as much as you like as long as you do not pretend to
# have written the whole script and you distribute it under the same license.
#
# Attribution-ShareAlike 4.0 International: https://creativecommons.org/licenses/by-sa/4.0/
#
# In addition to this I would like to be notified when this script is used in a
# commercial game. I do not require you to give me a percentage of your income
# when using this script but I would like to keep track of games where this
# script is being used.
# You can send me a private message on RPG Maker Forums @Heirukichi. While
# doing this is not mandatory please do not forget about it. It helps a lot.
# Of course feel free to notify me when you use it for non-commercial games as
# well. It is highly appreciated.
#==============================================================================
# DESCRIPTION
#------------------------------------------------------------------------------
# This scirpt adds physics to Mog's Linear Movement Battle System. This means
# your jumps, double jumps and falls will be affected by gravity.
#==============================================================================
# INSTRUCTIONS
#------------------------------------------------------------------------------
# This script is a plug and play script. There is only one parameter you can
# configure and that is if physics is enabled or not. More details below.
# Everything else must be configured in the original LMBS script.
#
# This script supports air friction for each character. You can configure
# notetags as in the original script. Keep in mind that Jump Speed is your jump
# initial speed and Jump Height tells you how high that character goes.
# If two characters have the same Jump Height but different Jump Speed that
# means the one with the lowest Jump Speed stays mid-air longer. In the same
# way if two characters have the same Jump Speed but different Jump Height the
# one with the highest Jump Height will stay mid-air longer.
#==============================================================================
# METHODS LIST
#------------------------------------------------------------------------------
# In this script I aliased few methods and also created new ones. The following
# list shows which ones are aliased, new or overwritten.
# + = New method.
# * = Aliased method.
# ! = Overwritten method.
# The script works as long as you put it BELOW every other script containing
# one or more of the aliased methods. In case it overwrites a method you have
# to place it BELOW the script where that method is defined and ABOVE scripts
# where that method is aliased. Also be sure to place it ABOVE any other script
# that aliases or overwrites any of the new methods.
#------------------------------------------------------------------------------
# Game_Battler
#	* initialize
#	* set_f_basic_parameters
#	* set_fmbs_initial_parameters
#	* f_mov_jump
#	* f_grv_speed
#	* f_update_jump
#	* f_update_gravity
#	* f_update_double_jump
#	* f_mov_double_jump
#	* f_move_screen_y
#	* f_mov_air_dash
#	+ initialize_gravity_variables
#	+ setup_gravity
#	+ hrk_f_grv_speed
#	+ double_jump_speed
#	+ increase_jump_frames
#==============================================================================

module HLMBSF
	
	module Config
	
		#======================================================================
		# Set the following to true if you want to use physics in your jumps,
		# set it to false if you want linear jumps. Default is true.
		#======================================================================
	
		PHYSICS = true
	
	end
	
	#==========================================================================
	# !! WARNING !!
	#--------------------------------------------------------------------------
	# Configuration module ends here. Any change after this point might prevent
	# the script from working properly. Please do not touch anything after this
	# point unless you know exactly what you are doing.
	#==========================================================================
	
	def self.physics_enabled?
		return Config::PHYSICS
	end
	
end

#==============================================================================
# * Game Battler Class
#==============================================================================

class Game_Battler < Game_BattlerBase
  
	attr_reader :jump_frames
	attr_reader :gravity
	
	#--------------------------------------------------------------------------
	# * Aliased Initialize
	#--------------------------------------------------------------------------
  
	alias hrk_initialize_old  initialize
	def initialize
		hrk_initialize_old
		initialize_gravity_variables
	end
	
	#--------------------------------------------------------------------------
	# * Aliased Set Basic Parameters
	#--------------------------------------------------------------------------
	
	alias hrk_set_f_basic_parameters_old	set_f_basic_parameters
	def set_f_basic_parameters
		hrk_set_f_basic_parameters_old
		return unless HLMBSF.physics_enabled?
		setup_gravity
	end
	
	#--------------------------------------------------------------------------
	# * Aliased Set Initial Parameters
	#--------------------------------------------------------------------------
	
	alias hrk_set_fmbs_initial_parameters_old set_fmbs_initial_parameters
	def set_fmbs_initial_parameters(f_battler)
		hrk_set_fmbs_initial_parameters_old(f_battler)
		return unless HLMBSF.physics_enabled?
		setup_gravity
	end
	
	#--------------------------------------------------------------------------
	# * Aliased Jump
	#--------------------------------------------------------------------------     

	alias hrk_f_mov_jump_old	f_mov_jump
	def f_mov_jump
		hrk_f_mov_jump_old
		return if !f_jump_conditions_met?
		@jump_frames = 0
	end
	
	#--------------------------------------------------------------------------
	# * Aliased Grv Speed
	#--------------------------------------------------------------------------
	
	alias hrk_f_grv_speed_old	f_grv_speed
	def f_grv_speed
		return hrk_f_grv_speed.abs if HLMBSF.physics_enabled?
		return hrk_f_grv_speed_old
	end
  
	#--------------------------------------------------------------------------
	# * Aliased Update Jump
	#--------------------------------------------------------------------------     
	
	alias hrk_f_update_jump_old	f_update_jump
	def f_update_jump
		@sprite_data[6][2] = 1 if ((hrk_f_grv_speed >= 0) && (!f_mov_air_dash?))
		hrk_f_update_jump_old
		f_ground? ? (@jump_frames = 0) : (@jump_frames += 1)
	end
    
	#--------------------------------------------------------------------------
	# * Aliased Update Gravity
	#--------------------------------------------------------------------------
	
	alias hrk_f_update_gravity_old	f_update_gravity
	def f_update_gravity
		hrk_f_update_gravity_old
		return if f_update_flying?
		return if !f_gravity_conditions_met?  
		increase_jump_frames
		@double_jump_speed = 0 if f_ground?
	end
    
	#--------------------------------------------------------------------------
	# * Aliased Update Double Jump
	#--------------------------------------------------------------------------
	
	alias hrk_f_update_double_jump_old	f_update_double_jump
	def f_update_double_jump
		hrk_f_update_double_jump_old
		increase_jump_frames
	end
    
	#--------------------------------------------------------------------------
	# * Aliased Mov Double Jump
	#-------------------------------------------------------------------------- 
	
	alias hrk_f_mov_double_jump_old	f_mov_double_jump
	def f_mov_double_jump
		return if !f_double_jump_conditions_met?
		@jump_frames = 0
		@double_jump_speed = double_jump_speed
		hrk_f_mov_double_jump_old
	end
	
	#--------------------------------------------------------------------------
	# * Aliased Move Screen Y
	#--------------------------------------------------------------------------
    
	alias hrk_f_move_screen_y_old f_move_screen_y
	def f_move_screen_y(val)
		hrk_f_move_screen_y_old(val)
		return if !f_move_usable?
		@screen_y = f_ground if @screen_y > f_ground
	end
  
	#--------------------------------------------------------------------------
	# * Aliased Mov Air Dash
	#--------------------------------------------------------------------------
	
	alias hrk_f_mov_air_dash_old	f_mov_air_dash
	def f_mov_air_dash
		hrk_f_mov_air_dash_old
		return if !f_air_dash_conditions_met?
		@jump_frames = ((@double_jump_speed == 0 ? @jump_speed : double_jump_speed) / @gravity).to_i
	end
	
	
	
	
	#==========================================================================
	# ** NEW METHODS
	#==========================================================================
	
	
	
	#--------------------------------------------------------------------------
	# + Initialize Gravity-related variables
	#--------------------------------------------------------------------------
  
	def initialize_gravity_variables
		@jump_frames = 0
		@double_jump_speed = 0
		@gravity = 0
	end
	
	#--------------------------------------------------------------------------
	# + Setup Gravity
	#--------------------------------------------------------------------------
	
	def setup_gravity
		@gravity = (@jump_speed * @jump_speed / (2 * @jump_height).to_f)
	end
  
	#--------------------------------------------------------------------------
	# + Gravity Speed (Physics Based)
	#--------------------------------------------------------------------------
	
	def hrk_f_grv_speed
		vd = (@gravity * @jump_frames)
		vd += 1 if vd > vd.to_i
		s = (@double_jump_speed == 0 ? @jump_speed : @double_jump_speed) - vd.to_i
		return -s
	end
	
	#--------------------------------------------------------------------------
	# + Double Jump Speed
	#--------------------------------------------------------------------------
	
	def double_jump_speed
		return (@jump_speed - [(@jump_speed / 4), 1].max)
	end
	
	#--------------------------------------------------------------------------
	# + Increase Jump Frames
	#--------------------------------------------------------------------------
	
	def increase_jump_frames
		return if f_ground?
		@jump_frames += 1
	end
    
end