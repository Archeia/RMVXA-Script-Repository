#==============================================================================
# ** Quasi Movement v1.5.7
#  Require Module Quasi [version 0.4.4 +]
#    http://quasixi.com/quasi-module/
#  If links are down, try my github
#    https://github.com/quasixi/RGSS3
#
#  **Remove Quasi Collision Map if you are using this!  Collision Map is no
#  **longer needed since it is built into this now!
#=============================================================================
# ** Terms of Use
# http://quasixi.com/rgss3/terms-of-use/
# https://github.com/quasixi/RGSS3/blob/master/README.md
#==============================================================================
#  Changed how movement works.  Allows players to choose how many pixels to move
# per movement.  In better terms, allows players to make characters have a pixel
# movement or still by by a grid like 32x32 or even 16x16.
#  Changed how collisions work.  Events now have bounding boxes surrounding them.
# If two boxes touch there will be a collision.  Boxes can be set in each event,
# further detail in the instructions.
#==============================================================================
# Collision Map Info:
#  Allows the use of an image with collisions.  Using this you can setup
# a pseudo perfect pixel collision.
#  To have a map use a collision map, use the following in the maps notetag
#    <cm=NAME>
#  Map note tags are found in the map properties
#  Set Name to the name of the collision map you want to use, this image
#  should be inside the parallax folder!
#==============================================================================
# How to install:
#  - Place this below Module Quasi (link is above)
#  - Make sure the version of Module Quasi is the required version.
#  - Follow instructions below
#
# Extra instructions + Bounding box setup help at:
#  http://quasixi.com/movement/
#==============================================================================
module Quasi
  module Movement
#------------------------------------------------------------------------------
# Setup:
#    GRID to the amount of pixels you want to move per movement.
#  Default is 1, meaning pixel movement.  This can be changed back
#  to 32 which is vxa default tile movement.
#------------------------------------------------------------------------------
    GRID      = 1
#------------------------------------------------------------------------------
#    OFFGRID when set to true it will allow characters to move faster then
#  the set GRID. This should be set to false for fixed grids like 16 or 32.
#------------------------------------------------------------------------------
    OFFGRID   = true
#------------------------------------------------------------------------------
#    FLOAT_XY when set to true x and y values will be a decimal instead of a
#  whole number. By default this is false, but setting this to true might
#  allow compatibility with other scripts.
#------------------------------------------------------------------------------
    FLOAT_XY  = false
#------------------------------------------------------------------------------
# Optimizing settings:
#  SMARTMOVE
#      If the move didn't succeed it will try again at lower speeds until
#    speed reaches 0.  This should only be used at lower grids like 1.
#      If movement fails it will attempt additional similar movements.
#  Values:
#    false   to disable
#    :speed  tries different speeds if move failed
#    :dir    tries different similiar directions if move failed (DIR8 needs to be true)
#    :both   both :speed and :dir
#------------------------------------------------------------------------------
    SMARTMOVE = :both
#------------------------------------------------------------------------------
#  MIDPASS
#      An extra collision check for the midpoint of the movement.  Should be
#    be used in larger grids if you have small boxes that can be skipped over
#    at certain speeds.
#    (Default passibilty only checks if you collided with anything at the point
#     you moved to, not anything inbetween)
#------------------------------------------------------------------------------
    MIDPASS   = false
#------------------------------------------------------------------------------
#  OPT is set to an integer which can help optimize the collision detection
#  What this does, it scans every X pixel, so if OPT was set to 5, it will scan
#  every 5th pixel when needed.  Depending on how detailed your collision maps
#  are you should use 1 or 2. If you are not using collision maps and your
#  maps are using tileboxes, then you can get away with 4 for pixel movement.
#------------------------------------------------------------------------------
    OPT       = 4
#------------------------------------------------------------------------------
#    Set DIR8 to true or false.  When true it will allow for 8 direction
#  movement, when false it will not.
#  (This does not include an 8 direction frame)
#------------------------------------------------------------------------------
    DIR8      = true
#------------------------------------------------------------------------------
#    DIAGSPEED.  This adjusts the speed when moving diagonal.  Set to
#  0 if you want to stay at same speed.  Floats and negative values
#  are allowed.  
#    Ex: 0.5 and -0.5
#------------------------------------------------------------------------------
    DIAGSPEED = 0
#------------------------------------------------------------------------------
#    Set PLAYERBOX and EVENTBOX.  This sets the bounding box for the
#  player character or event.
#    Good box for small grid( like GRID = 1):   [24, 16, 4, 16]
#    Good box for bigger grid( like GRID = 32): [22, 22, 5, 9]
#
#  Each actor can have their own bounding box by setting up a
#  bounding box inside the actors note tag.
#------------------------------------------------------------------------------
    PLAYERBOX  = [24, 16, 4, 16]
    EVENTBOX   = [24, 16, 4, 16]
    VEHICLES   = {
      :boat     => [22, 22, 5, 9],
      :ship     => [22, 22, 5, 9],
      :airship  => [22, 22, 5, 9]
    }
#------------------------------------------------------------------------------
# Set EVENTFREQ.  
#    This changes how many pixels an event should move before stopping.
#  For default vxa an event moves 32 pixels then stops a short time depending
#  on his frequency.  So if we have a pixel grid movement (GRID = 1) we can
#  duplicate that feature by setting this to 32, and the event will move 32 pixels
#  until he stops, instead of stopping at every pixel.
#------------------------------------------------------------------------------
    EVENTFREQ = 32
#------------------------------------------------------------------------------
# REGION BOXES  
#    These give region bounding boxes.
#  Regions, unlike character boxes, can have multiple boxes.
#  They are set up like:
#    REGIONBOXES{
#      REGION NUMBER => [box parameters], # Single box
#      REGION NUMBER => [[box 1 parameters],[box 2 parameters]], # Multiple boxes
#    } # < ends the hash *Important!*
#
# *NOTE*
#   Region boxes prioritize over tile passibilty, so even if the tile is set
# to no direction, it will use the region passibilty instead, if there is
# a region on that tile.
#------------------------------------------------------------------------------
    REGIONBOXES = {
      62 => [0, 0],
      63 => [32, 32]
    }
#------------------------------------------------------------------------------
#  For testing purposes, set the bottom value to true to see the boxes.
#  Only shows during play testing.
#  *Does not show region boxes!*
#------------------------------------------------------------------------------
    SHOWBOXES   = true
    BOXBLEND    = 0
    BOXCOLOR    = Color.new(255, 0, 0, 120)
#------------------------------------------------------------------------------
#  Collision Map
#    COLLISION = color for not passable
#    WATER1    = color for only passable with a boat and ship
#    WATER2    = color for only passable with a ship
#    
#  Color can be a hex code, using Quasi.color, or an rgb color using Color.new
#  Hex color is usually easy to find in most image editors, just don't
#  forget to leave out the # infront of the code!
#    Ex. Quasi.color("hex color code")
#
#  You can also use the default color method such as:
#    Ex. Color.new(R, G, B)
#  Leave Alpha out!
#------------------------------------------------------------------------------
    COLLISION = Quasi.color("ff0000")
    WATER1    = Color.new(0, 0, 200)
    WATER2    = Color.new(0, 0, 255)
#------------------------------------------------------------------------------
#  REGIONS allow you to mark a new region type (pixel regions) based off
#  of a color.  To find out the pixel region someone is on use:
#    $game_map.pixel_region_id(px, py)
#  *NOTE* Make sure you use pixel values, so not their x/y values!!
#  This is setup inside a hash in the following format:
#    "hex color code" => id,
#  *NOTE* This doesn't relate with current regions, so pixel region 1
#  is not map region 1!!
#  **Completely optional, and does not need to be used**
#------------------------------------------------------------------------------
    REGIONS   = {
      "00ff00" => 1,  # Green is pixel region 1
      "0000ff" => 2   # Blue is pixel region 2
    }
#------------------------------------------------------------------------------
# **DO NOT EDIT THESE UNLESS YOU KNOW WHAT YOU ARE DOING**
#------------------------------------------------------------------------------
    TILEBOXES = {
      1537 => [32, 4, 0, 28],
      1538 => [4, 32],
      1539 => [[32, 4, 0, 28], [4, 32]],
      1540 => [4, 32, 28],
      1541 => [[32, 4, 0, 28], [4, 32, 28]],
      1544 => [32, 4],
      1546 => [[32, 4], [4, 32]],
      1548 => [[32, 4], [4, 32, 28]],
      1551 => [32, 32],
      2063 => [32, 32],
      2575 => [32, 32],
      3586 => [4, 32],
      3588 => [4, 32, 28],
      3590 => [[4, 32], [4, 32, 28]],
      3592 => [32, 4],
      3594 => [[32, 4], [4, 32]],
      3596 => [[32, 4], [4, 32, 28]],
      3598 => [[32, 4], [4, 32], [4, 32, 28]],
      3599 => [32, 32],
      3727 => [32, 32]
    }
  end
end
#==============================================================================
# Change Log (Last 5)
#------------------------------------------------------------------------------
# v1.5.7 - 5/23/15
#      - Fixed bug with Jumping
# --
# v1.5.6 - 5/16/15
#      - Small patch for Gamepad Extender
# --
# v1.5.5 - 5/13/15
#      - Small changes / rewrites to work with Upcoming Scripts
#      - Small bug fixes
#      - 2 New options OFFGRID and FLOAT_XY
# --
# v1.5.4 - 4/10/15
#      - Fixed a couple bugs to work with Quasi Sprite
# --
# v1.5.3 - 3/23/15
#      - Fixed a bug that didn't allow saving / loading
#------------------------------------------------------------------------------
# To do / Upcoming
#------------------------------------------------------------------------------
# - Find more bugs
# - Pathfinder is complete but still needs more optimize, runs a complicated path
#   ( meaning it checks nearly 70-80% of the screen for the path ) in about
#   0.4-0.6 seconds in pixel mode (in 32 mode it runs in like 0.006)
# - True Line of Sight, now that I feel movement is complete I'll release my
#   sight soon.  By True I mean, events can not see through other events, or
#   walls, and it's completely calculation based so the sight automatically
#   changes every time the event moves.
#==============================================================================#
# By Quasi (http://quasixi.com/) || (https://github.com/quasixi/RGSS3)
#  - 9/22/14
#==============================================================================#
#   ** Stop! Do not edit anything below, unless you know what you      **
#   ** are doing!                                                      **
#==============================================================================#
$imported = {} if $imported.nil?
$imported["Quasi"] = 0 if $imported["Quasi"].nil?
$imported["Quasi_Movement"] = 1.57
 
if $imported["Quasi"] >= 0.44
#==============================================================================
# ** DataManager
#------------------------------------------------------------------------------
#  This module manages the database and game objects. Almost all of the
# global variables used by the game are initialized by this module.
#==============================================================================
 
module DataManager
  #--------------------------------------------------------------------------
  # * Alias
  #--------------------------------------------------------------------------
  class << self
    alias :qm_dm_save    :save_game
    alias :qm_dm_reload_map    :reload_map_if_updated
  end
  #--------------------------------------------------------------------------
  # * Execute Save
  #--------------------------------------------------------------------------
  def self.save_game(index)
    $game_map.dispose_collisionmap
    qm_dm_save(index)
    $game_map.create_collisionmap
  end
  #--------------------------------------------------------------------------
  # * Reload Map if Data Is Updated
  #--------------------------------------------------------------------------
  def self.reload_map_if_updated
    qm_dm_reload_map
    $game_map.create_collisionmap
  end
end
 
#==============================================================================
# ** Bounding_Box
#------------------------------------------------------------------------------
#  This class handles bounding boxes for characters.
#==============================================================================
 
class Bounding_Box
  attr_reader :width, :height, :ox, :oy, :px, :py
  #--------------------------------------------------------------------------
  # * Object Initialization
  #--------------------------------------------------------------------------
  def initialize(w, h, ox, oy, shift_y = 0)
    @width  = w
    @height = h
    @ox = ox
    @oy = oy
    @px = @py = 0
    @shift_y = shift_y
  end
  #--------------------------------------------------------------------------
  # * Boxes vertices
  #--------------------------------------------------------------------------
  def moveto(x, y)
    return if x == @px && y == @py
    @px = x
    @py = y
    vertices(true)
  end
  #--------------------------------------------------------------------------
  # * Boxes vertices
  #--------------------------------------------------------------------------
  def vertices(reset = false)
    if reset || @vertices.nil?
      bx = (@px + @ox)..(@px + @width + @ox - 1)
      by = (@py + @oy - @shift_y)..(@py + @height + @oy - @shift_y - 1)
      top_left     = [bx.first, by.first]
      top_right    = [bx.last, by.first]
      bottom_left  = [bx.first, by.last]
      bottom_right = [bx.last, by.last]
      @box = [bx, by]
      @vertices = [top_left, top_right, bottom_left, bottom_right]
    end
    return @vertices
  end
  #--------------------------------------------------------------------------
  # * Box dimension
  #--------------------------------------------------------------------------
  def box(x, y)
    bx = (x + @ox)..(x + @width + @ox)
    by = (y + @oy)..(y + @height + @oy)
    return [bx, by]
  end
  #--------------------------------------------------------------------------
  # * Boxes center
  #--------------------------------------------------------------------------
  def center
    cx = vertices[0][0] + (@width / 2.0)
    cy = vertices[0][1] + (@height / 2.0)
    return [cx, cy]
  end
  #--------------------------------------------------------------------------
  # * Box pixel edge
  #--------------------------------------------------------------------------
  def edge(direction)
    edges = {}
    edges[2] = [vertices[2], vertices[3]]
    edges[4] = [vertices[0], vertices[2]]
    edges[6] = [vertices[1], vertices[3]]
    edges[8] = [vertices[0], vertices[1]]
    return edges[direction]
  end
  #--------------------------------------------------------------------------
  # * Box edge in 32 grid
  #--------------------------------------------------------------------------
  def edge32(direction)
    edge1 = edge(direction)
    edges = []
    edges << [(edge1[0][0] / 32.0).floor, (edge1[0][1] / 32.0).floor]
    edges << [(edge1[1][0] / 32.0).floor, (edge1[1][1] / 32.0).floor]
    return edges
  end
end
 
#==============================================================================
# ** Game_Map
#------------------------------------------------------------------------------
#  This class handles maps. It includes scrolling and passage determination
# functions. The instance of this class is referenced by $game_map.
#==============================================================================
 
class Game_Map
  attr_reader   :collisionmap
  #--------------------------------------------------------------------------
  # * Setup
  #--------------------------------------------------------------------------
  alias :qm_gm_setup    :setup
  def setup(map_id)
    qm_gm_setup(map_id)
    @tileboxes = Array.new(width) { Array.new(height) { nil } }
    setup_tileboxes
    create_collisionmap
  end
  #--------------------------------------------------------------------------
  # * Calculate PX Coordinate After Loop Adjustment
  #--------------------------------------------------------------------------
  def round_px(x)
    loop_horizontal? ? (x + (width*32)) % (width*32) : x
  end
  #--------------------------------------------------------------------------
  # * Calculate PY Coordinate After Loop Adjustment
  #--------------------------------------------------------------------------
  def round_py(y)
    loop_vertical? ? (y + (height*32)) % (height*32) : y
  end
  #--------------------------------------------------------------------------
  # * Calculate PX Coordinate Before Loop Adjustment
  #--------------------------------------------------------------------------
  def unround_px(x)
    x > (width-1)*32 ? x - (width*32) : x
  end
  #--------------------------------------------------------------------------
  # * Calculate PY Coordinate Before Loop Adjustment
  #--------------------------------------------------------------------------
  def unround_py(y)
    y > (height-1)*32 ? y - (height*32) : y
  end
  #--------------------------------------------------------------------------
  # * Calculate PX Coordinate Shifted One Tile in Specific Direction
  #   (No Loop Adjustment)
  #--------------------------------------------------------------------------
  def px_with_direction(x, d, v)
    x + (d == 6 ? v : d == 4 ? -v : 0)
  end
  #--------------------------------------------------------------------------
  # * Calculate PY Coordinate Shifted One Tile in Specific Direction
  #   (No Loop Adjustment)
  #--------------------------------------------------------------------------
  def py_with_direction(y, d, v)
    y + (d == 2 ? v : d == 8 ? -v : 0)
  end
  #--------------------------------------------------------------------------
  # * Calculate PX Coordinate Shifted One Pixel in Specific Direction
  #   (With Loop Adjustment)
  #--------------------------------------------------------------------------
  def round_px_with_direction(x, d, v)
    round_px(x + (d == 6 ? v : d == 4 ? -v : 0))
  end
  #--------------------------------------------------------------------------
  # * Calculate PY Coordinate Shifted One Pixel in Specific Direction
  #   (With Loop Adjustment)
  #--------------------------------------------------------------------------
  def round_py_with_direction(y, d, v)
    round_py(y + (d == 2 ? v : d == 8 ? -v : 0))
  end
  #--------------------------------------------------------------------------
  # * Get Array of Event Bounding Box at Designated Coordinates
  #--------------------------------------------------------------------------
  def bounding_xy(objbox, through=nil)
    map_events_values.select {|event| event.box?(objbox, through) }
  end
  #--------------------------------------------------------------------------
  # * Get events on map
  #--------------------------------------------------------------------------
  def map_events_values
    return @events.values
  end
  #--------------------------------------------------------------------------
  # * Setup Passibilities
  #--------------------------------------------------------------------------
  def setup_tileboxes
    for x in 0...width
      for y in 0...height
        all_tiles(x, y).each do |tile_id|
          flag = tileset.flags[tile_id]
          if Quasi::Movement::REGIONBOXES.keys.include?(region_id(x, y))
            @tileboxes[x][y] = tilebox(x, y, region_id(x, y))
          else
            next if flag & 0x10 != 0
            next unless Quasi::Movement::TILEBOXES[flag]
            next if @tileboxes[x][y]
            @tileboxes[x][y] = tilebox(x, y, flag, true)
          end
        end
      end
    end
  end
  #--------------------------------------------------------------------------
  # * Makes region/tile boxes
  # Tiles on edges are made twice when there is scroll loop
  #--------------------------------------------------------------------------
  def tilebox(x, y, id, tile=false)
    bb = Quasi::Movement::REGIONBOXES[id]
    bb = Quasi::Movement::TILEBOXES[id] if tile
    return if !bb
    tilebox = []
    tilebox = make_tilebox(bb, id, x, y)
    if x == 0 && loop_horizontal?
      tilebox = [tilebox, make_tilebox(bb, id, width, y)]
    elsif y == 0 && loop_vertical?
      tilebox = [tilebox, make_tilebox(bb, id, x, height)]
    end
    return tilebox
  end
  #--------------------------------------------------------------------------
  # * Makes the box
  #--------------------------------------------------------------------------
  def make_tilebox(bb, id, x, y)
    tilebox = []
    if bb[0].is_a?(Array)
      bb.each do |box|
        x1 = x * 32; y1 = y * 32
        ox = box[2].nil? ? 0 : box[2]
        oy = box[3].nil? ? 0 : box[3]
        bx = x1 + ox..x1 + box[0] + ox
        by = y1 + oy..y1 + box[1] + oy
        tilebox << [bx, by, id]
      end
    else
      x1 = x * 32; y1 = y * 32
      ox = bb[2].nil? ? 0 : bb[2]
      oy = bb[3].nil? ? 0 : bb[3]
      bx = x1 + ox..x1 + bb[0] + ox
      by = y1 + oy..y1 + bb[1] + oy
      tilebox = [bx, by, id]
    end
    return tilebox
  end
  #--------------------------------------------------------------------------
  # * Grab Passibilities
  #--------------------------------------------------------------------------
  def tileboxes
    return @tileboxes if @tileboxes
  end
  #--------------------------------------------------------------------------
  # * Checks for collision
  #--------------------------------------------------------------------------
  def collisionmap_passable?(px, py, vehicle = false)
    return true unless @collisionmap
    collisions = []
    collisions << Quasi::Movement::COLLISION
    collisions << Quasi::Movement::WATER1
    collisions << Quasi::Movement::WATER2
    if vehicle
      case vehicle
      when :boat
        pass1 = @collisionmap.get_pixel(px, py) == collisions[1]
        pass2 = @collisionmap.get_pixel(px, py) != collisions[0]
        return pass1 && pass2
      when :ship
        pass1 = @collisionmap.get_pixel(px, py) == collisions[1]
        pass2 = @collisionmap.get_pixel(px, py) == collisions[2]
        pass3 = @collisionmap.get_pixel(px, py) != collisions[0]
        return (pass1 || pass2) && pass3
      end
    end
    return !collisions.include?(@collisionmap.get_pixel(px, py))
  end
  #--------------------------------------------------------------------------
  # * Start collisionmap
  #--------------------------------------------------------------------------
  def create_collisionmap
    dispose_collisionmap
    if @map.collisionmap
      @collisionmap = Cache.parallax(@map.collisionmap)
    else
      @collisionmap = Bitmap.new(32 * width, 32 * height)
    end
    for x in 0..width
      for y in 0..height
        next unless @tileboxes[x]
        box = @tileboxes[x][y]
        next unless box
        if box[0].is_a?(Array)
          box.each {|b| draw_box(b)}
        else
          draw_box(box)
        end
      end
    end
  end
  #--------------------------------------------------------------------------
  # * Remove collisionmap
  #--------------------------------------------------------------------------
  def dispose_collisionmap
    @collisionmap.dispose if @collisionmap
    @collisionmap = nil
  end
  #--------------------------------------------------------------------------
  # * Adds box to bitmap
  #--------------------------------------------------------------------------
  def draw_box(box)
    bw = box[0].last - box[0].first
    bh = box[1].last - box[1].first
    x = box[0].first
    y = box[1].first
    rect = Rect.new(x, y, bw, bh)
    color = Quasi::Movement::COLLISION
    color = Quasi::Movement::WATER1 if box[2] == 2063
    color = Quasi::Movement::WATER2 if box[2] == 2575
    @collisionmap.fill_rect(rect, color)
  end
  #--------------------------------------------------------------------------
  # * Check if tile has counter flag
  #--------------------------------------------------------------------------
  def tilecounter?(x, y)
    tile = @tileboxes[x][y]
    return unless tile
    if tile[0].is_a?(Array)
      return tile.any? {|box| box[2] == 3727}
    else
      return tile[2] == 3727
    end
  end
  #--------------------------------------------------------------------------
  # * Get Pixel Region ID
  #--------------------------------------------------------------------------
  def pixel_region_id(px, py)
    return 0 unless @collisionmap
    region = @collisionmap.get_pixel(px, py)
    id = Quasi::Movement::REGIONS[region.to_hex]
    return id || 0
  end
end
 
#==============================================================================
# ** Game_CharacterBase
#------------------------------------------------------------------------------
#  This base class handles characters. It retains basic information, such as
# coordinates and graphics, shared by all characters.
#==============================================================================
 
class Game_CharacterBase
  #--------------------------------------------------------------------------
  # * Public Instance Variables
  #--------------------------------------------------------------------------
  attr_reader   :px, :py
  #--------------------------------------------------------------------------
  # * Initialize Public Member Variables
  #--------------------------------------------------------------------------
  alias :qm_gcb_init    :init_public_members
  def init_public_members
    qm_gcb_init
    @px = @py = @npx = @npy = 0
    @diagonal = false
    @grid = Quasi::Movement::GRID
    init_quasi_variables
  end
  #--------------------------------------------------------------------------
  # * Initialize Quasi Movement setting variables
  #--------------------------------------------------------------------------
  def init_quasi_variables
    smart = Quasi::Movement::SMARTMOVE
    @smartmove = {
      :speed => (smart == :speed || smart == :both) && self.is_a?(Game_Player),
      :dir   => (smart == :dir || smart == :both) && self.is_a?(Game_Player)
    }
    @dir4_diag = {
      8 => [[4, 8], [6, 8]],
      6 => [[6, 8], [6, 2]],
      2 => [[4, 2], [6, 2]],
      4 => [[4, 8], [4, 2]]
    }
    @dir8 = {
      9 => [6, 8],    7 => [4, 8],
      3 => [6, 2],    1 => [4, 2]
    }
  end
  #--------------------------------------------------------------------------
  # * Determine if Passable
  #     d : Direction (2,4,6,8)
  #--------------------------------------------------------------------------
  def passable?(x, y, d, dist = move_tiles)
    x1 = $game_map.round_px_with_direction(x, d, dist)
    y1 = $game_map.round_py_with_direction(y, d, dist)
    bounding_box(d).moveto(x1, y1)
    return false unless valid?(d)
    return true if @through || debug_through?
    return false unless midpassable?(x, y, d, x1, y1, dist) if Quasi::Movement::MIDPASS
    return false unless tilebox_passable?(x1, y1, d)
    return false if collide_with_box?(x1, y1)
    return true
  end
  #--------------------------------------------------------------------------
  # * Determine Diagonal Passability
  #     horz : Horizontal (4 or 6)
  #     vert : Vertical (2 or 8)
  #--------------------------------------------------------------------------
  def diagonal_passable?(x, y, horz, vert, dist = move_tiles)
    x2 = $game_map.round_px_with_direction(x, horz, move_tiles)
    y2 = $game_map.round_py_with_direction(y, vert, move_tiles)
    (passable?(x, y, vert) &&  passable?(x, y2, horz)) ||
    (passable?(x, y, horz) &&  passable?(x2, y, vert))
  end
  #--------------------------------------------------------------------------
  # * Determine if Midpoint is Passable
  #     d : Direction (2,4,6,8)
  #--------------------------------------------------------------------------
  def midpassable?(x, y, d, x1, y1, dist)
    half_tiles = dist / 2.0
    x2 = $game_map.round_px_with_direction(x, d, half_tiles)
    y2 = $game_map.round_py_with_direction(y, d, half_tiles)
    bounding_box(d).moveto(x2, y2)
    return false unless oldtilebox_passable?(x2, y2, 5)
    return false if collide_with_box?(x2, y2)
    bounding_box(d).moveto(x1, y1)
    return true
  end
  #--------------------------------------------------------------------------
  # * Determine if player is still on map
  #--------------------------------------------------------------------------
  def valid?(d)
    return valid_edge?(d) if [2, 4, 6, 8].include?(d)
    return valid_edge?(2) && valid_edge?(8)
  end
  #--------------------------------------------------------------------------
  # * Determine if player edge is still on map
  #--------------------------------------------------------------------------
  def valid_edge?(d)
    edge = bounding_box.edge32(d)
    mw = $game_map.width
    mh = $game_map.height
    case d
    when 2
      return edge[0][1] < mh
    when 4
      return edge[0][0] >= 0
    when 6
      return edge[0][0] < mw
    when 8
      return edge[0][1] >= 0
    end
  end
  #--------------------------------------------------------------------------
  # * Determine if Tile is Passable
  #--------------------------------------------------------------------------
  def tilebox_passable?(x, y, d)
    unless [2, 4, 6, 8].include?(d)
      return tilebox_passable?(x, y, 2) && tilebox_passable?(x, y, 8) &&
        tilebox_passable?(x, y, 4) && tilebox_passable?(x, y, 6)
    end
    edge = bounding_box.edge(d)
    x1 = edge[0][0].floor
    x2 = edge[1][0].floor
    y1 = edge[0][1].floor
    y2 = edge[1][1].floor
    if !$game_map.collisionmap_passable?(x1, y1) ||
      !$game_map.collisionmap_passable?(x2, y2)
      return false
    end
    if [2, 8].include?(d)
      for x in x1..x2
        next unless x % Quasi::Movement::OPT == 0
        return false unless $game_map.collisionmap_passable?(x, y1)
      end
    else
      for y in y1..y2
        next unless y % Quasi::Movement::OPT == 0
        return false unless $game_map.collisionmap_passable?(x1, y)
      end
    end
    return true
  end
  #--------------------------------------------------------------------------
  # * Determine if Tile is Passable
  # Used only for mid passable
  #--------------------------------------------------------------------------
  def oldtilebox_passable?(x, y, d)
    edge1 = bounding_box.edge32(2)
    edge2 = bounding_box.edge32(8)
    tilepass?(edge1[0][0], edge1[0][1], x, y) &&
    tilepass?(edge1[1][0], edge1[1][1], x, y) &&
    tilepass?(edge2[0][0], edge2[0][1], x, y) &&
    tilepass?(edge2[1][0], edge2[1][1], x, y)
  end
  #--------------------------------------------------------------------------
  # * Tile box Collision
  #  Returns true if tile is passable ( No box collision. )
  # Used only for mid passable
  #--------------------------------------------------------------------------
  def tilepass?(x, y, nx, ny)
    tb = $game_map.tileboxes[x][y]
    return true if !tb || @through
    if tb[0].is_a?(Array)
      pass = []
      tb.each do |b|
        pass << tilebox?(b, nx, ny)
      end
      return pass.count(false) == pass.size
    else
      return tilebox?(tb, nx, ny) == false
    end
  end
  #--------------------------------------------------------------------------
  # * Returns true if boxes are inside each other.
  # Used only for mid passable
  #--------------------------------------------------------------------------
  def tilebox?(tilebox, nx, ny)
    box = bounding_box.box(nx, ny)
    insidex = (box[0].last > tilebox[0].first) && (box[0].first < tilebox[0].last)
    insidey = (box[1].last > tilebox[1].first) && (box[1].first - shift_y < tilebox[1].last)
    return insidex && insidey
  end
  #--------------------------------------------------------------------------
  # * Detect Collision with Character
  #--------------------------------------------------------------------------
  def collide_with_box?(x, y)
    looped = $game_map.loop_horizontal? || $game_map.loop_vertical?
    boxes = $game_map.bounding_xy(bounding_box.box(x, y))
    unless boxes.empty?
      boxes.keep_if {|e| e != self && e.normal_priority?}
    end
    !boxes.empty? || collide_with_vehicles?(x, y)
  end
  #--------------------------------------------------------------------------
  # * Detect Collision with Vehicle
  #--------------------------------------------------------------------------
  def collide_with_vehicles?(x, y)
    $game_map.boat.box?(bounding_box.box(x,y)) ||
    $game_map.ship.box?(bounding_box.box(x,y))
  end
  #--------------------------------------------------------------------------
  # * Determine Triggering of Frontal Touch Event
  #--------------------------------------------------------------------------
  def check_event_trigger_touch_front
    x1 = $game_map.round_px_with_direction(@px, @direction, move_tiles)
    y1 = $game_map.round_py_with_direction(@py, @direction, move_tiles)
    check_event_trigger_touch(x1, y1)
  end
  #--------------------------------------------------------------------------
  # * Check for Bounding box Collision
  #  Returns true if boxes are inside each other.
  #--------------------------------------------------------------------------
  def box?(objbox, through=nil)
    through = through.nil? ? @through : through
    return unless bounding_box
    return if through
    box = bounding_box.box(@npx, @npy)
    pass1 = (objbox[0].first < box[0].last) && (objbox[0].last > box[0].first)
    pass2 = (objbox[1].first < box[1].last) && (objbox[1].last > box[1].first)
    return pass1 && pass2
  end
  #--------------------------------------------------------------------------
  # * Get Move Speed (Account for Dash)
  #--------------------------------------------------------------------------
  def real_move_speed
    @move_speed + (dash? ? 1 : 0) + (diagonal? ? Quasi::Movement::DIAGSPEED : 0)
  end
  #--------------------------------------------------------------------------
  # * Move to Designated Position
  #--------------------------------------------------------------------------
  alias :qm_gcb_moveto    :moveto
  def moveto(x, y)
    qm_gcb_moveto(x,y)
    @px = @npx = x * 32.0
    @py = @npy = y * 32.0
    bounding_box
    @boundingbox.each {|k, v| v.moveto(@px, @py) }
  end
  #--------------------------------------------------------------------------
  # * Move to Designated Position (Pixel based)
  #--------------------------------------------------------------------------
  def pxl_moveto(px, py)
    @px = @npx = px % ($game_map.width*32)
    @py = @npy = py % ($game_map.height*32)
    @x = @px / (Quasi::Movement::FLOAT_XY ? 32.0 : 32)
    @y = @py / (Quasi::Movement::FLOAT_XY ? 32.0 : 32)
    @real_x = @px / 32.0
    @real_y = @py / 32.0
    @prelock_direction = 0
    bounding_box
    @boundingbox.each {|k, v| v.moveto(@px, @py) }
    straighten
    update_bush_depth
  end
  #--------------------------------------------------------------------------
  # * How many tiles are you moving
  #--------------------------------------------------------------------------
  def move_tiles
    @grid < speed ? ( Quasi::Movement::OFFGRID ? speed : @grid) : @grid
  end
  def speed
    2**real_move_speed / 8.0
  end
  def moving?
    @px != @npx || @py != @npy
  end
  #--------------------------------------------------------------------------
  # * Diagonal
  #--------------------------------------------------------------------------
  def diagonal?
    return true if @diagonal
    return false
  end
  #--------------------------------------------------------------------------
  # * Return the diagonal direction (1, 7, 3, 9)
  #--------------------------------------------------------------------------
  def diagonal_direction
    return @direction unless diagonal?
    return @dir8.key(@diagonal)
  end
  #--------------------------------------------------------------------------
  # * Update While Moving
  #--------------------------------------------------------------------------
  def update_move
    @px = [@px - speed, @npx].max if @npx < @px
    @px = [@px + speed, @npx].min if @npx > @px
    @py = [@py - speed, @npy].max if @npy < @py
    @py = [@py + speed, @npy].min if @npy > @py
   
    @real_x = @px/32.0 if @real_x != @px/32.0
    @real_y = @py/32.0 if @real_y != @py/32.0
    if Quasi::Movement::FLOAT_XY
      @x = @real_x
      @y = @real_y
    else
      @x = @real_x.truncate if @x != @real_x.truncate
      @y = @real_y.truncate if @y != @real_y.truncate
    end
   
    update_bush_depth unless moving?
  end
  #--------------------------------------------------------------------------
  # * Update While Jumping
  #--------------------------------------------------------------------------
  alias :qm_gcb_jump    :update_jump
  def update_jump
    qm_gcb_jump
    @px = @npx = @real_x * 32
    @py = @npy = @real_y * 32
    @boundingbox.each {|k, v| v.moveto(@px, @py) }
  end
  #--------------------------------------------------------------------------
  # * Move Straight
  #     d:        Direction (2,4,6,8)
  #     turn_ok : Allows change of direction on the spot
  #--------------------------------------------------------------------------
  def move_straight(d, turn_ok = true)
    @move_succeed = passable?(@px, @py, d)
    orginal_speed = @move_speed
    smart_move(d) if @smartmove[:speed]
    if @move_succeed
      set_direction(d)
      @diagonal = false
      @npx = $game_map.round_px_with_direction(@px, d, move_tiles)
      @npy = $game_map.round_py_with_direction(@py, d, move_tiles)
      @px = $game_map.px_with_direction(@npx, reverse_dir(d), move_tiles)
      @py = $game_map.py_with_direction(@npy, reverse_dir(d), move_tiles)
      increase_steps
    elsif turn_ok
      bounding_box(d).moveto(@px, @py)
      set_direction(d)
      check_event_trigger_touch_front
    else
      bounding_box(d).moveto(@px, @py)
    end
    @move_speed = orginal_speed
    if !@move_succeed && @smartmove[:dir]
      dir = @dir4_diag[d]
      if diagonal_passable?(@px, @py, dir[0][0], dir[0][1])
        move_diagonal(dir[0][0], dir[0][1])
      elsif diagonal_passable?(@px, @py, dir[1][0], dir[1][1])
        move_diagonal(dir[1][0], dir[1][1])
      end
    end
  end
  #--------------------------------------------------------------------------
  # * Move Diagonally
  #     horz:  Horizontal (4 or 6)
  #     vert:  Vertical (2 or 8)
  #--------------------------------------------------------------------------
  def move_diagonal(horz, vert)
    @move_succeed = diagonal_passable?(@px, @py, horz, vert)
    orginal_speed = @move_speed
    smart_move([horz, vert], true) if @smartmove[:speed]
    if @move_succeed
      @diagonal = [horz, vert]
      @npx = $game_map.round_px_with_direction(@px, horz, move_tiles)
      @npy = $game_map.round_py_with_direction(@py, vert, move_tiles)
      @px = $game_map.px_with_direction(@npx, reverse_dir(horz), move_tiles)
      @py = $game_map.py_with_direction(@npy, reverse_dir(vert), move_tiles)
      increase_steps
    else
      bounding_box(horz).moveto(@px, @py)
      bounding_box(vert).moveto(@px, @py)
    end
    @move_speed = orginal_speed
    set_direction(@direction)
    set_direction(horz) if @direction == reverse_dir(horz)
    set_direction(vert) if @direction == reverse_dir(vert)
    if !@move_succeed && @smartmove[:dir]
      if passable?(@px, @py, horz)
        move_straight(horz)
      elsif passable?(@px, @py, vert)
        move_straight(vert)
      end
    end
  end
  #--------------------------------------------------------------------------
  # * Smart move
  #--------------------------------------------------------------------------
  def smart_move(d, diag=false)
    return if @move_succeed && !self.is_a?(Game_Player)
    while !@move_succeed
      break if @move_speed < 1
      @move_speed -= 1
      if diag
        @move_succeed = diagonal_passable?(@px, @py, d[0], d[1])
      else
        @move_succeed = passable?(@px, @py, d)
      end
    end
  end
  #--------------------------------------------------------------------------
  # * Fixed Move (Straight)
  #   - Moves a fixed amount of distance
  #--------------------------------------------------------------------------
  def fixed_move(dist)
    d = @direction
    @move_succeed = passable?(@px, @py, d)
    if @move_succeed
      @diagonal = false
      @npx = $game_map.round_px_with_direction(@px, d, dist)
      @npy = $game_map.round_py_with_direction(@py, d, dist)
      @px = $game_map.px_with_direction(@npx, reverse_dir(d), dist)
      @py = $game_map.py_with_direction(@npy, reverse_dir(d), dist)
      increase_steps
    else
      bounding_box(d).moveto(@px, @py)
    end
  end
  #--------------------------------------------------------------------------
  # * Bounding box array
  #--------------------------------------------------------------------------
  def bounding_box(direction = @direction)
    unless @boundingbox
      default = Quasi::Movement::EVENTBOX
      @boundingbox = {}
      @boundingbox[:main] = Bounding_Box.new(default[0], default[1], default[2], default[3])
    end
    return @boundingbox[:main]
  end
end
 
#==============================================================================
# ** Game_Character
#------------------------------------------------------------------------------
#  A character class with mainly movement route and other such processing
# added. It is used as a super class of Game_Player, Game_Follower,
# GameVehicle, and Game_Event.
#==============================================================================
 
class Game_Character < Game_CharacterBase
  #--------------------------------------------------------------------------
  # * Force Move Route
  #--------------------------------------------------------------------------
  alias :qm_gc_force    :force_move_route
  def force_move_route(move_route)
    qm_gc_force(move_route)
    sub_qmove
  end
  #--------------------------------------------------------------------------
  # * Replace qmove() with real moves
  #--------------------------------------------------------------------------
  def sub_qmove
    move = { 2 => ROUTE_MOVE_DOWN,     4 => ROUTE_MOVE_LEFT,
             6 => ROUTE_MOVE_RIGHT,    8 => ROUTE_MOVE_UP,
             1 => ROUTE_MOVE_LOWER_L,  3 => ROUTE_MOVE_LOWER_R,
             7 => ROUTE_MOVE_UPPER_L,  9 => ROUTE_MOVE_UPPER_R  }
    @move_route.list.each_with_index do |list, i|
      next unless list.parameters[0] =~ /qmove/
      qmove =  list.parameters[0].delete "qmove()"
      qmove = qmove.split(",").map {|s| s.to_i}
      qmove[2] ||= 1
      amt = (qmove[1] * qmove[2]) / move_tiles
      amt.floor.times do
        @move_route.list.insert(i+1, RPG::MoveCommand.new(move[qmove[0]]))
      end
    end
    @move_route.list.delete_if {|list| list.parameters[0] =~ /qmove/ }
    memorize_move_route
  end
  #--------------------------------------------------------------------------
  # * Filler method
  #--------------------------------------------------------------------------
  def qmove(dir, steps, multi=1)
  end
  #--------------------------------------------------------------------------
  # * Move at Random
  #--------------------------------------------------------------------------
  def move_random
    if rand(2) == 0
      move_straight(2 + rand(4) * 2, false)
    else
      move_diagonal(4 + rand(2) * 2, 2 + rand(2) * 6)
    end
  end
  #--------------------------------------------------------------------------
  # * Move Toward Character
  #--------------------------------------------------------------------------
  def move_toward_character(character)
    dist = pxl_distance_from(character)
    sx = dist[0]
    sy = dist[1]
    if sx != 0 && sy != 0 && Quasi::Movement::DIR8
      move_diagonal(sx > 0 ? 4 : 6, sy > 0 ? 8 : 2)
    elsif sx.abs > sy.abs
      move_straight(sx > 0 ? 4 : 6)
      move_straight(sy > 0 ? 8 : 2) if !@move_succeed && sy != 0
    elsif sy != 0
      move_straight(sy > 0 ? 8 : 2)
      move_straight(sx > 0 ? 4 : 6) if !@move_succeed && sx != 0
    end
  end
  #--------------------------------------------------------------------------
  # * Move Away from Character
  #--------------------------------------------------------------------------
  def move_away_from_character(character)
    dist = pxl_distance_from(character)
    sx = dist[0]
    sy = dist[1]
    if sx != 0 && sy != 0 && Quasi::Movement::DIR8
      move_diagonal(sx > 0 ? 6 : 4, sy > 0 ? 2 : 8)
    elsif sx.abs > sy.abs
      move_straight(sx > 0 ? 6 : 4)
      move_straight(sy > 0 ? 2 : 8) if !@move_succeed && sy != 0
    elsif sy != 0
      move_straight(sy > 0 ? 2 : 8)
      move_straight(sx > 0 ? 6 : 4) if !@move_succeed && sx != 0
    end
  end
  #--------------------------------------------------------------------------
  # * Turn Toward Character
  #--------------------------------------------------------------------------
  def turn_toward_character(character)
    sx = distance_px_from(character)
    sy = distance_py_from(character)
    if sx.abs > sy.abs
      set_direction(sx > 0 ? 4 : 6)
    elsif sy != 0
      set_direction(sy > 0 ? 8 : 2)
    end
  end
  #--------------------------------------------------------------------------
  # * Turn Away from Character
  #--------------------------------------------------------------------------
  def turn_away_from_character(character)
    sx = distance_px_from(character)
    sy = distance_py_from(character)
    if sx.abs > sy.abs
      set_direction(sx > 0 ? 6 : 4)
    elsif sy != 0
      set_direction(sy > 0 ? 2 : 8)
    end
  end
  #--------------------------------------------------------------------------
  # * Calculate Distance in X Axis Direction
  #--------------------------------------------------------------------------
  def distance_px_from(obj)
    result = @px - obj.px
    width = $game_map.width * 32
    if $game_map.loop_horizontal? && result.abs > width / 2
      if result < 0
        result += width
      else
        result -= width
      end
    end
    return result
  end
  #--------------------------------------------------------------------------
  # * Calculate Distance in Y Axis Direction
  #--------------------------------------------------------------------------
  def distance_py_from(obj)
    result = @py - obj.py
    height = $game_map.height * 32
    if $game_map.loop_vertical? && result.abs > height / 2
      if result < 0
        result += height
      else
        result -= height
      end
    end
    return result
  end
  #--------------------------------------------------------------------------
  # * Calculate Distance in pixel from obj
  #--------------------------------------------------------------------------
  def pxl_distance_from(obj)
    bb = bounding_box
    x1 = @px - obj.px
    y1 = @py - obj.py
    x2 = y2 = 0
    if obj.diagonal?
      x2 = x1.abs > bb.width ? pxl_adjust_wbox(x1, :x, bb) : 0
      y2 = y1.abs > bb.height ? pxl_adjust_wbox(y1, :y, bb) : 0
    elsif obj.direction == 4 || obj.direction == 6
      x2 = x1.abs > bb.width ? pxl_adjust_wbox(x1, :x, bb) : 0
      y2 = bb.center[1] - obj.bounding_box.center[1]
    elsif obj.direction == 8 || obj.direction == 2
      y2 = y1.abs > bb.height ? pxl_adjust_wbox(y1, :y, bb) : 0
      x2 = bb.center[0] - obj.bounding_box.center[0]
    end
    if self.is_a?(Game_Follower)
      return [x1, y1] if $game_player.followers_gathering?
    end
    return [x2, y2]
  end
  #--------------------------------------------------------------------------
  # * Adjust distance with box
  # (Finds out if it should add/sub the width or height of the box to value)
  #--------------------------------------------------------------------------
  def pxl_adjust_wbox(value, axis, bb)
    if axis == :x
      if value < 0
        value += bb.width
      else
        value -= bb.width
      end
    elsif axis == :y
      if value < 0
        value += bb.height
      else
        value -= bb.height
      end
    end
    return value
  end
end
 
#==============================================================================
# ** Game_Event
#------------------------------------------------------------------------------
#  This class handles events. Functions include event page switching via
# condition determinants and running parallel process events. Used within the
# Game_Map class.
#==============================================================================
 
class Game_Event < Game_Character
  #--------------------------------------------------------------------------
  # * Object Initialization
  #     event:  RPG::Event
  #--------------------------------------------------------------------------
  def initialize(map_id, event)
    super()
    @map_id = map_id
    @event = event
    @id = @event.id
    @freq_count = 0
    @px = event.x * 32
    @py = event.y * 32
    refresh
  end
  #--------------------------------------------------------------------------
  # * Initialize starting position
  #--------------------------------------------------------------------------
  def init_pos(px, py)
    ox = initial_offset[0]
    oy = initial_offset[1]
    x1 = px + ox
    y1 = py + oy
    pxl_moveto(x1, y1)
  end
  #--------------------------------------------------------------------------
  # * Initial offsets
  #--------------------------------------------------------------------------
  def initial_offset
    unless @offsets
      ox = grab_comment(/<ox=(.*)>/i, 0)
      oy = grab_comment(/<oy=(.*)>/i, 0)
      @offsets = [ox.to_i, oy.to_i]
    end
    return @offsets
  end
  #--------------------------------------------------------------------------
  # * Update While Stopped
  #--------------------------------------------------------------------------
  def update_stop
    @freq_count += 1 unless @locked
    update_routine_move if @move_route_forcing
    update_self_movement unless @move_route_forcing
  end
  #--------------------------------------------------------------------------
  # * Update During Autonomous Movement
  #--------------------------------------------------------------------------
  def update_self_movement
    return unless near_the_screen?
    return if @locked
    if @freq_count <= real_freq
      case @move_type
      when 1;  move_type_random
      when 2;  move_type_toward_player
      when 3;  move_type_custom
      end
    else
      @stop_count += 1
      if @stop_count > stop_count_threshold
        @freq_count = @stop_count = 0
      end
    end
  end
  #--------------------------------------------------------------------------
  # * Get real frequency
  #--------------------------------------------------------------------------
  def real_freq
    return Quasi::Movement::EVENTFREQ / move_tiles
  end
  #--------------------------------------------------------------------------
  # * Detect Collision with Character
  #--------------------------------------------------------------------------
  def collide_with_box?(x, y)
    super || collide_with_player_characters?(x, y)
  end
  #--------------------------------------------------------------------------
  # * Detect Collision with Player (Including Followers)
  #--------------------------------------------------------------------------
  def collide_with_player_characters?(x, y)
    normal_priority? && $game_player.box?(bounding_box.box(x, y))
  end
  #--------------------------------------------------------------------------
  # * Determine if Touch Event is Triggered
  #--------------------------------------------------------------------------
  def check_event_trigger_touch(x, y)
    return if $game_map.interpreter.running?
    if @trigger == 2 && $game_player.box?(bounding_box.box(x, y), false)
      start if !jumping? && normal_priority?
    end
  end
  #--------------------------------------------------------------------------
  # * Set Up Event Page Settings
  #--------------------------------------------------------------------------
  alias :qm_ge_setup    :setup_page_settings
  def setup_page_settings
    qm_ge_setup
    init_pos(px, py)
    sub_qmove
  end
  #--------------------------------------------------------------------------
  # * Move Type : Random
  #--------------------------------------------------------------------------
  def move_type_random
    if @freq_count == 1 || !@rand_dir
      if Quasi::Movement::DIR8
        @rand_dir = 1 + rand(8)
        @rand_dir += 1 if @rand_dir >= 5
      else
        @rand_dir = 2 + rand(4) * 2
      end
    end
    if [2, 4, 6, 8].include?(@rand_dir)
      move_straight(@rand_dir, false)
    else
      move_diagonal(@dir8[@rand_dir][0], @dir8[@rand_dir][1])
    end
  end
  #--------------------------------------------------------------------------
  # * Bounding box
  #--------------------------------------------------------------------------
  def bounding_box(direction = @direction)
    unless @boundingbox
      @boundingbox = {}
      default = Quasi::Movement::EVENTBOX
      bb = Quasi::regex(comments, /<bbox>(.*)<\/bbox>/im, :linehash)
      if bb
        bb.each do |k, v|
          v[0] ||= default[0]
          v[1] ||= default[1]
          v[2] ||= default[2]
          v[3] ||= default[3]
          @boundingbox[k] = Bounding_Box.new(v[0], v[1], v[2], v[3], shift_y)
        end
      else
        defaultstring = "#{default[0]},#{default[1]},#{default[2]},#{default[3]}"
        bb = grab_comment(/<bbox=(.*)>/i, defaultstring)
        bb = bb.to_ary
        bb[0] ||= default[0]
        bb[1] ||= default[1]
        bb[2] ||= default[2]
        bb[3] ||= default[3]
        @boundingbox[:main] = Bounding_Box.new(bb[0], bb[1], bb[2], bb[3], shift_y)
      end
    end
    return @boundingbox["dir#{direction}".to_sym] || @boundingbox[:main]
  end
end
 
#==============================================================================
# ** Game_Player
#------------------------------------------------------------------------------
#  This class handles the player. It includes event starting determinants and
# map scrolling functions. The instance of this class is referenced by
# $game_player.
#==============================================================================
 
class Game_Player < Game_Character
  #--------------------------------------------------------------------------
  # * Frame Update
  #--------------------------------------------------------------------------
  def update
    last_real_x = @real_x
    last_real_y = @real_y
    move_by_input
    last_moving = moving?
    super
    update_scroll(last_real_x, last_real_y)
    update_vehicle
    update_nonmoving(last_moving) unless moving?
    @followers.update
  end
  #--------------------------------------------------------------------------
  # * Determine if Tile is Passable
  #--------------------------------------------------------------------------
  def tilebox_passable?(x, y, d)
    unless [2, 4, 6, 8].include?(d)
      return tilebox_passable?(x, y, 2) && tilebox_passable?(x, y, 8) &&
        tilebox_passable?(x, y, 4) && tilebox_passable?(x, y, 6)
    end
    edge = bounding_box.edge(d)
    x1 = edge[0][0].floor
    x2 = edge[1][0].floor
    y1 = edge[0][1].floor
    y2 = edge[1][1].floor
    if !$game_map.collisionmap_passable?(x1, y1, @vehicle_type) ||
      !$game_map.collisionmap_passable?(x2, y2, @vehicle_type)
      return false
    end
    if [2, 8].include?(d)
      for x in x1..x2
        next unless x % Quasi::Movement::OPT == 0
        return false unless $game_map.collisionmap_passable?(x, y1, @vehicle_type)
      end
    else
      for y in y1..y2
        next unless y % Quasi::Movement::OPT == 0
        return false unless $game_map.collisionmap_passable?(x1, y, @vehicle_type)
      end
    end
    return true
  end
  #--------------------------------------------------------------------------
  # * Detect Collision with Vehicle
  #--------------------------------------------------------------------------
  def collide_with_vehicles?(x, y)
    return false unless @vehicle_type == :walk
    $game_map.boat.box?(bounding_box.box(x,y)) ||
    $game_map.ship.box?(bounding_box.box(x,y))
  end
  #--------------------------------------------------------------------------
  # * Processing of Movement via Input from Directional Buttons
  #--------------------------------------------------------------------------
  def move_by_input
    return if !movable? || $game_map.interpreter.running?
    if Quasi::Movement::DIR8
      if Input.dir8 > 0
        dia = {7 => [4, 8], 1 => [4, 2], 9 => [6, 8], 3 => [6, 2]}
        if [1, 7, 9, 3].include?(Input.dir8)
          move_diagonal(dia[Input.dir8][0], dia[Input.dir8][1])
        elsif [2, 4, 6, 8].include?(Input.dir8)
          move_straight(Input.dir8)
        end
      end
    else
      move_straight(Input.dir4) if Input.dir4 > 0
    end
  end
  #--------------------------------------------------------------------------
  # * Trigger Map Event
  #     triggers : Trigger array
  #     normal   : Is priority set to [Same as Characters] ?
  #--------------------------------------------------------------------------
  def start_map_event(x, y, triggers, normal)
    return if $game_map.interpreter.running?
    x2 = $game_map.unround_px(x)
    y2 = $game_map.unround_py(y)
    looped = $game_map.loop_horizontal? || $game_map.loop_vertical?
    boxes = $game_map.bounding_xy(bounding_box.box(x, y), false)
    if looped && (x2 != x || y2 != y)
      boxes += $game_map.bounding_xy(bounding_box.box(x2, y2), false)
    end
    boxes.each do |event|
      if event.trigger_in?(triggers) && event.normal_priority? == normal
        event.start
      end
    end
  end
  #--------------------------------------------------------------------------
  # * Determine if Same Position Event is Triggered
  #--------------------------------------------------------------------------
  def check_event_trigger_here(triggers)
    start_map_event(@px, @py, triggers, false)
  end
  #--------------------------------------------------------------------------
  # * Determine if Front Event is Triggered
  #--------------------------------------------------------------------------
  def check_event_trigger_there(triggers)
    dir = @direction
    x1 = dir == 4 ? @px - move_tiles : dir == 6 ? @px + move_tiles : @px
    y1 = dir == 8 ? @py - move_tiles : dir == 2 ? @py + move_tiles : @py
    start_map_event(x1, y1, triggers, true)
    return if $game_map.any_event_starting?
    bounding_box.moveto(x1, y1)
    unless [2, 4, 6, 8].include?(dir)
      bounding_box.moveto(@px, @py)
      return
    end
    edge = bounding_box.edge32(dir)
    bounding_box.moveto(@px, @py)
    x2 = edge[0][0];   x3 = edge[1][0]
    y2 = edge[0][1];   y3 = edge[1][1]
    return unless $game_map.tilecounter?(x2, y2) || $game_map.tilecounter?(x3, y3)
    w = 32 + bounding_box.width + bounding_box.ox
    h = 32 + bounding_box.height + bounding_box.oy
    x4 = dir == 4 ? @px - w : dir == 6 ? @px + w : @px
    y4 = dir == 8 ? @py - h : dir == 2 ? @py + h : @py
    start_map_event(x4, y4, triggers, true)
  end
  #--------------------------------------------------------------------------
  # * Board Vehicle
  #    Assumes that the player is not currently in a vehicle.
  #--------------------------------------------------------------------------
  def get_on_vehicle
    front_x = $game_map.round_px_with_direction(@px, @direction, 32)
    front_y = $game_map.round_py_with_direction(@py, @direction, 32)
    @vehicle_type = :airship if $game_map.airship.box?(bounding_box.box(@px, @py))
    @vehicle_type = :boat    if $game_map.boat.box?(bounding_box.box(front_x, front_y))
    @vehicle_type = :ship    if $game_map.ship.box?(bounding_box.box(front_x, front_y))
    if vehicle
      @vehicle_getting_on = true
      distx = vehicle.px - @px
      disty = vehicle.py - @py
      dist = disty
      dist = distx if @direction == 4 || @direction == 6
      if dist == distx
        dir = @direction
        newdir = disty < 0 ? 8 : 2
        set_direction(newdir)
        force_move_towards(disty.abs)
      elsif dist == disty
        dir = @direction
        newdir = distx < 0 ? 4 : 6
        set_direction(newdir)
        force_move_towards(distx.abs)
      end
      update_move while moving?
      set_direction(dir)
      force_move_towards(dist.abs)
      @followers.gather
    end
    @vehicle_getting_on
  end
  #--------------------------------------------------------------------------
  # * Get Off Vehicle
  #    Assumes that the player is currently riding in a vehicle.
  #--------------------------------------------------------------------------
  def get_off_vehicle
    if vehicle.land_ok?(@px, @py, @direction)
      @boundingbox.each {|k, v| v.moveto(@px, @py)}
      set_direction(2) if in_airship?
      @followers.synchronize(@x, @y, @direction)
      vehicle.get_off
      unless in_airship?
        force_move_towards(32)
        @transparent = false
      end
      @vehicle_getting_off = true
      @move_speed = 4
      @through = false
      make_encounter_count
      @followers.gather
    end
    @vehicle_getting_off
  end
  #--------------------------------------------------------------------------
  # * Move Straight
  #--------------------------------------------------------------------------
  def move_straight(d, turn_ok = true)
    @followers.move if passable?(@px, @py, d)
    super
  end
  #--------------------------------------------------------------------------
  # * Move Diagonally
  #--------------------------------------------------------------------------
  def move_diagonal(horz, vert)
    @followers.move if diagonal_passable?(@px, @py, horz, vert)
    super
  end
  #--------------------------------------------------------------------------
  # * Force One Step Forward
  #--------------------------------------------------------------------------
  def force_move_towards(dist)
    @through = true
    fixed_move(dist)
    @through = false
  end
  #--------------------------------------------------------------------------
  # * Check if followers are gathering
  #--------------------------------------------------------------------------
  def followers_gathering?
    return @followers.gathering?
  end
  #--------------------------------------------------------------------------
  # * Bounding box
  #--------------------------------------------------------------------------
  def bounding_box(direction = @direction)
    unless @boundingbox
      @boundingbox = {}
      if actor.actor.bounding_box.is_a?(Hash)
        actor.actor.bounding_box.each do |k, v|
          v[0] ||= Quasi::Movement::PLAYERBOX[0]
          v[1] ||= Quasi::Movement::PLAYERBOX[1]
          v[2] ||= Quasi::Movement::PLAYERBOX[2]
          v[3] ||= Quasi::Movement::PLAYERBOX[3]
          @boundingbox[k] = Bounding_Box.new(v[0], v[1], v[2], v[3], shift_y)
        end
      else
        v = actor.actor.bounding_box
        v[0] ||= Quasi::Movement::PLAYERBOX[0]
        v[1] ||= Quasi::Movement::PLAYERBOX[1]
        v[2] ||= Quasi::Movement::PLAYERBOX[2]
        v[3] ||= Quasi::Movement::PLAYERBOX[3]
        @boundingbox[:main] = Bounding_Box.new(v[0], v[1], v[2], v[3], shift_y)
      end
    end
    return vehicle.bounding_box if vehicle
    return @boundingbox["dir#{direction}".to_sym] || @boundingbox[:main]
  end
end
 
#==============================================================================
# ** Game_Follower
#------------------------------------------------------------------------------
#  This class handles followers. A follower is an allied character, other than
# the front character, displayed in the party. It is referenced within the
# Game_Followers class.
#==============================================================================
 
class Game_Follower < Game_Character
  #--------------------------------------------------------------------------
  # * Pursue Preceding Character
  #--------------------------------------------------------------------------
  def chase_preceding_character
    unless moving?
      dist = pxl_distance_from(@preceding_character)
      sx = dist[0]
      sy = dist[1]
      if sx.abs > 2 && sy.abs > 2
        move_diagonal(sx > 0 ? 4 : 6, sy > 0 ? 8 : 2)
      elsif sx.abs > 2
        move_straight(sx > 0 ? 4 : 6)
      elsif sy.abs > 2
        move_straight(sy > 0 ? 8 : 2)
      end
    end
  end
  #--------------------------------------------------------------------------
  # * Determine if at Same Position as Preceding Character
  #--------------------------------------------------------------------------
  def gather?
    prev = @preceding_character
    !moving? && box?(prev.bounding_box.box(prev.px, prev.py), false)
  end
  #--------------------------------------------------------------------------
  # * Bounding box
  #--------------------------------------------------------------------------
  def bounding_box(direction = @direction)
    unless @boundingbox
      @boundingbox = {}
      if actor
        if actor.actor.bounding_box.is_a?(Hash)
          actor.actor.bounding_box.each do |k, v|
            v[0] ||= Quasi::Movement::PLAYERBOX[0]
            v[1] ||= Quasi::Movement::PLAYERBOX[1]
            v[2] ||= Quasi::Movement::PLAYERBOX[2]
            v[3] ||= Quasi::Movement::PLAYERBOX[3]
            @boundingbox[k] = Bounding_Box.new(v[0], v[1], v[2], v[3], shift_y)
          end
        else
          v = actor.actor.bounding_box
          v[0] ||= Quasi::Movement::PLAYERBOX[0]
          v[1] ||= Quasi::Movement::PLAYERBOX[1]
          v[2] ||= Quasi::Movement::PLAYERBOX[2]
          v[3] ||= Quasi::Movement::PLAYERBOX[3]
          @boundingbox[:main] = Bounding_Box.new(v[0], v[1], v[2], v[3], shift_y)
        end
      else
        v = Quasi::Movement::PLAYERBOX
        @boundingbox[:main] = Bounding_Box.new(v[0], v[1], v[2], v[3], shift_y)
      end
    end
    return @boundingbox["dir#{direction}".to_sym] || @boundingbox[:main]
  end
end
 
#==============================================================================
# ** Game_Vehicle
#------------------------------------------------------------------------------
#  This class handles vehicles. It's used within the Game_Map class. If there
# are no vehicles on the current map, the coordinates are set to (-1,-1).
#==============================================================================
 
class Game_Vehicle < Game_Character
  #--------------------------------------------------------------------------
  # * Synchronize With Player
  #--------------------------------------------------------------------------
  alias :qm_gv_sync  :sync_with_player
  def sync_with_player
    qm_gv_sync
    @npy = @py = $game_player.py
    @npx = @px = $game_player.px
    bounding_box
    @boundingbox.each {|k, v| v.moveto(@py, @px)}
  end
  #--------------------------------------------------------------------------
  # * Determine if Docking/Landing Is Possible
  #     d:  Direction (2,4,6,8)
  #--------------------------------------------------------------------------
  def land_ok?(x, y, d)
    bounding_box.moveto(x, y)
    if @type == :airship
      return false unless tilebox_passable?(x, y, d)
      return false if collide_with_box?(x, y)
    else
      x1 = d == 4 ? x - 32 : d == 6 ? x + 32: x
      y1 = d == 8 ? y - 32 : d == 2 ? y + 32 : y
      x2 = $game_map.round_px(x1)
      y2 = $game_map.round_py(y1)
      bounding_box.moveto(x2, y2)
      return false unless valid?(d)
      return false unless tilebox_passable?(x2, y2, d)
      return false if collide_with_box?(x2, y2)
    end
    return true
  end
  #--------------------------------------------------------------------------
  # * Check for Bounding box Collision
  #  Returns true if boxes are inside each other.
  #--------------------------------------------------------------------------
  def box?(objbox, through=nil)
    return false if transparent
    super
  end
  #--------------------------------------------------------------------------
  # * Detect Collision with Character
  #--------------------------------------------------------------------------
  def collide_with_box?(x, y)
    boxes = $game_map.bounding_xy(bounding_box.box(x,y))
    unless boxes.empty?
      boxes.keep_if {|e| e != self && e.normal_priority?}
    end
    !boxes.empty?
  end
  #--------------------------------------------------------------------------
  # * Bounding box
  #--------------------------------------------------------------------------
  def bounding_box
    return @boundingbox[:main] if @boundingbox
    box = Quasi::Movement::VEHICLES[@type]
    box[2] ||= 0
    box[3] ||= 0
    @boundingbox = {}
    @boundingbox[:main] = Bounding_Box.new(box[0], box[1], box[2], box[3])
  end
end
 
#==============================================================================
# ** RPG::BaseItem
#==============================================================================
 
class RPG::Actor
  def bounding_box
    if @bounding_box.nil?
      default = Quasi::Movement::PLAYERBOX
      bb = Quasi::regex(@note, /<bbox>(.*)<\/bbox>/im, :linehash)
      if bb
        bb[:main] = default unless bb[:main]
      else
        bb = Quasi::regex(@note, /<bbox=(.*)>/i, :array, default)
      end
      @bounding_box = bb
    end
    return @bounding_box
  end
end
 
#==============================================================================
# ** Sprite_Character
#------------------------------------------------------------------------------
#  This sprite is used to display characters. It observes an instance of the
# Game_Character class and automatically changes sprite state.
#==============================================================================
 
class Sprite_Character < Sprite_Base
  #--------------------------------------------------------------------------
  # * Object Initialization
  #     character : Game_Character
  #--------------------------------------------------------------------------
  alias :qbox_init    :initialize
  def initialize(viewport, character = nil)
    qbox_init(viewport, character)
    start_box if Quasi::Movement::SHOWBOXES && $TEST
  end
  #--------------------------------------------------------------------------
  # * Frame Update
  #--------------------------------------------------------------------------
  alias :qbox_update   :update
  def update
    qbox_update
    update_box if @box_sprite
  end
  #--------------------------------------------------------------------------
  # * Free
  #--------------------------------------------------------------------------
  alias :qbox_dispose   :dispose
  def dispose
    qbox_dispose
    dispose_box
  end
  #--------------------------------------------------------------------------
  # * Free box
  #--------------------------------------------------------------------------
  def dispose_box
    return unless @box_sprite
    @box_sprite.bitmap.dispose if @box_sprite.bitmap
    @box_sprite.dispose
  end
  #--------------------------------------------------------------------------
  # * Start Box Display
  #--------------------------------------------------------------------------
  def start_box
    @box_sprite = Sprite.new(viewport)
    @bbox = @character.bounding_box
    @box_sprite.bitmap = Bitmap.new(@bbox.width, @bbox.height)
    @box_sprite.bitmap.fill_rect(@box_sprite.bitmap.rect, Quasi::Movement::BOXCOLOR)
    @box_sprite.ox += 16 - @bbox.ox
    @box_sprite.oy += 32 - @bbox.oy
    @box_sprite.x = @character.x
    @box_sprite.y = @character.y
    @box_sprite.z = z
    @box_sprite.blend_type = Quasi::Movement::BOXBLEND
  end
    #--------------------------------------------------------------------------
  # * Update Box
  #--------------------------------------------------------------------------
  def update_box
    return unless @box_sprite
    @box_sprite.x = x if @box_sprite.x != x
    @box_sprite.y = y if @box_sprite.y != y
    @box_sprite.visible = self.visible
    if @character.is_a?(Game_Follower)
      @box_sprite.visible = @character.visible?
    else
      @box_sprite.visible = !@character.transparent
    end
    if @bbox != @character.bounding_box
      start_box
    end
    if @character.bounding_box.is_a?(Hash)
      if @bdir != @character.direction
        dispose_box
        start_box
      end
    end
  end
end
 
#==============================================================================
# ** Spriteset_Map
#------------------------------------------------------------------------------
#  This class brings together map screen sprites, collisionmaps, etc. It's used
# within the Scene_Map class.
#==============================================================================
 
class Spriteset_Map
  #--------------------------------------------------------------------------
  # * Object Initialization
  #--------------------------------------------------------------------------
  alias :qbox_sm_init    :initialize
  def initialize
    qbox_sm_init
    create_boxes
  end
  #--------------------------------------------------------------------------
  # * Start Box Display
  #--------------------------------------------------------------------------
  def create_boxes
    return unless $game_map
    @box_sprite = Sprite.new
    @box_sprite.bitmap = $game_map.collisionmap.clone
    @box_sprite.visible = Quasi::Movement::SHOWBOXES && $TEST
    @box_sprite.blend_type = Quasi::Movement::BOXBLEND
    @box_sprite.opacity = Quasi::Movement::BOXCOLOR.alpha
  end
  #--------------------------------------------------------------------------
  # * Free Tilebox
  #--------------------------------------------------------------------------
  def dispose_tilebox
    return unless @box_sprite
    @box_sprite.bitmap.dispose if @box_sprite.bitmap
    @box_sprite.dispose
  end
  #--------------------------------------------------------------------------
  # * Refresh Characters
  #--------------------------------------------------------------------------
  alias :qbox_sm_refresh    :refresh_characters
  def refresh_characters
    qbox_sm_refresh
    dispose_tilebox
    create_boxes
  end
  #--------------------------------------------------------------------------
  # * Frame Update
  #--------------------------------------------------------------------------
  alias qbox_sm_update update
  def update
    qbox_sm_update
    update_boxes
  end
  #--------------------------------------------------------------------------
  # * Update Boxes
  #--------------------------------------------------------------------------
  def update_boxes
    return unless @box_sprite
    @box_sprite.ox = $game_map.display_x * 32
    @box_sprite.oy = $game_map.display_y * 32
  end
end
 
#==============================================================================
# ** RPG::Map
#==============================================================================
 
class RPG::Map
  #--------------------------------------------------------------------------
  # * Collision Map notetag
  #--------------------------------------------------------------------------
  def collisionmap
    if @collisionmap.nil?
      @collisionmap = Quasi::regex(@note, /<cm=(.*)>/i, :string)
    end
    return @collisionmap
  end
end
else
  msgbox(sprintf("[Quasi Movement] Requires Quasi module."))
end