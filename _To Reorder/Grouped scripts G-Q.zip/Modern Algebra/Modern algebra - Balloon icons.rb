=begin
start_icon_balloon(character_id, icon_index, icon_hue, wait?, bg)
Where:
character_id - The character over which you want the balloon to show. If -1, it will show over the player. If 0, it will show over the event in which the command is called, and if anything else, it will play over the event with that ID.
icon_index - The index of the icon to draw
icon_hue - The hue of the icon when drawn. Default is 0.
wait? - When true, this will wait until the balloon disappears before continuing processing the event. When false, it will not. Defaults to true
bg - a String containing the name of the graphic for the balloon behind the icon. Defaults to whatever you have at line 68


=end
#==============================================================================
#    Icon Balloons
#    Version: 1.0.1
#    Author: modern algebra (rmrk.net)
#    Date: 7 April 2015
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#  Description:
#    
#    This script allows you to draw an icon into a balloon and have it play 
#   over the head of a character.
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#  Instructions:
#    
#    Paste this script into its own slot in the Script Editor, above Main but
#   below Materials.
#
#    To show an icon balloon, all you need to do is use the following code in
#   a Script event command:
#
#        start_icon_balloon(character_id, icon_index, icon_hue, wait?, bg)
#
#   where:
#      character_id - The character over which you want the balloon to show. If
#        -1, it will show over the player. If 0, it will show over the event in
#        which the command is called, and if anything else, it will play over
#        the event with that ID.
#      icon_index - The index of the icon to draw
#      icon_hue - The hue of the icon when drawn. Default is 0.
#      wait? - When true, this will wait until the balloon disappears before
#        continuing processing the event. When false, it will not. Defaults to
#        true
#      bg - a String containing the name of the graphic for the balloon behind
#        the icon. Defaults to whatever you have at line 68
#
#  EXAMPLES:
#
#    start_icon_balloon(-1, 74)
#      That plays icon 74 over the player.
#
#    start_icon_balloon(7, 115, 120)
#      That plays icon 115 over Event 7, and the icon is hue-shifted 120 
#     degrees
#
#    start_icon_balloon(0, 124, 0, false)
#      That plays icon 124 over this event, and event processing will not be 
#     paused to wait for the balloon's completion.
#
#    bg = "Icon_Balloon_Base2"
#    start_icon_balloon(4, 87, 200, false, bg)
#      That plays icon 87 over Event 7, the icon is hue-shifted 200 degrees,
#     event processing will not be paused to wait for the balloon's completion, 
#     and the balloon graphic will be "Icon_Balloon_Base2" instead of whatever 
#     you hnamed at line 68.
#``````````````````````````````````````````````````````````````````````````````
#  Please take note: you must put an image called "Icon_Balloon_Base" in the
# System folder of Graphics. You can change the name of the file at line 68 if
# you want, but there must be a base balloon graphic.
#
#  You can also change the size of the icon at each frame by adjusting the
# percentage values in the array at line 64.
#==============================================================================

$imported ||= {}
$imported[:MA_IconBalloons] = true

#\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
#  BEGIN Editable Region
#||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
# MAIB_BALLOON_GRAPHIC - the name of the balloon file in Graphics/System/
MAIB_BALLOON_GRAPHIC = "Icon_Balloon_Base" 
# MAIB_ICON_ZOOM - this array determines what size the icon is at each frame.
#  Just put an integer for the percentage zoom you want. 100 will show it at 
#  full size, 50 at half-size, 200 at double size, etc.
MAIB_ICON_ZOOM = [0, 50, 100, 115, 100, 100, 100, 100]
#||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
#  END Editable Region
#//////////////////////////////////////////////////////////////////////////////
MAIB_MAX_ICON_BALLOONS = 4 # Maximum number of icon balloons active at one time
MAIB_LAST_BALLOON_INDEX = 10 # Last normal index on the balloon sheet

#==============================================================================
# *** Cache
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#  Summary of Changes:
#    aliased method - self.system
#==============================================================================

class << Cache
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * Get System Graphic
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  alias maib_systm_9kx2 system
  def system(filename, *args, &block)
    if filename == "Balloon" && !include?("Graphics/System/Balloon")
      # Modify Balloon graphic to add another row.
      bmp = maib_systm_9kx2(filename, *args, &block) # Call Original Method
      @cache["Graphics/System/Balloon"] = Bitmap.new(bmp.width, 
        [32*(MAIB_LAST_BALLOON_INDEX + MAIB_MAX_ICON_BALLOONS), bmp.height].max)
      @cache["Graphics/System/Balloon"].blt(0, 0, bmp, bmp.rect)
      bmp.dispose
      @cache["Graphics/System/Balloon"]
    else
      maib_systm_9kx2(filename, *args, &block) # Call Original Method
    end
  end
end

#==============================================================================
# ** Game_CharacterBase
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#  Summary of Changes:
#    new attr_accessor - icon_balloon_id; icon_balloon_hue; icon_balloon_queue
#    aliased method - init_public_members
#==============================================================================

class Game_CharacterBase
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * Public Instance Variables
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  attr_accessor :icon_balloon_id
  attr_accessor :icon_balloon_hue
  attr_accessor :icon_balloon_queue
  attr_accessor :icon_balloon_base_graphic
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * Initialize Public Variables
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  alias maib_iniz_pubvars_1jw4 init_public_members
  def init_public_members(*args, &block)
    @icon_balloon_id = 0
    @icon_balloon_hue = 0
    @icon_balloon_queue = []
    @icon_balloon_base_graphic = MAIB_BALLOON_GRAPHIC
    maib_iniz_pubvars_1jw4(*args, &block) # Call Original Method
  end
end

#==============================================================================
# ** Game_Interpreter
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#  Summary of Changes:
#    new methods - start_icon_balloon
#==============================================================================

class Game_Interpreter
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * Start Icon Balloon
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def start_icon_balloon(character_id, icon_index, hue = 0, waiting = true, base_graphic = MAIB_BALLOON_GRAPHIC)
    character = get_character(character_id)
    # Adjust variables if sequence is out of order
    if character
      if waiting.is_a?(String)
        base_graphic = waiting 
      elsif hue.is_a?(String)
        base_graphic = hue
      end
      waiting = hue if hue == false || hue == true
      hue = 0 if !hue.is_a?(Integer)
      if character.balloon_id < 1
        character.balloon_id = MAIB_LAST_BALLOON_INDEX + 1
        character.icon_balloon_id = icon_index
        character.icon_balloon_hue = hue
        character.icon_balloon_base_graphic = base_graphic
        (Fiber.yield while character.icon_balloon_id > 0) if waiting
      else
        character.icon_balloon_queue << [icon_index, hue, base_graphic]
      end
    end
  end
end

#==============================================================================
# ** Sprite_Character
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#  Summary of Changes:
#    new class variables - balloon_icon_id; balloon_icon_hue; balloon_icon_index
#    aliased method - start_balloon; end_balloon
#    new_method - create_icon_balloon_graphic
#==============================================================================

class Sprite_Character
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * Class Variables
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  @@balloon_icon_id = 0    # Index of icon currently drawn to "Balloon"
  @@balloon_icon_hue = 0   # Hue of the icon currently drawn to "Balloon"
  @@balloon_icon_index = MAIB_LAST_BALLOON_INDEX # The index of the icon balloon in "Balloon"
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * Start Balloon
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  alias maib_strtballn_3ys5 start_balloon
  def start_balloon(*args, &block)
    if @character.icon_balloon_id > 0
      create_icon_balloon_graphic
      @balloon_id = @@balloon_icon_index
    end
    maib_strtballn_3ys5(*args, &block) # Call Original Method
  end
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * End Balloon
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  alias maib_endblloon_4nd5 end_balloon
  def end_balloon(*args, &block)
    maib_endblloon_4nd5(*args, &block) # Call Original Method
    if @character.icon_balloon_queue.empty?
      @character.icon_balloon_id = 0
      @character.icon_balloon_base_graphic = MAIB_BALLOON_GRAPHIC
    else
      @character.balloon_id = @@balloon_icon_index
      icon_index, hue, base_graphic = @character.icon_balloon_queue.shift
      @character.icon_balloon_id = icon_index
      @character.icon_balloon_hue = hue
      @character.icon_balloon_base_graphic = base_graphic
    end
  end
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * Create Icon Balloon Graphic
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def create_icon_balloon_graphic
    # Modify balloon icon index
    @@balloon_icon_index += 1
    @@balloon_icon_index = MAIB_LAST_BALLOON_INDEX + 1 if @@balloon_icon_index > MAIB_LAST_BALLOON_INDEX + MAIB_MAX_ICON_BALLOONS 
    icon_id, icon_hue = @character.icon_balloon_id, @character.icon_balloon_hue
    # Create Icon Bitmap
    icon_bmp = Cache.system("Iconset")
    ind_icon_bmp = Bitmap.new(24, 24)
    rect = Rect.new(icon_id % 16 * 24, icon_id / 16 * 24, 24, 24)
    ind_icon_bmp.blt(0, 0, icon_bmp, rect)
    ind_icon_bmp.hue_change(icon_hue) unless icon_hue == 0 # Change Hue
    # Draw Blank Balloon on Bitmap
    bmp = Cache.system("Balloon")
    balloon_bg_bmp = Cache.system(@character.icon_balloon_base_graphic)
    y = (@@balloon_icon_index - 1)*32
    bmp.clear_rect(0, y, bmp.width, 32)
    bmp.blt(0, y, balloon_bg_bmp, balloon_bg_bmp.rect)
    # Draw the icon on to the blank balloon
    for i in 0...MAIB_ICON_ZOOM.size
      zoom = MAIB_ICON_ZOOM[i] ? MAIB_ICON_ZOOM[i] : 100
      next if zoom <= 0
      if zoom == 100
        bmp.blt(32*i + 4, y + 4, ind_icon_bmp, ind_icon_bmp.rect)
      else
        size = ((zoom.to_f / 100.0)*24.0).to_i
        centre = (32 - size) / 2
        rect = Rect.new((32*i) + centre, y + centre, size, size)
        bmp.stretch_blt(rect, ind_icon_bmp, ind_icon_bmp.rect)
      end
    end
    @@balloon_icon_id = icon_id
    @@balloon_icon_hue = icon_hue
  end
end