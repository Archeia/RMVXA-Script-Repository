#==============================================================================
#  Scene Tutorial
#  Version 1.0
#  Original Author: modern algebra (rmrk.net)
#  Date: September 15, 2008
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#  Scene Tutorial to VX ACE
#  Version 1.1
#  Author: TinyMine (rpgmaker-vx-ace.de)
#  Date: 15.06.2014
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#  Description:
#    This script allows you to freeze user input for a scene and run a special
#   common event that controls input. Effectively, this allows you to run a 
#   scene and direct a tutorial to that scene that explains what the scene is.
#   So, if you ever wanted to give the players to your game a tutorial on
#   using the Menu scene, then this is the script for you.
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#  Instructions:
#    Okay, this script can be slightly difficult to use, so you have to pay 
#   careful attention to the instructions.
##    To start a tutorial, you must use a call script with this code:
##        start_tutorial(scene, common_id, return_scene)
##    where scene is the name of the scene to call, (like Scene_Menu or
#   Scene_Battle) and common event ID is the ID of the common event that 
#   controls the tutorial. Return_scene however is the true or false - true for returning
#   to last scene when tutorial was called and false for staying in the scene,
#   when tutorial is finished. Now, that's the easy part. Setting up 
#   the controller common event will be tricky at first, but once you get the 
#   hang of it, you'll be fine. Now, read the instructions very carefully:
##    The Standard Wait Variable - You set what Variable this will be at line
#   200. The value of this variable determines how many frames to wait for 
#   after each command.
##    The controller common event is similar to a regular common event in some 
#   ways but many of the commands will be unavailable to you while others will
#   be irrelevant and others still will have a different effect than you would
#   expect. In the instructions, I will go over the functions of what will be
#   the most important commands in making a scene tutorial, but I just wanted
#   to warn you that many commands will not work as you expect them to. (For
#   instance, pictures, screen tone etc... will only work in a battle or map
#   tutorial). So, depending on how the scene is built, some things are 
#   possible while others are not. Note, however, that in a number of cases, 
#   you can simulate the effect that is not possible. That being said, it can 
#   get quite convoluted, but that was as far as I was willing to go with this 
#   script. I apologize for the difficulty.
##    Anyway, there are a couple of specialized commands that have their function
#   changed from what they would normally do. These are:
##      Control Variable
#      Set Move Route
##    These have been changed so that rather than do what they would normally, 
#   they instead interpret input. Since player input is frozen during a 
#   tutorial, scene movement is handled by you, the game creator. It is done
#   through these two commands. This can be rather non-intuitive, but for each
#   value of 0 through 19, a button is attached. It is similar for Set Move
#   Route, but let's go over the variable way of setting input first.
##    To set it, it must be a single variable set to a constant. If any other
#   option is chosen, then the Control Variable command will function normally.
#   Also, the control variable command will behave normally if the variable you
#   choose is the one you choose for setting standard wait time. Anyway, here 
#   is the list of values and their effects:
##      0  - Down Cursor
#      1  - Left Cursor
#      2  - Right Cursor
#      3  - Up Cursor
#      4  - Button A
#      5  - Button B
#      6  - Button C
#      7  - Button X
#      8  - Button Y
#      9  - Button Z
#      10 - Button L
#      11 - Button R
#      12 - SHIFT
#      13 - CTRL
#      14 - ALT
#      15 - F5
#      16 - F6
#      17 - F7
#      18 - F8
#      19 - F9
##    If you want to wait some frames, the Wait command will work normally.
##    Set Move Route has a similar set of moves attached. They are:
#      Move Down             - Down Cursor
#      Move Left             - Left Cursor
#      Move Right            - Right Cursor
#      Move Up               - Up Cursor
#      Move Lower Left       - Button A
#      Move Lower Right      - Button B
#      Move Upper Left       - Button C
#      Move Upper Right      - Button X
#      Move at Random        - Button Y
#      Move Toward Player    - Button Z
#      Move Away from Player - Button L
#      One Step Forward      - Button R
#      One Step Backward     - SHIFT
#      Jump                  - CTRL
#      Wait                  - Waits for however many frames
#      Turn Down             - ALT
#      Turn Left             - F5
#      Turn Right            - F6
#      Turn Up               - F7
#      Turn 90 Left          - F8
#      Turn 90 Right         - F9
##   So basically, using those commands will make the scene react as if the 
#  corresponding button had just been pressed. 
#==============================================================================
# *** Input
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#  Summary of Changes:
#    aliased method - update, trigger?, press?, repeat?
#============================================================================== 
module Input  
class << self    
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~    
# * Frame Update    
#````````````````````````````````````````````````````````````````````````    
#  Reset the Button if Input.update was not called from default scene update    
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~    
alias modalg_tutorials_update_9rt update unless self.method_defined?(:modalg_tutorials_update_9rt)    
def update      
if $tutorial.active? && caller[0][/`([^']*)'/, 1] != "update_basic"        
$tutorial.button = false      
end      
# Run Original Method      
modalg_tutorials_update_9rt    
end    
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~    
# * Trigger?    
#````````````````````````````````````````````````````````````````````````    
#  If Tutorial is running, freezes input and accepts only tutorial input    
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~    
alias modalg_tut_frz_inpt_trig_dj5 trigger? unless self.method_defined?(:modalg_tut_frz_inpt_trig_dj5)    
def trigger?(key)      
if $tutorial.active? && !$tutorial.upd_input        
return $tutorial.button == key      
end      
# Run Original Method      
modalg_tut_frz_inpt_trig_dj5(key)    
end    
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~    # * Repeat?    #````````````````````````````````````````````````````````````````````````    #  If Tutorial is running, freezes input and accepts only tutorial input    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~    alias modalg_rpt_tutorial_upd_8fn repeat? unless self.method_defined? :)modalg_rpt_tutorial_upd_8fn)    def repeat? (key)      if $tutorial.active? && !$tutorial.upd_input        return $tutorial.button == key      end      # Run Original Method      modalg_rpt_tutorial_upd_8fn (key)    end    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~    # * Press?    #````````````````````````````````````````````````````````````````````````    #  If Tutorial is running, freezes input and accepts only tutorial input    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~    alias modalg_tut_prs_frz_inpt_9nfg press? unless self.method_defined? :)modalg_tut_prs_frz_inpt_9nfg)    def press? (key)      if $tutorial.active? && !$tutorial.upd_input        return $tutorial.button == key      end      # Run Original Method      modalg_tut_prs_frz_inpt_9nfg (key)    end  endend #==============================================================================# *** Scene_Base#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++#  Summary of Changes:#    aliased method - update_basic#==============================================================================class Scene_Base    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  # * Frame Update  #````````````````````````````````````````````````````````````````````````  #  Updates tutorial as well if it exists. Update along with scenes to sync  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  alias_method :modalg_tut_upd_sce_base_3837 ,:update_basic  def update_basic    modalg_tut_upd_sce_base_3837    $tutorial.update if $tutorial.active?  end  end#==============================================================================# ** Game_Interpreter#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++#  Summary of Changes:#    new method: start_tutorial#============================================================================== class Game_Interpreter    def start_tutorial(scene, common_id, return_scene)    $tutorial.start(scene,common_id, return_scene)    # Execute hack command to avoid fiber resuming in new scene    wait(1)  end  end #==============================================================================# ** Tutorial Guide#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++#  This class handles the interpretation of the common event for a tutorial#============================================================================== class Game_TutorialGuide < Game_Interpreter  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  # * Constant  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  # STANDARD WAIT VARIABLE is the ID of the event variable that holds a   #  standard wait between input commands. Basically, if this is set to 2,   #  then Variable with ID 2 will control the wait between actions. So, if  #  Variable with ID 2 is set to 4, then it will wait four frames before   #  executing the next command in the common event  STANDARD_WAIT_VARIABLE = 97  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  # * Object Initialization  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  def initialize    @wait_frames = 0    super  end     #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  # * Execute Fiber  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  def run    wait_for_transition    super  end  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  # * Control Variable  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  def command_122    if @params[3] == 0 || @params[0] == STANDARD_WAIT_VARIABLE       command_input (@params[4] + 1)     else      super     end  end  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  # * Set Move Route  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  def command_205    @move_route = @params[1].list    @moveroute_index = 0    while @move_route[@moveroute_index]        # Execute Input command        command_move (@move_route[@moveroute_index])        @moveroute_index += 1        Fiber.yield    end  end  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  # * Frame Update  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  def update    return unless Graphics.brightness == 255    if @wait_frames > 0      @wait_frames -= 1      return    end    super    return false unless @fiber  end  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  # * Command Input  #    button_code : the key a button corresponds to.  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  def command_input (button_value)    $tutorial.button = case button_value    when 1 then Input::DOWN      # Cursor Down    when 2 then Input::LEFT      # Cursor Left    when 3 then Input::RIGHT     # Cursor Right    when 4 then Input::UP        # Cursor Up    when 5 then Input::A         # Press A    when 6 then Input::B         # Press B    when 7 then Input::C         # Press C    when 8 then Input::X         # Press X    when 9 then Input::Y         # Press Y    when 10 then Input::Z        # Press Z    when 11 then Input::L        # Press L    when 12 then Input::R        # Press R    when 13 then Input::SHIFT    # Press SHIFT    when 14 then Input::CTRL     # Press CTRL    when 15 then Input::ALT      # Press ALT    when 16 then Input::F5       # Press F5    when 17 then Input::F6       # Press F6    when 18 then Input::F7       # Press F7    when 19 then Input::F8       # Press F8    when 20 then Input::F9       # Press F9    end    @wait_frames = [$game_variables[STANDARD_WAIT_VARIABLE], 1].max  end  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  # * Command Move  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  def command_move (command)    command_input (command.code) if command.code < 15    command_wait (command.parameters[0] - 1) if command.code == 15    command_input (command.code - 1) if command.code.between?(16,21)  end  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  # * Command Wait  #    duration : the number of frames to wait  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  def command_wait (duration)    # Wait Frames - Subtract Standard wait frames tacked on by previous command    @wait_frames = duration  end    def wait_for_transition    Fiber.yield until Graphics.brightness == 255  end  end #==============================================================================# ** Tutorial#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++#  This class basically interprets a common event and navigates a scene by the# codes used in that common event#============================================================================== class Tutorial  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  # * Public Instance Variables  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  attr_reader   :upd_input  attr_accessor :button  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  # * Object Initialization  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  def initialize    # Initialize variables    @button = false    @upd_input = false    @active = false    @tutorial_guide = Game_TutorialGuide.new  end  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  # * Start  #    scene           : the scene to guide through  #    common_event_id : the navigation common event   #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  def start (scene, common_event_id, return_last)    @tutorial_guide.setup ($data_common_events[common_event_id].list)    if !!return_last == return_last      return_last ? @old_scene = SceneManager.scene.class : @old_scene = nil    else      defined?(return_last) ? @old_scene = return_last : @old_scene = nil    end    Window_MenuCommand::init_command_position # if Scene_Menu    SceneManager.call(scene)     # Get Common Event    @active = true    @message_window = Window_Message.new if @message_window.nil?    @message_window.z = 500  end  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  # * Update  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  def update    @button = false    # Deactivate Input update and Tutorial update while message is active    @upd_input = true    @active = false    @message_window.update    # Reactivate Input update and Tutorial update when message is done    @upd_input = false    @active = true    if $game_message.visible      return    end    if @tutorial_guide.update == false      @active = false      SceneManager.call(@old_scene) unless @old_scene.nil?    end  end  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  # * Active?  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  def active?    return @active  endend #==============================================================================# ** DataManager#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++#  Summary of Changes:#    aliased methods - load_normal_database, load_battle_test_database#============================================================================== module DataManager  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  # * Load Database  #``````````````````````````````````````````````````````````````````````````  #  Initialize $tutorial  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  class << self    alias modalg_tutorial_scenes_ldb_init_nf4 load_normal_database    alias modalg_tutrl_scn_lbtdb_ak42 load_battle_test_database  end  def self.load_normal_database    # Run Original Method    modalg_tutorial_scenes_ldb_init_nf4    # Initialize Tutorial    $tutorial = Tutorial.new  end  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  # * Load Battle Test Database  #``````````````````````````````````````````````````````````````````````````  #  Initialize $tutorial  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  def self.load_battle_test_database    # Run Original Method    modalg_tutrl_scn_lbtdb_ak42    # Initialize Tutorial    $tutorial = Tutorial.new  endend