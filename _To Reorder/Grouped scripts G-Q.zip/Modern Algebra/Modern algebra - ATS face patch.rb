# patch for MA ATS Name and MA ATS Face box
# moves the window into position as soon as the face is set up instead of on the
# next available frame


class Window_ATS_Name
  
  alias set_x_pos_facesprite set_x_position
  def set_x_position
    set_x_pos_facesprite 
    adjust_for_sprite if $game_message.adjustment_for_sprite
  end
  
  def adjust_for_sprite
    rfx, rfy = $game_message.adjustment_for_sprite
    rnx, rny = self.screen_ranges
    # If name overlaps with face window
    if (rny === rfy.first || rfy === rny.first) && (rnx === rfx.first || 
      rfx === rnx.first)
      # if message window to left
      if rfx.first - self.width > x
        # Move name window to left of face
        self..x = rfx.first - self.width
      else
        self.x = rfx.last
      end
    end
    @test = true
    #$game_message.adjustment_for_sprite = nil
  end
  
end

class Spriteset_ATS_Face
  
  alias refresh_name_patch refresh 
  def refresh(face_name = @face_name, face_index = @face_index)
    result = refresh_name_patch(face_name, face_index)
    $game_message.adjustment_for_sprite = screen_ranges
    $game_message.adjustment_for_sprite = nil if @face_name.nil? || @face_name.empty? 
    result
  end
end

class Game_Message
  attr_accessor :adjustment_for_sprite
  
end