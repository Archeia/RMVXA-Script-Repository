#==============================================================================
#    Hover Alerts + galv's Region Effects
#    Compatibility Patch
#    Version: 1.0
#    Authors: modern algebra (rmrk.net) & galv
#    Date: 5 October 2013
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#  Description:
#
#    This patch fixes an error between my Hover Alerts script and galv's Region
#   Effects script. Without it, a hover alert will constantly refresh when
#   walking through an event-generating region.
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#  Instructions:
#
#    Insert this script into the Script Editor (F11) in a new slot, somewhere 
#   below galv's Region Effects script but still above Main.
#==============================================================================

#==============================================================================
# ** Spriteset_Map
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#  Summary of Changes:
#    new method - gre_refresh_event
#==============================================================================

class Spriteset_Map
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * Refresh Event
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def gre_refresh_event(id)
    # Find any existing event with the same ID
    esi = @character_sprites.find_index {|sprite| sprite && 
      sprite.is_a?(Sprite_Character) && sprite.character.is_a?(Game_Event) && 
      sprite.character.gre_event_id == id }
    if esi
      # Dispose Existing Event
      @character_sprites[esi].dispose if !@character_sprites[esi].disposed?
      @character_sprites.delete_at(esi)
    else
      esi = $game_map.events.values.size - 1
    end
    # Refresh new region event
    @character_sprites.insert(esi, Sprite_Character.new(@viewport1, $game_map.events[id]))
  end
end

#==============================================================================
# ** Game_Event
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#  Summary of Changes:
#    new method - gre_event_id
#==============================================================================

class Game_Event
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * Event ID
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def gre_event_id
    @id # Get Event ID
  end
end

#==============================================================================
# ** Game_Map
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#  Summary of Changes:
#    overwritten method - region_effect
#==============================================================================

class Game_Map
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * Region Effect
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def region_event(dx, dy, event_id, map_id)
    # Retrieve event from the spawn map
    map_id = @map_id if map_id == 0
    event = generated_region_event($data_spawn_map, event_id)
    # Generate ID
    new_id = @effect_var.length < Region_Effects::MAX_EFFECTS ? 
      (@events.keys.max.nil? ? 1 : @events.keys.max + 1) : @effect_var.shift
    @effect_var.push(new_id)
    # Create new Event
    @events[new_id] = Game_Event.new(@map_id, event)
    @events[new_id].moveto(dx, dy)
    SceneManager.scene.spriteset.gre_refresh_event(new_id) # Refresh Event
  end
end