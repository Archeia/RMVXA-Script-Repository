#==============================================================================
# ■ Meow Face Caterpillar
#------------------------------------------------------------------------------
# Change the numbers of visible followers without effecting battlers
#==============================================================================
# How to Use:
# [1] Put this script below Material and above Main
# [2] Change the COUNT numbers to how many members to show
#==============================================================================
module MEOW_FOLLOWERS #Do Not Remove!
#==============================================================================
# SETTINGS AREA
#==============================================================================
  COUNT = 6 # the count of party members in caterpillar (minimum 2)
#==============================================================================
# END OF SETTINGS AREA
# !!EDIT BEYOND THIS LINE AT YOUR OWN RISK!!
#==============================================================================
end
class Game_Follower < Game_Character
  def actor
    $game_party.members[@member_index]
  end
end
class Game_Followers
  def initialize(leader)
    @visible = $data_system.opt_followers
    @gathering = false
    @data = []
    @data.push(Game_Follower.new(1, leader))
    (2...MEOW_FOLLOWERS::COUNT).each do |index|
      @data.push(Game_Follower.new(index, @data[-1]))
    end
  end
end