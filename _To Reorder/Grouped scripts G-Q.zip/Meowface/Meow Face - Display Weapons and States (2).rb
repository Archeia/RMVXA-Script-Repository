#==============================================================================
# ■ Meow Face Weapon & States
#------------------------------------------------------------------------------
# Display Weapon & States
#==============================================================================
# How to Use:
# Plug & Play, Put this script below Material and above Main
#==============================================================================

module Display_Weapon_and_States
#============================Settings==========================================  

#GGZiron's Edit

# Higher Z value, higher chance to be above everything. If you don't want
#to be above certain things, you can reduce it
  Z_VALUE = 50
# That is th opacity of the window only. 255 for fully visible window layout,
# 0 for transparent window.
  OPACITY = 255
 
#If you want to hide this window, set the Switch ID (those from event commands)
#you want to use to hide it. When the switch value is false, the window will be
#hidden. When is true, it will be displayed.
#If you want it always visible, set the switch ID to nil
  SWITCH_ID = nil
#keep true if you want the window size to fit the number of icons.
#Since the code assume all states will fit in single line, the size is
#window width.
  DYNAMIC_WINDOW_SIZE = true
 
#if the above value is set to false, it will take this one for window's width  
  WINDOW_WIDTH_SIZE = 200  

#==========================End of Settings===========================  
end


class Window_StateEquip < Window_Base
 
    def initialize
      @actor = $game_party.leader
      @dynamic_size = Display_Weapon_and_States::DYNAMIC_WINDOW_SIZE
      @fixed_size = Display_Weapon_and_States::WINDOW_WIDTH_SIZE
      super(Graphics.width - window_width, 0, window_width, window_height)
      self.z = Display_Weapon_and_States::Z_VALUE
      self.opacity = Display_Weapon_and_States::OPACITY
      draw_equip_icons
      resize_window
    end

    def window_width
      return 0 if contents_count <= 0 && @dynamic_size
      @dynamic_size ? ((contents_count + 1) * 24 ) : @fixed_size
    end
   
    def resize_window
      self.width = window_width
      self.x = Graphics.width - window_width
    end

    def window_height
      fitting_height(1)
    end

    def draw_equip_icons
      draw_icon(@actor.weapons[0].icon_index, self.width - 48 , 0, true) if @actor.weapons[0]
      draw_actor_states(@actor.weapons[0] ? 1 : 0)
    end

    def draw_actor_states(icon_x)
      icons = (@actor.state_icons + @actor.buff_icons)
      icons.each_with_index {|n, i|
      draw_icon(n, self.width - ((24) * ( i + 2 + icon_x ) ), y)}
    end
     
    def contents_count
      weapon = @actor.weapons[0] ? 1 : 0
      icons = (@actor.state_icons + @actor.buff_icons)
      return weapon + icons.each_with_index.count
    end

    def update
      contents.clear
      resize_window
      create_contents
      draw_equip_icons
    end
     
end

class Scene_Map < Scene_Base
    def create_state_equip
      @stateicon_window = Window_StateEquip.new
    end
     
  alias_method :update_old, :update
   
    def update
      update_old
      switch_id = Display_Weapon_and_States::SWITCH_ID
      @stateicon_window.visible = $game_switches[switch_id] if switch_id
    end
   
    alias meow_windows create_all_windows
   
    def create_all_windows
      meow_windows
      create_state_equip
    end
   
end