#==============================================================================
# ■ Meow Face Chapter Selection
#------------------------------------------------------------------------------
# Select Chapter to Start Game
#==============================================================================
# How to Use:
# [1] Put this script below Material and above Main
# [2] Set up the required data in SETTINGS AREA below
# [3] At the end of each chapter, use this script call to save file
#      chapter_cleared
#==============================================================================
module MF_CHAPTER
#==============================================================================
# SETTINGS AREA
#==============================================================================
#------------------------------------------------------------------------------
# Use Title Screen - true is Select Chapter, false is normal game
#------------------------------------------------------------------------------
  TITLESCREEN = true
#------------------------------------------------------------------------------
# How many chapters are there (1 to 10 MAX)
#------------------------------------------------------------------------------
  MAXCHAPTER = 20
#------------------------------------------------------------------------------
# Background picture (in Graphics\Titles1 folder)
#------------------------------------------------------------------------------
  BACKGROUND = "Fountain"
#------------------------------------------------------------------------------
# Title
#------------------------------------------------------------------------------
  TITLE = "SELECT CHAPTER"
#------------------------------------------------------------------------------
# Chapter's Name
# Starting from top down, Chapter 1, Chapter 2, etc etc
#------------------------------------------------------------------------------
  NAME = [
  "Chapter One",
  "Chapter Two",
  "Chapter Three",
  "Chapter Four",
  "Chapter Five",
  "Chapter Six",
  "Chapter Seven",
  "Chapter Eight",
  "Chapter Nine",
  "Chapter Ten",
  "Chapter Eleven",
  "Chapter Twelve",
  "Chapter Thirteen",
  "Chapter Fourteen",
  "Chapter Fifteen",
  "Chapter Sixteen",
  "Chapter Seventeen",
  "Chapter Eighteen",
  "Chapter Nineteen",
  "Chapter Twenty",
  ] #Do Not Remove
#------------------------------------------------------------------------------
# Chapter's Description
# Starting from top down, Chapter 1, Chapter 2, etc etc
#------------------------------------------------------------------------------
  DESC = [
  "Chapter 1 Descriptions",
  "Chapter 2 Descriptions",
  "Chapter 3 Descriptions",
  "Chapter 4 Descriptions",
  "Chapter 5 Descriptions",
  "Chapter 6 Descriptions",
  "Chapter 7 Descriptions",
  "Chapter 8 Descriptions",
  "Chapter 9 Descriptions",
  "Chapter 10 Descriptions",
  "Chapter 11 Descriptions",
  "Chapter 12 Descriptions",
  "Chapter 13 Descriptions",
  "Chapter 14 Descriptions",
  "Chapter 15 Descriptions",
  "Chapter 16 Descriptions",
  "Chapter 17 Descriptions",
  "Chapter 18 Descriptions",
  "Chapter 19 Descriptions",
  "Chapter 20 Descriptions",
  ] #Do Not Remove
#------------------------------------------------------------------------------
# Starting Map for each Chapter
# [MapID, StartX, StartY]
# Starting top down from Chapter 1 to Chapter 10
#------------------------------------------------------------------------------
  MAP = [
  [1,1,1],
  [2,1,1],
  [3,1,1],
  [4,1,1],
  [5,1,1],
  [6,1,1],
  [7,1,1],
  [8,1,1],
  [9,1,1],
  [10,1,1],
  [11,1,1],
  [12,1,1],
  [13,1,1],
  [14,1,1],
  [15,1,1],
  [16,1,1],
  [17,1,1],
  [18,1,1],
  [19,1,1],
  [20,1,1],
  ] #Do Not Remove
#------------------------------------------------------------------------------
# Starting Actors for each Chapter
# Starting top down from Chapter 1 to Chapter 10
#------------------------------------------------------------------------------
  ACTORS = [
  [1,4,2,5], 	# Chapter 1
  [1,2,3,4],    # Chapter 2
  [1,2,3], 		# Chapter 3
  [2,3,4,5],	# Chapter 4
  [1,2,3,4],	# Chapter 5
  [1,2,3,4],	# Chapter 6
  [1,2,3,4],	# Chapter 7
  [1,2,3,4],	# Chapter 8
  [1,2,3,4],	# Chapter 9
  [1,2,3,4],	# Chapter 10
  [1,4,2,5],	# Chapter 11
  [1,2,3,4],	# Chapter 12
  [1,2,3],		# Chapter 13
  [2,3,4,5],	# Chapter 14
  [1,2,3,4],	# Chapter 15
  [1,2,3,4],	# Chapter 16
  [1,2,3,4],	# Chapter 17
  [1,2,3,4],	# Chapter 18
  [1,2,3,4],	# Chapter 19
  [1,2,3,4],	# Chapter 20
  ] #Do Not Remove
#------------------------------------------------------------------------------
# Reset Actor's Level? true/false
# Automatic set to true if previous chapter load file = nil
#------------------------------------------------------------------------------
  RESET = false
#------------------------------------------------------------------------------
# Data Loading for each Chapter
# This loads the data of the previous chapters during chapter selection
# So set up the file for each chapter accordingly
# Starting top down from Chapter 1 to Chapter 10
# nil = No load file
#------------------------------------------------------------------------------
  LOAD_FILE = [
  nil,
  "Chapter1_Cleared.rvdata2",
  "Chapter2_Cleared.rvdata2",
  "Chapter3_Cleared.rvdata2",
  "Chapter4_Cleared.rvdata2",
  "Chapter5_Cleared.rvdata2",
  "Chapter6_Cleared.rvdata2",
  "Chapter7_Cleared.rvdata2",
  "Chapter8_Cleared.rvdata2",
  "Chapter9_Cleared.rvdata2",
  "Chapter10_Cleared.rvdata2",
  "Chapter11_Cleared.rvdata2",
  "Chapter12_Cleared.rvdata2",
  "Chapter13_Cleared.rvdata2",
  "Chapter14_Cleared.rvdata2",
  "Chapter15_Cleared.rvdata2",
  "Chapter16_Cleared.rvdata2",
  "Chapter17_Cleared.rvdata2",
  "Chapter18_Cleared.rvdata2",
  "Chapter19_Cleared.rvdata2",
  ] #Do Not Remove
#------------------------------------------------------------------------------
# Save Data's Name
#------------------------------------------------------------------------------
  SAVE_FILE = [
  "Chapter1_Cleared.rvdata2",
  "Chapter2_Cleared.rvdata2",
  "Chapter3_Cleared.rvdata2",
  "Chapter4_Cleared.rvdata2",
  "Chapter5_Cleared.rvdata2",
  "Chapter6_Cleared.rvdata2",
  "Chapter7_Cleared.rvdata2",
  "Chapter8_Cleared.rvdata2",
  "Chapter9_Cleared.rvdata2",
  "Chapter10_Cleared.rvdata2",
  "Chapter11_Cleared.rvdata2",
  "Chapter12_Cleared.rvdata2",
  "Chapter13_Cleared.rvdata2",
  "Chapter14_Cleared.rvdata2",
  "Chapter15_Cleared.rvdata2",
  "Chapter16_Cleared.rvdata2",
  "Chapter17_Cleared.rvdata2",
  "Chapter18_Cleared.rvdata2",
  "Chapter19_Cleared.rvdata2",
  "Chapter20_Cleared.rvdata2",
  ] #Do Not Remove
#==============================================================================
# END OF SETTINGS AREA
# !!EDIT BEYOND THIS LINE AT YOUR OWN RISK!!
#==============================================================================
end
module DataManager
  class <<self  
    alias meow_god create_game_objects
    alias meow_load extract_save_contents
    alias meow_save make_save_contents
  end
  def self.make_save_contents
    meowdata = meow_save
    meowdata[:chapter] = $game_chapter
    meowdata
  end
  def self.extract_save_contents(contents)
    meow_load(contents)
    $game_chapter = contents[:chapter]
  end
  def self.make_save_party
    contents = {}
    contents[:actors]        = $game_actors
    contents[:party]         = $game_party
    contents[:player]        = $game_player
    contents
  end
  def self.extract_party(contents)
    $game_actors        = contents[:actors]
    $game_party         = contents[:party]
    $game_player        = contents[:player]
  end
  def self.save_chapter(chapter)
    filename = MF_CHAPTER::SAVE_FILE[chapter]
    File.open(filename, "wb") do |file|
      $game_system.on_before_save
      Marshal.dump(make_save_party, file)
    end
    return true
  end
  def self.load_chapter(chapter)
    filename = MF_CHAPTER::LOAD_FILE[chapter]
    File.open(filename, "rb") do |file|
      extract_party(Marshal.load(file))
    end
    return true
  end
  def self.create_game_objects
    meow_god
    $game_chapter = Game_Chapter.new
  end
  def self.setup_chapter
    chapter = $game_chapter.id
    load_chapter(chapter) if MF_CHAPTER::LOAD_FILE[chapter] != nil
    $game_party.setup_members(chapter)
    $game_map.setup(MF_CHAPTER::MAP[chapter][0])
    $game_player.moveto(MF_CHAPTER::MAP[chapter][1], MF_CHAPTER::MAP[chapter][2])
    $game_player.refresh
    Graphics.frame_count = 0
  end
end
class Game_Party < Game_Unit
  def setup_members(n)
    if MF_CHAPTER::LOAD_FILE[$game_chapter.id] != nil
      @actors.each do |m|
        $game_actors[m].setup(m) if MF_CHAPTER::RESET == true
        $game_actors[m].hp = $game_actors[m].mhp
        $game_actors[m].mp = $game_actors[m].mmp
      end
    end
    @actors = []
    @meowparty = MF_CHAPTER::ACTORS[n]
      @meowparty.each do |meow|
        $game_party.add_actor(meow)
      end
  end
end
class Game_Chapter
  attr_accessor :id
  def initialize
    @id = 0
  end
  def set(n)
    @id = n
  end
end
class Game_Interpreter
  def chapter_cleared
    DataManager.save_chapter($game_chapter.id)
  end
end
class Window_Chapter < Window_Base
  def initialize
    super(0, 0, Graphics.width, Graphics.height)
    self.opacity = 0
    draw_horz_line(Graphics.height - 100)
    draw_horz_line(Graphics.height - 36)
    draw_horz_line(68); draw_horz_line(69)
    draw_horz_line(8); draw_horz_line(7)
    draw_title
  end
  def window_width
    Graphics.width
  end
  def window_height
    Graphics.height
  end
  def draw_horz_line(y)
    line_y = y + line_height / 2 - 1
    contents.fill_rect(0, line_y, contents_width, 2, line_color)
  end
  def line_color
    color = normal_color
    color.alpha = 48
    color
  end
  def draw_title
    contents.font.size = 64
    contents.font.bold = true
    draw_text((Graphics.width/2) - (320/2), 18, 320, 68, MF_CHAPTER::TITLE)
    contents.font.size = Font.default_size
    contents.font.bold = false
  end
end
class Window_ChapterSelect < Window_Command
  def initialize
    super(0,0)
    update_placement
    self.opacity = 0
    create_help_window
  end
  def window_width
    return 220
  end
  def window_height
    fitting_height(9)
  end
  def update_placement
    self.x = (Graphics.width - width) / 2
    self.y = ((Graphics.height - height) / 2) + 5
  end
  def create_help_window
    @help_window = Window_Help.new
    @help_window.y = Graphics.height - @help_window.height + 4
    @help_window.opacity = 0
  end
  def make_command_list
    add_command(MF_CHAPTER::NAME[0], :ch1)
    add_command(MF_CHAPTER::NAME[1], :ch2, File.exist?(MF_CHAPTER::SAVE_FILE[0])) if MF_CHAPTER::MAXCHAPTER >= 2
    add_command(MF_CHAPTER::NAME[2], :ch3, File.exist?(MF_CHAPTER::SAVE_FILE[1])) if MF_CHAPTER::MAXCHAPTER >= 3
    add_command(MF_CHAPTER::NAME[3], :ch4, File.exist?(MF_CHAPTER::SAVE_FILE[2])) if MF_CHAPTER::MAXCHAPTER >= 4
    add_command(MF_CHAPTER::NAME[4], :ch5, File.exist?(MF_CHAPTER::SAVE_FILE[3])) if MF_CHAPTER::MAXCHAPTER >= 5
    add_command(MF_CHAPTER::NAME[5], :ch6, File.exist?(MF_CHAPTER::SAVE_FILE[4])) if MF_CHAPTER::MAXCHAPTER >= 6
    add_command(MF_CHAPTER::NAME[6], :ch7, File.exist?(MF_CHAPTER::SAVE_FILE[5])) if MF_CHAPTER::MAXCHAPTER >= 7
    add_command(MF_CHAPTER::NAME[7], :ch8, File.exist?(MF_CHAPTER::SAVE_FILE[6])) if MF_CHAPTER::MAXCHAPTER >= 8
    add_command(MF_CHAPTER::NAME[8], :ch9, File.exist?(MF_CHAPTER::SAVE_FILE[7])) if MF_CHAPTER::MAXCHAPTER >= 9
    add_command(MF_CHAPTER::NAME[9], :ch10, File.exist?(MF_CHAPTER::SAVE_FILE[8])) if MF_CHAPTER::MAXCHAPTER >= 10
    add_command(MF_CHAPTER::NAME[10], :ch11, File.exist?(MF_CHAPTER::SAVE_FILE[9])) if MF_CHAPTER::MAXCHAPTER >= 11
    add_command(MF_CHAPTER::NAME[11], :ch12, File.exist?(MF_CHAPTER::SAVE_FILE[10]))if MF_CHAPTER::MAXCHAPTER >= 12
    add_command(MF_CHAPTER::NAME[12], :ch13, File.exist?(MF_CHAPTER::SAVE_FILE[11])) if MF_CHAPTER::MAXCHAPTER >= 13
    add_command(MF_CHAPTER::NAME[13], :ch14, File.exist?(MF_CHAPTER::SAVE_FILE[12])) if MF_CHAPTER::MAXCHAPTER >= 14
    add_command(MF_CHAPTER::NAME[14], :ch15, File.exist?(MF_CHAPTER::SAVE_FILE[13])) if MF_CHAPTER::MAXCHAPTER >= 15
    add_command(MF_CHAPTER::NAME[15], :ch16, File.exist?(MF_CHAPTER::SAVE_FILE[14])) if MF_CHAPTER::MAXCHAPTER >= 16
    add_command(MF_CHAPTER::NAME[16], :ch17, File.exist?(MF_CHAPTER::SAVE_FILE[15])) if MF_CHAPTER::MAXCHAPTER >= 17
    add_command(MF_CHAPTER::NAME[17], :ch18, File.exist?(MF_CHAPTER::SAVE_FILE[16])) if MF_CHAPTER::MAXCHAPTER >= 18
    add_command(MF_CHAPTER::NAME[18], :ch19, File.exist?(MF_CHAPTER::SAVE_FILE[17])) if MF_CHAPTER::MAXCHAPTER >= 19
    add_command(MF_CHAPTER::NAME[19], :ch20, File.exist?(MF_CHAPTER::SAVE_FILE[18])) if MF_CHAPTER::MAXCHAPTER >= 20
  end
  def process_cursor_move
    super
    if @index <= 1
      @help_window.set_text(MF_CHAPTER::DESC[@index])
    else
      if File.exist?(MF_CHAPTER::SAVE_FILE[@index-1])
        text = MF_CHAPTER::DESC[@index]
      else
        text = "???"
      end
      @help_window.set_text(text)
    end
  end
end
class Scene_Title < Scene_Base
  def command_new_game
    if MF_CHAPTER::TITLESCREEN
      SceneManager.call(Scene_Chapter)
    else
      DataManager.setup_new_game
      close_command_window
      fadeout_all
      $game_map.autoplay
      SceneManager.goto(Scene_Map)
    end
  end
end
class Scene_Chapter < Scene_Base
  def start
    super
    create_background2
    create_back_window
    create_command_window
  end
  def create_background2
    @spritech = Sprite.new
    @spritech.bitmap = Cache.title1(MF_CHAPTER::BACKGROUND)
    @spritech.tone.set(0, 0, 0, 180)
  end
  def terminate
    super
    @spritech.bitmap.dispose if @spritech
    @spritech.dispose if @spritech
  end
  def create_back_window
    @back_window = Window_Chapter.new
  end
  def create_command_window
    @command_window = Window_ChapterSelect.new
    @command_window.set_handler(:ch1, method(:chapter))
    @command_window.set_handler(:ch2, method(:chapter))
    @command_window.set_handler(:ch3, method(:chapter))
    @command_window.set_handler(:ch4, method(:chapter))
    @command_window.set_handler(:ch5, method(:chapter))
    @command_window.set_handler(:ch6, method(:chapter))
    @command_window.set_handler(:ch7, method(:chapter))
    @command_window.set_handler(:ch8, method(:chapter))
    @command_window.set_handler(:ch9, method(:chapter))
    @command_window.set_handler(:ch10, method(:chapter))
    @command_window.set_handler(:ch11, method(:chapter))
    @command_window.set_handler(:ch12, method(:chapter))
    @command_window.set_handler(:ch13, method(:chapter))
    @command_window.set_handler(:ch14, method(:chapter))
    @command_window.set_handler(:ch15, method(:chapter))
    @command_window.set_handler(:ch16, method(:chapter))
    @command_window.set_handler(:ch17, method(:chapter))
    @command_window.set_handler(:ch18, method(:chapter))
    @command_window.set_handler(:ch19, method(:chapter))
    @command_window.set_handler(:ch20, method(:chapter))
    @command_window.set_handler(:cancel, method(:return_scene))
  end
  def chapter
    DataManager.create_game_objects
    case @command_window.current_symbol
    when :ch1; $game_chapter.set(0)
    when :ch2; $game_chapter.set(1)
    when :ch3; $game_chapter.set(2)
    when :ch4; $game_chapter.set(3)
    when :ch5; $game_chapter.set(4)
    when :ch6; $game_chapter.set(5)
    when :ch7; $game_chapter.set(6)
    when :ch8; $game_chapter.set(7)
    when :ch9; $game_chapter.set(8)
    when :ch10; $game_chapter.set(9)
    when :ch11; $game_chapter.set(10)
    when :ch12; $game_chapter.set(11)
    when :ch13; $game_chapter.set(12)
    when :ch14; $game_chapter.set(13)
    when :ch15; $game_chapter.set(14)
    when :ch16; $game_chapter.set(15)
    when :ch17; $game_chapter.set(16)
    when :ch18; $game_chapter.set(17)
    when :ch19; $game_chapter.set(18)
    when :ch20; $game_chapter.set(19)
    end
    DataManager.setup_chapter
    fadeout_all
    $game_map.autoplay
    SceneManager.goto(Scene_Map)
  end
end