#==============================================================================
# ■ Meow Face Battler Flip Animation
#------------------------------------------------------------------------------
# Animate Battlers with Flip and stop when hit effect is running
#==============================================================================
# How to Use:
# [1] Plug & Play
#==============================================================================
class Sprite_Battler < Sprite_Base  
  
  def initialize(viewport, battler = nil) 
  #Overwrite    
    super(viewport)    
    @battler = battler    
    @battler_visible = false    
    @effect_type = nil    
    @effect_duration = 0    
    @stop_flip = false    
    @flip_counter = rand(30)    
    self.mirror = (rand(2) == 0)  
  end  
  
  def update_effect 
  #Overwrite    
    if @effect_duration > 0      
      @effect_duration -= 1      
      @stop_flip = true      
      case @effect_type      
      when :whiten        
        update_whiten      
      when :blink        
        update_blink      
      when :appear        
        update_appear      
      when :disappear        
        update_disappear      
      when :collapse        
        update_collapse      
      when :boss_collapse        
        update_boss_collapse      
      when :instant_collapse        
        update_instant_collapse      
      end      
      @effect_type = nil if @effect_duration == 0      
      @stop_flip = false if @effect_duration == 0      
      @flip_counter = 30 if @effect_duration == 0    
    end  
  end  
  
  def flip_self 
  #New    
    if self.mirror == true      
      self.mirror = false    
    else      
      self.mirror = true    
    end  
  end  
  
  alias meow_sb_update update  
  def update 
  #Alias    
    if @flip_counter >= 0      
      @flip_counter -=1      
      flip_self if @flip_counter == 0 && !@stop_flip      
      @flip_counter = 15 if @flip_counter <= 0    
    end    
    meow_sb_update  
  end
  
end