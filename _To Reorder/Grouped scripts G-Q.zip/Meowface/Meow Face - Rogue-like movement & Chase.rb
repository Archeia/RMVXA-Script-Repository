#==============================================================================
# ■ Meow Face Rogue-like movement & Chase
#------------------------------------------------------------------------------
# Author: Meow Face
#==============================================================================
=begin

  =========
   Features:
  =========
  [1] Have the event move only when the player is moving
      (Controlled by switch)
  [2] Enemy remain half/fully hidden until the player is in range
      (Surprise attack anyone?)
  [3] Chase Mode, events will start chasing the player in range
      (Or runs away, you can even set your own AI)
  [4] Puts an exclamation mark on the event when chase starts
      (You get to choose the balloon)
  [5] Extra ENFORCED moveroute toward the player during chase
      (Go striaght for player when in chase range, do normal chase when not, do random move 
       when player is 10 mas away)
  [6] Chase Mode works for both rogue move/normal move
      (So you get to choose which one you like most, rogue or normal)
      
  ============
   How To Use:
  ============
  [1] Put this script above Main and below Material
  [2] Put <enemy> tag in the event's name
  [3] Change the event's move type to Move Toward Player
  [4] Turn the Switch on for rogue like move, off for normal move.
  
  = Run Away Enemy =
  ** If you set the move type to "custom" you can setup your own AI
  ** Use "Move away from Player" x 3, "Random move" x 1, "Move one step forward" x 1
  ** Check both repeat and ignore when unable to move tick boxes
  ** You should be able to make an event that runs away from the player this way
  
  ==================
   Name Tag: <enemy>
  ==================
  Put <enemy> as a tag in an event's name to indicate it as an enemy for chase.
  Event with <enemy> tag will be able to do chase with or without the rogue move switch.
  The only difference between rogue/normal is it will not wait for the player 
  to do its move in normal mode and move only when the player is moving in rogue mode.
  
  ===============
   Controll Switch:  (default 1, can be changed)
  ===============
  Turn on the switch anytime anywhere to switch between rogue move and normal move
  Rogue move only works for events with <enemy> name tag.
  
  ================
   Configure Points:
  ================
  You can set which switch number to turn on/off the rogue move
  You can set the distance to trigger off chase mode
  You can set the alpha/opacity of the enemy not in chase
  You can set the speed/frequency of enemy in/not in chase
  
  =============
   Compabilities
  =============
  It's unlikely that this script will conflict with any other script unless they happen to
  be using the same method name i used for new method. Old methods are all aliased.
  
  =============
   Terms of Use
  =============
  Free for use in any free/commercial games.
  
=end
#==============================================================================

module MF_RogueMove

#==============================================================================
# START OF CONFIGURATION
#==============================================================================
  
  SW_ROGUE = 1 #Switch number for turning the rogue move on/off (0 to turn it off)
  
  DISTANCE = 5 #Distance for chase activation (1-10, 10 is about 640x640 pixels in screen size)
  
  HIDE_OPACITY = 128 #Opacity of the enemy when player is not in range (0-255)
  
  BALLOON = 1 # Pop-up Balloon type (1-10, 0 to turn it Off)
  
  CHASE_SPEED = 4 # Enemy Speed when chasing the player (0-6)
  
  CHASE_FREQUENCY = 6 # Enemy Move Frequency when chasing the player (0-6)
  
  DEFAULT_SPEED = 4 # Enemy Move Speed when not chasing the player (0-6)
  
  DEFAULT_FREQUENCY = 3 # Enemy Move Frequency when not chasing the player (0-6)
  
#==============================================================================
# END OF CONFIGURATION
# Edit anything pass this line at your own risk!
#==============================================================================
  
end # DO NOT REMOVE THIS

#==============================================================================

class Game_Event < Game_Character
  #--------------------------------------------------------------------------
  # ◎ Alias Move Type: Move Toward Player
  #--------------------------------------------------------------------------
  alias meowface_mttp move_type_toward_player
  def move_type_toward_player
    if @event.name.include?('<enemy>') && distance_from_player <= MF_RogueMove::DISTANCE
      move_toward_player
      else
      meowface_mttp
    end
  end
  #--------------------------------------------------------------------------
  # ◎ Alias update movement
  #--------------------------------------------------------------------------
  alias meowface_stop update_stop
  def update_stop
    if $game_switches[MF_RogueMove::SW_ROGUE] && @event.name.include?('<enemy>')
      super
      return update_self_movement if $game_player.moving?
    else
      meowface_stop
    end
  end
  #--------------------------------------------------------------------------
  # ○ New method: Get the Distance between Event and Player
  #--------------------------------------------------------------------------
  def distance_from_player
    distance_x_from($game_player.x).abs + distance_y_from($game_player.y).abs
  end  
  #--------------------------------------------------------------------------
  # ○ New method: Start Chasing the Player
  #--------------------------------------------------------------------------
  def chase_player
      if distance_from_player <= MF_RogueMove::DISTANCE
        self.balloon_id = MF_RogueMove::BALLOON
        @opacity = 255 
        @move_speed = MF_RogueMove::CHASE_SPEED
        @move_frequency = MF_RogueMove::CHASE_FREQUENCY
      else
        @opacity = MF_RogueMove::HIDE_OPACITY
        @move_speed = MF_RogueMove::DEFAULT_SPEED
        @move_frequency = MF_RogueMove::DEFAULT_FREQUENCY
      end
  end
  #--------------------------------------------------------------------------
  # ◎ Alias Update Method
  #--------------------------------------------------------------------------
  alias meowface_rg_update update
  def update
    if @event.name.include?('<enemy>') && !$game_map.interpreter.running?
      chase_player
    end
    meowface_rg_update
  end
end
