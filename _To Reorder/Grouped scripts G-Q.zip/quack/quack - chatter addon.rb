class Window_Message < Window_Base
  # overwrite
  def adjust_pop_message(text = " ")
    #return unless SceneManager.scene_is?(Scene_Map) 
    unless @event_pop_id
      if $imported["YEA-MessageSystem"]
        #adjust_message_window_size 
      end
      return
    end
    n_line = cal_number_line(text)
    n_line = YSE::POP_MESSAGE::LIMIT[:limit_line] if YSE::POP_MESSAGE::LIMIT[:limit_line] > 0 && cal_number_line(text) > YSE::POP_MESSAGE::LIMIT[:limit_line]
    @real_lines = n_line
    self.height = fitting_height(n_line)
    self.height += @msg_size_y
    self.width = cal_width_line(text) + 10
    self.width += @msg_size_x
    self.width += new_line_x
    if self.width > YSE::POP_MESSAGE::LIMIT[:limit_width] && YSE::POP_MESSAGE::LIMIT[:limit_width] > 0
      self.width = YSE::POP_MESSAGE::LIMIT[:limit_width]
    end
    # If a chatter message with face graphic, force height to be at least big enough to show the face.
    if chatter? && !source.face_name.empty?
      self.height = [self.height, 86].max
    end
    
    create_contents
    update_placement
  end
  # overwrite
  def input_choice
    chatter_msg_input_choice
  end
end

class Window_ChoiceList < Window_Command
  # overwrite
  def update_placement
    chatter_msg_update_placement
    if @message_window.pop_message?
      self.opacity = 255
      self.x = Graphics.width / 2 - self.width / 2
      self.y = Graphics.height - [200, self.height].max
    end
  end
end