=begin
#==============================================================================
 * Chatter Messages (Yami's Pop Messages Addon) - v1.3
  Author: Quack
#==============================================================================
What it does:
1-Allows you to use 'chatter' messageboxes. The difference from normal messages
  is that they don't pause the game and don't close by pressing the action key.
  Instead you provide the message with a timer and it will close automically
  when the time is up. Another difference is that several chatter messages can
  be active at once (though there is a limit (7 by default) which you can adjust 
  by chaning MAX_MSGS a bit lower down).
  To make a message into 'chatter' use the '<cm:X>' tag in your message, where X
  is the duration in seconds (IMPORTANT: THIS TAG HAS TO BE ON THE FIRST LINE
  OF THE MESSAGE TO WORK).
  Set X to a negative number and the message will last forever.
  You can use this method in a script call to close all chatter messages:
  clear_chatter
  
2-By default Pop messages show a speech bubble tag of sorts so it's easier to
  see which character the message belongs to. 
  I changed that code a bit and added option of showing a speech bubble tag or
  thought bubble tag for the chose character.
  Speech bubble tag is the same message tag as previous: \bm[x]
  While thought bubble tag is: \bmt[x]
  
3-By defauult Pop messages don't work during combat. Now they do.
  It works mostly like normal. Use \bm[x] or \bmt[x] to show a pop message.
  The difference is that to apply the pop message to an enemy, make x a positive
  number. So enemy 1 \bm[1] and enemy 4 would be \bm[4]
  Meanwhile actors use negative numbers. Like so: actor 1= \bm[-1]
  HOWEVER, for pop messages to work for actors they needed to have a visual
  battler. And I can't guarantee it will work with all actor battler scripts.
  The only one I can guarantee works is Jet's sideview battlers since it's what
  I use. 
  One problem with Pop messages in battler is that if a battle has a different
  size than a normal character sprite the message box will get a bit missplaced.
  To fix that I added to other messagebox tags to use to change the position.
  \ox[X] - Offsets the messagebox position horizontally by X pixels.
  \oy[X] - Offsets the messagebox position vertically by X pixels.

Please note if you are using Yanfly's core script & Yanfly's Ace Message script
  together. You need to set FONT_NAME in the core script to have the same value
  as MESSAGE_WINDOW_FONT_NAME in the ace message script. Otherwise when these
  two are combined it will sometimes cause the width of text to be 
  miss-measured. This wouldn't cause much of a problem normally, but when using
  pop messages which measure the width of the text to set the width of the
  message box it can cause big problems. (the other font settings on the two
  scripts (that is bold, italic, shadow and outline) should preferably also be
  the same on both)
  
VERSION 1.1 ADDITIONS:

1-Added text sound. You can add different text sounds in the TEXT_SOUNDS hash
  in the config area (further instructions on adding sounds there). By default
  messages won't have sound. To add it use this tag: <ts:x>   where x is a key
  that exists in the TEXT_SOUNDS hash. 
  
2-Added Message box background tones. This allows you to specify different
  background colors for your message boxes. You can add different tones in the
  WINDOW_TONES has in the config area (further instructions on adding tones 
  there). By default it will use the normal window tone. To use one of the tones
  in the WINDOW_TONES has use this tag: <bc:x>  where x is a key that exists in
  the WINDOW_TONES hash.
 
3-Sometimes you might want to change font size in your message, multiple times,
  or do other things that might affect the size required by your message and
  therefore cause the size of the message window too be to big or too small. So
  I added a tag to use to adjust the message window size: <pms:x,y> . It changes
  Pop Message Size, adjusting the width by x and height by y. So if you put
  <pms:20,-10> in your message it will increase the width of the window by 20
  and decrease the height by 10.
  
4-If you're like me you think it's annoying to have to remember which event has
  what id when writing messages and it's further annoying to have to write so
  many tags for each message. That is why I made it so now in my game using this
  script I can position my pop message on the event I want and make it use the
  background color and text sound that I want just by entering this tag:
  <bt:x> (for speech bubble)  OR <btt:x> (for thought bubble)
  How does that work you might ask?
  Well lets say I have an event which is supposed to be one of my actors. Let's
  call the actor Emil. In the name box of the event I put the tag: <emil>.
  Now when I use the tags: <bt:emil> or <btt:emil>  the pop message will get
  placed on that event. And if WINDOW_TONES has a value with the key 'emil', 
  that window tone will be used too. Same for TEXT_SOUNDS except if you are 
  using btt because thoughts shouldn't make sound now should they?
  Doesn't that sound so much easier?
  It will also make it easier to tell which event is saying a text when looking
  at the event command in the editor since you know who 'emil' is but might not
  be able to as easily tell which event '72' is.
  
  You can also specify the player with these tags by using 'pl', like so:
  <bt:pl>
  The reason I added this was to allow setting window tone and text sound for
  player as well. This probably won't be all to useful in most cases since
  the showing actor for the party might vary but I figured I should still add
  the functionality.
  
  If you are wondering why all my new tags use different structure than the 
  previously existing ones then well.... because! Consistence is overrated 
  anyway, who needs it?
  
  Using these these two tags (<bt:x> & <btt:x>) does however require the 
  functionality of one of my other scripts, called Qonvenience (guess you could
  kind of call it my 'core' script like how other scripters have (Yanfly, 
  Victor, Yami, etc). 
  You can find a link to it under the 'Requirements' section.
  
VERSION 1.2 ADDITIONS:

-When showing choices it will appear differently depending on if the open
  game_message is a pop message or not. If it is not it will display like normal.
  But if it is a pop message the message window will be made bigger and the
  choices will be displayed inside the message window.
  
VERSION 1.3:

-Fixed some problems with faces graphics and nameboxes. It's still not perfect
  but I wrote this script for a project of mine where I don't use nameboxes
  or face graphics so I don't really want to put too much effort into features
  I'm not personally interested in.
  
-Like with window tones and text sounds, you can now associate namebox names to
  a tag.
  
==============================================================================
Instructions/Install notes:
Requires Yami's Pop messages to work.
Paste it below Yami's Pop messages script.

==============================================================================
Requirements:
Requires Yami's Pop messages to work. You can find it here:
​https://github.com/suppayami/rmvxa-collection/blob/master/yami-script-ace/10%20-%20Pop%20Message.txt
Also requires my script Qonvenience if you plan on using the message tags
<bt:x> and <btt:x>
Find it here:
http://pastebin.com/J6haUy5T

==============================================================================
Credits:
Yami for making Pop messages.

==============================================================================
Terms of Use:
Use it however you wish (yes, that does include commercial projects), as long
as you do not claim it as your own code. I would also prefer you mention me in
your credits if you do decide to use it.
However do remember that this script relies on Yami's pop messages script which
has it has it's own separate terms of use.

==============================================================================
Bugs:
dunno

==============================================================================
History:
11/10/2016 - Fixed some problems added some minor feature.
19/01/2016 - Fixed some bugs, changes to choices when a pop message is used.
14/01/2016 - Chatter messages now last forever if you set the duration to a
             negative number. Also added method for clearing all chatter
             to use in script calls. Also squashed some bugs.
13/01/2016 - Pretty big update. Added more functionality.
10/01/2016 - Proper release since Absurdiness found the original script so I
             could separate the addon from the original. 
08/01/2016 - Initial release

=end

$imported = {} if $imported.nil?
$imported["Chatter_Messages"] = true

#==============================================================================
# * CONFIG
#==============================================================================

module YSE
  module POP_MESSAGE
    #=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
    # - Visual Settings -
    #=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
    
    EFFECT2 = { # Start.
      :bubble_tag_name => "BubbleTag_Speech",
      :thought_bubble_tag_name => "BubbleTag_Thought",
    } # End.
  end
end

module QUACK
  module MSG
    
    # Max amount of chatter messages that can be exist at the same time.
    # Too few might be limiting your options and too many will clutter up
    # the screen and decrease performance.
    MAX_MSGS = 6
    
    # Used for setting the background color of messages.
    # To add a tone the syntax is:
    # Key => Tone.new(Red,Green,Blue,Grey)
    # Where key is a string, Red,Green and Blue are numerical value from -255 to
    # 255. And Grey is a value from 0 to 255. The Grey value is optional so you
    # don't have to add it.
    # If you are unsure how to do it just copy one of the lines, paste it below
    # and edit the values.
    WINDOW_TONES = {
      # Add tones below this line
      'reddish1' => Tone.new(85,44,51),
      'bluehair' => Tone.new(-34,85,102),
      'geezer' => Tone.new(68,68,68,10),
      'pl' => Tone.new(102,34,-34),
      'alf' => Tone.new(102,34,51),
      # And above this line
    }
    
    # The name is kind of self explanatory
    # If you want to add a sound the syntax is this:
    #Key => [Sound, Volume, Pitch minimum, Pitch Maximum],
    # where Key is a string. Sound is the name of your sound,
    # Volume, Pitch minimum and Pitch Maximum are values from 0-100.
    # Just a copy a line, paste it and edit it.
    TEXT_SOUNDS = {
      # Add sounds below this line
      '0' => nil, # DEFAULT VALUE USED FOR NO SOUND!
      '1' => ["Cursor1", 80, 70, 100],
      '2' => ["Cursor1", 80, 90, 120],
      '3' => ["Knock", 80, 50, 75],
      'bluehair' => ["Cursor1", 80, 90, 120],
      'geezer' => ["Cursor1", 80, 45, 70],
      'pl' => ["Cursor1", 80, 70, 100],
      'alf' => ["Cursor1", 70, 110, 140],
      # And above this line
    }
    
    NAMES = {
      # Add names below this line
      'bluehair' => "Riverhead"
    }
    
    # Play sound per X characters displayed.
    SOUND_PLAY_FREQUENCY = 3
    
    # Whether the pop message should grow to make place for choices as the text
    # finishes or just have the final size immediately.
    POP_CHOICE_GROW = true
    
  end
end

#==============================================================================
# * SCRIPT START
#==============================================================================

#==============================================================================
# ?! DataManager
#==============================================================================
module DataManager
  class << self
    alias quack_msg_create_game_objects create_game_objects
    def create_game_objects
      quack_msg_create_game_objects
      if !$imported["YSE-PopMessage"]
        msgbox(sprintf("This script(Chatter Messages) requires Yami's Pop Messages to function", "ChatterMessages", 1))
        exit
      end
      $game_message.quack_msg_make
    end
  end
end

#==============================================================================
# ?! Game_Message
#==============================================================================
class Game_Message
  attr_accessor :quack_msgs
  
  # new
  def quack_msg_make
    @quack_msgs = []
    QUACK::MSG::MAX_MSGS.times {@quack_msgs.push(Game_Message.new)}
    @quack_msg_ttl = 0
    @c_msg = 0
  end
  # new
  def set_ttl(ttl)
    @quack_msg_ttl = ttl
  end
  # new
  def ttl_sub
    @quack_msg_ttl -= 1 if @quack_msg_ttl > 0
  end
  # new
  def expire?
    return false if @quack_msg_ttl < 0
    @quack_msg_ttl == 0
  end
  # new
  def prepare_msg(duration)
    @quack_msg_ttl = (duration * 60).to_i
  end
  # new
  def fin_msg
    @quack_msg_ttl = 0
    @c_msg = (@c_msg + 1) % QUACK::MSG::MAX_MSGS
  end
  # new
  def add_chatter(text)
    m = @quack_msgs[@c_msg]
    m.add(text)
    m.face_name = face_name
    m.face_index = face_index
    m.set_ttl(@quack_msg_ttl)
  end
  # new
  def clear_chatter
    @quack_msgs.each {|m| m.set_ttl(0) }
  end
end

#==============================================================================
# ?! Window_Message
#==============================================================================

class Window_Message < Window_Base
  
  # new
  def chatter?
    false
  end
  # overwrite
  def standard_padding
    return 8
  end
  # alias
  alias quack_chatter_init initialize
  def initialize
    @msg_tone = $game_system.window_tone
    @snd_f = 0
    quack_chatter_init
  end
  # new
  def speech_bubble_tag=(sprite)
    @speech_bubble_tag = sprite
  end
  # new
  def thought_bubble_tag=(sprite)
    @thought_bubble_tag = sprite
  end
  # new
  def set_offset_x(x)
    @ox = x
    return ""
  end
  # new
  def set_offset_y(y)
    @oy = y
    return ""
  end
  # overwrite
  def cal_width_line(text)
    result = 0
    text.each_line { |line|
      result = text_size(line).width if result < text_size(line).width
    }
    return result
  end
  # alias
  alias quack_chatter_process_character process_character
  def process_character(c, text, pos)
    if @snd_f == 0 && !@show_fast && !@text_sound.nil?
      Audio.se_play("Audio/SE/"+@text_sound[0],@text_sound[1],@text_sound[2]+rand(@text_sound[3]-@text_sound[2]))
    end
    @snd_f += 1
    @snd_f = 0 if @snd_f == QUACK::MSG::SOUND_PLAY_FREQUENCY
    quack_chatter_process_character(c,text,pos)
  end
  #overwrite
  def update_tone
    self.tone.set(@msg_tone)
  end
  # overwrite
  def message_escape_characters_pop_message(result)
    @msg_tone = $game_system.window_tone
    @event_pop_id = nil
    set_offset_x(0)
    set_offset_y(0)
    @text_sound = QUACK::MSG::TEXT_SOUNDS['0']
    @msg_size_x = 0
    @msg_size_y = 0
    reset_font_settings
    
    result.gsub!(/<BT:([^<>]*)>/i) { event_pop_message_setup2($1, false) }
    result.gsub!(/<BTT:([^<>]*)>/i) { event_pop_message_setup2($1, true) }
    result.gsub!(/\eOX\[([-+]?\d+)\]/i) { set_offset_x($1.to_i) }
    result.gsub!(/\eOY\[([-+]?\d+)\]/i) { set_offset_y($1.to_i) }
    result.gsub!(/\eBM\[([-+]?\d+)\]/i) { event_pop_message_setup($1.to_i, false) }
    result.gsub!(/\eBMT\[([-+]?\d+)\]/i) { event_pop_message_setup($1.to_i, true) }
    result.gsub!(/\eBMF\[(\d+)\]/i) { event_pop_message_setup($1.to_i, false, true) }
    result.gsub!(/\eCBM/i) { event_pop_message_setup(nil, false) }
    result.gsub!(/<BC:([^<>]*)>/i) { @msg_tone = QUACK::MSG::WINDOW_TONES[$1] ;""}
    result.gsub!(/<TS:([^<>]*)>/i) { @text_sound = QUACK::MSG::TEXT_SOUNDS[$1]; ""}
    result.gsub!(/<PMS:([-+]?\d+),([-+]?\d+)>/i) { @msg_size_x = $1.to_i ;@msg_size_y = $2.to_i; ""}
    result
  end
  # new
  def event_pop_message_setup2(tag, thought = false)
    if SceneManager.scene_is?(Scene_Battle)
      if tag.include?('act')
        ev_id = tag[3].to_i
        ev_id = (1+$game_party.members.index($game_actors[ev_id])) * -1
        @msg_tone = QUACK::MSG::WINDOW_TONES[tag] if QUACK::MSG::WINDOW_TONES.has_key?(tag)
        @text_sound = QUACK::MSG::TEXT_SOUNDS[tag] if !thought && QUACK::MSG::TEXT_SOUNDS.has_key?(tag)
      else
        msgbox(sprintf("No event with tag: '" + tag + "'.","Chatter Messages",1))
      end
      return event_pop_message_setup(ev_id, thought)
    end
    msgbox(sprintf("Using this tag requires that you have Qonvenience installed.","Chatter Messages",1)) if !$imported["Qonvenience"]
    if tag == 'pl'
      ev_id = 0
    else
      ev_id = $game_map.first_event_tag(tag).id
      msgbox(sprintf("No event with tag: '" + tag + "'.","Chatter Messages",1)) if ev_id.nil?
    end
    @msg_tone = QUACK::MSG::WINDOW_TONES[tag] if QUACK::MSG::WINDOW_TONES.has_key?(tag)
    @text_sound = QUACK::MSG::TEXT_SOUNDS[tag] if !thought && QUACK::MSG::TEXT_SOUNDS.has_key?(tag)
    namewindow(QUACK::MSG::NAMES[tag], 1) if $imported["YEA-MessageSystem"] && QUACK::MSG::NAMES.has_key?(tag) && @name_text == ""
    return event_pop_message_setup(ev_id, thought)
  end
  # overwrite
  def event_pop_message_setup(event_id, thought = false, follower = false)
    start_name_window if $imported["YEA-MessageSystem"]
    if follower && $game_player.followers[event_id].nil?
      @event_pop_id = nil
      @event_pop_follower = false
      return ""
    end
    if thought # THOUGHT
      @speech_bubble_tag.visible = false
      @bubble_tag = @thought_bubble_tag
    else # SPEECH
      @thought_bubble_tag.visible = false
      @bubble_tag = @speech_bubble_tag
    end
    @event_pop_follower = follower
    @event_pop_id = event_id
    return ""
  end
  # overwrite
  def set_face_position
    #return unless SceneManager.scene_is?(Scene_Map)
    return unless @event_pop_id
    return unless @face_window
    contents.clear
    @face_window.set_face
    return unless $imported["YEA-MessageSystem"]
    return if @face_window.close?
    #@name_window.x = self.x + YSE::POP_MESSAGE::POSITION[:face_x_buffer] + YSE::POP_MESSAGE::POSITION[:name_x_buffer] if (@name_position == 1 || @name_position == 2)
  end
  # overwrite
  def close
    pop_message_close
    #return unless SceneManager.scene_is?(Scene_Map) 
    return unless @event_pop_id
    @event_pop_follower = false
    @face_window.hide_face
    return unless YSE::POP_MESSAGE::EFFECT[:use_bubble_tag]
    @speech_bubble_tag.visible = false if @speech_bubble_tag
    @thought_bubble_tag.visible = false if @thought_bubble_tag
  end
  # overwrite
  def process_all_text
    @event_pop_id = nil
    txt = convert_escape_characters($game_message.all_text)
    update_placement
    adjust_pop_message(txt)#$game_message.all_text)
    pop_message_process_all_text
  end
  # overwrite
  def update_placement
    if SceneManager.scene_is?(Scene_Map) 
      if @event_pop_id.nil?
        fix_default_message
        event_pop_message_update_placement
      elsif @event_pop_id == 0
        character = $game_player
        self.y = character.screen_y + @oy - self.height + YSE::POP_MESSAGE::POSITION[:y_buffer]
        self.x = character.screen_x + @ox - self.width / 2 + YSE::POP_MESSAGE::POSITION[:x_buffer]
        fix_position_bubble(character)
        set_bubble_tag(character)
        @name_window.update_pos if @name_window.open? && $imported["YEA-MessageSystem"]
        @face_window.set_position if !chatter? && @face_window.open?
      elsif @event_pop_id > 0
        hash = @event_pop_follower ? $game_player.followers : $game_map.events
        character = hash[@event_pop_id]
        self.y = character.screen_y + @oy - self.height + YSE::POP_MESSAGE::POSITION[:y_buffer]
        self.x = character.screen_x + @ox - self.width / 2 + YSE::POP_MESSAGE::POSITION[:x_buffer]
        fix_position_bubble(character)
        set_bubble_tag(character)
        @name_window.update_pos if @name_window.open? && $imported["YEA-MessageSystem"]
        @face_window.set_position if !chatter? && @face_window.open?
      end
    else
      # IF IN BATTLE
      #event_pop_message_update_placement
      if @event_pop_id.nil?
        fix_default_message
        event_pop_message_update_placement
      elsif @event_pop_id < 0
        battler = $game_party.members[(@event_pop_id * -1)-1]
        self.y = battler.screen_y + @oy - self.height + YSE::POP_MESSAGE::POSITION[:y_buffer]
        self.x = battler.screen_x + @ox - self.width / 2 + YSE::POP_MESSAGE::POSITION[:x_buffer]
        fix_position_bubble(battler)
        set_bubble_tag(battler)
        @name_window.update_pos if @name_window.open? && $imported["YEA-MessageSystem"]
        @face_window.set_position if !chatter? && @face_window.open?
      elsif @event_pop_id > 0
        battler = $game_troop.members[@event_pop_id-1]
        self.y = battler.screen_y + @oy - self.height + YSE::POP_MESSAGE::POSITION[:y_buffer]
        self.x = battler.screen_x + @ox - self.width / 2 + YSE::POP_MESSAGE::POSITION[:x_buffer]
        fix_position_bubble(battler)
        set_bubble_tag(battler)
        @name_window.update_pos if @name_window.open? && $imported["YEA-MessageSystem"]
        @face_window.set_position if !chatter? && @face_window.open?
      end
    end
  end
  # overwrite
  def fix_default_message
    self.width = window_width
    self.height = window_height
    self.x = 0
    @face_window.hide_face if @face_window
    create_contents
    return unless YSE::POP_MESSAGE::EFFECT[:use_bubble_tag]
    @speech_bubble_tag.visible = false if @speech_bubble_tag
    @thought_bubble_tag.visible = false if @thought_bubble_tag
  end
  # overwrite
  def fix_position_bubble(character)
    end_x = self.x + self.width
    end_y = self.y + self.height
    self.x = 0 if self.x < 0
    self.y = character.screen_y + @oy if self.y < 0
    self.y = -99 if self.y < 0
    self.x = Graphics.width - self.width if end_x > Graphics.width
    self.y = Graphics.height - self.height if end_y > Graphics.height
  end
  # overwrite
  def set_bubble_tag(character)
    return unless YSE::POP_MESSAGE::EFFECT[:use_bubble_tag]
    return unless @bubble_tag
    up = self.y == character.screen_y + @oy
    if self.y == -99
      self.y = 0
      up = true
    end
    self.y += up ? @bubble_tag.height / 2 : -@bubble_tag.height / 2
    @bubble_tag.x = character.screen_x + @ox - @bubble_tag.width / 2
    if up
      @bubble_tag.src_rect.set(0, @bubble_tag.height, @bubble_tag.width, @bubble_tag.height)
      @bubble_tag.y = self.y - @bubble_tag.height - YSE::POP_MESSAGE::POSITION[:tag_y_buffer]
    else
      @bubble_tag.src_rect.set(0, 0, @bubble_tag.width, @bubble_tag.height)
      @bubble_tag.y = self.y + self.height + YSE::POP_MESSAGE::POSITION[:tag_y_buffer]
    end
    @bubble_tag.z = self.z + 1
  end
  # overwrite
  def adjust_pop_message(text = " ")
    #return unless SceneManager.scene_is?(Scene_Map) 
    unless @event_pop_id
      if $imported["YEA-MessageSystem"]
        #adjust_message_window_size 
      end
      return
    end
    n_line = cal_number_line(text)
    n_line = YSE::POP_MESSAGE::LIMIT[:limit_line] if YSE::POP_MESSAGE::LIMIT[:limit_line] > 0 && cal_number_line(text) > YSE::POP_MESSAGE::LIMIT[:limit_line]
    @real_lines = n_line
    self.height = fitting_height(n_line)
    self.height += @msg_size_y
    self.width = cal_width_line(text) + 10
    self.width += @msg_size_x
    self.width += new_line_x
    if self.width > YSE::POP_MESSAGE::LIMIT[:limit_width] && YSE::POP_MESSAGE::LIMIT[:limit_width] > 0
      self.width = YSE::POP_MESSAGE::LIMIT[:limit_width]
    end
    if $game_message.choice? && !QUACK::MSG::POP_CHOICE_GROW
      dy = fitting_height($game_message.choices.size) - 16
      self.y -= dy - 16
      self.height += dy - 16
      @face_window.y -= dy - 16
      @name_window.y -= dy - 16 if $imported["YEA-MessageSystem"]
    end
    # If a chatter message with face graphic, force height to be at least big enough to show the face.
    if chatter? && !source.face_name.empty?
      self.height = [self.height, 86].max
    end
    
    create_contents
    update_placement
  end
  # alias
  alias yse_pop_dispose dispose
  def dispose
    @speech_bubble_tag.visible = false if @speech_bubble_tag
    @thought_bubble_tag.visible = false if @thought_bubble_tag
    yse_pop_dispose
  end
  # alias
  alias chatter_msg_input_choice input_choice
  def input_choice
    if !close? && pop_message? && QUACK::MSG::POP_CHOICE_GROW
      f = Fiber.new { add_room_for_choices }
      @choice_window.visible = false
      @choice_window.set_fiber(f)
      f.resume
    end
    chatter_msg_input_choice
  end
  # new
  def add_room_for_choices
    q = fitting_height($game_message.choices.size) - 16
    i = 0
    while true
      i += 4
      self.y -= 4
      self.height += 4
      @face_window.y -= 4
      @name_window.y -= 4 if $imported["YEA-MessageSystem"]
      break if i >= q
      Fiber.yield
    end
    @choice_window.visible = true
    @choice_window.set_fiber(nil)
  end
  # new
  def pop_message?
    @event_pop_id
  end
end

#==============================================================================
# ?! Window_ChoiceList
#==============================================================================
class Window_ChoiceList < Window_Command
  # alias
  alias chatter_msg_init initialize
  def initialize(message_window)
    chatter_msg_init(message_window)
    self.opacity = 0
    self.z = 207
  end
  # new
  def set_fiber(fiber)
    @fiber = fiber
  end
  # alias
  alias chatter_msg_update update
  def update
    chatter_msg_update
    @fiber.resume if @fiber
  end
  # alias
  alias chatter_msg_update_placement update_placement
  def update_placement
    if @message_window.pop_message?
      self.opacity = 0
      self.width = @message_window.width-26 + padding * 2
      self.width = [width, Graphics.width].min
      self.height = fitting_height($game_message.choices.size)
      self.x = @message_window.x
      self.y = @message_window.y+@message_window.height-self.height+6
    else
      self.opacity = 255
      chatter_msg_update_placement
    end
  end
end

#==============================================================================
# ■ Window_NameMessage
#==============================================================================
class Window_NameMessage < Window_Base
  # alias
  alias quack_msg_name_init initialize
  def initialize(message_window)
    quack_msg_name_init(message_window)
    self.z += 2
  end
  # new
  def update_pos
    set_x_position(1)
    #set_y_position
    self.y = @message_window.y - self.height / 1.25
    self.y = 0 if self.y < 0
  end
  # overwrite
      #  self.y = @message_window.height
      #  self.y -= YEA::MESSAGE::NAME_WINDOW_Y_BUFFER
      #else
      #  self.y = @message_window.y - self.height / 1.25
      #  self.y += YEA::MESSAGE::NAME_WINDOW_Y_BUFFER
      #end
end
  
#==============================================================================
# ¡ Window_Message_Face
#==============================================================================

class Window_Message_Face < Window_Base
  alias quack_msg_face_pos set_position
  def set_position
    quack_msg_face_pos
    self.y -= 4
  end
end

#==============================================================================
# ?! Window_Quack_Message
#==============================================================================
class Window_Quack_Message < Window_Message
  attr_accessor :active
  
  def initialize(msg_source, zz)
    super()
    self.z = zz
    @quack_msg_source = msg_source
    @active = false
    @background = 0
    self.opacity = 255
    self.visible = false
    clear_name_window if $imported["YEA-MessageSystem"]
  end
  
  def chatter?
    true
  end
  
  def source
    @quack_msg_source
  end

  def update
    if @quack_msg_source.busy?
      if @quack_msg_source.expire?
        close
      else
        self.visible = true if !self.visible
        @quack_msg_source.ttl_sub
      end
    end
    self.visible = false if self.visible && close?
    super
  end
  
  def update_placement
    return if @closing
    super
  end
  
  def update_show_fast
    return false
  end
  
  def process_all_text
    @event_pop_id = nil
    text = convert_escape_characters(@quack_msg_source.all_text)
    update_placement
    adjust_pop_message(text)
    open_and_wait
    #text = convert_escape_characters(@quack_msg_source.all_text)
    pos = {}
    new_page(text, pos)
    process_character(text.slice!(0, 1), text, pos) until text.empty? || close?
  end
  
  def close
    pop_message_close #super
    return unless @event_pop_id
    return unless YSE::POP_MESSAGE::EFFECT[:use_bubble_tag]
    @speech_bubble_tag.visible = false if @speech_bubble_tag
    @thought_bubble_tag.visible = false if @thought_bubble_tag
  end
  
  def input_pause
    self.pause = true
    wait(10)
    Fiber.yield until close?
    self.pause = false
  end
  
  def update_fiber
    if @fiber
      @fiber.resume
    elsif @quack_msg_source.busy?
      @fiber = Fiber.new { fiber_main }
      @fiber.resume
    else
      @quack_msg_source.visible = false
    end
  end
  def fiber_main
    @quack_msg_source.visible = true
    #update_background
    update_placement
    loop do
      process_all_text if @quack_msg_source.has_text?
      process_input
      @quack_msg_source.clear
      @name_window.start_close if $imported["YEA-MessageSystem"]
      Fiber.yield
      break unless text_continue?
    end
    close_and_wait
    @quack_msg_source.visible = false
    @fiber = nil
  end
  #def update_background
  #  @background = @quack_msg_source.background
  #  self.opacity = @background == 0 ? 255 : 0
  #end
  def process_input
    input_pause unless @pause_skip
  end
  def text_continue?
    @quack_msg_source.has_text?# && !settings_changed?
  end
  def settings_changed?
    #@background != $game_message.background ||
    #@position != @quack_msg_source.position
    false
  end
  def new_page(text, pos)
    contents.clear
    draw_face(@quack_msg_source.face_name, @quack_msg_source.face_index, 0, 0)
    reset_font_settings
    pos[:x] = new_line_x
    pos[:y] = 0
    pos[:new_x] = new_line_x
    pos[:height] = calc_line_height(text)
    clear_flags
  end
  def new_line_x
    @quack_msg_source.face_name.empty? ? 0 : 112
  end
  # overwrite
  def input_pause
    #self.pause = true
    wait(10)
    Fiber.yield until @quack_msg_source.expire? #Input.trigger?(:B) || Input.trigger?(:C)
    #Input.update
    #self.pause = false
  end
  
  # overwrite
  def create_all_windows
    @name_window = Window_NameMessage.new(self) if $imported["YEA-MessageSystem"]
  end
  # overwrite
  def dispose_all_windows
    @name_window.dispose if $imported["YEA-MessageSystem"]
  end
  # overwrite
  def update_all_windows
    if $imported["YEA-MessageSystem"]
      @name_window.update
      @name_window.back_opacity = self.back_opacity
      @name_window.opacity = self.opacity
    end
  end
  # overwrite
  def event_pop_message_update_placement
  end
  # overwrite
  def all_close?
    close? && (!$imported["YEA-MessageSystem"] || @name_window.close?)
  end
  
  if $imported["YEA-MessageSystem"]
    def close_and_wait
      @name_window.force_close
      window_message_close_and_wait_ams
    end
  end
end

#==============================================================================
# ?! Scene_Map
#==============================================================================

class Scene_Map < Scene_Base
  # alias
  alias quack_msg_update update
  def update
    @quack_msgs.each {|m| 
      m.update
      if m.open?
        m.update_placement
      end
    }
    @message_window.update_placement if @message_window.open?
    quack_msg_update
  end
  # overwrite
  def create_message_window
    yse_pm_create_message_window
    @face_window = Window_Message_Face.new
    @face_window.message_window = @message_window
    if @bubble_tag_sprite || @thought_bubble_tag_sprite
    @bubble_tag_sprite.dispose
    @thought_bubble_tag_sprite.dispose
    end
    if YSE::POP_MESSAGE::EFFECT[:use_bubble_tag]
      @bubble_tag_sprite = Sprite.new
      @bubble_tag_sprite.visible = false
      @bubble_tag_sprite.bitmap = Cache.system(YSE::POP_MESSAGE::EFFECT2[:bubble_tag_name])
      @bubble_tag_sprite.src_rect.set(0, 0, @bubble_tag_sprite.width, @bubble_tag_sprite.height / 2)
      @message_window.speech_bubble_tag = @bubble_tag_sprite
      
      @thought_bubble_tag_sprite = Sprite.new
      @thought_bubble_tag_sprite.visible = false
      @thought_bubble_tag_sprite.bitmap = Cache.system(YSE::POP_MESSAGE::EFFECT2[:thought_bubble_tag_name])
      @thought_bubble_tag_sprite.src_rect.set(0, 0, @thought_bubble_tag_sprite.width, @thought_bubble_tag_sprite.height / 2)
      @message_window.thought_bubble_tag = @thought_bubble_tag_sprite
    end
    @message_window.face_window = @face_window
    
    quack_msg_create_msg
  end
  # new
  def quack_msg_create_msg
    unless @quack_msgs.nil?
      @quack_msgs.each {|m| m.dispose}
      @quack_msg_speech_bubble_sprites.each {|s| s.dispose}
      @quack_msg_thought_bubble_sprites.each {|s| s.dispose}
    end
    @quack_msgs = []
    @quack_faces = []
    @quack_msg_speech_bubble_sprites = []
    @quack_msg_thought_bubble_sprites = []
    QUACK::MSG::MAX_MSGS.times do |i|
      qm = Window_Quack_Message.new($game_message.quack_msgs[i], 200-QUACK::MSG::MAX_MSGS+i)
      @quack_msgs.push(qm)
      ss = Sprite.new
      ss.visible = false
      ss.bitmap = Cache.system(YSE::POP_MESSAGE::EFFECT2[:bubble_tag_name])
      ss.src_rect.set(0, 0, ss.width, ss.height / 2)
      qm.speech_bubble_tag = ss
      ts = Sprite.new
      ts.visible = false
      ts.bitmap = Cache.system(YSE::POP_MESSAGE::EFFECT2[:thought_bubble_tag_name])
      ts.src_rect.set(0, 0, ts.width, ts.height / 2)
      qm.thought_bubble_tag = ts
    end
  end
  # overwrite
  def dispose_spriteset
    pop_message_dispose_spriteset
    #@quack_msg_speech_bubble_sprites.each {|s| s.dispose}
    #@quack_msg_thought_bubble_sprites.each {|s| s.dispose}
    #return unless @bubble_tag_sprite || @thought_bubble_tag_sprite
    #@bubble_tag_sprite.dispose
    #@thought_bubble_tag_sprite.dispose
  end
  # alias
  #alias quack_msg_dispose_all_windows dispose_all_windows
  #def dispose_all_windows
  #  @quack_msgs.each {|m| m.dispose}
  #  quack_msg_dispose_all_windows
  #end
end

#==============================================================================
# ?! Scene_Battle
#==============================================================================
class Scene_Battle
  alias quack_update_basic update_basic
  def update_basic
    quack_update_basic
    @quack_msgs.each {|m| 
      m.update
      if m.open?
        m.update_placement
      end
    }
  end
  
  alias yse_pop_create_message_window create_message_window
  def create_message_window
    yse_pop_create_message_window
    @face_window = Window_Message_Face.new
    @face_window.message_window = @message_window
    if YSE::POP_MESSAGE::EFFECT[:use_bubble_tag]
      @bubble_tag_sprite = Sprite.new
      @bubble_tag_sprite.visible = false
      @bubble_tag_sprite.bitmap = Cache.system(YSE::POP_MESSAGE::EFFECT2[:bubble_tag_name])
      @bubble_tag_sprite.src_rect.set(0, 0, @bubble_tag_sprite.width, @bubble_tag_sprite.height / 2)
      @message_window.speech_bubble_tag = @bubble_tag_sprite
      
      @thought_bubble_tag_sprite = Sprite.new
      @thought_bubble_tag_sprite.visible = false
      @thought_bubble_tag_sprite.bitmap = Cache.system(YSE::POP_MESSAGE::EFFECT2[:thought_bubble_tag_name])
      @thought_bubble_tag_sprite.src_rect.set(0, 0, @thought_bubble_tag_sprite.width, @thought_bubble_tag_sprite.height / 2)
      @message_window.thought_bubble_tag = @thought_bubble_tag_sprite

    end
    @message_window.face_window = @face_window
    
    quack_create_message_window
  end
  
  def quack_create_message_window
    @quack_msgs = []
    @quack_msg_speech_bubble_sprites = []
    @quack_msg_thought_bubble_sprites = []
    QUACK::MSG::MAX_MSGS.times do |i|
      qm = Window_Quack_Message.new($game_message.quack_msgs[i], 200-QUACK::MSG::MAX_MSGS+i)
      @quack_msgs.push(qm)
      ss = Sprite.new
      ss.visible = false
      ss.bitmap = Cache.system(YSE::POP_MESSAGE::EFFECT2[:bubble_tag_name])
      ss.src_rect.set(0, 0, ss.width, ss.height / 2)
      qm.speech_bubble_tag = ss
      ts = Sprite.new
      ts.visible = false
      ts.bitmap = Cache.system(YSE::POP_MESSAGE::EFFECT2[:thought_bubble_tag_name])
      ts.src_rect.set(0, 0, ts.width, ts.height / 2)
      qm.thought_bubble_tag = ts
    end
  end
  
  alias yse_pop_dispose_spriteset dispose_spriteset
  def dispose_spriteset
    yse_pop_dispose_spriteset
    @quack_msg_speech_bubble_sprites.each {|s| s.dispose}
    @quack_msg_thought_bubble_sprites.each {|s| s.dispose}
    return unless @bubble_tag_sprite || @thought_bubble_tag_sprite
    @bubble_tag_sprite.dispose
    @thought_bubble_tag_sprite.dispose
  end
  
  alias quack_msg_dispose_all_windows dispose_all_windows
  def dispose_all_windows
    @quack_msgs.each {|m| m.dispose}
    quack_msg_dispose_all_windows
  end
end

#==============================================================================
# ?! Game_Interpreter
#==============================================================================
class Game_Interpreter
  def command_101
    item = $data_items[20]
    if $imported["YEA-MessageSystem"]
      wait_for_message
      $game_message.face_name = @params[0]
      $game_message.face_index = @params[1]
      $game_message.background = @params[2]
      $game_message.position = @params[3]
      
      startindex = @index+1
      textline = @list[startindex].parameters[0].dup
      chatdur = 0
      textline.gsub!(/<cm:([^<>]*)>/i) { chatdur = $1.to_i;"" }
      $game_message.prepare_msg(chatdur) if chatdur != 0
      while continue_message_string?
        @index += 1
        if @list[@index].code == 401
          textline = @list[@index].parameters[0] unless @index == startindex
          if chatdur != 0; $game_message.add_chatter(textline)
          else; $game_message.add(textline)
          end
        end
        break if $game_message.texts.size >= Variable.message_rows
      end
      case next_event_code
      when 102
        @index += 1
        setup_choices(@list[@index].parameters)
      when 103
        @index += 1
        setup_num_input(@list[@index].parameters)
      when 104
        @index += 1
        setup_item_choice(@list[@index].parameters)
      end
      $game_message.fin_msg if chatdur != 0
      wait_for_message
    else
      wait_for_message
      $game_message.face_name = @params[0]
      $game_message.face_index = @params[1]
      $game_message.background = @params[2]
      $game_message.position = @params[3]
      
      startindex = @index+1
      textline = @list[startindex].parameters[0].dup
      chatdur = 0
      textline.gsub!(/<cm:([^<>]*)>/i) { chatdur = $1.to_i;"" }
      $game_message.prepare_msg(chatdur) if chatdur != 0
      
      while next_event_code == 401       # Text data
        @index += 1
        textline = @list[@index].parameters[0] unless @index == startindex
        if chatdur != 0; $game_message.add_chatter(textline)
        else; $game_message.add(textline)
        end
      end
      case next_event_code
      when 102  # Show Choices
        @index += 1
        setup_choices(@list[@index].parameters)
      when 103  # Input Number
        @index += 1
        setup_num_input(@list[@index].parameters)
      when 104  # Select Item
        @index += 1
        setup_item_choice(@list[@index].parameters)
      end
      $game_message.fin_msg if chatdur != 0
      wait_for_message
    end
  end
  # new
  def clear_chatter
    $game_message.clear_chatter
  end
end

#==============================================================================
# 
# ?\ End of File
# 
#==============================================================================