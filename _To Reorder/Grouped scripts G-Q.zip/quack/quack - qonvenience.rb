=begin
#==============================================================================
 * Qonvenience - v1.0c
  Author: Quack
#==============================================================================

What it is and what does it do?
-------------------------------------------------------------------------------
-Code that I have made for my own conveniece and use for some of my scripts.
 Other than needing it if you plan to use certain scripts I've written it
 adds some functionality others might be interested in listed below:

-Adds event self variables.
 Usage: (event_id should be a number and key can be what you want. Usually a
          number or a string)
  -Set var: L[event_id,key] = "a_value"  OR   event.tset(key,"a_value")
  -Get var: somevar = L[event_id,key]    OR   somevar = event.tget(key)

-Can access event self switches similar to self vars.
 Usage:
  -Set switch: SS[event_id,"A"] = true   OR   event.sset("B",false)
  -Get switch: somevar = SS[event_id,"A"] OR  event.sget("C")

-Game variables and game switches can also be accessed with shorter commands
 using V[23] = 200, somevar = V[2] for game variables and S[4] = true,
 somevar = S[5] for game switches.

-Adds map local variables. That is variables that are unique to that map.
 Usage:
  -Set var: M[key] = 123
  -Get var: somevar = M[key]

-Adds Temporary variables that reset on map change. There exists both map wide 
 and event self temporary variables.
 Usage:
 -To set or get a normal temp var you do this: 
    TMP["a_key"] = 9999   OR  TMP[7] = "some_value"
    somevar = TMP["another_key"]  OR  somevar = TMP[13]
 -To set or get an event self tmp var:
    event.tset("a_key","a_value")
    event.tget("a_key")
    
-Adds a functionality for enemy respawning. It doesn't do anything unless you
 actually use it. I would have taken it out and put it a separate script but I
 didn't feel like it. A bunch of extra methods aliases and waste of time.
 If you have no interest in this just skip to the next point instead.
 I use visible enemies that chase you in my game. When an enemy dies I set it's
 self A switch to ON to make it stay dead. I did this because I didn't want 
 them to respawn everytime I went into the room. But I didn't want them stay
 dead forever either. What I did was add a counter to each map that is set to
 a certain value (depends on a game variable, which variable you decide in the
 config area below). Whenever you change map that value is reduced by 1 for all
 maps. When the value gets to 0 all events with the tag <en> in their name on 
 that map gets their 'A' self switch set to OFF so they will respawn. So if you
 set the variable to 2 you have to walk at least 2 maps away from a certain map
 for that maps enemies to respawn. It is also possible you might want all
 enemies to stay dead in a dungeon until you leave that dungeon. To do this
 you would set the game variable to a really high value so the enemies will 
 never respawn from you walking to other maps upon entering the dungeon. And 
 when you leave you set it back and also do this script call: 
   $game_respawnVars.clear
 So to use this all your respawnable enemies would have to use the self switch
 'A' as ON to make it dead and they also need to have the tag <en> in their
 event name.
    
-Some things for Move routes.
 -Designate event to move via code evaluation by setting the first command in
  a move route to script call starting with '[v]' followed by code that can
  be evaluated to a number like: '[v]20-5' OR '[v]V[12]'
 
-Like with move routes you can now using jump to label designate a label to
 jump to via code evaluation by setting the label name in the jump to label
 command to '[v]' followed by code that can be evaluated to a string.
  Like so: '[v]"my label"' OR '[v]V[34]' OR '[v]"my label" + M[2]'

-Call an event page like you would call a common event using this method in
 a script call: call_event(event_id, page_number)

-Support for editor suffixes.
  Have you ever had multiple versions of the same skill, all with same name?
  Or wanted to add a comment to an enemy's name to help you remember exactly
  what that enemy is and/or does just by seeing it in the list rather than
  having to click it and check it's details?
  Then this is it. With this script active any text following and including
  the first '(' in a database object's name will get removed in-game.
  For example let's say I have a couple of key items which are all for a
  certain sidequest, lets call it the "Pink Elephant" quest. Therefore I add
  '(Pink Elephant)' to the name of each of those key items so they are easy to
  spot in the list. So lets say one of these key items is the "Golden Peanut".
  That item now has the name "Golden Peanut(Pink Elephant)" in the editor.
  But in-game it still has the name "Golden Peanut" because the pink elephant
  part gets removed.

Requirements:
None

Instructions/Install notes:
Paste it below Materials like you would any other script.

Terms of Use:
Use it however you wish, but do give credit if you do.

Bugs:
dunno

History:
13/01/2016 - Added comments, cleaned code and uploaded it since my Chatter 
             Messages script requires it.
  
=end

$imported = {} if $imported.nil?
$imported["Qonvenience"] = true

#==============================================================================
# CONFIG
#==============================================================================
module QUACK
  
  # Number of the game switch used to turn of the auto change bgm on 
  # map change.
  TURN_OFF_AUTO_BGM_PLAY_SWITCH = 20
  
  # Number of game variable that designates how many maps you have to go away
  # from a given map for that given map's enemies to respawn.
  RESPAWN_ROOM_COUNT = 12 
  
end
#==============================================================================
# SCRIPT START
#==============================================================================

#==============================================================================
# DataManager - Local variables & item names
# -----------------------------------------------------------------------------
# Adds hashes for new variables and removes text from all database item names
# from the first encountered '('. Useful in for example when you have several
# versions of the same skill (a levelable skill perhaps) and want them all to 
# have the same name but still be able to easily tell them apart in the editor.
#==============================================================================
module DataManager
  class << self
    
    #--------------------------------------------------------------------------
    # alias: Create Game Objects
    #--------------------------------------------------------------------------
    alias local_create_game_objects create_game_objects
    def create_game_objects
      local_create_game_objects
      $game_selfVars = {}#Simple_Matrix.new
      $game_mapVars = {}
      $game_respawnVars = {}
      $game_tempVars = {}
      #$game_database = Database.finalize
    end
    
    #--------------------------------------------------------------------------
    # alias: Make Save Contents
    #--------------------------------------------------------------------------
    alias local_make_save_contents make_save_contents
    def make_save_contents
      contents = local_make_save_contents
      contents[:self_vars] = $game_selfVars
      contents[:map_vars] = $game_mapVars
      contents[:respawn_vars] = $game_respawnVars
      contents[:tmp_vars] = $game_tempVars
      contents
    end
      
    #--------------------------------------------------------------------------
    # alias: Extract Save Contents
    #--------------------------------------------------------------------------
    alias local_extract_save_contents extract_save_contents
    def extract_save_contents(contents)
      local_extract_save_contents(contents)
      $game_selfVars = contents[:self_vars]
      $game_mapVars = contents[:map_vars]
      $game_tempVars = contents[:tmp_vars]
      $game_respawnVars = contents[:respawn_vars]
      #$game_database = Database.finalize
     end
      
    #--------------------------------------------------------------------------
    # alias: Load database
    #--------------------------------------------------------------------------
    alias load_database_item_names load_database
    def load_database
      load_database_item_names
      load_item_names
      load_notetags_type_tags
    end
    
    #--------------------------------------------------------------------------
    # new: Load Type Tags
    #--------------------------------------------------------------------------
    def load_notetags_type_tags
      for obj in $data_states
        next if obj.nil?
        obj.load_notetags_type_tags
      end
      for obj in $data_skills
        next if obj.nil?
        obj.load_notetags_type_tags
      end
      for obj in $data_items
        next if obj.nil?
        obj.load_notetags_type_tags
      end
      for obj in $data_weapons
        next if obj.nil?
        obj.load_notetags_type_tags
      end
      for obj in $data_armors
        next if obj.nil?
        obj.load_notetags_type_tags
      end
      for obj in $data_actors
        next if obj.nil?
        obj.load_notetags_type_tags
      end
      for obj in $data_enemies
        next if obj.nil?
        obj.load_notetags_type_tags
      end
    end
         
    #--------------------------------------------------------------------------
    # new: Remove Editor suffixes from items
    #--------------------------------------------------------------------------
    def load_item_names
      for actor in $data_actors
        next if actor.nil?
        actor.name = actor.name.partition("(")[0]
      end
      for clas in $data_classes
        next if clas.nil?
        clas.name = clas.name.partition("(")[0]
      end
      for item in $data_items
        next if item.nil?
        item.name = item.name.partition("(")[0]
      end
      for weapon in $data_weapons
        next if weapon.nil?
        weapon.name = weapon.name.partition("(")[0]
      end
      for armor in $data_armors
        next if armor.nil?
        armor.name = armor.name.partition("(")[0]
      end
      for skill in $data_skills
        next if skill.nil?
        skill.name = skill.name.partition("(")[0]
      end
      for state in $data_states
        next if state.nil?
        state.name = state.name.partition("(")[0]
      end
      for enemy in $data_enemies
        next if enemy.nil?
        enemy.name = enemy.name.partition("(")[0]
      end
    end
  end
end

class RPG::BaseItem
  attr_accessor :type_tags

  def has_tag?(tag)
    return @type_tags.include?(tag)
  end
  
  def load_notetags_type_tags
    @type_tags = self.note =~ /<TAGS:([^<>]*)>/i ? $1 : ""
  end
end # RPG::BaseItem

#==============================================================================
# TEMPORARY VARIABLES (reset on map change)
#==============================================================================
class TMP
  class << self
    def [](*arg)#id)
      case arg.length
        when 1
          return 0 if $game_tempVars[[arg[0]]].nil?
          return $game_tempVars[[arg[0]]]
        when 2
          return 0 if $game_tempVars[[arg[0], arg[1]]].nil?
          return $game_tempVars[[arg[0], arg[1]]]
      end
    end
    
    def []=(*arg)#id, val)
      case arg.length
        when 2; $game_tempVars[[arg[0]]] = arg[1]
        when 3; $game_tempVars[[arg[0],arg[1]]] = arg[2]
      end
      $game_map.need_refresh = true
    end  
    
    def clear
      $game_tempVars.clear
    end
  end
end

#==============================================================================
# MAP LOCAL VARIABLES
#==============================================================================
class M
  class << self
    def [](var_id)
      return 0 if $game_mapVars[[$game_map.map_id,var_id]].nil?
      return $game_mapVars[[$game_map.map_id,var_id]]
    end
    
    def []=(var_id, value)
      $game_mapVars[[$game_map.map_id,var_id]] = value
      $game_map.need_refresh = true
    end
  end
end

#==============================================================================
# EVENT LOCAL VARIABLES
#==============================================================================
class L
  class << self
    def [](eid, vid)
      return 0 if $game_selfVars[[$game_map.map_id,eid,vid]].nil?
      return $game_selfVars[[$game_map.map_id,eid,vid]]
    end
    
    def []=(eid, vid, value)
      $game_selfVars[[$game_map.map_id,eid,vid]] = value
      $game_map.need_refresh = true
    end
  end
end

#==============================================================================
# SELF SWITCHES
#==============================================================================
class SS
  class << self
    def [](eid, vid)
      return false if $game_self_switches[[$game_map.map_id, eif, vid]].nil?
      return $game_self_switches[[$game_map.map_id, eif, vid]]
    end
    
    def []=(eid, vid, value)
      $game_self_switches[[$game_map.map_id,eid,vid]] = value
      $game_map.need_refresh = true
    end
  end
end

#==============================================================================
# GLOBAL VARIABLES
#==============================================================================
class V
  class << self
    def [](id)
      return 0 if id < 1
      return $game_variables[id]
    end
    
    def []=(id, value)
      $game_variables[id] = value
    end
  end
end

#==============================================================================
# GLOBAL SWITCHES
#==============================================================================
class S
  class << self
    def [](id)
      return false if id < 1
      return $game_switches[id]
    end
    
    def []=(id, value)
      $game_switches[id] = value
    end
  end
end

#==============================================================================
#==============================================================================

class Game_Battler < Game_BattlerBase
  #--------------------------------------------------------------------------
  # new: Check if battler has that tag
  #--------------------------------------------------------------------------
  def has_tag?(tag)
    return $data_enemies[@enemy_id].has_tag?(tag)
  end
  
  #--------------------------------------------------------------------------
  # new: Check if battler has state with that tag
  #--------------------------------------------------------------------------
  def tagged_state?(tag)
    for state in states
      return true if state.type_tags.include?(tag)
    end
    return false
  end
  
  #--------------------------------------------------------------------------
  # new: Remove states with specified tag
  #--------------------------------------------------------------------------
  def remove_tagged_states(tag)
    rstates = []
    s = states
    for state in s
      if state.type_tags.include?(tag)
        remove_state(state.id)
        rstates.push(state)
      end
    end
    return rstates
  end
  
  #--------------------------------------------------------------------------
  # new: Return all states battler has with specified tag
  #--------------------------------------------------------------------------
  def states_with_tags(tag)
    s = []
    for state in states
      s.push(state.id) if state.type_tags.include?(tag)
    end
    return s
  end
end

class Game_Actor < Game_Battler
  #--------------------------------------------------------------------------
  # new: Check if battler has that tag
  #--------------------------------------------------------------------------
  def has_tag?(tag)
    return actor.has_tag?(tag)
  end
end

class Game_Map
  attr_reader   :map_id
  
  #--------------------------------------------------------------------------
  # alias: Autoplay
  # Switch for turning off bgm auto starting new song when entering map
  #--------------------------------------------------------------------------
  alias quack_qon_autoplay autoplay
  def autoplay
    if S[QUACK::TURN_OFF_AUTO_BGM_PLAY_SWITCH]
      @map.bgs.play if @map.autoplay_bgs
    else
      quack_qon_autoplay
    end
  end
  
  #--------------------------------------------------------------------------
  # alias: Setup
  # Clear TMP vars, clear event name tags & update enemy respawn
  #--------------------------------------------------------------------------
  alias qack_qon_setup setup
  def setup(map_id)
    TMP.clear
    @q_name_tags = {}
    qack_qon_setup(map_id)
    if get_respawn(map_id) == 0
      e = all_event_tag('en')
      e.each {|ev| ev.sset("A",false) } unless e.nil?
    end
    for key in $game_respawnVars.keys
      $game_respawnVars[key] -= 1
    end
    $game_respawnVars[map_id] = V[QUACK::RESPAWN_ROOM_COUNT]
    $game_respawnVars.delete_if {|k,v| v <= 0 }
  end
  
  #--------------------------------------------------------------------------
  # new: Add Event Tags
  # Used for event name tags
  #--------------------------------------------------------------------------
  def add_event_tags(ev)
    t = ev.name.scan(/<([^<>]*)>/i)
    return if t.nil? || t.length < 1
    t.each {|s|
      if @q_name_tags.has_key?(s[0])
        @q_name_tags[s[0]].push(ev)
      else
        @q_name_tags[s[0]] = [ev]
      end
      ev.add_name_tag(s[0])
    }
  end
  
  #--------------------------------------------------------------------------
  # new: Delete Event Tags
  # Used for event name tags
  #--------------------------------------------------------------------------
  def delete_event_tags(ev)
    ev.name_tags.each{|s|
      @q_name_tags[s].delete(ev)
    }
  end
  
  #--------------------------------------------------------------------------
  # new: First Event With Tag
  # First event on map with specified tag
  #--------------------------------------------------------------------------
  def first_event_tag(tag)
    return nil unless @q_name_tags.has_key?(tag)
    return @q_name_tags[tag][0]
  end
  #--------------------------------------------------------------------------
  # new: Last Event With Tag
  # Last event on map with specified tag
  #--------------------------------------------------------------------------
  def last_event_tag(tag)
    return nil unless @q_name_tags.has_key?(tag)
    return @q_name_tags[tag][@q_name_tags[tag].length-1]
  end
  #--------------------------------------------------------------------------
  # new: All Events With Tag
  # All events on map with specified tag
  #--------------------------------------------------------------------------
  def all_event_tag(tag)
    return nil unless @q_name_tags.has_key?(tag)
    return @q_name_tags[tag]
  end
  
  #--------------------------------------------------------------------------
  # new: get respawn
  # get respawn var
  #--------------------------------------------------------------------------
  def get_respawn(id)
    return $game_respawnVars[id] if $game_respawnVars.has_key?(id)
    return 0
  end
  
end


class Game_Character < Game_CharacterBase
  #--------------------------------------------------------------------------
  # alias: process_move_command
  #--------------------------------------------------------------------------
  alias process_move_command_movement_cmds_alias process_move_command
  def process_move_command(command)
    case command.code
      when ROUTE_SCRIPT
        return if command.parameters[0].include? '[v]'
    end
    process_move_command_movement_cmds_alias(command)
  end
  
  MOVE_SYMBOL_CODE = {
  :UP    => ROUTE_MOVE_UP,
  :DOWN  => ROUTE_MOVE_DOWN,
  :LEFT  => ROUTE_MOVE_LEFT,
  :RIGHT => ROUTE_MOVE_RIGHT,
  :FORWARD => ROUTE_MOVE_FORWARD,
  :BACKWARD => ROUTE_MOVE_BACKWARD,
  :TOWARD => ROUTE_MOVE_TOWARD,
  :AWAY => ROUTE_MOVE_AWAY,
  }
  
  #--------------------------------------------------------------------------
  # new method: opacity_tween
  #--------------------------------------------------------------------------
  def opacity_tween(opacity, duration) 
    crnt_opacity = @opacity
    i = (opacity - crnt_opacity).to_f / duration
    for x in (0..duration)
      @move_route.list.insert(@move_route_index + x + 1, RPG::MoveCommand.new(ROUTE_CHANGE_OPACITY, [crnt_opacity.to_i]))
      crnt_opacity += i
      crnt_opacity = opacity if x == (duration-1)
    end
    @move_route.list.delete_at(@move_route_index)
  end

  #--------------------------------------------------------------------------
  # new method: move
  #--------------------------------------------------------------------------
  def move(dir, steps)
    dir = MOVE_SYMBOL_CODE[dir] if dir.is_a?(Symbol)
    for x in (1..steps)
      @move_route.list.insert(@move_route_index + x, RPG::MoveCommand.new(dir))
    end
    @move_route.list.delete_at(@move_route_index)
  end
  
  def gotoxy(x,y)
    @x = x
    @y = y
  end
  
  def moveto2(x, y)
    @x = x % $game_map.width
    @y = y % $game_map.height
    @real_x = @x
    @real_y = @y
  end
  
  def moveto2_d(l, d)
    @y -= l if d == 8
    @y += l if d == 2
    @x -= l if d == 4
    @x += l if d == 6
    @real_x = @x
    @real_y = @y
  end
  
  def set_move_speed(val)
    @move_speed = val
  end
  
  def clear_move_route
    @move_route = nil
    @move_route_index = 0
    @wait_count = 0
  end
  
  def turn_left
    set_direction(4)
  end
  def turn_right
    set_direction(6)
  end
  def turn_up
    set_direction(8)
  end
  def turn_down
    set_direction(2)
  end
end

class Game_Player < Game_Character
  alias init_alias initialize
  def initialize
    init_alias
    @move_input_enabled = true
  end
  
  def disable_move_input
    @move_input_enabled = false
  end
  
  def enable_move_input
    @move_input_enabled = true
  end
  
  def in_control?
    return @move_input_enabled
  end
  
  alias qon_movable movable?
  def movable?
    return false if !@move_input_enabled
    qon_movable
  end
  
  #alias move_by_input_alias move_by_input
  #def move_by_input
  #  return if !@move_input_enabled
  #  move_by_input_alias
  #end
end

class RPG::Event::Page
  attr_reader :page_tags
  attr_reader :note_tags
  
  def setup_notetags
    @note_tags = ""
    @page_tags = []
    return if !@list || @list.size <= 0
    # build note tags
    list.each {|i|
      @note_tags += i.parameters[0] if i && (i.code == 108 || i.code == 408)
    }
    # get page tags from note tags
    t = @note_tags.scan(/<t:([^<>]*)>/i)
    @page_tags = t if t.nil? || t.length < 1
  end
end

class Game_Event < Game_Character
  
  #--------------------------------------------------------------------------
  # alias: initialize
  # For event name tags.
  #--------------------------------------------------------------------------
  alias quack_qon_init initialize
  def initialize(map_id, event)
    quack_qon_init(map_id, event)
    $game_map.add_event_tags(self)
    @event.pages.each {|p|
      p.setup_notetags
    }
  end
  #--------------------------------------------------------------------------
  # new: Add name tag
  # For event name tags.
  #--------------------------------------------------------------------------
  def add_name_tag(tag)
    if @name_tags.nil?
      @name_tags = [tag]
    else
      @name_tags.push(tag)
    end
  end
  def name_tags
    return [] if @name_tags.nil?
    return @name_tags
  end
  #--------------------------------------------------------------------------
  # new: Return event's name
  # For event name tags.
  #--------------------------------------------------------------------------
  def name
    return @event.name
  end
  
  def page_tags
    return @page.page_tags
  end
  
  def notetags_page
    return @page.note_tags
  #  return "" if !@page || !@page.list || @page.list.size <= 0
  #  return @notetags_page if @notetags_page
  #  @notetags_page = ""
  #  l = []
  #  @page.list.each {|i|
  #    @notetags_page += i.parameters[0] if i && (i.code == 108 || i.code == 408)
  #  }
  #  return @notetags_page
  end  
  def notetags
    @notetags = ""
    @event.pages.each {|p|
      next if !p || !p.list || p.list.size <= 0
      p.list.each {|i|
        @notetags += i.parameters[0] if i && (i.code == 108 || i.code == 408)
      }
    }
    return @notetags
  end
  
  # METHODS FOR ACCESSING THE EVENTS LOCAL VARIABLES AND SWITCHES
  
  #--------------------------------------------------------------------------
  # new: Get self var
  #--------------------------------------------------------------------------
  def lget(id)
    return $game_selfVars[[@map_id,@id,id]]
  end
  #--------------------------------------------------------------------------
  # new: Set self var
  #--------------------------------------------------------------------------
  def lset(id,val)
    $game_selfVars[[@map_id,@id,id]] = val
  end

  #--------------------------------------------------------------------------
  # new: Get self switch
  #--------------------------------------------------------------------------
  def sget(id)
    return $game_self_switches[[@map_id,@id,id]]
  end
  #--------------------------------------------------------------------------
  # new: Set self switch
  #--------------------------------------------------------------------------
  def sset(id,val)
    $game_self_switches[[@map_id,@id,id]] = val
  end
  
  #--------------------------------------------------------------------------
  # new: Get self temp var
  #--------------------------------------------------------------------------
  def tget(id)
    return TMP[@id,id]
    return 0
  end
  #--------------------------------------------------------------------------
  # new: Set self temp var
  #--------------------------------------------------------------------------
  def tset(id,val)
    $game_tempVars[[@id,id]] = val
    $game_map.need_refresh = true
  end
  
  #--------------------------------------------------------------------------
  # new: Get Page
  # Needed for event page call
  #--------------------------------------------------------------------------
  def get_page(index)
    return @event.pages[index]
  end
end

class Game_Interpreter
  #--------------------------------------------------------------------------
  # * Self Vars
  #--------------------------------------------------------------------------
  
  #--------------------------------------------------------------------------
  # new: lget
  # get self var
  #--------------------------------------------------------------------------
  def lget(*arguments)
    result = 0
    case arguments.length
      when 1; result = $game_selfVars[[@map_id, @event_id, arguments[0]]]
      when 2; result = $game_selfVars[[@map_id, arguments[0], arguments[1]]]
      when 3; result = $game_selfVars[[arguments[0], arguments[1], arguments[2]]]
    end
    return result
  end
  #--------------------------------------------------------------------------
  # new: lset
  # set self var
  #--------------------------------------------------------------------------
  def lset(*arguments)
    case arguments.length
      when 2; $game_selfVars[[@map_id, @event_id, arguments[0]]] = arguments[1]
      when 3; $game_selfVars[[@map_id, arguments[0], arguments[1]]] = arguments[2]
      when 4; $game_selfVars[[arguments[0], arguments[1], arguments[2]]] = arguments[3]
    end
    $game_map.need_refresh = true
  end
  #--------------------------------------------------------------------------
  # * Self Switches
  #--------------------------------------------------------------------------
  
  #--------------------------------------------------------------------------
  # new: sget
  # get self switch
  #--------------------------------------------------------------------------
  def sget(*arguments)
    result = false
    case arguments.length
      when 1; result = $game_self_switches[[@map_id, @event_id, arguments[0]]]
      when 2; result = $game_self_switches[[@map_id, arguments[0], arguments[1]]]
      when 3; result = $game_self_switches[[arguments[0], arguments[1], arguments[2]]]
    end
    return result
  end
  #--------------------------------------------------------------------------
  # new: sset
  # set self switch
  #--------------------------------------------------------------------------
  def sset(*arguments)
    case arguments.length
      when 2; $game_self_switches[[@map_id, @event_id, arguments[0]]] = arguments[1]
      when 3; $game_self_switches[[@map_id, arguments[0], arguments[1]]] = arguments[2]
      when 4; $game_self_switches[[arguments[0], arguments[1], arguments[2]]] = arguments[3]
    end
    $game_map.need_refresh = true
  end
  
  #--------------------------------------------------------------------------
  # * Respawn Vars
  #--------------------------------------------------------------------------
  
  #--------------------------------------------------------------------------
  # new: get respawn
  # get respawn var
  #--------------------------------------------------------------------------
  def get_respawn(id)
    return $game_respawnVars[id] if $game_respawnVars.has_key?(id)
    return 0
  end
  #--------------------------------------------------------------------------
  # new: set respawn
  # set respawn var
  #--------------------------------------------------------------------------
  def set_respawn(id, value)
    $game_respawnVars[id] = value
  end
  
  #--------------------------------------------------------------------------
  # * Easier to remember fade commands
  #--------------------------------------------------------------------------
  def fade_in(duration)
    screen.start_fadein(duration)
  end
  def fade_out(duration)
    screen.start_fadeout(duration)
  end
  
  #--------------------------------------------------------------------------
  # alias: Temporarily Erase Event
  # For event name tags
  #--------------------------------------------------------------------------
  alias quack_qon_command_214 command_214
  def command_214
    $game_map.delete_event_tags($game_map.events[@event_id])
    quack_qon_command_214
  end
  
  #--------------------------------------------------------------------------
  # overwrite method: command_205 (Set Move Route)
  # ---------------------------------------------------
  # By making the first command in a move route a script call which starts
  # with '[v]' the rest of the script call be evaluated to an integer which
  # is used as character id to chose which event the move route pertains to.
  #--------------------------------------------------------------------------
  def command_205 # COMMAND SET MOVE ROUTE
    $game_map.refresh if $game_map.need_refresh
    character = get_character(@params[0])
    cmd = @params[1].list[0]
    if cmd.code == 45 # 45 = SCRIPT COMMAND
      if cmd.parameters[0].include? '[v]'
        @params[0] = eval(cmd.parameters[0][3..cmd.parameters[0].length])
        character = get_character(@params[0])
        #@params[1].list.delete_at(0)
      end
    end
    if character
      character.force_move_route(@params[1].dup)
      Fiber.yield while character.move_route_forcing if @params[1].wait
    end
  end
  
  #==========================================================================
  # * Jump to Label (edited to allow to jump to a label using a variable)
  #==========================================================================
  def command_119
    label_name = @params[0]
    if label_name.include? '[v]'
      label_name = eval(label_name[3..label_name.length])
    end
    @list.size.times do |i|
      if @list[i].code == 118 && @list[i].parameters[0] == label_name
        @index = i
        return
      end
    end
  end
  
  #==========================================================================
  # * Call event page
  #==========================================================================
  def call_event(event_id, page_id)
    qq = Game_Interpreter.new(@depth + 1)
    page = evs[event_id].get_page(page_id)
    qq.setup(page.list, event_id)
    qq.run
  end
  
  def ev; @event_id; end
  def evs; $game_map.events; end
  def me; evs[ev]; end
  def pl; $game_player; end
  def char(id); get_character(id); end
  def map; return $game_map; end
  def set_move_speed(char_id, val)
    get_character(char_id).set_move_speed(val)
  end
  
  def move_to_point(id,x,y,wait=false)
    c = char(id)
    c.move_to_point(x,y)
    Fiber.yield while c.move_route_forcing if wait
  end
  
  #--------------------------------------------------------------------------
  # new: First event with tag
  #--------------------------------------------------------------------------
  def first_event_tag(tag)
    $game_map.first_event_tag(tag)
  end
  #--------------------------------------------------------------------------
  # new: Last event with tag
  #--------------------------------------------------------------------------
  def last_event_tag(tag)
    $game_map.last_event_tag(tag)
  end
  #--------------------------------------------------------------------------
  # new: All events with tag
  #--------------------------------------------------------------------------
  def all_event_tag(tag)
    $game_map.all_event_tag(tag)
  end
  #--------------------------------------------------------------------------
  # new: Find all events with all the specified tags
  #--------------------------------------------------------------------------
  def find_events(*args)
    result = []
    evs.keys.each {|k|
      unless evs[k].name_tags.nil?
        if (args - evs[k].name_tags).empty?
          result.push(evs[k])
        end
      end
    }
    return result
  end
  
  def diff(val1, val2)
    return (val1 - val2).abs
  end
  
  def pos_diff(id1, id2)
    c1 = char(id1)
    c2 = char(id2)
    xd = c1.x - c2.x
    yd = c1.y - c2.y
    xd *= xd
    yd *= yd
    return Math.sqrt(xd+yd)
  end
  
  #returns true if the distance between char1 and char2 is greater than dist
  def distance_gt(ev1,ev2,dist)#id1, id2, dist)
    #xd = char(id1).x - char(id2).x
    #yd = char(id1).y - char(id2).y
    xd = ev1.x - ev2.x
    yd = ev1.y - ev2.y
    xd *= xd
    yd *= yd
    return (xd + yd) > dist * dist
  end
  
  # returns true if the difference between val1 and val2 is greater than i.
  def diff_gt(val1, val2, i)
    if val1 < val2 - i; return true; end
    if val1 > val2 + i; return true; end
    return false
  end
  
  # returns true if the position1 is equal to position2
  def pos_is?(*arg)
    case arg.length
      when 1
        c = get_character(arg[0])
        return c.x == me.x && c.y == me.y
      when 2
        c1 = get_character(arg[0])
        c2 = get_character(arg[1])
        return c1.x == c2.x && c1.y == c2.y
      when 3
        c1 = get_character(arg[0])
        return c1.x == arg[1] && c2.y == arg[2]
      when 4
        return arg[0] == arg[2] && arg[1] == arg[3]
    end
    return false
  end
  
  # Returns in which of the 4 directions char2 is related to char1
  def ev_dir(char1, char2)
    if diff(char1.x, char2.x) > diff(char1.y,char2.y)
      if char1.x < char2.x
        return 6
      else
        return 4
      end
    else
      if char1.y < char2.y
        return 2
      else
        return 8
      end
    end
  end
  
  def wait_rnd(min_dur, max_dur)
    duration = min_dur + rnd(max_dur - min_dur).to_i
    duration.times { Fiber.yield }
  end
  
  def break_loop #becuz who can remember that 113 = break?
    command_113
  end
  
  # Prepare for cutscene
  def prep_scene
    $game_system.menu_disabled = true
    $game_system.save_disabled = true
    pl.disable_move_input
  end
  
  #end cutscene
  def end_scene
    $game_system.menu_disabled = false
    $game_system.save_disabled = false
    pl.enable_move_input
  end
end