#========================================================================
# ** Text Box Yabber, by: KilloZapit
#------------------------------------------------------------------------
# Plays sounds when textboxes print stuff!
#========================================================================

module Text_Sound_Config
  
  # Default value from the hash bellow. Can leave as nil to set as none.
  
  DEFAULT_SOUND = :default
  
  # Here is the hash that stores sound configuration you can insert a line 
  # with a syntex
  # like this:
  
  # :id      => ["file", vol, pitch, timing],

  # :id is the id you use to lable the sound. Any event with a lable like [id]
  # will automaticly use the sound with the matching id here when it isn't
  # overwridden with a face sound value. vol is the volume to play the sound at.
  # pitch is a single pitch or a range of pitches useing .. as in 50..150. Keep
  # in mind pitches can't go bellow 50 or above 150. timing is how many frames
  # minimum the script needs to wait between sounds.
  
  SOUND_HASH = {
    :default => ["miss", 100, 80..120, 3],
    :dog     => ["dog" , 100, 50..150, 3],
  }
  
  # Here is a hash for assigning voices to faces! It can assign to whole face
  # sets or just to a perticular index. Assigning to a index will override the
  # more general case. To assign to a whole face set use:
  
  # 'faceset' => :id
  
  # and for a perticular index use:
  
  # ['faceset', index] =? :id
  
  FACE_HASH = {
    '' => :silence,
    ['Spiritual', 5] => :dog,
  }
    
end

#========================================================================
# Bellow here there be dragons!
#========================================================================

class Text_Sound < RPG::SE
  
  def initialize(name = '', volume = 100, pitch = 100, timeout = 3)
    @timeout = timeout
    @next_frame = 0
    super(name, volume, pitch)
  end
  
  def play
    unless @name.empty? || !can_play?
      p = @pitch.is_a?(Enumerable) ? @pitch.to_a.sample : @pitch
      Audio.se_play('Audio/SE/' + @name, @volume, p)
      @next_frame = Graphics.frame_count + @timeout
    end
  end
  
  def can_play?
    Graphics.frame_count >= @next_frame
  end
  
end

class Game_Event
  
  def get_voice_id
    if @event.name.downcase =~ /\s*\[\s*([^\s]*)\s*\]\s*/
      return $1.to_sym
    end
    nil
  end

end

class Game_Interpreter
  
  alias_method :command_101_text_sound_base, :command_101
  def command_101
    wait_for_message
    puts @params[0].inspect
    if s = Text_Sound_Config::FACE_HASH[[@params[0], @params[1]]] ||
       s = Text_Sound_Config::FACE_HASH[@params[0]] ||
       s = $game_map.events[@event_id].get_voice_id
      $game_message.set_sound(s)
    else
      $game_message.set_sound(Text_Sound_Config::DEFAULT_SOUND)
    end
    command_101_text_sound_base
  end

end

class Game_Message

  attr_reader :sound
  
  alias_method :clear_text_sound_base, :clear
  def clear
    clear_text_sound_base
    @sound = nil
  end
  
  def set_sound(sound_id)
    return unless sound_id
    return unless sound_args = Text_Sound_Config::SOUND_HASH[sound_id]
    @sound = Text_Sound.new(*sound_args)
  end

end

class Window_Message < Window_Base

  alias_method :wait_for_one_character_text_sound_base, :wait_for_one_character
  def wait_for_one_character
    if $game_message.sound
      $game_message.sound.play
    end
    wait_for_one_character_text_sound_base
  end

end