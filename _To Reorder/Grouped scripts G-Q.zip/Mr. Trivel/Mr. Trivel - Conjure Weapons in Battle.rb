# )-----------------------------------------------------(
# )--     Author:     Mr Trivel                       --(
# )--     Name:       Conjure Weapons                 --(
# )--     Created:    2014-06-14                      --(
# )--     Version:    1.0b                            --(
# )-----------------------------------------------------(
# )--     Requires:   None                            --(
# )-----------------------------------------------------(
# )--             Description                         --(
# )--  Spells now allow you to equip magical weapons. --(
# )-----------------------------------------------------(
# )--             Instructions                        --(
# )--  Use the following Note tag on a skill:         --(
# )--  <Wequip: X, Y> or <Wequip: X>                  --(
# )--  X - Weapon ID in the database, Y - duration.   --(
# )--  If duration is not specified, the weapon will  --(
# )--  last whole battle.                             --(
# )-----------------------------------------------------(
# )--             LICENSE INFO                        --(
# )-- http://mrtrivelvx.wordpress.com/terms-of-use/   --(
# )-----------------------------------------------------(
 
# )-------------------------(
# )--  Class: RPG::Skill  --(
# )-------------------------(
class RPG::Skill < RPG::UsableItem
  # )-------------------------------(
  # )--  New Method: spell_equip  --(
  # )-------------------------------(
  def spell_equip
    return nil unless note[/<wequip:\s*(\d*),*\s*(\d*)>/i]
    return [$1.to_i] if $2.to_i == 0
    return [$1.to_i, $2.to_i+1]
  end
end
 
 
$imported = {} if $imported.nil?
$imported["MrTS_Conjured_Weapons"] = true
 
# )-------------------------(
# )--  Class: RPG::Skill  --(
# )-------------------------(
class Game_Actor < Game_Battler
 
  attr_reader   :original_weapon
  attr_reader   :conjured_weapon_timer
 
  # )----------------------------------(
  # )--  Alias to: item_user_effect  --(
  # )----------------------------------(
  alias mrts_item_user_effect item_user_effect
  def item_user_effect(user, item)
    mrts_item_user_effect(user, item)
    w_data = item.spell_equip if item.is_a?(RPG::Skill)
    unless !w_data
      t_wep = $data_weapons[w_data[0]]
      @conjured_weapon_timer = nil
      @original_weapon = user.weapons[0] unless @original_weapon
      @conjured_weapon_timer = w_data[1] if w_data[1]
      user.force_change_equip(0, t_wep)
      @result.conjured = true
    end
  end
 
  # )-------------------------------(
  # )--  Alias to: on_battle_end  --(
  # )-------------------------------(
  alias mrts_on_battle_end on_battle_end
  def on_battle_end
    if @original_weapon
      force_change_equip(0, @original_weapon)
      @original_weapon = nil
    end
    mrts_on_battle_end
  end
 
  # )-----------------------------(
  # )--  Alias to: on_turn_end  --(
  # )-----------------------------(
  alias mrts_on_turn_end on_turn_end
  def on_turn_end
    mrts_on_turn_end
    @conjured_weapon_timer -= 1 if @conjured_weapon_timer
    if @conjured_weapon_timer && @conjured_weapon_timer <= 0 && @original_weapon
      force_change_equip(0, @original_weapon)
      @original_weapon = nil
      @conjured_weapon_timer = nil
      @result.conjure_end = true
    end
  end
 
  def release_unequippable_items(item_gain = true)
    loop do
      last_equips = equips.dup
      @equips.each_with_index do |item, i|
        if (!equippable?(item.object) || item.object.etype_id != equip_slots[i]) && !(item.object.is_a?(RPG::Weapon) && original_weapon)
          trade_item_with_party(nil, item.object) if item_gain
          item.object = nil
        end
      end
      return if equips == last_equips
    end
  end
end
 
# )-------------------------------(
# )--  Class: Window_BattleLog  --(
# )-------------------------------(
class Window_BattleLog < Window_Selectable
 
  # )-----------------------------------------(
  # )--  Overwrite Method: display_failure  --(
  # )-----------------------------------------(
  def display_failure(target, item)
    if target.result.hit? && !target.result.success && !target.result.conjured
      add_text(sprintf(Vocab::ActionFailure, target.name))
      wait
    end
  end
end
 
# )--------------------------------(
# )--  Class: Game_ActionResult  --(
# )--------------------------------(
class Game_ActionResult
  #--------------------------------------------------------------------------
  # * Public Instance Variables
  #--------------------------------------------------------------------------
  attr_accessor :conjured                     # conjured flag
  attr_accessor :conjure_end
 
  # )--------------------------------(
  # )--  Overwrite Method:  clear  --(
  # )--------------------------------(
  alias mrts_clear clear
  def clear
    mrts_clear
    @conjured = false
  end
 
  # )-------------------------------------(
  # )--  New Method: clear_conjuration  --(
  # )-------------------------------------(
  def clear_conjuration
    @conjure_end = false
  end
end
 
# )---------------------------(
# )--  Class: Scene_Battle  --(
# )---------------------------(
class Scene_Battle < Scene_Base
 
  # )------------------------------(
  # )--  Alias Method: turn_end  --(
  # )------------------------------(
  alias mrts_sb_cw_turn_end turn_end
  def turn_end
    mrts_sb_cw_turn_end
    all_battle_members.each do |battler|
      battler.result.clear_conjuration
    end
  end
end
 
# )-------------------------------(
# )--  Class: Window_BattleLog  --(
# )-------------------------------(
class Window_BattleLog < Window_Selectable
  # )-----------------------------------------------(
  # )--  New Method: display_conjure_effect_loss  --(
  # )-----------------------------------------------(
    def display_conjure_effect_loss(subject)
    if subject.result.conjure_end
      add_text("Conjured weapon of " + subject.name + " has ended.")
      wait
    end
  end
end