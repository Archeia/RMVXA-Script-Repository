# )--------------------------------------------------(
# )--     Author:     Mr Trivel                    --(
# )--     Name:       Thirst System                --(
# )--     Created:    2014-06-08                   --(
# )--     Version:    1.1                          --(
# )--------------------------------------------------(
# )-- v1.1 - Negative Quench values can now be used--(
# )--        to make the person more thirsty.      --(
# )--------------------------------------------------(
# )--     Requires:   None                         --(
# )--------------------------------------------------(
# )--             Description                      --(
# )--  Your Actors can now be thirsty! At 0 thirst --(
# )--  value they will start losing hp.            --(
# )--------------------------------------------------(
# )--             Instructions                     --(
# )--  Use <Quench: X> in Consumable Item's Note   --(
# )--  tags to restore X% of the thirst.           --(
# )--------------------------------------------------(
# )--  Thanks to TheoAllen for helping with item   --(
# )--  targets.                                    --(
# )--------------------------------------------------(
# )--             LICENSE INFO                     --(
# )--http://mrtrivelvx.wordpress.com/terms-of-use/ --(
# )--------------------------------------------------(
 
module MrTS
  module Thirst
    LEVELS = {
    # )--------------------------------------------------(
    # )--  Thirst levels that will be shown on menu    --(
    # )--  If thirst >= X, that's what gonna be written--(
    # )--  X - 0..100                                  --(
    # )--------------------------------------------------(
    # )--     X  => "Text"                             --(
    # )--------------------------------------------------(
              65 => "Quenched",
              30 => "Thirsty",
              1  => "Dehydrated",
              0  => "Dying"
    # )--------------------------------------------------(
             }
    # )--------------------------------------------------(
    # )--  Actors will start with this thirst value.   --(
    # )--  Default: 70, meaning they will be 70% full. --(
    # )--------------------------------------------------(
    DEFAULT_THIRST = 70
   
    # )--------------------------------------------------(
    # )--  Lose 1 thirst value each Xth turn.          --(
    # )--------------------------------------------------(
    LOSE_THIRST_PER = 7
   
    # )--------------------------------------------------(
    # )--  If Actor can't lose another thirst point,   --(
    # )--  it will take damage instead. This denotes   --(
    # )--  how much damage the Actor will take.        --(
    # )--------------------------------------------------(
    THIRST_DAMAGE = 25
  end
end
 
# )--------------------------------------------------(
$imported = {} if $imported.nil?  #                --(
$imported["MrTS_Thirst"] = true   #                --(
# )--------------------------------------------------(
 
# )----------------------------------------(
# )--  Class: Game_Actor < Game_Battler  --(
# )----------------------------------------(
class Game_Actor < Game_Battler
 
  # )-------------------------------(
  # )--  Public access variables  --(
  # )-------------------------------(
  attr_accessor     :thirst
 
  # )-----------------------(
  # )--  Alias to: setup  --(
  # )-----------------------(
  alias mrts_ga_setup setup
  def setup(*args)
    mrts_ga_setup(*args)
    @thirst = MrTS::Thirst::DEFAULT_THIRST
  end
 
  # )------------------------------------(
  # )--  New Method: get_thirst_level  --(
  # )------------------------------------(
  def get_thirst_level
    MrTS::Thirst::LEVELS.each do |val, txt|
      if @thirst >= val
        return txt
      end
    end
    return ""
  end
 
  # )-------------------------------(
  # )--  New Method: lose_thirst  --(
  # )-------------------------------(
  def lose_thirst
    if @thirst >= 1
      @thirst -= 1
    elsif @thirst <= 0
      self.hp -= MrTS::Thirst::THIRST_DAMAGE
    end
  end
 
  # )----------------------------(
  # )--  Alias to: item_apply  --(
  # )----------------------------(
  alias mrts_item_apply item_apply
  def item_apply(user, item)
    mrts_item_apply(user, item)
    item.note[/<[q-qQ-Q]uench:\s*(-*\d*)>/]
    if $1
      self.thirst += $1.to_i
      self.thirst = 100 if self.thirst > 100
      self.thirst = 0 if self.thirst < 0
    end
  end
 
  # )-----------------------------------(
  # )--  Overwrite Method: item_test  --(
  # )-----------------------------------(
  def item_test(user, item)
    item.note[/<[q-qQ-Q]uench:\s*(-*\d*)>/]
 
    return false if item.for_dead_friend? != dead?
    return true if $game_party.in_battle
    return true if item.for_opponent?
    return true if item.damage.recover? && item.damage.to_hp? && hp < mhp
    return true if item.damage.recover? && item.damage.to_mp? && mp < mmp
    return true if item_has_any_valid_effects?(user, item)
    return true if $1
   
    return false
  end
 
end
 
# )----------------------------------------------------(
# )--  Class: Window_MenuStatus < Window_Selectable  --(
# )----------------------------------------------------(
class Window_MenuStatus < Window_Selectable
 
  # )-----------------------------------(
  # )--  Overwrite Method: draw_item  --(
  # )-----------------------------------(
  def draw_item(index)
    actor = $game_party.members[index]
    enabled = $game_party.battle_members.include?(actor)
    rect = item_rect(index)
    rect.y -= line_height/2
    draw_item_background(index)
    draw_actor_face(actor, rect.x + 1, rect.y + 1 + line_height/2, enabled)
    draw_actor_simple_status(actor, rect.x + 108, rect.y + line_height / 2)
    draw_thirst_gauge(actor, rect.x + 108 + 120, rect.y + line_height * 3 + line_height/2)
  end
end
 
# )--------------------------(
# )--  Class: Window_Base  --(
# )--------------------------(
class Window_Base
 
  # )-------------------------------------(
  # )--  New Method: draw_thirst_gauge  --(
  # )-------------------------------------(
  def draw_thirst_gauge(actor, x, y, width=124, height=line_height)
    draw_gauge(x, y, width, actor.thirst.to_f/100.0, text_color(16), text_color(23) )
    draw_text(x, y, width, line_height, actor.get_thirst_level)
  end
end
 
# )-------------------------------------------(
# )--  Class: Game_Player < Game_Character  --(
# )-------------------------------------------(
class Game_Player < Game_Character
 
  # )--------------------------------(
  # )--  Alias to: increase_steps  --(
  # )--------------------------------(
  alias mrts_gp_increase_steps increase_steps
  def increase_steps
    mrts_gp_increase_steps
    if $game_party.steps % MrTS::Thirst::LOSE_THIRST_PER == 0
      $game_party.all_members.each { |actor| actor.lose_thirst }
    end
  end
end