# )----------------------------------------------------------------------------(
# )--     AUTHOR:     Mr Trivel                                              --(
# )--     NAME:       Level Up Restore                                       --(
# )--     CREATED:    2014-06-17                                             --(
# )--     VERSION:    1.0                                                    --(
# )----------------------------------------------------------------------------(
# )--                          DESCRIPTION                                   --(
# )--                  Restores HP & MP on level up.                         --(
# )----------------------------------------------------------------------------(
# )--                          INSTRUCTIONS                                  --(
# )--          Plug & Play, or set values to you liking.                     --(
# )----------------------------------------------------------------------------(
# )--                          LICENSE INFO                                  --(
# )--  http://mrtrivelvx.wordpress.com/terms-of-use/                         --(
# )----------------------------------------------------------------------------(

module MrTS
  module Level_Up
    Restore_HP = 100 #100 - restore HP by 100%
    Restore_MP = 100 #100 - restore MP by 100%
  end
end

class Game_Actor < Game_Battler
  
  alias mrts_level_up level_up
  def level_up
    mrts_level_up
    @hp += (mhp * (MrTS::Level_Up::Restore_HP/100.0)).to_i
    @mp += (mmp * (MrTS::Level_Up::Restore_MP/100.0)).to_i
  end
end