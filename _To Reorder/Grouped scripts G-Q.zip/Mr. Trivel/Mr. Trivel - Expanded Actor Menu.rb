# )--------------------------------------------------(
# )--     Author:     Mr Trivel                    --(
# )--     Name:       Expanded Actor Menu          --(
# )--     Created:    2014-06-06                   --(
# )--     Version:    1.12a                        --(
# )--------------------------------------------------(
# )--     Requires:   None                         --(
# )--------------------------------------------------(
# )--             Description                      --(
# )--  Sets up status window so it displays only   --(
# )--  a single actor data. Browse through other   --(
# )--  actors by using LEFT and RIGHT buttons.     --(
# )--------------------------------------------------(
# )--             Instructions                     --(
# )--             Plug & Play                      --(
# )--------------------------------------------------(
# )--             LICENSE INFO                     --(
# )--http://mrtrivelvx.wordpress.com/terms-of-use/ --(
# )--------------------------------------------------(

module MrTS
  module Vocab
    
    # )--------------------------------------------------(
    # )--  Ex-parameter names, feel free to customize  --(
    # )--  Ex-params of index 3, 7, 8 & 9 are not drawn--(
    # )--------------------------------------------------(
    XPARAMS = [ "Hit", 
                "Evasion", 
                "Critical", 
                "CEV", #not drawn by default
                "Mag Evasion", 
                "Mag Reflect", 
                "Counter", 
                "HRG", #not drawn by default
                "MRG", #not drawn by default
                "TRG" ]#not drawn by default
  end
  module Data
    # )---------------------------------------------(
    # )--  Ex-parameter indexes that are ignored  --(
    # )---------------------------------------------(
    # )--  WARNING: If you have less than 4, it   --(
    # )--  will draw them over equipment.         --(
    # )---------------------------------------------(
    IGNORE = [3, 7, 8, 9]
  end
end

$imported = {} if $imported.nil?
$imported["MrTS_Expanded_Actor_Menu"] = true


#)-------------------------(
#)--  Class: Scene_Menu  --(
#)-------------------------(
class Scene_Menu < Scene_MenuBase
  
  # )--------------------------------(
  # )--  Overwrite Method: update  --(
  # )--------------------------------(
  def update
    super
    
    if Input.trigger?(:RIGHT)
      
      if !@in_item_menu
        next_actor
        set_actor_all_a
      end
      
    elsif Input.trigger?(:LEFT) 
      
      if !@in_item_menu
        prev_actor
        set_actor_all_a
      end
      
    end
  end
  
  # )-----------------------------------(
  # )--  New Method: set_actor_all_a  --(
  # )-----------------------------------(  
  def set_actor_all_a
    @equipment_window.actor = $game_party.menu_actor
    @status_window.actor = $game_party.menu_actor
    @item_list_window.actor = $game_party.menu_actor
  end
  
  # )---------------------------------------(
  # )--  Alias To: create_command_window  --(
  # )---------------------------------------(
  alias mrts_sm_start start
  def start
    mrts_sm_start
    create_equipment_window
    create_item_list_window
    @in_item_menu = false
    set_actor_all_a
  end
  
  # )-------------------------------------------(
  # )--  New Method: create_item_list_window  --(
  # )-------------------------------------------(
  def create_item_list_window
    @item_list_window = MrTS_Status_Item_List.new(@command_window.width)
    @item_list_window.openness = 0
    @item_list_window.status_window = @status_window
    @item_list_window.set_handler(:ok,       method(:ok_item))
    @item_list_window.set_handler(:cancel,   method(:back_item))
  end
  
  # )---------------------------(
  # )--  New Method: ok_item  --(
  # )---------------------------(
  def ok_item
    Sound.play_equip
    @actor.change_equip(@equipment_window.index, @item_list_window.item)
    @equipment_window.activate
    @equipment_window.refresh
    @item_list_window.close
    @item_list_window.unselect
    @status_window.refresh
    @status_window.set_temp_actor(nil)
    @in_item_menu = false
  end
  
  # )-----------------------------(
  # )--  New Method: back_item  --(
  # )-----------------------------(
  def back_item
    @equipment_window.activate
    @item_list_window.close
    @in_item_menu = false
  end
  
  # )-------------------------------------------(
  # )--  New Method: create_equipment_window  --(
  # )-------------------------------------------(
  def create_equipment_window
    @equipment_window = MrTS_Equipment_Window.new(@command_window.width)
    @equipment_window.status_window = @status_window
    @equipment_window.opacity = 0
    @equipment_window.set_handler(:ok,        method(:ok_equip))
    @equipment_window.set_handler(:cancel,    method(:back_equip))
  end
  
  # )----------------------------(
  # )--  New Method: ok_equip  --(
  # )----------------------------(
  def ok_equip
    index = @equipment_window.index
    if @actor.equip_change_ok?(index)
      @item_list_window.slot_id = index
      @item_list_window.refresh
      @item_list_window.open
      @item_list_window.activate
      @item_list_window.select(0)
      @in_item_menu = true
    else
      Sound.play_buzzer
      @equipment_window.activate
    end
  end
  
  # )------------------------------(
  # )--  New Method: back_equip  --(
  # )------------------------------(
  def back_equip
    @command_window.activate
    @equipment_window.unselect
  end
  
  # )-----------------------------------------------(
  # )--  Overwrite Method: create_command_window  --(
  # )-----------------------------------------------(
  def create_command_window
    @command_window = Window_MenuCommand.new
    @command_window.set_handler(:item,      method(:command_item))
    @command_window.set_handler(:skill,     method(:command_skill))
    @command_window.set_handler(:equip,     method(:command_equip))
    @command_window.set_handler(:save,      method(:command_save))
    @command_window.set_handler(:game_end,  method(:command_game_end))
    @command_window.set_handler(:cancel,    method(:return_scene))
  end
  
  # )---------------------------------(
  # )--  New Method: command_skill  --(
  # )---------------------------------(
  def command_skill
    SceneManager.call(Scene_Skill)
  end
  
  # )---------------------------------(
  # )--  New Method: command_equip  --(
  # )---------------------------------(
  def command_equip
    @equipment_window.activate
    @equipment_window.select(0)
  end
  
  # )----------------------------------------------(
  # )--  Overwrite Method: create_status_window  --(
  # )----------------------------------------------(
  def create_status_window
    @status_window = MrTS_Window_Solo_Status.new(@command_window.width, 0)
  end
end


#)------------------------------------(
#)--  Class: MrTS_Status_Item_List  --(
#)------------------------------------(
class MrTS_Status_Item_List < Window_EquipItem
  
  attr_reader :status_window
  
  # )--------------------------(
  # )--  Method: initialize  --(
  # )--------------------------(
  def initialize(width)
    super(width, 96 + line_height*7, Graphics.width-width, fitting_height(5))
    @actor = $game_party.leader
    @slot_id = 0
    @status_window = status_window
    refresh
  end
  
  # )------------------------------(
  # )--  Method: status_window=  --(
  # )------------------------------(
  def status_window=(status_window)
    @status_window = status_window
  end
  
  # )-----------------------(
  # )--  Method: col_max  --(
  # )-----------------------(
  def col_max
    return 1
  end
  
  # )--------------------------------(
  # )--  Method: call_update_help  --(
  # )--------------------------------(
  def call_update_help
    update_help
  end
  
  # )---------------------------(
  # )--  Method: update_help  --(
  # )---------------------------(
  def update_help
    if @actor && @status_window
      temp_actor = Marshal.load(Marshal.dump(@actor))
      temp_actor.force_change_equip(@slot_id, item)
      status_window.set_temp_actor(temp_actor)
    end
  end
  

end


#)------------------------------------(
#)--  Class: MrTS_Equipment_Window  --(
#)------------------------------------(
class MrTS_Equipment_Window < Window_EquipSlot
  
  attr_reader :status_window
  
  # )------------------------------------(
  # )--  Overwrite Method: initialize  --(
  # )------------------------------------(
  def initialize(x)
    super(x, 96 + line_height*7, Graphics.width-160)
    @actor = $game_party.leader
    create_contents
    refresh
  end
  
  # )------------------------------------------(
  # )--  Overwrite Method: call_update_help  --(
  # )------------------------------------------(
  def call_update_help
    update_help
  end
  
  # )-------------------------------------(
  # )--  Overwrite Method: update_help  --(
  # )-------------------------------------(
  def update_help
    status_window.set_temp_actor(nil) if @status_window
  end
end


#)--------------------------------------(
#)--  Class: MrTS_Window_Solo_Status  --(
#)--------------------------------------(
class MrTS_Window_Solo_Status < Window_Base
  
  # )--------------------------(
  # )--  Method: initialize  --(
  # )--------------------------(
  def initialize(x, y)
    super(x, y, window_width, window_height)
    @pending_index = -1
    @temp_actor = nil
    @actor = $game_party.leader
    refresh
  end
  
  # )----------------------------(
  # )--  Method: window_width  --(
  # )----------------------------(
  def window_width
    Graphics.width - 160
  end
  
  # )-----------------------------(
  # )--  Method: window_height  --(
  # )-----------------------------(
  def window_height
    Graphics.height
  end
  
  # )--------------------------------(
  # )--  Method: draw_actor_param  --(
  # )--------------------------------(
  def draw_actor_param(actor, x, y, param_id, color = normal_color)
    change_color(system_color)
    draw_text(x, y, 120, line_height, Vocab::param(param_id))
    change_color(color)
    draw_text(x + 120, y, 36, line_height, actor.param(param_id), 2)
    change_color(normal_color)
  end
  
  # )-----------------------------(
  # )--  Method: draw_actor_hp  --(
  # )-----------------------------(
  def draw_actor_hp(actor, x, y, width = 124, color = normal_color)
    draw_gauge(x, y, width, actor.hp_rate, hp_gauge_color1, hp_gauge_color2)
    change_color(system_color)
    draw_text(x, y, 30, line_height, Vocab::hp_a)
    draw_current_and_max_values(x, y, width, actor.hp, actor.mhp,
      hp_color(actor), color)
    end
    
  # )-----------------------------(
  # )--  Method: draw_actor_mp  --(
  # )-----------------------------(
  def draw_actor_mp(actor, x, y, width = 124, color = normal_color)
    draw_gauge(x, y, width, actor.mp_rate, mp_gauge_color1, mp_gauge_color2)
    change_color(system_color)
    draw_text(x, y, 30, line_height, Vocab::mp_a)
    draw_current_and_max_values(x, y, width, actor.mp, actor.mmp,
      mp_color(actor), color)
  end
  
  # )-----------------------(
  # )--  Method: refresh  --(
  # )-----------------------(
  def refresh
    contents.clear
    create_contents
    
    temp_color = normal_color
    
    draw_actor_face(@actor, 0, 0)
    draw_actor_level(@actor, 96, 0)
    draw_actor_name(@actor, 96, line_height)
    draw_actor_class(@actor, 96, line_height*2)
    if !$imported["MrTS_Thirst"]
      draw_actor_xp(@actor, contents.width-160, line_height*2, 160)
    elsif $imported["MrTS_Thirst"]
      draw_thirst_gauge(@actor, contents.width-160, line_height*2, 160)
    end    
    
    if @temp_actor == nil
      draw_actor_hp(@actor, contents.width-160, 0, 160)
      draw_actor_mp(@actor, contents.width-160, line_height, 160)
    else
      temp_color = param_change_color(@temp_actor.param(0)-@actor.param(0))
      draw_actor_hp(@temp_actor, contents.width-160, 0, 160, temp_color)
      
      temp_color = param_change_color(@temp_actor.param(1)-@actor.param(1))
      draw_actor_mp(@temp_actor, contents.width-160, line_height, 160, temp_color)
    end
    
    #params
    6.times do |i|
      contents.gradient_fill_rect(-3, 96+line_height*i, 159, line_height-10, text_color(15), text_color(19)) 
      dy = 96 + line_height * i
      
      if @temp_actor == nil
        draw_actor_param(@actor, 0, dy, i + 2)
      else
        temp_color = param_change_color(@temp_actor.param(i+2)-@actor.param(i+2))
        draw_actor_param(@temp_actor, 0, 96 + line_height * (i), i+2, temp_color)
      end
    end
    
    #xparams
    skipped = 0
    ignore = MrTS::Data::IGNORE #ignore these xparams
    10.times do |i|
      if !ignore.include?(i)
        if @temp_actor == nil
          draw_actor_xparam(@actor, contents.width-156, 96 + line_height * (i - skipped), i)
        else
          temp_color = param_change_color(@temp_actor.xparam(i)-@actor.xparam(i))
          draw_actor_xparam(@temp_actor, contents.width-156, 96 + line_height * (i - skipped), i, temp_color)
        end
        
      else
        skipped += 1
      end
    end
  end # of refresh
  
  # )---------------------------------(
  # )--  Method: draw_actor_xparam  --(
  # )---------------------------------(
  def draw_actor_xparam(actor, x, y, param_id, color = normal_color)
    contents.gradient_fill_rect(x-3, y, 159, line_height-10, text_color(15), text_color(19))
    change_color(system_color)
    draw_text(x, y, 120, line_height, MrTS::Vocab::XPARAMS[param_id])
    change_color(color)
    draw_text(x + 120 - 36, y, 72, line_height, (actor.xparam(param_id)*100).to_i.to_s + "%", 2)
  end
  
  # )-----------------------------(
  # )--  Method: draw_actor_xp  --(
  # )-----------------------------(
  def draw_actor_xp(actor, x, y, width = 124)
    float = 1.0 * (actor.exp - actor.current_level_exp) / (actor.next_level_exp - actor.current_level_exp)
    draw_gauge(x, y, width, float, text_color(28), text_color(29))
    change_color(system_color)
    draw_text(x, y, 30, line_height, "EXP")
    change_color(normal_color)
    draw_text(x + width - 140, y, (140-12)/2, line_height, actor.exp - actor.current_level_exp, 2)
    draw_text(x+ width - 140/2, y, 12, line_height, "/", 2)
    draw_text(x+ width - (140-12)/2, y, (140-12)/2, line_height, actor.next_level_exp - actor.current_level_exp, 2)
  end
  
  # )------------------------------(
  # )--  Method: set_temp_actor  --(
  # )------------------------------(
  def set_temp_actor(temp_actor)
    return if @temp_actor == temp_actor
    @temp_actor = temp_actor
    refresh
  end
  
  # )----------------------(
  # )--  Method: actor=  --(
  # )----------------------(
  def actor=(actor)
    return if @actor == actor
    @actor = actor
    refresh
  end
  
end

  
# )---------------------------------(
# )--  Class: Window_MenuCommand  --(
# )---------------------------------(
class Window_MenuCommand < Window_Command
  
  # )-------------------------------------------(
  # )--  Overwrite Method: make_command_list  --(
  # )-------------------------------------------(
  def make_command_list
    add_main_commands
    add_original_commands
    add_save_command
    add_game_end_command
  end
  
  # )-------------------------------------------(
  # )--  Overwrite Method: add_main_commands  --(
  # )-------------------------------------------(
  def add_main_commands
    add_command(Vocab::item,   :item,   main_commands_enabled)
    add_command(Vocab::skill,  :skill,  main_commands_enabled)
    add_command(Vocab::equip,  :equip,  main_commands_enabled)
  end
end