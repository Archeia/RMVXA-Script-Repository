# )----------------------------------------------------------------------------(
# )--     AUTHOR:     Mr Trivel                                              --(
# )--     NAME:       Static Exp                                             --(
# )--     CREATED:    2014-06-11                                             --(
# )--     VERSION:    1.1a                                                   --(
# )----------------------------------------------------------------------------(
# )--                         VERSION HISTORY                                --(
# )--  1.1a - Reserve Members now properly gain XP if specified.             --(
# )--  1.1  - Fixed Overflow XP bug and a crash if party had atleast 1       --(
# )--  inactive party member.                                                --(
# )----------------------------------------------------------------------------(
# )--                          DESCRIPTION                                   --(
# )--  Every level will require same amount of XP. But enemies lower level   --(
# )--  than actor will give less XP and higher level enemies will give more  --(
# )--  XP.                                                                   --(
# )----------------------------------------------------------------------------(
# )--                          INSTRUCTIONS                                  --(
# )--  EXP box in Enemy Database now denotes the Enemies level.              --(
# )--  E.g.: An enemy with with EXP set to 3 will be used as a level 3 enemy.--(
# )----------------------------------------------------------------------------(
# )--                          LICENSE INFO                                  --(
# )--    Free for non-commercial games if credit was given to Mr Trivel.     --(
# )----------------------------------------------------------------------------(
 
module MrTS
  module Static_Exp
    # )-----------------------------------------(
    # )--  How much XP per level actor needs  --(
    # )-----------------------------------------(
    NEXT_LEVEL_XP = 200
   
    # )-------------------------------------------(
    # )--  Does XP overflow to the next level?  --(
    # )--  E.g. If true and Actor is at 95 XP   --(
    # )--  and it gets 10XP, he will level up   --(
    # )--  and he will have 5 XP ready. If false--(
    # )--  he will have 0 XP after level up.    --(
    # )-------------------------------------------(
    OVERFLOW_XP = true
   
    # )---------------------------------(
    # )--  Base amout of XP rewarded  --(
    # )---------------------------------(
    XP_REWARDED = 15
   
    # )--------------------------------------------------------------(
    # )--  XP Bonus for killing higher level enemy per it's level  --(
    # )--------------------------------------------------------------(
    XP_BONUS = 7
   
    # )------------------------------------------------------------(
    # )--  XP Loss for killing lower level enemy per it's level  --(
    # )------------------------------------------------------------(
    XP_LOSS = 3
  end
 
  module Vocab
    # )----------------------(
    # )--  XP Get message  --(
    # )----------------------(
    OBTAIN_EXP  = "%s has received %s EXP!" # actor name, total xp gotten
  end
end
 
# )------------------------(
# )--  Class: Game_Actor --(
# )------------------------(
class Game_Actor < Game_Battler
 
  # )---------------------------------------(
  # )--  Overwrite Method: exp_for_level  --(
  # )---------------------------------------(
  def exp_for_level(level)
    0
  end
  # )----------------------------------------(
  # )--  Overwrite Method: next_level_exp  --(
  # )----------------------------------------(
  def next_level_exp
    MrTS::Static_Exp::NEXT_LEVEL_XP
  end
  # )----------------------------------(
  # )--  Overwrite Method: level_up  --(
  # )----------------------------------(
  def level_up
    @level += 1
    @exp[@class_id] = MrTS::Static_Exp::OVERFLOW_XP ? @exp[class_id]-MrTS::Static_Exp::NEXT_LEVEL_XP : 0
    self.class.learnings.each do |learning|
      learn_skill(learning.skill_id) if learning.level == @level
    end
  end
end
 
# )------------------------(
# )--  Class: Game_Troop --(
# )------------------------(
class Game_Troop < Game_Unit
  # )-----------------------------------(
  # )--  Overwrite Method: exp_total  --(
  # )-----------------------------------(
  def exp_total
    party_exp = []
    loop = 0
    $game_party.all_members.each do
      party_exp[loop] = dead_members.inject(0) do |totalxp, enemy|
        xp_reward = MrTS::Static_Exp::XP_REWARDED
        xp_reward += MrTS::Static_Exp::XP_BONUS * (enemy.exp - $game_party.all_members[loop].level) if enemy.exp > $game_party.all_members[loop].level
        xp_reward -= MrTS::Static_Exp::XP_LOSS  * ($game_party.all_members[loop].level - enemy.exp) if enemy.exp < $game_party.all_members[loop].level
        xp_reward = 0 if xp_reward < 0
        totalxp += xp_reward
      end
      loop += 1
    end
    return party_exp
  end
end
 
 
module BattleManager
  # )----------------------------------(
  # )--  Overwrite Method: gain_exp  --(
  # )----------------------------------(
  def self.gain_exp
    i = 0
    $game_party.all_members.each do |actor|
      actor.gain_exp($game_troop.exp_total[i])
      i += 1
    end
    wait_for_message
  end
 
  # )-------------------------------------(
  # )--  Overwrite Method: display_exp  --(
  # )-------------------------------------(
  def self.display_exp
    if $game_troop.exp_total.size > 0
      i = 0
      $game_party.members.each do |member|
        if $game_troop.exp_total[i] > 0
          text = sprintf(MrTS::Vocab::OBTAIN_EXP, member.name, $game_troop.exp_total[i])
          $game_message.add('\.' + text)
        end
        i += 1
      end
    end
  end
end