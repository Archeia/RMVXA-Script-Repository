# )----------------------------------------------------------------------------(
# )--     AUTHOR:     Mr Trivel                                              --(
# )--     NAME:       Enemies Teach Skill on Death                           --(
# )--     CREATED:    2014-06-20                                             --(
# )--     VERSION:    1.0a                                                   --(
# )--     Idea by:    Trickstette                                            --(
# )----------------------------------------------------------------------------(
# )--                          DESCRIPTION                                   --(
# )--  Enemies have a chance to teach skills to your actors after the battle.--(
# )----------------------------------------------------------------------------(
# )--                          INSTRUCTIONS                                  --(
# )--  <OnDeathTeach: X, Y, [A, B, C]>                                       --(
# )--  Use this notetag for Enemy note tags.                                 --(
# )--  X - ID of the skill to teach                                          --(
# )--  Y - Chance of learning it (0.0 - 1.0, 0.0 - being 0% chance and 1.0   --(
# )--  being 100% chance to learn)                                           --(
# )--  [A, B, C] - E.g. [1, 5, 6, 8, 9] - which classes could learn it.      --(
# )----------------------------------------------------------------------------(
# )--                          LICENSE INFO                                  --(
# )--    http://mrtrivelvx.wordpress.com/terms-of-use/                       --(
# )----------------------------------------------------------------------------(
 
module MrTS
  module Skill_On_Kill
    # )------------------------------------------------------------------------(
    # )--  Should a dead member learn the skill?                             --(
    # )------------------------------------------------------------------------(
    TEACH_TO_DEAD_MEMBERS = false
    LEARNT_TEXT = "%s learned %s from enemy!"
  end
 
  # )--------------------------------------------------------------------------(
  # )--  No touching!                                                        --(
  # )--------------------------------------------------------------------------(
  module Regex
    REGEX_MAIN = /<ondeathteach:[ ]*(\d+),[ ]*(\d*\.*\d*),[ ]*\[*((\d*,*[ ]*)*)\]>/i
    REGEX_ARRAY = /(\d+)/
  end
end
# )----------------------------------------------------------------------------(
# )--  Module: BattleManager                                                 --(
# )----------------------------------------------------------------------------(
module BattleManager
  class << self ; alias mrts_process_victory process_victory ; end
  # )--------------------------------------------------------------------------(
  # )--  Overwrite Method: self.process_victory                              --(
  # )--------------------------------------------------------------------------(
  def self.process_victory
    mrts_process_victory
    gain_monster_skills
  end
 
  # )--------------------------------------------------------------------------(
  # )--  New Method: self.gain_monster_skills                                --(
  # )--------------------------------------------------------------------------(
  def self.gain_monster_skills
    $game_troop.dead_members.each do |dm|
      dm.enemy.note[MrTS::Regex::REGEX_MAIN]
      temp_class_list = nil
      temp_skill_id = nil
      temp_chance = 0.0
      if $1
        temp_class_list = []
        temp_skill_id = $1.to_i
        temp_chance = $2.to_f
        $3.scan(MrTS::Regex::REGEX_ARRAY).collect { |ele| temp_class_list.push(ele[0].to_i) }
      end
      actor_array = MrTS::Skill_On_Kill::TEACH_TO_DEAD_MEMBERS ? $game_party.battle_members : $game_party.alive_members
      actor_array.each do |ac|
        if rand < temp_chance && temp_class_list.include?(ac.class_id)
          $game_message.add(sprintf(MrTS::Skill_On_Kill::LEARNT_TEXT, ac.name, $data_skills[temp_skill_id].name)) if !ac.skills.include?($data_skills[temp_skill_id])
          ac.learn_skill(temp_skill_id)
        end
      end if temp_class_list.size > 0
    end
    wait_for_message
  end
end