# )----------------------------------------------------------------------------(
# )--     AUTHOR:     Mr Trivel                                              --(
# )--     NAME:       Hurt Sounds                                            --(
# )--     CREATED:    2014-06-30                                             --(
# )--     VERSION:    1.1                                                    --(
# )--     Request by: Rimaka                                                 --(
# )----------------------------------------------------------------------------(
# )--                         VERSION HISTORY                                --(
# )--  1.0 - Initial scream.                                                 --(
# )--  1.1 - No more screaming on healing.                                   --(
# )----------------------------------------------------------------------------(
# )--                          DESCRIPTION                                   --(
# )--  Enemies and actors will play Sound Effect when getting hit.           --(
# )----------------------------------------------------------------------------(
# )--                          INSTRUCTIONS                                  --(
# )--  Add <Hurt: SE_name, volume, pitch> to your Actor or Enemy note box.   --(
# )--  Example: <Hurt: Bite, 100, 100>                                       --(
# )----------------------------------------------------------------------------(
# )--                          LICENSE INFO                                  --(
# )--   Free for commercial and non-commercial games as long as credit is    --(
# )--   given to Mr. Trivel.                                                 --(
# )----------------------------------------------------------------------------(
 
# )----------------------------------------------------------------------------(
# )--  Class: Game_Battler                                                   --(
# )----------------------------------------------------------------------------(
class Game_Battler < Game_BattlerBase
  alias :mrts_hurt_execute_damage :execute_damage
 
  # )--------------------------------------------------------------------------(
  # )--  Alias Method: execute_damage                                        --(
  # )--------------------------------------------------------------------------(
  def execute_damage(user)
    mrts_hurt_execute_damage(user)
    return unless @hurt_sound && @result.hp_damage > 0
    Audio.se_play(@hurt_sound[0], @hurt_sound[1], @hurt_sound[2])
  end
end
 
# )----------------------------------------------------------------------------(
# )--  Class: Game_Actor                                                     --(
# )----------------------------------------------------------------------------(
class Game_Actor < Game_Battler
  alias :mrts_hurt_setup :setup
 
  # )--------------------------------------------------------------------------(
  # )--  Alias Method: setup                                                 --(
  # )--------------------------------------------------------------------------(
  def setup(actor_id)
    mrts_hurt_setup(actor_id)
    actor.note[/<Hurt:[ ]*(\w*),[ ]*(\d*),[ ]*(\d+)>/i]
    $1 ? @hurt_sound = ["Audio/SE/"+$1, $2.to_i, $3.to_i] : @hurt_sound = nil
  end
end
 
# )----------------------------------------------------------------------------(
# )--  Class: Game_Enemy                                                     --(
# )----------------------------------------------------------------------------(
class Game_Enemy < Game_Battler
  alias :mrts_hurt_initialize :initialize
 
  # )--------------------------------------------------------------------------(
  # )--  Alias Method: initialize                                            --(
  # )--------------------------------------------------------------------------(
  def initialize(index, enemy_id)
    mrts_hurt_initialize(index, enemy_id)
    enemy.note[/<Hurt:[ ]*(\w*),[ ]*(\d*),[ ]*(\d+)>/i]
    $1 ? @hurt_sound = ["Audio/SE/"+$1, $2.to_i, $3.to_i] : @hurt_sound = nil
  end
end