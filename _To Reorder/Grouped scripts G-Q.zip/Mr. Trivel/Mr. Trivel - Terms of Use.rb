Terms of Use

All the scripts that are on my blog are free to use for non-commercial games as long as credit is given to me – Mr. Trivel.

All the scripts that are on my blog are also free to use for commercial use as long as credit is given to me and I’m informed by e-mail or private message on the forums that you’re using it. A free copy after the game is finished would be nice, too.

You’re free to edit the scripts as long as credit is properly given.

Don’t copy paste my scripts all over the internet. Link them to my forum posts/scripts on site