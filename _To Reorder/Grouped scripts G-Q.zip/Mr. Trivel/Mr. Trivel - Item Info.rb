# )-------------------------------------------(
# )--     Author:     Mr Trivel             --(
# )--     Name:       Item Info             --(
# )--     Created:    2014-06-05            --(
# )--     Version:    1.01                  --(
# )-------------------------------------------(
# )--     Requires:   None                  --(
# )-------------------------------------------(
# )--             Description               --(
# )-- This script expands Item List in the  --(
# )-- Item Menu, giving it a bigger         --(
# )-- description window that shows more    --(
# )-- data, like attack type, value,        --(
# )-- immunity, buffs, debuffs, etc...      --(
# )-------------------------------------------(
# )--             Instructions              --(
# )--Plug & Play or Plug -> Customize & Play--(
# )---------------------------------------------------(
# )--             LICENSE INFO                      --(
# )-- http://mrtrivelvx.wordpress.com/terms-of-use/ --(
# )---------------------------------------------------(
# )-- Version history:                      --(
# )-- v1.01 - Added indicators who can equip--(
# )-- the armor/weapon.                     --(
# )-------------------------------------------(

module MrTS
  module MrTS_Item_Info
    
    # )-------------------------------------(
    # )-- Hashes (leave this)             --(
    # )-------------------------------------(
    Icon_list = {}
    Text_list = {}
    Element_list = {}
    
    # )-------------------------------------(
    # )--     Customize stat names here   --(
    # )-------------------------------------(
    # )--     Parameters                  --(
    # )-------------------------------------(
    STATS = [ "MHP: ", 
              "MMP: ", 
              "ATK: ", 
              "DEF: ", 
              "MAT: ", 
              "MDF: ", 
              "AGI: ", 
              "LUK: " ]
              
    # )-------------------------------------(
    # )--      Ex-Parameters              --(
    # )-------------------------------------(    
    XSTATS = [ "HIT: ",
               "EVA: ",
               "CRI: ",
               "CEV: ",
               "MEV: ",
               "MRF: ",
               "CNT: ",
               "HRG: ",
               "MRG: ",
               "TRG: " ]
    
    # )-------------------------------------(
    # )-- Number of colums for items      --(
    # )-------------------------------------(
    COLUMNS = 3
    
    # )-------------------------------------(
    # )--Icon list - Change to your liking--(
    # )-------------------------------------(
    Icon_list[11] = 112 # Health Recovery
    Icon_list[12] = 121 # Mana Recovery
    Icon_list[13] = 117 # TP Recovery
    
    Icon_list[41] = 12 # Special action: Escape
    
    # )-------------------------------------(
    # )--        Buffs                    --(
    # )-------------------------------------(
    Icon_list["310"] = 32 # MHP Up
    Icon_list["311"] = 33 # MMP Up
    Icon_list["312"] = 34 # ATK Up
    Icon_list["313"] = 35 # DEF Up
    Icon_list["314"] = 36 # MAT Up
    Icon_list["315"] = 37 # MDF Up
    Icon_list["316"] = 38 # AGI Up
    Icon_list["317"] = 39 # LUK Up
    
    # )-------------------------------------(
    # )--        Debuffs                  --(
    # )-------------------------------------(
    Icon_list["320"] = 48 # MHP Down
    Icon_list["321"] = 49 # MMP Down
    Icon_list["322"] = 50 # ATK Down
    Icon_list["323"] = 51 # DEF Down
    Icon_list["324"] = 52 # MAT Down
    Icon_list["325"] = 53 # MDF Down
    Icon_list["326"] = 54 # AGI Down
    Icon_list["327"] = 55 # LUK Down
    
    
    # )-------------------------------------(
    # )--        Text strings             --(
    # )-------------------------------------(
    Text_list[0] = "to apply"
    Text_list[1] = "removal"
    Text_list[2] = " turns"
    Text_list[3] = "Cleanse"
    Text_list[4] = "Escape"
    Text_list[5] = "grow by"
    Text_list[6] = "Learn skill"
    Text_list[7] = "rate"
    Text_list[8] = "Immunity"
    
    # )----------------------------------------------------(
    # )--        Element list                            --(
    # )--  Make sure it has all icons for your elements! --(
    # )----------------------------------------------------(
    Element_list[1] = 143
    Element_list[2] = 120
    Element_list[3] = 96
    Element_list[4] = 97
    Element_list[5] = 98
    Element_list[6] = 99
    Element_list[7] = 100
    Element_list[8] = 101
    Element_list[9] = 102
    Element_list[10] = 103
  end
end


# )------------------------------------------(
# )--  Class: MrTS_Window_Description      --(
# )------------------------------------------(

class MrTS_Window_Description < Window_Base
  include MrTS
  
  # )-------------------------------------(
  # )--  Method: initialize             --(
  # )-------------------------------------(
  def initialize (x, y, width, height)
    super(x, y, width, height)
    @name_offset = 32;
    @currency_unit = Vocab::currency_unit
  end
  
  # )-------------------------------------(
  # )--  Method: set_item(item)         --(
  # )-------------------------------------(
  def set_item (newitem)
    @item = newitem
    if @item
      draw_info
    end
  end
  
  # )-------------------------------------(
  # )-- Method: get_item, returns @item --(
  # )-------------------------------------(  
  def get_item
    return @item
  end
  
  # )-------------------------------------(
  # )--  Method: draw_info              --(
  # )-------------------------------------(
  def draw_info()
    contents.clear
    # Line 1
      # Item name
      draw_item_name(@item, @name_offset, 0)
      change_color(normal_color)
      
      # Value
      txt_value = "Value"
      if (@item.is_a?(RPG::Item) && !@item.key_item?) || @item.is_a?(RPG::Weapon) || @item.is_a?(RPG::Armor)
        draw_text_ex(@name_offset + 176 + 40, 0, "Value -")
        draw_currency_value(@item.price, @currency_unit, 
                            @name_offset + 156 + 20 + text_size(txt_value).width, 
                            0, 160)
      end
                          
    # Line 2&3
      #Description
      draw_text_ex(0, line_height, @item.description)
      
    # Line 4-Last
    if @item.is_a?(RPG::Item)  
      effect_num = 0
      
      @item.effects.each do |eff|
        # Draw X
        dx = (contents.width/MrTS::MrTS_Item_Info::COLUMNS) * (effect_num%MrTS::MrTS_Item_Info::COLUMNS)
        
        # Draw Y
        dy = line_height*(3 + effect_num/MrTS::MrTS_Item_Info::COLUMNS)
        
        # Values of effects
        value1 = eff.value1
        value2 = eff.value2
        
        # Draw effect icon
        if MrTS_Item_Info::Icon_list[eff.code]
          draw_icon(MrTS_Item_Info::Icon_list[eff.code], dx, dy)
        elsif eff.code == 21 || eff.code == 22
          draw_icon($data_states[eff.data_id].icon_index, dx, dy)
        elsif eff.code == 31 || eff.code == 32
          draw_icon(MrTS_Item_Info::Icon_list[eff.code.to_s + eff.data_id.to_s], dx, dy)
        elsif eff.code == 33 || eff.code == 34
          draw_icon(MrTS_Item_Info::Icon_list[(eff.code-2).to_s + eff.data_id.to_s], dx, dy)
        elsif eff.code == 42
          draw_icon(MrTS_Item_Info::Icon_list[(eff.code-11).to_s + eff.data_id.to_s], dx, dy)
        elsif eff.code == 43
          draw_icon($data_skills[eff.data_id].icon_index, dx, dy)
        elsif eff.code == 44 # common event skip it
          effect_num -= 1
        else # Draw default
          draw_icon(1, dx, dy)
        end
        
        if eff.code == 11 || eff.code == 12 || eff.code == 21 || eff.code == 22
          value1 *= 100
        end
        
        value1_sign = value1 >= 0 ? "+" : ""
        value2_sign = value2 >= 0 ? "+" : ""
        value1_text = ""
        value2_text = ""
        
        if eff.code == 11 || eff.code == 12
          value1_text = value1 != 0 ? value1_sign + value1.to_i.to_s + "%" : ""
          value2_text = value2 != 0 ? value2_sign + value2.to_i.to_s : ""
        elsif eff.code == 21 || eff.code == 22
          value1_text = value1.to_i.to_s + "%"
          value2_text = eff.code == 21 ? MrTS::MrTS_Item_Info::Text_list[0] : MrTS::MrTS_Item_Info::Text_list[1] 
        elsif eff.code == 31 || eff.code == 32
          value1_text = "for " + value1.to_i.to_s + MrTS::MrTS_Item_Info::Text_list[2] 
        elsif eff.code == 33 || eff.code == 34
          value1_text = MrTS::MrTS_Item_Info::Text_list[3] 
        elsif eff.code == 41
          value1_text = MrTS::MrTS_Item_Info::Text_list[4] 
        elsif eff.code == 42
          value1_text = MrTS::MrTS_Item_Info::Text_list[5] 
          value2_text = value1.to_i.to_s
        elsif eff.code == 43
          value1_text = MrTS::MrTS_Item_Info::Text_list[6] 
        end        
        
        draw_text_ex(dx+32, dy, value1_text + " " + value2_text)
        
        effect_num += 1
      end
    elsif @item.is_a?(RPG::Weapon) || @item.is_a?(RPG::Armor)
      
      row = 0
      
      #Check if party can equip
      $game_party.members.each do |memb|
        dx = 0 + row*32
        dy = line_height*8
        if memb.equippable?(@item)
          draw_character(memb.character_name, memb.character_index, dx+16, dy+32)
        else
          row -= 1
        end
        
        row += 1
        
      end
      
      
      row = 0
      @item.params.each do |param|
        dx = row%2 * contents.width/4
        dy = line_height*4 + row/2*line_height
        change_color(param > 0 ? text_color(3) : param == 0 ? normal_color : text_color(18))
        draw_text(dx, dy, contents.width/4, line_height, MrTS::MrTS_Item_Info::STATS[row] + param.to_s)
        change_color(normal_color)
        row += 1
      end
      
      row = 0
      elem = 0

      @item.features.each do |feat|
        dx = row%2 * contents.width/4 + contents.width/4*2
        dy = line_height*4 + row/2*line_height
        
        value1 = feat.value
        
        if feat.code == 11
          draw_icon(MrTS_Item_Info::Element_list[feat.data_id], dx, dy)
          value1 *= 100
          change_color(value1 > 100 ? text_color(18) : value1 == 100 ? normal_color : text_color(3))
          draw_text(dx+32, dy, contents.width/4, line_height, value1.to_i.to_s + "% rate")
          change_color(normal_color)
        elsif feat.code == 12
          draw_icon(MrTS_Item_Info::Icon_list["32"+feat.data_id.to_s], dx, dy)
          value1 *= 100
          change_color(value1 > 100 ? text_color(18) : value1 == 100 ? normal_color : text_color(3))
          draw_text(dx+32, dy, contents.width/4, line_height, value1.to_i.to_s + "% rate")
          change_color(normal_color)
        elsif feat.code == 13
          draw_icon($data_states[feat.data_id].icon_index, dx, dy)
          value1 *= 100
          change_color(value1 > 100 ? text_color(18) : value1 == 100 ? normal_color : text_color(3))
          draw_text(dx+32, dy, contents.width/4, line_height, value1.to_i.to_s + "%  " + MrTS::MrTS_Item_Info::Text_list[7])
          change_color(normal_color)
        elsif feat.code == 14
          draw_icon($data_states[feat.data_id].icon_index, dx, dy)
          draw_text(dx+32, dy, contents.width/4, line_height, MrTS::MrTS_Item_Info::Text_list[8])
        elsif feat.code == 21
          value1 *= 100
          if value1 > 100 || value1 < 100
            draw_icon(value1 > 100 ? MrTS::MrTS_Item_Info::Icon_list["31" + feat.data_id.to_s] : MrTS::MrTS_Item_Info::Icon_list["32" + feat.data_id.to_s], dx, dy)
            change_color(value1 > 100 ? text_color(3) : text_color(18))
            value1 -= 100
            draw_text(dx+32, dy, contents.width/4, line_height, (value1 > 0 ? "+" : "") + value1.to_i.to_s + "%")
            change_color(normal_color)
          else
            row -= 1
          end
        elsif feat.code == 22
          value1 *= 100
          if value1 < 0 || value1 > 0
            change_color(value1 > 0 ? text_color(3) : text_color(18))
            draw_text(dx+32, dy, contents.width/4, line_height, MrTS::MrTS_Item_Info::XSTATS[feat.data_id] + " " + (value1 > 0 ? "+" : "") + value1.to_i.to_s + "%")
          else
            row -= 1
          end
        elsif feat.code == 31
          icon_i = MrTS_Item_Info::Element_list[feat.data_id] ? MrTS_Item_Info::Element_list[feat.data_id] : 1
          draw_icon(icon_i, 0 + elem*32, line_height*3)
          elem += 1
          row -= 1
        elsif feat.code == 32
          draw_icon($data_states[feat.data_id].icon_index, dx, dy)
          value1 *= 100
          draw_text(dx+30, dy, contents.width/4, line_height, "OnHit:" + value1.to_i.to_s + "%")
        end
        
        row += 1
        
      end #feats
    end #elsif
  end #def
  
end #class

# )-------------------------------------(
# )--  Class: Scene_Item              --(
# )-------------------------------------(
class Scene_Item < Scene_ItemBase
  
  # )-------------------------------------(
  # )--  Alias to: start                --(
  # )-------------------------------------(
  alias mrts_si_create_start start
  def start
    super
    create_category_window
    create_item_window
    create_description_window
    set_description_window
  end
  
  # )------------------------------------------(
  # )--  New method: set_description_window  --(
  # )------------------------------------------(
  def set_description_window
    @item_window.set_desc_window(@desc_window)
  end
  
  # )---------------------------------------------(
  # )--  New method: create_description_window  --(
  # )---------------------------------------------(
  def create_description_window
    wy = @category_window.y + @category_window.height
    wh = Graphics.height - wy - @item_window.height
    @desc_window = MrTS_Window_Description.new(0, wy, Graphics.width, wh)
    @desc_window.viewport = @viewport
  end
  
  # )-------------------------------------(
  # )--  Alias to: create_item_window   --(
  # )-------------------------------------(
  alias mrts_si_create_item_window create_item_window
  def create_item_window
    wh = 24*4 + 12*2
    wy = Graphics.height - wh
    @item_window = MrTS_Item_List.new(0, wy, Graphics.width, wh)
    @item_window.viewport = @viewport
    @item_window.set_handler(:ok,     method(:on_item_ok))
    @item_window.set_handler(:cancel, method(:on_item_cancel))
    @category_window.item_window = @item_window
  end
  
  # )----------------------------------------(
  # )--  Alias to: create_category_window  --(
  # )----------------------------------------(
  alias mrts_si_create_create_category_window create_category_window
  def create_category_window
    @category_window = Window_ItemCategory.new
    @category_window.viewport = @viewport
    @category_window.help_window = @help_window
    @category_window.y = 0
    @category_window.set_handler(:ok,     method(:on_category_ok))
    @category_window.set_handler(:cancel, method(:return_scene))
  end
  
end

# )-------------------------------------(
# )--  Class: MrTS_Item_List          --(
# )-------------------------------------(
class MrTS_Item_List < Window_ItemList
  
  # )-------------------------------------(
  # )--  Method: set_desc_window        --(
  # )-------------------------------------(
  def set_desc_window(new_desc)
    @desc_window = new_desc
  end
  
  # )-------------------------------------(
  # )--  Method: call_update_help       --(
  # )-------------------------------------(
  def call_update_help
    update_help if active && @desc_window
  end
  
  # )-------------------------------------(
  # )-- Method: update_help             --(
  # )-------------------------------------(
  def update_help
    @desc_window.set_item(item)
  end
  
  
end