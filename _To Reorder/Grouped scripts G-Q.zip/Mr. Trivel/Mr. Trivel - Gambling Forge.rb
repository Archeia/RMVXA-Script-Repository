# )--------------------------------------------------(
# )--     Author:     Mr Trivel                    --(
# )--     Name:       Gambler's Forge              --(
# )--     Created:    2014-06-05                   --(
# )--     Version:    1.01                         --(
# )--------------------------------------------------(
# )--     Requires:   None                         --(
# )--------------------------------------------------(
# )--    Version changes:                          --(
# )-- 1.01 - Items with <No Forge> note tag, are   --(
# )--        now not listed in the forge.          --(
# )--------------------------------------------------(
# )--             Description                      --(
# )-- Use 4 items to get 1 random item from item   --(
# )-- tables.                                      --(
# )--------------------------------------------------(
# )-- For all people who want to gamble their      --(
# )-- useless items away or want to try and get    --(
# )-- something useful can now use Gambler's       --(
# )-- Forge for that!                              --(
# )--------------------------------------------------(
# )--             Instructions                     --(
# )--  Call the Gambler's Forge scene by using:    --(
# )-- SceneManager.call(MrTS_Scene_Gamblers_Forge) --(
# )--                                              --(
# )-- If you don't want an item to be forgeable,   --(
# )-- add <No Forge> in that item's note box.      --(
# )-- <No Forge> <Noforge> <noforge> <no forge>    --(
# )--------------------------------------------------(
# )--             LICENSE INFO                     --(
# )--http://mrtrivelvx.wordpress.com/terms-of-use/ --(
# )--------------------------------------------------(
 
module MrTS
  module MrTS_Gambler_Forge
   
    # )-----------------------------------------------(
    # )--  Feel free to customize for your needs    --(
    # )--     2 means 2nd item in the database      --(
    # )-----------------------------------------------(
    # )--  Item rewards - what Items can player get --(
    # )-----------------------------------------------(
    ITEM_REWARDS   =  [
                      2, 3
                      ]
    # )--------------------------------------------------(
    # )-- Weapon rewards - what Weapons can player get --(
    # )--------------------------------------------------(
    WEAPON_REWARDS =  [
                      2, 3
                      ]
    # )------------------------------------------------(
    # )-- Armor rewards - what Armors can player get --(
    # )------------------------------------------------(
    ARMOR_REWARDS  =  [
                      2, 3 #2, 3, 4, 5, 6, 7, 8, 9, 10, 11
                      ]
   
    # )---------------------------------------------(
    # )--  How long reward pop up stays on screen --(
    # )---------------------------------------------(
    POP_UP_TIME = 120 # 60 = 1 second
   
    # )----------------(
    # )--  Text list --(
    # )----------------(
    TEXT_LIST = [
                "Forge",
                "Add Item",
                "Remove All",
                "Leave",
                "Welcome to Gambler's Forge!"
                ]
   
    # )----------------------------------------(
    # )--  Preferably don't edit down below  --(
    # )----------------------------------------(
                     
  end
end
 
 
# )--------------------------------------(
# )--  Class: MrTS_Scene_Mystic_Forge  --(
# )--------------------------------------(
class MrTS_Scene_Gamblers_Forge < Scene_Base
 
  # )---------------------(
  # )--  Method: start  --(
  # )---------------------(
  def start
    create_background
    create_main_viewport
    create_all_windows
    @timer_started = false
    @timer = 0
  end
 
  # )---------------------------------(
  # )--  Method: create_background  --(
  # )---------------------------------(
  def create_background
    @background_sprite = Sprite.new
    @background_sprite.bitmap = SceneManager.background_bitmap
    @background_sprite.color.set(16, 16, 16, 128)
  end
 
  # )----------------------(
  # )--  Method: update  --(
  # )----------------------(
  def update
    super
    @timer += 1 if @timer_started
    if @timer > MrTS::MrTS_Gambler_Forge::POP_UP_TIME
      @reward_window.close
      @timer_started = false
      @timer = 0
    end
  end
 
  # )-------------------------(
  # )--  Method: terminate  --(
  # )-------------------------(
  def terminate
    super
    dispose_all_windows
    dispose_background
  end
 
  # )----------------------------------(
  # )--  Method: dispose_background  --(
  # )----------------------------------(
  def dispose_background
    @background_sprite.dispose
  end
 
  # )----------------------------------(
  # )--  Method: create_all_windows  --(
  # )----------------------------------(
  def create_all_windows
    create_mystic_forge_window
    create_items_taken_window
    create_command_window
    create_item_list_window
    create_reward_window
  end
 
  # )--------------------(
  # )--  Method: item  --(
  # )--------------------(
  def item
    @item_list.item
  end
 
  # )------------------------------------------(
  # )--  Method: create_mystic_forge_window  --(
  # )------------------------------------------(
  def create_mystic_forge_window
    @welcome_window = MrTS_Mystic_Forge_Window.new
  end
 
  # )-----------------------------------------(
  # )--  Method: create_items_taken_window  --(
  # )-----------------------------------------(
  def create_items_taken_window
    @taken_window = MrTS_Items_Taken_Window.new
  end
 
  # )---------------------------------------(
  # )--  Method: create_item_list_window  --(
  # )---------------------------------------(
  def create_item_list_window
    @item_list = MrTS_Mystic_Forge_Item_List_Window.new(@command_window, @taken_window.y + @taken_window.height)
    @item_list.set_handler(:ok    , method(:item_ok))
    @item_list.set_handler(:cancel, method(:item_back))
  end
 
  # )-----------------------(
  # )--  Method: item_ok  --(
  # )-----------------------(
  def item_ok
    $game_party.last_item.object = item
    @taken_window.add_item(item)
    @item_list.activate
    @item_list.select_last
    @item_list.refresh
  end
 
  # )-------------------------(
  # )--  Method: item_back  --(
  # )-------------------------(
  def item_back
    @item_list.unselect
    @command_window.activate
  end  
 
  # )-------------------------------------(
  # )--  Method: create_command_window  --(
  # )-------------------------------------(
  def create_command_window
    @command_window = MrTS_Command_Window_MF.new
    @command_window.set_handler(:forge, method(:forge))
    @command_window.set_handler(:additem, method(:additem))
    @command_window.set_handler(:restart, method(:restart))
    @command_window.set_handler(:quit, method(:return_scene))
    @command_window.set_handler(:cancel, method(:command_back))
  end
 
  # )---------------------(
  # )--  Method: forge  --(
  # )---------------------(
  def forge
    if @taken_window.can_forge?
      @taken_window.destroy_items
      @reward_window.give_reward
      @item_list.refresh
      @timer_started = true
    end
    @command_window.activate
  end
 
  # )----------------------------(
  # )--  Method: command_back  --(
  # )----------------------------(
  def command_back
    @taken_window.return_items
    @item_list.refresh
    return_scene
  end
 
  # )-----------------------(
  # )--  Method: additem  --(
  # )-----------------------(
  def additem
    @item_list.activate
    @item_list.select_last
  end
 
  # )-----------------------(
  # )--  Method: restart  --(
  # )-----------------------(
  def restart
    @taken_window.return_items
    @command_window.activate
    @item_list.refresh
  end
 
  # )------------------------------------(
  # )--  Method: create_reward_window  --(
  # )------------------------------------(
  def create_reward_window
    @reward_window = MrTS_Mystic_Forge_Reward_Window.new
  end
 
  # )-----------------------------------(
  # )--  Method: dispose_all_windows  --(
  # )-----------------------------------(
  def dispose_all_windows
    @welcome_window.dispose
    @taken_window.dispose
    @command_window.dispose
    @item_list.dispose
    @reward_window.dispose
  end
end # End of MrTS_Scene_Mystic_Forge
 
# )----------------------------------------------(
# )--  Class: MrTS_Mystic_Forge_Reward_Window  --(
# )----------------------------------------------(
class MrTS_Mystic_Forge_Reward_Window < Window_Base
 
  # )--------------------------(
  # )--  Method: initialize  --(
  # )--------------------------(
  def initialize
    dw = 172 + standard_padding*2
    dh = line_height + standard_padding*2
    dx = Graphics.width/2 - dw/2
    dy = Graphics.height/2 - dh/2
    super(dx, dy, dw, dh)
    self.openness = 0
  end
 
  # )---------------------------(
  # )--  Method: give_reward  --(
  # )---------------------------(
  def give_reward
    loot_table = rand(3)
    case loot_table
    when 0
      item = $data_items[MrTS::MrTS_Gambler_Forge::ITEM_REWARDS[rand(MrTS::MrTS_Gambler_Forge::ITEM_REWARDS.size)]]
    when 1
      item = $data_weapons[MrTS::MrTS_Gambler_Forge::WEAPON_REWARDS[rand(MrTS::MrTS_Gambler_Forge::WEAPON_REWARDS.size)]]  
    when 2
      item = $data_armors[MrTS::MrTS_Gambler_Forge::ARMOR_REWARDS[rand(MrTS::MrTS_Gambler_Forge::ARMOR_REWARDS.size)]]
    end
    open
    create_contents
    draw_item_name(item, 0, 0)
    $game_party.gain_item(item, 1)
  end
end # end of MrTS_Mystic_Forge_Reward_Window
 
# )-------------------------------------------------(
# )--  Class: MrTS_Mystic_Forge_Item_List_Window  --(
# )-------------------------------------------------(
class MrTS_Mystic_Forge_Item_List_Window < Window_Selectable
 
  # )--------------------------(
  # )--  Method: initialize  --(
  # )--------------------------(
  def initialize (command_window, y)
    super(0, y, Graphics.width, Graphics.height - y - command_window.height)
    @data = []
    refresh
  end
 
  # )-----------------------(
  # )--  Method: col_max  --(
  # )-----------------------(
  def col_max
    return 2
  end
 
  # )------------------------(
  # )--  Method: item_max  --(
  # )------------------------(
  def item_max
    return @data ? @data.size : 1
  end
 
  # )--------------------(
  # )--  Method: item  --(
  # )--------------------(
  def item
    @data && index >= 0 ? @data[index] : nil
  end
 
  # )-----------------------(
  # )--  Method: refresh  --(
  # )-----------------------(
  def refresh
    make_data
    create_contents
    draw_all_items
  end
 
  # )---------------------------(
  # )--  Method: select_last  --(
  # )---------------------------(
  def select_last
    select(@data.index($game_party.last_item.object) || 0)
  end
 
  # )-------------------------(
  # )--  Method: make_data  --(
  # )-------------------------(
  def make_data
    @data = $game_party.all_items.select {|item| include?(item) }
    @data.push(nil) if include?(nil)
  end
 
  # )-------------------------(
  # )--  Method: draw_item  --(
  # )-------------------------(
  def draw_item(index)
    item = @data[index]
    if item
      rect = item_rect(index)
      rect.width -= 4
      draw_item_name(item, rect.x, rect.y, true)
      draw_item_number(rect, item)
    end
  end
 
  # )--------------------------------(
  # )--  Method: draw_item_number  --(
  # )--------------------------------(
  def draw_item_number(rect, item)
    draw_text(rect, sprintf(":%2d", $game_party.item_number(item)), 2)
  end
 
  # )------------------------------(
  # )--  Method: can_be_listed?  --(
  # )------------------------------(
  def can_be_listed?(item)
    item.note[/(<[n-nN-N]o\s*[f-fF-F]orge>)/]
    if $1
      false
    else
      true
    end
  end
 
  # )------------------------(
  # )--  Method: include?  --(
  # )------------------------(
  def include?(item)
    if (item.is_a?(RPG::Weapon) || item.is_a?(RPG::Armor) ||
      (item.is_a?(RPG::Item) && !item.key_item?)) && can_be_listed?(item)
      true
    else
      false
    end
  end
end # end of MrTS_Mystic_Forge_Item_List_Window
 
 
# )-------------------------------------(
# )--  Class: MrTS_Command_Window_MF  --(
# )-------------------------------------(
class MrTS_Command_Window_MF < Window_HorzCommand
  # )--------------------------(
  # )--  Method: initialize  --(
  # )--------------------------(
  def initialize
    super(0, Graphics.height - line_height - standard_padding*2)
  end
 
  # )---------------------------------(
  # )--  Method: make_command_list  --(
  # )---------------------------------(
  def make_command_list
    add_command(MrTS::MrTS_Gambler_Forge::TEXT_LIST[0], :forge)
    add_command(MrTS::MrTS_Gambler_Forge::TEXT_LIST[1], :additem)
    add_command(MrTS::MrTS_Gambler_Forge::TEXT_LIST[2], :restart)
    add_command(MrTS::MrTS_Gambler_Forge::TEXT_LIST[3], :quit)
  end
 
  # )----------------------------(
  # )--  Method: window_width  --(
  # )----------------------------(
  def window_width
    Graphics.width
  end
 
  # )-----------------------(
  # )--  Method: col_max  --(
  # )-----------------------(
  def col_max
    return 4
  end
 
end # end of MrTS_Command_Window_MF
 
 
# )---------------------------------------(
# )--  Class: MrTS_Mystic_Forge_Window  --(
# )---------------------------------------(
class MrTS_Mystic_Forge_Window < Window_Base
 
  # )--------------------------(
  # )--  Method: initialize  --(
  # )--------------------------(
  def initialize
    super(0, 0, Graphics.width, line_height + standard_padding*2)
    draw_welcome_message
  end
 
  # )------------------------------------(
  # )--  Method: draw_welcome_message  --(
  # )------------------------------------(
  def draw_welcome_message
    contents.clear
    text = MrTS::MrTS_Gambler_Forge::TEXT_LIST[4]
    draw_text(contents.width/2 - text_size(text).width/2, 0, contents.width, line_height, text)
  end
end # end of MrTS_Mystic_Forge_Window
 
 
# )---------------------------------------(
# )--  Class: MrTS_Items_Taken_Window  --(
# )---------------------------------------(
class MrTS_Items_Taken_Window < Window_Base
 
  # )--------------------------(
  # )--  Method: initialize  --(
  # )--------------------------(
  def initialize
    super(0, line_height + standard_padding*2, Graphics.width, line_height*2 + standard_padding * 4)
    @item = []
    refresh
  end
 
  # )-----------------------(
  # )--  Method: refresh  --(
  # )-----------------------(
  def refresh
    contents.clear
    create_contents
    draw_items    
  end
 
  # )--------------------------(
  # )--  Method: draw_items  --(
  # )--------------------------(
  def draw_items
    item_no = 0
   
    while item_no < 4
      item = @item[item_no]
      dx = contents.width/2 * (item_no%2)
      dy = (contents.height - line_height) * (item_no/2)
      draw_icon(16, dx, dy)
      if item
        draw_item_name(item, dx, dy)
      end
      item_no += 1
    end
  end
 
  # )--------------------------(
  # )--  Method: can_forge?  --(
  # )--------------------------(
  def can_forge?
    if @item.length == 4
      true
    else
      false
    end
  end
 
  # )------------------------(
  # )--  Method: add_item  --(
  # )------------------------(
  def add_item(item)
    if item && @item.length < 4
      $game_party.lose_item(item, 1)
      @item.push(item)
      refresh
    end
  end
 
  # )-----------------------------(
  # )--  Method: destroy_items  --(
  # )-----------------------------(
  def destroy_items
    @item = []
    refresh
  end
 
  # )----------------------------(
  # )--  Method: return_items  --(
  # )----------------------------(
  def return_items
    @item.each do |it|
      $game_party.gain_item(it, 1)
    end
   
    @item = []
    refresh
  end
end # end of MrTS_Items_Taken_Window