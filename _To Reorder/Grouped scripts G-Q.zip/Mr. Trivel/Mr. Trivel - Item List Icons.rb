# )----------------------------------------------------------------------------(
# )--     AUTHOR:     Mr Trivel                                              --(
# )--     NAME:       Item List Icons                                        --(
# )--     CREATED:    2014-06-17                                             --(
# )--     VERSION:    1.0                                                    --(
# )----------------------------------------------------------------------------(
# )--                          DESCRIPTION                                   --(
# )--  Instead of using Icon > Name > Quantity in an item list. It will only --(
# )--  show Icon and quantity in top right corner of the item.               --(
# )----------------------------------------------------------------------------(
# )--                          INSTRUCTIONS                                  --(
# )--                          Plug & Play                                   --(
# )----------------------------------------------------------------------------(
# )--                          LICENSE INFO                                  --(
# )--    http://mrtrivelvx.wordpress.com/terms-of-use/                       --(
# )----------------------------------------------------------------------------(
 
class Window_ItemList < Window_Selectable
  def col_max
    return 16
  end
 
  def draw_item(index)
    item = @data[index]
    if item
      rect = item_rect(index)
      rect.width -= 4
      draw_icon(item.icon_index, rect.x+3, rect.y+2, enable?(item))
      draw_item_number(rect, item)
    end
  end
 
  def item_rect(index)
    rect = Rect.new
    rect.width = 32
    rect.height = item_height + 4
    rect.x = index % col_max * (32)
    rect.y = index / col_max * (item_height + 4)
    rect
  end
 
  def draw_item_number(rect, item)
    make_font_smaller
    rect.y -= 5
    rect.x += 3
    draw_text(rect, sprintf("%2d", $game_party.item_number(item)),2) if $game_party.item_number(item) > 1
    make_font_bigger
  end
end