# )--------------------------------------------------(
# )--     Author:     Mr Trivel                    --(
# )--     Name:       New Items in Shop on Sell    --(
# )--     Created:    2014-06-12                   --(
# )--     Version:    1.0                          --(
# )--------------------------------------------------(
# )--     Requires:   None                         --(
# )--------------------------------------------------(
# )--             Description                      --(
# )--  Instead of having default shop where you    --(
# )--  list items in it. Now you can call another  --(
# )--  type of shop. Which gets new items as you   --(
# )--  sell specific items to it.                  --(
# )--  E.g. Sell 5 Copper Ore to unlock Copper     --(
# )--  Dagger.                                     --(
# )--  (You can still use normal shop, too!)       --(
# )--------------------------------------------------(
# )--             Instructions                     --(
# )--  Call the shop by using:                     --(
# )--  SceneManager.call(MrTS_Dynamic_Shop)        --(
# )--                                              --(
# )--  In item's note tag, write:                  --(
# )--  <Shop:                                      --(
# )--  i: X, Y                                     --(
# )--  >                                           --(
# )--                                              --(
# )--  i - item, w - weapon, a - armor             --(
# )--  X - ID of the item/weapon/armor             --(
# )--  Y - Quantity                                --(
# )--                                              --(
# )--  E.g.                                        --(
# )--  <Shop:                                      --(
# )--  i: 10, 12                                   --(
# )--  w: 2, 5                                     --(
# )--  >                                           --(
# )--  Means you need to have 12 of Item with ID 10--(
# )--  sold at the shop and 5 of Weapon with ID 2  --(
# )--  also sold at the shop.                      --(
# )--                                              --(
# )--  Or you can use                              --(
# )--  <Shop: Default>                             --(
# )--  To make item be automatically unlocked in   --(
# )--  the shop.                                   --(
# )--------------------------------------------------(
# )--             LICENSE INFO                     --(
# )--http://mrtrivelvx.wordpress.com/terms-of-use/ --(
# )--------------------------------------------------(
 
 
# )--------------------------------(
# )--  Class: MrTS_Dynamic_Shop  --(
# )--------------------------------(
class MrTS_Dynamic_Shop < Scene_Shop
 
  # )---------------------(
  # )--  Method: start  --(
  # )---------------------(
  alias mrts_start start
  def start
    prepare
    mrts_start
  end
 
  # )-----------------------(
  # )--  Method: prepare  --(
  # )-----------------------(
  def prepare(purchase_only=false)
    @goods = []
    rgx_one = /<[s-sS-S]hop\s*:.*\s*^(([a-ai-iw-w]:\s*\d+,\s*\d+\s*^)+)>/
    rgx_two = /([a-ai-iw-w]:\s*\d+,\s*\d+)/
    rgx_three = /([a-ai-iw-w]):\s*(\d+),\s*(\d+)/
    $data_items.each do |item|
      if item
        item.note[/<[s-sS-S]hop:\s*([d-dD-D]efault)>/]
        if $1
          @goods.push([0, item.id, 0, 0])
        elsif
          item_exists = true
          item.note[rgx_one]
          if $1
            $1.scan(rgx_two).collect do |ele|
              ele[0][rgx_three]
              case $1
              when "i"
                item_exists = false unless $game_party.item_available?($data_items[$2.to_i], $3.to_i)
              when "a"
                item_exists = false unless $game_party.item_available?($data_armors[$2.to_i], $3.to_i)
              when "w"
                item_exists = false unless $game_party.item_available?($data_weapons[$2.to_i], $3.to_i)
              end # case
            end # $1.scan
            @goods.push([0, item.id, 0, 0]) if item_exists
          end #if $1
        end
      end #if item
    end
   
    $data_weapons.each do |item|
      if item
        item.note[/<[s-sS-S]hop:\s*([d-dD-D]efault)>/]
        if $1
          @goods.push([1, item.id, 0, 0])
        elsif
          item_exists = true
          item.note[rgx_one]
          if ($1)
            $1.scan(rgx_two).collect do |ele|
              ele[0][rgx_three]
              case $1
              when "i"
                item_exists = false unless $game_party.item_available?($data_items[$2.to_i], $3.to_i)
              when "a"
                item_exists = false unless $game_party.item_available?($data_armors[$2.to_i], $3.to_i)
              when "w"
                item_exists = false unless $game_party.item_available?($data_weapons[$2.to_i], $3.to_i)
              end
            end
            @goods.push([1, item.id, 0, 0]) if item_exists
          end
        end
      end
    end
   
    $data_armors.each do |item|
      if item
        item.note[/<[s-sS-S]hop:\s*([d-dD-D]efault)>/]
        if $1
          @goods.push([2, item.id, 0, 0])
        elsif
          item_exists = true
          item.note[rgx_one]
          if ($1)
            $1.scan(rgx_two).collect do |ele|
              ele[0][rgx_three]
              case $1
              when "i"
                item_exists = false unless $game_party.item_available?($data_items[$2.to_i], $3.to_i)
              when "a"
                item_exists = false unless $game_party.item_available?($data_armors[$2.to_i], $3.to_i)
              when "w"
                item_exists = false unless $game_party.item_available?($data_weapons[$2.to_i], $3.to_i)
              end
            end
            @goods.push([2, item.id, 0, 0]) if item_exists
          end
        end
      end
    end
   
    @purchase_only = purchase_only
  end
 
  # )-----------------------(
  # )--  Method: do_sell  --(
  # )-----------------------(
  def do_sell(number)
    $game_party.gain_gold(number * selling_price)
    $game_party.lose_item(@item, number)
    $game_party.item_sold(@item, number)
    prepare
    @buy_window.set_goods(@goods)
    @buy_window.refresh
  end
end
 
# )-------------------------(
# )--  Class: Game_Party  --(
# )-------------------------(
class Game_Party < Game_Unit
 
  # )---------------------------------(
  # )--  Public Instance Variables  --(
  # )---------------------------------(
  attr_reader   :items_sold               # To know which items have been sold
  attr_reader   :items_quantities         # To know how many of that item has been sold
 
  # )---------------------------------(
  # )--  Alias to: mrts_initialize  --(
  # )---------------------------------(
  alias mrts_initialize initialize
  def initialize
    mrts_initialize
    @items_sold = []
    @items_quantities = []
  end
 
  # )-----------------------------(
  # )--  New Method: item_sold  --(
  # )-----------------------------(
  def item_sold(t_item, t_quantity = 1)
    @items_quantities.push(0) unless @items_sold.include?(t_item)
    @items_sold.push(t_item) unless @items_sold.include?(t_item)
    @items_quantities[@items_sold.index(t_item)]+=t_quantity
  end
 
  # )-----------------------------(
  # )--  New Method: item_sold  --(
  # )-----------------------------(
  def item_available?(t_item, t_quantity)
    return false if !@items_sold.include?(t_item)
    return false if !@items_quantities[@items_sold.index(t_item)] || @items_quantities[@items_sold.index(t_item)]<t_quantity
    return true
  end
 
end
 
# )-------------------------(
# )--  Class: Scene_Shop  --(
# )-------------------------(
class Scene_Shop < Scene_MenuBase
  alias mrts_do_sell do_sell
  def do_sell(number)
    mrts_do_sell(number)
    $game_party.item_sold(@item, number)
  end
end
 
# )-----------------------------(
# )--  Class: Window_ShopBuy  --(
# )-----------------------------(
class Window_ShopBuy < Window_Selectable
 
  def set_goods(shop_goods)
    @shop_goods = shop_goods
  end
end