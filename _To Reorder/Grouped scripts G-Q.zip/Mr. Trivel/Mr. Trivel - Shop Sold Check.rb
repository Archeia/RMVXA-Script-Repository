# )-------------------------------------------(
# )--     Author:     Mr Trivel             --(
# )--     Name:       Shop Check            --(
# )--     Created:    2014-06-05            --(
# )--     Version:    1.00                  --(
# )-------------------------------------------(
# )--     Requires:   None                  --(
# )-------------------------------------------(
# )--             Description               --(
# )-- This script changes a switch          --(
# )-- depending if player has bought or     --(
# )-- or sold anything to the store.        --(
# )-------------------------------------------(
# )--             Instructions              --(
# )--Plug & Play or Plug -> Customize & Play--(
# )----------------------------------------------------(
# )--             LICENSE INFO                       --(
# )-- http://mrtrivelvx.wordpress.com/terms-of-use/  --(
# )----------------------------------------------------(

module MrTS
  module MrTS_Shop_Check
    
    # )-------------------------------------(
    # )--  Switches for                   --(
    # )-------------------------------------(
    # )-- Bought anything                 --(
    BOUGHT = 1 
    
    # )-- Sold anything                   --(
    SOLD = 2 
    
    # )-- Bought or sold anything         --(
    DID_ANYTHING = 3
    # )-------------------------------------(
  end
end

# )------------------------------------------(
# )--    Careful with editing down below   --(
# )------------------------------------------(

# )-----------------------------(
# )--  Class: Scene_Shop      --(
# )-----------------------------(
class Scene_Shop < Scene_MenuBase
  
  # )-------------------------------------(
  # )--  Alias to: prepare              --(
  # )-------------------------------------(
  alias MrTS_ss_prepare prepare
  def prepare(*args)
    MrTS_ss_prepare(*args)
    $game_switches[MrTS::MrTS_Shop_Check::BOUGHT] =       false
    $game_switches[MrTS::MrTS_Shop_Check::SOLD] =         false
    $game_switches[MrTS::MrTS_Shop_Check::DID_ANYTHING] = false
  end
  
  # )-------------------------------------(
  # )--  Alias to: do_buy               --(
  # )-------------------------------------(
  alias MrTS_ss_do_buy do_buy
  def do_buy(*args)
    MrTS_ss_do_buy(*args)
    $game_switches[MrTS::MrTS_Shop_Check::BOUGHT] =       true
    $game_switches[MrTS::MrTS_Shop_Check::DID_ANYTHING] = true
  end
  
  # )-------------------------------------(
  # )--  Alias to: do_sell              --(
  # )-------------------------------------(
  alias MrTS_ss_do_sell do_sell
  def do_sell(*args)
    MrTS_ss_do_sell(*args)
    $game_switches[MrTS::MrTS_Shop_Check::SOLD] =         true
    $game_switches[MrTS::MrTS_Shop_Check::DID_ANYTHING] = true
  end
end