# Instructions: Set price in database by using <Sell: X> X – price
#

class Scene_Shop<Scene_MenuBase
def selling_price
    @item.note[/<[s-sS-S]ell\s*:\s*(\d*)>/]if $1
      $1.to_i
    else
      @item.price/2
    end
  end
end