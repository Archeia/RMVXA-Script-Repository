# )----------------------------------------------------------------------------(
# )--     AUTHOR:     Mr Trivel                                              --(
# )--     NAME:       Stat Points                                            --(
# )--     CREATED:    2014-06-17                                             --(
# )--     VERSION:    1.0                                                    --(
# )----------------------------------------------------------------------------(
# )--                          DESCRIPTION                                   --(
# )--  Adds Stat Points to actors which are gained on level up. And can be   --(
# )--  spent in Status screen.                                               --(
# )----------------------------------------------------------------------------(
# )--                          INSTRUCTIONS                                  --(
# )--               Customize below to your needs.                           --(
# )----------------------------------------------------------------------------(
# )--                          LICENSE INFO                                  --(
# )--    http://mrtrivelvx.wordpress.com/terms-of-use/                       --(
# )----------------------------------------------------------------------------(

module MrTS
  module Stat_Points
    # )----------------------------------------------------(
    # )--  Stat points each actor gets at the beginning  --(
    # )----------------------------------------------------(
    Default = 15
    
    # )----------------------------------------------------(
    # )--  How many stat points actor gets on level up.  --(
    # )----------------------------------------------------(
    PointsOnLevelUp = 5
    
    # )---------------------------------------------------(
    # )--  By how much your stats grow per stat point.  --(
    # )---------------------------------------------------(
    StatsPerIncrease = 2
  end
end


# )----------------------------------------------------------------------------(
# )--  Class: Scene_Status                                                   --(
# )----------------------------------------------------------------------------(
class Scene_Status < Scene_MenuBase
  # )--------------------------------------------------------------------------(
  # )--  Overwrite Method: start                                             --(
  # )--------------------------------------------------------------------------(
  def start
    super
    @status_window = Window_Status.new(@actor)
    @status_window.set_handler(:cancel,   method(:return_scene))
    @status_window.set_handler(:pagedown, method(:next_actor))
    @status_window.set_handler(:pageup,   method(:prev_actor))
    create_stat_command_window
  end
  # )--------------------------------------------------------------------------(
  # )--  New Method: create_stat_command_window                              --(
  # )--------------------------------------------------------------------------(
  def create_stat_command_window
    @command_window = MrTS_Stat_Command.new(22, (24*7)+12)
    @command_window.set_handler(:ok, method(:increase_stat))
  end
  # )--------------------------------------------------------------------------(
  # )--  New Method: increase_stat                                           --(
  # )--------------------------------------------------------------------------(
  def increase_stat
    @actor.spend_stat_point(@command_window.index)
    @status_window.refresh
    @command_window.activate
  end
end


# )----------------------------------------------------------------------------(
# )--  Class: MrTS_Stat_Command                                              --(
# )----------------------------------------------------------------------------(
class MrTS_Stat_Command < Window_Command
  # )--------------------------------------------------------------------------(
  # )--  Method: initialize                                                  --(
  # )--------------------------------------------------------------------------(
  def initialize(x, y)
    super(x,y)
    self.opacity = 0
  end
  # )--------------------------------------------------------------------------(
  # )--  Method: window_width                                                --(
  # )--------------------------------------------------------------------------(
  def window_width
    return 196
  end
  # )--------------------------------------------------------------------------(
  # )--  Method: make_command_list                                           --(
  # )--------------------------------------------------------------------------(
  def make_command_list
    6.times do 
      add_command("", :ok)
    end
  end
  # )--------------------------------------------------------------------------(
  # )--  Method: process_ok                                                  --(
  # )--------------------------------------------------------------------------(
  def process_ok
    if current_item_enabled?
      Input.update
      deactivate
      call_ok_handler
    end
  end
end

# )----------------------------------------------------------------------------(
# )--  Class: Window_Status                                                  --(
# )----------------------------------------------------------------------------(
class Window_Status < Window_Selectable
  # )--------------------------------------------------------------------------(
  # )--  Overwrite Method: draw_block3                                       --(
  # )--------------------------------------------------------------------------(
  def draw_block3(y)
    draw_statpoints(32, y-line_height/2)
    draw_parameters(32, y+line_height/2)
    draw_equipments(288, y)
  end
  
  # )--------------------------------------------------------------------------(
  # )--  New Method: draw_statpoints                                         --(
  # )--------------------------------------------------------------------------(
  def draw_statpoints(x, y)
    change_color(system_color)
    draw_text(x, y, 140, line_height, "Stat Points: ")
    change_color(@actor.stat_point > 0 ? power_up_color : normal_color)
    draw_text(x+120, y, 36, line_height, @actor.stat_point.to_s,2) 
  end
end


# )----------------------------------------------------------------------------(
# )--  Class: Game_Actor                                                     --(
# )----------------------------------------------------------------------------(
class Game_Actor < Game_Battler
  
  # )--------------------------------------------------------------------------(
  # )--  Public Instance Variables                                           --(
  # )--------------------------------------------------------------------------(
  attr_reader   :stat_point
  attr_reader   :stat_points_spent

  # )--------------------------------------------------------------------------(
  # )--  Alias to: setup                                                     --(
  # )--------------------------------------------------------------------------(
  alias mrts_sp_setup setup
  def setup(actor_id)
    mrts_sp_setup(actor_id)
    initialize_stat_points
  end
  
  
  # )--------------------------------------------------------------------------(
  # )--  New Method: initialize_stat_points                                  --(
  # )--------------------------------------------------------------------------(
  def initialize_stat_points
    @stat_point = MrTS::Stat_Points::Default
    @stat_points_spent.size.times do |i|
      add_param(i+2, -@stat_points_spent[i])
    end if @stat_points_spent
    @stat_points_spent = [0,0,0,0,0,0]
  end
  
  # )--------------------------------------------------------------------------(
  # )--  New Method: spend_stat_point                                        --(
  # )--------------------------------------------------------------------------(
  def spend_stat_point(stat_id)
    unless @stat_point > 0 && param(stat_id+2) < param_max(stat_id+2)
      Sound.play_buzzer
      return
    end
    inc_by = MrTS::Stat_Points::StatsPerIncrease
    add_param(stat_id+2, inc_by)
    @stat_point -= 1
    @stat_points_spent[stat_id] += inc_by
    Sound.play_ok
  end
  
  # )--------------------------------------------------------------------------(
  # )--  Alias To: change_class                                              --(
  # )--------------------------------------------------------------------------(
  alias mrts_sp_change_class change_class 
  def change_class(class_id, keep_exp = false)
    initialize_stat_points unless keep_exp
    mrts_sp_change_class(class_id, keep_exp = false)
    @stat_point = MrTS::Stat_Points::Default + ( (level-1) * MrTS::Stat_Points::PointsOnLevelUp)
  end
  
  # )--------------------------------------------------------------------------(
  # )--  Alias to: level_up                                                  --(
  # )--------------------------------------------------------------------------(
  alias mrts_sp_level_up level_up
  def level_up
    mrts_sp_level_up
    @stat_point += MrTS::Stat_Points::PointsOnLevelUp
  end
end