# )----------------------------------------------------------------------------(
# )--     AUTHOR:     Mr Trivel                                              --(
# )--     NAME:       Skill Tiers                                            --(
# )--     CREATED:    2014-06-12                                             --(
# )--     VERSION:    1.1a                                                   --(
# )----------------------------------------------------------------------------(
# )--                         VERSION HISTORY                                --(
# )--  1.1a - selection fix.                                                 --(
# )--  1.1 - Completely rewritten with less and lighter code. Removed Tier   --(
# )--  limit of 8. Tiers are limitless now. Also removed battle system       --(
# )--  overwriting.                                                          --(
# )----------------------------------------------------------------------------(
# )--                          DESCRIPTION                                   --(
# )--  Your Actors are now limited to only 3 spells per tier! Spells have    --(
# )--  their tier and Actors have Max Tier. So Actor with Max Tier of 5 can't--(
# )--  learn a skill that is Tier 6.                                         --(
# )----------------------------------------------------------------------------(
# )--                          INSTRUCTIONS                                  --(
# )-- Use <Max Tier: X> in class' Note Box to set maximum skill tier for that--(
# )-- class.                                                                 --(
# )-- Use <Tier: X> in skill's Note Box to set that skill's Tier.            --(
# )----------------------------------------------------------------------------(
# )--                          LICENSE INFO                                  --(
# )--    http://mrtrivelvx.wordpress.com/terms-of-use/                       --(
# )----------------------------------------------------------------------------(
 
 
module MrTS
  module Spell_Tiers
    # Default tier of the actor if Max Tier is not set
    DEFAULT_TIER = 2
   
    # Default tier of the spell if Tier is not set
    DEFAULT_SPELL_TIER = 1
   
    # Letter for Tier in menus
    TIER_LETTER = "T"
  end
end
 
# some stuff that I will need later, not you, probably
$imported = {} if $imported.nil?
$imported["MrTS_Spell_Tiers"] = true
 
# )-------------------------(
# )--  Class: Game_Actor  --(
# )-------------------------(
class Game_Actor < Game_Battler
  # )---------------------------------(
  # )--  Public Instance Variables  --(
  # )---------------------------------(
  attr_reader :max_tier
 
  # )-------------------------------(
  # )--  Overwrite Method: setup  --(
  # )-------------------------------(
  def setup(actor_id)
    @actor_id = actor_id
    @name = actor.name
    @nickname = actor.nickname
    init_graphics
    @class_id = actor.class_id
    @level = actor.initial_level
    @exp = {}
    @equips = []
    @max_tier = self.class.note =~ /<max\s*tier\s*:\s*(\d+)>/i ? $1.to_i : MrTS::Spell_Tiers::DEFAULT_TIER
    init_exp
    init_skills
    init_equips(actor.equips)
    clear_param_plus
    recover_all
  end
 
  # )-------------------------------(
  # )--  New Method: learn_skill  --(
  # )-------------------------------(
  def learn_skill(skill_id)
    skill = $data_skills[skill_id]
    unless skill_learn?(skill) || tier_full?(skill.tier) || skill.tier > @max_tier
      @skills.push(skill_id)
      @skills.sort!
    end
  end
 
  # )------------------------------(
  # )--  New Method: tier_full?  --(
  # )------------------------------(
  def tier_full?(tier)
    in_tier = 0
    @skills.each do |skill|
      if $data_skills[skill].tier == tier
        in_tier += 1
      end
    end
    if in_tier >= 3
      true
    else
      false
    end
  end
 
  # )------------------------------------(
  # )--  New Method: can_learn_skill?  --(
  # )------------------------------------(
  def can_learn_skill?(skill_id)
    skill = $data_skills[skill_id]
    !tier_full?(skill.tier) && skill.tier <= @max_tier && !@skills.include?(skill_id)
  end
end
 
# )-------------------------(
# )--  Class: RPG::Skill  --(
# )-------------------------(
class RPG::Skill < RPG::UsableItem
 
  # )------------------------(
  # )--  New Method: tier  --(
  # )------------------------(
  def tier
    tmp_tier = note =~ /<tier\s*:\s*(\d+)>/i ? $1.to_i : MrTS::Spell_Tiers::DEFAULT_SPELL_TIER
    return tmp_tier
  end
end
 
# )--------------------------(
# )--  Class: Scene_Skill  --(
# )--------------------------(
class Scene_Skill < Scene_ItemBase
 
  # )-------------------------------(
  # )--  Overwrite Method: start  --(
  # )-------------------------------(
  def start
    super
    create_help_window
    create_status_window
    create_item_window
    @item_window.activate
    @item_window.select(0)
  end
 
  # )--------------------------------------------(
  # )--  Overwrite Method: create_status_window--(
  # )--------------------------------------------(
  def create_status_window
    y = @help_window.height
    @status_window = Window_SkillStatus.new(0, 0)
    @status_window.width = Graphics.width
    @status_window.viewport = @viewport
    @status_window.actor = @actor
    @help_window.y = Graphics.height - @help_window.height
  end
 
  # )--------------------------------------------(
  # )--  Overwrite Method: create_item_window  --(
  # )--------------------------------------------(
  def create_item_window
    wx = 0
    wy = @status_window.y + @status_window.height
    ww = Graphics.width
    wh = Graphics.height - wy - @help_window.height
    @item_window = Window_SkillList.new(wx, wy, ww, wh)
    @item_window.actor = @actor
    @item_window.viewport = @viewport
    @item_window.help_window = @help_window
    @item_window.set_handler(:ok,     method(:on_item_ok))
    @item_window.set_handler(:cancel, method(:on_item_cancel))
  end
 
  # )----------------------------------------(
  # )--  Overwrite Method: on_item_cancel  --(
  # )----------------------------------------(
  def on_item_cancel
    return_scene
  end
 
  # )-----------------------------------------(
  # )--  Overwrite Method: on_actor_change  --(
  # )-----------------------------------------(
  def on_actor_change
    @command_window.actor = @actor
    @status_window.actor = @actor
    @item_window.actor = @actor
    @item_window.activate
  end
end
 
# )-------------------------------(
# )--  Class: Window_SkillList  --(
# )-------------------------------(
class Window_SkillList < Window_Selectable
  # )---------------------------------(
  # )--  Overwrite Method: col_max  --(
  # )---------------------------------(
  def col_max
    return 3
  end
 
  # )----------------------------------------(
  # )--  Overwrite Method: make_item_list  --(
  # )----------------------------------------(
  def make_item_list
    @data = []
    tier = []
    @actor.max_tier.times do |i|
      tier[i] = []
    end
   
    @actor.skills.each do |skill|
      tt = skill.tier-1
      tier[tt].push(skill)
    end
   
    tier.each do |t|
      t.push(nil) while t.size < 3
      @data += t
    end
  end
 
  # )---------------------------------(
  # )--  Overwrite Method: refresh  --(
  # )---------------------------------(
  def refresh
    make_item_list
    create_contents
    draw_all_items
    draw_levels
  end
 
  # )-------------------------------(
  # )--  New Method: draw_levels  --(
  # )-------------------------------(
  def draw_levels
    @actor.max_tier.times do |i|
      change_color(normal_color)
      draw_text(0, line_height*i, 24, line_height, MrTS::Spell_Tiers::TIER_LETTER+(i+1).to_s)
    end
  end
 
  # )-----------------------------------(
  # )--  Overwrite Method: item_rect  --(
  # )-----------------------------------(
  def item_rect(index)
    rect = Rect.new
    rect.width = item_width + 12
    rect.height = item_height
    rect.x = index % col_max * (item_width + spacing - 20) + 24
    rect.y = index / col_max * item_height
    rect
  end
end
 
# )-----------------------------(
# )--  Class: Scene_ItemBase  --(
# )-----------------------------(
class Scene_ItemBase < Scene_MenuBase
 
  # )--------------------------------------(
  # )--  Overwrite Method: item_usable?  --(
  # )--------------------------------------(
  def item_usable?
    learn_skill_effect = nil
    item.effects.each do |eff|
      if eff.code == 43
        learn_skill_effect = eff
      end
    end
    if learn_skill_effect != nil
      user.usable?(item) && item_effects_valid? && can_learn_skill?(learn_skill_effect.data_id)
    else
      user.usable?(item) && item_effects_valid?
    end
  end
 
  # )------------------------------------(
  # )--  New Method: can_learn_skill?  --(
  # )------------------------------------(
  def can_learn_skill?(skill_id)
 
    item_target_actors.any? do |target|
      target.can_learn_skill?(skill_id)
    end
  end
end
 
# )---------------------------(
# )--  Class: Scene_Battle  --(
# )---------------------------(
class Scene_Battle < Scene_Base
  # )-------------------------------(
  # )--  Alias to: command_skill  --(
  # )-------------------------------(
  alias mrts_command_skill command_skill
  def command_skill
    mrts_command_skill
    @skill_window.select(0)
  end
end