# )----------------------------------------------------------------------------(
# )--     AUTHOR:     Mr Trivel                                              --(
# )--     NAME:       Actor Stats on Level Up                                --(
# )--     CREATED:    2014-06-30                                             --(
# )--     VERSION:    1.0                                                    --(
# )----------------------------------------------------------------------------(
# )--                         VERSION HISTORY                                --(
# )--  1.0 - Initial push.                                                   --(
# )----------------------------------------------------------------------------(
# )--                          DESCRIPTION                                   --(
# )--  Instead of setting every and single stat for the level ups, you can   --(
# )--  just write a formula in that actors note box.                         --(
# )----------------------------------------------------------------------------(
# )--                          INSTRUCTIONS                                  --(
# )--  The stat you want to be increased by formula on level up, write e.g.: --(
# )--  <MHP: 50 + (@level/10).ceil> - Actor will get 50 HP + extra HP from   --(
# )--  10th level                                                            --(
# )--  <MMP: 10 + @level> - Actor will get 10 + number of his level Max MP.  --(
# )--  <ATK: @level> - Actor will get his level number of ATK.               --(
# )--  <DEF: 3 + @level> - Actor will get his level number + 3 of DEF.       --(
# )--  <MAT: 7> - Actor will get plain 7 MAT each level.                     --(
# )--  <MDF: 5> - Same as above, just 5.                                     --(
# )--  <AGI: 5 + rand(3)> - Actor will get 5 + 0/1/2 AGI per level.          --(
# )--  <LUK: 1> - Actor will get flat 1 LUK per level.                       --(
# )--  In actors note tag.                                                   --(
# )----------------------------------------------------------------------------(
# )--                          LICENSE INFO                                  --(
# )--    http://mrtrivelvx.wordpress.com/terms-of-use/                       --(
# )----------------------------------------------------------------------------(

# )----------------------------------------------------------------------------(
# )--  Class: Game_Actor                                                     --(
# )----------------------------------------------------------------------------(
class Game_Actor < Game_Battler
  # )--------------------------------------------------------------------------(
  # )--  Aliases: setup, level_up                                            --(
  # )--------------------------------------------------------------------------(
  alias :mrts_ga_setup :setup
  alias :mrts_ga_level_up :level_up
  
  # )--------------------------------------------------------------------------(
  # )--  Alias Method: setup                                                 --(
  # )--------------------------------------------------------------------------(
  def setup(actor_id)
    mrts_ga_setup(actor_id)
    @stat_formulas = []
    @stat_formulas.push(actor.note =~ /<MHP:(.+)>/i ? $1 : "0")
    @stat_formulas.push(actor.note =~ /<MMP:(.+)>/i ? $1 : "0")
    @stat_formulas.push(actor.note =~ /<ATK:(.+)>/i ? $1 : "0")
    @stat_formulas.push(actor.note =~ /<DEF:(.+)>/i ? $1 : "0")
    @stat_formulas.push(actor.note =~ /<MAT:(.+)>/i ? $1 : "0")
    @stat_formulas.push(actor.note =~ /<MDF:(.+)>/i ? $1 : "0")
    @stat_formulas.push(actor.note =~ /<AGI:(.+)>/i ? $1 : "0")
    @stat_formulas.push(actor.note =~ /<LUK:(.+)>/i ? $1 : "0")
  end
  
  # )--------------------------------------------------------------------------(
  # )--  Alias Method: level_up                                              --(
  # )--------------------------------------------------------------------------(
  def level_up
    mrts_ga_level_up
    count = 0
    @stat_formulas.each { |i| add_param(count, eval(i)) ; count += 1 }
  end
end