# )--------------------------------------------------(
# )--     Author:     Mr Trivel                    --(
# )--     Name:       No Actor Menu                --(
# )--     Created:    2014-06-06                   --(
# )--     Version:    1.00                         --(
# )--------------------------------------------------(
# )--     Requires:   None                         --(
# )--------------------------------------------------(
# )--             Description                      --(
# )-- Removes all actor info from menu.            --(
# )--------------------------------------------------(
# )--------------------------------------------------(
# )--             Instructions                     --(
# )--             Plug & Play                      --(
# )--------------------------------------------------(
# )--             LICENSE INFO                     --(
# )--http://mrtrivelvx.wordpress.com/terms-of-use/ --(
# )--------------------------------------------------(
 
# )------------------------(
# )--  Class: Scene_Menu  -(
# )------------------------(
class Scene_Menu < Scene_MenuBase
 
  # )----------------------(
  # )--  Alias to: start  -(
  # )----------------------(
  alias mrts_sm_start start
  def start
    super
    create_command_window
    create_gold_window
  end
 
  # )--------------------------------------(
  # )--  Alias to: create_command_window  -(
  # )--------------------------------------(
  alias mrts_sm_create_command_window create_command_window
  def create_command_window
    @command_window = Window_MenuCommand.new
    @command_window.set_handler(:save,      method(:command_save))
    @command_window.set_handler(:game_end,  method(:command_game_end))
    @command_window.set_handler(:cancel,    method(:return_scene))
    @command_window.x = Graphics.width/2 - @command_window.width/2
    @command_window.y = Graphics.height/2 - @command_window.height/2
  end
 
  # )-----------------------------------(
  # )--  Alias to: create_gold_window  -(
  # )-----------------------------------(
  alias mrts_sm_create_gold_window create_gold_window
  def create_gold_window
    @gold_window = Window_Gold.new
    @gold_window.x = @command_window.x
    @gold_window.y = @command_window.y + @command_window.height
  end
end
 
 
# )--------------------------------(
# )--  Class: Window_MenuCommand  -(
# )--------------------------------(
class Window_MenuCommand < Window_Command
 
  # )----------------------------------(
  # )--  Alias to: make_command_list  -(
  # )----------------------------------(
  alias mrts_wmc_make_command_list make_command_list
  def make_command_list
    add_original_commands
    add_save_command
    add_game_end_command
  end
end