#_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/
#_/    ◆ Distribute Parameter - KMS_DistributeParameter ◆ VXAce ◆
#_/    ◇ Last update : 2012/08/05 (TOMY@Kamesoft) ◇
#_/    ◇ Website: http://ytomy.sakura.ne.jp/ ◇
#_/    ◇ Translated by Mr. Bubble ◇ 
#_/----------------------------------------------------------------------------
#_/  This script allows players to freely upgrade actor stats with points
#_/ gained through leveling up.
#_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/
# This script gives players the power to determine how actors' stats are
# distributed in a game.
#
# This is one of TOMY's more popular scripts from VX now made for VX Ace.
# 
# Please read the comments thoroughly since all customization in this
# script is done within the customization module.
#--------------------------------------------------------------------------
#   Script Calls
#--------------------------------------------------------------------------
# The following Script Calls are meant to be used in "Script..." event 
# commands found under Tab 3 when creating a new event command.
#
# gain_rp(actor_id, value)
#   This script call increases a specified actor's RP. actor_id is an
#   Actor ID number from your database and value is how much RP the actor 
#   will gain. value can be negative.
#
# distribute_param_actor(actor_id, key, n)
# distribute_param_actor(actor_id, key)
#   This script call allows you to forcefully upgrade a specified actor's
#   parameter. actor_id is an Actor ID number from your database. key is a 
#   parameter's :key from the settings module. n is the number of times the
#   parameter is upgraded. If n is a negative value, it will "downgrade"
#   the parameter. If the actor does not have enough RP points for
#   n number of upgrades, it will upgrade the parameter as much as possible.
#   If the n is omitted from the script call's arguments, it will upgrade the 
#   parameter only once.
#
# reset_distributed_count(actor_id)
#   This script call resets all of an actor's parameter upgrades which frees
#   all RP for reallocation. actor_id is an Actor ID number from your
#   database.
#
# call_distribute_parameter(actor_index)
# call_distribute_parameter
#   This script call opens up the DistributeParameter scene to a specified
#   actor in the party. actor_index is the position index of an actor in the 
#   party (NOT an actor's database ID number). 0 is the leader, 1 is the
#   second party member, 2 is the third party member, and so on...
#   If actor_index is omitted as as an argument in the script call, it will 
#   open the DistributeParameter scene to the first possible actor (the 
#   party leader).
#   
#--------------------------------------------------------------------------
#   KMS Generic Gauge Compatibility Caution
#--------------------------------------------------------------------------
# This script will only be compatible with KMS Generic Gauge scripts
# dated 2012/08/05 or above. Any older versions before that date will
# not work.
#
#==============================================================================


#==============================================================================
# ★ BEGIN Setting ★
#==============================================================================

module KMS_DistributeParameter
  #--------------------------------------------------------------------------
  # * Default Parameter Settings
  #--------------------------------------------------------------------------
  # This section determines the upgradable parameters listed in the
  # Distribute Parameter scene.
  #
  # The format for defining a new distributable parameter block is as follows:
  #
  #   {
  #     :key        => key,
  #     :name       => "Name",
  #     :limit      => Maximum upgrade limit,
  #     :cost       => [Base RP Cost, RP Cost Growth],
  #     :parameter  => [Base Param Gain, Param Gain Growth],
  #   },
  #
  # key : A unique symbol that represents the parameter within the 
  #       script. Symbols start with a colon ":" and appear orange in
  #       the script editor.
  #
  # "Name" : Parameter name displayed in the Distribute Parameter scene.
  #
  # Maximum upgrade limit : The maximum number of times the player can
  #                         upgrade the parameter. Decimal values are ok.
  #                         If this value is 0, it means that upgrades are 
  #                         allowed infinitely.
  #
  # Base RP Cost   : Base RP cost to upgrade the parameter.
  # RP Cost Growth : Amount added to Base RP Cost per parameter upgrade.
  #                  If this value is omitted from the array, the growth
  #                  value will default to zero. Can be a negative value.
  #                  Decimal values are ok.
  #
  # :parameter        : A parameter key. See list below. You can add
  #                     as many different parameters within a block as 
  #                     you like.
  # Base Param Gain   : Base amount of stat points gained per upgrade
  # Param Gain Growth : Amount added to Base Gain per parameter upgrade.
  #                     If this value is omitted from the array, the growth
  #                     value will default to zero. Can be a negative value.
  #                     Decimal values are ok.
  #
  # Always remember the comma after the closing curly bracket.
  #
  # The order of parameters defined in this section determines the order
  # of parameters displayed in the Distribute Parameter scene.
  #
  # !! IMPORTANT !!
  # It is important to note that Actor Ex-Parameters and Sp-Parameters deal 
  # with "rate" or "percentage chance" values. This should mean their gain
  # values should be floating point values that represent rates. What this 
  # means is:
  # 
  #   0.001 is 0.1%
  #   0.01  is 1%
  #   0.1   is 10%
  #   1.0   is 100%
  #
  # Be *very* careful with Ex-Parameters and Sp-Parameters when defining 
  # their gain values.
  #--------------------------------------------------------------------------
  #   List of Usable :parameter Keys
  #--------------------------------------------------------------------------
  # Actor Base Params (all these are normal values):
  #
  #     :mhp  Maximum Hit Points
  #     :mmp  Maximum Magic Points
  #     :atk  ATtacK power
  #     :def  DEFense power
  #     :mat  Magic ATtack power
  #     :mdf  Magic DeFense power
  #     :agi  AGIlity
  #     :luk  LUcK
  #
  # Actor Ex-Params and Sp-Params (all these are rate values):
  # 
  #     :hit  HIT rate
  #     :eva  EVAsion rate
  #     :cri  CRItical rate
  #     :cev  Critical EVasion rate                 (not yet supported)
  #     :mev  Magic EVasion rate                    (not yet supported)
  #     :mrf  Magic ReFlection rate                 (not yet supported)
  #     :cnt  CouNTer attack rate                   (not yet supported)
  #     :hrg  Hp ReGeneration rate                  (not yet supported)
  #     :mrg  Mp ReGeneration rate                  (not yet supported)
  #     :trg  Tp ReGeneration rate                  (not yet supported)
  #     :tgr  TarGet Rate
  #     :grd  GuaRD effect rate                     (not yet supported)
  #     :rec  RECovery effect rate                  (not yet supported)
  #     :pha  PHArmacology                          (not yet supported)
  #     :mcr  Mp Cost Rate                          (not yet supported)
  #     :tcr  Tp Charge Rate                        (not yet supported)
  #     :pdr  Physical Damage Rate                  (not yet supported)
  #     :mdr  Magical Damage Rate                   (not yet supported)
  #     :fdr  Floor Damage Rate                     (not yet supported)
  #     :exr  EXperience Rate                       (not yet supported)
  #
  # Item/Skill Invocation Speed:
  #
  #     :skill_speed  Skill Speed
  #     :item_speed   Item Speed
  #
  # Any parameters not listed here, such as ones created in other custom 
  # scripts, *MUST* be manually coded to support that custom parameter
  # in this script. Yes, this means supporting custom parameters requires
  # scripting knowledge.
  GAIN_PARAMETER = [
    # - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    # Param blocks defined below can be safely removed or modified if desired
    # - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    {
      :key   => :health,
      :name  => "Health",
      :limit => 30,
      :cost  => [ 1, 0.4],
      :mhp   => [30, 2],    # MaxHP
      :def   => [ 1, 0.25], # Defense
    }, # <- Always remember the comma after each closing curly bracket!
    {
      :key   => :magic,
      :name  => "Magic",
      :limit => 30,
      :cost  => [1, 0.4],
      :mmp   => [5, 0.5], # MaxMP
      :mat   => [2, 0.5], # Magic Attack
    }, # <- Comma!
    {
      :key   => :pow,
      :name  => "Power",
      :limit => 30,
      :cost  => [1, 0.4],
      :atk   => [2, 0.5],  # Attack
      :def   => [1, 0.25], # Defense
    },
    {
      :key   => :dex,
      :name  => "Dexterity",
      :limit => 30,
      :cost  => [1, 0.4],
      :agi   => [2, 0.5], # Agility
      :hit   => [0.005],  # Hit Rate
      :eva   => [0.005],  # Evasion Rate
    },
    {
      :key   => :luk,
      :name  => "Luck",
      :limit => 20,
      :cost  => [1, 0.5],
      :luk   => [1] # Luck
    },
    {
      :key   => :hit,
      :name  => "Accuracy",
      :limit => 20,
      :cost  => [1, 0.5],
      :hit   => [0.01], # Hit Rate
    },
    {
      :key   => :eva,
      :name  => "Evasion",
      :limit => 20,
      :cost  => [1, 0.5],
      :eva   => [0.01], # Evasion Rate
    },
    {
      :key   => :crt,
      :name  => "Critical",
      :limit => 20,
      :cost  => [1, 0.7],
      :cri   => [0.01], # Critical Rate
    },
    {
      :key         => :chant,
      :name        => "Skill Speed",
      :limit       => 0,
      :cost        => [1, 0.5],
      :skill_speed => [1], # Skill Speed
    },
    {
      :key        => :item,
      :name       => "Item Speed",
      :limit      => 0,
      :cost       => [1, 0.5],
      :item_speed => [1], # Item Speed
    },
    {
      :key   => :tgr,
      :name  => "Target Rate",
      :limit => 5,
      :cost  => [1],
      :tgr   => [0.2], # Target Rate (likelyhood of being targeted)
    }, # <- Again, remember the comma even if it's the last one!
    
    # - - - - You can add more distributable parameters here - - - - - - - -
    
  ] # <- Do not delete!

  #--------------------------------------------------------------------------
  # * Actor Personal Parameter Settings
  #--------------------------------------------------------------------------
  PERSONAL_GAIN_PARAMETER = [] # <- Do not delete or change!
  # This section allows you to define distributable parameters for
  # specific actors.
  # 
  #   PERSONAL_GAIN_PARAMETER[actor_id] = [ settings ]
  #
  # actor_id is an Actor ID number from your database. 
  # 
  # settings follow same syntax and format rules as explained in the 
  # Default Parameter Settings section above.
  #
  # If an Actor's parameter block has the same :key as one from the Default 
  # Parameter Settings section, the Actor's parameter block will take
  # precedence. Otherwise, the actor will use all default parameter blocks
  # defined in the section above.
  PERSONAL_GAIN_PARAMETER[1] = [
    # - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    {
      :key   => :health,
      :name  => "Health",
      :limit => 30,
      :cost  => [ 1, 0.4],
      :mhp   => [50, 3],   # MaxHP
      :def   => [ 1, 0.3], # Defense
    }, # <- Always remember the comma.
    
  ] # End of Actor ID 1's parameter array
  
  
  
  # - - - - - - You can create more actor personal parameters here - - - - -

  
  

  #--------------------------------------------------------------------------
  # * Class Parameter Settings
  #--------------------------------------------------------------------------
  CLASS_GAIN_PARAMETER = [] # <- Do not delete or change!
  # This section allows you to define distributable parameters for
  # specific classes.
  #
  #   CLASS_GAIN_PARAMETER[class_id] = [ settings ]
  #
  # class_id is a Class ID number from your database. 
  # 
  # settings follow same syntax and format rules as explained in the 
  # Default Parameter Settings and the Actor Personal Parameter
  # Settings sections above.
  #
  #  Parameter Settings priority order is: Class > Actor > Default
  
  
  
  
  # - - - - - - - - You can create class parameters here - - - - - - - - -
  
  
  
  
  #--------------------------------------------------------------------------
  # * RP Vocab
  #--------------------------------------------------------------------------
  VOCAB_RP   = "RP"
  #--------------------------------------------------------------------------
  # * RP Vocab Abbreviation
  #--------------------------------------------------------------------------
  VOCAB_RP_A = "R"

  #--------------------------------------------------------------------------
  # * Actor MaxRP Formula
  #--------------------------------------------------------------------------
  # This setting determines the amount of RP actors have based on level.
  # Decimal results are ok and are automatically rounded to a whole number.
  # Any proper Ruby mathmatical syntax may be used. 
  # ( ** is "to the power of" if anyone is wondering.)
  #
  # level : Actor's current level
  MAXRP_EXP = "(level ** 0.25 + 2.0) * level"
  #--------------------------------------------------------------------------
  # * Extra Parameter Terms
  #--------------------------------------------------------------------------
  # This allows you to provide display names for other actor default stats 
  # that aren't namable within the "Terms" tab in your database.
  #
  # Parameter Terms defined in KMS Extended Equip Scene take precedence 
  # over the vocab defined here.
  VOCAB_PARAM = {
    :hit         => "HIT",          # Accuracy
    :eva         => "EVA",          # Evasion Rate
    :cri         => "CRI",          # Critical Rate
    :skill_speed => "Skill Speed",  # Skill Evocation Speed
    :item_speed  => "Item Speed",   # Item Evocation Speed 
    :tgr         => "Target Rate",  # Target Rate
  }  # <- Do not delete!
  #--------------------------------------------------------------------------
  # * Infinite Upgrade Limit Display Setting
  #--------------------------------------------------------------------------
  # This setting determines how parameters with an infinite upgrade limit 
  # has its denominator displayed.
  #
  #  true  : num_of_upgrades          (Numerator only)
  #  false : num_of_upgrades/---      (Numerator/Denominator)
  HIDE_MAX_COUNT_INFINITE  = false

  #--------------------------------------------------------------------------
  # * Parameter Gauge Colors
  #--------------------------------------------------------------------------
  # Color index  : Window skin color index, 0~35 ( same values used in \C[n] )
  # Color object : RGB Color, Color.new(red, green, blue)
  #                Where red, green, and blue are values between 0~255
  GAUGE_START_COLOR = 28  # Start Color (left side)
  GAUGE_END_COLOR   = 29  # End Color (right side)
  
  #--------------------------------------------------------------------------
  # * KMS Generic Gauge Settings
  #--------------------------------------------------------------------------
  # These settings are only used when KMS Generic Gauge is also installed.
  #
  # Also, KMS Distribute Parameter can only be used with KMS Generic Gauge
  # versions dated 2012/08/05 or later.
  ENABLE_GENERIC_GAUGE = true
  
  # GAUGE_IMAGE must be placed in the Graphics/System/ folder.
  GAUGE_IMAGE  = "GaugeDist"  # Gauge Filename
  GAUGE_OFFSET = [-23, -2]    # Gauge Position Correction [x, y]
  GAUGE_LENGTH = -4           # Gauge Length
  GAUGE_SLOPE  = 30           # Gauge Slope (-89 ~ 89)
  
  #--------------------------------------------------------------------------
  # * Confirm Window Commands Text
  #--------------------------------------------------------------------------
  CONFIRM_COMMANDS = [
    "　Confirm",  # Confirm and save
    "　Cancel",   # Cancel and exit
    "　Go Back",  # Continue distributing RP
  ]  # <- Do not delete!

  #--------------------------------------------------------------------------
  # * Confirm Window Help Window Text
  #--------------------------------------------------------------------------
  CONFIRM_COMMAND_HELP = [
    "Save current RP allocation.",    # Confirm
    "Cancel current RP allocation.",  # Cancel
    "Continue allocating RP.",        # Continue
  ]  # <- Do not delete!

  #--------------------------------------------------------------------------
  # * Confirm Window Width
  #--------------------------------------------------------------------------
  CONFIRM_WIDTH = 160 # Pixel width

  #--------------------------------------------------------------------------
  # * Distribute Parameters Menu Command
  #--------------------------------------------------------------------------
  # This setting determines whether a menu command for the Distribute
  # Parameter scene appears in the memu. Commands will always be placed
  # at the bottom of the list. If you want to change the position of the
  # command, you can use a custom menu script such as KMS Custom Menu Command.
  #
  # true  : Allow distribute parameter access from menu.
  # false : Do not allow distribute parameter access from menu.
  USE_MENU_DISTRIBUTE_PARAMETER_COMMAND = true
  #--------------------------------------------------------------------------
  # * Distribute Parameters Menu Command Name
  #--------------------------------------------------------------------------
  VOCAB_MENU_DISTRIBUTE_PARAMETER       = "Parameters"

  #--------------------------------------------------------------------------
  # * Allow RP Redistribution
  #--------------------------------------------------------------------------
  # true  : RP can be freely redistributed by the player at any time.
  # false : RP distributions are permanent.
  ENABLE_REVERSE_DISTRIBUTE = true
end

#==============================================================================
# ☆ END Setting ☆
#==============================================================================

$kms_imported = {} if $kms_imported == nil
$kms_imported["DistributeParameter"] = true


module KMS_DistributeParameter
  # Distribution target parameter
  PARAMS = [:mhp, :mmp, :atk, :def, :mat, :mdf, :agi, :luk,
    :hit, :eva, :cri, :skill_speed, :item_speed, :tgr]
  PARAMS |= [:hit, :eva, :cri, :cev, :mev, :mrf, :cnt, :hrg, :mrg, :trg]
  PARAMS |= [:tgr, :grd, :rec, :pha, :mcr, :tcr, :pdr, :mdr, :fdr, :exr]

  # Parameter increment structure
  GainInfo  = Struct.new(:key, :name, :limit, :cost, :cost_rev, :params)
  ParamInfo = Struct.new(:value, :value_rev)

  # Distribution information structure
  DistInfo = Struct.new(:count, :hp, :mp)

  #--------------------------------------------------------------------------
  # Structure of parameter increment
  #--------------------------------------------------------------------------
  def self.create_gain_param_structs(target)
    result = []
    target.each { |v|
      info = GainInfo.new
      info.key      = v[:key]
      info.name     = v[:name]
      info.limit    = v[:limit]
      info.cost     = v[:cost][0]
      info.cost_rev = (v[:cost][1] == nil ? 0 : v[:cost][1])
      info.params   = {}

      PARAMS.each { |param|
        next unless v.has_key?(param)
        pinfo = ParamInfo.new
        pinfo.value     = v[param][0]
        pinfo.value_rev = (v[param][1] == nil ? 0 : v[param][1])
        info.params[param] = pinfo
      }
      result << info
    }
    return result
  end
  #--------------------------------------------------------------------------
  # ○ Parameter increment is structured (for intrinsic incremental amount)
  #--------------------------------------------------------------------------
  def self.create_gain_param_structs_for_personal(target)
    result = []
    target.each { |list|
      next if list == nil
      result << create_gain_param_structs(list)
    }
    return result
  end
  #--------------------------------------------------------------------------
  # ○ Merging parameter increase amount
  #--------------------------------------------------------------------------
  def self.merge(list1, list2)
    result = list1.clone
    list2.each { |info2|
      overwrite = false
      list1.each_with_index { |info1, i|
        if info1.key == info2.key
          result[i] = info2
          overwrite = true
          break
        end
      }
      result << info2 unless overwrite
    }
    return result
  end

  # Structuring of parameter increment
  GAIN_PARAMS = create_gain_param_structs(GAIN_PARAMETER)
  PERSONAL_GAIN_PARAMS =
    create_gain_param_structs_for_personal(PERSONAL_GAIN_PARAMETER)
  CLASS_GAIN_PARAMS =
    create_gain_param_structs_for_personal(CLASS_GAIN_PARAMETER)
end

#★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★

#==============================================================================
# ■ Vocab
#==============================================================================

module Vocab
  # Hit rate
  def self.hit
    return KMS_DistributeParameter::VOCAB_PARAM[:hit]
  end

  # Avoidance rate
  def self.eva
    return KMS_DistributeParameter::VOCAB_PARAM[:eva]
  end

  # critical ratio
  def self.cri
    return KMS_DistributeParameter::VOCAB_PARAM[:cri]
  end

  # Skill speed correction
  def self.skill_speed
    return KMS_DistributeParameter::VOCAB_PARAM[:skill_speed]
  end

  # Item Speed Correction
  def self.item_speed
    return KMS_DistributeParameter::VOCAB_PARAM[:item_speed]
  end

  # Targetability
  def self.tgr
    return KMS_DistributeParameter::VOCAB_PARAM[:tgr]
  end

  # RP
  def self.rp
    return KMS_DistributeParameter::VOCAB_RP
  end

  # RP (slightly)
  def self.rp_a
    return KMS_DistributeParameter::VOCAB_RP_A
  end

  # Parameter assignment
  def self.distribute_parameter
    return KMS_DistributeParameter::VOCAB_MENU_DISTRIBUTE_PARAMETER
  end
end

#★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★

#==============================================================================
# ■ DataManager
#==============================================================================

module DataManager
  module_function
  #--------------------------------------------------------------------------
  # ● Expansion of save contents
  #--------------------------------------------------------------------------
  class << DataManager
    unless method_defined?(:extract_save_contents_KMS_DistributeParameter)
      alias extract_save_contents_KMS_DistributeParameter extract_save_contents
    end
  end
  def extract_save_contents(contents)
    extract_save_contents_KMS_DistributeParameter(contents)

    KMS_Commands.check_distribution_values
    Graphics.frame_reset
  end
end

#★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★

#==============================================================================
# □ KMS_Commands
#==============================================================================

module KMS_Commands
  module_function
  #--------------------------------------------------------------------------
  # ○ Check values related to parameter assignment
  #--------------------------------------------------------------------------
  def check_distribution_values
    (1...$data_actors.size).each { |i|
      actor = $game_actors[i]
      actor.check_distribution_values
      actor.restore_distribution_values
    }
  end
  #--------------------------------------------------------------------------
  # ○ RP Increase or decrease
  #     actor_id : Actor ID
  #     value    : Increase / decrease amount
  #--------------------------------------------------------------------------
  def gain_rp(actor_id, value)
    actor = $game_actors[actor_id]
    return if actor == nil
    actor.gain_rp(value)
  end
  #--------------------------------------------------------------------------
  # ○ Execution of distribution
  #     actor_id : Actor ID
  #     key      : Key of target parameter
  #     num      : Number of sorting
  #--------------------------------------------------------------------------
  def distribute_param_actor(actor_id, key, num = 1)
    actor = $game_actors[actor_id]
    return if actor == nil

    # Inverse addition decision
    reverse = false
    if num < 0
      reverse = true
      num = num.abs
    end

    # Be applicable
    num.times { |i| actor.rp_growth_effect(key, reverse) }
  end
  #--------------------------------------------------------------------------
  # ○ Reset number of sorting
  #     actor_id : Actor ID
  #--------------------------------------------------------------------------
  def reset_distributed_count(actor_id)
    actor = $game_actors[actor_id]
    return if actor == nil
    actor.clear_distribution_values
    actor.restore_distribution_values
  end
  #--------------------------------------------------------------------------
  # ○ Call up the parameter allocation screen
  #     actor_index : Actor index
  #--------------------------------------------------------------------------
  def call_distribute_parameter(actor_index = 0)
    return if $game_party.in_battle
    $game_temp.call_distribute_parameter = true
    $game_party.menu_actor = $game_party.members[actor_index]
  end
end

class Game_Interpreter
  include KMS_Commands
end

#★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★

#==============================================================================
# ■ Game_Temp
#==============================================================================

class Game_Temp
  #--------------------------------------------------------------------------
  # ● Public instance variable
  #--------------------------------------------------------------------------
  attr_accessor :call_distribute_parameter  # Distribution screen call flag
  attr_accessor :menu_actor_index           # Actors for various menu screens index
  #--------------------------------------------------------------------------
  # ● Object initialization
  #--------------------------------------------------------------------------
  alias initialize_KMS_DistributeParameter initialize
  def initialize
    initialize_KMS_DistributeParameter

    @call_distribute_parameter = false
    @menu_actor_index = 0
  end
end

#★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★

#==============================================================================
# ■ Game_BattlerBase
#==============================================================================

class Game_BattlerBase
  #--------------------------------------------------------------------------
  # ● Clear the value to be added to the ability value
  #--------------------------------------------------------------------------
  alias clear_param_plus_KMS_DistributeParameter clear_param_plus
  def clear_param_plus
    clear_param_plus_KMS_DistributeParameter

    clear_distribution_values
    calc_distribution_values
  end
  #--------------------------------------------------------------------------
  # ○ Clear value relating to parameter assignment
  #--------------------------------------------------------------------------
  def clear_distribution_values
    @distributed_count = {}
    KMS_DistributeParameter::PARAMS.each { |param|
      @distributed_count[param] = 0
    }
  end
  #--------------------------------------------------------------------------
  # ○ Check values related to parameter assignment
  #--------------------------------------------------------------------------
  def check_distribution_values
    last_distributed_count = @distributed_count

    clear_distribution_values

    @distributed_count = last_distributed_count if last_distributed_count != nil
  end
  #--------------------------------------------------------------------------
  # ○ Compute various correction values
  #--------------------------------------------------------------------------
  def calc_distribution_values
    # Definition at inheritance destination
  end
  #--------------------------------------------------------------------------
  # ○ Acquire rise value by sorting
  #     param : Of parameters Symbol
  #--------------------------------------------------------------------------
  def distributed_param(param)
    return 0
  end
  #--------------------------------------------------------------------------
  # ○ Acquire information on sorting
  #--------------------------------------------------------------------------
  def distribution_info
    info = KMS_DistributeParameter::DistInfo.new
    info.count = @distributed_count.clone
    info.hp    = self.hp
    info.mp    = self.mp
    return info
  end
  #--------------------------------------------------------------------------
  # ○ Set information on distribution
  #--------------------------------------------------------------------------
  def set_distribution_info(info)
    return unless info.is_a?(KMS_DistributeParameter::DistInfo)

    @distributed_count = info.count
    calc_distribution_values
    self.hp = info.hp
    self.mp = info.mp
  end
end

#★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★

#==============================================================================
# ■ Game_Action
#==============================================================================

class Game_Action
  #--------------------------------------------------------------------------
  # ● Calculation of behavioral speed
  #--------------------------------------------------------------------------
  alias speed_KMS_DistributeParameter speed
  def speed
    speed = speed_KMS_DistributeParameter
    return speed if attack?

    if item.is_a?(RPG::Skill) && item.speed < 0
      n = [subject.distributed_param(:skill_speed), item.speed.abs].min
      speed += n
    elsif item.is_a?(RPG::Item) && item.speed < 0
      n = [subject.distributed_param(:item_speed), item.speed.abs].min
      speed += n
    end

    return speed
  end
end

#★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★

#==============================================================================
# ■ Game_Actor
#==============================================================================

class Game_Actor < Game_Battler
  #--------------------------------------------------------------------------
  # ○ Class variable
  #--------------------------------------------------------------------------
  @@__distribute_gain_params = {}
  #--------------------------------------------------------------------------
  # ● Object initialization
  #     actor_id : Actor ID
  #--------------------------------------------------------------------------
  alias initialize_KMS_DistributeParameter initialize
  def initialize(actor_id)
    @actor_id = actor_id
    @class_id = actor.class_id

    initialize_KMS_DistributeParameter(actor_id)
  end
  #--------------------------------------------------------------------------
  # ○ Acquire parameter increase amount list
  #--------------------------------------------------------------------------
  def gain_parameter_list
    key = "#{@actor_id}_#{@class_id}"
    unless @@__distribute_gain_params.has_key?(key)
      result = KMS_DistributeParameter::GAIN_PARAMS

      # Actor specific
      list   = KMS_DistributeParameter::PERSONAL_GAIN_PARAMS[@actor_id]
      result = KMS_DistributeParameter.merge(result, list) if list != nil

      # Occupation inherent
      list   = KMS_DistributeParameter::CLASS_GAIN_PARAMS[@class_id]
      result = KMS_DistributeParameter.merge(result, list) if list != nil

      @@__distribute_gain_params[key] = result
    end

    return @@__distribute_gain_params[key]
  end
  #--------------------------------------------------------------------------
  # ○ Acquire parameter increment
  #     key : Distribution key
  #--------------------------------------------------------------------------
  def gain_parameter(key)
    return gain_parameter_list.find { |v| v.key == key }
  end
  #--------------------------------------------------------------------------
  # ○ Compute various correction values
  #--------------------------------------------------------------------------
  def calc_distribution_values
    @rp_cost = 0
    @distributed_param = {}
    KMS_DistributeParameter::PARAMS.each { |param|
      @distributed_param[param] = 0
    }

    gain_parameter_list.each { |gain|
      next if gain == nil
      cost = 0
      distributed_count(gain.key).times { |i|
        cost += Integer(gain.cost + gain.cost_rev * i)
        gain.params.each { |param, v|
          @distributed_param[param] += v.value + v.value_rev * i
        }
      }
      @rp_cost += [cost, 0].max
    }

    KMS_DistributeParameter::PARAMS.each { |param|
      @distributed_param[param] = @distributed_param[param]
    }
  end
  #--------------------------------------------------------------------------
  # ○ Repair various correction values
  #--------------------------------------------------------------------------
  def restore_distribution_values
    calc_distribution_values
    self.hp = self.hp
    self.mp = self.mp
  end
  #--------------------------------------------------------------------------
  # ○ Acquire rise value by sorting
  #     param : Of parameters Symbol
  #--------------------------------------------------------------------------
  def distributed_param(param)
    return 0 if @distributed_param == nil
    return 0 if @distributed_param[param] == nil
    return @distributed_param[param]
  end
  PARAM_SYMBOL  = [:mhp, :mmp, :atk, :def, :mat, :mdf, :agi, :luk]
  XPARAM_SYMBOL = [:hit, :eva, :cri, :cev, :mev, :mrf, :cnt, :hrg, :mrg, :trg]
  SPARAM_SYMBOL = [:tgr, :grd, :rec, :pha, :mcr, :tcr, :pdr, :mdr, :fdr, :exr]
  #--------------------------------------------------------------------------
  # ● Acquire basic value of normal ability value
  #--------------------------------------------------------------------------
  alias param_base_KMS_DistributeParameter param_base
  def param_base(param_id)
    n = param_base_KMS_DistributeParameter(param_id)
    if PARAM_SYMBOL[param_id] != nil
      n += distributed_param(PARAM_SYMBOL[param_id])
    end

    return Integer(n)
  end
  #--------------------------------------------------------------------------
  # ● Acquisition of Accuracy
  #--------------------------------------------------------------------------
  alias hit_KMS_DistributeParameter hit
  def hit
    n = hit_KMS_DistributeParameter + distributed_param(:hit)
    return n
  end
  #--------------------------------------------------------------------------
  # ● Obtain evasion rate
  #--------------------------------------------------------------------------
  alias eva_KMS_DistributeParameter eva
  def eva
    n = eva_KMS_DistributeParameter + distributed_param(:eva)
    return n
  end
  #--------------------------------------------------------------------------
  # ● Acquisition of Critical Rate
  #--------------------------------------------------------------------------
  alias cri_KMS_DistributeParameter cri
  def cri
    n = cri_KMS_DistributeParameter + distributed_param(:cri)
    return n
  end
  #--------------------------------------------------------------------------
  # ● Acquisition of Target Rate
  #--------------------------------------------------------------------------
  alias tgr_KMS_DistributeParameter tgr
  def tgr
    n = tgr_KMS_DistributeParameter + distributed_param(:tgr)
    return n
  end
  #--------------------------------------------------------------------------
  # ○ MaxRP Acquisition
  #--------------------------------------------------------------------------
  def mrp
    n = Integer(eval(KMS_DistributeParameter::MAXRP_EXP))
    return [n + mrp_plus, 0].max
  end
  #--------------------------------------------------------------------------
  # ○ MaxRP Acquisition of correction value
  #--------------------------------------------------------------------------
  def mrp_plus
    @mrp_plus = 0 if @mrp_plus == nil
    return @mrp_plus
  end
  #--------------------------------------------------------------------------
  # ○ RP Acquisition
  #--------------------------------------------------------------------------
  def rp
    return [mrp - @rp_cost, 0].max
  end
  #--------------------------------------------------------------------------
  # ○ Acquisition of number of sorting
  #     param : Distribution destination parameter
  #--------------------------------------------------------------------------
  def distributed_count(param)
    clear_distribution_values     if @distributed_count == nil
    @distributed_count[param] = 0 if @distributed_count[param] == nil
    return @distributed_count[param]
  end
  #--------------------------------------------------------------------------
  # ○ RP Increase or decrease
  #     value : Increase / decrease amount
  #--------------------------------------------------------------------------
  def gain_rp(value)
    @mrp_plus = mrp_plus + value
  end
  #--------------------------------------------------------------------------
  # ○ Increase / decrease number of sorting
  #     param : Distribution destination parameter
  #     value : Increase / decrease amount
  #--------------------------------------------------------------------------
  def gain_distributed_count(param, value = 1)
    n = distributed_count(param)
    @distributed_count[param] += value if n.is_a?(Integer)
  end
  #--------------------------------------------------------------------------
  # ○ RP Growth effect by sorting
  #     param   : Distribution destination parameter
  #     reverse : When it is an inverse function true
  #--------------------------------------------------------------------------
  def rp_growth_effect(param, reverse = false)
    gain = gain_parameter(param)
    return if gain == nil  # Invalid parameter

    if reverse
      return if distributed_count(param) == 0  # Inverse addition is not
    else
      return unless can_distribute?(param)
    end

    gain_distributed_count(param, reverse ? -1 : 1)
    restore_distribution_values
  end
  #--------------------------------------------------------------------------
  # ○ Parameter allocation availability determination
  #     param : Distribution destination parameter
  #--------------------------------------------------------------------------
  def can_distribute?(param)
    gain = gain_parameter(param)
    return false if gain == nil                        # Invalid parameter
    return false if self.rp < distribute_cost(param)   # RP Lack
    if gain.limit > 0
      return false if gain.limit <= distributed_count(param)  # Maximum number of times
    end

    return true
  end
  #--------------------------------------------------------------------------
  # ○ Parameter allocation cost calculation
  #     param : Distribution destination parameter
  #--------------------------------------------------------------------------
  def distribute_cost(param)
    gain = gain_parameter(param)
    return 0 if gain == nil  # Invalid parameter

    n = gain.cost
    count = distributed_count(param)
    count = [count, gain.limit - 1].min if gain.limit > 0
    n += gain.cost_rev * count
    return [Integer(n), 0].max
  end
  #--------------------------------------------------------------------------
  # ○ Increase calculation after parameter assignment
  #     param : Distribution destination parameter
  #     amt   : Distribution number
  #--------------------------------------------------------------------------
  def distribute_gain(param, amt = 1)
    gain = gain_parameter(param)

    # Invalid parameter
    return 0 if gain == nil

    result = {}
    KMS_DistributeParameter::PARAMS.each { |par|
      result[par] = distributed_param(par)
    }

    # Not able to sort
    if amt > 0
      return result if gain.limit > 0 && gain.limit == distributed_count(param)
    else
      return result if distributed_count(param) + amt < 0
    end

    last_hp = self.hp
    last_mp = self.mp
    last_count = distributed_count(param)
    rp_growth_effect(param)
    KMS_DistributeParameter::PARAMS.each { |par|
      result[par] = distributed_param(par) if gain.params.include?(par)
    }
    rp_growth_effect(param, true) if last_count < distributed_count(param)
    self.hp = last_hp
    self.mp = last_mp

    return result
  end
end

#★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★

#==============================================================================
# ■ Window_Base
#==============================================================================

class Window_Base < Window
  #--------------------------------------------------------------------------
  # ○ RP Get text color of
  #     actor : Actor
  #--------------------------------------------------------------------------
  def rp_color(actor)
    return (actor.rp == 0 ? knockout_color : normal_color)
  end
  #--------------------------------------------------------------------------
  # ○ Acquisition of color 1 of sorting gauge
  #--------------------------------------------------------------------------
  def distribute_gauge_color1
    color = KMS_DistributeParameter::GAUGE_START_COLOR
    return (color.is_a?(Integer) ? text_color(color) : color)
  end
  #--------------------------------------------------------------------------
  # ○ Acquisition of color 2 of sorting gauge
  #--------------------------------------------------------------------------
  def distribute_gauge_color2
    color = KMS_DistributeParameter::GAUGE_END_COLOR
    return (color.is_a?(Integer) ? text_color(color) : color)
  end
  #--------------------------------------------------------------------------
  # ○ RP Drawing
  #     actor : Actor
  #     x     : Destination X coordinate
  #     y     : Destination Y coordinate
  #     width : width
  #--------------------------------------------------------------------------
  def draw_actor_rp(actor, x, y, width = 124)
    change_color(system_color)
    draw_text(x, y, 30, line_height, Vocab::rp_a)
    draw_current_and_max_values(x, y, width, actor.rp, actor.mrp,
      rp_color(actor), normal_color)
    change_color(normal_color)
  end
  #--------------------------------------------------------------------------
  # ○ Drawing of distribution gauge
  #     actor : Actor
  #     param : Parameters
  #     x     : Destination X coordinate
  #     y     : Destination Y coordinate
  #     width : width
  #--------------------------------------------------------------------------
  def draw_actor_distribute_gauge(actor, param, x, y, width = 124)
    gain = actor.gain_parameter(param)
    return if gain == nil || gain.limit <= 0

    rate = actor.distributed_count(param) * 1.0 / gain.limit
    if $kms_imported["GenericGauge"] &&
        KMS_DistributeParameter::ENABLE_GENERIC_GAUGE
      # General purpose gauge
      draw_generic_gauge(KMS_DistributeParameter::GAUGE_IMAGE,
        x, y, width, rate,
        KMS_DistributeParameter::GAUGE_OFFSET,
        KMS_DistributeParameter::GAUGE_LENGTH,
        KMS_DistributeParameter::GAUGE_SLOPE)
    else
      # Default gauge
      gc1  = distribute_gauge_color1
      gc2  = distribute_gauge_color2
      draw_gauge(x, y, width, rate, gc1, gc2)
    end
  end
end

#★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★

#==============================================================================
# ■ Window_MenuCommand
#==============================================================================

class Window_MenuCommand < Window_Command
  if KMS_DistributeParameter::USE_MENU_DISTRIBUTE_PARAMETER_COMMAND &&
      !$kms_imported["CustomMenuCommand"]
    #--------------------------------------------------------------------------
    # ● Create command list
    #--------------------------------------------------------------------------
    alias make_command_list_KMS_DistributeParameter make_command_list
    def make_command_list
      make_command_list_KMS_DistributeParameter

      add_distribute_parameter_command
    end
  end
  #--------------------------------------------------------------------------
  # ○ Add distribution command to list
  #--------------------------------------------------------------------------
  def add_distribute_parameter_command
    add_command(Vocab::distribute_parameter,
      :distribute_parameter,
      distribute_parameter_enabled)
  end
  #--------------------------------------------------------------------------
  # ○ Acquire parameter validation status
  #--------------------------------------------------------------------------
  def distribute_parameter_enabled
    return true
  end
end

#★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★

#==============================================================================
# □ Window_DistributeParameterActor
#------------------------------------------------------------------------------
#   It is the window that displays information on actors on the screen.
#==============================================================================

class Window_DistributeParameterActor < Window_Base
  #--------------------------------------------------------------------------
  # ○ Public instance variable
  #--------------------------------------------------------------------------
  attr_accessor :actor
  #--------------------------------------------------------------------------
  # ● Object initialization
  #     x     : X coordinate of window
  #     y     : Y coordinate of window
  #     actor : Actor
  #--------------------------------------------------------------------------
  def initialize(x, y, actor)
    super(x, y, Graphics.width, line_height + 32)
    @actor = actor
    refresh
  end
  #--------------------------------------------------------------------------
  # ● refresh
  #--------------------------------------------------------------------------
  def refresh
    contents.clear
    draw_actor_name(@actor, 4, 0)
    draw_actor_level(@actor, 140, 0)
    draw_actor_rp(@actor, 240, 0)
  end
end

#★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★

#==============================================================================
# □ Window_DistributeParameterList
#------------------------------------------------------------------------------
#   In the sort screen, you can select parameters to grow.
#==============================================================================

class Window_DistributeParameterList < Window_Selectable
  #--------------------------------------------------------------------------
  # ○ Public instance variable
  #--------------------------------------------------------------------------
  attr_accessor :actor
  #--------------------------------------------------------------------------
  # ● Object initialization
  #     actor : Actor
  #--------------------------------------------------------------------------
  def initialize(actor)
    off_h = line_height + 32
    super(0, off_h, 286, Graphics.height - off_h)
    @actor = actor
    refresh
    self.index = 0
  end
  #--------------------------------------------------------------------------
  # ○ Get Symbol of selected parameter
  #--------------------------------------------------------------------------
  def parameter_key
    return @data[self.index]
  end
  #--------------------------------------------------------------------------
  # ● Retrieve the number of items
  #--------------------------------------------------------------------------
  def item_max
    return @data == nil ? 0 : @data.size
  end
  #--------------------------------------------------------------------------
  # ● 1 Retrieve the number of rows that can be displayed on the page
  #--------------------------------------------------------------------------
  def page_row_max
    return super - 1
  end
  #--------------------------------------------------------------------------
  # ● Fetching shapes to draw items
  #     index : Item Number
  #--------------------------------------------------------------------------
  def item_rect(index)
    rect = super(index)
    rect.y += line_height
    return rect
  end
  #--------------------------------------------------------------------------
  # ● Move cursor one page backward
  #--------------------------------------------------------------------------
  def cursor_pagedown
    return if Input.repeat?(Input::R)
    super
  end
  #--------------------------------------------------------------------------
  # ● Move cursor one page forward
  #--------------------------------------------------------------------------
  def cursor_pageup
    return if Input.repeat?(Input::L)
    super
  end
  #--------------------------------------------------------------------------
  # ● refresh
  #--------------------------------------------------------------------------
  def refresh
    @gain_list = @actor.gain_parameter_list
    @data = []
    @gain_list.each { |gain| @data << gain.key }
    @item_max = @data.size + 1
    create_contents
    @item_max -= 1
    draw_caption
    @item_max.times { |i| draw_item(i, @actor.can_distribute?(@data[i])) }
  end
  #--------------------------------------------------------------------------
  # ○ Draw headings
  #--------------------------------------------------------------------------
  def draw_caption
    change_color(system_color)
    draw_text(  4, 0, 96, line_height, "Parameters")
    draw_text(120, 0, 40, line_height, Vocab.rp, 2)
    draw_text(170, 0, 80, line_height, "Upgrades", 2)
    change_color(normal_color)
  end
  #--------------------------------------------------------------------------
  # ○ Drawing items
  #     index   : Item Number
  #     enabled : Valid flag
  #--------------------------------------------------------------------------
  def draw_item(index, enabled = true)
    rect = item_rect(index)
    contents.clear_rect(rect)
    item = @data[index]
    if item != nil
      draw_parameter(rect.x, rect.y, @data[index], enabled)
    end
  end
  #--------------------------------------------------------------------------
  # ○ Draw ability score
  #     x       : Destination X coordinate
  #     y       : Destination Y coordinate
  #     param   : Distribution destination
  #     enabled : Valid flag
  #--------------------------------------------------------------------------
  def draw_parameter(x, y, param, enabled)
    gain = @gain_list.find { |v| v.key == param }
    return if gain == nil

    change_color(normal_color)
    contents.font.color.alpha = enabled ? 255 : 128
    draw_text(x + 4, y, 96, line_height, gain.name)

    # Cost drawing
    value = @actor.distribute_cost(param)
    draw_text(x + 120, y, 40, line_height, value, 2)

    # Drawing number of sorting
    if gain.limit > 0
      value = sprintf("%3d/%3d", @actor.distributed_count(param), gain.limit)
    else
      value = sprintf("%3d%s", @actor.distributed_count(param),
        KMS_DistributeParameter::HIDE_MAX_COUNT_INFINITE ? "" : "/---")
    end
    draw_actor_distribute_gauge(@actor, param, x + 170, y, 80)
    draw_text(x + 170, y, 80, line_height, value, 2)

    change_color(normal_color)
  end
  #--------------------------------------------------------------------------
  # ● Handling process such as decision and cancellation
  #--------------------------------------------------------------------------
  def process_handling
    super
    call_handler(:increase) if handle?(:increase) && Input.repeat?(:RIGHT)
    call_handler(:decrease) if handle?(:decrease) && Input.repeat?(:LEFT)
    call_handler(:up)       if handle?(:up)       && Input.repeat?(:UP)
    call_handler(:down)     if handle?(:down)     && Input.repeat?(:DOWN)
  end
end

#★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★

#==============================================================================
# □ Window_DistributeParameterStatus
#------------------------------------------------------------------------------
#   This window displays the status of the actor on the sort screen.
#==============================================================================

class Window_DistributeParameterStatus < Window_Base
  #--------------------------------------------------------------------------
  # ○ Public instance variable
  #--------------------------------------------------------------------------
  attr_accessor :actor
  #--------------------------------------------------------------------------
  # ● Object initialization
  #     actor : Actor
  #--------------------------------------------------------------------------
  def initialize(actor)
    dx = 286
    off_h = line_height + 32
    super(dx, off_h, Graphics.width - dx, Graphics.height - off_h)
    @actor = actor
    refresh(actor.gain_parameter_list[0].key)
  end
  #--------------------------------------------------------------------------
  # ● refresh
  #--------------------------------------------------------------------------
  def refresh(param = nil)
    @distribute_gain = nil
    if param != nil
      @distribute_gain = @actor.distribute_gain(param)
    end

    contents.clear
#    change_color(system_color)
#    draw_text(0, 0, width - 32, line_height, "パラメータ変化", 1)
#    change_color(normal_color)
#
#    dy = line_height
    dy = 0
    KMS_DistributeParameter::PARAMS.each { |param|
      draw_parameter(0, dy, param)
      dy += line_height
    }
  end
  #--------------------------------------------------------------------------
  # ○ Draw ability score
  #     x    : Destination X coordinate
  #     y    : Destination YX coordinate
  #     type : Types of ability values
  #--------------------------------------------------------------------------
  def draw_parameter(x, y, type)
    is_float = false

    case type
    when :mhp
      name  = Vocab.hp
      value = @actor.mhp
    when :mmp
      name  = Vocab.mp
      value = @actor.mmp
    when :atk
      name  = Vocab.param(2)
      value = @actor.atk
    when :def
      name  = Vocab.param(3)
      value = @actor.def
    when :mat
      name  = Vocab.param(4)
      value = @actor.mat
    when :mdf
      name  = Vocab.param(5)
      value = @actor.mdf
    when :agi
      name  = Vocab.param(6)
      value = @actor.agi
    when :luk
      name  = Vocab.param(7)
      value = @actor.luk
    when :hit
      name  = Vocab.hit
      value = @actor.hit
      is_float = true
    when :eva
      name  = Vocab.eva
      value = @actor.eva
      is_float = true
    when :cri
      name  = Vocab.cri
      value = @actor.cri
      is_float = true
    when :skill_speed
      name  = Vocab.skill_speed
      value = @actor.distributed_param(type)
    when :item_speed
      name  = Vocab.item_speed
      value = @actor.distributed_param(type)
    when :tgr
      name  = Vocab.tgr
      value = @actor.tgr
      is_float = true
    else
      return
    end

    # Parameter name
    change_color(system_color)
    draw_text(x + 4, y, 96, line_height, name)
    change_color(normal_color)
    draw_text(x + 106, y, 48, line_height, convert_value(value, is_float), 2)

    return if @distribute_gain == nil

    # Parameter change
    draw_text(x + 154, y, 16, line_height, "→", 1)

    curr = @actor.distributed_param(type)
    gain = @distribute_gain[type]
    change_color(gain > curr ? text_color(3) : gain < curr ?
        text_color(2) : normal_color)
    new_value = value + (gain - curr)
    draw_text(x + 174, y, 48, line_height, convert_value(new_value, is_float), 2)

    change_color(normal_color)
  end
  def convert_value(value, is_float)
    if is_float
      return sprintf("%.2f", value)
    else
      return value.to_i.to_s
    end
  end
end

#★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★

#==============================================================================
# □ Window_DistributeParameterConfirm
#------------------------------------------------------------------------------
#   This window is used to select finalization / cancellation of sorting on the sort screen.
#==============================================================================

class Window_DistributeParameterConfirm < Window_Command
  #--------------------------------------------------------------------------
  # ● Get window width
  #--------------------------------------------------------------------------
  def window_width
    return KMS_DistributeParameter::CONFIRM_WIDTH
  end
  #--------------------------------------------------------------------------
  # ● Create command list
  #--------------------------------------------------------------------------
  def make_command_list
    super
    add_command(KMS_DistributeParameter::CONFIRM_COMMANDS[0], :decide)
    add_command(KMS_DistributeParameter::CONFIRM_COMMANDS[1], :stop)
    add_command(KMS_DistributeParameter::CONFIRM_COMMANDS[2], :cancel)
  end
  #--------------------------------------------------------------------------
  # ● Help text update
  #--------------------------------------------------------------------------
  def update_help
    text = index >= 0 ? KMS_DistributeParameter::CONFIRM_COMMAND_HELP[index] : nil
    @help_window.set_text(text)
  end
end

#★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★

#==============================================================================
# ■ Scene_Map
#==============================================================================

class Scene_Map < Scene_Base
  #--------------------------------------------------------------------------
  # ● Updates related to scene transitions
  #--------------------------------------------------------------------------
  alias update_scene_KMS_DistributeParameter update_scene
  def update_scene
    update_scene_KMS_DistributeParameter

    update_call_distribute_parameter unless scene_changing?
  end
  #--------------------------------------------------------------------------
  # ○ Parameter assignment screen call determination
  #--------------------------------------------------------------------------
  def update_call_distribute_parameter
    if $game_temp.call_distribute_parameter && !$game_player.moving?
      $game_temp.call_distribute_parameter = false
      call_distribute_parameter
    end
  end
  #--------------------------------------------------------------------------
  # ○ Switch to parameter allocation screen
  #--------------------------------------------------------------------------
  def call_distribute_parameter
    SceneManager.call(Scene_DistributeParameter)
  end
end

#★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★

#==============================================================================
# ■ Scene_Menu
#==============================================================================

class Scene_Menu < Scene_MenuBase
  #--------------------------------------------------------------------------
  # ● Create Command Window
  #--------------------------------------------------------------------------
  alias create_command_window_KMS_DistributeParameter create_command_window
  def create_command_window
    create_command_window_KMS_DistributeParameter

    @command_window.set_handler(:distribute_parameter, method(:command_personal))
  end
  #--------------------------------------------------------------------------
  # ○ Command [Parameter assignment]
  #--------------------------------------------------------------------------
  def command_distribute_parameter
    SceneManager.call(Scene_DistributeParameter)
  end
  #--------------------------------------------------------------------------
  # ● Personal command [decision]
  #--------------------------------------------------------------------------
  alias on_personal_ok_KMS_DistributeParameter on_personal_ok
  def on_personal_ok
    on_personal_ok_KMS_DistributeParameter

    if @command_window.current_symbol == :distribute_parameter
      command_distribute_parameter
    end
  end
end

#★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★

#==============================================================================
# □ Scene_DistributeParameter
#------------------------------------------------------------------------------
#   It is a class that performs processing of parameter allocation screen.
#==============================================================================

class Scene_DistributeParameter < Scene_MenuBase
  #--------------------------------------------------------------------------
  # ● Start processing
  #--------------------------------------------------------------------------
  def start
    super
    @prev_actor = @actor
    @prev_info  = @actor.distribution_info
    create_help_window
    create_actor_window
    create_parameter_window
    create_status_window
    create_confirm_window
  end
  #--------------------------------------------------------------------------
  # ○ Create actor window
  #--------------------------------------------------------------------------
  def create_actor_window
    @actor_window = Window_DistributeParameterActor.new(0, 0, @actor)
    @actor_window.viewport = @viewport
  end
  #--------------------------------------------------------------------------
  # ○ Create parameter list window
  #--------------------------------------------------------------------------
  def create_parameter_window
    @parameter_window = Window_DistributeParameterList.new(@actor)
    @parameter_window.viewport = @viewport
    @parameter_window.activate
    @parameter_window.set_handler(:ok,       method(:on_parameter_ok))
    @parameter_window.set_handler(:cancel,   method(:on_parameter_cancel))
    @parameter_window.set_handler(:increase, method(:on_parameter_increase))
    @parameter_window.set_handler(:decrease, method(:on_parameter_decrease))
    @parameter_window.set_handler(:down,     method(:update_status))
    @parameter_window.set_handler(:up,       method(:update_status))
    @parameter_window.set_handler(:pagedown, method(:next_actor))
    @parameter_window.set_handler(:pageup,   method(:prev_actor))
  end
  #--------------------------------------------------------------------------
  # ○ Create distribution status window
  #--------------------------------------------------------------------------
  def create_status_window
    @status_window = Window_DistributeParameterStatus.new(@actor)
    @status_window.viewport = @viewport

    @help_window.z = @status_window.z + 100
    @help_window.openness = 0
  end
  #--------------------------------------------------------------------------
  # ○ Create confirmation window
  #--------------------------------------------------------------------------
  def create_confirm_window
    @confirm_window = Window_DistributeParameterConfirm.new(0, 0)
    @confirm_window.x = (Graphics.width  - @confirm_window.width)  / 2
    @confirm_window.y = (Graphics.height - @confirm_window.height) / 2
    @confirm_window.z = @help_window.z
    @confirm_window.viewport    = @viewport
    @confirm_window.help_window = @help_window
    @confirm_window.openness    = 0
    @confirm_window.deactivate
    @confirm_window.set_handler(:decide, method(:on_confirm_decide))
    @confirm_window.set_handler(:stop,   method(:on_confirm_stop))
    @confirm_window.set_handler(:cancel, method(:on_confirm_cancel))
  end
  #--------------------------------------------------------------------------
  # ○ Window redraw
  #--------------------------------------------------------------------------
  def refresh_window
    @actor_window.refresh
    @parameter_window.refresh
    @status_window.refresh(@parameter_window.parameter_key)
    Graphics.frame_reset
  end
  #--------------------------------------------------------------------------
  # ○ Parameter selection [Determine]
  #--------------------------------------------------------------------------
  def on_parameter_ok
    command_confirm
  end
  #--------------------------------------------------------------------------
  # ○ Parameter selection [Cancel]
  #--------------------------------------------------------------------------
  def on_parameter_cancel
    command_confirm
  end
  #--------------------------------------------------------------------------
  # ○ Parameter selection [Addition]
  #--------------------------------------------------------------------------
  def on_parameter_increase
    param = @parameter_window.parameter_key
    unless @actor.can_distribute?(param)
      Sound.play_buzzer
      return
    end
    Sound.play_cursor
    @actor.rp_growth_effect(param)
    refresh_window
  end
  #--------------------------------------------------------------------------
  # ○ Parameter selection [subtraction]
  #--------------------------------------------------------------------------
  def on_parameter_decrease
    param = @parameter_window.parameter_key
    unless reversible?(param)
      Sound.play_buzzer
      return
    end
    Sound.play_cursor
    @actor.rp_growth_effect(param, true)
    refresh_window
  end
  #--------------------------------------------------------------------------
  # ○ Status update
  #--------------------------------------------------------------------------
  def update_status
    @status_window.refresh(@parameter_window.parameter_key)
  end
  #--------------------------------------------------------------------------
  # ○ Subtractability judgment
  #     param : Target parameters
  #--------------------------------------------------------------------------
  def reversible?(param)
    return false if @actor.distributed_count(param) == 0
    return true  if KMS_DistributeParameter::ENABLE_REVERSE_DISTRIBUTE

    # If it does not decrease from last time OK
    base = @prev_info.count[param]
    return ( base < @actor.distributed_count(param) )
  end
  #--------------------------------------------------------------------------
  # ○ Switch to parameter window
  #--------------------------------------------------------------------------
  def command_parameter
    @confirm_window.deactivate
    @confirm_window.close
    @help_window.close
    @parameter_window.activate
  end
  #--------------------------------------------------------------------------
  # ○ Switch to confirmation window
  #--------------------------------------------------------------------------
  def command_confirm
    @status_window.refresh
    @confirm_window.index  = 0
    @confirm_window.activate
    @confirm_window.open
    @help_window.open
    @parameter_window.deactivate
  end
  #--------------------------------------------------------------------------
  # ○ Confirmation [Final]
  #--------------------------------------------------------------------------
  def on_confirm_decide
    return_scene
  end
  #--------------------------------------------------------------------------
  # ○ Confirmation [Cancel]
  #--------------------------------------------------------------------------
  def on_confirm_stop
    @actor.set_distribution_info(@prev_info)
    return_scene
  end
  #--------------------------------------------------------------------------
  # ○ Confirmation [Cancel]
  #--------------------------------------------------------------------------
  def on_confirm_cancel
    command_parameter
  end
  #--------------------------------------------------------------------------
  # ● Switching actors
  #--------------------------------------------------------------------------
  def on_actor_change
    @prev_actor.set_distribution_info(@prev_info)
    @prev_info  = @actor.distribution_info
    @prev_actor = @actor

    @actor_window.actor     = @actor
    @parameter_window.actor = @actor
    @status_window.actor    = @actor
    @parameter_window.activate
    refresh_window
  end
end