#==============================================================================
# ¥ Randomized Enemy Battlers ¥
# -- Last Updated: 4.JAN.2013
# -- Author: NAMKCOR
#
# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# ¥ Details ¥
# -- Set random battlers per enemy ID
# -- Set random hues per enemy ID
#
# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# ¥ Fun Fact ¥
# -- Without comments, this script is only 14 lines ( without config section )
#
# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# ¥ Version History ¥
# -- v1.0 (4.JAN.2013)
# :: Original Release
#
# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# ¥ Compatability and Support ¥
# -- This script was created for use with RPG Maker VX Ace.  It is unlikely
#    that it will work out of the box with RPG Maker VX.
# -- You can get support for this script by contacting NAMKCOR at RMRK.net
# -- No known compatibility issues.
#
# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# ¥ Licensed under Creative Commons BY-NC-SA 3.0 ¥
# -- Not for use in Commercial projects without explicit permission from
#    NAMKCOR.
# -- You are free to modify this work as long as you distribute it with the 
#    same license terms.
# -- Please credit NAMKCOR if used, distributed, or modified.
#
#==============================================================================

module NAMKCOR
  
  #============================================================================
  # ¥ NAMKCOR.get_enemy_battler ¥
  # -- returns the array of battler options
  # =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
  # To add a new set of random battlers, use the enemy ID from the database as
  # your when condition, then return an array of strings, where each string is
  # a battler filename.  No filetype is necessary.
  #
  # Try to keep when statements in ascending order, for ease of use.
  #============================================================================
  def self.get_enemy_battler(enemy_id)
    case enemy_id
    # -------------------------------------------------------------------------
    # Example
    # when N
    #   return ["Battler_1", "Battler_2", "Battler_3"]
    # -------------------------------------------------------------------------
    # insert new configurations below this point.
    # -------------------------------------------------------------------------
    when 1
      return ["Slime", "Snake", "Soldier"]
    else
      return "ORIGINAL"
    end
  end
  
  #============================================================================
  # ¥ NAMKCOR.get_enemy_hue ¥
  # -- returns the array of hue options
  # =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
  # To add a new set of random hues, use the enemy ID from the database as
  # your when condition, then return an array of integers, where each is a
  # number from 0 to 255, being the hue variation.
  #
  # Try to keep when statements in ascending order, for ease of use.
  #============================================================================
  def self.get_enemy_hue(enemy_id)
    case enemy_id
    # -------------------------------------------------------------------------
    # Example
    # when N
    #   return [100, 150, 75]
    # -------------------------------------------------------------------------
    # insert new configurations below this point.
    # -------------------------------------------------------------------------
    when 1
      return [255, 23, 15, 100, 75]
    else
      return "ORIGINAL"
    end
  end
  
end

#==============================================================================
# DO NOT EDIT BELOW THIS LINE UNLESS YOU KNOW WHAT YOU ARE DOING
#==============================================================================

class Game_Enemy < Game_Battler
  
  alias :_old_init :initialize
  
  def initialize(index, enemy_id)
    # call original initialize
    _old_init(index, enemy_id)
    
    # override battler image with random selections
    @battler_options = NAMKCOR.get_enemy_battler(@enemy_id)
    # only if the battler isn't set to use the original method
    if @battler_options != "ORIGINAL"
      @battler_name = @battler_options[rand(@battler_options.length)]
    end
     
    # override battler hue with random selections
    @battler_hues = NAMKCOR.get_enemy_hue(@enemy_id)
    # only if the battler isn't set to use the original method
    if @battler_hues != "ORIGINAL"
      @battler_hue = @battler_hues[rand(@battler_hues.length)]
    end
  end
  
end