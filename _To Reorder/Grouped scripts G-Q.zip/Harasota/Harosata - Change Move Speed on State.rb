# Harosata - change move speed on state inflicted

class Game_Player < Game_Character
  def real_move_speed
    c = @move_speed + (dash? ? 1 : 0)
    c -= 1 if actor.state?(13) #or your number for sticky
    return c
  end
end