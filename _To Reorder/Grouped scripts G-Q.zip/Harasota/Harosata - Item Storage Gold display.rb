#Addon: Convert Gold to GSC standard
class Window_ItemStorageRight  < Window_ItemList
  def draw_item_name(item, x, y, enabled = true, width = 172)
    return unless item
    if item != :gold
      draw_icon(item.icon_index, x, y, enabled)
      change_color(normal_color, enabled)
      draw_text(x + 24, y, width, line_height, item.name)
    end
  end
 
  def draw_item_number(rect, item)
    if item != :gold
      draw_text(rect, sprintf(":%2d", $game_boxes.item_number(item, @box_id)), 2)
    else
      draw_currency_value($game_boxes.item_number(item, @box_id), "", rect.x, rect.y, rect.width)
    end
  end
end