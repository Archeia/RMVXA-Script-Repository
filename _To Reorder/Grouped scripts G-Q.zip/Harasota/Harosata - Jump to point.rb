#(jump by distance, x, y)
#Script Call:
$game_player.jump($game_variables[1], $game_variables[2])

#(jump by distance, one direction)
#Script Call:
case $game_player.direction
  when 2
    $game_player.jump(0, $game_variables[1])
  when 4
    $game_player.jump(-$game_variables[1], 0)
  when 6
    $game_player.jump($game_variables[1], 0)
  when 8
    $game_player.jump(0, -$game_variables[1])
end

#(jump to point)
#Script Call:
dx = $game_variables[1] - $game_player.x
dy = $game_variables[2] - $game_player.y
$game_player.jump(dx, dy)