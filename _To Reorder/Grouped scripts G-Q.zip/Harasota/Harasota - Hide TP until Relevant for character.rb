module DL
  module Trance_Skill
    NoTPDisplay = 30 #Garnet's Shock state, no TP display
    Regex = /<TranceID:\s*(\d+)\s*>/i
  end
end

module RPG
  class BaseItem
    def trance_skill
      load_notetag_enemy_class unless @class_id
      return @class_id
    end
  
    def load_notetag_enemy_class
     trance_id = 0
      if self.note =~ DL::Trance_Skill::Regex
        trance_id = $1.to_i
      end
     return trance_id
    end
  end
end

class Game_Actor < Game_Battler
  def skill_trance_check?  #use <TranceID: X> to show TP when you have that skill
    trance_skill_id = actor.trance_id
    return true if trance_skill_id  > 0 and skills.include? trance_skill_id
    return false
  end
end

class Window_BattleStatus < Window_Selectable

  def draw_gauge_area(rect, actor)
    if trance_display(actor)
      draw_gauge_area_with_tp(rect, actor)
    else
      draw_gauge_area_without_tp(rect, actor)
    end
  end

  def trance_display(actor)
    return false unless $data_system.opt_display_tp
    return false if actor.state?(DL::Trance_Skill::NoTPDisplay)
    return actor.skill_trance_check?
  end

end