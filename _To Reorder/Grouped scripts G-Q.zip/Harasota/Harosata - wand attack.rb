class Game_Actor < Game_Battler
  def attack_skill_id
    if id == 1 #id of wand user, in case other characters use wands as whacking sticks
      if weapons.include?($data_weapons[14]) # A Fire II Wand
        return 52
      end
      if weapons.include?($data_weapons[15]) # A Fire-Ice-Thunder Wand
        random_attack_skill = rand(3)
        return 51 if random_attack_skill == 0
        return 55 if random_attack_skill == 1
        return 59 if random_attack_skill == 2
      end
      if weapons.include?($data_weapons[16]) # A Flame Wand.  Attack all enemies even if you "select" a single one.
        return 53
      end
    end
    return 1 # default attack, in case you're a regular fighter or not properly equipped.
  end
end