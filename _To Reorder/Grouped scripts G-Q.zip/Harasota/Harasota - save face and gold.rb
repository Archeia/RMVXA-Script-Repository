module DataManager
def self.make_save_header
  header = {}
  header[:faces] = $game_party.faces_for_savefile
  header[:gold] = $game_party.gold
  header[:playtime_s] = $game_system.playtime_s
  header
end
end

class Game_Party
def faces_for_savefile
  battle_members.collect do |actor|
    [actor.face_name, actor.face_index]
  end
end
end

class Window_SaveFile < Window_Base
def refresh
  contents.clear
  change_color(normal_color)
  name = Vocab::File + " #{@file_index + 1}"
  draw_text(4, 0, 200, line_height, name)
  @name_width = text_size(name).width
  draw_party_faces(100, 0)
  draw_playtime(0, contents.height - line_height, contents.width - 4, 2)
draw_gold(0, contents.height - (line_height* 2), contents.width - 4)
end

def draw_party_faces(x, y)
  header = DataManager.load_header(@file_index)
  return unless header
  header[:faces].each_with_index do |data, i|
    draw_face(data[0], data[1], x + i * 96, y)
  end
end

def draw_gold(x, y, width)
  header = DataManager.load_header(@file_index)
  return unless header
  draw_currency_value(header[:gold], Vocab::currency_unit, x, y, width)
end

end