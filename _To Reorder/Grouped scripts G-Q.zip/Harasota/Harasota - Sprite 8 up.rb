# Harasota use '&' at the beginning of the filename to make sprites align up 8 pixels
class Game_CharacterBase
  def up_character?
    @character_name[0, 1] == '&'
  end

  def shift_y
    bob = 4
    bob = 0 if object_character?
    bob = 8 if up_character?
    return bob
  end
end