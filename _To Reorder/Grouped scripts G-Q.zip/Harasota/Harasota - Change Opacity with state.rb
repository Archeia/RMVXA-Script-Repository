class Sprite_Battler < Sprite_Base
  alias dl_update_effect update_effect #alias means run this method on top of the originial
  def update_effect
    if @battler.state?(GHOST) #Change this to your state id
      self.opacity = 100 #Opacity is 0-255
    else #If you don't have this state, return opacity to normal
      self.opacity = 255
    end
    dl_update_effect #This alias nickname runs the original update_effect
  end
end