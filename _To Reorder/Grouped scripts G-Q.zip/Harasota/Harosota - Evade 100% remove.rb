=begin
Here's my idea how it works. The first method is used to determine the chance to evade,
so if you have the 100% evade state, it will remove the state and return 1 
(highest in rand). The second method will call a common event I believe, 
but if you're planning to use the Troop Page, you can replace the common event 
reservation with a $game_switches[EVADECE] = true (Remember to turn off switch in page)
=end 
module CEevade
# Common event number
EVADECE = 1
# State for evasion
FULLEVADE = 2
end

class Game_Battler < Game_BattlerBase
  alias :dl_100_item_eva :item_eva
  def item_eva(user, item)
    if state?(CEevade::FULLEVADE) #Change these two to your evade state
      remove_state(CEevade::FULLEVADE)
      return 1
    end
    return dl_100_item_eva(user, item)
  end

  alias :dl_100_item_apply :item_apply
  def item_apply(user, item)
    dl_100_item_apply(user, item)
     #Change EVADECE to Common Event ID
   $game_temp.reserve_common_event(CEevade::EVADECE) if @result.evaded
   end
end