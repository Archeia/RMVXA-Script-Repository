class Game_BattlerBase
def refresh
    state_resist_set.each {|state_id| erase_state(state_id) }
    @hp = [[@hp, mhp].min, 0].max
    @mp = [[@mp, mmp].min, 0].max
    if @hp == 0
      if state?(2)
        remove_state(2)
        remove_state(death_state_id)
        @hp = (mhp * 0.3).to_i
      else
        add_state(death_state_id)
      end
    else
      remove_state(death_state_id)
    end
  end
end