=begin
#==============================================================================#
#   AMN DQ Battle Addon
#   Version 1.02
#   Author: AMoonlessNight
#   Date: 09 Dec 2018
#   Latest: 10 Dec 2018
#==============================================================================#
#   UPDATE LOG
#------------------------------------------------------------------------------#
# 09 Dec 2018 - created the script
# 10 Dec 2018 - fixed a couple of bugs
#==============================================================================#
#   TERMS OF USE
#------------------------------------------------------------------------------#
# - Please credit AMoonlessNight or A-Moonless-Night
# - Free for non-commercial use
# - I'd love to see your game if you end up using one of my scripts
#==============================================================================#

This script updates the battle scene from Jamiras843 Dragon Quest Battle script,
changing the position of certain windows and changing the way some information
is drawn.

You can choose whether to draw icons in skill and item lists in the editable
region below.

All windows now open and close instantly, no fade-in/-out transition.

=end
module AMN_DQ_Battle
#==============================================================================
# ** EDITABLE REGION BELOW
#------------------------------------------------------------------------------
#  Change the values in the area below to suit your needs.
#==============================================================================

  Icons_On = false  # whether to draw icons in item and skill lists
 
#==============================================================================
# ** END OF EDITABLE REGION
#------------------------------------------------------------------------------
#  Please do not edit below this point unless you know what you are doing.
#==============================================================================
end

class Window_Base < Window
 
  def update_open
    self.openness += 255
    @opening = false if open?
  end

  def update_close
    self.openness -= 255
    @closing = false if close?
  end
 
  alias amn_dqbattle_windowbase_drawitemname  draw_item_name
  def draw_item_name(item, x, y, enabled = true, width = 172)
    if AMN_DQ_Battle::Icons_On
      amn_dqbattle_windowbase_drawitemname(item, x, y, enabled, width)
    else
      return unless item
      change_color(normal_color, enabled)
      draw_text(x, y, width, line_height, item.name)
    end
  end
end

class Window_Selectable < Window_Base

  def item_rect_for_text(index)
    rect = item_rect(index)
    rect.x += 10
    rect.width -= 20
    rect
  end
 
end

class Window_BattleActor < Window_BattleStatus
 
  def visible_line_number; item_max; end
  def show; select(0) if @info_viewport; super; end
  def hide; super; end
  def window_width; 170; end
 
  def draw_item(index)
    actor = $game_party.battle_members[index]
    draw_actor_name(actor, 10, line_height * index)
  end
 
end

class Window_BattleEnemy < Window_Selectable
  def col_max; return 1; end

  def initialize(info_viewport)
    super(250, 296, Graphics.width - 250, fitting_height(4))
    refresh
    self.visible = false
  end
 
  # def deactivate
    # super
  # end
 
end

class Window_DQ_BattleStatus < Window_Base

  def initialize
    super(100, 0, 112 * [$game_party.members.size, 4].min, 120)  
    create_contents    
    @actor1 = $game_party.members[0]    
    @actor2 = $game_party.members[1]    
    @actor3 = $game_party.members[2]    
    @actor4 = $game_party.members[3]    
    refresh    
    self.openness = 0
    self.arrows_visible = false
  end
 
  def draw_actor_info(actor, x, y, width)
    draw_face(actor.face_name, actor.face_index, x, y, false) if Jami_DQ_Battle::SHOW_FACE
    draw_actor_name(actor, x, y)
    draw_actor_hp(actor, x, y+24, width)
    draw_actor_mp(actor, x, y+44, width)
    draw_actor_level(actor, x, y+64)
    draw_actor_icons(actor, x+60, y)
  end
 
  def draw_window_content
    draw_actor_info(@actor1, 0, 0, 80)
    draw_actor_info(@actor2, 110, 0, 80) if $game_party.members.size > 1
    draw_actor_info(@actor3, 220, 0, 80) if $game_party.members.size > 2
    draw_actor_info(@actor4, 330, 0, 80) if $game_party.members.size > 3
  end
end

class Window_ActorCommand < Window_Command
  def spacing; return 6; end
  def visible_line_number; return 3; end
  def window_width; return 250; end
   
  alias amn_dqbattle_windowactorcmd_init  initialize
  def initialize
    amn_dqbattle_windowactorcmd_init
    self.opacity = 0
  end
 
end

class Window_ActorDummy < Window_Base
  def initialize
    super(0, 0, 250, fitting_height(visible_line_number))
    self.openness = 0
    @actor = nil
  end

  def visible_line_number; return 4; end

  def draw_actor_details
    return unless @actor
    draw_text(0, 0, contents_width, line_height, @actor.name, 1)
    draw_horz_line(12)
  end

  def draw_horz_line(y)
    line_y = y + line_height / 2 - 1
    contents.fill_rect(0, line_y, contents_width, 2, normal_color)
  end
 
  def setup(actor)
    @actor = actor
    contents.clear
    draw_actor_details
    open
  end
end

class Window_BattleItem < Window_ItemList
  def col_max; return 1; end
   
  def initialize(help_window, info_viewport)
    height = fitting_height(4)
    hww = help_window.width
    super(0, Graphics.height - height, Graphics.width - hww, height)
    self.visible = false
    @help_window = help_window
    @info_viewport = info_viewport
  end
 
  def draw_item(index)
    item = @data[index]
    if item
      rect = item_rect(index)
      rect.width -= 8
      draw_item_name(item, rect.x+10, rect.y, enable?(item))
      draw_item_number(rect, item)
    end
  end
 
end

class Window_BattleSkill < Window_SkillList
  attr_reader :actor
  def col_max; return 1; end
 
  def initialize(help_window, info_viewport)
    height = fitting_height(4)
    hww = help_window.width
    super(0, Graphics.height - height, Graphics.width - hww, height)
    self.visible = false
    @help_window = help_window
    @info_viewport = info_viewport
    @mp_window = nil
  end
 
  def mp_window=(mp_window)
    @mp_window = mp_window
  end

  def draw_item(index)
    skill = @data[index]
    if skill
      rect = item_rect(index)
      rect.width -= 8
      draw_item_name(skill, rect.x+10, rect.y, enable?(skill))
    end
  end
 
  alias amn_dqbattle_windbattleskill_show show
  def show
    @mp_window.show if @mp_window
    amn_dqbattle_windbattleskill_show
  end

  alias amn_dqbattle_windbattleskill_hide hide
  def hide
    @mp_window.hide if @mp_window
    amn_dqbattle_windbattleskill_hide
  end
 
  def update_help
    super
    @mp_window.set_item if @mp_window
  end
end

class Window_BattleSkillMP < Window_Base

  def initialize(skill_window, info_viewport)
    h = fitting_height(1)
    super(Graphics.width - 250, Graphics.height - h, 250, h)
    self.visible = false
    @info_viewport = info_viewport
    skill_window.mp_window = self
    @skill_window = skill_window
  end

  def set_text(text)
    if text != @text
      @text = text
      refresh
    end
  end

  def clear
    set_text("")
  end

  def item
    @skill_window.item
  end
 
  def actor
    @skill_window.actor
  end
 
  def set_item
    return clear if actor.nil? || item.nil?
    return clear if actor.skill_mp_cost(item).zero? && actor.skill_tp_cost(item).zero?
    if actor.skill_mp_cost(item) > 0
      set_text(sprintf("MP Cost: %d/%d", actor.skill_mp_cost(item), actor.mp))
    elsif actor.skill_tp_cost(item) > 0
      set_text(sprintf("TP Cost: %d/%d", actor.skill_tp_cost(item), actor.tp))
    end
  end

  def refresh
    contents.clear
    draw_text_ex(4, 0, @text)
  end
end

class Scene_Battle < Scene_Base
 
  alias amn_dqbattle_scenebattle_createactorcmdwind create_actor_command_window
  def create_actor_command_window
    @dummy_window = Window_ActorDummy.new
    amn_dqbattle_scenebattle_createactorcmdwind
    @actor_command_window.y = 320
    @dummy_window.y = 296
  end
 
  alias amn_dqbattle_scenebattle_createactorwind  create_actor_window
  def create_actor_window
    amn_dqbattle_scenebattle_createactorwind
    @actor_window.y -= @actor_window.height
    @actor_window.x = Graphics.width - @actor_window.width
  end
 
  alias amn_dqbattle_scenebattle_startpartycmdselect  start_party_command_selection
  def start_party_command_selection
    amn_dqbattle_scenebattle_startpartycmdselect
    unless scene_changing?  
      if BattleManager.input_start    
        @dummy_window.close
        @enemy_window.deactivate.hide
      end
    end
  end
 
  alias amn_dqbattle_scenebattle_createskillwind create_skill_window
  def create_skill_window
    amn_dqbattle_scenebattle_createskillwind
    @skill_mp_window = Window_BattleSkillMP.new(@skill_window, @info_viewport)
  end
 
  alias amn_dqbattle_scenebattle_createhelpwind create_help_window
  def create_help_window
    amn_dqbattle_scenebattle_createhelpwind
    w = 250
    hh = @help_window.height
    h = @help_window.fitting_height(4)
    @help_window.move(Graphics.width - w, Graphics.height - h, w, hh)
    @help_window.create_contents
  end
 
  alias amn_dqbattle_scenebattle_cmdfight command_fight
  def command_fight
    amn_dqbattle_scenebattle_cmdfight
    @enemy_window.deactivate.show
  end
 
  alias amn_dqbattle_scenebattle_startactorcmdselect  start_actor_command_selection
  def start_actor_command_selection
    amn_dqbattle_scenebattle_startactorcmdselect
    @dummy_window.setup(BattleManager.actor)
  end
 
  alias amn_dqbattle_scenebattle_updatemsgopen  update_message_open
  def update_message_open
    amn_dqbattle_scenebattle_updatemsgopen
    if $game_message.busy? && !@DQ_status_window.close?  
      @dummy_window.close
    end
  end

  def turn_start
    @party_command_window.close
    @actor_command_window.close
    @dummy_window.close
    @enemy_window.deactivate.hide
    @subject =  nil
    BattleManager.turn_start
    if Jami_DQ_Battle::HUD_HIDE
      @DQ_status_window.height = @DQ_status_window.fitting_height(2)
      @info_viewport.rect.height = @DQ_status_window.fitting_height(2)
    end
    @log_window.clear
  end

  def turn_end
    all_battle_members.each do |battler|  
      battler.on_turn_end  
      refresh_status  
      if Jami_DQ_Battle::HUD_HIDE
        @DQ_status_window.height = 110
        @DQ_status_window.update_padding
        @info_viewport.rect.height = @DQ_status_window.height
      end  
      @log_window.display_auto_affected_status(battler)  
      @log_window.wait_and_clear
    end
    BattleManager.turn_end
    process_event
    start_party_command_selection
  end
 
  def update_message_open
    if $game_message.busy?
      if !$game_troop.all_dead? && !@DQ_status_window.close?
        @message_window.openness = 0  
        @DQ_status_window.close
      end
      @party_command_window.close  
      @actor_command_window.close
    end
  end
 
  def on_enemy_ok
    unless @actor_command_window.visible
      @actor_command_window.show
      @dummy_window.show
    end
    case @actor_command_window.current_symbol
    when :skill
      @enemy_window.y += @enemy_window.height
    when :item
      @enemy_window.y += @enemy_window.height
    end
    BattleManager.actor.input.target_index = @enemy_window.enemy.index
    @enemy_window.hide
    @skill_window.hide
    @item_window.hide
    next_command
  end

  def on_enemy_cancel
    @enemy_window.deactivate
    case @actor_command_window.current_symbol
    when :attack
      @actor_command_window.activate
    when :skill
      @skill_window.activate
      @enemy_window.hide
    when :item
      @item_window.activate
      @enemy_window.hide
    end
  end
 
  alias amn_dqbattle_scenebattle_commandskill command_skill
  def command_skill
    amn_dqbattle_scenebattle_commandskill
    @enemy_window.deactivate.hide
    @enemy_window.y -= @enemy_window.height
    @actor_command_window.hide
    @dummy_window.hide
  end

  alias amn_dqbattle_scenebattle_commanditem command_item
  def command_item
    amn_dqbattle_scenebattle_commanditem
    @enemy_window.deactivate.hide
    @enemy_window.y -= @enemy_window.height
    @actor_command_window.hide
    @dummy_window.hide
  end
 
  alias amn_dqbattle_scenebattle_onactorok on_actor_ok
  def on_actor_ok
    unless @actor_command_window.visible
      @actor_command_window.show
      @dummy_window.show
    end
    @enemy_window.y += @enemy_window.height
    @enemy_window.deactivate.show
    amn_dqbattle_scenebattle_onactorok
  end
 
  alias amn_dqbattle_scenebattle_onskillok  on_skill_ok
  def on_skill_ok
    amn_dqbattle_scenebattle_onskillok
    @skill = @skill_window.item
    if !@skill.need_selection?
      @enemy_window.y += @enemy_window.height
      @actor_command_window.show
      @dummy_window.show
      @enemy_window.deactivate.show
    end
  end

  alias amn_dqbattle_scenebattle_onskillcancel  on_skill_cancel
  def on_skill_cancel
    amn_dqbattle_scenebattle_onskillcancel
    @enemy_window.y += @enemy_window.height
    @enemy_window.deactivate.show
    @actor_command_window.show
    @dummy_window.show
  end

  alias amn_dqbattle_scenebattle_onitemok  on_item_ok
  def on_item_ok
    amn_dqbattle_scenebattle_onitemok
    @item = @item_window.item
    if !@item.need_selection?
      @enemy_window.y += @enemy_window.height
      @actor_command_window.show
      @dummy_window.show
      @enemy_window.deactivate.show
    end
  end

  alias amn_dqbattle_scenebattle_onitemcancel  on_item_cancel
  def on_item_cancel
    amn_dqbattle_scenebattle_onitemcancel
    @enemy_window.deactivate.show
    @enemy_window.y += @enemy_window.height
    @actor_command_window.show
    @dummy_window.show
  end
 
end
class Scene_Map < Scene_Base
  def perform_transition
    if Graphics.brightness == 0
      Graphics.transition(0)
      fadein(fadein_speed)
    else
      super
    end
  end
end

class Scene_Menu < Scene_MenuBase
  def transition_speed
    return 0
  end
 
  def terminate
    super
    Graphics.transition(0)
  end
end