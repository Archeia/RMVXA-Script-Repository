#============================================================================
# [VXAce] Dragon Quest Menu V2.00
#----------------------------------------------------------------------------
# By Jamiras843
#
# Features: 
#     V2.00
#     * Fixed menu close issue
#     * Added the ability to hide HP/MP Bars
#     V1.50
#     * Fixed menu overlap issues
#     * Added charater HUD with options
#     V1.00
#     * Simplified menu layout that has adjustable columns and rows.
#     * New actor selection menu which is smaller and simpler in design.
#============================================================================
$imported = {} if $imported.nil?
$imported["Dragon Quest Menu"] = true

module Jami_DQ_Menu
 #========================================================================
 # Script options
 #------------------------------------------------------------------------
 # Here you edit menu specific things, such as height, x/y origin, column
 # number, etc.
 #
 # Make all simple edits here! They are easy to understand and labled! 
 #========================================================================
 WINDOW_OPACITY = 255 #Number 0-255 that determines window opacity
 DRAW_HP_MP_BARS = false #If true shows default RPG maker bar
 MENU_COLUMN = 2    #Number of columns for the menu
 MENU_LINE = 2      #Number of max lines for the menu
 MENU_HEIGHT = 100   #Menu height (at least 80 per line, no <80)
 MENU_WIDTH = 180   #Menu width (at least 90 per column)
 MENU_X = 0        #Menu X origin
 MENU_Y = 0         #Menu Y origin
 LOC_X = 0       #Custom location window X origin
 LOC_Y = 306 - 75          #Custom location window Y origin   
 GOLD_X = 0      #Custom gold window X origin
 GOLD_Y = 306 - 54         #Custom gold window Y origin
 #=========================================================================
 # Menu Command options
 #-------------------------------------------------------------------------
 # This is where you set up what commands you want in the menu, including
 # custom ones using common events.
 #=========================================================================
 SHOW_SAVE_CMD = false #If false removes save option from menu
 SHOW_EXIT_GAME = true #If false removes quit game option from the menu
 SHOW_FORMATION = true #If false removes the formation command
 SHOW_LOCATION = true #If true shows custom gold window w/ location
     VOCAB_LOC = "Location:"
     VOCAB_GOLD = "Gold Coins:"
 SIMPLE_STATUS = true #If true shows a list staus menu DW2,3,&4 style
 ACTOR_WINDOW = true
     SHOW_FACE = true
     SHOW_HP = true
     SHOW_MP = true
     SHOW_LEVEL = true
end #end module Jami_DQ_Menu

#============================================================================    
# WARNING: Do not edit below unless you know what you are doing. This script
# is rather sloppy but it does its job. 
#============================================================================

#============================================================================
# * DQ Window (over writes menu command window)
#============================================================================
class Window_DQ_Menu < Window_Command
 #--------------------------------------------------------------------------
 # * Object Initialization
 #--------------------------------------------------------------------------
 def initialize
       super(Jami_DQ_Menu::MENU_X, Jami_DQ_Menu::MENU_Y)
 end
 #--------------------------------------------------------------------------
 # * Get Number of Lines to Show
 #--------------------------------------------------------------------------
 def visible_line_number
       return Jami_DQ_Menu::MENU_LINE
 end
 #--------------------------------------------------------------------------
 # * Get Digit Count
 #--------------------------------------------------------------------------
 def col_max
       return Jami_DQ_Menu::MENU_COLUMN
 end
 #--------------------------------------------------------------------------
 # * Set Width
 #--------------------------------------------------------------------------
 def window_width
       return Jami_DQ_Menu::MENU_WIDTH
 end
 #--------------------------------------------------------------------------
 # * Set Height
 #--------------------------------------------------------------------------
 def window_height
       return Jami_DQ_Menu::MENU_HEIGHT
 end
 #--------------------------------------------------------------------------
 # * Create Command List
 #--------------------------------------------------------------------------
 def make_command_list
       add_main_commands
       add_formation_command
       add_game_end_command
 end
 #--------------------------------------------------------------------------
 # * Create Command List
 #--------------------------------------------------------------------------
 def make_command_list
       add_main_commands
       add_formation_command
       add_save_command
       add_game_end_command
 end
 #--------------------------------------------------------------------------
 # * Add Main Commands to List
 #--------------------------------------------------------------------------
 def add_main_commands
       add_command(Vocab::item,   :item,   main_commands_enabled)
       add_command(Vocab::skill,  :skill,  main_commands_enabled)
       add_command(Vocab::equip,  :equip,  main_commands_enabled)
       add_command(Vocab::status, :status, main_commands_enabled)
 end
 #--------------------------------------------------------------------------
 # * Add Save to Command List
 #--------------------------------------------------------------------------
 def add_save_command
       add_command(Vocab::save, :save, save_enabled) if Jami_DQ_Menu::SHOW_SAVE_CMD == true
 end
 #--------------------------------------------------------------------------
 # * Add Formation to Command List
 #--------------------------------------------------------------------------
 def add_formation_command
       add_command(Vocab::formation, :formation, formation_enabled) if Jami_DQ_Menu::SHOW_FORMATION == true
 end
 #--------------------------------------------------------------------------
 # * Add Exit Game to Command List
 #--------------------------------------------------------------------------
 def add_game_end_command
       add_command(Vocab::game_end, :game_end) if Jami_DQ_Menu::SHOW_EXIT_GAME == true
 end
 #-------------------------------------------------------------------------
 # * Get Activation State of Main Commands
 #-------------------------------------------------------------------------
 def main_commands_enabled
       $game_party.exists
 end
 #-------------------------------------------------------------------------
 # * Get Activation State of Save
 #-------------------------------------------------------------------------
 def save_enabled
   !$game_system.save_disabled
 end
 #-------------------------------------------------------------------------
 # * Get Activation State of Formation
 #-------------------------------------------------------------------------
 def formation_enabled
       $game_party.members.size >= 2 && !$game_system.formation_disabled
 end
end #class Window_DQ_Menu
#============================================================================
# * Window Base
#----------------------------------------------------------------------------
# Edit which changes base window
#============================================================================
class Window_Base < Window
 #--------------------------------------------------------------------------
 # * Object Initialization
 #--------------------------------------------------------------------------
 def initialize(x, y, width, height)
   super
   self.windowskin = Cache.system("Window")
   update_padding
   update_tone
   create_contents
   @opening = @closing = false
   self.back_opacity = Jami_DQ_Menu::WINDOW_OPACITY
 end

 #--------------------------------------------------------------------------
 # * Draw HP
 #--------------------------------------------------------------------------
 def draw_actor_hp(actor, x, y, width = 124)
   if Jami_DQ_Menu::DRAW_HP_MP_BARS == true
   draw_gauge(x, y, width, actor.hp_rate, hp_gauge_color1, hp_gauge_color2)
   end
   change_color(system_color)
   draw_text(x, y, 30, line_height, Vocab::hp_a)
   draw_current_and_max_values(x, y, width, actor.hp, actor.mhp,
     hp_color(actor), normal_color)
   end

 #--------------------------------------------------------------------------
 # * Draw MP
 #--------------------------------------------------------------------------
 def draw_actor_mp(actor, x, y, width = 124)
   if Jami_DQ_Menu::DRAW_HP_MP_BARS == true
   draw_gauge(x, y, width, actor.mp_rate, mp_gauge_color1, mp_gauge_color2)
   end
   change_color(system_color)
   draw_text(x, y, 30, line_height, Vocab::mp_a)
   draw_current_and_max_values(x, y, width, actor.mp, actor.mmp,
   mp_color(actor), normal_color)
   end
end

#============================================================================
# ** Gold/location Window
#============================================================================
class Window_Location < Window_Base
 #--------------------------------------------------------------------------
 # * Object Initialization
 #--------------------------------------------------------------------------
 def initialize
       super(Jami_DQ_Menu::LOC_X, Jami_DQ_Menu::LOC_Y,300,75)
       self.contents = Bitmap.new(width - 32, height - 32)
       refresh

     end
 #--------------------------------------------------------------------------
 # * Refresh
 #--------------------------------------------------------------------------
 def refresh
   self.contents.clear
   self.contents.draw_text(0,0,140,32, Jami_DQ_Menu::VOCAB_LOC)
   self.contents.draw_text(120,0,140,32, $game_map.display_name)
   self.contents.draw_text(0,20,140,32, Jami_DQ_Menu::VOCAB_GOLD)
   self.contents.draw_text(120,20,140,32, $game_party.gold)
 end
end #end class Window_Location

#============================================================================
# ** Gold Window (No location)
#============================================================================
class Window_Gold < Window_Base
 #--------------------------------------------------------------------------
 # * Object Initialization
 #--------------------------------------------------------------------------
 def initialize
       super(Jami_DQ_Menu::GOLD_X, Jami_DQ_Menu::GOLD_Y,245,54)
       self.contents = Bitmap.new(width - 32, height - 32)
       refresh

     end
 #--------------------------------------------------------------------------
 # * Refresh
 #--------------------------------------------------------------------------
 def refresh
   self.contents.clear
   self.contents.draw_text(0,0,140,32, Jami_DQ_Menu::VOCAB_GOLD)
   self.contents.draw_text(120,0,140,32, $game_party.gold)
 end
end #end class Window_Location

#============================================================================
# ** Actor Window 
#============================================================================
class Window_Actor < Window_Base
 #--------------------------------------------------------------------------
 # * Object Initialization
 #--------------------------------------------------------------------------
 def initialize
   if $game_party.members.size < 4
       super(0,306,110 * $game_party.members.size,110)
   else 
       super(0,306,110 * 4,110)
   end
       create_contents
       @actor1 = $game_party.members[0]
       @actor2 = $game_party.members[1]
       @actor3 = $game_party.members[2]
       @actor4 = $game_party.members[3]
       refresh
 end
  #----------------------------------------------------
  # * Refresh
  #----------------------------------------------------
 def refresh
       contents.clear
       draw_window_content
       draw_horiz_line (line_height * 1)

     end
  #----------------------------------------------------
  # * Draw Window Contents
  #----------------------------------------------------
 def draw_window_content

   # Face
      if Jami_DQ_Menu::SHOW_FACE == true
   draw_face(@actor1.face_name, @actor1.face_index, 0, 0, enabled = false)
      if $game_party.members.size > 1
   draw_face(@actor2.face_name, @actor2.face_index, 110, 0, enable = false)
      end # > 1
      if $game_party.members.size > 2
   draw_face(@actor3.face_name, @actor3.face_index, 220, 0, enable = false)
      end # > 2
      if $game_party.members.size > 3
   draw_face(@actor4.face_name, @actor4.face_index, 330, 0, enable = false)
      end # > 3
    end # if face

   # Actor Name
   draw_actor_name(@actor1, 0, 0)
     if $game_party.members.size > 1
   draw_actor_name(@actor2, 110, 0)
      end # > 1
      if $game_party.members.size > 2
   draw_actor_name(@actor3, 220, 0)
      end # > 2
      if $game_party.members.size > 3
   draw_actor_name(@actor4, 330, 0)
      end # > 3

   # Actor HP
   if Jami_DQ_Menu::SHOW_HP == true
   draw_actor_hp(@actor1, 0, 24, 80)
     if $game_party.members.size > 1
   draw_actor_hp(@actor2, 110, 24, 80)
      end # > 1
      if $game_party.members.size > 2
   draw_actor_hp(@actor3, 220, 24, 80)
      end # > 2
      if $game_party.members.size > 3
   draw_actor_hp(@actor4, 330, 24, 80)
      end # > 3
   end #if SHOW_HP

   # Actor MP
   if Jami_DQ_Menu::SHOW_MP == true
   draw_actor_mp(@actor1, 0, 44, 80)
     if $game_party.members.size > 1
   draw_actor_mp(@actor2, 110, 44, 80)
      end # > 1
      if $game_party.members.size > 2
   draw_actor_mp(@actor3, 220, 44, 80)
      end # > 2
      if $game_party.members.size > 3
   draw_actor_mp(@actor4, 330, 44, 80)
      end # > 3
   end #if SHOW_MP

   # Actor LV
   if Jami_DQ_Menu::SHOW_LEVEL == true
   draw_actor_level(@actor1, 0, 64)
     if $game_party.members.size > 1
   draw_actor_level(@actor2, 110, 64)
      end # > 1
      if $game_party.members.size > 2
   draw_actor_level(@actor3, 220, 64)
      end # > 2
      if $game_party.members.size > 3
   draw_actor_level(@actor4, 330, 64)
      end # > 3
   end #if SHOW_Level
 end # df draw_window_content
end #end class Window_Location

 #--------------------------------------------------------------------------
 # * Draw Horizontal Line
 #--------------------------------------------------------------------------
 def draw_horiz_line(y)
   contents.fill_rect(0, 22, contents_width, 2, line_color)
 end
 #--------------------------------------------------------------------------
 # * Get Color of Horizontal Line
 #--------------------------------------------------------------------------
 def line_color
   color = normal_color
   color.alpha = 200
   color
 end


#==============================================================================
# ** Window_MenuStatus
#------------------------------------------------------------------------------
#  This window displays party member status on the menu screen.
#==============================================================================

class Window_Simple_MenuStatus < Window_Selectable
 #--------------------------------------------------------------------------
 # * Public Instance Variables
 #--------------------------------------------------------------------------
 attr_reader   :pending_index            # Pending position (for formation)
 #--------------------------------------------------------------------------
 # * Object Initialization
 #--------------------------------------------------------------------------
 def initialize(x, y)
   super(x, y, window_width, window_height)
   @pending_index = -1
   refresh
 end
 #--------------------------------------------------------------------------
 # * Get Window Width
 #--------------------------------------------------------------------------
 def window_width
   Jami_DQ_Menu::MENU_WIDTH
 end
 #--------------------------------------------------------------------------
 # * Get Window Height
 #--------------------------------------------------------------------------
 def window_height
   124
 end
 #--------------------------------------------------------------------------
 # * Get Number of Items
 #--------------------------------------------------------------------------
 def item_max
   $game_party.members.size
 end
 #--------------------------------------------------------------------------
 # * Get Item Height
 #--------------------------------------------------------------------------
 def item_height
   22
 end
 #--------------------------------------------------------------------------
 # * Draw Item
 #--------------------------------------------------------------------------
 def draw_item(index)
   actor = $game_party.members[index]
   enabled = $game_party.battle_members.include?(actor)
   rect = item_rect(index)
   draw_item_background(index)
   draw_actor_name(actor, 4, rect.y - 2)

 end
 #--------------------------------------------------------------------------
 # * Draw Background for Item
 #--------------------------------------------------------------------------
 def draw_item_background(index)
   if index == @pending_index
     contents.fill_rect(item_rect(index), pending_color)
   end
 end
 #--------------------------------------------------------------------------
 # * Processing When OK Button Is Pressed
 #--------------------------------------------------------------------------
 def process_ok
   super
   $game_party.menu_actor = $game_party.members[index]
 end
 #--------------------------------------------------------------------------
 # * Restore Previous Selection Position
 #--------------------------------------------------------------------------
 def select_last
   select($game_party.menu_actor.index || 0)
 end
 #--------------------------------------------------------------------------
 # * Set Pending Position (for Formation)
 #--------------------------------------------------------------------------
 def pending_index=(index)
   last_pending_index = @pending_index
   @pending_index = index
   redraw_item(@pending_index)
   redraw_item(last_pending_index)
 end
end


#============================================================================
# ** Scene_Menu
#----------------------------------------------------------------------------
#  This overwrites menu
#============================================================================

class Scene_Menu < Scene_MenuBase
 #--------------------------------------------------------------------------
 # * Start Processing
 #--------------------------------------------------------------------------
 def start
   super
   create_command_window
   if Jami_DQ_Menu::SHOW_LOCATION == false
     create_gold_window
   else
     create_location_window
   end
   if Jami_DQ_Menu::SIMPLE_STATUS == false
     create_status_window
   else
     create_simple_status_window
   end
   if Jami_DQ_Menu::ACTOR_WINDOW == true
     create_actor_window
   end
 end
 #--------------------------------------------------------------------------
 # * Create Command Window
 #--------------------------------------------------------------------------
 def create_command_window
   @command_window = Window_DQ_Menu.new
   @command_window.set_handler(:item,      method(:command_item))
   @command_window.set_handler(:skill,     method(:command_personal))
   @command_window.set_handler(:equip,     method(:command_personal))
   @command_window.set_handler(:status,    method(:command_personal))
   @command_window.set_handler(:formation, method(:command_formation))
   @command_window.set_handler(:save,      method(:command_save))
   @command_window.set_handler(:game_end,  method(:command_game_end))
   @command_window.set_handler(:cancel,    method(:return_scene))

 end
 #--------------------------------------------------------------------------
 # * Create Status Window
 #--------------------------------------------------------------------------
 def create_status_window
   @status_window = Window_MenuStatus.new(0,0)
   @status_window.hide
 end
 #--------------------------------------------------------------------------
 # * Create Simple Status Window
 #--------------------------------------------------------------------------
 def create_simple_status_window
   @simple_status_window = Window_Simple_MenuStatus.new(0,0)
   @simple_status_window.hide
 end
 #--------------------------------------------------------------------------
 # * [skill], [Equipment] and [status] Commands
 #--------------------------------------------------------------------------
 def command_personal
   if Jami_DQ_Menu::SIMPLE_STATUS == false
   @status_window.show
   @command_window.hide
   if Jami_DQ_Menu::ACTOR_WINDOW == true
   @actor_window.hide
   end
   @status_window.select_last
   @status_window.activate
   @status_window.set_handler(:ok,     method(:on_personal_ok))
   @status_window.set_handler(:cancel, method(:on_personal_cancel))
   else
   @simple_status_window.show
   @command_window.hide
   @simple_status_window.select_last
   @simple_status_window.activate
   @simple_status_window.set_handler(:ok,     method(:on_personal_ok))
   @simple_status_window.set_handler(:cancel, method(:on_personal_cancel))
   end
 end
 #--------------------------------------------------------------------------
 # * [Cancel] Personal Command
 #--------------------------------------------------------------------------
 def on_personal_cancel
   if Jami_DQ_Menu::SIMPLE_STATUS == false
   @status_window.unselect
   @status_window.hide
   if Jami_DQ_Menu::ACTOR_WINDOW == true
   @actor_window.dispose
   @actor_window = Window_Actor.new
   end
   @command_window.show
   @command_window.activate
   else
   @simple_status_window.unselect
   @command_window.show
   @simple_status_window.hide
   if Jami_DQ_Menu::ACTOR_WINDOW == true
   @actor_window.dispose
   @actor_window = Window_Actor.new
   end
   @command_window.activate
   end
 end
 #--------------------------------------------------------------------------
 # * [Formation] Command
 #--------------------------------------------------------------------------
 def command_formation
   if Jami_DQ_Menu::SIMPLE_STATUS == false
   @status_window.show
   @command_window.hide
   if Jami_DQ_Menu::ACTOR_WINDOW == true
   @actor_window.hide
   end
   @status_window.select_last
   @status_window.activate
   @status_window.set_handler(:ok,     method(:on_formation_ok))
   @status_window.set_handler(:cancel, method(:on_formation_cancel))
   else
   @simple_status_window.show
   @command_window.hide
   @simple_status_window.select_last
   @simple_status_window.activate
   @simple_status_window.set_handler(:ok,     method(:on_formation_ok))
   @simple_status_window.set_handler(:cancel, method(:on_formation_cancel))
   end
 end      
 #--------------------------------------------------------------------------
 # * Formation [OK]
 #--------------------------------------------------------------------------
 def on_formation_ok
   if Jami_DQ_Menu::SIMPLE_STATUS == false
   if @status_window.pending_index >= 0
     $game_party.swap_order(@status_window.index,
                            @status_window.pending_index)
     @status_window.pending_index = -1
     @status_window.redraw_item(@status_window.index)
     if Jami_DQ_Menu::ACTOR_WINDOW == true
     @actor_window.dispose
     @actor_window = Window_Actor.new
     @actor_window.hide
     end
   else
     @status_window.pending_index = @status_window.index
   end
   @status_window.activate
   else 
   if @simple_status_window.pending_index >= 0
     $game_party.swap_order(@simple_status_window.index,
                            @simple_status_window.pending_index)
     @simple_status_window.pending_index = -1
     @simple_status_window.redraw_item(@simple_status_window.index)
     if Jami_DQ_Menu::ACTOR_WINDOW == true
     @actor_window.dispose
     @actor_window = Window_Actor.new
     end
   else
     @simple_status_window.pending_index = @simple_status_window.index
   end
   @simple_status_window.activate
   end
 end
 #--------------------------------------------------------------------------
 # * Formation [Cancel]
 #--------------------------------------------------------------------------
 def on_formation_cancel
   if Jami_DQ_Menu::SIMPLE_STATUS == false
     if @status_window.pending_index >= 0
       @status_window.pending_index = -1
       @status_window.activate
     else
       @status_window.unselect
       @status_window.hide
       if Jami_DQ_Menu::ACTOR_WINDOW == true
     @actor_window.dispose
     @actor_window = Window_Actor.new
     end
       @command_window.show
       @command_window.activate
     end
     else
     if @simple_status_window.pending_index >= 0
       @simple_status_window.pending_index = -1
       @simple_status_window.activate
     else
       @simple_status_window.unselect
       @simple_status_window.hide
       if Jami_DQ_Menu::ACTOR_WINDOW == true
       @actor_window.dispose
       @actor_window = Window_Actor.new
     end
       @command_window.show
       @command_window.activate
     end
  end 
 end
 #--------------------------------------------------------------------------
 # * Location window
 #--------------------------------------------------------------------------
 def create_location_window
   @location_window = Window_Location.new
 end
 #--------------------------------------------------------------------------
 # * Create Gold Window
 #--------------------------------------------------------------------------
 def create_gold_window
   @gold_window = Window_Gold.new
 end
 #--------------------------------------------------------------------------
 # * Create Actor Window
 #--------------------------------------------------------------------------
 def create_actor_window
   @actor_window = Window_Actor.new
 end
end # end Scene_Menu