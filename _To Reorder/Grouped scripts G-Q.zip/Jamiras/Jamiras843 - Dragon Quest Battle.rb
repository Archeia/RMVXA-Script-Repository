#============================================================================
# [VXAce] Dragon Quest Battle V1.00 (Finished)
#----------------------------------------------------------------------------
# By Jamiras843#
# Features: 
#     V1.00
#     * Dragon Quest VIII style battle 
#     * Limited options to have list style Status or block style
#     * Face graphics optional
#     * Level Up option available for sound.
#============================================================================
$imported = {} if $imported.nil?
$imported["Dragon Quest Battle"] = true 

module Jami_DQ_Battle    
#========================================================================  
# Script options  
#------------------------------------------------------------------------  
# Here you edit some simple aspects of the Battle System  
#  
#========================================================================  
  SHOW_FACE = true 
  # Shows actor face in menu  
  HUD_HIDE = true 
  #Hides Battle status during combat if true  
  LVL_UP = true 
  #Play level up sounde effect      
  LVL_UP_SND = "Level_Up" 
  #Name of sound effect    
end 
#end module Jami_DQ_Battle    

#============================================================================    
# WARNING: Do not edit below unless you know what you are doing. This script
# is rather sloppy but it does its job. 
#============================================================================

#==============================================================================
# ** Game_Actor
#------------------------------------------------------------------------------
#  This class handles actors. It's used within the Game_Actors class
# ($game_actors) and referenced by the Game_Party class ($game_party).
#============================================================================== 
class Game_Actor < Game_Battler  
#--------------------------------------------------------------------------  
# * Show Level Up Message  
#     new_skills : Array of newly learned skills  
#--------------------------------------------------------------------------  
  def display_level_up(new_skills)    
    Audio.me_play("Audio/ME/" + Jami_DQ_Battle::LVL_UP_SND)    
    $game_message.new_page    
    $game_message.add(sprintf(Vocab::LevelUp, @name, Vocab::level, @level))    
    new_skills.each do |skill|      
      $game_message.add(sprintf(Vocab::obtainSkill, skill.name))    
    end  
  end
end

#==============================================================================
# ** Window_Base
#------------------------------------------------------------------------------
#  This is a super class of all windows within the game.
#============================================================================== 
class Window_Base < Window  
#--------------------------------------------------------------------------  
# * Close Window  
#--------------------------------------------------------------------------  
  def close    
    @closing = true     
    @opening = false    
    self  
  end
end #class Window_Base 

#==============================================================================
# ** Window_Help
#------------------------------------------------------------------------------
#  This window shows skill and item explanations along with actor status.
#============================================================================== 
class Window_Help < Window_Base  
#--------------------------------------------------------------------------  
# * Object Initialization  
#--------------------------------------------------------------------------  
  def initialize(line_number = 2)    
    super(0, 0, Graphics.width, fitting_height(line_number))  
  end
end 

#==============================================================================
# ** Window_BattleItem
#------------------------------------------------------------------------------
#  This window is for selecting items to use in the battle window.
#============================================================================== 
class Window_BattleItem < Window_ItemList  
#--------------------------------------------------------------------------  
# * Object Initialization  
#     info_viewport : Viewport for displaying information  
#--------------------------------------------------------------------------  
  def initialize(help_window, info_viewport)    
    y = help_window.height    
    super(0, y, Graphics.width, 416)    
    self.visible = false    
    @help_window = help_window    
    @info_viewport = info_viewport  
  end
end

#==============================================================================
# ** Window_BattleSkill
#------------------------------------------------------------------------------
#  This window is for selecting skills to use in the battle window.
#============================================================================== 
class Window_BattleSkill < Window_SkillList  
#--------------------------------------------------------------------------  
# * Object Initialization  
#     info_viewport : Viewport for displaying information  
#--------------------------------------------------------------------------  
  def initialize(help_window, info_viewport)    
    y = help_window.height    
    super(0, y, Graphics.width, 416)    
    self.visible = false    
    @help_window = help_window    
    @info_viewport = info_viewport  
  end
end

#==============================================================================
# ** Window_BattleActor
#------------------------------------------------------------------------------
#  This window is for selecting an actor's action target on the battle screen.
#============================================================================== 
class Window_BattleActor < Window_BattleStatus  
#--------------------------------------------------------------------------  
# * Object Initialization  
#     info_viewport : Viewport for displaying information  
#--------------------------------------------------------------------------  
  def initialize(info_viewport)    
    super()    
    self.y = 416 - 120    
    self.visible = false   
    self.openness = 255    
    @info_viewport = info_viewport    
    @info_viewport2 = info_viewport      
  end
end 

#============================================================================
# ** Actor Window 
#============================================================================
class Window_DQ_BattleStatus < Window_Base
#--------------------------------------------------------------------------  
# * Object Initialization  
#--------------------------------------------------------------------------  
  def initialize
    if $game_party.members.size < 4        
      super(100, 0, 110 * $game_party.members.size,120)    
    else         
      super(100, 0, 110 * 4,120)    
    end        
    create_contents        
    @actor1 = $game_party.members[0]        
    @actor2 = $game_party.members[1]        
    @actor3 = $game_party.members[2]        
    @actor4 = $game_party.members[3]        
    refresh        
    self.openness = 0      
  end  
#--------------------------------------------------------------------------  
# * Draw Item  
#--------------------------------------------------------------------------  
  def draw_item(index)    
    actor = $game_party.battle_members[index]  
  end  
#--------------------------------------------------------------------------  
# * Get Number of Lines to Show  
#--------------------------------------------------------------------------  
  def visible_line_number        
    return 4 
  end  
#--------------------------------------------------------------------------  
# * Get Digit Count  
#--------------------------------------------------------------------------  
  def col_max        
    return 4  
  end       
#----------------------------------------------------   
# * Refresh   
#----------------------------------------------------  
  def refresh        
    contents.clear        
    draw_window_content        
    draw_horz_line(line_height * 1)              
  end   
#----------------------------------------------------   
# * Draw Window Contents   
#----------------------------------------------------  
  def draw_window_content        
    # Face       
    if Jami_DQ_Battle::SHOW_FACE == true    
      draw_face(@actor1.face_name, @actor1.face_index, 0, 0, enabled = false)       
    if $game_party.members.size > 1    
      draw_face(@actor2.face_name, @actor2.face_index, 110, 0, enable = false)       
    end # > 1       
    if $game_party.members.size > 2    
      draw_face(@actor3.face_name, @actor3.face_index, 220, 0, enable = false)       
    end # > 2       
    if $game_party.members.size > 3    
      draw_face(@actor4.face_name, @actor4.face_index, 330, 0, enable = false)       
    end # > 3     
    end # if face   

    # Actor Name    
    draw_actor_name(@actor1, 0, 0)      
    if $game_party.members.size > 1    
      draw_actor_name(@actor2, 110, 0)       
    end # > 1       
    if $game_party.members.size > 2    
      draw_actor_name(@actor3, 220, 0)       
    end # > 2       
    if $game_party.members.size > 3    
      draw_actor_name(@actor4, 330, 0)       
    end # > 3      
    
    # Actor HP    
    draw_actor_hp(@actor1, 0, 24, 80)      
    if $game_party.members.size > 1    
      draw_actor_hp(@actor2, 110, 24, 80)       
    end # > 1       
    if $game_party.members.size > 2    
      draw_actor_hp(@actor3, 220, 24, 80)       
    end # > 2       
    if $game_party.members.size > 3    
      draw_actor_hp(@actor4, 330, 24, 80)       
    end # > 3      
    
    # Actor MP    
    draw_actor_mp(@actor1, 0, 44, 80)      
    if $game_party.members.size > 1    
      draw_actor_mp(@actor2, 110, 44, 80)       
    end # > 1       
    if $game_party.members.size > 2    
      draw_actor_mp(@actor3, 220, 44, 80)       
    end # > 2       
    if $game_party.members.size > 3    
      draw_actor_mp(@actor4, 330, 44, 80)       
    end # > 3           
    
    # Actor LV    
    draw_actor_level(@actor1, 0, 64)      
    if $game_party.members.size > 1   
      draw_actor_level(@actor2, 110, 64)       
    end # > 1       
    if $game_party.members.size > 2    
      draw_actor_level(@actor3, 220, 64)       
    end # > 2       
    if $game_party.members.size > 3    
      draw_actor_level(@actor4, 330, 64)       
    end # > 3      
    
    # Actor Icons  
    draw_actor_icons(@actor1, 60, 0)       
    if $game_party.members.size > 1    
      draw_actor_icons(@actor2, 170, 0)       
    end # > 1       
    if $game_party.members.size > 2    
      draw_actor_icons(@actor3, 280, 0)       
    end # > 2       
    if $game_party.members.size > 3    
      draw_actor_icons(@actor4, 400, 0)       
    end # > 3  
  end  #end draw_window_content
end 

#==============================================================================
# ** Window_BattleEnemy
#------------------------------------------------------------------------------
#  Window for selecting the enemy who is the action target on the battle
# screen.
#============================================================================== 
class Window_BattleEnemy < Window_Selectable  
#--------------------------------------------------------------------------  
# * Object Initialization  
#     info_viewport : Viewport for displaying information  
#--------------------------------------------------------------------------  
  def initialize(info_viewport)    
    super(200, 296, 344, fitting_height(4))    
    refresh    
    self.visible = false  
  end
end #class Window_BattleEnemy  

#==============================================================================
# ** Window_BattleLog
#------------------------------------------------------------------------------
#  Window edited to be more like DQVIII
#============================================================================== 
class Window_BattleLog < Window_Selectable  
#--------------------------------------------------------------------------  
# * Object Initialization  
#--------------------------------------------------------------------------  
  def initialize    
    super(0, 296, window_width, window_height)    
    self.z = 200    
    self.hide    
    self.opacity = 255    
    @lines = []    
    @num_wait = 0    
    create_back_bitmap    
    create_back_sprite    
    refresh  
  end  
  #--------------------------------------------------------------------------  
  # * Free  
  #--------------------------------------------------------------------------  
  def dispose    
    super    
    self.close    
    dispose_back_bitmap    
    dispose_back_sprite  
  end  
  #--------------------------------------------------------------------------  
  # * Get Window Width  
  #--------------------------------------------------------------------------  
  def window_width    
    Graphics.width  
  end  
  #--------------------------------------------------------------------------  
  # * Get Window Height  
  #--------------------------------------------------------------------------  
  def window_height    
    fitting_height(max_line_number)  
  end  
  #--------------------------------------------------------------------------  
  # * Get Maximum Number of Lines  
  #--------------------------------------------------------------------------  
  def max_line_number    
    return 4  
  end  
  #--------------------------------------------------------------------------  
  # * Clear  
  #--------------------------------------------------------------------------  
  def clear    
    self.hide    
    @num_wait = 0    
    @lines.clear    
    refresh  
  end  
  #--------------------------------------------------------------------------  
  # * Add Text  
  #--------------------------------------------------------------------------  
  def add_text(text)    
    self.show    
    @lines.push(text)    
    refresh  
  end  
  #--------------------------------------------------------------------------  
  # * Get Background Opacity  
  #--------------------------------------------------------------------------  
  def back_opacity    
    return 0  
  end 
end #Window_Battlelog

#==============================================================================
# ** Window_ActorCommand
#------------------------------------------------------------------------------
#  This window is for selecting an actor's action on the battle screen.
#============================================================================== 
class Window_ActorCommand < Window_Command  
#--------------------------------------------------------------------------  
# * Object Initialization  
#--------------------------------------------------------------------------  
  def initialize    
    super(0, 0)    
    self.openness = 0    
    deactivate    
    @actor = nil  
  end  
  #--------------------------------------------------------------------------  
  # * Get Window Width  
  #--------------------------------------------------------------------------  
  def window_width    
    return 200  
  end  
  #--------------------------------------------------------------------------  
  # * Get Number of Lines to Show  
  #--------------------------------------------------------------------------  
  def visible_line_number    
    return 4  
  end  
  #--------------------------------------------------------------------------  
  # * Get Digit Count  
  #--------------------------------------------------------------------------  
  def col_max        
    return 2  
  end
end

#==============================================================================
# ** Scene_Battle
#------------------------------------------------------------------------------
#  This class performs battle screen processing.
#============================================================================== 
class Scene_Battle < Scene_Base  
#--------------------------------------------------------------------------  
# * Start Processing  
#--------------------------------------------------------------------------  
  def start    
    super    
    create_spriteset    
    create_all_windows    
    BattleManager.method_wait_for_message = method(:wait_for_message)    
    @game_party = $game_party.members  
  end  
  #--------------------------------------------------------------------------  
  # * Update Frame (Basic)  
  #--------------------------------------------------------------------------  
  def update_basic    
    super    
    $game_timer.update    
    $game_troop.update    
    @spriteset.update    
    update_message_open  
  end   
  #--------------------------------------------------------------------------  
  # * Create All Windows  
  #--------------------------------------------------------------------------  
  def create_all_windows    
    create_message_window    
    create_log_window    
    create_DQ_status_window    
    create_info_viewport    
    create_party_command_window    
    create_actor_command_window    
    create_help_window    
    create_skill_window    
    create_item_window    
    create_actor_window    
    create_enemy_window  
  end  
  #--------------------------------------------------------------------------  
  # * Create Message Window  
  #--------------------------------------------------------------------------  
  def create_message_window    
    @message_window = Window_Message.new  
  end    
  #--------------------------------------------------------------------------  
  # * Create DQ Status Window  
  #--------------------------------------------------------------------------  
  def create_DQ_status_window    
    @DQ_status_window = Window_DQ_BattleStatus.new
    @DQ_status_window.x = 128  
  end    
  #--------------------------------------------------------------------------  
  # * Create Log Window  
  #--------------------------------------------------------------------------  
  def create_log_window    
    @log_window = Window_BattleLog.new    
    @log_window.method_wait = method(:wait)    
    @log_window.method_wait_for_effect = method(:wait_for_effect)  
  end   
  #--------------------------------------------------------------------------  
  # * Create Information Display Viewport  
  #--------------------------------------------------------------------------   
  def create_info_viewport    
    @info_viewport = Viewport.new    
    @info_viewport.rect.y = 0    
    @info_viewport.rect.height = Graphics.height - @DQ_status_window.height    
    @info_viewport.z = 100    
    @info_viewport.ox = 544 - 104 * 4    
    @DQ_status_window.viewport = @info_viewport  
  end    
  #--------------------------------------------------------------------------  
  # * Create Party Commands Window  
  #--------------------------------------------------------------------------  
  def create_party_command_window    
    @DQ_status_window.show    
    @party_command_window = Window_PartyCommand.new    
    @party_command_window.set_handler(:fight,  method(:command_fight))    
    @party_command_window.set_handler(:escape, method(:command_escape))    
    @party_command_window.x = 0    
    @party_command_window.y = 296    
    @party_command_window.unselect  
  end  
  #--------------------------------------------------------------------------  
  # * Create Actor Commands Window  
  #--------------------------------------------------------------------------  
  def create_actor_command_window    
    @actor_command_window = Window_ActorCommand.new    
    @actor_command_window.set_handler(:attack, method(:command_attack))    
    @actor_command_window.set_handler(:skill,  method(:command_skill))    
    @actor_command_window.set_handler(:guard,  method(:command_guard))    
    @actor_command_window.set_handler(:item,   method(:command_item))   
    @actor_command_window.set_handler(:cancel, method(:prior_command))    
    @actor_command_window.x = 0    
    @actor_command_window.y = 296    
  end  
  #--------------------------------------------------------------------------  
  # * Create Help Window  
  #--------------------------------------------------------------------------  
  def create_help_window    
    @help_window = Window_Help.new    
    @help_window.visible = false  
  end   
  #--------------------------------------------------------------------------  
  # * Create Enemy Window  
  #--------------------------------------------------------------------------  
  def create_enemy_window    
    @enemy_window = Window_BattleEnemy.new(@help_window)    
    @enemy_window.index = 0    
    @enemy_window.set_handler(:ok,     method(:on_enemy_ok))    
    @enemy_window.set_handler(:cancel, method(:on_enemy_cancel))  
  end   
  #--------------------------------------------------------------------------  
  # * Start Enemy Selection  
  #--------------------------------------------------------------------------  
  def select_enemy_selection    
    @enemy_window.refresh    
    @enemy_window.show.activate    
    @enemy_window.index = 0  
  end  
  #--------------------------------------------------------------------------  
  # * Create Skill Window  
  #--------------------------------------------------------------------------  
  def create_skill_window    
    @skill_window = Window_BattleSkill.new(@help_window, @info_viewport)    
    @skill_window.set_handler(:ok,     method(:on_skill_ok))    
    @skill_window.set_handler(:cancel, method(:on_skill_cancel))  
  end  
  #--------------------------------------------------------------------------  
  # * Create Item Window  
  #--------------------------------------------------------------------------  
  def create_item_window    
    @item_window = Window_BattleItem.new(@help_window, @info_viewport)    
    @item_window.set_handler(:ok,     method(:on_item_ok))    
    @item_window.set_handler(:cancel, method(:on_item_cancel))  
  end   
  #--------------------------------------------------------------------------  
  # * Update Status Window Information  
  #--------------------------------------------------------------------------  
  def refresh_status    
    @DQ_status_window.refresh 
  end    
  #--------------------------------------------------------------------------  
  # * Start Party Command Selection  
  #--------------------------------------------------------------------------  
  def start_party_command_selection    
    unless scene_changing?      
    refresh_status      
    @DQ_status_window.open      
    if BattleManager.input_start        
      @actor_command_window.close        
      @party_command_window.setup      
    else        
      @party_command_window.deactivate        
      turn_start      
    end    
    end  
  end    
  #--------------------------------------------------------------------------  
  # * Start Actor Command Selection  
  #--------------------------------------------------------------------------  
  def start_actor_command_selection    
    @party_command_window.close    
    @actor_command_window.setup(BattleManager.actor)  
  end  
  #--------------------------------------------------------------------------  
  # * Update Processing for Opening Message Window  
  #    Set openness to 0 until the status window and so on are finished closing.  
  #--------------------------------------------------------------------------  
  def update_message_open    
    if $game_message.busy? && !@DQ_status_window.close?      
      @message_window.openness = 0      
      @DQ_status_window.close      
      @party_command_window.close      
      @actor_command_window.close    
    end  
  end  
  #--------------------------------------------------------------------------  
  # * Start Turn  
  #--------------------------------------------------------------------------  
  def turn_start    
    @party_command_window.close    
    @actor_command_window.close    
    @subject =  nil    
    BattleManager.turn_start    
    if Jami_DQ_Battle::HUD_HIDE == true    
      @info_viewport.rect.height = 60    
    end #if HUDE_HIDE    
    @log_window.clear  
  end  
  #--------------------------------------------------------------------------  
  # * End Turn  
  #--------------------------------------------------------------------------  
  def turn_end    
    all_battle_members.each do |battler|      
    battler.on_turn_end      
    refresh_status      
    if Jami_DQ_Battle::HUD_HIDE == true      
      @info_viewport.rect.height = @DQ_status_window.height      
    end      
    @log_window.display_auto_affected_status(battler)      
    @log_window.wait_and_clear    
    end    
    BattleManager.turn_end    
    process_event    
    start_party_command_selection  
  end  
  #--------------------------------------------------------------------------  
  # * Battle Action Processing  
  #--------------------------------------------------------------------------  
  def process_action    
    return if scene_changing?    
    if !@subject || !@subject.current_action      
      @subject = BattleManager.next_subject    
    end    
    return turn_end unless @subject    
    if @subject.current_action      
      @subject.current_action.prepare      
    if @subject.current_action.valid?        
      @DQ_status_window.open        
      execute_action      
    end      
    @subject.remove_current_action    
    end    
    process_action_end unless @subject.current_action  
  end 
end # end Scene_battle 