#============================================================================
# [VXAce] Dragon Quest Status V1.00 (finished)
#----------------------------------------------------------------------------
# By Jamiras843
#
# Features:
# V1.00
# * New status window similar to DQ DS remakes
# * Minimal customization (sorry guys)
#============================================================================
$imported = {} if $imported.nil?
$imported["Dragon Quest Status"] = true
module Jami_DQ_Status
  #========================================================================
  # Script options
  #------------------------------------------------------------------------
  # Here you edit some simple aspects of the menu
  #
  #========================================================================
  SHOW_EXP = true 
  #Shows total 
  EXPVOCAB_EXP = "Ex:" 
  #I use "Ex:"
  LENGTH2 = 40 
  #Changes the text length of VOCAB_EXP
  SHOW_BIO = false 
  #Shows Actor bio/description
  SHOW_FACE = true 
  #Shows Actor face graphic
  SHOW_NICKNAME = true 
  #Show Actor nick name
  VOCAB_NICKNAME = "Personality:" 
  # I use "Sex" or "Personality"
  LENGTH1 = 100 
  #Changes the text length of VOCAB_NICKNAME
end 
#end module Jami_DQ_Menu
#============================================================================
# WARNING: Do not edit below unless you know what you are doing. This script
# is rather sloppy but it does its job.
#============================================================================

#==============================================================================
# ** Window_Status_Main
#------------------------------------------------------------------------------
# This window displays full status specs on the status screen.
#==============================================================================
class Window_Status_Main < Window_Selectable
  def initialize(actor)
    super(0, 0, main_width, line_height * 8)
    @actor = actor
    refresh
    draw_horiz_line(line_height * 1)
    activate
  end 
  #initialize
  #--------------------------------------------------------------------------
  # * Main Window Width
  #--------------------------------------------------------------------------
  def main_width
    if Jami_DQ_Status::SHOW_FACE == true
      320
    else
      268
    end
  end
  #--------------------------------------------------------------------------
  # * Set Actor
  #--------------------------------------------------------------------------
  def actor=(actor)
    return if @actor == actor
    @actor = actor
    refresh
  end 
  #actor
  #--------------------------------------------------------------------------
  # * Refresh
  #--------------------------------------------------------------------------
  def refresh
    contents.clear
    draw_main_content
  end 
  #refresh
  #--------------------------------------------------------------------------
  # * Main Content
  #--------------------------------------------------------------------------
  def draw_main_content
    s1 = @actor.max_level? ? "-------" : @actor.exp
    draw_actor_name(@actor, 20, 0)
    draw_actor_icons(@actor, 200, 0)
    if Jami_DQ_Status::SHOW_FACE == true
      draw_face(@actor.face_name, @actor.face_index, 0, 40, enabled = true)
      draw_actor_class(@actor, 128, y + line_height * 1)
      draw_text(128, y + line_height * 2, Jami_DQ_Status::LENGTH1, y + line_height, Jami_DQ_Status::VOCAB_NICKNAME)
      draw_actor_nickname(@actor, Jami_DQ_Status::LENGTH1 + 128, y + line_height * 2)
      draw_actor_level(@actor, 128, y + line_height * 3)
      draw_actor_hp(@actor, 128, y + line_height * 4)
      draw_actor_mp(@actor, 128, y + line_height * 5)
      if Jami_DQ_Status::SHOW_EXP == true
        draw_text(128, y + line_height * 6, Jami_DQ_Status::LENGTH2, y + line_height, Jami_DQ_Status::VOCAB_EXP)
        draw_text(Jami_DQ_Status::LENGTH2 + 128, y + line_height * 6, 70, line_height, s1)
      end 
      #show exp
    else
      draw_actor_class(@actor, x, y + line_height * 1)
      draw_text(x, y + line_height * 2, Jami_DQ_Status::LENGTH1, y + line_height, Jami_DQ_Status::VOCAB_NICKNAME)
      draw_actor_nickname(@actor, Jami_DQ_Status::LENGTH1, y + line_height * 2)
      draw_actor_level(@actor, x, y + line_height * 3)
      draw_actor_hp(@actor, x, y + line_height * 4)
	  draw_actor_mp(@actor, x, y + line_height * 5)
      if Jami_DQ_Status::SHOW_EXP == true
        draw_text(x, y + line_height * 6, Jami_DQ_Status::LENGTH2, y + line_height, Jami_DQ_Status::VOCAB_EXP)
        draw_text(Jami_DQ_Status::LENGTH2, y + line_height * 6, 70, line_height, s1)
      end 
      #show exp
    end 
    #show face
  end
  #--------------------------------------------------------------------------
  # * Draw Horizontal Line
  #--------------------------------------------------------------------------
  def draw_horiz_line(y)
    contents.fill_rect(0, 24, contents_width, 2, line_color)
  end 
  #draw line
  #--------------------------------------------------------------------------
  # * Get Color of Horizontal Line
  #--------------------------------------------------------------------------
  def line_color
    color = normal_color
    color.alpha = 200
    color
  end 
  #line color
end 
#window main
#==============================================================================
# ** Window_Status_Stats
#------------------------------------------------------------------------------
# This window displays full status
#==============================================================================
class Window_Status_Stats < Window_Base
  def initialize(actor)
    super(stat_x + 4, 0, 220, line_height * 8)
    @actor = actor
    refresh
    activate
  end 
  #initialize
  #--------------------------------------------------------------------------
  # * Stat Window X
  #--------------------------------------------------------------------------
  def stat_x
    if Jami_DQ_Status::SHOW_FACE == true
      320
    else
      268
    end 
    #if
  end 
  #stat X
  #--------------------------------------------------------------------------
  # * Set Actor
  #--------------------------------------------------------------------------
  def actor=(actor)
    return if @actor == actor
    @actor = actor
    refresh
  end 
  #actor
  #--------------------------------------------------------------------------
  # * Refresh
  #--------------------------------------------------------------------------
  def refresh
    contents.clear
    draw_stat_content(0, 0)
  end 
  #refresh
  #--------------------------------------------------------------------------
  # * Draw Parameters
  #--------------------------------------------------------------------------
  def draw_stat_content(x, y)
    [2, 3, 4, 5, 6, 7].each_with_index {|p, i| draw_actor_param(@actor, x, y + line_height * i, p) }
  end 
  #Stat Content
end 
#window stat
#==============================================================================
# ** Window_Status_Equip
#------------------------------------------------------------------------------
# This window displays full status specs on the status screen.
#==============================================================================
class Window_Status_Equip < Window_Base
  def initialize(actor)
    super(stat_x + 4, line_height * 8 + 4, 220, line_height * 6)
    @actor = actor
    refresh
    activate
  end 
  #initialize
  #--------------------------------------------------------------------------
  # * Stat Window X
  #--------------------------------------------------------------------------
  def stat_x
    if Jami_DQ_Status::SHOW_FACE == true
      320
    else
      268
    end 
    #if true
  end 
  #stat X
  #--------------------------------------------------------------------------
  # * Set Actor
  #--------------------------------------------------------------------------
  def actor=(actor)
    return if @actor == actor
    @actor = actor
    refresh
  end 
  #actor
  #--------------------------------------------------------------------------
  # * Refresh
  #--------------------------------------------------------------------------
  def refresh
    contents.clear
    draw_equip_content(0, 0)
  end 
  #refresh
  #--------------------------------------------------------------------------
  # * Equip Content
  #--------------------------------------------------------------------------
  def draw_equip_content(x, y)
    @actor.equips.each_with_index do |item, i|
      draw_item_name(item, x, y + line_height * i)
    end
  end
end
#==============================================================================
# ** Window_Status_Bio
#------------------------------------------------------------------------------
# This window displays character Bio.
#==============================================================================
class Window_Status_Bio < Window_Base
  def initialize(actor)
    super(0, line_height * 14 + 8, 544, line_height * 3)
    @actor = actor
    refresh
    activate
  end 
  #initialize
  #--------------------------------------------------------------------------
  # * Set Actor
  #--------------------------------------------------------------------------
  def actor=(actor)
    return if @actor == actor
    @actor = actor
    refresh
  end 
  #actor
  #--------------------------------------------------------------------------
  # * Refresh
  #--------------------------------------------------------------------------
  def refresh
    contents.clear
    draw_stat_bio
  end 
  #refresh
  #--------------------------------------------------------------------------
  # * Draw Bio
  #--------------------------------------------------------------------------
  def draw_stat_bio
    draw_text_ex(0, 0, @actor.description)
  end
end 
#class bio
#==============================================================================
# ** Scene_Status
#------------------------------------------------------------------------------
# This class performs the status screen processing.
#==============================================================================
class Scene_Status < Scene_MenuBase
  #--------------------------------------------------------------------------
  # * Start Processing
  #--------------------------------------------------------------------------
  def start
    super
    @status_window1 = Window_Status_Main.new(@actor)
    @status_window2 = Window_Status_Stats.new(@actor)
    @status_window3 = Window_Status_Equip.new(@actor)
    if Jami_DQ_Status::SHOW_BIO == true
      @status_window4 = Window_Status_Bio.new(@actor)
    end
    @status_window1.set_handler(:cancel, method(:return_scene))
  end
  #--------------------------------------------------------------------------
  # * Change Actors
  #--------------------------------------------------------------------------
  def on_actor_change
    @status_window.actor = @actor
    @status_window.activate
  end
end