#===============================================================================
# APPDATA Saving
# By Jet10985 (Jet)
#===============================================================================
# This script will save your game's save files in the APPDATA directory of the 
# user's computer. This is useful for keeping save files after game deletion,
# and is required by some commercial portals.
# This script has: 0 customization options.
#===============================================================================
# Overwritten Methods:
# DataManager: save_file_exists?, make_filename
#-------------------------------------------------------------------------------
# Aliased methods:
# None
#===============================================================================
=begin
The directory that save files willbe in will be the APPDATA directory of the
player's computer, followed by the name of your game as written in the
Config.ini file, followed by "Saves".
=end

module Utility
  
  Win32API.new('kernel32', 'GetEnvironmentVariable', 'ppl', 'l').call(
    "APPDATA", title = "\0" * 256, 256)
  APPDATA = title.unpack("C*").pack("U*").delete!("\0")
  
  a = Win32API.new('kernel32', 'GetPrivateProfileString', 'pppplp', 'l')
  a.call("Game", "Title", "", title = "\0" * 256, 256, ".//Game.ini")
  
  GAME_NAME = title.unpack("C*").pack("U*").delete!("\0")
  
  
  APPDATA_DIRECTORY = "#{APPDATA}\\#{GAME_NAME.gsub(/[\\\/\:\*\?\"\<\>\|]/, '')}"

end

class << DataManager
	
  def save_file_exists?(*args, &block)
    f = Utility::APPDATA_DIRECTORY.dup
    Dir.mkdir(f) unless File.directory?(f)
    f << "\\Saves"
    Dir.mkdir(f) unless File.directory?(f)
    entries = Dir.entries(f.unpack("U*").pack("C*"), :encoding => 'UTF-8')
    entries.size > 2
  end
	
  def make_filename(index)
    f = Utility::APPDATA_DIRECTORY
    Dir.mkdir(f) unless File.directory?(f)
    f = f + "\\Saves"
    Dir.mkdir(f) unless File.directory?(f)
    "#{f}\\#{sprintf("Save%02d.rvdata2", index + 1)}"
  end
end