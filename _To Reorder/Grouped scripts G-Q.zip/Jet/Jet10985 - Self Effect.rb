#===============================================================================
# Skill Self Effects
# By Jet10985 (Jet)
# Requested by Touchfuzzy
#===============================================================================
# This script will allow you to specify a skill's effects tot arget the user
# instead of the target, on skills that don't already effect the user.
# This script has: 0 customization options.
#===============================================================================
# Overwritten Methods:
# None
#-------------------------------------------------------------------------------
# Aliased methods:
# Game_Battler: item_effect_apply
#===============================================================================
=begin
To specify the effects, use this notetag in the skill's notebox:
<self effect: 1>
or
<self effect: 1, 2, 3> to specify more than 1 effect
--------------------------------------------------------------------------------
Use of this script could be as the following.
You make a "Berserk Strike" skill, which does 200% damage to an enemy.
You make the 2nd effect "Defense Down 50%" and want it applied to the user.
You'd use this notetag: <self effect: 2>
=end
class RPG::Skill
  def self_effects
    if @self_effects.nil?
      @self_effects = []
      self.note.each_line {|a|
      scan = a.scan(/<self[ ]*effect[ ]*\:[ ]*(\d+(?:[ ]*,[ ]*\d+)*)>/i)
      begin
      scan[0][0].scan(/\d+/).each {|b|
      @self_effects.push(@effects[b.to_i - 1]) if b.to_i >= 1
      }
      rescue Exception => e
      end
      }
    end
    @self_effects
  end
end

class Game_Battler
  alias jet3745_item_effect_apply item_effect_apply
  def item_effect_apply(user, item, effect, reffed = false)
    if item.is_a?(RPG::Skill) && item.self_effects.include?(effect) && !reffed
      user.item_effect_apply(user, item, effect, true)
      return
    end
    jet3745_item_effect_apply(user, item, effect)
  end
end