#===============================================================================
# Mouse System (RGSS3)
# By Jet10985(Jet)
# Some Code by: Woratana, Berka
# Uses: ListRA-92's Path Finding
# Super Heavy Testing/Debug Help/Requested By: Nathanial(Beleren)
#===============================================================================
# This script will allow full use of the mouse inside of rmvx for various
# purposes.
# This script has: 7 customization options.
#===============================================================================
# Overwritten Methods:
# Game_Player: move_by_input
#-------------------------------------------------------------------------------
# Aliased methods:
# Scene_Map: update, terminate, update_transfer_player
# Input: update, trigger?, press?, repeat?, dir4, dir8
# Window_Selectable: update, top_row=
# Scene_File: update
# Window_NameInput: update
# Game_Temp: initialize
# Game_Event: initialize, update
#===============================================================================

=begin
Showing text above event when mouse hovers:

If you want a message to appear over an event's head if the mouse is hovering
over the event, put this comment in the event:

MOUSE TEXT MESSAGE HERE

everything after TEXT will be the hovering display.
--------------------------------------------------------------------------------
Change mouse picture above event when mouse hovers:

If you want the mouse's picture to temporarily change whne over an event, put
this comment in the event

MOUSE PIC NAME/NUMBER

if you put a name, the mouse will become that picture, but if you put a number
then the mouse will become the icon that is the id number
--------------------------------------------------------------------------------
Specific mouse click movement routes:

If you want the player to land specifically in a square around an event when
they click to move on the event, put one of these comments in the event:

MOUSE MOVE UP/LEFT/RIGHT/DOWN

only put the direction that you want the player to land on.
--------------------------------------------------------------------------------
Click to activate:

If you want an event to automatically start when it is clicked on, place
this in an event comment:

MOUSE CLICK
--------------------------------------------------------------------------------
Don't stop the player when walking over a touch event:

By default, this script will stop a mouse-caused movement if the player walks
over/under a player touch/event touch event. If you want the event to activate,
but for the player to keep walking to their destination, put this comment in the
event:

MOUSE NOSTOP
--------------------------------------------------------------------------------
Ignore Events:

To have an event be ignored when the mouse makes it's movement path(as if the
event isn't there), put this comment in the event:

MOUSE THROUGH
--------------------------------------------------------------------------------
Extra Notes:

In selectable windows that have more items than what's shown, players can
either put the mouse below the window to scroll down, OR use the mouse's
scroll wheel to scroll up/down.

You can activate action button events by standing next to the event and clicking
on it with the mouse.
=end
module JetMouse
  
  # If you are using a graphic, this is it.
  # It must be in the Graphics/System folder.
  CURSOR_PICTURE = "cursor-mouse"
  
  # If you aren't using a graphic, this icon will be the mouse.
  # To use the icon, just put a non-existant picture as the above config
  ICON_INDEX = 387
  
  # Do you want the player to be able to move by clicking the mouse?
  ALLOW_MOUSE_MOVEMENT = true
  
  # Do you want mouse movement to do 8-dir walking?
  # Requires 8-Dir Walking by Jet.
  DO_8DIR_WALKING = false
  
  # Turning this switch on will make the mouse invisible and unusuable until
  # the switch is turned off
  TURN_MOUSE_OFF_SWITCH = 99
  
  # Do you want the mouse to check for mouse wheel scrolling in selectbale
  # windows? Not using this may reduce some rare cases of lag.
  USE_WHEEL_DETECTION = false
  
  # Do you want to use the Dijkstra formula for pathfinding?
  # This is more accurate, but slower.
  USE_DIJKSTRA = true
  
end

#===============================================================================
# DON'T EDIT FURTHER UNLESS YOU KNOW WHAT TO DO.
#===============================================================================
module Mouse
  
  Get_Message = Win32API.new('user32', 'GetMessage', 'plll', 'l')
  GetAsyncKeyState = Win32API.new("user32", "GetAsyncKeyState", 'i', 'i')
  GetKeyState = Win32API.new("user32", "GetKeyState", 'i', 'i')
  SetCursorPos = Win32API.new('user32', 'SetCursorPos', 'nn', 'n')
  GetCursorPo = Win32API.new('user32', 'GetCursorPos', 'p', 'i')
  ScreenToClient = Win32API.new('user32', 'ScreenToClient', 'lp', 'i')
  FindWindowA = Win32API.new('user32', 'FindWindowA', 'pp', 'l')
  GetClientRect = Win32API.new('user32', 'GetClientRect', 'lp', 'i')
  GetWindowRect = Win32API.new('user32', 'GetWindowRect', 'lp', 'i')
  contents = File.open('Game.ini', 'r') { |f| f.read }
  q = contents[/Title=(.+)/].nil? ? "cccc" : $1
  @handle = FindWindowA.call('RGSS Player', q)
  module_function
  
  Point = Struct.new(:x, :y)
  
  Message = Struct.new(:message, :wparam, :lparam, :pt)
  
  Param = Struct.new(:x, :y, :scroll)
  
  Scroll = 0x0000020A
  
  def hiword(dword); return((dword&0xffff0000) >> 16)&0x0000ffff; end
  def loword(dword); return dword&0x0000ffff; end
    
  def word2signed_short(value)
    return value if (value&0x8000) == 0
    return -1 *((~value&0x7fff) + 1)
  end
  
  def unpack_dword(buffer, offset = 0)
    ret = buffer[offset + 0]&0x000000ff
    ret |=(buffer[offset + 1] <<(8 * 1))&0x0000ff00
    ret |=(buffer[offset + 2] <<(8 * 2))&0x00ff0000
    ret |=(buffer[offset + 3] <<(8 * 3))&0xff000000
    return ret
  end
  
  def unpack_msg(buffer)
    msg = Message.new; msg.pt = Point.new
    msg.message=unpack_dword(buffer,4*1)
    msg.wparam = unpack_dword(buffer, 4 * 2)
    msg.lparam = unpack_dword(buffer,4*3)
    msg.pt.x = unpack_dword(buffer, 4 * 5)
    msg.pt.y = unpack_dword(buffer, 4 * 6)
    return msg
  end
  
  def wmcallback(msg)
    return unless msg.message == Scroll
    param = Param.new
    param.x = word2signed_short(loword(msg.lparam))
    param.y = word2signed_short(hiword(msg.lparam))
    param.scroll = word2signed_short(hiword(msg.wparam))
    return [param.x, param.y, param.scroll]
  end
  
  def click?(button)
    return false if $game_switches[JetMouse::TURN_MOUSE_OFF_SWITCH]
    return true if @keys.include?(button)
    return false
  end 
  
  def press?(button)
    return false if $game_switches[JetMouse::TURN_MOUSE_OFF_SWITCH]
    return true if @press.include?(button)
    return false
  end
  
  def set_pos(x_pos = 0, y_pos = 0)
    width,height = client_size
    if (x_pos.between?(0, width) && y_pos.between?(0, height))
      SetCursorPos.call(client_pos[0] + x_pos,client_pos[1] + y_pos)
    end
  end
  
  def update
    return if $game_switches[JetMouse::TURN_MOUSE_OFF_SWITCH]
    @pos = Mouse.pos
    @keys, @press = [], []
    @keys.push(1) if GetAsyncKeyState.call(1)&0x01==1
    @keys.push(2) if GetAsyncKeyState.call(2)&0x01==1
    @keys.push(3) if GetAsyncKeyState.call(4)&0x01==1
    @press.push(1) if pressed?(1)
    @press.push(2) if pressed?(2)
    @press.push(3) if pressed?(4)
  end 
  
  def pressed?(key)
    return true unless GetKeyState.call(key).between?(0, 1)
    return false
  end
  
  def global_pos
    pos = [0, 0].pack('ll')
    GetCursorPo.call(pos) != 0 ?(return pos.unpack('ll')):(return [0, 0])
  end
  
  def pos
    return 0, 0 if $game_switches[JetMouse::TURN_MOUSE_OFF_SWITCH]
    x, y = screen_to_client(*global_pos)
    width, height = client_size
    begin
      x = 0 if x <= 0; y = 0 if y <= 0
      x = width if x >= width; y = height if y >= height
      return x, y
    end
  end
  
  def screen_to_client(x, y)
    return nil unless x && y
    pos = [x, y].pack('ll')
    ScreenToClient.call(@handle, pos) != 0 ?(return pos.unpack('ll')):(return [0, 0])
  end
  
  def client_size
    rect = [0, 0, 0, 0].pack('l4')
    GetClientRect.call(@handle, rect)
    right,bottom = rect.unpack('l4')[2..3]
    return right, bottom
  end
  
  def client_pos
    rect=[0, 0, 0, 0].pack('l4')
    GetWindowRect.call(@handle, rect)
    left, upper = rect.unpack('l4')[0..1]
    return left + 4, upper + 30
  end
  
  def grid
    return [-1, -1] if $game_switches[JetMouse::TURN_MOUSE_OFF_SWITCH]
    return [-1, -1] if @pos.nil?
    return [(@pos[0]/32),(@pos[1]/32)]
  end
  
  def true_grid
    return [grid[0] + $game_map.display_x / 256, grid[1] + $game_map.display_y / 256]
  end
  
  def area?(x, y, width, height)
    return false if $game_switches[JetMouse::TURN_MOUSE_OFF_SWITCH]
    return false if @pos.nil?
    return @pos[0].between?(x, width + x) && @pos[1].between?(y, height + y)
  end
  
  def scroll
    msg="\0"*32;Get_Message.call(msg,0,0,0);r=wmcallback(unpack_msg(msg))
    return r if !r.nil?
  end
end

class Sprite_Cursor < Sprite_Base
  
  attr_accessor :current_cursor, :not_default
  
  include JetMouse
  
  def initialize
    super
    @current_cursor = ""
    @not_default = false
    Win32API.new('user32', 'ShowCursor', 'i', 'i').call(0)
    self.z = 5004
    create_cursor(CURSOR_PICTURE)
    $game_switches = []
    update
  end
  
  def create_cursor(cursor = "")
    self.bitmap.dispose unless self.bitmap.nil?
    self.bitmap = nil
    begin
      self.bitmap = Cache.system(cursor)
      @current_cursor = cursor
    rescue
      self.bitmap = Bitmap.new(24, 24)
      bitmap = Cache.system("Iconset")
      rect = Rect.new(ICON_INDEX % 16 * 24, ICON_INDEX / 16 * 24, 24, 24)
      self.bitmap.blt(0, 0, bitmap, rect)
      @current_cursor = ICON_INDEX
    end
    @not_default = false
  end
  
  def change_cursor(cursor)
    self.bitmap.dispose unless self.bitmap.nil?
    self.bitmap = nil
    begin
      self.bitmap = Cache.system(cursor)
      @current_cursor = cursor
      @not_default = true
    rescue
      begin
        self.bitmap = Bitmap.new(24, 24)
        bitmap = Cache.system("Iconset")
        rect = Rect.new(cursor % 16 * 24, cursor / 16 * 24, 24, 24)
        self.bitmap.blt(0, 0, bitmap, rect)
        @current_cursor = cursor
        @not_default = true
      rescue
        create_cursor(CURSOR_PICTURE)
      end
    end
  end

  def update
	  return if self.disposed?
    if $game_switches[TURN_MOUSE_OFF_SWITCH]
      self.opacity = 0 unless self.opacity == 0
    end
    self.opacity = 255 unless self.opacity == 255
    super
    x = self.x
    y = self.y
    self.x, self.y = Mouse.pos
    self.x -= 8 if @not_default
    self.y -= 8 if @not_default
  end
end

$cursor = Sprite_Cursor.new

module Input
  
  class << self
    
    alias jet5888_press? press? unless $@
    def press?(arg)
      if arg == Input::C
        return true if Mouse.press?(1)
      elsif arg == Input::B
        return true if Mouse.press?(2)
      end
      jet5888_press?(arg)
    end
    
    alias jet5888_repeat? repeat? unless $@
    def repeat?(arg)
      if arg == Input::C
        return true if Mouse.click?(1)
      elsif arg == Input::B
        return true if Mouse.click?(2)
      end
      jet5888_repeat?(arg)
    end
    
    alias jet5888_trigger? trigger? unless $@
    def trigger?(arg)
      if arg == Input::C
        return true if Mouse.click?(1)
      elsif arg == Input::B
        return true if Mouse.click?(2)
      end
      jet5888_trigger?(arg)
    end
    
    alias jet8432_update update unless $@
    def update(*args, &block)
      jet8432_update(*args, &block)
      if $game_switches[JetMouse::TURN_MOUSE_OFF_SWITCH] && $cursor.opacity != 0
        $cursor.opacity = 0
      end
      $cursor.update unless $game_switches[JetMouse::TURN_MOUSE_OFF_SWITCH]
      Mouse.update unless $game_switches[JetMouse::TURN_MOUSE_OFF_SWITCH]
    end
  
    alias jet1626_dir4 dir4 unless $@
    def dir4(*args, &block)
      if !$game_temp.nil?
        if $game_temp.move_because_of_mouse
          if !$game_temp.mouse_path.empty? && $game_player.movable? && 
              !$game_map.interpreter.running? && SceneManager.scene_is?(Scene_Map) &&
              jet1626_dir4(*args, &block) == 0
            f = $game_temp.mouse_path.reverse!.pop
            $game_temp.mouse_path.reverse!
            return f * 2
          else
            $game_temp.move_because_of_mouse = false
            $game_temp.mouse_path = []
          end
        end
      end
      jet1626_dir4(*args, &block)
    end
    
    alias jet1626_dir8 dir8 unless $@
    def dir8(*args, &block)
      if !$game_temp.nil?
        if $game_temp.move_because_of_mouse
          if !$game_temp.mouse_path.empty? && $game_player.movable? && 
              !$game_map.interpreter.running? && SceneManager.scene_is?(Scene_Map) &&
              jet1626_dir8(*args, &block) == 0
            f = $game_temp.mouse_path.reverse!.pop
            $game_temp.mouse_path.reverse!
            if [1, 2, 3, 4].include?(f)
              return f * 2
            else
              case f
              when 5
                return 1
              when 6
                return 3
              when 7
                return 7
              when 8
                return 9
              end
            end
          else
            $game_temp.move_because_of_mouse = false
            $game_temp.mouse_path = []
          end
        end
      end
      jet1626_dir8(*args, &block)
    end
  end
end

class Game_Player
	
	def move_by_input
    return if !movable? || $game_map.interpreter.running?
    move = Input.dir4
    move_straight(move) if move > 0
  end
end

class Game_Character
  
  def find_mouse_path(trgt_x, trgt_y)
	  fake_char = Game_Character.new
	  fake_char.moveto(self.x, self.y)
		fake_char.set_direction(self.direction)
	  path = []
	  g = MGraph.new(JetMouse::DO_8DIR_WALKING ? 8 : 4)
    until fake_char.x == trgt_x && fake_char.y == trgt_y
      if JetMouse::USE_DIJKSTRA
        path.push(g.Dijkstra(fake_char.x, fake_char.y, trgt_x, trgt_y))
      else
        path.push(g.AStar(fake_char.x, fake_char.y, trgt_x, trgt_y))
      end
      if path[-1] != 0
        fake_char.move_straight(path[-1] * 2)
      else
        path = []
        break
      end
    end
    Graphics.frame_reset
    return path.reverse
  end
end

class PQueue < Array

  def addEl(ii)
    iii = 0
    while iii < self.length && self[iii] < ii
      iii += 1
    end
    self.insert(iii,ii)
  end

  def remEl(ii)
    iii = 0
    while iii < self.length && self[iii] < ii
      iii += 1
    end
    self.delete_at(iii)
  end

  def found?(ii)
    i = 0
    j = self.length-1
    ff = false
    while (not ff) && i <= j
      mid = (i+j)/2
      if self[mid] == ii
        ff = true
      else
        if self[mid] < ii
          i = mid+1
        else
          j = mid-1
        end
      end
    end
    return ff
  end
end

class MGraph

  attr_accessor :w, :h
  attr_accessor :neighbors
  attr_accessor :passage_table

  def initialize(nh, char = $game_player)
    @w = $game_map.width
    @h = $game_map.height
    @neighbors = nh
    @passage_table = Table.new(@w,@h,nh)
    for i in 0..@w
      for j in 0..@h
        for k in 1..nh
          @passage_table[i,j,k-1] = char.passable?(i, j, k * 2) ? 1 : 0
          if not neighborExist?(nodeOf(i, j), k)
            @passage_table[i, j, k - 1] = 0
          end
        end
      end
    end
  end

  def nodeOf(x,y)
    return y*@w+x+1
  end

  def xNode(idxNode)
    return (idxNode-1) % @w
  end
  
  def yNode(idxNode)
    return (idxNode-1)/@w
  end

  def neighborOf(idxNode,dir)
    case dir
      when 1
        return (idxNode+@w)
      when 2
        return (idxNode-1)
      when 3
        return (idxNode+1)
      when 4
        return (idxNode-@w)
    end
  end

  def neighborExist?(idxNode,dir)
    case dir
      when 1
        return (yNode(idxNode)<@h-1)
      when 2
        return (xNode(idxNode)>0)
      when 3
        return (xNode(idxNode)<@w-1)
      when 4
        return (yNode(idxNode)>0)
    end
  end

  def reconstruct_path(s,t,vertices_prev)
    u=t
    while vertices_prev[u] != s && vertices_prev[u] != 0
      u = vertices_prev[u]
    end
    case u
      when s+@w
        return 1
      when s-1
        return 2
      when s+1
        return 3
      when s-@w
        return 4
    end
    return 0
  end

  def heuristic_dist(u,v)
    dx = xNode(v)-xNode(u)
    dy = yNode(v)-yNode(u)
    return (dx.abs+dy.abs)
  end
  
  def Dijkstra(x1, y1, x2, y2)
    s = nodeOf(x1, y1)
    t = nodeOf(x2, y2)
    q = PQueue.new(1, 0)
    q.addEl(s)
    vertices_dist = Array.new(@w * @h + 1, 9999)
    vertices_prev = Array.new(@w * @h + 1, 0)
    vertices_dist[s] = 0
    while q.length > 1
      d = vertices_dist[q[1]]
      u = q[1]
      if q.length > 2
        for ii in 2..q.length-1
          if vertices_dist[q[ii]] < d
            d = vertices_dist[q[ii]]
            u = q[ii]
          end
        end
      end
      if u == t
        return reconstruct_path(s,t,vertices_prev)
      end
      q.remEl(u)
      for i in 1..@neighbors
        if @passage_table[xNode(u), yNode(u), i - 1] == 1
          v = neighborOf(u, i)
          alt = vertices_dist[u] + 1
          if alt < vertices_dist[v]
            q.addEl(v)
            vertices_dist[v] = alt
            vertices_prev[v] = u
          end
        end
      end
    end
    return 0
  end
  
  def AStar(x1, y1, x2, y2)
    s = nodeOf(x1, y1)
    t = nodeOf(x2, y2)
    q = PQueue.new(1, 0)
    q.addEl(s)
    q1 = Array.new(@w * @h + 1, false)
    vertices_prev = Array.new(@w * @h + 1, 0)
    vertices_dist = Array.new(@w * @h + 1, 9999)
    h_score = Array.new(@w * @h + 1, 0)
    f_score = Array.new(@w * @h + 1, 9999)
    vertices_dist[s] = 0
    h_score[s] = heuristic_dist(s, t)
    f_score[s] = h_score[s]
    while q.length > 1
      d = f_score[q[1]]
      u = q[1]
      if q.length > 2
        for ii in 2..q.length-1
          if f_score[q[ii]] < d
            d = f_score[q[ii]]
            u = q[ii]
          end
        end
      end
      if u == t
        return reconstruct_path(s, t, vertices_prev)
      end
      q.remEl(u)
      q1[u] = true
      for i in 1..@neighbors
        if @passage_table[xNode(u), yNode(u), i - 1] == 1
          v = neighborOf(u, i)
          if !q1[v]
            tentative_g_score = vertices_dist[u] + 1
            if !q.found?(v)
              q.addEl(v)
              tentative_is_better = true
            elsif tentative_g_score < vertices_dist[v]
              tentative_is_better = true
            else
              tentative_is_better = false
            end
            if tentative_is_better
              if vertices_prev[v] != 0
                if f_score[u] < f_score[vertices_prev[v]]
                  vertices_prev[v] = u
                end
              else
                vertices_prev[v] = u
              end
              vertices_dist[v] = tentative_g_score
              h_score[v] = heuristic_dist(v, t)
              f_score[v] = vertices_dist[v] + h_score[v]
            end
          end
        end
      end
    end
    return 0
  end
end

class Game_Temp
  
  attr_accessor :move_because_of_mouse
  attr_accessor :mouse_controlled_object
  attr_accessor :making_path
  attr_accessor :mouse_path
  attr_accessor :did_mouse_change
  
  alias jet6742_initialize initialize unless $@
  def initialize(*args, &block)
    jet6742_initialize(*args, &block)
    @move_because_of_mouse = false
    @making_path = false
    @mouse_path = []
  end
end

class Window_Selectable
  
  alias jet6742_update update unless $@
  def update(*args, &block)
    jet6742_update(*args, &block)
    update_mouse if self.active && self.visible
  end
  
  alias jet7222_top_row top_row= unless $@
  def top_row=(*args, &block)
    @last_cursor_move = 0 if @last_cursor_move.nil?
    @last_cursor_move -= 1
    return if @in_rect_loop || @last_cursor_move > 0
    jet7222_top_row(*args, &block)
    @last_cursor_move = 10
  end
  
  def update_mouse
    if JetMouse::USE_WHEEL_DETECTION
      f = Mouse.scroll
      if !f.nil?
        if f[2] < 0
          if contents.height > self.height && self.oy - contents.height < -self.height + 32
            self.top_row = self.top_row + 1
          end
        else
          self.top_row = self.top_row - 1 if contents.height > self.height
        end
      end
    end
    original_index = @index
    fake_index = -2
    add_x = self.viewport.nil? ? 0 : self.viewport.ox
    add_y = self.viewport.nil? ? 0 : self.viewport.oy
    self.item_max.times {|i|
      rect = item_rect(i)
      if Mouse.area?(self.x - self.ox + rect.x + 16 + add_x, self.y - self.oy + rect.y + 16 + add_y, rect.width, rect.height)
        fake_index = i
      end
    }
    @index = fake_index == -2 ? original_index : fake_index
    update_cursor
  end
end

class Scene_File
  
  alias wor_scefil_upd_mouse update unless $@
  def update(*args, &block)
    (0..self.item_max - 1).each do |i|
      ix = @savefile_windows[i].x
      iy = @savefile_windows[i].y + 48
      iw = @savefile_windows[i].width
      ih = @savefile_windows[i].height
      if Mouse.area?(ix, iy, iw, ih)
        @savefile_windows[@index].selected = false
        @savefile_windows[i].selected = true
        @index = i
      end
    end
    wor_scefil_upd_mouse(*args, &block)
  end
end

class Window_NameInput
  
  alias wor_winnam_upd_mouse update unless $@
  def update(*args, &block)
    wor_winnam_upd_mouse(*args, &block)
    if self.active and self.visible
      (0..self.table[@page].size - 1).each do |i|
      irect = item_rect(i)
      irx = self.x + 16 + irect.x - self.ox
      iry = self.y + 16 + irect.y - self.oy
      @index = i if Mouse.area?(irx, iry, irect.width, irect.height)
      end
    end
  end
end

class Window_PartyCommand
  
  def update_mouse
    (0..self.item_max - 1).each do |i|
    irect = item_rect(i)
    irx = self.viewport.ox + 16 + irect.x - self.ox
    iry = 288 + 16 + irect.y - self.oy + 64
    self.index = i if Mouse.area?(irx, iry, irect.width, irect.height)
    end
  end
end

class Window_ActorCommand
  
  def update_mouse
    (0..self.item_max - 1).each do |i|
    irect = item_rect(i)
    irx = self.viewport.ox + 288 + 16 + irect.x + 96
    iry = 288 + 16 + irect.y + 64
    self.index = i if Mouse.area?(irx, iry, irect.width, irect.height)
    end
  end
end

class Window_EventPopUp < Window_Base
  
  def initialize(x, y, width, height, text)
    super(x, y, width, height)
    self.opacity = 0
    @text = text
    refresh
  end
  
  def refresh
    self.contents.clear
    self.contents.draw_text(0, 0, self.width, 24, @text)
  end
end

class Game_Event
  
  attr_accessor :popup_window, :page
  
  def check_for_comment(regexp)
    return false if @list.nil?
    for item in @list
      if item.code == 108 or item.code == 408
        if !item.parameters[0][regexp].nil?
          return $1.nil? ? true : $1
        end
      end
    end
    return false
  end
  
  def through
    return true if check_for_comment(/MOUSE THROUGH/i) && $game_temp.making_path
    return @through
  end
  
  alias jet2734_update update unless $@
  def update(*args, &block)
    jet2734_update(*args, &block)
    update_mouse_popup
    update_mouse_change
  end
  
  def update_mouse_popup
    switch = $game_switches[JetMouse::TURN_MOUSE_OFF_SWITCH]
    if Mouse.true_grid == [self.x, self.y] && !switch && !@erased
      f = self.check_for_comment(/MOUSE TEXT(.+)/i)
      if f != false
        q = Bitmap.new(1, 1)
        size = q.text_size(f)
        x = self.screen_x - 16 - size.width / 2
        y = self.screen_y - 52 - size.height / 2
        if self.popup_window != nil
          self.popup_window.dispose
          self.popup_window = nil
        end
        self.popup_window = Window_EventPopUp.new(x, y, 
          size.width + 34, size.height + 34, f)
        q.dispose
        q = nil
      end
    else
      if self.popup_window != nil
        self.popup_window.dispose
        self.popup_window = nil
      end
    end
  end
  
  def update_mouse_change
    if Mouse.true_grid == [self.x, self.y]
      f =(self.check_for_comment(/MOUSE PIC(.+)/i) rescue false)
      if f != false
        if f.to_i != 0
          $cursor.change_cursor(f.to_i) unless $cursor.current_cursor == f.to_i
        else
          $cursor.change_cursor(f) unless $cursor.current_cursor == f
        end
        $game_temp.did_mouse_change = true
      end
    end
  end
end


class Scene_Map
  
  alias jet6742_update update unless $@
  def update(*args, &block)
    if !$game_message.visible
      update_mouse_left_click
    end
    jet6742_update(*args, &block)
    check_mouse_change
  end
  
  alias jet7811_terminate terminate unless $@
  def terminate(*args, &block)
    for event in $game_map.events.values
      next if event.popup_window.nil?
      event.popup_window.dispose unless event.popup_window.disposed?
      event.popup_window = nil
    end
    $cursor.create_cursor(JetMouse::CURSOR_PICTURE) if ![JetMouse::CURSOR_PICTURE,
      JetMouse::ICON_INDEX].include?($cursor.current_cursor)
    $cursor.opacity = 0
    jet7811_terminate(*args, &block)
    $cursor.opacity = 255 unless $game_switches[JetMouse::TURN_MOUSE_OFF_SWITCH]
  end
  
  alias jet8887_update_transfer_player update_transfer_player unless $@
  def update_transfer_player(*args, &block)
    if $game_player.transfer?
      $cursor.create_cursor(JetMouse::CURSOR_PICTURE) if ![JetMouse::CURSOR_PICTURE,
        JetMouse::ICON_INDEX].include?($cursor.current_cursor)
    end
    jet8887_update_transfer_player(*args, &block)
  end
  
  def check_mouse_change
    return if $game_switches[JetMouse::TURN_MOUSE_OFF_SWITCH]
    if $game_message.visible || $game_player.transfer?
      $cursor.create_cursor(JetMouse::CURSOR_PICTURE) if ![JetMouse::CURSOR_PICTURE,
        JetMouse::ICON_INDEX].include?($cursor.current_cursor)
      return
    end
    $cursor.create_cursor(JetMouse::CURSOR_PICTURE) if $game_temp.did_mouse_change.nil? && 
      ![JetMouse::CURSOR_PICTURE, JetMouse::ICON_INDEX].include?($cursor.current_cursor)
    $game_temp.did_mouse_change = nil
  end

  def update_mouse_left_click
    return if $game_map.interpreter.running? || $game_player.transfer?
    if Mouse.click?(1)
      event_activated = false
      for event in $game_map.events_xy(*Mouse.true_grid)
        if event.check_for_comment(/MOUSE CLICK/i)
          event.start
          event_activated = true
        elsif (event.x - $game_player.x).abs + (event.y - $game_player.y).abs == 1
          if ![3, 4].include?(event.trigger) && 
               (![0, 2].include?(event.priority_type) || event.trigger == 0) &&
                  ![0, 1].include?(event.page.list.size)
            if (event.y - $game_player.y).abs >
               (event.x - $game_player.x).abs
              if event.y - $game_player.y > 0
                $game_player.set_direction(2)
              else
                $game_player.set_direction(8)
              end
            else
              if event.x - $game_player.x > 0
                $game_player.set_direction(6)
              else
                $game_player.set_direction(4)
              end
            end
            event.start
            event_activated = true
            break
          end
        end
        if !event_activated
          for i in ["UP", "DOWN", "RIGHT", "LEFT"]
            if event.check_for_comment(/MOUSE MOVE #{i}/i)
              event_activated = true
              case i
              when "UP"
                x, y = event.x, event.y - 1
              when "DOWN"
                x, y = event.x, event.y + 1
              when "LEFT"
                x, y = event.x - 1, event.y
              when "RIGHT"
                x, y = event.x + 1, event.y
              end
              break
            end
          end
        end
      end
      if !event_activated
        x, y = *Mouse.true_grid
      end
      if !x.nil?
        $game_temp.move_because_of_mouse = true
        g = $game_player.find_mouse_path(x, y)
        $game_temp.mouse_path = g
      end
    end
  end
end