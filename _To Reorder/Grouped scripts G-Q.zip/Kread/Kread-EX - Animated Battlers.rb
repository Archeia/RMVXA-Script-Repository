#:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=
#  ▼ Animated Battlers
#  Author: Kread-EX
#  Version 1.08
#  Release date: 28/11/2012
#:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=

#------------------------------------------------------------------------------
#  ▼ UPDATES
#------------------------------------------------------------------------------
# # 07/04/2013. Added option for linking animations during skill use.
# # 04/04/2013. Fixed a bug with guarding.
# # 18/02/2013. Fixed another bug with Dual Wielding.
# # 16/02/2013. Fixed a bug with Dual Wielding.
# # 15/02/2013. Compatibility with Symphony.
# # 15/02/2013. Added state animations and a few other options.
# # 15/02/2013. Compatibility with modern algebra's Flash Enemy.
# # 05/01/2013. Compatibility with Banish Skills.
#------------------------------------------------------------------------------
#  ▼ INTRODUCTION
#------------------------------------------------------------------------------
# # This script will allow you to use battle animations as animation battlers.
# # It sounds simple enough but please read the instructions.
# #
# # DON'T ASK ME FOR A DEMO. PLEASE.
#------------------------------------------------------------------------------
#  ▼ INSTRUCTIONS
#------------------------------------------------------------------------------
# # I direct you to this page: http://wp.me/P22oyp-ca
#------------------------------------------------------------------------------
#  ▼ TERMS OF USAGE
#------------------------------------------------------------------------------
# #  You are free to adapt this work to suit your needs.
# #  You can use this work for commercial purposes if you like it.
# #  Credit is appreciated.
# #
# # For support:
# # grimoirecastle.wordpress.com
# # rpgmakerweb.com
#------------------------------------------------------------------------------
#  ▼ COMPATIBILITY
#------------------------------------------------------------------------------
# # Works with the DBS and Ace Battle Engine.
# # List of aliases and overwrites:
# #
# # DataManager
# # load_database (alias)
# # load_aniB_notetags (new method)
# #
# # BattleManager
# # process_victory (alias)
# #
# # RPG::Actor, RPG::Class, RPG::Enemy
# # load_aniB_notetags (new method)
# # animation_data (new method)
# #
# # RPG::UsableItem
# # load_aniB_notetags (new method)
# # battler_anim_id (new attr method)
# # move_to_target (new attr method)
# #
# # Game_Battler
# # skill_pose_active (new attr method)
# # item_pose_active (new attr method)
# # x_destination (new attr method)
# # y_destination (new attr method)
# # movement_type (new attr method)
# # animation_data (new method)
# # skill_battler_anim (new method)
# # item_battler_anim (new method)
# # on_action_end (alias)
# # is_moving? (new method)
# #
# # Game_Actor
# # victory_pose (new attr method)
# # perform_collapse_effect (alias)
# # screen_x (overwrite)
# # screen_y (overwrite)
# # screen_z (overwrite)
# # use_sprite? (overwrite)
# #
# # Sprite_Battler
# # screen_x (new attr method)
# # screen_y (new attr method)
# # initialize (alias)
# # update (alias)
# # update_bitmap (overwrite)
# # update_position (overwrite)
# # update_movement (new method)
# # update_battler_poses (new method)
# # animation? (overwrite)
# # battler_animation? (new method)
# # start_battler_animation (new method)
# # load_battler_animation_bitmap (new method)
# # make_battler_animation_sprites (new method)
# # set_battler_animation_origin (new method)
# # move_battler_animation (new method)
# # dispose_battler_animation (new method)
# # update_battler_animation (new method)
# # battler_animation_set_sprites (new method)
# # battler_animation_process_timing (new method)
# # get_current_pose (new method)
# # update_collapse (alias)
# # update_boss_collapse (overwrite)
# #
# # Window_BattleActor
# # update (alias)
# #
# # Scene_Battle
# # execute_action (alias)
# # move_to_target (new method)
# # move_back_to_pos (new method)
#------------------------------------------------------------------------------
=begin
<animation_block>
Always start the tag settings with this.

standing: n
Set the idle animation to n (n being the animation ID in the database).

danger: n
Set the danger animation (HP > 50%) to n.

hit: n
Set the hit animation to n.

dead: n
Set the dead animation to n. Enemies always collapse once dead, so they don’t need it. For bosses enemies, see the Boss Collapsing section.

victory: n
Set the victory pose animation to n. Actors only.

item_default: n
Set the default animation played for item use. Overwritten by individual item settings.

skill_default: n
Set the default animation played for skill use. Overwritten by individual skill settings.

move_f: n
Set the animation played when the active battler moves towards their target.

move_b: n
Set the animation played when the active battler goes back to their initial location.

guard: n
Set the animation played when the active battler guards.

mirror
If this tag is present, the animations will all be flipped horizontally.

</animation_block>
Must end the settings.

There are two additional tags used for item and skill settings.
skill: skill_id, anim_id, skill_id, anim_id...
If two battlers have the same skill, you don’t have to duplicate the skill. Instead you use this tag on actors and/or enemies to associate an animation ID to a skill ID.

item: item_id, anim_id, item_id, anim_id...
Same as above, but with items.

Note: Multiple lines are not supported but you can write the same tag again like this:
<skill: 36, 158, 76, 134, 99, 200>
<skill: 1, 159, 34, 121, 76, 206>

Tagging your skills and items
Two tags are available for skills and items alike:
<anim_id: n>
This is the default animation ID for the skill/item. It will be overwritten by actor and enemy tags.

<move_to_target>
This tag indicates that the battler will approach their target before using the item or the skill.

Additional settings
Two additional settings can be found within the script itself.
ACTOR_POSITIONS = [[400, 300], [460, 320], [520, 340], [580, 360]]
Indicates the coordinates of every actor on the screen. Default settings optimized for four-sized party and 640×480 resolution. There’s no miracle setting: experiment and keep what you prefer.

VICTORY_DELAY = 30
The number of frames the victory pose keeps being played.

Boss Collapsing
The special boss collapse feature doesn’t work the same way as before. It now enables the dead tag for the enemies as well. You can make any kind of death animation you like.

Animation Linking
You can play animations successively by putting a ToXXX marker in the first animation’s name, where XXX is the ID of the second animation. Currently only works for skills.
=end

($imported ||= {})['KRX-AnimatedBattlers'] = true

#puts 'Load: Animated Battlers v1.08 by Kread-EX'

module KRX
#===========================================================================
# ■ CONFIGURATION
#===========================================================================

  ACTOR_POSITIONS = [[430, 250], [487, 274], [550, 300], [540, 300]]
  VICTORY_DELAY = 30
  MAX_SPRITES = 16
  MOVEMENT_Y_OFFSET = 70
  # Set this to true to make the attack anim play twice for dual wielders.
  DUAL_WIELDING = false
 
#===========================================================================
# ■ CONFIGURATION ENDS HERE
#===========================================================================
  module REGEXP
    ANIM_TAG_START = /<animation_block>/i
    ANIM_TAG_END = /<\/animation_block>/i
    ANIM_STANDING = /standing:[ ]*(\d+)/i
    ANIM_DANGER = /danger:[ ]*(\d+)/i
    ANIM_HIT = /hit:[ ]*(\d+)/i
    ANIM_DEAD = /dead:[ ]*(\d+)/i
    ANIM_VICTORY = /victory:[ ]*(\d+)/i
    ANIM_ITEM_DEFAULT = /item_default:[ ]*(\d+)/i
    ANIM_SKILL_DEFAULT = /skill_default:[ ]*(\d+)/i
    ANIM_ITEM = /item:[ ]*(\d+(?:\s*,\s*\d+*)*)/i
    ANIM_SKILL = /skill:[ ]*(\d+(?:\s*,\s*\d+*)*)/i
    ANIM_STATE = /state:[ ]*(\d+(?:\s*,\s*\d+*)*)/i
    ANIM_MOV_F = /move_f:[ ]*(\d+)/
    ANIM_MOV_B = /move_b:[ ]*(\d+)/
    ANIM_MIRROR = /mirror/i
    ANIM_GUARD = /guard:[ ]*(\d+)/i
    ANIM_ON_ITEM = /<anim_id:[ ]*(\d+)>/i
    ANIM_TO_TARGET = /<move_to_target:*[ ]*(-?\d+)*>/i
  end
 
end

#===========================================================================
# ■ DataManager
#===========================================================================

module DataManager  
    #--------------------------------------------------------------------------
    # ● Loads the database
    #--------------------------------------------------------------------------
    class << self; alias_method(:krx_aniB_dm_ld, :load_database); end
    def self.load_database
        krx_aniB_dm_ld
        load_aniB_notetags
    end  
    #--------------------------------------------------------------------------
    # ● Loads the note tags
    #--------------------------------------------------------------------------
    def self.load_aniB_notetags
        groups = [$data_skills, $data_items, $data_actors, $data_classes,
    $data_enemies]
        for group in groups
            for obj in group
                next if obj.nil?
                obj.load_aniB_notetags
            end
        end
        #puts "Read: Animated Battlers Notetags"
    end
end

#===========================================================================
# ■ BattleManager
#===========================================================================

module BattleManager
    #--------------------------------------------------------------------------
    # ● Process the battle victory
    #--------------------------------------------------------------------------
  class << self; alias_method(:krx_aniB_bm_pv, :process_victory); end
  def self.process_victory
    $game_party.members.each {|m| m.victory_pose = true}
    KRX::VICTORY_DELAY.times {SceneManager.scene.update_basic}
    krx_aniB_bm_pv
    $game_party.members.each {|m| m.victory_pose = false}
  end
end


#===========================================================================
# ■ RPG::Actor, RPG::Class, RPG::Enemy
#===========================================================================

module KRX
  module ANIMATED_BATTLERS
    #--------------------------------------------------------------------------
    # ● Loads the note tags
    #--------------------------------------------------------------------------
    def load_aniB_notetags
      @animation_data = {}
      @note.split(/[\r\n]+/).each do |line|
        case line
        when KRX::REGEXP::ANIM_TAG_START
          @enable_aniB_tags = true
        when KRX::REGEXP::ANIM_TAG_END
          @enable_aniB_tags = false
        when KRX::REGEXP::ANIM_STANDING
          @animation_data[:stand] = $1.to_i if @enable_aniB_tags
        when KRX::REGEXP::ANIM_DANGER
          @animation_data[:danger] = $1.to_i if @enable_aniB_tags
        when KRX::REGEXP::ANIM_HIT
          @animation_data[:hit] = $1.to_i if @enable_aniB_tags
        when KRX::REGEXP::ANIM_DEAD
          @animation_data[:dead] = $1.to_i if @enable_aniB_tags
        when KRX::REGEXP::ANIM_VICTORY
          @animation_data[:victory] = $1.to_i if @enable_aniB_tags
        when KRX::REGEXP::ANIM_ITEM_DEFAULT
          @animation_data[:dflt_item] = $1.to_i if @enable_aniB_tags
        when KRX::REGEXP::ANIM_SKILL_DEFAULT
          @animation_data[:dflt_skill] = $1.to_i if @enable_aniB_tags
        when KRX::REGEXP::ANIM_MIRROR
          @animation_data[:mirror] = true if @enable_aniB_tags
        when KRX::REGEXP::ANIM_GUARD
          @animation_data[:guard] = $1.to_i if @enable_aniB_tags
        when KRX::REGEXP::ANIM_MOV_F
          @animation_data[:move_f] = $1.to_i if @enable_aniB_tags
        when KRX::REGEXP::ANIM_MOV_B
          @animation_data[:move_b] = $1.to_i if @enable_aniB_tags
        when KRX::REGEXP::ANIM_ITEM
          if @enable_aniB_tags
            @animation_data[:item] ||= []
            $1.scan(/\d+/).each {|i| @animation_data[:item].push(i.to_i)}
          end
        when KRX::REGEXP::ANIM_SKILL
          if @enable_aniB_tags
            @animation_data[:skill] ||= []
            $1.scan(/\d+/).each {|i| @animation_data[:skill].push(i.to_i)}
          end
        when KRX::REGEXP::ANIM_STATE
          if @enable_aniB_tags
            @animation_data[:states] ||= []
            $1.scan(/\d+/).each {|i| @animation_data[:states].push(i.to_i)}
          end
        end
      end
    end
    #--------------------------------------------------------------------------
    # ● Returns the animation settings
    #--------------------------------------------------------------------------
    def animation_data(key)
      @animation_data[key]
    end
  end
end

class RPG::Actor < RPG::BaseItem
  include KRX::ANIMATED_BATTLERS
end

class RPG::Class < RPG::BaseItem
  include KRX::ANIMATED_BATTLERS
end

class RPG::Enemy < RPG::BaseItem
  include KRX::ANIMATED_BATTLERS
end

#===========================================================================
# ■ RPG::UsableItem
#===========================================================================

class RPG::UsableItem < RPG::BaseItem
    #--------------------------------------------------------------------------
    # ● Public instance variables
    #--------------------------------------------------------------------------
  attr_reader     :battler_anim_id
  attr_reader     :move_to_target
  attr_reader     :move_direction
    #--------------------------------------------------------------------------
    # ● Loads the note tags
    #--------------------------------------------------------------------------
  def load_aniB_notetags
    @note.split(/[\r\n]+/).each do |line|
      case line
      when KRX::REGEXP::ANIM_ON_ITEM
        @battler_anim_id = $1.to_i
      when KRX::REGEXP::ANIM_TO_TARGET
        @move_to_target = true
        @move_direction = $1.to_i
        @move_direction ||= 0
      end
    end
  end
end

#===========================================================================
# ■ Game_Battler
#===========================================================================

class Game_Battler < Game_BattlerBase
    #--------------------------------------------------------------------------
    # ● Public instance variables
    #--------------------------------------------------------------------------
  attr_accessor   :skill_pose_active
  attr_accessor   :item_pose_active
  attr_accessor   :x_destination
  attr_accessor   :y_destination
  attr_accessor   :movement_type
    #--------------------------------------------------------------------------
    # ● Returns the battler animation data
    #--------------------------------------------------------------------------
  def animation_data(key)
    if actor?
      if actor.animation_data(key).nil?
        self.class.animation_data(key)
      else
        actor.animation_data(key)
      end
    else
      enemy.animation_data(key)
    end
  end
    #--------------------------------------------------------------------------
    # ● Returns the battler animation ID for a specific skill
    #--------------------------------------------------------------------------
  def skill_battler_anim(id)
    data = animation_data(:skill) || []
    data.each_index do |i|
      next if i % 2 != 0
      return data[i+1] if data[i] == id
    end
    $data_skills[id].battler_anim_id ? $data_skills[id].battler_anim_id :
    animation_data(:dflt_skill)
  end
    #--------------------------------------------------------------------------
    # ● Returns the battler animation ID for a specific item
    #--------------------------------------------------------------------------
  def item_battler_anim(id)
    data = animation_data(:item) || []
    data.each_index do |i|
      next if i % 2 != 0
      return data[i+1] if data[i] == id
    end
    $data_items[id].battler_anim_id ? $data_items[id].battler_anim_id :
    animation_data(:dflt_item)
  end
    #--------------------------------------------------------------------------
    # ● Returns the battler animation ID for a specific state
    #--------------------------------------------------------------------------
  def state_battler_anim(id)
    data = animation_data(:states) || []
    data.each_index do |i|
      next if i % 2 != 0
      return data[i+1] if data[i] == id
    end
    nil
  end
  #--------------------------------------------------------------------------
  # ● Clears the action data
  #--------------------------------------------------------------------------
  alias_method(:krx_aniB_gb_oae, :on_action_end)
  def on_action_end
    krx_aniB_gb_oae
    @skill_pose_active = false
    @item_pose_active = false
  end
  #--------------------------------------------------------------------------
  # ● Determine if the battler is moving on the battle screen
  #--------------------------------------------------------------------------
  unless $imported["YES-BattleSymphony"]
  def is_moving?
    ((@x_destination || 0) > 0) || ((@y_destination || 0) > 0)
  end
  end
    #--------------------------------------------------------------------------
    # ● Update movement (Symphony)
    #--------------------------------------------------------------------------
  if $imported["YES-BattleSymphony"]
  def update_movement
    return unless self.is_moving?
    @move_x_rate = 0 if @screen_x == @destination_x || @move_x_rate.nil?
    @move_y_rate = 0 if @screen_y == @destination_y || @move_y_rate.nil?
    value = [(@screen_x - @destination_x).abs, @move_x_rate].min
    ofx = (@destination_x > @screen_x) ? value : -value
    @screen_x += (@destination_x > @screen_x) ? value : -value
    value = [(@screen_y - @destination_y).abs, @move_y_rate].min
    ofy = (@destination_y > @screen_y) ? value : -value
    @screen_y += (@destination_y > @screen_y) ? value : -value
    sprite.move_battler_animation(ofx, ofy)
  end
    #--------------------------------------------------------------------------
    # ● Update jump (Symphony)
    #--------------------------------------------------------------------------
  def update_jump
    return unless self.is_moving?
    #---
    value = [(@screen_x - @destination_x).abs, @move_x_rate].min
    @screen_x += (@destination_x > @screen_x) ? value : -value
    ofx = (@destination_x > @screen_x) ? value : -value
    @parabola[:x] += value
    @screen_y -= @arc_y
    #---
    if @destination_x == @screen_x
      @screen_y = @destination_y
      @arc_y = 0
      @arc = 0
    else
      a = (2.0*(@parabola[:y0]+@parabola[:y1])-4*@parabola[:h])/(@parabola[:d]**2)
      b = (@parabola[:y1]-@parabola[:y0]-a*(@parabola[:d]**2))/@parabola[:d]
      @arc_y = a * @parabola[:x] * @parabola[:x] + b * @parabola[:x] + @parabola[:y0]
    end
    #---
    @screen_y += @arc_y
    @move_x_rate = 0 if @screen_x == @destination_x
    @move_y_rate = 0 if @screen_y == @destination_y
    sprite.move_battler_animation(ofx, @arc_y)
  end
  end
end

#===========================================================================
# ■ Game_Actor
#===========================================================================

class Game_Actor < Game_Battler
  #--------------------------------------------------------------------------
  # ● Public instance variables
  #--------------------------------------------------------------------------
  attr_accessor   :victory_pose
  #--------------------------------------------------------------------------
  # ● Perform the collapse effect if dead
  #--------------------------------------------------------------------------
  alias_method(:krx_aniB_ga_pce, :perform_collapse_effect)
  def perform_collapse_effect
    return if animation_data(:dead) != nil
    krx_aniB_ga_pce
  end
  #--------------------------------------------------------------------------
  # ● Return x coordinates on battle screen
  #--------------------------------------------------------------------------
  unless $imported["YES-BattleSymphony"]
  def screen_x
    KRX::ACTOR_POSITIONS[index][0]
  end
  #--------------------------------------------------------------------------
  # ● Return y coordinates on battle screen
  #--------------------------------------------------------------------------
  def screen_y
    KRX::ACTOR_POSITIONS[index][1]
  end
  end
  #--------------------------------------------------------------------------
  # ● Return z coordinates on battle screen
  #--------------------------------------------------------------------------
  def screen_z
    return 100
  end
  #--------------------------------------------------------------------------
  # ● The actors will use a sprite
  #--------------------------------------------------------------------------
  def use_sprite?
    return true
  end
end

#==============================================================================
# ■ Sprite_Battler
#==============================================================================

class Sprite_Battler < Sprite_Base
  #--------------------------------------------------------------------------
  # ● Public instance variables
  #--------------------------------------------------------------------------
  attr_reader   :screen_x
  attr_reader   :screen_y
  #--------------------------------------------------------------------------
  # ● Object Initialize
  #--------------------------------------------------------------------------
  alias_method(:krx_aniB_sb_init, :initialize)
  def initialize(viewport, battler = nil)
    krx_aniB_sb_init(viewport, battler)
    @battler_ani_duration = 0
    @blank_bitmap = Bitmap.new(48, 48)
  end
  #--------------------------------------------------------------------------
  # ● Frame Update
  #--------------------------------------------------------------------------
  alias_method(:krx_abiB_sb_update, :update)
  def update
    dispose_battler_animation unless @battler || !battler_animation?
    krx_abiB_sb_update
    update_movement
    @charset_shadow.visible = false if $imported["YES-BattleSymphony"]
  end
  #--------------------------------------------------------------------------
  # ● Updates the initial bitmap
  #--------------------------------------------------------------------------
  def update_bitmap
    self.bitmap = @blank_bitmap if self.bitmap != @blank_bitmap
    update_battler_poses
    update_flash_and_whiten
  end
  #--------------------------------------------------------------------------
  # ● Updates the coordinates
  #--------------------------------------------------------------------------
  unless $imported["YES-BattleSymphony"]
  def update_position
    self.x = @screen_x || @battler.screen_x
    self.y = @screen_y || @battler.screen_y
    self.z = @battler.screen_z
  end
  end
  #--------------------------------------------------------------------------
  # ● Updates the movement positions
  #--------------------------------------------------------------------------
  def update_movement
    return unless @battler
    return if $imported["YES-BattleSymphony"]
    @battler.x_destination ||= 0
    @battler.y_destination ||= 0
    @screen_x ||= @battler.screen_x
    @screen_y ||= @battler.screen_y
    if @battler.x_destination != 0
      sx, dx = @screen_x, @battler.x_destination
      @screen_x = sx > dx ? [sx-16, dx].max : [sx+16, dx].min
      mx = @screen_x - sx
      move_battler_animation(mx, 0)
      if @screen_x == dx
        @battler.x_destination = 0
        update_position
      end
    end
    if @battler.y_destination != 0
      sy, dy = @screen_y, @battler.y_destination
      @screen_y = sy > dy ? [sy-8, dy].max : [sy+8, dy].min
      my = @screen_y - sy
      move_battler_animation(0, my)
      if @screen_y == dy
        @battler.y_destination = 0
        update_position
      end
    end
  end
  #--------------------------------------------------------------------------
  # ● Updates the battler poses
  #--------------------------------------------------------------------------
  def update_battler_poses
    update_battler_animation
    return if @battler.nil? || !@battler_visible
    battler_anim_id = get_current_pose
    return if battler_animation? || @no_loop
    return if battler_anim_id.nil?
    animation = $data_animations[battler_anim_id]
    mirror = @battler.animation_data(:mirror)
    if @battler.dual_wield? && @start_dual_wielding
      @dual_wielding_done = true
      @start_dual_wielding = false
    end
    start_battler_animation(animation, mirror)
  end
  #--------------------------------------------------------------------------
  # ● Updates the flash and whiten effects
  #--------------------------------------------------------------------------
  def update_flash_and_whiten
    unless @battler_ani_sprites.nil?
      if @flash_color && @flash_duration > 0
        d = @flash_duration
        r, g, b = @flash_color.red, @flash_color.green, @flash_color.blue
        @flash_color.alpha = @flash_color.alpha * (d - 1) / d
      end
      @battler_ani_sprites.each do |sprite|
        if @flash_color && @flash_duration > 0
          sprite.color.set(r, g, b, @flash_color.alpha)
        end
        if @effect_type == :whiten
          sprite.color.set(255, 255, 255, 0)
          sprite.color.alpha = 128 - (16 - @effect_duration) * 10
        end
      end
      @flash_duration -= 1 if @flash_duration
    end
  end
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  # * Update Flash (modern algebra Flash Selected Enemy)
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  def update_fse_flash
    unless @battler_ani_sprites.nil?
      @battler_ani_sprites.each do |sprite|
        sprite.color.set(*FSE_FLASH_COLOUR)
        if @effect_duration > (FSE_FLASH_DURATION / 2)
          sprite.color.alpha =
          (FSE_FLASH_DURATION - @effect_duration) * @fse_flash_mod
        else
          sprite.color.alpha = @effect_duration * @fse_flash_mod
        end
      end
    end
  end
  #--------------------------------------------------------------------------
  # ● Determine if an anim is playing
  #--------------------------------------------------------------------------
  def animation?
    @animation != nil || @banim_wait
  end
  #--------------------------------------------------------------------------
  # ● Determine if a battler anim is playing
  #--------------------------------------------------------------------------
  def battler_animation?
    @battler_animation != nil
  end
  #--------------------------------------------------------------------------
  # ● Start the battler animation
  #--------------------------------------------------------------------------
  def start_battler_animation(animation, mirror)
    dispose_battler_animation
    @battler_animation = animation
    @battler_mirror = mirror
    if @battler_animation
      set_animation_rate
      @battler_ani_duration = @battler_animation.frame_max * @ani_rate + 1
      load_battler_animation_bitmap
      make_battler_animation_sprites
      set_battler_animation_origin
      update_battler_animation
    end
   
  end
  #--------------------------------------------------------------------------
  # ● Construct the animation bitmaps
  #--------------------------------------------------------------------------
  def load_battler_animation_bitmap
    animation1_name = @battler_animation.animation1_name
    animation1_hue = @battler_animation.animation1_hue
    animation2_name = @battler_animation.animation2_name
    animation2_hue = @battler_animation.animation2_hue
    @battler_ani_bitmap1 = Cache.animation(animation1_name, animation1_hue)
    @battler_ani_bitmap2 = Cache.animation(animation2_name, animation2_hue)
    if @@_reference_count.include?(@battler_ani_bitmap1)
      @@_reference_count[@battler_ani_bitmap1] += 1
    else
      @@_reference_count[@battler_ani_bitmap1] = 1
    end
    if @@_reference_count.include?(@battler_ani_bitmap2)
      @@_reference_count[@battler_ani_bitmap2] += 1
    else
      @@_reference_count[@battler_ani_bitmap2] = 1
    end
    Graphics.frame_reset
  end
  #--------------------------------------------------------------------------
  # ● Construct the animation sprites to hold the bitmaps
  #--------------------------------------------------------------------------
  def make_battler_animation_sprites
    @battler_ani_sprites = []
    if @use_sprite && !@@ani_spr_checker.include?(@battler_animation)
      KRX::MAX_SPRITES.times do
        sprite = ::Sprite.new(viewport)
        sprite.visible = false
        @battler_ani_sprites.push(sprite)
      end
    end
    @battler_ani_duplicated = @@ani_checker.include?(@battler_animation)
  end
  #--------------------------------------------------------------------------
  # ● Pinpoint the animation origin values
  #--------------------------------------------------------------------------
  def set_battler_animation_origin
    @battler_ani_ox = x - ox + width / 2
    @battler_ani_oy = y - oy + height / 2
    if @battler_animation.position == 0
      @battler_ani_oy -= height / 2
    elsif @battler_animation.position == 2 || @battler_animation.position == 3
      @battler_ani_oy += height / 2
    end
  end
  #--------------------------------------------------------------------------
  # ● Move the animation
  #--------------------------------------------------------------------------
  def move_battler_animation(dx, dy)
    if @battler_ani_sprites
      @battler_ani_ox += dx
      @battler_ani_oy += dy
      @battler_ani_sprites.each do |sprite|
        sprite.x += dx
        sprite.y += dy
      end
    end
  end
  #--------------------------------------------------------------------------
  # ● Free the animation
  #--------------------------------------------------------------------------
  def dispose_battler_animation
   
#    p @@_reference_count
    if @battler_ani_bitmap1
      @@_reference_count[@battler_ani_bitmap1] -= 1
      if @@_reference_count[@battler_ani_bitmap1] == 0
#        @battler_ani_bitmap1.dispose
      end
    end
   
   
    if @battler_ani_bitmap2
      @@_reference_count[@battler_ani_bitmap2] -= 1
      if @@_reference_count[@battler_ani_bitmap2] == 0
        @battler_ani_bitmap2.dispose
      end
    end
    if @battler_ani_sprites
      @battler_ani_sprites.each {|sprite| sprite.dispose }
      @battler_ani_sprites = nil
      @battler_animation = nil
    end
    @battler_ani_bitmap1 = nil
    @battler_ani_bitmap2 = nil
    @flash_color = @flash_duration = nil
  end
  #--------------------------------------------------------------------------
  # ● Update the animation
  #--------------------------------------------------------------------------
  def update_battler_animation
    return unless battler_animation?
    @battler_ani_duration -= 1
    if @battler_ani_duration % @ani_rate == 0
      if @battler_ani_duration > 0
        frame_index = @battler_animation.frame_max
        frame_index -= (@battler_ani_duration + @ani_rate - 1) / @ani_rate
        @last_frame = frame_index
        battler_animation_set_sprites(@battler_animation.frames[frame_index])
        @battler_animation.timings.each do |timing|
          battler_animation_process_timing(timing) if timing.frame == frame_index
        end
      else
        @battler_animation = nil
      end
    end
  end
  #--------------------------------------------------------------------------
  # ● Set the animation sprites' coordinates
  #--------------------------------------------------------------------------
  def battler_animation_set_sprites(frame)
    cell_data = frame.cell_data
    @battler_ani_sprites.each_with_index do |sprite, i|
      next unless sprite
      pattern = cell_data[i, 0]
      if !pattern || pattern < 0
        sprite.visible = false
        next
      end
      sprite.bitmap = pattern < 100 ? @battler_ani_bitmap1 :
      @battler_ani_bitmap2
      sprite.visible = true
      sprite.src_rect.set(pattern % 5 * 192,
      pattern % 100 / 5 * 192, 192, 192)
      if @battler_mirror
        sprite.x = @battler_ani_ox - cell_data[i, 1]
        sprite.y = @battler_ani_oy + cell_data[i, 2]
        sprite.angle = (360 - cell_data[i, 4])
        sprite.mirror = (cell_data[i, 5] == 0)
      else
        sprite.x = @battler_ani_ox + cell_data[i, 1]
        sprite.y = @battler_ani_oy + cell_data[i, 2]
        sprite.angle = cell_data[i, 4]
        sprite.mirror = (cell_data[i, 5] == 1)
      end
      sprite.z = @battler.is_moving? ? self.z + 60 : self.z + i
      sprite.ox = 96
      sprite.oy = 96
      sprite.zoom_x = cell_data[i, 3] / 100.0
      sprite.zoom_y = cell_data[i, 3] / 100.0
      sprite.opacity = cell_data[i, 6] * self.opacity / 255.0
      sprite.blend_type = cell_data[i, 7]
    end
  end
  #--------------------------------------------------------------------------
  # ● Plays sounds and flash effects
  #--------------------------------------------------------------------------
  def battler_animation_process_timing(timing)
    timing.se.play unless @battler_ani_duplicated
    case timing.flash_scope
    when 1
      self.flash(timing.flash_color, timing.flash_duration * @ani_rate)
    when 2
      if viewport && !@battler_ani_duplicated
        viewport.flash(timing.flash_color, timing.flash_duration * @ani_rate)
      end
    when 3
      self.flash(nil, timing.flash_duration * @ani_rate)
    end
  end
  #--------------------------------------------------------------------------
  # ● Determine which pose should be used right now
  #--------------------------------------------------------------------------
  def get_current_pose
    return unless @battler
    # Standing
    new_pose = @battler.animation_data(:stand)
    # Dead
    if @battler.dead?
      new_pose = @battler.animation_data(:dead)
    # Victory
    elsif @battler.is_a?(Game_Actor) && @battler.victory_pose
      new_pose = @battler.animation_data(:victory)
    # Moving toward target
    elsif @battler.is_moving? && @battler.movement_type == 0
      new_pose = @battler.animation_data(:move_f)
    # Moving back to initial position
    elsif @battler.is_moving? && @battler.movement_type == 1
      new_pose = @battler.animation_data(:move_b)
    # Guarding
    elsif @battler.guard?
      new_pose = @battler.animation_data(:guard)
    # Skill
    elsif @battler.skill_pose_active
      new_pose = @battler.skill_battler_anim(@battler.current_action.item.id)
    # Item
    elsif @battler.item_pose_active
      new_pose = @battler.item_battler_anim(@battler.current_action.item.id)
    # Being hit
    elsif @battler.result.hp_damage > 0 && @battler.result.added_states.size == 0
      new_pose = @battler.animation_data(:hit)
    elsif @battler.states.size > 0 || @battler.result.added_states.size > 0
      new_pose = @battler.animation_data(:stand)
      @battler.sort_states.each do |state|
        if @battler.state_battler_anim(state)
          new_pose = @battler.state_battler_anim(state)
          break
        end
      end
    elsif @battler.hp_rate < 0.5
      new_pose = @battler.animation_data(:danger)
    end
    # Saved pose
    @next_pose = nil unless @battler.skill_pose_active
    new_pose = @next_pose if @next_pose
    # Failsafe: use hit animation if no other one is found
    new_pose = @battler.animation_data(:hit) if new_pose.nil?
    # Failsafe: and in last resort, use standing anim
    new_pose = @battler.animation_data(:stand) if new_pose.nil?
    # Animation loops unless specified otherwise
    if @last_pose == new_pose
      @no_loop = !($data_animations[new_pose].name =~ /no[_|\s]loop/i).nil?
    end
    # Forces 1 loop for dual wielding animation
    if KRX::DUAL_WIELDING
    if @battler.dual_wield? && @battler.weapons.size == 2
      if @battler.current_action && @battler.current_action.item
        if @battler.current_action.item.id == @battler.attack_skill_id
          @start_dual_wielding = true unless @dual_wielding_done
          @no_loop = false unless @dual_wielding_done
        end
      end
    end; end
    # Manage wait flag
    fmax = $data_animations[new_pose].frame_max
    @banim_wait = !($data_animations[new_pose].name =~ /wait/i).nil?
    @banim_wait = false if @last_frame == fmax - 1 if @banim_wait
    if @last_frame == fmax - 1
      switch_to = $data_animations[new_pose].name.match(/To(\d+)/i)
      id = switch_to[1] if switch_to
      @next_pose = id.to_i if id
    end
    # Update animation
    if new_pose != @last_pose
      @last_pose = new_pose
      @battler_animation = nil
      @no_loop = false
      @start_dual_wielding = false
      @dual_wielding_done = false
    end
    new_pose
  end
  #--------------------------------------------------------------------------
  # ● Performs the collapse effect
  #--------------------------------------------------------------------------
  alias_method(:krx_aniB_sb_uc, :update_collapse)
  def update_collapse
    krx_aniB_sb_uc
    @battler_ani_sprites.each do |spr|
      spr.blend_type = 1
      spr.color.set(255, 128, 128, 128)
      spr.opacity = 256 - (48 - @effect_duration) * 6
    end
  end
  #--------------------------------------------------------------------------
  # ● Performs the boss collapse effect
  #--------------------------------------------------------------------------
  def update_boss_collapse
    @effect_duration = @battler_ani_duration
  end
  #--------------------------------------------------------------------------
  # ● Mimics the flash effect
  #--------------------------------------------------------------------------
  def flash(color, duration)
    @flash_color = color.dup
    @flash_duration = duration
  end
end

# Ignore in YEA Battle Engine

unless $imported["YEA-BattleEngine"]
#==============================================================================
# ■ Window_BattleEnemy
#==============================================================================

class Window_BattleEnemy < Window_Selectable
  #--------------------------------------------------------------------------
  # ● Frame Update
  #--------------------------------------------------------------------------
  alias_method(:krx_aniB_wbe_update, :update)
  def update
    enemy.sprite_effect_type = :whiten if active
    krx_aniB_wbe_update
  end
end
 
end

# End of YEA Battle Engine check

# Flash Selected Enemy compat.

if $imported[:"FlashSelectedEnemy 1.0.0"]
#==============================================================================
# ■ Window_BattleEnemy
#==============================================================================

class Window_BattleEnemy < Window_Selectable
  #--------------------------------------------------------------------------
  # ● Frame Update
  #--------------------------------------------------------------------------
  def update
    super
  end
end
 
end

# End of Flash Selected Enemy check

#==============================================================================
# ■ Window_BattleActor
#==============================================================================

class Window_BattleActor < Window_BattleStatus
  #--------------------------------------------------------------------------
  # ● Frame Update
  #--------------------------------------------------------------------------
  alias_method(:krx_aniB_wba_update, :update)
  def update
    $game_party.battle_members[index].sprite_effect_type = :whiten if active
    krx_aniB_wba_update
  end
end

#==============================================================================
# ■ Scene_Battle
#==============================================================================

class Scene_Battle < Scene_Base
  #--------------------------------------------------------------------------
  # ● Execute the action previously selected
  #--------------------------------------------------------------------------
  alias_method(:krx_aniB_sb_ea, :execute_action)
  def execute_action
    move_to_target
    if @subject.current_action.item.is_a?(RPG::Skill)
      @subject.skill_pose_active = true
      wait_for_animation
    elsif @subject.current_action.item.is_a?(RPG::Item)
      @subject.item_pose_active = true
    end
    krx_aniB_sb_ea
    move_back_to_pos
  end
  #--------------------------------------------------------------------------
  # ● Moves the battler towards the target
  #--------------------------------------------------------------------------
  def move_to_target
    @subject.movement_type = 2
    return unless @subject.current_action.item.move_to_target
    target = @subject.current_action.make_targets.compact[0]
    ctx =  @subject.screen_x > target.screen_x ? 96 : -96
    cty = KRX::MOVEMENT_Y_OFFSET * @subject.current_action.item.move_direction
    @subject.x_destination = target.screen_x + ctx
    @subject.y_destination = target.screen_y + cty
    @subject.movement_type = 0
    update_basic while @subject.is_moving?
  end
  #--------------------------------------------------------------------------
  # ● Moves the battler back to where they started
  #--------------------------------------------------------------------------
  def move_back_to_pos
    return unless @subject.movement_type == 0
    @subject.x_destination = @subject.screen_x
    @subject.y_destination = @subject.screen_y
    @subject.movement_type = 1
    update_basic while @subject.is_moving?
  end
  #--------------------------------------------------------------------------
  # ● Use a Banish skill
  #--------------------------------------------------------------------------
  if $imported['KRX-BanishSkills']
  def use_banish_skill(target, orig_item, skill_id)
    @log_window.display_use_item(@subject, orig_item)
    @subject.use_item(orig_item)
    @log_window.display_banish(orig_item, target)
    item = $data_skills[skill_id]
    @log_window.display_use_item(target, item)
    target.actions << Game_Action.new(self)
    target.current_action.set_skill(item.id)
    target.skill_pose_active = true
    wait_for_animation
    target.use_item(item)
    target.remove_banish_state
    refresh_status
    show_animation([@subject], item.animation_id)
    item.repeats.times do
      @subject.item_apply(target, item)
      refresh_status
      @log_window.display_action_results(@subject, item)
    end
    target.skill_pose_active = false
    target.actions.clear
  end; end
end

if $imported["YES-BattleSymphony"]
#===========================================================================
# ■ Spriteset_Battle
#===========================================================================
class Spriteset_Battle  
  #--------------------------------------------------------------------------
  def update_actors
    @actor_sprites.each_with_index do |sprite, i|
      party_member = $game_party.battle_members[i]
      if party_member != sprite.battler
        sprite.battler = $game_party.battle_members[i]
        #---
        if party_member
          party_member.reset_position
          party_member.correct_origin_position
          party_member.break_pose if party_member.dead?
        end
      end
      sprite.update
    end
  end
end
#===========================================================================
# ■ Game_Actor
#===========================================================================
class Game_Actor
  #--------------------------------------------------------------------------
  def use_charset?
    return false
  end
end
end